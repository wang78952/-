<?php
// 检查PerformanceOptimizer.php文件的语法
$file = 'd:\迅雷下载\发卡系统\includes\performance\PerformanceOptimizer.php';

if (!file_exists($file)) {
    echo "文件不存在: $file\n";
    exit(1);
}

echo "开始检查文件: $file\n";

try {
    // 使用token_get_all解析PHP文件
    $tokens = token_get_all(file_get_contents($file));
    echo "文件解析成功，没有发现语法错误\n";
} catch (Exception $e) {
    echo "发现错误: " . $e->getMessage() . "\n";
}

// 手动检查花括号匹配
echo "\n开始检查花括号匹配:\n";
$openBraces = 0;
$closeBraces = 0;
$content = file_get_contents($file);

for ($i = 0; $i < strlen($content); $i++) {
    if ($content[$i] === '{') {
        $openBraces++;
    } elseif ($content[$i] === '}') {
        $closeBraces++;
    }
}

echo "开括号数量: $openBraces\n";
echo "闭括号数量: $closeBraces\n";

if ($openBraces !== $closeBraces) {
    echo "错误: 花括号不匹配!\n";
} else {
    echo "花括号匹配正常\n";
}

// 检查冒号使用
echo "\n开始检查冒号使用模式:\n";
preg_match_all('/\}[\s]*\:|\:[\s]*\}/', $content, $matches);

if (!empty($matches[0])) {
    echo "发现潜在问题的冒号模式:\n";
    foreach ($matches[0] as $match) {
        echo "- $match\n";
    }
} else {
    echo "未发现异常的冒号模式\n";
}