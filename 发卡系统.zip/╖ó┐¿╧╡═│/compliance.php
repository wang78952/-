<?php
// 合规管理页面
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 模拟合规统计数据
$compliance_stats = [
    'total_policies' => 25,
    'active_policies' => 18,
    'compliance_rate' => 92.5,
    'pending_audits' => 3,
    'last_audit_date' => '2024-01-15',
    'risk_level' => 'low'
];

// 模拟合规政策数据
$policies = [
    ['id' => 1, 'name' => '数据保护政策', 'status' => 'active', 'last_reviewed' => '2024-01-10', 'compliance_score' => 95],
    ['id' => 2, 'name' => '访问控制政策', 'status' => 'active', 'last_reviewed' => '2024-01-08', 'compliance_score' => 88],
    ['id' => 3, 'name' => '密码安全政策', 'status' => 'pending', 'last_reviewed' => '2023-12-20', 'compliance_score' => 76],
    ['id' => 4, 'name' => '网络安全政策', 'status' => 'active', 'last_reviewed' => '2024-01-05', 'compliance_score' => 92],
    ['id' => 5, 'name' => '备份恢复政策', 'status' => 'active', 'last_reviewed' => '2024-01-12', 'compliance_score' => 89]
];

// 模拟审计记录数据
$audits = [
    ['id' => 1, 'policy_name' => '数据保护政策', 'audit_date' => '2024-01-15', 'auditor' => '张三', 'status' => 'completed', 'score' => 95],
    ['id' => 2, 'policy_name' => '访问控制政策', 'audit_date' => '2024-01-14', 'auditor' => '李四', 'status' => 'completed', 'score' => 88],
    ['id' => 3, 'policy_name' => '密码安全政策', 'audit_date' => '2024-01-16', 'auditor' => '王五', 'status' => 'pending', 'score' => null]
];
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>合规管理 - 发卡系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);
            --warning-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .navbar {
            background: var(--primary-gradient);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: none;
            position: relative;
            overflow: hidden;
        }

        .stats-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .stats-card.primary::before { background: var(--primary-gradient); }
        .stats-card.success::before { background: var(--success-gradient); }
        .stats-card.warning::before { background: var(--warning-gradient); }
        .stats-card.info::before { background: var(--info-gradient); }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 1rem;
        }

        .stats-icon.primary { background: var(--primary-gradient); }
        .stats-icon.success { background: var(--success-gradient); }
        .stats-icon.warning { background: var(--warning-gradient); }
        .stats-icon.info { background: var(--info-gradient); }

        .nav-tabs .nav-link {
            border: none;
            color: #6c757d;
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
        }

        .nav-tabs .nav-link.active {
            background: var(--primary-gradient);
            color: white;
            border-radius: 8px;
        }

        .nav-tabs .nav-link:hover {
            color: #667eea;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .btn-gradient {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }

        .fade-in-up {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease;
        }

        .fade-in-up.active {
            opacity: 1;
            transform: translateY(0);
        }

        .compliance-score {
            font-size: 1.2rem;
            font-weight: bold;
        }

        .score-high { color: #28a745; }
        .score-medium { color: #ffc107; }
        .score-low { color: #dc3545; }

        .status-badge {
            padding: 0.35rem 0.65rem;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .risk-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 0.5rem;
        }

        .risk-low { background-color: #28a745; }
        .risk-medium { background-color: #ffc107; }
        .risk-high { background-color: #dc3545; }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-shield-check"></i> 发卡系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-house"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cards.php">
                            <i class="bi bi-credit-card"></i> 卡密管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart"></i> 订单管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="bi bi-people"></i> 用户管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="analytics.php">
                            <i class="bi bi-graph-up"></i> 数据分析
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="security.php">
                            <i class="bi bi-shield-lock"></i> 安全管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="compliance.php">
                            <i class="bi bi-clipboard-check"></i> 合规管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payment.php">
                            <i class="bi bi-credit-card-2-back"></i> 支付管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="monitoring.php">
                            <i class="bi bi-activity"></i> 监控管理
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> 管理员
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person"></i> 个人资料</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear"></i> 系统设置</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出登录</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- 主要内容 -->
    <div class="container-fluid mt-4">
        <!-- 页面标题 -->
        <div class="d-flex justify-content-between align-items-center mb-4 fade-in-up">
            <h2 class="mb-0">
                <i class="bi bi-clipboard-check"></i> 合规管理
            </h2>
            <div>
                <button class="btn btn-gradient me-2" id="refreshBtn">
                    <i class="bi bi-arrow-clockwise"></i> 刷新
                </button>
                <button class="btn btn-gradient" data-bs-toggle="modal" data-bs-target="#addPolicyModal">
                    <i class="bi bi-plus-circle"></i> 新增政策
                </button>
            </div>
        </div>

        <!-- 统计卡片 -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card primary fade-in-up">
                    <div class="stats-icon primary">
                        <i class="bi bi-file-earmark-text"></i>
                    </div>
                    <h3 class="mb-1"><?php echo $compliance_stats['total_policies']; ?></h3>
                    <p class="text-muted mb-0">总政策数</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card success fade-in-up">
                    <div class="stats-icon success">
                        <i class="bi bi-check-circle"></i>
                    </div>
                    <h3 class="mb-1"><?php echo $compliance_stats['active_policies']; ?></h3>
                    <p class="text-muted mb-0">生效政策</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card info fade-in-up">
                    <div class="stats-icon info">
                        <i class="bi bi-percent"></i>
                    </div>
                    <h3 class="mb-1"><?php echo $compliance_stats['compliance_rate']; ?>%</h3>
                    <p class="text-muted mb-0">合规率</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card warning fade-in-up">
                    <div class="stats-icon warning">
                        <i class="bi bi-clock-history"></i>
                    </div>
                    <h3 class="mb-1"><?php echo $compliance_stats['pending_audits']; ?></h3>
                    <p class="text-muted mb-0">待审核</p>
                </div>
            </div>
        </div>

        <!-- 功能选项卡 -->
        <ul class="nav nav-tabs mb-4" id="complianceTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="policies-tab" data-bs-toggle="tab" data-bs-target="#policies" type="button" role="tab">
                    <i class="bi bi-file-earmark-text"></i> 政策管理
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="audits-tab" data-bs-toggle="tab" data-bs-target="#audits" type="button" role="tab">
                    <i class="bi bi-clipboard-check"></i> 审核记录
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="risk-tab" data-bs-toggle="tab" data-bs-target="#risk" type="button" role="tab">
                    <i class="bi bi-exclamation-triangle"></i> 风险评估
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="reports-tab" data-bs-toggle="tab" data-bs-target="#reports" type="button" role="tab">
                    <i class="bi bi-file-earmark-bar-graph"></i> 合规报告
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="standards-tab" data-bs-toggle="tab" data-bs-target="#standards" type="button" role="tab">
                    <i class="bi bi-shield-check"></i> 标准管理
                </button>
            </li>
        </ul>

        <div class="tab-content" id="complianceTabContent">
            <!-- 政策管理 -->
            <div class="tab-pane fade show active" id="policies" role="tabpanel">
                <div class="table-container fade-in-up">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">合规政策列表</h5>
                        <div class="d-flex gap-2">
                            <input type="text" class="form-control" placeholder="搜索政策..." id="policySearch" style="width: 200px;">
                            <button class="btn btn-gradient" onclick="searchPolicies()">
                                <i class="bi bi-search"></i> 搜索
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>政策名称</th>
                                    <th>状态</th>
                                    <th>最后审核</th>
                                    <th>合规评分</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($policies as $policy): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($policy['name']); ?></td>
                                    <td>
                                        <?php if ($policy['status'] == 'active'): ?>
                                            <span class="status-badge bg-success text-white">生效</span>
                                        <?php else: ?>
                                            <span class="status-badge bg-warning text-dark">待审核</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($policy['last_reviewed']); ?></td>
                                    <td>
                                        <span class="compliance-score <?php echo $policy['compliance_score'] >= 90 ? 'score-high' : ($policy['compliance_score'] >= 70 ? 'score-medium' : 'score-low'); ?>">
                                            <?php echo $policy['compliance_score']; ?>%
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" onclick="viewPolicy(<?php echo $policy['id']; ?>)">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning" onclick="editPolicy(<?php echo $policy['id']; ?>)">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success" onclick="auditPolicy(<?php echo $policy['id']; ?>)">
                                            <i class="bi bi-clipboard-check"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 审核记录 -->
            <div class="tab-pane fade" id="audits" role="tabpanel">
                <div class="table-container fade-in-up">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">审核记录</h5>
                        <button class="btn btn-gradient" onclick="generateAuditReport()">
                            <i class="bi bi-file-earmark-text"></i> 生成报告
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>政策名称</th>
                                    <th>审核日期</th>
                                    <th>审核员</th>
                                    <th>状态</th>
                                    <th>评分</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($audits as $audit): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($audit['policy_name']); ?></td>
                                    <td><?php echo htmlspecialchars($audit['audit_date']); ?></td>
                                    <td><?php echo htmlspecialchars($audit['auditor']); ?></td>
                                    <td>
                                        <?php if ($audit['status'] == 'completed'): ?>
                                            <span class="status-badge bg-success text-white">已完成</span>
                                        <?php else: ?>
                                            <span class="status-badge bg-warning text-dark">进行中</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($audit['score'] !== null): ?>
                                            <span class="compliance-score <?php echo $audit['score'] >= 90 ? 'score-high' : ($audit['score'] >= 70 ? 'score-medium' : 'score-low'); ?>">
                                                <?php echo $audit['score']; ?>%
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" onclick="viewAudit(<?php echo $audit['id']; ?>)">
                                            <i class="bi bi-eye"></i> 查看
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 风险评估 -->
            <div class="tab-pane fade" id="risk" role="tabpanel">
                <div class="table-container fade-in-up">
                    <h5 class="mb-3">风险评估</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card border-0 bg-light mb-3">
                                <div class="card-body">
                                    <h6 class="card-title">总体风险等级</h6>
                                    <div class="d-flex align-items-center">
                                        <span class="risk-indicator risk-<?php echo $compliance_stats['risk_level']; ?>"></span>
                                        <span class="h4 mb-0">
                                            <?php 
                                            $risk_text = ['low' => '低风险', 'medium' => '中风险', 'high' => '高风险'];
                                            echo $risk_text[$compliance_stats['risk_level']];
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border-0 bg-light mb-3">
                                <div class="card-body">
                                    <h6 class="card-title">最后审核日期</h6>
                                    <p class="h4 mb-0"><?php echo $compliance_stats['last_audit_date']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>风险类型</th>
                                    <th>风险等级</th>
                                    <th>影响范围</th>
                                    <th>缓解措施</th>
                                    <th>状态</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>数据泄露风险</td>
                                    <td><span class="risk-indicator risk-low"></span>低</td>
                                    <td>全系统</td>
                                    <td>加密存储</td>
                                    <td><span class="status-badge bg-success text-white">已缓解</span></td>
                                </tr>
                                <tr>
                                    <td>访问控制风险</td>
                                    <td><span class="risk-indicator risk-medium"></span>中</td>
                                    <td>用户管理</td>
                                    <td>权限优化</td>
                                    <td><span class="status-badge bg-warning text-dark">处理中</span></td>
                                </tr>
                                <tr>
                                    <td>合规性风险</td>
                                    <td><span class="risk-indicator risk-low"></span>低</td>
                                    <td>政策执行</td>
                                    <td>定期审核</td>
                                    <td><span class="status-badge bg-success text-white">已缓解</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 合规报告 -->
            <div class="tab-pane fade" id="reports" role="tabpanel">
                <div class="table-container fade-in-up">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">合规报告</h5>
                        <button class="btn btn-gradient" onclick="generateComplianceReport()">
                            <i class="bi bi-file-earmark-arrow-down"></i> 生成报告
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <div class="card border-0">
                                <div class="card-body text-center">
                                    <i class="bi bi-file-earmark-pdf text-danger" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">月度合规报告</h6>
                                    <button class="btn btn-sm btn-outline-danger">下载</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="card border-0">
                                <div class="card-body text-center">
                                    <i class="bi bi-file-earmark-excel text-success" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">风险评估报告</h6>
                                    <button class="btn btn-sm btn-outline-success">下载</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="card border-0">
                                <div class="card-body text-center">
                                    <i class="bi bi-file-earmark-word text-primary" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">年度合规总结</h6>
                                    <button class="btn btn-sm btn-outline-primary">下载</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 标准管理 -->
            <div class="tab-pane fade" id="standards" role="tabpanel">
                <div class="table-container fade-in-up">
                    <h5 class="mb-3">合规标准</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="card border-0">
                                <div class="card-body">
                                    <h6 class="card-title">ISO 27001</h6>
                                    <p class="text-muted">信息安全管理体系</p>
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-success" style="width: 95%">95%</div>
                                    </div>
                                    <small class="text-muted">符合度: 95%</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="card border-0">
                                <div class="card-body">
                                    <h6 class="card-title">GDPR</h6>
                                    <p class="text-muted">通用数据保护条例</p>
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-info" style="width: 88%">88%</div>
                                    </div>
                                    <small class="text-muted">符合度: 88%</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="card border-0">
                                <div class="card-body">
                                    <h6 class="card-title">SOX</h6>
                                    <p class="text-muted">萨班斯-奥克斯利法案</p>
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-warning" style="width: 76%">76%</div>
                                    </div>
                                    <small class="text-muted">符合度: 76%</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="card border-0">
                                <div class="card-body">
                                    <h6 class="card-title">PCI DSS</h6>
                                    <p class="text-muted">支付卡行业数据安全标准</p>
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-primary" style="width: 92%">92%</div>
                                    </div>
                                    <small class="text-muted">符合度: 92%</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 新增政策模态框 -->
    <div class="modal fade" id="addPolicyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">新增合规政策</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addPolicyForm">
                        <div class="mb-3">
                            <label class="form-label">政策名称</label>
                            <input type="text" class="form-control" name="policy_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">政策类型</label>
                            <select class="form-select" name="policy_type" required>
                                <option value="">选择类型</option>
                                <option value="data_protection">数据保护</option>
                                <option value="access_control">访问控制</option>
                                <option value="security">安全政策</option>
                                <option value="backup">备份恢复</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">政策描述</label>
                            <textarea class="form-control" name="description" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">生效日期</label>
                            <input type="date" class="form-control" name="effective_date" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-gradient" onclick="savePolicy()">保存</button>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const elements = document.querySelectorAll('.fade-in-up');
            elements.forEach((el, index) => {
                setTimeout(() => {
                    el.classList.add('active');
                }, index * 100);
            });
        });

        // 刷新按钮
        document.getElementById('refreshBtn').addEventListener('click', function() {
            location.reload();
        });

        // 搜索政策
        function searchPolicies() {
            const searchTerm = document.getElementById('policySearch').value.toLowerCase();
            const rows = document.querySelectorAll('#policies tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        }

        // 查看政策详情
        function viewPolicy(id) {
            alert('查看政策详情: ID ' + id);
        }

        // 编辑政策
        function editPolicy(id) {
            alert('编辑政策: ID ' + id);
        }

        // 审核政策
        function auditPolicy(id) {
            alert('开始审核政策: ID ' + id);
        }

        // 查看审核详情
        function viewAudit(id) {
            alert('查看审核详情: ID ' + id);
        }

        // 生成审核报告
        function generateAuditReport() {
            alert('正在生成审核报告...');
        }

        // 生成合规报告
        function generateComplianceReport() {
            alert('正在生成合规报告...');
        }

        // 保存政策
        function savePolicy() {
            const form = document.getElementById('addPolicyForm');
            if (form.checkValidity()) {
                alert('政策保存成功！');
                bootstrap.Modal.getInstance(document.getElementById('addPolicyModal')).hide();
                form.reset();
            } else {
                form.reportValidity();
            }
        }
    </script>
</body>
</html>
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="kycTable">
                            <thead>
                                <tr>
                                    <th>用户ID</th>
                                    <th>真实姓名</th>
                                    <th>身份证号</th>
                                    <th>手机号</th>
                                    <th>邮箱</th>
                                    <th>验证分数</th>
                                    <th>状态</th>
                                    <th>创建时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="kycTableBody">
                                <!-- 动态加载 -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- AML警报 -->
        <div class="tab-pane fade" id="alerts" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">AML警报管理</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="alertsTable">
                            <thead>
                                <tr>
                                    <th>警报ID</th>
                                    <th>用户ID</th>
                                    <th>警报类型</th>
                                    <th>风险评分</th>
                                    <th>状态</th>
                                    <th>分配给</th>
                                    <th>创建时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="alertsTableBody">
                                <!-- 动态加载 -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 合规事件 -->
        <div class="tab-pane fade" id="events" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">合规事件日志</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="eventsTable">
                            <thead>
                                <tr>
                                    <th>事件类型</th>
                                    <th>严重程度</th>
                                    <th>描述</th>
                                    <th>用户ID</th>
                                    <th>事件时间</th>
                                </tr>
                            </thead>
                            <tbody id="eventsTableBody">
                                <!-- 动态加载 -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 数据留存 -->
        <div class="tab-pane fade" id="retention" role="tabpanel">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">数据留存策略</h5>
                    <div>
                        <button class="btn btn-success" onclick="executeRetentionPolicies()">
                            <i class="bi bi-play-fill"></i> 执行策略
                        </button>
                        <button class="btn btn-primary" onclick="showRetentionModal()">
                            <i class="bi bi-plus-circle"></i> 新增策略
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="retentionTable">
                            <thead>
                                <tr>
                                    <th>策略名称</th>
                                    <th>表名</th>
                                    <th>日期字段</th>
                                    <th>留存天数</th>
                                    <th>操作类型</th>
                                    <th>执行频率</th>
                                    <th>状态</th>
                                    <th>最后执行</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="retentionTableBody">
                                <!-- 动态加载 -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 合规报告 -->
        <div class="tab-pane fade" id="reports" role="tabpanel">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">合规报告</h5>
                    <button class="btn btn-primary" onclick="showReportModal()">
                        <i class="bi bi-plus-circle"></i> 生成报告
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="reportsTable">
                            <thead>
                                <tr>
                                    <th>报告ID</th>
                                    <th>报告类型</th>
                                    <th>开始日期</th>
                                    <th>结束日期</th>
                                    <th>状态</th>
                                    <th>文件大小</th>
                                    <th>生成时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="reportsTableBody">
                                <!-- 动态加载 -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 合规配置 -->
        <div class="tab-pane fade" id="config" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">合规配置</h5>
                </div>
                <div class="card-body">
                    <form id="configForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">AML风险阈值</label>
                                    <input type="number" class="form-control" name="aml_risk_threshold" value="60" min="0" max="100">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">KYC验证阈值</label>
                                    <input type="number" class="form-control" name="kyc_verification_threshold" value="80" min="0" max="100">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">数据留存默认天数</label>
                                    <input type="number" class="form-control" name="default_retention_days" value="2555" min="1">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">报告自动生成</label>
                                    <select class="form-select" name="auto_generate_reports">
                                        <option value="enabled">启用</option>
                                        <option value="disabled">禁用</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">高风险地区</label>
                            <textarea class="form-control" name="high_risk_regions" rows="3" placeholder="输入高风险地区代码，用逗号分隔"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">监控关键词</label>
                            <textarea class="form-control" name="monitoring_keywords" rows="3" placeholder="输入需要监控的关键词，用逗号分隔"></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> 保存配置
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- AML筛查模态框 -->
<div class="modal fade" id="amlScreeningModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">执行AML筛查</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="amlScreeningForm">
                    <div class="mb-3">
                        <label class="form-label">用户ID</label>
                        <input type="text" class="form-control" name="user_id" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">筛查原因</label>
                        <textarea class="form-control" name="screening_reason" rows="3" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" onclick="performAmlScreening()">执行筛查</button>
            </div>
        </div>
    </div>
</div>

<!-- KYC验证模态框 -->
<div class="modal fade" id="kycModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">新增KYC验证</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="kycForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">用户ID</label>
                                <input type="text" class="form-control" name="user_id" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">真实姓名</label>
                                <input type="text" class="form-control" name="real_name" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">身份证号</label>
                                <input type="text" class="form-control" name="id_number" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">手机号</label>
                                <input type="text" class="form-control" name="phone_number" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">邮箱</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" onclick="performKycVerification()">提交验证</button>
            </div>
        </div>
    </div>
</div>

<!-- AML警报处理模态框 -->
<div class="modal fade" id="alertProcessModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">处理AML警报</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="alertProcessForm">
                    <input type="hidden" name="alert_id">
                    
                    <div class="mb-3">
                        <label class="form-label">处理状态</label>
                        <select class="form-select" name="status" required>
                            <option value="">选择状态</option>
                            <option value="RESOLVED">已解决</option>
                            <option value="DISMISSED">已忽略</option>
                            <option value="ESCALATED">已上报</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">分配给</label>
                        <input type="text" class="form-control" name="assigned_to">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">处理说明</label>
                        <textarea class="form-control" name="resolution_notes" rows="4" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" onclick="processAmlAlert()">处理警报</button>
            </div>
        </div>
    </div>
</div>

<!-- 数据留存策略模态框 -->
<div class="modal fade" id="retentionModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">新增数据留存策略</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="retentionForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">策略名称</label>
                                <input type="text" class="form-control" name="policy_name" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">表名</label>
                                <input type="text" class="form-control" name="table_name" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">日期字段</label>
                                <input type="text" class="form-control" name="date_column" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">留存天数</label>
                                <input type="number" class="form-control" name="retention_days" required min="1">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">操作类型</label>
                                <select class="form-select" name="action_type" required>
                                    <option value="">选择操作</option>
                                    <option value="DELETE">删除</option>
                                    <option value="ARCHIVE">归档</option>
                                    <option value="ANONYMIZE">匿名化</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">执行频率</label>
                                <select class="form-select" name="execution_frequency" required>
                                    <option value="">选择频率</option>
                                    <option value="daily">每日</option>
                                    <option value="weekly">每周</option>
                                    <option value="monthly">每月</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" onclick="createRetentionPolicy()">创建策略</button>
            </div>
        </div>
    </div>
</div>

<!-- 报告生成模态框 -->
<div class="modal fade" id="reportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">生成合规报告</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="reportForm">
                    <div class="mb-3">
                        <label class="form-label">报告类型</label>
                        <select class="form-select" name="report_type" required>
                            <option value="">选择类型</option>
                            <option value="DAILY">日报</option>
                            <option value="WEEKLY">周报</option>
                            <option value="MONTHLY">月报</option>
                            <option value="CUSTOM">自定义</option>
                        </select>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">开始日期</label>
                                <input type="date" class="form-control" name="start_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">结束日期</label>
                                <input type="date" class="form-control" name="end_date" required>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" onclick="generateComplianceReport()">生成报告</button>
            </div>
        </div>
    </div>
</div>

<script>
// 页面加载动画
document.addEventListener('DOMContentLoaded', function() {
    // 页面加载动画
    document.body.classList.add('loaded');
    
    // 初始化工具提示
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // 加载初始数据
    loadComplianceStats();
    loadPolicies();
    loadAuditRecords();
    loadRiskAssessments();
    loadStandards();
});

// 刷新统计数据
function refreshStats() {
    showLoading();
    setTimeout(() => {
        loadComplianceStats();
        hideLoading();
        showNotification('统计数据已刷新', 'success');
    }, 1000);
}

// 加载合规统计数据
function loadComplianceStats() {
    const stats = <?php echo json_encode($compliance_stats); ?>;
    
    document.getElementById('totalPolicies').textContent = stats.total_policies;
    document.getElementById('activePolicies').textContent = stats.active_policies;
    document.getElementById('complianceRate').textContent = stats.compliance_rate + '%';
    document.getElementById('pendingReviews').textContent = stats.pending_reviews;
}

// 加载政策列表
function loadPolicies() {
    const policies = <?php echo json_encode($policies); ?>;
    const tbody = document.getElementById('policiesTableBody');
    
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    policies.forEach(policy => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${policy.id}</td>
            <td>${policy.title}</td>
            <td><span class="badge bg-${getStatusColor(policy.status)}">${policy.status}</span></td>
            <td>${policy.category}</td>
            <td>${policy.effective_date}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editPolicy(${policy.id})">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deletePolicy(${policy.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// 加载审核记录
function loadAuditRecords() {
    const records = <?php echo json_encode($audit_records); ?>;
    const tbody = document.getElementById('auditTableBody');
    
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    records.forEach(record => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${record.id}</td>
            <td>${record.type}</td>
            <td>${record.description}</td>
            <td>${record.auditor}</td>
            <td>${record.date}</td>
            <td><span class="badge bg-${getStatusColor(record.status)}">${record.status}</span></td>
        `;
        tbody.appendChild(row);
    });
}

// 加载风险评估
function loadRiskAssessments() {
    const risks = <?php echo json_encode($risk_assessments); ?>;
    
    ['high', 'medium', 'low'].forEach(level => {
        const container = document.getElementById(level + 'Risks');
        if (container) {
            container.innerHTML = '';
            
            const levelRisks = risks.filter(risk => risk.level === level);
            levelRisks.forEach(risk => {
                const riskCard = document.createElement('div');
                riskCard.className = 'card mb-2';
                riskCard.innerHTML = `
                    <div class="card-body">
                        <h6 class="card-title">${risk.title}</h6>
                        <p class="card-text small">${risk.description}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">风险值: ${risk.score}</small>
                            <button class="btn btn-sm btn-outline-primary" onclick="viewRiskDetails(${risk.id})">
                                <i class="bi bi-eye"></i> 详情
                            </button>
                        </div>
                    </div>
                `;
                container.appendChild(riskCard);
            });
        }
    });
}

// 加载合规标准
function loadStandards() {
    const standards = <?php echo json_encode($standards); ?>;
    const container = document.getElementById('standardsContainer');
    
    if (!container) return;
    
    container.innerHTML = '';
    
    standards.forEach(standard => {
        const standardCard = document.createElement('div');
        standardCard.className = 'col-md-6 mb-3';
        standardCard.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">${standard.name}</h6>
                    <p class="card-text small">${standard.description}</p>
                    <div class="progress mb-2">
                        <div class="progress-bar" style="width: ${standard.compliance_rate}%"></div>
                    </div>
                    <small class="text-muted">合规率: ${standard.compliance_rate}%</small>
                </div>
            </div>
        `;
        container.appendChild(standardCard);
    });
}

// 显示政策模态框
function showPolicyModal() {
    const modal = new bootstrap.Modal(document.getElementById('policyModal'));
    modal.show();
}

// 显示报告模态框
function showReportModal() {
    const modal = new bootstrap.Modal(document.getElementById('reportModal'));
    modal.show();
}

// 显示留存策略模态框
function showRetentionModal() {
    const modal = new bootstrap.Modal(document.getElementById('retentionModal'));
    modal.show();
}

// 执行留存策略
function executeRetentionPolicies() {
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('数据留存策略执行成功', 'success');
    }, 2000);
}

// 生成合规报告
function generateComplianceReport() {
    const form = document.getElementById('reportForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('合规报告生成成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('reportModal')).hide();
    }, 2000);
}

// 创建留存策略
function createRetentionPolicy() {
    const form = document.getElementById('retentionForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('数据留存策略创建成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('retentionModal')).hide();
    }, 2000);
}

// 处理AML警报
function processAmlAlert() {
    const form = document.getElementById('alertProcessForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('AML警报处理成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('alertProcessModal')).hide();
    }, 2000);
}

// 执行AML筛查
function performAmlScreening() {
    const form = document.getElementById('amlScreeningForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('AML筛查执行成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('amlScreeningModal')).hide();
    }, 2000);
}

// 执行KYC验证
function performKycVerification() {
    const form = document.getElementById('kycForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('KYC验证提交成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('kycModal')).hide();
    }, 2000);
}

// 保存配置
document.getElementById('configForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    showLoading();
    setTimeout(() => {
        hideLoading();
        showNotification('合规配置保存成功', 'success');
    }, 1000);
});

// 搜索功能
function searchPolicies() {
    const searchTerm = document.getElementById('policySearch').value.toLowerCase();
    const rows = document.querySelectorAll('#policiesTableBody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function searchAudits() {
    const searchTerm = document.getElementById('auditSearch').value.toLowerCase();
    const rows = document.querySelectorAll('#auditTableBody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

// 工具函数
function getStatusColor(status) {
    const colors = {
        'active': 'success',
        'pending': 'warning',
        'inactive': 'secondary',
        'completed': 'success',
        'failed': 'danger',
        'in_progress': 'info'
    };
    return colors[status] || 'secondary';
}

function showLoading() {
    const loader = document.createElement('div');
    loader.id = 'pageLoader';
    loader.className = 'position-fixed top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-center';
    loader.style.backgroundColor = 'rgba(0,0,0,0.5)';
    loader.style.zIndex = '9999';
    loader.innerHTML = '<div class="spinner-border text-light" role="status"><span class="visually-hidden">加载中...</span></div>';
    document.body.appendChild(loader);
}

function hideLoading() {
    const loader = document.getElementById('pageLoader');
    if (loader) {
        loader.remove();
    }
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    notification.style.zIndex = '9999';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

function editPolicy(id) {
    showNotification('编辑政策功能开发中...', 'info');
}

function deletePolicy(id) {
    if (confirm('确定要删除这个政策吗？')) {
        showNotification('政策删除成功', 'success');
    }
}

function viewRiskDetails(id) {
    showNotification('查看风险详情功能开发中...', 'info');
}
</script>

</body>
</html>