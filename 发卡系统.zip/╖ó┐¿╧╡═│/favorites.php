<?php
/**
 * 卡密收藏夹页面
 * 显示用户收藏的卡密列表
 */
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/Logger.php';
require_once __DIR__ . '/includes/api/middleware/AuthMiddleware.php';
require_once __DIR__ . '/includes/Response.php';

// 检查用户登录状态
$auth_middleware = new AuthMiddleware();
if (!$auth_middleware->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 获取当前用户信息
$user_info = $auth_middleware->getCurrentUserInfo();

// 页面标题
$page_title = '我的收藏夹';

// 页面导航
$current_page = 'favorites';

// 加载页面头部
include __DIR__ . '/includes/views/header.php';
?>

<!-- 页面内容 -->
<div class="container-fluid">
    <div class="row">
        <!-- 侧边栏 -->
        <div class="col-md-3 col-lg-2 sidebar">
            <?php include __DIR__ . '/includes/views/sidebar.php'; ?>
        </div>
        
        <!-- 主内容区 -->
        <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">我的收藏夹</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group mr-2">
                        <a href="dashboard.php" class="btn btn-sm btn-outline-secondary">返回首页</a>
                    </div>
                </div>
            </div>
            
            <!-- 收藏夹说明 -->
            <div class="alert alert-info" role="alert">
                <i class="icon-info-circle mr-2"></i>
                收藏夹可以帮您保存重要的卡密信息，方便日后查看和使用。您收藏的卡密信息将安全存储在您的账户中。
            </div>
            
            <!-- 加载指示器 -->
            <div id="loading-indicator" class="text-center py-5" style="display: none;">
                <div class="spinner-border" role="status">
                    <span class="sr-only">加载中...</span>
                </div>
                <p class="mt-2">加载收藏列表中...</p>
            </div>
            
            <!-- 收藏列表 -->
            <div id="favorites-list" class="row">
                <!-- 将通过JavaScript动态加载 -->
                <div class="col-12 text-center py-5">
                    <p>请稍候，正在加载您的收藏...</p>
                </div>
            </div>
            
            <!-- 分页控件 -->
            <div id="pagination" class="mt-5 justify-content-center">
                <!-- 将通过JavaScript动态加载 -->
            </div>
        </main>
    </div>
</div>

<!-- 加载所需的JavaScript -->
<?php include __DIR__ . '/includes/views/footer.php'; ?>
<script src="/assets/js/card_favorites.js"></script>
<script src="/assets/js/mobile_interactions.js"></script>