module.exports = {
  "env": {
    "browser": true,
    "es2021": true,
    "commonjs": true
  },
  "extends": [
    "standard"
  ],
  "parserOptions": {
    "ecmaVersion": "latest"
  },
  "rules": {
    // 缩进风格：2个空格
    "indent": ["error", 2],
    // 行尾使用分号
    "semi": ["error", "always"],
    // 字符串使用单引号
    "quotes": ["error", "single"],
    // 对象键值对末尾允许逗号
    "comma-dangle": ["error", "always-multiline"],
    // 禁止未使用的变量
    "no-unused-vars": ["warn", { "argsIgnorePattern": "^_" }],
    // 大括号风格
    "brace-style": ["error", "1tbs"],
    // 函数括号前必须有空格
    "space-before-function-paren": ["error", {
      "anonymous": "always",
      "named": "always",
      "asyncArrow": "always"
    }],
    // 箭头函数参数使用括号
    "arrow-parens": ["error", "always"],
    // 对象字面量键值对之间空格
    "key-spacing": ["error", { "beforeColon": false, "afterColon": true }],
    // 数组括号内部空格
    "array-bracket-spacing": ["error", "never"],
    // 对象括号内部空格
    "object-curly-spacing": ["error", "always"],
    // 逗号后必须有空格
    "comma-spacing": ["error", { "before": false, "after": true }],
    // 禁止console.log，仅允许console.error和console.warn
    "no-console": ["warn", { "allow": ["error", "warn"] }]
  }
};