<?php
// 检查已安装的PHP扩展
$extensions = get_loaded_extensions();

echo "已安装的PHP扩展：\n";
foreach ($extensions as $extension) {
    echo "- $extension\n";
}

// 检查特定扩展
$checkExtensions = ['brotli', 'zlib'];
echo "\n特定扩展检查：\n";
foreach ($checkExtensions as $ext) {
    $status = extension_loaded($ext) ? "✓ 已安装" : "✗ 未安装";
    echo "- $ext: $status\n";
}

// 检查PHP版本和配置
echo "\nPHP版本信息：\n";
echo "PHP版本: " . PHP_VERSION . "\n";
echo "PHP配置文件路径: " . php_ini_loaded_file() . "\n";
echo "扩展目录: " . ini_get('extension_dir') . "\n";

// 检查zlib压缩设置
if (extension_loaded('zlib')) {
    echo "\nZlib配置: \n";
    echo "zlib.output_compression: " . ini_get('zlib.output_compression') . "\n";
    echo "zlib.output_compression_level: " . ini_get('zlib.output_compression_level') . "\n";
}