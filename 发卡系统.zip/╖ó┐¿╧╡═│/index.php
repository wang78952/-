<?php
/**
 * 发卡系统首页
 * 
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

// 加载文件监控钩子，确保核心文件完整性
if (file_exists(__DIR__ . '/includes/file_monitor_hook.php')) {
    include_once __DIR__ . '/includes/file_monitor_hook.php';
}

// 引入授权验证模块
if (file_exists(__DIR__ . '/includes/license_validator.php')) {
    include_once __DIR__ . '/includes/license_validator.php';
}

// 引入配置文件
require_once 'config.php';

// 初始化插件管理器
$pluginManager = initializePluginManager();

// 触发系统初始化钩子
triggerHook('system.init', ['page' => 'index']);

// 获取数据库连接
$db = getDB();

// 获取卡片统计信息
try {
    $totalCards = $db->fetch("SELECT COUNT(*) as count FROM cards");
    $activeCards = $db->fetch("SELECT COUNT(*) as count FROM cards WHERE status = '正常'");
    $inactiveCards = $db->fetch("SELECT COUNT(*) as count FROM cards WHERE status = '未激活'");
    $frozenCards = $db->fetch("SELECT COUNT(*) as count FROM cards WHERE status = '冻结'");
    
    $total = $totalCards['count'];
    $active = $activeCards['count'];
    $inactive = $inactiveCards['count'];
    $frozen = $frozenCards['count'];
} catch (Exception $e) {
    $total = $active = $inactive = $frozen = 0;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - 首页</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* 导航栏样式 */
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            padding: 20px 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .logo::before {
            content: "💳";
            margin-right: 10px;
            font-size: 28px;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .nav-link {
            display: inline-block;
            padding: 10px 20px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: all 0.3s ease;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }
        
        .nav-link::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.3s ease;
        }
        
        .nav-link:hover::before {
            left: 100%;
        }
        
        .nav-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        /* 主要内容区域 */
        .main-content {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .welcome-title {
            font-size: 36px;
            color: #333;
            margin-bottom: 20px;
            font-weight: bold;
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .welcome-subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 40px;
        }
        
        /* 统计卡片 */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 40px 0;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .stat-card.total {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .stat-card.active {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }
        
        .stat-card.inactive {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        }
        
        .stat-card.frozen {
            background: linear-gradient(135deg, #ff6b6b 0%, #feca57 100%);
        }
        
        /* 功能按钮区域 */
        .features {
            margin-top: 40px;
        }
        
        .features-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 30px;
        }
        
        .feature-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .feature-button {
            display: block;
            padding: 20px;
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .feature-button:hover {
            border-color: #667eea;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .feature-icon {
            font-size: 40px;
            margin-bottom: 10px;
        }
        
        .feature-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .feature-desc {
            font-size: 14px;
            color: #666;
        }
        
        /* 响应式设计 */
        @media (max-width: 768px) {
            .navbar-content {
                flex-direction: column;
                gap: 20px;
            }
            
            .nav-links {
                justify-content: center;
            }
            
            .welcome-title {
                font-size: 28px;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .stats-container {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 480px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .feature-buttons {
                grid-template-columns: 1fr;
            }
        }
        
        /* 页脚 */
        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            color: white;
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 导航栏 -->
        <nav class="navbar">
            <div class="navbar-content">
                <a href="index.php" class="logo"><?php echo APP_NAME; ?></a>
                <div class="nav-links">
                    <a href="add_card.php" class="nav-link">添加卡片</a>
                    <a href="search_card.php" class="nav-link">查询卡片</a>
                    <a href="update_status.php" class="nav-link">修改状态</a>
                </div>
            </div>
        </nav>
        
        <!-- 主要内容 -->
        <main class="main-content">
            <h1 class="welcome-title">欢迎使用 <?php echo APP_NAME; ?></h1>
            <p class="welcome-subtitle">专业的卡片管理系统，为您提供高效的卡片管理解决方案</p>
            
            <!-- 统计信息 -->
            <div class="stats-container">
                <div class="stat-card total">
                    <div class="stat-number"><?php echo number_format($total); ?></div>
                    <div class="stat-label">总卡片数</div>
                </div>
                <div class="stat-card active">
                    <div class="stat-number"><?php echo number_format($active); ?></div>
                    <div class="stat-label">正常卡片</div>
                </div>
                <div class="stat-card inactive">
                    <div class="stat-number"><?php echo number_format($inactive); ?></div>
                    <div class="stat-label">未激活卡片</div>
                </div>
                <div class="stat-card frozen">
                    <div class="stat-number"><?php echo number_format($frozen); ?></div>
                    <div class="stat-label">冻结卡片</div>
                </div>
            </div>
            
            <!-- 功能区域 -->
            <div class="features">
                <h2 class="features-title">系统功能</h2>
                <div class="feature-buttons">
                    <a href="add_card.php" class="feature-button">
                        <div class="feature-icon">➕</div>
                        <div class="feature-title">添加卡片</div>
                        <div class="feature-desc">新增卡片信息到系统</div>
                    </a>
                    <a href="search_card.php" class="feature-button">
                        <div class="feature-icon">🔍</div>
                        <div class="feature-title">查询卡片</div>
                        <div class="feature-desc">搜索和查看卡片信息</div>
                    </a>
                    <a href="update_status.php" class="feature-button">
                        <div class="feature-icon">✏️</div>
                        <div class="feature-title">修改状态</div>
                        <div class="feature-desc">更新卡片状态信息</div>
                    </a>
                </div>
            </div>
        </main>
        
        <!-- 页脚 -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> v<?php echo APP_VERSION; ?> - 版权所有</p>
        </footer>
    </div>
    
    <script>
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stat-card, .feature-button');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>