<?php
/**
 * 操作日志审计系统
 * 扩展自check_logs_syntax.php，实现管理员操作（如改价）的自动化审计与异常行为标记
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('memory_limit', '256M');

class LogAuditSystem {
    private $db;
    private $config;
    private $auditResults = [];
    private $anomalies = [];
    private $notificationSystem;
    private $behaviorPatterns = []; // 存储行为模式
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 加载配置
        $this->config = [
            // 基础配置
            'price_change_threshold' => 20, // 价格变动阈值（百分比）
            'audit_time_range' => 7, // 审计最近7天
            'max_price_changes_per_hour' => 10, // 每小时最大价格变动次数
            'max_amount_per_withdrawal' => 5000, // 单次提现最大金额
            'suspicious_hours' => [0, 1, 2, 3, 4, 5], // 可疑操作时间段
            
            // 高级异常检测配置
            'anomaly_detection' => [
                'enabled' => true,
                'min_confidence' => 0.7, // 异常置信度阈值
                'historical_data_days' => 30, // 历史数据分析天数
                'behavior_baseline_days' => 14, // 行为基线建立天数
                'notification_threshold' => 3, // 触发通知的异常数量
            ],
            
            // 行为模式检测配置
            'pattern_detection' => [
                'sequence_length' => 3, // 序列模式最小长度
                'time_window_minutes' => 60, // 时间窗口大小
                'min_pattern_occurrences' => 3, // 最小模式出现次数
            ],
            
            // 通知配置
            'notifications' => [
                'enabled' => true,
                'email' => 'admin@example.com',
                'sms' => '+8613800138000',
                'alert_levels' => [
                    'high' => ['sms', 'email'],
                    'medium' => ['email'],
                    'low' => ['log']
                ]
            ],
            
            // 其他阈值配置
            'consecutive_failures' => 5, // 连续失败操作阈值
            'new_device_login_threshold' => 3, // 新设备登录阈值
            'ip_address_change_threshold' => 4, // IP地址变更阈值
            'admin_account_creation_threshold' => 2, // 管理员账户创建阈值
        ];
        
        // 初始化数据库连接
        $this->connectDatabase();
        
        // 初始化通知系统
        $this->notificationSystem = new NotificationSystem($this->config['notifications']);
        
        // 加载历史行为模式
        $this->loadHistoricalPatterns();
    }
    
    /**
     * 加载历史行为模式
     */
    private function loadHistoricalPatterns() {
        try {
            // 从数据库加载历史行为模式
            $query = "SELECT user_id, action_pattern, frequency, confidence_score, last_detected FROM behavior_patterns";
            $result = $this->db->query($query);
            
            while ($row = $result->fetch_assoc()) {
                $this->behaviorPatterns[$row['user_id']][] = [
                    'pattern' => json_decode($row['action_pattern'], true),
                    'frequency' => $row['frequency'],
                    'confidence' => $row['confidence_score'],
                    'last_detected' => $row['last_detected']
                ];
            }
            
            echo "📊 已加载历史行为模式数据\n";
            
        } catch (Exception $e) {
            echo "⚠️  无法加载历史行为模式: " . $e->getMessage() . "\n";
            // 初始化行为模式表（如果不存在）
            $this->createBehaviorPatternsTable();
        }
    }
    
    /**
     * 创建行为模式表
     */
    private function createBehaviorPatternsTable() {
        try {
            $createTable = "
                CREATE TABLE IF NOT EXISTS behavior_patterns (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    action_pattern TEXT NOT NULL,
                    frequency INT DEFAULT 1,
                    confidence_score FLOAT DEFAULT 0.5,
                    first_detected DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_detected DATETIME DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_confidence (confidence_score)
                )
            ";
            
            $this->db->query($createTable);
            echo "✅ 已创建行为模式表\n";
            
        } catch (Exception $e) {
            echo "✗ 创建行为模式表失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 连接数据库
     */
    private function connectDatabase() {
        try {
            // 尝试包含配置文件获取数据库连接信息
            if (file_exists('config.php')) {
                require_once 'config.php';
                if (defined('DB_HOST') && defined('DB_USER') && defined('DB_PASS') && defined('DB_NAME')) {
                    $this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                } else {
                    // 备用连接信息
                    $this->db = new mysqli('localhost', 'root', '', 'card_system');
                }
            } else {
                // 备用连接信息
                $this->db = new mysqli('localhost', 'root', '', 'card_system');
            }
            
            if ($this->db->connect_error) {
                throw new Exception("数据库连接失败: " . $this->db->connect_error);
            }
            
            // 设置字符集
            $this->db->set_charset("utf8mb4");
            
        } catch (Exception $e) {
            echo "✗ 数据库连接错误: " . $e->getMessage() . "\n";
            die();
        }
    }
    
    /**
     * 获取管理员操作日志
     */
    private function getAdminOperationLogs($days = 7) {
        try {
            $startDate = date('Y-m-d H:i:s', strtotime("-$days days"));
            $query = "
                SELECT 
                    ul.id, ul.user_id, ul.action, ul.action_type, ul.description, 
                    ul.details, ul.created_at, u.username, u.role
                FROM 
                    user_logs ul
                JOIN 
                    users u ON ul.user_id = u.id
                WHERE 
                    u.role IN ('admin', 'business_admin') 
                    AND ul.created_at >= ?
                ORDER BY 
                    ul.created_at DESC
            ";
            
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $startDate);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $logs = [];
            while ($row = $result->fetch_assoc()) {
                // 解析JSON详情
                if (!empty($row['details'])) {
                    $row['details'] = json_decode($row['details'], true);
                }
                $logs[] = $row;
            }
            
            $stmt->close();
            return $logs;
            
        } catch (Exception $e) {
            echo "✗ 获取操作日志失败: " . $e->getMessage() . "\n";
            return [];
        }
    }
    
    /**
     * 审计管理员改价操作
     */
    public function auditPriceChanges() {
        echo "\n🔍 开始审计管理员改价操作...\n";
        
        try {
            $logs = $this->getAdminOperationLogs($this->config['audit_time_range']);
            echo "📊 共获取到 " . count($logs) . " 条管理员操作日志\n";
            
            $priceChanges = [];
            $userPriceChanges = [];
            
            // 筛选改价相关操作
            foreach ($logs as $log) {
                if ($log['action_type'] == 'price_change' || 
                    strpos($log['action'], 'price') !== false || 
                    strpos($log['description'], '价格') !== false) {
                    
                    $priceChanges[] = $log;
                    
                    // 按用户和小时统计
                    $hourKey = $log['user_id'] . '_' . date('Y-m-d H', strtotime($log['created_at']));
                    if (!isset($userPriceChanges[$hourKey])) {
                        $userPriceChanges[$hourKey] = 0;
                    }
                    $userPriceChanges[$hourKey]++;
                    
                    // 检查价格变动幅度
                    if (isset($log['details']['old_price']) && isset($log['details']['new_price'])) {
                        $oldPrice = floatval($log['details']['old_price']);
                        $newPrice = floatval($log['details']['new_price']);
                        
                        if ($oldPrice > 0) {
                            $changePercent = abs(($newPrice - $oldPrice) / $oldPrice) * 100;
                            
                            // 检查是否超过阈值
                            if ($changePercent > $this->config['price_change_threshold']) {
                                $this->markAnomaly($log, 'large_price_change', [
                                    'old_price' => $oldPrice,
                                    'new_price' => $newPrice,
                                    'change_percent' => round($changePercent, 2),
                                    'threshold' => $this->config['price_change_threshold']
                                ]);
                            }
                        }
                    }
                    
                    // 检查操作时间是否在可疑时段
                    $hour = date('G', strtotime($log['created_at']));
                    if (in_array($hour, $this->config['suspicious_hours'])) {
                        $this->markAnomaly($log, 'suspicious_hour', [
                            'hour' => $hour,
                            'action' => $log['action']
                        ]);
                    }
                }
            }
            
            // 检查每小时价格变动频率
            foreach ($userPriceChanges as $hourKey => $count) {
                if ($count > $this->config['max_price_changes_per_hour']) {
                    list($userId, $hour) = explode('_', $hourKey);
                    
                    // 找到该时段的第一条日志作为标记点
                    foreach ($logs as $log) {
                        if ($log['user_id'] == $userId && date('Y-m-d H', strtotime($log['created_at'])) == $hour) {
                            $this->markAnomaly($log, 'frequent_price_changes', [
                                'user_id' => $userId,
                                'hour' => $hour,
                                'count' => $count,
                                'threshold' => $this->config['max_price_changes_per_hour']
                            ]);
                            break;
                        }
                    }
                }
            }
            
            $this->auditResults['price_changes'] = [
                'total' => count($priceChanges),
                'anomalies' => count(array_filter($this->anomalies, function($a) { 
                    return in_array($a['type'], ['large_price_change', 'frequent_price_changes', 'suspicious_hour']); 
                }))
            ];
            
            echo "📝 发现 " . count($priceChanges) . " 次价格变动操作\n";
            echo "⚠️  标记 " . $this->auditResults['price_changes']['anomalies'] . " 次异常价格变动\n";
            
        } catch (Exception $e) {
            echo "✗ 改价操作审计失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 标记异常行为
     */
    private function markAnomaly($log, $type, $details) {
        // 计算异常严重程度
        $severity = $this->calculateAnomalySeverity($type, $details);
        
        // 创建异常记录
        $anomaly = [
            'id' => $log['id'],
            'user_id' => $log['user_id'],
            'username' => $log['username'],
            'action' => $log['action'],
            'type' => $type,
            'severity' => $severity,
            'timestamp' => $log['created_at'],
            'details' => $details,
            'confidence' => $this->calculateConfidenceScore($type, $details),
            'risk_factors' => $this->identifyRiskFactors($log, $type, $details)
        ];
        
        $this->anomalies[] = $anomaly;
        
        // 发送通知（如果需要）
        $this->notifyAnomaly($anomaly);
        
        // 更新异常计数统计
        $this->updateAnomalyStatistics($anomaly);
    }
    
    /**
     * 计算异常严重程度
     */
    private function calculateAnomalySeverity($type, $details) {
        $severityMap = [
            'large_price_change' => 3, // 高
            'frequent_price_changes' => 2, // 中
            'suspicious_hour' => 2, // 中
            'large_withdrawal' => 3, // 高
            'frequent_withdrawals' => 2, // 中
            'withdrawal_pattern' => 3, // 高
            'unusual_login' => 2, // 中
            'permission_escalation' => 3, // 高
            'suspicious_sequence' => 2, // 中
            'data_exfiltration' => 3, // 高
        ];
        
        $baseSeverity = $severityMap[$type] ?? 1;
        
        // 根据细节调整严重程度
        if (isset($details['amount']) && $details['amount'] > 10000) {
            $baseSeverity = min(3, $baseSeverity + 1);
        }
        
        if (isset($details['pattern']) && $details['pattern'] == 'repeated_amount') {
            $baseSeverity = min(3, $baseSeverity + 1);
        }
        
        return $baseSeverity;
    }
    
    /**
     * 计算异常置信度分数
     */
    private function calculateConfidenceScore($type, $details) {
        // 基础置信度
        $confidence = 0.7; // 默认置信度
        
        switch ($type) {
            case 'large_price_change':
            case 'large_withdrawal':
                // 数值型异常有较高的置信度
                if (isset($details['amount']) || isset($details['change_percent'])) {
                    $confidence = 0.9;
                }
                break;
            case 'frequent_price_changes':
            case 'frequent_withdrawals':
                // 频率型异常根据频率提高置信度
                if (isset($details['count']) && $details['count'] > $details['threshold'] * 2) {
                    $confidence = 0.85;
                }
                break;
            case 'suspicious_hour':
                // 时间型异常置信度适中
                $confidence = 0.75;
                break;
            case 'withdrawal_pattern':
                // 模式型异常根据重复次数调整
                if (isset($details['count']) && $details['count'] >= 5) {
                    $confidence = 0.8;
                }
                break;
        }
        
        return $confidence;
    }
    
    /**
     * 识别风险因素
     */
    private function identifyRiskFactors($log, $type, $details) {
        $riskFactors = [];
        
        // 检查操作时间
        $hour = date('G', strtotime($log['created_at']));
        if (in_array($hour, $this->config['suspicious_hours'])) {
            $riskFactors[] = 'suspicious_time';
        }
        
        // 检查操作金额
        if (isset($details['amount']) && $details['amount'] > $this->config['max_amount_per_withdrawal']) {
            $riskFactors[] = 'excessive_amount';
        }
        
        // 检查频率
        if (isset($details['count']) && isset($details['threshold']) && $details['count'] > $details['threshold']) {
            $riskFactors[] = 'high_frequency';
        }
        
        // 检查模式
        if (isset($details['pattern'])) {
            $riskFactors[] = 'suspicious_pattern';
        }
        
        // 检查是否为高权限操作
        if (strpos($log['action'], 'admin') !== false || 
            strpos($log['action'], '权限') !== false || 
            strpos($log['action'], 'create') !== false) {
            $riskFactors[] = 'privileged_operation';
        }
        
        return $riskFactors;
    }
    
    /**
     * 发送异常通知
     */
    private function notifyAnomaly($anomaly) {
        if (!$this->config['notifications']['enabled']) {
            return;
        }
        
        // 根据严重程度确定通知方式
        $alertLevel = $anomaly['severity'] == 3 ? 'high' : ($anomaly['severity'] == 2 ? 'medium' : 'low');
        $notificationMethods = $this->config['notifications']['alert_levels'][$alertLevel] ?? ['log'];
        
        foreach ($notificationMethods as $method) {
            $this->notificationSystem->send($method, [
                'level' => $alertLevel,
                'title' => "【风险预警】检测到异常操作行为",
                'message' => $this->formatAnomalyMessage($anomaly),
                'details' => $anomaly
            ]);
        }
    }
    
    /**
     * 格式化异常消息
     */
    private function formatAnomalyMessage($anomaly) {
        $typeName = $this->getAnomalyTypeName($anomaly['type']);
        return sprintf(
            "%s 风险等级: %s\n用户: %s (ID: %s)\n操作: %s\n时间: %s\n详情: %s",
            $typeName,
            str_repeat('⚠️', $anomaly['severity']),
            $anomaly['username'],
            $anomaly['user_id'],
            $anomaly['action'],
            $anomaly['timestamp'],
            json_encode($anomaly['details'], JSON_UNESCAPED_UNICODE)
        );
    }
    
    /**
     * 更新异常统计
     */
    private function updateAnomalyStatistics($anomaly) {
        // 创建或更新统计记录
        $query = "
            INSERT INTO anomaly_statistics (user_id, anomaly_type, severity, count, last_occurrence)
            VALUES (?, ?, ?, 1, NOW())
            ON DUPLICATE KEY UPDATE 
                count = count + 1,
                last_occurrence = NOW(),
                updated_at = NOW()
        ";
        
        try {
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("iss", $anomaly['user_id'], $anomaly['type'], $anomaly['severity']);
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            // 如果表不存在，创建它
            $this->createAnomalyStatisticsTable();
        }
    }
    
    /**
     * 创建异常统计表
     */
    private function createAnomalyStatisticsTable() {
        try {
            $createTable = "
                CREATE TABLE IF NOT EXISTS anomaly_statistics (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    anomaly_type VARCHAR(100) NOT NULL,
                    severity INT NOT NULL,
                    count INT DEFAULT 1,
                    first_occurrence DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_occurrence DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_anomaly (user_id, anomaly_type, severity),
                    INDEX idx_user_id (user_id),
                    INDEX idx_severity (severity)
                )
            ";
            
            $this->db->query($createTable);
        } catch (Exception $e) {
            // 忽略错误，继续执行
        }
    }
    
    /**
     * 保存审计结果
     */
    private function saveAuditResults() {
        try {
            // 创建审计结果表（如果不存在）
            $createTable = "
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    audit_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                    log_id INT,
                    user_id INT,
                    username VARCHAR(100),
                    anomaly_type VARCHAR(100),
                    anomaly_severity INT,
                    anomaly_confidence FLOAT,
                    anomaly_details TEXT,
                    risk_factors TEXT,
                    action VARCHAR(255),
                    timestamp DATETIME,
                    status VARCHAR(50) DEFAULT 'unreviewed',
                    INDEX idx_user_id (user_id),
                    INDEX idx_anomaly_type (anomaly_type),
                    INDEX idx_severity (anomaly_severity),
                    INDEX idx_status (status)
                )
            ";
            
            $this->db->query($createTable);
            
            // 保存异常记录
            foreach ($this->anomalies as $anomaly) {
                $stmt = $this->db->prepare(
                    "INSERT INTO audit_logs (log_id, user_id, username, anomaly_type, anomaly_severity, anomaly_confidence, anomaly_details, risk_factors, action, timestamp) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                
                $detailsJson = json_encode($anomaly['details']);
                $riskFactorsJson = json_encode($anomaly['risk_factors']);
                $severity = isset($anomaly['severity']) ? $anomaly['severity'] : 1;
                $confidence = isset($anomaly['confidence']) ? $anomaly['confidence'] : 0.5;
                
                $stmt->bind_param(
                    "iisssdssss",
                    $anomaly['id'],
                    $anomaly['user_id'],
                    $anomaly['username'],
                    $anomaly['type'],
                    $severity,
                    $confidence,
                    $detailsJson,
                    $riskFactorsJson,
                    $anomaly['action'],
                    $anomaly['timestamp']
                );
                
                $stmt->execute();
                $stmt->close();
            }
            
            // 保存审计摘要
            $this->saveAuditSummary();
            
            echo "💾 审计结果已保存到数据库\n";
            
        } catch (Exception $e) {
            echo "✗ 保存审计结果失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 保存审计摘要
     */
    private function saveAuditSummary() {
        try {
            $summaryQuery = "
                INSERT INTO audit_summaries (total_logs, total_anomalies, high_severity, medium_severity, low_severity, risk_score, audit_date)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ";
            
            // 统计不同严重程度的异常
            $highSeverity = count(array_filter($this->anomalies, function($a) { return $a['severity'] == 3; }));
            $mediumSeverity = count(array_filter($this->anomalies, function($a) { return $a['severity'] == 2; }));
            $lowSeverity = count(array_filter($this->anomalies, function($a) { return $a['severity'] == 1; }));
            
            // 计算风险分数
            $riskScore = ($highSeverity * 10) + ($mediumSeverity * 5) + ($lowSeverity * 1);
            
            $stmt = $this->db->prepare($summaryQuery);
            $stmt->bind_param(
                "iiiiii",
                count($this->getAllAuditedLogs()),
                count($this->anomalies),
                $highSeverity,
                $mediumSeverity,
                $lowSeverity,
                $riskScore
            );
            
            $stmt->execute();
            $stmt->close();
            
        } catch (Exception $e) {
            // 创建摘要表
            $createSummaryTable = "
                CREATE TABLE IF NOT EXISTS audit_summaries (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    total_logs INT DEFAULT 0,
                    total_anomalies INT DEFAULT 0,
                    high_severity INT DEFAULT 0,
                    medium_severity INT DEFAULT 0,
                    low_severity INT DEFAULT 0,
                    risk_score INT DEFAULT 0,
                    audit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_audit_date (audit_date)
                )
            ";
            
            $this->db->query($createSummaryTable);
        }
    }
    
    /**
     * 获取所有审计的日志数量
     */
    private function getAllAuditedLogs() {
        // 这里应该返回所有被审计的日志记录
        // 由于我们没有保存所有审计的日志，这里返回一个估算值
        $adminLogs = $this->getAdminOperationLogs($this->config['audit_time_range']);
        $agentLogs = $this->getAgentOperationLogs($this->config['audit_time_range']);
        return array_merge($adminLogs, $agentLogs);
    }
    
    /**
     * 生成审计报告
     */
    public function generateReport() {
        echo "\n📋 生成审计报告...\n";
        echo "==================================================\n";
        echo "      操作日志审计报告 - " . date('Y-m-d H:i:s') . "      \n";
        echo "==================================================\n";
        
        // 总体统计
        echo "\n📊 总体统计:\n";
        echo "   ├── 价格变动操作: " . ($this->auditResults['price_changes']['total'] ?? 0) . " 次\n";
        echo "   ├── 代理提现操作: " . ($this->auditResults['agent_withdrawals']['total'] ?? 0) . " 次\n";
        echo "   └── 异常行为: " . count($this->anomalies) . " 次\n";
        
        // 分类统计
        echo "\n📊 分类异常统计:\n";
        echo "--------------------------------------------------\n";
        echo "   ├── 管理员操作异常: " . count(array_filter($this->anomalies, function($a) { 
            return isset($a['details']['agent_id']) ? false : true; 
        })) . " 次\n";
        echo "   └── 代理操作异常: " . count(array_filter($this->anomalies, function($a) { 
            return isset($a['details']['agent_id']); 
        })) . " 次\n";
        
        // 异常详情
        if (!empty($this->anomalies)) {
            echo "\n⚠️  异常行为详情:\n";
            echo "--------------------------------------------------\n";
            
            $typeCounts = [];
            foreach ($this->anomalies as $anomaly) {
                if (!isset($typeCounts[$anomaly['type']])) {
                    $typeCounts[$anomaly['type']] = 0;
                }
                $typeCounts[$anomaly['type']]++;
            }
            
            foreach ($typeCounts as $type => $count) {
                $typeName = $this->getAnomalyTypeName($type);
                echo "   ├── $typeName: $count 次\n";
            }
            
            // 显示管理员异常示例
            echo "\n🔍 管理员异常示例 (前3个):\n";
            $adminAnomalies = array_filter($this->anomalies, function($a) { 
                return !isset($a['details']['agent_id']); 
            });
            $showCount = 0;
            foreach ($adminAnomalies as $anomaly) {
                if ($showCount >= 3) break;
                
                $typeName = $this->getAnomalyTypeName($anomaly['type']);
                echo "   ┌───────────────────────────────────────────────────\n";
                echo "   │ #" . ($showCount + 1) . " $typeName\n";
                echo "   │ 用户: " . $anomaly['username'] . " (ID: " . $anomaly['user_id'] . ")\n";
                echo "   │ 操作: " . $anomaly['action'] . "\n";
                echo "   │ 时间: " . $anomaly['timestamp'] . "\n";
                echo "   │ 详情: " . json_encode($anomaly['details'], JSON_UNESCAPED_UNICODE) . "\n";
                echo "   └───────────────────────────────────────────────────\n";
                
                $showCount++;
            }
            
            // 显示代理异常示例
            echo "\n🔍 代理异常示例 (前3个):\n";
            $agentAnomalies = array_filter($this->anomalies, function($a) { 
                return isset($a['details']['agent_id']); 
            });
            $showCount = 0;
            foreach ($agentAnomalies as $anomaly) {
                if ($showCount >= 3) break;
                
                $typeName = $this->getAnomalyTypeName($anomaly['type']);
                echo "   ┌───────────────────────────────────────────────────\n";
                echo "   │ #" . ($showCount + 1) . " $typeName\n";
                echo "   │ 代理: " . $anomaly['username'] . " (ID: " . $anomaly['user_id'] . ")\n";
                echo "   │ 操作: " . $anomaly['action'] . "\n";
                echo "   │ 时间: " . $anomaly['timestamp'] . "\n";
                echo "   │ 详情: " . json_encode($anomaly['details'], JSON_UNESCAPED_UNICODE) . "\n";
                echo "   └───────────────────────────────────────────────────\n";
                
                $showCount++;
            }
        }
        
        // 风险评估
        $riskLevel = $this->assessRiskLevel();
        echo "\n🚨 风险评估:\n";
        echo "--------------------------------------------------\n";
        echo "   └── 系统风险等级: $riskLevel\n";
        
        echo "==================================================\n";
        echo "报告生成完毕！\n";
    }
    
    /**
     * 风险等级评估
     */
    private function assessRiskLevel() {
        // 基于异常数量和严重程度的综合风险评估
        $highSeverity = count(array_filter($this->anomalies, function($a) { return $a['severity'] == 3; }));
        $mediumSeverity = count(array_filter($this->anomalies, function($a) { return $a['severity'] == 2; }));
        $lowSeverity = count(array_filter($this->anomalies, function($a) { return $a['severity'] == 1; }));
        
        // 加权风险分数
        $riskScore = ($highSeverity * 10) + ($mediumSeverity * 5) + ($lowSeverity * 1);
        
        if ($riskScore == 0) {
            return "低风险 ✅";
        } elseif ($riskScore < 10) {
            return "中低风险 ⚠️";
        } elseif ($riskScore < 30) {
            return "中等风险 ⚠️⚠️";
        } else {
            return "高风险 🚨";
        }
    }
    
    /**
     * 检测异常行为模式
     */
    public function detectBehaviorPatterns($userId, $logs) {
        try {
            echo "🔍 正在检测用户 $userId 的行为模式...\n";
            
            // 提取操作序列
            $actionSequence = [];
            foreach ($logs as $log) {
                $actionSequence[] = [
                    'action' => $log['action_type'] ?? $log['action'],
                    'timestamp' => strtotime($log['created_at']),
                    'details' => $log['details']
                ];
            }
            
            // 检测序列模式
            $patterns = $this->findSequentialPatterns($actionSequence);
            
            // 保存检测到的模式
            foreach ($patterns as $pattern) {
                $this->saveBehaviorPattern($userId, $pattern);
            }
            
            echo "📝 发现 " . count($patterns) . " 个行为模式\n";
            
        } catch (Exception $e) {
            echo "✗ 行为模式检测失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 查找序列模式
     */
    private function findSequentialPatterns($actionSequence) {
        $patterns = [];
        $minLength = $this->config['pattern_detection']['sequence_length'];
        $windowMinutes = $this->config['pattern_detection']['time_window_minutes'];
        $windowSeconds = $windowMinutes * 60;
        
        // 遍历所有可能的序列起点
        for ($i = 0; $i <= count($actionSequence) - $minLength; $i++) {
            // 检查时间窗口
            $startTime = $actionSequence[$i]['timestamp'];
            $endTime = $actionSequence[$i + $minLength - 1]['timestamp'];
            
            if ($endTime - $startTime > $windowSeconds) {
                continue; // 超出时间窗口
            }
            
            // 提取模式
            $pattern = [];
            for ($j = 0; $j < $minLength; $j++) {
                $pattern[] = $actionSequence[$i + $j]['action'];
            }
            
            // 计算模式频率
            $frequency = $this->countPatternOccurrences($actionSequence, $pattern, $windowSeconds);
            
            // 如果频率足够高，保存模式
            if ($frequency >= $this->config['pattern_detection']['min_pattern_occurrences']) {
                $patterns[] = [
                    'sequence' => $pattern,
                    'frequency' => $frequency,
                    'confidence' => min(1.0, $frequency / 10), // 简单的置信度计算
                    'window_minutes' => $windowMinutes
                ];
            }
        }
        
        return $patterns;
    }
    
    /**
     * 计算模式出现频率
     */
    private function countPatternOccurrences($actionSequence, $pattern, $windowSeconds) {
        $count = 0;
        $patternLength = count($pattern);
        
        for ($i = 0; $i <= count($actionSequence) - $patternLength; $i++) {
            $match = true;
            $startTime = $actionSequence[$i]['timestamp'];
            
            for ($j = 0; $j < $patternLength; $j++) {
                if ($actionSequence[$i + $j]['action'] !== $pattern[$j]) {
                    $match = false;
                    break;
                }
                
                // 检查时间窗口
                if ($actionSequence[$i + $j]['timestamp'] - $startTime > $windowSeconds) {
                    $match = false;
                    break;
                }
            }
            
            if ($match) {
                $count++;
                $i += $patternLength - 1; // 跳过已匹配的部分
            }
        }
        
        return $count;
    }
    
    /**
     * 保存行为模式
     */
    private function saveBehaviorPattern($userId, $pattern) {
        try {
            $patternJson = json_encode($pattern['sequence']);
            
            // 检查是否已存在
            $checkQuery = "SELECT id, frequency FROM behavior_patterns WHERE user_id = ? AND action_pattern = ?";
            $stmt = $this->db->prepare($checkQuery);
            $stmt->bind_param("is", $userId, $patternJson);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // 更新现有模式
                $row = $result->fetch_assoc();
                $newFrequency = $row['frequency'] + $pattern['frequency'];
                
                $updateQuery = "UPDATE behavior_patterns SET frequency = ?, confidence_score = ?, last_detected = NOW() WHERE id = ?";
                $updateStmt = $this->db->prepare($updateQuery);
                $updateStmt->bind_param("idi", $newFrequency, $pattern['confidence'], $row['id']);
                $updateStmt->execute();
                $updateStmt->close();
            } else {
                // 插入新模式
                $insertQuery = "INSERT INTO behavior_patterns (user_id, action_pattern, frequency, confidence_score) VALUES (?, ?, ?, ?)";
                $insertStmt = $this->db->prepare($insertQuery);
                $insertStmt->bind_param("isid", $userId, $patternJson, $pattern['frequency'], $pattern['confidence']);
                $insertStmt->execute();
                $insertStmt->close();
            }
            
            $stmt->close();
            
        } catch (Exception $e) {
            // 忽略错误，继续执行
        }
    }
    
    /**
     * 获取异常类型名称
     */
    private function getAnomalyTypeName($type) {
        $typeNames = [
            'large_price_change' => '大额价格变动',
            'frequent_price_changes' => '频繁价格变动',
            'suspicious_hour' => '可疑时段操作',
            'large_withdrawal' => '大额提现',
            'frequent_withdrawals' => '频繁提现',
            'withdrawal_pattern' => '可疑提现模式'
        ];
        
        return $typeNames[$type] ?? $type;
    }
    
    /**
     * 获取代理操作日志
     */
    private function getAgentOperationLogs($days = 7) {
        try {
            $startDate = date('Y-m-d H:i:s', strtotime("-$days days"));
            $query = "
                SELECT 
                    ul.id, ul.user_id, ul.action, ul.action_type, ul.description, 
                    ul.details, ul.created_at, u.username, u.role
                FROM 
                    user_logs ul
                JOIN 
                    users u ON ul.user_id = u.id
                WHERE 
                    u.role = 'agent' 
                    AND ul.created_at >= ?
                ORDER BY 
                    ul.created_at DESC
            ";
            
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $startDate);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $logs = [];
            while ($row = $result->fetch_assoc()) {
                // 解析JSON详情
                if (!empty($row['details'])) {
                    $row['details'] = json_decode($row['details'], true);
                }
                $logs[] = $row;
            }
            
            $stmt->close();
            return $logs;
            
        } catch (Exception $e) {
            echo "✗ 获取代理操作日志失败: " . $e->getMessage() . "\n";
            return [];
        }
    }
    
    /**
     * 审计代理提现操作
     */
    public function auditAgentWithdrawals() {
        echo "\n🔍 开始审计代理提现操作...\n";
        
        try {
            $logs = $this->getAgentOperationLogs($this->config['audit_time_range']);
            echo "📊 共获取到 " . count($logs) . " 条代理操作日志\n";
            
            $withdrawals = [];
            $agentWithdrawals = []; // 按代理统计提现记录
            
            // 筛选提现相关操作
            foreach ($logs as $log) {
                if ($log['action_type'] == 'withdraw' || 
                    strpos($log['action'], 'withdraw') !== false || 
                    strpos($log['action'], '提现') !== false ||
                    strpos($log['description'], '提现') !== false) {
                    
                    $withdrawals[] = $log;
                    
                    // 按代理ID分组
                    if (!isset($agentWithdrawals[$log['user_id']])) {
                        $agentWithdrawals[$log['user_id']] = [];
                    }
                    $agentWithdrawals[$log['user_id']][] = $log;
                    
                    // 检查提现金额
                    if (isset($log['details']['amount'])) {
                        $amount = floatval($log['details']['amount']);
                        
                        // 检查是否超过单次提现阈值
                        if ($amount > $this->config['max_amount_per_withdrawal']) {
                            $this->markAnomaly($log, 'large_withdrawal', [
                                'amount' => $amount,
                                'threshold' => $this->config['max_amount_per_withdrawal'],
                                'agent_id' => $log['user_id']
                            ]);
                        }
                    }
                    
                    // 检查操作时间是否在可疑时段
                    $hour = date('G', strtotime($log['created_at']));
                    if (in_array($hour, $this->config['suspicious_hours'])) {
                        $this->markAnomaly($log, 'suspicious_hour', [
                            'hour' => $hour,
                            'action' => $log['action'],
                            'agent_id' => $log['user_id']
                        ]);
                    }
                }
            }
            
            // 检查每个代理的提现频率和模式
            foreach ($agentWithdrawals as $agentId => $agentLogs) {
                $this->checkWithdrawalPatterns($agentId, $agentLogs);
            }
            
            $this->auditResults['agent_withdrawals'] = [
                'total' => count($withdrawals),
                'anomalies' => count(array_filter($this->anomalies, function($a) { 
                    return $a['type'] == 'large_withdrawal' || 
                           ($a['type'] == 'suspicious_hour' && isset($a['details']['agent_id'])) ||
                           $a['type'] == 'frequent_withdrawals'; 
                }))
            ];
            
            echo "📝 发现 " . count($withdrawals) . " 次提现操作\n";
            echo "⚠️  标记 " . $this->auditResults['agent_withdrawals']['anomalies'] . " 次异常提现行为\n";
            
        } catch (Exception $e) {
            echo "✗ 代理提现操作审计失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 检查提现模式
     */
    private function checkWithdrawalPatterns($agentId, $logs) {
        // 按天统计提现次数
        $dailyCounts = [];
        $hourlyCounts = [];
        $totalAmount = 0;
        $amounts = [];
        
        foreach ($logs as $log) {
            $date = date('Y-m-d', strtotime($log['created_at']));
            $hourKey = date('Y-m-d H', strtotime($log['created_at']));
            
            // 日统计
            if (!isset($dailyCounts[$date])) {
                $dailyCounts[$date] = 0;
            }
            $dailyCounts[$date]++;
            
            // 小时统计
            if (!isset($hourlyCounts[$hourKey])) {
                $hourlyCounts[$hourKey] = 0;
            }
            $hourlyCounts[$hourKey]++;
            
            // 金额统计
            if (isset($log['details']['amount'])) {
                $amount = floatval($log['details']['amount']);
                $totalAmount += $amount;
                $amounts[] = $amount;
            }
        }
        
        // 检查每小时提现频率
        foreach ($hourlyCounts as $hourKey => $count) {
            if ($count >= 5) { // 每小时超过5次提现
                // 找到该时段的第一条日志作为标记点
                foreach ($logs as $log) {
                    if (date('Y-m-d H', strtotime($log['created_at'])) == $hourKey) {
                        $this->markAnomaly($log, 'frequent_withdrawals', [
                            'agent_id' => $agentId,
                            'hour' => $hourKey,
                            'count' => $count,
                            'pattern' => 'high_frequency'
                        ]);
                        break;
                    }
                }
            }
        }
        
        // 检查是否有相同金额多次提现的模式
        if (!empty($amounts)) {
            $amountCounts = array_count_values($amounts);
            arsort($amountCounts);
            
            foreach ($amountCounts as $amount => $count) {
                if ($count >= 3 && $amount > 0) { // 相同金额提现3次以上
                    // 找到该金额的第一条日志
                    foreach ($logs as $log) {
                        if (isset($log['details']['amount']) && floatval($log['details']['amount']) == $amount) {
                            $this->markAnomaly($log, 'withdrawal_pattern', [
                                'agent_id' => $agentId,
                                'amount' => $amount,
                                'count' => $count,
                                'pattern' => 'repeated_amount'
                            ]);
                            break;
                        }
                    }
                    break; // 只标记最频繁的金额模式
                }
            }
        }
    }
    
    /**
     * 执行完整审计
     */
    public function runFullAudit() {
        echo "==========================================\n";
        echo "      操作日志审计系统启动      \n";
        echo "==========================================\n";
        
        // 记录审计开始
        $startTime = microtime(true);
        echo "⏱️  开始时间: " . date('Y-m-d H:i:s') . "\n";
        
        // 执行各项审计
        $this->auditPriceChanges();
        $this->auditAgentWithdrawals();
        
        // 执行行为模式检测
        $this->performBehavioralAnalysis();
        
        // 保存结果
        $this->saveAuditResults();
        
        // 生成报告
        $this->generateReport();
        
        // 显示性能统计
        $endTime = microtime(true);
        $executionTime = round($endTime - $startTime, 2);
        echo "⏱️  执行时间: $executionTime 秒\n";
        echo "📊 处理日志数: " . count($this->getAllAuditedLogs()) . " 条\n";
        echo "🚨 标记异常数: " . count($this->anomalies) . " 个\n";
        
        // 关闭数据库连接
        if ($this->db) {
            $this->db->close();
        }
    }
    
    /**
     * 执行行为分析
     */
    private function performBehavioralAnalysis() {
        echo "\n🔬 执行行为模式分析...\n";
        
        try {
            // 获取所有用户ID
            $userIds = $this->getAllUserIds();
            
            foreach ($userIds as $userId) {
                // 获取用户的操作日志
                $userLogs = $this->getUserOperationLogs($userId);
                
                if (count($userLogs) >= $this->config['pattern_detection']['sequence_length']) {
                    // 检测行为模式
                    $this->detectBehaviorPatterns($userId, $userLogs);
                    
                    // 检测异常行为偏离
                    $this->detectBehavioralDeviations($userId, $userLogs);
                }
            }
            
        } catch (Exception $e) {
            echo "✗ 行为分析失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 获取所有用户ID
     */
    private function getAllUserIds() {
        $userIds = [];
        
        try {
            $query = "SELECT DISTINCT user_id FROM user_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("i", $this->config['audit_time_range']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $userIds[] = $row['user_id'];
            }
            
            $stmt->close();
            
        } catch (Exception $e) {
            // 如果查询失败，使用已有的用户ID
            $adminLogs = $this->getAdminOperationLogs($this->config['audit_time_range']);
            $agentLogs = $this->getAgentOperationLogs($this->config['audit_time_range']);
            
            foreach ($adminLogs as $log) {
                $userIds[$log['user_id']] = $log['user_id'];
            }
            
            foreach ($agentLogs as $log) {
                $userIds[$log['user_id']] = $log['user_id'];
            }
            
            $userIds = array_values($userIds);
        }
        
        return $userIds;
    }
    
    /**
     * 获取用户操作日志
     */
    private function getUserOperationLogs($userId) {
        $logs = [];
        
        try {
            $startDate = date('Y-m-d H:i:s', strtotime("-" . $this->config['audit_time_range'] . " days"));
            $query = "
                SELECT 
                    ul.id, ul.user_id, ul.action, ul.action_type, ul.description, 
                    ul.details, ul.created_at, u.username, u.role
                FROM 
                    user_logs ul
                JOIN 
                    users u ON ul.user_id = u.id
                WHERE 
                    ul.user_id = ? 
                    AND ul.created_at >= ?
                ORDER BY 
                    ul.created_at DESC
            ";
            
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("is", $userId, $startDate);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                if (!empty($row['details'])) {
                    $row['details'] = json_decode($row['details'], true);
                }
                $logs[] = $row;
            }
            
            $stmt->close();
            
        } catch (Exception $e) {
            // 忽略错误，返回空数组
        }
        
        return $logs;
    }
    
    /**
     * 检测行为偏差
     */
    private function detectBehavioralDeviations($userId, $logs) {
        // 实现行为偏差检测逻辑
        // 这里可以比较当前行为与历史行为基线
        // 例如：操作时间分布、操作频率、操作序列等
    }
    
    /**
     * 获取Web界面数据
     */
    public function getWebInterfaceData() {
        // 为Web界面准备数据
        return [
            'audit_summary' => $this->auditResults,
            'anomalies' => $this->anomalies,
            'risk_level' => $this->assessRiskLevel(),
            'anomaly_statistics' => $this->getAnomalyStatistics(),
            'top_risky_users' => $this->getTopRiskyUsers(),
            'audit_time' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * 获取异常统计
     */
    private function getAnomalyStatistics() {
        try {
            $query = "SELECT anomaly_type, COUNT(*) as count, AVG(anomaly_severity) as avg_severity FROM audit_logs GROUP BY anomaly_type ORDER BY count DESC LIMIT 10";
            $result = $this->db->query($query);
            
            $statistics = [];
            while ($row = $result->fetch_assoc()) {
                $statistics[] = $row;
            }
            
            return $statistics;
        } catch (Exception $e) {
            return [];
        }
    }
    
    /**
     * 获取风险最高的用户
     */
    private function getTopRiskyUsers() {
        try {
            $query = "SELECT user_id, username, COUNT(*) as anomaly_count, SUM(anomaly_severity) as total_risk FROM audit_logs JOIN users ON audit_logs.user_id = users.id GROUP BY user_id ORDER BY total_risk DESC LIMIT 5";
            $result = $this->db->query($query);
            
            $users = [];
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
            
            return $users;
        } catch (Exception $e) {
            return [];
        }
    }
}

/**
 * 通知系统类
 */
class NotificationSystem {
    private $config;
    
    /**
     * 构造函数
     */
    public function __construct($config) {
        $this->config = $config;
    }
    
    /**
     * 发送通知
     */
    public function send($method, $data) {
        switch ($method) {
            case 'email':
                $this->sendEmailNotification($data);
                break;
            case 'sms':
                $this->sendSmsNotification($data);
                break;
            case 'log':
                $this->logNotification($data);
                break;
        }
    }
    
    /**
     * 发送邮件通知
     */
    private function sendEmailNotification($data) {
        try {
            $to = $this->config['email'];
            $subject = $data['title'];
            $message = $data['message'];
            
            // 在实际环境中，这里应该使用PHPMailer或其他邮件库
            // 这里只是模拟邮件发送
            echo "📧 发送邮件通知到 $to: $subject\n";
            
            // 记录邮件发送
            $this->logNotification([
                'type' => 'email',
                'to' => $to,
                'subject' => $subject,
                'status' => 'sent'
            ]);
            
        } catch (Exception $e) {
            echo "✗ 邮件发送失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 发送短信通知
     */
    private function sendSmsNotification($data) {
        try {
            $to = $this->config['sms'];
            $message = substr($data['message'], 0, 160); // 短信长度限制
            
            // 在实际环境中，这里应该集成短信API
            // 这里只是模拟短信发送
            echo "📱 发送短信通知到 $to\n";
            
            // 记录短信发送
            $this->logNotification([
                'type' => 'sms',
                'to' => $to,
                'message' => $message,
                'status' => 'sent'
            ]);
            
        } catch (Exception $e) {
            echo "✗ 短信发送失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 记录通知
     */
    private function logNotification($data) {
        try {
            // 创建通知日志文件
            $logFile = 'notification_log.txt';
            $logEntry = date('Y-m-d H:i:s') . " | " . json_encode($data) . "\n";
            file_put_contents($logFile, $logEntry, FILE_APPEND);
        } catch (Exception $e) {
            // 忽略日志错误
        }
    }
}

/**
 * 交互式审计界面支持类
 */
class AuditWebInterface {
    private $auditSystem;
    
    /**
     * 构造函数
     */
    public function __construct($auditSystem) {
        $this->auditSystem = $auditSystem;
    }
    
    /**
     * 生成JSON响应
     */
    public function generateJsonResponse() {
        $data = $this->auditSystem->getWebInterfaceData();
        return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
    /**
     * 生成HTML报告
     */
    public function generateHtmlReport() {
        $data = $this->auditSystem->getWebInterfaceData();
        
        $html = "<!DOCTYPE html>
        <html>
        <head>
            <title>操作日志审计报告</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
                .container { max-width: 1200px; margin: 0 auto; background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #333; text-align: center; }
                .summary { background-color: #e8f4f8; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
                .stats { display: flex; justify-content: space-between; margin-bottom: 20px; }
                .stat-card { background-color: #f8f9fa; padding: 15px; border-radius: 4px; flex: 1; margin: 0 10px; text-align: center; }
                .stat-card h3 { margin-top: 0; color: #666; }
                .stat-card .value { font-size: 24px; font-weight: bold; margin: 10px 0; }
                .high-risk { color: #d9534f; }
                .medium-risk { color: #f0ad4e; }
                .low-risk { color: #5cb85c; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
                th { background-color: #f2f2f2; }
                tr:hover { background-color: #f5f5f5; }
                .severity-1 { background-color: #dff0d8; }
                .severity-2 { background-color: #fcf8e3; }
                .severity-3 { background-color: #f2dede; }
                .chart-container { margin: 20px 0; text-align: center; }
            </style>
        </head>
        <body>
            <div class='container'>
                <h1>操作日志审计报告</h1>
                <div class='summary'>
                    <p><strong>生成时间:</strong> {$data['audit_time']}</p>
                    <p><strong>风险等级:</strong> {$data['risk_level']}</p>
                </div>
                
                <div class='stats'>
                    <div class='stat-card'>
                        <h3>异常总数</h3>
                        <div class='value'>" . count($data['anomalies']) . "</div>
                    </div>
                    <div class='stat-card'>
                        <h3>高风险异常</h3>
                        <div class='value high-risk'>" . count(array_filter($data['anomalies'], function($a) { return $a['severity'] == 3; })) . "</div>
                    </div>
                    <div class='stat-card'>
                        <h3>中等风险异常</h3>
                        <div class='value medium-risk'>" . count(array_filter($data['anomalies'], function($a) { return $a['severity'] == 2; })) . "</div>
                    </div>
                    <div class='stat-card'>
                        <h3>低风险异常</h3>
                        <div class='value low-risk'>" . count(array_filter($data['anomalies'], function($a) { return $a['severity'] == 1; })) . "</div>
                    </div>
                </div>
                
                <h2>异常详情</h2>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>用户</th>
                        <th>操作</th>
                        <th>异常类型</th>
                        <th>严重程度</th>
                        <th>置信度</th>
                        <th>时间</th>
                    </tr>";
        
        foreach ($data['anomalies'] as $anomaly) {
            $severityClass = 'severity-' . $anomaly['severity'];
            $html .= "
                    <tr class='$severityClass'>
                        <td>{$anomaly['id']}</td>
                        <td>{$anomaly['username']}</td>
                        <td>{$anomaly['action']}</td>
                        <td>{$anomaly['type']}</td>
                        <td>" . str_repeat('⚠️', $anomaly['severity']) . "</td>
                        <td>" . round($anomaly['confidence'] * 100) . "%</td>
                        <td>{$anomaly['timestamp']}</td>
                    </tr>";
        }
        
        $html .= "
                </table>
                
                <h2>风险评估</h2>
                <div class='chart-container'>
                    <!-- 这里可以集成图表库，如Chart.js -->
                    <p>系统风险等级: {$data['risk_level']}</p>
                </div>
            </div>
        </body>
        </html>";
        
        return $html;
    }
}

// 主程序
try {
    echo "🚀 启动操作日志审计系统...\n";
    
    // 检查是否为Web访问
    $isWebRequest = isset($_SERVER['REQUEST_METHOD']);
    
    $auditSystem = new LogAuditSystem();
    $auditSystem->runFullAudit();
    
    // 如果是Web请求，生成HTML响应
    if ($isWebRequest) {
        header('Content-Type: text/html; charset=utf-8');
        $webInterface = new AuditWebInterface($auditSystem);
        echo $webInterface->generateHtmlReport();
    } else {
        // 命令行输出
        echo "\n✅ 审计完成！\n";
        echo "\n💡 提示：您可以通过Web浏览器访问本脚本查看交互式审计报告\n";
        echo "   例如：http://your-server/check_logs_syntax.php\n";
    }
    
} catch (Exception $e) {
    echo "✗ 审计系统异常: " . $e->getMessage() . "\n";
    exit(1);
}

echo "\n📝 原始语法检查功能保留...\n";
try {
    // 保留原始的语法检查功能
    $file = 'logs.php';
    if (file_exists($file)) {
        echo "✓ logs.php 文件存在\n";
    } else {
        echo "⚠️ logs.php 文件不存在\n";
    }
} catch (Exception $e) {
    echo "✗ 语法检查异常: " . $e->getMessage() . "\n";
?>