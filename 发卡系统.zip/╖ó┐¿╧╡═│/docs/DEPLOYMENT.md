# 发卡系统部署指南

## 目录
1. [环境要求](#环境要求)
2. [系统安装](#系统安装)
3. [配置文件设置](#配置文件设置)
4. [数据库初始化](#数据库初始化)
5. [Web服务器配置](#web服务器配置)
6. [安全配置](#安全配置)
7. [性能优化](#性能优化)
8. [监控与日志](#监控与日志)
9. [常见问题](#常见问题)
10. [维护与更新](#维护与更新)

## 环境要求

### 最低要求
- **操作系统**: Linux (Ubuntu 18.04+, CentOS 7+) 或 Windows Server 2016+
- **PHP版本**: PHP 7.4+ (推荐 PHP 8.0+)
- **数据库**: MySQL 5.7+ 或 MariaDB 10.3+ (推荐 MySQL 8.0+)
- **Web服务器**: Apache 2.4+ 或 Nginx 1.18+
- **内存**: 最低 2GB RAM (推荐 4GB+)
- **存储**: 最低 20GB 可用空间 (推荐 50GB+)

### PHP扩展要求
```bash
# 必需扩展
php-mysql
php-curl
php-gd
php-json
php-mbstring
php-openssl
php-session
php-xml
php-zip

# 推荐扩展
php-redis (用于缓存)
php-apcu (用于本地缓存)
php-imagick (用于图片处理)
```

### 可选组件
- **Redis**: 用于缓存和会话存储
- **Elasticsearch**: 用于全文搜索
- **Supervisor**: 用于进程管理
- **Fail2ban**: 用于安全防护

## 系统安装

### 1. 下载系统文件
```bash
# 使用Git克隆（推荐）
git clone https://github.com/your-repo/card-system.git
cd card-system

# 或下载压缩包
wget https://github.com/your-repo/card-system/archive/main.zip
unzip main.zip
cd card-system-main
```

### 2. 设置文件权限
```bash
# 设置基本权限
chmod -R 755 .
chmod -R 775 storage/
chmod -R 775 cache/
chmod -R 775 logs/
chmod -R 775 uploads/

# 设置所有者（根据实际Web服务器用户调整）
chown -R www-data:www-data .
# 或对于Apache
chown -R apache:apache .
```

### 3. 创建必要目录
```bash
mkdir -p storage/{app,framework,logs}
mkdir -p cache/{sessions,views,config}
mkdir -p logs/{app,nginx,mysql}
mkdir -p uploads/{products,avatars,documents}
mkdir -p backups/{database,files}
```

## 配置文件设置

### 1. 数据库配置
编辑 `config/database.php`:
```php
<?php
return [
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'card_system',
    'username' => 'card_user',
    'password' => 'your_secure_password',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
    'strict' => true,
    'engine' => 'InnoDB',
];
```

### 2. 应用配置
编辑 `config/app.php`:
```php
<?php
return [
    'app_name' => '发卡系统',
    'app_url' => 'https://your-domain.com',
    'debug' => false, // 生产环境设为false
    'timezone' => 'Asia/Shanghai',
    'locale' => 'zh-CN',
    
    // 安全配置
    'key' => 'your-32-character-encryption-key',
    'cipher' => 'AES-256-CBC',
    
    // 缓存配置
    'cache_driver' => 'redis',
    'session_driver' => 'redis',
    
    // 邮件配置
    'mail_driver' => 'smtp',
    'mail_host' => 'smtp.gmail.com',
    'mail_port' => 587,
    'mail_username' => 'your-email@gmail.com',
    'mail_password' => 'your-app-password',
    'mail_encryption' => 'tls',
];
```

### 3. Redis配置（可选）
编辑 `config/redis.php`:
```php
<?php
return [
    'client' => 'phpredis',
    'options' => [
        'cluster' => 'redis',
    ],
    'default' => [
        'url' => env('REDIS_URL'),
        'host' => env('REDIS_HOST', '127.0.0.1'),
        'password' => env('REDIS_PASSWORD', null),
        'port' => env('REDIS_PORT', '6379'),
        'database' => env('REDIS_DB', '0'),
    ],
    'cache' => [
        'url' => env('REDIS_URL'),
        'host' => env('REDIS_HOST', '127.0.0.1'),
        'password' => env('REDIS_PASSWORD', null),
        'port' => env('REDIS_PORT', '6379'),
        'database' => env('REDIS_CACHE_DB', '1'),
    ],
];
```

## 数据库初始化

### 1. 创建数据库
```sql
-- 登录MySQL
mysql -u root -p

-- 创建数据库
CREATE DATABASE card_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 创建用户并授权
CREATE USER 'card_user'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON card_system.* TO 'card_user'@'localhost';
FLUSH PRIVILEGES;

-- 退出MySQL
EXIT;
```

### 2. 导入数据库结构
```bash
# 导入基础表结构
mysql -u card_user -p card_system < database/schema.sql

# 导入初始数据
mysql -u card_user -p card_system < database/seed.sql

# 或使用PHP脚本
php scripts/database_install.php
```

### 3. 验证数据库安装
```bash
# 运行数据库检查脚本
php scripts/database_check.php

# 预期输出：
# ✓ 数据库连接成功
# ✓ 所有表创建完成
# ✓ 初始数据导入完成
```

## Web服务器配置

### Apache配置
创建虚拟主机配置文件 `/etc/apache2/sites-available/card-system.conf`:
```apache
<VirtualHost *:80>
    ServerName your-domain.com
    ServerAlias www.your-domain.com
    DocumentRoot /var/www/card-system/public
    
    <Directory /var/www/card-system/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/card-system-error.log
    CustomLog ${APACHE_LOG_DIR}/card-system-access.log combined
</VirtualHost>

# HTTPS配置
<VirtualHost *:443>
    ServerName your-domain.com
    ServerAlias www.your-domain.com
    DocumentRoot /var/www/card-system/public
    
    <Directory /var/www/card-system/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    SSLEngine on
    SSLCertificateFile /path/to/your/certificate.crt
    SSLCertificateKeyFile /path/to/your/private.key
    SSLCertificateChainFile /path/to/your/chain.crt
    
    ErrorLog ${APACHE_LOG_DIR}/card-system-ssl-error.log
    CustomLog ${APACHE_LOG_DIR}/card-system-ssl-access.log combined
</VirtualHost>
```

启用站点和模块：
```bash
# 启用站点
sudo a2ensite card-system.conf
sudo a2dissite 000-default.conf

# 启用必要模块
sudo a2enmod rewrite
sudo a2enmod ssl
sudo a2enmod headers

# 重启Apache
sudo systemctl restart apache2
```

### Nginx配置
创建虚拟主机配置文件 `/etc/nginx/sites-available/card-system`:
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    root /var/www/card-system/public;
    index index.php index.html;
    
    # SSL配置
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # 安全头
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    
    # PHP处理
    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
    }
    
    # 隐藏敏感文件
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    location ~ /(config|storage|cache|logs|backups)/ {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    # 主要路由
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    # 错误和访问日志
    access_log /var/log/nginx/card-system-access.log;
    error_log /var/log/nginx/card-system-error.log;
}
```

启用站点：
```bash
# 创建软链接
sudo ln -s /etc/nginx/sites-available/card-system /etc/nginx/sites-enabled/

# 测试配置
sudo nginx -t

# 重启Nginx
sudo systemctl restart nginx
```

## 安全配置

### 1. 文件系统安全
```bash
# 设置敏感文件权限
chmod 600 config/database.php
chmod 600 config/app.php
chmod 600 .env

# 隐藏敏感目录
echo "Deny from all" > storage/.htaccess
echo "Deny from all" > cache/.htaccess
echo "Deny from all" > logs/.htaccess
echo "Deny from all" > backups/.htaccess
```

### 2. PHP安全配置
编辑 `php.ini`:
```ini
# 隐藏PHP版本
expose_php = Off

# 错误显示
display_errors = Off
display_startup_errors = Off
log_errors = On
error_log = /var/log/php_errors.log

# 文件上传限制
file_uploads = On
upload_max_filesize = 10M
post_max_size = 12M
max_file_uploads = 20

# 执行时间限制
max_execution_time = 300
max_input_time = 300

# 内存限制
memory_limit = 256M

# 会话安全
session.cookie_httponly = 1
session.cookie_secure = 1
session.use_only_cookies = 1

# 其他安全设置
allow_url_fopen = Off
allow_url_include = Off
```

### 3. 防火墙配置
```bash
# Ubuntu/Debian
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# CentOS/RHEL
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload
```

### 4. SSL证书配置
```bash
# 使用Let's Encrypt获取免费SSL证书
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d your-domain.com -d www.your-domain.com

# 或使用Nginx
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# 设置自动续期
sudo crontab -e
# 添加以下行
0 12 * * * /usr/bin/certbot renew --quiet
```

## 性能优化

### 1. PHP性能优化
```ini
# OPcache配置
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=4000
opcache.revalidate_freq=60
opcache.fast_shutdown=1
opcache.enable_cli=1

# Redis会话存储
session.save_handler = redis
session.save_path = "tcp://127.0.0.1:6379"
```

### 2. 数据库优化
```sql
-- MySQL配置优化
SET GLOBAL innodb_buffer_pool_size = 1073741824; -- 1GB
SET GLOBAL innodb_log_file_size = 268435456; -- 256MB
SET GLOBAL innodb_flush_log_at_trx_commit = 2;
SET GLOBAL query_cache_size = 67108864; -- 64MB
SET GLOBAL query_cache_type = 1;
```

### 3. 缓存配置
```bash
# Redis配置优化
echo "maxmemory 512mb" >> /etc/redis/redis.conf
echo "maxmemory-policy allkeys-lru" >> /etc/redis/redis.conf
echo "save 900 1" >> /etc/redis/redis.conf
echo "save 300 10" >> /etc/redis/redis.conf
echo "save 60 10000" >> /etc/redis/redis.conf

# 重启Redis
sudo systemctl restart redis-server
```

## 监控与日志

### 1. 日志轮转配置
创建 `/etc/logrotate.d/card-system`:
```
/var/log/card-system/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        systemctl reload apache2
    endscript
}

/var/log/nginx/card-system-*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        systemctl reload nginx
    endscript
}
```

### 2. 系统监控脚本
创建 `/usr/local/bin/monitor-card-system.sh`:
```bash
#!/bin/bash

# 检查网站响应
if ! curl -f -s https://your-domain.com/health > /dev/null; then
    echo "$(date): Website is down" >> /var/log/card-system/monitor.log
    # 发送告警邮件或短信
fi

# 检查数据库连接
if ! mysql -u card_user -p'your_password' -e "SELECT 1" card_system > /dev/null 2>&1; then
    echo "$(date): Database connection failed" >> /var/log/card-system/monitor.log
fi

# 检查磁盘空间
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    echo "$(date): Disk usage is ${DISK_USAGE}%" >> /var/log/card-system/monitor.log
fi

# 检查内存使用
MEMORY_USAGE=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
if [ $MEMORY_USAGE -gt 90 ]; then
    echo "$(date): Memory usage is ${MEMORY_USAGE}%" >> /var/log/card-system/monitor.log
fi
```

设置定时任务：
```bash
# 添加到crontab
sudo crontab -e

# 每5分钟检查一次
*/5 * * * * /usr/local/bin/monitor-card-system.sh

# 每天凌晨备份数据库
0 2 * * * /usr/local/bin/backup-database.sh

# 每周清理日志
0 3 * * 0 /usr/local/bin/cleanup-logs.sh
```

## 常见问题

### 1. 500内部服务器错误
```bash
# 检查错误日志
tail -f /var/log/apache2/error.log
tail -f /var/log/nginx/error.log
tail -f /var/log/php_errors.log

# 检查文件权限
ls -la /var/www/card-system/
ls -la /var/www/card-system/storage/

# 检查PHP配置
php -m | grep mysql
php -i | grep memory_limit
```

### 2. 数据库连接失败
```bash
# 测试数据库连接
mysql -u card_user -p -h localhost card_system

# 检查MySQL服务状态
sudo systemctl status mysql

# 检查数据库用户权限
mysql -u root -p -e "SHOW GRANTS FOR 'card_user'@'localhost';"
```

### 3. 文件上传失败
```bash
# 检查上传目录权限
ls -la /var/www/card-system/uploads/

# 检查PHP上传配置
php -i | grep upload
php -i | grep post_max_size

# 检查磁盘空间
df -h
```

### 4. 性能问题
```bash
# 检查系统负载
top
htop
iostat -x 1

# 检查MySQL性能
mysql -u root -p -e "SHOW PROCESSLIST;"
mysql -u root -p -e "SHOW STATUS LIKE 'Slow_queries';"

# 检查PHP性能
php -v
php -m | grep opcache
```

## 维护与更新

### 1. 系统更新
```bash
# 更新系统包
sudo apt update && sudo apt upgrade -y

# 更新PHP包
sudo apt update
sudo apt install php8.0 php8.0-fpm php8.0-mysql php8.0-curl

# 重启服务
sudo systemctl restart apache2
sudo systemctl restart php8.0-fpm
```

### 2. 数据库维护
```bash
# 数据库优化
mysql -u root -p -e "OPTIMIZE TABLE card_system.users, card_system.orders, card_system.products;"

# 检查表完整性
mysql -u root -p -e "CHECK TABLE card_system.*;"

# 修复表（如需要）
mysql -u root -p -e "REPAIR TABLE card_system.users;"
```

### 3. 备份策略
创建备份脚本 `/usr/local/bin/backup-database.sh`:
```bash
#!/bin/bash
BACKUP_DIR="/var/backups/card-system"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="card_system"

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份数据库
mysqldump -u card_user -p'your_password' $DB_NAME | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# 备份文件
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /var/www/card-system/uploads/

# 清理旧备份（保留30天）
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete

echo "Backup completed: $DATE"
```

### 4. 安全检查
```bash
# 检查文件权限
find /var/www/card-system -type f -perm /o+w -exec ls -la {} \;

# 检查可疑文件
find /var/www/card-system -name "*.php" -exec grep -l "eval\|base64_decode\|shell_exec" {} \;

# 检查登录日志
sudo grep "Failed password" /var/log/auth.log | tail -20
```

---

## 联系支持

如果在部署过程中遇到问题，请通过以下方式获取支持：

- **技术支持邮箱**: support@example.com
- **文档网站**: https://docs.example.com
- **GitHub Issues**: https://github.com/your-repo/card-system/issues

## 版本历史

- **v2.0.0** - 当前版本，包含完整功能和优化
- **v1.5.0** - 添加批量操作和高级权限管理
- **v1.0.0** - 初始版本发布

---

*最后更新: 2024年1月*