# 发卡系统运维手册

## 目录
1. [系统监控](#系统监控)
2. [日志管理](#日志管理)
3. [备份与恢复](#备份与恢复)
4. [性能调优](#性能调优)
5. [安全运维](#安全运维)
6. [故障排除](#故障排除)
7. [日常维护](#日常维护)
8. [应急响应](#应急响应)

## 系统监控

### 1. 监控指标体系

#### 系统级指标
```bash
# CPU使用率监控
top -b -n 1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//'

# 内存使用率
free | awk 'NR==2{printf "%.2f%%", $3*100/$2}'

# 磁盘使用率
df -h | awk '$NF=="/"{printf "%s", $5}'

# 网络连接数
netstat -an | grep :80 | wc -l

# 系统负载
uptime | awk -F'load average:' '{print $2}'
```

#### 应用级指标
```bash
# PHP进程数
ps aux | grep php-fpm | wc -l

# MySQL连接数
mysql -u root -p -e "SHOW STATUS LIKE 'Threads_connected';" | tail -1

# Redis连接数
redis-cli info clients | grep connected_clients

# 网站响应时间
curl -o /dev/null -s -w "%{time_total}\n" https://your-domain.com

# 数据库查询时间
mysql -u root -p -e "SHOW STATUS LIKE 'Slow_queries';" | tail -1
```

#### 业务级指标
```bash
# 在线用户数
mysql -u card_user -p -e "SELECT COUNT(*) FROM user_sessions WHERE last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE);" card_system

# 今日订单数
mysql -u card_user -p -e "SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE();" card_system

# 今日销售额
mysql -u card_user -p -e "SELECT SUM(amount) FROM orders WHERE DATE(created_at) = CURDATE() AND status = 'completed';" card_system

# 卡密库存
mysql -u card_user -p -e "SELECT COUNT(*) FROM cards WHERE status = 'available';" card_system
```

### 2. 监控脚本实现

#### 主监控脚本 `/usr/local/bin/system-monitor.sh`
```bash
#!/bin/bash

# 配置参数
LOG_FILE="/var/log/card-system/monitor.log"
ALERT_EMAIL="admin@example.com"
WEB_URL="https://your-domain.com"
DB_USER="card_user"
DB_PASS="your_password"
DB_NAME="card_system"

# 创建日志目录
mkdir -p $(dirname $LOG_FILE)

# 函数：记录日志
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> $LOG_FILE
}

# 函数：发送告警
send_alert() {
    local subject=$1
    local message=$2
    echo "$message" | mail -s "$subject" $ALERT_EMAIL
    log_message "ALERT: $subject - $message"
}

# 函数：检查网站可用性
check_website() {
    local response=$(curl -s -o /dev/null -w "%{http_code}" $WEB_URL)
    if [ "$response" != "200" ]; then
        send_alert "网站不可用" "HTTP响应码: $response"
        return 1
    fi
    return 0
}

# 函数：检查数据库连接
check_database() {
    if ! mysql -u $DB_USER -p$DB_PASS -e "SELECT 1" $DB_NAME >/dev/null 2>&1; then
        send_alert "数据库连接失败" "无法连接到数据库 $DB_NAME"
        return 1
    fi
    return 0
}

# 函数：检查磁盘空间
check_disk_space() {
    local usage=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ $usage -gt 85 ]; then
        send_alert "磁盘空间不足" "当前使用率: ${usage}%"
        return 1
    fi
    return 0
}

# 函数：检查内存使用
check_memory() {
    local usage=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
    if [ $usage -gt 90 ]; then
        send_alert "内存使用过高" "当前使用率: ${usage}%"
        return 1
    fi
    return 0
}

# 函数：检查系统负载
check_load() {
    local load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    local cpu_count=$(nproc)
    local threshold=$(echo "$cpu_count * 0.8" | bc)
    
    if (( $(echo "$load > $threshold" | bc -l) )); then
        send_alert "系统负载过高" "当前负载: $load, CPU核心数: $cpu_count"
        return 1
    fi
    return 0
}

# 函数：检查服务状态
check_services() {
    local services=("apache2" "mysql" "redis-server")
    for service in "${services[@]}"; do
        if ! systemctl is-active --quiet $service; then
            send_alert "服务异常" "$service 服务未运行"
            return 1
        fi
    done
    return 0
}

# 执行所有检查
log_message "开始系统监控检查"

check_website
check_database
check_disk_space
check_memory
check_load
check_services

log_message "系统监控检查完成"
echo "---" >> $LOG_FILE
```

#### 性能监控脚本 `/usr/local/bin/performance-monitor.sh`
```bash
#!/bin/bash

# 性能数据收集脚本
METRICS_FILE="/var/log/card-system/metrics.csv"
DB_USER="card_user"
DB_PASS="your_password"
DB_NAME="card_system"

# 创建CSV文件头（如果文件不存在）
if [ ! -f "$METRICS_FILE" ]; then
    echo "timestamp,cpu_usage,memory_usage,disk_usage,load_avg,mysql_connections,redis_connections,website_response_time" > $METRICS_FILE
fi

# 收集指标
timestamp=$(date '+%Y-%m-%d %H:%M:%S')
cpu_usage=$(top -b -n 1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//')
memory_usage=$(free | awk 'NR==2{printf "%.2f", $3*100/$2}')
disk_usage=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
mysql_connections=$(mysql -u $DB_USER -p$DB_PASS -e "SHOW STATUS LIKE 'Threads_connected';" $DB_NAME | tail -1 | awk '{print $2}')
redis_connections=$(redis-cli info clients | grep connected_clients | cut -d: -f2 | tr -d '\r')
website_response_time=$(curl -o /dev/null -s -w "%{time_total}" https://your-domain.com)

# 写入CSV
echo "$timestamp,$cpu_usage,$memory_usage,$disk_usage,$load_avg,$mysql_connections,$redis_connections,$website_response_time" >> $METRICS_FILE

echo "性能指标收集完成: $timestamp"
```

### 3. 监控定时任务配置
```bash
# 编辑crontab
sudo crontab -e

# 添加监控任务
*/5 * * * * /usr/local/bin/system-monitor.sh
*/15 * * * * /usr/local/bin/performance-monitor.sh
0 0 * * * /usr/local/bin/daily-report.sh
```

## 日志管理

### 1. 日志分类与配置

#### 应用日志配置 `config/logging.php`
```php
<?php
return [
    'default' => 'stack',
    
    'channels' => [
        'stack' => [
            'driver' => 'stack',
            'channels' => ['single', 'daily'],
        ],
        
        'single' => [
            'driver' => 'single',
            'path' => storage_path('logs/app.log'),
            'level' => 'debug',
        ],
        
        'daily' => [
            'driver' => 'daily',
            'path' => storage_path('logs/app.log'),
            'level' => 'debug',
            'days' => 14,
        ],
        
        'error' => [
            'driver' => 'daily',
            'path' => storage_path('logs/error.log'),
            'level' => 'error',
            'days' => 30,
        ],
        
        'access' => [
            'driver' => 'daily',
            'path' => storage_path('logs/access.log'),
            'level' => 'info',
            'days' => 7,
        ],
        
        'payment' => [
            'driver' => 'daily',
            'path' => storage_path('logs/payment.log'),
            'level' => 'info',
            'days' => 90,
        ],
        
        'security' => [
            'driver' => 'daily',
            'path' => storage_path('logs/security.log'),
            'level' => 'warning',
            'days' => 180,
        ],
    ],
];
```

### 2. 日志轮转配置

#### 系统日志轮转 `/etc/logrotate.d/card-system`
```
/var/www/card-system/storage/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    sharedscripts
    postrotate
        systemctl reload apache2
    endscript
}

/var/log/card-system/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
}

/var/log/nginx/card-system-*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    sharedscripts
    postrotate
        systemctl reload nginx
    endscript
}
```

### 3. 日志分析脚本

#### 日志分析工具 `/usr/local/bin/log-analyzer.sh`
```bash
#!/bin/bash

# 日志分析脚本
LOG_DIR="/var/www/card-system/storage/logs"
REPORT_DIR="/var/log/card-system/reports"
DATE=$(date +%Y%m%d)

# 创建报告目录
mkdir -p $REPORT_DIR

# 函数：分析错误日志
analyze_errors() {
    local error_log="$LOG_DIR/error-$DATE.log"
    local report_file="$REPORT_DIR/error-analysis-$DATE.txt"
    
    if [ -f "$error_log" ]; then
        echo "=== 错误日志分析报告 - $DATE ===" > $report_file
        echo "生成时间: $(date)" >> $report_file
        echo "" >> $report_file
        
        # 统计错误类型
        echo "=== 错误类型统计 ===" >> $report_file
        grep -o "ERROR: [A-Z_]*" $error_log | sort | uniq -c | sort -nr >> $report_file
        echo "" >> $report_file
        
        # 统计错误最多的文件
        echo "=== 错误文件统计 ===" >> $report_file
        grep -o "in [^:]*:" $error_log | sort | uniq -c | sort -nr | head -10 >> $report_file
        echo "" >> $report_file
        
        # 错误时间分布
        echo "=== 错误时间分布 ===" >> $report_file
        grep -o "^\[.*\]" $error_log | cut -d[ -f2 | cut -d] -f1 | cut -d: -f1 | sort | uniq -c >> $report_file
        
        echo "错误分析报告已生成: $report_file"
    fi
}

# 函数：分析访问日志
analyze_access() {
    local access_log="$LOG_DIR/access-$DATE.log"
    local report_file="$REPORT_DIR/access-analysis-$DATE.txt"
    
    if [ -f "$access_log" ]; then
        echo "=== 访问日志分析报告 - $DATE ===" > $report_file
        echo "生成时间: $(date)" >> $report_file
        echo "" >> $report_file
        
        # 访问量统计
        echo "=== 访问量统计 ===" >> $report_file
        echo "总访问次数: $(wc -l < $access_log)" >> $report_file
        echo "独立IP数: $(awk '{print $1}' $access_log | sort | uniq | wc -l)" >> $report_file
        echo "" >> $report_file
        
        # 热门页面
        echo "=== 热门页面 TOP 10 ===" >> $report_file
        grep -o "GET [^\?]*" $access_log | sort | uniq -c | sort -nr | head -10 >> $report_file
        echo "" >> $report_file
        
        # 用户代理统计
        echo "=== 用户代理统计 ===" >> $report_file
        grep -o '"[^"]*"$' $access_log | sort | uniq -c | sort -nr | head -5 >> $report_file
        
        echo "访问分析报告已生成: $report_file"
    fi
}

# 函数：分析安全日志
analyze_security() {
    local security_log="$LOG_DIR/security-$DATE.log"
    local report_file="$REPORT_DIR/security-analysis-$DATE.txt"
    
    if [ -f "$security_log" ]; then
        echo "=== 安全日志分析报告 - $DATE ===" > $report_file
        echo "生成时间: $(date)" >> $report_file
        echo "" >> $report_file
        
        # 登录失败统计
        echo "=== 登录失败统计 ===" >> $report_file
        grep -c "登录失败" $security_log >> $report_file
        
        # 可疑IP统计
        echo "=== 可疑IP统计 ===" >> $report_file
        grep -o "IP: [0-9.]*" $security_log | sort | uniq -c | sort -nr | head -10 >> $report_file
        echo "" >> $report_file
        
        # 安全事件类型
        echo "=== 安全事件类型 ===" >> $report_file
        grep -o "WARNING: [A-Z_]*" $security_log | sort | uniq -c | sort -nr >> $report_file
        
        echo "安全分析报告已生成: $report_file"
    fi
}

# 执行分析
analyze_errors
analyze_access
analyze_security

echo "日志分析完成，报告保存在: $REPORT_DIR"
```

## 备份与恢复

### 1. 数据库备份策略

#### 自动备份脚本 `/usr/local/bin/backup-database.sh`
```bash
#!/bin/bash

# 数据库备份脚本
BACKUP_DIR="/var/backups/card-system/database"
DB_USER="card_user"
DB_PASS="your_password"
DB_NAME="card_system"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# 创建备份目录
mkdir -p $BACKUP_DIR

# 函数：备份数据库
backup_database() {
    local backup_file="$BACKUP_DIR/db_backup_$DATE.sql"
    local compressed_file="$backup_file.gz"
    
    echo "开始备份数据库: $DB_NAME"
    
    # 执行备份
    if mysqldump -u $DB_USER -p$DB_PASS \
        --single-transaction \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --default-character-set=utf8mb4 \
        $DB_NAME > $backup_file; then
        
        # 压缩备份文件
        gzip $backup_file
        
        echo "数据库备份完成: $compressed_file"
        
        # 验证备份文件
        if [ -f "$compressed_file" ] && [ -s "$compressed_file" ]; then
            echo "备份文件验证成功"
        else
            echo "备份文件验证失败"
            return 1
        fi
    else
        echo "数据库备份失败"
        return 1
    fi
}

# 函数：备份表结构
backup_schema() {
    local schema_file="$BACKUP_DIR/schema_$DATE.sql"
    
    echo "备份数据库结构..."
    
    if mysqldump -u $DB_USER -p$DB_PASS \
        --no-data \
        --routines \
        --triggers \
        --events \
        $DB_NAME > $schema_file; then
        
        gzip $schema_file
        echo "数据库结构备份完成: $schema_file.gz"
    else
        echo "数据库结构备份失败"
        return 1
    fi
}

# 函数：清理旧备份
cleanup_old_backups() {
    echo "清理 $RETENTION_DAYS 天前的备份文件..."
    
    find $BACKUP_DIR -name "db_backup_*.sql.gz" -mtime +$RETENTION_DAYS -delete
    find $BACKUP_DIR -name "schema_*.sql.gz" -mtime +$RETENTION_DAYS -delete
    
    echo "旧备份清理完成"
}

# 函数：备份验证
verify_backup() {
    local backup_file="$BACKUP_DIR/db_backup_$DATE.sql.gz"
    
    echo "验证备份文件完整性..."
    
    if gunzip -t $backup_file; then
        echo "备份文件完整性验证通过"
        return 0
    else
        echo "备份文件完整性验证失败"
        return 1
    fi
}

# 执行备份流程
echo "=== 数据库备份开始 ==="
echo "时间: $(date)"

backup_database
backup_schema
verify_backup
cleanup_old_backups

echo "=== 数据库备份完成 ==="
echo "备份目录: $BACKUP_DIR"
```

#### 数据库恢复脚本 `/usr/local/bin/restore-database.sh`
```bash
#!/bin/bash

# 数据库恢复脚本
BACKUP_DIR="/var/backups/card-system/database"
DB_USER="card_user"
DB_PASS="your_password"
DB_NAME="card_system"

# 函数：显示可用备份
list_backups() {
    echo "可用的数据库备份:"
    ls -la $BACKUP_DIR/db_backup_*.sql.gz | awk '{print $9}' | sed 's/.*\///'
}

# 函数：恢复数据库
restore_database() {
    local backup_file=$1
    
    if [ ! -f "$backup_file" ]; then
        echo "备份文件不存在: $backup_file"
        return 1
    fi
    
    echo "警告: 此操作将覆盖现有数据库"
    read -p "确认继续? (y/N): " confirm
    
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        echo "操作已取消"
        return 0
    fi
    
    echo "开始恢复数据库..."
    
    # 创建临时文件
    local temp_file="/tmp/restore_temp.sql"
    
    # 解压备份文件
    if gunzip -c $backup_file > $temp_file; then
        # 恢复数据库
        if mysql -u $DB_USER -p$DB_PASS $DB_NAME < $temp_file; then
            echo "数据库恢复成功"
        else
            echo "数据库恢复失败"
            rm -f $temp_file
            return 1
        fi
    else
        echo "备份文件解压失败"
        return 1
    fi
    
    # 清理临时文件
    rm -f $temp_file
    
    echo "数据库恢复完成"
}

# 主程序
if [ $# -eq 0 ]; then
    list_backups
    echo ""
    read -p "请输入要恢复的备份文件名: " backup_name
    backup_file="$BACKUP_DIR/$backup_name"
else
    backup_file=$1
fi

restore_database $backup_file
```

### 2. 文件备份策略

#### 文件备份脚本 `/usr/local/bin/backup-files.sh`
```bash
#!/bin/bash

# 文件备份脚本
BACKUP_DIR="/var/backups/card-system/files"
SOURCE_DIR="/var/www/card-system"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# 创建备份目录
mkdir -p $BACKUP_DIR

# 函数：备份上传文件
backup_uploads() {
    local upload_dir="$SOURCE_DIR/uploads"
    local backup_file="$BACKUP_DIR/uploads_$DATE.tar.gz"
    
    echo "备份上传文件..."
    
    if [ -d "$upload_dir" ]; then
        tar -czf $backup_file -C $(dirname $upload_dir) $(basename $upload_dir)
        echo "上传文件备份完成: $backup_file"
    else
        echo "上传目录不存在: $upload_dir"
    fi
}

# 函数：备份配置文件
backup_configs() {
    local config_dir="$SOURCE_DIR/config"
    local backup_file="$BACKUP_DIR/configs_$DATE.tar.gz"
    
    echo "备份配置文件..."
    
    if [ -d "$config_dir" ]; then
        tar -czf $backup_file -C $(dirname $config_dir) $(basename $config_dir)
        echo "配置文件备份完成: $backup_file"
    else
        echo "配置目录不存在: $config_dir"
    fi
}

# 函数：备份应用代码
backup_application() {
    local app_dir="$SOURCE_DIR"
    local exclude_file="/tmp/backup_exclude.txt"
    local backup_file="$BACKUP_DIR/application_$DATE.tar.gz"
    
    echo "备份应用代码..."
    
    # 创建排除文件列表
    cat > $exclude_file << EOF
uploads/
storage/logs/
cache/
.git/
node_modules/
*.log
.env
EOF
    
    tar -czf $backup_file -X $exclude_file -C $(dirname $app_dir) $(basename $app_dir)
    
    rm -f $exclude_file
    echo "应用代码备份完成: $backup_file"
}

# 函数：清理旧备份
cleanup_old_backups() {
    echo "清理 $RETENTION_DAYS 天前的文件备份..."
    
    find $BACKUP_DIR -name "*.tar.gz" -mtime +$RETENTION_DAYS -delete
    
    echo "旧文件备份清理完成"
}

# 执行备份
echo "=== 文件备份开始 ==="
echo "时间: $(date)"

backup_uploads
backup_configs
backup_application
cleanup_old_backups

echo "=== 文件备份完成 ==="
```

### 3. 自动备份配置

#### 完整备份脚本 `/usr/local/bin/full-backup.sh`
```bash
#!/bin/bash

# 完整系统备份脚本
BACKUP_ROOT="/var/backups/card-system"
DATE=$(date +%Y%m%d_%H%M%S)
REPORT_FILE="$BACKUP_ROOT/backup_report_$DATE.txt"

# 创建报告文件
echo "=== 系统备份报告 ===" > $REPORT_FILE
echo "备份时间: $(date)" >> $REPORT_FILE
echo "" >> $REPORT_FILE

# 执行数据库备份
echo "1. 执行数据库备份..." >> $REPORT_FILE
if /usr/local/bin/backup-database.sh >> $REPORT_FILE 2>&1; then
    echo "✓ 数据库备份成功" >> $REPORT_FILE
else
    echo "✗ 数据库备份失败" >> $REPORT_FILE
fi
echo "" >> $REPORT_FILE

# 执行文件备份
echo "2. 执行文件备份..." >> $REPORT_FILE
if /usr/local/bin/backup-files.sh >> $REPORT_FILE 2>&1; then
    echo "✓ 文件备份成功" >> $REPORT_FILE
else
    echo "✗ 文件备份失败" >> $REPORT_FILE
fi
echo "" >> $REPORT_FILE

# 备份系统配置
echo "3. 备份系统配置..." >> $REPORT_FILE
mkdir -p $BACKUP_ROOT/system
cp /etc/apache2/sites-available/card-system.conf $BACKUP_ROOT/system/ 2>/dev/null
cp /etc/nginx/sites-available/card-system $BACKUP_ROOT/system/ 2>/dev/null
cp /etc/mysql/mysql.conf.d/mysqld.cnf $BACKUP_ROOT/system/ 2>/dev/null
echo "✓ 系统配置备份完成" >> $REPORT_FILE
echo "" >> $REPORT_FILE

# 生成备份清单
echo "4. 生成备份清单..." >> $REPORT_FILE
echo "备份文件清单:" >> $REPORT_FILE
find $BACKUP_ROOT -name "*$DATE*" -type f -exec ls -lh {} \; >> $REPORT_FILE

# 发送备份报告
if command -v mail >/dev/null 2>&1; then
    cat $REPORT_FILE | mail -s "系统备份报告 - $DATE" admin@example.com
fi

echo "完整备份完成，报告文件: $REPORT_FILE"
```

## 性能调优

### 1. 数据库性能优化

#### MySQL优化配置 `/etc/mysql/mysql.conf.d/99-performance.cnf`
```ini
[mysqld]
# 内存配置
innodb_buffer_pool_size = 2G
innodb_buffer_pool_instances = 4
innodb_log_file_size = 256M
innodb_log_buffer_size = 16M

# 连接配置
max_connections = 500
max_connect_errors = 1000
connect_timeout = 10
wait_timeout = 600
interactive_timeout = 600

# 查询缓存
query_cache_type = 1
query_cache_size = 256M
query_cache_limit = 2M

# 临时表配置
tmp_table_size = 256M
max_heap_table_size = 256M

# InnoDB配置
innodb_flush_log_at_trx_commit = 2
innodb_flush_method = O_DIRECT
innodb_file_per_table = 1
innodb_open_files = 400

# 慢查询日志
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2

# 二进制日志
log_bin = /var/log/mysql/mysql-bin.log
binlog_format = ROW
expire_logs_days = 7
max_binlog_size = 100M

# 字符集配置
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
```

#### 数据库性能监控脚本 `/usr/local/bin/db-performance-monitor.sh`
```bash
#!/bin/bash

# 数据库性能监控脚本
DB_USER="card_user"
DB_PASS="your_password"
DB_NAME="card_system"
REPORT_FILE="/var/log/card-system/db-performance-$(date +%Y%m%d).txt"

# 函数：获取数据库状态
get_db_status() {
    mysql -u $DB_USER -p$DB_PASS -e "SHOW GLOBAL STATUS;" $DB_NAME
}

# 函数：获取数据库变量
get_db_variables() {
    mysql -u $DB_USER -p$DB_PASS -e "SHOW GLOBAL VARIABLES;" $DB_NAME
}

# 函数：分析慢查询
analyze_slow_queries() {
    local slow_log="/var/log/mysql/slow.log"
    local today=$(date +%Y-%m-%d)
    
    if [ -f "$slow_log" ]; then
        echo "=== 今日慢查询分析 ===" >> $REPORT_FILE
        grep "$today" $slow_log | wc -l >> $REPORT_FILE
        echo "" >> $REPORT_FILE
    fi
}

# 函数：检查表状态
check_table_status() {
    echo "=== 表状态检查 ===" >> $REPORT_FILE
    mysql -u $DB_USER -p$DB_PASS -e "SHOW TABLE STATUS;" $DB_NAME | \
    awk 'NR>1 {print $1, $6, $8, $10}' | \
    while read table rows data_size index_size; do
        echo "$表: $rows 行, 数据: $data_size, 索引: $index_size" >> $REPORT_FILE
    done
    echo "" >> $REPORT_FILE
}

# 函数：性能建议
performance_recommendations() {
    echo "=== 性能优化建议 ===" >> $REPORT_FILE
    
    # 检查连接数
    local max_connections=$(mysql -u $DB_USER -p$DB_PASS -e "SHOW VARIABLES LIKE 'max_connections';" $DB_NAME | tail -1 | awk '{print $2}')
    local current_connections=$(mysql -u $DB_USER -p$DB_PASS -e "SHOW STATUS LIKE 'Threads_connected';" $DB_NAME | tail -1 | awk '{print $2}')
    local usage_percent=$((current_connections * 100 / max_connections))
    
    if [ $usage_percent -gt 80 ]; then
        echo "- 当前连接使用率: ${usage_percent}%, 建议增加max_connections" >> $REPORT_FILE
    fi
    
    # 检查查询缓存命中率
    local qcache_hits=$(mysql -u $DB_USER -p$DB_PASS -e "SHOW STATUS LIKE 'Qcache_hits';" $DB_NAME | tail -1 | awk '{print $2}')
    local qcache_inserts=$(mysql -u $DB_USER -p$DB_PASS -e "SHOW STATUS LIKE 'Qcache_inserts';" $DB_NAME | tail -1 | awk '{print $2}')
    
    if [ $qcache_inserts -gt 0 ]; then
        local hit_rate=$((qcache_hits * 100 / (qcache_hits + qcache_inserts)))
        if [ $hit_rate -lt 80 ]; then
            echo "- 查询缓存命中率: ${hit_rate}%, 建议优化查询或增加query_cache_size" >> $REPORT_FILE
        fi
    fi
    
    echo "" >> $REPORT_FILE
}

# 生成性能报告
echo "=== 数据库性能报告 - $(date) ===" > $REPORT_FILE
echo "" >> $REPORT_FILE

check_table_status
analyze_slow_queries
performance_recommendations

echo "数据库性能报告已生成: $REPORT_FILE"
```

### 2. PHP性能优化

#### PHP-FPM配置优化 `/etc/php/8.0/fpm/pool.d/www.conf`
```ini
[www]
user = www-data
group = www-data
listen = /run/php/php8.0-fpm.sock
listen.owner = www-data
listen.group = www-data
listen.mode = 0660

# 进程管理
pm = dynamic
pm.max_children = 100
pm.start_servers = 20
pm.min_spare_servers = 10
pm.max_spare_servers = 30
pm.max_requests = 500

# 进程优先级
process.priority = -5

# 超时设置
request_terminate_timeout = 300
request_slowlog_timeout = 10

# 慢日志
slowlog = /var/log/php8.0-fpm-slow.log

# 安全设置
security.limit_extensions = .php
```

#### PHP性能监控脚本 `/usr/local/bin/php-performance-monitor.sh`
```bash
#!/bin/bash

# PHP性能监控脚本
PHP_FPM_STATUS_URL="http://localhost/fpm_status"
REPORT_FILE="/var/log/card-system/php-performance-$(date +%Y%m%d).txt"

# 函数：获取PHP-FPM状态
get_fpm_status() {
    if command -v curl >/dev/null 2>&1; then
        curl -s $PHP_FPM_STATUS_URL
    fi
}

# 函数：检查PHP进程
check_php_processes() {
    echo "=== PHP进程状态 ===" >> $REPORT_FILE
    ps aux | grep php-fpm | grep -v grep | wc -l >> $REPORT_FILE
    echo "" >> $REPORT_FILE
}

# 函数：检查OPcache状态
check_opcache() {
    echo "=== OPcache状态 ===" >> $REPORT_FILE
    php -r "echo 'OPcache启用: ' . (ini_get('opcache.enable') ? '是' : '否') . PHP_EOL;" >> $REPORT_FILE
    php -r "echo '内存使用: ' . round(opcache_get_status()['memory_usage']['used']/1024/1024, 2) . 'MB' . PHP_EOL;" >> $REPORT_FILE
    php -r "echo '缓存命中率: ' . round(opcache_get_status()['opcache_statistics']['hit_rate'], 2) . '%' . PHP_EOL;" >> $REPORT_FILE
    echo "" >> $REPORT_FILE
}

# 函数：性能建议
php_performance_tips() {
    echo "=== PHP性能建议 ===" >> $REPORT_FILE
    
    # 检查内存限制
    local memory_limit=$(php -r "echo ini_get('memory_limit');")
    echo "- 当前内存限制: $memory_limit" >> $REPORT_FILE
    
    # 检查执行时间限制
    local max_execution_time=$(php -r "echo ini_get('max_execution_time');")
    echo "- 最大执行时间: $max_execution_time 秒" >> $REPORT_FILE
    
    # 检查文件上传限制
    local upload_max_filesize=$(php -r "echo ini_get('upload_max_filesize');")
    echo "- 文件上传限制: $upload_max_filesize" >> $REPORT_FILE
    
    echo "" >> $REPORT_FILE
}

# 生成PHP性能报告
echo "=== PHP性能报告 - $(date) ===" > $REPORT_FILE
echo "" >> $REPORT_FILE

check_php_processes
check_opcache
php_performance_tips

echo "PHP性能报告已生成: $REPORT_FILE"
```

## 安全运维

### 1. 安全扫描脚本

#### 安全检查脚本 `/usr/local/bin/security-scan.sh`
```bash
#!/bin/bash

# 系统安全扫描脚本
REPORT_FILE="/var/log/card-system/security-scan-$(date +%Y%m%d).txt"
WEB_ROOT="/var/www/card-system"

# 函数：检查文件权限
check_file_permissions() {
    echo "=== 文件权限检查 ===" >> $REPORT_FILE
    
    # 检查可写文件
    echo "可写文件列表:" >> $REPORT_FILE
    find $WEB_ROOT -type f -perm /o+w -exec ls -la {} \; >> $REPORT_FILE
    echo "" >> $REPORT_FILE
    
    # 检查敏感文件权限
    echo "敏感文件权限:" >> $REPORT_FILE
    ls -la $WEB_ROOT/config/ >> $REPORT_FILE
    ls -la $WEB_ROOT/.env* 2>/dev/null >> $REPORT_FILE
    echo "" >> $REPORT_FILE
}

# 函数：检查可疑代码
check_suspicious_code() {
    echo "=== 可疑代码检查 ===" >> $REPORT_FILE
    
    # 检查常见的恶意代码模式
    echo "检查可疑函数调用:" >> $REPORT_FILE
    find $WEB_ROOT -name "*.php" -exec grep -l "eval\|base64_decode\|shell_exec\|system\|passthru" {} \; >> $REPORT_FILE
    echo "" >> $REPORT_FILE
    
    # 检查webshell特征
    echo "检查WebShell特征:" >> $REPORT_FILE
    find $WEB_ROOT -name "*.php" -exec grep -l "cmd=\|exec=\|shell=" {} \; >> $REPORT_FILE
    echo "" >> $REPORT_FILE
}

# 函数：检查SSL证书
check_ssl_certificate() {
    echo "=== SSL证书检查 ===" >> $REPORT_FILE
    
    local domain="your-domain.com"
    local cert_info=$(echo | openssl s_client -servername $domain -connect $domain:443 2>/dev/null | openssl x509 -noout -dates)
    
    echo "SSL证书信息:" >> $REPORT_FILE
    echo "$cert_info" >> $REPORT_FILE
    
    # 检查证书过期时间
    local expiry_date=$(echo "$cert_info" | grep "notAfter" | cut -d= -f2)
    local expiry_timestamp=$(date -d "$expiry_date" +%s)
    local current_timestamp=$(date +%s)
    local days_until_expiry=$(( (expiry_timestamp - current_timestamp) / 86400 ))
    
    if [ $days_until_expiry -lt 30 ]; then
        echo "警告: SSL证书将在 $days_until_expiry 天后过期" >> $REPORT_FILE
    fi
    
    echo "" >> $REPORT_FILE
}

# 函数：检查系统更新
check_system_updates() {
    echo "=== 系统更新检查 ===" >> $REPORT_FILE
    
    # 检查包更新
    if command -v apt >/dev/null 2>&1; then
        apt list --upgradable 2>/dev/null | grep -v "WARNING" >> $REPORT_FILE
    elif command -v yum >/dev/null 2>&1; then
        yum check-updates >> $REPORT_FILE
    fi
    
    echo "" >> $REPORT_FILE
}

# 函数：检查登录日志
check_login_logs() {
    echo "=== 登录日志检查 ===" >> $REPORT_FILE
    
    # 检查最近的失败登录
    echo "最近24小时失败登录:" >> $REPORT_FILE
    journalctl -u ssh --since "24 hours ago" | grep "Failed password" | wc -l >> $REPORT_FILE
    
    # 检查可疑IP
    echo "频繁失败登录的IP:" >> $REPORT_FILE
    journalctl -u ssh --since "24 hours ago" | grep "Failed password" | \
    awk '{print $NF}' | sort | uniq -c | sort -nr | head -10 >> $REPORT_FILE
    
    echo "" >> $REPORT_FILE
}

# 函数：检查防火墙状态
check_firewall() {
    echo "=== 防火墙状态检查 ===" >> $REPORT_FILE
    
    if command -v ufw >/dev/null 2>&1; then
        ufw status verbose >> $REPORT_FILE
    elif command -v firewall-cmd >/dev/null 2>&1; then
        firewall-cmd --list-all >> $REPORT_FILE
    fi
    
    echo "" >> $REPORT_FILE
}

# 执行安全扫描
echo "=== 系统安全扫描报告 - $(date) ===" > $REPORT_FILE
echo "" >> $REPORT_FILE

check_file_permissions
check_suspicious_code
check_ssl_certificate
check_system_updates
check_login_logs
check_firewall

echo "安全扫描完成，报告文件: $REPORT_FILE"

# 如果发现安全问题，发送告警
if grep -q "警告\|Warning" $REPORT_FILE; then
    echo "发现安全问题，请查看报告: $REPORT_FILE" | mail -s "安全扫描告警" admin@example.com
fi
```

### 2. 入侵检测脚本

#### 入侵检测脚本 `/usr/local/bin/intrusion-detection.sh`
```bash
#!/bin/bash

# 入侵检测脚本
LOG_FILE="/var/log/card-system/intrusion-detection.log"
ALERT_EMAIL="admin@example.com"

# 函数：检测异常登录
detect_anomalous_login() {
    local current_hour=$(date +%H)
    local login_count=$(journalctl -u ssh --since "1 hour ago" | grep "Accepted password" | wc -l)
    
    # 如果非工作时间登录次数过多
    if [ $current_hour -lt 9 ] || [ $current_hour -gt 18 ]; then
        if [ $login_count -gt 5 ]; then
            echo "$(date): 检测到异常时间段登录活动，次数: $login_count" >> $LOG_FILE
            echo "异常时间段登录活动" | mail -s "安全告警" $ALERT_EMAIL
        fi
    fi
}

# 函数：检测文件完整性
detect_file_integrity() {
    local web_root="/var/www/card-system"
    local checksum_file="/var/tmp/file_checksums.md5"
    
    # 如果校验文件不存在，创建一个
    if [ ! -f "$checksum_file" ]; then
        find $web_root -name "*.php" -type f -exec md5sum {} \; > $checksum_file
        return
    fi
    
    # 检查文件变化
    local new_checksum_file="/tmp/new_checksums.md5"
    find $web_root -name "*.php" -type f -exec md5sum {} \; > $new_checksum_file
    
    # 比较校验和
    if ! diff -q $checksum_file $new_checksum_file >/dev/null; then
        echo "$(date): 检测到文件完整性变化" >> $LOG_FILE
        diff $checksum_file $new_checksum_file >> $LOG_FILE
        echo "文件完整性变化" | mail -s "安全告警" $ALERT_EMAIL
    fi
    
    # 更新校验文件
    mv $new_checksum_file $checksum_file
}

# 函数：检测异常进程
detect_anomalous_processes() {
    # 检查可疑进程
    local suspicious_processes=$(ps aux | grep -E "nc|netcat|telnet|wget|curl.*http" | grep -v grep)
    
    if [ ! -z "$suspicious_processes" ]; then
        echo "$(date): 检测到可疑进程:" >> $LOG_FILE
        echo "$suspicious_processes" >> $LOG_FILE
        echo "检测到可疑进程" | mail -s "安全告警" $ALERT_EMAIL
    fi
}

# 函数：检测网络连接
detect_network_connections() {
    # 检查异常网络连接
    local unusual_connections=$(netstat -an | grep -E ":22|:80|:443" | grep ESTABLISHED | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -nr | head -10)
    
    if [ ! -z "$unusual_connections" ]; then
        echo "$(date): 网络连接统计:" >> $LOG_FILE
        echo "$unusual_connections" >> $LOG_FILE
    fi
}

# 执行入侵检测
detect_anomalous_login
detect_file_integrity
detect_anomalous_processes
detect_network_connections

echo "$(date): 入侵检测检查完成" >> $LOG_FILE
```

## 故障排除

### 1. 常见故障诊断脚本

#### 系统诊断脚本 `/usr/local/bin/system-diagnosis.sh`
```bash
#!/bin/bash

# 系统故障诊断脚本
REPORT_FILE="/var/log/card-system/diagnosis-$(date +%Y%m%d_%H%M%S).txt"

# 函数：系统基本信息
system_info() {
    echo "=== 系统基本信息 ===" >> $REPORT_FILE
    echo "主机名: $(hostname)" >> $REPORT_FILE
    echo "操作系统: $(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '"')" >> $REPORT_FILE
    echo "内核版本: $(uname -r)" >> $REPORT_FILE
    echo "系统时间: $(date)" >> $REPORT_FILE
    echo "运行时间: $(uptime -p)" >> $REPORT_FILE
    echo "" >> $REPORT_FILE
}

# 函数：硬件资源状态
hardware_status() {
    echo "=== 硬件资源状态 ===" >> $REPORT_FILE
    
    # CPU信息
    echo "CPU信息:" >> $REPORT_FILE
    lscpu | grep -E "Model name|CPU\(s\)|Thread" >> $REPORT_FILE
    echo "" >> $REPORT_FILE
    
    # 内存信息
    echo "内存信息:" >> $REPORT_FILE
    free -h >> $REPORT_FILE
    echo "" >> $REPORT_FILE
    
    # 磁盘信息
    echo "磁盘信息:" >> $REPORT_FILE
    df -h >> $REPORT_FILE
    echo "" >> $REPORT_FILE
    
    # 网络接口
    echo "网络接口:" >> $REPORT_FILE
    ip addr show >> $REPORT_FILE
    echo "" >> $REPORT_FILE
}

# 函数：服务状态检查
service_status() {
    echo "=== 服务状态检查 ===" >> $REPORT_FILE
    
    local services=("apache2" "nginx" "mysql" "redis-server" "php8.0-fpm")
    
    for service in "${services[@]}"; do
        if systemctl is-active --quiet $service; then
            echo "$service: 运行中" >> $REPORT_FILE
        else
            echo "$service: 未运行" >> $REPORT_FILE
        fi
    done
    echo "" >> $REPORT_FILE
}

# 函数：网络连通性测试
network_connectivity() {
    echo "=== 网络连通性测试 ===" >> $REPORT_FILE
    
    # 测试外网连通性
    if ping -c 3 8.8.8.8 >/dev/null 2>&1; then
        echo "外网连通性: 正常" >> $REPORT_FILE
    else
        echo "外网连通性: 异常" >> $REPORT_FILE
    fi
    
    # 测试DNS解析
    if nslookup google.com >/dev/null 2>&1; then
        echo "DNS解析: 正常" >> $REPORT_FILE
    else
        echo "DNS解析: 异常" >> $REPORT_FILE
    fi
    
    # 测试网站响应
    local response_code=$(curl -s -o /dev/null -w "%{http_code}" https://your-domain.com)
    echo "网站响应码: $response_code" >> $REPORT_FILE
    
    echo "" >> $REPORT_FILE
}

# 函数：数据库连接测试
database_connectivity() {
    echo "=== 数据库连接测试 ===" >> $REPORT_FILE
    
    # 测试MySQL连接
    if mysql -u card_user -p'your_password' -e "SELECT 1" card_system >/dev/null 2>&1; then
        echo "MySQL连接: 正常" >> $REPORT_FILE
    else
        echo "MySQL连接: 异常" >> $REPORT_FILE
    fi
    
    # 测试Redis连接
    if redis-cli ping >/dev/null 2>&1; then
        echo "Redis连接: 正常" >> $REPORT_FILE
    else
        echo "Redis连接: 异常" >> $REPORT_FILE
    fi
    
    echo "" >> $REPORT_FILE
}

# 函数：日志错误检查
log_errors() {
    echo "=== 日志错误检查 ===" >> $REPORT_FILE
    
    # 检查Apache错误日志
    echo "Apache错误日志 (最近10条):" >> $REPORT_FILE
    tail -10 /var/log/apache2/error.log >> $REPORT_FILE 2>/dev/null
    echo "" >> $REPORT_FILE
    
    # 检查MySQL错误日志
    echo "MySQL错误日志 (最近10条):" >> $REPORT_FILE
    tail -10 /var/log/mysql/error.log >> $REPORT_FILE 2>/dev/null
    echo "" >> $REPORT_FILE
    
    # 检查PHP错误日志
    echo "PHP错误日志 (最近10条):" >> $REPORT_FILE
    tail -10 /var/log/php_errors.log >> $REPORT_FILE 2>/dev/null
    echo "" >> $REPORT_FILE
}

# 函数：性能指标
performance_metrics() {
    echo "=== 性能指标 ===" >> $REPORT_FILE
    
    # 系统负载
    echo "系统负载: $(uptime | awk -F'load average:' '{print $2}')" >> $REPORT_FILE
    
    # CPU使用率
    echo "CPU使用率: $(top -b -n 1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//')" >> $REPORT_FILE
    
    # 内存使用率
    echo "内存使用率: $(free | awk 'NR==2{printf "%.2f%%", $3*100/$2}')" >> $REPORT_FILE
    
    # 磁盘I/O
    echo "磁盘I/O:" >> $REPORT_FILE
    iostat -x 1 1 | tail -n +4 >> $REPORT_FILE
    
    echo "" >> $REPORT_FILE
}

# 生成诊断报告
echo "=== 系统诊断报告 ===" > $REPORT_FILE
echo "诊断时间: $(date)" >> $REPORT_FILE
echo "" >> $REPORT_FILE

system_info
hardware_status
service_status
network_connectivity
database_connectivity
log_errors
performance_metrics

echo "系统诊断完成，报告文件: $REPORT_FILE"
```

### 2. 自动修复脚本

#### 自动修复脚本 `/usr/local/bin/auto-fix.sh`
```bash
#!/bin/bash

# 自动修复脚本
LOG_FILE="/var/log/card-system/auto-fix.log"

# 函数：记录修复操作
log_fix() {
    echo "$(date): $1" >> $LOG_FILE
}

# 函数：修复Apache服务
fix_apache() {
    if ! systemctl is-active --quiet apache2; then
        log_fix "Apache服务未运行，尝试重启"
        systemctl restart apache2
        sleep 5
        
        if systemctl is-active --quiet apache2; then
            log_fix "Apache服务重启成功"
        else
            log_fix "Apache服务重启失败"
        fi
    fi
}

# 函数：修复MySQL服务
fix_mysql() {
    if ! systemctl is-active --quiet mysql; then
        log_fix "MySQL服务未运行，尝试重启"
        systemctl restart mysql
        sleep 10
        
        if systemctl is-active --quiet mysql; then
            log_fix "MySQL服务重启成功"
        else
            log_fix "MySQL服务重启失败"
        fi
    fi
}

# 函数：修复Redis服务
fix_redis() {
    if ! systemctl is-active --quiet redis-server; then
        log_fix "Redis服务未运行，尝试重启"
        systemctl restart redis-server
        sleep 5
        
        if systemctl is-active --quiet redis-server; then
            log_fix "Redis服务重启成功"
        else
            log_fix "Redis服务重启失败"
        fi
    fi
}

# 函数：清理磁盘空间
cleanup_disk() {
    local usage=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    
    if [ $usage -gt 85 ]; then
        log_fix "磁盘使用率过高 (${usage}%)，开始清理"
        
        # 清理日志文件
        find /var/log -name "*.log" -mtime +7 -delete
        log_fix "清理7天前的日志文件"
        
        # 清理临时文件
        find /tmp -mtime +1 -delete
        log_fix "清理临时文件"
        
        # 清理包缓存
        if command -v apt >/dev/null 2>&1; then
            apt autoclean
            log_fix "清理APT包缓存"
        fi
        
        # 清理旧备份
        find /var/backups -name "*.gz" -mtime +30 -delete
        log_fix "清理30天前的备份文件"
    fi
}

# 函数：修复文件权限
fix_permissions() {
    local web_root="/var/www/card-system"
    
    log_fix "检查并修复文件权限"
    
    # 设置基本权限
    chmod -R 755 $web_root
    chmod -R 775 $web_root/storage/
    chmod -R 775 $web_root/cache/
    chmod -R 775 $web_root/uploads/
    
    # 设置所有者
    chown -R www-data:www-data $web_root
    
    log_fix "文件权限修复完成"
}

# 函数：优化数据库
optimize_database() {
    log_fix "开始数据库优化"
    
    # 检查表
    mysql -u card_user -p'your_password' -e "CHECK TABLE card_system.users, card_system.orders, card_system.products;" card_system
    
    # 优化表
    mysql -u card_user -p'your_password' -e "OPTIMIZE TABLE card_system.users, card_system.orders, card_system.products;" card_system
    
    log_fix "数据库优化完成"
}

# 执行自动修复
log_fix "开始自动修复检查"

fix_apache
fix_mysql
fix_redis
cleanup_disk
fix_permissions
optimize_database

log_fix "自动修复完成"
```

## 日常维护

### 1. 每日维护脚本

#### 每日维护脚本 `/usr/local/bin/daily-maintenance.sh`
```bash
#!/bin/bash

# 每日维护脚本
LOG_FILE="/var/log/card-system/daily-maintenance.log"

# 函数：记录维护操作
log_maintenance() {
    echo "$(date): $1" >> $LOG_FILE
}

# 函数：系统更新检查
check_updates() {
    log_maintenance "检查系统更新"
    
    if command -v apt >/dev/null 2>&1; then
        apt update
        local updates=$(apt list --upgradable 2>/dev/null | grep -v "WARNING" | wc -l)
        log_maintenance "发现 $updates 个可用更新"
    fi
}

# 函数：数据库维护
database_maintenance() {
    log_maintenance "执行数据库维护"
    
    # 备份数据库
    /usr/local/bin/backup-database.sh
    
    # 优化数据库
    mysql -u card_user -p'your_password' -e "OPTIMIZE TABLE card_system.orders;" card_system
    
    log_maintenance "数据库维护完成"
}

# 函数：日志清理
log_cleanup() {
    log_maintenance "清理过期日志"
    
    # 清理应用日志
    find /var/www/card-system/storage/logs -name "*.log" -mtime +14 -delete
    
    # 清理系统日志
    journalctl --vacuum-time=14d
    
    log_maintenance "日志清理完成"
}

# 函数：缓存清理
cache_cleanup() {
    log_maintenance "清理系统缓存"
    
    # 清理Redis缓存
    redis-cli FLUSHDB
    
    # 清理文件缓存
    rm -rf /var/www/card-system/cache/*
    
    log_maintenance "缓存清理完成"
}

# 函数：安全检查
security_check() {
    log_maintenance "执行安全检查"
    
    # 检查文件权限
    find /var/www/card-system -type f -perm /o+w -exec ls -la {} \; >> $LOG_FILE
    
    # 检查登录失败
    local failed_logins=$(journalctl -u ssh --since "24 hours ago" | grep "Failed password" | wc -l)
    log_maintenance "24小时内失败登录次数: $failed_logins"
    
    log_maintenance "安全检查完成"
}

# 函数：性能检查
performance_check() {
    log_maintenance "执行性能检查"
    
    # 检查系统负载
    local load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    log_maintenance "当前系统负载: $load_avg"
    
    # 检查内存使用
    local memory_usage=$(free | awk 'NR==2{printf "%.2f%%", $3*100/$2}')
    log_maintenance "当前内存使用率: $memory_usage"
    
    # 检查磁盘使用
    local disk_usage=$(df / | awk 'NR==2 {print $5}')
    log_maintenance "当前磁盘使用率: $disk_usage"
    
    log_maintenance "性能检查完成"
}

# 执行每日维护
log_maintenance "=== 开始每日维护 ==="

check_updates
database_maintenance
log_cleanup
cache_cleanup
security_check
performance_check

log_maintenance "=== 每日维护完成 ==="
```

### 2. 周期性维护脚本

#### 周维护脚本 `/usr/local/bin/weekly-maintenance.sh`
```bash
#!/bin/bash

# 周维护脚本
LOG_FILE="/var/log/card-system/weekly-maintenance.log"

# 函数：记录维护操作
log_maintenance() {
    echo "$(date): $1" >> $LOG_FILE
}

# 函数：深度系统清理
deep_cleanup() {
    log_maintenance "执行深度系统清理"
    
    # 清理包缓存
    if command -v apt >/dev/null 2>&1; then
        apt autoremove -y
        apt autoclean
    fi
    
    # 清理旧的内核文件
    if command -v apt >/dev/null 2>&1; then
        apt autoremove -y --purge
    fi
    
    # 清理临时目录
    find /tmp -type f -mtime +7 -delete
    find /var/tmp -type f -mtime +7 -delete
    
    log_maintenance "深度系统清理完成"
}

# 函数：数据库深度维护
deep_database_maintenance() {
    log_maintenance "执行数据库深度维护"
    
    # 检查所有表
    mysql -u card_user -p'your_password' -e "SHOW TABLES" card_system | \
    while read table; do
        if [ "$table" != "Tables_in_card_system" ]; then
            mysql -u card_user -p'your_password -e "CHECK TABLE $table" card_system
            mysql -u card_user -p'your_password -e "OPTIMIZE TABLE $table" card_system
        fi
    done
    
    # 分析表统计信息
    mysql -u card_user -p'your_password -e "ANALYZE TABLE card_system.users, card_system.orders, card_system.products" card_system
    
    log_maintenance "数据库深度维护完成"
}

# 函数：安全更新
security_updates() {
    log_maintenance "检查安全更新"
    
    if command -v apt >/dev/null 2>&1; then
        # 只安装安全更新
        apt update
        apt list --upgradable 2>/dev/null | grep -i security | awk -F'/' '{print $1}' > /tmp/security_updates.txt
        
        if [ -s /tmp/security_updates.txt ]; then
            log_maintenance "发现安全更新，开始安装"
            xargs -a /tmp/security_updates.txt apt install -y
            log_maintenance "安全更新安装完成"
        else
            log_maintenance "没有发现安全更新"
        fi
        
        rm -f /tmp/security_updates.txt
    fi
}

# 函数：备份验证
backup_verification() {
    log_maintenance "验证备份完整性"
    
    local backup_dir="/var/backups/card-system"
    local latest_backup=$(ls -t $backup_dir/database/db_backup_*.sql.gz | head -1)
    
    if [ -f "$latest_backup" ]; then
        if gunzip -t $latest_backup; then
            log_maintenance "最新备份验证通过: $latest_backup"
        else
            log_maintenance "最新备份验证失败: $latest_backup"
        fi
    else
        log_maintenance "未找到备份文件"
    fi
}

# 函数：性能分析
performance_analysis() {
    log_maintenance "执行性能分析"
    
    # 生成性能报告
    /usr/local/bin/performance-monitor.sh
    
    # 分析慢查询
    if [ -f "/var/log/mysql/slow.log" ]; then
        local slow_queries=$(grep -c "Query_time" /var/log/mysql/slow.log)
        log_maintenance "本周慢查询数量: $slow_queries"
    fi
    
    log_maintenance "性能分析完成"
}

# 执行周维护
log_maintenance "=== 开始周维护 ==="

deep_cleanup
deep_database_maintenance
security_updates
backup_verification
performance_analysis

log_maintenance "=== 周维护完成 ==="
```

## 应急响应

### 1. 应急响应脚本

#### 应急响应脚本 `/usr/local/bin/emergency-response.sh`
```bash
#!/bin/bash

# 应急响应脚本
INCIDENT_LOG="/var/log/card-system/emergency-$(date +%Y%m%d_%H%M%S).log"
ALERT_EMAIL="admin@example.com"

# 函数：记录事件
log_incident() {
    echo "$(date): $1" >> $INCIDENT_LOG
}

# 函数：发送紧急通知
send_emergency_alert() {
    local subject=$1
    local message=$2
    
    echo "$message" | mail -s "[紧急] $subject" $ALERT_EMAIL
    log_incident "发送紧急通知: $subject"
}

# 函数：系统隔离
isolate_system() {
    log_incident "开始系统隔离"
    
    # 停止Web服务
    systemctl stop apache2
    systemctl stop nginx
    
    # 阻止外部连接
    if command -v ufw >/dev/null 2>&1; then
        ufw deny in from any to any
    fi
    
    log_incident "系统隔离完成"
}

# 函数：创建系统快照
create_snapshot() {
    log_incident "创建系统快照"
    
    local snapshot_dir="/var/backups/emergency-$(date +%Y%m%d_%H%M%S)"
    mkdir -p $snapshot_dir
    
    # 备份关键文件
    cp -r /var/www/card-system $snapshot_dir/
    cp -r /etc/apache2 $snapshot_dir/
    cp -r /etc/nginx $snapshot_dir/
    cp -r /etc/mysql $snapshot_dir/
    
    # 备份数据库
    mysqldump -u card_user -p'your_password' --single-transaction card_system > $snapshot_dir/emergency_db.sql
    
    log_incident "系统快照创建完成: $snapshot_dir"
}

# 函数：安全检查
security_audit() {
    log_incident "开始安全审计"
    
    # 检查活动连接
    netstat -an > $snapshot_dir/active_connections.txt
    
    # 检查活动进程
    ps aux > $snapshot_dir/running_processes.txt
    
    # 检查登录用户
    who > $snapshot_dir/logged_users.txt
    
    # 检查最近登录
    last -n 50 > $snapshot_dir/recent_logins.txt
    
    log_incident "安全审计完成"
}

# 函数：恶意软件扫描
malware_scan() {
    log_incident "开始恶意软件扫描"
    
    # 扫描Web目录
    find /var/www/card-system -name "*.php" -exec grep -l "eval\|base64_decode\|shell_exec" {} \; > $snapshot_dir/suspicious_files.txt
    
    # 检查最近修改的文件
    find /var/www/card-system -name "*.php" -mtime -1 -ls > $snapshot_dir/recently_modified.txt
    
    log_incident "恶意软件扫描完成"
}

# 函数：恢复服务
restore_services() {
    log_incident "开始恢复服务"
    
    # 恢复防火墙规则
    if command -v ufw >/dev/null 2>&1; then
        ufw --force reset
        ufw default allow outgoing
        ufw default deny incoming
        ufw allow ssh
        ufw allow 80/tcp
        ufw allow 443/tcp
        ufw --force enable
    fi
    
    # 启动Web服务
    systemctl start apache2
    
    log_incident "服务恢复完成"
}

# 主应急响应流程
if [ "$1" = "isolate" ]; then
    log_incident "触发系统隔离"
    isolate_system
    send_emergency_alert "系统已隔离" "检测到安全威胁，系统已自动隔离"
    
elif [ "$1" = "snapshot" ]; then
    log_incident "创建应急快照"
    create_snapshot
    security_audit
    malware_scan
    send_emergency_alert "应急快照已创建" "系统快照和安全审计已完成"
    
elif [ "$1" = "restore" ]; then
    log_incident "恢复系统服务"
    restore_services
    send_emergency_alert "系统已恢复" "系统服务已恢复正常"
    
else
    echo "用法: $0 {isolate|snapshot|restore}"
    echo "  isolate  - 隔离系统"
    echo "  snapshot - 创建应急快照"
    echo "  restore  - 恢复系统服务"
fi
```

---

## 联系信息

- **技术支持**: support@example.com
- **紧急联系**: emergency@example.com
- **文档更新**: docs@example.com

## 版本历史

- **v2.0.0** - 完整运维手册
- **v1.5.0** - 添加监控和自动化
- **v1.0.0** - 初始版本

---

*最后更新: 2024年1月*