# 授权验证系统使用说明

## 概述

发卡系统内置了授权验证机制，用于防止代码被非法上传到未经授权的服务器。该机制会在系统启动时自动检查当前服务器是否被授权运行。

## 工作原理

1. 系统启动时自动加载 `includes/license_validator.php` 文件
2. 检查当前服务器域名和IP地址是否在授权列表中
3. 如果未授权，则记录访问日志并显示错误页面

## 配置授权服务器

### 授权域名配置

在 `includes/license_validator.php` 文件中找到以下数组并添加您的授权域名：

```php
private static $authorizedDomains = [
    'localhost',
    '127.0.0.1',
    '::1',
    // 添加您的授权域名
    'yourdomain.com',
    'www.yourdomain.com'
];
```

### 授权IP配置

在同一文件中找到以下数组并添加您的授权IP地址：

```php
private static $authorizedIPs = [
    '127.0.0.1',
    '::1',
    // 添加您的授权IP地址
    '203.0.113.1',
    '198.51.100.1'
];
```

## 测试授权验证

您可以使用 `test_license.php` 脚本来测试当前服务器是否被授权：

```bash
curl http://localhost/发卡系统/test_license.php
```

返回结果示例：
```json
{
    "authorized": true,
    "server_info": {
        "domain": "localhost",
        "ip": "127.0.0.1",
        "software": "Apache/2.4.41 (Win64) PHP/7.4.0",
        "signature": "5d41402abc4b2a76b9719d911017c592"
    },
    "timestamp": "2025-11-27 10:30:45"
}
```

## 日志记录

未授权访问尝试会被记录到 `logs/unauthorized_access.log` 文件中，日志格式如下：

```
2025-11-27 10:30:45 - 未授权访问尝试
服务器域名: unauthorized-domain.com
服务器IP: 203.0.113.1
客户端IP: 192.0.2.1
请求URI: /index.php
User Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36
--------------------------------------------------
```

## 错误页面

当检测到未授权访问时，系统会显示以下错误页面：

```
访问被拒绝

检测到未授权的服务器访问。
此软件只能在授权的服务器上运行。
如果您是合法用户，请联系技术支持获取授权。
```

## 开发环境

在本地开发环境中（localhost、127.0.0.1），系统会自动允许运行，无需额外配置。

## 故障排除

### 1. 授权验证未生效

检查以下几点：
1. 确保 `includes/license_validator.php` 文件已正确加载
2. 检查授权域名/IP是否正确配置
3. 确认文件权限允许读取

### 2. 误报未授权访问

如果在授权服务器上收到未授权访问错误，请检查：
1. 服务器域名解析是否正确
2. 服务器IP地址是否变化
3. 防火墙或CDN是否改变了请求来源

### 3. 日志文件未生成

如果 `logs/unauthorized_access.log` 文件未生成，请检查：
1. `logs` 目录是否存在且具有写权限
2. 磁盘空间是否充足
3. PHP进程是否有足够权限创建文件

## 安全建议

1. **定期更新授权列表**：及时添加新的授权服务器
2. **保护配置文件**：确保 `includes/license_validator.php` 文件不被恶意修改
3. **监控日志**：定期检查未授权访问日志
4. **备份配置**：备份授权配置以防意外丢失

## 联系支持

如遇到授权验证相关问题，请联系发卡系统技术支持团队。