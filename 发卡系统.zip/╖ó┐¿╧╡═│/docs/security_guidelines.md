# 输入验证与安全防护最佳实践指南

## 1. 概述

本文档提供了项目中输入验证和安全防护的最佳实践指南，旨在帮助开发人员正确使用新实现的安全验证机制，防止注入攻击、XSS攻击和数据类型错误等安全问题。

## 2. 核心安全类和组件

### 2.1 EnhancedValidator 类

`EnhancedValidator` 类提供了全面的输入验证和数据清理功能。

**文件位置**: `includes/EnhancedValidator.php`

**主要功能**:
- 数据类型验证和转换
- 输入清理和消毒
- 格式验证（邮箱、URL、电话号码等）
- 自定义验证规则
- 批量验证

### 2.2 InjectionProtection 类

`InjectionProtection` 类专注于防止各类注入攻击。

**文件位置**: `includes/InjectionProtection.php`

**主要功能**:
- SQL注入防护
- XSS攻击防护
- 命令注入防护
- 输入特殊字符处理

### 2.3 BaseAPI 类

`BaseAPI` 类已集成了输入验证和安全检查功能。

**文件位置**: `includes/api/BaseAPI.php`

**主要功能**:
- 安全的参数获取和类型转换
- 请求体验证
- API响应安全处理

### 2.4 DatabaseReadWrite 类

`DatabaseReadWrite` 类提供了安全的数据库操作功能。

**文件位置**: `includes/DatabaseReadWrite.php`

**主要功能**:
- 安全的SQL参数绑定
- 参数类型验证和转换
- SQL注入防护

## 3. 输入验证最佳实践

### 3.1 所有外部输入必须经过验证

**规则**: 任何来自用户、API或外部系统的输入都必须经过验证。

**示例代码**:

```php
// 正确方式：使用EnhancedValidator验证输入
$validator = new EnhancedValidator();
$username = $validator->cleanInput($_POST['username']);
$isValid = $validator->validate($username, ['required' => true, 'min' => 3, 'max' => 20]);

// 错误方式：直接使用未验证的输入
$username = $_POST['username']; // 危险！未经验证
```

### 3.2 实现严格的类型转换

**规则**: 始终明确指定所需的数据类型，并执行类型转换。

**示例代码**:

```php
// 正确方式：明确类型转换
$id = $validator->convertToType($_GET['id'], 'int'); // 转换为整数
$active = $validator->convertToType($_POST['active'], 'bool'); // 转换为布尔值

// 使用API类的参数获取方法
$api = new BaseAPI();
$page = $api->getParam('page', 1, 'int'); // 获取整数参数，默认值为1
```

### 3.3 使用白名单验证而非黑名单

**规则**: 优先使用白名单方式验证允许的字符和模式，而非尝试过滤不允许的字符。

**示例代码**:

```php
// 正确方式：使用白名单验证
$username = $_POST['username'];
if ($validator->validatePattern($username, '/^[a-zA-Z0-9_]{3,20}$/')) {
    // 有效用户名
} else {
    // 无效用户名
}

// 使用枚举值验证
$status = $_POST['status'];
if ($validator->validateEnum($status, ['active', 'inactive', 'pending'])) {
    // 有效状态
} else {
    // 无效状态
}
```

### 3.4 实现最小权限原则

**规则**: 数据访问和操作权限应当遵循最小权限原则。

**示例代码**:

```php
// 正确方式：使用参数化查询，限制访问范围
$userId = $currentUser->id;
$sql = "SELECT * FROM orders WHERE user_id = :userId";
$params = [':userId' => $userId];
$orders = $db->query($sql, $params);
```

## 4. API安全开发指南

### 4.1 API参数获取与验证

**规则**: 始终使用`BaseAPI`类提供的参数获取方法，避免直接访问`$_GET`、`$_POST`或`$_REQUEST`。

**示例代码**:

```php
// 正确方式：使用API的参数获取方法
$api = new BaseAPI();

// 获取字符串参数
$username = $api->getParam('username', '', 'string');

// 获取整数参数
$id = $api->getParam('id', 0, 'int');

// 获取布尔参数
$active = $api->getParam('active', false, 'bool');

// 获取浮点数参数
$amount = $api->getParam('amount', 0.0, 'float');

// 获取数组参数
$ids = $api->getParam('ids', [], 'array');
```

### 4.2 API请求验证

**规则**: 为API端点定义明确的验证规则，并在处理请求前验证所有必要参数。

**示例代码**:

```php
// 在API处理方法中实现验证
public function processRequest() {
    // 定义验证规则
    $rules = [
        'username' => ['required' => true, 'min' => 3, 'max' => 20],
        'email' => ['required' => true, 'email' => true],
        'age' => ['required' => true, 'min' => 18, 'max' => 120],
        'status' => ['enum' => ['active', 'inactive']]
    ];
    
    // 获取所有参数
    $data = [
        'username' => $this->getParam('username', '', 'string'),
        'email' => $this->getParam('email', '', 'string'),
        'age' => $this->getParam('age', 0, 'int'),
        'status' => $this->getParam('status', 'active', 'string')
    ];
    
    // 验证参数
    if (!$this->validate($data, $rules)) {
        return $this->errorResponse('参数验证失败', 400);
    }
    
    // 处理请求...
}
```

### 4.3 API响应安全

**规则**: 确保API响应中不包含敏感信息，且错误信息不泄露系统内部细节。

**示例代码**:

```php
// 正确方式：安全的API响应
public function getUserInfo($userId) {
    try {
        // 验证用户ID
        $userId = $this->getParam('id', 0, 'int');
        if ($userId <= 0) {
            return $this->errorResponse('无效的用户ID', 400);
        }
        
        // 查询用户信息
        $user = $this->getUserById($userId);
        
        // 过滤敏感信息
        $safeUser = [
            'id' => $user->id,
            'username' => $user->username,
            'email' => $user->email,
            'created_at' => $user->created_at
            // 不返回密码、token等敏感字段
        ];
        
        return $this->successResponse($safeUser);
    } catch (Exception $e) {
        // 记录详细错误信息到日志
        $this->logError($e);
        
        // 向客户端返回安全的错误信息
        return $this->errorResponse('操作失败，请稍后重试', 500);
    }
}
```

## 5. 数据库安全最佳实践

### 5.1 始终使用参数化查询

**规则**: 绝不在SQL语句中直接拼接用户输入。始终使用参数化查询。

**示例代码**:

```php
// 正确方式：使用参数化查询
$db = new DatabaseReadWrite();
$username = $_POST['username'];

// 方式1：使用命名参数
$sql = "SELECT * FROM users WHERE username = :username";
$params = [':username' => $username];
$result = $db->query($sql, $params);

// 方式2：使用位置参数
$sql = "SELECT * FROM users WHERE username = ?";
$params = [$username];
$result = $db->query($sql, $params);

// 方式3：指定参数类型（推荐）
$paramTypes = [':username' => 'string'];
$result = $db->query($sql, $params, $paramTypes);

// 错误方式：SQL注入风险
$username = $_POST['username'];
$sql = "SELECT * FROM users WHERE username = '$username'"; // 危险！可能导致SQL注入
$result = $db->query($sql);
```

### 5.2 指定参数类型

**规则**: 明确指定SQL参数的类型，提高安全性和性能。

**示例代码**:

```php
// 正确方式：指定参数类型
$db = new DatabaseReadWrite();
$params = [
    ':id' => 123,
    ':active' => true,
    ':name' => '测试用户',
    ':amount' => 199.99
];
$paramTypes = [
    ':id' => 'int',
    ':active' => 'bool',
    ':name' => 'string',
    ':amount' => 'float'
];

$sql = "INSERT INTO users (id, active, name, amount) VALUES (:id, :active, :name, :amount)";
$db->execute($sql, $params, $paramTypes);
```

### 5.3 避免SQL注入的高级技巧

**规则**: 使用`InjectionProtection`类对SQL相关输入进行额外保护。

**示例代码**:

```php
// 使用InjectionProtection进行额外防护
$protection = new InjectionProtection();
$tableName = $protection->protectIdentifier($_GET['table']); // 保护表名
$columnName = $protection->protectIdentifier($_GET['column']); // 保护列名

// 安全的动态SQL构建
if (in_array($tableName, ['users', 'orders', 'products'])) {
    $sql = "SELECT * FROM $tableName ORDER BY $columnName";
    $result = $db->query($sql);
}
```

## 6. 表单处理安全

### 6.1 表单输入验证

**规则**: 表单提交的数据必须经过验证和清理。

**示例代码**:

```php
// 表单处理代码
$validator = new EnhancedValidator();
$errors = [];

// 清理和验证输入
$username = $validator->cleanInput($_POST['username']);
$email = $validator->cleanInput($_POST['email']);
$password = $_POST['password']; // 密码不需要清理，因为将被哈希处理

// 验证用户名
if (!$validator->validate($username, ['required' => true, 'min' => 3, 'max' => 20])) {
    $errors['username'] = '用户名长度必须在3-20个字符之间';
}

// 验证邮箱
if (!$validator->validate($email, ['required' => true, 'email' => true])) {
    $errors['email'] = '请输入有效的邮箱地址';
}

// 验证密码强度
if (!$validator->validatePasswordStrength($password)) {
    $errors['password'] = '密码必须包含大小写字母、数字和特殊字符，长度至少8位';
}

// 检查验证结果
if (empty($errors)) {
    // 处理表单数据
} else {
    // 显示错误信息
}
```

### 6.2 CSRF保护

**规则**: 所有修改数据的表单必须实现CSRF保护。

**示例代码**:

```php
// 在表单中添加CSRF令牌
$validator = new EnhancedValidator();
$csrfToken = $validator->generateCSRFToken();

// 在会话中存储令牌
$_SESSION['csrf_token'] = $csrfToken;

// 在HTML表单中包含令牌
<form method="post" action="process.php">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <!-- 其他表单字段 -->
    <button type="submit">提交</button>
</form>

// 在服务器端验证CSRF令牌
$submittedToken = $_POST['csrf_token'] ?? '';
$sessionToken = $_SESSION['csrf_token'] ?? '';

if (!$validator->validateCSRFToken($submittedToken, $sessionToken)) {
    die('安全验证失败，请刷新页面后重试');
}
```

## 7. 文件上传安全

### 7.1 验证文件类型和大小

**规则**: 限制允许上传的文件类型和大小，验证文件内容。

**示例代码**:

```php
// 验证上传的文件
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
$maxSize = 5 * 1024 * 1024; // 5MB

if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    die('文件上传失败');
}

// 验证文件类型
$fileType = mime_content_type($_FILES['file']['tmp_name']);
if (!in_array($fileType, $allowedTypes)) {
    die('不支持的文件类型');
}

// 验证文件大小
if ($_FILES['file']['size'] > $maxSize) {
    die('文件大小超过限制');
}

// 安全地保存文件
$safeFilename = $validator->cleanFilename($_FILES['file']['name']);
$uploadPath = '/path/to/uploads/' . time() . '_' . $safeFilename;

if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath)) {
    // 文件上传成功
} else {
    die('文件保存失败');
}
```

## 8. 常见安全漏洞和解决方案

### 8.1 SQL注入

**漏洞描述**: 攻击者通过在用户输入中注入恶意SQL代码，从而操纵数据库查询。

**解决方案**:
- 使用参数化查询
- 对数据库标识符进行验证
- 限制数据库用户权限

**防护代码**:

```php
$protection = new InjectionProtection();
$db = new DatabaseReadWrite();

// 保护SQL输入
$input = $protection->protectSQL($_GET['search']);

// 使用参数化查询
$sql = "SELECT * FROM users WHERE name LIKE :search";
$params = [':search' => '%' . $input . '%'];
$result = $db->query($sql, $params);
```

### 8.2 XSS攻击

**漏洞描述**: 攻击者注入恶意脚本，当其他用户浏览页面时执行。

**解决方案**:
- 对所有输出进行HTML转义
- 使用Content-Security-Policy
- 清理用户输入

**防护代码**:

```php
$validator = new EnhancedValidator();

// 清理用户输入
$userComment = $validator->cleanInput($_POST['comment']);

// 在显示时进行HTML转义
echo htmlspecialchars($userComment, ENT_QUOTES, 'UTF-8');
```

### 8.3 命令注入

**漏洞描述**: 攻击者通过在命令参数中注入恶意代码，执行未授权的系统命令。

**解决方案**:
- 避免使用系统命令
- 对命令参数进行严格验证
- 使用白名单验证

**防护代码**:

```php
$protection = new InjectionProtection();

// 保护命令参数
$filename = $protection->protectCommand($_GET['filename']);

// 使用escapeshellarg确保安全
$safeFilename = escapeshellarg($filename);
$result = shell_exec("ls -la " . $safeFilename);
```

### 8.4 类型混淆攻击

**漏洞描述**: 利用PHP弱类型特性，绕过验证或导致逻辑错误。

**解决方案**:
- 执行严格的类型转换
- 使用类型安全的比较
- 验证数据类型

**防护代码**:

```php
$validator = new EnhancedValidator();

// 严格类型转换
$userId = $validator->convertToType($_GET['id'], 'int');

// 类型安全的比较
if ($userId === 123) { // 使用严格比较 ===
    // 处理逻辑
}

// 验证数值范围
if ($userId < 1 || $userId > 1000) {
    die('无效的用户ID');
}
```

## 9. 测试和调试

### 9.1 运行安全测试

项目提供了专门的安全测试用例，确保安全机制正常工作。

**测试文件**:
- `tests/EnhancedValidatorTest.php` - 验证器测试
- `tests/DatabaseSecurityTest.php` - 数据库安全测试
- `tests/APISecurityTest.php` - API安全测试

**运行测试**:

```bash
php tests/run_tests.php
```

### 9.2 安全日志记录

**规则**: 记录安全相关事件，以便监控和排查潜在的安全问题。

**示例代码**:

```php
// 记录安全事件
function logSecurityEvent($event, $details = []) {
    $logData = [
        'timestamp' => date('Y-m-d H:i:s'),
        'event' => $event,
        'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'details' => json_encode($details)
    ];
    
    // 将日志写入文件或数据库
    error_log("[SECURITY] " . json_encode($logData));
}

// 使用示例
if (!$validator->validateCSRFToken($token, $sessionToken)) {
    logSecurityEvent('csrf_token_invalid', ['token' => substr($token, 0, 8) . '...']);
    die('安全验证失败');
}
```

## 10. 总结

安全是一个持续的过程，而不仅仅是一次性的实现。开发人员应当：

1. 始终遵循最小权限原则
2. 对所有外部输入进行严格验证
3. 使用安全的API和数据库访问方式
4. 定期审查代码中的安全问题
5. 及时应用安全补丁和更新

通过严格遵守本指南中的最佳实践，可以显著提高系统的安全性，减少安全漏洞和攻击风险。

---

**文档版本**: 1.0
**最后更新**: