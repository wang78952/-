# 发卡系统文件结构文档

## 概述
本文档详细描述了发卡系统的文件结构、目录组织和各部分功能，帮助开发人员理解系统架构和代码组织方式。

## 项目根目录结构

```
├── admin/           # 管理后台目录
├── agent/           # 代理系统相关文件
├── api/             # API接口目录
├── app/             # 应用主目录
├── assets/          # 静态资源文件
├── config/          # 配置文件目录
├── database/        # 数据库相关文件
├── docs/            # 文档目录
├── includes/        # 核心代码和服务目录
├── plugins/         # 插件目录
├── templates/       # 模板文件目录
├── tests/           # 测试文件目录
└── 其他根目录文件    # 配置文件、启动脚本等
```

## 核心目录详解

### 1. includes/ - 核心代码目录

这是系统的核心代码目录，包含了所有核心类、服务和功能实现。

```
├── core/            # 核心基础类
│   ├── BaseService.php    # 基础服务类，所有服务类的父类
│   ├── Database.php       # 数据库连接类
│   ├── Logger.php         # 日志服务类
│   └── SecurityUtils.php  # 安全工具类
├── services/        # 业务服务类目录
│   ├── card/        # 卡片相关服务
│   │   ├── CardService.php      # 卡片服务类
│   │   └── InventoryService.php # 库存服务类
│   ├── payment/     # 支付相关服务
│   │   └── PaymentService.php   # 支付服务类
│   └── order/       # 订单相关服务
│       ├── OrderService.php     # 订单服务类
│       └── OrderNoteService.php # 订单备注服务类
├── init.php         # 系统初始化文件
└── ...              # 其他核心组件
```

### 2. config/ - 配置文件目录

集中存放所有配置文件，按功能模块分类。

```
├── app.php          # 应用基本配置
├── database.php     # 数据库配置（支持读写分离）
├── payment.php      # 支付配置
├── security.php     # 安全配置
└── ...              # 其他配置文件
```

### 3. api/ - API接口目录

提供RESTful API接口，支持系统集成和外部调用。

```
├── controllers/     # API控制器
├── routes.php       # 路由配置
├── router.php       # 路由器
└── ...              # 其他API组件
```

### 4. assets/ - 静态资源目录

存放前端静态资源文件。

```
├── css/             # 样式文件
├── js/              # JavaScript文件
├── images/          # 图片文件
└── lang/            # 语言包文件
```

### 5. database/ - 数据库相关目录

存放数据库初始化脚本、迁移文件和模式定义。

```
├── init.sql         # 数据库初始化脚本
├── migrations/      # 数据库迁移文件
└── schema.sql       # 数据库结构定义
```

## 代码组织规范

### 1. 类命名和文件结构规范

- 所有服务类使用 `Service` 后缀，例如 `OrderService`
- 核心基础类放在 `includes/core/` 目录下
- 业务服务类按功能模块组织在 `includes/services/` 对应子目录中
- 配置文件按功能命名并存放在 `config/` 目录下

### 2. 依赖关系

- 服务类继承自 `BaseService` 类
- 服务类使用单例模式实现
- 核心类通过 `init.php` 统一加载
- 配置文件通过 `loadConfig()` 函数加载

## 导航说明

### 如何查找特定功能

1. **核心服务类**：在 `includes/services/` 目录下按功能模块查找
2. **配置项**：在 `config/` 目录下查找对应的配置文件
3. **数据库操作**：核心数据库操作封装在 `includes/core/Database.php` 中
4. **API接口**：在 `api/` 目录下查找对应的控制器

### 新增功能流程

1. 创建相应的服务类（继承 `BaseService`）
2. 在 `init.php` 中注册新服务
3. 根据需要添加配置文件到 `config/` 目录
4. 更新相关的依赖引用

## 最佳实践

1. **路径引用**：始终使用常量定义的路径，避免硬编码
2. **类实例化**：使用单例模式的 `getInstance()` 方法获取服务实例
3. **配置访问**：通过 `loadConfig()` 函数加载配置，避免直接包含配置文件
4. **错误处理**：使用统一的错误处理机制，记录详细日志

---

本文档由系统自动生成，最后更新时间：" . date('Y-m-d H:i:s') . "