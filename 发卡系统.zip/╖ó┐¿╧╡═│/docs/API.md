# 发卡系统API文档

## 目录
1. [API概述](#api概述)
2. [认证机制](#认证机制)
3. [通用响应格式](#通用响应格式)
4. [错误处理](#错误处理)
5. [API端点](#api端点)
6. [数据模型](#数据模型)
7. [示例代码](#示例代码)
8. [版本控制](#版本控制)

## API概述

### 基本信息
- **Base URL**: `https://your-domain.com/api/v2`
- **协议**: HTTPS
- **数据格式**: JSON
- **字符编码**: UTF-8
- **API版本**: v2.0.0

### 特性
- JWT认证
- RESTful设计
- 请求限流
- 数据验证
- 错误处理
- 分页支持
- 批量操作
- 实时通知

## 认证机制

### JWT认证
所有API请求都需要在请求头中包含有效的JWT令牌：

```http
Authorization: Bearer <jwt_token>
```

### 获取令牌
```http
POST /api/v2/auth/login
Content-Type: application/json

{
    "username": "admin",
    "password": "password123"
}
```

**响应示例**:
```json
{
    "success": true,
    "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "expires_in": 3600,
        "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "user": {
            "id": 1,
            "username": "admin",
            "role": "admin"
        }
    }
}
```

### 刷新令牌
```http
POST /api/v2/auth/refresh
Content-Type: application/json

{
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

## 通用响应格式

### 成功响应
```json
{
    "success": true,
    "data": {
        // 响应数据
    },
    "message": "操作成功",
    "timestamp": "2024-01-01T12:00:00Z"
}
```

### 分页响应
```json
{
    "success": true,
    "data": {
        "items": [
            // 数据项
        ],
        "pagination": {
            "current_page": 1,
            "per_page": 20,
            "total": 100,
            "total_pages": 5,
            "has_next": true,
            "has_prev": false
        }
    },
    "message": "获取成功",
    "timestamp": "2024-01-01T12:00:00Z"
}
```

## 错误处理

### 错误响应格式
```json
{
    "success": false,
    "error": {
        "code": "VALIDATION_ERROR",
        "message": "请求参数验证失败",
        "details": {
            "field": "email",
            "reason": "邮箱格式不正确"
        }
    },
    "timestamp": "2024-01-01T12:00:00Z"
}
```

### 错误代码列表

| 错误代码 | HTTP状态码 | 描述 |
|---------|-----------|------|
| VALIDATION_ERROR | 400 | 请求参数验证失败 |
| UNAUTHORIZED | 401 | 未授权访问 |
| FORBIDDEN | 403 | 权限不足 |
| NOT_FOUND | 404 | 资源不存在 |
| METHOD_NOT_ALLOWED | 405 | 请求方法不允许 |
| RATE_LIMIT_EXCEEDED | 429 | 请求频率超限 |
| INTERNAL_ERROR | 500 | 服务器内部错误 |
| SERVICE_UNAVAILABLE | 503 | 服务不可用 |

### 异常处理最佳实践

#### 全局异常处理机制

发卡系统实现了统一的全局异常处理机制，通过ApiResponse类和ErrorHandler工具类的集成，确保所有未捕获的异常都能被正确处理并返回标准格式的错误响应。

**核心特性：**

- 自动捕获和处理所有未捕获的异常
- 统一的错误响应格式
- 详细的错误日志记录（包含异常堆栈）
- 安全的错误信息返回（生产环境隐藏敏感错误详情）
- 支持不同类型异常的自定义处理

#### 如何使用

##### 1. 注册全局异常处理器

在API入口文件中注册全局异常处理器：

```php
// 在api/index.php中
require_once __DIR__ . '/helpers.php';

// 注册全局异常处理器
ApiResponse::registerGlobalExceptionHandler();
```

##### 2. 手动抛出和处理异常

在业务代码中，推荐使用以下方式处理和返回错误：

```php
// 验证错误处理
try {
    // 业务逻辑
    if (empty($username)) {
        // 使用验证错误方法返回结构化的验证错误
        return ApiResponse::validationError([
            'username' => '用户名不能为空'
        ]);
    }
    
    // 成功响应
    return ApiResponse::success($data, '操作成功');
} catch (Exception $e) {
    // 记录错误日志
    ErrorHandler::getInstance()->logError('业务操作失败', [
        'exception' => $e,
        'context' => ['user_id' => $userId]
    ]);
    
    // 返回错误响应
    return ApiResponse::error('操作失败，请稍后重试', 500);
}
```

##### 3. 自定义异常类型

对于特定业务场景，可以创建自定义异常类：

```php
// 示例：创建业务异常类
class BusinessException extends Exception {
    public $errorCode;
    
    public function __construct($message, $errorCode = 'BUSINESS_ERROR', $code = 400) {
        $this->errorCode = $errorCode;
        parent::__construct($message, $code);
    }
}

// 使用自定义异常
try {
    // 业务逻辑
    if (!$order->canBeCancelled()) {
        throw new BusinessException('订单状态不允许取消', 'ORDER_CANNOT_CANCEL', 400);
    }
} catch (BusinessException $e) {
    return ApiResponse::error($e->getMessage(), $e->getCode(), [
        'error_code' => $e->errorCode
    ]);
} catch (Exception $e) {
    // 通用异常处理
    return ApiResponse::error('系统错误', 500);
}
```

#### 开发最佳实践

1. **总是使用try-catch包装关键业务逻辑**
2. **优先使用ApiResponse类的方法返回错误**
3. **提供有意义的错误消息，但不暴露系统内部细节**
4. **记录详细的错误日志，包括上下文信息**
5. **区分验证错误和业务错误**
6. **使用适当的HTTP状态码**
7. **对于预期的业务异常，提前检查并返回友好错误**
8. **定期检查错误日志，优化异常处理**

#### 错误日志格式

系统异常日志包含以下关键信息：

- 时间戳
- 错误级别（ERROR/WARNING/INFO等）
- 错误消息
- 异常类型
- 异常堆栈
- 请求上下文（请求ID、用户ID、请求路径等）
- 业务上下文（相关业务ID、操作类型等）

这些日志对于问题排查和系统监控非常重要，开发人员应该熟悉日志格式并利用日志进行问题分析。

## API端点

### 认证相关

#### 登录
```http
POST /api/v2/auth/login
```

**请求参数**:
```json
{
    "username": "string",
    "password": "string",
    "captcha": "string"
}
```

**响应**: JWT令牌和用户信息

#### 登出
```http
POST /api/v2/auth/logout
Authorization: Bearer <token>
```

#### 刷新令牌
```http
POST /api/v2/auth/refresh
```

#### 获取用户信息
```http
GET /api/v2/auth/me
Authorization: Bearer <token>
```

### 用户管理

#### 获取用户列表
```http
GET /api/v2/users?page=1&per_page=20&role=admin&status=active
Authorization: Bearer <token>
```

**查询参数**:
- `page`: 页码 (默认: 1)
- `per_page`: 每页数量 (默认: 20, 最大: 100)
- `role`: 角色筛选
- `status`: 状态筛选
- `search`: 搜索关键词

#### 创建用户
```http
POST /api/v2/users
Authorization: Bearer <token>
Content-Type: application/json

{
    "username": "newuser",
    "email": "user@example.com",
    "password": "password123",
    "role": "user",
    "status": "active"
}
```

#### 获取用户详情
```http
GET /api/v2/users/{id}
Authorization: Bearer <token>
```

#### 更新用户
```http
PUT /api/v2/users/{id}
Authorization: Bearer <token>
Content-Type: application/json

{
    "email": "newemail@example.com",
    "role": "admin",
    "status": "active"
}
```

#### 删除用户
```http
DELETE /api/v2/users/{id}
Authorization: Bearer <token>
```

### 产品管理

#### 获取产品列表
```http
GET /api/v2/products?page=1&per_page=20&category=software&status=active
Authorization: Bearer <token>
```

**查询参数**:
- `page`: 页码
- `per_page`: 每页数量
- `category`: 产品分类
- `status`: 产品状态
- `search`: 搜索关键词
- `sort`: 排序字段
- `order`: 排序方向 (asc/desc)

#### 创建产品
```http
POST /api/v2/products
Authorization: Bearer <token>
Content-Type: application/json

{
    "name": "软件产品",
    "description": "产品描述",
    "category": "software",
    "price": 99.99,
    "stock": 100,
    "status": "active",
    "images": [
        "https://example.com/image1.jpg"
    ],
    "attributes": {
        "version": "1.0.0",
        "platform": "windows"
    }
}
```

#### 获取产品详情
```http
GET /api/v2/products/{id}
Authorization: Bearer <token>
```

#### 更新产品
```http
PUT /api/v2/products/{id}
Authorization: Bearer <token>
Content-Type: application/json

{
    "name": "更新的产品名称",
    "price": 149.99,
    "stock": 150
}
```

#### 删除产品
```http
DELETE /api/v2/products/{id}
Authorization: Bearer <token>
```

### 订单管理

#### 获取订单列表
```http
GET /api/v2/orders?page=1&per_page=20&status=pending&date_from=2024-01-01&date_to=2024-01-31
Authorization: Bearer <token>
```

**查询参数**:
- `page`: 页码
- `per_page`: 每页数量
- `status`: 订单状态
- `date_from`: 开始日期
- `date_to`: 结束日期
- `user_id`: 用户ID
- `product_id`: 产品ID

#### 创建订单
```http
POST /api/v2/orders
Authorization: Bearer <token>
Content-Type: application/json

{
    "user_id": 123,
    "items": [
        {
            "product_id": 1,
            "quantity": 2,
            "price": 99.99
        }
    ],
    "payment_method": "alipay",
    "contact_info": {
        "email": "user@example.com",
        "phone": "13800138000"
    }
}
```

#### 获取订单详情
```http
GET /api/v2/orders/{id}
Authorization: Bearer <token>
```

#### 更新订单状态
```http
PATCH /api/v2/orders/{id}/status
Authorization: Bearer <token>
Content-Type: application/json

{
    "status": "completed",
    "note": "订单已完成"
}
```

### 卡密管理

#### 获取卡密列表
```http
GET /api/v2/cards?page=1&per_page=20&product_id=1&status=available
Authorization: Bearer <token>
```

#### 生成卡密
```http
POST /api/v2/cards/generate
Authorization: Bearer <token>
Content-Type: application/json

{
    "product_id": 1,
    "quantity": 100,
    "prefix": "CARD",
    "length": 16,
    "expires_at": "2024-12-31T23:59:59Z"
}
```

#### 批量导入卡密
```http
POST /api/v2/cards/import
Authorization: Bearer <token>
Content-Type: multipart/form-data

file: cards.csv
```

**CSV格式**:
```csv
card_code,product_id,expires_at
CARD1234567890123,1,2024-12-31
CARD1234567890124,1,2024-12-31
```

#### 分配卡密
```http
POST /api/v2/cards/{id}/assign
Authorization: Bearer <token>
Content-Type: application/json

{
    "order_id": 123,
    "user_id": 456
}
```

### 支付管理

#### 创建支付
```http
POST /api/v2/payments
Authorization: Bearer <token>
Content-Type: application/json

{
    "order_id": 123,
    "payment_method": "alipay",
    "amount": 199.98,
    "return_url": "https://your-domain.com/payment/return",
    "notify_url": "https://your-domain.com/payment/notify"
}
```

#### 查询支付状态
```http
GET /api/v2/payments/{id}
Authorization: Bearer <token>
```

#### 支付回调处理
```http
POST /api/v2/payments/notify/{provider}
Content-Type: application/json

{
    // 支付平台回调数据
}
```

### 统计分析

#### 获取销售统计
```http
GET /api/v2/analytics/sales?period=30&group_by=day
Authorization: Bearer <token>
```

**查询参数**:
- `period`: 统计周期 (天数)
- `group_by`: 分组方式 (day/week/month)
- `date_from`: 开始日期
- `date_to`: 结束日期

#### 获取用户统计
```http
GET /api/v2/analytics/users?period=30
Authorization: Bearer <token>
```

#### 获取产品统计
```http
GET /api/v2/analytics/products?period=30
Authorization: Bearer <token>
```

### 批量操作

#### 批量删除
```http
DELETE /api/v2/batch/delete
Authorization: Bearer <token>
Content-Type: application/json

{
    "type": "products",
    "ids": [1, 2, 3, 4, 5]
}
```

#### 批量更新
```http
PUT /api/v2/batch/update
Authorization: Bearer <token>
Content-Type: application/json

{
    "type": "products",
    "ids": [1, 2, 3],
    "data": {
        "status": "inactive"
    }
}
```

#### 批量导出
```http
POST /api/v2/batch/export
Authorization: Bearer <token>
Content-Type: application/json

{
    "type": "orders",
    "filters": {
        "date_from": "2024-01-01",
        "date_to": "2024-01-31",
        "status": "completed"
    },
    "format": "csv"
}
```

### 系统管理

#### 系统信息
```http
GET /api/v2/system/info
Authorization: Bearer <token>
```

#### 系统健康检查
```http
GET /api/v2/system/health
```

#### 系统配置
```http
GET /api/v2/system/config
Authorization: Bearer <token>
```

```http
PUT /api/v2/system/config
Authorization: Bearer <token>
Content-Type: application/json

{
    "site_name": "发卡系统",
    "maintenance_mode": false,
    "max_upload_size": "10MB"
}
```

## 数据模型

### 用户模型
```json
{
    "id": 1,
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin",
    "status": "active",
    "created_at": "2024-01-01T12:00:00Z",
    "updated_at": "2024-01-01T12:00:00Z",
    "last_login": "2024-01-01T12:00:00Z"
}
```

### 产品模型
```json
{
    "id": 1,
    "name": "软件产品",
    "description": "产品描述",
    "category": "software",
    "price": 99.99,
    "stock": 100,
    "sold": 50,
    "status": "active",
    "images": [
        "https://example.com/image1.jpg"
    ],
    "attributes": {
        "version": "1.0.0",
        "platform": "windows"
    },
    "created_at": "2024-01-01T12:00:00Z",
    "updated_at": "2024-01-01T12:00:00Z"
}
```

### 订单模型
```json
{
    "id": 1,
    "order_no": "ORD20240101001",
    "user_id": 123,
    "status": "completed",
    "total_amount": 199.98,
    "items": [
        {
            "product_id": 1,
            "product_name": "软件产品",
            "quantity": 2,
            "price": 99.99,
            "subtotal": 199.98
        }
    ],
    "payment_method": "alipay",
    "payment_status": "paid",
    "contact_info": {
        "email": "user@example.com",
        "phone": "13800138000"
    },
    "created_at": "2024-01-01T12:00:00Z",
    "updated_at": "2024-01-01T12:00:00Z"
}
```

### 卡密模型
```json
{
    "id": 1,
    "card_code": "CARD1234567890123",
    "product_id": 1,
    "product_name": "软件产品",
    "status": "available",
    "order_id": null,
    "user_id": null,
    "assigned_at": null,
    "expires_at": "2024-12-31T23:59:59Z",
    "created_at": "2024-01-01T12:00:00Z"
}
```

## 示例代码

### JavaScript (Axios)
```javascript
// 配置API客户端
const api = axios.create({
    baseURL: 'https://your-domain.com/api/v2',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
});

// 添加请求拦截器
api.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// 添加响应拦截器
api.interceptors.response.use(
    response => response.data,
    error => {
        if (error.response?.status === 401) {
            // 处理未授权
            localStorage.removeItem('token');
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

// 登录
async function login(username, password) {
    try {
        const response = await api.post('/auth/login', {
            username,
            password
        });
        
        localStorage.setItem('token', response.data.token);
        return response.data;
    } catch (error) {
        console.error('登录失败:', error.response?.data?.error?.message);
        throw error;
    }
}

// 获取产品列表
async function getProducts(page = 1, filters = {}) {
    try {
        const response = await api.get('/products', {
            params: { page, ...filters }
        });
        return response.data;
    } catch (error) {
        console.error('获取产品失败:', error.response?.data?.error?.message);
        throw error;
    }
}

// 创建订单
async function createOrder(orderData) {
    try {
        const response = await api.post('/orders', orderData);
        return response.data;
    } catch (error) {
        console.error('创建订单失败:', error.response?.data?.error?.message);
        throw error;
    }
}
```

### PHP (Guzzle)
```php
<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class CardSystemAPI
{
    private $client;
    private $token;
    
    public function __construct($baseUri)
    {
        $this->client = new Client([
            'base_uri' => $baseUri,
            'timeout' => 10,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ]
        ]);
    }
    
    public function login($username, $password)
    {
        try {
            $response = $this->client->post('/auth/login', [
                'json' => [
                    'username' => $username,
                    'password' => $password
                ]
            ]);
            
            $data = json_decode($response->getBody(), true);
            $this->token = $data['data']['token'];
            
            return $data;
        } catch (RequestException $e) {
            $this->handleError($e);
        }
    }
    
    public function getProducts($page = 1, $filters = [])
    {
        try {
            $response = $this->client->get('/products', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->token
                ],
                'query' => array_merge(['page' => $page], $filters)
            ]);
            
            return json_decode($response->getBody(), true);
        } catch (RequestException $e) {
            $this->handleError($e);
        }
    }
    
    public function createOrder($orderData)
    {
        try {
            $response = $this->client->post('/orders', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->token
                ],
                'json' => $orderData
            ]);
            
            return json_decode($response->getBody(), true);
        } catch (RequestException $e) {
            $this->handleError($e);
        }
    }
    
    private function handleError($exception)
    {
        if ($exception->hasResponse()) {
            $response = $exception->getResponse();
            $body = json_decode($response->getBody(), true);
            
            throw new Exception($body['error']['message'] ?? 'API请求失败');
        }
        
        throw new Exception('网络请求失败');
    }
}

// 使用示例
$api = new CardSystemAPI('https://your-domain.com/api/v2');

// 登录
$loginResult = $api->login('admin', 'password');

// 获取产品列表
$products = $api->getProducts(1, ['category' => 'software']);

// 创建订单
$orderData = [
    'user_id' => 123,
    'items' => [
        [
            'product_id' => 1,
            'quantity' => 2,
            'price' => 99.99
        ]
    ],
    'payment_method' => 'alipay'
];

$order = $api->createOrder($orderData);
```

### Python (Requests)
```python
import requests
import json
from datetime import datetime

class CardSystemAPI:
    def __init__(self, base_url):
        self.base_url = base_url
        self.token = None
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
    
    def login(self, username, password):
        """登录获取token"""
        url = f"{self.base_url}/auth/login"
        data = {
            'username': username,
            'password': password
        }
        
        try:
            response = self.session.post(url, json=data)
            response.raise_for_status()
            
            result = response.json()
            self.token = result['data']['token']
            self.session.headers.update({
                'Authorization': f'Bearer {self.token}'
            })
            
            return result
        except requests.exceptions.RequestException as e:
            self._handle_error(e)
    
    def get_products(self, page=1, **filters):
        """获取产品列表"""
        url = f"{self.base_url}/products"
        params = {'page': page, **filters}
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self._handle_error(e)
    
    def create_order(self, order_data):
        """创建订单"""
        url = f"{self.base_url}/orders"
        
        try:
            response = self.session.post(url, json=order_data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self._handle_error(e)
    
    def get_order(self, order_id):
        """获取订单详情"""
        url = f"{self.base_url}/orders/{order_id}"
        
        try:
            response = self.session.get(url)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self._handle_error(e)
    
    def _handle_error(self, exception):
        """处理API错误"""
        if hasattr(exception, 'response') and exception.response is not None:
            try:
                error_data = exception.response.json()
                error_message = error_data.get('error', {}).get('message', 'API请求失败')
                raise Exception(f"API错误: {error_message}")
            except ValueError:
                raise Exception(f"HTTP错误: {exception.response.status_code}")
        else:
            raise Exception(f"网络错误: {str(exception)}")

# 使用示例
api = CardSystemAPI('https://your-domain.com/api/v2')

# 登录
login_result = api.login('admin', 'password')
print(f"登录成功: {login_result['data']['user']['username']}")

# 获取产品列表
products = api.get_products(page=1, category='software')
print(f"获取到 {len(products['data']['items'])} 个产品")

# 创建订单
order_data = {
    'user_id': 123,
    'items': [
        {
            'product_id': 1,
            'quantity': 2,
            'price': 99.99
        }
    ],
    'payment_method': 'alipay',
    'contact_info': {
        'email': 'user@example.com',
        'phone': '13800138000'
    }
}

order = api.create_order(order_data)
print(f"订单创建成功: {order['data']['order_no']}")
```

## 版本控制

### 版本策略
- 使用语义化版本控制 (SemVer)
- 主版本号：不兼容的API修改
- 次版本号：向下兼容的功能性新增
- 修订号：向下兼容的问题修正

### 版本支持
- 当前版本：v2.0.0
- 支持版本：v1.x.x (即将弃用)
- 弃用通知：提前3个月通知

### 版本升级指南

#### 从v1升级到v2
1. **认证方式变更**
   - v1: API Key认证
   - v2: JWT认证

2. **响应格式变更**
   - v1: 直接返回数据
   - v2: 统一包装格式

3. **端点变更**
   - `/api/user` → `/api/v2/users`
   - `/api/product` → `/api/v2/products`

4. **参数变更**
   - 分页参数：`limit/offset` → `page/per_page`

### 向后兼容性
- 保持至少6个月的向后兼容性
- 提供弃用警告头
- 文档中明确标注弃用功能

---

## 更新日志

### v2.0.0 (2024-01-01)
- 新增JWT认证机制
- 重构API响应格式
- 添加批量操作接口
- 优化错误处理
- 增加统计分析功能

### v1.5.0 (2023-10-01)
- 添加支付回调接口
- 优化卡密管理功能
- 增加数据导出功能

### v1.0.0 (2023-06-01)
- 初始版本发布
- 基础CRUD操作
- 用户认证系统

---

## 联系信息

- **技术支持**: api-support@example.com
- **文档网站**: https://docs.example.com/api
- **问题反馈**: https://github.com/your-repo/card-system/issues

---

*最后更新: 2024年1月*