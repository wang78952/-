-- 发卡系统数据库创建脚本
-- 数据库名：card_system

-- 创建数据库
CREATE DATABASE IF NOT EXISTS `card_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE `card_system`;

-- 创建卡片表
CREATE TABLE IF NOT EXISTS `cards` (
    `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '卡片ID',
    `card_number` varchar(16) NOT NULL COMMENT '卡号（16位）',
    `card_type` varchar(20) NOT NULL COMMENT '卡片类型：借记卡/信用卡/预付卡',
    `status` varchar(20) NOT NULL DEFAULT '未激活' COMMENT '状态：未激活/正常/冻结',
    `expire_date` varchar(7) DEFAULT NULL COMMENT '有效期（格式：YYYY-MM）',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_card_number` (`card_number`),
    KEY `idx_card_type` (`card_type`),
    KEY `idx_status` (`status`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡片信息表';

-- 插入示例数据（可选）
INSERT INTO `cards` (`card_number`, `card_type`, `status`, `expire_date`) VALUES
('6222021234567890', '借记卡', '未激活', '2028-12'),
('6222021234567891', '借记卡', '正常', '2027-06'),
('6222021234567892', '信用卡', '未激活', '2029-03'),
('6222021234567893', '预付卡', '正常', '2026-12'),
('6222021234567894', '信用卡', '冻结', '2028-09');

-- 查看表结构
DESCRIBE `cards`;

-- 查看示例数据
SELECT * FROM `cards`;