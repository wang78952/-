<?php
/**
 * 输入验证和数据清理类
 * 防止XSS、SQL注入、CSRF等安全攻击
 */

require_once __DIR__ . '/ErrorHandler.php';

/**
 * 输入验证器类
 */
class InputValidator {
    private static $instance = null;
    private $patterns = array();
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->initializePatterns();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化验证模式
     */
    private function initializePatterns() {
        $this->patterns = array(
            'username' => array(
                'pattern' => '/^[a-zA-Z0-9_]{3,20}$/',
                'message' => '用户名只能包含字母、数字和下划线，长度3-20位'
            ),
            'password' => array(
                'pattern' => '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{' . PASSWORD_MIN_LENGTH . ',}$/',
                'message' => '密码必须包含大小写字母、数字和特殊字符，最少' . PASSWORD_MIN_LENGTH . '位'
            ),
            'email' => array(
                'pattern' => '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/',
                'message' => '邮箱格式不正确'
            ),
            'phone' => array(
                'pattern' => '/^1[3-9]\d{9}$/',
                'message' => '手机号格式不正确'
            ),
            'id_card' => array(
                'pattern' => '/^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/',
                'message' => '身份证号格式不正确'
            ),
            'card_number' => array(
                'pattern' => '/^\d{16,19}$/',
                'message' => '卡号格式不正确，应为16-19位数字'
            ),
            'amount' => array(
                'pattern' => '/^\d+(\.\d{1,2})?$/',
                'message' => '金额格式不正确'
            ),
            'date' => array(
                'pattern' => '/^\d{4}-\d{2}-\d{2}$/',
                'message' => '日期格式不正确，应为YYYY-MM-DD'
            ),
            'datetime' => array(
                'pattern' => '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
                'message' => '日期时间格式不正确，应为YYYY-MM-DD HH:MM:SS'
            ),
            'ip_address' => array(
                'pattern' => '/^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/',
                'message' => 'IP地址格式不正确'
            ),
            'url' => array(
                'pattern' => '/^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$/',
                'message' => 'URL格式不正确'
            ),
            'chinese_name' => array(
                'pattern' => '/^[\u4e00-\u9fa5]{2,10}$/',
                'message' => '姓名格式不正确，应为2-10位中文字符'
            ),
            'english_name' => array(
                'pattern' => '/^[a-zA-Z\s]{2,50}$/',
                'message' => '英文名格式不正确，应为2-50位字母和空格'
            )
        );
    }
    
    /**
     * 验证输入数据
     */
    public function validate($input, $type, $options = array()) {
        if (empty($input) && (isset($options['required']) ? $options['required'] : true)) {
            throw new ValidationException('输入不能为空');
        }
        
        if (empty($input) && !(isset($options['required']) ? $options['required'] : true)) {
            return $input;
        }
        
        switch ($type) {
            case 'string':
                return $this->validateString($input, $options);
                
            case 'integer':
                return $this->validateInteger($input, $options);
                
            case 'float':
                return $this->validateFloat($input, $options);
                
            case 'boolean':
                return $this->validateBoolean($input, $options);
                
            case 'array':
                return $this->validateArray($input, $options);
                
            case 'email':
                return $this->validateEmail($input, $options);
                
            case 'password':
                return $this->validatePassword($input, $options);
                
            case 'username':
                return $this->validateUsername($input, $options);
                
            case 'phone':
                return $this->validatePhone($input, $options);
                
            case 'card_number':
                return $this->validateCardNumber($input, $options);
                
            case 'id_card':
                return $this->validateIdCard($input, $options);
                
            default:
                if (isset($this->patterns[$type])) {
                    return $this->validatePattern($input, $type);
                }
                throw new ValidationException("未知的验证类型: {$type}");
        }
    }
    
    /**
     * 验证字符串
     */
    private function validateString($input, $options) {
        if (!is_string($input)) {
            throw new ValidationException('输入必须是字符串');
        }
        
        $length = mb_strlen($input, 'UTF-8');
        
        if (isset($options['min_length']) && $length < $options['min_length']) {
            throw new ValidationException("长度不能少于{$options['min_length']}位");
        }
        
        if (isset($options['max_length']) && $length > $options['max_length']) {
            throw new ValidationException("长度不能超过{$options['max_length']}位");
        }
        
        if (isset($options['allowed_chars'])) {
            if (!preg_match($options['allowed_chars'], $input)) {
                throw new ValidationException('包含不允许的字符');
            }
        }
        
        return $this->sanitizeString($input);
    }
    
    /**
     * 验证整数
     */
    private function validateInteger($input, $options) {
        if (!is_numeric($input)) {
            throw new ValidationException('输入必须是数字');
        }
        
        $value = (int)$input;
        
        if (isset($options['min']) && $value < $options['min']) {
            throw new ValidationException("值不能小于{$options['min']}");
        }
        
        if (isset($options['max']) && $value > $options['max']) {
            throw new ValidationException("值不能大于{$options['max']}");
        }
        
        return $value;
    }
    
    /**
     * 验证浮点数
     */
    private function validateFloat($input, $options) {
        if (!is_numeric($input)) {
            throw new ValidationException('输入必须是数字');
        }
        
        $value = (float)$input;
        
        if (isset($options['min']) && $value < $options['min']) {
            throw new ValidationException("值不能小于{$options['min']}");
        }
        
        if (isset($options['max']) && $value > $options['max']) {
            throw new ValidationException("值不能大于{$options['max']}");
        }
        
        if (isset($options['decimals'])) {
            $value = round($value, $options['decimals']);
        }
        
        return $value;
    }
    
    /**
     * 验证布尔值
     */
    private function validateBoolean($input, $options) {
        if (is_bool($input)) {
            return $input;
        }
        
        if (is_string($input)) {
            $input = strtolower($input);
            if (in_array($input, ['true', '1', 'yes', 'on'])) {
                return true;
            } elseif (in_array($input, ['false', '0', 'no', 'off'])) {
                return false;
            }
        }
        
        if (is_numeric($input)) {
            return (bool)$input;
        }
        
        throw new ValidationException('输入必须是布尔值');
    }
    
    /**
     * 验证数组
     */
    private function validateArray($input, $options) {
        if (!is_array($input)) {
            throw new ValidationException('输入必须是数组');
        }
        
        if (isset($options['min_count']) && count($input) < $options['min_count']) {
            throw new ValidationException("数组元素不能少于{$options['min_count']}个");
        }
        
        if (isset($options['max_count']) && count($input) > $options['max_count']) {
            throw new ValidationException("数组元素不能超过{$options['max_count']}个");
        }
        
        if (isset($options['allowed_values'])) {
            foreach ($input as $value) {
                if (!in_array($value, $options['allowed_values'])) {
                    throw new ValidationException('数组包含不允许的值');
                }
            }
        }
        
        return $input;
    }
    
    /**
     * 验证邮箱
     */
    private function validateEmail($input, $options) {
        if (!filter_var($input, FILTER_VALIDATE_EMAIL)) {
            throw new ValidationException('邮箱格式不正确');
        }
        
        $input = strtolower($input);
        
        if (isset($options['allowed_domains'])) {
            $domain = substr(strrchr($input, '@'), 1);
            if (!in_array($domain, $options['allowed_domains'])) {
                throw new ValidationException('邮箱域名不在允许列表中');
            }
        }
        
        return $input;
    }
    
    /**
     * 验证密码
     */
    private function validatePassword($input, $options) {
        $length = strlen($input);
        
        if ($length < PASSWORD_MIN_LENGTH) {
            throw new ValidationException("密码长度不能少于" . PASSWORD_MIN_LENGTH . "位");
        }
        
        if (PASSWORD_REQUIRE_UPPERCASE && !preg_match('/[A-Z]/', $input)) {
            throw new ValidationException('密码必须包含大写字母');
        }
        
        if (PASSWORD_REQUIRE_LOWERCASE && !preg_match('/[a-z]/', $input)) {
            throw new ValidationException('密码必须包含小写字母');
        }
        
        if (PASSWORD_REQUIRE_NUMBERS && !preg_match('/\d/', $input)) {
            throw new ValidationException('密码必须包含数字');
        }
        
        if (PASSWORD_REQUIRE_SYMBOLS && !preg_match('/[@$!%*?&]/', $input)) {
            throw new ValidationException('密码必须包含特殊字符');
        }
        
        return $input;
    }
    
    /**
     * 验证用户名
     */
    private function validateUsername($input, $options) {
        return $this->validatePattern($input, 'username');
    }
    
    /**
     * 验证手机号
     */
    private function validatePhone($input, $options) {
        $input = preg_replace('/\D/', '', $input);
        return $this->validatePattern($input, 'phone');
    }
    
    /**
     * 验证卡号
     */
    private function validateCardNumber($input, $options) {
        $input = preg_replace('/\D/', '', $input);
        
        if (!$this->validateLuhn($input)) {
            throw new ValidationException('卡号校验失败');
        }
        
        return $this->validatePattern($input, 'card_number');
    }
    
    /**
     * 验证身份证号
     */
    private function validateIdCard($input, $options) {
        $input = strtoupper($input);
        
        if (!$this->validateIdCardChecksum($input)) {
            throw new ValidationException('身份证号校验失败');
        }
        
        return $this->validatePattern($input, 'id_card');
    }
    
    /**
     * 使用正则表达式验证
     */
    private function validatePattern($input, $type) {
        if (!isset($this->patterns[$type])) {
            throw new ValidationException("未知的验证模式: {$type}");
        }
        
        $pattern = $this->patterns[$type];
        
        if (!preg_match($pattern['pattern'], $input)) {
            throw new ValidationException($pattern['message']);
        }
        
        return $input;
    }
    
    /**
     * 清理字符串
     */
    private function sanitizeString($input) {
        // 移除控制字符
        $input = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $input);
        
        // HTML转义
        $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        return $input;
    }
    
    /**
     * Luhn算法验证
     */
    private function validateLuhn($number) {
        $sum = 0;
        $alternate = false;
        
        for ($i = strlen($number) - 1; $i >= 0; $i--) {
            $digit = intval($number[$i]);
            
            if ($alternate) {
                $digit *= 2;
                if ($digit > 9) {
                    $digit = ($digit % 10) + 1;
                }
            }
            
            $sum += $digit;
            $alternate = !$alternate;
        }
        
        return ($sum % 10) === 0;
    }
    
    /**
     * 身份证校验码验证
     */
    private function validateIdCardChecksum($idCard) {
        if (strlen($idCard) !== 18) {
            return false;
        }
        
        $weights = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
        $checksumMap = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
        
        $sum = 0;
        for ($i = 0; $i < 17; $i++) {
            $sum += intval($idCard[$i]) * $weights[$i];
        }
        
        $checksum = $checksumMap[$sum % 11];
        return $idCard[17] === $checksum;
    }
    
    /**
     * 批量验证
     */
    public function validateBatch($data, $rules) {
        $errors = array();
        $validated = array();
        
        foreach ($rules as $field => $rule) {
            try {
                $value = isset($data[$field]) ? $data[$field] : null;
                $validated[$field] = $this->validate($value, $rule['type'], isset($rule['options']) ? $rule['options'] : array());
            } catch (ValidationException $e) {
                $errors[$field] = $e->getMessage();
            }
        }
        
        if (!empty($errors)) {
            throw new ValidationException('验证失败', $errors);
        }
        
        return $validated;
    }
    
    /**
     * 清理和过滤输入数据
     */
    public function sanitize($input, $type = 'general') {
        if (is_array($input)) {
            return array_map([$this, 'sanitize'], $input, array_fill(0, count($input), $type));
        }
        
        switch ($type) {
            case 'sql':
                return $this->sanitizeForSQL($input);
                
            case 'html':
                return $this->sanitizeForHTML($input);
                
            case 'js':
                return $this->sanitizeForJS($input);
                
            case 'url':
                return $this->sanitizeForURL($input);
                
            case 'file':
                return $this->sanitizeForFile($input);
                
            default:
                return $this->sanitizeString($input);
        }
    }
    
    /**
     * SQL注入防护
     */
    private function sanitizeForSQL($input) {
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除SQL关键字和特殊字符
        $sqlKeywords = array(
            'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER',
            'UNION', 'EXEC', 'EXECUTE', 'DECLARE', 'CAST', 'CONVERT', 'SCRIPT',
            'JAVASCRIPT', 'VBSCRIPT', 'ONLOAD', 'ONERROR', 'ONCLICK'
        );
        
        $pattern = '/\b(' . implode('|', $sqlKeywords) . ')\b/i';
        $input = preg_replace($pattern, '', $input);
        
        // 移除注释
        $input = preg_replace('/\/\*.*?\*\//', '', $input);
        $input = preg_replace('/--.*$/m', '', $input);
        
        // 移除特殊字符
        $input = str_replace(array("'", '"', ';', '\\', '/', '*', '=', '<', '>', '&', '|'), '', $input);
        
        return trim($input);
    }
    
    /**
     * XSS防护
     */
    private function sanitizeForHTML($input) {
        if (!is_string($input)) {
            return $input;
        }
        
        // HTML实体编码
        $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // 移除危险标签
        $dangerousTags = array(
            '<script', '</script', '<iframe', '</iframe', '<object', '</object',
            '<embed', '</embed', '<form', '</form', '<input', '<textarea',
            '<button', '<select', '<option', '<link', '<meta'
        );
        
        foreach ($dangerousTags as $tag) {
            $input = str_ireplace($tag, '', $input);
        }
        
        return $input;
    }
    
    /**
     * JavaScript注入防护
     */
    private function sanitizeForJS($input) {
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除JavaScript事件处理器
        $jsEvents = array(
            'onload', 'onerror', 'onclick', 'ondblclick', 'onmousedown', 'onmouseup',
            'onmouseover', 'onmouseout', 'onmousemove', 'onkeydown', 'onkeyup',
            'onkeypress', 'onsubmit', 'onreset', 'onfocus', 'onblur', 'onchange'
        );
        
        foreach ($jsEvents as $event) {
            $input = preg_replace('/\b' . $event . '\s*=/i', '', $input);
        }
        
        // 移除javascript:协议
        $input = preg_replace('/javascript\s*:/i', '', $input);
        
        return $input;
    }
    
    /**
     * URL注入防护
     */
    private function sanitizeForURL($input) {
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除危险协议
        $dangerousProtocols = array('javascript:', 'data:', 'vbscript:', 'file:');
        foreach ($dangerousProtocols as $protocol) {
            $input = str_ireplace($protocol, '', $input);
        }
        
        return filter_var($input, FILTER_SANITIZE_URL);
    }
    
    /**
     * 文件名安全处理
     */
    private function sanitizeForFile($input) {
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除路径遍历字符
        $input = str_replace(array('../', '..\\', '/', '\\'), '', $input);
        
        // 移除危险字符
        $input = preg_replace('/[<>:"|?*]/', '', $input);
        
        // 限制长度
        return substr($input, 0, 255);
    }
}

/**
 * 验证异常类
 */
class ValidationException extends Exception {
    private $errors = array();
    
    public function __construct($message, $errors = array(), $code = 0, $previous = null) {
        parent::__construct($message, $code, $previous);
        $this->errors = $errors;
    }
    
    public function getErrors() {
        return $this->errors;
    }
}


?>