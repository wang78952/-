<?php
/**
 * 多端适配与国际化示例页面
 * 展示响应式设计和多语言支持的实际应用
 */

// 确保系统已加载
if (!defined('IN_SYSTEM')) {
    define('IN_SYSTEM', true);
    require_once dirname(dirname(__DIR__)) . '/core/init.php';
}

// 初始化语言切换器
if (class_exists('LanguageSwitcher')) {
    $languageSwitcher = new LanguageSwitcher();
    $currentLang = $languageSwitcher->getCurrentLanguage();
} else {
    $currentLang = 'zh_CN'; // 默认语言
}

// 模拟翻译函数
function __($text) {
    static $translations = [];
    
    if (empty($translations)) {
        // 这里应该从LanguageSwitcher获取翻译
        // 为演示目的，使用硬编码的示例
        $translations = [
            'responsive_example_title' => '响应式设计与国际化示例',
            'welcome_message' => '欢迎使用发卡系统的响应式设计示例',
            'feature_demo' => '功能演示',
            'responsive_design' => '响应式设计',
            'responsive_desc' => '页面会根据设备屏幕尺寸自动调整布局',
            'internationalization' => '国际化支持',
            'i18n_desc' => '支持多语言切换，适应不同地区用户',
            'mobile_optimization' => '移动端优化',
            'mobile_desc' => '专为移动设备设计的交互体验',
            'device_detection' => '设备检测',
            'device_desc' => '自动识别设备类型并应用相应的布局',
            'try_resize' => '尝试调整浏览器窗口大小，查看响应式效果',
            'card_demo_title' => '响应式卡片组件演示',
            'card_1_title' => '系统状态',
            'card_1_desc' => '实时监控系统运行状态',
            'card_2_title' => '交易数据',
            'card_2_desc' => '查看最新交易和统计信息',
            'card_3_title' => '用户管理',
            'card_3_desc' => '管理用户账户和权限设置',
            'card_4_title' => '产品管理',
            'card_4_desc' => '创建和管理卡片产品',
            'form_demo_title' => '响应式表单演示',
            'form_name' => '姓名',
            'form_email' => '邮箱',
            'form_message' => '留言',
            'form_submit' => '提交',
            'table_demo_title' => '响应式表格演示',
            'table_id' => 'ID',
            'table_name' => '名称',
            'table_status' => '状态',
            'table_actions' => '操作',
            'status_active' => '活跃',
            'status_inactive' => '非活跃',
            'action_edit' => '编辑',
            'action_delete' => '删除',
            'responsive_tips' => '响应式设计提示',
            'tip_1_title' => '移动优先',
            'tip_1_desc' => '从移动设备开始设计，然后逐步扩展到更大的屏幕',
            'tip_2_title' => '灵活网格',
            'tip_2_desc' => '使用灵活的网格系统，确保内容可以适应不同屏幕尺寸',
            'tip_3_title' => '媒体查询',
            'tip_3_desc' => '使用CSS媒体查询根据屏幕宽度应用不同的样式',
            'tip_4_title' => '响应式图片',
            'tip_4_desc' => '使用响应式图片技术，确保在各种设备上都能高效加载',
            'language_switcher_title' => '语言切换',
            'mobile_nav_tip' => '在移动设备上，导航菜单会转换为汉堡菜单',
            'footer_text' => '© 2024 发卡系统 - 响应式设计与国际化示例',
            'table_data_1' => '用户1',
            'table_data_2' => '用户2',
            'table_data_3' => '用户3',
            'table_data_4' => '用户4',
            'table_data_5' => '用户5',
        ];
    }
    
    return $translations[$text] ?? $text;
}

// 获取设备信息
function getDeviceInfo() {
    if (class_exists('MobileDeviceDetector')) {
        $detector = new MobileDeviceDetector();
        return [
            'isMobile' => $detector->isMobile(),
            'isTablet' => $detector->isTablet(),
            'isDesktop' => $detector->isDesktop(),
            'deviceType' => $detector->getDeviceType(),
            'screenWidth' => $detector->getScreenWidth(),
            'screenHeight' => $detector->getScreenHeight(),
        ];
    }
    return [
        'isMobile' => false,
        'isTablet' => false,
        'isDesktop' => true,
        'deviceType' => 'desktop',
        'screenWidth' => 1920,
        'screenHeight' => 1080,
    ];
}

$deviceInfo = getDeviceInfo();

// 输出HTML
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo __('responsive_example_title'); ?></title>
    
    <!-- 加载响应式CSS -->
    <?php if (file_exists(dirname(dirname(dirname(__DIR__))) . '/assets/css/responsive.css')): ?>
    <link rel="stylesheet" href="<?php echo '/assets/css/responsive.css'; ?>">
    <?php endif; ?>
    
    <!-- 自定义响应式示例CSS -->
    <style>
        /* 全局样式 */
        :root {
            --primary-color: #007bff;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --border-color: #dee2e6;
            --background-color: #ffffff;
            --text-color: #212529;
            --box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--background-color);
        }
        
        /* 容器 */
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }
        
        /* 页头 */
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 2rem 0;
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            font-weight: 600;
        }
        
        .header p {
            font-size: 1.2rem;
            opacity: 0.9;
        }
        
        /* 部分 */
        .section {
            margin-bottom: 3rem;
            padding: 2rem;
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--primary-color);
            position: relative;
            padding-bottom: 0.5rem;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 4px;
            background-color: var(--primary-color);
            border-radius: 2px;
        }
        
        /* 卡片网格 */
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .card {
            background-color: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        
        .card-body {
            padding: 1.5rem;
            flex-grow: 1;
        }
        
        .card-title {
            font-size: 1.25rem;
            margin-bottom: 0.75rem;
            color: var(--dark-color);
        }
        
        .card-text {
            color: var(--secondary-color);
            font-size: 0.95rem;
        }
        
        /* 特性列表 */
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }
        
        .feature {
            padding: 1.5rem;
            background-color: var(--light-color);
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .feature:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .feature:hover .feature-icon {
            color: white;
            transform: scale(1.1);
        }
        
        .feature-title {
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        
        /* 表单 */
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            font-size: 1rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.25);
        }
        
        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
            font-weight: 500;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            cursor: pointer;
            border: 1px solid transparent;
            border-radius: 4px;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .btn-primary {
            color: white;
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        
        /* 表格 */
        .table-container {
            overflow-x: auto;
            margin: 1.5rem 0;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .table th {
            background-color: var(--light-color);
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .table tbody tr:hover {
            background-color: var(--light-color);
        }
        
        /* 提示框 */
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        
        .alert-info {
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }
        
        /* 语言切换器 */
        .language-switcher {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1000;
        }
        
        .lang-btn {
            background-color: var(--dark-color);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .lang-btn:hover {
            background-color: var(--primary-color);
        }
        
        /* 设备信息 */
        .device-info {
            position: fixed;
            bottom: 1rem;
            left: 1rem;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 0.75rem;
            border-radius: 4px;
            box-shadow: var(--box-shadow);
            font-size: 0.85rem;
            z-index: 1000;
        }
        
        .device-info-label {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        /* 页脚 */
        .footer {
            background-color: var(--dark-color);
            color: white;
            padding: 2rem 0;
            text-align: center;
            margin-top: 3rem;
        }
        
        /* 响应式设计提示 */
        .responsive-tips {
            background-color: var(--warning-color);
            color: var(--dark-color);
            padding: 1rem;
            border-radius: 4px;
            text-align: center;
            font-weight: 500;
            margin-bottom: 2rem;
        }
        
        /* 响应式断点 */
        @media (max-width: 1200px) {
            .container {
                max-width: 960px;
            }
            
            .header h1 {
                font-size: 2.25rem;
            }
        }
        
        @media (max-width: 992px) {
            .container {
                max-width: 720px;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 1.75rem;
            }
            
            .card-grid,
            .features {
                grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            }
        }
        
        @media (max-width: 768px) {
            .container {
                max-width: 540px;
            }
            
            .header {
                padding: 1.5rem 0;
            }
            
            .header h1 {
                font-size: 1.75rem;
            }
            
            .section {
                padding: 1.5rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .card-grid,
            .features {
                grid-template-columns: 1fr;
            }
            
            .device-info {
                position: static;
                margin-top: 1rem;
                width: 100%;
            }
        }
        
        @media (max-width: 576px) {
            .container {
                padding: 0 10px;
            }
            
            .header h1 {
                font-size: 1.5rem;
            }
            
            .header p {
                font-size: 1rem;
            }
            
            .section {
                padding: 1.25rem;
            }
            
            .section-title {
                font-size: 1.35rem;
            }
            
            .card-body {
                padding: 1.25rem;
            }
            
            .btn {
                width: 100%;
                text-align: center;
            }
        }
        
        /* 打印样式 */
        @media print {
            .language-switcher,
            .device-info {
                display: none;
            }
            
            body {
                font-size: 12pt;
            }
            
            .header,
            .footer {
                background-color: white;
                color: black;
            }
        }
        
        /* 减少动画偏好 */
        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }
        
        /* 高对比度模式 */
        @media (prefers-contrast: high) {
            .card,
            .feature,
            .section {
                border-width: 2px;
            }
        }
    </style>
    
    <!-- 加载移动端工具JS -->
    <?php if (file_exists(dirname(dirname(dirname(__DIR__))) . '/assets/js/mobile-utils.js')): ?>
    <script src="<?php echo '/assets/js/mobile-utils.js'; ?>"></script>
    <?php endif; ?>
</head>
<body>
    <!-- 语言切换器 -->
    <div class="language-switcher">
        <button class="lang-btn" onclick="switchLanguage()">
            <?php echo $currentLang; ?> ▼
        </button>
    </div>
    
    <!-- 设备信息 -->
    <div class="device-info">
        <div><span class="device-info-label">设备类型:</span> <?php echo ucfirst($deviceInfo['deviceType']); ?></div>
        <div><span class="device-info-label">屏幕:</span> <?php echo $deviceInfo['screenWidth']; ?> × <?php echo $deviceInfo['screenHeight']; ?></div>
        <div><span class="device-info-label">移动端:</span> <?php echo $deviceInfo['isMobile'] ? '是' : '否'; ?></div>
    </div>
    
    <!-- 页头 -->
    <header class="header">
        <div class="container">
            <h1><?php echo __('responsive_example_title'); ?></h1>
            <p><?php echo __('welcome_message'); ?></p>
        </div>
    </header>
    
    <div class="container">
        <!-- 响应式提示 -->
        <div class="responsive-tips">
            <?php echo __('try_resize'); ?>
        </div>
        
        <!-- 特性演示 -->
        <section class="section">
            <h2 class="section-title"><?php echo __('feature_demo'); ?></h2>
            
            <div class="features">
                <div class="feature">
                    <div class="feature-icon">📱</div>
                    <h3 class="feature-title"><?php echo __('responsive_design'); ?></h3>
                    <p><?php echo __('responsive_desc'); ?></p>
                </div>
                
                <div class="feature">
                    <div class="feature-icon">🌐</div>
                    <h3 class="feature-title"><?php echo __('internationalization'); ?></h3>
                    <p><?php echo __('i18n_desc'); ?></p>
                </div>
                
                <div class="feature">
                    <div class="feature-icon">🎯</div>
                    <h3 class="feature-title"><?php echo __('mobile_optimization'); ?></h3>
                    <p><?php echo __('mobile_desc'); ?></p>
                </div>
                
                <div class="feature">
                    <div class="feature-icon">🔍</div>
                    <h3 class="feature-title"><?php echo __('device_detection'); ?></h3>
                    <p><?php echo __('device_desc'); ?></p>
                </div>
            </div>
        </section>
        
        <!-- 响应式卡片演示 -->
        <section class="section">
            <h2 class="section-title"><?php echo __('card_demo_title'); ?></h2>
            
            <div class="card-grid">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title"><?php echo __('card_1_title'); ?></h3>
                        <p class="card-text"><?php echo __('card_1_desc'); ?></p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title"><?php echo __('card_2_title'); ?></h3>
                        <p class="card-text"><?php echo __('card_2_desc'); ?></p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title"><?php echo __('card_3_title'); ?></h3>
                        <p class="card-text"><?php echo __('card_3_desc'); ?></p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title"><?php echo __('card_4_title'); ?></h3>
                        <p class="card-text"><?php echo __('card_4_desc'); ?></p>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- 响应式表单演示 -->
        <section class="section">
            <h2 class="section-title"><?php echo __('form_demo_title'); ?></h2>
            
            <form>
                <div class="form-group">
                    <label for="name"><?php echo __('form_name'); ?></label>
                    <input type="text" class="form-control" id="name" placeholder="<?php echo __('form_name'); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email"><?php echo __('form_email'); ?></label>
                    <input type="email" class="form-control" id="email" placeholder="<?php echo __('form_email'); ?>">
                </div>
                
                <div class="form-group">
                    <label for="message"><?php echo __('form_message'); ?></label>
                    <textarea class="form-control" id="message" rows="4" placeholder="<?php echo __('form_message'); ?>"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php echo __('form_submit'); ?></button>
            </form>
        </section>
        
        <!-- 响应式表格演示 -->
        <section class="section">
            <h2 class="section-title"><?php echo __('table_demo_title'); ?></h2>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php echo __('table_id'); ?></th>
                            <th><?php echo __('table_name'); ?></th>
                            <th><?php echo __('table_status'); ?></th>
                            <th><?php echo __('table_actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td><?php echo __('table_data_1'); ?></td>
                            <td><?php echo __('status_active'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary"><?php echo __('action_edit'); ?></button>
                                <button class="btn btn-sm btn-danger"><?php echo __('action_delete'); ?></button>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td><?php echo __('table_data_2'); ?></td>
                            <td><?php echo __('status_active'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary"><?php echo __('action_edit'); ?></button>
                                <button class="btn btn-sm btn-danger"><?php echo __('action_delete'); ?></button>
                            </td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td><?php echo __('table_data_3'); ?></td>
                            <td><?php echo __('status_inactive'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary"><?php echo __('action_edit'); ?></button>
                                <button class="btn btn-sm btn-danger"><?php echo __('action_delete'); ?></button>
                            </td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td><?php echo __('table_data_4'); ?></td>
                            <td><?php echo __('status_active'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary"><?php echo __('action_edit'); ?></button>
                                <button class="btn btn-sm btn-danger"><?php echo __('action_delete'); ?></button>
                            </td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td><?php echo __('table_data_5'); ?></td>
                            <td><?php echo __('status_inactive'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary"><?php echo __('action_edit'); ?></button>
                                <button class="btn btn-sm btn-danger"><?php echo __('action_delete'); ?></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        
        <!-- 响应式设计提示 -->
        <section class="section">
            <h2 class="section-title"><?php echo __('responsive_tips'); ?></h2>
            
            <div class="features">
                <div class="feature">
                    <h3 class="feature-title">移动优先</h3>
                    <p><?php echo __('tip_1_desc'); ?></p>
                </div>
                
                <div class="feature">
                    <h3 class="feature-title">灵活网格</h3>
                    <p><?php echo __('tip_2_desc'); ?></p>
                </div>
                
                <div class="feature">
                    <h3 class="feature-title">媒体查询</h3>
                    <p><?php echo __('tip_3_desc'); ?></p>
                </div>
                
                <div class="feature">
                    <h3 class="feature-title">响应式图片</h3>
                    <p><?php echo __('tip_4_desc'); ?></p>
                </div>
            </div>
        </section>
    </div>
    
    <!-- 页脚 -->
    <footer class="footer">
        <div class="container">
            <p><?php echo __('footer_text'); ?></p>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script>
        // 模拟语言切换
        function switchLanguage() {
            alert('语言切换功能将在实际系统中实现');
            // 实际实现应该调用LanguageSwitcher的方法
        }
        
        // 检测窗口大小变化
        window.addEventListener('resize', function() {
            // 在实际应用中，这里可以重新加载页面或调整布局
            console.log('窗口大小已改变:', window.innerWidth, '×', window.innerHeight);
        });
        
        // 移动端优化
        document.addEventListener('DOMContentLoaded', function() {
            // 禁用双击缩放
            document.addEventListener('dblclick', function(e) {
                e.preventDefault();
            }, { passive: false });
            
            // 优化触摸事件
            const touchableElements = document.querySelectorAll('button, a, .card, .feature');
            touchableElements.forEach(el => {
                el.style.tapHighlightColor = 'transparent';
                el.style.webkitTapHighlightColor = 'transparent';
            });
            
            // 表单自动聚焦优化
            const formInputs = document.querySelectorAll('input, textarea');
            formInputs.forEach(input => {
                input.addEventListener('focus', function() {
                    // 在移动设备上，确保输入框在键盘弹出时可见
                    setTimeout(() => {
                        this.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }, 100);
                });
            });
        });
    </script>
</body>
</html>