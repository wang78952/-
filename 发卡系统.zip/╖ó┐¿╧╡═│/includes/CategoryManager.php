<?php

/**
 * 分类管理器
 */
class CategoryManager extends BaseService
{
    private $cacheManager;
    
    public function __construct($database, $logger = null, $cacheManager = null)
    {
        parent::__construct();
        $this->cacheManager = $cacheManager ?: CacheManager::getInstance();
    }
    
    /**
     * 创建分类
     */
    public function createCategory($categoryData)
    {
        try {
            // 验证必填字段
            $required = array('name');
            foreach ($required as $field) {
                if (empty($categoryData[$field])) {
                    throw new Exception("Missing required field: {$field}");
                }
            }
            
            // 检查分类名称是否重复
            if ($this->isCategoryNameExists($categoryData['name'])) {
                throw new Exception('分类名称已存在');
            }
            
            // 准备数据
            $data = array(
                'name' => $categoryData['name'],
                'description' => isset($categoryData['description']) ? $categoryData['description'] : '',
                'parent_id' => isset($categoryData['parent_id']) ? $categoryData['parent_id'] : 0,
                'icon' => isset($categoryData['icon']) ? $categoryData['icon'] : '',
                'is_active' => isset($categoryData['is_active']) ? $categoryData['is_active'] : 1,
                'sort_order' => isset($categoryData['sort_order']) ? $categoryData['sort_order'] : 0,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            );
            
            // 插入数据
            $categoryId = $this->database->insert('categories', $data);
            
            // 清除缓存
            $this->cacheManager->delete('categories:*');
            
            $this->logInfo('分类创建成功', [
                'category_id' => $categoryId,
                'name' => $categoryData['name']
            ]);
            
            return array(
                'success' => true,
                'id' => $categoryId,
                'message' => '分类创建成功'
            );
            
        } catch (Exception $e) {
            $this->logError('创建分类失败', [
                'category_data' => $categoryData,
                'error' => $e->getMessage()
            ]);
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 更新分类
     */
    public function updateCategory($categoryId, $categoryData)
    {
        try {
            $category = $this->getCategory($categoryId);
            if (!$category) {
                throw new Exception('分类不存在');
            }
            
            // 检查分类名称是否重复（排除自己）
            if (isset($categoryData['name']) && 
                $categoryData['name'] !== $category['name'] && 
                $this->isCategoryNameExists($categoryData['name'], $categoryId)) {
                throw new Exception('分类名称已存在');
            }
            
            // 检查是否设置自己为父分类
            if (isset($categoryData['parent_id']) && 
                $categoryData['parent_id'] == $categoryId) {
                throw new Exception('不能设置自己为父分类');
            }
            
            // 准备更新数据
            $updateData = array();
            
            $allowedFields = array(
                'name', 'description', 'parent_id', 'icon', 'is_active', 'sort_order'
            );
            
            foreach ($allowedFields as $field) {
                if (isset($categoryData[$field])) {
                    $updateData[$field] = $categoryData[$field];
                }
            }
            
            if (empty($updateData)) {
                throw new Exception('没有需要更新的字段');
            }
            
            $updateData['updated_at'] = date('Y-m-d H:i:s');
            
            // 更新数据
            $this->database->update('categories', $updateData, array('id' => $categoryId));
            
            // 清除缓存
            $this->cacheManager->delete('categories:*');
            
            $this->logInfo('分类更新成功', array(
                'category_id' => $categoryId,
                'updated_fields' => array_keys($categoryData)
            ));
            
            return array(
                'success' => true,
                'message' => '分类更新成功'
            );
            
        } catch (Exception $e) {
            $this->logError('更新分类失败', array(
                'category_id' => $categoryId,
                'category_data' => $categoryData,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 删除分类
     */
    public function deleteCategory($categoryId)
    {
        try {
            $category = $this->getCategory($categoryId);
            if (!$category) {
                throw new Exception('分类不存在');
            }
            
            // 检查是否有子分类
            if ($this->hasChildCategories($categoryId)) {
                throw new Exception('该分类下有子分类，无法删除');
            }
            
            // 检查是否有关联的产品
            if ($this->hasAssociatedProducts($categoryId)) {
                throw new Exception('该分类下有产品，无法删除');
            }
            
            // 删除分类
            $this->database->delete('categories', array('id' => $categoryId));
            
            // 清除缓存
            $this->cacheManager->delete('categories:*');
            
            $this->logInfo('分类删除成功', array(
                'category_id' => $categoryId,
                'category_name' => $category['name']
            ));
            
            return array(
                'success' => true,
                'message' => '分类删除成功'
            );
            
        } catch (Exception $e) {
            $this->logError('删除分类失败', array(
                'category_id' => $categoryId,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 获取分类详情
     */
    public function getCategory($categoryId)
    {
        try {
            $cacheKey = "category:{$categoryId}";
            $category = $this->cacheManager->get($cacheKey);
            
            if ($category === null) {
                $sql = "SELECT c.*, p.name as parent_name 
                        FROM categories c 
                        LEFT JOIN categories p ON c.parent_id = p.id 
                        WHERE c.id = ?";
                $category = $this->database->fetch($sql, array($categoryId));
                
                if ($category) {
                    // 获取子分类数量
                    $childCount = $this->database->fetchColumn("SELECT COUNT(*) as child_count FROM categories WHERE parent_id = ?", array($categoryId));
                    $category['child_count'] = $childCount;
                    
                    // 获取产品数量
                    $productCount = $this->database->fetchColumn("SELECT COUNT(*) as product_count FROM products WHERE category_id = ?", array($categoryId));
                    $category['product_count'] = $productCount;
                    
                    // 缓存结果
                    $this->cacheManager->set($cacheKey, $category, 300);
                }
            }
            
            return $category;
            
        } catch (Exception $e) {
            $this->logError('获取分类失败', array(
                'category_id' => $categoryId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取分类列表
     */
    public function getCategoryList($filters = array(), $page = 1, $limit = 50)
    {
        try {
            $offset = ($page - 1) * $limit;
            $whereClause = 'WHERE 1=1';
            $params = array();
            
            // 构建查询条件
            if (!empty($filters['is_active'])) {
                $whereClause .= " AND c.is_active = ?";
                $params[] = $filters['is_active'];
            }
            
            if (!empty($filters['parent_id'])) {
                $whereClause .= " AND c.parent_id = ?";
                $params[] = $filters['parent_id'];
            }
            
            if (!empty($filters['search'])) {
                $whereClause .= " AND (c.name LIKE ? OR c.description LIKE ?)";
                $searchTerm = '%' . $filters['search'] . '%';
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }
            
            // 查询总数
            $countSql = "SELECT COUNT(DISTINCT c.id) FROM categories c {$whereClause}";
            $total = $this->database->fetchColumn($countSql, $params);
            
            // 查询数据
            $sql = "SELECT c.*, p.name as parent_name,
                           COUNT(child.id) as child_count,
                           COUNT(pr.id) as product_count
                    FROM categories c 
                    LEFT JOIN categories p ON c.parent_id = p.id
                    LEFT JOIN categories child ON c.id = child.parent_id
                    LEFT JOIN products pr ON c.id = pr.category_id
                    {$whereClause}
                    GROUP BY c.id
                    ORDER BY c.sort_order ASC, c.created_at ASC
                    LIMIT {$limit} OFFSET {$offset}";
            
            $categories = $this->database->fetchAll($sql, $params);
            
            return array(
                'categories' => $categories,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                )
            );
            
        } catch (Exception $e) {
            $this->logError('获取分类列表失败', array(
                'filters' => $filters,
                'page' => $page,
                'limit' => $limit,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取分类树
     */
    public function getCategoryTree($filters = array())
    {
        try {
            $whereClause = 'WHERE 1=1';
            $params = array();
            
            if (!empty($filters['is_active'])) {
                $whereClause .= " AND is_active = ?";
                $params[] = $filters['is_active'];
            }
            
            $sql = "SELECT * FROM categories {$whereClause} ORDER BY sort_order ASC, created_at ASC";
            $categories = $this->database->fetchAll($sql, $params);
            
            return $this->buildCategoryTree($categories);
            
        } catch (Exception $e) {
            $this->logError('获取分类树失败', array(
                'filters' => $filters,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取分类统计
     */
    public function getCategoryStatistics($filters = array())
    {
        try {
            $whereClause = 'WHERE 1=1';
            $params = array();
            
            if (!empty($filters['start_date'])) {
                $whereClause .= " AND created_at >= ?";
                $params[] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $whereClause .= " AND created_at <= ?";
                $params[] = $filters['end_date'] . ' 23:59:59';
            }
            
            $sql = "SELECT 
                        COUNT(*) as total_categories,
                        COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_categories,
                        COUNT(CASE WHEN parent_id = 0 THEN 1 END) as root_categories,
                        COUNT(CASE WHEN parent_id > 0 THEN 1 END) as child_categories
                    FROM categories {$whereClause}";
            
            $stats = $this->database->fetch($sql, $params);
            
            // 按父分类统计
            $parentSql = "SELECT parent_id, COUNT(*) as count
                         FROM categories 
                         GROUP BY parent_id
                         ORDER BY count DESC";
            $stats['by_parent'] = $this->database->fetchAll($parentSql);
            
            return $stats;
            
        } catch (Exception $e) {
            $this->logError('获取分类统计失败', array(
                'filters' => $filters,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 检查分类名称是否存在
     */
    private function isCategoryNameExists($name, $excludeId = null)
    {
        try {
            $sql = "SELECT COUNT(*) FROM categories WHERE name = ?";
            $params = array($name);
            
            if ($excludeId) {
                $sql .= " AND id != ?";
                $params[] = $excludeId;
            }
            
            return $this->database->fetchColumn($sql, $params) > 0;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 检查是否有子分类
     */
    private function hasChildCategories($categoryId)
    {
        try {
            return $this->database->fetchColumn("SELECT COUNT(*) FROM categories WHERE parent_id = ?", array($categoryId)) > 0;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 检查是否有关联的产品
     */
    private function hasAssociatedProducts($categoryId)
    {
        try {
            return $this->database->fetchColumn("SELECT COUNT(*) FROM products WHERE category_id = ?", array($categoryId)) > 0;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 构建分类树
     */
    private function buildCategoryTree($categories, $parentId = 0)
    {
        $tree = array();
        
        foreach ($categories as $category) {
            if ($category['parent_id'] == $parentId) {
                $children = $this->buildCategoryTree($categories, $category['id']);
                if ($children) {
                    $category['children'] = $children;
                }
                $tree[] = $category;
            }
        }
        
        return $tree;
    }
    
    /**
     * 记录信息日志
     */
    private function logInfo($message, $data = array())
    {
        $this->logger->info($message, array_merge($data, array('component' => 'CategoryManager')));
    }
    
    /**
     * 记录错误日志
     */
    private function logError($message, $data = array())
    {
        $this->logger->error($message, array_merge($data, array('component' => 'CategoryManager')));
    }
}