<?php
/**
 * 防注入攻击工具类
 * 提供全面的注入防护功能，包括SQL注入、XSS、CSRF、命令注入等
 */

/**
 * 注入防护类
 * 集中管理所有输入数据的安全处理和注入防护
 */
class InjectionProtection {
    /**
     * 单例实例
     * @var InjectionProtection
     */
    private static $instance = null;
    
    /**
     * SQL关键字黑名单
     * @var array
     */
    private $sqlKeywords = [
        // SQL DML语句
        'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'MERGE', 'UPSERT',
        // SQL DDL语句
        'CREATE', 'DROP', 'ALTER', 'TRUNCATE', 'RENAME', 'COMMENT',
        // SQL控制流
        'UNION', 'INTERSECT', 'EXCEPT', 'HAVING', 'GROUP BY', 'ORDER BY', 'LIMIT', 'OFFSET',
        // SQL函数和操作符
        'EXEC', 'EXECUTE', 'CALL', 'DECLARE', 'CAST', 'CONVERT', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END',
        'OR', 'AND', 'NOT', 'IN', 'BETWEEN', 'LIKE', 'IS', 'NULL',
        // SQL注释标记
        '--', '/*', '*/', '#',
        // SQL特殊字符
        ';', ':', '=', '<', '>', '!', '+', '-', '*', '/', '%', '\'', '"', '`'
    ];
    
    /**
     * XSS危险标签和属性
     * @var array
     */
    private $xssPatterns = [
        // 危险的HTML标签
        '/<\s*script[^>]*>.*?<\s*\/\s*script\s*>/is',
        '/<\s*iframe[^>]*>.*?<\s*\/\s*iframe\s*>/is',
        '/<\s*embed[^>]*>.*?<\s*\/\s*embed\s*>/is',
        '/<\s*object[^>]*>.*?<\s*\/\s*object\s*>/is',
        '/<\s*form[^>]*>.*?<\s*\/\s*form\s*>/is',
        '/<\s*input[^>]*>/is',
        '/<\s*button[^>]*>.*?<\s*\/\s*button\s*>/is',
        // 危险的事件处理器
        '/\s*on\w+\s*=\s*["\'].*?["\']/is',
        '/\s*on\w+\s*=\s*[^{]*{[^}]*}/is',
        // 危险的JavaScript URL
        '/javascript\s*:\s*/i',
        '/data\s*:\s*/i',
        '/vbscript\s*:\s*/i',
        // 危险的编码
        '/&#x[0-9a-f]{1,8};/i',
        '/&#[0-9]{1,8};/i'
    ];
    
    /**
     * 命令注入危险字符
     * @var array
     */
    private $commandInjectionChars = [
        '|', '&', '&&', '||', ';', '\n', '\r', '`', '$(', '>', '<', '>>', '<<',
        'cat', 'echo', 'ls', 'dir', 'rm', 'del', 'copy', 'move', 'mv', 'cp',
        'chmod', 'chown', 'chgrp', 'cd', 'pwd', 'mkdir', 'rmdir'
    ];
    
    /**
     * 敏感路径模式
     * @var array
     */
    private $pathTraversalPatterns = [
        '/\.\./', '/\.\.\\', '\\\.\.\\', '\/\.\.\/', 
        '\.\.\\\.', '\.\\\.\.', '\\\.\\\.', '\/\.\/\.'
    ];
    
    /**
     * 构造函数
     */
    private function __construct() {
        // 初始化配置
        $this->initialize();
    }
    
    /**
     * 初始化
     */
    private function initialize() {
        // 可以在这里加载配置、黑名单等
    }
    
    /**
     * 获取单例实例
     * @return InjectionProtection
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 清理SQL输入
     * 用于防止SQL注入攻击
     * @param mixed $input 输入数据
     * @param array $options 选项配置
     * @return mixed 清理后的数据
     */
    public function cleanSQL($input, $options = []) {
        $defaultOptions = [
            'strict_mode' => false,
            'allow_quotes' => false,
            'max_length' => null
        ];
        
        $options = array_merge($defaultOptions, $options);
        
        if (is_array($input)) {
            return array_map(function($value) use ($options) {
                return $this->cleanSQL($value, $options);
            }, $input);
        }
        
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除控制字符
        $input = preg_replace('/[\x00-\x1F\x7F]/', '', $input);
        
        // 限制长度
        if ($options['max_length'] !== null) {
            $input = substr($input, 0, $options['max_length']);
        }
        
        // 严格模式下的SQL注入防护
        if ($options['strict_mode']) {
            // 转义SQL特殊字符
            $input = addslashes($input);
            
            // 移除或替换SQL关键字
            $input = $this->removeSQLKeywords($input);
        }
        
        // 移除SQL注释
        $input = preg_replace('/(--.*?\r?\n|\/\*.*?\*\/)/s', '', $input);
        
        // 引号处理
        if (!$options['allow_quotes']) {
            $input = str_replace(['\'', '"', '`'], ['\'', '"', '\`'], $input);
        }
        
        return $input;
    }
    
    /**
     * 清理HTML输入
     * 用于防止XSS攻击
     * @param mixed $input 输入数据
     * @param array $options 选项配置
     * @return mixed 清理后的数据
     */
    public function cleanHTML($input, $options = []) {
        $defaultOptions = [
            'strip_tags' => true,
            'allow_basic_tags' => true,
            'html_entities' => true
        ];
        
        $options = array_merge($defaultOptions, $options);
        
        if (is_array($input)) {
            return array_map(function($value) use ($options) {
                return $this->cleanHTML($value, $options);
            }, $input);
        }
        
        if (!is_string($input)) {
            return $input;
        }
        
        // 应用XSS过滤模式
        foreach ($this->xssPatterns as $pattern) {
            $input = preg_replace($pattern, '', $input);
        }
        
        // 移除危险的JavaScript事件
        $input = preg_replace('/\s*on[a-zA-Z]+\s*=\s*["\'].*?["\']/is', '', $input);
        
        // 移除危险的URL协议
        $input = preg_replace('/(src|href)\s*=\s*["\']\s*(javascript|data|vbscript):/i', '', $input);
        
        // 基本标签过滤
        if ($options['strip_tags']) {
            if ($options['allow_basic_tags']) {
                $allowedTags = '<p><br><strong><em><u><b><i><ul><ol><li><blockquote><a><img><h1><h2><h3><h4><h5><h6><table><tr><td><th>';
                $input = strip_tags($input, $allowedTags);
            } else {
                $input = strip_tags($input);
            }
        }
        
        // HTML实体编码
        if ($options['html_entities']) {
            $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        
        return $input;
    }
    
    /**
     * 清理命令行输入
     * 用于防止命令注入攻击
     * @param mixed $input 输入数据
     * @param array $options 选项配置
     * @return mixed 清理后的数据
     */
    public function cleanCommand($input, $options = []) {
        $defaultOptions = [
            'allow_safe_chars' => true
        ];
        
        $options = array_merge($defaultOptions, $options);
        
        if (is_array($input)) {
            return array_map(function($value) use ($options) {
                return $this->cleanCommand($value, $options);
            }, $input);
        }
        
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除或替换危险字符
        $input = str_replace($this->commandInjectionChars, '', $input);
        
        // 清理特殊字符
        $input = preg_replace('/[;&|`$<>\\\n\r]/', '', $input);
        
        return $input;
    }
    
    /**
     * 清理文件路径输入
     * 用于防止路径遍历攻击
     * @param mixed $input 输入数据
     * @param array $options 选项配置
     * @return mixed 清理后的数据
     */
    public function cleanPath($input, $options = []) {
        $defaultOptions = [
            'base_dir' => null,
            'allowed_extensions' => [],
            'normalize_path' => true
        ];
        
        $options = array_merge($defaultOptions, $options);
        
        if (is_array($input)) {
            return array_map(function($value) use ($options) {
                return $this->cleanPath($value, $options);
            }, $input);
        }
        
        if (!is_string($input)) {
            return $input;
        }
        
        // 移除路径遍历模式
        foreach ($this->pathTraversalPatterns as $pattern) {
            $input = preg_replace($pattern, '', $input);
        }
        
        // 移除危险的路径字符
        $input = preg_replace('/[<>"\'|\\]/', '', $input);
        
        // 验证文件扩展名
        if (!empty($options['allowed_extensions'])) {
            $ext = strtolower(pathinfo($input, PATHINFO_EXTENSION));
            if (!in_array($ext, $options['allowed_extensions'])) {
                // 扩展名不允许时可以选择返回空或默认值
                return '';
            }
        }
        
        // 规范化路径
        if ($options['normalize_path']) {
            $input = realpath($input);
            
            // 如果指定了基础目录，验证路径是否在允许的目录内
            if ($options['base_dir'] !== null && $input !== false) {
                $baseDir = realpath($options['base_dir']);
                if ($baseDir !== false && strpos($input, $baseDir) !== 0) {
                    // 路径不在允许的目录内
                    return '';
                }
            }
        }
        
        return $input === false ? '' : $input;
    }
    
    /**
     * 清理所有类型的输入
     * 综合应用各种清理规则
     * @param mixed $input 输入数据
     * @param array $options 选项配置
     * @return mixed 清理后的数据
     */
    public function cleanAll($input, $options = []) {
        $sqlOptions = isset($options['sql']) ? $options['sql'] : [];
        $htmlOptions = isset($options['html']) ? $options['html'] : [];
        $commandOptions = isset($options['command']) ? $options['command'] : [];
        $pathOptions = isset($options['path']) ? $options['path'] : [];
        
        // 递归处理数组
        if (is_array($input)) {
            return array_map(function($value) use ($sqlOptions, $htmlOptions, $commandOptions, $pathOptions) {
                return $this->cleanAll($value, [
                    'sql' => $sqlOptions,
                    'html' => $htmlOptions,
                    'command' => $commandOptions,
                    'path' => $pathOptions
                ]);
            }, $input);
        }
        
        if (!is_string($input)) {
            return $input;
        }
        
        // 应用所有清理规则
        $input = $this->cleanSQL($input, $sqlOptions);
        $input = $this->cleanHTML($input, $htmlOptions);
        $input = $this->cleanCommand($input, $commandOptions);
        $input = $this->cleanPath($input, $pathOptions);
        
        return $input;
    }
    
    /**
     * 移除SQL关键字
     * @param string $input 输入字符串
     * @return string 处理后的字符串
     */
    private function removeSQLKeywords($input) {
        $processedInput = $input;
        foreach ($this->sqlKeywords as $keyword) {
            $processedInput = preg_replace('/\b' . preg_quote($keyword, '/') . '\b/i', '', $processedInput);
        }
        return $processedInput;
    }
    
    /**
     * 验证输入是否包含SQL注入尝试
     * @param mixed $input 输入数据
     * @return bool 是否包含SQL注入尝试
     */
    public function hasSQLInjection($input) {
        if (is_array($input)) {
            foreach ($input as $value) {
                if ($this->hasSQLInjection($value)) {
                    return true;
                }
            }
            return false;
        }
        
        if (!is_string($input)) {
            return false;
        }
        
        $inputUpper = strtoupper($input);
        
        // 检查SQL关键字组合
        $dangerousPatterns = [
            '/\bSELECT\b.*\bFROM\b/i',
            '/\bINSERT\b.*\bINTO\b/i',
            '/\bUPDATE\b.*\bSET\b/i',
            '/\bDELETE\b.*\bFROM\b/i',
            '/\bDROP\b.*\bTABLE\b/i',
            '/\bUNION\b.*\bSELECT\b/i',
            '/\bEXEC\b/i',
            '/\bEXECUTE\b/i',
            '/\bDECLARE\b/i',
            '/\bCAST\b/i',
            '/\bCONVERT\b/i',
            '/\bMERGE\b/i'
        ];
        
        foreach ($dangerousPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        
        // 检查SQL特殊字符组合
        $specialCharsPatterns = [
            '/\'\s*OR\s*\'/i',
            '/\'\s*AND\s*\'/i',
            '/\'\s*;\s*/i',
            '/\'\s*--/i',
            '/\'\s*\(/i',
            '/\)\s*\'/i'
        ];
        
        foreach ($specialCharsPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 验证输入是否包含XSS攻击尝试
     * @param mixed $input 输入数据
     * @return bool 是否包含XSS攻击尝试
     */
    public function hasXSSAttempt($input) {
        if (is_array($input)) {
            foreach ($input as $value) {
                if ($this->hasXSSAttempt($value)) {
                    return true;
                }
            }
            return false;
        }
        
        if (!is_string($input)) {
            return false;
        }
        
        // 检查危险的XSS模式
        foreach ($this->xssPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        
        // 检查危险的JavaScript URL
        if (preg_match('/javascript\s*:\s*/i', $input) || 
            preg_match('/data\s*:\s*/i', $input) || 
            preg_match('/vbscript\s*:\s*/i', $input)) {
            return true;
        }
        
        // 检查危险的事件处理器
        if (preg_match('/\s*on\w+\s*=\s*["\']/i', $input)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 验证输入是否包含命令注入尝试
     * @param mixed $input 输入数据
     * @return bool 是否包含命令注入尝试
     */
    public function hasCommandInjection($input) {
        if (is_array($input)) {
            foreach ($input as $value) {
                if ($this->hasCommandInjection($value)) {
                    return true;
                }
            }
            return false;
        }
        
        if (!is_string($input)) {
            return false;
        }
        
        // 检查危险的命令字符和命令
        foreach ($this->commandInjectionChars as $char) {
            if (stripos($input, $char) !== false) {
                return true;
            }
        }
        
        // 检查命令分隔符
        $commandSeparators = [';', '|', '||', '&&'];
        foreach ($commandSeparators as $separator) {
            if (strpos($input, $separator) !== false) {
                // 检查分隔符前后是否有命令特征
                $parts = explode($separator, $input);
                foreach ($parts as $part) {
                    $trimmedPart = trim($part);
                    if (in_array($trimmedPart, $this->commandInjectionChars)) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * 验证输入是否包含路径遍历尝试
     * @param mixed $input 输入数据
     * @return bool 是否包含路径遍历尝试
     */
    public function hasPathTraversal($input) {
        if (is_array($input)) {
            foreach ($input as $value) {
                if ($this->hasPathTraversal($value)) {
                    return true;
                }
            }
            return false;
        }
        
        if (!is_string($input)) {
            return false;
        }
        
        // 检查路径遍历模式
        foreach ($this->pathTraversalPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        
        // 检查绝对路径特征
        if (preg_match('/^\/|^[a-zA-Z]:\/|^[a-zA-Z]:\\/i', $input)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 检测是否存在任何注入攻击尝试
     * @param mixed $input 输入数据
     * @return array 检测结果数组
     */
    public function detectAllInjections($input) {
        return [
            'sql_injection' => $this->hasSQLInjection($input),
            'xss_attempt' => $this->hasXSSAttempt($input),
            'command_injection' => $this->hasCommandInjection($input),
            'path_traversal' => $this->hasPathTraversal($input)
        ];
    }
    
    /**
     * 安全地构建SQL查询参数
     * 用于预处理语句和参数化查询
     * @param string $query SQL查询模板
     * @param array $params 参数数组
     * @return array [预处理查询, 参数绑定数组]
     */
    public function buildSafeQuery($query, array $params) {
        $placeholders = [];
        $bindParams = [];
        
        foreach ($params as $key => $value) {
            $paramKey = ':' . (is_string($key) ? $key : 'param' . $key);
            $placeholders[$key] = $paramKey;
            $bindParams[$paramKey] = $this->cleanSQL($value, ['strict_mode' => false]);
        }
        
        // 替换查询中的占位符
        $preparedQuery = $query;
        foreach ($placeholders as $original => $placeholder) {
            $preparedQuery = str_replace('{' . $original . '}', $placeholder, $preparedQuery);
        }
        
        return [$preparedQuery, $bindParams];
    }
    
    /**
     * 清理URL参数
     * @param string $url URL字符串
     * @return string 清理后的URL
     */
    public function cleanURL($url) {
        if (!is_string($url)) {
            return $url;
        }
        
        // 移除可能的XSS攻击代码
        $url = preg_replace('/javascript\s*:/i', '', $url);
        $url = preg_replace('/data\s*:/i', '', $url);
        $url = preg_replace('/vbscript\s*:/i', '', $url);
        
        // 清理URL中的危险字符
        $url = preg_replace('/[<>"\'\(\)]/', '', $url);
        
        // 验证URL格式
        if (filter_var($url, FILTER_VALIDATE_URL) === false) {
            // URL格式无效，可以选择返回空字符串或原始URL
            return '';
        }
        
        return $url;
    }
    
    /**
     * 清理JSON输入
     * @param string $json JSON字符串
     * @return string 清理后的JSON
     */
    public function cleanJSON($json) {
        if (!is_string($json)) {
            return $json;
        }
        
        // 移除可能的危险字符
        $json = preg_replace('/[\x00-\x1F\x7F]/', '', $json);
        
        // 验证JSON格式
        json_decode($json);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // JSON格式无效
            return '{}';
        }
        
        return $json;
    }
    
    /**
     * 获取单例实例的静态方法别名
     * @return InjectionProtection
     */
    public static function get() {
        return self::getInstance();
    }
}

/**
 * 全局辅助函数
 */

/**
 * 安全清理函数
 * @param mixed $input 输入数据
 * @param string $type 清理类型：'sql', 'html', 'command', 'path', 'all'
 * @param array $options 选项配置
 * @return mixed 清理后的数据
 */
function safe_clean($input, $type = 'all', array $options = []) {
    $protector = InjectionProtection::getInstance();
    
    switch (strtolower($type)) {
        case 'sql':
            return $protector->cleanSQL($input, $options);
        case 'html':
            return $protector->cleanHTML($input, $options);
        case 'command':
            return $protector->cleanCommand($input, $options);
        case 'path':
            return $protector->cleanPath($input, $options);
        case 'all':
        default:
            return $protector->cleanAll($input, $options);
    }
}

/**
 * 安全检测函数
 * @param mixed $input 输入数据
 * @param string $type 检测类型：'sql', 'xss', 'command', 'path', 'all'
 * @return bool|array 检测结果
 */
function safe_detect($input, $type = 'all') {
    $protector = InjectionProtection::getInstance();
    
    switch (strtolower($type)) {
        case 'sql':
            return $protector->hasSQLInjection($input);
        case 'xss':
            return $protector->hasXSSAttempt($input);
        case 'command':
            return $protector->hasCommandInjection($input);
        case 'path':
            return $protector->hasPathTraversal($input);
        case 'all':
        default:
            return $protector->detectAllInjections($input);
    }
}

/**
 * 安全构建SQL查询
 * @param string $query SQL查询模板
 * @param array $params 参数数组
 * @return array [预处理查询, 参数绑定数组]
 */
function safe_build_query($query, array $params) {
    $protector = InjectionProtection::getInstance();
    return $protector->buildSafeQuery($query, $params);
}