<?php
/**
 * 卡密管理精细化系统
 * 功能：批量卡密导入、智能分组、有效期管理、收藏夹、心愿单等
 * @author System Developer
 * @version 1.0.0
 */

// 导入必要的类
require_once __DIR__ . '/../NotificationManager.php';
require_once __DIR__ . '/../Logger.php';
// 尝试导入Redis类，但不强制要求
try {
    if (class_exists('Redis')) {
        // Redis类已存在于系统中，无需额外导入
    }
} catch (Exception $e) {
    // Redis不可用，将在运行时处理
}

// 注意：Redis功能是可选的，如果系统不支持Redis扩展，将在运行时优雅降级

class CardManagementSystem {
    
    /**
     * 数据库连接实例
     * @var mysqli
     */
    protected $db;
    
    /**
     * Redis连接实例
     * @var Redis
     */
    protected $redis;
    
    /**
     * 日志记录器
     * @var Logger
     */
    protected $logger;
    
    /**
     * 通知服务
     * @var NotificationManager
     */
    protected $notificationService;
    
    /**
     * 发送通知
     * @param mixed $recipient 接收者（邮箱、手机号或用户ID）
     * @param string $subject 通知主题
     * @param string $content 通知内容
     * @param array $options 可选参数
     * @return bool 发送结果
     */
    public function sendNotification($recipient, $subject, $content, $options = [])
    {
        try {
            if ($this->notificationService) {
                return $this->notificationService->send($recipient, $subject, $content, $options);
            } else {
                $this->logger->warning('通知服务未初始化，无法发送通知');
                return false;
            }
        } catch (Exception $e) {
            $this->logger->error('发送通知失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 发送通知方法
     * @param int $recipientId 接收者ID
     * @param string $recipientType 接收者类型
     * @param string $notificationType 通知类型
     * @param array $data 通知数据
     * @return bool 是否发送成功
     */
    public function sendNotification($recipientId, $recipientType, $notificationType, $data = []) {
        try {
            if (isset($this->notificationService) && method_exists($this->notificationService, 'send')) {
                return $this->notificationService->send($recipientId, $notificationType, $data, ['type' => $recipientType]);
            }
            return false;
        } catch (Exception $e) {
            if (isset($this->logger)) {
                $this->logger->error('发送通知失败: ' . $e->getMessage());
            }
            return false;
        }
    }
    
    // 注意：createFallbackNotificationService方法已在后面定义为private方法，这里不再重复声明
    
    /**
     * 构造函数
     */
    public function __construct($db, $logger = null, $notificationService = null) {
        $this->db = $db;
        $this->logger = $logger ?? new Logger();
        // 使用后备通知服务，确保所有需要的方法都可用
        $this->notificationService = $notificationService ?? $this->createFallbackNotificationService();
        
        // 尝试初始化Redis连接
        try {
            if (class_exists('Redis')) {
                $this->redis = new Redis();
                // 可以在这里添加Redis连接代码
            }
        } catch (Exception $e) {
            $this->redis = null;
            $this->logger->warning("Redis初始化失败，将使用数据库模式：" . $e->getMessage());
        }
    }
    
    /**
     * 更新分组卡密数量
     * @param int $groupId 分组ID
     * @return bool 是否成功
     */
    protected function updateGroupCardCount($groupId) {
        try {
            // 计算分组中的卡密数量
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM card_category_mapping WHERE group_id = ?");
            $stmt->bind_param("i", $groupId);
            $stmt->execute();
            $stmt->bind_result($count);
            $stmt->fetch();
            $stmt->close();
            
            // 更新分组表中的卡密数量
            $stmt = $this->db->prepare("UPDATE card_groups SET card_count = ? WHERE id = ?");
            $stmt->bind_param("ii", $count, $groupId);
            $result = $stmt->execute();
            $stmt->close();
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("更新分组卡密数量失败，分组ID：{$groupId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 创建后备日志记录器
     * 当Logger类不可用或有问题时使用
     */
    private function createFallbackLogger() {
        $fallbackLogger = new stdClass();
        
        // 实现基础日志方法
        $fallbackLogger->info = function($message, $context = []) {
            error_log('INFO: ' . $message . ' ' . json_encode($context));
        };
        
        $fallbackLogger->error = function($message, $context = []) {
            error_log('ERROR: ' . $message . ' ' . json_encode($context));
        };
        
        $fallbackLogger->warning = function($message, $context = []) {
            error_log('WARNING: ' . $message . ' ' . json_encode($context));
        };
        
        return $fallbackLogger;
    }
    
    /**
     * 创建后备通知服务
     * 当NotificationManager不可用时使用
     */
    private function createFallbackNotificationService() {
        $fallbackService = new stdClass();
        
        // 与includes/NotificationManager.php中的方法签名匹配
        $fallbackService->sendEmail = function($to, $subject, $content, $config = []) {
            return ['success' => false, 'message' => '通知服务不可用'];
        };
        
        // 实现sendMerchantNotification方法，这是CardManagementSystem中调用的方法
        $fallbackService->sendMerchantNotification = function($merchantId, $type, $data = []) {
            return ['success' => false, 'message' => '通知服务不可用'];
        };
        
        // 添加sendUserNotification方法，这是CardManagementSystem中调用的方法
        $fallbackService->sendUserNotification = function($userId, $type, $data = []) {
            return ['success' => false, 'message' => '通知服务不可用'];
        };
        
        // 添加sendNotification方法，这是CardManagementSystem中调用的方法
        $fallbackService->sendNotification = function($recipientId, $recipientType, $type, $data = []) {
            return ['success' => false, 'message' => '通知服务不可用'];
        };
        
        // 实现必要的方法，确保CardManagementSystem可以正常运行
        $fallbackService->logInfo = function($message, $data = []) {
            // 静默忽略日志记录
        };
        
        $fallbackService->logError = function($message, $data = []) {
            // 静默忽略错误日志
        };
        
        // 添加sendNotification方法以解决未定义方法错误
        $fallbackService->sendNotification = function($recipientId, $recipientType, $notificationType, $data = []) {
            // 静默忽略通知发送
            return true;
        };
        
        return $fallbackService;
    }
    
    /**
     * 创建卡密分组
     * @param array $groupData 分组数据
     * @return int|bool 创建的分组ID或失败返回false
     */
    public function createCardGroup($groupData) {
        try {
            $stmt = $this->db->prepare("INSERT INTO card_groups (name, description, merchant_id, user_id, group_type, color, sort_order, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $name = $groupData['name'] ?? '';
            $description = $groupData['description'] ?? '';
            $merchantId = $groupData['merchant_id'] ?? null;
            $userId = $groupData['user_id'] ?? null;
            $groupType = $groupData['group_type'] ?? 'merchant';
            $color = $groupData['color'] ?? '#007bff';
            $sortOrder = $groupData['sort_order'] ?? 0;
            $status = $groupData['status'] ?? 1;
            
            $stmt->bind_param("ssisssii", $name, $description, $merchantId, $userId, $groupType, $color, $sortOrder, $status);
            $stmt->execute();
            $groupId = $stmt->insert_id;
            $stmt->close();
            
            $this->logger->info("创建卡密分组成功，分组ID：{$groupId}，分组名称：{$name}");
            return $groupId;
        } catch (Exception $e) {
            $this->logger->error("创建卡密分组失败：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 更新卡密分组
     * @param int $groupId 分组ID
     * @param array $groupData 分组数据
     * @return bool 是否成功
     */
    public function updateCardGroup($groupId, $groupData) {
        try {
            $fields = [];
            $params = [];
            $types = '';
            
            if (isset($groupData['name'])) {
                $fields[] = 'name = ?';
                $params[] = $groupData['name'];
                $types .= 's';
            }
            
            if (isset($groupData['description'])) {
                $fields[] = 'description = ?';
                $params[] = $groupData['description'];
                $types .= 's';
            }
            
            if (isset($groupData['color'])) {
                $fields[] = 'color = ?';
                $params[] = $groupData['color'];
                $types .= 's';
            }
            
            if (isset($groupData['sort_order'])) {
                $fields[] = 'sort_order = ?';
                $params[] = $groupData['sort_order'];
                $types .= 'i';
            }
            
            if (isset($groupData['status'])) {
                $fields[] = 'status = ?';
                $params[] = $groupData['status'];
                $types .= 'i';
            }
            
            if (empty($fields)) {
                return true;
            }
            
            $params[] = $groupId;
            $types .= 'i';
            
            $sql = "UPDATE card_groups SET " . implode(', ', $fields) . " WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $result = $stmt->execute();
            $stmt->close();
            
            $this->logger->info("更新卡密分组成功，分组ID：{$groupId}");
            return $result;
        } catch (Exception $e) {
            $this->logger->error("更新卡密分组失败，分组ID：{$groupId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 删除卡密分组
     * @param int $groupId 分组ID
     * @return bool 是否成功
     */
    public function deleteCardGroup($groupId) {
        try {
            // 开始事务
            $this->db->begin_transaction();
            
            // 删除分组映射
            $stmt = $this->db->prepare("DELETE FROM card_category_mapping WHERE group_id = ?");
            $stmt->bind_param("i", $groupId);
            $stmt->execute();
            $stmt->close();
            
            // 删除分组
            $stmt = $this->db->prepare("DELETE FROM card_groups WHERE id = ?");
            $stmt->bind_param("i", $groupId);
            $result = $stmt->execute();
            $stmt->close();
            
            // 提交事务
            $this->db->commit();
            
            $this->logger->info("删除卡密分组成功，分组ID：{$groupId}");
            return $result;
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error("删除卡密分组失败，分组ID：{$groupId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取卡密分组列表
     * @param array $params 查询参数
     * @return array 分组列表
     */
    public function getCardGroups($params = []) {
        try {
            $where = [];
            $queryParams = [];
            $types = '';
            
            if (isset($params['merchant_id'])) {
                $where[] = 'merchant_id = ?';
                $queryParams[] = $params['merchant_id'];
                $types .= 'i';
            }
            
            if (isset($params['user_id'])) {
                $where[] = 'user_id = ?';
                $queryParams[] = $params['user_id'];
                $types .= 'i';
            }
            
            if (isset($params['group_type'])) {
                $where[] = 'group_type = ?';
                $queryParams[] = $params['group_type'];
                $types .= 's';
            }
            
            if (isset($params['status'])) {
                $where[] = 'status = ?';
                $queryParams[] = $params['status'];
                $types .= 'i';
            }
            
            $sql = "SELECT * FROM card_groups";
            if (!empty($where)) {
                $sql .= " WHERE " . implode(' AND ', $where);
            }
            
            $sql .= " ORDER BY sort_order ASC, created_at DESC";
            
            $stmt = $this->db->prepare($sql);
            if (!empty($queryParams)) {
                $stmt->bind_param($types, ...$queryParams);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $groups = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            return $groups;
        } catch (Exception $e) {
            $this->logger->error("获取卡密分组列表失败：" . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 将卡密添加到分组
     * @param int $cardId 卡密ID
     * @param int $groupId 分组ID
     * @param string $mappingType 映射类型
     * @return bool 是否成功
     */
    public function addCardToGroup($cardId, $groupId, $mappingType = 'primary') {
        try {
            // 检查卡密和分组是否存在
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards WHERE id = ?");
            $stmt->bind_param("i", $cardId);
            $stmt->execute();
            $stmt->bind_result($cardCount);
            $stmt->fetch();
            $stmt->close();
            
            if ($cardCount === 0) {
                throw new Exception("卡密不存在");
            }
            
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM card_groups WHERE id = ? AND status = 1");
            $stmt->bind_param("i", $groupId);
            $stmt->execute();
            $stmt->bind_result($groupCount);
            $stmt->fetch();
            $stmt->close();
            
            if ($groupCount === 0) {
                throw new Exception("分组不存在或已禁用");
            }
            
            // 添加映射
            $stmt = $this->db->prepare("INSERT IGNORE INTO card_category_mapping (card_id, group_id, mapping_type) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $cardId, $groupId, $mappingType);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新分组卡密数量
                $this->updateGroupCardCount($groupId);
                $this->logger->info("将卡密添加到分组成功，卡密ID：{$cardId}，分组ID：{$groupId}，映射类型：{$mappingType}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("将卡密添加到分组失败，卡密ID：{$cardId}，分组ID：{$groupId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 从分组中移除卡密
     * @param int $cardId 卡密ID
     * @param int $groupId 分组ID
     * @return bool 是否成功
     */
    public function removeCardFromGroup($cardId, $groupId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM card_category_mapping WHERE card_id = ? AND group_id = ?");
            $stmt->bind_param("ii", $cardId, $groupId);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新分组卡密数量
                $this->updateGroupCardCount($groupId);
                $this->logger->info("从分组中移除卡密成功，卡密ID：{$cardId}，分组ID：{$groupId}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("从分组中移除卡密失败，卡密ID：{$cardId}，分组ID：{$groupId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    // 注意：updateGroupCardCount函数在第74行已定义，这里不再重复定义
    
    /**
     * 批量导入卡密
     * @param int $merchantId 商户ID
     * @param int $productId 商品ID
     * @param int $groupId 分组ID（可选）
     * @param array $cardData 卡密数据数组
     * @return array 导入结果
     */
    public function bulkImportCards($merchantId, $productId, $groupId = null, $cardData = []) {
        try {
            $result = [
                'success_count' => 0,
                'failed_count' => 0,
                'error_details' => [],
                'total_count' => count($cardData),
                'status' => 'success'
            ];
            
            if (empty($cardData)) {
                throw new Exception("卡密数据为空");
            }
            
            // 创建导入记录
            $importId = $this->createImportRecord($merchantId, $productId, $groupId, $cardData);
            
            // 使用事务批量插入
            $this->db->begin_transaction();
            
            $success = true;
            foreach ($cardData as $index => $card) {
                try {
                    $cardNo = $card['card_no'] ?? '';
                    $password = $card['password'] ?? '';
                    $expireDays = $card['expire_days'] ?? 0;
                    
                    // 验证卡密格式
                    if (empty($cardNo)) {
                        throw new Exception("卡密编号不能为空");
                    }
                    
                    // 检查卡密是否已存在
                    $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards WHERE card_no = ?");
                    $stmt->bind_param("s", $cardNo);
                    $stmt->execute();
                    $stmt->bind_result($count);
                    $stmt->fetch();
                    $stmt->close();
                    
                    if ($count > 0) {
                        throw new Exception("卡密已存在");
                    }
                    
                    // 计算过期日期
                    $expireDate = null;
                    if ($expireDays > 0) {
                        $expireDate = date('Y-m-d H:i:s', strtotime("+{$expireDays} days"));
                    }
                    
                    // 插入卡密
                    $stmt = $this->db->prepare("INSERT INTO cards (card_no, password, product_id, merchant_id, status, created_at, expire_date) VALUES (?, ?, ?, ?, ?, NOW(), ?)");
                    $status = 1; // 默认状态为有效
                    $stmt->bind_param("ssiii", $cardNo, $password, $productId, $merchantId, $status, $expireDate);
                    $stmt->execute();
                    $newCardId = $stmt->insert_id;
                    $stmt->close();
                    
                    // 添加到分组
                    if ($groupId) {
                        $this->addCardToGroup($newCardId, $groupId, 'primary');
                    }
                    
                    $result['success_count']++;
                } catch (Exception $e) {
                    $result['failed_count']++;
                    $result['error_details'][] = [
                        'index' => $index,
                        'card_no' => $card['card_no'] ?? '',
                        'error' => $e->getMessage()
                    ];
                }
            }
            
            // 提交或回滚事务
            if ($success && $result['failed_count'] === 0) {
                $this->db->commit();
            } else {
                $this->db->rollback();
                $result['status'] = 'partial_success';
            }
            
            // 更新导入记录
            $this->updateImportRecord($importId, $result);
            
            $this->logger->info("批量导入卡密完成，成功：{$result['success_count']}，失败：{$result['failed_count']}，商户ID：{$merchantId}");
            return $result;
        } catch (Exception $e) {
            $this->logger->error("批量导入卡密失败，商户ID：{$merchantId}，错误：" . $e->getMessage());
            return [
                'success_count' => 0,
                'failed_count' => 0,
                'error_details' => [['error' => $e->getMessage()]],
                'total_count' => count($cardData),
                'status' => 'error'
            ];
        }
    }
    
    /**
     * 创建导入记录
     * @param int $merchantId 商户ID
     * @param int $productId 商品ID
     * @param int $groupId 分组ID
     * @param array $cardData 卡密数据
     * @return int 导入记录ID
     */
    protected function createImportRecord($merchantId, $productId, $groupId, $cardData) {
        $stmt = $this->db->prepare("INSERT INTO card_bulk_imports (merchant_id, product_id, group_id, total_rows, status, created_at, import_settings) VALUES (?, ?, ?, ?, ?, NOW(), ?)");
        $status = 'pending';
        $importSettings = json_encode(['card_count' => count($cardData)]);
        $stmt->bind_param("iiiss", $merchantId, $productId, $groupId, count($cardData), $status, $importSettings);
        $stmt->execute();
        $importId = $stmt->insert_id;
        $stmt->close();
        return $importId;
    }
    
    /**
     * 更新导入记录
     * @param int $importId 导入记录ID
     * @param array $result 导入结果
     */
    protected function updateImportRecord($importId, $result) {
        $stmt = $this->db->prepare("UPDATE card_bulk_imports SET status = ?, success_rows = ?, failed_rows = ?, completed_at = NOW(), error_message = ? WHERE id = ?");
        $status = $result['status'] === 'success' ? 'completed' : 'completed';
        $errorMsg = $result['failed_count'] > 0 ? "导入完成，但有{$result['failed_count']}条失败" : null;
        $stmt->bind_param("siisi", $status, $result['success_count'], $result['failed_count'], $errorMsg, $importId);
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * 创建卡密收藏夹
     * @param int $userId 用户ID
     * @param array $collectionData 收藏夹数据
     * @return int|bool 收藏夹ID或失败返回false
     */
    public function createCollection($userId, $collectionData) {
        try {
            $stmt = $this->db->prepare("INSERT INTO card_collections (user_id, name, description, is_private, sort_order) VALUES (?, ?, ?, ?, ?)");
            $name = $collectionData['name'] ?? '新收藏夹';
            $description = $collectionData['description'] ?? '';
            $isPrivate = $collectionData['is_private'] ?? 1;
            $sortOrder = $collectionData['sort_order'] ?? 0;
            
            $stmt->bind_param("issii", $userId, $name, $description, $isPrivate, $sortOrder);
            $stmt->execute();
            $collectionId = $stmt->insert_id;
            $stmt->close();
            
            $this->logger->info("创建收藏夹成功，收藏夹ID：{$collectionId}，用户ID：{$userId}");
            return $collectionId;
        } catch (Exception $e) {
            $this->logger->error("创建收藏夹失败，用户ID：{$userId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 将卡密添加到收藏夹
     * @param int $collectionId 收藏夹ID
     * @param int $cardId 卡密ID
     * @return bool 是否成功
     */
    public function addCardToCollection($collectionId, $cardId) {
        try {
            // 检查收藏夹是否存在
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM card_collections WHERE id = ?");
            $stmt->bind_param("i", $collectionId);
            $stmt->execute();
            $stmt->bind_result($count);
            $stmt->fetch();
            $stmt->close();
            
            if ($count === 0) {
                throw new Exception("收藏夹不存在");
            }
            
            // 添加到收藏夹
            $stmt = $this->db->prepare("INSERT IGNORE INTO card_collection_items (collection_id, card_id, added_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $collectionId, $cardId);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新收藏夹卡密数量
                $updateStmt = $this->db->prepare("UPDATE card_collections SET card_count = (SELECT COUNT(*) FROM card_collection_items WHERE collection_id = ?) WHERE id = ?");
                $updateStmt->bind_param("ii", $collectionId, $collectionId);
                $updateStmt->execute();
                $updateStmt->close();
                $this->logger->info("将卡密添加到收藏夹成功，收藏夹ID：{$collectionId}，卡密ID：{$cardId}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("将卡密添加到收藏夹失败，收藏夹ID：{$collectionId}，卡密ID：{$cardId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 从收藏夹移除卡密
     * @param int $collectionId 收藏夹ID
     * @param int $cardId 卡密ID
     * @return bool 是否成功
     */
    public function removeCardFromCollection($collectionId, $cardId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM card_collection_items WHERE collection_id = ? AND card_id = ?");
            $stmt->bind_param("ii", $collectionId, $cardId);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新收藏夹卡密数量
                $updateStmt = $this->db->prepare("UPDATE card_collections SET card_count = (SELECT COUNT(*) FROM card_collection_items WHERE collection_id = ?) WHERE id = ?");
                $updateStmt->bind_param("ii", $collectionId, $collectionId);
                $updateStmt->execute();
                $updateStmt->close();
                $this->logger->info("从收藏夹移除卡密成功，收藏夹ID：{$collectionId}，卡密ID：{$cardId}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("从收藏夹移除卡密失败，收藏夹ID：{$collectionId}，卡密ID：{$cardId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取用户心愿单
     * @param int $userId 用户ID
     * @return array 心愿单信息
     */
    public function getUserWishlist($userId) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM card_wishlists WHERE user_id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $wishlist = $result->fetch_assoc();
            $stmt->close();
            
            // 如果心愿单不存在，则创建一个
            if (!$wishlist) {
                $wishlistId = $this->createWishlist($userId);
                $wishlist = [
                    'id' => $wishlistId,
                    'user_id' => $userId,
                    'name' => '我的心愿单',
                    'description' => '',
                    'item_count' => 0,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
            }
            
            return $wishlist;
        } catch (Exception $e) {
            $this->logger->error("获取用户心愿单失败，用户ID：{$userId}，错误：" . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 创建心愿单
     * @param int $userId 用户ID
     * @return int|bool 心愿单ID或失败返回false
     */
    protected function createWishlist($userId) {
        try {
            $stmt = $this->db->prepare("INSERT INTO card_wishlists (user_id, name) VALUES (?, ?)");
            $name = '我的心愿单';
            $stmt->bind_param("is", $userId, $name);
            $stmt->execute();
            $wishlistId = $stmt->insert_id;
            $stmt->close();
            
            $this->logger->info("创建心愿单成功，用户ID：{$userId}");
            return $wishlistId;
        } catch (Exception $e) {
            $this->logger->error("创建心愿单失败，用户ID：{$userId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 将卡密添加到心愿单
     * @param int $userId 用户ID
     * @param int $cardId 卡密ID
     * @param array $options 选项
     * @return bool 是否成功
     */
    public function addToWishlist($userId, $cardId, $options = []) {
        try {
            // 获取或创建心愿单
            $wishlist = $this->getUserWishlist($userId);
            if (!$wishlist) {
                throw new Exception("获取心愿单失败");
            }
            
            $wishlistId = $wishlist['id'];
            $wishPrice = $options['wish_price'] ?? null;
            
            // 添加到心愿单
            $stmt = $this->db->prepare("INSERT IGNORE INTO card_wishlist_items (wishlist_id, card_id, wish_price) VALUES (?, ?, ?)");
            $stmt->bind_param("iid", $wishlistId, $cardId, $wishPrice);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新心愿单数量
                $updateStmt = $this->db->prepare("UPDATE card_wishlists SET item_count = (SELECT COUNT(*) FROM card_wishlist_items WHERE wishlist_id = ?) WHERE id = ?");
                $updateStmt->bind_param("ii", $wishlistId, $wishlistId);
                $updateStmt->execute();
                $updateStmt->close();
                $this->logger->info("将卡密添加到心愿单成功，用户ID：{$userId}，卡密ID：{$cardId}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("将卡密添加到心愿单失败，用户ID：{$userId}，卡密ID：{$cardId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 设置卡密有效期提醒
     * @param int $cardId 卡密ID
     * @param int $userId 用户ID
     * @param int $remindDays 提前提醒天数
     * @param array $remindMethods 提醒方式
     * @return bool 是否成功
     */
    public function setCardExpirationReminder($cardId, $userId, $remindDays = 7, $remindMethods = ['email']) {
        try {
            // 获取卡密过期日期
            $stmt = $this->db->prepare("SELECT expire_date FROM cards WHERE id = ?");
            $stmt->bind_param("i", $cardId);
            $stmt->execute();
            $stmt->bind_result($expireDate);
            $stmt->fetch();
            $stmt->close();
            
            if (!$expireDate) {
                throw new Exception("卡密未设置过期日期或不存在");
            }
            
            // 计算提醒日期
            $remindDate = date('Y-m-d H:i:s', strtotime($expireDate . " -{$remindDays} days"));
            
            // 保存提醒设置
            $stmt = $this->db->prepare("INSERT INTO card_expiration_reminders (card_id, user_id, remind_days, expire_date, remind_date, remind_method) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE remind_days = ?, remind_date = ?, remind_method = ?");
            $methodJson = json_encode($remindMethods);
            $stmt->bind_param("iisississ", $cardId, $userId, $remindDays, $expireDate, $remindDate, $methodJson, $remindDays, $remindDate, $methodJson);
            $result = $stmt->execute();
            $stmt->close();
            
            $this->logger->info("设置卡密有效期提醒成功，卡密ID：{$cardId}，用户ID：{$userId}，提前提醒天数：{$remindDays}天");
            return $result;
        } catch (Exception $e) {
            $this->logger->error("设置卡密有效期提醒失败，卡密ID：{$cardId}，用户ID：{$userId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 申请卡密延期
     * @param int $cardId 卡密ID
     * @param int $userId 用户ID
     * @param int $extensionDays 延期天数
     * @param string $reason 延期原因
     * @return int|bool 延期申请ID或失败返回false
     */
    public function applyCardExtension($cardId, $userId, $extensionDays = 30, $reason = '') {
        try {
            // 获取卡密信息
            $stmt = $this->db->prepare("SELECT merchant_id, expire_date FROM cards WHERE id = ?");
            $stmt->bind_param("i", $cardId);
            $stmt->execute();
            $stmt->bind_result($merchantId, $oldExpireDate);
            $stmt->fetch();
            $stmt->close();
            
            if (!$merchantId) {
                throw new Exception("卡密不存在");
            }
            
            // 计算新的过期日期
            $newExpireDate = date('Y-m-d H:i:s', strtotime($oldExpireDate . "+{$extensionDays} days"));
            
            // 保存延期申请
            $stmt = $this->db->prepare("INSERT INTO card_extensions (card_id, user_id, merchant_id, old_expire_date, new_expire_date, extension_days, reason, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $status = 'pending';
            $stmt->bind_param("iiiisiss", $cardId, $userId, $merchantId, $oldExpireDate, $newExpireDate, $extensionDays, $reason, $status);
            $stmt->execute();
            $extensionId = $stmt->insert_id;
            $stmt->close();
            
            $this->logger->info("申请卡密延期成功，延期申请ID：{$extensionId}，卡密ID：{$cardId}，延期天数：{$extensionDays}天");
            
            // 发送通知给商户
            try {
                if (isset($this->notificationService) && is_object($this->notificationService)) {
                    if (method_exists($this->notificationService, 'sendMerchantNotification')) {
                        $this->notificationService->sendMerchantNotification($merchantId, 'card_extension_request', [
                            'extension_id' => $extensionId,
                            'card_id' => $cardId,
                            'user_id' => $userId,
                            'days' => $extensionDays,
                            'reason' => $reason,
                        ]);
                    } else {
                        // 由于我们已经在NotificationManager中添加了public的sendNotification方法，这里可以直接调用
                        // 但为了安全起见，仍然添加method_exists检查
                        if (method_exists($this->notificationService, 'sendNotification')) {
                            try {
                                $this->notificationService->sendNotification($merchantId, 'merchant', 'card_extension_request', [
                                    'extension_id' => $extensionId,
                                    'card_id' => $cardId,
                                    'user_id' => $userId,
                                    'days' => $extensionDays,
                                    'reason' => $reason,
                                ]);
                            } catch (Exception $e) {
                                $this->logger->warning("调用sendNotification方法时出错: " . $e->getMessage());
                                // 如果调用失败，使用后备方案
                                $this->createFallbackNotificationService()->sendNotification($merchantId, 'merchant', 'card_extension_request', [
                                    'extension_id' => $extensionId,
                                    'card_id' => $cardId,
                                    'user_id' => $userId,
                                    'days' => $extensionDays,
                                    'reason' => $reason,
                                ]);
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error("发送商户通知失败: " . $e->getMessage());
            }
            
            return $extensionId;
        } catch (Exception $e) {
            $this->logger->error("申请卡密延期失败，卡密ID：{$cardId}，用户ID：{$userId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 处理卡密延期申请
     * @param int $extensionId 延期申请ID
     * @param string $status 处理状态
     * @param array $options 选项
     * @return bool 是否成功
     */
    public function processExtensionRequest($extensionId, $status, $options = []) {
        try {
            $adminNotes = $options['admin_notes'] ?? '';
            
            $this->db->begin_transaction();
            
            // 更新延期申请状态
            $stmt = $this->db->prepare("UPDATE card_extensions SET status = ?, admin_notes = ?, processed_at = NOW() WHERE id = ?");
            $stmt->bind_param("ssi", $status, $adminNotes, $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // 如果批准延期，更新卡密过期日期
            if ($status === 'approved') {
                // 获取延期信息
                $stmt = $this->db->prepare("SELECT card_id, new_expire_date, user_id FROM card_extensions WHERE id = ?");
                $stmt->bind_param("i", $extensionId);
                $stmt->execute();
                $stmt->bind_result($cardId, $newExpireDate, $userId);
                $stmt->fetch();
                $stmt->close();
                
                // 更新卡密过期日期
                $stmt = $this->db->prepare("UPDATE cards SET expire_date = ? WHERE id = ?");
                $stmt->bind_param("si", $newExpireDate, $cardId);
                $stmt->execute();
                $stmt->close();
                
                $this->logger->info("卡密延期申请已批准，卡密ID：{$cardId}，新过期日期：{$newExpireDate}");
                
                // 发送通知给用户
                try {
                    if (isset($this->notificationService) && is_object($this->notificationService)) {
                        if (method_exists($this->notificationService, 'sendUserNotification')) {
                            $this->notificationService->sendUserNotification($userId, 'card_extension_approved', [
                                'extension_id' => $extensionId,
                                'card_id' => $cardId,
                                'new_expire_date' => $newExpireDate
                            ]);
                        } else {
                            // 如果方法不存在，尝试使用通用通知方法
                            if (method_exists($this->notificationService, 'sendNotification')) {
                                $this->notificationService->sendNotification($userId, 'user', 'card_extension_approved', [
                                    'extension_id' => $extensionId,
                                    'card_id' => $cardId,
                                    'new_expire_date' => $newExpireDate
                                ]);
                            }
                        }
                    }
                } catch (Exception $e) {
                    $this->logger->error("发送用户通知失败: " . $e->getMessage());
                }
            } else {
                // 发送拒绝通知
                $stmt = $this->db->prepare("SELECT user_id FROM card_extensions WHERE id = ?");
                $stmt->bind_param("i", $extensionId);
                $stmt->execute();
                $stmt->bind_result($userId);
                $stmt->fetch();
                $stmt->close();
                
                try {
                    if (isset($this->notificationService) && is_object($this->notificationService)) {
                        if (method_exists($this->notificationService, 'sendUserNotification')) {
                            $this->notificationService->sendUserNotification($userId, 'card_extension_rejected', [
                                'extension_id' => $extensionId,
                                'reason' => $adminNotes
                            ]);
                        } else {
                            // 如果方法不存在，尝试使用通用通知方法
                            if (method_exists($this->notificationService, 'sendNotification')) {
                                $this->notificationService->sendNotification($userId, 'user', 'card_extension_rejected', [
                                    'extension_id' => $extensionId,
                                    'reason' => $adminNotes
                                ]);
                            }
                        }
                    }
                } catch (Exception $e) {
                    $this->logger->error("发送用户拒绝通知失败: " . $e->getMessage());
                }
            }
            
            $this->db->commit();
            $this->logger->info("处理卡密延期申请成功，延期申请ID：{$extensionId}，状态：{$status}");
            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error("处理卡密延期申请失败，延期申请ID：{$extensionId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 创建卡密标签
     * @param string $name 标签名称
     * @param int $merchantId 商户ID（可选，null表示公共标签）
     * @param array $options 选项
     * @return int|bool 标签ID或失败返回false
     */
    public function createCardTag($name, $merchantId = null, $options = []) {
        try {
            $color = $options['color'] ?? '#6c757d';
            
            $stmt = $this->db->prepare("INSERT INTO card_tags (name, merchant_id, color) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE usage_count = usage_count + 1");
            $stmt->bind_param("sis", $name, $merchantId, $color);
            $stmt->execute();
            $tagId = $stmt->insert_id;
            $stmt->close();
            
            $this->logger->info("创建卡密标签成功，标签名称：{$name}");
            return $tagId;
        } catch (Exception $e) {
            $this->logger->error("创建卡密标签失败，标签名称：{$name}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 为卡密添加标签
     * @param int $cardId 卡密ID
     * @param int $tagId 标签ID
     * @return bool 是否成功
     */
    public function addTagToCard($cardId, $tagId) {
        try {
            // 检查卡密和标签是否存在
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards WHERE id = ?");
            $stmt->bind_param("i", $cardId);
            $stmt->execute();
            $stmt->bind_result($cardCount);
            $stmt->fetch();
            $stmt->close();
            
            if ($cardCount === 0) {
                throw new Exception("卡密不存在");
            }
            
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM card_tags WHERE id = ?");
            $stmt->bind_param("i", $tagId);
            $stmt->execute();
            $stmt->bind_result($tagCount);
            $stmt->fetch();
            $stmt->close();
            
            if ($tagCount === 0) {
                throw new Exception("标签不存在");
            }
            
            // 添加标签映射
            $stmt = $this->db->prepare("INSERT IGNORE INTO card_tag_mapping (card_id, tag_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $cardId, $tagId);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新标签使用次数
                // 安全地更新标签使用计数
                $subQuery = $this->db->prepare("SELECT COUNT(*) FROM card_tag_mapping WHERE tag_id = ?");
                $subQuery->bind_param("i", $tagId);
                $subQuery->execute();
                $subQuery->bind_result($count);
                $subQuery->fetch();
                $subQuery->close();
                
                $updateStmt = $this->db->prepare("UPDATE card_tags SET usage_count = ? WHERE id = ?");
                $updateStmt->bind_param("ii", $count, $tagId);
                $updateStmt->execute();
                $updateStmt->close();
                $this->logger->info("为卡密添加标签成功，卡密ID：{$cardId}，标签ID：{$tagId}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("为卡密添加标签失败，卡密ID：{$cardId}，标签ID：{$tagId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 移除卡密标签
     * @param int $cardId 卡密ID
     * @param int $tagId 标签ID
     * @return bool 是否成功
     */
    public function removeTagFromCard($cardId, $tagId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM card_tag_mapping WHERE card_id = ? AND tag_id = ?");
            $stmt->bind_param("ii", $cardId, $tagId);
            $result = $stmt->execute();
            $stmt->close();
            
            if ($result) {
                // 更新标签使用次数 - 使用prepare和bind_param替代直接传递数组给query方法
                $subQuery = $this->db->prepare("SELECT COUNT(*) FROM card_tag_mapping WHERE tag_id = ?");
                $subQuery->bind_param("i", $tagId);
                $subQuery->execute();
                $subQuery->bind_result($count);
                $subQuery->fetch();
                $subQuery->close();
                
                $updateStmt = $this->db->prepare("UPDATE card_tags SET usage_count = ? WHERE id = ?");
                $updateStmt->bind_param("ii", $count, $tagId);
                $updateStmt->execute();
                $updateStmt->close();
                
                $this->logger->info("移除卡密标签成功，卡密ID：{$cardId}，标签ID：{$tagId}");
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("移除卡密标签失败，卡密ID：{$cardId}，标签ID：{$tagId}，错误：" . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取卡密统计数据
     * @param array $params 查询参数
     * @return array 统计结果
     */
    public function getCardStatistics($params = []) {
        try {
            $statistics = [];
            
            // 总卡密数量
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards");
            $stmt->execute();
            $stmt->bind_result($totalCards);
            $stmt->fetch();
            $stmt->close();
            $statistics['total_cards'] = $totalCards;
            
            // 按状态统计
            $stmt = $this->db->prepare("SELECT status, COUNT(*) as count FROM cards GROUP BY status");
            $stmt->execute();
            $result = $stmt->get_result();
            $statusStats = [];
            while ($row = $result->fetch_assoc()) {
                $statusStats[$row['status']] = $row['count'];
            }
            $stmt->close();
            $statistics['status_distribution'] = $statusStats;
            
            // 即将过期的卡密（30天内）
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards WHERE expire_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 30 DAY)");
            $stmt->execute();
            $stmt->bind_result($expiringSoon);
            $stmt->fetch();
            $stmt->close();
            $statistics['expiring_soon'] = $expiringSoon;
            
            // 已过期的卡密
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards WHERE expire_date < NOW() AND expire_date IS NOT NULL");
            $stmt->execute();
            $stmt->bind_result($expired);
            $stmt->fetch();
            $stmt->close();
            $statistics['expired'] = $expired;
            
            // 今日新增卡密
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM cards WHERE DATE(created_at) = DATE(NOW())");
            $stmt->execute();
            $stmt->bind_result($todayAdded);
            $stmt->fetch();
            $stmt->close();
            $statistics['today_added'] = $todayAdded;
            
            return $statistics;
        } catch (Exception $e) {
            $this->logger->error("获取卡密统计数据失败：" . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 记录卡密浏览
     * @param int $cardId 卡密ID
     * @param int $userId 用户ID（可选）
     * @param string $ipAddress IP地址
     * @param string $userAgent 用户代理
     */
    public function recordCardView($cardId, $userId = null, $ipAddress = '', $userAgent = '') {
        try {
            $stmt = $this->db->prepare("INSERT INTO card_views (card_id, user_id, ip_address, user_agent) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $cardId, $userId, $ipAddress, $userAgent);
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            $this->logger->error("记录卡密浏览失败，卡密ID：{$cardId}，错误：" . $e->getMessage());
        }
    }
    
    /**
     * 健康检查
     * @return array 健康状态
     */
    public function healthCheck() {
        $status = 'healthy';
        $details = [];
        
        try {
            // 检查数据库连接
            $stmt = $this->db->prepare("SELECT 1");
            $stmt->execute();
            $stmt->close();
            $details['database'] = 'connected';
        } catch (Exception $e) {
            $status = 'unhealthy';
            $details['database'] = 'disconnected';
            $details['database_error'] = $e->getMessage();
        }
        
        try {
            // 检查Redis连接
            if ($this->redis && is_object($this->redis) && method_exists($this->redis, 'ping')) {
                $this->redis->ping();
                $details['redis'] = 'connected';
            } else {
                $details['redis'] = 'not_available';
            }
        } catch (Exception $e) {
            $status = 'degraded';
            $details['redis'] = 'disconnected';
            $details['redis_error'] = $e->getMessage();
        }
        
        return [
            'status' => $status,
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0.0',
            'details' => $details
        ];
    }
}
?>