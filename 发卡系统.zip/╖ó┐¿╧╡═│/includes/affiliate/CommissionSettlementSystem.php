\u003c?php
/**
 * 代理佣金结算自动化系统
 * 实现佣金计算、结算周期管理、提现处理等核心功能
 * 
 * @package Affiliate
 * @author System Admin
 */

namespace Affiliate;

use Database\DBConnection;
use Logger\Logger;
use Cache\CacheFactory;
use Payment\PaymentProcessor;

class CommissionSettlementSystem {
    /**
     * 配置项
     * @var array
     */
    private $config = [
        'auto_calculate_enabled' =\u003e true, // 是否启用自动计算
        'settlement_cycle' =\u003e 'monthly', // 结算周期：daily/weekly/monthly
        'min_payout_amount' =\u003e 100.00, // 最低结算金额
        'max_payout_amount' =\u003e 50000.00, // 最高结算金额
        'payout_fee_rate' =\u003e 0.50, // 提现手续费率(%)
        'min_fee' =\u003e 1.00, // 最低手续费
        'max_fee' =\u003e 100.00, // 最高手续费
        'commission_cache_ttl' =\u003e 300, // 佣金计算结果缓存时间（秒）
        'enable_team_commission' =\u003e true, // 是否启用团队佣金
        'max_team_level' =\u003e 5, // 最大团队层级
        'notify_on_payout' =\u003e true, // 结算时是否发送通知
    ];
    
    /**
     * 数据库连接
     * @var DBConnection
     */
    private $db;
    
    /**
     * 缓存实例
     * @var Cache\CacheInterface
     */
    private $cache;
    
    /**
     * 日志实例
     * @var Logger
     */
    private $logger;
    
    /**
     * 支付处理器
     * @var PaymentProcessor
     */
    private $paymentProcessor;
    
    /**
     * 构造函数
     * 
     * @param array $config 配置项
     * @throws \Exception
     */
    public function __construct(array $config = []) {
        $this-\u003econfig = array_merge($this-\u003econfig, $config);
        
        // 初始化数据库连接
        $this-\u003edb = DBConnection::getInstance();
        
        // 初始化缓存
        $this-\u003ecache = CacheFactory::getInstance('redis');
        
        // 初始化日志
        $this-\u003elogger = Logger::getInstance('affiliate_commission');
        
        // 初始化支付处理器
        try {
            $this-\u003epaymentProcessor = new PaymentProcessor();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003ewarning('Payment processor initialization failed: ' . $e-\u003egetMessage());
        }
    }
    
    /**
     * 计算订单佣金
     * 
     * @param array $order 订单信息
     * @param array $commissionInfo 佣金相关信息
     * @return array 计算结果
     */
    public function calculateOrderCommission($order, $commissionInfo) {
        $cacheKey = 'commission_calc:' . $order['id'];
        
        // 检查缓存
        if ($cachedResult = $this-\u003ecache-\u003eget($cacheKey)) {
            return json_decode($cachedResult, true);
        }
        
        try {
            $orderAmount = $order['amount'];
            $affiliateId = $commissionInfo['affiliate_id'];
            $productInfo = $commissionInfo['product_info'] ?? [];
            $userId = $order['user_id'] ?? null;
            
            // 获取代理信息
            $affiliate = $this-\u003egetAffiliateInfo($affiliateId);
            if (!$affiliate) {
                throw new \Exception("代理不存在: {$affiliateId}");
            }
            
            // 获取佣金规则
            $commissionRate = $this-\u003edetermineCommissionRate($affiliateId, $orderAmount, $productInfo, $userId);
            
            // 计算佣金金额
            $commissionAmount = ($orderAmount * $commissionRate) / 100;
            
            // 应用最低/最高佣金限制
            $commissionAmount = $this-\u003eapplyCommissionLimits($commissionAmount);
            
            // 准备佣金记录数据
            $commissionData = [
                'order_id' =\u003e $order['id'],
                'affiliate_id' =\u003e $affiliateId,
                'amount' =\u003e $commissionAmount,
                'commission_rate' =\u003e $commissionRate,
                'commission_type' =\u003e 'direct',
                'source_type' =\u003e 'order',
                'source_id' =\u003e $order['id'],
                'status' =\u003e 'pending',
                'description' =\u003e "订单号: {$order['order_no']} 佣金",
                'product_info' =\u003e $productInfo,
                'affiliate_level' =\u003e $affiliate['level_id'],
            ];
            
            // 缓存结果
            $this-\u003ecache-\u003eset($cacheKey, json_encode($commissionData), $this-\u003econfig['commission_cache_ttl']);
            
            return $commissionData;
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to calculate order commission: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 根据多维度因素确定佣金比例
     * 
     * @param int $affiliateId 代理ID
     * @param float $orderAmount 订单金额
     * @param array $productInfo 产品信息
     * @param int|null $userId 用户ID
     * @return float 佣金比例
     */
    private function determineCommissionRate($affiliateId, $orderAmount, $productInfo, $userId = null) {
        // 基础佣金率
        $baseRate = 10.00;
        
        // 1. 获取代理等级佣金比例
        $affiliateLevel = $this-\u003egetAffiliateLevel($affiliateId);
        if ($affiliateLevel) {
            $baseRate = $affiliateLevel['commission_rate'];
        }
        
        // 2. 检查特殊佣金规则
        $customRate = $this-\u003egetCustomCommissionRate($affiliateId, $productInfo, $orderAmount, $userId);
        if ($customRate \u003e $baseRate) {
            $baseRate = $customRate;
        }
        
        // 3. 大额订单加成
        if ($orderAmount \u003e 1000) {
            $baseRate += 2.00;
        } elseif ($orderAmount \u003e 5000) {
            $baseRate += 3.00;
        }
        
        // 4. 新客户加成
        if ($userId && !$this-\u003ehasPreviousOrders($userId)) {
            $baseRate += 1.50;
        }
        
        return min($baseRate, 50.00); // 最高不超过50%
    }
    
    /**
     * 获取代理信息
     * 
     * @param int $affiliateId 代理ID
     * @return array|null
     */
    private function getAffiliateInfo($affiliateId) {
        try {
            $query = "SELECT * FROM affiliates WHERE id = :id AND status = 'active'";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':id', $affiliateId);
            $stmt-\u003eexecute();
            return $stmt-\u003efetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get affiliate info: ' . $e-\u003egetMessage());
            return null;
        }
    }
    
    /**
     * 获取代理等级信息
     * 
     * @param int $affiliateId 代理ID
     * @return array|null
     */
    private function getAffiliateLevel($affiliateId) {
        try {
            $query = "SELECT al.* FROM affiliate_levels al
                      JOIN affiliates a ON al.id = a.level_id
                      WHERE a.id = :id";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':id', $affiliateId);
            $stmt-\u003eexecute();
            return $stmt-\u003efetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get affiliate level: ' . $e-\u003egetMessage());
            return null;
        }
    }
    
    /**
     * 获取自定义佣金率
     * 
     * @param int $affiliateId 代理ID
     * @param array $productInfo 产品信息
     * @param float $orderAmount 订单金额
     * @param int|null $userId 用户ID
     * @return float 佣金率
     */
    private function getCustomCommissionRate($affiliateId, $productInfo, $orderAmount, $userId = null) {
        try {
            // 按照优先级查找适用的佣金规则
            $query = "SELECT commission_rate FROM commission_rules
                      WHERE enabled = 1
                      AND (
                          -- 产品特定规则
                          (:product_id IS NOT NULL AND rule_type = 'product' AND target_id = :product_id) OR
                          -- 分类规则
                          (:category_id IS NOT NULL AND rule_type = 'category' AND target_id = :category_id) OR
                          -- 用户等级规则
                          (:user_level IS NOT NULL AND rule_type = 'user_level' AND target_id = :user_level) OR
                          -- 全局规则
                          (rule_type = 'global' AND target_id IS NULL)
                      )
                      AND (:min_amount IS NULL OR min_amount \u003c= :order_amount)
                      AND (:max_commission IS NULL OR commission_rate * :order_amount / 100 \u003c= :max_commission)
                      AND (effective_from IS NULL OR effective_from \u003c= NOW())
                      AND (effective_to IS NULL OR effective_to \u003e NOW())
                      ORDER BY priority ASC
                      LIMIT 1";
            
            $stmt = $this-\u003edb-\u003eprepare($query);
            $productId = $productInfo['id'] ?? null;
            $categoryId = $productInfo['category_id'] ?? null;
            $userLevel = null; // 需要从用户信息中获取
            
            $stmt-\u003ebindParam(':product_id', $productId);
            $stmt-\u003ebindParam(':category_id', $categoryId);
            $stmt-\u003ebindParam(':user_level', $userLevel);
            $stmt-\u003ebindParam(':min_amount', $minAmount, \PDO::PARAM_NULL);
            $stmt-\u003ebindParam(':max_commission', $maxCommission, \PDO::PARAM_NULL);
            $stmt-\u003ebindParam(':order_amount', $orderAmount);
            $stmt-\u003eexecute();
            
            $result = $stmt-\u003efetchColumn();
            return $result !== false ? $result : 0.00;
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get custom commission rate: ' . $e-\u003egetMessage());
            return 0.00;
        }
    }
    
    /**
     * 应用佣金限制
     * 
     * @param float $amount 佣金金额
     * @return float 限制后的金额
     */
    private function applyCommissionLimits($amount) {
        $minCommission = $this-\u003econfig['min_payout_amount'] * 0.1; // 最低佣金为最低提现金额的10%
        $maxCommission = $this-\u003econfig['max_payout_amount'];
        
        return max($minCommission, min($amount, $maxCommission));
    }
    
    /**
     * 检查用户是否有历史订单
     * 
     * @param int $userId 用户ID
     * @return bool
     */
    private function hasPreviousOrders($userId) {
        try {
            $query = "SELECT 1 FROM orders WHERE user_id = :userId AND created_at \u003c DATE_SUB(NOW(), INTERVAL 1 DAY) LIMIT 1";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':userId', $userId);
            $stmt-\u003eexecute();
            return $stmt-\u003efetchColumn() !== false;
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to check previous orders: ' . $e-\u003egetMessage());
            return false;
        }
    }
    
    /**
     * 创建佣金记录
     * 
     * @param array $commissionData 佣金数据
     * @return int 记录ID
     */
    public function createCommissionRecord($commissionData) {
        try {
            $query = "INSERT INTO commission_records (affiliate_id, order_id, amount, commission_rate, commission_type, 
                     source_type, source_id, status, description, created_at) 
                     VALUES (:affiliate_id, :order_id, :amount, :commission_rate, :commission_type, 
                     :source_type, :source_id, :status, :description, NOW())";
            
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':affiliate_id', $commissionData['affiliate_id']);
            $stmt-\u003ebindParam(':order_id', $commissionData['order_id']);
            $stmt-\u003ebindParam(':amount', $commissionData['amount']);
            $stmt-\u003ebindParam(':commission_rate', $commissionData['commission_rate']);
            $stmt-\u003ebindParam(':commission_type', $commissionData['commission_type']);
            $stmt-\u003ebindParam(':source_type', $commissionData['source_type']);
            $stmt-\u003ebindParam(':source_id', $commissionData['source_id']);
            $stmt-\u003ebindParam(':status', $commissionData['status']);
            $stmt-\u003ebindParam(':description', $commissionData['description']);
            $stmt-\u003eexecute();
            
            $recordId = $this-\u003edb-\u003elastInsertId();
            
            // 清理缓存
            $this-\u003ecache-\u003edelete('commission_calc:' . $commissionData['order_id']);
            
            // 记录日志
            $this-\u003elogger-\u003einfo("创建佣金记录: ID={$recordId}, 代理ID={$commissionData['affiliate_id']}, 金额={$commissionData['amount']}");
            
            // 如果启用了团队佣金，计算团队佣金
            if ($this-\u003econfig['enable_team_commission'] \u0026\u0026 $commissionData['commission_type'] === 'direct') {
                $this-\u003ecalculateTeamCommissions($commissionData, $recordId);
            }
            
            return $recordId;
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to create commission record: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 计算团队佣金
     * 
     * @param array $directCommission 直接佣金数据
     * @param int $directRecordId 直接佣金记录ID
     */
    private function calculateTeamCommissions($directCommission, $directRecordId) {
        try {
            $affiliateId = $directCommission['affiliate_id'];
            $teamCommissions = [];
            
            // 获取代理团队结构
            $teamStructure = $this-\u003egetTeamStructure($affiliateId);
            
            // 计算各级别佣金
            foreach ($teamStructure as $level =\u003e $parentAffiliates) {
                // 确保不超过最大层级
                if ($level \u003e $this-\u003econfig['max_team_level']) {
                    break;
                }
                
                // 计算该层级的佣金比例（递减）
                $teamCommissionRate = $this-\u003ecalculateTeamCommissionRate($level);
                
                foreach ($parentAffiliates as $parentId) {
                    // 计算佣金金额
                    $teamCommissionAmount = ($directCommission['amount'] * $teamCommissionRate) / 100;
                    
                    if ($teamCommissionAmount \u003e 0) {
                        $teamCommissions[] = [
                            'affiliate_id' =\u003e $parentId,
                            'amount' =\u003e $teamCommissionAmount,
                            'commission_rate' =\u003e $teamCommissionRate,
                            'commission_type' =\u003e 'indirect',
                            'source_type' =\u003e 'team',
                            'source_id' =\u003e $directRecordId,
                            'status' =\u003e 'pending',
                            'description' =\u003e "团队佣金 - 层级{$level} - 订单号: {$directCommission['order_id']}",
                        ];
                    }
                }
            }
            
            // 批量创建团队佣金记录
            if (!empty($teamCommissions)) {
                $this-\u003ecreateTeamCommissionRecords($teamCommissions);
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Team commission calculation failed: ' . $e-\u003egetMessage());
        }
    }
    
    /**
     * 获取代理团队结构
     * 
     * @param int $affiliateId 代理ID
     * @return array 层级-代理ID映射
     */
    private function getTeamStructure($affiliateId) {
        try {
            $team = [];
            $currentLevel = 1;
            $currentAffiliates = [$affiliateId];
            
            while (!empty($currentAffiliates) \u0026\u0026 $currentLevel \u003c= $this-\u003econfig['max_team_level']) {
                // 获取上一级代理
                $query = "SELECT parent_id FROM affiliate_teams 
                          WHERE child_id IN (:ids) AND status = 'active'";
                
                $stmt = $this-\u003edb-\u003eprepare($query);
                $idsString = implode(',', $currentAffiliates);
                $stmt-\u003ebindParam(':ids', $idsString);
                $stmt-\u003eexecute();
                
                $parents = $stmt-\u003efetchAll(\PDO::FETCH_COLUMN);
                $parents = array_unique(array_filter($parents));
                
                if (!empty($parents)) {
                    $team[$currentLevel] = $parents;
                    $currentAffiliates = $parents;
                    $currentLevel++;
                } else {
                    break;
                }
            }
            
            return $team;
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get team structure: ' . $e-\u003egetMessage());
            return [];
        }
    }
    
    /**
     * 计算团队佣金比例
     * 
     * @param int $level 层级
     * @return float 佣金比例
     */
    private function calculateTeamCommissionRate($level) {
        // 层级佣金递减算法
        switch ($level) {
            case 1: return 5.00; // 直接上级
            case 2: return 3.00;
            case 3: return 2.00;
            case 4: return 1.00;
            case 5: return 0.50;
            default: return 0.00;
        }
    }
    
    /**
     * 批量创建团队佣金记录
     * 
     * @param array $teamCommissions 团队佣金数据数组
     */
    private function createTeamCommissionRecords($teamCommissions) {
        try {
            $query = "INSERT INTO commission_records (affiliate_id, amount, commission_rate, commission_type, 
                     source_type, source_id, status, description, created_at) 
                     VALUES (:affiliate_id, :amount, :commission_rate, :commission_type, 
                     :source_type, :source_id, :status, :description, NOW())";
            
            $stmt = $this-\u003edb-\u003eprepare($query);
            
            foreach ($teamCommissions as $commission) {
                $stmt-\u003ebindParam(':affiliate_id', $commission['affiliate_id']);
                $stmt-\u003ebindParam(':amount', $commission['amount']);
                $stmt-\u003ebindParam(':commission_rate', $commission['commission_rate']);
                $stmt-\u003ebindParam(':commission_type', $commission['commission_type']);
                $stmt-\u003ebindParam(':source_type', $commission['source_type']);
                $stmt-\u003ebindParam(':source_id', $commission['source_id']);
                $stmt-\u003ebindParam(':status', $commission['status']);
                $stmt-\u003ebindParam(':description', $commission['description']);
                $stmt-\u003eexecute();
                
                $recordId = $this-\u003edb-\u003elastInsertId();
                $this-\u003elogger-\u003edebug("创建团队佣金记录: ID={$recordId}, 代理ID={$commission['affiliate_id']}, 金额={$commission['amount']}");
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to create team commission records: ' . $e-\u003egetMessage());
        }
    }
    
    /**
     * 创建结算周期
     * 
     * @param string $cycleType 周期类型 (daily/weekly/monthly)
     * @return int 结算周期ID
     */
    public function createSettlementCycle($cycleType = 'monthly') {
        try {
            // 确定日期范围
            $startDate = null;
            $endDate = null;
            $cycleName = '';
            
            switch ($cycleType) {
                case 'daily':
                    $startDate = date('Y-m-d', strtotime('-1 day'));
                    $endDate = $startDate;
                    $cycleName = '日结';
                    break;
                case 'weekly':
                    $startDate = date('Y-m-d', strtotime('last monday -1 week'));
                    $endDate = date('Y-m-d', strtotime('last sunday'));
                    $cycleName = '周结';
                    break;
                case 'monthly':
                default:
                    $startDate = date('Y-m-01', strtotime('-1 month'));
                    $endDate = date('Y-m-t', strtotime('-1 month'));
                    $cycleName = '月结';
                    break;
            }
            
            // 检查是否已存在该周期
            $query = "SELECT id FROM commission_payout_cycles 
                      WHERE cycle_name = :cycle_name 
                      AND start_date = :start_date 
                      AND end_date = :end_date";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':cycle_name', $cycleName);
            $stmt-\u003ebindParam(':start_date', $startDate);
            $stmt-\u003ebindParam(':end_date', $endDate);
            $stmt-\u003eexecute();
            
            $existingCycle = $stmt-\u003efetchColumn();
            if ($existingCycle) {
                return $existingCycle;
            }
            
            // 创建新结算周期
            $query = "INSERT INTO commission_payout_cycles (cycle_name, start_date, end_date, status, created_at) 
                     VALUES (:cycle_name, :start_date, :end_date, 'open', NOW())";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':cycle_name', $cycleName);
            $stmt-\u003ebindParam(':start_date', $startDate);
            $stmt-\u003ebindParam(':end_date', $endDate);
            $stmt-\u003eexecute();
            
            $cycleId = $this-\u003edb-\u003elastInsertId();
            $this-\u003elogger-\u003einfo("创建结算周期: ID={$cycleId}, 类型={$cycleName}, 开始={$startDate}, 结束={$endDate}");
            
            return $cycleId;
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to create settlement cycle: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 执行自动结算
     * 
     * @param int $cycleId 结算周期ID
     * @return array 结算结果
     */
    public function performSettlement($cycleId) {
        try {
            $this-\u003elogger-\u003einfo("开始执行结算: 结算周期ID={$cycleId}");
            
            // 开始事务
            $this-\u003edb-\u003ebeginTransaction();
            
            try {
                // 获取结算周期信息
                $cycleInfo = $this-\u003egetSettlementCycleInfo($cycleId);
                if (!$cycleInfo || $cycleInfo['status'] !== 'open') {
                    throw new \Exception("无效的结算周期: {$cycleId}");
                }
                
                // 更新周期状态为处理中
                $query = "UPDATE commission_payout_cycles SET status = 'processing', updated_at = NOW() WHERE id = :id";
                $stmt = $this-\u003edb-\u003eprepare($query);
                $stmt-\u003ebindParam(':id', $cycleId);
                $stmt-\u003eexecute();
                
                // 获取待结算的佣金记录
                $pendingCommissions = $this-\u003egetPendingCommissionsForSettlement($cycleId, $cycleInfo);
                
                // 按代理分组
                $affiliateCommissions = $this-\u003egroupCommissionsByAffiliate($pendingCommissions);
                
                // 处理每个代理的结算
                $processedCount = 0;
                $totalPayoutAmount = 0;
                $affiliateResults = [];
                
                foreach ($affiliateCommissions as $affiliateId =\u003e $commissions) {
                    $result = $this-\u003eprocessAffiliateSettlement($cycleId, $affiliateId, $commissions);
                    if ($result['success']) {
                        $processedCount++;
                        $totalPayoutAmount += $result['amount'];
                        $affiliateResults[$affiliateId] = $result;
                        
                        // 发送通知
                        if ($this-\u003econfig['notify_on_payout']) {
                            $this-\u003esendPayoutNotification($affiliateId, $result, $cycleInfo);
                        }
                    }
                }
                
                // 更新结算周期信息
                $query = "UPDATE commission_payout_cycles 
                         SET status = 'completed', 
                             total_affiliates = :processed_count, 
                             total_amount = :total_amount, 
                             processed_at = NOW(), 
                             updated_at = NOW() 
                         WHERE id = :id";
                $stmt = $this-\u003edb-\u003eprepare($query);
                $stmt-\u003ebindParam(':processed_count', $processedCount);
                $stmt-\u003ebindParam(':total_amount', $totalPayoutAmount);
                $stmt-\u003ebindParam(':id', $cycleId);
                $stmt-\u003eexecute();
                
                // 提交事务
                $this-\u003edb-\u003ecommit();
                
                $this-\u003elogger-\u003einfo("结算完成: 周期ID={$cycleId}, 处理代理数={$processedCount}, 总金额={$totalPayoutAmount}");
                
                return [
                    'success' =\u003e true,
                    'cycle_id' =\u003e $cycleId,
                    'processed_count' =\u003e $processedCount,
                    'total_amount' =\u003e $totalPayoutAmount,
                    'affiliate_results' =\u003e $affiliateResults
                ];
            } catch (\Exception $e) {
                // 回滚事务
                $this-\u003edb-\u003erollBack();
                
                // 更新周期状态为失败
                $query = "UPDATE commission_payout_cycles SET status = 'failed', updated_at = NOW() WHERE id = :id";
                $stmt = $this-\u003edb-\u003eprepare($query);
                $stmt-\u003ebindParam(':id', $cycleId);
                $stmt-\u003eexecute();
                
                throw $e;
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Settlement failed: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 获取结算周期信息
     * 
     * @param int $cycleId 结算周期ID
     * @return array|null
     */
    private function getSettlementCycleInfo($cycleId) {
        try {
            $query = "SELECT * FROM commission_payout_cycles WHERE id = :id";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':id', $cycleId);
            $stmt-\u003eexecute();
            return $stmt-\u003efetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get settlement cycle info: ' . $e-\u003egetMessage());
            return null;
        }
    }
    
    /**
     * 获取待结算的佣金记录
     * 
     * @param int $cycleId 结算周期ID
     * @param array $cycleInfo 结算周期信息
     * @return array
     */
    private function getPendingCommissionsForSettlement($cycleId, $cycleInfo) {
        try {
            $query = "SELECT * FROM commission_records 
                     WHERE status = 'pending' 
                     AND created_at BETWEEN :start_date AND :end_date 
                     ORDER BY affiliate_id, created_at";
            
            $stmt = $this-\u003edb-\u003eprepare($query);
            $startDateTime = $cycleInfo['start_date'] . ' 00:00:00';
            $endDateTime = $cycleInfo['end_date'] . ' 23:59:59';
            
            $stmt-\u003ebindParam(':start_date', $startDateTime);
            $stmt-\u003ebindParam(':end_date', $endDateTime);
            $stmt-\u003eexecute();
            
            return $stmt-\u003efetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get pending commissions: ' . $e-\u003egetMessage());
            return [];
        }
    }
    
    /**
     * 按代理分组佣金记录
     * 
     * @param array $commissions 佣金记录
     * @return array 分组后的佣金
     */
    private function groupCommissionsByAffiliate($commissions) {
        $grouped = [];
        
        foreach ($commissions as $commission) {
            $affiliateId = $commission['affiliate_id'];
            if (!isset($grouped[$affiliateId])) {
                $grouped[$affiliateId] = [];
            }
            $grouped[$affiliateId][] = $commission;
        }
        
        return $grouped;
    }
    
    /**
     * 处理单个代理的结算
     * 
     * @param int $cycleId 结算周期ID
     * @param int $affiliateId 代理ID
     * @param array $commissions 佣金记录
     * @return array 处理结果
     */
    private function processAffiliateSettlement($cycleId, $affiliateId, $commissions) {
        try {
            // 计算总金额
            $totalAmount = 0;
            foreach ($commissions as $commission) {
                $totalAmount += $commission['amount'];
            }
            
            // 检查最低结算金额
            if ($totalAmount \u003c $this-\u003econfig['min_payout_amount']) {
                return [
                    'success' =\u003e false,
                    'reason' =\u003e '未达到最低结算金额',
                    'amount' =\u003e $totalAmount
                ];
            }
            
            // 创建结算明细
            $detailId = $this-\u003ecreateSettlementDetail($cycleId, $affiliateId, $totalAmount, $commissions);
            
            // 更新佣金记录状态
            $this-\u003eupdateCommissionRecordsStatus($commissions, 'approved');
            
            // 更新代理余额
            $this-\u003eupdateAffiliateBalance($affiliateId, $totalAmount);
            
            // 记录财务流水
            $this-\u003elogFinancialTransaction($affiliateId, 'commission_payout', $totalAmount, $cycleId);
            
            return [
                'success' =\u003e true,
                'amount' =\u003e $totalAmount,
                'detail_id' =\u003e $detailId
            ];
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror("代理结算处理失败: 代理ID={$affiliateId}, 错误={$e-\u003egetMessage()}");
            return [
                'success' =\u003e false,
                'reason' =\u003e $e-\u003egetMessage(),
                'amount' =\u003e 0
            ];
        }
    }
    
    /**
     * 创建结算明细
     * 
     * @param int $cycleId 结算周期ID
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     * @param array $commissions 佣金记录
     * @return int 明细ID
     */
    private function createSettlementDetail($cycleId, $affiliateId, $amount, $commissions) {
        try {
            // 准备佣金明细JSON
            $commissionDetails = [];
            foreach ($commissions as $commission) {
                $commissionDetails[] = [
                    'id' =\u003e $commission['id'],
                    'amount' =\u003e $commission['amount'],
                    'rate' =\u003e $commission['commission_rate'],
                    'type' =\u003e $commission['commission_type'],
                    'source' =\u003e $commission['source_type'],
                    'source_id' =\u003e $commission['source_id']
                ];
            }
            
            $query = "INSERT INTO commission_payout_details (cycle_id, affiliate_id, payout_amount, 
                     commission_details, status, created_at) 
                     VALUES (:cycle_id, :affiliate_id, :amount, :details, 'completed', NOW())";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $detailsJSON = json_encode($commissionDetails);
            
            $stmt-\u003ebindParam(':cycle_id', $cycleId);
            $stmt-\u003ebindParam(':affiliate_id', $affiliateId);
            $stmt-\u003ebindParam(':amount', $amount);
            $stmt-\u003ebindParam(':details', $detailsJSON);
            $stmt-\u003eexecute();
            
            return $this-\u003edb-\u003elastInsertId();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to create settlement detail: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 更新佣金记录状态
     * 
     * @param array $commissions 佣金记录
     * @param string $status 新状态
     */
    private function updateCommissionRecordsStatus($commissions, $status) {
        try {
            $ids = [];
            foreach ($commissions as $commission) {
                $ids[] = $commission['id'];
            }
            
            if (!empty($ids)) {
                $query = "UPDATE commission_records SET status = :status, approved_at = NOW() WHERE id IN (:ids)";
                $stmt = $this-\u003edb-\u003eprepare($query);
                $idsString = implode(',', $ids);
                
                $stmt-\u003ebindParam(':status', $status);
                $stmt-\u003ebindParam(':ids', $idsString);
                $stmt-\u003eexecute();
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to update commission records status: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 更新代理余额
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     */
    private function updateAffiliateBalance($affiliateId, $amount) {
        try {
            $query = "UPDATE affiliates SET available_balance = available_balance + :amount, updated_at = NOW() WHERE id = :id";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':amount', $amount);
            $stmt-\u003ebindParam(':id', $affiliateId);
            $stmt-\u003eexecute();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to update affiliate balance: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 记录财务流水
     * 
     * @param int $affiliateId 代理ID
     * @param string $transactionType 交易类型
     * @param float $amount 金额
     * @param int $relatedId 关联ID
     */
    private function logFinancialTransaction($affiliateId, $transactionType, $amount, $relatedId) {
        try {
            // 获取交易前后的余额
            $query = "SELECT available_balance FROM affiliates WHERE id = :id FOR UPDATE";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':id', $affiliateId);
            $stmt-\u003eexecute();
            $balanceBefore = $stmt-\u003efetchColumn() - $amount;
            $balanceAfter = $balanceBefore + $amount;
            
            // 记录流水
            $query = "INSERT INTO affiliate_financial_logs (affiliate_id, transaction_type, amount, 
                     balance_before, balance_after, related_id, description, created_at) 
                     VALUES (:affiliate_id, :transaction_type, :amount, :balance_before, 
                     :balance_after, :related_id, :description, NOW())";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $description = "佣金结算 - 周期ID: {$relatedId}";
            
            $stmt-\u003ebindParam(':affiliate_id', $affiliateId);
            $stmt-\u003ebindParam(':transaction_type', $transactionType);
            $stmt-\u003ebindParam(':amount', $amount);
            $stmt-\u003ebindParam(':balance_before', $balanceBefore);
            $stmt-\u003ebindParam(':balance_after', $balanceAfter);
            $stmt-\u003ebindParam(':related_id', $relatedId);
            $stmt-\u003ebindParam(':description', $description);
            $stmt-\u003eexecute();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to log financial transaction: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 处理提现申请
     * 
     * @param array $withdrawalData 提现数据
     * @return array 处理结果
     */
    public function processWithdrawalRequest($withdrawalData) {
        try {
            $affiliateId = $withdrawalData['affiliate_id'];
            $amount = $withdrawalData['amount'];
            $paymentMethod = $withdrawalData['payment_method'];
            $paymentAccount = $withdrawalData['payment_account'];
            
            // 开始事务
            $this-\u003edb-\u003ebeginTransaction();
            
            try {
                // 获取代理信息
                $affiliate = $this-\u003egetAffiliateInfo($affiliateId);
                if (!$affiliate) {
                    throw new \Exception("代理不存在");
                }
                
                // 检查余额
                if ($affiliate['available_balance'] \u003c $amount) {
                    throw new \Exception("余额不足");
                }
                
                // 检查金额限制
                if ($amount \u003c $this-\u003econfig['min_payout_amount']) {
                    throw new \Exception("低于最低提现金额");
                }
                
                if ($amount \u003e $this-\u003econfig['max_payout_amount']) {
                    throw new \Exception("超过最高提现金额");
                }
                
                // 计算手续费
                $fee = $this-\u003ecalculateWithdrawalFee($amount);
                $actualAmount = $amount - $fee;
                
                // 创建提现记录
                $withdrawalId = $this-\u003ecreateWithdrawalRequest($affiliateId, $amount, $fee, $actualAmount, $paymentMethod, $paymentAccount);
                
                // 冻结余额
                $this-\u003efreezeAffiliateBalance($affiliateId, $amount);
                
                // 记录财务流水
                $this-\u003elogWithdrawalTransaction($affiliateId, $amount, $fee, $withdrawalId);
                
                // 提交事务
                $this-\u003edb-\u003ecommit();
                
                // 异步处理支付
                $this-\u003escheduleWithdrawalProcessing($withdrawalId);
                
                $this-\u003elogger-\u003einfo("提现申请创建成功: ID={$withdrawalId}, 代理ID={$affiliateId}, 金额={$amount}");
                
                return [
                    'success' =\u003e true,
                    'withdrawal_id' =\u003e $withdrawalId,
                    'amount' =\u003e $amount,
                    'fee' =\u003e $fee,
                    'actual_amount' =\u003e $actualAmount,
                    'status' =\u003e 'pending'
                ];
            } catch (\Exception $e) {
                $this-\u003edb-\u003erollBack();
                throw $e;
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Withdrawal request processing failed: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 计算提现手续费
     * 
     * @param float $amount 提现金额
     * @return float 手续费
     */
    private function calculateWithdrawalFee($amount) {
        $fee = ($amount * $this-\u003econfig['payout_fee_rate']) / 100;
        
        // 应用最低/最高限制
        $fee = max($this-\u003econfig['min_fee'], min($fee, $this-\u003econfig['max_fee']));
        
        return round($fee, 2);
    }
    
    /**
     * 创建提现申请记录
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     * @param float $fee 手续费
     * @param float $actualAmount 实际到账金额
     * @param string $paymentMethod 支付方式
     * @param string $paymentAccount 支付账号
     * @return int 提现记录ID
     */
    private function createWithdrawalRequest($affiliateId, $amount, $fee, $actualAmount, $paymentMethod, $paymentAccount) {
        try {
            $query = "INSERT INTO withdrawal_requests (affiliate_id, amount, fee, actual_amount, 
                     payment_method, payment_account, status, created_at) 
                     VALUES (:affiliate_id, :amount, :fee, :actual_amount, :payment_method, 
                     :payment_account, 'pending', NOW())";
            $stmt = $this-\u003edb-\u003eprepare($query);
            
            $stmt-\u003ebindParam(':affiliate_id', $affiliateId);
            $stmt-\u003ebindParam(':amount', $amount);
            $stmt-\u003ebindParam(':fee', $fee);
            $stmt-\u003ebindParam(':actual_amount', $actualAmount);
            $stmt-\u003ebindParam(':payment_method', $paymentMethod);
            $stmt-\u003ebindParam(':payment_account', $paymentAccount);
            $stmt-\u003eexecute();
            
            return $this-\u003edb-\u003elastInsertId();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to create withdrawal request: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 冻结代理余额
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     */
    private function freezeAffiliateBalance($affiliateId, $amount) {
        try {
            $query = "UPDATE affiliates SET 
                     available_balance = available_balance - :amount, 
                     frozen_balance = frozen_balance + :amount, 
                     updated_at = NOW() 
                     WHERE id = :id";
            $stmt = $this-\u003edb-\u003eprepare($query);
            
            $stmt-\u003ebindParam(':amount', $amount);
            $stmt-\u003ebindParam(':id', $affiliateId);
            $stmt-\u003eexecute();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to freeze affiliate balance: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 记录提现交易流水
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     * @param float $fee 手续费
     * @param int $withdrawalId 提现ID
     */
    private function logWithdrawalTransaction($affiliateId, $amount, $fee, $withdrawalId) {
        try {
            // 获取交易前后的余额
            $query = "SELECT available_balance FROM affiliates WHERE id = :id FOR UPDATE";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':id', $affiliateId);
            $stmt-\u003eexecute();
            $balanceAfter = $stmt-\u003efetchColumn();
            $balanceBefore = $balanceAfter + $amount;
            
            // 记录流水
            $query = "INSERT INTO affiliate_financial_logs (affiliate_id, transaction_type, amount, 
                     balance_before, balance_after, related_id, description, created_at) 
                     VALUES (:affiliate_id, 'withdrawal_request', :amount, :balance_before, 
                     :balance_after, :related_id, :description, NOW())";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $description = "提现申请 - ID: {$withdrawalId}";
            
            $stmt-\u003ebindParam(':affiliate_id', $affiliateId);
            $stmt-\u003ebindParam(':amount', $amount);
            $stmt-\u003ebindParam(':balance_before', $balanceBefore);
            $stmt-\u003ebindParam(':balance_after', $balanceAfter);
            $stmt-\u003ebindParam(':related_id', $withdrawalId);
            $stmt-\u003ebindParam(':description', $description);
            $stmt-\u003eexecute();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to log withdrawal transaction: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 调度提现处理
     * 
     * @param int $withdrawalId 提现ID
     */
    private function scheduleWithdrawalProcessing($withdrawalId) {
        // 这里可以使用消息队列或其他异步处理机制
        // 示例：将任务添加到待处理队列
        try {
            // 假设使用Redis列表作为简单队列
            $queueKey = 'withdrawal_queue';
            $this-\u003ecache-\u003erpush($queueKey, $withdrawalId);
            $this-\u003elogger-\u003edebug("提现任务已加入队列: {$withdrawalId}");
        } catch (\Exception $e) {
            $this-\u003elogger-\u003ewarning('Failed to schedule withdrawal processing: ' . $e-\u003egetMessage());
        }
    }
    
    /**
     * 处理提现队列中的任务
     */
    public function processWithdrawalQueue() {
        try {
            $queueKey = 'withdrawal_queue';
            
            while (true) {
                // 从队列中获取任务
                $withdrawalId = $this-\u003ecache-\u003elpop($queueKey);
                if (!$withdrawalId) {
                    break;
                }
                
                // 处理提现
                $this-\u003eexecuteWithdrawalPayment($withdrawalId);
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Withdrawal queue processing failed: ' . $e-\u003egetMessage());
        }
    }
    
    /**
     * 执行提现支付
     * 
     * @param int $withdrawalId 提现ID
     */
    private function executeWithdrawalPayment($withdrawalId) {
        try {
            // 开始事务
            $this-\u003edb-\u003ebeginTransaction();
            
            try {
                // 获取提现信息
                $withdrawal = $this-\u003egetWithdrawalInfo($withdrawalId);
                if (!$withdrawal || $withdrawal['status'] !== 'pending') {
                    throw new \Exception("提现记录无效或已处理");
                }
                
                // 更新状态为处理中
                $this-\u003eupdateWithdrawalStatus($withdrawalId, 'processing');
                
                // 提交事务
                $this-\u003edb-\u003ecommit();
                
                // 调用支付处理
                $paymentResult = $this-\u003eprocessPayment($withdrawal);
                
                if ($paymentResult['success']) {
                    // 支付成功
                    $this-\u003efinalizeSuccessfulWithdrawal($withdrawalId, $paymentResult['transaction_id']);
                } else {
                    // 支付失败
                    $this-\u003ehandleFailedWithdrawal($withdrawalId, $paymentResult['error']);
                }
            } catch (\Exception $e) {
                $this-\u003edb-\u003erollBack();
                throw $e;
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror("提现支付执行失败: ID={$withdrawalId}, 错误={$e-\u003egetMessage()}");
        }
    }
    
    /**
     * 处理支付
     * 
     * @param array $withdrawal 提现信息
     * @return array 支付结果
     */
    private function processPayment($withdrawal) {
        try {
            if ($this-\u003epaymentProcessor) {
                return $this-\u003epaymentProcessor-\u003eprocessPayout([
                    'amount' =\u003e $withdrawal['actual_amount'],
                    'currency' =\u003e 'CNY',
                    'payment_method' =\u003e $withdrawal['payment_method'],
                    'payment_account' =\u003e $withdrawal['payment_account'],
                    'description' =\u003e "代理提现 - ID: {$withdrawal['id']}",
                    'reference_id' =\u003e $withdrawal['id']
                ]);
            }
            
            // 模拟支付处理
            // 在实际环境中应该替换为真实的支付接口调用
            return [
                'success' =\u003e true,
                'transaction_id' =\u003e 'TX' . date('YmdHis') . rand(1000, 9999),
                'message' =\u003e '支付处理成功'
            ];
        } catch (\Exception $e) {
            return [
                'success' =\u003e false,
                'error' =\u003e $e-\u003egetMessage()
            ];
        }
    }
    
    /**
     * 完成成功的提现
     * 
     * @param int $withdrawalId 提现ID
     * @param string $transactionId 交易ID
     */
    private function finalizeSuccessfulWithdrawal($withdrawalId, $transactionId) {
        try {
            // 开始事务
            $this-\u003edb-\u003ebeginTransaction();
            
            try {
                // 更新提现状态
                $this-\u003eupdateWithdrawalStatus($withdrawalId, 'completed', $transactionId);
                
                // 获取提现信息
                $withdrawal = $this-\u003egetWithdrawalInfo($withdrawalId);
                
                // 扣除冻结余额
                $this-\u003eunfreezeAffiliateBalance($withdrawal['affiliate_id'], $withdrawal['amount']);
                
                // 提交事务
                $this-\u003edb-\u003ecommit();
                
                // 发送通知
                $this-\u003esendWithdrawalCompletedNotification($withdrawal);
                
                $this-\u003elogger-\u003einfo("提现支付成功: ID={$withdrawalId}, 交易ID={$transactionId}");
            } catch (\Exception $e) {
                $this-\u003edb-\u003erollBack();
                throw $e;
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror("提现完成处理失败: ID={$withdrawalId}, 错误={$e-\u003egetMessage()}");
        }
    }
    
    /**
     * 处理失败的提现
     * 
     * @param int $withdrawalId 提现ID
     * @param string $error 错误信息
     */
    private function handleFailedWithdrawal($withdrawalId, $error) {
        try {
            // 开始事务
            $this-\u003edb-\u003ebeginTransaction();
            
            try {
                // 获取提现信息
                $withdrawal = $this-\u003egetWithdrawalInfo($withdrawalId);
                
                // 更新提现状态
                $this-\u003eupdateWithdrawalStatus($withdrawalId, 'failed', null, $error);
                
                // 解冻余额
                $this-\u003eunfreezeAffiliateBalance($withdrawal['affiliate_id'], $withdrawal['amount']);
                
                // 恢复可用余额
                $this-\u003erestoreAffiliateBalance($withdrawal['affiliate_id'], $withdrawal['amount']);
                
                // 提交事务
                $this-\u003edb-\u003ecommit();
                
                // 发送通知
                $this-\u003esendWithdrawalFailedNotification($withdrawal, $error);
                
                $this-\u003elogger-\u003ewarning("提现支付失败: ID={$withdrawalId}, 错误={$error}");
            } catch (\Exception $e) {
                $this-\u003edb-\u003erollBack();
                throw $e;
            }
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror("提现失败处理失败: ID={$withdrawalId}, 错误={$e-\u003egetMessage()}");
        }
    }
    
    /**
     * 获取提现信息
     * 
     * @param int $withdrawalId 提现ID
     * @return array|null
     */
    private function getWithdrawalInfo($withdrawalId) {
        try {
            $query = "SELECT * FROM withdrawal_requests WHERE id = :id";
            $stmt = $this-\u003edb-\u003eprepare($query);
            $stmt-\u003ebindParam(':id', $withdrawalId);
            $stmt-\u003eexecute();
            return $stmt-\u003efetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to get withdrawal info: ' . $e-\u003egetMessage());
            return null;
        }
    }
    
    /**
     * 更新提现状态
     * 
     * @param int $withdrawalId 提现ID
     * @param string $status 状态
     * @param string $transactionId 交易ID
     * @param string $notes 备注
     */
    private function updateWithdrawalStatus($withdrawalId, $status, $transactionId = null, $notes = null) {
        try {
            $query = "UPDATE withdrawal_requests 
                     SET status = :status, 
                         transaction_id = :transaction_id, 
                         admin_notes = :notes, 
                         processed_at = NOW(), 
                         updated_at = NOW() 
                     WHERE id = :id";
            $stmt = $this-\u003edb-\u003eprepare($query);
            
            $stmt-\u003ebindParam(':status', $status);
            $stmt-\u003ebindParam(':transaction_id', $transactionId);
            $stmt-\u003ebindParam(':notes', $notes);
            $stmt-\u003ebindParam(':id', $withdrawalId);
            $stmt-\u003eexecute();
        } catch (\Exception $e) {
            $this-\u003elogger-\u003eerror('Failed to update withdrawal status: ' . $e-\u003egetMessage());
            throw $e;
        }
    }
    
    /**
     * 解冻余额
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     */
    private function unfreezeAffiliateBalance($affiliateId, $amount) {
        try {
            $query = "UPDATE affiliates 
                     SET frozen_balance = frozen_balance - :amount, 
                         updated_at = NOW() 
                     WHERE id = :id AND frozen_balance >= :amount";
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':amount', $amount);
            $stmt->bindParam(':id', $affiliateId);
            $stmt->execute();
        } catch (\Exception $e) {
            $this->logger->error('Failed to unfreeze affiliate balance: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 恢复代理余额
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     */
    private function restoreAffiliateBalance($affiliateId, $amount) {
        try {
            $query = "UPDATE affiliates 
                     SET available_balance = available_balance + :amount, 
                         updated_at = NOW() 
                     WHERE id = :id";
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':amount', $amount);
            $stmt->bindParam(':id', $affiliateId);
            $stmt->execute();
        } catch (\Exception $e) {
            $this->logger->error('Failed to restore affiliate balance: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 发送结算通知
     * 
     * @param int $affiliateId 代理ID
     * @param array $result 结算结果
     * @param array $cycleInfo 结算周期信息
     */
    private function sendPayoutNotification($affiliateId, $result, $cycleInfo) {
        try {
            // 获取代理联系方式
            $affiliate = $this->getAffiliateInfo($affiliateId);
            if (!$affiliate) {
                throw new \Exception("代理信息不存在");
            }
            
            // 准备通知内容
            $notificationData = [
                'affiliate_id' => $affiliateId,
                'type' => 'commission_settlement',
                'title' => '佣金结算通知',
                'content' => "尊敬的代理商，您在{$cycleInfo['cycle_name']}（{$cycleInfo['start_date']}至{$cycleInfo['end_date']}）的佣金已结算成功，金额：¥{$result['amount']}，已自动加入您的可用余额。",
                'user_email' => $affiliate['email'],
                'user_phone' => $affiliate['phone'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 发送通知（可以通过消息队列异步处理）
            $this->sendNotification($notificationData);
            
        } catch (\Exception $e) {
            $this->logger->warning('Failed to send payout notification: ' . $e->getMessage());
        }
    }
    
    /**
     * 发送提现成功通知
     * 
     * @param array $withdrawal 提现信息
     */
    private function sendWithdrawalCompletedNotification($withdrawal) {
        try {
            // 获取代理联系方式
            $affiliate = $this->getAffiliateInfo($withdrawal['affiliate_id']);
            if (!$affiliate) {
                throw new \Exception("代理信息不存在");
            }
            
            // 准备通知内容
            $notificationData = [
                'affiliate_id' => $withdrawal['affiliate_id'],
                'type' => 'withdrawal_completed',
                'title' => '提现成功通知',
                'content' => "尊敬的代理商，您的提现申请（ID:{$withdrawal['id']}）已处理成功，金额：¥{$withdrawal['actual_amount']}，手续费：¥{$withdrawal['fee']}，预计1-3个工作日到账。",
                'user_email' => $affiliate['email'],
                'user_phone' => $affiliate['phone'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 发送通知
            $this->sendNotification($notificationData);
            
        } catch (\Exception $e) {
            $this->logger->warning('Failed to send withdrawal completed notification: ' . $e->getMessage());
        }
    }
    
    /**
     * 发送提现失败通知
     * 
     * @param array $withdrawal 提现信息
     * @param string $error 错误信息
     */
    private function sendWithdrawalFailedNotification($withdrawal, $error) {
        try {
            // 获取代理联系方式
            $affiliate = $this->getAffiliateInfo($withdrawal['affiliate_id']);
            if (!$affiliate) {
                throw new \Exception("代理信息不存在");
            }
            
            // 准备通知内容
            $notificationData = [
                'affiliate_id' => $withdrawal['affiliate_id'],
                'type' => 'withdrawal_failed',
                'title' => '提现失败通知',
                'content' => "尊敬的代理商，您的提现申请（ID:{$withdrawal['id']}）处理失败，原因：{$error}。资金已自动退回您的账户，您可以稍后重新申请提现。",
                'user_email' => $affiliate['email'],
                'user_phone' => $affiliate['phone'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 发送通知
            $this->sendNotification($notificationData);
            
        } catch (\Exception $e) {
            $this->logger->warning('Failed to send withdrawal failed notification: ' . $e->getMessage());
        }
    }
    
    /**
     * 发送通知（抽象方法，可以集成到消息队列或通知系统）
     * 
     * @param array $notificationData 通知数据
     */
    private function sendNotification($notificationData) {
        try {
            // 这里可以调用实际的通知系统或消息队列
            // 简单示例：记录通知到数据库
            $query = "INSERT INTO affiliate_notifications (affiliate_id, type, title, content, 
                     user_email, user_phone, status, created_at) 
                     VALUES (:affiliate_id, :type, :title, :content, 
                     :user_email, :user_phone, 'pending', NOW())";
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':affiliate_id', $notificationData['affiliate_id']);
            $stmt->bindParam(':type', $notificationData['type']);
            $stmt->bindParam(':title', $notificationData['title']);
            $stmt->bindParam(':content', $notificationData['content']);
            $stmt->bindParam(':user_email', $notificationData['user_email']);
            $stmt->bindParam(':user_phone', $notificationData['user_phone']);
            $stmt->execute();
            
            $notificationId = $this->db->lastInsertId();
            
            // 异步处理实际发送（可以通过消息队列）
            $this->scheduleNotificationSending($notificationId);
            
        } catch (\Exception $e) {
            $this->logger->error('Failed to send notification: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 调度通知发送
     * 
     * @param int $notificationId 通知ID
     */
    private function scheduleNotificationSending($notificationId) {
        try {
            // 使用Redis列表作为简单队列
            $queueKey = 'notification_queue';
            $this->cache->rpush($queueKey, $notificationId);
            $this->logger->debug("通知任务已加入队列: {$notificationId}");
        } catch (\Exception $e) {
            $this->logger->warning('Failed to schedule notification sending: ' . $e->getMessage());
        }
    }
    
    /**
     * 生成代理业绩统计报表
     * 
     * @param array $filters 过滤条件
     * @return array 统计数据
     */
    public function generatePerformanceReport($filters) {
        try {
            $query = "SELECT 
                        a.id as affiliate_id, 
                        a.username, 
                        a.level_id, 
                        al.level_name,
                        COUNT(DISTINCT cr.id) as order_count,
                        SUM(cr.amount) as total_commission,
                        SUM(CASE WHEN cr.commission_type = 'direct' THEN cr.amount ELSE 0 END) as direct_commission,
                        SUM(CASE WHEN cr.commission_type = 'indirect' THEN cr.amount ELSE 0 END) as indirect_commission,
                        COUNT(DISTINCT CASE WHEN cr.status = 'approved' THEN cr.id END) as approved_count,
                        SUM(CASE WHEN cr.status = 'approved' THEN cr.amount ELSE 0 END) as approved_commission,
                        COUNT(DISTINCT CASE WHEN cr.status = 'pending' THEN cr.id END) as pending_count,
                        SUM(CASE WHEN cr.status = 'pending' THEN cr.amount ELSE 0 END) as pending_commission,
                        COUNT(DISTINCT w.id) as withdrawal_count,
                        SUM(CASE WHEN w.status = 'completed' THEN w.amount ELSE 0 END) as withdrawal_amount,
                        COUNT(DISTINCT CASE WHEN w.status = 'completed' THEN w.id END) as completed_withdrawals,
                        (SELECT COUNT(*) FROM affiliate_teams WHERE parent_id = a.id AND status = 'active') as team_count
                    FROM affiliates a
                    LEFT JOIN affiliate_levels al ON a.level_id = al.id
                    LEFT JOIN commission_records cr ON a.id = cr.affiliate_id
                    LEFT JOIN withdrawal_requests w ON a.id = w.affiliate_id
                    WHERE 1=1";
            
            // 添加过滤条件
            $params = [];
            
            if (!empty($filters['start_date'])) {
                $query .= " AND cr.created_at >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND cr.created_at <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            if (!empty($filters['affiliate_id'])) {
                $query .= " AND a.id = :affiliate_id";
                $params[':affiliate_id'] = $filters['affiliate_id'];
            }
            
            if (!empty($filters['level_id'])) {
                $query .= " AND a.level_id = :level_id";
                $params[':level_id'] = $filters['level_id'];
            }
            
            if (!empty($filters['status'])) {
                $query .= " AND cr.status = :status";
                $params[':status'] = $filters['status'];
            }
            
            // 分组和排序
            $query .= " GROUP BY a.id";
            
            if (!empty($filters['order_by'])) {
                $query .= " ORDER BY " . $filters['order_by'];
                if (!empty($filters['order_dir'])) {
                    $query .= " " . $filters['order_dir'];
                }
            } else {
                $query .= " ORDER BY total_commission DESC";
            }
            
            // 分页
            $page = $filters['page'] ?? 1;
            $pageSize = $filters['page_size'] ?? 20;
            $offset = ($page - 1) * $pageSize;
            $query .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = $pageSize;
            $params[':offset'] = $offset;
            
            // 执行查询
            $stmt = $this->db->prepare($query);
            
            // 绑定参数
            foreach ($params as $param => $value) {
                $paramType = PDO::PARAM_STR;
                if (is_numeric($value)) {
                    $paramType = PDO::PARAM_INT;
                }
                $stmt->bindValue($param, $value, $paramType);
            }
            
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 获取总数
            $totalQuery = "SELECT COUNT(*) FROM (
                            SELECT 1 FROM affiliates a
                            LEFT JOIN commission_records cr ON a.id = cr.affiliate_id
                            WHERE 1=1";
            
            // 复制过滤条件
            $totalParams = [];
            foreach (array_slice($params, 0, -2) as $param => $value) { // 排除分页参数
                $totalQuery .= str_replace(":", "'", str_replace($param, $value, $query));
                $totalParams[$param] = $value;
            }
            
            $totalQuery .= " GROUP BY a.id) as t";
            
            $totalStmt = $this->db->prepare($totalQuery);
            
            // 绑定参数
            foreach ($totalParams as $param => $value) {
                $paramType = PDO::PARAM_STR;
                if (is_numeric($value)) {
                    $paramType = PDO::PARAM_INT;
                }
                $totalStmt->bindValue($param, $value, $paramType);
            }
            
            $totalStmt->execute();
            $totalCount = $totalStmt->fetchColumn();
            
            return [
                'data' => $results,
                'total' => $totalCount,
                'page' => $page,
                'page_size' => $pageSize,
                'total_pages' => ceil($totalCount / $pageSize)
            ];
            
        } catch (\Exception $e) {
            $this->logger->error('Failed to generate performance report: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 生成佣金趋势图数据
     * 
     * @param array $filters 过滤条件
     * @return array 趋势数据
     */
    public function generateCommissionTrendData($filters) {
        try {
            $groupBy = $filters['group_by'] ?? 'day'; // day, week, month
            $startDate = $filters['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $endDate = $filters['end_date'] ?? date('Y-m-d');
            $affiliateId = $filters['affiliate_id'] ?? null;
            
            // 根据分组类型设置日期格式
            $dateFormat = '%Y-%m-%d'; // 默认按天
            switch ($groupBy) {
                case 'week':
                    $dateFormat = '%Y-%u'; // 年-周
                    break;
                case 'month':
                    $dateFormat = '%Y-%m'; // 年-月
                    break;
            }
            
            $query = "SELECT 
                        DATE_FORMAT(cr.created_at, :date_format) as period,
                        COUNT(*) as order_count,
                        SUM(cr.amount) as total_commission,
                        SUM(CASE WHEN cr.commission_type = 'direct' THEN cr.amount ELSE 0 END) as direct_commission,
                        SUM(CASE WHEN cr.commission_type = 'indirect' THEN cr.amount ELSE 0 END) as indirect_commission,
                        COUNT(DISTINCT cr.affiliate_id) as affiliate_count,
                        SUM(CASE WHEN cr.status = 'approved' THEN cr.amount ELSE 0 END) as approved_commission,
                        SUM(CASE WHEN cr.status = 'pending' THEN cr.amount ELSE 0 END) as pending_commission
                    FROM commission_records cr
                    WHERE cr.created_at BETWEEN :start_date AND :end_date";
            
            $params = [
                ':date_format' => $dateFormat,
                ':start_date' => $startDate . ' 00:00:00',
                ':end_date' => $endDate . ' 23:59:59'
            ];
            
            if (!empty($affiliateId)) {
                $query .= " AND cr.affiliate_id = :affiliate_id";
                $params[':affiliate_id'] = $affiliateId;
            }
            
            $query .= " GROUP BY period ORDER BY period";
            
            $stmt = $this->db->prepare($query);
            
            // 绑定参数
            foreach ($params as $param => $value) {
                $paramType = PDO::PARAM_STR;
                if (is_numeric($value)) {
                    $paramType = PDO::PARAM_INT;
                }
                $stmt->bindValue($param, $value, $paramType);
            }
            
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $results;
            
        } catch (\Exception $e) {
            $this->logger->error('Failed to generate commission trend data: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取代理余额详情
     * 
     * @param int $affiliateId 代理ID
     * @return array 余额信息
     */
    public function getAffiliateBalanceInfo($affiliateId) {
        try {
            $query = "SELECT 
                        a.id as affiliate_id,
                        a.username,
                        a.available_balance,
                        a.frozen_balance,
                        (a.available_balance + a.frozen_balance) as total_balance,
                        a.total_commission,
                        a.total_withdrawal,
                        (SELECT SUM(amount) FROM withdrawal_requests 
                         WHERE affiliate_id = a.id AND status = 'pending') as pending_withdrawal,
                        (SELECT COUNT(*) FROM withdrawal_requests 
                         WHERE affiliate_id = a.id AND status = 'completed') as withdrawal_count,
                        (SELECT COUNT(*) FROM commission_records 
                         WHERE affiliate_id = a.id AND status = 'approved') as approved_commission_count,
                        (SELECT SUM(amount) FROM commission_records 
                         WHERE affiliate_id = a.id AND status = 'approved') as approved_commission_amount,
                        (SELECT SUM(amount) FROM commission_records 
                         WHERE affiliate_id = a.id AND status = 'pending') as pending_commission_amount
                    FROM affiliates a
                    WHERE a.id = :affiliate_id";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':affiliate_id', $affiliateId);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$result) {
                throw new \Exception("代理不存在或无余额记录");
            }
            
            return $result;
            
        } catch (\Exception $e) {
            $this->logger->error('Failed to get affiliate balance info: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取结算周期列表
     * 
     * @param array $filters 过滤条件
     * @return array 结算周期列表
     */
    public function getSettlementCycles($filters = []) {
        try {
            $query = "SELECT c.*,
                        (SELECT COUNT(*) FROM commission_payout_details d WHERE d.cycle_id = c.id) as detail_count,
                        (SELECT SUM(d.payout_amount) FROM commission_payout_details d WHERE d.cycle_id = c.id) as total_amount,
                        (SELECT COUNT(DISTINCT d.affiliate_id) FROM commission_payout_details d WHERE d.cycle_id = c.id) as affiliate_count
                    FROM commission_payout_cycles c
                    WHERE 1=1";
            
            $params = [];
            
            if (!empty($filters['status'])) {
                $query .= " AND c.status = :status";
                $params[':status'] = $filters['status'];
            }
            
            if (!empty($filters['start_date'])) {
                $query .= " AND c.start_date >= :start_date";
                $params[':start_date'] = $filters['start_date'];
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND c.end_date <= :end_date";
                $params[':end_date'] = $filters['end_date'];
            }
            
            $query .= " ORDER BY c.id DESC";
            
            // 分页
            if (!empty($filters['page']) && !empty($filters['page_size'])) {
                $offset = ($filters['page'] - 1) * $filters['page_size'];
                $query .= " LIMIT :limit OFFSET :offset";
                $params[':limit'] = $filters['page_size'];
                $params[':offset'] = $offset;
            }
            
            $stmt = $this->db->prepare($query);
            
            // 绑定参数
            foreach ($params as $param => $value) {
                $paramType = PDO::PARAM_STR;
                if (is_numeric($value)) {
                    $paramType = PDO::PARAM_INT;
                }
                $stmt->bindValue($param, $value, $paramType);
            }
            
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $results;
            
        } catch (\Exception $e) {
            $this->logger->error('Failed to get settlement cycles: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取提现历史记录
     * 
     * @param array $filters 过滤条件
     * @return array 提现记录
     */
    public function getWithdrawalHistory($filters = []) {
        try {
            $query = "SELECT w.*, a.username, a.email, a.phone
                    FROM withdrawal_requests w
                    LEFT JOIN affiliates a ON w.affiliate_id = a.id
                    WHERE 1=1";
            
            $params = [];
            
            if (!empty($filters['affiliate_id'])) {
                $query .= " AND w.affiliate_id = :affiliate_id";
                $params[':affiliate_id'] = $filters['affiliate_id'];
            }
            
            if (!empty($filters['status'])) {
                $query .= " AND w.status = :status";
                $params[':status'] = $filters['status'];
            }
            
            if (!empty($filters['start_date'])) {
                $query .= " AND w.created_at >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND w.created_at <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            if (!empty($filters['payment_method'])) {
                $query .= " AND w.payment_method = :payment_method";
                $params[':payment_method'] = $filters['payment_method'];
            }
            
            $query .= " ORDER BY w.id DESC";
            
            // 分页
            if (!empty($filters['page']) && !empty($filters['page_size'])) {
                $offset = ($filters['page'] - 1) * $filters['page_size'];
                $query .= " LIMIT :limit OFFSET :offset";
                $params[':limit'] = $filters['page_size'];
                $params[':offset'] = $offset;
            }
            
            $stmt = $this->db->prepare($query);
            
            // 绑定参数
            foreach ($params as $param => $value) {
                $paramType = PDO::PARAM_STR;
                if (is_numeric($value)) {
                    $paramType = PDO::PARAM_INT;
                }
                $stmt->bindValue($param, $value, $paramType);
            }
            
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 获取总数
            $totalQuery = "SELECT COUNT(*) FROM withdrawal_requests WHERE 1=1";
            $totalParams = [];
            
            foreach (array_slice($params, 0, -2) as $param => $value) { // 排除分页参数
                $totalQuery .= str_replace(":", "'", str_replace($param, $value, $query));
                $totalParams[$param] = $value;
            }
            
            $totalStmt = $this->db->prepare($totalQuery);
            
            // 绑定参数
            foreach ($totalParams as $param => $value) {
                $paramType = PDO::PARAM_STR;
                if (is_numeric($value)) {
                    $paramType = PDO::PARAM_INT;
                }
                $totalStmt->bindValue($param, $value, $paramType);
            }
            
            $totalStmt->execute();
            $totalCount = $totalStmt->fetchColumn();
            
            return [
                'data' => $results,
                'total' => $totalCount,
                'page' => $filters['page'] ?? 1,
                'page_size' => $filters['page_size'] ?? 20,
                'total_pages' => ceil($totalCount / ($filters['page_size'] ?? 20))
            ];
            
        } catch (\Exception $e) {
            $this->logger->error('Failed to get withdrawal history: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 手动结算指定代理的佣金
     * 
     * @param array $params 结算参数
     * @return array 结算结果
     */
    public function manualSettlement($params) {
        try {
            $affiliateId = $params['affiliate_id'];
            $startDate = $params['start_date'] ?? null;
            $endDate = $params['end_date'] ?? null;
            $adminId = $params['admin_id'] ?? null;
            $adminNotes = $params['admin_notes'] ?? null;
            
            // 开始事务
            $this->db->beginTransaction();
            
            try {
                // 获取待结算的佣金记录
                $query = "SELECT * FROM commission_records 
                         WHERE affiliate_id = :affiliate_id AND status = 'pending'";
                
                $queryParams = [':affiliate_id' => $affiliateId];
                
                if ($startDate) {
                    $query .= " AND created_at >= :start_date";
                    $queryParams[':start_date'] = $startDate . ' 00:00:00';
                }
                
                if ($endDate) {
                    $query .= " AND created_at <= :end_date";
                    $queryParams[':end_date'] = $endDate . ' 23:59:59';
                }
                
                $stmt = $this->db->prepare($query);
                
                // 绑定参数
                foreach ($queryParams as $param => $value) {
                    $paramType = PDO::PARAM_STR;
                    if (is_numeric($value)) {
                        $paramType = PDO::PARAM_INT;
                    }
                    $stmt->bindValue($param, $value, $paramType);
                }
                
                $stmt->execute();
                $commissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (empty($commissions)) {
                    throw new \Exception("没有可结算的佣金记录");
                }
                
                // 计算总金额
                $totalAmount = 0;
                foreach ($commissions as $commission) {
                    $totalAmount += $commission['amount'];
                }
                
                // 创建手动结算记录
                $query = "INSERT INTO manual_settlements (affiliate_id, admin_id, start_date, end_date, 
                         amount, commission_count, admin_notes, status, created_at) 
                         VALUES (:affiliate_id, :admin_id, :start_date, :end_date, 
                         :amount, :commission_count, :admin_notes, 'completed', NOW())";
                $stmt = $this->db->prepare($query);
                
                $stmt->bindParam(':affiliate_id', $affiliateId);
                $stmt->bindParam(':admin_id', $adminId);
                $stmt->bindParam(':start_date', $startDate);
                $stmt->bindParam(':end_date', $endDate);
                $stmt->bindParam(':amount', $totalAmount);
                $stmt->bindParam(':commission_count', count($commissions));
                $stmt->bindParam(':admin_notes', $adminNotes);
                $stmt->execute();
                
                $settlementId = $this->db->lastInsertId();
                
                // 更新佣金记录状态
                $commissionIds = [];
                foreach ($commissions as $commission) {
                    $commissionIds[] = $commission['id'];
                }
                
                if (!empty($commissionIds)) {
                    $idsString = implode(',', $commissionIds);
                    $query = "UPDATE commission_records SET status = 'approved', approved_at = NOW(), 
                             approved_by = :admin_id, settlement_id = :settlement_id 
                             WHERE id IN ({$idsString})";
                    $stmt = $this->db->prepare($query);
                    $stmt->bindParam(':admin_id', $adminId);
                    $stmt->bindParam(':settlement_id', $settlementId);
                    $stmt->execute();
                }
                
                // 更新代理余额
                $this->updateAffiliateBalance($affiliateId, $totalAmount);
                
                // 提交事务
                $this->db->commit();
                
                // 发送通知
                $this->sendManualSettlementNotification($affiliateId, $totalAmount, $startDate, $endDate);
                
                return [
                    'success' => true,
                    'settlement_id' => $settlementId,
                    'affiliate_id' => $affiliateId,
                    'amount' => $totalAmount,
                    'commission_count' => count($commissions),
                    'status' => 'completed'
                ];
                
            } catch (\Exception $e) {
                $this->db->rollBack();
                throw $e;
            }
            
        } catch (\Exception $e) {
            $this->logger->error('Manual settlement failed: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 发送手动结算通知
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     * @param string $startDate 开始日期
     * @param string $endDate 结束日期
     */
    private function sendManualSettlementNotification($affiliateId, $amount, $startDate, $endDate) {
        try {
            // 获取代理联系方式
            $affiliate = $this->getAffiliateInfo($affiliateId);
            if (!$affiliate) {
                throw new \Exception("代理信息不存在");
            }
            
            // 准备通知内容
            $notificationData = [
                'affiliate_id' => $affiliateId,
                'type' => 'manual_commission_settlement',
                'title' => '手动佣金结算通知',
                'content' => "尊敬的代理商，您有一笔手动佣金结算已完成，金额：¥{$amount}，结算周期：{$startDate}至{$endDate}，已自动加入您的可用余额。",
                'user_email' => $affiliate['email'],
                'user_phone' => $affiliate['phone'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 发送通知
            $this->sendNotification($notificationData);
            
        } catch (\Exception $e) {
            $this->logger->warning('Failed to send manual settlement notification: ' . $e->getMessage());
        }
    }
    
    /**
     * 执行系统定时任务：自动结算
     * 
     * @param array $options 选项
     */
    public function runScheduledSettlement($options = []) {
        try {
            $this->logger->info("开始执行定时结算任务");
            
            // 根据配置确定结算周期
            $cycleType = $this->config['settlement_cycle'] ?? 'monthly';
            
            // 创建结算周期
            $cycleId = $this->createSettlementCycle($cycleType);
            
            // 执行结算
            $result = $this->performSettlement($cycleId);
            
            $this->logger->info("定时结算任务完成: 周期ID={$cycleId}, 处理代理数={$result['processed_count']}, 总金额={$result['total_amount']}");
            
            // 生成结算报告（可以通过邮件或其他方式发送）
            $this->generateSettlementReport($cycleId);
            
            return $result;
            
        } catch (\Exception $e) {
            $this->logger->error('Scheduled settlement failed: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 生成结算报告
     * 
     * @param int $cycleId 结算周期ID
     */
    private function generateSettlementReport($cycleId) {
        try {
            // 获取结算周期信息
            $cycleInfo = $this->getSettlementCycleInfo($cycleId);
            if (!$cycleInfo) {
                throw new \Exception("结算周期不存在");
            }
            
            // 获取结算详情
            $query = "SELECT * FROM commission_payout_details WHERE cycle_id = :cycle_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':cycle_id', $cycleId);
            $stmt->execute();
            $details = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 生成报告数据
            $reportData = [
                'cycle_id' => $cycleId,
                'cycle_name' => $cycleInfo['cycle_name'],
                'start_date' => $cycleInfo['start_date'],
                'end_date' => $cycleInfo['end_date'],
                'generated_at' => date('Y-m-d H:i:s'),
                'total_affiliates' => count($details),
                'total_amount' => array_sum(array_column($details, 'payout_amount')),
                'details' => $details
            ];
            
            // 保存报告（可以保存到文件或数据库）
            $reportJson = json_encode($reportData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            $reportFileName = "settlement_report_{$cycleId}_{$cycleInfo['cycle_name']}.json";
            
            // 示例：保存到数据库
            $query = "INSERT INTO settlement_reports (cycle_id, report_data, report_file, generated_at) 
                     VALUES (:cycle_id, :report_data, :report_file, NOW())";
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':cycle_id', $cycleId);
            $stmt->bindParam(':report_data', $reportJson);
            $stmt->bindParam(':report_file', $reportFileName);
            $stmt->execute();
            
            $reportId = $this->db->lastInsertId();
            
            // 可以在这里添加邮件发送逻辑
            $this->logger->info("结算报告已生成: ID={$reportId}, 文件名={$reportFileName}");
            
            return $reportId;
            
        } catch (\Exception $e) {
            $this->logger->warning('Failed to generate settlement report: ' . $e->getMessage());
        }
    }
    
    /**
     * 代理佣金管理系统的健康检查
     * 
     * @return array 健康状态
     */
    public function healthCheck() {
        try {
            $status = [
                'database_connected' => true,
                'cache_available' => true,
                'payment_processor_available' => true,
                'latest_settlement_cycle' => null,
                'pending_settlement_count' => 0,
                'pending_withdrawals_count' => 0,
                'system_time' => date('Y-m-d H:i:s'),
                'errors' => []
            ];
            
            // 检查数据库连接
            try {
                $stmt = $this->db->prepare("SELECT 1");
                $stmt->execute();
            } catch (\Exception $e) {
                $status['database_connected'] = false;
                $status['errors'][] = "数据库连接失败: " . $e->getMessage();
            }
            
            // 检查缓存连接
            try {
                $this->cache->set('health_check', 'ok', 5);
                if ($this->cache->get('health_check') !== 'ok') {
                    throw new \Exception("缓存读取失败");
                }
            } catch (\Exception $e) {
                $status['cache_available'] = false;
                $status['errors'][] = "缓存服务不可用: " . $e->getMessage();
            }
            
            // 检查支付处理器
            try {
                if (!$this->paymentProcessor || !$this->paymentProcessor->isAvailable()) {
                    throw new \Exception("支付处理器不可用");
                }
            } catch (\Exception $e) {
                $status['payment_processor_available'] = false;
                $status['errors'][] = "支付处理器不可用: " . $e->getMessage();
            }
            
            // 获取最新结算周期
            try {
                $query = "SELECT * FROM commission_payout_cycles ORDER BY id DESC LIMIT 1";
                $stmt = $this->db->query($query);
                $status['latest_settlement_cycle'] = $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (\Exception $e) {
                $status['errors'][] = "获取最新结算周期失败: " . $e->getMessage();
            }
            
            // 获取待结算佣金数量
            try {
                $query = "SELECT COUNT(*) FROM commission_records WHERE status = 'pending'";
                $stmt = $this->db->query($query);
                $status['pending_settlement_count'] = $stmt->fetchColumn();
            } catch (\Exception $e) {
                $status['errors'][] = "获取待结算佣金数量失败: " . $e->getMessage();
            }
            
            // 获取待处理提现数量
            try {
                $query = "SELECT COUNT(*) FROM withdrawal_requests WHERE status = 'pending'";
                $stmt = $this->db->query($query);
                $status['pending_withdrawals_count'] = $stmt->fetchColumn();
            } catch (\Exception $e) {
                $status['errors'][] = "获取待处理提现数量失败: " . $e->getMessage();
            }
            
            // 整体状态
            $status['overall_status'] = count($status['errors']) === 0 ? 'ok' : 'warning';
            
            return $status;
            
        } catch (\Exception $e) {
            $this->logger->error('Health check failed: ' . $e->getMessage());
            return [
                'overall_status' => 'error',
                'system_time' => date('Y-m-d H:i:s'),
                'errors' => ["系统健康检查失败: " . $e->getMessage()]
            ];
        }
    }
}

// 类结束
?>