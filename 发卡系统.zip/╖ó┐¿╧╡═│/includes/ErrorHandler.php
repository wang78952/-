<?php
/**
 * 高级错误处理和日志系统
 * 统一异常处理、错误报告、监控告警、安全日志
 */

// 引入必要的依赖
require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/SecurityConfig.php';
require_once __DIR__ . '/ErrorLevel.php';
require_once __DIR__ . '/LogManager.php';
require_once __DIR__ . '/exceptions/LogException.php';
require_once __DIR__ . '/SecurityUtils.php';
require_once __DIR__ . '/Config.php';

/**
 * 错误处理器类
 */
class ErrorHandler {
    /**
     * 错误处理级别常量
     */
    const HANDLER_LEVEL_BASIC = 1;
    const HANDLER_LEVEL_ADVANCED = 2;
    const HANDLER_LEVEL_SECURITY = 3;
    const HANDLER_LEVEL_COMPREHENSIVE = 4;
    
    /**
     * 单例实例
     */
    private static $instance = null;
    
    /**
     * 日志管理器实例
     */
    private $logManager;
    
    /**
     * 配置实例
     */
    private $config;
    
    /**
     * 错误处理级别
     */
    private $handlerLevel;
    
    /**
     * 是否启用详细错误报告
     */
    private $detailedErrors;
    
    /**
     * 安全配置
     */
    private $securityConfig;
    
    /**
     * 已处理的错误ID缓存，防止重复报告
     */
    private $processedErrors = [];
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        try {
            // 初始化配置
            $this->config = Config::getInstance();
            
            // 获取安全配置
            $this->securityConfig = SecurityConfig::getInstance();
            
            // 初始化日志管理器
            $this->logManager = LogManager::getInstance();
            
            // 设置处理级别
            $this->handlerLevel = $this->config->get('error_handler.level', self::HANDLER_LEVEL_COMPREHENSIVE);
            
            // 是否启用详细错误报告
            $this->detailedErrors = !IS_PRODUCTION || $this->config->get('error_handler.detailed', false);
            
            // 初始化日志系统
            $this->initializeLogging();
            
            // 设置错误处理器
            $this->setupErrorHandlers();
            
            // 记录初始化信息
            $this->logManager->logSystem('info', '错误处理器初始化完成', ['level' => $this->handlerLevel]);
        } catch (Exception $e) {
            // 紧急错误处理，直接输出
            echo "初始化错误处理器失败: " . $e->getMessage() . PHP_EOL;
            die();
        }
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化日志系统
     */
    private function initializeLogging() {
        try {
            $logDir = $this->config->get('log.directory', __DIR__ . '/../logs');
            
            // 确保日志目录存在
            if (!is_dir($logDir)) {
                mkdir($logDir, 0755, true);
            }
            
            // 设置适当的目录权限
            if (!SecurityUtils::hasProperPermissions($logDir, 0755)) {
                @chmod($logDir, 0755);
            }
        } catch (Exception $e) {
            throw new LogException(LogException::TYPE_CONFIG, '初始化日志目录失败', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * 设置错误处理器
     */
    private function setupErrorHandlers() {
        // 设置自定义错误处理器
        set_error_handler([$this, 'handleError']);
        
        // 设置异常处理器
        set_exception_handler([$this, 'handleException']);
        
        // 设置致命错误处理器
        register_shutdown_function([$this, 'handleFatalError']);
    }
    
    /**
     * 处理PHP错误
     */
    public function handleError($severity, $message, $file, $line) {
        // 检查是否应该处理此错误
        if (!(error_reporting() & $severity)) {
            return false;
        }
        
        // 生成错误唯一ID，防止重复处理
        $errorId = md5("{$severity}:{$message}:{$file}:{$line}");
        if (isset($this->processedErrors[$errorId])) {
            return false;
        }
        $this->processedErrors[$errorId] = true;
        
        // 映射PHP错误级别到自定义级别
        $errorTypes = [
            E_ERROR => ErrorLevel::ERROR,
            E_WARNING => ErrorLevel::WARNING,
            E_PARSE => ErrorLevel::CRITICAL,
            E_NOTICE => ErrorLevel::INFO,
            E_CORE_ERROR => ErrorLevel::CRITICAL,
            E_CORE_WARNING => ErrorLevel::WARNING,
            E_COMPILE_ERROR => ErrorLevel::CRITICAL,
            E_COMPILE_WARNING => ErrorLevel::WARNING,
            E_USER_ERROR => ErrorLevel::ERROR,
            E_USER_WARNING => ErrorLevel::WARNING,
            E_USER_NOTICE => ErrorLevel::INFO,
            E_STRICT => ErrorLevel::INFO,
            E_RECOVERABLE_ERROR => ErrorLevel::ERROR,
            E_DEPRECATED => ErrorLevel::INFO,
            E_USER_DEPRECATED => ErrorLevel::INFO
        ];
        
        $level = isset($errorTypes[$severity]) ? $errorTypes[$severity] : ErrorLevel::ERROR;
        
        // 构建错误上下文
        $context = array(
            'file' => $file,
            'line' => $line,
            'severity' => $severity,
            'error_id' => $errorId,
            'request_id' => $this->getRequestId(),
            'server' => $this->getCleanServerData(),
            'timestamp' => date('Y-m-d H:i:s')
        );
        
        // 高级级别时添加调用堆栈
        if ($this->handlerLevel >= self::HANDLER_LEVEL_ADVANCED) {
            $context['trace'] = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
        }
        
        // 记录错误
        $this->logError($level, $message, $context);
        
        // 返回true表示错误已处理
        return true;
    }
    
    /**
     * 处理未捕获的异常
     */
    public function handleException($exception) {
        try {
            // 生成异常唯一ID
            $exceptionId = md5($exception->getMessage() . ':' . $exception->getFile() . ':' . $exception->getLine());
            
            // 异常分类
            $exceptionType = get_class($exception);
            
            // 根据异常类型确定日志级别
            if ($exception instanceof LogException) {
                $level = ErrorLevel::CRITICAL;
                $context = array(
                    'exception_type' => $exceptionType,
                    'exception_id' => $exceptionId,
                    'error_code' => $exception->getType(),
                    'context' => $exception->getContext(),
                    'file' => $exception->getFile(),
                    'line' => $exception->getLine(),
                    'code' => $exception->getCode(),
                    'request_id' => $this->getRequestId(),
                    'timestamp' => date('Y-m-d H:i:s')
                );
            } else {
                // 普通异常
                $level = ErrorLevel::ERROR;
                $context = array(
                    'exception_type' => $exceptionType,
                    'exception_id' => $exceptionId,
                    'file' => $exception->getFile(),
                    'line' => $exception->getLine(),
                    'code' => $exception->getCode(),
                    'request_id' => $this->getRequestId(),
                    'timestamp' => date('Y-m-d H:i:s')
                );
                
                // 高级级别时添加完整堆栈
                if ($this->handlerLevel >= self::HANDLER_LEVEL_ADVANCED) {
                    $context['trace'] = $exception->getTrace();
                }
            }
            
            // 记录异常
            $this->logError($level, $exception->getMessage(), $context);
            
            // 显示错误页面
            $errorMessage = $this->detailedErrors ? $exception->getMessage() : '系统遇到了一个错误';
            $this->showErrorPage(500, '系统错误', $errorMessage);
            
            return true;
        } catch (Exception $e) {
            // 处理异常处理程序本身的异常
            echo "初始化错误处理器失败: " . $e->getMessage() . PHP_EOL;
            die();
            return true;
        }
    }
    
    /**
     * 处理致命错误
     */
    public function handleFatalError() {
        $error = error_get_last();
        if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
            try {
                // 致命错误ID
                $fatalErrorId = md5($error['message'] . ':' . $error['file'] . ':' . $error['line']);
                
                $context = array(
                    'error_id' => $fatalErrorId,
                    'file' => $error['file'],
                    'line' => $error['line'],
                    'type' => $error['type'],
                    'request_id' => $this->getRequestId(),
                    'server' => $this->getCleanServerData(),
                    'timestamp' => date('Y-m-d H:i:s')
                );
                
                // 记录致命错误
                $this->logError(ErrorLevel::CRITICAL, $error['message'], $context);
                
                // 发送紧急告警
                $this->sendAlert(ErrorLevel::CRITICAL, '致命错误', $error['message']);
                
                // 系统恢复措施
                $this->systemRecovery();
                
                $this->showErrorPage(500, '系统错误', '发生了致命错误，请联系管理员。');
                
            } catch (Exception $e) {
                // 紧急情况，直接输出
                file_put_contents('fatal-error-' . time() . '.log', 
                    '致命错误处理失败: ' . $e->getMessage() . PHP_EOL . 
                    '原始错误: ' . print_r($error, true), FILE_APPEND);
            }
        }
    }
    
    /**
     * 记录错误日志
     */
    public function logError($level, $message, $context = array()) {
        try {
            // 清理敏感信息
            $context = $this->cleanSensitiveData($context);
            
            // 根据日志级别确定LogManager方法
            switch ($level) {
                case ErrorLevel::CRITICAL:
                    $this->logManager->logSystem('critical', $message, $context);
                    
                    // 发送告警
                    if ($this->handlerLevel >= self::HANDLER_LEVEL_BASIC) {
                        $this->sendAlert($level, '错误告警', $message);
                    }
                    break;
                    
                case ErrorLevel::ERROR:
                    $this->logManager->logSystem('error', $message, $context);
                    
                    // 发送告警
                    if ($this->handlerLevel >= self::HANDLER_LEVEL_COMPREHENSIVE) {
                        $this->sendAlert($level, '错误告警', $message);
                    }
                    break;
                    
                case ErrorLevel::WARNING:
                    $this->logManager->logSystem('warning', $message, $context);
                    break;
                    
                default:
                    $this->logManager->logSystem('info', $message, $context);
                    break;
            }
        } catch (Exception $e) {
            // 日志记录失败时的紧急处理
            $fallbackContext = array(
                'level' => $level,
                'message' => $message,
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            // 尝试基本写入
            $logDir = $this->config->get('log.directory', __DIR__ . '/../logs');
            file_put_contents($logDir . '/fallback-error.log', 
                date('Y-m-d H:i:s') . ' - 日志记录失败: ' . print_r($fallbackContext, true) . PHP_EOL, FILE_APPEND);
        }
    }
    
    /**
     * 记录审计日志
     */
    public function logAudit($action, $resource, $details = array()) {
        try {
            // 清理敏感信息
            $cleanDetails = $this->cleanSensitiveData($details);
            
            // 构建审计上下文
            $context = array(
                'resource' => $resource,
                'user_id' => $this->getCurrentUserId(),
                'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown',
                'request_id' => $this->getRequestId(),
                'server' => $this->getCleanServerData(),
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            // 合并详情，确保不覆盖基础上下文
            $mergedContext = array_merge($context, $cleanDetails);
            
            // 使用LogManager记录审计日志
            $this->logManager->logOperation($action, $mergedContext);
            
        } catch (Exception $e) {
            // 审计日志记录失败时的紧急处理
            $fallbackAudit = array(
                'action' => $action,
                'resource' => $resource,
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            // 尝试基本写入
            $logDir = $this->config->get('log.directory', __DIR__ . '/../logs');
            file_put_contents($logDir . '/fallback-audit.log', 
                date('Y-m-d H:i:s') . ' - 审计日志记录失败: ' . print_r($fallbackAudit, true) . PHP_EOL, FILE_APPEND);
        }
    }
    
    /**
     * 记录安全日志
     */
    public function logSecurity($level, $event, $details = array()) {
        try {
            // 清理敏感信息
            $cleanDetails = $this->cleanSensitiveData($details);
            
            // 构建安全事件上下文
            $context = array(
                'level' => $level,
                'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown',
                'request_id' => $this->getRequestId(),
                'server' => $this->getCleanServerData(),
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            // 合并详情，确保不覆盖基础上下文
            $mergedContext = array_merge($context, $cleanDetails);
            
            // 使用LogManager记录安全日志
            $this->logManager->logSecurity($event, $mergedContext);
            
            // 安全事件告警
            if (in_array($level, [ErrorLevel::WARNING, ErrorLevel::ERROR, ErrorLevel::CRITICAL])) {
                $this->sendAlert($level, "Security Event: {$event}", $mergedContext);
            }
            
        } catch (Exception $e) {
            // 安全日志记录失败时的紧急处理
            $fallbackSecurity = array(
                'level' => $level,
                'event' => $event,
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            // 尝试基本写入
            $logDir = $this->config->get('log.directory', __DIR__ . '/../logs');
            file_put_contents($logDir . '/fallback-security.log', 
                date('Y-m-d H:i:s') . ' - 安全日志记录失败: ' . print_r($fallbackSecurity, true) . PHP_EOL, FILE_APPEND);
        }
    }
    
    /**
     * 记录性能日志
     */
    public function logPerformance($operation, $duration, $details = array()) {
        $logEntry = array(
            'timestamp' => date('Y-m-d H:i:s'),
            'operation' => $operation,
            'duration_ms' => $duration,
            'details' => $details,
            'request_id' => $this->getRequestId(),
            'user_id' => $this->getCurrentUserId(),
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true)
        );
        
        $logMessage = json_encode($logEntry, JSON_PRETTY_PRINT) . PHP_EOL;
        file_put_contents($this->performanceLogFile, $logMessage, FILE_APPEND | LOCK_EX);
        
        // 性能告警
        if ($duration > 5000) { // 超过5秒
            $this->sendAlert(ErrorLevel::WARNING, "Performance Alert: {$operation}", [
                'duration' => $duration,
                'details' => $details
            ]);
        }
    }
    
    /**
     * 记录信息日志
     */
    public function logInfo($message, $context = array()) {
        $logEntry = array(
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => 'INFO',
            'message' => $message,
            'context' => $context,
            'request_id' => $this->getRequestId(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'unknown',
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'unknown'
        );
        $logMessage = json_encode($logEntry, JSON_PRETTY_PRINT) . PHP_EOL;
        file_put_contents($this->logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
    

    
    /**
     * 获取请求ID
     */
    private function getRequestId() {
        if (!isset($_SERVER['HTTP_X_REQUEST_ID'])) {
            $_SERVER['HTTP_X_REQUEST_ID'] = uniqid('req_', true);
        }
        return $_SERVER['HTTP_X_REQUEST_ID'];
    }
    
    /**
     * 清理敏感数据
     */
    private function cleanSensitiveData($data) {
        if (!is_array($data)) {
            return $data;
        }
        
        $sensitiveKeys = array(
            'password', 'passwd', 'pwd', 'secret', 'token', 'api_key', 
            'credit_card', 'cc_number', 'cvv', 'expiry', 'full_name',
            'address', 'phone', 'email', 'ssn', 'id_card'
        );
        
        $cleanedData = array();
        foreach ($data as $key => $value) {
            $keyLower = strtolower($key);
            
            // 检查是否为敏感键
            $isSensitive = false;
            foreach ($sensitiveKeys as $sensitiveKey) {
                if (strpos($keyLower, $sensitiveKey) !== false) {
                    $isSensitive = true;
                    break;
                }
            }
            
            if ($isSensitive) {
                // 替换敏感值
                $cleanedData[$key] = '[REDACTED]';
            } else if (is_array($value)) {
                // 递归清理嵌套数组
                $cleanedData[$key] = $this->cleanSensitiveData($value);
            } else {
                // 保留非敏感数据
                $cleanedData[$key] = $value;
            }
        }
        
        return $cleanedData;
    }
    
    /**
     * 获取清理后的服务器数据
     */
    private function getCleanServerData() {
        if (empty($_SERVER)) {
            return array();
        }
        
        $cleanedServer = array();
        $allowedKeys = array(
            'REQUEST_METHOD', 'REQUEST_URI', 'SERVER_PROTOCOL', 
            'HTTP_HOST', 'HTTP_USER_AGENT', 'HTTP_ACCEPT', 
            'REMOTE_ADDR', 'SERVER_PORT', 'SERVER_NAME'
        );
        
        foreach ($allowedKeys as $key) {
            if (isset($_SERVER[$key])) {
                $cleanedServer[$key] = $_SERVER[$key];
            }
        }
        
        return $cleanedServer;
    }
    
    /**
     * 系统恢复措施
     */
    private function systemRecovery() {
        try {
            // 记录恢复开始
            $this->logManager->logSystem('info', '开始系统恢复措施', array());
            
            // 清理会话数据
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_regenerate_id(true);
            }
            
            // 关闭数据库连接
            $db = Database::getInstance();
            $db->closeConnections();
            
            // 记录恢复完成
            $this->logManager->logSystem('info', '系统恢复措施完成', array());
            
        } catch (Exception $e) {
            // 恢复措施本身失败时，记录到备用日志
            $logDir = $this->config->get('log.directory', __DIR__ . '/../logs');
            file_put_contents($logDir . '/recovery-failed.log', 
                date('Y-m-d H:i:s') . ' - 系统恢复失败: ' . $e->getMessage() . PHP_EOL, FILE_APPEND);
        }
    }
    
    /**
     * 获取当前用户ID
     */
    public function getCurrentUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
    
    /**
     * 发送告警
     */
    private function sendAlert($level, $message, $context = array()) {
        if (!ENABLE_SECURITY_MONITORING) {
            return;
        }
        
        $subject = "[{$level}] " . APP_NAME . " Alert";
        $body = "Time: " . date('Y-m-d H:i:s') . "\n";
        $body .= "Level: {$level}\n";
        $body .= "Message: {$message}\n";
        $body .= "Context: " . json_encode($context, JSON_PRETTY_PRINT) . "\n";
        
        // 发送邮件告警
        $this->sendEmailAlert(ALERT_EMAIL, $subject, $body);
        
        // 记录告警日志
        $this->logError(ErrorLevel::WARNING, "Alert sent: {$message}", $context);
    }
    
    /**
     * 发送邮件告警
     */
    private function sendEmailAlert($to, $subject, $body) {
        try {
            $headers = [
                'From: ' . env('MAIL_FROM', 'alerts@example.com'),
                'Content-Type: text/plain; charset=UTF-8'
            ];
            
            mail($to, $subject, $body, implode("\r\n", $headers));
        } catch (Exception $e) {
            // 邮件发送失败，记录到日志
            $this->logError(ErrorLevel::ERROR, "Failed to send alert email", [
                'error' => $e->getMessage(),
                'to' => $to,
                'subject' => $subject
            ]);
        }
    }
    
    /**
     * 记录到外部服务
     */
    private function logToExternalService($logEntry) {
        // 这里可以集成外部日志服务，如ELK、Splunk等
        // 示例代码，需要根据实际服务调整
        try {
            // $this->sendToElasticsearch($logEntry);
            // $this->sendToSplunk($logEntry);
        } catch (Exception $e) {
            // 外部服务失败，记录到本地
            $this->logError(ErrorLevel::WARNING, "Failed to log to external service", [
                'error' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * 显示错误页面
     */
    private function showErrorPage($statusCode, $title, $message) {
        if (!headers_sent()) {
            http_response_code($statusCode);
            header('Content-Type: text/html; charset=UTF-8');
        }
        
        if (IS_DEVELOPMENT) {
            // 开发环境显示详细错误
            echo "<h1>{$title}</h1>";
            echo "<p>{$message}</p>";
            echo "<p>Request ID: " . $this->getRequestId() . "</p>";
        } else {
            // 生产环境显示通用错误页面
            echo "<!DOCTYPE html>";
            echo "<html><head><title>系统错误</title></head>";
            echo "<body><h1>系统暂时不可用</h1>";
            echo "<p>我们正在处理这个问题，请稍后再试。</p>";
            echo "<p>错误代码: {$statusCode}</p>";
            echo "<p>请求ID: " . $this->getRequestId() . "</p>";
            echo "</body></html>";
        }
        exit;
    }
    
    /**
     * 获取错误统计
     */
    public function getErrorStats($hours = 24) {
        $stats = array(
            'total_errors' => 0,
            'by_level' => array(),
            'by_hour' => array()
        );
        
        $files = glob(__DIR__ . '/../logs/error-*.log');
        $cutoffTime = time() - ($hours * 3600);
        
        foreach ($files as $file) {
            $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                try {
                    $logEntry = json_decode($line, true);
                    if ($logEntry && strtotime($logEntry['timestamp']) >= $cutoffTime) {
                        $stats['total_errors']++;
                        $level = $logEntry['level'];
                        $hour = date('H', strtotime($logEntry['timestamp']));
                        
                        $stats['by_level'][$level] = isset($stats['by_level'][$level]) ? $stats['by_level'][$level] + 1 : 1;
            $stats['by_hour'][$hour] = isset($stats['by_hour'][$hour]) ? $stats['by_hour'][$hour] + 1 : 1;
                    }
                } catch (Exception $e) {
                    // 忽略解析错误
                }
            }
        }
        
        return $stats;
    }
    
    /**
     * 清理旧日志
     */
    public function cleanupOldLogs() {
        $logDir = __DIR__ . '/../logs';
        $cutoffTime = time() - (AUDIT_LOG_RETENTION_DAYS * 24 * 3600);
        
        $files = glob($logDir . '/*.log');
        foreach ($files as $file) {
            if (filemtime($file) < $cutoffTime) {
                unlink($file);
            }
        }
    }
}

// 初始化错误处理器
$errorHandler = ErrorHandler::getInstance();

/**
 * 便捷函数
 */
function logInfo($message, $context = array()) {
    ErrorHandler::getInstance()->logInfo($message, $context);
}

function logError($level, $message, $context = array()) {
    ErrorHandler::getInstance()->logError($level, $message, $context);
}

function logAudit($action, $resource, $details = array()) {
    ErrorHandler::getInstance()->logAudit($action, $resource, $details);
}

function logPerformance($operation, $duration, $details = array()) {
    ErrorHandler::getInstance()->logPerformance($operation, $duration, $details);
}

function logSecurity($level, $event, $details = array()) {
    ErrorHandler::getInstance()->logSecurity($level, $event, $details);
}
?>