<?php
/**
 * 权限管理类
 * 实现角色管理、权限分配、权限审批等功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/SecurityUtils.php';
require_once __DIR__ . '/AuthManager.php'; // 添加AuthManager引用用于双因素认证检查

class PermissionManager extends BaseService {
    // 权限请求状态常量
    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    const STATUS_CANCELLED = 'cancelled';
    
    private $cache = array();
    
    // 构造函数
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * 为角色分配权限
     */
    public function assignPermissionToRole($roleId, $permissionId, $assignedBy) {
        // 双因素认证检查
        $authManager = AuthManager::getInstance();
        if ($authManager->requireTwoFactor('assign_permission')) {
            // 检查双因素认证是否已验证
            if (!$authManager->isTwoFactorVerified($assignedBy)) {
                throw new Exception('该敏感操作需要双因素认证，请先完成验证');
            }
        }
        
        try {
            // 检查是否已经分配
            $stmt = $this->database->prepare("
                SELECT id FROM role_permissions 
                WHERE role_id = ? AND permission_id = ?
            ");
            $stmt->execute(array($roleId, $permissionId));
            if ($stmt->fetch()) {
                throw new Exception("角色已拥有该权限");
            }
            
            $stmt = $this->database->prepare("
                INSERT INTO role_permissions (role_id, permission_id, created_by)
                VALUES (?, ?, ?)
            ");
            $result = $stmt->execute(array($roleId, $permissionId, $assignedBy));
            
            if ($result) {
                // 清除相关用户的权限缓存
                $this->clearRoleUsersPermissionCache($roleId);
                
                // 记录审计日志
                $permission = $this->getPermission($permissionId);
                $role = $this->getRole($roleId);
                $this->logPermissionAction($assignedBy, null, 'assign_permission', 'role_permission', $roleId, null, array(
                    'permission_name' => $permission['name'],
                    'role_name' => $role['name']
                ));
                
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("分配权限到角色失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取角色权限
     */
    public function getRolePermissions($roleId) {
        try {
            $stmt = $this->database->prepare("
                SELECT p.*, rp.created_at as assigned_at
                FROM permissions p
                INNER JOIN role_permissions rp ON p.id = rp.permission_id
                WHERE rp.role_id = ? AND p.is_active = TRUE
                ORDER BY p.module, p.action, p.resource
            ");
            $stmt->execute(array($roleId));
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            error_log("获取角色权限失败: " . $e->getMessage());
            return array();
        }
    }
    
    /**
     * 移除角色权限
     */
    public function removePermissionFromRole($roleId, $permissionId, $removedBy) {
        // 双因素认证检查
        $authManager = AuthManager::getInstance();
        if ($authManager->requireTwoFactor('remove_permission')) {
            // 检查双因素认证是否已验证
            if (!$authManager->isTwoFactorVerified($removedBy)) {
                throw new Exception('该敏感操作需要双因素认证，请先完成验证');
            }
        }
        
        try {
            $stmt = $this->database->prepare("
                DELETE FROM role_permissions 
                WHERE role_id = ? AND permission_id = ?
            ");
            $result = $stmt->execute(array($roleId, $permissionId));
            
            if ($result) {
                // 清除相关用户的权限缓存
                $this->clearRoleUsersPermissionCache($roleId);
                
                // 记录审计日志
                $permission = $this->getPermission($permissionId);
                $role = $this->getRole($roleId);
                $this->logPermissionAction($removedBy, null, 'remove_permission', 'role_permission', $roleId, array(
                    'permission_name' => $permission['name'],
                    'role_name' => $role['name']
                ), null);
                
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("移除角色权限失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取权限统计
     */
    public function getPermissionStats() {
        try {
            $stats = array();
            
            // 角色统计
            $stmt = $this->database->prepare("SELECT COUNT(*) as total_roles FROM roles WHERE is_active = TRUE");
            $stmt->execute();
            $stats['total_roles'] = $stmt->fetchColumn();
            
            // 权限统计
            $stmt = $this->database->prepare("SELECT COUNT(*) as total_permissions FROM permissions WHERE is_active = TRUE");
            $stmt->execute();
            $stats['total_permissions'] = $stmt->fetchColumn();
            
            // 用户角色统计
            $stmt = $this->database->prepare("SELECT COUNT(*) as total_user_roles FROM user_roles WHERE is_active = TRUE");
            $stmt->execute();
            $stats['total_user_roles'] = $stmt->fetchColumn();
            
            // 待审批申请统计
            $stmt = $this->database->prepare("SELECT COUNT(*) as pending_requests FROM permission_requests WHERE status = 'pending'");
            $stmt->execute();
            $stats['pending_requests'] = $stmt->fetchColumn();
            
            // 今日申请统计
            $stmt = $this->database->prepare("SELECT COUNT(*) as today_requests FROM permission_requests WHERE DATE(requested_at) = CURDATE()");
            $stmt->execute();
            $stats['today_requests'] = $stmt->fetchColumn();
            
            // 本周申请统计
            $stmt = $this->database->prepare("SELECT COUNT(*) as week_requests FROM permission_requests WHERE YEARWEEK(requested_at, 1) = YEARWEEK(CURDATE(), 1)");
            $stmt->execute();
            $stats['week_requests'] = $stmt->fetchColumn();
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("获取权限统计失败: " . $e->getMessage());
            return array();
        }
    }
    
    /**
     * 私有方法：获取角色信息
     */
    private function getRole($roleId) {
        $stmt = $this->database->prepare("SELECT * FROM roles WHERE id = ?");
        $stmt->execute(array($roleId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * 私有方法：获取权限信息
     */
    private function getPermission($permissionId) {
        $stmt = $this->database->prepare("SELECT * FROM permissions WHERE id = ?");
        $stmt->execute(array($permissionId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * 私有方法：获取申请信息
     */
    private function getRequest($requestId) {
        $stmt = $this->database->prepare("SELECT * FROM permission_requests WHERE id = ?");
        $stmt->execute(array($requestId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * 私有方法：清除用户权限缓存
     */
    private function clearUserPermissionCache($userId) {
        $stmt = $this->database->prepare("DELETE FROM user_permissions_cache WHERE user_id = ?");
        $stmt->execute(array($userId));
        
        // 清除内存缓存
        foreach (array_keys($this->cache) as $key) {
            if (strpos($key, "perm_{$userId}_") === 0) {
                unset($this->cache[$key]);
            }
        }
    }
    
    /**
     * 私有方法：清除角色用户权限缓存
     */
    private function clearRoleUsersPermissionCache($roleId) {
        $stmt = $this->database->prepare("
            DELETE FROM user_permissions_cache 
            WHERE user_id IN (
                SELECT user_id FROM user_roles WHERE role_id = ? AND is_active = TRUE
            )
        ");
        $stmt->execute(array($roleId));
    }
    
    /**
     * 私有方法：记录权限操作日志
     */
    private function logPermissionAction($userId, $targetUserId, $action, $resourceType, $resourceId, $oldValue, $newValue) {
        try {
            $stmt = $this->database->prepare("
                INSERT INTO permission_audit_logs (
                    user_id, target_user_id, action, resource_type, resource_id,
                    old_value, new_value, ip_address, user_agent
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute(array(
                $userId,
                $targetUserId,
                $action,
                $resourceType,
                $resourceId,
                $oldValue ? json_encode($oldValue) : null,
                $newValue ? json_encode($newValue) : null,
                $this->getClientIp(),
                $_SERVER['HTTP_USER_AGENT'] ? $_SERVER['HTTP_USER_AGENT'] : null
            ));
            
        } catch (Exception $e) {
            error_log("记录权限操作日志失败: " . $e->getMessage());
        }
    }
    
    /**
     * 私有方法：判断是否应该自动批准
     */
    private function shouldAutoApprove($userId, $requestType, $targetId) {
        try {
            // 获取配置
            $sql = "
                SELECT value FROM permission_settings 
                WHERE `key` = 'auto_approve_low_risk' AND `type` = 'boolean'
            ";
            $autoApprove = $this->database->fetchColumn($sql);
            
            if (!$autoApprove) {
                return false;
            }
            
            // 检查是否为低风险权限
            if ($requestType === 'permission') {
                $stmt = $this->database->prepare("
                    SELECT module, action FROM permissions 
                    WHERE id = ? AND is_active = TRUE
                ");
                $stmt->execute(array($targetId));
                $permission = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($permission) {
                    // 只读权限可以自动批准
                    $readonlyActions = array('view', 'list', 'export');
                    return in_array($permission['action'], $readonlyActions);
                }
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("判断自动批准失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 私有方法：自动批准申请
     */
    private function autoApproveRequest($requestId) {
        try {
            $request = $this->getRequest($requestId);
            if ($request) {
                $this->executePermissionGrant($request);
                
                $stmt = $this->database->prepare("
                    UPDATE permission_requests 
                    SET status = 'approved', approved_at = NOW(), approved_by = NULL
                    WHERE id = ?
                ");
                $stmt->execute(array($requestId));
            }
            
        } catch (Exception $e) {
            $this->logger->error("自动批准申请失败: " . $e->getMessage());
        }
    }
    
    /**
     * 执行权限授予
     */
    protected function executePermissionGrant($request) {
        if ($request['request_type'] === 'role') {
            // 授予角色
            $stmt = $this->database->prepare("
                INSERT IGNORE INTO user_roles (user_id, role_id, assigned_by, assigned_at)
                VALUES (?, ?, NULL, NOW())
            ");
            $stmt->execute(array($request['user_id'], $request['role_id']));
            
            // 清除权限缓存
            $this->clearUserPermissionCache($request['user_id']);
            
        } elseif ($request['request_type'] === 'permission') {
            // 直接授予权限（临时权限）
            $permission = $this->getPermission($request['permission_id']);
            if ($permission) {
                $stmt = $this->database->prepare("
                    INSERT IGNORE INTO user_permissions_cache 
                    (user_id, permission_name, granted_via, source_id, expires_at)
                    VALUES (?, ?, 'temporary', ?, ?)
                ");
                $expiresAt = $request['expires_at'] ? $request['expires_at'] : date('Y-m-d H:i:s', strtotime('+30 days'));
                $stmt->execute(array($request['user_id'], $permission['name'], $request['permission_id'], $expiresAt));
            }
        }
    }
    
    /**
     * 创建审批流程
     */
    protected function createApprovalProcess($requestId) {
        try {
            $request = $this->getRequest($requestId);
            if (!$request) {
                return;
            }
            
            // 获取对应的审批流程
            $stmt = $this->database->prepare("
                SELECT aw.* FROM approval_workflows aw
                WHERE aw.request_type = ? AND aw.is_active = TRUE
                ORDER BY aw.min_level ASC
                LIMIT 1
            ");
            $stmt->execute(array($request['request_type']));
            $workflow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($workflow) {
                // 获取审批步骤
                $stmt = $this->database->prepare("
                    SELECT * FROM approval_steps 
                    WHERE workflow_id = ? AND is_required = TRUE
                    ORDER BY step_order ASC
                ");
                $stmt->execute(array($workflow['id']));
                $steps = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // 这里可以创建审批任务或通知等
                // 实际应用中可能需要更复杂的逻辑
            }
            
        } catch (Exception $e) {
            $this->logger->error("创建审批流程失败: " . $e->getMessage());
        }
    }
    
    /**
     * 获取当前审批步骤
     */
    protected function getCurrentApprovalStep($requestId) {
        try {
            $stmt = $this->database->prepare("
                SELECT as_.* FROM approval_steps as_
                INNER JOIN approval_workflows aw ON as_.workflow_id = aw.id
                INNER JOIN permission_requests pr ON aw.request_type = pr.request_type
                WHERE pr.id = ? AND aw.is_active = TRUE
                AND as_.step_order = (
                    SELECT COALESCE(MAX(pa2.step_order), 0) + 1
                    FROM permission_approvals pa2
                    WHERE pa2.request_id = ?
                )
                ORDER BY as_.step_order ASC
                LIMIT 1
            ");
            $stmt->execute(array($requestId, $requestId));
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            $this->logger->error("获取当前审批步骤失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 获取下一步审批步骤
     */
    protected function getNextApprovalStep($requestId, $currentStepOrder) {
        try {
            $stmt = $this->database->prepare("
                SELECT as_.* FROM approval_steps as_
                INNER JOIN approval_workflows aw ON as_.workflow_id = aw.id
                INNER JOIN permission_requests pr ON aw.request_type = pr.request_type
                WHERE pr.id = ? AND aw.is_active = TRUE
                AND as_.step_order > ?
                ORDER BY as_.step_order ASC
                LIMIT 1
            ");
            $stmt->execute(array($requestId, $currentStepOrder));
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            $this->logger->error("获取下一步审批步骤失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 判断用户是否可以审批申请
     */
    protected function canApproveRequest($approverId, $request) {
        // 检查用户是否有审批权限
        return $this->hasPermission($approverId, 'permission.approve');
    }
    
    /**
     * 获取当前用户ID
     */
    protected function getCurrentUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}