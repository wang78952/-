<?php
/**
 * 消息队列系统
 * 实现异步处理机制，支持多种消息队列后端，提供任务调度、重试机制和监控功能
 */

class MessageQueueSystem {
    // 队列类型常量
    const TYPE_REDIS = 'redis';
    const TYPE_RABBITMQ = 'rabbitmq';
    const TYPE_BEANSTALKD = 'beanstalkd';
    
    // 队列优先级常量
    const PRIORITY_LOW = 10;
    const PRIORITY_NORMAL = 5;
    const PRIORITY_HIGH = 1;
    
    // 任务状态常量
    const STATUS_PENDING = 'pending';
    const STATUS_PROCESSING = 'processing';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';
    
    // 单例实例
    private static $instance = null;
    
    // 当前队列适配器
    private $adapter = null;
    
    // 队列配置
    private $config = [];
    
    // 任务处理器映射
    private $processors = [];
    
    // 监控数据
    private $metrics = [
        'tasks_enqueued' => 0,
        'tasks_completed' => 0,
        'tasks_failed' => 0,
        'tasks_retried' => 0,
        'processing_time' => 0
    ];
    
    /**
     * 私有构造函数（单例模式）
     */
    private function __construct() {
        $this->loadConfig();
        $this->initializeAdapter();
        $this->registerDefaultProcessors();
    }
    
    /**
     * 获取消息队列实例（单例模式）
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 加载队列配置
     */
    private function loadConfig() {
        // 默认配置
        $this->config = [
            'type' => self::TYPE_REDIS,
            'redis' => [
                'host' => 'localhost',
                'port' => 6379,
                'password' => '',
                'database' => 0,
                'timeout' => 5
            ],
            'rabbitmq' => [
                'host' => 'localhost',
                'port' => 5672,
                'user' => 'guest',
                'password' => 'guest',
                'vhost' => '/'
            ],
            'beanstalkd' => [
                'host' => 'localhost',
                'port' => 11300,
                'timeout' => 5
            ],
            'default_queue' => 'default',
            'max_retries' => 3,
            'retry_delay' => 60, // 秒
            'visibility_timeout' => 300, // 秒
            'log_level' => 'info',
            'enable_metrics' => true,
            'queues' => [
                'order_processing' => ['priority' => self::PRIORITY_HIGH],
                'notification' => ['priority' => self::PRIORITY_NORMAL],
                'data_sync' => ['priority' => self::PRIORITY_NORMAL],
                'report_generation' => ['priority' => self::PRIORITY_LOW]
            ]
        ];
        
        // 从配置文件加载自定义配置
        if (file_exists(CONFIG_PATH . '/message_queue_config.php')) {
            include CONFIG_PATH . '/message_queue_config.php';
            if (isset($queueConfig) && is_array($queueConfig)) {
                $this->mergeConfig($this->config, $queueConfig);
            }
        }
    }
    
    /**
     * 合并配置
     */
    private function mergeConfig(&$default, $custom) {
        foreach ($custom as $key => $value) {
            if (is_array($value) && isset($default[$key]) && is_array($default[$key])) {
                $this->mergeConfig($default[$key], $value);
            } else {
                $default[$key] = $value;
            }
        }
    }
    
    /**
     * 初始化队列适配器
     */
    private function initializeAdapter() {
        $type = $this->config['type'] ?? self::TYPE_REDIS;
        
        switch ($type) {
            case self::TYPE_REDIS:
                $this->adapter = new RedisQueueAdapter($this->config['redis']);
                break;
            case self::TYPE_RABBITMQ:
                // 检查是否有RabbitMQ扩展
                if (class_exists('AMQPConnection')) {
                    $this->adapter = new RabbitMQQueueAdapter($this->config['rabbitmq']);
                } else {
                    Logger::warning('RabbitMQ扩展不可用，回退到Redis队列');
                    $this->adapter = new RedisQueueAdapter($this->config['redis']);
                }
                break;
            case self::TYPE_BEANSTALKD:
                // 检查是否有Beanstalkd扩展
                if (class_exists('Pheanstalk')) {
                    $this->adapter = new BeanstalkdQueueAdapter($this->config['beanstalkd']);
                } else {
                    Logger::warning('Beanstalkd扩展不可用，回退到Redis队列');
                    $this->adapter = new RedisQueueAdapter($this->config['redis']);
                }
                break;
            default:
                $this->adapter = new RedisQueueAdapter($this->config['redis']);
        }
        
        // 初始化所有队列
        foreach ($this->config['queues'] as $queueName => $queueConfig) {
            $this->adapter->createQueue($queueName);
        }
    }
    
    /**
     * 注册默认任务处理器
     */
    private function registerDefaultProcessors() {
        // 订单处理任务处理器
        $this->registerProcessor('order.process', function($data) {
            return OrderService::processAsyncOrder($data);
        });
        
        // 通知发送任务处理器
        $this->registerProcessor('notification.send', function($data) {
            return NotificationService::sendAsyncNotification($data);
        });
        
        // 数据同步任务处理器
        $this->registerProcessor('data.sync', function($data) {
            return DataSyncService::syncDataAsync($data);
        });
        
        // 报表生成任务处理器
        $this->registerProcessor('report.generate', function($data) {
            return ReportService::generateReportAsync($data);
        });
        
        // 卡密激活任务处理器
        $this->registerProcessor('card.activate', function($data) {
            return CardService::activateCardAsync($data);
        });
    }
    
    /**
     * 注册任务处理器
     */
    public function registerProcessor($taskType, $processor) {
        $this->processors[$taskType] = $processor;
        Logger::info('已注册任务处理器: ' . $taskType);
        return $this;
    }
    
    /**
     * 入队任务
     */
    public function enqueue($taskType, $data, $options = []) {
        try {
            // 默认选项
            $defaultOptions = [
                'queue' => $this->config['default_queue'],
                'priority' => self::PRIORITY_NORMAL,
                'delay' => 0,
                'timeout' => $this->config['visibility_timeout'],
                'max_retries' => $this->config['max_retries']
            ];
            
            // 合并选项
            $options = array_merge($defaultOptions, $options);
            
            // 创建任务数据
            $task = [
                'id' => $this->generateTaskId(),
                'type' => $taskType,
                'data' => $data,
                'options' => $options,
                'status' => self::STATUS_PENDING,
                'attempts' => 0,
                'created_at' => time(),
                'updated_at' => time()
            ];
            
            // 序列化任务数据
            $taskJson = json_encode($task);
            
            // 发送到队列
            $queueName = $this->getQueueName($taskType, $options['queue']);
            $this->adapter->publish($queueName, $taskJson, $options['priority'], $options['delay']);
            
            // 更新指标
            if ($this->config['enable_metrics']) {
                $this->metrics['tasks_enqueued']++;
            }
            
            Logger::info('任务已入队', [
                'task_id' => $task['id'],
                'task_type' => $taskType,
                'queue' => $queueName
            ]);
            
            return $task['id'];
        } catch (Exception $e) {
            Logger::error('任务入队失败', [
                'task_type' => $taskType,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
    
    /**
     * 处理队列任务
     */
    public function process($queue = null, $limit = 100, $timeout = 0) {
        $queueName = $queue ?? $this->config['default_queue'];
        $processedCount = 0;
        $startTime = time();
        
        Logger::info('开始处理队列任务', [
            'queue' => $queueName,
            'limit' => $limit,
            'timeout' => $timeout
        ]);
        
        try {
            while (true) {
                // 检查超时
                if ($timeout > 0 && (time() - $startTime) > $timeout) {
                    Logger::info('队列处理超时，已处理 ' . $processedCount . ' 个任务');
                    break;
                }
                
                // 检查任务数限制
                if ($limit > 0 && $processedCount >= $limit) {
                    Logger::info('已达到任务处理限制，已处理 ' . $processedCount . ' 个任务');
                    break;
                }
                
                // 从队列获取任务
                $taskJson = $this->adapter->consume($queueName, 5); // 5秒超时
                
                // 如果没有任务，退出循环
                if ($taskJson === null) {
                    Logger::info('队列为空，没有可处理的任务');
                    break;
                }
                
                // 解析任务数据
                $task = json_decode($taskJson, true);
                if ($task === null) {
                    Logger::error('无效的任务数据格式');
                    continue;
                }
                
                // 处理任务
                $this->processTask($task, $queueName);
                $processedCount++;
            }
        } catch (Exception $e) {
            Logger::error('队列处理异常', ['error' => $e->getMessage()]);
        }
        
        Logger::info('队列处理完成', ['processed_count' => $processedCount]);
        return $processedCount;
    }
    
    /**
     * 处理单个任务
     */
    private function processTask(&$task, $queueName) {
        $startTime = microtime(true);
        $taskId = $task['id'];
        $taskType = $task['type'];
        $task->attempts++;
        
        Logger::info('开始处理任务', [
            'task_id' => $taskId,
            'task_type' => $taskType,
            'attempts' => $task->attempts
        ]);
        
        try {
            // 更新任务状态
            $task['status'] = self::STATUS_PROCESSING;
            $task['updated_at'] = time();
            
            // 获取任务处理器
            $processor = $this->processors[$taskType] ?? null;
            
            if ($processor === null) {
                throw new Exception('未找到任务处理器: ' . $taskType);
            }
            
            // 执行任务
            $result = call_user_func($processor, $task['data']);
            
            // 更新任务状态为完成
            $task['status'] = self::STATUS_COMPLETED;
            $task['result'] = $result;
            $task['updated_at'] = time();
            
            // 确认任务完成
            $this->adapter->acknowledge($queueName, $taskId);
            
            // 更新指标
            if ($this->config['enable_metrics']) {
                $this->metrics['tasks_completed']++;
                $this->metrics['processing_time'] += (microtime(true) - $startTime);
            }
            
            Logger::info('任务处理成功', ['task_id' => $taskId]);
            
            return true;
        } catch (Exception $e) {
            // 记录错误
            $errorInfo = [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => time()
            ];
            
            $task['status'] = self::STATUS_FAILED;
            $task['error'] = $errorInfo;
            $task['updated_at'] = time();
            
            Logger::error('任务处理失败', [
                'task_id' => $taskId,
                'error' => $e->getMessage()
            ]);
            
            // 检查是否需要重试
            if ($task->attempts < $task['options']['max_retries']) {
                $retryDelay = $task['options']['max_retries'] * $this->config['retry_delay'];
                $this->retryTask($task, $retryDelay, $queueName);
            } else {
                // 达到最大重试次数，拒绝任务
                $this->adapter->reject($queueName, $taskId);
                $this->handleFailedTask($task);
            }
            
            // 更新指标
            if ($this->config['enable_metrics']) {
                $this->metrics['tasks_failed']++;
            }
            
            return false;
        }
    }
    
    /**
     * 重试任务
     */
    private function retryTask($task, $delay, $queueName) {
        $task['attempts']++;
        $task['status'] = self::STATUS_PENDING;
        $task['updated_at'] = time();
        
        // 发布到延迟队列
        $taskJson = json_encode($task);
        $this->adapter->publish($queueName, $taskJson, $task['options']['priority'], $delay);
        
        // 更新指标
        if ($this->config['enable_metrics']) {
            $this->metrics['tasks_retried']++;
        }
        
        Logger::info('任务已安排重试', [
            'task_id' => $task['id'],
            'attempts' => $task['attempts'],
            'delay' => $delay
        ]);
    }
    
    /**
     * 处理失败的任务
     */
    private function handleFailedTask($task) {
        try {
            // 记录到失败任务表
            $this->logFailedTask($task);
            
            // 发送告警通知
            $this->sendFailureAlert($task);
        } catch (Exception $e) {
            Logger::error('处理失败任务时发生错误', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * 记录失败任务
     */
    private function logFailedTask($task) {
        // 这里可以实现将失败任务记录到数据库
        $db = Database::getInstance();
        $db->insert('failed_tasks', [
            'task_id' => $task['id'],
            'task_type' => $task['type'],
            'task_data' => json_encode($task),
            'error_info' => json_encode($task['error'] ?? []),
            'attempts' => $task['attempts'],
            'created_at' => $task['created_at'],
            'failed_at' => time()
        ]);
    }
    
    /**
     * 发送失败告警
     */
    private function sendFailureAlert($task) {
        // 构建告警消息
        $alertData = [
            'type' => 'task_failure',
            'subject' => '任务处理失败告警',
            'message' => "任务 {$task['type']} ({$task['id']}) 处理失败，已达到最大重试次数",
            'task' => $task,
            'level' => 'error'
        ];
        
        // 发送告警（可以通过邮件、短信等方式）
        if (class_exists('AlertService')) {
            AlertService::sendAlert($alertData);
        }
    }
    
    /**
     * 获取队列统计信息
     */
    public function getQueueStats($queue = null) {
        $queueName = $queue ?? $this->config['default_queue'];
        return $this->adapter->getStats($queueName);
    }
    
    /**
     * 获取所有队列统计信息
     */
    public function getAllQueueStats() {
        $stats = [];
        
        // 获取默认队列统计
        $stats[$this->config['default_queue']] = $this->getQueueStats();
        
        // 获取其他队列统计
        foreach (array_keys($this->config['queues']) as $queueName) {
            $stats[$queueName] = $this->getQueueStats($queueName);
        }
        
        return $stats;
    }
    
    /**
     * 获取系统指标
     */
    public function getMetrics() {
        return $this->metrics;
    }
    
    /**
     * 清空队列
     */
    public function clearQueue($queue = null) {
        $queueName = $queue ?? $this->config['default_queue'];
        $this->adapter->clearQueue($queueName);
        Logger::info('已清空队列: ' . $queueName);
        return $this;
    }
    
    /**
     * 重新入队失败任务
     */
    public function requeueFailedTasks($limit = 100) {
        $db = Database::getInstance();
        $failedTasks = $db->select('failed_tasks', '*', ['LIMIT' => $limit]);
        
        $requeuedCount = 0;
        
        foreach ($failedTasks as $failedTask) {
            try {
                $task = json_decode($failedTask['task_data'], true);
                
                if ($task !== null) {
                    // 重置任务状态
                    $task['status'] = self::STATUS_PENDING;
                    $task['attempts'] = 0;
                    $task['updated_at'] = time();
                    
                    // 重新入队
                    $this->adapter->publish(
                        $this->getQueueName($task['type']),
                        json_encode($task),
                        $task['options']['priority'] ?? self::PRIORITY_NORMAL
                    );
                    
                    // 删除失败记录
                    $db->delete('failed_tasks', ['id' => $failedTask['id']]);
                    
                    $requeuedCount++;
                }
            } catch (Exception $e) {
                Logger::error('重新入队失败任务时出错', [
                    'task_id' => $failedTask['task_id'],
                    'error' => $e->getMessage()
                ]);
            }
        }
        
        Logger::info('重新入队失败任务完成', ['count' => $requeuedCount]);
        return $requeuedCount;
    }
    
    /**
     * 获取队列名称（根据任务类型）
     */
    private function getQueueName($taskType, $defaultQueue = null) {
        // 可以根据任务类型映射到不同的队列
        $queueMappings = [
            'order.' => 'order_processing',
            'notification.' => 'notification',
            'data.' => 'data_sync',
            'report.' => 'report_generation',
            'card.' => 'card_processing'
        ];
        
        foreach ($queueMappings as $prefix => $queue) {
            if (strpos($taskType, $prefix) === 0) {
                return $queue;
            }
        }
        
        return $defaultQueue ?? $this->config['default_queue'];
    }
    
    /**
     * 生成任务ID
     */
    private function generateTaskId() {
        return 'task_' . uniqid() . '_' . mt_rand(1000, 9999);
    }
    
    /**
     * 工厂方法 - 获取消息队列实例
     */
    public static function getSystem() {
        return self::getInstance();
    }
}

/**
 * Redis队列适配器
 * 基于Redis实现的消息队列适配器
 */
class RedisQueueAdapter {
    private $redis = null;
    private $config = [];
    
    public function __construct($config) {
        $this->config = $config;
        $this->connect();
    }
    
    private function connect() {
        try {
            $this->redis = new Redis();
            $this->redis->connect(
                $this->config['host'],
                $this->config['port'],
                $this->config['timeout']
            );
            
            if (!empty($this->config['password'])) {
                $this->redis->auth($this->config['password']);
            }
            
            if (isset($this->config['database']) && $this->config['database'] > 0) {
                $this->redis->select($this->config['database']);
            }
            
            Logger::info('Redis队列连接成功');
        } catch (Exception $e) {
            Logger::error('Redis队列连接失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    public function createQueue($queueName) {
        // Redis不需要预创建队列
        Logger::info('队列已就绪: ' . $queueName);
    }
    
    public function publish($queueName, $message, $priority = 0, $delay = 0) {
        $queueKey = 'queue:' . $queueName;
        $priorityKey = 'queue:' . $queueName . ':priority';
        
        // 如果有延迟，使用有序集合
        if ($delay > 0) {
            $this->redis->zAdd($priorityKey, time() + $delay, $message);
        } else {
            // 否则直接入队
            $this->redis->lPush($queueKey, $message);
        }
    }
    
    public function consume($queueName, $timeout = 0) {
        $queueKey = 'queue:' . $queueName;
        $priorityKey = 'queue:' . $queueName . ':priority';
        
        // 检查是否有到期的延迟任务
        $now = time();
        $dueTasks = $this->redis->zRangeByScore($priorityKey, 0, $now);
        
        if (!empty($dueTasks)) {
            // 将到期任务移到主队列
            foreach ($dueTasks as $task) {
                $this->redis->lPush($queueKey, $task);
                $this->redis->zRem($priorityKey, $task);
            }
        }
        
        // 从队列中获取任务
        if ($timeout > 0) {
            // 阻塞模式
            return $this->redis->brPop($queueKey, $timeout);
        } else {
            // 非阻塞模式
            return $this->redis->rPop($queueKey);
        }
    }
    
    public function acknowledge($queueName, $taskId) {
        // Redis队列不需要显式确认
    }
    
    public function reject($queueName, $taskId) {
        // Redis队列不需要显式拒绝
    }
    
    public function getStats($queueName) {
        $queueKey = 'queue:' . $queueName;
        $priorityKey = 'queue:' . $queueName . ':priority';
        
        return [
            'queue_name' => $queueName,
            'pending_tasks' => $this->redis->lLen($queueKey),
            'delayed_tasks' => $this->redis->zCard($priorityKey),
            'timestamp' => time()
        ];
    }
    
    public function clearQueue($queueName) {
        $queueKey = 'queue:' . $queueName;
        $priorityKey = 'queue:' . $queueName . ':priority';
        
        $this->redis->del($queueKey);
        $this->redis->del($priorityKey);
    }
}

// 创建消息队列实例
$queue = MessageQueueSystem::getInstance();