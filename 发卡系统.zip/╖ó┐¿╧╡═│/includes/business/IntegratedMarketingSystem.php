<?php
/**
 * 整合营销系统核心类
 * 用于协调数据分析平台、营销工具和用户留存系统之间的数据流转和交互
 */

require_once 'UserPurchaseAnalytics.php';
require_once 'AgentAnalytics.php';
require_once 'DiscountManager.php';
require_once 'PromotionService.php';
require_once 'MemberService.php';
require_once 'FlashSaleManager.php';

class IntegratedMarketingSystem {
    
    /**
     * @var Database 数据库连接实例
     */
    protected $db;
    
    /**
     * @var UserPurchaseAnalytics 用户购买分析实例
     */
    protected $userAnalytics;
    
    /**
     * @var AgentAnalytics 代理分析实例
     */
    protected $agentAnalytics;
    
    /**
     * @var DiscountManager 折扣管理实例
     */
    protected $discountManager;
    
    /**
     * @var PromotionService 促销服务实例
     */
    protected $promotionService;
    
    /**
     * @var MemberService 会员服务实例
     */
    protected $memberService;
    
    /**
     * @var FlashSaleManager 限时秒杀管理实例
     */
    protected $flashSaleManager;
    
    /**
     * 构造函数
     * @param Database $db 数据库连接
     */
    public function __construct($db = null) {
        if ($db === null) {
            require_once '../Database.php';
            $this->db = Database::getInstance();
        } else {
            $this->db = $db;
        }
        
        // 初始化各模块实例
        $this->userAnalytics = new UserPurchaseAnalytics($this->db);
        $this->agentAnalytics = new AgentAnalytics();
        $this->discountManager = new DiscountManager($this->db);
        $this->promotionService = new PromotionService($this->db);
        $this->memberService = new MemberService($this->db);
        $this->flashSaleManager = new FlashSaleManager($this->db);
    }
    
    /**
     * 获取用户完整营销信息
     * 整合用户的会员等级、可用积分、适用的促销活动、限时秒杀等信息
     * 
     * @param int $userId 用户ID
     * @param array $orderData 订单数据（可选，用于计算适用的优惠）
     * @return array 用户营销信息
     */
    public function getUserMarketingInfo($userId, $orderData = null) {
        try {
            // 获取用户会员信息
            $memberInfo = $this->memberService->getUserMemberInfo($userId);
            
            // 获取用户可用积分
            $pointsInfo = [
                'current_points' => $memberInfo['data']['current_points'],
                'total_points' => $memberInfo['data']['total_points'],
                'expiring_points' => $this->memberService->getExpiringPointsAmount($userId)
            ];
            
            // 获取用户可用的积分兑换规则
            $exchangeRules = $this->memberService->getAvailableExchangeRules($userId);
            
            // 获取用户可参与的限时秒杀活动
            $flashSales = [];
            if (!empty($orderData)) {
                $flashSales = $this->flashSaleManager->getAvailableFlashSales($userId, $orderData);
            }
            
            // 获取用户适用的优惠券和满减活动
            $promotions = [];
            if (!empty($orderData)) {
                $promotions = $this->promotionService->getUserAvailablePromotions($userId, $orderData);
            }
            
            // 获取用户购买偏好（用于个性化推荐）
            $purchasePreferences = $this->userAnalytics->getUserProductPreferences(
                date('Y-m-d', strtotime('-3 months')),
                date('Y-m-d'),
                $userId,
                5
            );
            
            return [
                'success' => true,
                'data' => [
                    'user_id' => $userId,
                    'member_level' => $memberInfo['data']['member_level'],
                    'member_info' => $memberInfo['data'],
                    'points' => $pointsInfo,
                    'available_exchange_rules' => $exchangeRules['data'],
                    'available_flash_sales' => $flashSales,
                    'available_promotions' => $promotions['data'],
                    'purchase_preferences' => $purchasePreferences,
                    'recommended_actions' => $this->getRecommendedActions($userId, $memberInfo, $pointsInfo)
                ],
                'message' => '获取用户营销信息成功'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => '获取用户营销信息失败：' . $e->getMessage(),
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 获取推荐的用户行为
     * 
     * @param int $userId 用户ID
     * @param array $memberInfo 会员信息
     * @param array $pointsInfo 积分信息
     * @return array 推荐行为列表
     */
    protected function getRecommendedActions($userId, $memberInfo, $pointsInfo) {
        $recommendedActions = [];
        
        // 根据会员等级推荐
        $memberLevel = $memberInfo['data']['member_level'];
        $nextLevel = $this->memberService->getNextLevelInfo($memberLevel);
        
        if (!empty($nextLevel)) {
            $pointsNeeded = $nextLevel['min_points'] - $memberInfo['data']['total_points'];
            if ($pointsNeeded > 0 && $pointsNeeded < 5000) {
                $recommendedActions[] = [
                    'type' => 'level_up',
                    'title' => '升级会员等级',
                    'description' => "再积累{$pointsNeeded}积分即可升级到{$nextLevel['name']}",
                    'priority' => 1
                ];
            }
        }
        
        // 根据积分推荐兑换
        if ($pointsInfo['current_points'] >= 1000) {
            $recommendedActions[] = [
                'type' => 'point_exchange',
                'title' => '积分兑换',
                'description' => "您有{$pointsInfo['current_points']}积分可兑换优惠券",
                'priority' => 2
            ];
        }
        
        // 积分即将过期提醒
        if ($pointsInfo['expiring_points'] > 0) {
            $recommendedActions[] = [
                'type' => 'points_expiring',
                'title' => '积分即将过期',
                'description' => "您有{$pointsInfo['expiring_points']}积分即将过期，请及时使用",
                'priority' => 0
            ];
        }
        
        return $recommendedActions;
    }
    
    /**
     * 计算订单适用的所有优惠
     * 整合满减、优惠券、限时秒杀等多重优惠
     * 
     * @param int $userId 用户ID
     * @param array $orderData 订单数据
     * @return array 适用的优惠信息
     */
    public function calculateOrderDiscounts($userId, $orderData) {
        try {
            // 初始化优惠结果
            $discounts = [
                'flash_sale' => null,
                'coupon_discount' => 0,
                'full_reduction' => 0,
                'member_discount' => 0,
                'total_discount' => 0,
                'applied_rules' => []
            ];
            
            // 获取用户会员信息（用于计算会员折扣）
            $memberInfo = $this->memberService->getUserMemberInfo($userId);
            $discountRate = 1.0;
            if ($memberInfo['success']) {
                $discountRate = $memberInfo['data']['discount_rate'] ?? 1.0;
                $memberLevelId = $memberInfo['data']['member_level_id'] ?? 1;
                
                // 获取会员等级信息
                $levelInfo = $this->memberService->getLevelInfo($memberLevelId);
                if ($levelInfo['success'] && $levelInfo['data']['discount_rate'] < 1.0) {
                    $discountRate = $levelInfo['data']['discount_rate'];
                }
            }
            
            // 计算会员折扣
            $originalAmount = floatval($orderData['total_amount'] ?? 0);
            $memberDiscountAmount = $originalAmount * (1 - $discountRate);
            
            // 获取可用的满减优惠
            $fullReduction = $this->discountManager->calculateDiscount($orderData);
            $reductionAmount = 0;
            if (!empty($fullReduction['data'])) {
                $reductionAmount = floatval($fullReduction['data']['discount_amount'] ?? 0);
            }
            
            // 获取可用的限时秒杀活动
            $flashSales = $this->flashSaleManager->getAvailableFlashSales($userId, $orderData);
            $flashSaleDiscount = null;
            $flashSaleAmount = 0;
            
            if (!empty($flashSales['data'])) {
                // 找到最适合的限时秒杀活动（折扣最大）
                $bestFlashSale = null;
                $maxDiscount = 0;
                
                foreach ($flashSales['data'] as $sale) {
                    $currentDiscount = $this->flashSaleManager->calculateFlashSaleDiscount($sale, $orderData);
                    if ($currentDiscount > $maxDiscount) {
                        $maxDiscount = $currentDiscount;
                        $bestFlashSale = $sale;
                    }
                }
                
                if ($bestFlashSale) {
                    $flashSaleDiscount = $bestFlashSale;
                    $flashSaleAmount = $maxDiscount;
                }
            }
            
            // 计算总折扣金额
            $totalDiscount = $memberDiscountAmount + $reductionAmount + $flashSaleAmount;
            
            // 构建返回数据
            $discounts = [
                'flash_sale' => $flashSaleDiscount,
                'coupon_discount' => 0, // 优惠券折扣需要单独处理
                'full_reduction' => $reductionAmount,
                'member_discount' => $memberDiscountAmount,
                'total_discount' => $totalDiscount,
                'final_amount' => $originalAmount - $totalDiscount,
                'applied_rules' => []
            ];
            
            // 添加应用的规则信息
            if (!empty($flashSaleDiscount)) {
                $discounts['applied_rules'][] = [
                    'type' => 'flash_sale',
                    'id' => $flashSaleDiscount['id'],
                    'name' => $flashSaleDiscount['name'],
                    'discount_amount' => $flashSaleAmount
                ];
            }
            
            if ($reductionAmount > 0) {
                $discounts['applied_rules'][] = [
                    'type' => 'full_reduction',
                    'name' => $fullReduction['data']['rule_name'] ?? '满减优惠',
                    'discount_amount' => $reductionAmount
                ];
            }
            
            if ($memberDiscountAmount > 0) {
                $discounts['applied_rules'][] = [
                    'type' => 'member_discount',
                    'name' => '会员折扣',
                    'discount_rate' => $discountRate,
                    'discount_amount' => $memberDiscountAmount
                ];
            }
            
            return [
                'success' => true,
                'data' => $discounts,
                'message' => '计算优惠成功'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => '计算优惠失败：' . $e->getMessage(),
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 处理订单完成后的营销操作
     * 包括积分发放、会员等级更新、推广效果统计等
     * 
     * @param int $orderId 订单ID
     * @param array $orderData 订单数据
     * @return array 处理结果
     */
    public function handleOrderCompletion($orderId, $orderData) {
        try {
            $this->db->beginTransaction();
            
            $userId = $orderData['user_id'] ?? 0;
            $orderAmount = $orderData['total_amount'] ?? 0;
            $status = $orderData['status'] ?? '';
            
            // 只有订单状态为完成时才进行处理
            if ($status !== 'completed') {
                throw new Exception('订单状态不是已完成');
            }
            
            // 记录订单营销效果数据
            $this->recordOrderMarketingData($orderId, $orderData);
            
            // 发放积分给用户
            $pointsToAdd = floor($orderAmount * 10); // 订单金额的10%作为积分
            $pointResult = $this->memberService->addPoints($userId, $pointsToAdd, 'order', $orderId, '订单完成获得积分');
            
            if (!$pointResult['success']) {
                throw new Exception('发放积分失败：' . $pointResult['message']);
            }
            
            // 检查并更新用户会员等级
            $levelResult = $this->memberService->checkAndUpdateLevel($userId);
            if (!$levelResult['success'] && !empty($levelResult['message'])) {
                // 日志记录等级更新失败，但不中断整个流程
                error_log('会员等级更新失败: ' . $levelResult['message']);
            }
            
            // 处理推广关系（如果有代理推荐）
            if (!empty($orderData['referral_code'])) {
                $this->processReferralOrder($orderId, $orderData);
            }
            
            // 记录用户购买偏好（用于后续分析）
            $this->recordUserPurchasePreference($userId, $orderData);
            
            $this->db->commit();
            
            return [
                'success' => true,
                'data' => [
                    'points_added' => $pointsToAdd,
                    'level_updated' => $levelResult['data']['level_changed'] ?? false,
                    'new_level' => $levelResult['data']['new_level'] ?? null
                ],
                'message' => '订单营销处理成功'
            ];
            
        } catch (Exception $e) {
            $this->db->rollback();
            return [
                'success' => false,
                'message' => '订单营销处理失败：' . $e->getMessage(),
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 记录订单营销数据
     * 
     * @param int $orderId 订单ID
     * @param array $orderData 订单数据
     */
    protected function recordOrderMarketingData($orderId, $orderData) {
        // 这里可以记录订单相关的营销数据到analytics_tables
        // 例如记录使用的优惠类型、折扣金额等
        $userId = $orderData['user_id'] ?? 0;
        $discountAmount = $orderData['discount_amount'] ?? 0;
        $discountType = $orderData['discount_type'] ?? 'none';
        
        $sql = "INSERT INTO order_marketing_data 
                (order_id, user_id, discount_amount, discount_type, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        
        try {
            $this->db->query($sql, [$orderId, $userId, $discountAmount, $discountType]);
        } catch (Exception $e) {
            // 日志记录错误，但不中断流程
            error_log('记录订单营销数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 处理推荐订单
     * 
     * @param int $orderId 订单ID
     * @param array $orderData 订单数据
     */
    protected function processReferralOrder($orderId, $orderData) {
        // 这里可以处理代理推荐相关的逻辑
        // 例如更新代理业绩、计算佣金等
        $referralCode = $orderData['referral_code'] ?? '';
        $userId = $orderData['user_id'] ?? 0;
        $orderAmount = $orderData['total_amount'] ?? 0;
        
        // 记录推荐转化
        $sql = "INSERT INTO referral_conversions 
                (order_id, user_id, referral_code, amount, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        
        try {
            $this->db->query($sql, [$orderId, $userId, $referralCode, $orderAmount]);
            
            // 触发代理统计更新
            $this->agentAnalytics->updateAgentStatsByReferralCode($referralCode);
        } catch (Exception $e) {
            // 日志记录错误，但不中断流程
            error_log('处理推荐订单失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 记录用户购买偏好
     * 
     * @param int $userId 用户ID
     * @param array $orderData 订单数据
     */
    protected function recordUserPurchasePreference($userId, $orderData) {
        // 记录用户的购买偏好（产品类别、价格区间等）
        if (!empty($orderData['items'])) {
            foreach ($orderData['items'] as $item) {
                $productId = $item['product_id'] ?? 0;
                $categoryId = $item['category_id'] ?? 0;
                $price = $item['price'] ?? 0;
                
                // 记录用户对产品类别的偏好
                if ($categoryId > 0) {
                    $this->recordUserCategoryPreference($userId, $categoryId, $price);
                }
                
                // 记录用户对产品的偏好
                if ($productId > 0) {
                    $this->recordUserProductPreference($userId, $productId, $price);
                }
            }
        }
    }
    
    /**
     * 记录用户产品类别偏好
     * 
     * @param int $userId 用户ID
     * @param int $categoryId 产品类别ID
     * @param float $price 价格
     */
    protected function recordUserCategoryPreference($userId, $categoryId, $price) {
        try {
            // 检查记录是否存在
            $sql = "SELECT * FROM user_category_preferences WHERE user_id = ? AND category_id = ?";
            $existing = $this->db->fetch($sql, [$userId, $categoryId]);
            
            if ($existing) {
                // 更新现有记录
                $sql = "UPDATE user_category_preferences 
                        SET purchase_count = purchase_count + 1, 
                            total_amount = total_amount + ?, 
                            last_purchase_at = NOW(),
                            updated_at = NOW()
                        WHERE user_id = ? AND category_id = ?";
                $this->db->query($sql, [$price, $userId, $categoryId]);
            } else {
                // 创建新记录
                $sql = "INSERT INTO user_category_preferences 
                        (user_id, category_id, purchase_count, total_amount, last_purchase_at, created_at, updated_at) 
                        VALUES (?, ?, 1, ?, NOW(), NOW(), NOW())";
                $this->db->query($sql, [$userId, $categoryId, $price]);
            }
        } catch (Exception $e) {
            // 日志记录错误，但不中断流程
            error_log('记录用户类别偏好失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 记录用户产品偏好
     * 
     * @param int $userId 用户ID
     * @param int $productId 产品ID
     * @param float $price 价格
     */
    protected function recordUserProductPreference($userId, $productId, $price) {
        try {
            // 检查记录是否存在
            $sql = "SELECT * FROM user_product_preferences WHERE user_id = ? AND product_id = ?";
            $existing = $this->db->fetch($sql, [$userId, $productId]);
            
            if ($existing) {
                // 更新现有记录
                $sql = "UPDATE user_product_preferences 
                        SET purchase_count = purchase_count + 1, 
                            total_amount = total_amount + ?, 
                            last_purchase_at = NOW(),
                            updated_at = NOW()
                        WHERE user_id = ? AND product_id = ?";
                $this->db->query($sql, [$price, $userId, $productId]);
            } else {
                // 创建新记录
                $sql = "INSERT INTO user_product_preferences 
                        (user_id, product_id, purchase_count, total_amount, last_purchase_at, created_at, updated_at) 
                        VALUES (?, ?, 1, ?, NOW(), NOW(), NOW())";
                $this->db->query($sql, [$userId, $productId, $price]);
            }
        } catch (Exception $e) {
            // 日志记录错误，但不中断流程
            error_log('记录用户产品偏好失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取营销仪表盘数据
     * 整合营销系统各模块的数据，提供统一的仪表盘视图
     * 
     * @param array $filters 过滤条件
     * @return array 仪表盘数据
     */
    public function getMarketingDashboardData($filters = []) {
        try {
            $startDate = $filters['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $endDate = $filters['end_date'] ?? date('Y-m-d');
            $userId = $filters['user_id'] ?? null;
            $agentId = $filters['agent_id'] ?? null;
            
            // 获取用户分析数据
            $userSummary = $this->userAnalytics->getUserPurchasePreferences([
                'start_date' => $startDate,
                'end_date' => $endDate,
                'user_id' => $userId
            ]);
            
            // 获取代理分析数据
            $agentSummary = $this->agentAnalytics->getAgentConversionStats(
                ['agent_id' => $agentId],
                'custom',
                $startDate,
                $endDate
            );
            
            // 获取营销活动效果数据
            $promotionStats = $this->promotionService->getPromotionStats($startDate, $endDate);
            
            // 获取会员系统统计数据
            $memberStats = $this->memberService->getMemberSystemStats($startDate, $endDate);
            
            // 获取限时秒杀活动效果
            $flashSaleStats = $this->flashSaleManager->getFlashSaleStats($startDate, $endDate);
            
            // 整合所有数据
            return [
                'success' => true,
                'data' => [
                    'summary' => [
                        'date_range' => [
                            'start' => $startDate,
                            'end' => $endDate
                        ],
                        'total_orders' => $userSummary['data']['total_orders'] ?? 0,
                        'total_amount' => $userSummary['data']['total_amount'] ?? 0,
                        'total_users' => $userSummary['data']['total_users'] ?? 0,
                        'avg_order_value' => $userSummary['data']['avg_order_value'] ?? 0,
                        'total_agents' => $agentSummary['data']['total_agents'] ?? 0,
                        'conversion_rate' => $agentSummary['data']['average_conversion_rate'] ?? 0,
                        'active_promotions' => $promotionStats['data']['active_promotions'] ?? 0,
                        'promotion_revenue' => $promotionStats['data']['total_revenue'] ?? 0,
                        'member_count' => $memberStats['data']['total_members'] ?? 0,
                        'new_members' => $memberStats['data']['new_members'] ?? 0
                    ],
                    'user_analytics' => $userSummary['data'] ?? [],
                    'agent_analytics' => $agentSummary['data'] ?? [],
                    'promotion_analytics' => $promotionStats['data'] ?? [],
                    'member_analytics' => $memberStats['data'] ?? [],
                    'flash_sale_analytics' => $flashSaleStats['data'] ?? []
                ],
                'message' => '获取仪表盘数据成功'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => '获取仪表盘数据失败：' . $e->getMessage(),
                'error' => $e->getMessage()
            ];
        }
    }
}

// 确保类被正确加载
if (!class_exists('IntegratedMarketingSystem')) {
    throw new Exception('IntegratedMarketingSystem 类未被正确加载');
}