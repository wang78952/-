<?php
/**
 * 用户购卡偏好分析业务逻辑类
 * 提供用户购买行为分析、产品偏好统计等功能
 */
class UserPurchaseAnalytics {
    private $db;
    
    /**
     * 构造函数
     * @param mysqli $db 数据库连接对象
     */
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * 获取用户购卡偏好分析
     * @param array $params 查询参数
     * @return array 分析结果
     */
    public function getUserPurchasePreferences($params = []) {
        $filters = $this->buildFilters($params);
        $start_date = $params['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
        $end_date = $params['end_date'] ?? date('Y-m-d');
        $user_id = $params['user_id'] ?? null;
        $limit = $params['limit'] ?? 20;
        
        // 1. 用户产品偏好统计
        $product_preferences = $this->getUserProductPreferences($start_date, $end_date, $user_id, $limit);
        
        // 2. 价格区间偏好
        $price_range_preferences = $this->getPriceRangePreferences($start_date, $end_date, $user_id);
        
        // 3. 分类偏好
        $category_preferences = $this->getCategoryPreferences($start_date, $end_date, $user_id);
        
        // 4. 购买时间偏好
        $time_preferences = $this->getPurchaseTimePreferences($start_date, $end_date, $user_id);
        
        // 5. 购买频率分析
        $frequency_analysis = $this->getPurchaseFrequencyAnalysis($start_date, $end_date, $user_id);
        
        return [
            'product_preferences' => $product_preferences,
            'price_range_preferences' => $price_range_preferences,
            'category_preferences' => $category_preferences,
            'time_preferences' => $time_preferences,
            'frequency_analysis' => $frequency_analysis,
            'summary' => [
                'total_users' => $this->getTotalUsers($filters),
                'total_orders' => $this->getTotalOrders($filters),
                'total_amount' => $this->getTotalAmount($filters),
                'avg_order_value' => $this->getAvgOrderValue($filters),
                'date_range' => [
                    'start' => $start_date,
                    'end' => $end_date
                ]
            ]
        ];
    }
    
    /**
     * 获取用户产品偏好统计
     * @param string $start_date 开始日期
     * @param string $end_date 结束日期
     * @param int $user_id 用户ID（可选）
     * @param int $limit 限制数量
     * @return array 产品偏好统计
     */
    public function getUserProductPreferences($start_date, $end_date, $user_id = null, $limit = 20) {
        $userFilter = $user_id ? "AND o.user_id = {$user_id}" : '';
        
        $sql = "
            SELECT 
                p.id as product_id,
                p.name as product_name,
                p.category_id,
                c.name as category_name,
                p.price,
                COUNT(oc.id) as purchase_count,
                SUM(oc.quantity) as total_quantity,
                SUM(oc.quantity * p.price) as total_amount,
                ROUND(AVG(p.price), 2) as avg_price
            FROM 
                orders o
            JOIN 
                order_cards oc ON o.id = oc.order_id
            JOIN 
                cards cds ON oc.card_id = cds.id
            JOIN 
                products p ON cds.product_id = p.id
            LEFT JOIN 
                categories c ON p.category_id = c.id
            WHERE 
                o.created_at BETWEEN '{$start_date} 00:00:00' AND '{$end_date} 23:59:59'
                AND o.status = 'completed'
                {$userFilter}
            GROUP BY 
                p.id, p.name, p.category_id, c.name, p.price
            ORDER BY 
                purchase_count DESC
            LIMIT {$limit}
        ";
        
        $result = $this->db->query($sql);
        $preferences = [];
        
        while ($row = $result->fetch_assoc()) {
            $preferences[] = $row;
        }
        
        return $preferences;
    }
    
    /**
     * 获取价格区间偏好
     * @param string $start_date 开始日期
     * @param string $end_date 结束日期
     * @param int $user_id 用户ID（可选）
     * @return array 价格区间偏好
     */
    public function getPriceRangePreferences($start_date, $end_date, $user_id = null) {
        $userFilter = $user_id ? "AND o.user_id = {$user_id}" : '';
        
        $sql = "
            SELECT 
                CASE
                    WHEN p.price < 50 THEN '0-50'
                    WHEN p.price < 100 THEN '50-100'
                    WHEN p.price < 500 THEN '100-500'
                    WHEN p.price < 1000 THEN '500-1000'
                    ELSE '1000+'
                END as price_range,
                COUNT(oc.id) as purchase_count,
                SUM(oc.quantity) as total_quantity,
                SUM(oc.quantity * p.price) as total_amount,
                ROUND(AVG(p.price), 2) as avg_price
            FROM 
                orders o
            JOIN 
                order_cards oc ON o.id = oc.order_id
            JOIN 
                cards cds ON oc.card_id = cds.id
            JOIN 
                products p ON cds.product_id = p.id
            WHERE 
                o.created_at BETWEEN '{$start_date} 00:00:00' AND '{$end_date} 23:59:59'
                AND o.status = 'completed'
                {$userFilter}
            GROUP BY 
                price_range
            ORDER BY 
                FIELD(price_range, '0-50', '50-100', '100-500', '500-1000', '1000+')
        ";
        
        $result = $this->db->query($sql);
        $preferences = [];
        
        while ($row = $result->fetch_assoc()) {
            $preferences[] = $row;
        }
        
        return $preferences;
    }
    
    /**
     * 获取分类偏好
     * @param string $start_date 开始日期
     * @param string $end_date 结束日期
     * @param int $user_id 用户ID（可选）
     * @return array 分类偏好
     */
    public function getCategoryPreferences($start_date, $end_date, $user_id = null) {
        $userFilter = $user_id ? "AND o.user_id = {$user_id}" : '';
        
        $sql = "
            SELECT 
                c.id as category_id,
                c.name as category_name,
                COUNT(oc.id) as purchase_count,
                SUM(oc.quantity) as total_quantity,
                SUM(oc.quantity * p.price) as total_amount,
                ROUND(AVG(p.price), 2) as avg_price
            FROM 
                orders o
            JOIN 
                order_cards oc ON o.id = oc.order_id
            JOIN 
                cards cds ON oc.card_id = cds.id
            JOIN 
                products p ON cds.product_id = p.id
            LEFT JOIN 
                categories c ON p.category_id = c.id
            WHERE 
                o.created_at BETWEEN '{$start_date} 00:00:00' AND '{$end_date} 23:59:59'
                AND o.status = 'completed'
                {$userFilter}
            GROUP BY 
                c.id, c.name
            ORDER BY 
                purchase_count DESC
        ";
        
        $result = $this->db->query($sql);
        $preferences = [];
        
        while ($row = $result->fetch_assoc()) {
            $preferences[] = $row;
        }
        
        return $preferences;
    }
    
    /**
     * 获取购买时间偏好
     * @param string $start_date 开始日期
     * @param string $end_date 结束日期
     * @param int $user_id 用户ID（可选）
     * @return array 购买时间偏好
     */
    public function getPurchaseTimePreferences($start_date, $end_date, $user_id = null) {
        $userFilter = $user_id ? "AND user_id = {$user_id}" : '';
        
        // 按小时统计
        $hour_sql = "
            SELECT 
                HOUR(created_at) as hour,
                COUNT(*) as order_count,
                COUNT(DISTINCT user_id) as user_count,
                SUM(total_amount) as total_amount
            FROM 
                orders
            WHERE 
                created_at BETWEEN '{$start_date} 00:00:00' AND '{$end_date} 23:59:59'
                AND status = 'completed'
                {$userFilter}
            GROUP BY 
                HOUR(created_at)
            ORDER BY 
                hour
        ";
        
        // 按星期统计
        $weekday_sql = "
            SELECT 
                DAYOFWEEK(created_at) as weekday,
                CASE DAYOFWEEK(created_at)
                    WHEN 1 THEN '周日'
                    WHEN 2 THEN '周一'
                    WHEN 3 THEN '周二'
                    WHEN 4 THEN '周三'
                    WHEN 5 THEN '周四'
                    WHEN 6 THEN '周五'
                    WHEN 7 THEN '周六'
                END as weekday_name,
                COUNT(*) as order_count,
                COUNT(DISTINCT user_id) as user_count,
                SUM(total_amount) as total_amount
            FROM 
                orders
            WHERE 
                created_at BETWEEN '{$start_date} 00:00:00' AND '{$end_date} 23:59:59'
                AND status = 'completed'
                {$userFilter}
            GROUP BY 
                DAYOFWEEK(created_at), weekday_name
            ORDER BY 
                weekday
        ";
        
        $hour_result = $this->db->query($hour_sql);
        $weekday_result = $this->db->query($weekday_sql);
        
        $hour_preferences = [];
        $weekday_preferences = [];
        
        while ($row = $hour_result->fetch_assoc()) {
            $hour_preferences[] = $row;
        }
        
        while ($row = $weekday_result->fetch_assoc()) {
            $weekday_preferences[] = $row;
        }
        
        return [
            'hourly' => $hour_preferences,
            'weekday' => $weekday_preferences
        ];
    }
    
    /**
     * 获取购买频率分析
     * @param string $start_date 开始日期
     * @param string $end_date 结束日期
     * @param int $user_id 用户ID（可选）
     * @return array 购买频率分析
     */
    public function getPurchaseFrequencyAnalysis($start_date, $end_date, $user_id = null) {
        $userFilter = $user_id ? "AND user_id = {$user_id}" : '';
        
        $sql = "
            SELECT 
                purchase_count,
                COUNT(*) as user_count,
                ROUND(AVG(total_spent), 2) as avg_spent_per_user
            FROM (
                SELECT 
                    user_id,
                    COUNT(*) as purchase_count,
                    SUM(total_amount) as total_spent
                FROM 
                    orders
                WHERE 
                    created_at BETWEEN '{$start_date} 00:00:00' AND '{$end_date} 23:59:59'
                    AND status = 'completed'
                    {$userFilter}
                GROUP BY 
                    user_id
            ) as user_purchases
            GROUP BY 
                purchase_count
            ORDER BY 
                purchase_count
        ";
        
        $result = $this->db->query($sql);
        $analysis = [];
        
        while ($row = $result->fetch_assoc()) {
            $analysis[] = $row;
        }
        
        return $analysis;
    }
    
    /**
     * 获取产品推荐
     * @param int $user_id 用户ID
     * @param int $limit 推荐数量
     * @return array 推荐产品列表
     */
    public function getProductRecommendations($user_id, $limit = 10) {
        // 基于用户历史购买行为的推荐
        $recommendations = [];
        
        // 1. 同类产品推荐
        $category_based = $this->getCategoryBasedRecommendations($user_id, $limit);
        
        // 2. 热门产品推荐
        $popular_products = $this->getPopularProducts($limit);
        
        // 3. 价格区间相似产品推荐
        $price_based = $this->getPriceBasedRecommendations($user_id, $limit);
        
        return [
            'category_based' => $category_based,
            'popular_products' => $popular_products,
            'price_based' => $price_based
        ];
    }
    
    /**
     * 获取分类相关推荐
     * @param int $user_id 用户ID
     * @param int $limit 推荐数量
     * @return array 推荐产品
     */
    private function getCategoryBasedRecommendations($user_id, $limit) {
        $sql = "
            SELECT 
                p.id, p.name, p.price, p.image_url, p.category_id,
                COUNT(oc.id) as popularity_score
            FROM 
                products p
            JOIN 
                cards cds ON p.id = cds.product_id
            JOIN 
                order_cards oc ON cds.id = oc.card_id
            JOIN 
                orders o ON oc.order_id = o.id
            WHERE 
                p.category_id IN (
                    SELECT DISTINCT p.category_id
                    FROM 
                        orders o2
                    JOIN 
                        order_cards oc2 ON o2.id = oc2.order_id
                    JOIN 
                        cards cds2 ON oc2.card_id = cds2.id
                    JOIN 
                        products p ON cds2.product_id = p.id
                    WHERE 
                        o2.user_id = {$user_id}
                        AND o2.status = 'completed'
                )
                AND p.id NOT IN (
                    SELECT DISTINCT cds.product_id
                    FROM 
                        orders o3
                    JOIN 
                        order_cards oc3 ON o3.id = oc3.order_id
                    JOIN 
                        cards cds ON oc3.card_id = cds.id
                    WHERE 
                        o3.user_id = {$user_id}
                )
                AND p.status = 'active'
            GROUP BY 
                p.id, p.name, p.price, p.image_url, p.category_id
            ORDER BY 
                popularity_score DESC
            LIMIT {$limit}
        ";
        
        $result = $this->db->query($sql);
        $recommendations = [];
        
        while ($row = $result->fetch_assoc()) {
            $recommendations[] = $row;
        }
        
        return $recommendations;
    }
    
    /**
     * 获取热门产品
     * @param int $limit 推荐数量
     * @return array 热门产品
     */
    private function getPopularProducts($limit) {
        $sql = "
            SELECT 
                p.id, p.name, p.price, p.image_url, p.category_id,
                COUNT(oc.id) as sales_count,
                SUM(oc.quantity) as total_quantity
            FROM 
                products p
            JOIN 
                cards cds ON p.id = cds.product_id
            JOIN 
                order_cards oc ON cds.id = oc.card_id
            JOIN 
                orders o ON oc.order_id = o.id
            WHERE 
                o.status = 'completed'
                AND p.status = 'active'
            GROUP BY 
                p.id, p.name, p.price, p.image_url, p.category_id
            ORDER BY 
                sales_count DESC
            LIMIT {$limit}
        ";
        
        $result = $this->db->query($sql);
        $products = [];
        
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        
        return $products;
    }
    
    /**
     * 获取价格区间相关推荐
     * @param int $user_id 用户ID
     * @param int $limit 推荐数量
     * @return array 推荐产品
     */
    private function getPriceBasedRecommendations($user_id, $limit) {
        // 获取用户平均购买价格
        $avg_price_sql = "
            SELECT 
                AVG(p.price) as avg_purchase_price
            FROM 
                orders o
            JOIN 
                order_cards oc ON o.id = oc.order_id
            JOIN 
                cards cds ON oc.card_id = cds.id
            JOIN 
                products p ON cds.product_id = p.id
            WHERE 
                o.user_id = {$user_id}
                AND o.status = 'completed'
        ";
        
        $result = $this->db->query($avg_price_sql);
        $row = $result->fetch_assoc();
        $avg_price = $row['avg_purchase_price'] ?? 100;
        
        // 获取价格相近的产品
        $price_range = $avg_price * 0.3; // 30% 价格浮动范围
        $min_price = max(0, $avg_price - $price_range);
        $max_price = $avg_price + $price_range;
        
        $sql = "
            SELECT 
                p.id, p.name, p.price, p.image_url, p.category_id,
                ABS(p.price - {$avg_price}) as price_similarity
            FROM 
                products p
            WHERE 
                p.price BETWEEN {$min_price} AND {$max_price}
                AND p.id NOT IN (
                    SELECT DISTINCT cds.product_id
                    FROM 
                        orders o3
                    JOIN 
                        order_cards oc3 ON o3.id = oc3.order_id
                    JOIN 
                        cards cds ON oc3.card_id = cds.id
                    WHERE 
                        o3.user_id = {$user_id}
                )
                AND p.status = 'active'
            ORDER BY 
                price_similarity ASC, RAND()
            LIMIT {$limit}
        ";
        
        $result = $this->db->query($sql);
        $recommendations = [];
        
        while ($row = $result->fetch_assoc()) {
            $recommendations[] = $row;
        }
        
        return $recommendations;
    }
    
    /**
     * 构建筛选条件
     * @param array $params 参数
     * @return array 筛选条件
     */
    private function buildFilters($params) {
        $filters = [];
        if (!empty($params['start_date'])) {
            $filters['start_date'] = $params['start_date'];
        }
        if (!empty($params['end_date'])) {
            $filters['end_date'] = $params['end_date'];
        }
        if (!empty($params['user_id'])) {
            $filters['user_id'] = $params['user_id'];
        }
        return $filters;
    }
    
    /**
     * 获取总用户数
     * @param array $filters 筛选条件
     * @return int 用户数
     */
    private function getTotalUsers($filters = []) {
        $where = $this->buildWhereClause($filters);
        $sql = "SELECT COUNT(DISTINCT user_id) as total FROM orders WHERE status = 'completed' {$where}";
        $result = $this->db->query($sql);
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }
    
    /**
     * 获取总订单数
     * @param array $filters 筛选条件
     * @return int 订单数
     */
    private function getTotalOrders($filters = []) {
        $where = $this->buildWhereClause($filters);
        $sql = "SELECT COUNT(*) as total FROM orders WHERE status = 'completed' {$where}";
        $result = $this->db->query($sql);
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }
    
    /**
     * 获取总金额
     * @param array $filters 筛选条件
     * @return float 总金额
     */
    private function getTotalAmount($filters = []) {
        $where = $this->buildWhereClause($filters);
        $sql = "SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed' {$where}";
        $result = $this->db->query($sql);
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }
    
    /**
     * 获取平均订单价值
     * @param array $filters 筛选条件
     * @return float 平均订单价值
     */
    private function getAvgOrderValue($filters = []) {
        $where = $this->buildWhereClause($filters);
        $sql = "SELECT AVG(total_amount) as avg FROM orders WHERE status = 'completed' {$where}";
        $result = $this->db->query($sql);
        $row = $result->fetch_assoc();
        return $row['avg'] ?? 0;
    }
    
    /**
     * 构建WHERE子句
     * @param array $filters 筛选条件
     * @return string WHERE子句
     */
    private function buildWhereClause($filters = []) {
        $where = [];
        
        if (!empty($filters['start_date'])) {
            $where[] = "created_at >= '{$filters['start_date']} 00:00:00'";
        }
        
        if (!empty($filters['end_date'])) {
            $where[] = "created_at <= '{$filters['end_date']} 23:59:59'";
        }
        
        if (!empty($filters['user_id'])) {
            $where[] = "user_id = {$filters['user_id']}";
        }
        
        return $where ? 'AND ' . implode(' AND ', $where) : '';
    }
}
?>