<?php
/**
 * 数据分析仪表盘服务类
 * 处理营销数据分析平台的核心业务逻辑
 * 包括代理推广效果统计和用户购卡偏好分析
 */

class AnalyticsDashboardService {
    private $db; // 数据库连接
    private $logger; // 日志记录器
    private $cache; // 缓存服务
    
    /**
     * 构造函数
     * @param PDO $db 数据库连接对象
     */
    public function __construct(PDO $db) {
        $this->db = $db;
        $this->logger = new Logger('analytics');
        $this->cache = new CacheService();
    }
    
    /**
     * 获取代理推广效果统计数据
     * @param array $filters 筛选条件，包括时间范围、代理ID等
     * @return array 代理推广效果数据
     */
    public function getAgentPromotionStats($filters = array()) {
        try {
            // 构建缓存键
            $cacheKey = 'agent_promotion_stats_' . md5(json_encode($filters));
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 构建查询条件
            $query = "SELECT 
                a.agent_id, 
                a.agent_name, 
                COUNT(p.visit_id) as total_visits,
                COUNT(DISTINCT p.user_id) as unique_visitors,
                COUNT(CASE WHEN p.converted = 1 THEN p.visit_id END) as converted_visits,
                SUM(CASE WHEN p.converted = 1 THEN o.order_amount ELSE 0 END) as total_revenue,
                COUNT(DISTINCT CASE WHEN p.converted = 1 THEN o.order_id END) as converted_orders
                FROM agent_promotion_stats p
                LEFT JOIN agents a ON p.agent_id = a.agent_id
                LEFT JOIN orders o ON p.visit_id = o.visit_id
                WHERE 1=1";
            
            $params = array();
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $query .= " AND p.visit_time >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND p.visit_time <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            // 添加代理ID筛选
            if (!empty($filters['agent_id'])) {
                $query .= " AND p.agent_id = :agent_id";
                $params[':agent_id'] = $filters['agent_id'];
            }
            
            // 分组和排序
            $query .= " GROUP BY a.agent_id, a.agent_name ORDER BY total_visits DESC";
            
            // 执行查询
            $stmt = $this->db->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 计算额外的统计指标
            foreach ($results as &$result) {
                // 计算转化率
                $result['conversion_rate'] = $result['total_visits'] > 0 
                    ? ($result['converted_visits'] / $result['total_visits']) * 100 
                    : 0;
                
                // 计算平均订单价值
                $result['avg_order_value'] = $result['converted_orders'] > 0
                    ? $result['total_revenue'] / $result['converted_orders']
                    : 0;
                
                // 计算每访客收入
                $result['revenue_per_visitor'] = $result['unique_visitors'] > 0
                    ? $result['total_revenue'] / $result['unique_visitors']
                    : 0;
            }
            
            // 缓存结果（缓存1小时）
            $this->cache->set($cacheKey, $results, 3600);
            
            return $results;
        } catch (Exception $e) {
            $this->logger->error('获取代理推广效果统计数据失败: ' . $e->getMessage());
            throw new Exception('获取代理推广效果数据失败');
        }
    }
    
    /**
     * 获取代理推广趋势数据
     * @param array $filters 筛选条件
     * @return array 代理推广趋势数据
     */
    public function getAgentPromotionTrend($filters = array()) {
        try {
            // 构建缓存键
            $cacheKey = 'agent_promotion_trend_' . md5(json_encode($filters));
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间粒度
            $dateFormat = $this->determineDateFormat($filters);
            
            // 构建查询
            $query = "SELECT 
                DATE_FORMAT(p.visit_time, :date_format) as period,
                COUNT(p.visit_id) as total_visits,
                COUNT(DISTINCT p.user_id) as unique_visitors,
                COUNT(CASE WHEN p.converted = 1 THEN p.visit_id END) as converted_visits,
                SUM(CASE WHEN p.converted = 1 THEN o.order_amount ELSE 0 END) as total_revenue,
                COUNT(DISTINCT CASE WHEN p.converted = 1 THEN o.order_id END) as converted_orders
                FROM agent_promotion_stats p
                LEFT JOIN orders o ON p.visit_id = o.visit_id
                WHERE 1=1";
            
            $params = array(':date_format' => $dateFormat);
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $query .= " AND p.visit_time >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND p.visit_time <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            // 添加代理ID筛选
            if (!empty($filters['agent_id'])) {
                $query .= " AND p.agent_id = :agent_id";
                $params[':agent_id'] = $filters['agent_id'];
            }
            
            // 分组和排序
            $query .= " GROUP BY period ORDER BY period ASC";
            
            // 执行查询
            $stmt = $this->db->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 计算额外的统计指标
            foreach ($results as &$result) {
                $result['conversion_rate'] = $result['total_visits'] > 0 
                    ? ($result['converted_visits'] / $result['total_visits']) * 100 
                    : 0;
            }
            
            // 缓存结果（缓存1小时）
            $this->cache->set($cacheKey, $results, 3600);
            
            return $results;
        } catch (Exception $e) {
            $this->logger->error('获取代理推广趋势数据失败: ' . $e->getMessage());
            throw new Exception('获取代理推广趋势数据失败');
        }
    }
    
    /**
     * 获取用户购卡偏好分析数据
     * @param array $filters 筛选条件
     * @return array 用户购卡偏好数据
     */
    public function getUserPurchasePreferences($filters = array()) {
        try {
            // 构建缓存键
            $cacheKey = 'user_purchase_preferences_' . md5(json_encode($filters));
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 1. 产品类别偏好
            $categoryQuery = "SELECT 
                c.category_id, 
                c.category_name,
                COUNT(o.order_item_id) as purchase_count,
                SUM(o.item_amount) as total_amount,
                COUNT(DISTINCT o.user_id) as unique_users
                FROM order_items o
                JOIN products p ON o.product_id = p.product_id
                JOIN product_categories c ON p.category_id = c.category_id
                JOIN orders ord ON o.order_id = ord.order_id
                WHERE ord.order_status = 'completed'";
            
            $categoryParams = array();
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $categoryQuery .= " AND ord.order_time >= :start_date";
                $categoryParams[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $categoryQuery .= " AND ord.order_time <= :end_date";
                $categoryParams[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            // 添加用户ID筛选
            if (!empty($filters['user_id'])) {
                $categoryQuery .= " AND o.user_id = :user_id";
                $categoryParams[':user_id'] = $filters['user_id'];
            }
            
            $categoryQuery .= " GROUP BY c.category_id, c.category_name ORDER BY purchase_count DESC";
            
            // 执行查询
            $stmt = $this->db->prepare($categoryQuery);
            $stmt->execute($categoryParams);
            $categoryPreferences = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 2. 价格区间偏好
            $priceRangeQuery = "SELECT 
                CASE 
                    WHEN p.price < 50 THEN '0-50'
                    WHEN p.price BETWEEN 50 AND 100 THEN '50-100'
                    WHEN p.price BETWEEN 100 AND 200 THEN '100-200'
                    WHEN p.price BETWEEN 200 AND 500 THEN '200-500'
                    ELSE '500+'
                END as price_range,
                COUNT(o.order_item_id) as purchase_count,
                SUM(o.item_amount) as total_amount,
                COUNT(DISTINCT o.user_id) as unique_users
                FROM order_items o
                JOIN products p ON o.product_id = p.product_id
                JOIN orders ord ON o.order_id = ord.order_id
                WHERE ord.order_status = 'completed'";
            
            $priceParams = array();
            
            // 添加相同的筛选条件
            if (!empty($filters['start_date'])) {
                $priceRangeQuery .= " AND ord.order_time >= :start_date";
                $priceParams[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $priceRangeQuery .= " AND ord.order_time <= :end_date";
                $priceParams[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            if (!empty($filters['user_id'])) {
                $priceRangeQuery .= " AND o.user_id = :user_id";
                $priceParams[':user_id'] = $filters['user_id'];
            }
            
            $priceRangeQuery .= " GROUP BY price_range ORDER BY MIN(p.price) ASC";
            
            // 执行查询
            $stmt = $this->db->prepare($priceRangeQuery);
            $stmt->execute($priceParams);
            $pricePreferences = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 3. 购买时间偏好
            $timeQuery = "SELECT 
                HOUR(ord.order_time) as hour_of_day,
                COUNT(o.order_item_id) as purchase_count,
                SUM(o.item_amount) as total_amount
                FROM order_items o
                JOIN orders ord ON o.order_id = ord.order_id
                WHERE ord.order_status = 'completed'";
            
            $timeParams = array();
            
            // 添加相同的筛选条件
            if (!empty($filters['start_date'])) {
                $timeQuery .= " AND ord.order_time >= :start_date";
                $timeParams[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $timeQuery .= " AND ord.order_time <= :end_date";
                $timeParams[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            if (!empty($filters['user_id'])) {
                $timeQuery .= " AND o.user_id = :user_id";
                $timeParams[':user_id'] = $filters['user_id'];
            }
            
            $timeQuery .= " GROUP BY HOUR(ord.order_time) ORDER BY hour_of_day ASC";
            
            // 执行查询
            $stmt = $this->db->prepare($timeQuery);
            $stmt->execute($timeParams);
            $timePreferences = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 整合所有偏好数据
            $preferences = array(
                'category' => $categoryPreferences,
                'price_range' => $pricePreferences,
                'time' => $timePreferences
            );
            
            // 缓存结果（缓存1小时）
            $this->cache->set($cacheKey, $preferences, 3600);
            
            return $preferences;
        } catch (Exception $e) {
            $this->logger->error('获取用户购卡偏好数据失败: ' . $e->getMessage());
            throw new Exception('获取用户购卡偏好数据失败');
        }
    }
    
    /**
     * 获取热门产品数据
     * @param array $filters 筛选条件
     * @param int $limit 返回数量限制
     * @return array 热门产品数据
     */
    public function getPopularProducts($filters = array(), $limit = 10) {
        try {
            // 构建缓存键
            $cacheKey = 'popular_products_' . md5(json_encode($filters)) . '_' . $limit;
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 构建查询
            $query = "SELECT 
                p.product_id,
                p.product_name,
                c.category_name,
                COUNT(o.order_item_id) as sales_count,
                SUM(o.item_amount) as total_sales,
                ROUND(AVG(p.price), 2) as avg_price
                FROM order_items o
                JOIN products p ON o.product_id = p.product_id
                JOIN product_categories c ON p.category_id = c.category_id
                JOIN orders ord ON o.order_id = ord.order_id
                WHERE ord.order_status = 'completed'";
            
            $params = array();
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $query .= " AND ord.order_time >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND ord.order_time <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            $query .= " GROUP BY p.product_id, p.product_name, c.category_name
                        ORDER BY sales_count DESC, total_sales DESC
                        LIMIT :limit";
            
            // 执行查询
            $stmt = $this->db->prepare($query);
            $params[':limit'] = (int)$limit;
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 计算市场份额
            $totalSales = array_sum(array_column($results, 'total_sales'));
            foreach ($results as &$product) {
                $product['market_share'] = $totalSales > 0
                    ? round(($product['total_sales'] / $totalSales) * 100, 2)
                    : 0;
            }
            
            // 缓存结果（缓存1小时）
            $this->cache->set($cacheKey, $results, 3600);
            
            return $results;
        } catch (Exception $e) {
            $this->logger->error('获取热门产品数据失败: ' . $e->getMessage());
            throw new Exception('获取热门产品数据失败');
        }
    }
    
    /**
     * 获取高价值客户列表
     * @param array $filters 筛选条件
     * @param int $limit 返回数量限制
     * @return array 高价值客户数据
     */
    public function getHighValueCustomers($filters = array(), $limit = 10) {
        try {
            // 构建缓存键
            $cacheKey = 'high_value_customers_' . md5(json_encode($filters)) . '_' . $limit;
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 构建查询
            $query = "SELECT 
                u.user_id,
                u.username,
                u.email,
                COUNT(DISTINCT o.order_id) as order_count,
                SUM(o.total_amount) as total_spending,
                ROUND(AVG(o.total_amount), 2) as avg_order_value,
                MAX(o.order_time) as last_purchase_time,
                ml.level_name as member_level
                FROM users u
                JOIN orders o ON u.user_id = o.user_id
                LEFT JOIN user_member_info umi ON u.user_id = umi.user_id
                LEFT JOIN member_levels ml ON umi.level_id = ml.level_id
                WHERE o.order_status = 'completed'";
            
            $params = array();
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $query .= " AND o.order_time >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND o.order_time <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            $query .= " GROUP BY u.user_id, u.username, u.email, ml.level_name
                        ORDER BY total_spending DESC, order_count DESC
                        LIMIT :limit";
            
            // 执行查询
            $stmt = $this->db->prepare($query);
            $params[':limit'] = (int)$limit;
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 缓存结果（缓存1小时）
            $this->cache->set($cacheKey, $results, 3600);
            
            return $results;
        } catch (Exception $e) {
            $this->logger->error('获取高价值客户数据失败: ' . $e->getMessage());
            throw new Exception('获取高价值客户数据失败');
        }
    }
    
    /**
     * 获取销售趋势数据
     * @param array $filters 筛选条件
     * @return array 销售趋势数据
     */
    public function getSalesTrend($filters = array()) {
        try {
            // 构建缓存键
            $cacheKey = 'sales_trend_' . md5(json_encode($filters));
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间粒度
            $dateFormat = $this->determineDateFormat($filters);
            
            // 构建查询
            $query = "SELECT 
                DATE_FORMAT(o.order_time, :date_format) as period,
                COUNT(o.order_id) as order_count,
                COUNT(DISTINCT o.user_id) as unique_customers,
                SUM(o.total_amount) as total_sales,
                ROUND(AVG(o.total_amount), 2) as avg_order_value
                FROM orders o
                WHERE o.order_status = 'completed'";
            
            $params = array(':date_format' => $dateFormat);
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $query .= " AND o.order_time >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND o.order_time <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            $query .= " GROUP BY period ORDER BY period ASC";
            
            // 执行查询
            $stmt = $this->db->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 缓存结果（缓存1小时）
            $this->cache->set($cacheKey, $results, 3600);
            
            return $results;
        } catch (Exception $e) {
            $this->logger->error('获取销售趋势数据失败: ' . $e->getMessage());
            throw new Exception('获取销售趋势数据失败');
        }
    }
    
    /**
     * 根据时间范围确定日期格式
     * @param array $filters 筛选条件
     * @return string 日期格式
     */
    private function determineDateFormat($filters) {
        // 默认格式
        $format = '%Y-%m-%d'; // 按天
        
        // 如果没有提供日期范围，返回默认格式
        if (empty($filters['start_date']) || empty($filters['end_date'])) {
            return $format;
        }
        
        // 计算时间跨度
        $startDate = new DateTime($filters['start_date']);
        $endDate = new DateTime($filters['end_date']);
        $daysDiff = $startDate->diff($endDate)->days;
        
        // 根据时间跨度调整格式
        if ($daysDiff > 90) {
            $format = '%Y-%m'; // 超过90天按月份
        } elseif ($daysDiff > 14) {
            $format = '%Y-%m-%d'; // 15-90天按天
        } else {
            $format = '%Y-%m-%d %H:00'; // 14天内按小时
        }
        
        return $format;
    }
    
    /**
     * 获取营销仪表盘数据
     * @param array $filters 筛选条件
     * @return array 仪表盘数据
     */
    public function getDashboardData($filters = array()) {
        try {
            // 获取各类数据
            $dashboardData = array(
                'summary' => $this->getSummaryStats($filters),
                'sales_trend' => $this->getSalesTrend($filters),
                'agent_performance' => $this->getAgentPromotionStats($filters),
                'user_preferences' => $this->getUserPurchasePreferences($filters),
                'popular_products' => $this->getPopularProducts($filters, 10),
                'high_value_customers' => $this->getHighValueCustomers($filters, 10)
            );
            
            return $dashboardData;
        } catch (Exception $e) {
            $this->logger->error('获取仪表盘数据失败: ' . $e->getMessage());
            throw new Exception('获取仪表盘数据失败');
        }
    }
    
    /**
     * 获取摘要统计数据
     * @param array $filters 筛选条件
     * @return array 摘要统计数据
     */
    private function getSummaryStats($filters = array()) {
        try {
            // 构建缓存键
            $cacheKey = 'dashboard_summary_' . md5(json_encode($filters));
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 获取订单统计
            $orderQuery = "SELECT 
                COUNT(order_id) as total_orders,
                SUM(total_amount) as total_amount,
                ROUND(AVG(total_amount), 2) as avg_order_value
                FROM orders
                WHERE order_status = 'completed'";
            
            $params = array();
            
            // 添加时间范围筛选
            if (!empty($filters['start_date'])) {
                $orderQuery .= " AND order_time >= :start_date";
                $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $orderQuery .= " AND order_time <= :end_date";
                $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
            }
            
            // 执行查询
            $stmt = $this->db->prepare($orderQuery);
            $stmt->execute($params);
            $orderStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 获取用户统计
            $userQuery = "SELECT 
                COUNT(DISTINCT user_id) as total_users
                FROM orders
                WHERE order_status = 'completed'";
            
            // 添加相同的时间范围筛选
            if (!empty($filters['start_date'])) {
                $userQuery .= " AND order_time >= :start_date";
            }
            
            if (!empty($filters['end_date'])) {
                $userQuery .= " AND order_time <= :end_date";
            }
            
            // 执行查询
            $stmt = $this->db->prepare($userQuery);
            $stmt->execute($params);
            $userStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 计算转化率（简化版本：完成订单的用户数 / 总访问用户数）
            // 注意：在实际应用中，这个计算可能需要更复杂的逻辑，涉及到访问日志
            $conversionRate = 0;
            if (!empty($filters['agent_id'])) {
                // 针对特定代理计算转化率
                $convQuery = "SELECT 
                    COUNT(DISTINCT visit_id) as total_visits,
                    COUNT(DISTINCT CASE WHEN converted = 1 THEN visit_id END) as converted_visits
                    FROM agent_promotion_stats
                    WHERE agent_id = :agent_id";
                
                if (!empty($filters['start_date'])) {
                    $convQuery .= " AND visit_time >= :start_date";
                }
                
                if (!empty($filters['end_date'])) {
                    $convQuery .= " AND visit_time <= :end_date";
                }
                
                $stmt = $this->db->prepare($convQuery);
                $stmt->execute($params);
                $convStats = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $conversionRate = $convStats['total_visits'] > 0 
                    ? ($convStats['converted_visits'] / $convStats['total_visits']) 
                    : 0;
            }
            
            // 获取活跃促销数量
            $promotionQuery = "SELECT 
                COUNT(promotion_id) as active_promotions
                FROM promotions
                WHERE status = 'active'
                AND start_date <= NOW()
                AND end_date >= NOW()";
            
            $stmt = $this->db->prepare($promotionQuery);
            $stmt->execute();
            $promotionStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 整合摘要数据
            $summary = array(
                'total_orders' => $orderStats['total_orders'] ?? 0,
                'total_amount' => $orderStats['total_amount'] ?? 0,
                'avg_order_value' => $orderStats['avg_order_value'] ?? 0,
                'total_users' => $userStats['total_users'] ?? 0,
                'conversion_rate' => $conversionRate,
                'active_promotions' => $promotionStats['active_promotions'] ?? 0
            );
            
            // 获取代理数量
            $agentQuery = "SELECT COUNT(agent_id) as total_agents FROM agents WHERE status = 'active'";
            $stmt = $this->db->prepare($agentQuery);
            $stmt->execute();
            $agentStats = $stmt->fetch(PDO::FETCH_ASSOC);
            $summary['total_agents'] = $agentStats['total_agents'] ?? 0;
            
            // 缓存结果（缓存30分钟）
            $this->cache->set($cacheKey, $summary, 1800);
            
            return $summary;
        } catch (Exception $e) {
            $this->logger->error('获取摘要统计数据失败: ' . $e->getMessage());
            throw new Exception('获取摘要统计数据失败');
        }
    }
}