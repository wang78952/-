<?php
/**
 * 代理数据分析模块
 * 负责代理推广效果、转化率统计等数据分析功能
 */
class AgentAnalytics {
    private $database;
    private $config;
    private $logger;
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->database = getDB();
        $this->config = Config::getInstance();
        $this->logger = Logger::getInstance();
    }
    
    /**
     * 获取代理推广转化率统计
     * 支持按时间段、代理筛选，并提供转化率趋势数据
     * 
     * @param array $filters 筛选条件
     * @param string $dateRange 时间范围 (today, yesterday, 7days, 30days, custom)
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 统计数据
     */
    public function getAgentConversionStats($filters = array(), $dateRange = '7days', $startDate = '', $endDate = '') {
        try {
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange, $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 构建基础查询条件
            $whereClause = "WHERE 1=1";
            $params = array();
            
            // 应用时间范围
            $whereClause .= " AND clicked_at >= ? AND clicked_at <= ?";
            $params[] = $startDate;
            $params[] = $endDate;
            
            // 代理ID筛选
            if (!empty($filters['agent_id'])) {
                $whereClause .= " AND rc.agent_id = ?";
                $params[] = $filters['agent_id'];
            }
            
            // 代理等级筛选
            if (!empty($filters['level'])) {
                $whereClause .= " AND a.level = ?";
                $params[] = $filters['level'];
            }
            
            // 获取代理列表
            $agentsQuery = "
                SELECT 
                    a.id as agent_id,
                    a.contact_name as agent_name,
                    a.level,
                    (SELECT COUNT(*) FROM agents WHERE superior_id = a.id) as team_size,
                    COUNT(DISTINCT rc.id) as total_clicks,
                    COUNT(DISTINCT rc.ip_address) as unique_clicks,
                    COUNT(DISTINCT u.id) as registrations,
                    COUNT(DISTINCT o.id) as orders,
                    SUM(IFNULL(o.amount, 0)) as order_amount
                FROM agents a
                LEFT JOIN referral_clicks rc ON a.id = rc.agent_id {$whereClause}
                LEFT JOIN users u ON u.referral_code = a.referral_code AND u.created_at >= ? AND u.created_at <= ?
                LEFT JOIN orders o ON o.user_id = u.id AND o.created_at >= ? AND o.created_at <= ?
                GROUP BY a.id
                ORDER BY total_clicks DESC
            ";
            
            // 添加时间范围参数
            $params[] = $startDate;
            $params[] = $endDate;
            $params[] = $startDate;
            $params[] = $endDate;
            
            $agents = $this->database->query($agentsQuery, $params);
            
            // 计算转化率并添加到结果中
            $result = array();
            foreach ($agents as $agent) {
                // 计算各阶段转化率
                $clickRate = $agent['total_clicks'] > 0 ? 
                    round(($agent['unique_clicks'] / $agent['total_clicks']) * 100, 2) : 0;
                
                $regConversionRate = $agent['total_clicks'] > 0 ? 
                    round(($agent['registrations'] / $agent['total_clicks']) * 100, 2) : 0;
                
                $orderConversionRate = $agent['registrations'] > 0 ? 
                    round(($agent['orders'] / $agent['registrations']) * 100, 2) : 0;
                
                $avgOrderValue = $agent['orders'] > 0 ? 
                    round($agent['order_amount'] / $agent['orders'], 2) : 0;
                
                $result[] = array_merge($agent, array(
                    'click_rate' => $clickRate,
                    'reg_conversion_rate' => $regConversionRate,
                    'order_conversion_rate' => $orderConversionRate,
                    'total_conversion_rate' => $agent['total_clicks'] > 0 ? 
                        round(($agent['orders'] / $agent['total_clicks']) * 100, 2) : 0,
                    'avg_order_value' => $avgOrderValue
                ));
            }
            
            return $this->formatResponse(true, '获取代理转化率统计成功', $result);
            
        } catch (Exception $e) {
            $this->logger->error('获取代理转化率统计失败', array(
                'filters' => $filters,
                'dateRange' => $dateRange,
                'error' => $e->getMessage()
            ));
            return $this->formatResponse(false, '获取代理转化率统计失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取转化率趋势数据
     * 按天统计推广链接点击和转化率
     * 
     * @param int $agentId 代理ID，0表示所有代理
     * @param string $dateRange 时间范围
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 趋势数据
     */
    public function getConversionTrend($agentId = 0, $dateRange = '7days', $startDate = '', $endDate = '') {
        try {
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange, $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 构建基础查询条件
            $whereClause = "WHERE clicked_at >= ? AND clicked_at <= ?";
            $params = array($startDate, $endDate);
            
            // 代理ID筛选
            if ($agentId > 0) {
                $whereClause .= " AND agent_id = ?";
                $params[] = $agentId;
            }
            
            // 按天统计点击量
            $clicksQuery = "
                SELECT 
                    DATE(clicked_at) as date,
                    COUNT(*) as total_clicks,
                    COUNT(DISTINCT ip_address) as unique_clicks
                FROM referral_clicks
                {$whereClause}
                GROUP BY DATE(clicked_at)
                ORDER BY date ASC
            ";
            
            $clicksData = $this->database->query($clicksQuery, $params);
            
            // 构建注册统计的查询条件
            $regWhereClause = "WHERE created_at >= ? AND created_at <= ?";
            $regParams = array($startDate, $endDate);
            
            // 代理ID筛选
            if ($agentId > 0) {
                $regWhereClause .= " AND referral_code = (SELECT referral_code FROM agents WHERE id = ?)";
                $regParams[] = $agentId;
            }
            
            // 按天统计注册量
            $registrationsQuery = "
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as registrations
                FROM users
                {$regWhereClause}
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            ";
            
            $registrationsData = $this->database->query($registrationsQuery, $regParams);
            
            // 按天统计订单量和订单金额
            $ordersWhereClause = "WHERE o.created_at >= ? AND o.created_at <= ?";
            $ordersParams = array($startDate, $endDate);
            
            // 代理ID筛选
            if ($agentId > 0) {
                $ordersWhereClause .= " AND u.referral_code = (SELECT referral_code FROM agents WHERE id = ?)";
                $ordersParams[] = $agentId;
            }
            
            $ordersQuery = "
                SELECT 
                    DATE(o.created_at) as date,
                    COUNT(*) as orders,
                    SUM(o.amount) as order_amount
                FROM orders o
                LEFT JOIN users u ON o.user_id = u.id
                {$ordersWhereClause}
                GROUP BY DATE(o.created_at)
                ORDER BY date ASC
            ";
            
            $ordersData = $this->database->query($ordersQuery, $ordersParams);
            
            // 合并数据并计算转化率
            $clicksMap = $this->arrayToMap($clicksData, 'date');
            $registrationsMap = $this->arrayToMap($registrationsData, 'date');
            $ordersMap = $this->arrayToMap($ordersData, 'date');
            
            $result = array();
            $currentDate = new DateTime($startDate);
            $endDateObj = new DateTime($endDate);
            
            // 生成完整的日期序列
            while ($currentDate <= $endDateObj) {
                $dateStr = $currentDate->format('Y-m-d');
                $clicks = isset($clicksMap[$dateStr]) ? $clicksMap[$dateStr] : array('total_clicks' => 0, 'unique_clicks' => 0);
                $regs = isset($registrationsMap[$dateStr]) ? $registrationsMap[$dateStr]['registrations'] : 0;
                $ords = isset($ordersMap[$dateStr]) ? $ordersMap[$dateStr] : array('orders' => 0, 'order_amount' => 0);
                
                $result[] = array(
                    'date' => $dateStr,
                    'total_clicks' => $clicks['total_clicks'],
                    'unique_clicks' => $clicks['unique_clicks'],
                    'registrations' => $regs,
                    'orders' => $ords['orders'],
                    'order_amount' => $ords['order_amount'],
                    'registration_rate' => $clicks['total_clicks'] > 0 ? 
                        round(($regs / $clicks['total_clicks']) * 100, 2) : 0,
                    'conversion_rate' => $clicks['total_clicks'] > 0 ? 
                        round(($ords['orders'] / $clicks['total_clicks']) * 100, 2) : 0
                );
                
                $currentDate->modify('+1 day');
            }
            
            return $this->formatResponse(true, '获取转化率趋势成功', $result);
            
        } catch (Exception $e) {
            $this->logger->error('获取转化率趋势失败', array(
                'agentId' => $agentId,
                'dateRange' => $dateRange,
                'error' => $e->getMessage()
            ));
            return $this->formatResponse(false, '获取转化率趋势失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取推广效果排名
     * 按转化率、点击量、订单量等维度进行排名
     * 
     * @param string $sortBy 排序依据 (conversion_rate, clicks, registrations, orders, revenue)
     * @param int $limit 返回数量
     * @param string $dateRange 时间范围
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 排名数据
     */
    public function getAgentPerformanceRanking($sortBy = 'conversion_rate', $limit = 10, $dateRange = '30days', $startDate = '', $endDate = '') {
        try {
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange, $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 构建查询
            $query = "
                SELECT 
                    a.id as agent_id,
                    a.contact_name as agent_name,
                    a.level,
                    COUNT(DISTINCT rc.id) as total_clicks,
                    COUNT(DISTINCT u.id) as registrations,
                    COUNT(DISTINCT o.id) as orders,
                    SUM(IFNULL(o.amount, 0)) as revenue,
                    COUNT(DISTINCT rc.id) as click_count,
                    CASE 
                        WHEN COUNT(DISTINCT rc.id) > 0 THEN ROUND((COUNT(DISTINCT o.id) / COUNT(DISTINCT rc.id)) * 100, 2)
                        ELSE 0
                    END as conversion_rate
                FROM agents a
                LEFT JOIN referral_clicks rc ON a.id = rc.agent_id 
                    AND rc.clicked_at >= ? AND rc.clicked_at <= ?
                LEFT JOIN users u ON u.referral_code = a.referral_code 
                    AND u.created_at >= ? AND u.created_at <= ?
                LEFT JOIN orders o ON o.user_id = u.id 
                    AND o.created_at >= ? AND o.created_at <= ?
                WHERE a.status = 'active'
                GROUP BY a.id
                ORDER BY 
            ";
            
            // 根据排序依据添加排序规则
            $orderClause = '';
            switch ($sortBy) {
                case 'conversion_rate':
                    $orderClause = "conversion_rate DESC";
                    break;
                case 'clicks':
                    $orderClause = "total_clicks DESC";
                    break;
                case 'registrations':
                    $orderClause = "registrations DESC";
                    break;
                case 'orders':
                    $orderClause = "orders DESC";
                    break;
                case 'revenue':
                    $orderClause = "revenue DESC";
                    break;
                default:
                    $orderClause = "conversion_rate DESC";
            }
            
            $query .= $orderClause . " LIMIT ?";
            
            // 构建参数
            $params = array(
                $startDate, $endDate,
                $startDate, $endDate,
                $startDate, $endDate,
                $limit
            );
            
            $result = $this->database->query($query, $params);
            
            return $this->formatResponse(true, '获取代理排名成功', $result);
            
        } catch (Exception $e) {
            $this->logger->error('获取代理排名失败', array(
                'sortBy' => $sortBy,
                'limit' => $limit,
                'error' => $e->getMessage()
            ));
            return $this->formatResponse(false, '获取代理排名失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取代理推广效果详情
     * 提供单个代理的详细推广数据和趋势
     * 
     * @param int $agentId 代理ID
     * @param string $dateRange 时间范围
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 代理详情数据
     */
    public function getAgentPerformanceDetails($agentId, $dateRange = '30days', $startDate = '', $endDate = '') {
        try {
            // 验证代理是否存在
            $agent = $this->database->queryOne(
                "SELECT id, contact_name, level, status, created_at FROM agents WHERE id = ?",
                array($agentId)
            );
            
            if (!$agent) {
                return $this->formatResponse(false, '代理不存在');
            }
            
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange, $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 获取总体统计数据
            $summaryQuery = "
                SELECT 
                    COUNT(DISTINCT rc.id) as total_clicks,
                    COUNT(DISTINCT rc.ip_address) as unique_clicks,
                    COUNT(DISTINCT u.id) as registrations,
                    COUNT(DISTINCT o.id) as orders,
                    SUM(IFNULL(o.amount, 0)) as revenue,
                    COUNT(DISTINCT o.id) / NULLIF(COUNT(DISTINCT rc.id), 0) as conversion_rate,
                    COUNT(DISTINCT u.id) / NULLIF(COUNT(DISTINCT rc.id), 0) as registration_rate,
                    COUNT(DISTINCT o.id) / NULLIF(COUNT(DISTINCT u.id), 0) as order_rate
                FROM agents a
                LEFT JOIN referral_clicks rc ON a.id = rc.agent_id 
                    AND rc.clicked_at >= ? AND rc.clicked_at <= ?
                LEFT JOIN users u ON u.referral_code = a.referral_code 
                    AND u.created_at >= ? AND u.created_at <= ?
                LEFT JOIN orders o ON o.user_id = u.id 
                    AND o.created_at >= ? AND o.created_at <= ?
                WHERE a.id = ?
            ";
            
            $params = array(
                $startDate, $endDate,
                $startDate, $endDate,
                $startDate, $endDate,
                $agentId
            );
            
            $summary = $this->database->queryOne($summaryQuery, $params);
            
            // 获取趋势数据
            $trendData = $this->getConversionTrend($agentId, $dateRange, $startDate, $endDate);
            
            // 获取代理团队表现
            $teamQuery = "
                SELECT 
                    sa.id as agent_id,
                    sa.contact_name as agent_name,
                    sa.level,
                    COUNT(DISTINCT rc.id) as total_clicks,
                    COUNT(DISTINCT o.id) as orders,
                    SUM(IFNULL(o.amount, 0)) as revenue
                FROM agents sa
                LEFT JOIN agents a ON sa.superior_id = a.id
                LEFT JOIN referral_clicks rc ON sa.id = rc.agent_id 
                    AND rc.clicked_at >= ? AND rc.clicked_at <= ?
                LEFT JOIN users u ON u.referral_code = sa.referral_code
                LEFT JOIN orders o ON o.user_id = u.id 
                    AND o.created_at >= ? AND o.created_at <= ?
                WHERE a.id = ? AND sa.status = 'active'
                GROUP BY sa.id
                ORDER BY total_clicks DESC
            ";
            
            $teamParams = array(
                $startDate, $endDate,
                $startDate, $endDate,
                $agentId
            );
            
            $teamData = $this->database->query($teamQuery, $teamParams);
            
            // 构建返回数据
            $result = array(
                'agent_info' => $agent,
                'summary' => array(
                    'total_clicks' => $summary['total_clicks'],
                    'unique_clicks' => $summary['unique_clicks'],
                    'registrations' => $summary['registrations'],
                    'orders' => $summary['orders'],
                    'revenue' => $summary['revenue'],
                    'conversion_rate' => round(($summary['conversion_rate'] ?? 0) * 100, 2),
                    'registration_rate' => round(($summary['registration_rate'] ?? 0) * 100, 2),
                    'order_rate' => round(($summary['order_rate'] ?? 0) * 100, 2)
                ),
                'trend' => $trendData['data'] ?? array(),
                'team_performance' => $teamData
            );
            
            return $this->formatResponse(true, '获取代理详情成功', $result);
            
        } catch (Exception $e) {
            $this->logger->error('获取代理详情失败', array(
                'agentId' => $agentId,
                'dateRange' => $dateRange,
                'error' => $e->getMessage()
            ));
            return $this->formatResponse(false, '获取代理详情失败：' . $e->getMessage());
        }
    }
    
    /**
     * 生成图表所需的数据格式
     * 支持ECharts数据格式
     * 
     * @param array $data 原始数据
     * @param string $chartType 图表类型
     * @return array 图表数据格式
     */
    public function generateChartData($data, $chartType = 'line') {
        try {
            if (!is_array($data) || empty($data)) {
                return array(
                    'categories' => array(),
                    'series' => array()
                );
            }
            
            $result = array(
                'categories' => array(),
                'series' => array()
            );
            
            switch ($chartType) {
                case 'line':
                    // 假设数据是带date字段的数组
                    if (isset($data[0]['date'])) {
                        foreach ($data as $item) {
                            $result['categories'][] = $item['date'];
                        }
                        
                        // 添加转化率系列
                        $conversionData = array();
                        $clicksData = array();
                        $ordersData = array();
                        
                        foreach ($data as $item) {
                            $conversionData[] = $item['conversion_rate'] ?? 0;
                            $clicksData[] = $item['total_clicks'] ?? 0;
                            $ordersData[] = $item['orders'] ?? 0;
                        }
                        
                        $result['series'] = array(
                            array(
                                'name' => '转化率(%)',
                                'type' => 'line',
                                'data' => $conversionData,
                                'yAxisIndex' => 0
                            ),
                            array(
                                'name' => '点击量',
                                'type' => 'line',
                                'data' => $clicksData,
                                'yAxisIndex' => 1
                            ),
                            array(
                                'name' => '订单量',
                                'type' => 'line',
                                'data' => $ordersData,
                                'yAxisIndex' => 1
                            )
                        );
                    }
                    break;
                    
                case 'bar':
                    // 代理排名柱状图
                    if (isset($data[0]['agent_name'])) {
                        foreach ($data as $item) {
                            $result['categories'][] = $item['agent_name'];
                        }
                        
                        $conversionData = array();
                        foreach ($data as $item) {
                            $conversionData[] = $item['conversion_rate'] ?? 0;
                        }
                        
                        $result['series'] = array(
                            array(
                                'name' => '转化率(%)',
                                'type' => 'bar',
                                'data' => $conversionData
                            )
                        );
                    }
                    break;
                    
                case 'pie':
                    // 代理贡献占比饼图
                    $result['series'] = array(
                        array(
                            'name' => '贡献占比',
                            'type' => 'pie',
                            'data' => array()
                        )
                    );
                    
                    foreach ($data as $item) {
                        $result['series'][0]['data'][] = array(
                            'name' => $item['agent_name'],
                            'value' => $item['revenue'] ?? 0
                        );
                    }
                    break;
            }
            
            return $this->formatResponse(true, '生成图表数据成功', $result);
            
        } catch (Exception $e) {
            $this->logger->error('生成图表数据失败', array(
                'chartType' => $chartType,
                'error' => $e->getMessage()
            ));
            return $this->formatResponse(false, '生成图表数据失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取时间范围参数
     * 
     * @param string $dateRange 预定义时间范围
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 时间范围参数
     */
    private function getDateRangeParams($dateRange, $startDate, $endDate) {
        $now = new DateTime();
        $endDateObj = clone $now;
        $startDateObj = clone $now;
        
        switch ($dateRange) {
            case 'today':
                $startDateObj->setTime(0, 0, 0);
                $endDateObj->setTime(23, 59, 59);
                break;
            case 'yesterday':
                $startDateObj->modify('-1 day')->setTime(0, 0, 0);
                $endDateObj->modify('-1 day')->setTime(23, 59, 59);
                break;
            case '7days':
                $startDateObj->modify('-7 days')->setTime(0, 0, 0);
                $endDateObj->setTime(23, 59, 59);
                break;
            case '30days':
                $startDateObj->modify('-30 days')->setTime(0, 0, 0);
                $endDateObj->setTime(23, 59, 59);
                break;
            case 'custom':
                if ($startDate && $endDate) {
                    $startDateObj = new DateTime($startDate);
                    $endDateObj = new DateTime($endDate);
                    $endDateObj->setTime(23, 59, 59);
                } else {
                    // 默认使用最近30天
                    $startDateObj->modify('-30 days')->setTime(0, 0, 0);
                    $endDateObj->setTime(23, 59, 59);
                }
                break;
            default:
                // 默认使用最近7天
                $startDateObj->modify('-7 days')->setTime(0, 0, 0);
                $endDateObj->setTime(23, 59, 59);
        }
        
        return array(
            'startDate' => $startDateObj->format('Y-m-d H:i:s'),
            'endDate' => $endDateObj->format('Y-m-d H:i:s')
        );
    }
    
    /**
     * 将数组转换为以指定字段为键的映射
     * 
     * @param array $array 原始数组
     * @param string $key 作为键的字段名
     * @return array 映射数组
     */
    private function arrayToMap($array, $key) {
        $map = array();
        foreach ($array as $item) {
            if (isset($item[$key])) {
                $map[$item[$key]] = $item;
            }
        }
        return $map;
    }
    
    /**
     * 格式化响应数据
     * 
     * @param bool $success 是否成功
     * @param string $message 消息
     * @param mixed $data 数据
     * @return array 格式化的响应
     */
    private function formatResponse($success, $message, $data = null) {
        $response = array(
            'success' => $success,
            'message' => $message
        );
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        return $response;
    }
    
    /**
     * 获取仪表盘汇总数据
     * 提供完整的仪表盘统计信息，包括汇总数据、转化率趋势和顶级代理排名
     * 
     * @param string $startDate 开始日期
     * @param string $endDate 结束日期
     * @param int $agentId 代理ID，0表示所有代理
     * @param int $level 代理等级，0表示所有等级
     * @return array 仪表盘汇总数据
     */
    public function getDashboardSummary($startDate, $endDate, $agentId = 0, $level = 0) {
        try {
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams('custom', $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 1. 获取汇总统计
            $summaryQuery = "
                SELECT 
                    COUNT(DISTINCT rc.id) AS total_clicks,
                    COUNT(DISTINCT rc.ip_address) AS unique_clicks,
                    COUNT(DISTINCT u.id) AS registrations,
                    COUNT(DISTINCT o.id) AS orders,
                    SUM(IFNULL(o.amount, 0)) AS total_revenue,
                    CASE 
                        WHEN COUNT(DISTINCT rc.id) > 0 
                        THEN ROUND((COUNT(DISTINCT o.id) / COUNT(DISTINCT rc.id)) * 100, 2)
                        ELSE 0
                    END AS average_conversion_rate
                FROM agents a
                LEFT JOIN referral_clicks rc ON a.id = rc.agent_id AND rc.clicked_at >= ? AND rc.clicked_at <= ?
                LEFT JOIN users u ON u.referral_code = a.referral_code AND u.created_at >= ? AND u.created_at <= ?
                LEFT JOIN orders o ON o.user_id = u.id AND o.created_at >= ? AND o.created_at <= ?
                WHERE 1=1
            ";
            
            // 添加筛选条件
            $params = array(
                $startDate, $endDate,
                $startDate, $endDate,
                $startDate, $endDate
            );
            
            if ($agentId > 0) {
                $summaryQuery .= " AND a.id = ?";
                $params[] = $agentId;
            }
            
            if ($level > 0) {
                $summaryQuery .= " AND a.level = ?";
                $params[] = $level;
            }
            
            $summary = $this->database->queryOne($summaryQuery, $params);
            
            // 处理空值
            $summary['total_clicks'] = $summary['total_clicks'] ?? 0;
            $summary['unique_clicks'] = $summary['unique_clicks'] ?? 0;
            $summary['registrations'] = $summary['registrations'] ?? 0;
            $summary['orders'] = $summary['orders'] ?? 0;
            $summary['total_revenue'] = $summary['total_revenue'] ?? 0;
            $summary['average_conversion_rate'] = $summary['average_conversion_rate'] ?? 0;
            
            // 2. 获取转化率趋势
            $conversionTrend = $this->getConversionTrend($agentId, 'custom', $startDate, $endDate);
            
            // 3. 获取排名靠前的代理
            $topAgents = $this->getAgentPerformanceRanking('conversion_rate', 10, 'custom', $startDate, $endDate);
            
            // 返回完整数据
            return $this->formatResponse(true, '获取仪表盘汇总数据成功', array(
                'summary' => $summary,
                'conversion_trend' => $conversionTrend['data'] ?? array(),
                'top_agents' => $topAgents['data'] ?? array()
            ));
            
        } catch (Exception $e) {
            $this->logger->error('获取仪表盘汇总数据失败', array(
                'startDate' => $startDate,
                'endDate' => $endDate,
                'error' => $e->getMessage()
            ));
            return $this->formatResponse(false, '获取仪表盘汇总数据失败：' . $e->getMessage());
        }
    }
}