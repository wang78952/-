<?php
/**
 * 满减优惠活动管理业务逻辑类
 * 负责满减优惠活动的创建、管理、验证和应用
 */

class DiscountManager {
    private $database;
    private $logger;
    
    /**
     * 构造函数
     * @param Database $database 数据库连接对象
     * @param Logger $logger 日志对象
     */
    public function __construct($database, $logger) {
        $this->database = $database;
        $this->logger = $logger;
    }
    
    /**
     * 创建满减优惠活动
     * @param array $discountData 满减活动数据
     * @return int 创建的活动ID
     * @throws Exception 创建失败时抛出异常
     */
    public function createDiscountActivity($discountData) {
        try {
            // 数据验证
            $this->validateDiscountData($discountData);
            
            // 构建规则JSON
            $rules = [
                'threshold_amount' => isset($discountData['threshold_amount']) ? (float)$discountData['threshold_amount'] : 0,
                'discount_amount' => isset($discountData['discount_amount']) ? (float)$discountData['discount_amount'] : 0,
                'max_discount' => isset($discountData['max_discount']) ? (float)$discountData['max_discount'] : null,
                'step_discount' => isset($discountData['step_discount']) ? (bool)$discountData['step_discount'] : false,
                'step_rules' => isset($discountData['step_rules']) ? $discountData['step_rules'] : [],
                'product_scope' => isset($discountData['product_scope']) ? $discountData['product_scope'] : 'all',
                'product_data' => isset($discountData['product_data']) ? $discountData['product_data'] : [],
                'user_scope' => isset($discountData['user_scope']) ? $discountData['user_scope'] : 'all',
                'user_data' => isset($discountData['user_data']) ? $discountData['user_data'] : []
            ];
            
            // 构建目标用户数据
            $targetData = [];
            if ($discountData['user_scope'] == 'member_level') {
                $targetData['member_levels'] = isset($discountData['member_levels']) ? $discountData['member_levels'] : [];
            } elseif ($discountData['user_scope'] == 'specific_users') {
                $targetData['user_ids'] = isset($discountData['user_ids']) ? $discountData['user_ids'] : [];
            }
            
            // 插入数据
            $query = "INSERT INTO promotions 
                      (name, type, sub_type, description, start_time, end_time, status, rules, 
                       target_scope, target_data, max_usage, created_by) 
                      VALUES (?, 'discount', 'threshold', ?, ?, ?, 'draft', ?, 
                              ?, ?, ?, ?)";
            
            $this->database->execute($query, [
                $discountData['name'],
                $discountData['description'],
                $discountData['start_time'],
                $discountData['end_time'],
                json_encode($rules, JSON_UNESCAPED_UNICODE),
                $discountData['user_scope'],
                !empty($targetData) ? json_encode($targetData, JSON_UNESCAPED_UNICODE) : null,
                isset($discountData['max_usage']) ? (int)$discountData['max_usage'] : null,
                isset($discountData['created_by']) ? (int)$discountData['created_by'] : null
            ]);
            
            return $this->database->lastInsertId();
        } catch (Exception $e) {
            $this->logger->error('创建满减活动失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取满减活动列表
     * @param array $filters 筛选条件
     * @param int $page 页码
     * @param int $pageSize 每页数量
     * @return array 活动列表和总数
     */
    public function getDiscountActivities($filters = [], $page = 1, $pageSize = 20) {
        $where = [];
        $params = [];
        
        // 添加子类型筛选
        $where[] = "sub_type = 'threshold'";
        
        // 状态筛选
        if (isset($filters['status'])) {
            $where[] = "status = ?";
            $params[] = $filters['status'];
        }
        
        // 名称筛选
        if (isset($filters['name']) && !empty($filters['name'])) {
            $where[] = "name LIKE ?";
            $params[] = '%' . $filters['name'] . '%';
        }
        
        // 时间范围筛选
        if (isset($filters['date_range'])) {
            $where[] = "(start_time BETWEEN ? AND ? OR end_time BETWEEN ? AND ?)";
            $params[] = $filters['date_range']['start'];
            $params[] = $filters['date_range']['end'];
            $params[] = $filters['date_range']['start'];
            $params[] = $filters['date_range']['end'];
        }
        
        // 构建SQL查询
        $whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        
        // 获取总数
        $countQuery = "SELECT COUNT(*) as total FROM promotions " . $whereClause;
        $total = $this->database->selectOne($countQuery, $params)['total'];
        
        // 分页查询
        $offset = ($page - 1) * $pageSize;
        $query = "SELECT * FROM promotions " . $whereClause . 
                 " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $pageSize;
        $params[] = $offset;
        
        $activities = $this->database->select($query, $params);
        
        // 解析规则JSON
        foreach ($activities as &$activity) {
            $activity['rules'] = json_decode($activity['rules'], true);
            $activity['target_data'] = $activity['target_data'] ? json_decode($activity['target_data'], true) : [];
        }
        
        return [
            'activities' => $activities,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ];
    }
    
    /**
     * 获取活动详情
     * @param int $activityId 活动ID
     * @return array 活动详情
     * @throws Exception 活动不存在时抛出异常
     */
    public function getDiscountActivity($activityId) {
        $query = "SELECT * FROM promotions WHERE id = ? AND sub_type = 'threshold'";
        $activity = $this->database->selectOne($query, [$activityId]);
        
        if (!$activity) {
            throw new Exception("满减活动不存在");
        }
        
        // 解析JSON数据
        $activity['rules'] = json_decode($activity['rules'], true);
        $activity['target_data'] = $activity['target_data'] ? json_decode($activity['target_data'], true) : [];
        
        return $activity;
    }
    
    /**
     * 更新满减活动
     * @param int $activityId 活动ID
     * @param array $updateData 更新数据
     * @return bool 更新是否成功
     * @throws Exception 更新失败时抛出异常
     */
    public function updateDiscountActivity($activityId, $updateData) {
        try {
            // 获取原活动数据
            $activity = $this->getDiscountActivity($activityId);
            
            // 检查活动状态是否允许修改
            if ($activity['status'] == 'ended' || $activity['status'] == 'cancelled') {
                throw new Exception("已结束或已取消的活动不允许修改");
            }
            
            // 合并数据
            $discountData = array_merge($activity, $updateData);
            
            // 数据验证
            $this->validateDiscountData($discountData, true);
            
            // 构建规则JSON
            $rules = [
                'threshold_amount' => isset($discountData['rules']['threshold_amount']) ? (float)$discountData['rules']['threshold_amount'] : 0,
                'discount_amount' => isset($discountData['rules']['discount_amount']) ? (float)$discountData['rules']['discount_amount'] : 0,
                'max_discount' => isset($discountData['rules']['max_discount']) ? (float)$discountData['rules']['max_discount'] : null,
                'step_discount' => isset($discountData['rules']['step_discount']) ? (bool)$discountData['rules']['step_discount'] : false,
                'step_rules' => isset($discountData['rules']['step_rules']) ? $discountData['rules']['step_rules'] : [],
                'product_scope' => isset($discountData['rules']['product_scope']) ? $discountData['rules']['product_scope'] : 'all',
                'product_data' => isset($discountData['rules']['product_data']) ? $discountData['rules']['product_data'] : [],
                'user_scope' => isset($discountData['rules']['user_scope']) ? $discountData['rules']['user_scope'] : 'all',
                'user_data' => isset($discountData['rules']['user_data']) ? $discountData['rules']['user_data'] : []
            ];
            
            // 构建目标用户数据
            $targetData = [];
            if ($discountData['rules']['user_scope'] == 'member_level') {
                $targetData['member_levels'] = isset($discountData['target_data']['member_levels']) ? $discountData['target_data']['member_levels'] : [];
            } elseif ($discountData['rules']['user_scope'] == 'specific_users') {
                $targetData['user_ids'] = isset($discountData['target_data']['user_ids']) ? $discountData['target_data']['user_ids'] : [];
            }
            
            // 更新数据
            $query = "UPDATE promotions SET name = ?, description = ?, start_time = ?, end_time = ?, 
                      status = ?, rules = ?, target_scope = ?, target_data = ? WHERE id = ?";
            
            return $this->database->execute($query, [
                $discountData['name'],
                $discountData['description'],
                $discountData['start_time'],
                $discountData['end_time'],
                $discountData['status'],
                json_encode($rules, JSON_UNESCAPED_UNICODE),
                $discountData['rules']['user_scope'],
                !empty($targetData) ? json_encode($targetData, JSON_UNESCAPED_UNICODE) : null,
                $activityId
            ]);
        } catch (Exception $e) {
            $this->logger->error('更新满减活动失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 删除满减活动
     * @param int $activityId 活动ID
     * @return bool 删除是否成功
     * @throws Exception 删除失败时抛出异常
     */
    public function deleteDiscountActivity($activityId) {
        try {
            $activity = $this->getDiscountActivity($activityId);
            
            // 检查活动状态
            if ($activity['status'] == 'active') {
                throw new Exception("进行中的活动不允许删除，请先暂停或取消");
            }
            
            $query = "DELETE FROM promotions WHERE id = ? AND sub_type = 'threshold'";
            return $this->database->execute($query, [$activityId]);
        } catch (Exception $e) {
            $this->logger->error('删除满减活动失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 计算订单可应用的满减优惠
     * @param int $userId 用户ID
     * @param float $orderAmount 订单金额
     * @param array $orderItems 订单商品
     * @return array 可应用的优惠列表
     */
    public function calculateAvailableDiscounts($userId, $orderAmount, $orderItems) {
        // 获取用户信息
        $user = $this->database->selectOne("SELECT * FROM users WHERE id = ?", [$userId]);
        $userMemberInfo = $this->database->selectOne(
            "SELECT ml.level FROM user_members um 
             LEFT JOIN member_levels ml ON um.member_level_id = ml.id 
             WHERE um.user_id = ?", 
            [$userId]
        );
        $memberLevel = $userMemberInfo ? $userMemberInfo['level'] : 1;
        
        // 获取有效的满减活动
        $now = date('Y-m-d H:i:s');
        $query = "SELECT * FROM promotions 
                  WHERE type = 'discount' AND sub_type = 'threshold' 
                  AND status = 'active' AND start_time <= ? AND end_time >= ?";
        $activities = $this->database->select($query, [$now, $now]);
        
        $availableDiscounts = [];
        
        foreach ($activities as $activity) {
            $rules = json_decode($activity['rules'], true);
            $targetData = $activity['target_data'] ? json_decode($activity['target_data'], true) : [];
            
            // 检查用户是否符合条件
            if (!$this->checkUserEligibility($userId, $memberLevel, $rules['user_scope'], $targetData)) {
                continue;
            }
            
            // 检查商品是否符合条件
            if (!$this->checkProductEligibility($orderItems, $rules['product_scope'], $rules['product_data'])) {
                continue;
            }
            
            // 检查使用次数限制
            if ($activity['max_usage'] !== null && $activity['usage_count'] >= $activity['max_usage']) {
                continue;
            }
            
            // 计算优惠金额
            $discountAmount = $this->calculateDiscountAmount($orderAmount, $rules);
            
            if ($discountAmount > 0) {
                $availableDiscounts[] = [
                    'activity_id' => $activity['id'],
                    'name' => $activity['name'],
                    'description' => $activity['description'],
                    'discount_amount' => $discountAmount,
                    'threshold_amount' => $rules['threshold_amount'],
                    'max_discount' => $rules['max_discount'],
                    'step_discount' => $rules['step_discount']
                ];
            }
        }
        
        // 按优惠金额降序排序
        usort($availableDiscounts, function($a, $b) {
            return $b['discount_amount'] - $a['discount_amount'];
        });
        
        return $availableDiscounts;
    }
    
    /**
     * 应用满减优惠到订单
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param int $activityId 活动ID
     * @return float 应用的优惠金额
     * @throws Exception 应用失败时抛出异常
     */
    public function applyDiscountToOrder($userId, $orderId, $activityId) {
        try {
            // 获取订单信息
            $order = $this->database->selectOne("SELECT * FROM orders WHERE id = ? AND user_id = ?", [$orderId, $userId]);
            if (!$order) {
                throw new Exception("订单不存在");
            }
            
            // 获取订单商品
            $orderItems = $this->database->select(
                "SELECT * FROM order_items WHERE order_id = ?", 
                [$orderId]
            );
            
            // 计算可应用的优惠
            $availableDiscounts = $this->calculateAvailableDiscounts($userId, $order['total_amount'], $orderItems);
            
            // 查找指定的活动
            $selectedDiscount = null;
            foreach ($availableDiscounts as $discount) {
                if ($discount['activity_id'] == $activityId) {
                    $selectedDiscount = $discount;
                    break;
                }
            }
            
            if (!$selectedDiscount) {
                throw new Exception("该满减优惠不适用于此订单");
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            try {
                // 记录优惠应用
                $query = "INSERT INTO order_discounts 
                          (order_id, promotion_id, discount_amount, created_at) 
                          VALUES (?, ?, ?, NOW())";
                $this->database->execute($query, [
                    $orderId, 
                    $activityId, 
                    $selectedDiscount['discount_amount']
                ]);
                
                // 更新订单金额
                $newTotalAmount = $order['total_amount'] - $selectedDiscount['discount_amount'];
                $updateOrderQuery = "UPDATE orders SET total_amount = ?, discount_amount = ? WHERE id = ?";
                $this->database->execute($updateOrderQuery, [
                    max(0, $newTotalAmount),
                    $selectedDiscount['discount_amount'],
                    $orderId
                ]);
                
                // 更新活动使用次数
                $updateActivityQuery = "UPDATE promotions SET usage_count = usage_count + 1 WHERE id = ?";
                $this->database->execute($updateActivityQuery, [$activityId]);
                
                // 提交事务
                $this->database->commit();
                
                return $selectedDiscount['discount_amount'];
            } catch (Exception $e) {
                // 回滚事务
                $this->database->rollback();
                throw $e;
            }
        } catch (Exception $e) {
            $this->logger->error('应用满减优惠失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 验证满减活动数据
     * @param array $data 满减活动数据
     * @param bool $isUpdate 是否为更新操作
     * @throws Exception 验证失败时抛出异常
     */
    private function validateDiscountData($data, $isUpdate = false) {
        // 验证必填字段
        if (!$isUpdate || isset($data['name'])) {
            if (!isset($data['name']) || empty(trim($data['name']))) {
                throw new Exception("活动名称不能为空");
            }
        }
        
        if (!isset($data['rules']['threshold_amount']) || $data['rules']['threshold_amount'] <= 0) {
            throw new Exception("满减门槛必须大于0");
        }
        
        if (!isset($data['rules']['discount_amount']) || $data['rules']['discount_amount'] <= 0) {
            if (!isset($data['rules']['step_discount']) || !$data['rules']['step_discount']) {
                throw new Exception("优惠金额必须大于0");
            }
        }
        
        if (isset($data['rules']['step_discount']) && $data['rules']['step_discount']) {
            if (!isset($data['rules']['step_rules']) || empty($data['rules']['step_rules'])) {
                throw new Exception("阶梯满减必须设置阶梯规则");
            }
            
            // 验证阶梯规则
            foreach ($data['rules']['step_rules'] as $step) {
                if (!isset($step['threshold']) || $step['threshold'] <= 0) {
                    throw new Exception("阶梯门槛必须大于0");
                }
                if (!isset($step['discount']) || $step['discount'] <= 0) {
                    throw new Exception("阶梯优惠金额必须大于0");
                }
            }
        }
        
        // 验证时间
        if (!$isUpdate || isset($data['start_time']) || isset($data['end_time'])) {
            $startTime = isset($data['start_time']) ? $data['start_time'] : $data['rules']['start_time'];
            $endTime = isset($data['end_time']) ? $data['end_time'] : $data['rules']['end_time'];
            
            if (strtotime($startTime) >= strtotime($endTime)) {
                throw new Exception("开始时间必须早于结束时间");
            }
        }
    }
    
    /**
     * 检查用户是否符合活动条件
     * @param int $userId 用户ID
     * @param int $memberLevel 会员等级
     * @param string $userScope 用户范围
     * @param array $targetData 目标数据
     * @return bool 是否符合条件
     */
    private function checkUserEligibility($userId, $memberLevel, $userScope, $targetData) {
        switch ($userScope) {
            case 'all':
                return true;
            
            case 'new':
                // 检查是否为新用户（注册30天内）
                $user = $this->database->selectOne("SELECT created_at FROM users WHERE id = ?", [$userId]);
                if ($user) {
                    $createdDays = (strtotime(date('Y-m-d H:i:s')) - strtotime($user['created_at'])) / (60 * 60 * 24);
                    return $createdDays <= 30;
                }
                return false;
            
            case 'member_level':
                return isset($targetData['member_levels']) && in_array($memberLevel, $targetData['member_levels']);
            
            case 'specific_users':
                return isset($targetData['user_ids']) && in_array($userId, $targetData['user_ids']);
            
            default:
                return false;
        }
    }
    
    /**
     * 检查商品是否符合活动条件
     * @param array $orderItems 订单商品
     * @param string $productScope 商品范围
     * @param array $productData 商品数据
     * @return bool 是否符合条件
     */
    private function checkProductEligibility($orderItems, $productScope, $productData) {
        switch ($productScope) {
            case 'all':
                return true;
            
            case 'category':
                if (!isset($productData['categories']) || empty($productData['categories'])) {
                    return false;
                }
                
                // 检查订单中是否包含指定分类的商品
                foreach ($orderItems as $item) {
                    $product = $this->database->selectOne("SELECT category_id FROM products WHERE id = ?", [$item['product_id']]);
                    if ($product && in_array($product['category_id'], $productData['categories'])) {
                        return true;
                    }
                }
                return false;
            
            case 'specific':
                if (!isset($productData['product_ids']) || empty($productData['product_ids'])) {
                    return false;
                }
                
                // 检查订单中是否包含指定商品
                foreach ($orderItems as $item) {
                    if (in_array($item['product_id'], $productData['product_ids'])) {
                        return true;
                    }
                }
                return false;
            
            default:
                return false;
        }
    }
    
    /**
     * 计算满减优惠金额
     * @param float $orderAmount 订单金额
     * @param array $rules 活动规则
     * @return float 优惠金额
     */
    private function calculateDiscountAmount($orderAmount, $rules) {
        // 检查是否达到门槛
        if ($orderAmount < $rules['threshold_amount']) {
            return 0;
        }
        
        $discountAmount = 0;
        
        if (isset($rules['step_discount']) && $rules['step_discount']) {
            // 阶梯满减
            $stepRules = $rules['step_rules'];
            usort($stepRules, function($a, $b) {
                return $b['threshold'] - $a['threshold'];
            });
            
            // 找到适用的最高阶梯
            foreach ($stepRules as $step) {
                if ($orderAmount >= $step['threshold']) {
                    $discountAmount = $step['discount'];
                    break;
                }
            }
        } else {
            // 普通满减
            $discountAmount = $rules['discount_amount'];
            
            // 如果是按比例满减
            if (isset($rules['percentage']) && $rules['percentage']) {
                $discountAmount = $orderAmount * ($discountAmount / 100);
            }
        }
        
        // 应用最大优惠限制
        if (isset($rules['max_discount']) && $rules['max_discount'] !== null) {
            $discountAmount = min($discountAmount, $rules['max_discount']);
        }
        
        // 优惠金额不能超过订单金额
        $discountAmount = min($discountAmount, $orderAmount);
        
        return round($discountAmount, 2);
    }
    
    /**
     * 获取满减活动统计数据
     * @param int $activityId 活动ID
     * @return array 统计数据
     */
    public function getDiscountActivityStats($activityId) {
        // 获取活动信息
        $activity = $this->getDiscountActivity($activityId);
        
        // 获取活动期间的订单数和优惠金额
        $stats = $this->database->selectOne(
            "SELECT COUNT(*) as order_count, SUM(discount_amount) as total_discount 
             FROM order_discounts 
             WHERE promotion_id = ?", 
            [$activityId]
        );
        
        // 获取活动期间的销售总额
        $salesTotal = $this->database->selectOne(
            "SELECT SUM(o.total_amount + od.discount_amount) as total_sales 
             FROM order_discounts od 
             LEFT JOIN orders o ON od.order_id = o.id 
             WHERE od.promotion_id = ? AND o.status = 'completed'", 
            [$activityId]
        );
        
        return [
            'activity_id' => $activityId,
            'activity_name' => $activity['name'],
            'start_time' => $activity['start_time'],
            'end_time' => $activity['end_time'],
            'status' => $activity['status'],
            'order_count' => $stats['order_count'],
            'total_discount' => $stats['total_discount'] ?: 0,
            'total_sales' => $salesTotal['total_sales'] ?: 0,
            'usage_rate' => $activity['max_usage'] ? ($activity['usage_count'] / $activity['max_usage'] * 100) : null
        ];
    }
    
    /**
     * 批量更改活动状态
     * @param array $activityIds 活动ID列表
     * @param string $status 新状态
     * @return bool 操作是否成功
     */
    public function batchUpdateActivityStatus($activityIds, $status) {
        if (empty($activityIds)) {
            return false;
        }
        
        $placeholders = implode(',', array_fill(0, count($activityIds), '?'));
        $query = "UPDATE promotions SET status = ? WHERE id IN ($placeholders) AND sub_type = 'threshold'";
        
        $params = array_merge([$status], $activityIds);
        return $this->database->execute($query, $params);
    }
}
?>