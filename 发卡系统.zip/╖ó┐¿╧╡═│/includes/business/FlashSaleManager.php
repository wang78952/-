<?php
/**
 * 限时秒杀活动管理业务逻辑类
 * 负责限时秒杀活动的创建、管理、验证和应用
 */

class FlashSaleManager {
    private $database;
    private $logger;
    
    /**
     * 构造函数
     * @param Database $database 数据库连接对象
     * @param Logger $logger 日志对象
     */
    public function __construct($database, $logger) {
        $this->database = $database;
        $this->logger = $logger;
    }
    
    /**
     * 创建限时秒杀活动
     * @param array $flashSaleData 秒杀活动数据
     * @return int 创建的活动ID
     * @throws Exception 创建失败时抛出异常
     */
    public function createFlashSale($flashSaleData) {
        // 数据验证
        $this->validateFlashSaleData($flashSaleData);
        
        // 构建规则JSON
        $rules = [
            'discount_rate' => (float)$flashSaleData['discount_rate'],
            'limited_quantity' => (int)$flashSaleData['limited_quantity'],
            'max_per_user' => (int)$flashSaleData['max_per_user'],
            'product_data' => $flashSaleData['product_data'] ?? []
        ];
        
        // 插入数据
        $query = "INSERT INTO promotions 
                  (name, description, type, sub_type, rules, target_data, 
                   status, start_time, end_time, max_usage, created_at)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $this->database->execute($query, [
            $flashSaleData['name'],
            $flashSaleData['description'],
            'discount',
            'flash_sale',
            json_encode($rules),
            json_encode($flashSaleData['target_data'] ?? []),
            $flashSaleData['status'] ?? 'pending',
            $flashSaleData['start_time'],
            $flashSaleData['end_time'],
            $flashSaleData['max_usage'] ?? null
        ]);
        
        return $this->database->lastInsertId();
    }
    
    /**
     * 获取限时秒杀活动详情
     * @param int $activityId 活动ID
     * @return array 活动详情
     * @throws Exception 活动不存在时抛出异常
     */
    public function getFlashSaleActivity($activityId) {
        $query = "SELECT * FROM promotions WHERE id = ? AND sub_type = 'flash_sale'";
        $activity = $this->database->selectOne($query, [$activityId]);
        
        if (!$activity) {
            throw new Exception("限时秒杀活动不存在");
        }
        
        // 解析JSON数据
        $activity['rules'] = json_decode($activity['rules'], true);
        $activity['target_data'] = $activity['target_data'] ? json_decode($activity['target_data'], true) : [];
        
        return $activity;
    }
    
    /**
     * 更新限时秒杀活动
     * @param int $activityId 活动ID
     * @param array $updateData 更新数据
     * @return bool 更新是否成功
     * @throws Exception 更新失败时抛出异常
     */
    public function updateFlashSale($activityId, $updateData) {
        try {
            // 获取原活动数据
            $activity = $this->getFlashSaleActivity($activityId);
            
            // 检查活动状态是否允许修改
            if ($activity['status'] == 'ended' || $activity['status'] == 'cancelled') {
                throw new Exception("已结束或已取消的活动不允许修改");
            }
            
            // 合并数据
            $flashSaleData = array_merge($activity, $updateData);
            
            // 如果更新了规则，需要重新构建规则JSON
            if (isset($updateData['rules'])) {
                $flashSaleData['rules'] = json_encode($updateData['rules']);
            }
            
            // 如果更新了目标数据，需要重新构建目标数据JSON
            if (isset($updateData['target_data'])) {
                $flashSaleData['target_data'] = json_encode($updateData['target_data']);
            }
            
            // 数据验证
            $this->validateFlashSaleData($flashSaleData);
            
            // 构建更新字段
            $updateFields = [];
            $updateValues = [];
            
            $fieldsToUpdate = ['name', 'description', 'status', 'start_time', 'end_time', 'max_usage', 'rules', 'target_data'];
            foreach ($fieldsToUpdate as $field) {
                if (isset($flashSaleData[$field])) {
                    $updateFields[] = "$field = ?";
                    $updateValues[] = $flashSaleData[$field];
                }
            }
            
            $updateValues[] = $activityId;
            
            // 执行更新
            $query = "UPDATE promotions SET " . implode(', ', $updateFields) . " WHERE id = ?";
            $this->database->execute($query, $updateValues);
            
            return true;
        } catch (Exception $e) {
            $this->logger->error('更新限时秒杀活动失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取有效的限时秒杀活动列表
     * @return array 活动列表
     */
    public function getActiveFlashSales() {
        $now = date('Y-m-d H:i:s');
        $query = "SELECT * FROM promotions 
                  WHERE type = 'discount' AND sub_type = 'flash_sale' 
                  AND status = 'active' AND start_time <= ? AND end_time >= ?";
        $activities = $this->database->select($query, [$now, $now]);
        
        // 解析JSON数据
        foreach ($activities as &$activity) {
            $activity['rules'] = json_decode($activity['rules'], true);
            $activity['target_data'] = $activity['target_data'] ? json_decode($activity['target_data'], true) : [];
        }
        
        return $activities;
    }
    
    /**
     * 计算订单可应用的限时秒杀优惠
     * @param int $userId 用户ID
     * @param float $orderAmount 订单金额
     * @param array $orderItems 订单商品
     * @return array 可应用的优惠列表
     */
    public function calculateAvailableFlashSales($userId, $orderAmount, $orderItems) {
        // 获取用户信息
        $user = $this->database->selectOne("SELECT * FROM users WHERE id = ?", [$userId]);
        $userMemberInfo = $this->database->selectOne(
            "SELECT ml.level FROM user_members um 
             LEFT JOIN member_levels ml ON um.member_level_id = ml.id 
             WHERE um.user_id = ?", 
            [$userId]
        );
        $memberLevel = $userMemberInfo ? $userMemberInfo['level'] : 1;
        
        // 获取有效的限时秒杀活动
        $now = date('Y-m-d H:i:s');
        $query = "SELECT * FROM promotions 
                  WHERE type = 'discount' AND sub_type = 'flash_sale' 
                  AND status = 'active' AND start_time <= ? AND end_time >= ?";
        $activities = $this->database->select($query, [$now, $now]);
        
        $availableFlashSales = [];
        
        foreach ($activities as $activity) {
            $rules = json_decode($activity['rules'], true);
            $targetData = $activity['target_data'] ? json_decode($activity['target_data'], true) : [];
            
            // 检查用户是否符合条件
            if (!$this->checkUserEligibility($userId, $memberLevel, $rules['user_scope'] ?? 'all', $targetData)) {
                continue;
            }
            
            // 检查商品是否符合条件
            $eligibleItems = [];
            foreach ($orderItems as $item) {
                if ($this->checkProductEligibility($item, $rules['product_data'] ?? [])) {
                    $eligibleItems[] = $item;
                }
            }
            
            if (empty($eligibleItems)) {
                continue;
            }
            
            // 检查使用次数限制
            if ($activity['max_usage'] !== null && $activity['usage_count'] >= $activity['max_usage']) {
                continue;
            }
            
            // 检查用户已购买数量限制
            $userPurchaseCount = $this->getUserPurchaseCount($userId, $activity['id']);
            if ($rules['max_per_user'] > 0 && $userPurchaseCount >= $rules['max_per_user']) {
                continue;
            }
            
            // 计算折扣金额
            $discountAmount = 0;
            foreach ($eligibleItems as $item) {
                $discountAmount += $item['price'] * $item['quantity'] * (1 - $rules['discount_rate']);
            }
            
            $availableFlashSales[] = [
                'activity_id' => $activity['id'],
                'name' => $activity['name'],
                'description' => $activity['description'],
                'discount_rate' => $rules['discount_rate'],
                'discount_amount' => $discountAmount,
                'limited_quantity' => $rules['limited_quantity'],
                'available_quantity' => $rules['limited_quantity'] - $activity['usage_count'],
                'max_per_user' => $rules['max_per_user'],
                'user_purchased' => $userPurchaseCount,
                'eligible_items' => $eligibleItems
            ];
        }
        
        return $availableFlashSales;
    }
    
    /**
     * 应用限时秒杀优惠到订单
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param int $activityId 活动ID
     * @return float 应用的优惠金额
     * @throws Exception 应用失败时抛出异常
     */
    public function applyFlashSaleToOrder($userId, $orderId, $activityId) {
        try {
            // 获取订单信息
            $order = $this->database->selectOne("SELECT * FROM orders WHERE id = ? AND user_id = ?", [$orderId, $userId]);
            if (!$order) {
                throw new Exception("订单不存在");
            }
            
            // 获取订单商品
            $orderItems = $this->database->select(
                "SELECT oi.*, p.price FROM order_items oi 
                 LEFT JOIN products p ON oi.product_id = p.id 
                 WHERE oi.order_id = ?", 
                [$orderId]
            );
            
            // 计算可应用的优惠
            $availableFlashSales = $this->calculateAvailableFlashSales($userId, $order['total_amount'], $orderItems);
            
            // 查找指定的活动
            $selectedFlashSale = null;
            foreach ($availableFlashSales as $flashSale) {
                if ($flashSale['activity_id'] == $activityId) {
                    $selectedFlashSale = $flashSale;
                    break;
                }
            }
            
            if (!$selectedFlashSale) {
                throw new Exception("该限时秒杀活动不适用于此订单");
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            try {
                // 记录优惠应用
                $query = "INSERT INTO order_discounts 
                          (order_id, promotion_id, discount_amount, created_at) 
                          VALUES (?, ?, ?, NOW())";
                $this->database->execute($query, [
                    $orderId, 
                    $activityId, 
                    $selectedFlashSale['discount_amount']
                ]);
                
                // 更新订单金额
                $newTotalAmount = $order['total_amount'] - $selectedFlashSale['discount_amount'];
                $updateOrderQuery = "UPDATE orders SET total_amount = ?, discount_amount = ? WHERE id = ?";
                $this->database->execute($updateOrderQuery, [
                    max(0, $newTotalAmount),
                    $selectedFlashSale['discount_amount'],
                    $orderId
                ]);
                
                // 更新活动使用次数
                $updateActivityQuery = "UPDATE promotions SET usage_count = usage_count + 1 WHERE id = ?";
                $this->database->execute($updateActivityQuery, [$activityId]);
                
                // 记录用户购买记录
                $recordPurchaseQuery = "INSERT INTO flash_sale_user_purchases 
                                       (user_id, promotion_id, order_id, created_at) 
                                       VALUES (?, ?, ?, NOW())";
                $this->database->execute($recordPurchaseQuery, [$userId, $activityId, $orderId]);
                
                // 提交事务
                $this->database->commit();
                
                return $selectedFlashSale['discount_amount'];
            } catch (Exception $e) {
                // 回滚事务
                $this->database->rollback();
                throw $e;
            }
        } catch (Exception $e) {
            $this->logger->error('应用限时秒杀优惠失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取用户在特定秒杀活动中的购买数量
     * @param int $userId 用户ID
     * @param int $activityId 活动ID
     * @return int 购买数量
     */
    private function getUserPurchaseCount($userId, $activityId) {
        $query = "SELECT COUNT(*) as count FROM flash_sale_user_purchases 
                  WHERE user_id = ? AND promotion_id = ?";
        $result = $this->database->selectOne($query, [$userId, $activityId]);
        return $result['count'] ?? 0;
    }
    
    /**
     * 检查用户是否符合活动条件
     * @param int $userId 用户ID
     * @param int $memberLevel 会员等级
     * @param string $userScope 用户范围
     * @param array $targetData 目标数据
     * @return bool 是否符合条件
     */
    private function checkUserEligibility($userId, $memberLevel, $userScope, $targetData) {
        switch ($userScope) {
            case 'all':
                return true;
            case 'specific_users':
                return in_array($userId, $targetData['user_ids'] ?? []);
            case 'member_level':
                return $memberLevel >= ($targetData['min_level'] ?? 1);
            default:
                return true;
        }
    }
    
    /**
     * 检查商品是否符合活动条件
     * @param array $item 订单商品
     * @param array $productData 商品数据
     * @return bool 是否符合条件
     */
    private function checkProductEligibility($item, $productData) {
        // 如果没有指定商品，所有商品都符合条件
        if (empty($productData) || empty($productData['product_ids'])) {
            return true;
        }
        
        return in_array($item['product_id'], $productData['product_ids']);
    }
    
    /**
     * 验证秒杀活动数据
     * @param array $flashSaleData 秒杀活动数据
     * @throws Exception 验证失败时抛出异常
     */
    private function validateFlashSaleData($flashSaleData) {
        // 验证必填字段
        $requiredFields = ['name', 'description', 'start_time', 'end_time'];
        foreach ($requiredFields as $field) {
            if (!isset($flashSaleData[$field]) || empty(trim($flashSaleData[$field]))) {
                throw new Exception("缺少必填字段: $field");
            }
        }
        
        // 验证时间
        if (strtotime($flashSaleData['start_time']) >= strtotime($flashSaleData['end_time'])) {
            throw new Exception("开始时间必须早于结束时间");
        }
        
        // 验证折扣率
        if (isset($flashSaleData['rules']['discount_rate'])) {
            $discountRate = $flashSaleData['rules']['discount_rate'];
            if ($discountRate <= 0 || $discountRate >= 1) {
                throw new Exception("折扣率必须在0和1之间");
            }
        } elseif (isset($flashSaleData['discount_rate'])) {
            $discountRate = $flashSaleData['discount_rate'];
            if ($discountRate <= 0 || $discountRate >= 1) {
                throw new Exception("折扣率必须在0和1之间");
            }
        }
        
        // 验证限量数量
        if (isset($flashSaleData['rules']['limited_quantity'])) {
            $limitedQuantity = $flashSaleData['rules']['limited_quantity'];
            if ($limitedQuantity <= 0) {
                throw new Exception("限量数量必须大于0");
            }
        } elseif (isset($flashSaleData['limited_quantity'])) {
            $limitedQuantity = $flashSaleData['limited_quantity'];
            if ($limitedQuantity <= 0) {
                throw new Exception("限量数量必须大于0");
            }
        }
    }
    
    /**
     * 获取限时秒杀活动统计数据
     * @param int $activityId 活动ID
     * @return array 统计数据
     */
    public function getFlashSaleStats($activityId) {
        // 获取活动信息
        $activity = $this->getFlashSaleActivity($activityId);
        
        // 获取活动期间的订单数和优惠金额
        $stats = $this->database->selectOne(
            "SELECT COUNT(*) as order_count, SUM(discount_amount) as total_discount 
             FROM order_discounts 
             WHERE promotion_id = ?", 
            [$activityId]
        );
        
        // 获取活动期间的销售总额
        $salesTotal = $this->database->selectOne(
            "SELECT SUM(o.total_amount + od.discount_amount) as total_sales 
             FROM order_discounts od 
             LEFT JOIN orders o ON od.order_id = o.id 
             WHERE od.promotion_id = ? AND o.status = 'completed'", 
            [$activityId]
        );
        
        return [
            'activity_id' => $activityId,
            'activity_name' => $activity['name'],
            'start_time' => $activity['start_time'],
            'end_time' => $activity['end_time'],
            'status' => $activity['status'],
            'order_count' => $stats['order_count'],
            'total_discount' => $stats['total_discount'] ?: 0,
            'total_sales' => $salesTotal['total_sales'] ?: 0,
            'usage_rate' => $activity['rules']['limited_quantity'] > 0 ? 
                          ($activity['usage_count'] / $activity['rules']['limited_quantity'] * 100) : null
        ];
    }
}