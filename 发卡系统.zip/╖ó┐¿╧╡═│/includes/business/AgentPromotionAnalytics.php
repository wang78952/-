<?php
/**
 * 代理推广数据分析服务
 * 提供代理实时推广数据看板所需的数据分析和处理功能
 * 支持访问量、转化量、佣金明细等数据的实时统计和展示
 */

namespace Business;

class AgentPromotionAnalytics {
    /**
     * @var \Database 数据库连接实例
     */
    protected $database;
    
    /**
     * @var \Cache 缓存实例
     */
    protected $cache;
    
    /**
     * @var array 配置信息
     */
    protected $config;
    
    /**
     * @var \Logger 日志实例
     */
    protected $logger;
    
    /**
     * 构造函数
     * 
     * @param array $config 配置参数
     */
    public function __construct($config = array()) {
        global $database, $cache, $logger;
        
        $this->database = $database;
        $this->cache = $cache;
        $this->logger = $logger;
        
        $this->config = array_merge(array(
            'cache_lifetime' => 300, // 缓存有效期，单位秒
            'max_records_per_page' => 100, // 每页最大记录数
            'stat_interval_minutes' => 5, // 实时统计间隔，单位分钟
        ), $config);
    }
    
    /**
     * 获取代理实时推广数据总览
     * 
     * @param int $agentId 代理ID
     * @param string $dateRange 时间范围 (today, yesterday, 7days, 30days, custom)
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 代理总览数据
     */
    public function getAgentPromotionOverview($agentId, $dateRange = '7days', $startDate = '', $endDate = '') {
        try {
            // 构建缓存键
            $cacheKey = "agent_overview_{$agentId}_{$dateRange}_{$startDate}_{$endDate}";
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange, $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 获取代理信息
            $agentInfo = $this->database->queryOne(
                "SELECT id, contact_name, level, status, created_at FROM agents WHERE id = ?",
                array($agentId)
            );
            
            if (!$agentInfo) {
                return array('success' => false, 'error' => '代理不存在');
            }
            
            // 获取总览数据
            $overviewQuery = "
                SELECT 
                    COUNT(DISTINCT rc.id) as total_clicks,
                    COUNT(DISTINCT rc.ip_address) as unique_clicks,
                    COUNT(DISTINCT u.id) as registrations,
                    COUNT(DISTINCT o.id) as orders,
                    SUM(IFNULL(o.amount, 0)) as total_amount,
                    COUNT(DISTINCT CASE WHEN o.status = 'completed' THEN o.id END) as completed_orders,
                    SUM(IFNULL(c.amount, 0)) as commission_earned
                FROM referral_clicks rc
                LEFT JOIN users u ON u.referral_code = (SELECT referral_code FROM agents WHERE id = ?) 
                    AND u.created_at >= ? AND u.created_at <= ?
                LEFT JOIN orders o ON o.user_id = u.id AND o.created_at >= ? AND o.created_at <= ?
                LEFT JOIN commission_records c ON c.agent_id = ? AND c.order_id = o.id AND c.status = 'settled'
                WHERE rc.agent_id = ? AND rc.clicked_at >= ? AND rc.clicked_at <= ?
            ";
            
            $params = array(
                $agentId, $startDate, $endDate,
                $startDate, $endDate,
                $agentId,
                $agentId, $startDate, $endDate
            );
            
            $overview = $this->database->queryOne($overviewQuery, $params);
            
            // 计算转化率
            $clickToRegRate = $overview['total_clicks'] > 0 ? 
                round($overview['registrations'] / $overview['total_clicks'] * 100, 2) : 0;
            $regToOrderRate = $overview['registrations'] > 0 ? 
                round($overview['orders'] / $overview['registrations'] * 100, 2) : 0;
            $overallConvRate = $overview['total_clicks'] > 0 ? 
                round($overview['orders'] / $overview['total_clicks'] * 100, 2) : 0;
            
            // 准备返回数据
            $result = array(
                'success' => true,
                'agent_info' => $agentInfo,
                'metrics' => array(
                    'total_clicks' => $overview['total_clicks'],
                    'unique_clicks' => $overview['unique_clicks'],
                    'registrations' => $overview['registrations'],
                    'orders' => $overview['orders'],
                    'completed_orders' => $overview['completed_orders'],
                    'total_amount' => $overview['total_amount'],
                    'commission_earned' => $overview['commission_earned'],
                    'click_to_reg_rate' => $clickToRegRate, // 点击到注册转化率
                    'reg_to_order_rate' => $regToOrderRate, // 注册到下单转化率
                    'overall_conversion_rate' => $overallConvRate, // 总体转化率
                ),
                'date_range' => array(
                    'start' => $startDate,
                    'end' => $endDate,
                ),
                'last_updated' => date('Y-m-d H:i:s')
            );
            
            // 缓存结果
            $this->cache->set($cacheKey, $result, $this->config['cache_lifetime']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("获取代理推广总览数据失败: " . $e->getMessage());
            return array('success' => false, 'error' => '获取数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取代理推广趋势数据
     * 
     * @param int $agentId 代理ID
     * @param string $dateRange 时间范围
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 趋势数据
     */
    public function getPromotionTrend($agentId, $dateRange = '7days', $startDate = '', $endDate = '') {
        try {
            // 构建缓存键
            $cacheKey = "promotion_trend_{$agentId}_{$dateRange}_{$startDate}_{$endDate}";
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange, $startDate, $endDate);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 根据时间范围确定分组方式
            $dateFormat = $dateRangeParams['days'] <= 7 ? '%Y-%m-%d %H:00' : '%Y-%m-%d';
            $dateLabel = $dateRangeParams['days'] <= 7 ? '%H:00' : '%m-%d';
            
            // 获取点击数据
            $clicksQuery = "
                SELECT 
                    DATE_FORMAT(clicked_at, '{$dateFormat}') as period,
                    DATE_FORMAT(clicked_at, '{$dateLabel}') as period_label,
                    COUNT(*) as total_clicks,
                    COUNT(DISTINCT ip_address) as unique_clicks
                FROM referral_clicks
                WHERE agent_id = ? AND clicked_at >= ? AND clicked_at <= ?
                GROUP BY period
                ORDER BY period ASC
            ";
            
            $clicks = $this->database->query($clicksQuery, array($agentId, $startDate, $endDate));
            
            // 获取注册数据
            $regQuery = "
                SELECT 
                    DATE_FORMAT(u.created_at, '{$dateFormat}') as period,
                    DATE_FORMAT(u.created_at, '{$dateLabel}') as period_label,
                    COUNT(*) as registrations
                FROM users u
                JOIN agents a ON u.referral_code = a.referral_code
                WHERE a.id = ? AND u.created_at >= ? AND u.created_at <= ?
                GROUP BY period
                ORDER BY period ASC
            ";
            
            $registrations = $this->database->query($regQuery, array($agentId, $startDate, $endDate));
            
            // 获取订单数据
            $orderQuery = "
                SELECT 
                    DATE_FORMAT(o.created_at, '{$dateFormat}') as period,
                    DATE_FORMAT(o.created_at, '{$dateLabel}') as period_label,
                    COUNT(*) as orders,
                    SUM(IFNULL(o.amount, 0)) as order_amount,
                    SUM(IFNULL(c.amount, 0)) as commission_amount
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN agents a ON u.referral_code = a.referral_code
                LEFT JOIN commission_records c ON c.order_id = o.id AND c.agent_id = a.id
                WHERE a.id = ? AND o.created_at >= ? AND o.created_at <= ?
                GROUP BY period
                ORDER BY period ASC
            ";
            
            $orders = $this->database->query($orderQuery, array($agentId, $startDate, $endDate));
            
            // 合并数据
            $trendData = array();
            $allPeriods = $this->generateDatePeriods($startDate, $endDate, $dateRangeParams['days'] <= 7 ? 'hour' : 'day');
            
            foreach ($allPeriods as $period => $label) {
                $trendData[] = array(
                    'period' => $period,
                    'period_label' => $label,
                    'total_clicks' => 0,
                    'unique_clicks' => 0,
                    'registrations' => 0,
                    'orders' => 0,
                    'order_amount' => 0,
                    'commission_amount' => 0
                );
            }
            
            // 填充点击数据
            foreach ($clicks as $click) {
                foreach ($trendData as &$data) {
                    if ($data['period'] === $click['period']) {
                        $data['total_clicks'] = $click['total_clicks'];
                        $data['unique_clicks'] = $click['unique_clicks'];
                        break;
                    }
                }
            }
            
            // 填充注册数据
            foreach ($registrations as $reg) {
                foreach ($trendData as &$data) {
                    if ($data['period'] === $reg['period']) {
                        $data['registrations'] = $reg['registrations'];
                        break;
                    }
                }
            }
            
            // 填充订单数据
            foreach ($orders as $order) {
                foreach ($trendData as &$data) {
                    if ($data['period'] === $order['period']) {
                        $data['orders'] = $order['orders'];
                        $data['order_amount'] = $order['order_amount'];
                        $data['commission_amount'] = $order['commission_amount'];
                        break;
                    }
                }
            }
            
            $result = array(
                'success' => true,
                'data' => $trendData,
                'date_range' => array('start' => $startDate, 'end' => $endDate)
            );
            
            // 缓存结果
            $this->cache->set($cacheKey, $result, $this->config['cache_lifetime']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("获取推广趋势数据失败: " . $e->getMessage());
            return array('success' => false, 'error' => '获取数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取代理佣金明细
     * 
     * @param int $agentId 代理ID
     * @param array $filters 筛选条件
     * @param int $page 页码
     * @param int $pageSize 每页数量
     * @return array 佣金明细数据
     */
    public function getCommissionDetails($agentId, $filters = array(), $page = 1, $pageSize = 20) {
        try {
            // 验证代理是否存在
            $agentExists = $this->database->queryOne(
                "SELECT COUNT(*) as count FROM agents WHERE id = ?",
                array($agentId)
            );
            
            if ($agentExists['count'] == 0) {
                return array('success' => false, 'error' => '代理不存在');
            }
            
            // 构建查询条件
            $whereClause = "WHERE cr.agent_id = ?";
            $params = array($agentId);
            
            // 添加日期范围筛选
            if (!empty($filters['start_date']) && !empty($filters['end_date'])) {
                $whereClause .= " AND cr.created_at >= ? AND cr.created_at <= ?";
                $params[] = $filters['start_date'];
                $params[] = $filters['end_date'];
            }
            
            // 添加状态筛选
            if (!empty($filters['status'])) {
                $whereClause .= " AND cr.status = ?";
                $params[] = $filters['status'];
            }
            
            // 获取佣金明细
            $commissionQuery = "
                SELECT 
                    cr.id, cr.order_id, cr.amount as commission_amount, 
                    cr.status, cr.created_at, cr.settled_at,
                    o.order_no, o.amount as order_amount, o.created_at as order_time,
                    o.status as order_status,
                    u.username as user_name
                FROM commission_records cr
                LEFT JOIN orders o ON cr.order_id = o.id
                LEFT JOIN users u ON o.user_id = u.id
                {$whereClause}
                ORDER BY cr.created_at DESC
                LIMIT ? OFFSET ?
            ";
            
            // 添加分页参数
            $pageSize = min($pageSize, $this->config['max_records_per_page']);
            $offset = ($page - 1) * $pageSize;
            $params[] = $pageSize;
            $params[] = $offset;
            
            $commissions = $this->database->query($commissionQuery, $params);
            
            // 获取总数
            $totalQuery = "SELECT COUNT(*) as total FROM commission_records cr {$whereClause}";
            $total = $this->database->queryOne($totalQuery, array_slice($params, 0, -2))['total'];
            
            // 计算分页信息
            $totalPages = ceil($total / $pageSize);
            
            // 统计数据
            $statsQuery = "
                SELECT 
                    SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as pending_amount,
                    SUM(CASE WHEN status = 'settled' THEN amount ELSE 0 END) as settled_amount,
                    SUM(CASE WHEN status = 'rejected' THEN amount ELSE 0 END) as rejected_amount,
                    COUNT(*) as total_records,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                    COUNT(CASE WHEN status = 'settled' THEN 1 END) as settled_count,
                    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected_count
                FROM commission_records cr
                {$whereClause}
            ";
            
            $stats = $this->database->queryOne($statsQuery, array_slice($params, 0, -2));
            
            $result = array(
                'success' => true,
                'data' => array(
                    'commissions' => $commissions,
                    'pagination' => array(
                        'current_page' => $page,
                        'page_size' => $pageSize,
                        'total_records' => $total,
                        'total_pages' => $totalPages
                    ),
                    'summary' => $stats
                )
            );
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("获取佣金明细失败: " . $e->getMessage());
            return array('success' => false, 'error' => '获取数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取推广页面效果分析
     * 
     * @param int $agentId 代理ID
     * @param string $dateRange 时间范围
     * @return array 页面效果分析
     */
    public function getPageEffectiveness($agentId, $dateRange = '30days') {
        try {
            // 构建缓存键
            $cacheKey = "page_effectiveness_{$agentId}_{$dateRange}";
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 获取页面效果数据
            $pageQuery = "
                SELECT 
                    target_url,
                    COUNT(*) as total_clicks,
                    COUNT(DISTINCT ip_address) as unique_clicks,
                    COUNT(DISTINCT CASE WHEN session_converted = 1 THEN session_id END) as converted_sessions,
                    AVG(time_on_page) as avg_time_on_page,
                    SUM(CASE WHEN session_converted = 1 THEN 1 ELSE 0 END) / COUNT(DISTINCT session_id) as conversion_rate
                FROM referral_clicks
                WHERE agent_id = ? AND clicked_at >= ? AND clicked_at <= ?
                GROUP BY target_url
                ORDER BY total_clicks DESC
                LIMIT 10
            ";
            
            $pages = $this->database->query($pageQuery, array($agentId, $startDate, $endDate));
            
            // 格式化转化率
            foreach ($pages as &$page) {
                $page['conversion_rate'] = round($page['conversion_rate'] * 100, 2);
            }
            
            $result = array(
                'success' => true,
                'data' => $pages,
                'date_range' => array('start' => $startDate, 'end' => $endDate)
            );
            
            // 缓存结果
            $this->cache->set($cacheKey, $result, $this->config['cache_lifetime']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("获取页面效果分析失败: " . $e->getMessage());
            return array('success' => false, 'error' => '获取数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取地域分布数据
     * 
     * @param int $agentId 代理ID
     * @param string $dateRange 时间范围
     * @return array 地域分布数据
     */
    public function getGeographicDistribution($agentId, $dateRange = '30days') {
        try {
            // 构建缓存键
            $cacheKey = "geo_distribution_{$agentId}_{$dateRange}";
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 获取地域分布数据
            $geoQuery = "
                SELECT 
                    location_country as country,
                    location_region as region,
                    location_city as city,
                    COUNT(*) as visit_count,
                    COUNT(DISTINCT session_id) as unique_sessions,
                    COUNT(DISTINCT CASE WHEN session_converted = 1 THEN session_id END) as converted_sessions
                FROM referral_clicks
                WHERE agent_id = ? AND clicked_at >= ? AND clicked_at <= ?
                    AND location_country IS NOT NULL
                GROUP BY location_country, location_region, location_city
                ORDER BY visit_count DESC
                LIMIT 20
            ";
            
            $geoData = $this->database->query($geoQuery, array($agentId, $startDate, $endDate));
            
            // 格式化数据
            foreach ($geoData as &$item) {
                $item['conversion_rate'] = $item['unique_sessions'] > 0 ? 
                    round($item['converted_sessions'] / $item['unique_sessions'] * 100, 2) : 0;
            }
            
            $result = array(
                'success' => true,
                'data' => $geoData,
                'date_range' => array('start' => $startDate, 'end' => $endDate)
            );
            
            // 缓存结果
            $this->cache->set($cacheKey, $result, $this->config['cache_lifetime']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("获取地域分布数据失败: " . $e->getMessage());
            return array('success' => false, 'error' => '获取数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取设备和浏览器统计
     * 
     * @param int $agentId 代理ID
     * @param string $dateRange 时间范围
     * @return array 设备统计数据
     */
    public function getDeviceStatistics($agentId, $dateRange = '30days') {
        try {
            // 构建缓存键
            $cacheKey = "device_stats_{$agentId}_{$dateRange}";
            
            // 尝试从缓存获取
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData !== false) {
                return $cachedData;
            }
            
            // 确定时间范围
            $dateRangeParams = $this->getDateRangeParams($dateRange);
            $startDate = $dateRangeParams['startDate'];
            $endDate = $dateRangeParams['endDate'];
            
            // 获取设备类型统计
            $deviceTypeQuery = "
                SELECT 
                    device_type,
                    COUNT(*) as count,
                    COUNT(DISTINCT session_id) as unique_sessions,
                    COUNT(DISTINCT CASE WHEN session_converted = 1 THEN session_id END) as converted_sessions
                FROM referral_clicks
                WHERE agent_id = ? AND clicked_at >= ? AND clicked_at <= ?
                GROUP BY device_type
                ORDER BY count DESC
            ";
            
            $deviceTypes = $this->database->query($deviceTypeQuery, array($agentId, $startDate, $endDate));
            
            // 获取浏览器统计
            $browserQuery = "
                SELECT 
                    browser_name,
                    COUNT(*) as count,
                    COUNT(DISTINCT session_id) as unique_sessions
                FROM referral_clicks
                WHERE agent_id = ? AND clicked_at >= ? AND clicked_at <= ?
                GROUP BY browser_name
                ORDER BY count DESC
                LIMIT 10
            ";
            
            $browsers = $this->database->query($browserQuery, array($agentId, $startDate, $endDate));
            
            $result = array(
                'success' => true,
                'data' => array(
                    'device_types' => $deviceTypes,
                    'browsers' => $browsers
                ),
                'date_range' => array('start' => $startDate, 'end' => $endDate)
            );
            
            // 缓存结果
            $this->cache->set($cacheKey, $result, $this->config['cache_lifetime']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("获取设备统计数据失败: " . $e->getMessage());
            return array('success' => false, 'error' => '获取数据失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 生成日期范围参数
     * 
     * @param string $dateRange 时间范围
     * @param string $startDate 自定义开始日期
     * @param string $endDate 自定义结束日期
     * @return array 日期范围参数
     */
    protected function getDateRangeParams($dateRange, $startDate = '', $endDate = '') {
        $now = date('Y-m-d H:i:s');
        $params = array();
        
        if ($dateRange === 'custom' && !empty($startDate) && !empty($endDate)) {
            $params['startDate'] = $startDate;
            $params['endDate'] = $endDate;
            $params['days'] = ceil((strtotime($endDate) - strtotime($startDate)) / 86400);
        } else {
            switch ($dateRange) {
                case 'today':
                    $params['startDate'] = date('Y-m-d 00:00:00');
                    $params['endDate'] = $now;
                    $params['days'] = 1;
                    break;
                case 'yesterday':
                    $params['startDate'] = date('Y-m-d 00:00:00', strtotime('-1 day'));
                    $params['endDate'] = date('Y-m-d 23:59:59', strtotime('-1 day'));
                    $params['days'] = 1;
                    break;
                case '7days':
                    $params['startDate'] = date('Y-m-d 00:00:00', strtotime('-7 days'));
                    $params['endDate'] = $now;
                    $params['days'] = 7;
                    break;
                case '30days':
                default:
                    $params['startDate'] = date('Y-m-d 00:00:00', strtotime('-30 days'));
                    $params['endDate'] = $now;
                    $params['days'] = 30;
                    break;
            }
        }
        
        return $params;
    }
    
    /**
     * 生成日期周期数组
     * 
     * @param string $startDate 开始日期
     * @param string $endDate 结束日期
     * @param string $interval 时间间隔 (hour, day)
     * @return array 日期周期数组
     */
    protected function generateDatePeriods($startDate, $endDate, $interval = 'day') {
        $periods = array();
        $current = strtotime($startDate);
        $end = strtotime($endDate);
        
        while ($current <= $end) {
            if ($interval === 'hour') {
                $period = date('Y-m-d H:00', $current);
                $label = date('H:00', $current);
                $current += 3600; // 加1小时
            } else {
                $period = date('Y-m-d', $current);
                $label = date('m-d', $current);
                $current += 86400; // 加1天
            }
            
            $periods[$period] = $label;
        }
        
        return $periods;
    }
}