<?php
/**
 * 业务指标收集器
 * 负责收集和计算核心业务指标，如卡密激活率、订单转化率、代理推广效果等
 */

class BusinessMetricsCollector {
    /**
     * 数据库连接
     * @var PDO
     */
    protected $db = null;
    
    /**
     * 缓存系统
     * @var array|object
     */
    protected $cache = null;
    
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        // 卡密相关配置
        'card_metrics' => [
            'table_cards' => 'cards',           // 卡密表
            'table_card_logs' => 'card_logs',   // 卡密操作日志表
            'fields' => [
                'status_field' => 'status',      // 状态字段
                'create_time_field' => 'create_time', // 创建时间字段
                'activate_time_field' => 'activate_time', // 激活时间字段
                'user_id_field' => 'user_id',    // 用户ID字段
                'proxy_id_field' => 'proxy_id',  // 代理ID字段
            ],
        ],
        
        // 订单相关配置
        'order_metrics' => [
            'table_orders' => 'orders',         // 订单表
            'fields' => [
                'status_field' => 'status',      // 状态字段
                'create_time_field' => 'create_time', // 创建时间字段
                'pay_time_field' => 'pay_time',  // 支付时间字段
                'user_id_field' => 'user_id',    // 用户ID字段
                'proxy_id_field' => 'proxy_id',  // 代理ID字段
                'amount_field' => 'amount',      // 订单金额字段
            ],
            // 成功订单状态
            'success_statuses' => ['paid', 'completed', 'success'],
        ],
        
        // 代理相关配置
        'proxy_metrics' => [
            'table_proxies' => 'proxies',       // 代理表
            'table_proxy_logs' => 'proxy_logs', // 代理操作日志表
            'table_commission' => 'commission', // 佣金表
        ],
        
        // 用户相关配置
        'user_metrics' => [
            'table_users' => 'users',           // 用户表
            'table_login_logs' => 'login_logs', // 登录日志表
        ],
        
        // 时间范围配置
        'time_ranges' => [
            'today' => 'CURDATE()',
            'yesterday' => 'DATE_SUB(CURDATE(), INTERVAL 1 DAY)',
            'this_week' => 'WEEK(CURDATE(), 1)',
            'last_week' => 'WEEK(DATE_SUB(CURDATE(), INTERVAL 1 WEEK), 1)',
            'this_month' => 'MONTH(CURDATE())',
            'last_month' => 'MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))',
            'last_7_days' => 'DATE_SUB(CURDATE(), INTERVAL 7 DAY)',
            'last_30_days' => 'DATE_SUB(CURDATE(), INTERVAL 30 DAY)',
            'last_90_days' => 'DATE_SUB(CURDATE(), INTERVAL 90 DAY)',
        ],
        
        // 缓存配置
        'cache' => [
            'enabled' => true,
            'ttl_seconds' => 300, // 5分钟缓存
        ],
    ];
    
    /**
     * 单例实例
     * @var BusinessMetricsCollector
     */
    protected static $instance = null;
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化数据库连接
        $this->initializeDatabase();
        
        // 初始化缓存
        $this->initializeCache();
    }
    
    /**
     * 获取单例实例
     * @param array $config 配置信息
     * @return BusinessMetricsCollector
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化数据库连接
     */
    protected function initializeDatabase() {
        try {
            // 尝试从全局获取数据库连接
            global $pdo;
            if ($pdo instanceof PDO) {
                $this->db = $pdo;
            } else {
                // 如果没有全局连接，则尝试创建连接
                // 这里需要根据实际项目的数据库配置进行调整
                $host = DB_HOST ?? 'localhost';
                $port = DB_PORT ?? '3306';
                $dbname = DB_NAME ?? 'card_system';
                $username = DB_USERNAME ?? 'root';
                $password = DB_PASSWORD ?? '';
                
                $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
                $this->db = new PDO($dsn, $username, $password);
                $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
        } catch (PDOException $e) {
            error_log('数据库连接失败: ' . $e->getMessage());
            throw new Exception('数据库连接失败');
        }
    }
    
    /**
     * 初始化缓存
     */
    protected function initializeCache() {
        // 这里可以集成项目中已有的缓存系统
        // 如Redis、Memcached或者简单的文件缓存
        $this->cache = [];
    }
    
    /**
     * 从缓存获取数据
     * @param string $key 缓存键
     * @return mixed
     */
    protected function getCache($key) {
        if (!$this->config['cache']['enabled']) {
            return false;
        }
        
        if (isset($this->cache[$key]) && isset($this->cache[$key]['expire']) && $this->cache[$key]['expire'] > time()) {
            return $this->cache[$key]['data'];
        } else {
            // 缓存过期或不存在
            unset($this->cache[$key]);
            return false;
        }
    }
    
    /**
     * 设置缓存数据
     * @param string $key 缓存键
     * @param mixed $data 缓存数据
     */
    protected function setCache($key, $data) {
        if (!$this->config['cache']['enabled']) {
            return;
        }
        
        $this->cache[$key] = [
            'data' => $data,
            'expire' => time() + $this->config['cache']['ttl_seconds'],
        ];
    }
    
    /**
     * 清理缓存
     * @param string $key 可选，指定要清理的缓存键，不传则清理所有缓存
     */
    public function clearCache($key = null) {
        if ($key !== null) {
            unset($this->cache[$key]);
        } else {
            $this->cache = [];
        }
    }
    
    /**
     * 获取卡密激活率指标
     * @param string $timeRange 时间范围 (today, yesterday, this_week, last_week, this_month, last_month, last_7_days, last_30_days, last_90_days)
     * @param int $proxyId 可选，代理ID，不传则获取所有代理的数据
     * @return array 激活率数据
     */
    public function getCardActivationRate($timeRange = 'today', $proxyId = null) {
        // 构建缓存键
        $cacheKey = "card_activation_rate_{$timeRange}_{$proxyId ?? 'all'}";
        
        // 尝试从缓存获取
        if ($cached = $this->getCache($cacheKey)) {
            return $cached;
        }
        
        try {
            // 获取时间条件
            $timeCondition = $this->getTimeCondition($timeRange, 'create_time');
            
            // 构建代理条件
            $proxyCondition = '';
            if ($proxyId) {
                $proxyCondition = " AND `{$this->config['card_metrics']['fields']['proxy_id_field']}` = :proxy_id ";
            }
            
            // 获取总卡密数量
            $queryTotal = "
                SELECT COUNT(*) AS total 
                FROM `{$this->config['card_metrics']['table_cards']}` 
                WHERE {$timeCondition} {$proxyCondition}
            ";
            
            $stmtTotal = $this->db->prepare($queryTotal);
            if ($proxyId) {
                $stmtTotal->bindValue(':proxy_id', $proxyId, PDO::PARAM_INT);
            }
            $stmtTotal->execute();
            $totalCards = $stmtTotal->fetch(PDO::FETCH_ASSOC)['total'];
            
            // 获取已激活卡密数量
            $queryActivated = "
                SELECT COUNT(*) AS activated 
                FROM `{$this->config['card_metrics']['table_cards']}` 
                WHERE `{$this->config['card_metrics']['fields']['activate_time_field']}` IS NOT NULL 
                AND `{$this->config['card_metrics']['fields']['status_field']}` = 'activated'
                AND {$timeCondition} {$proxyCondition}
            ";
            
            $stmtActivated = $this->db->prepare($queryActivated);
            if ($proxyId) {
                $stmtActivated->bindValue(':proxy_id', $proxyId, PDO::PARAM_INT);
            }
            $stmtActivated->execute();
            $activatedCards = $stmtActivated->fetch(PDO::FETCH_ASSOC)['activated'];
            
            // 计算激活率
            $activationRate = $totalCards > 0 ? ($activatedCards / $totalCards * 100) : 0;
            
            // 结果
            $result = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'total_cards' => $totalCards,
                'activated_cards' => $activatedCards,
                'activation_rate' => round($activationRate, 2),
                'timestamp' => time(),
            ];
            
            // 缓存结果
            $this->setCache($cacheKey, $result);
            
            return $result;
        } catch (Exception $e) {
            error_log('获取卡密激活率失败: ' . $e->getMessage());
            return [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'total_cards' => 0,
                'activated_cards' => 0,
                'activation_rate' => 0,
                'timestamp' => time(),
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 获取订单转化率指标
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 转化率数据
     */
    public function getOrderConversionRate($timeRange = 'today', $proxyId = null) {
        // 构建缓存键
        $cacheKey = "order_conversion_rate_{$timeRange}_{$proxyId ?? 'all'}";
        
        // 尝试从缓存获取
        if ($cached = $this->getCache($cacheKey)) {
            return $cached;
        }
        
        try {
            // 获取时间条件
            $timeCondition = $this->getTimeCondition($timeRange, 'create_time');
            
            // 构建代理条件
            $proxyCondition = '';
            if ($proxyId) {
                $proxyCondition = " AND `{$this->config['order_metrics']['fields']['proxy_id_field']}` = :proxy_id ";
            }
            
            // 获取总订单数量
            $queryTotal = "
                SELECT COUNT(*) AS total 
                FROM `{$this->config['order_metrics']['table_orders']}` 
                WHERE {$timeCondition} {$proxyCondition}
            ";
            
            $stmtTotal = $this->db->prepare($queryTotal);
            if ($proxyId) {
                $stmtTotal->bindValue(':proxy_id', $proxyId, PDO::PARAM_INT);
            }
            $stmtTotal->execute();
            $totalOrders = $stmtTotal->fetch(PDO::FETCH_ASSOC)['total'];
            
            // 构建成功状态条件
            $successStatuses = $this->config['order_metrics']['success_statuses'];
            $successStatusCondition = "`{$this->config['order_metrics']['fields']['status_field']}` IN ('" . implode("', '", $successStatuses) . "')";
            
            // 获取成功订单数量
            $querySuccess = "
                SELECT COUNT(*) AS success, SUM(`{$this->config['order_metrics']['fields']['amount_field']}`) AS total_amount 
                FROM `{$this->config['order_metrics']['table_orders']}` 
                WHERE {$successStatusCondition} 
                AND {$timeCondition} {$proxyCondition}
            ";
            
            $stmtSuccess = $this->db->prepare($querySuccess);
            if ($proxyId) {
                $stmtSuccess->bindValue(':proxy_id', $proxyId, PDO::PARAM_INT);
            }
            $stmtSuccess->execute();
            $successData = $stmtSuccess->fetch(PDO::FETCH_ASSOC);
            $successOrders = $successData['success'];
            $totalAmount = $successData['total_amount'] ?: 0;
            
            // 计算转化率
            $conversionRate = $totalOrders > 0 ? ($successOrders / $totalOrders * 100) : 0;
            
            // 结果
            $result = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'total_orders' => $totalOrders,
                'success_orders' => $successOrders,
                'conversion_rate' => round($conversionRate, 2),
                'total_amount' => $totalAmount,
                'timestamp' => time(),
            ];
            
            // 缓存结果
            $this->setCache($cacheKey, $result);
            
            return $result;
        } catch (Exception $e) {
            error_log('获取订单转化率失败: ' . $e->getMessage());
            return [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'total_orders' => 0,
                'success_orders' => 0,
                'conversion_rate' => 0,
                'total_amount' => 0,
                'timestamp' => time(),
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 获取代理推广效果指标
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID，不传则获取所有代理的数据
     * @return array 推广效果数据
     */
    public function getProxyPromotionEffect($timeRange = 'today', $proxyId = null) {
        // 构建缓存键
        $cacheKey = "proxy_promotion_effect_{$timeRange}_{$proxyId ?? 'all'}";
        
        // 尝试从缓存获取
        if ($cached = $this->getCache($cacheKey)) {
            return $cached;
        }
        
        try {
            // 获取时间条件
            $timeCondition = $this->getTimeCondition($timeRange, 'create_time');
            
            // 构建代理条件
            $proxyCondition = '';
            $params = [];
            
            if ($proxyId) {
                $proxyCondition = " AND `{$this->config['order_metrics']['fields']['proxy_id_field']}` = :proxy_id ";
                $params[':proxy_id'] = $proxyId;
            }
            
            // 获取代理推广订单数和金额
            $queryOrders = "
                SELECT 
                    `{$this->config['order_metrics']['fields']['proxy_id_field']}` AS proxy_id,
                    COUNT(*) AS order_count,
                    SUM(`{$this->config['order_metrics']['fields']['amount_field']}`) AS total_amount
                FROM `{$this->config['order_metrics']['table_orders']}` 
                WHERE `{$this->config['order_metrics']['fields']['status_field']}` IN ('" . 
                    implode("', '", $this->config['order_metrics']['success_statuses']) . "') 
                AND {$timeCondition} {$proxyCondition}
                GROUP BY `{$this->config['order_metrics']['fields']['proxy_id_field']}`
                ORDER BY total_amount DESC
            ";
            
            $stmtOrders = $this->db->prepare($queryOrders);
            foreach ($params as $key => $value) {
                $stmtOrders->bindValue($key, $value);
            }
            $stmtOrders->execute();
            $proxyOrders = $stmtOrders->fetchAll(PDO::FETCH_ASSOC);
            
            // 获取代理推广的新用户数
            $queryUsers = "
                SELECT 
                    `{$this->config['card_metrics']['fields']['proxy_id_field']}` AS proxy_id,
                    COUNT(DISTINCT `{$this->config['card_metrics']['fields']['user_id_field']}`) AS new_users
                FROM `{$this->config['card_metrics']['table_cards']}` 
                WHERE `{$this->config['card_metrics']['fields']['activate_time_field']}` IS NOT NULL
                AND {$timeCondition} {$proxyCondition}
                GROUP BY `{$this->config['card_metrics']['fields']['proxy_id_field']}`
            ";
            
            $stmtUsers = $this->db->prepare($queryUsers);
            foreach ($params as $key => $value) {
                $stmtUsers->bindValue($key, $value);
            }
            $stmtUsers->execute();
            $proxyUsers = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);
            
            // 合并数据
            $proxyData = [];
            
            // 先处理订单数据
            foreach ($proxyOrders as $orderData) {
                $proxyData[$orderData['proxy_id']] = [
                    'proxy_id' => $orderData['proxy_id'],
                    'order_count' => $orderData['order_count'],
                    'total_amount' => $orderData['total_amount'] ?? 0,
                    'new_users' => 0,
                ];
            }
            
            // 再合并用户数据
            foreach ($proxyUsers as $userData) {
                if (!isset($proxyData[$userData['proxy_id']])) {
                    $proxyData[$userData['proxy_id']] = [
                        'proxy_id' => $userData['proxy_id'],
                        'order_count' => 0,
                        'total_amount' => 0,
                    ];
                }
                $proxyData[$userData['proxy_id']]['new_users'] = $userData['new_users'];
            }
            
            // 结果
            $result = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'proxy_data' => array_values($proxyData),
                'timestamp' => time(),
            ];
            
            // 缓存结果
            $this->setCache($cacheKey, $result);
            
            return $result;
        } catch (Exception $e) {
            error_log('获取代理推广效果失败: ' . $e->getMessage());
            return [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'proxy_data' => [],
                'timestamp' => time(),
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 获取核心业务指标摘要
     * @param string $timeRange 时间范围
     * @return array 指标摘要
     */
    public function getBusinessMetricsSummary($timeRange = 'today') {
        // 构建缓存键
        $cacheKey = "business_metrics_summary_{$timeRange}";
        
        // 尝试从缓存获取
        if ($cached = $this->getCache($cacheKey)) {
            return $cached;
        }
        
        try {
            // 获取各项指标
            $cardActivationRate = $this->getCardActivationRate($timeRange);
            $orderConversionRate = $this->getOrderConversionRate($timeRange);
            $proxyEffect = $this->getProxyPromotionEffect($timeRange);
            
            // 计算总推广金额和订单数
            $totalPromotionAmount = 0;
            $totalPromotionOrders = 0;
            $totalNewUsers = 0;
            
            foreach ($proxyEffect['proxy_data'] as $proxy) {
                $totalPromotionAmount += $proxy['total_amount'];
                $totalPromotionOrders += $proxy['order_count'];
                $totalNewUsers += $proxy['new_users'];
            }
            
            // 构建摘要数据
            $summary = [
                'time_range' => $timeRange,
                'card_metrics' => [
                    'total_cards' => $cardActivationRate['total_cards'],
                    'activated_cards' => $cardActivationRate['activated_cards'],
                    'activation_rate' => $cardActivationRate['activation_rate'],
                ],
                'order_metrics' => [
                    'total_orders' => $orderConversionRate['total_orders'],
                    'success_orders' => $orderConversionRate['success_orders'],
                    'conversion_rate' => $orderConversionRate['conversion_rate'],
                    'total_amount' => $orderConversionRate['total_amount'],
                ],
                'proxy_metrics' => [
                    'total_promotion_amount' => $totalPromotionAmount,
                    'total_promotion_orders' => $totalPromotionOrders,
                    'total_new_users' => $totalNewUsers,
                    'top_proxies' => array_slice($proxyEffect['proxy_data'], 0, 5), // 前5名代理
                ],
                'timestamp' => time(),
            ];
            
            // 缓存结果
            $this->setCache($cacheKey, $summary);
            
            return $summary;
        } catch (Exception $e) {
            error_log('获取业务指标摘要失败: ' . $e->getMessage());
            return [
                'time_range' => $timeRange,
                'error' => $e->getMessage(),
                'timestamp' => time(),
            ];
        }
    }
    
    /**
     * 根据时间范围获取数据库条件
     * @param string $timeRange 时间范围
     * @param string $timeField 时间字段
     * @return string 时间条件
     */
    protected function getTimeCondition($timeRange, $timeField) {
        $field = "{$this->config['card_metrics']['table_cards']}.{$timeField}";
        
        switch ($timeRange) {
            case 'today':
                return "DATE(`{$timeField}`) = CURDATE()";
            case 'yesterday':
                return "DATE(`{$timeField}`) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case 'this_week':
                return "WEEK(`{$timeField}`, 1) = WEEK(CURDATE(), 1) AND YEAR(`{$timeField}`) = YEAR(CURDATE())";
            case 'last_week':
                return "WEEK(`{$timeField}`, 1) = WEEK(DATE_SUB(CURDATE(), INTERVAL 1 WEEK), 1) AND YEAR(`{$timeField}`) = YEAR(CURDATE())";
            case 'this_month':
                return "MONTH(`{$timeField}`) = MONTH(CURDATE()) AND YEAR(`{$timeField}`) = YEAR(CURDATE())";
            case 'last_month':
                return "MONTH(`{$timeField}`) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(`{$timeField}`) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
            case 'last_7_days':
                return "`{$timeField}` >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
            case 'last_30_days':
                return "`{$timeField}` >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            case 'last_90_days':
                return "`{$timeField}` >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)";
            default:
                return "1=1";
        }
    }
    
    /**
     * 获取指定时间段内的业务指标趋势
     * @param string $metric 指标类型 (activation_rate, conversion_rate, order_amount, new_users)
     * @param string $timeRange 时间范围 (week, month, quarter)
     * @return array 趋势数据
     */
    public function getMetricsTrend($metric, $timeRange = 'week') {
        // 构建缓存键
        $cacheKey = "metrics_trend_{$metric}_{$timeRange}";
        
        // 尝试从缓存获取
        if ($cached = $this->getCache($cacheKey)) {
            return $cached;
        }
        
        try {
            $trendData = [];
            $currentDate = new DateTime();
            
            switch ($timeRange) {
                case 'week':
                    // 过去7天
                    for ($i = 6; $i >= 0; $i--) {
                        $date = clone $currentDate;
                        $date->sub(new DateInterval("P{$i}D"));
                        $dateStr = $date->format('Y-m-d');
                        
                        switch ($metric) {
                            case 'activation_rate':
                                $dayMetrics = $this->getCardActivationRateByDate($dateStr);
                                $trendData[] = [
                                    'date' => $dateStr,
                                    'value' => $dayMetrics['activation_rate'],
                                    'total' => $dayMetrics['total_cards'],
                                    'activated' => $dayMetrics['activated_cards'],
                                ];
                                break;
                            case 'conversion_rate':
                                $dayMetrics = $this->getOrderConversionRateByDate($dateStr);
                                $trendData[] = [
                                    'date' => $dateStr,
                                    'value' => $dayMetrics['conversion_rate'],
                                    'total' => $dayMetrics['total_orders'],
                                    'success' => $dayMetrics['success_orders'],
                                ];
                                break;
                            case 'order_amount':
                                $dayMetrics = $this->getOrderAmountByDate($dateStr);
                                $trendData[] = [
                                    'date' => $dateStr,
                                    'value' => $dayMetrics['total_amount'],
                                    'orders' => $dayMetrics['order_count'],
                                ];
                                break;
                            case 'new_users':
                                $dayMetrics = $this->getNewUsersByDate($dateStr);
                                $trendData[] = [
                                    'date' => $dateStr,
                                    'value' => $dayMetrics['new_users'],
                                ];
                                break;
                        }
                    }
                    break;
                
                case 'month':
                    // 过去30天，按天统计
                    for ($i = 29; $i >= 0; $i--) {
                        $date = clone $currentDate;
                        $date->sub(new DateInterval("P{$i}D"));
                        $dateStr = $date->format('Y-m-d');
                        
                        // 指标计算逻辑类似week情况
                        // ...
                    }
                    break;
                
                case 'quarter':
                    // 过去90天，按周统计
                    for ($i = 12; $i >= 0; $i--) {
                        $date = clone $currentDate;
                        $date->sub(new DateInterval("P{$i}W"));
                        $weekStart = clone $date;
                        $weekStart->modify('monday this week');
                        $weekEnd = clone $weekStart;
                        $weekEnd->modify('sunday this week');
                        
                        $weekLabel = $weekStart->format('Y-m-d') . ' ~ ' . $weekEnd->format('Y-m-d');
                        
                        // 按周计算指标
                        // ...
                    }
                    break;
            }
            
            // 缓存结果
            $this->setCache($cacheKey, $trendData);
            
            return $trendData;
        } catch (Exception $e) {
            error_log('获取指标趋势失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取指定日期的卡密激活率
     * @param string $date 日期，格式 Y-m-d
     * @return array 激活率数据
     */
    protected function getCardActivationRateByDate($date) {
        try {
            // 获取总卡密数量
            $queryTotal = "
                SELECT COUNT(*) AS total 
                FROM `{$this->config['card_metrics']['table_cards']}` 
                WHERE DATE(`{$this->config['card_metrics']['fields']['create_time_field']}`) = :date
            ";
            
            $stmtTotal = $this->db->prepare($queryTotal);
            $stmtTotal->bindValue(':date', $date, PDO::PARAM_STR);
            $stmtTotal->execute();
            $totalCards = $stmtTotal->fetch(PDO::FETCH_ASSOC)['total'];
            
            // 获取已激活卡密数量
            $queryActivated = "
                SELECT COUNT(*) AS activated 
                FROM `{$this->config['card_metrics']['table_cards']}` 
                WHERE `{$this->config['card_metrics']['fields']['activate_time_field']}` IS NOT NULL 
                AND DATE(`{$this->config['card_metrics']['fields']['create_time_field']}`) = :date
            ";
            
            $stmtActivated = $this->db->prepare($queryActivated);
            $stmtActivated->bindValue(':date', $date, PDO::PARAM_STR);
            $stmtActivated->execute();
            $activatedCards = $stmtActivated->fetch(PDO::FETCH_ASSOC)['activated'];
            
            // 计算激活率
            $activationRate = $totalCards > 0 ? ($activatedCards / $totalCards * 100) : 0;
            
            return [
                'date' => $date,
                'total_cards' => $totalCards,
                'activated_cards' => $activatedCards,
                'activation_rate' => round($activationRate, 2),
            ];
        } catch (Exception $e) {
            error_log('获取指定日期卡密激活率失败: ' . $e->getMessage());
            return [
                'date' => $date,
                'total_cards' => 0,
                'activated_cards' => 0,
                'activation_rate' => 0,
            ];
        }
    }
    
    /**
     * 获取指定日期的订单转化率
     * @param string $date 日期，格式 Y-m-d
     * @return array 转化率数据
     */
    protected function getOrderConversionRateByDate($date) {
        try {
            // 获取总订单数量
            $queryTotal = "
                SELECT COUNT(*) AS total 
                FROM `{$this->config['order_metrics']['table_orders']}` 
                WHERE DATE(`{$this->config['order_metrics']['fields']['create_time_field']}`) = :date
            ";
            
            $stmtTotal = $this->db->prepare($queryTotal);
            $stmtTotal->bindValue(':date', $date, PDO::PARAM_STR);
            $stmtTotal->execute();
            $totalOrders = $stmtTotal->fetch(PDO::FETCH_ASSOC)['total'];
            
            // 获取成功订单数量
            $querySuccess = "
                SELECT COUNT(*) AS success 
                FROM `{$this->config['order_metrics']['table_orders']}` 
                WHERE `{$this->config['order_metrics']['fields']['status_field']}` IN ('" . 
                    implode("', '", $this->config['order_metrics']['success_statuses']) . "') 
                AND DATE(`{$this->config['order_metrics']['fields']['create_time_field']}`) = :date
            ";
            
            $stmtSuccess = $this->db->prepare($querySuccess);
            $stmtSuccess->bindValue(':date', $date, PDO::PARAM_STR);
            $stmtSuccess->execute();
            $successOrders = $stmtSuccess->fetch(PDO::FETCH_ASSOC)['success'];
            
            // 计算转化率
            $conversionRate = $totalOrders > 0 ? ($successOrders / $totalOrders * 100) : 0;
            
            return [
                'date' => $date,
                'total_orders' => $totalOrders,
                'success_orders' => $successOrders,
                'conversion_rate' => round($conversionRate, 2),
            ];
        } catch (Exception $e) {
            error_log('获取指定日期订单转化率失败: ' . $e->getMessage());
            return [
                'date' => $date,
                'total_orders' => 0,
                'success_orders' => 0,
                'conversion_rate' => 0,
            ];
        }
    }
    
    /**
     * 获取指定日期的订单金额
     * @param string $date 日期，格式 Y-m-d
     * @return array 订单金额数据
     */
    protected function getOrderAmountByDate($date) {
        try {
            $query = "
                SELECT 
                    COUNT(*) AS order_count,
                    SUM(`{$this->config['order_metrics']['fields']['amount_field']}`) AS total_amount 
                FROM `{$this->config['order_metrics']['table_orders']}` 
                WHERE `{$this->config['order_metrics']['fields']['status_field']}` IN ('" . 
                    implode("', '", $this->config['order_metrics']['success_statuses']) . "') 
                AND DATE(`{$this->config['order_metrics']['fields']['create_time_field']}`) = :date
            ";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':date', $date, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return [
                'date' => $date,
                'order_count' => $result['order_count'],
                'total_amount' => $result['total_amount'] ?? 0,
            ];
        } catch (Exception $e) {
            error_log('获取指定日期订单金额失败: ' . $e->getMessage());
            return [
                'date' => $date,
                'order_count' => 0,
                'total_amount' => 0,
            ];
        }
    }
    
    /**
     * 获取指定日期的新用户数量
     * @param string $date 日期，格式 Y-m-d
     * @return array 新用户数据
     */
    protected function getNewUsersByDate($date) {
        try {
            $query = "
                SELECT COUNT(DISTINCT `{$this->config['card_metrics']['fields']['user_id_field']}`) AS new_users 
                FROM `{$this->config['card_metrics']['table_cards']}` 
                WHERE `{$this->config['card_metrics']['fields']['activate_time_field']}` IS NOT NULL 
                AND DATE(`{$this->config['card_metrics']['fields']['activate_time_field']}`) = :date
            ";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':date', $date, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return [
                'date' => $date,
                'new_users' => $result['new_users'],
            ];
        } catch (Exception $e) {
            error_log('获取指定日期新用户数量失败: ' . $e->getMessage());
            return [
                'date' => $date,
                'new_users' => 0,
            ];
        }
    }
}