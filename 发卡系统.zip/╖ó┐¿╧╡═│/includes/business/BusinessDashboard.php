<?php
/**
 * 业务指标看板
 * 负责整合和展示核心业务指标，提供数据可视化和分析功能
 */

// 引入业务指标收集器
require_once __DIR__ . '/BusinessMetricsCollector.php';

class BusinessDashboard {
    /**
     * 业务指标收集器实例
     * @var BusinessMetricsCollector
     */
    protected $metricsCollector = null;
    
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        // 看板配置
        'dashboard' => [
            'default_time_range' => 'today',    // 默认时间范围
            'available_time_ranges' => ['today', 'yesterday', 'last_7_days', 'last_30_days', 'this_week', 'last_week', 'this_month', 'last_month'],
            'refresh_interval' => 60,           // 数据刷新间隔，秒
        ],
        
        // 图表配置
        'charts' => [
            'card_activation' => [
                'enabled' => true,
                'title' => '卡密激活率趋势',
                'type' => 'line',  // 折线图
            ],
            'order_conversion' => [
                'enabled' => true,
                'title' => '订单转化率趋势',
                'type' => 'line',  // 折线图
            ],
            'order_amount' => [
                'enabled' => true,
                'title' => '订单金额趋势',
                'type' => 'bar',   // 柱状图
            ],
            'new_users' => [
                'enabled' => true,
                'title' => '新增用户趋势',
                'type' => 'line',  // 折线图
            ],
            'proxy_performance' => [
                'enabled' => true,
                'title' => '代理推广效果排行',
                'type' => 'bar',   // 柱状图
                'limit' => 10,     // 显示前10名
            ],
        ],
        
        // 统计面板配置
        'stats_panels' => [
            'total_cards' => [
                'enabled' => true,
                'title' => '总卡密数',
                'icon' => 'card',
                'color' => '#4CAF50',
            ],
            'activation_rate' => [
                'enabled' => true,
                'title' => '激活率',
                'icon' => 'check-circle',
                'color' => '#2196F3',
                'unit' => '%',
            ],
            'total_orders' => [
                'enabled' => true,
                'title' => '总订单数',
                'icon' => 'receipt',
                'color' => '#FF9800',
            ],
            'conversion_rate' => [
                'enabled' => true,
                'title' => '转化率',
                'icon' => 'pie-chart',
                'color' => '#9C27B0',
                'unit' => '%',
            ],
            'total_amount' => [
                'enabled' => true,
                'title' => '总交易额',
                'icon' => 'credit-card',
                'color' => '#F44336',
                'unit' => '元',
            ],
            'new_users' => [
                'enabled' => true,
                'title' => '新增用户',
                'icon' => 'account-plus',
                'color' => '#00BCD4',
            ],
        ],
        
        // 告警配置
        'alerts' => [
            'thresholds' => [
                'activation_rate_low' => 30,    // 激活率低于30%告警
                'conversion_rate_low' => 20,    // 转化率低于20%告警
                'error_rate_high' => 5,         // 错误率高于5%告警
            ],
            'compare_to_previous_period' => true,  // 是否与上期对比
            'alert_on_decline' => true,            // 是否在指标下降时告警
            'decline_threshold' => 20,             // 下降超过20%告警
        ],
    ];
    
    /**
     * 单例实例
     * @var BusinessDashboard
     */
    protected static $instance = null;
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化业务指标收集器
        $this->initializeMetricsCollector();
    }
    
    /**
     * 获取单例实例
     * @param array $config 配置信息
     * @return BusinessDashboard
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化业务指标收集器
     */
    protected function initializeMetricsCollector() {
        try {
            $this->metricsCollector = BusinessMetricsCollector::getInstance();
        } catch (Exception $e) {
            error_log('初始化业务指标收集器失败: ' . $e->getMessage());
            throw new Exception('业务看板初始化失败');
        }
    }
    
    /**
     * 获取看板数据
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID，不传则获取所有代理的数据
     * @return array 看板数据
     */
    public function getDashboardData($timeRange = null, $proxyId = null) {
        // 使用默认时间范围或指定的时间范围
        $timeRange = $timeRange ?? $this->config['dashboard']['default_time_range'];
        
        // 验证时间范围
        if (!in_array($timeRange, $this->config['dashboard']['available_time_ranges'])) {
            throw new InvalidArgumentException("无效的时间范围: {$timeRange}");
        }
        
        try {
            // 获取统计面板数据
            $statsPanels = $this->getStatsPanelsData($timeRange, $proxyId);
            
            // 获取图表数据
            $chartData = $this->getChartData($timeRange, $proxyId);
            
            // 获取告警信息
            $alerts = $this->getAlerts($timeRange, $proxyId);
            
            // 构建看板数据
            $dashboardData = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'timestamp' => time(),
                'refresh_interval' => $this->config['dashboard']['refresh_interval'],
                'stats_panels' => $statsPanels,
                'charts' => $chartData,
                'alerts' => $alerts,
                'available_time_ranges' => $this->config['dashboard']['available_time_ranges'],
            ];
            
            return $dashboardData;
        } catch (Exception $e) {
            error_log('获取看板数据失败: ' . $e->getMessage());
            throw new Exception('获取看板数据失败');
        }
    }
    
    /**
     * 获取统计面板数据
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 统计面板数据
     */
    protected function getStatsPanelsData($timeRange, $proxyId = null) {
        try {
            $panels = [];
            
            // 获取业务指标摘要
            $metricsSummary = $this->metricsCollector->getBusinessMetricsSummary($timeRange);
            
            // 计算新增用户数
            $proxyEffect = $this->metricsCollector->getProxyPromotionEffect($timeRange, $proxyId);
            $totalNewUsers = 0;
            foreach ($proxyEffect['proxy_data'] as $proxy) {
                $totalNewUsers += $proxy['new_users'];
            }
            
            // 生成各个统计面板
            foreach ($this->config['stats_panels'] as $panelKey => $panelConfig) {
                if (!$panelConfig['enabled']) {
                    continue;
                }
                
                $panelData = [
                    'key' => $panelKey,
                    'title' => $panelConfig['title'],
                    'icon' => $panelConfig['icon'],
                    'color' => $panelConfig['color'],
                    'unit' => isset($panelConfig['unit']) ? $panelConfig['unit'] : '',
                ];
                
                // 根据面板类型设置数值
                switch ($panelKey) {
                    case 'total_cards':
                        $panelData['value'] = $metricsSummary['card_metrics']['total_cards'];
                        break;
                    case 'activation_rate':
                        $panelData['value'] = $metricsSummary['card_metrics']['activation_rate'];
                        break;
                    case 'total_orders':
                        $panelData['value'] = $metricsSummary['order_metrics']['total_orders'];
                        break;
                    case 'conversion_rate':
                        $panelData['value'] = $metricsSummary['order_metrics']['conversion_rate'];
                        break;
                    case 'total_amount':
                        $panelData['value'] = $metricsSummary['order_metrics']['total_amount'];
                        break;
                    case 'new_users':
                        $panelData['value'] = $totalNewUsers;
                        break;
                }
                
                // 获取对比数据
                $previousValue = $this->getPreviousPeriodValue($panelKey, $timeRange, $proxyId);
                if ($previousValue !== null) {
                    $panelData['previous_value'] = $previousValue;
                    $panelData['change'] = $this->calculateChange($panelData['value'], $previousValue);
                    $panelData['trend'] = $panelData['change'] > 0 ? 'up' : ($panelData['change'] < 0 ? 'down' : 'stable');
                }
                
                $panels[] = $panelData;
            }
            
            return $panels;
        } catch (Exception $e) {
            error_log('获取统计面板数据失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取图表数据
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 图表数据
     */
    protected function getChartData($timeRange, $proxyId = null) {
        try {
            $charts = [];
            
            // 确定图表的时间范围类型
            $chartTimeRange = $this->getTimeRangeForChart($timeRange);
            
            // 生成各个图表数据
            foreach ($this->config['charts'] as $chartKey => $chartConfig) {
                if (!$chartConfig['enabled']) {
                    continue;
                }
                
                $chartData = [
                    'key' => $chartKey,
                    'title' => $chartConfig['title'],
                    'type' => $chartConfig['type'],
                    'data' => [],
                    'labels' => [],
                    'series' => [],
                ];
                
                // 根据图表类型获取数据
                switch ($chartKey) {
                    case 'card_activation':
                        $trendData = $this->metricsCollector->getMetricsTrend('activation_rate', $chartTimeRange);
                        $chartData['labels'] = array_column($trendData, 'date');
                        $chartData['series'][] = [
                            'name' => '激活率(%)',
                            'data' => array_column($trendData, 'value'),
                        ];
                        break;
                    case 'order_conversion':
                        $trendData = $this->metricsCollector->getMetricsTrend('conversion_rate', $chartTimeRange);
                        $chartData['labels'] = array_column($trendData, 'date');
                        $chartData['series'][] = [
                            'name' => '转化率(%)',
                            'data' => array_column($trendData, 'value'),
                        ];
                        break;
                    case 'order_amount':
                        $trendData = $this->metricsCollector->getMetricsTrend('order_amount', $chartTimeRange);
                        $chartData['labels'] = array_column($trendData, 'date');
                        $chartData['series'][] = [
                            'name' => '订单金额(元)',
                            'data' => array_column($trendData, 'value'),
                        ];
                        break;
                    case 'new_users':
                        $trendData = $this->metricsCollector->getMetricsTrend('new_users', $chartTimeRange);
                        $chartData['labels'] = array_column($trendData, 'date');
                        $chartData['series'][] = [
                            'name' => '新增用户',
                            'data' => array_column($trendData, 'value'),
                        ];
                        break;
                    case 'proxy_performance':
                        $proxyData = $this->metricsCollector->getProxyPromotionEffect($timeRange);
                        // 获取代理信息
                        $proxyInfo = $this->getProxyInfo(array_column($proxyData['proxy_data'], 'proxy_id'));
                        
                        // 限制显示数量
                        $limit = $chartConfig['limit'];
                        $limitedProxies = array_slice($proxyData['proxy_data'], 0, $limit);
                        
                        // 构建图表数据
                        $chartData['labels'] = array_map(function($proxy) use ($proxyInfo) {
                            return isset($proxyInfo[$proxy['proxy_id']]) ? $proxyInfo[$proxy['proxy_id']]['name'] : "代理{$proxy['proxy_id']}";
                        }, $limitedProxies);
                        
                        $chartData['series'][] = [
                            'name' => '推广金额(元)',
                            'data' => array_column($limitedProxies, 'total_amount'),
                        ];
                        break;
                }
                
                $charts[] = $chartData;
            }
            
            return $charts;
        } catch (Exception $e) {
            error_log('获取图表数据失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取告警信息
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 告警信息
     */
    protected function getAlerts($timeRange, $proxyId = null) {
        $alerts = [];
        
        // 只有开启告警功能时才检查
        if (!$this->config['alerts']['compare_to_previous_period']) {
            return $alerts;
        }
        
        try {
            // 获取当前指标
            $statsPanels = $this->getStatsPanelsData($timeRange, $proxyId);
            
            // 检查每个指标是否触发告警
            foreach ($statsPanels as $panel) {
                $alert = $this->checkAlertConditions($panel, $timeRange, $proxyId);
                if ($alert) {
                    $alerts[] = $alert;
                }
            }
            
            return $alerts;
        } catch (Exception $e) {
            error_log('获取告警信息失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 检查告警条件
     * @param array $panel 统计面板数据
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array|null 告警信息，不触发告警则返回null
     */
    protected function checkAlertConditions(array $panel, $timeRange, $proxyId = null) {
        $alertThreshold = $this->config['alerts']['decline_threshold'];
        
        // 检查是否有对比数据
        if (!isset($panel['change'])) {
            return null;
        }
        
        // 检查下降趋势告警
        if ($this->config['alerts']['alert_on_decline'] && $panel['change'] < -$alertThreshold) {
            return [
                'type' => 'decline',
                'severity' => 'warning',
                'title' => "{$panel['title']}下降",
                'message' => "{$panel['title']}较上期下降了" . abs($panel['change']) . "%",
                'metric' => $panel['key'],
                'current_value' => $panel['value'],
                'previous_value' => $panel['previous_value'],
                'change' => $panel['change'],
                'time_range' => $timeRange,
                'timestamp' => time(),
            ];
        }
        
        // 检查特定指标阈值
        switch ($panel['key']) {
            case 'activation_rate':
                if ($panel['value'] < $this->config['alerts']['thresholds']['activation_rate_low']) {
                    return [
                        'type' => 'threshold',
                        'severity' => 'critical',
                        'title' => '卡密激活率过低',
                        'message' => "卡密激活率仅为{$panel['value']}%，低于阈值{$this->config['alerts']['thresholds']['activation_rate_low']}%",
                        'metric' => $panel['key'],
                        'current_value' => $panel['value'],
                        'threshold' => $this->config['alerts']['thresholds']['activation_rate_low'],
                        'time_range' => $timeRange,
                        'timestamp' => time(),
                    ];
                }
                break;
            case 'conversion_rate':
                if ($panel['value'] < $this->config['alerts']['thresholds']['conversion_rate_low']) {
                    return [
                        'type' => 'threshold',
                        'severity' => 'critical',
                        'title' => '订单转化率过低',
                        'message' => "订单转化率仅为{$panel['value']}%，低于阈值{$this->config['alerts']['thresholds']['conversion_rate_low']}%",
                        'metric' => $panel['key'],
                        'current_value' => $panel['value'],
                        'threshold' => $this->config['alerts']['thresholds']['conversion_rate_low'],
                        'time_range' => $timeRange,
                        'timestamp' => time(),
                    ];
                }
                break;
        }
        
        return null;
    }
    
    /**
     * 获取上一时期的指标值
     * @param string $metricKey 指标键
     * @param string $currentTimeRange 当前时间范围
     * @param int $proxyId 可选，代理ID
     * @return float|null 上一时期的指标值
     */
    protected function getPreviousPeriodValue($metricKey, $currentTimeRange, $proxyId = null) {
        try {
            // 确定上一时期的时间范围
            $previousTimeRange = $this->getPreviousPeriodTimeRange($currentTimeRange);
            if (!$previousTimeRange) {
                return null;
            }
            
            // 获取上一时期的统计面板数据
            $previousPanels = $this->getStatsPanelsData($previousTimeRange, $proxyId);
            
            // 查找对应指标值
            foreach ($previousPanels as $panel) {
                if ($panel['key'] === $metricKey) {
                    return $panel['value'];
                }
            }
            
            return null;
        } catch (Exception $e) {
            error_log('获取上一时期指标值失败: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 获取上一时期的时间范围
     * @param string $currentTimeRange 当前时间范围
     * @return string|null 上一时期的时间范围
     */
    protected function getPreviousPeriodTimeRange($currentTimeRange) {
        $previousMap = [
            'today' => 'yesterday',
            'yesterday' => 'last_7_days', // 这里简化处理，实际应该获取前天的数据
            'last_7_days' => 'last_7_days', // 这里简化处理，实际应该获取再上7天的数据
            'last_30_days' => 'last_30_days', // 这里简化处理
            'this_week' => 'last_week',
            'last_week' => 'last_week', // 这里简化处理
            'this_month' => 'last_month',
            'last_month' => 'last_month', // 这里简化处理
        ];
        
        return isset($previousMap[$currentTimeRange]) ? $previousMap[$currentTimeRange] : null;
    }
    
    /**
     * 获取图表用的时间范围类型
     * @param string $timeRange 时间范围
     * @return string 图表时间范围类型
     */
    protected function getTimeRangeForChart($timeRange) {
        $chartTimeRangeMap = [
            'today' => 'week',
            'yesterday' => 'week',
            'last_7_days' => 'week',
            'this_week' => 'week',
            'last_week' => 'week',
            'this_month' => 'month',
            'last_month' => 'month',
            'last_30_days' => 'month',
        ];
        
        return isset($chartTimeRangeMap[$timeRange]) ? $chartTimeRangeMap[$timeRange] : 'week';
    }
    
    /**
     * 计算变化百分比
     * @param float $current 当前值
     * @param float $previous 上一期值
     * @return float 变化百分比
     */
    protected function calculateChange($current, $previous) {
        if ($previous == 0) {
            return $current > 0 ? 100 : 0;
        }
        
        return round(($current - $previous) / $previous * 100, 2);
    }
    
    /**
     * 获取代理信息
     * @param array $proxyIds 代理ID数组
     * @return array 代理信息数组
     */
    protected function getProxyInfo(array $proxyIds) {
        if (empty($proxyIds)) {
            return [];
        }
        
        try {
            // 这里应该根据实际的代理表结构进行查询
            // 假设代理表为proxies，有id和name字段
            $proxyIdsStr = implode(',', $proxyIds);
            $query = "SELECT id, name FROM proxies WHERE id IN ({$proxyIdsStr})";
            
            // 这里需要从指标收集器获取数据库连接
            $db = $this->metricsCollector->db ?? null; // 注意：这里需要BusinessMetricsCollector提供访问数据库连接的方法
            
            // 简化处理，如果无法获取数据库连接，则返回空数组
            if (!$db) {
                return [];
            }
            
            $stmt = $db->query($query);
            $proxies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 构建代理信息映射
            $proxyInfo = [];
            foreach ($proxies as $proxy) {
                $proxyInfo[$proxy['id']] = $proxy;
            }
            
            return $proxyInfo;
        } catch (Exception $e) {
            error_log('获取代理信息失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取卡密指标详情
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 卡密指标详情
     */
    public function getCardMetricsDetails($timeRange = null, $proxyId = null) {
        // 使用默认时间范围或指定的时间范围
        $timeRange = $timeRange ?? $this->config['dashboard']['default_time_range'];
        
        try {
            // 获取卡密激活率数据
            $activationRate = $this->metricsCollector->getCardActivationRate($timeRange, $proxyId);
            
            // 获取卡密类型分布
            $cardTypeDistribution = $this->getCardTypeDistribution($timeRange, $proxyId);
            
            // 构建详情数据
            $details = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'activation_rate' => $activationRate,
                'type_distribution' => $cardTypeDistribution,
                'time_series' => $this->metricsCollector->getMetricsTrend('activation_rate', $this->getTimeRangeForChart($timeRange)),
            ];
            
            return $details;
        } catch (Exception $e) {
            error_log('获取卡密指标详情失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取订单指标详情
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 订单指标详情
     */
    public function getOrderMetricsDetails($timeRange = null, $proxyId = null) {
        // 使用默认时间范围或指定的时间范围
        $timeRange = $timeRange ?? $this->config['dashboard']['default_time_range'];
        
        try {
            // 获取订单转化率数据
            $conversionRate = $this->metricsCollector->getOrderConversionRate($timeRange, $proxyId);
            
            // 获取订单状态分布
            $orderStatusDistribution = $this->getOrderStatusDistribution($timeRange, $proxyId);
            
            // 构建详情数据
            $details = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'conversion_rate' => $conversionRate,
                'status_distribution' => $orderStatusDistribution,
                'time_series' => $this->metricsCollector->getMetricsTrend('conversion_rate', $this->getTimeRangeForChart($timeRange)),
            ];
            
            return $details;
        } catch (Exception $e) {
            error_log('获取订单指标详情失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取代理指标详情
     * @param int $proxyId 代理ID
     * @param string $timeRange 时间范围
     * @return array 代理指标详情
     */
    public function getProxyMetricsDetails($proxyId, $timeRange = null) {
        // 使用默认时间范围或指定的时间范围
        $timeRange = $timeRange ?? $this->config['dashboard']['default_time_range'];
        
        try {
            // 获取代理推广效果数据
            $proxyEffect = $this->metricsCollector->getProxyPromotionEffect($timeRange, $proxyId);
            
            // 获取代理的卡密激活率
            $cardActivationRate = $this->metricsCollector->getCardActivationRate($timeRange, $proxyId);
            
            // 获取代理的订单转化率
            $orderConversionRate = $this->metricsCollector->getOrderConversionRate($timeRange, $proxyId);
            
            // 构建详情数据
            $details = [
                'time_range' => $timeRange,
                'proxy_id' => $proxyId,
                'promotion_effect' => $proxyEffect,
                'card_activation_rate' => $cardActivationRate,
                'order_conversion_rate' => $orderConversionRate,
            ];
            
            return $details;
        } catch (Exception $e) {
            error_log('获取代理指标详情失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取卡密类型分布
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 卡密类型分布
     */
    protected function getCardTypeDistribution($timeRange, $proxyId = null) {
        try {
            // 这里简化处理，实际应该根据项目的卡密类型字段进行查询
            // 假设卡密表中有type字段表示卡密类型
            return [
                'type1' => ['count' => 100, 'percentage' => 30],
                'type2' => ['count' => 150, 'percentage' => 45],
                'type3' => ['count' => 83, 'percentage' => 25],
            ];
        } catch (Exception $e) {
            error_log('获取卡密类型分布失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取订单状态分布
     * @param string $timeRange 时间范围
     * @param int $proxyId 可选，代理ID
     * @return array 订单状态分布
     */
    protected function getOrderStatusDistribution($timeRange, $proxyId = null) {
        try {
            // 这里简化处理，实际应该根据订单表的状态字段进行查询
            $statuses = [
                'pending' => '待支付',
                'paid' => '已支付',
                'completed' => '已完成',
                'failed' => '失败',
                'canceled' => '已取消',
            ];
            
            $distribution = [];
            foreach ($statuses as $key => $name) {
                $distribution[$key] = ['name' => $name, 'count' => 0, 'percentage' => 0];
            }
            
            // 假设从metrics collector获取订单状态分布
            return $distribution;
        } catch (Exception $e) {
            error_log('获取订单状态分布失败: ' . $e->getMessage());
            return [];
        }
    }
}