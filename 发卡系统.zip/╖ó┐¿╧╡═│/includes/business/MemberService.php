<?php
/**
 * 会员服务类
 * 实现会员等级管理、积分管理等功能
 */

require_once '../config.php';
require_once '../database/Database.php';
require_once '../utils/Logger.php';

class MemberService {
    private $db;
    private $logger;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     */
    public function __construct($db = null) {
        if ($db === null) {
            $db = new Database();
        }
        $this->db = $db;
        $this->logger = new Logger('member');
    }
    
    /**
     * 获取用户会员信息
     * @param int $userId 用户ID
     * @return array 会员信息
     */
    public function getUserMemberInfo($userId) {
        try {
            // 检查用户会员记录是否存在
            $memberInfo = $this->db->selectOne(
                "SELECT um.*, ml.name as level_name, ml.level as level_value, 
                        ml.discount_rate, ml.description as level_description,
                        ml.icon_url, ml.privileges
                 FROM user_members um
                 LEFT JOIN member_levels ml ON um.member_level_id = ml.id
                 WHERE um.user_id = ?", 
                [$userId]
            );
            
            // 如果不存在，创建一个默认记录
            if (!$memberInfo) {
                // 获取初始会员等级
                $defaultLevel = $this->db->selectOne(
                    "SELECT id FROM member_levels WHERE level = 1 AND status = 'active'"
                );
                
                $defaultLevelId = $defaultLevel ? $defaultLevel['id'] : 1;
                
                // 创建用户会员记录
                $this->db->execute(
                    "INSERT INTO user_members (user_id, member_level_id, current_points, total_points, member_since) 
                     VALUES (?, ?, 0, 0, NOW())", 
                    [$userId, $defaultLevelId]
                );
                
                // 重新获取会员信息
                return $this->getUserMemberInfo($userId);
            }
            
            // 解析特权JSON
            if (isset($memberInfo['privileges']) && !empty($memberInfo['privileges'])) {
                $memberInfo['privileges'] = json_decode($memberInfo['privileges'], true);
            } else {
                $memberInfo['privileges'] = [];
            }
            
            // 获取积分明细
            $memberInfo['points_from_orders'] = $this->db->selectOne(
                "SELECT COALESCE(SUM(change_points), 0) as points 
                 FROM point_transactions 
                 WHERE user_id = ? AND type = 'order' AND change_points > 0",
                [$userId]
            )['points'];
            
            $memberInfo['points_from_activities'] = $this->db->selectOne(
                "SELECT COALESCE(SUM(change_points), 0) as points 
                 FROM point_transactions 
                 WHERE user_id = ? AND type = 'activity' AND change_points > 0",
                [$userId]
            )['points'];
            
            // 获取即将过期积分
            $memberInfo['expiring_points'] = $this->getExpiringPoints($userId);
            
            // 获取距离下一等级所需积分
            $memberInfo['next_level_remaining'] = $this->getNextLevelRemainingPoints($userId);
            
            return $memberInfo;
        } catch (Exception $e) {
            $this->logger->error("获取用户会员信息失败: " . $e->getMessage(), ['user_id' => $userId]);
            throw $e;
        }
    }
    
    /**
     * 更新用户积分
     * @param int $userId 用户ID
     * @param int $points 积分变化量（正数增加，负数减少）
     * @param string $reason 积分变更原因
     * @param string $type 积分变更类型 (order/activity/exchange/expire/other)
     * @param int $relatedId 关联ID（如订单ID、活动ID等）
     * @return bool 是否成功
     */
    public function updateUserPoints($userId, $points, $reason, $type = 'other', $relatedId = null) {
        try {
            // 开始事务
            $this->db->beginTransaction();
            
            // 获取用户当前积分
            $memberInfo = $this->getUserMemberInfo($userId);
            $currentPoints = $memberInfo['current_points'];
            $newPoints = $currentPoints + $points;
            
            // 检查积分是否足够
            if ($newPoints < 0) {
                throw new Exception('积分不足');
            }
            
            // 更新用户积分
            $this->db->execute(
                "UPDATE user_members SET current_points = ?, total_points = total_points + ? 
                 WHERE user_id = ?", 
                [$newPoints, $points, $userId]
            );
            
            // 记录积分交易
            $expireDate = null;
            // 积分通常设置为1年后过期，除非是负积分（如兑换或过期）
            if ($points > 0) {
                $expireDate = date('Y-m-d', strtotime('+1 year'));
            }
            
            $this->db->execute(
                "INSERT INTO point_transactions 
                 (user_id, type, change_points, balance_points, reason, expire_date, related_id, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())", 
                [$userId, $type, $points, $newPoints, $reason, $expireDate, $relatedId]
            );
            
            // 检查并更新会员等级
            $this->checkAndUpdateMemberLevel($userId, $newPoints);
            
            // 提交事务
            $this->db->commit();
            
            $this->logger->info("用户积分更新", [
                'user_id' => $userId,
                'points_change' => $points,
                'new_balance' => $newPoints,
                'reason' => $reason
            ]);
            
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollback();
            $this->logger->error("更新用户积分失败: " . $e->getMessage(), [
                'user_id' => $userId,
                'points_change' => $points
            ]);
            throw $e;
        }
    }
    
    /**
     * 检查并更新会员等级
     * @param int $userId 用户ID
     * @param int $currentPoints 当前积分
     * @return bool 是否成功
     */
    private function checkAndUpdateMemberLevel($userId, $currentPoints) {
        // 获取积分对应的会员等级
        $sql = "SELECT id, level FROM member_levels 
                WHERE min_points <= ? AND status = 'active' 
                ORDER BY level DESC LIMIT 1";
        $levelInfo = $this->db->selectOne($sql, [$currentPoints]);
        
        if (!$levelInfo) {
            return false;
        }
        
        $newLevelId = $levelInfo['id'];
        $newLevelValue = $levelInfo['level'];
        
        // 获取用户当前等级
        $memberInfo = $this->getUserMemberInfo($userId);
        $currentLevelId = $memberInfo['member_level_id'];
        $currentLevelValue = $memberInfo['level_value'] ?? 1;
        
        // 如果等级有变化
        if ($newLevelId != $currentLevelId) {
            // 更新会员等级
            $sql = "UPDATE user_members SET member_level_id = ?, last_level_change = NOW() WHERE user_id = ?";
            $result = $this->db->execute($sql, [$newLevelId, $userId]);
            
            if ($result) {
                // 记录等级变更历史
                $changeReason = $newLevelValue > $currentLevelValue ? '积分达到升级条件' : '积分不足降级';
                
                $this->db->execute(
                    "INSERT INTO member_level_history 
                     (user_id, old_level_id, new_level_id, change_reason, change_points, created_at) 
                     VALUES (?, ?, ?, ?, ?, NOW())", 
                    [$userId, $currentLevelId, $newLevelId, $changeReason, $currentPoints]
                );
                
                $this->logger->info("用户会员等级更新", [
                    'user_id' => $userId,
                    'old_level' => $currentLevelValue,
                    'new_level' => $newLevelValue,
                    'reason' => $changeReason
                ]);
                
                // 这里可以添加等级变更通知逻辑
                $this->sendLevelChangeNotification($userId, $currentLevelValue, $newLevelValue);
            }
            
            return $result;
        }
        
        return true;
    }
    
    /**
     * 获取可用的积分兑换规则
     * @return array 兑换规则列表
     */
    public function getAvailableExchangeRules() {
        try {
            return $this->db->select(
                "SELECT * FROM point_exchange_rules WHERE status = 'active' ORDER BY required_points ASC"
            );
        } catch (Exception $e) {
            $this->logger->error("获取积分兑换规则失败: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 使用积分兑换
     * @param int $userId 用户ID
     * @param int $ruleId 兑换规则ID
     * @return array 兑换结果
     */
    public function exchangePoints($userId, $ruleId) {
        try {
            // 开始事务
            $this->db->beginTransaction();
            
            // 获取兑换规则
            $rule = $this->db->selectOne(
                "SELECT * FROM point_exchange_rules WHERE id = ? AND status = 'active'", 
                [$ruleId]
            );
            
            if (!$rule) {
                throw new Exception('无效的兑换规则');
            }
            
            // 检查用户积分
            $memberInfo = $this->getUserMemberInfo($userId);
            if ($memberInfo['current_points'] < $rule['required_points']) {
                throw new Exception('积分不足');
            }
            
            // 检查每日兑换次数限制
            $todayExchanges = $this->db->selectOne(
                "SELECT COUNT(*) as count FROM point_exchanges 
                 WHERE user_id = ? AND rule_id = ? AND DATE(created_at) = DATE(NOW())", 
                [$userId, $ruleId]
            );
            
            if ($todayExchanges['count'] >= $rule['max_daily_exchanges']) {
                throw new Exception('已达到今日兑换次数上限');
            }
            
            // 根据兑换类型处理
            $exchangeResult = null;
            
            switch ($rule['type']) {
                case 'cash':
                    // 现金抵扣，记录兑换但不需要创建具体物品
                    $exchangeResult = [
                        'type' => 'cash',
                        'amount' => $rule['exchange_value'],
                        'message' => '积分兑换现金成功'
                    ];
                    break;
                    
                case 'coupon':
                    // 创建优惠券
                    // 这里简化处理，实际应调用优惠券服务
                    $couponCode = 'CP' . date('YmdHis') . $userId . rand(100, 999);
                    $couponId = $this->createCoupon($userId, $rule, $couponCode);
                    
                    $exchangeResult = [
                        'type' => 'coupon',
                        'coupon_id' => $couponId,
                        'coupon_code' => $couponCode,
                        'value' => $rule['exchange_value'],
                        'message' => '积分兑换优惠券成功'
                    ];
                    break;
                    
                case 'product':
                    // 产品兑换，记录兑换但实际发货需要其他流程
                    $exchangeResult = [
                        'type' => 'product',
                        'product_id' => $rule['related_id'],
                        'product_value' => $rule['exchange_value'],
                        'message' => '积分兑换商品成功，请等待发货'
                    ];
                    break;
                    
                default:
                    throw new Exception('不支持的兑换类型');
            }
            
            // 扣除积分
            $this->updateUserPoints($userId, -$rule['required_points'], 
                "积分兑换: " . $rule['name'], 'exchange', $ruleId);
            
            // 记录兑换记录
            $this->db->execute(
                "INSERT INTO point_exchanges 
                 (user_id, rule_id, exchange_type, exchange_value, points_cost, created_at) 
                 VALUES (?, ?, ?, ?, ?, NOW())", 
                [$userId, $ruleId, $rule['type'], $rule['exchange_value'], $rule['required_points']]
            );
            
            // 提交事务
            $this->db->commit();
            
            $this->logger->info("积分兑换成功", [
                'user_id' => $userId,
                'rule_id' => $ruleId,
                'points' => $rule['required_points'],
                'type' => $rule['type'],
                'value' => $rule['exchange_value']
            ]);
            
            return $exchangeResult;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollback();
            $this->logger->error("积分兑换失败: " . $e->getMessage(), [
                'user_id' => $userId,
                'rule_id' => $ruleId
            ]);
            throw $e;
        }
    }
    
    /**
     * 创建优惠券（简化版）
     * 实际应用中应调用专门的优惠券服务
     */
    private function createCoupon($userId, $rule, $couponCode) {
        // 这里简化处理，实际应调用优惠券服务或插入优惠券表
        $expireDate = date('Y-m-d', strtotime('+30 days'));
        
        $this->db->execute(
            "INSERT INTO coupons 
             (code, type, value, min_spend, user_id, status, expire_date, created_at) 
             VALUES (?, 'discount', ?, ?, ?, 'active', ?, NOW())", 
            [$couponCode, $rule['exchange_value'], $rule['min_spend'] ?? 0, $userId, $expireDate]
        );
        
        return $this->db->lastInsertId();
    }
    
    /**
     * 获取用户积分历史
     * @param int $userId 用户ID
     * @param int $limit 记录数量限制
     * @param int $offset 偏移量
     * @return array 积分历史列表
     */
    public function getUserPointsHistory($userId, $limit = 20, $offset = 0) {
        try {
            return $this->db->select(
                "SELECT * FROM point_transactions 
                 WHERE user_id = ? 
                 ORDER BY created_at DESC 
                 LIMIT ? OFFSET ?", 
                [$userId, $limit, $offset]
            );
        } catch (Exception $e) {
            $this->logger->error("获取用户积分历史失败: " . $e->getMessage(), ['user_id' => $userId]);
            return [];
        }
    }
    
    /**
     * 获取会员等级列表
     * @return array 会员等级列表
     */
    public function getMemberLevels() {
        try {
            return $this->db->select(
                "SELECT * FROM member_levels WHERE status = 'active' ORDER BY level ASC"
            );
        } catch (Exception $e) {
            $this->logger->error("获取会员等级列表失败: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取即将过期的积分
     * @param int $userId 用户ID
     * @param int $days 天数内过期
     * @return array 过期积分信息
     */
    public function getExpiringPoints($userId, $days = 30) {
        try {
            $expireDate = date('Y-m-d', strtotime("+{$days} days"));
            
            $result = $this->db->selectOne(
                "SELECT SUM(change_points) as expiring_points, 
                        MIN(expire_date) as earliest_expire_date 
                 FROM point_transactions 
                 WHERE user_id = ? AND expire_date <= ? AND expire_date >= DATE(NOW()) 
                 AND change_points > 0", 
                [$userId, $expireDate]
            );
            
            return [
                'expiring_points' => $result['expiring_points'] ?? 0,
                'earliest_expire_date' => $result['earliest_expire_date']
            ];
        } catch (Exception $e) {
            $this->logger->error("获取即将过期积分失败: " . $e->getMessage(), ['user_id' => $userId]);
            return ['expiring_points' => 0, 'earliest_expire_date' => null];
        }
    }
    
    /**
     * 获取距离下一等级所需积分
     * @param int $userId 用户ID
     * @return int 所需积分
     */
    public function getNextLevelRemainingPoints($userId) {
        $memberInfo = $this->getUserMemberInfo($userId);
        $currentPoints = $memberInfo['current_points'];
        $currentLevel = $memberInfo['level_value'] ?? 1;
        
        // 获取下一等级所需积分
        $sql = "SELECT min_points FROM member_levels 
                WHERE level > ? AND status = 'active' 
                ORDER BY level ASC LIMIT 1";
        $nextLevel = $this->db->selectOne($sql, [$currentLevel]);
        
        if (!$nextLevel) {
            return 0; // 已经是最高等级
        }
        
        $remainingPoints = $nextLevel['min_points'] - $currentPoints;
        return $remainingPoints > 0 ? $remainingPoints : 0;
    }
    
    /**
     * 发送等级变更通知
     * 这里简化处理，实际应调用通知服务
     */
    private function sendLevelChangeNotification($userId, $oldLevel, $newLevel) {
        // 这里可以实现发送短信、邮件或站内信等通知
        $this->logger->info("等级变更通知待发送", [
            'user_id' => $userId,
            'old_level' => $oldLevel,
            'new_level' => $newLevel
        ]);
    }
    
    /**
     * 清理过期积分
     * 通常作为定时任务调用
     */
    public function cleanupExpiredPoints() {
        try {
            $this->db->beginTransaction();
            
            // 获取过期积分记录
            $expiredPoints = $this->db->select(
                "SELECT user_id, SUM(change_points) as expired_points 
                 FROM point_transactions 
                 WHERE expire_date <= DATE(NOW()) AND type != 'expire' AND change_points > 0
                 GROUP BY user_id"
            );
            
            foreach ($expiredPoints as $expiredPoint) {
                // 更新用户积分
                $this->db->execute(
                    "UPDATE user_members SET current_points = current_points - ? 
                     WHERE user_id = ? AND current_points >= ?", 
                    [$expiredPoint['expired_points'], $expiredPoint['user_id'], $expiredPoint['expired_points']]
                );
                
                // 记录积分过期
                $this->db->execute(
                    "INSERT INTO point_transactions 
                     (user_id, type, change_points, balance_points, reason, created_at) 
                     VALUES (?, 'expire', ?, 
                             (SELECT current_points FROM user_members WHERE user_id = ?), 
                             '积分过期', NOW())", 
                    [$expiredPoint['user_id'], -$expiredPoint['expired_points'], $expiredPoint['user_id']]
                );
                
                // 检查并更新会员等级
                $memberInfo = $this->getUserMemberInfo($expiredPoint['user_id']);
                $this->checkAndUpdateMemberLevel($expiredPoint['user_id'], $memberInfo['current_points']);
            }
            
            $this->db->commit();
            
            $this->logger->info("清理过期积分完成", ['count' => count($expiredPoints)]);
            
            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error("清理过期积分失败: " . $e->getMessage());
            throw $e;
        }
    }
}