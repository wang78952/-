<?php

require_once __DIR__ . '/../compression/BrotliCompressor.php';

/**
 * HTTP响应压缩中间件
 * 自动检测客户端支持的压缩格式并应用相应压缩
 */
class ResponseCompression {
    /**
     * 中间件执行方法
     * @param Request $request 请求对象
     * @param Response $response 响应对象
     * @param callable $next 下一个中间件
     * @return Response 处理后的响应
     */
    public function handle($request, $response, $next) {
        // 先执行后续中间件获取响应
        $response = $next($request, $response);
        
        // 获取响应内容和类型
        $content = $response->getContent();
        $contentType = $response->getHeader('Content-Type') ?: 'text/html';
        
        // 检查是否需要压缩
        if ($this->shouldCompress($request, $content, $contentType)) {
            // 应用压缩
            $compressedContent = $this->compressContent($content, $contentType, $request);
            
            if ($compressedContent !== null) {
                // 更新响应内容和头信息
                $response->setContent($compressedContent);
                $response->setHeader('Content-Encoding', 'gzip');
                $response->setHeader('Content-Length', strlen($compressedContent));
                $response->setHeader('X-Content-Compressed', 'true');
                $response->setHeader('Vary', 'Accept-Encoding');
            }
        }
        
        return $response;
    }
    
    /**
     * 判断是否应该压缩内容
     * @param mixed $request 请求对象
     * @param string $content 响应内容
     * @param string $contentType 内容类型
     * @return bool 是否压缩
     */
    private function shouldCompress($request, $content, $contentType) {
        // 检查内容大小，小内容不值得压缩
        if (strlen($content) < 1024) {
            return false;
        }
        
        // 检查内容类型，二进制文件不需要压缩
        $excludedTypes = [
            'image/', 'video/', 'audio/', 'application/octet-stream',
            'application/zip', 'application/gzip', 'application/pdf'
        ];
        
        foreach ($excludedTypes as $type) {
            if (strpos($contentType, $type) !== false) {
                return false;
            }
        }
        
        // 检查客户端是否支持压缩
        $acceptEncoding = isset($_SERVER['HTTP_ACCEPT_ENCODING']) ? $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
        if (!($acceptEncoding && (strpos($acceptEncoding, 'gzip') !== false || strpos($acceptEncoding, 'br') !== false))) {
            return false;
        }
        
        // 检查是否已经压缩过
        $contentEncoding = isset($_SERVER['HTTP_CONTENT_ENCODING']) ? $_SERVER['HTTP_CONTENT_ENCODING'] : '';
        if ($contentEncoding && (strpos($contentEncoding, 'gzip') !== false || strpos($contentEncoding, 'br') !== false)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 压缩内容
     * @param string $content 原始内容
     * @param string $contentType 内容类型
     * @param mixed $request 请求对象
     * @return string|null 压缩后的内容
     */
    private function compressContent($content, $contentType, $request) {
        try {
            // 获取推荐的压缩配置
            $config = BrotliCompressor::getRecommendedConfig($contentType);
            
            if (!$config['enabled']) {
                return null;
            }
            
            // 执行压缩
            $compressed = BrotliCompressor::compress($content, $config['quality']);
            
            // 检查压缩是否有效减少了数据大小
            if ($compressed && strlen($compressed) < strlen($content)) {
                // 移除自定义头部标识
                if (strpos($compressed, 'GZIP_BACKUP:') === 0) {
                    $compressed = substr($compressed, 12);
                }
                return $compressed;
            }
            
            return null;
        } catch (Exception $e) {
            error_log("ResponseCompression: 压缩失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 静态调用方法，适用于简单应用场景
     * @param string $content 要压缩的内容
     * @param string $contentType 内容类型
     * @return string 压缩后的内容或原始内容
     */
    public static function compressOutput($content, $contentType = 'text/html') {
        $compressor = new self();
        $request = new stdClass(); // 简单的请求对象模拟
        
        // 检查是否应该压缩
        if ($compressor->shouldCompress($request, $content, $contentType)) {
            $compressed = $compressor->compressContent($content, $contentType, $request);
            if ($compressed) {
                // 设置压缩头
                header('Content-Encoding: gzip');
                header('Content-Length: ' . strlen($compressed));
                header('X-Content-Compressed: true');
                header('Vary: Accept-Encoding');
                return $compressed;
            }
        }
        
        return $content;
    }
}