<?php
/**
 * 短信服务类
 * 提供短信发送功能
 */

class SMSService {
    private $config = [];
    private $logger;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 初始化默认配置
        $this->config = [
            'api_key' => '',
            'api_secret' => '',
            'api_url' => 'https://api.example.com/sms/send',
            'signature' => '【发卡系统】',
            'timeout' => 10, // 请求超时时间（秒）
            'use_sandbox' => true // 默认使用沙箱模式
        ];
        
        // 尝试从配置文件加载短信配置
        if (file_exists(__DIR__ . '/../config.php')) {
            require_once __DIR__ . '/../config.php';
            if (defined('SMS_CONFIG') && is_array(SMS_CONFIG)) {
                $this->config = array_merge($this->config, SMS_CONFIG);
            }
        }
        
        // 如果Logger类可用，则使用它
        if (class_exists('Logger')) {
            $this->logger = new Logger();
        }
    }
    
    /**
     * 发送短信
     * 
     * @param string|array $phoneNumbers 手机号（单个或数组）
     * @param string $message 短信内容
     * @param array $options 附加选项
     * @return array 发送结果
     */
    public function sendSMS($phoneNumbers, $message, $options = []) {
        try {
            // 验证必要参数
            if (empty($phoneNumbers) || empty($message)) {
                throw new Exception('短信参数不完整');
            }
            
            // 添加短信签名
            if (isset($options['signature'])) {
                $signature = $options['signature'];
            } else {
                $signature = $this->config['signature'];
            }
            
            // 确保短信内容包含签名
            if (!strpos($message, $signature)) {
                $message = $signature . $message;
            }
            
            // 处理手机号（支持多个）
            $phones = is_array($phoneNumbers) ? $phoneNumbers : [$phoneNumbers];
            
            // 验证手机号格式
            foreach ($phones as $phone) {
                if (!preg_match('/^1[3-9]\d{9}$/', $phone)) {
                    throw new Exception("无效的手机号：$phone");
                }
            }
            
            // 如果是沙箱模式，返回模拟成功
            if ($this->config['use_sandbox']) {
                $this->log('沙箱模式：短信发送', ['phones' => $phones, 'message' => $message]);
                return [
                    'success' => true,
                    'message' => '短信发送成功（沙箱模式）',
                    'data' => [
                        'phones' => $phones,
                        'message' => $message,
                        'timestamp' => date('Y-m-d H:i:s')
                    ]
                ];
            }
            
            // 实际发送短信（这里是模拟实现）
            $result = $this->sendViaAPI($phones, $message, $options);
            
            return $result;
            
        } catch (Exception $e) {
            $errorMessage = $e->getMessage();
            $this->log('短信发送失败: ' . $errorMessage, ['phones' => $phoneNumbers, 'message' => $message], 'error');
            return ['success' => false, 'error' => $errorMessage];
        }
    }
    
    /**
     * 通过API发送短信（模拟实现）
     * 实际项目中应该调用真实的短信API服务
     */
    private function sendViaAPI($phoneNumbers, $message, $options = []) {
        $this->log('通过API发送短信', ['phones' => $phoneNumbers, 'message' => $message]);
        
        // 这里是模拟实现，实际项目中应根据短信服务商的API文档实现
        // 例如阿里云短信、腾讯云短信等
        
        // 模拟API调用成功
        return [
            'success' => true,
            'message' => '短信发送成功',
            'request_id' => 'req_' . time() . mt_rand(1000, 9999),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * 发送验证码短信
     * 
     * @param string $phoneNumber 手机号
     * @param string $code 验证码
     * @param int $expireMinutes 过期时间（分钟）
     * @return array 发送结果
     */
    public function sendVerificationCode($phoneNumber, $code, $expireMinutes = 5) {
        $message = "您的验证码是：{$code}，有效期{$expireMinutes}分钟，请勿泄露给他人。";
        return $this->sendSMS($phoneNumber, $message);
    }
    
    /**
     * 发送模板短信
     * 
     * @param string|array $phoneNumbers 手机号
     * @param string $templateId 模板ID
     * @param array $params 模板参数
     * @return array 发送结果
     */
    public function sendTemplateSMS($phoneNumbers, $templateId, $params = []) {
        try {
            // 这里是模拟实现，实际项目中应根据短信服务商的模板机制实现
            $this->log('发送模板短信', ['phones' => $phoneNumbers, 'templateId' => $templateId, 'params' => $params]);
            
            // 模拟模板内容
            $templateContent = "模板短信测试，模板ID：{$templateId}，参数：" . json_encode($params);
            
            return $this->sendSMS($phoneNumbers, $templateContent);
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 记录日志
     */
    private function log($message, $data = [], $level = 'info') {
        if ($this->logger && method_exists($this->logger, $level)) {
            $this->logger->$level($message, $data);
        } else {
            // 简单的错误日志记录
            $logData = json_encode(['message' => $message, 'data' => $data, 'level' => $level]);
            error_log($logData);
        }
    }
}