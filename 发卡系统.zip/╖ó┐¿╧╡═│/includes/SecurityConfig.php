<?php
/**
 * 商业级安全配置文件
 * 环境变量配置、安全设置、密钥管理
 */

// 环境检测
define('IS_PRODUCTION', getenv('APP_ENV') === 'production');
define('IS_DEVELOPMENT', getenv('APP_ENV') === 'development');
define('IS_TESTING', getenv('APP_ENV') === 'testing');

// 安全配置
define('ENFORCE_HTTPS', IS_PRODUCTION); // 生产环境强制HTTPS
define('SECURE_COOKIES', IS_PRODUCTION); // 生产安全Cookie
define('ENABLE_CSRF_PROTECTION', true); // CSRF保护
define('ENABLE_RATE_LIMITING', true);   // 速率限制

// 会话安全配置
define('SESSION_LIFETIME', 3600);        // 会话生命周期（秒）
define('SESSION_REGENERATE_ID', true);  // 会话ID重新生成
define('SESSION_STRICT_MODE', true);    // 严格会话模式
define('SESSION_SAME_SITE', 'Strict');  // SameSite属性

// 密码策略
define('PASSWORD_MIN_LENGTH', 12);
define('PASSWORD_REQUIRE_UPPERCASE', true);
define('PASSWORD_REQUIRE_LOWERCASE', true);
define('PASSWORD_REQUIRE_NUMBERS', true);
define('PASSWORD_REQUIRE_SYMBOLS', true);
define('PASSWORD_MAX_AGE_DAYS', 90);

// 登录安全
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_DURATION', 900); // 15分钟
define('REQUIRE_2FA', IS_PRODUCTION);   // 生产环境要求双因素认证

// 速率限制配置
define('RATE_LIMIT_REQUESTS_PER_MINUTE', 60);
define('RATE_LIMIT_REQUESTS_PER_HOUR', 1000);
define('RATE_LIMIT_LOGIN_ATTEMPTS_PER_HOUR', 10);

// 数据加密配置
define('ENCRYPTION_ALGORITHM', 'AES-256-GCM');
define('ENCRYPTION_KEY_ROTATION_DAYS', 30);

// 审计日志配置
define('AUDIT_LOG_RETENTION_DAYS', 2555); // 7年
define('ENABLE_DETAILED_LOGGING', IS_PRODUCTION);
define('LOG_SENSITIVE_OPERATIONS', true);

// 数据保护配置
define('DATA_MASKING_ENABLED', true);
define('PII_ENCRYPTION_ENABLED', true);
define('DATA_RETENTION_DAYS', 2555); // 7年GDPR合规

// 备份配置
define('BACKUP_ENCRYPTION_ENABLED', true);
define('BACKUP_RETENTION_DAYS', 90);
define('AUTO_BACKUP_ENABLED', true);

// 监控和告警
define('ENABLE_SECURITY_MONITORING', IS_PRODUCTION);
define('ALERT_EMAIL', getenv('ALERT_EMAIL') ?: 'admin@example.com');
define('ENABLE_PERFORMANCE_MONITORING', IS_PRODUCTION);

// API安全配置
define('API_RATE_LIMIT_PER_MINUTE', 100);
define('API_TOKEN_EXPIRY_HOURS', 24);
define('ENABLE_API_AUTHENTICATION', true);

// 文件上传安全
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_FILE_TYPES', array('jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'));
define('SCAN_UPLOADED_FILES', true);

// 数据库安全配置
define('DB_SSL_ENABLED', IS_PRODUCTION);
define('DB_CONNECTION_TIMEOUT', 30);
define('DB_QUERY_TIMEOUT', 60);

// 缓存安全
define('CACHE_ENCRYPTION_ENABLED', true);
define('CACHE_TTL_DEFAULT', 3600);

// 邮件安全
define('EMAIL_ENCRYPTION', 'TLS');
define('EMAIL_AUTH_REQUIRED', true);

// 合规配置
define('GDPR_COMPLIANCE_ENABLED', true);
define('CCPA_COMPLIANCE_ENABLED', true);
define('DATA_SUBJECT_REQUEST_ENABLED', true);

/**
 * 获取环境变量或默认值
 */
function env($key, $default = null) {
    $value = getenv($key);
    if ($value === false) {
        return $default;
    }
    return $value;
}

/**
 * 获取加密密钥
 */
function getEncryptionKey() {
    $key = env('ENCRYPTION_KEY');
    if (empty($key)) {
        throw new Exception('ENCRYPTION_KEY environment variable is required');
    }
    return $key;
}

/**
 * 获取数据库配置
 */
function getDatabaseConfig() {
    return array(
        'host' => env('DB_HOST', 'localhost'),
        'port' => env('DB_PORT', '3306'),
        'dbname' => env('DB_NAME', 'card_system'),
        'username' => env('DB_USER', 'root'),
        'password' => env('DB_PASS', ''),
        'charset' => 'utf8mb4',
        'ssl' => DB_SSL_ENABLED,
        'timeout' => DB_CONNECTION_TIMEOUT
    );
}

/**
 * 获取邮件配置
 */
function getMailConfig() {
    return array(
        'host' => env('MAIL_HOST', 'localhost'),
        'port' => env('MAIL_PORT', 587),
        'username' => env('MAIL_USERNAME'),
        'password' => env('MAIL_PASSWORD'),
        'encryption' => defined('EMAIL_ENCRYPTION') ? EMAIL_ENCRYPTION : 'tls',
        'from' => env('MAIL_FROM', 'noreply@example.com'),
        'from_name' => env('MAIL_FROM_NAME', APP_NAME)
    );
}

/**
 * 检查是否为安全环境
 */
function isSecureEnvironment() {
    return (IS_PRODUCTION || 
            (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
            ($_SERVER['SERVER_PORT'] == 443) ||
            (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https'));
}

/**
 * 验证必需的环境变量
 */
function validateRequiredEnvironment() {
    $required = array('ENCRYPTION_KEY');
    
    if (IS_PRODUCTION) {
        $required = array_merge($required, array(
            'DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME',
            'MAIL_HOST', 'MAIL_USERNAME', 'MAIL_PASSWORD',
            'ALERT_EMAIL'
        ));
    }
    
    $missing = array();
    foreach ($required as $var) {
        if (empty(env($var))) {
            $missing[] = $var;
        }
    }
    
    if (!empty($missing)) {
        throw new Exception("Missing required environment variables: " . implode(', ', $missing));
    }
}

// 验证环境配置
if (IS_PRODUCTION) {
    validateRequiredEnvironment();
    
    // 生产环境安全检查
    if (!isSecureEnvironment()) {
        throw new Exception('Production environment must use HTTPS');
    }
}

/**
 * 安全头部配置
 */
function getSecurityHeaders() {
    return array(
        'X-Content-Type-Options' => 'nosniff',
        'X-Frame-Options' => 'DENY',
        'X-XSS-Protection' => '1; mode=block',
        'Strict-Transport-Security' => 'max-age=31536000; includeSubDomains; preload',
        'Content-Security-Policy' => "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'; frame-ancestors 'none';",
        'Referrer-Policy' => 'strict-origin-when-cross-origin',
        'Permissions-Policy' => 'geolocation=(), microphone=(), camera=(), payment=(), usb=(), magnetometer=(), gyroscope=()'
    );
}

/**
 * 应用安全头部
 */
function applySecurityHeaders() {
    if (headers_sent()) {
        return;
    }
    
    $headers = getSecurityHeaders();
    foreach ($headers as $name => $value) {
        header("{$name}: {$value}");
    }
}

// 自动应用安全头部
if (ENFORCE_HTTPS && !isSecureEnvironment()) {
    $redirectUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("Location: {$redirectUrl}", true, 301);
    exit;
}

applySecurityHeaders();
?>