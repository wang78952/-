<?php
/**
 * 数据备份管理器
 * 实现数据库备份、恢复、验证和调度功能
 */

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/ErrorHandler.php';
require_once __DIR__ . '/SecurityUtils.php';

class BackupManager {
    private static $instance = null;
    private $database;
    private $backupDir;
    private $maxBackups = 10; // 最大保留备份数量
    private $compressionLevel = 6; // 压缩级别
    
    // 远程备份配置
    private $remoteConfig = array();
    
    // 可用的远程存储类型
    const REMOTE_STORAGE_FTP = 'ftp';
    const REMOTE_STORAGE_SFTP = 'sftp';
    const REMOTE_STORAGE_AWS_S3 = 'aws_s3';
    const REMOTE_STORAGE_ALIYUN_OSS = 'aliyun_oss';
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        global $config;
        
        // 初始化备份目录
        $this->backupDir = isset($config['backup_dir']) ? $config['backup_dir'] : __DIR__ . '/../backups';
        
        // 确保备份目录存在
        $this->ensureBackupDirectory();
        
        // 获取数据库连接
        $this->database = Database::getInstance();
        
        // 初始化远程备份配置
        $this->initRemoteConfig();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化远程备份配置
     */
    private function initRemoteConfig() {
        global $config;
        
        // 从配置中加载远程备份设置
        if (isset($config['remote_backup']) && is_array($config['remote_backup'])) {
            $this->remoteConfig = $config['remote_backup'];
        }
        
        // 或者从数据库加载配置
        try {
            $sql = "SELECT * FROM system_config WHERE category = 'remote_backup'";
            $stmt = $this->database->query($sql);
            $configs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($configs as $item) {
                $this->remoteConfig[$item['key']] = json_decode($item['value'], true);
            }
        } catch (Exception $e) {
            // 如果表不存在或其他错误，忽略
            error_log("加载远程备份配置失败: " . $e->getMessage());
        }
    }
    
    /**
     * 确保备份目录存在
     */
    private function ensureBackupDirectory() {
        if (!file_exists($this->backupDir)) {
            if (!mkdir($this->backupDir, 0755, true)) {
                throw new Exception("无法创建备份目录: " . $this->backupDir);
            }
        }
        
        // 创建子目录
        $subdirs = array('database', 'files', 'logs');
        foreach ($subdirs as $subdir) {
            $path = $this->backupDir . '/' . $subdir;
            if (!file_exists($path)) {
                mkdir($path, 0755, true);
            }
        }
    }
    
    /**
     * 创建数据库备份
     */
    public function createDatabaseBackup($description = '', $incremental = false, $baseBackupTime = null, $syncToRemote = true) {
        try {
            $timestamp = date('Y-m-d_H-i-s');
            $backupType = $incremental ? "incremental" : "full";
            $filename = "database_{$backupType}_{$timestamp}.sql";
            $filepath = $this->backupDir . '/database/' . $filename;
            
            // 获取所有表
            $tables = $this->getAllTables();
            
            $sql = "-- 发卡系统数据库备份\n";
            $sql .= "-- 备份时间: " . date('Y-m-d H:i:s') . "\n";
            $sql .= "-- 描述: " . $description . "\n";
            $sql .= "-- 备份类型: " . ($incremental ? "增量备份" : "完整备份") . "\n";
            if ($incremental && $baseBackupTime) {
                $sql .= "-- 基于时间点: " . $baseBackupTime . "\n";
            }
            $sql .= "-- MySQL版本: " . $this->getMySQLVersion() . "\n\n";
            
            // 设置字符集
            $sql .= "SET NAMES utf8mb4;\n";
            $sql .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";
            
            foreach ($tables as $table) {
                // 增量备份只导出结构（如果需要）和变更的数据
                if ($incremental) {
                    // 检查是否有支持增量备份的表（有主键和更新时间戳的表）
                    if ($this->tableSupportsIncremental($table)) {
                        $sql .= $this->getIncrementalTableData($table, $baseBackupTime);
                    } else {
                        // 不支持增量备份的表导出完整数据
                        $sql .= "-- 表 {$table} 不支持增量备份，导出完整数据\n";
                        $sql .= $this->getTableData($table);
                    }
                } else {
                    // 完整备份导出结构和数据
                    $sql .= $this->getTableStructure($table);
                    $sql .= $this->getTableData($table);
                }
                $sql .= "\n";
            }
            
            $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            
            // 写入文件
            if (file_put_contents($filepath, $sql) === false) {
                throw new Exception("无法写入备份文件: " . $filepath);
            }
            
            // 压缩文件
            $compressedFile = $this->compressFile($filepath);
            
            // 如果启用了远程备份同步，将备份上传到远程存储
            $remoteStatus = array();
            if ($syncToRemote) {
                // 生成远程文件路径，使用日期作为目录结构
                $dateDir = date('Y/m/d');
                $remoteRelativePath = "backups/{$dateDir}/" . basename($compressedFile);
                
                // 上传到所有配置的远程存储
                $remoteStatus = $this->syncToAllRemotes($compressedFile, $remoteRelativePath);
            }
            
            // 记录备份信息
            $this->recordBackup($filename, $description, 'database', filesize($compressedFile), $incremental, $baseBackupTime, $remoteStatus);
            
            // 清理旧备份
            $this->cleanupOldBackups('database');
            
            // 记录日志
            $errorHandler = ErrorHandler::getInstance();
            $errorHandler->logInfo("数据库备份创建成功", array(
                'filename' => basename($compressedFile),
                'size' => $this->formatFileSize(filesize($compressedFile)),
                'tables' => count($tables)
            ));
            
            return array(
                'success' => true,
                'filename' => basename($compressedFile),
                'filepath' => $compressedFile,
                'size' => $this->formatFileSize(filesize($compressedFile)),
                'tables' => count($tables),
                'remote_status' => $remoteStatus
            );
            
        } catch (Exception $e) {
            $errorHandler = ErrorHandler::getInstance();
            $errorHandler->logError("数据库备份失败", ErrorLevel::ERROR, array(
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ));
            
            return array(
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    
    /**
     * 获取所有表名
     */
    private function getAllTables() {
        $stmt = $this->database->query("SHOW TABLES");
        $tables = array();
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }
        return $tables;
    }
    
    /**
     * 获取表结构
     */
    private function getTableStructure($table) {
        $sql = "-- 表结构: {$table}\n";
        $sql .= "DROP TABLE IF EXISTS `{$table}`;\n";
        
        $stmt = $this->database->query("SHOW CREATE TABLE `{$table}`");
        $row = $stmt->fetch();
        $sql .= $row['Create Table'] . ";\n\n";
        
        return $sql;
    }
    
    /**
     * 获取表数据
     */
    private function getTableData($table) {
        $sql = "-- 表数据: {$table}\n";
        
        $stmt = $this->database->query("SELECT * FROM `{$table}`");
        $rows = $stmt->fetchAll();
        
        if (empty($rows)) {
            return $sql . "-- 表为空\n\n";
        }
        
        $columns = array_keys($rows[0]);
        $columnList = '`' . implode('`, `', $columns) . '`';
        
        foreach ($rows as $row) {
            $values = array();
            foreach ($row as $value) {
                if ($value === null) {
                    $values[] = 'NULL';
                } else {
                    $values[] = "'" . addslashes($value) . "'";
                }
            }
            $sql .= "INSERT INTO `{$table}` ({$columnList}) VALUES (" . implode(', ', $values) . ");\n";
        }
        
        return $sql . "\n";
    }
    
    /**
     * 压缩文件
     */
    private function compressFile($filepath) {
        $compressedFile = $filepath . '.gz';
        
        $source = fopen($filepath, 'rb');
        $dest = fopen($compressedFile, 'wb');
        
        if (!$source || !$dest) {
            throw new Exception("无法打开文件进行压缩");
        }
        
        // 使用gzcompress进行压缩
        $data = fread($source, filesize($filepath));
        $compressed = gzencode($data, $this->compressionLevel);
        fwrite($dest, $compressed);
        
        fclose($source);
        fclose($dest);
        
        // 删除原文件
        unlink($filepath);
        
        return $compressedFile;
    }
    
    /**
     * 解压文件
     */
    private function decompressFile($compressedFile) {
        $source = fopen($compressedFile, 'rb');
        $data = fread($source, filesize($compressedFile));
        fclose($source);
        
        $decompressed = gzdecode($data);
        
        $tempFile = tempnam(sys_get_temp_dir(), 'backup_restore_');
        file_put_contents($tempFile, $decompressed);
        
        return $tempFile;
    }
    
    /**
     * 恢复数据库备份（支持一键恢复功能）
     * 
     * @param string $filename 备份文件名
     * @param bool $fromRemote 是否从远程存储恢复
     * @param string $remoteType 远程存储类型
     * @return array 恢复结果
     */
    public function restoreDatabaseBackup($filename, $fromRemote = false, $remoteType = null) {
        $restoreInfo = array(
            'success' => false,
            'statements_executed' => 0,
            'total_statements' => 0,
            'error' => null,
            'steps' => array(),
            'time_started' => date('Y-m-d H:i:s'),
            'time_completed' => null,
            'from_remote' => $fromRemote,
            'remote_type' => $remoteType
        );
        
        try {
            $restoreInfo['steps'][] = array('step' => '准备恢复', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            $filepath = $this->backupDir . '/database/' . $filename;
            
            // 如果从远程存储恢复，先下载文件
            if ($fromRemote) {
                $restoreInfo['steps'][] = array('step' => '远程恢复', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
                
                if (empty($remoteType)) {
                    throw new Exception("从远程恢复时必须指定远程存储类型");
                }
                
                // 确保本地目录存在
                if (!is_dir($this->backupDir . '/database')) {
                    mkdir($this->backupDir . '/database', 0755, true);
                }
                
                // 从远程存储下载文件
                $downloadResult = $this->downloadFromRemote($filename, $filepath, $remoteType);
                
                if (!$downloadResult['success']) {
                    throw new Exception("从远程存储下载失败: " . ($downloadResult['error'] ?? '未知错误'));
                }
                
                $restoreInfo['steps'][] = array('step' => '远程恢复', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            }
            
            // 检查文件是否存在
            if (!file_exists($filepath)) {
                throw new Exception("备份文件不存在: " . $filename);
            }
            
            $restoreInfo['steps'][] = array('step' => '验证备份', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            // 验证备份文件
            $verifyResult = $this->verifyBackup($filename);
            if (!$verifyResult['success']) {
                throw new Exception("备份文件验证失败: " . ($verifyResult['error'] ?? '未知错误'));
            }
            
            $restoreInfo['steps'][] = array('step' => '验证备份', 'status' => '通过', 'time' => date('Y-m-d H:i:s'));
            $restoreInfo['steps'][] = array('step' => '解压文件', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            // 解压文件
            $tempFile = $this->decompressFile($filepath);
            
            $restoreInfo['steps'][] = array('step' => '解压文件', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            $restoreInfo['steps'][] = array('step' => '读取SQL', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            // 读取SQL内容
            $sql = file_get_contents($tempFile);
            
            $restoreInfo['steps'][] = array('step' => '读取SQL', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            $restoreInfo['steps'][] = array('step' => '分割语句', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            // 分割SQL语句
            $statements = $this->splitSQLStatements($sql);
            $restoreInfo['total_statements'] = count($statements);
            
            $restoreInfo['steps'][] = array('step' => '分割语句', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            $restoreInfo['steps'][] = array('step' => '事务处理', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            // 开始事务
            $this->database->beginTransaction();
            
            $restoreInfo['steps'][] = array('step' => '执行SQL', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            $executedCount = 0;
            $totalStatements = count($statements);
            $statementBatchSize = 100; // 每执行100条语句记录一次进度
            
            foreach ($statements as $i => $statement) {
                $statement = trim($statement);
                if ($statement && !preg_match('/^--/', $statement)) {
                    $this->database->query($statement);
                    $executedCount++;
                    
                    // 记录批量进度
                    if ($executedCount % $statementBatchSize === 0 || $executedCount === $totalStatements) {
                        $percent = round(($executedCount / $totalStatements) * 100);
                        $restoreInfo['steps'][] = array(
                            'step' => '执行SQL', 
                            'status' => "进行中 {$percent}%", 
                            'time' => date('Y-m-d H:i:s'),
                            'details' => "已执行 {$executedCount}/{$totalStatements} 条语句"
                        );
                    }
                }
            }
            
            $restoreInfo['steps'][] = array('step' => '执行SQL', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            $restoreInfo['steps'][] = array('step' => '提交事务', 'status' => '开始', 'time' => date('Y-m-d H:i:s'));
            
            // 提交事务
            $this->database->commit();
            
            $restoreInfo['steps'][] = array('step' => '提交事务', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            
            // 清理临时文件
            unlink($tempFile);
            
            $restoreInfo['steps'][] = array('step' => '清理资源', 'status' => '完成', 'time' => date('Y-m-d H:i:s'));
            
            // 更新恢复信息
            $restoreInfo['success'] = true;
            $restoreInfo['statements_executed'] = $executedCount;
            $restoreInfo['time_completed'] = date('Y-m-d H:i:s');
            
            // 记录恢复日志
            $errorHandler = ErrorHandler::getInstance();
            $errorHandler->logInfo("数据库恢复成功", array(
                'filename' => $filename,
                'statements_executed' => $executedCount,
                'from_remote' => $fromRemote,
                'remote_type' => $remoteType
            ));
            
            $restoreInfo['steps'][] = array('step' => '恢复完成', 'status' => '成功', 'time' => date('Y-m-d H:i:s'));
            
        } catch (Exception $e) {
            // 回滚事务
            if ($this->database->inTransaction()) {
                $this->database->rollback();
                $restoreInfo['steps'][] = array('step' => '事务处理', 'status' => '回滚', 'time' => date('Y-m-d H:i:s'));
            }
            
            $restoreInfo['error'] = $e->getMessage();
            $restoreInfo['time_completed'] = date('Y-m-d H:i:s');
            
            // 记录错误日志
            $errorHandler = ErrorHandler::getInstance();
            $errorHandler->logError("数据库恢复失败", ErrorLevel::CRITICAL, array(
                'filename' => $filename,
                'error' => $e->getMessage(),
                'from_remote' => $fromRemote,
                'remote_type' => $remoteType
            ));
            
            $restoreInfo['steps'][] = array('step' => '恢复失败', 'status' => '错误', 'time' => date('Y-m-d H:i:s'), 'details' => $e->getMessage());
        }
        
        return $restoreInfo;
    }
    
    /**
     * 分割SQL语句
     */
    private function splitSQLStatements($sql) {
        $statements = array();
        $current = '';
        $delimiter = ';';
        
        $tokens = token_get_all('<?php ' . $sql);
        array_shift($tokens); // 移除开始的php标签
        
        foreach ($tokens as $token) {
            if (is_array($token)) {
                $current .= $token[1];
            } else {
                $current .= $token;
            }
            
            if ($token === $delimiter) {
                $statements[] = $current;
                $current = '';
            }
        }
        
        if (!empty($current)) {
            $statements[] = $current;
        }
        
        return $statements;
    }
    
    /**
     * 验证备份文件完整性
     */
    public function verifyBackup($filename) {
        try {
            $filepath = $this->backupDir . '/database/' . $filename;
            
            if (!file_exists($filepath)) {
                throw new Exception("备份文件不存在");
            }
            
            // 检查文件大小
            $filesize = filesize($filepath);
            if ($filesize === 0) {
                throw new Exception("备份文件为空");
            }
            
            // 解压并检查内容
            $tempFile = $this->decompressFile($filepath);
            $content = file_get_contents($tempFile);
            unlink($tempFile);
            
            // 基本检查
            if (strpos($content, '发卡系统数据库备份') === false) {
                throw new Exception("不是有效的发卡系统备份文件");
            }
            
            // 检查SQL语法
            $statements = $this->splitSQLStatements($content);
            $validStatements = 0;
            
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if (!empty($statement) && !preg_match('/^--/', $statement)) {
                    // 简单的语法检查
                    if (preg_match('/^(CREATE|INSERT|DROP|SET|ALTER|TRUNCATE)/i', $statement)) {
                        $validStatements++;
                    }
                }
            }
            
            if ($validStatements === 0) {
                throw new Exception("备份文件中没有有效的SQL语句");
            }
            
            return array(
                'success' => true,
                'filesize' => $this->formatFileSize($filesize),
                'statements_count' => count($statements),
                'valid_statements' => $validStatements,
                'created_time' => date('Y-m-d H:i:s', filemtime($filepath))
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    
    /**
     * 获取备份列表
     */
    public function getBackupList($type = 'database') {
        $backupDir = $this->backupDir . '/' . $type;
        $backups = array();
        
        if (is_dir($backupDir)) {
            $files = scandir($backupDir);
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..') {
                    $filepath = $backupDir . '/' . $file;
                    $backups[] = array(
                        'filename' => $file,
                        'size' => $this->formatFileSize(filesize($filepath)),
                        'created_time' => date('Y-m-d H:i:s', filemtime($filepath)),
                        'type' => $type
                    );
                }
            }
        }
        
        // 按创建时间倒序排列
        usort($backups, function($a, $b) {
            return strtotime($b['created_time']) - strtotime($a['created_time']);
        });
        
        return $backups;
    }
    
    /**
     * 删除备份
     */
    public function deleteBackup($filename, $type = 'database') {
        $filepath = $this->backupDir . '/' . $type . '/' . $filename;
        
        if (file_exists($filepath)) {
            if (unlink($filepath)) {
                $errorHandler = ErrorHandler::getInstance();
                $errorHandler->logInfo("备份文件已删除", array(
                    'filename' => $filename,
                    'type' => $type
                ));
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 清理旧备份
     */
    private function cleanupOldBackups($type) {
        $backups = $this->getBackupList($type);
        
        if (count($backups) > $this->maxBackups) {
            $toDelete = array_slice($backups, $this->maxBackups);
            foreach ($toDelete as $backup) {
                $this->deleteBackup($backup['filename'], $type);
            }
        }
    }
    
    /**
     * 记录备份信息到数据库
     */
    private function recordBackup($filename, $description, $type, $size, $incremental = false, $baseBackupTime = null, $remote_status = array()) {
        try {
            // 将远程状态序列化为JSON
            $remote_status_json = json_encode($remote_status);
            
            $sql = "INSERT INTO backup_logs (filename, description, type, size, created_at, is_incremental, base_backup_time, remote_status) 
                    VALUES (?, ?, ?, ?, NOW(), ?, ?, ?)";
            $this->database->query($sql, array($filename, $description, $type, $size, $incremental ? 1 : 0, $baseBackupTime, $remote_status_json));
        } catch (Exception $e) {
            // 如果表不存在，创建表
            $this->createBackupLogsTable();
            $this->recordBackup($filename, $description, $type, $size);
        }
    }
    
    /**
     * 创建备份日志表
     */
    private function createBackupLogsTable() {
        $sql = "CREATE TABLE IF NOT EXISTS backup_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            filename VARCHAR(255) NOT NULL,
            description TEXT,
            type ENUM('database', 'files', 'logs') NOT NULL,
            size BIGINT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_incremental TINYINT DEFAULT 0,
            base_backup_time DATETIME DEFAULT NULL,
            remote_status TEXT DEFAULT NULL,
            INDEX idx_type_created (type, created_at),
            INDEX idx_incremental (is_incremental)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        $this->database->query($sql);
    }
    
    /**
     * 获取MySQL版本
     */
    private function getMySQLVersion() {
        $stmt = $this->database->query("SELECT VERSION() as version");
        $row = $stmt->fetch(PDO::FETCH_NUM);
        return $row[0];
    }
    
    /**
     * 格式化文件大小
     */
    private function formatFileSize($bytes) {
        $units = array('B', 'KB', 'MB', 'GB');
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
    
    /**
     * 设置最大备份数量
     */
    public function setMaxBackups($max) {
        $this->maxBackups = max(1, (int)$max);
    }
    
    /**
     * 设置压缩级别
     */
    public function setCompressionLevel($level) {
        $this->compressionLevel = max(1, min(9, (int)$level));
    }
    
    /**
     * 检查表是否支持增量备份（有主键和更新时间戳字段）
     */
    private function tableSupportsIncremental($table) {
        try {
            $sql = "SHOW COLUMNS FROM `{$table}`";
            $stmt = $this->database->query($sql);
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $hasPrimaryKey = false;
            $hasTimestamp = false;
            
            foreach ($columns as $column) {
                if ($column['Key'] == 'PRI') {
                    $hasPrimaryKey = true;
                }
                // 检查是否有常见的时间戳字段
                $timestampColumns = ['updated_at', 'update_time', 'last_modified', 'modify_time'];
                if (in_array(strtolower($column['Field']), $timestampColumns)) {
                    $hasTimestamp = true;
                }
            }
            
            return $hasPrimaryKey && $hasTimestamp;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 获取表的增量数据（基于时间戳）
     */
    private function getIncrementalTableData($table, $sinceTime) {
        try {
            $sql = "SHOW COLUMNS FROM `{$table}`";
            $stmt = $this->database->query($sql);
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 查找时间戳字段
            $timestampField = null;
            $timestampColumns = ['updated_at', 'update_time', 'last_modified', 'modify_time'];
            
            foreach ($columns as $column) {
                if (in_array(strtolower($column['Field']), $timestampColumns)) {
                    $timestampField = $column['Field'];
                    break;
                }
            }
            
            if (!$timestampField) {
                return "-- 无法找到时间戳字段，跳过增量备份\n";
            }
            
            $result = "-- 表 {$table} 的增量数据（自 {$sinceTime} 起）\n";
            
            // 获取增量数据
            $query = "SELECT * FROM `{$table}` WHERE `{$timestampField}` >= ?";
            $stmt = $this->database->query($query, [$sinceTime]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($rows)) {
                return $result . "-- 没有增量数据\n";
            }
            
            // 生成INSERT/UPDATE语句
            foreach ($rows as $row) {
                $columnsStr = '`' . implode('`, `', array_keys($row)) . '`';
                $values = array();
                foreach ($row as $value) {
                    if ($value === null) {
                        $values[] = 'NULL';
                    } else {
                        $values[] = $this->database->quote($value);
                    }
                }
                $valuesStr = implode(', ', $values);
                
                // 使用INSERT ... ON DUPLICATE KEY UPDATE 以支持更新
                $result .= "INSERT INTO `{$table}` ({$columnsStr}) VALUES ({$valuesStr}) ";
                $result .= "ON DUPLICATE KEY UPDATE ";
                
                $updates = array();
                foreach (array_keys($row) as $col) {
                    if (!in_array($col, $timestampColumns)) { // 不更新时间戳字段
                        $updates[] = "`{$col}` = VALUES(`{$col}`)";
                    }
                }
                $result .= implode(', ', $updates) . ";\n";
            }
            
            return $result;
        } catch (Exception $e) {
            return "-- 增量备份 {$table} 失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 获取最近的完整备份时间
     */
    public function getLastFullBackupTime() {
        try {
            $sql = "SELECT MAX(created_at) as last_full_backup 
                    FROM backup_logs 
                    WHERE type = 'database' AND is_incremental = 0";
            $stmt = $this->database->query($sql);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['last_full_backup'] ? $result['last_full_backup'] : null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * 创建增量备份
     */
    public function createIncrementalBackup($description = '增量数据库备份', $syncToRemote = true) {
        $lastFullBackup = $this->getLastFullBackupTime();
        
        if (!$lastFullBackup) {
            return array(
                'success' => false,
                'error' => '找不到最近的完整备份，无法创建增量备份'
            );
        }
        
        return $this->createDatabaseBackup($description, true, $lastFullBackup, $syncToRemote);
    }
    
    /**
     * 从远程存储下载备份文件
     * 
     * @param string $filename 备份文件名
     * @param string $localFilePath 本地保存路径
     * @param string $storageType 远程存储类型
     * @return array 下载结果
     */
    public function downloadFromRemote($filename, $localFilePath, $storageType) {
        $downloadStatus = array(
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s'),
            'type' => $storageType
        );
        
        try {
            // 根据当前日期构建远程路径（与上传时保持一致）
            $dateDir = date('Y/m/d');
            $remoteFilePath = "database/{$dateDir}/{$filename}";
            
            // 根据存储类型选择下载方法
            switch ($storageType) {
                case self::REMOTE_STORAGE_FTP:
                    $downloadStatus = $this->downloadFromFTP($remoteFilePath, $localFilePath);
                    break;
                case self::REMOTE_STORAGE_SFTP:
                    $downloadStatus = $this->downloadFromSFTP($remoteFilePath, $localFilePath);
                    break;
                case self::REMOTE_STORAGE_AWS_S3:
                    $downloadStatus = $this->downloadFromS3($remoteFilePath, $localFilePath);
                    break;
                case self::REMOTE_STORAGE_ALIYUN_OSS:
                    $downloadStatus = $this->downloadFromAliyunOSS($remoteFilePath, $localFilePath);
                    break;
                default:
                    throw new Exception("不支持的远程存储类型: $storageType");
            }
        } catch (Exception $e) {
            $downloadStatus['error'] = $e->getMessage();
            error_log("远程备份下载失败: " . $e->getMessage());
        }
        
        return $downloadStatus;
    }
    
    /**
     * 从FTP下载文件
     */
    private function downloadFromFTP($remoteFilePath, $localFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_FTP,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['ftp']) || !is_array($this->remoteConfig['ftp'])) {
            $status['error'] = 'FTP配置未设置';
            return $status;
        }
        
        $ftpConfig = $this->remoteConfig['ftp'];
        
        try {
            // 连接FTP服务器
            $connId = ftp_connect($ftpConfig['host'], isset($ftpConfig['port']) ? $ftpConfig['port'] : 21);
            if (!$connId) {
                throw new Exception("无法连接到FTP服务器: " . $ftpConfig['host']);
            }
            
            // 登录FTP服务器
            $loginResult = ftp_login($connId, $ftpConfig['username'], $ftpConfig['password']);
            if (!$loginResult) {
                ftp_close($connId);
                throw new Exception("FTP登录失败");
            }
            
            // 设置被动模式
            if (isset($ftpConfig['passive']) && $ftpConfig['passive']) {
                ftp_pasv($connId, true);
            }
            
            // 下载文件
            $downloaded = ftp_get($connId, $localFilePath, $remoteFilePath, FTP_BINARY);
            
            if (!$downloaded) {
                ftp_close($connId);
                throw new Exception("文件下载失败");
            }
            
            // 关闭连接
            ftp_close($connId);
            
            $status['success'] = true;
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 从SFTP下载文件
     */
    private function downloadFromSFTP($remoteFilePath, $localFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_SFTP,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['sftp']) || !is_array($this->remoteConfig['sftp'])) {
            $status['error'] = 'SFTP配置未设置';
            return $status;
        }
        
        $sftpConfig = $this->remoteConfig['sftp'];
        
        try {
            // 这里需要使用SSH2扩展，确保已安装
            if (!function_exists('ssh2_connect')) {
                throw new Exception("PHP SSH2扩展未安装");
            }
            
            // 连接SSH服务器
            $connection = ssh2_connect($sftpConfig['host'], isset($sftpConfig['port']) ? $sftpConfig['port'] : 22);
            if (!$connection) {
                throw new Exception("无法连接到SFTP服务器: " . $sftpConfig['host']);
            }
            
            // 根据认证方式登录
            if (isset($sftpConfig['auth_method']) && $sftpConfig['auth_method'] === 'key') {
                // 使用密钥认证
                if (!isset($sftpConfig['private_key']) || !file_exists($sftpConfig['private_key'])) {
                    throw new Exception("私钥文件不存在或未配置");
                }
                
                $authResult = ssh2_auth_pubkey_file(
                    $connection,
                    $sftpConfig['username'],
                    $sftpConfig['public_key'] ?? ($sftpConfig['private_key'] . '.pub'),
                    $sftpConfig['private_key'],
                    $sftpConfig['passphrase'] ?? ''
                );
            } else {
                // 使用密码认证
                $authResult = ssh2_auth_password($connection, $sftpConfig['username'], $sftpConfig['password']);
            }
            
            if (!$authResult) {
                throw new Exception("SFTP认证失败");
            }
            
            // 初始化SFTP
            $sftp = ssh2_sftp($connection);
            if (!$sftp) {
                throw new Exception("SFTP初始化失败");
            }
            
            // 下载文件
            $remoteStream = fopen("ssh2.sftp://{$sftp}/{$remoteFilePath}", 'r');
            if (!$remoteStream) {
                throw new Exception("无法打开远程文件: {$remoteFilePath}");
            }
            
            $localStream = fopen($localFilePath, 'w');
            if (!$localStream) {
                fclose($remoteStream);
                throw new Exception("无法创建本地文件: {$localFilePath}");
            }
            
            // 传输数据
            $data = stream_copy_to_stream($remoteStream, $localStream);
            
            // 关闭流
            fclose($remoteStream);
            fclose($localStream);
            
            if ($data === false) {
                throw new Exception("文件传输失败");
            }
            
            $status['success'] = true;
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 从AWS S3下载文件
     */
    private function downloadFromS3($remoteFilePath, $localFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_AWS_S3,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['aws_s3']) || !is_array($this->remoteConfig['aws_s3'])) {
            $status['error'] = 'AWS S3配置未设置';
            return $status;
        }
        
        $s3Config = $this->remoteConfig['aws_s3'];
        
        try {
            // 这里可以使用AWS SDK或简单的HTTP请求
            // 为了简化，我们使用cURL
            $url = "https://{$s3Config['bucket']}.s3.{$s3Config['region']}.amazonaws.com/{$remoteFilePath}";
            
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            
            // 添加AWS认证头
            $date = gmdate('D, d M Y H:i:s T');
            $stringToSign = "GET\n\n\n{$date}\n/{$s3Config['bucket']}/{$remoteFilePath}";
            $signature = base64_encode(hash_hmac('sha1', $stringToSign, $s3Config['secret_key'], true));
            $authHeader = "AWS {$s3Config['access_key']}:{$signature}";
            
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Date: {$date}",
                "Authorization: {$authHeader}"
            ));
            
            $response = curl_exec($curl);
            $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            
            curl_close($curl);
            
            if ($httpCode !== 200) {
                throw new Exception("S3下载失败，HTTP状态码: {$httpCode}");
            }
            
            // 保存文件
            file_put_contents($localFilePath, $response);
            
            $status['success'] = true;
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 从阿里云OSS下载文件
     */
    private function downloadFromAliyunOSS($remoteFilePath, $localFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_ALIYUN_OSS,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['aliyun_oss']) || !is_array($this->remoteConfig['aliyun_oss'])) {
            $status['error'] = '阿里云OSS配置未设置';
            return $status;
        }
        
        $ossConfig = $this->remoteConfig['aliyun_oss'];
        
        try {
            // 使用cURL下载
            $url = "https://{$ossConfig['bucket']}.{$ossConfig['endpoint']}/{$remoteFilePath}";
            
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            
            // 添加OSS认证头
            $date = gmdate('D, d M Y H:i:s T');
            $stringToSign = "GET\n\n\n{$date}\n/{$ossConfig['bucket']}/{$remoteFilePath}";
            $signature = base64_encode(hash_hmac('sha1', $stringToSign, $ossConfig['access_key_secret'], true));
            $authHeader = "OSS {$ossConfig['access_key_id']}:{$signature}";
            
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Date: {$date}",
                "Authorization: {$authHeader}"
            ));
            
            $response = curl_exec($curl);
            $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            
            curl_close($curl);
            
            if ($httpCode !== 200) {
                throw new Exception("OSS下载失败，HTTP状态码: {$httpCode}");
            }
            
            // 保存文件
            file_put_contents($localFilePath, $response);
            
            $status['success'] = true;
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 上传备份到远程存储
     */
    public function uploadToRemote($localFilePath, $remoteFilePath, $storageType) {
        $remoteStatus = array(
            'type' => $storageType,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        try {
            // 根据存储类型选择上传方法
            switch ($storageType) {
                case self::REMOTE_STORAGE_FTP:
                    $remoteStatus = $this->uploadToFTP($localFilePath, $remoteFilePath);
                    break;
                case self::REMOTE_STORAGE_SFTP:
                    $remoteStatus = $this->uploadToSFTP($localFilePath, $remoteFilePath);
                    break;
                case self::REMOTE_STORAGE_AWS_S3:
                    $remoteStatus = $this->uploadToS3($localFilePath, $remoteFilePath);
                    break;
                case self::REMOTE_STORAGE_ALIYUN_OSS:
                    $remoteStatus = $this->uploadToAliyunOSS($localFilePath, $remoteFilePath);
                    break;
                default:
                    throw new Exception("不支持的远程存储类型: $storageType");
            }
        } catch (Exception $e) {
            $remoteStatus['error'] = $e->getMessage();
            error_log("远程备份上传失败: " . $e->getMessage());
        }
        
        return $remoteStatus;
    }
    
    /**
     * 通过FTP上传文件
     */
    private function uploadToFTP($localFilePath, $remoteFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_FTP,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['ftp']) || !is_array($this->remoteConfig['ftp'])) {
            $status['error'] = 'FTP配置未设置';
            return $status;
        }
        
        $ftpConfig = $this->remoteConfig['ftp'];
        
        try {
            // 连接FTP服务器
            $connId = ftp_connect($ftpConfig['host'], isset($ftpConfig['port']) ? $ftpConfig['port'] : 21);
            if (!$connId) {
                throw new Exception("无法连接到FTP服务器: " . $ftpConfig['host']);
            }
            
            // 登录FTP服务器
            $loginResult = ftp_login($connId, $ftpConfig['username'], $ftpConfig['password']);
            if (!$loginResult) {
                ftp_close($connId);
                throw new Exception("FTP登录失败");
            }
            
            // 设置被动模式
            ftp_pasv($connId, true);
            
            // 创建远程目录结构
            $remoteDir = dirname($remoteFilePath);
            if (!empty($remoteDir) && $remoteDir != '.') {
                $this->ftpMakeDirRecursive($connId, $remoteDir);
            }
            
            // 上传文件
            $upload = ftp_put($connId, $remoteFilePath, $localFilePath, FTP_BINARY);
            
            // 关闭连接
            ftp_close($connId);
            
            if ($upload) {
                $status['success'] = true;
            } else {
                throw new Exception("文件上传失败");
            }
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 递归创建FTP目录
     */
    private function ftpMakeDirRecursive($connId, $path) {
        $parts = explode('/', $path);
        $currentPath = '';
        
        foreach ($parts as $part) {
            if (empty($part)) continue;
            
            $currentPath .= '/' . $part;
            
            // 检查目录是否存在
            if (!@ftp_chdir($connId, $currentPath)) {
                // 如果不存在则创建
                ftp_chdir($connId, '/');
                if (!ftp_mkdir($connId, $currentPath)) {
                    throw new Exception("无法创建FTP目录: $currentPath");
                }
            }
        }
    }
    
    /**
     * 通过SFTP上传文件
     */
    private function uploadToSFTP($localFilePath, $remoteFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_SFTP,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['sftp']) || !is_array($this->remoteConfig['sftp'])) {
            $status['error'] = 'SFTP配置未设置';
            return $status;
        }
        
        $sftpConfig = $this->remoteConfig['sftp'];
        
        try {
            // 使用PHP的SSH2扩展上传文件（如果可用）
            if (function_exists('ssh2_connect')) {
                // 连接SFTP服务器
                $connection = ssh2_connect($sftpConfig['host'], isset($sftpConfig['port']) ? $sftpConfig['port'] : 22);
                if (!$connection) {
                    throw new Exception("无法连接到SFTP服务器");
                }
                
                // 认证
                if (isset($sftpConfig['private_key']) && !empty($sftpConfig['private_key'])) {
                    // 使用私钥认证
                    if (!ssh2_auth_pubkey_file($connection, $sftpConfig['username'], 
                        $sftpConfig['public_key'], $sftpConfig['private_key'], 
                        isset($sftpConfig['passphrase']) ? $sftpConfig['passphrase'] : '')) {
                        throw new Exception("SFTP密钥认证失败");
                    }
                } else {
                    // 使用密码认证
                    if (!ssh2_auth_password($connection, $sftpConfig['username'], $sftpConfig['password'])) {
                        throw new Exception("SFTP密码认证失败");
                    }
                }
                
                // 初始化SFTP会话
                $sftp = ssh2_sftp($connection);
                
                // 创建远程目录结构
                $remoteDir = dirname($remoteFilePath);
                if (!empty($remoteDir) && $remoteDir != '.') {
                    $this->sftpMakeDirRecursive($sftp, $remoteDir);
                }
                
                // 上传文件
                $stream = @fopen("ssh2.sftp://{$sftp}{$remoteFilePath}", 'w');
                if (!$stream) {
                    throw new Exception("无法创建远程文件");
                }
                
                $data_to_send = @file_get_contents($localFilePath);
                if ($data_to_send === false) {
                    fclose($stream);
                    throw new Exception("无法读取本地文件");
                }
                
                if (@fwrite($stream, $data_to_send) === false) {
                    fclose($stream);
                    throw new Exception("文件写入失败");
                }
                
                fclose($stream);
                $status['success'] = true;
            } else {
                // 如果没有SSH2扩展，尝试使用系统命令
                $status['error'] = 'PHP SSH2扩展未安装';
                // 这里可以添加使用系统命令的备选方案
            }
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 递归创建SFTP目录
     */
    private function sftpMakeDirRecursive($sftp, $path) {
        $parts = explode('/', $path);
        $currentPath = '';
        
        foreach ($parts as $part) {
            if (empty($part)) continue;
            
            $currentPath .= '/' . $part;
            
            // 尝试创建目录
            @mkdir("ssh2.sftp://{$sftp}{$currentPath}");
        }
    }
    
    /**
     * 上传到AWS S3
     */
    private function uploadToS3($localFilePath, $remoteFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_AWS_S3,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['aws_s3']) || !is_array($this->remoteConfig['aws_s3'])) {
            $status['error'] = 'AWS S3配置未设置';
            return $status;
        }
        
        $s3Config = $this->remoteConfig['aws_s3'];
        
        try {
            // 检查是否有AWS SDK可用
            if (class_exists('Aws\S3\S3Client')) {
                // 使用AWS SDK上传
                $s3 = new Aws\S3\S3Client(array(
                    'version' => 'latest',
                    'region'  => $s3Config['region'],
                    'credentials' => array(
                        'key'    => $s3Config['access_key'],
                        'secret' => $s3Config['secret_key']
                    )
                ));
                
                // 上传文件
                $result = $s3->putObject(array(
                    'Bucket' => $s3Config['bucket'],
                    'Key'    => $remoteFilePath,
                    'SourceFile' => $localFilePath,
                    'ContentType' => 'application/octet-stream'
                ));
                
                $status['success'] = true;
                $status['url'] = $result['ObjectURL'];
            } else {
                // 如果没有SDK，尝试使用REST API（简化版）
                $status['error'] = 'AWS SDK未安装';
                // 这里可以添加使用curl的备选方案
            }
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 上传到阿里云OSS
     */
    private function uploadToAliyunOSS($localFilePath, $remoteFilePath) {
        $status = array(
            'type' => self::REMOTE_STORAGE_ALIYUN_OSS,
            'success' => false,
            'error' => null,
            'time' => date('Y-m-d H:i:s')
        );
        
        if (!isset($this->remoteConfig['aliyun_oss']) || !is_array($this->remoteConfig['aliyun_oss'])) {
            $status['error'] = '阿里云OSS配置未设置';
            return $status;
        }
        
        $ossConfig = $this->remoteConfig['aliyun_oss'];
        
        try {
            // 检查是否有阿里云OSS SDK可用
            if (class_exists('OSS\OssClient')) {
                // 使用阿里云OSS SDK上传
                $ossClient = new OSS\OssClient(
                    $ossConfig['access_key'],
                    $ossConfig['secret_key'],
                    $ossConfig['endpoint']
                );
                
                // 上传文件
                $ossClient->uploadFile(
                    $ossConfig['bucket'],
                    $remoteFilePath,
                    $localFilePath
                );
                
                $status['success'] = true;
                $status['url'] = 'https://' . $ossConfig['bucket'] . '.' . $ossConfig['endpoint'] . '/' . $remoteFilePath;
            } else {
                // 如果没有SDK，尝试使用REST API（简化版）
                $status['error'] = '阿里云OSS SDK未安装';
                // 这里可以添加使用curl的备选方案
            }
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }
        
        return $status;
    }
    
    /**
     * 启用跨地域备份
     */
    public function enableRemoteBackup($storageType, $config) {
        try {
            // 验证存储类型
            $validTypes = array(
                self::REMOTE_STORAGE_FTP,
                self::REMOTE_STORAGE_SFTP,
                self::REMOTE_STORAGE_AWS_S3,
                self::REMOTE_STORAGE_ALIYUN_OSS
            );
            
            if (!in_array($storageType, $validTypes)) {
                throw new Exception("无效的存储类型");
            }
            
            // 保存配置到数据库
            $this->saveRemoteConfig($storageType, $config);
            
            // 更新内存中的配置
            $this->remoteConfig[$storageType] = $config;
            
            return array('success' => true);
        } catch (Exception $e) {
            return array('success' => false, 'error' => $e->getMessage());
        }
    }
    
    /**
     * 保存远程备份配置到数据库
     */
    private function saveRemoteConfig($storageType, $config) {
        try {
            // 确保配置表存在
            $this->ensureSystemConfigTableExists();
            
            // 将配置序列化为JSON
            $configJson = json_encode($config);
            
            // 保存到数据库
            $sql = "INSERT INTO system_config (category, `key`, `value`, created_at, updated_at) 
                   VALUES ('remote_backup', :type, :config, NOW(), NOW()) 
                   ON DUPLICATE KEY UPDATE 
                   `value` = :config, 
                   updated_at = NOW()";
            
            $this->database->query($sql, array(
                ':type' => $storageType,
                ':config' => $configJson
            ));
        } catch (Exception $e) {
            throw $e;
        }
    }
    
    /**
     * 确保系统配置表存在
     */
    private function ensureSystemConfigTableExists() {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS system_config (
                id INT AUTO_INCREMENT PRIMARY KEY,
                category VARCHAR(50) NOT NULL,
                `key` VARCHAR(100) NOT NULL,
                `value` TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY idx_category_key (category, `key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            
            $this->database->query($sql);
        } catch (Exception $e) {
            // 忽略错误
        }
    }
    
    /**
     * 禁用远程备份
     */
    public function disableRemoteBackup($storageType) {
        try {
            // 从数据库中删除配置
            $sql = "DELETE FROM system_config WHERE category = 'remote_backup' AND `key` = :type";
            $this->database->query($sql, array(':type' => $storageType));
            
            // 从内存中移除
            if (isset($this->remoteConfig[$storageType])) {
                unset($this->remoteConfig[$storageType]);
            }
            
            return array('success' => true);
        } catch (Exception $e) {
            return array('success' => false, 'error' => $e->getMessage());
        }
    }
    
    /**
     * 获取远程备份配置
     */
    public function getRemoteConfig() {
        return $this->remoteConfig;
    }
    
    /**
     * 同步备份到所有配置的远程存储
     */
    public function syncToAllRemotes($localFilePath, $remoteRelativePath) {
        $allResults = array();
        
        // 遍历所有配置的远程存储
        foreach ($this->remoteConfig as $storageType => $config) {
            if (!empty($config) && isset($config['enabled']) && $config['enabled']) {
                // 上传到远程存储
                $result = $this->uploadToRemote($localFilePath, $remoteRelativePath, $storageType);
                $allResults[$storageType] = $result;
            }
        }
        
        return $allResults;
    }
    
    /**
     * 获取备份统计信息
     */
    public function getBackupStats() {
        $stats = array();
        
        $types = array('database', 'files', 'logs');
        foreach ($types as $type) {
            $backups = $this->getBackupList($type);
            $totalSize = 0;
            foreach ($backups as $backup) {
                $totalSize += filesize($this->backupDir . '/' . $type . '/' . $backup['filename']);
            }
            
            $stats[$type] = array(
                'count' => count($backups),
                'total_size' => $this->formatFileSize($totalSize),
                'latest' => !empty($backups) ? $backups[0]['created_time'] : '无'
            );
        }
        
        return $stats;
    }
    
    /**
     * 防止克隆
     */
    private function __clone() {}
    
    /**
     * 防止反序列化
     */
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}