<?php

require_once __DIR__ . '/BaseService.php';

/**
 * 产品管理器
 */
class ProductManager extends BaseService
{
    private $cacheManager;
    
    public function __construct($database = null)
    {
        parent::__construct();
        // logger已在父类中初始化
        $this->cacheManager = CacheManager::getInstance();
    }
    
    /**
     * 创建产品
     */
    public function createProduct($productData)
    {
        try {
            // 验证必填字段
            $required = ['name', 'category_id', 'price'];
            foreach ($required as $field) {
                if (empty($productData[$field])) {
                    throw new Exception("Missing required field: {$field}");
                }
            }
            
            // 生成产品编号
            $productNo = $this->generateProductNo();
            
            // 准备数据
            $data = array(
                'product_no' => $productNo,
                'name' => $productData['name'],
                'description' => isset($productData['description']) ? $productData['description'] : '',
                'category_id' => $productData['category_id'],
                'price' => $productData['price'],
                'original_price' => isset($productData['original_price']) ? $productData['original_price'] : $productData['price'],
                'stock' => isset($productData['stock']) ? $productData['stock'] : 0,
                'min_stock' => isset($productData['min_stock']) ? $productData['min_stock'] : 0,
                'max_stock' => isset($productData['max_stock']) ? $productData['max_stock'] : 0,
                'card_type' => isset($productData['card_type']) ? $productData['card_type'] : 'text',
                'is_digital' => isset($productData['is_digital']) ? $productData['is_digital'] : 1,
                'is_active' => isset($productData['is_active']) ? $productData['is_active'] : 1,
                'sort_order' => isset($productData['sort_order']) ? $productData['sort_order'] : 0,
                'tags' => isset($productData['tags']) ? json_encode($productData['tags']) : null,
                'specifications' => isset($productData['specifications']) ? json_encode($productData['specifications']) : null,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            );
            
            // 插入数据
            $sql = "INSERT INTO products (" . implode(', ', array_keys($data)) . ") 
                    VALUES (" . str_repeat('?,', count($data) - 1) . "?)";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array_values($data));
            
            $productId = $this->database->lastInsertId();
            
            // 清除缓存
            $this->cacheManager->delete('products:*');
            
            $this->logInfo('产品创建成功', array(
                'product_id' => $productId,
                'product_no' => $productNo,
                'name' => $productData['name']
            ));
            
            return array(
                'success' => true,
                'id' => $productId,
                'product_no' => $productNo,
                'message' => '产品创建成功'
            );
            
        } catch (Exception $e) {
            $this->logError('创建产品失败', array(
                'product_data' => $productData,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 更新产品
     */
    public function updateProduct($productId, $productData)
    {
        try {
            $product = $this->getProduct($productId);
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            // 准备更新数据
            $updateData = array();
            $params = array();
            
            $allowedFields = array(
                'name', 'description', 'category_id', 'price', 'original_price',
                'stock', 'min_stock', 'max_stock', 'card_type', 'is_digital',
                'is_active', 'sort_order', 'tags', 'specifications'
            );
            
            foreach ($allowedFields as $field) {
                if (isset($productData[$field])) {
                    $updateData[] = "{$field} = ?";
                    if (in_array($field, array('tags', 'specifications'))) {
                        $params[] = json_encode($productData[$field]);
                    } else {
                        $params[] = $productData[$field];
                    }
                }
            }
            
            if (empty($updateData)) {
                throw new Exception('没有需要更新的字段');
            }
            
            $updateData[] = "updated_at = ?";
            $params[] = date('Y-m-d H:i:s');
            $params[] = $productId;
            
            // 更新数据
            $sql = "UPDATE products SET " . implode(', ', $updateData) . " WHERE id = ?";
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            
            // 清除缓存
            $this->cacheManager->delete('products:*');
            
            $this->logInfo('产品更新成功', array(
                'product_id' => $productId,
                'updated_fields' => array_keys($productData)
            ));
            
            return array(
                'success' => true,
                'message' => '产品更新成功'
            );
            
        } catch (Exception $e) {
            $this->logError('更新产品失败', array(
                'product_id' => $productId,
                'product_data' => $productData,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 删除产品
     */
    public function deleteProduct($productId)
    {
        try {
            $product = $this->getProduct($productId);
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            // 检查是否有关联的订单
            $orderCount = $this->database->fetchColumn("SELECT COUNT(*) FROM orders WHERE product_id = ?", array($productId));
            
            if ($orderCount > 0) {
                throw new Exception('该产品有关联订单，无法删除');
            }
            
            // 删除产品
            $sql = "DELETE FROM products WHERE id = ?";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($productId));
            
            // 清除缓存
            $this->cacheManager->delete('products:*');
            
            $this->logInfo('产品删除成功', array(
                'product_id' => $productId,
                'product_name' => $product['name']
            ));
            
            return array(
                'success' => true,
                'message' => '产品删除成功'
            );
            
        } catch (Exception $e) {
            $this->logError('删除产品失败', array(
                'product_id' => $productId,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 获取产品详情
     */
    public function getProduct($productId)
    {
        try {
            $cacheKey = "product:{$productId}";
            $product = $this->cacheManager->get($cacheKey);
            
            if ($product === null) {
                $sql = "SELECT p.*, c.name as category_name 
                        FROM products p 
                        LEFT JOIN categories c ON p.category_id = c.id 
                        WHERE p.id = ?";
                $stmt = $this->database->prepare($sql);
                $stmt->execute(array($productId));
                $product = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($product) {
                    // 解析JSON字段
                    if ($product['tags']) {
                        $product['tags'] = json_decode($product['tags'], true);
                    }
                    if ($product['specifications']) {
                        $product['specifications'] = json_decode($product['specifications'], true);
                    }
                    
                    // 获取库存统计
                    $sql = "SELECT COUNT(*) as total_cards, 
                                   COUNT(CASE WHEN status = 'available' THEN 1 END) as available_cards
                            FROM cards 
                            WHERE product_id = ?";
                    $stmt = $this->database->prepare($sql);
                    $stmt->execute(array($productId));
                    $cardStats = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    $product['card_stats'] = $cardStats;
                    
                    // 缓存结果
                    $this->cacheManager->set($cacheKey, $product, 300);
                }
            }
            
            return $product;
            
        } catch (Exception $e) {
            $this->logError('获取产品失败', array(
                'product_id' => $productId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 根据产品编号获取产品
     */
    public function getProductByNo($productNo)
    {
        try {
            $sql = "SELECT id FROM products WHERE product_no = ?";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($productNo));
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $product ? $this->getProduct($product['id']) : false;
            
        } catch (Exception $e) {
            $this->logError('根据编号获取产品失败', array(
                'product_no' => $productNo,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取产品列表
     */
    public function getProductList($filters = array(), $page = 1, $limit = 20)
    {
        try {
            $offset = ($page - 1) * $limit;
            $whereClause = 'WHERE 1=1';
            $params = array();
            
            // 构建查询条件
            if (!empty($filters['category_id'])) {
                $whereClause .= " AND p.category_id = ?";
                $params[] = $filters['category_id'];
            }
            
            if (!empty($filters['is_active'])) {
                $whereClause .= " AND p.is_active = ?";
                $params[] = $filters['is_active'];
            }
            
            if (!empty($filters['is_digital'])) {
                $whereClause .= " AND p.is_digital = ?";
                $params[] = $filters['is_digital'];
            }
            
            if (!empty($filters['search'])) {
                $whereClause .= " AND (p.name LIKE ? OR p.description LIKE ? OR p.product_no LIKE ?)";
                $searchTerm = '%' . $filters['search'] . '%';
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }
            
            if (!empty($filters['min_price'])) {
                $whereClause .= " AND p.price >= ?";
                $params[] = $filters['min_price'];
            }
            
            if (!empty($filters['max_price'])) {
                $whereClause .= " AND p.price <= ?";
                $params[] = $filters['max_price'];
            }
            
            // 查询总数
            $countSql = "SELECT COUNT(*) FROM products p {$whereClause}";
            $total = $this->database->fetchColumn($countSql, $params);
            
            // 查询数据
            $sql = "SELECT p.*, c.name as category_name,
                           COUNT(ca.id) as total_cards,
                           COUNT(CASE WHEN ca.status = 'available' THEN 1 END) as available_cards
                    FROM products p 
                    LEFT JOIN categories c ON p.category_id = c.id
                    LEFT JOIN cards ca ON p.id = ca.product_id
                    {$whereClause}
                    GROUP BY p.id
                    ORDER BY p.sort_order ASC, p.created_at DESC
                    LIMIT {$limit} OFFSET {$offset}";
            
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 格式化数据
            foreach ($products as &$product) {
                if ($product['tags']) {
                    $product['tags'] = json_decode($product['tags'], true);
                }
                if ($product['specifications']) {
                    $product['specifications'] = json_decode($product['specifications'], true);
                }
            }
            
            return array(
                'products' => $products,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                )
            );
            
        } catch (Exception $e) {
            $this->logError('获取产品列表失败', array(
                'filters' => $filters,
                'page' => $page,
                'limit' => $limit,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取产品统计
     */
    public function getProductStatistics($filters = array())
    {
        try {
            $whereClause = 'WHERE 1=1';
            $params = array();
            
            if (!empty($filters['start_date'])) {
                $whereClause .= " AND created_at >= ?";
                $params[] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $whereClause .= " AND created_at <= ?";
                $params[] = $filters['end_date'] . ' 23:59:59';
            }
            
            $sql = "SELECT 
                         COUNT(*) as total_products,
                         COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_products,
                         COUNT(CASE WHEN is_digital = 1 THEN 1 END) as digital_products,
                         SUM(price) as total_value,
                         AVG(price) as avg_price,
                         MIN(price) as min_price,
                         MAX(price) as max_price
                     FROM products {$whereClause}";
             
             $stmt = $this->database->prepare($sql);
             $stmt->execute($params);
             $stats = $stmt->fetch(PDO::FETCH_ASSOC);
             
             // 按分类统计
             $categorySql = "SELECT c.name, COUNT(p.id) as product_count, SUM(p.price) as total_value
                            FROM categories c
                            LEFT JOIN products p ON c.id = p.category_id
                            GROUP BY c.id, c.name
                            ORDER BY product_count DESC";
             $categoryStmt = $this->database->prepare($categorySql);
             $categoryStmt->execute();
             $stats['by_category'] = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
             
             return $stats;
            
        } catch (Exception $e) {
            $this->logError('获取产品统计失败', array(
                'filters' => $filters,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 更新产品库存
     */
    public function updateProductStock($productId, $quantity, $operation = 'add')
    {
        try {
            $product = $this->getProduct($productId);
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            if ($operation === 'add') {
                $newStock = $product['stock'] + $quantity;
            } elseif ($operation === 'subtract') {
                $newStock = $product['stock'] - $quantity;
                if ($newStock < 0) {
                    throw new Exception('库存不足');
                }
            } else {
                $newStock = $quantity;
            }
            
            $sql = "UPDATE products SET stock = ?, updated_at = ? WHERE id = ?";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($newStock, date('Y-m-d H:i:s'), $productId));
            
            // 清除缓存
            $this->cacheManager->delete("product:{$productId}");
            
            $this->logInfo('产品库存更新', array(
                'product_id' => $productId,
                'old_stock' => $product['stock'],
                'new_stock' => $newStock,
                'operation' => $operation
            ));
            
            return array(
                'success' => true,
                'new_stock' => $newStock
            );
            
        } catch (Exception $e) {
            $this->logError('更新产品库存失败', array(
                'product_id' => $productId,
                'quantity' => $quantity,
                'operation' => $operation,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 生成产品编号
     */
    private function generateProductNo()
    {
        $prefix = 'PRD';
        $date = date('Ymd');
        $random = sprintf('%04d', mt_rand(1, 9999));
        return $prefix . $date . $random;
    }
    
    /**
     * 记录信息日志
     */
    private function logInfo($message, $data = array())
    {
        $this->logger->info($message, array_merge($data, array('component' => 'ProductManager')));
    }
    
    /**
     * 记录错误日志
     */
    private function logError($message, $data = array())
    {
        $this->logger->error($message, array_merge($data, array('component' => 'ProductManager')));
    }
}