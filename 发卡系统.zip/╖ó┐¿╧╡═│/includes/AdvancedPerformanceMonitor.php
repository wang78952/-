\u003c?php
/**
 * 高级性能监控与告警系统
 * 提供全面的系统监控、性能分析、趋势预测和智能告警功能
 */

class AdvancedPerformanceMonitor {
    private $db;
    private $config;
    private $system_monitor;
    private $performance_monitor;
    private $alerts = [];
    private $thresholds = [];
    private $notification_channels = [];
    
    /**
     * 构造函数
     */
    public function __construct($db, $config = []) {
        $this-\u003edb = $db;
        $this-\u003econfig = array_merge([
            'sampling_interval' =\u003e 60, // 秒
            'alert_cooldown' =\u003e 300, // 告警冷却时间，避免告警风暴
            'dashboard_refresh_interval' =\u003e 5, // 仪表盘刷新间隔，秒
            'data_retention_days' =\u003e 90,
            'anomaly_detection_enabled' =\u003e true,
            'auto_scaling_enabled' =\u003e false,
            'baseline_days' =\u003e 7, // 基线学习天数
            'sensitivity_level' =\u003e 'medium', // low, medium, high
            'notification_settings' =\u003e [
                'email' =\u003e ['enabled' =\u003e true, 'recipients' =\u003e ['admin@example.com']],
                'sms' =\u003e ['enabled' =\u003e false, 'recipients' =\u003e ['13800138000']],
                'webhook' =\u003e ['enabled' =\u003e false, 'url' =\u003e 'https://api.example.com/webhook'],
                'wechat' =\u003e ['enabled' =\u003e false, 'app_id' =\u003e '', 'app_secret' =\u003e '']
            ],
        ], $config);
        
        $this-\u003esystem_monitor = new SystemMonitor($db);
        $this-\u003eperformance_monitor = new PerformanceMonitor($db);
        
        $this-\u003esetupThresholds();
        $this-\u003esetupNotificationChannels();
    }
    
    /**
     * 启动监控服务
     */
    public function startMonitoring() {
        $this-\u003elogMonitoringEvent('monitoring_started');
        
        // 在实际应用中，这里会启动一个守护进程或定时任务
        // 这里仅作为示例
        $this-\u003ecollectAndAnalyzeMetrics();
        
        return ['status' =\u003e 'started', 'message' =\u003e '监控服务已启动'];
    }
    
    /**
     * 收集并分析指标
     */
    public function collectAndAnalyzeMetrics() {
        try {
            // 收集基础性能指标
            $metrics = $this-\u003eperformance_monitor-\u003ecollectMetrics();
            
            // 扩展收集应用级指标
            $app_metrics = $this-\u003ecollectApplicationMetrics();
            
            // 合并所有指标
            $combined_metrics = array_merge($metrics, $app_metrics);
            
            // 保存详细指标
            $this-\u003esaveDetailedMetrics($combined_metrics);
            
            // 分析性能趋势
            $trends = $this-\u003eanalyzePerformanceTrends($combined_metrics);
            
            // 异常检测
            if ($this-\u003econfig['anomaly_detection_enabled']) {
                $anomalies = $this-\u003edetectAnomalies($combined_metrics, $trends);
                if (!empty($anomalies)) {
                    foreach ($anomalies as $anomaly) {
                        $this-\u003etriggerAlert($anomaly['type'], $anomaly['severity'], $anomaly['message'], $anomaly['details']);
                    }
                }
            }
            
            // 阈值检查
            $threshold_alerts = $this-\u003echeckThresholds($combined_metrics);
            foreach ($threshold_alerts as $alert) {
                $this-\u003etriggerAlert($alert['type'], $alert['severity'], $alert['message'], $alert['details']);
            }
            
            // 性能预测
            $predictions = $this-\u003epredictPerformance($trends);
            if (!empty($predictions['warnings'])) {
                foreach ($predictions['warnings'] as $warning) {
                    $this-\u003etriggerAlert('prediction', 'warning', $warning['message'], $warning['details']);
                }
            }
            
            return [
                'metrics' =\u003e $combined_metrics,
                'trends' =\u003e $trends,
                'anomalies' =\u003e isset($anomalies) ? $anomalies : [],
                'predictions' =\u003e $predictions
            ];
        } catch (Exception $e) {
            $this-\u003elogMonitoringEvent('monitoring_error', ['error' =\u003e $e-\u003egetMessage()]);
            $this-\u003etriggerAlert('monitoring', 'critical', '监控系统异常', ['error' =\u003e $e-\u003egetMessage()]);
            return ['error' =\u003e $e-\u003egetMessage()];
        }
    }
    
    /**
     * 收集应用级指标
     */
    public function collectApplicationMetrics() {
        $metrics = [];
        
        // 收集API请求统计
        $metrics['api_requests'] = $this-\u003ecollectApiMetrics();
        
        // 收集数据库性能指标
        $metrics['database'] = $this-\u003ecollectDatabaseMetrics();
        
        // 收集业务指标
        $metrics['business'] = $this-\u003ecollectBusinessMetrics();
        
        // 收集错误统计
        $metrics['errors'] = $this-\u003esystem_monitor-\u003 egetErrorStats('1h');
        
        // 收集会话统计
        $metrics['sessions'] = $this-\u003ecollectSessionMetrics();
        
        // 收集缓存性能
        $metrics['cache'] = $this-\u003ecollectCacheMetrics();
        
        return $metrics;
    }
    
    /**
     * 分析性能趋势
     */
    public function analyzePerformanceTrends($current_metrics) {
        $trends = [];
        $time_ranges = ['1h', '6h', '24h', '7d'];
        
        foreach ($time_ranges as $range) {
            $historical_data = $this-\u003eperformance_monitor-\u003 egetHistoricalMetrics($range);
            $trends[$range] = $this-\u003ecalculateTrends($historical_data, $current_metrics);
        }
        
        // 计算环比和同比变化
        $trends['comparison'] = [
            'day_over_day' =\u003e $this-\u003ecalculateDayOverDayChange(),
            'week_over_week' =\u003e $this-\u003ecalculateWeekOverWeekChange(),
        ];
        
        // 更新性能基线
        $this-\u003eupdatePerformanceBaseline($current_metrics, $trends);
        
        return $trends;
    }
    
    /**
     * 异常检测
     */
    public function detectAnomalies($current_metrics, $trends) {
        $anomalies = [];
        
        // 基于统计模型的异常检测
        $statistical_anomalies = $this-\u003edetectStatisticalAnomalies($current_metrics, $trends);
        if (!empty($statistical_anomalies)) {
            $anomalies = array_merge($anomalies, $statistical_anomalies);
        }
        
        // 基于规则的异常检测
        $rule_based_anomalies = $this-\u003edetectRuleBasedAnomalies($current_metrics);
        if (!empty($rule_based_anomalies)) {
            $anomalies = array_merge($anomalies, $rule_based_anomalies);
        }
        
        // 检测业务异常
        $business_anomalies = $this-\u003edetectBusinessAnomalies($current_metrics['business'] ?? []);
        if (!empty($business_anomalies)) {
            $anomalies = array_merge($anomalies, $business_anomalies);
        }
        
        return $anomalies;
    }
    
    /**
     * 性能预测
     */
    public function predictPerformance($trends) {
        $predictions = ['forecast' =\u003e [], 'warnings' =\u003e []];
        
        try {
            // 预测未来24小时的关键指标
            $predictions['forecast'] = $this-\u003eforecastNext24Hours($trends);
            
            // 生成预警
            $predictions['warnings'] = $this-\u003egenerateForecastWarnings($predictions['forecast']);
        } catch (Exception $e) {
            $this-\u003elogMonitoringEvent('prediction_error', ['error' =\u003e $e-\u003egetMessage()]);
        }
        
        return $predictions;
    }
    
    /**
     * 触发告警
     */
    public function triggerAlert($type, $severity, $message, $details = []) {
        // 检查告警冷却
        if ($this-\u003eisAlertOnCooldown($type)) {
            return false;
        }
        
        $alert = [
            'id' =\u003e uniqid('alert_'),
            'type' =\u003e $type,
            'severity' =\u003e $severity,
            'message' =\u003e $message,
            'details' =\u003e $details,
            'timestamp' =\u003e time(),
            'status' =\u003e 'active',
            'acknowledged' =\u003e false,
            'acknowledged_by' =\u003e null,
            'acknowledged_at' =\u003e null,
            'resolved' =\u003e false,
            'resolved_at' =\u003e null,
            'resolution_note' =\u003e null,
        ];
        
        // 保存告警
        $this-\u003esaveAlert($alert);
        $this-\u003ealerts[] = $alert;
        
        // 记录告警事件
        $this-\u003elogMonitoringEvent('alert_triggered', $alert);
        
        // 发送通知
        $this-\u003esendAlertNotifications($alert);
        
        // 设置告警冷却
        $this-\u003esetAlertCooldown($type);
        
        return true;
    }
    
    /**
     * 解决告警
     */
    public function resolveAlert($alert_id, $resolution_note = '') {
        foreach ($this-\u003ealerts as \u0026$alert) {
            if ($alert['id'] === $alert_id) {
                $alert['status'] =\u003e 'resolved';
                $alert['resolved_at'] =\u003e time();
                $alert['resolution_note'] =\u003e $resolution_note;
                
                // 更新数据库
                $this-\u003edb-\u003eexec("UPDATE alerts SET status = 'resolved', resolved_at = NOW(), resolution_note = '{$resolution_note}' WHERE id = '{$alert_id}'");
                
                $this-\u003elogMonitoringEvent('alert_resolved', $alert);
                
                return true;
            }
        }
        
        // 如果在内存中找不到，尝试从数据库更新
        $result = $this-\u003edb-\u003eexec("UPDATE alerts SET status = 'resolved', resolved_at = NOW(), resolution_note = '{$resolution_note}' WHERE id = '{$alert_id}'");
        
        return $result \u003e 0;
    }
    
    /**
     * 确认告警
     */
    public function acknowledgeAlert($alert_id, $user_id) {
        foreach ($this-\u003ealerts as \u0026$alert) {
            if ($alert['id'] === $alert_id) {
                $alert['acknowledged'] =\u003e true;
                $alert['acknowledged_by'] =\u003e $user_id;
                $alert['acknowledged_at'] =\u003e time();
                
                // 更新数据库
                $this-\u003edb-\u003eexec("UPDATE alerts SET acknowledged = 1, acknowledged_by = '{$user_id}', acknowledged_at = NOW() WHERE id = '{$alert_id}'");
                
                $this-\u003elogMonitoringEvent('alert_acknowledged', $alert);
                
                return true;
            }
        }
        
        // 如果在内存中找不到，尝试从数据库更新
        $result = $this-\u003edb-\u003eexec("UPDATE alerts SET acknowledged = 1, acknowledged_by = '{$user_id}', acknowledged_at = NOW() WHERE id = '{$alert_id}'");
        
        return $result \u003e 0;
    }
    
    /**
     * 获取仪表盘数据
     */
    public function getDashboardData() {
        $dashboard = [
            'system_health' =\u003e $this-\u003esystem_monitor-\u003 egetHealthStatus(),
            'performance_summary' =\u003e $this-\u003egetPerformanceSummary(),
            'recent_alerts' =\u003e $this-\u003egetRecentAlerts(10),
            'performance_trends' =\u003e $this-\u003egetPerformanceTrends('24h'),
            'top_issues' =\u003e $this-\u003egetTopIssues(),
            'business_metrics' =\u003e $this-\u003ecollectBusinessMetrics(),
            'resource_usage' =\u003e $this-\u003eperformance_monitor-\u003 egetHistoricalMetrics('1h'),
            'api_performance' =\u003e $this-\u003ecollectApiMetrics(),
            'predictions' =\u003e $this-\u003epredictPerformance($this-\u003egetPerformanceTrends('7d')),
        ];
        
        return $dashboard;
    }
    
    /**
     * 生成性能报告
     */
    public function generatePerformanceReport($time_range = '7d', $format = 'html') {
        $report_data = [
            'period' =\u003e $time_range,
            'generated_at' =\u003e date('Y-m-d H:i:s'),
            'summary' =\u003e $this-\u003egenerateReportSummary($time_range),
            'detailed_metrics' =\u003e $this-\u003egetDetailedMetrics($time_range),
            'anomalies' =\u003e $this-\u003egetAnomaliesDuringPeriod($time_range),
            'recommendations' =\u003e $this-\u003egenerateOptimizationRecommendations(),
            'comparison' =\u003e $this-\u003egetPeriodComparison($time_range),
        ];
        
        switch ($format) {
            case 'html':
                return $this-\u003erenderHtmlReport($report_data);
            case 'pdf':
                return $this-\u003egeneratePdfReport($report_data);
            case 'json':
                return json_encode($report_data, JSON_PRETTY_PRINT);
            default:
                return json_encode($report_data, JSON_PRETTY_PRINT);
        }
    }
    
    /**
     * 配置告警阈值
     */
    public function setThresholds($thresholds) {
        $this-\u003ethresholds = array_merge($this-\u003ethresholds, $thresholds);
        $this-\u003esaveThresholds();
        return true;
    }
    
    /**
     * 获取当前阈值配置
     */
    public function getThresholds() {
        return $this-\u003ethresholds;
    }
    
    /**
     * 设置通知渠道
     */
    public function configureNotificationChannel($channel, $settings) {
        if (isset($this-\u003enotification_channels[$channel])) {
            $this-\u003enotification_channels[$channel]['settings'] = $settings;
            $this-\u003esaveNotificationSettings();
            return true;
        }
        return false;
    }
    
    // ------------------------- 私有辅助方法 ------------------------- //
    
    /**
     * 设置默认阈值
     */
    private function setupThresholds() {
        $this-\u003ethresholds = [
            'cpu' =\u003e [
                'warning' =\u003e 70,
                'critical' =\u003e 90,
                'sustained_period' =\u003e 3 // 分钟
            ],
            'memory' =\u003e [
                'warning' =\u003e 75,
                'critical' =\u003e 90,
                'sustained_period' =\u003e 5 // 分钟
            ],
            'disk' =\u003e [
                'warning' =\u003e 80,
                'critical' =\u003e 95,
                'sustained_period' =\u003e 0 // 立即告警
            ],
            'database' =\u003e [
                'connection_pool_usage' =\u003e [
                    'warning' =\u003e 80,
                    'critical' =\u003e 95
                ],
                'query_time' =\u003e [
                    'warning' =\u003e 0.5, // 秒
                    'critical' =\u003e 1.0 // 秒
                ],
                'slow_queries_rate' =\u003e [
                    'warning' =\u003e 5, // 每分钟
                    'critical' =\u003e 10 // 每分钟
                ]
            ],
            'api' =\u003e [
                'response_time' =\u003e [
                    'warning' =\u003e 200, // ms
                    'critical' =\u003e 500 // ms
                ],
                'error_rate' =\u003e [
                    'warning' =\u003e 1, // 百分比
                    'critical' =\u003e 5 // 百分比
                ],
                'request_rate' =\u003e [
                    'warning' =\u003e 500, // 每分钟
                    'critical' =\u003e 1000 // 每分钟
                ]
            ],
            'business' =\u003e [
                'transaction_error_rate' =\u003e [
                    'warning' =\u003e 0.5, // 百分比
                    'critical' =\u003e 2 // 百分比
                ],
                'checkout_failure_rate' =\u003e [
                    'warning' =\u003e 3, // 百分比
                    'critical' =\u003e 10 // 百分比
                ]
            ],
            'cache' =\u003e [
                'miss_rate' =\u003e [
                    'warning' =\u003e 30, // 百分比
                    'critical' =\u003e 50 // 百分比
                ]
            ]
        ];
        
        // 从数据库加载自定义阈值
        $this-\u003eloadCustomThresholds();
    }
    
    /**
     * 设置通知渠道
     */
    private function setupNotificationChannels() {
        $this-\u003enotification_channels = [
            'email' =\u003e [
                'enabled' =\u003e $this-\u003econfig['notification_settings']['email']['enabled'],
                'settings' =\u003e $this-\u003econfig['notification_settings']['email'],
                'send' =\u003e [$this, 'sendEmailNotification']
            ],
            'sms' =\u003e [
                'enabled' =\u003e $this-\u003econfig['notification_settings']['sms']['enabled'],
                'settings' =\u003e $this-\u003econfig['notification_settings']['sms'],
                'send' =\u003e [$this, 'sendSmsNotification']
            ],
            'webhook' =\u003e [
                'enabled' =\u003e $this-\u003econfig['notification_settings']['webhook']['enabled'],
                'settings' =\u003e $this-\u003econfig['notification_settings']['webhook'],
                'send' =\u003e [$this, 'sendWebhookNotification']
            ],
            'wechat' =\u003e [
                'enabled' =\u003e $this-\u003econfig['notification_settings']['wechat']['enabled'],
                'settings' =\u003e $this-\u003econfig['notification_settings']['wechat'],
                'send' =\u003e [$this, 'sendWechatNotification']
            ]
        ];
    }
    
    /**
     * 收集API性能指标
     */
    private function collectApiMetrics() {
        $query = "SELECT
            endpoint,
            COUNT(*) as request_count,
            AVG(response_time) as avg_response_time,
            MAX(response_time) as max_response_time,
            SUM(CASE WHEN status_code \u003e= 400 THEN 1 ELSE 0 END) as error_count,
            DATE_FORMAT(created_at, '%Y-%m-%d %H:00:00') as hour
            FROM api_requests
            WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            GROUP BY endpoint, hour
            ORDER BY request_count DESC";
        
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute();
        
        $metrics = $stmt-\u003efetchAll(PDO::FETCH_ASSOC);
        
        // 计算汇总数据
        $summary = [
            'total_requests' =\u003e array_sum(array_column($metrics, 'request_count')),
            'total_errors' =\u003e array_sum(array_column($metrics, 'error_count')),
            'avg_response_time' =\u003e !empty($metrics) ? array_sum(array_column($metrics, 'avg_response_time')) / count($metrics) : 0,
            'error_rate' =\u003e $summary['total_requests'] \u003e 0 ? ($summary['total_errors'] / $summary['total_requests']) * 100 : 0,
            'top_endpoints' =\u003e array_slice($metrics, 0, 5),
            'slowest_endpoints' =\u003e array_slice(array_values(array_sort($metrics, 'avg_response_time', SORT_DESC)), 0, 5),
            'error_endpoints' =\u003e array_filter($metrics, function($m) { return $m['error_count'] \u003e 0; })
        ];
        
        return ['details' =\u003e $metrics, 'summary' =\u003e $summary];
    }
    
    /**
     * 收集数据库性能指标
     */
    private function collectDatabaseMetrics() {
        // 查询慢查询
        $slow_queries = $this-\u003edb-\u003equery("SELECT * FROM slow_queries WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR) ORDER BY execution_time DESC LIMIT 10")-\u003efetchAll();
        
        // 查询连接池状态
        $connection_stats = $this-\u003edb-\u003equery("SELECT * FROM db_connection_stats ORDER BY timestamp DESC LIMIT 1")-\u003efetch();
        
        // 查询索引使用情况
        $index_usage = $this-\u003edb-\u003equery("SELECT * FROM index_usage_stats WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)")-\u003efetchAll();
        
        return [
            'slow_queries' =\u003e $slow_queries,
            'connection_pool' =\u003e $connection_stats,
            'index_usage' =\u003e $index_usage,
            'slow_query_count' =\u003e count($slow_queries),
            'avg_query_time' =\u003e $connection_stats ? $connection_stats['avg_query_time'] : 0,
        ];
    }
    
    /**
     * 收集业务指标
     */
    private function collectBusinessMetrics() {
        $metrics = [];
        
        // 订单统计
        $orders = $this-\u003edb-\u003equery("SELECT
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_orders,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
            AVG(total_amount) as avg_order_value,
            SUM(total_amount) as total_sales
            FROM orders
            WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)")-\u003efetch();
        
        $metrics['orders'] = $orders;
        
        // 活跃用户
        $users = $this-\u003edb-\u003equery("SELECT
            COUNT(DISTINCT user_id) as active_users,
            COUNT(DISTINCT CASE WHEN last_login \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN user_id END) as hourly_active_users
            FROM users
            WHERE last_login \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)")-\u003efetch();
        
        $metrics['users'] = $users;
        
        // 卡密销售统计
        $cards = $this-\u003edb-\u003equery("SELECT
            card_type,
            COUNT(*) as sold_count,
            SUM(price) as revenue
            FROM order_items
            WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)
            GROUP BY card_type
            ORDER BY sold_count DESC")-\u003efetchAll();
        
        $metrics['cards'] = $cards;
        
        // 转化率
        $conversion = $this-\u003edb-\u003equery("SELECT
            (SELECT COUNT(*) FROM sessions WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)) as total_sessions,
            (SELECT COUNT(*) FROM orders WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)) as orders
            ")-\u003efetch();
        
        $metrics['conversion_rate'] = $conversion['total_sessions'] \u003e 0 ? ($conversion['orders'] / $conversion['total_sessions']) * 100 : 0;
        
        return $metrics;
    }
    
    /**
     * 收集会话指标
     */
    private function collectSessionMetrics() {
        $query = "SELECT
            COUNT(*) as active_sessions,
            AVG(session_duration) as avg_session_duration,
            COUNT(DISTINCT user_id) as unique_users,
            COUNT(DISTINCT ip_address) as unique_ips
            FROM sessions
            WHERE last_activity \u003e= DATE_SUB(NOW(), INTERVAL 30 MINUTE)";
        
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute();
        
        return $stmt-\u003efetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * 收集缓存性能指标
     */
    private function collectCacheMetrics() {
        $query = "SELECT
            SUM(hits) as total_hits,
            SUM(misses) as total_misses,
            SUM(hits + misses) as total_operations,
            AVG(execution_time) as avg_execution_time
            FROM cache_stats
            WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute();
        
        $stats = $stmt-\u003efetch(PDO::FETCH_ASSOC);
        
        $hit_rate = $stats['total_operations'] \u003e 0 ? ($stats['total_hits'] / $stats['total_operations']) * 100 : 0;
        $miss_rate = 100 - $hit_rate;
        
        return [
            'hit_rate' =\u003e round($hit_rate, 2),
            'miss_rate' =\u003e round($miss_rate, 2),
            'total_operations' =\u003e $stats['total_operations'],
            'avg_execution_time' =\u003e $stats['avg_execution_time'],
            'top_keys' =\u003e $this-\u003edb-\u003equery("SELECT cache_key, hits + misses as operations FROM cache_stats WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR) GROUP BY cache_key ORDER BY operations DESC LIMIT 10")-\u003efetchAll()
        ];
    }
    
    /**
     * 检查阈值
     */
    private function checkThresholds($metrics) {
        $threshold_alerts = [];
        
        // CPU 检查
        if (isset($metrics['cpu']['usage_percent']) \u0026\u0026 $metrics['cpu']['usage_percent'] \u003e= $this-\u003ethresholds['cpu']['warning']) {
            $severity = $metrics['cpu']['usage_percent'] \u003e= $this-\u003ethresholds['cpu']['critical'] ? 'critical' : 'warning';
            $threshold_alerts[] = [
                'type' =\u003e 'cpu_usage',
                'severity' =\u003e $severity,
                'message' =\u003e "CPU使用率过高: {$metrics['cpu']['usage_percent']}%",
                'details' =\u003e $metrics['cpu']
            ];
        }
        
        // 内存检查
        if (isset($metrics['memory']['usage_percent']) \u0026\u0026 $metrics['memory']['usage_percent'] \u003e= $this-\u003ethresholds['memory']['warning']) {
            $severity = $metrics['memory']['usage_percent'] \u003e= $this-\u003ethresholds['memory']['critical'] ? 'critical' : 'warning';
            $threshold_alerts[] = [
                'type' =\u003e 'memory_usage',
                'severity' =\u003e $severity,
                'message' =\u003e "内存使用率过高: {$metrics['memory']['usage_percent']}%",
                'details' =\u003e $metrics['memory']
            ];
        }
        
        // 磁盘检查
        if (isset($metrics['disk']) \u0026\u0026 is_array($metrics['disk'])) {
            foreach ($metrics['disk'] as $disk) {
                if ($disk['usage_percent'] \u003e= $this-\u003ethresholds['disk']['warning']) {
                    $severity = $disk['usage_percent'] \u003e= $this-\u003ethresholds['disk']['critical'] ? 'critical' : 'warning';
                    $threshold_alerts[] = [
                        'type' =\u003e 'disk_usage',
                        'severity' =\u003e $severity,
                        'message' =\u003e "磁盘 {$disk['mount_point']} 使用率过高: {$disk['usage_percent']}%",
                        'details' =\u003e $disk
                    ];
                }
            }
        }
        
        // API 响应时间检查
        if (isset($metrics['api']['summary']['avg_response_time']) \u0026\u0026 $metrics['api']['summary']['avg_response_time'] \u003e= $this-\u003ethresholds['api']['response_time']['warning']) {
            $severity = $metrics['api']['summary']['avg_response_time'] \u003e= $this-\u003ethresholds['api']['response_time']['critical'] ? 'critical' : 'warning';
            $threshold_alerts[] = [
                'type' =\u003e 'api_response_time',
                'severity' =\u003e $severity,
                'message' =\u003e "API响应时间过长: {$metrics['api']['summary']['avg_response_time']}ms",
                'details' =\u003e $metrics['api']['summary']
            ];
        }
        
        // API 错误率检查
        if (isset($metrics['api']['summary']['error_rate']) \u0026\u0026 $metrics['api']['summary']['error_rate'] \u003e= $this-\u003ethresholds['api']['error_rate']['warning']) {
            $severity = $metrics['api']['summary']['error_rate'] \u003e= $this-\u003ethresholds['api']['error_rate']['critical'] ? 'critical' : 'warning';
            $threshold_alerts[] = [
                'type' =\u003e 'api_error_rate',
                'severity' =\u003e $severity,
                'message' =\u003e "API错误率过高: {$metrics['api']['summary']['error_rate']}%",
                'details' =\u003e $metrics['api']['summary']
            ];
        }
        
        // 业务指标检查
        if (isset($metrics['business']['conversion_rate']) \u0026\u0026 $metrics['business']['conversion_rate'] \u003c 0.5) {
            $threshold_alerts[] = [
                'type' =\u003e 'conversion_rate_low',
                'severity' =\u003e 'warning',
                'message' =\u003e "转化率异常低: {$metrics['business']['conversion_rate']}%",
                'details' =\u003e $metrics['business']
            ];
        }
        
        return $threshold_alerts;
    }
    
    /**
     * 检测统计异常
     */
    private function detectStatisticalAnomalies($current_metrics, $trends) {
        $anomalies = [];
        
        // 基于Z-Score的异常检测
        $z_score_threshold = $this-\u003econfig['sensitivity_level'] === 'high' ? 2 : ($this-\u003econfig['sensitivity_level'] === 'medium' ? 3 : 4);
        
        // CPU异常检测
        if (isset($current_metrics['cpu']['usage_percent']) \u0026\u0026 isset($trends['24h']['cpu']['mean']) \u0026\u0026 isset($trends['24h']['cpu']['std_dev'])) {
            $z_score = abs(($current_metrics['cpu']['usage_percent'] - $trends['24h']['cpu']['mean']) / $trends['24h']['cpu']['std_dev']);
            if ($z_score \u003e $z_score_threshold \u0026\u0026 $current_metrics['cpu']['usage_percent'] \u003e $trends['24h']['cpu']['mean']) {
                $anomalies[] = [
                    'type' =\u003e 'cpu_anomaly',
                    'severity' =\u003e 'warning',
                    'message' =\u003e "CPU使用率异常 (Z-Score: {$z_score})",
                    'details' =\u003e ['current' =\u003e $current_metrics['cpu'], 'baseline' =\u003e $trends['24h']['cpu'], 'z_score' =\u003e $z_score]
                ];
            }
        }
        
        // 流量突增检测
        if (isset($current_metrics['api']['summary']['total_requests']) \u0026\u0026 isset($trends['24h']['api']['mean_requests'])) {
            $ratio = $current_metrics['api']['summary']['total_requests'] / $trends['24h']['api']['mean_requests'];
            if ($ratio \u003e 3) {
                $anomalies[] = [
                    'type' =\u003e 'traffic_spike',
                    'severity' =\u003e 'warning',
                    'message' =\u003e "请求流量突增 (正常的 {$ratio} 倍)",
                    'details' =\u003e ['current' =\u003e $current_metrics['api'], 'baseline' =\u003e $trends['24h']['api']]
                ];
            }
        }
        
        // 错误率异常检测
        if (isset($current_metrics['api']['summary']['error_rate']) \u0026\u0026 $current_metrics['api']['summary']['error_rate'] \u003e 5) {
            $anomalies[] = [
                'type' =\u003e 'error_rate_anomaly',
                'severity' =\u003e 'warning',
                'message' =\u003e "错误率异常增高: {$current_metrics['api']['summary']['error_rate']}%",
                'details' =\u003e $current_metrics['api']
            ];
        }
        
        return $anomalies;
    }
    
    /**
     * 检测规则异常
     */
    private function detectRuleBasedAnomalies($metrics) {
        $anomalies = [];
        
        // 检测潜在的DoS攻击
        if (isset($metrics['api']['summary']['total_requests']) \u0026\u0026 $metrics['api']['summary']['total_requests'] \u003e 10000) {
            $unique_ips = $this-\u003edb-\u003equery("SELECT COUNT(DISTINCT ip_address) as count FROM api_requests WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 MINUTE)")-\u003efetchColumn();
            
            if ($unique_ips \u003c $metrics['api']['summary']['total_requests'] * 0.1) { // 10%的IP贡献了大部分流量
                $anomalies[] = [
                    'type' =\u003e 'possible_dos',
                    'severity' =\u003e 'critical',
                    'message' =\u003e "可能存在DoS攻击: 流量集中于少数IP",
                    'details' =\u003e ['total_requests' =\u003e $metrics['api']['summary']['total_requests'], 'unique_ips' =\u003e $unique_ips]
                ];
            }
        }
        
        // 检测数据库连接泄漏
        $db_connections = $this-\u003edb-\u003equery("SELECT COUNT(*) as count FROM information_schema.processlist")-\u003efetchColumn();
        if ($db_connections \u003e 100) {
            $idle_connections = $this-\u003edb-\u003equery("SELECT COUNT(*) as count FROM information_schema.processlist WHERE command = 'Sleep' AND time \u003e 300")-\u003efetchColumn();
            
            if ($idle_connections \u003e $db_connections * 0.5) {
                $anomalies[] = [
                    'type' =\u003e 'db_connection_leak',
                    'severity' =\u003e 'warning',
                    'message' =\u003e "可能存在数据库连接泄漏: {$idle_connections}个空闲连接",
                    'details' =\u003e ['total_connections' =\u003e $db_connections, 'idle_connections' =\u003e $idle_connections]
                ];
            }
        }
        
        return $anomalies;
    }
    
    /**
     * 检测业务异常
     */
    private function detectBusinessAnomalies($business_metrics) {
        $anomalies = [];
        
        // 检测退款异常
        $refund_rate = $this-\u003edb-\u003equery("SELECT
            (SELECT COUNT(*) FROM orders WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY) AND status = 'refunded') as refunded,
            (SELECT COUNT(*) FROM orders WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 DAY)) as total
            ")-\u003efetch();
        
        if ($refund_rate['total'] \u003e 0) {
            $refund_percentage = ($refund_rate['refunded'] / $refund_rate['total']) * 100;
            if ($refund_percentage \u003e 20) { // 超过20%的退款率
                $anomalies[] = [
                    'type' =\u003e 'refund_anomaly',
                    'severity' =\u003e 'warning',
                    'message' =\u003e "退款率异常增高: {$refund_percentage}%",
                    'details' =\u003e ['refunded' =\u003e $refund_rate['refunded'], 'total' =\u003e $refund_rate['total']]
                ];
            }
        }
        
        // 检测登录失败异常
        $failed_logins = $this-\u003edb-\u003equery("SELECT COUNT(*) FROM auth_logs WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR) AND success = 0")-\u003efetchColumn();
        $total_logins = $this-\u003edb-\u003equery("SELECT COUNT(*) FROM auth_logs WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 1 HOUR)")-\u003efetchColumn();
        
        if ($total_logins \u003e 0) {
            $failure_rate = ($failed_logins / $total_logins) * 100;
            if ($failure_rate \u003e 30) { // 超过30%的失败率
                $anomalies[] = [
                    'type' =\u003e 'login_failure_anomaly',
                    'severity' =\u003e 'warning',
                    'message' =\u003e "登录失败率异常增高: {$failure_rate}%",
                    'details' =\u003e ['failed' =\u003e $failed_logins, 'total' =\u003e $total_logins]
                ];
            }
        }
        
        return $anomalies;
    }
    
    /**
     * 预测未来24小时性能
     */
    private function forecastNext24Hours($trends) {
        $forecast = [];
        $hourly_forecasts = [];
        
        // 简单的线性预测模型
        $metrics_to_forecast = ['cpu', 'memory', 'disk', 'api_requests', 'error_rate'];
        
        foreach ($metrics_to_forecast as $metric) {
            if (isset($trends['7d'][$metric])) {
                $historical = $trends['7d'][$metric]['data'] ?? [];
                
                if (!empty($historical)) {
                    // 计算趋势斜率
                    $slope = $this-\u003ecalculateLinearSlope($historical);
                    
                    // 预测未来24小时
                    $last_value = end($historical);
                    $hourly_values = [];
                    
                    for ($i = 1; $i \u003c= 24; $i++) {
                        $predicted = $last_value + ($slope * $i);
                        // 确保预测值在合理范围内
                        $predicted = max(0, min(100, $predicted));
                        $hourly_values[] = $predicted;
                    }
                    
                    $hourly_forecasts[$metric] = $hourly_values;
                    $forecast[$metric] = [
                        'trend' =\u003e $slope \u003e 0 ? 'increasing' : ($slope \u003c 0 ? 'decreasing' : 'stable'),
                        'projected_24h_avg' =\u003e array_sum($hourly_values) / count($hourly_values),
                        'projected_24h_max' =\u003e max($hourly_values),
                        'projected_24h_min' =\u003e min($hourly_values),
                        'hourly_forecast' =\u003e $hourly_values
                    ];
                }
            }
        }
        
        return $forecast;
    }
    
    /**
     * 发送告警通知
     */
    private function sendAlertNotifications($alert) {
        foreach ($this-\u003enotification_channels as $channel =\u003e $config) {
            if ($config['enabled']) {
                try {
                    call_user_func($config['send'], $alert, $config['settings']);
                } catch (Exception $e) {
                    $this-\u003elogMonitoringEvent('notification_failed', ['channel' =\u003e $channel, 'error' =\u003e $e-\u003egetMessage()]);
                }
            }
        }
    }
    
    /**
     * 发送邮件通知
     */
    private function sendEmailNotification($alert, $settings) {
        $subject = "[告警 - {$alert['severity']}] {$alert['message']}";
        $body = 
            "<h2>系统告警通知</h2>\n"
            . "<p><strong>告警ID:</strong> {$alert['id']}</p>\n"
            . "<p><strong>类型:</strong> {$alert['type']}</p>\n"
            . "<p><strong>级别:</strong> {$alert['severity']}</p>\n"
            . "<p><strong>消息:</strong> {$alert['message']}</p>\n"
            . "<p><strong>时间:</strong> " . date('Y-m-d H:i:s', $alert['timestamp']) . "</p>\n"
            . "<p><strong>详细信息:</strong></p>\n"
            . "<pre>" . json_encode($alert['details'], JSON_PRETTY_PRINT) . "</pre>\n"
            . "<p>请及时处理此告警。</p>\n";
        
        // 设置邮件头
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=utf-8',
            'From: Monitoring System <monitoring@example.com>',
        ];
        
        // 发送给所有收件人
        foreach ($settings['recipients'] as $recipient) {
            mail($recipient, $subject, $body, implode("\r\n", $headers));
        }
    }
    
    /**
     * 保存告警
     */
    private function saveAlert($alert) {
        $query = "INSERT INTO alerts (
            id, type, severity, message, details, timestamp, 
            status, acknowledged, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute([
            $alert['id'],
            $alert['type'],
            $alert['severity'],
            $alert['message'],
            json_encode($alert['details']),
            $alert['timestamp'],
            $alert['status'],
            $alert['acknowledged'] ? 1 : 0
        ]);
    }
    
    /**
     * 检查告警冷却
     */
    private function isAlertOnCooldown($alert_type) {
        // 这里可以使用Redis或内存缓存来跟踪告警冷却状态
        // 简化实现
        static $last_alert_time = [];
        
        if (isset($last_alert_time[$alert_type])) {
            return (time() - $last_alert_time[$alert_type]) \u003c $this-\u003econfig['alert_cooldown'];
        }
        
        return false;
    }
    
    /**
     * 设置告警冷却
     */
    private function setAlertCooldown($alert_type) {
        static $last_alert_time = [];
        $last_alert_time[$alert_type] = time();
    }
    
    /**
     * 获取性能摘要
     */
    private function getPerformanceSummary() {
        $summary = [
            'current_cpu' =\u003e $this-\u003eperformance_monitor-\u003 egetCPUUsage()['usage_percent'] ?? 0,
            'current_memory' =\u003e $this-\u003eperformance_monitor-\u003 egetMemoryUsage()['usage_percent'] ?? 0,
            'current_disk' =\u003e $this-\u003ecalculateAverageDiskUsage(),
            'current_load' =\u003e $this-\u003eperformance_monitor-\u003 egetCPUUsage()['load_1min'] ?? 0,
            'api_response_time' =\u003e $this-\u003ecollectApiMetrics()['summary']['avg_response_time'] ?? 0,
            'error_rate' =\u003e $this-\u003ecollectApiMetrics()['summary']['error_rate'] ?? 0,
            'active_users' =\u003e $this-\u003ecollectSessionMetrics()['unique_users'] ?? 0,
            'transaction_volume' =\u003e $this-\u003ecollectBusinessMetrics()['orders']['total_orders'] ?? 0,
        ];
        
        return $summary;
    }
    
    /**
     * 获取最近告警
     */
    private function getRecentAlerts($limit = 10) {
        $query = "SELECT * FROM alerts WHERE status != 'resolved' ORDER BY timestamp DESC LIMIT ?";
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute([$limit]);
        
        return $stmt-\u003efetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * 获取性能趋势
     */
    private function getPerformanceTrends($time_range) {
        return $this-\u003eperformance_monitor-\u003 egetHistoricalMetrics($time_range);
    }
    
    /**
     * 记录监控事件
     */
    private function logMonitoringEvent($event, $details = []) {
        $query = "INSERT INTO monitoring_events (event_type, details, created_at) VALUES (?, ?, NOW())";
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute([$event, json_encode($details)]);
    }
    
    /**
     * 计算平均磁盘使用率
     */
    private function calculateAverageDiskUsage() {
        $disks = $this-\u003eperformance_monitor-\u003 egetDiskUsage();
        if (empty($disks)) return 0;
        
        $total_usage = array_sum(array_column($disks, 'usage_percent'));
        return $total_usage / count($disks);
    }
    
    /**
     * 计算线性斜率
     */
    private function calculateLinearSlope($data_points) {
        $n = count($data_points);
        if ($n \u003c 2) return 0;
        
        $sum_x = 0; $sum_y = 0; $sum_xy = 0; $sum_x2 = 0;
        
        for ($i = 0; $i \u003c $n; $i++) {
            $sum_x += $i;
            $sum_y += $data_points[$i];
            $sum_xy += $i * $data_points[$i];
            $sum_x2 += $i * $i;
        }
        
        $slope = ($n * $sum_xy - $sum_x * $sum_y) / ($n * $sum_x2 - $sum_x * $sum_x);
        return $slope;
    }
    
    /**
     * 保存详细指标
     */
    private function saveDetailedMetrics($metrics) {
        // 保存到详细指标表
        $query = "INSERT INTO detailed_performance_metrics (timestamp, metrics, created_at) VALUES (?, ?, NOW())";
        $stmt = $this-\u003edb-\u003eprepare($query);
        $stmt-\u003eexecute([time(), json_encode($metrics)]);
    }
    
    /**
     * 加载自定义阈值
     */
    private function loadCustomThresholds() {
        try {
            $custom = $this-\u003edb-\u003equery("SELECT * FROM monitoring_thresholds WHERE active = 1")-\u003efetchAll();
            foreach ($custom as $threshold) {
                $this-\u003ethresholds[$threshold['metric_type']][$threshold['threshold_type']] = $threshold['value'];
            }
        } catch (Exception $e) {
            // 表可能不存在，忽略错误
        }
    }
    
    /**
     * 保存阈值
     */
    private function saveThresholds() {
        // 这里可以将阈值保存到数据库
    }
    
    /**
     * 保存通知设置
     */
    private function saveNotificationSettings() {
        // 这里可以将通知设置保存到数据库
    }
    
    /**
     * 更新性能基线
     */
    private function updatePerformanceBaseline($current_metrics, $trends) {
        // 更新性能基线数据，用于异常检测和预测
    }
    
    /**
     * 生成报告摘要
     */
    private function generateReportSummary($time_range) {
        // 生成性能报告摘要
        return ['generated_at' =\u003e date('Y-m-d H:i:s'), 'period' =\u003e $time_range, 'summary' =\u003e 'Performance report summary'];
    }
    
    /**
     * 获取详细指标
     */
    private function getDetailedMetrics($time_range) {
        $time_condition = $this-\u003egetTimeCondition($time_range);
        return $this-\u003edb-\u003equery("SELECT * FROM detailed_performance_metrics WHERE created_at \u003e= {$time_condition} ORDER BY timestamp DESC")-\u003efetchAll();
    }
    
    /**
     * 获取时间段内的异常
     */
    private function getAnomaliesDuringPeriod($time_range) {
        $time_condition = $this-\u003egetTimeCondition($time_range);
        return $this-\u003edb-\u003equery("SELECT * FROM alerts WHERE created_at \u003e= {$time_condition} ORDER BY severity DESC, timestamp DESC")-\u003efetchAll();
    }
    
    /**
     * 生成优化建议
     */
    private function generateOptimizationRecommendations() {
        $recommendations = [];
        
        // 基于性能数据生成优化建议
        $cpu_trend = $this-\u003egetPerformanceTrends('7d');
        if (isset($cpu_trend['cpu']['trend']) \u0026\u0026 $cpu_trend['cpu']['trend'] === 'increasing') {
            $recommendations[] = [
                'type' =\u003e 'resource_upgrade',
                'priority' =\u003e 'medium',
                'title' =\u003e 'CPU资源升级建议',
                'description' =\u003e 'CPU使用率呈上升趋势，建议考虑升级服务器CPU或增加服务器数量。',
                'impact' =\u003e 'high',
                'implementation_effort' =\u003e 'medium'
            ];
        }
        
        // 慢查询优化建议
        $slow_queries = $this-\u003edb-\u003equery("SELECT query_pattern, COUNT(*) as count FROM slow_queries WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY query_pattern ORDER BY count DESC LIMIT 5")-\u003efetchAll();
        
        foreach ($slow_queries as $query) {
            $recommendations[] = [
                'type' =\u003e 'query_optimization',
                'priority' =\u003e 'high',
                'title' =\u003e "慢查询优化建议: {$query['query_pattern']}",
                'description' =\u003e "此查询模式在过去7天内出现{$query['count']}次，建议优化SQL并添加适当索引。",
                'impact' =\u003e 'high',
                'implementation_effort' =\u003e 'low'
            ];
        }
        
        // 缓存优化建议
        $cache_metrics = $this-\u003ecollectCacheMetrics();
        if ($cache_metrics['miss_rate'] \u003e 40) {
            $recommendations[] = [
                'type' =\u003e 'cache_optimization',
                'priority' =\u003e 'medium',
                'title' =\u003e '缓存策略优化建议',
                'description' =\u003e "缓存未命中率过高({$cache_metrics['miss_rate']}%)，建议增加缓存键覆盖范围或延长缓存过期时间。",
                'impact' =\u003e 'medium',
                'implementation_effort' =\u003e 'low'
            ];
        }
        
        return $recommendations;
    }
    
    /**
     * 获取主要问题
     */
    private function getTopIssues() {
        $issues = [];
        
        // 基于告警频率和严重程度获取主要问题
        $top_alerts = $this-\u003edb-\u003equery("SELECT type, severity, COUNT(*) as count FROM alerts WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY type, severity ORDER BY count DESC, severity DESC LIMIT 5")-\u003efetchAll();
        
        foreach ($top_alerts as $alert) {
            $issues[] = [
                'type' =\u003e $alert['type'],
                'severity' =\u003e $alert['severity'],
                'occurrences' =\u003e $alert['count'],
                'description' =\u003e $this-\u003 egetIssueDescription($alert['type'])
            ];
        }
        
        return $issues;
    }
    
    /**
     * 获取问题描述
     */
    private function getIssueDescription($issue_type) {
        $descriptions = [
            'cpu_usage' =\u003e 'CPU使用率过高可能导致系统响应缓慢',
            'memory_usage' =\u003e '内存使用率过高可能导致系统不稳定或崩溃',
            'disk_usage' =\u003e '磁盘空间不足可能导致数据写入失败',
            'api_error_rate' =\u003e 'API错误率过高影响用户体验和系统可靠性',
            'api_response_time' =\u003e 'API响应时间过长影响用户体验',
        ];
        
        return $descriptions[$issue_type] ?? "检测到{$issue_type}问题";
    }
    
    /**
     * 计算时间条件
     */
    private function getTimeCondition($time_range) {
        switch ($time_range) {
            case '1h': return "DATE_SUB(NOW(), INTERVAL 1 HOUR)";
            case '6h': return "DATE_SUB(NOW(), INTERVAL 6 HOUR)";
            case '24h': return "DATE_SUB(NOW(), INTERVAL 1 DAY)";
            case '7d': return "DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case '30d': return "DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default: return "DATE_SUB(NOW(), INTERVAL 7 DAY)";
        }
    }
    
    /**
     * 获取周期比较
     */
    private function getPeriodComparison($time_range) {
        $comparison = [];
        
        // 获取当前周期数据
        $current_period = $this->getDetailedMetrics($time_range);
        
        // 获取上一周期数据
        $previous_period = $this->getPreviousPeriodMetrics($time_range);
        
        // 计算关键指标变化
        if (!empty($current_period) && !empty($previous_period)) {
            $comparison['cpu_usage_change'] = $this->calculatePercentageChange(
                $previous_period['cpu']['avg'], 
                $current_period['cpu']['avg']
            );
            
            $comparison['memory_usage_change'] = $this->calculatePercentageChange(
                $previous_period['memory']['avg'], 
                $current_period['memory']['avg']
            );
            
            $comparison['api_response_time_change'] = $this->calculatePercentageChange(
                $previous_period['api']['avg_response_time'], 
                $current_period['api']['avg_response_time']
            );
            
            $comparison['error_rate_change'] = $this->calculatePercentageChange(
                $previous_period['api']['error_rate'], 
                $current_period['api']['error_rate']
            );
            
            $comparison['transaction_volume_change'] = $this->calculatePercentageChange(
                $previous_period['business']['total_orders'], 
                $current_period['business']['total_orders']
            );
        }
        
        return $comparison;
    }
    
    /**
     * 获取上一周期指标
     */
    private function getPreviousPeriodMetrics($time_range) {
        // 获取上一周期的性能指标用于比较
        $days = $this->getTimeRangeDays($time_range);
        $start_date = date('Y-m-d', strtotime("-{$days} days"));
        $end_date = date('Y-m-d', strtotime("-1 day"));
        
        // 这里应该返回上一周期的指标
        return [];
    }
    
    /**
     * 计算时间范围天数
     */
    private function getTimeRangeDays($time_range) {
        switch ($time_range) {
            case '1h': return 1/24;
            case '6h': return 6/24;
            case '24h': return 1;
            case '7d': return 7;
            case '30d': return 30;
            default: return 7;
        }
    }
    
    /**
     * 计算百分比变化
     */
    private function calculatePercentageChange($previous, $current) {
        if ($previous == 0) return $current > 0 ? 100 : 0;
        return (($current - $previous) / $previous) * 100;
    }
    
    /**
     * 渲染HTML报告
     */
    private function renderHtmlReport($report_data) {
        $html = "<!DOCTYPE html>
        <html>
        <head>
            <title>性能监控报告</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }
                h1, h2 { color: #2c3e50; }
                .summary { background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
                .metric { margin-bottom: 10px; padding: 10px; border-bottom: 1px solid #eee; }
                .metric strong { color: #3498db; }
                .alert { padding: 10px; margin: 5px 0; border-radius: 3px; }
                .alert-warning { background: #fff3cd; border: 1px solid #ffeaa7; }
                .alert-critical { background: #f8d7da; border: 1px solid #f5c6cb; }
                table { width: 100%; border-collapse: collapse; }
                th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
                th { background-color: #f2f2f2; }
                .trend-up { color: #e74c3c; }
                .trend-down { color: #27ae60; }
                .recommendation { background: #e8f5e9; padding: 10px; border-left: 4px solid #4caf50; margin-bottom: 10px; }
            </style>
        </head>
        <body>
            <h1>系统性能监控报告</h1>
            <div class="summary">
                <p>报告生成时间: {$report_data['generated_at']}</p>
                <p>监控周期: {$report_data['period']}</p>
            </div>
            
            <h2>性能摘要</h2>
            <div class="metric"><strong>平均CPU使用率:</strong> {$report_data['summary']['cpu_usage']}%</div>
            <div class="metric"><strong>平均内存使用率:</strong> {$report_data['summary']['memory_usage']}%</div>
            <div class="metric"><strong>平均API响应时间:</strong> {$report_data['summary']['api_response_time']}ms</div>
            <div class="metric"><strong>错误率:</strong> {$report_data['summary']['error_rate']}%</div>
            
            <h2>异常事件</h2>";
        
        foreach ($report_data['anomalies'] as $alert) {
            $class = $alert['severity'] == 'critical' ? 'alert-critical' : 'alert-warning';
            $html .= "<div class='alert {$class}'>
                <strong>{$alert['message']}</strong><br>
                时间: " . date('Y-m-d H:i:s', $alert['timestamp']) . "<br>
                类型: {$alert['type']}
            </div>";
        }
        
        $html .= "<h2>优化建议</h2>";
        
        foreach ($report_data['recommendations'] as $rec) {
            $html .= "<div class='recommendation'>
                <strong>[{$rec['priority']}] {$rec['title']}</strong><br>
                {$rec['description']}
            </div>";
        }
        
        $html .= "</body></html>";
        
        return $html;
    }
    
    /**
     * 生成PDF报告
     */
    private function generatePdfReport($report_data) {
        // 这里可以集成PDF生成库，如TCPDF或FPDF
        // 简化实现，返回HTML版本
        return $this->renderHtmlReport($report_data);
    }
    
    /**
     * 计算环比变化
     */
    private function calculateDayOverDayChange() {
        // 计算日环比变化
        $today = $this->getPerformanceSummaryForDate(date('Y-m-d'));
        $yesterday = $this->getPerformanceSummaryForDate(date('Y-m-d', strtotime('-1 day')));
        
        return $this->calculateMetricsChange($yesterday, $today);
    }
    
    /**
     * 计算同比变化
     */
    private function calculateWeekOverWeekChange() {
        // 计算周同比变化
        $this_week = $this->getPerformanceSummaryForDateRange(
            date('Y-m-d', strtotime('-7 days')), 
            date('Y-m-d')
        );
        
        $last_week = $this->getPerformanceSummaryForDateRange(
            date('Y-m-d', strtotime('-14 days')), 
            date('Y-m-d', strtotime('-7 days'))
        );
        
        return $this->calculateMetricsChange($last_week, $this_week);
    }
    
    /**
     * 获取指定日期的性能摘要
     */
    private function getPerformanceSummaryForDate($date) {
        // 这里应该返回指定日期的性能摘要
        return [];
    }
    
    /**
     * 获取日期范围的性能摘要
     */
    private function getPerformanceSummaryForDateRange($start_date, $end_date) {
        // 这里应该返回日期范围的性能摘要
        return [];
    }
    
    /**
     * 计算指标变化
     */
    private function calculateMetricsChange($previous, $current) {
        // 计算两个时期之间的指标变化
        $changes = [];
        
        // 计算各种指标的变化
        $metrics_to_compare = ['cpu', 'memory', 'disk', 'api_response_time', 'error_rate', 'transaction_volume'];
        
        foreach ($metrics_to_compare as $metric) {
            if (isset($previous[$metric]) && isset($current[$metric])) {
                $changes[$metric] = $this->calculatePercentageChange($previous[$metric], $current[$metric]);
            }
        }
        
        return $changes;
    }
    
    /**
     * 获取详细指标
     */
    private function getDetailedMetrics($time_range) {
        // 获取详细的性能指标
        return [];
    }
    
    /**
     * 生成预测警告
     */
    private function generateForecastWarnings($forecast) {
        $warnings = [];
        
        // 检查预测中是否有潜在问题
        foreach ($forecast as $metric => $data) {
            if ($metric == 'cpu' && $data['projected_24h_max'] >= $this->thresholds['cpu']['warning']) {
                $warnings[] = [
                    'type' => 'cpu_forecast',
                    'message' => "预测CPU使用率将超过阈值",
                    'details' => [
                        'projected_max' => $data['projected_24h_max'],
                        'warning_threshold' => $this->thresholds['cpu']['warning'],
                        'expected_at' => $this->calculateProjectedTime($data, $this->thresholds['cpu']['warning'])
                    ]
                ];
            }
            
            if ($metric == 'memory' && $data['projected_24h_max'] >= $this->thresholds['memory']['warning']) {
                $warnings[] = [
                    'type' => 'memory_forecast',
                    'message' => "预测内存使用率将超过阈值",
                    'details' => [
                        'projected_max' => $data['projected_24h_max'],
                        'warning_threshold' => $this->thresholds['memory']['warning'],
                        'expected_at' => $this->calculateProjectedTime($data, $this->thresholds['memory']['warning'])
                    ]
                ];
            }
        }
        
        return $warnings;
    }
    
    /**
     * 计算预计达到时间
     */
    private function calculateProjectedTime($forecast_data, $threshold) {
        // 计算预计达到阈值的时间
        $hourly_values = $forecast_data['hourly_forecast'];
        
        for ($i = 0; $i < count($hourly_values); $i++) {
            if ($hourly_values[$i] >= $threshold) {
                return date('Y-m-d H:i:s', strtotime("+{$i} hours"));
            }
        }
        
        return null; // 24小时内不会达到阈值
    }
    
    /**
     * 获取顶部问题
     */
    private function getTopIssues() {
        // 获取系统中的主要问题
        $issues = [];
        
        // 从数据库获取主要问题
        $top_issues = $this->db->query("SELECT type, COUNT(*) as count FROM alerts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY type ORDER BY count DESC LIMIT 5")->fetchAll();
        
        foreach ($top_issues as $issue) {
            $issues[] = [
                'type' => $issue['type'],
                'count' => $issue['count'],
                'description' => $this->getIssueDescription($issue['type'])
            ];
        }
        
        return $issues;
    }
    
    /**
     * 计算趋势
     */
    private function calculateTrends($historical_data, $current_metrics) {
        $trends = [];
        
        // 计算各种指标的趋势
        $metrics_to_analyze = ['cpu', 'memory', 'disk', 'api', 'business'];
        
        foreach ($metrics_to_analyze as $metric) {
            if (isset($historical_data[$metric]) && !empty($historical_data[$metric])) {
                // 计算均值、标准差等统计信息
                $data_points = array_column($historical_data[$metric], 'value');
                $trends[$metric] = [
                    'mean' => array_sum($data_points) / count($data_points),
                    'std_dev' => $this->calculateStandardDeviation($data_points),
                    'min' => min($data_points),
                    'max' => max($data_points),
                    'trend' => $this->determineTrend($historical_data[$metric])
                ];
            }
        }
        
        return $trends;
    }
    
    /**
     * 计算标准差
     */
    private function calculateStandardDeviation($data) {
        $count = count($data);
        $mean = array_sum($data) / $count;
        $variance = 0;
        
        foreach ($data as $value) {
            $variance += pow(($value - $mean), 2);
        }
        
        return sqrt($variance / $count);
    }
    
    /**
     * 判断趋势
     */
    private function determineTrend($data_points) {
        $slope = $this->calculateLinearSlope(array_column($data_points, 'value'));
        
        if (abs($slope) < 0.1) return 'stable';
        return $slope > 0 ? 'increasing' : 'decreasing';
    }
}

// 辅助函数：数组排序
function array_sort($array, $key, $sort_flags = SORT_REGULAR) {
    if (!is_array($array)) return [];
    
    $keys = array_column($array, $key);
    array_multisort($keys, $sort_flags, $array);
    
    return $array;
})";
            case '30d': return "DATE_SUB(NOW(), INTERVAL 30 DAY