<?php

/**
 * 异步任务队列
 * 管理需要异步执行的任务，支持优先级、重试和状态跟踪
 */
class TaskQueue {
    /**
     * 任务状态常量
     */
    const STATUS_PENDING = 'pending';
    const STATUS_RUNNING = 'running';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';
    const STATUS_RETRYING = 'retrying';
    
    /**
     * 优先级常量
     */
    const PRIORITY_HIGH = 1;
    const PRIORITY_MEDIUM = 5;
    const PRIORITY_LOW = 10;
    
    /**
     * 任务队列存储文件
     */
    private $queueFile;
    
    /**
     * 队列锁文件
     */
    private $lockFile;
    
    /**
     * 构造函数
     * @param string $queueName 队列名称
     */
    public function __construct($queueName = 'default') {
        $queueDir = __DIR__ . '/../../storage/queue/';
        if (!is_dir($queueDir)) {
            mkdir($queueDir, 0755, true);
        }
        
        $this->queueFile = $queueDir . $queueName . '.json';
        $this->lockFile = $queueDir . $queueName . '.lock';
        
        // 初始化队列文件
        if (!file_exists($this->queueFile)) {
            file_put_contents($this->queueFile, json_encode([]));
        }
    }
    
    /**
     * 添加任务到队列
     * @param string $taskClass 任务类名
     * @param array $params 任务参数
     * @param int $priority 优先级
     * @param int $maxRetries 最大重试次数
     * @return string 任务ID
     */
    public function enqueue($taskClass, $params = [], $priority = self::PRIORITY_MEDIUM, $maxRetries = 3) {
        $this->acquireLock();
        
        try {
            // 读取队列
            $queue = $this->getQueue();
            
            // 创建任务
            $task = [
                'id' => uniqid('task_', true),
                'class' => $taskClass,
                'params' => $params,
                'priority' => $priority,
                'status' => self::STATUS_PENDING,
                'attempts' => 0,
                'max_retries' => $maxRetries,
                'created_at' => time(),
                'updated_at' => time()
            ];
            
            // 添加到队列
            $queue[] = $task;
            
            // 按优先级排序
            usort($queue, function($a, $b) {
                return $a['priority'] - $b['priority'];
            });
            
            // 保存队列
            $this->saveQueue($queue);
            
            return $task['id'];
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 获取下一个待执行任务
     * @return array|null 任务信息
     */
    public function dequeue() {
        $this->acquireLock();
        
        try {
            $queue = $this->getQueue();
            
            // 查找第一个待执行的任务
            foreach ($queue as $index => $task) {
                if ($task['status'] === self::STATUS_PENDING || $task['status'] === self::STATUS_RETRYING) {
                    // 更新任务状态为运行中
                    $queue[$index]['status'] = self::STATUS_RUNNING;
                    $queue[$index]['attempts']++;
                    $queue[$index]['updated_at'] = time();
                    $queue[$index]['started_at'] = time();
                    
                    // 保存队列
                    $this->saveQueue($queue);
                    
                    return $task;
                }
            }
            
            return null;
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 更新任务状态
     * @param string $taskId 任务ID
     * @param string $status 新状态
     * @param array $result 任务结果
     * @return bool 是否更新成功
     */
    public function updateTaskStatus($taskId, $status, $result = null) {
        $this->acquireLock();
        
        try {
            $queue = $this->getQueue();
            $updated = false;
            
            foreach ($queue as $index => $task) {
                if ($task['id'] === $taskId) {
                    $queue[$index]['status'] = $status;
                    $queue[$index]['updated_at'] = time();
                    
                    if ($result !== null) {
                        $queue[$index]['result'] = $result;
                    }
                    
                    if ($status === self::STATUS_COMPLETED || $status === self::STATUS_FAILED) {
                        $queue[$index]['completed_at'] = time();
                    }
                    
                    $updated = true;
                    break;
                }
            }
            
            if ($updated) {
                $this->saveQueue($queue);
            }
            
            return $updated;
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 重试失败的任务
     * @param string $taskId 任务ID
     * @return bool 是否成功重试
     */
    public function retryTask($taskId) {
        $this->acquireLock();
        
        try {
            $queue = $this->getQueue();
            $retryable = false;
            
            foreach ($queue as $index => $task) {
                if ($task['id'] === $taskId && $task['status'] === self::STATUS_FAILED) {
                    // 检查是否还可以重试
                    if ($task['attempts'] < $task['max_retries']) {
                        $queue[$index]['status'] = self::STATUS_RETRYING;
                        $queue[$index]['updated_at'] = time();
                        $retryable = true;
                    }
                    break;
                }
            }
            
            if ($retryable) {
                $this->saveQueue($queue);
            }
            
            return $retryable;
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 获取任务信息
     * @param string $taskId 任务ID
     * @return array|null 任务信息
     */
    public function getTask($taskId) {
        $queue = $this->getQueue();
        
        foreach ($queue as $task) {
            if ($task['id'] === $taskId) {
                return $task;
            }
        }
        
        return null;
    }
    
    /**
     * 获取队列中的任务数量
     * @param string $status 按状态筛选
     * @return int 任务数量
     */
    public function getTaskCount($status = null) {
        $queue = $this->getQueue();
        
        if ($status === null) {
            return count($queue);
        }
        
        $count = 0;
        foreach ($queue as $task) {
            if ($task['status'] === $status) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * 清理已完成的任务
     * @param int $maxAge 最大保留时间（秒）
     */
    public function cleanup($maxAge = 86400) {
        $this->acquireLock();
        
        try {
            $queue = $this->getQueue();
            $now = time();
            
            // 保留未完成的任务和最近完成的任务
            $queue = array_filter($queue, function($task) use ($now, $maxAge) {
                if ($task['status'] === self::STATUS_COMPLETED || $task['status'] === self::STATUS_FAILED) {
                    $completedAt = isset($task['completed_at']) ? $task['completed_at'] : $task['updated_at'];
                    return ($now - $completedAt) < $maxAge;
                }
                return true;
            });
            
            $this->saveQueue(array_values($queue));
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 获取队列内容
     * @return array 队列数据
     */
    private function getQueue() {
        $content = file_get_contents($this->queueFile);
        return json_decode($content, true) ?: [];
    }
    
    /**
     * 保存队列内容
     * @param array $queue 队列数据
     */
    private function saveQueue($queue) {
        file_put_contents($this->queueFile, json_encode($queue));
    }
    
    /**
     * 获取文件锁
     */
    private function acquireLock() {
        $maxAttempts = 10;
        $attempt = 0;
        
        while ($attempt < $maxAttempts) {
            if (!file_exists($this->lockFile)) {
                file_put_contents($this->lockFile, getmypid());
                return;
            }
            
            // 检查锁是否过期（超过30秒）
            $lockTime = filemtime($this->lockFile);
            if (time() - $lockTime > 30) {
                unlink($this->lockFile);
                continue;
            }
            
            $attempt++;
            usleep(100000); // 等待100ms
        }
        
        throw new Exception('无法获取队列锁，请稍后再试');
    }
    
    /**
     * 释放文件锁
     */
    private function releaseLock() {
        if (file_exists($this->lockFile)) {
            unlink($this->lockFile);
        }
    }
}