<?php

require_once __DIR__ . '/TaskQueue.php';
require_once __DIR__ . '/Task.php';

/**
 * 任务调度器
 * 负责任务队列中任务的实际执行和管理
 */
class TaskScheduler {
    /**
     * 调度器实例
     */
    private static $instance;
    
    /**
     * 任务队列
     */
    private $queue;
    
    /**
     * 最大并发任务数
     */
    private $maxConcurrentTasks = 1;
    
    /**
     * 当前运行的任务
     */
    private $runningTasks = [];
    
    /**
     * 日志文件
     */
    private $logFile;
    
    /**
     * 构造函数
     * @param string $queueName 队列名称
     * @param int $maxConcurrentTasks 最大并发任务数
     */
    private function __construct($queueName = 'default', $maxConcurrentTasks = 1) {
        $this->queue = new TaskQueue($queueName);
        $this->maxConcurrentTasks = $maxConcurrentTasks;
        
        // 设置日志文件
        $logDir = __DIR__ . '/../../storage/logs/';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        $this->logFile = $logDir . 'task_scheduler.log';
    }
    
    /**
     * 获取调度器单例
     * @param string $queueName 队列名称
     * @param int $maxConcurrentTasks 最大并发任务数
     * @return TaskScheduler 调度器实例
     */
    public static function getInstance($queueName = 'default', $maxConcurrentTasks = 1) {
        if (!self::$instance) {
            self::$instance = new TaskScheduler($queueName, $maxConcurrentTasks);
        }
        return self::$instance;
    }
    
    /**
     * 运行调度器
     * @param int $runTime 运行时间（秒），0表示无限运行
     */
    public function run($runTime = 0) {
        $this->log("调度器启动，最大并发任务数: {$this->maxConcurrentTasks}");
        
        $startTime = time();
        
        try {
            while (true) {
                // 检查运行时间
                if ($runTime > 0 && (time() - $startTime) > $runTime) {
                    break;
                }
                
                // 清理过期的任务记录
                $this->cleanupRunningTasks();
                
                // 执行新任务
                $this->executePendingTasks();
                
                // 短暂休息，避免CPU占用过高
                usleep(100000); // 100ms
            }
        } catch (Exception $e) {
            $this->log("调度器异常: " . $e->getMessage(), 'error');
        }
        
        $this->log("调度器停止");
    }
    
    /**
     * 执行待处理的任务
     */
    private function executePendingTasks() {
        // 检查是否还有并发槽位
        if (count($this->runningTasks) >= $this->maxConcurrentTasks) {
            return;
        }
        
        // 从队列获取任务
        $taskInfo = $this->queue->dequeue();
        
        if (!$taskInfo) {
            return;
        }
        
        $this->log("开始执行任务: {$taskInfo['id']} ({$taskInfo['class']})");
        
        // 记录运行中的任务
        $this->runningTasks[$taskInfo['id']] = time();
        
        // 执行任务
        $this->executeTask($taskInfo);
    }
    
    /**
     * 执行单个任务
     * @param array $taskInfo 任务信息
     */
    private function executeTask($taskInfo) {
        try {
            // 动态加载任务类
            $taskClass = $taskInfo['class'];
            
            if (!class_exists($taskClass)) {
                throw new Exception("任务类不存在: {$taskClass}");
            }
            
            if (!is_subclass_of($taskClass, 'Task')) {
                throw new Exception("任务类必须继承Task基类: {$taskClass}");
            }
            
            // 创建任务实例并执行
            $task = new $taskClass($taskInfo['params'], $taskInfo['id']);
            
            // 执行任务
            $result = Task::execute($taskClass, $taskInfo['params']);
            
            // 更新任务状态为完成
            $this->queue->updateTaskStatus($taskInfo['id'], TaskQueue::STATUS_COMPLETED, $result);
            $this->log("任务完成: {$taskInfo['id']}");
            
        } catch (Exception $e) {
            $error = $e->getMessage();
            $this->log("任务失败: {$taskInfo['id']} - {$error}", 'error');
            
            // 检查是否需要重试
            if ($taskInfo['attempts'] < $taskInfo['max_retries']) {
                $this->queue->updateTaskStatus($taskInfo['id'], TaskQueue::STATUS_RETRYING, ['error' => $error]);
                $this->log("任务将重试: {$taskInfo['id']} (尝试次数: {$taskInfo['attempts']}/{$taskInfo['max_retries']})");
            } else {
                $this->queue->updateTaskStatus($taskInfo['id'], TaskQueue::STATUS_FAILED, ['error' => $error]);
                $this->log("任务达到最大重试次数: {$taskInfo['id']}", 'error');
            }
        } finally {
            // 从运行中任务列表移除
            unset($this->runningTasks[$taskInfo['id']]);
        }
    }
    
    /**
     * 清理运行中的任务记录
     */
    private function cleanupRunningTasks() {
        $now = time();
        
        foreach ($this->runningTasks as $taskId => $startTime) {
            // 检查是否有长时间运行的任务（超过1小时）
            if ($now - $startTime > 3600) {
                $this->log("检测到长时间运行的任务: {$taskId}", 'warning');
                
                // 获取任务信息
                $taskInfo = $this->queue->getTask($taskId);
                
                if ($taskInfo && $taskInfo['status'] === TaskQueue::STATUS_RUNNING) {
                    // 标记为需要重试
                    if ($taskInfo['attempts'] < $taskInfo['max_retries']) {
                        $this->queue->updateTaskStatus($taskId, TaskQueue::STATUS_RETRYING);
                    } else {
                        $this->queue->updateTaskStatus($taskId, TaskQueue::STATUS_FAILED);
                    }
                    
                    unset($this->runningTasks[$taskId]);
                }
            }
        }
    }
    
    /**
     * 添加任务到队列
     * @param string $taskClass 任务类名
     * @param array $params 任务参数
     * @param int $priority 优先级
     * @param int $maxRetries 最大重试次数
     * @return string 任务ID
     */
    public function scheduleTask($taskClass, $params = [], $priority = TaskQueue::PRIORITY_MEDIUM, $maxRetries = 3) {
        $taskId = $this->queue->enqueue($taskClass, $params, $priority, $maxRetries);
        $this->log("任务已调度: {$taskId} ({$taskClass})");
        return $taskId;
    }
    
    /**
     * 获取任务状态
     * @param string $taskId 任务ID
     * @return array|null 任务信息
     */
    public function getTaskStatus($taskId) {
        return $this->queue->getTask($taskId);
    }
    
    /**
     * 记录日志
     * @param string $message 日志消息
     * @param string $level 日志级别
     */
    private function log($message, $level = 'info') {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] [{$level}] {$message}\n";
        
        // 写入日志文件
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
        
        // 同时输出到标准输出
        echo $logMessage;
    }
    
    /**
     * 清理过期任务
     * @param int $maxAge 最大保留时间（秒）
     */
    public function cleanupTasks($maxAge = 86400) {
        $this->queue->cleanup($maxAge);
        $this->log("清理完成，保留时间: {$maxAge}秒");
    }
    
    /**
     * 获取队列统计信息
     * @return array 统计信息
     */
    public function getQueueStats() {
        return [
            'pending' => $this->queue->getTaskCount(TaskQueue::STATUS_PENDING),
            'running' => $this->queue->getTaskCount(TaskQueue::STATUS_RUNNING),
            'completed' => $this->queue->getTaskCount(TaskQueue::STATUS_COMPLETED),
            'failed' => $this->queue->getTaskCount(TaskQueue::STATUS_FAILED),
            'retrying' => $this->queue->getTaskCount(TaskQueue::STATUS_RETRYING),
            'total' => $this->queue->getTaskCount()
        ];
    }
    
    /**
     * 命令行运行入口
     * @param array $argv 命令行参数
     */
    public static function main($argv) {
        $queueName = isset($argv[1]) ? $argv[1] : 'default';
        $maxConcurrent = isset($argv[2]) ? intval($argv[2]) : 1;
        $runTime = isset($argv[3]) ? intval($argv[3]) : 0;
        
        echo "启动任务调度器\n";
        echo "队列名称: {$queueName}\n";
        echo "最大并发任务: {$maxConcurrent}\n";
        echo "运行时间: " . ($runTime > 0 ? "{$runTime}秒" : "无限") . "\n";
        echo "===============================\n";
        
        $scheduler = self::getInstance($queueName, $maxConcurrent);
        $scheduler->run($runTime);
    }
}

// 如果直接运行此脚本
if (basename(__FILE__) == basename($_SERVER['PHP_SELF'])) {
    TaskScheduler::main($argv);
}