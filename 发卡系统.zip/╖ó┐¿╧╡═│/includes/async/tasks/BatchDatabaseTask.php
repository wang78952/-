<?php

require_once __DIR__ . '/../Task.php';

/**
 * 数据库批量操作任务
 * 用于异步处理大型数据库操作，支持分片执行
 */
class BatchDatabaseTask extends Task {
    /**
     * 每个批次的大小
     */
    const DEFAULT_BATCH_SIZE = 1000;
    
    /**
     * 数据库连接
     */
    private $db;
    
    /**
     * 任务配置
     */
    protected $config = [
        'batch_size' => self::DEFAULT_BATCH_SIZE,
        'table' => '',
        'operation' => 'update', // update, delete, insert
        'condition' => '',
        'data_mapper' => null,
        'total_records' => null
    ];
    
    /**
     * 构造函数
     * @param array $params 任务参数
     * @param string $taskId 任务ID
     */
    public function __construct($params = [], $taskId = null) {
        parent::__construct($params, $taskId);
        
        // 合并配置
        if (isset($params['config'])) {
            $this->config = array_merge($this->config, $params['config']);
        }
    }
    
    /**
     * 准备工作
     */
    public function prepare() {
        parent::prepare();
        
        // 建立数据库连接
        $this->connectToDatabase();
        
        // 估算总记录数
        if ($this->config['total_records'] === null) {
            $this->config['total_records'] = $this->estimateTotalRecords();
        }
    }
    
    /**
     * 运行任务
     * @return array 执行结果
     */
    public function run() {
        $startTime = microtime(true);
        $processedCount = 0;
        $totalCount = $this->config['total_records'];
        
        try {
            // 根据操作类型执行不同的批量处理
            switch ($this->config['operation']) {
                case 'update':
                    $processedCount = $this->batchUpdate();
                    break;
                case 'delete':
                    $processedCount = $this->batchDelete();
                    break;
                case 'insert':
                    $processedCount = $this->batchInsert();
                    break;
                case 'export':
                    $processedCount = $this->batchExport();
                    break;
                default:
                    throw new Exception("不支持的操作类型: " . $this->config['operation']);
            }
            
            $endTime = microtime(true);
            $duration = $endTime - $startTime;
            
            return [
                'status' => 'success',
                'processed_count' => $processedCount,
                'total_count' => $totalCount,
                'duration' => round($duration, 2),
                'records_per_second' => round($processedCount / $duration, 2)
            ];
        } catch (Exception $e) {
            $this->setProgress(0);
            throw $e;
        }
    }
    
    /**
     * 批量更新操作
     * @return int 处理的记录数
     */
    private function batchUpdate() {
        $table = $this->config['table'];
        $condition = $this->config['condition'] ? " WHERE " . $this->config['condition'] : '';
        $batchSize = $this->config['batch_size'];
        $totalCount = $this->config['total_records'];
        $processed = 0;
        
        // 使用主键进行分页处理
        $lastId = 0;
        
        while (true) {
            // 查询当前批次的数据
            $pageCondition = $lastId > 0 ? " AND id > {$lastId}" : '';
            $query = "SELECT * FROM {$table}{$condition}{$pageCondition} ORDER BY id LIMIT {$batchSize}";
            
            $result = $this->db->query($query);
            $records = [];
            
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
                $lastId = max($lastId, $row['id']);
            }
            
            if (empty($records)) {
                break;
            }
            
            // 开始事务
            $this->db->begin_transaction();
            
            try {
                // 处理每条记录
                foreach ($records as $record) {
                    // 应用数据映射函数
                    $updateData = $this->applyDataMapper($record);
                    
                    if (!empty($updateData)) {
                        $this->updateRecord($table, $record['id'], $updateData);
                    }
                }
                
                // 提交事务
                $this->db->commit();
                
                $processed += count($records);
                
                // 更新进度
                $progress = $totalCount > 0 ? intval(($processed / $totalCount) * 100) : 0;
                $this->setProgress($progress);
                
            } catch (Exception $e) {
                $this->db->rollback();
                throw $e;
            }
            
            // 短暂休息，避免数据库压力过大
            usleep(100000); // 100ms
        }
        
        return $processed;
    }
    
    /**
     * 批量删除操作
     * @return int 删除的记录数
     */
    private function batchDelete() {
        $table = $this->config['table'];
        $condition = $this->config['condition'] ? " WHERE " . $this->config['condition'] : '';
        $batchSize = $this->config['batch_size'];
        $totalCount = $this->config['total_records'];
        $deleted = 0;
        
        // 使用主键进行分页删除
        $lastId = 0;
        
        while (true) {
            $pageCondition = $lastId > 0 ? " AND id > {$lastId}" : '';
            $deleteQuery = "DELETE FROM {$table}{$condition}{$pageCondition} ORDER BY id LIMIT {$batchSize}";
            
            $result = $this->db->query($deleteQuery);
            $affectedRows = $this->db->affected_rows;
            
            if ($affectedRows === 0) {
                break;
            }
            
            $deleted += $affectedRows;
            
            // 更新进度
            $progress = $totalCount > 0 ? intval(($deleted / $totalCount) * 100) : 0;
            $this->setProgress($progress);
            
            // 短暂休息
            usleep(100000);
        }
        
        return $deleted;
    }
    
    /**
     * 批量插入操作
     * @return int 插入的记录数
     */
    private function batchInsert() {
        $table = $this->config['table'];
        $batchSize = $this->config['batch_size'];
        $data = $this->params['data'] ?? [];
        $inserted = 0;
        $totalRecords = count($data);
        
        // 分片插入
        for ($i = 0; $i < $totalRecords; $i += $batchSize) {
            $batchData = array_slice($data, $i, $batchSize);
            
            if (empty($batchData)) {
                continue;
            }
            
            // 开始事务
            $this->db->begin_transaction();
            
            try {
                foreach ($batchData as $record) {
                    $this->insertRecord($table, $record);
                }
                
                $this->db->commit();
                $inserted += count($batchData);
                
                // 更新进度
                $progress = intval(($inserted / $totalRecords) * 100);
                $this->setProgress($progress);
                
            } catch (Exception $e) {
                $this->db->rollback();
                throw $e;
            }
            
            // 短暂休息
            usleep(100000);
        }
        
        return $inserted;
    }
    
    /**
     * 批量导出操作
     * @return int 导出的记录数
     */
    private function batchExport() {
        $table = $this->config['table'];
        $condition = $this->config['condition'] ? " WHERE " . $this->config['condition'] : '';
        $batchSize = $this->config['batch_size'];
        $outputFile = $this->params['output_file'] ?? tempnam(sys_get_temp_dir(), 'export_');
        $exported = 0;
        $totalCount = $this->config['total_records'];
        
        // 准备输出文件
        $fileHandle = fopen($outputFile, 'w');
        if (!$fileHandle) {
            throw new Exception("无法打开输出文件: {$outputFile}");
        }
        
        try {
            // 使用主键分页导出
            $lastId = 0;
            $headersWritten = false;
            
            while (true) {
                $pageCondition = $lastId > 0 ? " AND id > {$lastId}" : '';
                $query = "SELECT * FROM {$table}{$condition}{$pageCondition} ORDER BY id LIMIT {$batchSize}";
                
                $result = $this->db->query($query);
                $records = [];
                
                while ($row = $result->fetch_assoc()) {
                    $records[] = $row;
                    $lastId = max($lastId, $row['id']);
                }
                
                if (empty($records)) {
                    break;
                }
                
                // 写入CSV头部
                if (!$headersWritten) {
                    fputcsv($fileHandle, array_keys($records[0]));
                    $headersWritten = true;
                }
                
                // 写入数据
                foreach ($records as $record) {
                    fputcsv($fileHandle, $record);
                }
                
                $exported += count($records);
                
                // 更新进度
                $progress = $totalCount > 0 ? intval(($exported / $totalCount) * 100) : 0;
                $this->setProgress($progress);
                
                // 短暂休息
                usleep(100000);
            }
            
            return [
                'exported_count' => $exported,
                'file_path' => $outputFile,
                'file_size' => filesize($outputFile)
            ];
        } finally {
            fclose($fileHandle);
        }
    }
    
    /**
     * 连接数据库
     */
    private function connectToDatabase() {
        $dbConfig = $this->params['database'] ?? include(__DIR__ . '/../../../config/database.php');
        
        $this->db = new mysqli(
            $dbConfig['host'],
            $dbConfig['username'],
            $dbConfig['password'],
            $dbConfig['database']
        );
        
        if ($this->db->connect_error) {
            throw new Exception("数据库连接失败: " . $this->db->connect_error);
        }
        
        // 设置字符集
        $this->db->set_charset("utf8mb4");
    }
    
    /**
     * 估算总记录数
     * @return int 记录数
     */
    private function estimateTotalRecords() {
        $table = $this->config['table'];
        $condition = $this->config['condition'] ? " WHERE " . $this->config['condition'] : '';
        
        $query = "SELECT COUNT(*) as count FROM {$table}{$condition}";
        $result = $this->db->query($query);
        $row = $result->fetch_assoc();
        
        return $row['count'];
    }
    
    /**
     * 应用数据映射函数
     * @param array $record 原始记录
     * @return array 映射后的数据
     */
    private function applyDataMapper($record) {
        $mapper = $this->config['data_mapper'];
        
        if (is_callable($mapper)) {
            return $mapper($record);
        } elseif (is_array($mapper)) {
            // 简单的字段映射
            $result = [];
            foreach ($mapper as $field => $value) {
                $result[$field] = is_callable($value) ? $value($record) : $value;
            }
            return $result;
        }
        
        return [];
    }
    
    /**
     * 更新单条记录
     * @param string $table 表名
     * @param int $id 记录ID
     * @param array $data 更新数据
     */
    private function updateRecord($table, $id, $data) {
        $fields = [];
        $values = [];
        
        foreach ($data as $field => $value) {
            $fields[] = "{$field} = ?";
            $values[] = $value;
        }
        
        $fieldsStr = implode(', ', $fields);
        $query = "UPDATE {$table} SET {$fieldsStr} WHERE id = ?";
        $values[] = $id;
        
        $stmt = $this->db->prepare($query);
        $this->bindParams($stmt, $values);
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * 插入单条记录
     * @param string $table 表名
     * @param array $data 记录数据
     */
    private function insertRecord($table, $data) {
        $fields = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $query = "INSERT INTO {$table} ({$fields}) VALUES ({$placeholders})";
        
        $stmt = $this->db->prepare($query);
        $this->bindParams($stmt, array_values($data));
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * 绑定预处理语句参数
     * @param mysqli_stmt $stmt 预处理语句
     * @param array $params 参数数组
     */
    private function bindParams($stmt, $params) {
        if (empty($params)) {
            return;
        }
        
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    /**
     * 清理工作
     */
    public function cleanup() {
        parent::cleanup();
        
        // 关闭数据库连接
        if ($this->db) {
            $this->db->close();
        }
    }
}