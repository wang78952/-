<?php

/**
 * 任务基类
 * 所有异步任务必须继承此类并实现run方法
 */
abstract class Task {
    /**
     * 任务参数
     */
    protected $params;
    
    /**
     * 任务ID
     */
    protected $taskId;
    
    /**
     * 构造函数
     * @param array $params 任务参数
     * @param string $taskId 任务ID
     */
    public function __construct($params = [], $taskId = null) {
        $this->params = $params;
        $this->taskId = $taskId;
    }
    
    /**
     * 任务执行方法
     * @return mixed 任务结果
     * @throws Exception 任务执行异常
     */
    abstract public function run();
    
    /**
     * 获取任务名称
     * @return string 任务名称
     */
    public function getName() {
        return get_class($this);
    }
    
    /**
     * 获取任务ID
     * @return string 任务ID
     */
    public function getTaskId() {
        return $this->taskId;
    }
    
    /**
     * 获取任务参数
     * @return array 任务参数
     */
    public function getParams() {
        return $this->params;
    }
    
    /**
     * 设置任务进度
     * @param int $progress 进度百分比(0-100)
     */
    public function setProgress($progress) {
        // 记录进度到日志
        if ($this->taskId) {
            $progress = min(max(intval($progress), 0), 100);
            error_log("Task {$this->taskId} ({$this->getName()}): {$progress}% complete");
        }
    }
    
    /**
     * 任务开始前的准备工作
     */
    public function prepare() {
        // 默认实现，可以被子类重写
    }
    
    /**
     * 任务执行后的清理工作
     */
    public function cleanup() {
        // 默认实现，可以被子类重写
    }
    
    /**
     * 任务失败时的处理
     * @param Exception $exception 异常信息
     * @return bool 是否应该重试
     */
    public function onFailure($exception) {
        // 默认实现，可以被子类重写
        error_log("Task failed: " . $exception->getMessage());
        return false; // 默认不重试
    }
    
    /**
     * 静态方法：执行单个任务
     * @param string $taskClass 任务类名
     * @param array $params 任务参数
     * @return mixed 任务结果
     */
    public static function execute($taskClass, $params = []) {
        if (!class_exists($taskClass)) {
            throw new Exception("任务类不存在: {$taskClass}");
        }
        
        if (!is_subclass_of($taskClass, 'Task')) {
            throw new Exception("任务类必须继承Task基类: {$taskClass}");
        }
        
        $task = new $taskClass($params);
        
        try {
            $task->prepare();
            $result = $task->run();
            return $result;
        } catch (Exception $e) {
            if ($task->onFailure($e)) {
                throw $e; // 抛出异常以便调用者重试
            }
            return null;
        } finally {
            try {
                $task->cleanup();
            } catch (Exception $e) {
                error_log("Task cleanup failed: " . $e->getMessage());
            }
        }
    }
}