<?php

require_once __DIR__ . '/PaymentManager.php';

/**
 * 微信支付集成
 */
class WechatPayment
    private $config;
    private $gateway;
    
    public function __construct($config)
    {
        $this->config = $config;
        $this->gateway = 'https://api.mch.weixin.qq.com';
    }
    
    /**
     * 创建统一下单
     */
    public function createOrder($params)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'nonce_str' => $this->generateNonceStr(),
            'body' => $params['subject'],
            'out_trade_no' => $params['out_trade_no'],
            'total_fee' => (int)($params['total_amount'] * 100), // 转换为分
            'spbill_create_ip' => $this->getClientIp(),
            'notify_url' => $params['notify_url'],
            'trade_type' => 'NATIVE' // 默认扫码支付
        );
        
        // 添加可选参数
        if (isset($params['extra']['openid'])) {
            $requestParams['trade_type'] = 'JSAPI';
            $requestParams['openid'] = $params['extra']['openid'];
        }
        
        // 生成签名
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        // 发送请求
        $response = $this->httpRequest($this->gateway . '/pay/unifiedorder', $requestParams);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS') {
            throw new Exception('微信支付统一下单失败：' . $result['return_msg']);
        }
        
        if ($result['result_code'] !== 'SUCCESS') {
            throw new Exception('微信支付统一下单失败：' . $result['err_code_des']);
        }
        
        // 根据支付类型返回不同结果
        if ($requestParams['trade_type'] === 'NATIVE') {
            return array(
                'qr_code' => $result['code_url'],
                'prepay_id' => $result['prepay_id'],
                'out_trade_no' => $params['out_trade_no']
            );
        } elseif ($requestParams['trade_type'] === 'JSAPI') {
            return array(
                'prepay_id' => $result['prepay_id'],
                'jsapi_params' => $this->generateJsApiParams($result['prepay_id']),
                'out_trade_no' => $params['out_trade_no']
            );
        }
        
        return $result;
    }
    
    /**
     * 创建H5支付订单
     */
    public function createH5Order($params)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'nonce_str' => $this->generateNonceStr(),
            'body' => $params['subject'],
            'out_trade_no' => $params['out_trade_no'],
            'total_fee' => (int)($params['total_amount'] * 100),
            'spbill_create_ip' => $this->getClientIp(),
            'notify_url' => $params['notify_url'],
            'trade_type' => 'MWEB',
            'scene_info' => json_encode(array(
                'h5_info' => array(
                    'type' => 'Wap',
                    'wap_url' => isset($params['extra']['wap_url']) ? $params['extra']['wap_url'] : '',
                    'wap_name' => isset($params['extra']['wap_name']) ? $params['extra']['wap_name'] : '发卡系统'
                )
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway . '/pay/unifiedorder', $requestParams);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS' || $result['result_code'] !== 'SUCCESS') {
            throw new Exception('微信H5支付创建失败：' . (isset($result['err_code_des']) ? $result['err_code_des'] : $result['return_msg']));
        }
        
        return array(
            'payment_url' => $result['mweb_url'],
            'out_trade_no' => $params['out_trade_no']
        );
    }
    
    /**
     * 创建APP支付订单
     */
    public function createAppOrder($params)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'nonce_str' => $this->generateNonceStr(),
            'body' => $params['subject'],
            'out_trade_no' => $params['out_trade_no'],
            'total_fee' => (int)($params['total_amount'] * 100),
            'spbill_create_ip' => $this->getClientIp(),
            'notify_url' => $params['notify_url'],
            'trade_type' => 'APP'
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway . '/pay/unifiedorder', $requestParams);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS' || $result['result_code'] !== 'SUCCESS') {
            throw new Exception('微信APP支付创建失败：' . (isset($result['err_code_des']) ? $result['err_code_des'] : $result['return_msg']));
        }
        
        return array(
            'prepay_id' => $result['prepay_id'],
            'app_params' => $this->generateAppParams($result['prepay_id']),
            'out_trade_no' => $params['out_trade_no']
        );
    }
    
    /**
     * 查询支付状态
     */
    public function query($outTradeNo)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'out_trade_no' => $outTradeNo,
            'nonce_str' => $this->generateNonceStr()
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway . '/pay/orderquery', $requestParams);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS') {
            throw new Exception('微信支付查询失败：' . $result['return_msg']);
        }
        
        return $result;
    }
    
    /**
     * 申请退款
     */
    public function refund($params)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'nonce_str' => $this->generateNonceStr(),
            'out_trade_no' => $params['out_trade_no'],
            'out_refund_no' => $params['refund_no'],
            'total_fee' => (int)($params['total_amount'] * 100),
            'refund_fee' => (int)($params['refund_amount'] * 100),
            'refund_desc' => isset($params['refund_reason']) ? $params['refund_reason'] : ''
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        // 需要使用证书
        $response = $this->httpRequest($this->gateway . '/secapi/pay/refund', $requestParams, true);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS') {
            throw new Exception('微信退款申请失败：' . $result['return_msg']);
        }
        
        if ($result['result_code'] !== 'SUCCESS') {
            throw new Exception('微信退款申请失败：' . $result['err_code_des']);
        }
        
        return $result;
    }
    
    /**
     * 查询退款状态
     */
    public function queryRefund($refundNo)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'nonce_str' => $this->generateNonceStr(),
            'out_refund_no' => $refundNo
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway . '/pay/refundquery', $requestParams);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS') {
            throw new Exception('微信退款查询失败：' . $result['return_msg']);
        }
        
        return $result;
    }
    
    /**
     * 关闭订单
     */
    public function close($outTradeNo)
    {
        $requestParams = array(
            'appid' => $this->config['app_id'],
            'mch_id' => $this->config['mch_id'],
            'out_trade_no' => $outTradeNo,
            'nonce_str' => $this->generateNonceStr()
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway . '/pay/closeorder', $requestParams);
        $result = $this->xmlToArray($response);
        
        if ($result['return_code'] !== 'SUCCESS') {
            throw new Exception('微信关闭订单失败：' . $result['return_msg']);
        }
        
        return $result;
    }
    
    /**
     * 验证回调签名
     */
    public function verifyCallback($data)
    {
        if (!isset($data['sign'])) {
            return false;
        }
        
        $sign = $data['sign'];
        $unsignedData = $data;
        unset($unsignedData['sign']);
        
        // 生成签名
        $expectedSign = $this->generateSign($unsignedData);
        
        return $sign === $expectedSign;
    }
    
    /**
     * 生成随机字符串
     */
    private function generateNonceStr($length = 32)
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $nonceStr = '';
        for ($i = 0; $i < $length; $i++) {
            $nonceStr .= $chars[mt_rand(0, strlen($chars) - 1)];
        }
        return $nonceStr;
    }
    
    /**
     * 生成签名
     */
    private function generateSign($params)
    {
        // 移除空值参数
        $params = array_filter($params, function($value) {
            return $value !== '' && $value !== null;
        });
        
        // 排序参数
        ksort($params);
        
        // 构建签名字符串
        $stringA = '';
        foreach ($params as $key => $value) {
            $stringA .= $key . '=' . $value . '&';
        }
        $stringA .= 'key=' . $this->config['key'];
        
        // MD5加密并转为大写
        return strtoupper(md5($stringA));
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIp()
    {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            return $_SERVER['REMOTE_ADDR'];
        }
        return '127.0.0.1';
    }
    
    /**
     * 生成JSAPI支付参数
     */
    private function generateJsApiParams($prepayId)
    {
        $params = array(
            'appId' => $this->config['app_id'],
            'timeStamp' => (string)time(),
            'nonceStr' => $this->generateNonceStr(),
            'package' => 'prepay_id=' . $prepayId,
            'signType' => 'MD5'
        );
        
        $params['paySign'] = $this->generateSign($params);
        
        return $params;
    }
    
    /**
     * 生成APP支付参数
     */
    private function generateAppParams($prepayId)
    {
        $params = array(
            'appid' => $this->config['app_id'],
            'partnerid' => $this->config['mch_id'],
            'prepayid' => $prepayId,
            'package' => 'Sign=WXPay',
            'noncestr' => $this->generateNonceStr(),
            'timestamp' => (string)time()
        );
        
        $params['sign'] = $this->generateSign($params);
        
        return $params;
    }
    
    /**
     * 发送HTTP请求
     */
    private function httpRequest($url, $params, $useCert = false)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->arrayToXml($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        // 使用证书
        if ($useCert && !empty($this->config['cert_path']) && !empty($this->config['key_path'])) {
            curl_setopt($ch, CURLOPT_SSLCERT, $this->config['cert_path']);
            curl_setopt($ch, CURLOPT_SSLKEY, $this->config['key_path']);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($response === false || !empty($error)) {
            throw new Exception('微信支付API请求失败：' . $error);
        }
        
        if ($httpCode !== 200) {
            throw new Exception('微信支付API请求失败，HTTP状态码：' . $httpCode);
        }
        
        return $response;
    }
    
    /**
     * 数组转XML
     */
    private function arrayToXml($array)
    {
        $xml = '<xml>';
        foreach ($array as $key => $value) {
            $xml .= '<' . $key . '>' . $value . '</' . $key . '>';
        }
        $xml .= '</xml>';
        return $xml;
    }
    
    /**
     * XML转数组
     */
    private function xmlToArray($xml)
    {
        return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
    }
    
    /**
     * 获取微信授权链接
     */
    public function getAuthUrl($redirectUri, $scope = 'snsapi_base', $state = '')
    {
        $params = array(
            'appid' => $this->config['app_id'],
            'redirect_uri' => urlencode($redirectUri),
            'response_type' => 'code',
            'scope' => $scope,
            'state' => $state ? $state : time()
        );
        
        return 'https://open.weixin.qq.com/connect/oauth2/authorize?' . http_build_query($params) . '#wechat_redirect';
    }
    
    /**
     * 通过code获取access_token
     */
    public function getAccessToken($code)
    {
        $params = array(
            'appid' => $this->config['app_id'],
            'secret' => isset($this->config['app_secret']) ? $this->config['app_secret'] : '',
            'code' => $code,
            'grant_type' => 'authorization_code'
        );
        
        $response = file_get_contents('https://api.weixin.qq.com/sns/oauth2/access_token?' . http_build_query($params));
        $result = json_decode($response, true);
        
        if (isset($result['errcode'])) {
            throw new Exception('获取微信access_token失败：' . $result['errmsg']);
        }
        
        return $result;
    }
    
    /**
     * 获取用户信息
     */
    public function getUserInfo($accessToken, $openId)
    {
        $params = array(
            'access_token' => $accessToken,
            'openid' => $openId,
            'lang' => 'zh_CN'
        );
        
        $response = file_get_contents('https://api.weixin.qq.com/sns/userinfo?' . http_build_query($params));
        $result = json_decode($response, true);
        
        if (isset($result['errcode'])) {
            throw new Exception('获取微信用户信息失败：' . $result['errmsg']);
        }
        
        return $result;
    }
    
    /**
     * 1分钱测试支付
     * 创建一个0.01元的测试订单，用于验证支付配置是否正确
     */
    public function createTestPayment()
    {
        try {
            // 验证必要配置
            if (empty($this->config['app_id'])) {
                return array(
                    'success' => false,
                    'error_msg' => '缺少AppID配置'
                );
            }
            
            if (empty($this->config['mch_id'])) {
                return array(
                    'success' => false,
                    'error_msg' => '缺少商户号配置'
                );
            }
            
            if (empty($this->config['key'])) {
                return array(
                    'success' => false,
                    'error_msg' => '缺少API密钥配置'
                );
            }
            
            // 生成测试订单号
            $testOrderNo = 'test_' . date('YmdHis') . '_' . mt_rand(1000, 9999);
            
            // 准备测试参数
            $params = array(
                'out_trade_no' => $testOrderNo,
                'total_amount' => 0.01,
                'subject' => '发卡系统支付测试',
                'notify_url' => $this->config['notify_url'] ?? '',
                'extra' => array()
            );
            
            // 创建测试订单（使用扫码支付）
            $result = $this->createOrder($params);
            
            return array(
                'success' => true,
                'qrcode_url' => $result['qr_code'],
                'out_trade_no' => $result['out_trade_no'],
                'amount' => '0.01元'
            );
        } catch (Exception $e) {
            // 解析错误信息，提供更友好的错误提示
            $errorMsg = $e->getMessage();
            
            // 根据常见错误提供更具体的提示
            if (strpos($errorMsg, '签名验证失败') !== false) {
                $errorMsg = '密钥配置错误，请检查API密钥是否正确';
            } elseif (strpos($errorMsg, '签名不正确') !== false) {
                $errorMsg = 'API密钥错误，请检查密钥配置';
            } elseif (strpos($errorMsg, '商户号') !== false && strpos($errorMsg, '不存在') !== false) {
                $errorMsg = '商户号不存在或已被禁用';
            } elseif (strpos($errorMsg, 'H5') !== false && strpos($errorMsg, '未开通') !== false) {
                $errorMsg = 'H5支付功能未开通，请在微信支付商户平台开通';
            } elseif (strpos($errorMsg, '支付') !== false && strpos($errorMsg, '未开通') !== false) {
                $errorMsg = '支付功能未开通，请在微信支付商户平台开通';
            } elseif (strpos($errorMsg, '证书') !== false) {
                $errorMsg = '证书配置错误，请检查证书路径是否正确';
            }
            
            return array(
                'success' => false,
                'error_msg' => '测试支付失败：' . $errorMsg
            );
        }
    }
}