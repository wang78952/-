<?php
/**
 * 全局异常处理器
 * 统一处理系统中所有类型的异常
 */

require_once __DIR__ . '/ErrorHandler.php';
require_once __DIR__ . '/Logger.php';

class GlobalExceptionHandler {
    private static $instance = null;
    private $errorHandler;
    private $logger;
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->errorHandler = ErrorHandler::getInstance();
        $this->logger = Logger::getInstance();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 处理所有未捕获的异常
     */
    public function handleException($exception) {
        $this->logger->error('未捕获的异常', array(
            'type' => get_class($exception),
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString(),
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'CLI',
            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'CLI',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'CLI',
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp()
        ));
        
        // 根据异常类型进行特殊处理
        $this->handleSpecificException($exception);
        
        // 显示错误页面
        $this->displayErrorPage($exception);
    }
    
    /**
     * 处理特定类型的异常
     */
    private function handleSpecificException($exception) {
        if ($exception instanceof PDOException) {
            $this->handleDatabaseException($exception);
        } elseif ($exception instanceof InvalidArgumentException) {
            $this->handleInvalidArgumentException($exception);
        } elseif ($exception instanceof RuntimeException) {
            $this->handleRuntimeException($exception);
        } elseif ($exception instanceof AuthenticationException) {
            $this->handleAuthenticationException($exception);
        } elseif ($exception instanceof AuthorizationException) {
            $this->handleAuthorizationException($exception);
        } elseif ($exception instanceof ValidationException) {
            $this->handleValidationException($exception);
        } elseif ($exception instanceof RateLimitException) {
            $this->handleRateLimitException($exception);
        } elseif ($exception instanceof UnexpectedException) {
            $this->handleUnexpectedException($exception);
        }
    }
    
    /**
     * 处理数据库异常
     */
    private function handleDatabaseException($exception) {
        $this->logger->critical('数据库异常', array(
            'sql_state' => $exception->getCode(),
            'error_info' => isset($exception->errorInfo) ? $exception->errorInfo : array(),
            'message' => $exception->getMessage()
        ));
        
        // 数据库异常告警
        $this->errorHandler->sendAlert(ErrorLevel::CRITICAL, '数据库连接或查询失败', array(
            'error' => $exception->getMessage(),
            'code' => $exception->getCode()
        ));
    }
    
    /**
     * 处理无效参数异常
     */
    private function handleInvalidArgumentException($exception) {
        $this->logger->warning('无效参数异常', array(
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine()
        ));
    }
    
    /**
     * 处理运行时异常
     */
    private function handleRuntimeException($exception) {
        $this->logger->error('运行时异常', array(
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine()
        ));
    }
    
    /**
     * 处理认证异常
     */
    private function handleAuthenticationException($exception) {
        $this->logger->warning('认证异常', array(
            'message' => $exception->getMessage(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp()
        ));
        
        // 认证失败记录
        $this->errorHandler->logSecurity(ErrorLevel::WARNING, '用户认证失败', array(
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'reason' => $exception->getMessage()
        ));
    }
    
    /**
     * 处理授权异常
     */
    private function handleAuthorizationException($exception) {
        $this->logger->warning('授权异常', array(
            'message' => $exception->getMessage(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp(),
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
        ));
        
        // 授权失败记录
        $this->errorHandler->logSecurity(ErrorLevel::WARNING, '用户授权失败', array(
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp(),
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'reason' => $exception->getMessage()
        ));
    }
    
    /**
     * 处理验证异常
     */
    private function handleValidationException($exception) {
        $this->logger->info('验证异常', array(
            'message' => $exception->getMessage(),
            'errors' => method_exists($exception, 'getErrors') ? $exception->getErrors() : array(),
            'user_id' => $this->getCurrentUserId()
        ));
    }
    
    /**
     * 处理速率限制异常
     */
    private function handleRateLimitException($exception) {
        $this->logger->warning('速率限制异常', array(
            'message' => $exception->getMessage(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp(),
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
        ));
        
        // 速率限制告警
        $this->errorHandler->logSecurity(ErrorLevel::WARNING, '触发速率限制', array(
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp(),
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'limit_type' => $exception->getMessage()
        ));
    }
    
    /**
     * 处理无法预料异常
     */
    private function handleUnexpectedException($exception) {
        $logData = array(
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $this->getClientIp(),
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '',
            'request_id' => $this->getRequestId()
        );
        
        // 添加上下文信息（如果有）
        if (!empty($exception->getContext())) {
            $logData['context'] = $exception->getContext();
        }
        
        // 记录严重错误日志
        $this->logger->critical('无法预料的系统错误', $logData);
        
        // 发送关键错误告警
        $this->errorHandler->sendAlert(ErrorLevel::CRITICAL, '系统发生无法预料的错误', array(
            'error' => $exception->getMessage(),
            'request_id' => $logData['request_id'],
            'file' => $logData['file'],
            'line' => $logData['line']
        ));
    }
    
    /**
     * 显示错误页面
     */
    private function displayErrorPage($exception) {
        // 如果是AJAX请求，返回JSON格式的错误
        if ($this->isAjaxRequest()) {
            $this->displayJsonError($exception);
        } else {
            $this->displayHtmlError($exception);
        }
    }
    
    /**
     * 显示JSON格式错误
     */
    private function displayJsonError($exception) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code($this->getStatusCode($exception));
        }
        
        $response = array(
            'success' => false,
            'error' => array(
                'type' => get_class($exception),
                'message' => $this->getErrorMessage($exception),
                'code' => $exception->getCode(),
                'request_id' => $this->getRequestId()
            )
        );
        
        // 开发环境显示详细信息
        if (DEBUG_MODE) {
            $response['error']['file'] = $exception->getFile();
            $response['error']['line'] = $exception->getLine();
            $response['error']['trace'] = $exception->getTraceAsString();
        }
        
        echo json_encode($response);
        exit;
    }
    
    /**
     * 显示HTML格式错误
     */
    private function displayHtmlError($exception) {
        if (!headers_sent()) {
            http_response_code($this->getStatusCode($exception));
            header('Content-Type: text/html; charset=UTF-8');
        }
        
        $statusCode = $this->getStatusCode($exception);
        $errorMessage = $this->getErrorMessage($exception);
        $requestId = $this->getRequestId();
        
        if (DEBUG_MODE) {
            // 开发环境显示详细错误
            echo "<!DOCTYPE html>";
            echo "<html><head><title>系统错误 - {$statusCode}</title>";
            echo "<style>";
            echo "body { font-family: Arial, sans-serif; margin: 40px; }";
            echo ".error-container { max-width: 800px; margin: 0 auto; }";
            echo ".error-title { color: #d32f2f; }";
            echo ".error-details { background: #f5f5f5; padding: 20px; margin: 20px 0; border-radius: 5px; }";
            echo ".stack-trace { background: #fff3cd; padding: 15px; margin: 10px 0; border-radius: 5px; font-family: monospace; }";
            echo "</style></head><body>";
            
            echo "<div class='error-container'>";
            echo "<h1 class='error-title'>系统错误 ({$statusCode})</h1>";
            echo "<p><strong>错误信息:</strong> {$errorMessage}</p>";
            echo "<p><strong>错误类型:</strong> " . get_class($exception) . "</p>";
            echo "<p><strong>文件:</strong> " . $exception->getFile() . "</p>";
            echo "<p><strong>行号:</strong> " . $exception->getLine() . "</p>";
            echo "<p><strong>请求ID:</strong> {$requestId}</p>";
            
            echo "<div class='error-details'>";
            echo "<h3>堆栈跟踪:</h3>";
            echo "<div class='stack-trace'>" . nl2br(htmlspecialchars($exception->getTraceAsString())) . "</div>";
            echo "</div>";
            
            echo "</div></body></html>";
        } else {
            // 生产环境显示通用错误页面
            echo "<!DOCTYPE html>";
            echo "<html><head><title>系统错误</title>";
            echo "<style>";
            echo "body { font-family: Arial, sans-serif; margin: 40px; text-align: center; }";
            echo ".error-container { max-width: 600px; margin: 100px auto; }";
            echo ".error-title { color: #d32f2f; font-size: 24px; margin-bottom: 20px; }";
            echo ".error-message { color: #666; font-size: 16px; margin-bottom: 30px; }";
            echo ".error-info { background: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0; }";
            echo "</style></head><body>";
            
            echo "<div class='error-container'>";
            echo "<h1 class='error-title'>系统暂时不可用</h1>";
            echo "<p class='error-message'>我们正在处理这个问题，请稍后再试。</p>";
            echo "<div class='error-info'>";
            echo "<p><strong>错误代码:</strong> {$statusCode}</p>";
            echo "<p><strong>请求ID:</strong> {$requestId}</p>";
            echo "<p><strong>时间:</strong> " . date('Y-m-d H:i:s') . "</p>";
            echo "</div>";
            echo "<p><a href='/'>返回首页</a></p>";
            echo "</div></body></html>";
        }
        exit;
    }
    
    /**
     * 获取HTTP状态码
     */
    private function getStatusCode($exception) {
        if (method_exists($exception, 'getStatusCode')) {
            return $exception->getStatusCode();
        }
        
        // 根据异常类型返回适当的状态码
        if ($exception instanceof AuthenticationException) {
            return 401;
        } elseif ($exception instanceof AuthorizationException) {
            return 403;
        } elseif ($exception instanceof ValidationException) {
            return 422;
        } elseif ($exception instanceof RateLimitException) {
            return 429;
        } elseif ($exception instanceof NotFoundException) {
            return 404;
        } elseif ($exception instanceof UnexpectedException) {
            return 500;
        }
        
        return 500;
    }
    
    /**
     * 获取错误消息
     */
    private function getErrorMessage($exception) {
        if (DEBUG_MODE) {
            return $exception->getMessage();
        }
        
        // 生产环境返回通用错误消息
        if ($exception instanceof AuthenticationException) {
            return '认证失败，请重新登录';
        } elseif ($exception instanceof AuthorizationException) {
            return '权限不足，无法访问该资源';
        } elseif ($exception instanceof ValidationException) {
            return '请求数据验证失败';
        } elseif ($exception instanceof RateLimitException) {
            return '请求过于频繁，请稍后再试';
        } elseif ($exception instanceof NotFoundException) {
            return '请求的资源不存在';
        } elseif ($exception instanceof UnexpectedException) {
            // 对无法预料的错误提供更友好的消息，并包含请求ID以便技术支持跟进
            $requestId = $this->getRequestId();
            return "系统遇到无法预料的情况，请记录此错误ID: {$requestId}，并联系技术支持。";
        }
        
        return '系统内部错误，请稍后再试';
    }
    
    /**
     * 检查是否为AJAX请求
     */
    private function isAjaxRequest() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * 获取请求ID
     */
    private function getRequestId() {
        return isset($_SERVER['HTTP_X_REQUEST_ID']) ? $_SERVER['HTTP_X_REQUEST_ID'] : uniqid('req_', true);
    }
    
    /**
     * 获取当前用户ID
     */
    private function getCurrentUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIp() {
        $ipKeys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
        
        foreach ($ipKeys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
    }
}

// 定义自定义异常类
class AuthenticationException extends Exception {}
class AuthorizationException extends Exception {}
class ValidationException extends Exception {
    private $errors;
    
    public function __construct($message, $errors = array(), $code = 0, Exception $previous = null) {
        parent::__construct($message, $code, $previous);
        $this->errors = $errors;
    }
    
    public function getErrors() {
        return $this->errors;
    }
}
class RateLimitException extends Exception {}
class NotFoundException extends Exception {
    private $statusCode = 404;
    
    public function getStatusCode() {
        return $this->statusCode;
    }
}

/**
 * 无法预料异常类
 * 用于处理系统中的意外错误
 */
class UnexpectedException extends Exception {
    private $statusCode = 500;
    private $context = array();
    
    public function getStatusCode() {
        return $this->statusCode;
    }
    
    public function setContext(array $context) {
        $this->context = $context;
        return $this;
    }
    
    public function getContext() {
        return $this->context;
    }
}

// 初始化全局异常处理器
$globalExceptionHandler = GlobalExceptionHandler::getInstance();

// 设置全局异常处理器
set_exception_handler([$globalExceptionHandler, 'handleException']);
?>