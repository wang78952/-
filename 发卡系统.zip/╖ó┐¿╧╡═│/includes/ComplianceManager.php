<?php
/**
 * 合规性管理器类
 */
require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/VerificationService.php';

class ComplianceManager extends BaseService {
    protected $config;
    protected $verificationService;
    
    public function __construct($database = null, $logger = null)
    {
        parent::__construct();
        if ($database) {
            $this->database = $database;
        } else {
            // 如果没有提供数据库实例，则使用单例
            require_once __DIR__ . '/Database.php';
            $this->database = Database::getInstance();
        }
        // 使用Logger对象进行日志记录
        $this->logger = $logger ?: Logger::getInstance();
        $this->config = $this->loadComplianceConfig();
        $this->verificationService = new VerificationService();
    }
    
    /**
     * AML筛查
     */
    public function performAmlScreening($userId) {
        try {
            // 获取用户信息
            $userInfo = $this->getUserInfo($userId);
            if (!$userInfo) {
                throw new Exception('用户不存在');
            }
            
            // 执行AML筛查规则
            $amlResult = $this->executeAmlRules($userInfo);
            
            // 记录筛查结果
            $this->recordAmlScreening($userId, $amlResult);
            
            // 如果高风险，创建警报
            if ($amlResult['risk_level'] === 'HIGH' || $amlResult['risk_level'] === 'CRITICAL') {
                $this->createAmlAlert($userId, $amlResult);
            }
            
            return array(
                'success' => true,
                'risk_score' => $amlResult['risk_score'],
                'risk_level' => $amlResult['risk_level'],
                'factors' => $amlResult['factors']
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * KYC验证
     */
    public function performKycVerification($kycData) {
        try {
            // 验证必填字段
            $required = array('user_id', 'real_name', 'id_number', 'phone_number', 'email');
            foreach ($required as $field) {
                if (empty($kycData[$field])) {
                    throw new Exception("字段 {$field} 不能为空");
                }
            }
            
            // 身份证号格式验证
            if (!$this->validateIdNumber($kycData['id_number'])) {
                throw new Exception('身份证号格式不正确');
            }
            
            // 手机号格式验证
            if (!$this->validatePhoneNumber($kycData['phone_number'])) {
                throw new Exception('手机号格式不正确');
            }
            
            // 邮箱格式验证
            if (!filter_var($kycData['email'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception('邮箱格式不正确');
            }
            
            // 检查是否已存在KYC记录
            $existingKyc = $this->getExistingKyc($kycData['user_id']);
            if ($existingKyc && $existingKyc['verification_status'] === 'VERIFIED') {
                throw new Exception('用户已完成KYC验证');
            }
            
            // 执行身份核验
            $verificationResult = $this->verifyIdentity($kycData);
            
            // 记录KYC验证
            $kycId = $this->recordKycVerification($kycData, $verificationResult);
            
            // 记录合规事件
            $this->recordComplianceEvent('KYC_VERIFICATION', 'MEDIUM', 
                "用户 {$kycData['user_id']} 提交KYC验证", $kycData['user_id']);
            
            return array(
                'success' => true,
                'kyc_id' => $kycId,
                'verification_score' => $verificationResult['score'],
                'status' => $verificationResult['status']
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 创建数据留存策略
     */
    public function createRetentionPolicy($policyData) {
        try {
            // 验证策略数据
            $required = array('policy_name', 'table_name', 'date_column', 'retention_days', 'action_type', 'execution_frequency');
            foreach ($required as $field) {
                if (empty($policyData[$field])) {
                    throw new Exception("字段 {$field} 不能为空");
                }
            }
            
            // 验证表是否存在
            if (!$this->tableExists($policyData['table_name'])) {
                throw new Exception("表 {$policyData['table_name']} 不存在");
            }
            
            // 验证日期字段是否存在
            if (!$this->columnExists($policyData['table_name'], $policyData['date_column'])) {
                throw new Exception("字段 {$policyData['date_column']} 在表 {$policyData['table_name']} 中不存在");
            }
            
            // 插入留存策略
            $data = array(
                'policy_name' => $policyData['policy_name'],
                'table_name' => $policyData['table_name'],
                'date_column' => $policyData['date_column'],
                'retention_days' => $policyData['retention_days'],
                'action_type' => $policyData['action_type'],
                'execution_frequency' => $policyData['execution_frequency'],
                'is_active' => 1,
                'created_at' => date('Y-m-d H:i:s')
            );
            
            $policyId = $this->database->insert('data_retention_policies', $data);
            
            // 记录合规事件
            $this->recordComplianceEvent('RETENTION_POLICY_CREATED', 'MEDIUM', 
                "创建数据留存策略: {$policyData['policy_name']}");
            
            return array(
                'success' => true,
                'policy_id' => $policyId
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 执行数据留存策略
     */
    public function executeRetentionPolicies() {
        try {
            $policies = $this->getActiveRetentionPolicies();
            $executedCount = 0;
            $affectedRows = 0;
            
            foreach ($policies as $policy) {
                $result = $this->executeSinglePolicy($policy);
                if ($result['success']) {
                    $executedCount++;
                    $affectedRows += $result['affected_rows'];
                    
                    // 更新最后执行时间
                    $this->updatePolicyLastExecuted($policy['id']);
                }
            }
            
            // 记录合规事件
            $this->recordComplianceEvent('RETENTION_EXECUTION', 'MEDIUM', 
                "执行了 {$executedCount} 个数据留存策略，影响 {$affectedRows} 条记录");
            
            return array(
                'success' => true,
                'executed_policies' => $executedCount,
                'affected_rows' => $affectedRows
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 生成合规报告
     */
    public function generateComplianceReport($reportData) {
        try {
            $reportType = $reportData['report_type'];
            $startDate = $reportData['start_date'];
            $endDate = $reportData['end_date'];
            
            // 生成报告数据
            $reportContent = $this->generateReportContent($reportType, $startDate, $endDate);
            
            // 保存报告记录
            $reportId = $this->saveReportRecord($reportData, $reportContent);
            
            // 记录合规事件
            $this->recordComplianceEvent('REPORT_GENERATED', 'LOW', 
                "生成合规报告: {$reportType}");
            
            return array(
                'success' => true,
                'report_id' => $reportId
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 处理AML警报
     */
    public function processAmlAlert($alertId, $processData) {
        try {
            // 更新警报状态
            $this->database->update('aml_alerts', array(
                'status' => $processData['status'],
                'assigned_to' => $processData['assigned_to'],
                'resolution_notes' => $processData['resolution_notes'],
                'resolved_at' => date('Y-m-d H:i:s')
            ), array('id' => $alertId));
            
            // 记录合规事件
            $this->recordComplianceEvent('ALERT_PROCESSED', 'MEDIUM', 
                "处理AML警报: {$alertId}");
            
            return array(
                'success' => true
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * 获取合规统计
     */
    public function getComplianceStatistics() {
        try {
            $stats = array();
            
            // AML统计
            $amlStats = $this->database->fetch(
                "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN risk_level = 'HIGH' THEN 1 ELSE 0 END) as high_risk,
                    SUM(CASE WHEN risk_level = 'MEDIUM' THEN 1 ELSE 0 END) as medium_risk
                FROM aml_screening_results 
                WHERE screened_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
            );
            $stats['aml'] = $amlStats;
            
            // KYC统计
            $kycStats = $this->database->fetch(
                "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as verified,
                    SUM(CASE WHEN verification_status = 'PENDING' THEN 1 ELSE 0 END) as pending
                FROM kyc_verifications"
            );
            $stats['kyc'] = $kycStats;
            
            // 事件统计
            $eventStats = $this->database->fetch(
                "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                    SUM(CASE WHEN severity = 'HIGH' THEN 1 ELSE 0 END) as high
                FROM compliance_events 
                WHERE event_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
            );
            $stats['events'] = $eventStats;
            
            // 留存策略统计
            $retentionStats = $this->database->fetch(
                "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active
                FROM data_retention_policies"
            );
            $stats['retention'] = $retentionStats;
            
            return array(
                'success' => true,
                'data' => $stats
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    // 私有方法
    
    private function loadComplianceConfig() {
        $configs = $this->database->fetchAll("SELECT config_key, config_value FROM compliance_config WHERE is_active = 1");
        $result = array();
        foreach ($configs as $row) {
            $result[$row['config_key']] = $row['config_value'];
        }
        return $result;
    }
    
    private function getUserInfo($userId) {
        return $this->database->fetch(
            "SELECT u.*, up.* FROM users u 
             LEFT JOIN user_profiles up ON u.id = up.user_id 
             WHERE u.id = ?", 
            [$userId]
        );
    }
    
    private function executeAmlRules($userInfo) {
        $riskScore = 0;
        $factors = array();
        
        // 规则1: 检查黑名单
        if ($this->isInBlacklist($userInfo['id'])) {
            $riskScore += 50;
            $factors[] = '用户在黑名单中';
        }
        
        // 规则2: 检查异常交易模式
        if ($this->hasAnomalousTransactions($userInfo['id'])) {
            $riskScore += 30;
            $factors[] = '检测到异常交易模式';
        }
        
        // 规则3: 检查高风险地区
        if ($this->isFromHighRiskRegion($userInfo)) {
            $riskScore += 20;
            $factors[] = '来自高风险地区';
        }
        
        // 规则4: 检查大额交易
        if ($this->hasLargeTransactions($userInfo['id'])) {
            $riskScore += 25;
            $factors[] = '存在大额交易';
        }
        
        // 确定风险等级
        if ($riskScore >= 80) {
            $riskLevel = 'CRITICAL';
        } elseif ($riskScore >= 60) {
            $riskLevel = 'HIGH';
        } elseif ($riskScore >= 30) {
            $riskLevel = 'MEDIUM';
        } else {
            $riskLevel = 'LOW';
        }
        
        return array(
            'risk_score' => $riskScore,
            'risk_level' => $riskLevel,
            'factors' => $factors
        );
    }
    
    private function recordAmlScreening($userId, $amlResult) {
        $this->database->insert('aml_screening_results', array(
            'user_id' => $userId,
            'risk_score' => $amlResult['risk_score'],
            'risk_level' => $amlResult['risk_level'],
            'screening_factors' => json_encode($amlResult['factors']),
            'screened_at' => date('Y-m-d H:i:s')
        ));
    }
    
    private function createAmlAlert($userId, $amlResult) {
        $this->database->insert('aml_alerts', array(
            'user_id' => $userId,
            'alert_type' => 'HIGH_RISK',
            'risk_score' => $amlResult['risk_score'],
            'status' => 'OPEN',
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
    
    private function validateIdNumber($idNumber) {
        // 简单的身份证号格式验证
        return preg_match('/^\d{17}[\dXx]$/', $idNumber);
    }
    
    private function validatePhoneNumber($phoneNumber) {
        return preg_match('/^1[3-9]\d{9}$/', $phoneNumber);
    }
    
    private function getExistingKyc($userId) {
        return $this->database->fetch(
            "SELECT * FROM kyc_verifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1", 
            [$userId]
        );
    }
    
    private function verifyIdentity($kycData) {
        // 使用VerificationService进行身份验证
        return $this->verificationService->verifyIdentity($kycData);
    }
    
    private function recordKycVerification($kycData, $verificationResult) {
        return $this->database->insert('kyc_verifications', array(
            'user_id' => $kycData['user_id'],
            'real_name' => $kycData['real_name'],
            'id_number' => $kycData['id_number'],
            'phone_number' => $kycData['phone_number'],
            'email' => $kycData['email'],
            'verification_score' => $verificationResult['score'],
            'verification_status' => $verificationResult['status'],
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
    
    private function recordComplianceEvent($eventType, $severity, $description, $userId = null) {
        $this->database->insert('compliance_events', array(
            'event_type' => $eventType,
            'severity' => $severity,
            'description' => $description,
            'user_id' => $userId,
            'event_time' => date('Y-m-d H:i:s')
        ));
    }
    
    private function tableExists($tableName) {
        $result = $this->database->fetch("SHOW TABLES LIKE ?", [$tableName]);
        return !empty($result);
    }
    
    private function columnExists($tableName, $columnName) {
        $result = $this->database->fetch("SHOW COLUMNS FROM {$tableName} LIKE ?", [$columnName]);
        return !empty($result);
    }
    
    private function getActiveRetentionPolicies() {
        return $this->database->fetchAll("SELECT * FROM data_retention_policies WHERE is_active = 1");
    }
    
    private function executeSinglePolicy($policy) {
        try {
            $cutoffDate = date('Y-m-d', strtotime("-{$policy['retention_days']} days"));
            
            switch ($policy['action_type']) {
                case 'DELETE':
                    $affectedRows = $this->database->query(
                        "DELETE FROM {$policy['table_name']} WHERE {$policy['date_column']} < ?", 
                        [$cutoffDate]
                    );
                    break;
                case 'ARCHIVE':
                    // 归档逻辑
                    return array('success' => true, 'affected_rows' => 0);
                case 'ANONYMIZE':
                    // 匿名化逻辑
                    return array('success' => true, 'affected_rows' => 0);
                default:
                    throw new Exception('未知的操作类型');
            }
            
            return array(
                'success' => true,
                'affected_rows' => $affectedRows
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    private function updatePolicyLastExecuted($policyId) {
        $this->database->update('data_retention_policies', 
            array('last_executed_at' => date('Y-m-d H:i:s')), 
            array('id' => $policyId)
        );
    }
    
    private function generateReportContent($reportType, $startDate, $endDate) {
        // 根据报告类型生成不同的内容
        switch ($reportType) {
            case 'DAILY':
                return $this->generateDailyReport($startDate, $endDate);
            case 'WEEKLY':
                return $this->generateWeeklyReport($startDate, $endDate);
            case 'MONTHLY':
                return $this->generateMonthlyReport($startDate, $endDate);
            default:
                return $this->generateCustomReport($startDate, $endDate);
        }
    }
    
    private function generateDailyReport($startDate, $endDate) {
        // 生成日报内容
        return "合规日报: {$startDate} 至 {$endDate}";
    }
    
    private function generateWeeklyReport($startDate, $endDate) {
        // 生成周报内容
        return "合规周报: {$startDate} 至 {$endDate}";
    }
    
    private function generateMonthlyReport($startDate, $endDate) {
        // 生成月报内容
        return "合规月报: {$startDate} 至 {$endDate}";
    }
    
    private function generateCustomReport($startDate, $endDate) {
        // 生成自定义报告内容
        return "合规自定义报告: {$startDate} 至 {$endDate}";
    }
    
    private function saveReportRecord($reportData, $content) {
        return $this->database->insert('compliance_reports', array(
            'report_type' => $reportData['report_type'],
            'start_date' => $reportData['start_date'],
            'end_date' => $reportData['end_date'],
            'status' => 'COMPLETED',
            'file_size' => strlen($content),
            'generated_at' => date('Y-m-d H:i:s')
        ));
    }
    
    // 模拟方法（实际应用中需要实现具体逻辑）
    private function isInBlacklist($userId) {
        return false; // 模拟实现
    }
    
    private function hasAnomalousTransactions($userId) {
        return false; // 模拟实现
    }
    
    private function isFromHighRiskRegion($userInfo) {
        return false; // 模拟实现
    }
    
    private function hasLargeTransactions($userId) {
        return false; // 模拟实现
    }
    
    /**
     * 检查数据访问权限
     */
    public static function checkDataAccessPermission($userId, $action = 'read', $resourceType = 'card_data') {
        try {
            // 这里应该实现具体的权限检查逻辑
            // 模拟权限检查
            $hasPermission = true; // 默认允许访问
            
            // 根据不同的资源类型和动作进行权限验证
            switch ($resourceType) {
                case 'card_data':
                    $hasPermission = self::checkCardDataPermission($userId, $action);
                    break;
                case 'user_data':
                    $hasPermission = self::checkUserDataPermission($userId, $action);
                    break;
                case 'order_data':
                    $hasPermission = self::checkOrderDataPermission($userId, $action);
                    break;
                default:
                    $hasPermission = false;
            }
            
            return $hasPermission;
            
        } catch (Exception $e) {
            error_log("权限检查失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查卡片数据权限
     */
    private static function checkCardDataPermission($userId, $action) {
        // 根据用户角色和动作检查权限
        // 这里应该查询数据库获取用户角色和权限
        // 模拟实现
        return true;
    }
    
    /**
     * 检查用户数据权限
     */
    private static function checkUserDataPermission($userId, $action) {
        // 根据用户角色和动作检查权限
        // 模拟实现
        return true;
    }
    
    /**
     * 检查订单数据权限
     */
    private static function checkOrderDataPermission($userId, $action) {
        // 根据用户角色和动作检查权限
        // 模拟实现
        return true;
    }
    
    /**
     * 记录数据访问授权
     */
    public static function recordDataAccessAuthorization($userId, $resourceType, $action, $description, $metadata = array()) {
        try {
            // 获取数据库连接
            $db = Database::getInstance();
            
            // 插入访问授权记录
            $sql = "INSERT INTO data_access_authorizations 
                    (user_id, resource_type, action, description, metadata, created_at)
                    VALUES (?, ?, ?, ?, ?, NOW())";
            
            $stmt = $db->prepare($sql);
            $metadataJson = json_encode($metadata, JSON_PRETTY_PRINT);
            $stmt->execute([$userId, $resourceType, $action, $description, $metadataJson]);
            
            return $db->lastInsertId();
            
        } catch (Exception $e) {
            error_log("记录数据访问授权失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 脱敏处理敏感数据
     */
    public static function maskSensitiveData($data, $type = 'default') {
        if (empty($data)) {
            return $data;
        }
        
        switch ($type) {
            case 'id_card':
                return self::maskIdCard($data);
            case 'name':
                return self::maskName($data);
            case 'phone':
                return self::maskPhone($data);
            case 'email':
                return self::maskEmail($data);
            case 'card_number':
                return self::maskCardNumber($data);
            default:
                // 默认脱敏处理
                if (strlen($data) <= 4) {
                    return $data;
                }
                return substr($data, 0, 2) . '***' . substr($data, -2);
        }
    }
    
    /**
     * 脱敏处理身份证号
     */
    public static function maskIdCard($idCard, $userRole = null) {
        if (empty($idCard) || strlen($idCard) < 8) {
            return $idCard;
        }
        
        // 根据用户角色决定脱敏程度
        switch ($userRole) {
            case 'admin':
                // 管理员可以看到更多信息
                return substr($idCard, 0, 6) . '******' . substr($idCard, -4);
            case 'manager':
                // 管理者可以看到中等信息
                return substr($idCard, 0, 4) . '********' . substr($idCard, -4);
            default:
                // 其他角色只能看到少量信息
                return substr($idCard, 0, 3) . '***********' . substr($idCard, -3);
        }
    }
    
    /**
     * 脱敏处理姓名
     */
    public static function maskName($name, $userRole = null) {
        if (empty($name) || strlen($name) <= 2) {
            return $name;
        }
        
        // 根据用户角色决定脱敏程度
        switch ($userRole) {
            case 'admin':
                // 管理员可以看到完整姓名
                return $name;
            case 'manager':
                // 管理者可以看到更多字符
                return substr($name, 0, 2) . '*' . substr($name, -1);
            default:
                // 其他角色只能看到首尾字符
                return substr($name, 0, 1) . '**' . substr($name, -1);
        }
    }
    
    /**
     * 脱敏处理手机号
     */
    public static function maskPhone($phone, $userRole = null) {
        if (empty($phone) || strlen($phone) < 11) {
            return $phone;
        }
        
        // 根据用户角色决定脱敏程度
        switch ($userRole) {
            case 'admin':
                // 管理员可以看到更多数字
                return substr($phone, 0, 3) . '**' . substr($phone, -3);
            case 'manager':
                // 管理者可以看到中等信息
                return substr($phone, 0, 3) . '****' . substr($phone, -4);
            default:
                // 其他角色只能看到少量信息
                return substr($phone, 0, 3) . '*****' . substr($phone, -3);
        }
    }
    
    /**
     * 脱敏处理银行卡号
     */
    public static function maskCardNumber($cardNumber) {
        if (empty($cardNumber) || strlen($cardNumber) < 8) {
            return $cardNumber;
        }
        return substr($cardNumber, 0, 4) . '****' . substr($cardNumber, -4);
    }
    
    /**
     * 脱敏处理邮箱
     */
    public static function maskEmail($email) {
        if (empty($email) || strpos($email, '@') === false) {
            return $email;
        }
        list($local, $domain) = explode('@', $email);
        if (strlen($local) <= 2) {
            return $email;
        }
        return substr($local, 0, 2) . '***@' . $domain;
    }
}