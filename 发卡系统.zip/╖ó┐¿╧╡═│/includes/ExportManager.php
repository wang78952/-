<?php
/**
 * 导出管理器
 * 处理CSV、Excel、PDF等格式的数据导出功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Logger.php';

class ExportManager extends BaseService {
    protected $logger;
    private $allowedFormats = array('csv', 'xlsx', 'pdf');
    private $exportDir;
    
    public function __construct($database = null, $logger = null)
    {
        parent::__construct();
        $this->logger = $logger ?: new Logger();
        $this->exportDir = __DIR__ . '/../exports/';
        // 确保导出目录存在
        if (!is_dir($this->exportDir)) {
            mkdir($this->exportDir, 0755, true);
        }
    }
    
    /**
     * 导出卡密数据
     */
    public function exportCards($filters = array(), $format = 'csv') {
        try {
            // 构建查询
            $query = $this->buildCardQuery($filters);
            $cards = $this->database->fetchAll($query['sql'], $query['params']);
            
            // 转换数据格式
            $data = $this->formatCardData($cards);
            
            // 导出文件
            $filename = 'cards_' . date('Y-m-d_H-i-s') . '.' . $format;
            $filepath = $this->exportFile($data, $filename, $format);
            
            $this->logger->logInfo("卡密导出完成", array(
                'format' => $format,
                'count' => count($cards),
                'filename' => $filename
            ));
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'count' => count($cards)
            ];
            
        } catch (Exception $e) {
            $this->logger->logError("卡密导出失败", [
                'format' => $format,
                'error' => $e->getMessage()
            ]);
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 导出产品数据
     */
    public function exportProducts($filters = array(), $format = 'csv') {
        try {
            // 构建查询
            $query = $this->buildProductQuery($filters);
            $products = $this->database->fetchAll($query['sql'], $query['params']);
            
            // 转换数据格式
            $data = $this->formatProductData($products);
            
            // 导出文件
            $filename = 'products_' . date('Y-m-d_H-i-s') . '.' . $format;
            $filepath = $this->exportFile($data, $filename, $format);
            
            $this->logger->logInfo("产品导出完成", array(
                'format' => $format,
                'count' => count($products),
                'filename' => $filename
            ));
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'count' => count($products)
            ];
            
        } catch (Exception $e) {
            $this->logger->logError("产品导出失败", [
                'format' => $format,
                'error' => $e->getMessage()
            ]);
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 导出用户数据
     */
    public function exportUsers($filters = array(), $format = 'csv') {
        try {
            // 构建查询
            $query = $this->buildUserQuery($filters);
            $users = $this->database->fetchAll($query['sql'], $query['params']);
            
            // 转换数据格式
            $data = $this->formatUserData($users);
            
            // 导出文件
            $filename = 'users_' . date('Y-m-d_H-i-s') . '.' . $format;
            $filepath = $this->exportFile($data, $filename, $format);
            
            $this->logger->logInfo("用户导出完成", array(
                'format' => $format,
                'count' => count($users),
                'filename' => $filename
            ));
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'count' => count($users)
            ];
            
        } catch (Exception $e) {
            $this->logger->logError("用户导出失败", [
                'format' => $format,
                'error' => $e->getMessage()
            ]);
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 导出类型常量
     */
    const EXPORT_TYPE_NORMAL = 'normal';
    const EXPORT_TYPE_PROMOTION = 'promotion';
    const EXPORT_TYPE_ABNORMAL = 'abnormal';
    const EXPORT_TYPE_PERIOD = 'period';
    
    /**
     * 导出文件格式
     */
    const FORMAT_CSV = 'csv';
    const FORMAT_EXCEL = 'excel';
    
    /**
     * 导出订单数据 - 增强版
     */
    public function exportOrders($params = array()) {
        try {
            // 默认参数
            $defaults = [
                'export_type' => self::EXPORT_TYPE_NORMAL,
                'start_date' => '',
                'end_date' => '',
                'fields' => [],
                'format' => self::FORMAT_CSV,
                'status' => [],
                'payment_method' => [],
                'agent_id' => 0
            ];
            
            $params = array_merge($defaults, $params);
            
            // 根据导出类型构建查询条件
            $conditions = $this->buildConditionsByExportType($params);
            
            // 构建查询
            $query = $this->buildOrderQuery($conditions);
            $orders = $this->database->fetchAll($query['sql'], $query['params']);
            
            // 获取要导出的字段
            $fields = $this->getExportFields($params['fields'], $params['export_type']);
            
            // 处理订单数据，补充导出所需的额外字段
            $orders = $this->processOrderDataForExport($orders, $fields);
            
            // 转换数据格式
            $data = $this->formatOrderData($orders, $fields);
            
            // 生成文件名
            $filename = $this->generateExportFilename($params['export_type'], $params['format']);
            $filepath = $this->exportDir . $filename;
            
            // 导出文件
            $this->exportFile($data, $filename, $params['format']);
            
            $this->logger->logInfo("订单导出完成", array(
                'format' => $params['format'],
                'count' => count($orders),
                'filename' => $filename,
                'export_type' => $params['export_type']
            ));
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'count' => count($orders)
            ];
            
        } catch (Exception $e) {
            $this->logger->logError("订单导出失败", [
                'format' => isset($params['format']) ? $params['format'] : 'csv',
                'error' => $e->getMessage(),
                'export_type' => isset($params['export_type']) ? $params['export_type'] : self::EXPORT_TYPE_NORMAL
            ]);
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 根据导出类型构建查询条件
     * @param array $params 导出参数
     * @return array 查询条件
     */
    private function buildConditionsByExportType($params) {
        $conditions = [];
        
        // 时间段条件
        if (!empty($params['start_date'])) {
            $conditions['date_from'] = $params['start_date'];
        }
        if (!empty($params['end_date'])) {
            $conditions['date_to'] = $params['end_date'];
        }
        
        // 状态条件
        if (!empty($params['status'])) {
            $conditions['status'] = $params['status'];
        }
        
        // 用户条件
        if (!empty($params['user_id'])) {
            $conditions['user_id'] = $params['user_id'];
        }
        
        // 代理ID条件
        if (!empty($params['agent_id'])) {
            // 这里假设订单表中有agent_id字段
            $conditions['agent_id'] = $params['agent_id'];
        }
        
        // 根据导出类型添加特定条件
        switch ($params['export_type']) {
            case self::EXPORT_TYPE_ABNORMAL:
                // 异常订单：退款、取消等
                $conditions['status'] = ['refunded', 'cancelled'];
                break;
                
            case self::EXPORT_TYPE_PROMOTION:
                // 推广订单：这里可以添加代理相关条件
                break;
        }
        
        return $conditions;
    }
    
    /**
     * 获取导出字段
     * @param array $userFields 用户选择的字段
     * @param string $exportType 导出类型
     * @return array 最终导出字段
     */
    private function getExportFields($userFields = [], $exportType = self::EXPORT_TYPE_NORMAL) {
        // 默认字段
        $defaultFields = [
            'id', 'user_name', 'product_name', 'amount', 'status', 
            'payment_method', 'created_at', 'paid_at'
        ];
        
        // 代理相关字段
        $agentFields = [
            'agent_id', 'agent_name', 'agent_commission'
        ];
        
        // 异常订单特定字段
        $abnormalFields = [
            'refund_status', 'dispute_reason'
        ];
        
        // 根据导出类型添加特定字段
        switch ($exportType) {
            case self::EXPORT_TYPE_PROMOTION:
                $defaultFields = array_merge($defaultFields, $agentFields);
                break;
                
            case self::EXPORT_TYPE_ABNORMAL:
                $defaultFields = array_merge($defaultFields, $abnormalFields);
                break;
        }
        
        // 如果用户指定了字段，则使用用户指定的字段
        if (!empty($userFields)) {
            return array_intersect($userFields, $this->getAllAvailableFields());
        }
        
        return $defaultFields;
    }
    
    /**
     * 获取所有可用的导出字段
     * @return array 所有可用字段
     */
    private function getAllAvailableFields() {
        return [
            'id', 'user_name', 'product_name', 'amount', 'status', 
            'payment_method', 'created_at', 'paid_at', 'agent_id', 
            'agent_name', 'agent_commission', 'refund_status', 'dispute_reason'
        ];
    }
    
    /**
     * 处理订单数据，补充导出所需的额外字段
     * @param array $orders 订单数据
     * @param array $fields 导出字段
     * @return array 处理后的订单数据
     */
    private function processOrderDataForExport($orders, $fields) {
        // 需要补充的额外字段
        $needAgentData = array_intersect(['agent_id', 'agent_name', 'agent_commission'], $fields);
        
        foreach ($orders as &$order) {
            // 格式化支付方式
            if (isset($order['payment_method'])) {
                $order['payment_method'] = $this->formatPaymentMethod($order['payment_method']);
            }
            
            // 格式化订单状态
            if (isset($order['status'])) {
                $order['status'] = $this->getOrderStatusText($order['status']);
            }
            
            // 如果需要代理数据
            if (!empty($needAgentData)) {
                $order = $this->appendAgentData($order);
            }
        }
        
        return $orders;
    }
    
    /**
     * 附加代理数据
     * @param array $order 订单数据
     * @return array 附加代理数据后的订单
     */
    private function appendAgentData($order) {
        // 实际环境中应该从数据库获取代理信息
        // 这里简单模拟代理数据
        $order['agent_id'] = isset($order['agent_id']) ? $order['agent_id'] : 0;
        $order['agent_name'] = $order['agent_id'] > 0 ? "代理" . $order['agent_id'] : "无";
        $order['agent_commission'] = isset($order['amount']) && isset($order['commission_rate']) 
            ? round($order['amount'] * $order['commission_rate'] / 100, 2) : 0;
        
        return $order;
    }
    
    /**
     * 格式化支付方式
     * @param string $paymentMethod 支付方式
     * @return string 格式化后的支付方式
     */
    private function formatPaymentMethod($paymentMethod) {
        $paymentMethods = [
            'alipay' => '支付宝',
            'wechat' => '微信支付',
            'balance' => '余额支付'
        ];
        
        return isset($paymentMethods[$paymentMethod]) ? $paymentMethods[$paymentMethod] : $paymentMethod;
    }
    
    /**
     * 生成导出文件名
     * @param string $exportType 导出类型
     * @param string $format 文件格式
     * @return string 文件名
     */
    private function generateExportFilename($exportType, $format) {
        $typePrefix = '';
        switch ($exportType) {
            case self::EXPORT_TYPE_PROMOTION:
                $typePrefix = 'promotion_';
                break;
            case self::EXPORT_TYPE_ABNORMAL:
                $typePrefix = 'abnormal_';
                break;
            case self::EXPORT_TYPE_PERIOD:
                $typePrefix = 'period_';
                break;
        }
        
        return 'orders_' . $typePrefix . date('Y-m-d_H-i-s') . '.' . $format;
    }
    
    /**
     * 导出财务报表
     */
    public function exportFinancialReport($filters = array(), $format = 'csv') {
        try {
            // 构建查询
            $query = $this->buildFinancialQuery($filters);
            $data = $this->database->fetchAll($query['sql'], $query['params']);
            
            // 导出文件
            $filename = 'financial_report_' . date('Y-m-d_H-i-s') . '.' . $format;
            $filepath = $this->exportFile($data, $filename, $format);
            
            $this->logger->logInfo("财务报表导出完成", array(
                'format' => $format,
                'count' => count($data),
                'filename' => $filename
            ));
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'count' => count($data)
            ];
            
        } catch (Exception $e) {
            $this->logger->logError("财务报表导出失败", array(
                'format' => $format,
                'error' => $e->getMessage()
            ));
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 构建卡密查询
     */
    private function buildCardQuery($filters) {
        $sql = "
            SELECT c.*, p.name as product_name, u.username as user_name
            FROM cards c
            LEFT JOIN products p ON c.product_id = p.id
            LEFT JOIN users u ON c.user_id = u.id
            WHERE 1=1
        ";
        $params = array();
        
        // 添加过滤条件
        if (!empty($filters['product_id'])) {
            $sql .= " AND c.product_id = ?";
            $params[] = $filters['product_id'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND c.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['user_id'])) {
            $sql .= " AND c.user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND c.created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND c.created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        $sql .= " ORDER BY c.created_at DESC";
        
        return array('sql' => $sql, 'params' => $params);
    }
    
    /**
     * 构建产品查询
     */
    private function buildProductQuery($filters) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE 1=1
        ";
        $params = array();
        
        // 添加过滤条件
        if (!empty($filters['category_id'])) {
            $sql .= " AND p.category_id = ?";
            $params[] = $filters['category_id'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND p.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['min_price'])) {
            $sql .= " AND p.price >= ?";
            $params[] = $filters['min_price'];
        }
        
        if (!empty($filters['max_price'])) {
            $sql .= " AND p.price <= ?";
            $params[] = $filters['max_price'];
        }
        
        $sql .= " ORDER BY p.created_at DESC";
        
        return array('sql' => $sql, 'params' => $params);
    }
    
    /**
     * 构建用户查询
     */
    private function buildUserQuery($filters) {
        $sql = "
            SELECT id, username, email, role, status, phone, real_name, created_at, last_login
            FROM users
            WHERE 1=1
        ";
        $params = array();
        
        // 添加过滤条件
        if (!empty($filters['role'])) {
            $sql .= " AND role = ?";
            $params[] = $filters['role'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        return array('sql' => $sql, 'params' => $params);
    }
    
    /**
     * 构建订单查询
     */
    private function buildOrderQuery($filters) {
        $sql = "
            SELECT o.*, u.username as user_name, p.name as product_name
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            LEFT JOIN products p ON o.product_id = p.id
            WHERE 1=1
        ";
        $params = array();
        
        // 添加过滤条件
        if (!empty($filters['status'])) {
            $sql .= " AND o.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['user_id'])) {
            $sql .= " AND o.user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND o.created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND o.created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        $sql .= " ORDER BY o.created_at DESC";
        
        return array('sql' => $sql, 'params' => $params);
    }
    
    /**
     * 构建财务查询
     */
    private function buildFinancialQuery($filters) {
        $sql = "
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as order_count,
                SUM(amount) as total_amount,
                SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as completed_amount,
                SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as pending_amount,
                SUM(CASE WHEN status = 'cancelled' THEN amount ELSE 0 END) as cancelled_amount
            FROM orders
            WHERE 1=1
        ";
        $params = array();
        
        // 添加过滤条件
        if (!empty($filters['date_from'])) {
            $sql .= " AND created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        $sql .= " GROUP BY DATE(created_at) ORDER BY date DESC";
        
        return array('sql' => $sql, 'params' => $params);
    }
    
    /**
     * 格式化卡密数据
     */
    private function formatCardData($cards) {
        $data = array();
        
        foreach ($cards as $card) {
            $data[] = array(
                'ID' => $card['id'],
                '卡密' => $card['card_code'],
                '产品' => isset($card['product_name']) ? $card['product_name'] : '未知产品',
                '用户' => isset($card['user_name']) ? $card['user_name'] : '未分配',
                '状态' => $this->getCardStatusText($card['status']),
                '创建时间' => $card['created_at'],
                '过期时间' => isset($card['expires_at']) ? $card['expires_at'] : '永不过期',
                '备注' => isset($card['notes']) ? $card['notes'] : ''
            );
        }
        
        return $data;
    }
    
    /**
     * 格式化产品数据
     */
    private function formatProductData($products) {
        $data = array();
        
        foreach ($products as $product) {
            $data[] = array(
                'ID' => $product['id'],
                '产品名称' => $product['name'],
                '价格' => number_format($product['price'], 2),
                '分类' => isset($product['category_name']) ? $product['category_name'] : '未分类',
                '库存' => isset($product['stock']) ? $product['stock'] : 0,
                '状态' => $this->getProductStatusText($product['status']),
                '描述' => isset($product['description']) ? $product['description'] : '',
                '创建时间' => $product['created_at']
            );
        }
        
        return $data;
    }
    
    /**
     * 格式化用户数据
     */
    private function formatUserData($users) {
        $data = array();
        
        foreach ($users as $user) {
            $data[] = array(
                'ID' => $user['id'],
                '用户名' => $user['username'],
                '邮箱' => $user['email'],
                '角色' => $this->getRoleText($user['role']),
                '状态' => $this->getUserStatusText($user['status']),
                '电话' => isset($user['phone']) ? $user['phone'] : '',
                '真实姓名' => isset($user['real_name']) ? $user['real_name'] : '',
                '注册时间' => $user['created_at'],
                '最后登录' => isset($user['last_login']) ? $user['last_login'] : '从未登录'
            );
        }
        
        return $data;
    }
    
    /**
     * 格式化订单数据
     */
    private function formatOrderData($orders, $fields = array()) {
        $data = array();
        
        // 如果没有指定字段，使用默认字段
        if (empty($fields)) {
            $fields = ['id', 'user_name', 'product_name', 'amount', 'status', 
                'payment_method', 'created_at', 'paid_at'];
        }
        
        foreach ($orders as $order) {
            $row = array();
            
            foreach ($fields as $field) {
                $label = $this->getFieldLabel($field);
                $value = '';
                
                if (isset($order[$field])) {
                    if ($field === 'amount') {
                        $value = number_format($order[$field], 2);
                    } else {
                        $value = $order[$field];
                    }
                }
                
                $row[$label] = $value;
            }
            
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * 获取字段对应的中文标签
     * @param string $field 字段名
     * @return string 中文标签
     */
    private function getFieldLabel($field) {
        $labels = [
            'id' => '订单号',
            'user_name' => '用户',
            'product_name' => '产品',
            'amount' => '金额',
            'status' => '状态',
            'payment_method' => '支付方式',
            'created_at' => '创建时间',
            'paid_at' => '支付时间',
            'agent_id' => '代理ID',
            'agent_name' => '代理名称',
            'agent_commission' => '代理佣金',
            'refund_status' => '退款状态',
            'dispute_reason' => '纠纷原因'
        ];
        
        return isset($labels[$field]) ? $labels[$field] : $field;
    }
    
    /**
     * 获取可用的导出字段选项
     * @return array 字段选项列表
     */
    public function getExportFieldOptions() {
        $allFields = $this->getAllAvailableFields();
        $options = [];
        
        foreach ($allFields as $field) {
            $options[] = [
                'value' => $field,
                'label' => $this->getFieldLabel($field)
            ];
        }
        
        return $options;
    }
    
    /**
     * 获取导出类型选项
     * @return array 导出类型选项
     */
    public function getExportTypeOptions() {
        return [
            ['value' => self::EXPORT_TYPE_NORMAL, 'label' => '普通订单'],
            ['value' => self::EXPORT_TYPE_PROMOTION, 'label' => '代理推广订单'],
            ['value' => self::EXPORT_TYPE_ABNORMAL, 'label' => '异常订单'],
            ['value' => self::EXPORT_TYPE_PERIOD, 'label' => '时间段订单']
        ];
    }
    
    /**
     * 导出文件
     */
    private function exportFile($data, $filename, $format) {
        $filepath = $this->exportDir . $filename;
        
        switch ($format) {
            case 'csv':
                $this->exportToCSV($data, $filepath);
                break;
            case 'xlsx':
                $this->exportToExcel($data, $filepath);
                break;
            case 'pdf':
                $this->exportToPDF($data, $filepath);
                break;
            default:
                throw new Exception('不支持的导出格式');
        }
        
        return $filepath;
    }
    
    /**
     * 导出为CSV
     */
    private function exportToCSV($data, $filepath) {
        if (empty($data)) {
            throw new Exception('没有数据可导出');
        }
        
        $handle = fopen($filepath, 'w');
        if ($handle === false) {
            throw new Exception('无法创建文件');
        }
        
        // 添加BOM以支持中文
        fwrite($handle, "\xEF\xBB\xBF");
        
        // 写入标题行
        $headers = array_keys($data[0]);
        fputcsv($handle, $headers);
        
        // 写入数据行
        foreach ($data as $row) {
            fputcsv($handle, $row);
        }
        
        fclose($handle);
    }
    
    /**
     * 导出为Excel
     */
    private function exportToExcel($data, $filepath) {
        // 这里应该集成PhpSpreadsheet库
        // 为了演示，先导出为CSV
        $this->exportToCSV($data, $filepath);
    }
    
    /**
     * 导出为PDF
     */
    private function exportToPDF($data, $filepath) {
        // 这里应该集成TCPDF或FPDF库
        // 为了演示，先导出为CSV
        $this->exportToCSV($data, $filepath);
    }
    
    /**
     * 获取卡密状态文本
     */
    private function getCardStatusText($status) {
        $statuses = array(
            'available' => '可用',
            'sold' => '已售出',
            'expired' => '已过期',
            'disabled' => '已禁用'
        );
        
        return isset($statuses[$status]) ? $statuses[$status] : $status;
    }
    
    /**
     * 获取产品状态文本
     */
    private function getProductStatusText($status) {
        $statuses = array(
            'active' => '上架',
            'inactive' => '下架',
            'out_of_stock' => '缺货'
        );
        
        return isset($statuses[$status]) ? $statuses[$status] : $status;
    }
    
    /**
     * 获取角色文本
     */
    private function getRoleText($role) {
        $roles = array(
            'admin' => '管理员',
            'agent' => '代理',
            'user' => '用户'
        );
        
        return isset($roles[$role]) ? $roles[$role] : $role;
    }
    
    /**
     * 获取用户状态文本
     */
    private function getUserStatusText($status) {
        $statuses = array(
            'active' => '正常',
            'disabled' => '禁用',
            'banned' => '封禁'
        );
        
        return isset($statuses[$status]) ? $statuses[$status] : $status;
    }
    
    /**
     * 获取订单状态文本
     */
    private function getOrderStatusText($status) {
        $statuses = array(
            'pending' => '待支付',
            'paid' => '已支付',
            'completed' => '已完成',
            'cancelled' => '已取消',
            'refunded' => '已退款'
        );
        
        return isset($statuses[$status]) ? $statuses[$status] : $status;
    }
    
    /**
     * 获取导出文件列表
     */
    public function getExportFiles() {
        $files = array();
        
        if (is_dir($this->exportDir)) {
            $items = scandir($this->exportDir);
            
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                
                $filepath = $this->exportDir . $item;
                if (is_file($filepath)) {
                    $files[] = array(
                        'filename' => $item,
                        'filepath' => $filepath,
                        'size' => filesize($filepath),
                        'created_at' => filemtime($filepath)
                    );
                }
            }
        }
        
        // 按创建时间倒序排列
        usort($files, function($a, $b) {
            return $b['created_at'] - $a['created_at'];
        });
        
        return $files;
    }
    
    /**
     * 删除导出文件
     */
    public function deleteExportFile($filename) {
        $filepath = $this->exportDir . $filename;
        
        if (!file_exists($filepath)) {
            return array('success' => false, 'message' => '文件不存在');
        }
        
        if (unlink($filepath)) {
            $this->logger->logInfo("导出文件删除成功", array('filename' => $filename));
            return array('success' => true);
        } else {
            return array('success' => false, 'message' => '删除失败');
        }
    }
    
    /**
     * 清理过期导出文件
     */
    public function cleanExpiredExports($days = 7) {
        $files = $this->getExportFiles();
        $deletedCount = 0;
        $expiredTime = time() - ($days * 24 * 60 * 60);
        
        foreach ($files as $file) {
            if ($file['created_at'] < $expiredTime) {
                if (unlink($file['filepath'])) {
                    $deletedCount++;
                }
            }
        }
        
        $this->logger->logInfo("过期导出文件清理完成", array(
            'deleted_count' => $deletedCount,
            'days' => $days
        ));
        
        return array('success' => true, 'deleted_count' => $deletedCount);
    }
}