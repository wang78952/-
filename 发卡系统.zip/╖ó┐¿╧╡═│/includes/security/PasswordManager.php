<?php
/**
 * 密码管理器类
 * 处理密码哈希、验证、重置等安全相关功能
 * 
 * @package includes/security
 */

class PasswordManager {
    /**
     * 默认密码哈希选项
     * @var array
     */
    private $defaultOptions = [
        'cost' => 12, // bcrypt工作因子
        'algo' => PASSWORD_BCRYPT, // 默认哈希算法
        'verify_old_passwords' => true, // 支持验证旧算法哈希的密码
        'enforce_history' => true, // 强制执行密码历史记录
        'history_limit' => 5, // 记住的历史密码数量
        'min_length' => 8, // 最小密码长度
        'require_uppercase' => true, // 要求大写字母
        'require_lowercase' => true, // 要求小写字母
        'require_number' => true, // 要求数字
        'require_special_char' => true, // 要求特殊字符
        'special_chars' => '!@#$%^&*()-_=+[]{}|;:,.<>?', // 允许的特殊字符
        'password_expiry_days' => 90, // 密码过期天数
        'min_unlock_time' => 300, // 账户锁定最短时间（秒）
        'max_failed_attempts' => 5, // 最大失败尝试次数
        'lockout_duration' => 86400, // 锁定时长（秒）
        'prevent_common_passwords' => true, // 阻止常见密码
        'common_passwords_path' => null, // 常见密码文件路径
        'password_blacklist' => [] // 密码黑名单
    ];
    
    /**
     * 配置选项
     * @var array
     */
    private $options = [];
    
    /**
     * 常见密码缓存
     * @var array
     */
    private $commonPasswords = [];
    
    /**
     * 构造函数
     * @param array $options 配置选项
     */
    public function __construct(array $options = []) {
        $this->options = array_merge($this->defaultOptions, $options);
        $this->loadCommonPasswords();
    }
    
    /**
     * 加载常见密码列表
     */
    private function loadCommonPasswords() {
        if (!$this->options['prevent_common_passwords']) {
            return;
        }
        
        // 如果提供了常见密码文件路径
        if ($this->options['common_passwords_path'] && file_exists($this->options['common_passwords_path'])) {
            $this->commonPasswords = file($this->options['common_passwords_path'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        } else {
            // 内置的常见密码列表（简化版）
            $this->commonPasswords = [
                '123456', 'password', '12345678', 'qwerty', '123456789', '12345', '1234', '111111', 
                '1234567', 'dragon', '123123', 'baseball', 'abc123', 'football', 'monkey', 'letmein', 
                '696969', 'shadow', 'master', '666666', 'qwertyuiop', '123321', 'mustang', '1234567890',
                'michael', '654321', 'superman', '1qaz2wsx', '7777777', '121212', '000000', 'qazwsxedc',
                '123qwe', 'killer', 'trustno1', 'jordan', 'jennifer', 'zxcvbnm', 'asdfgh', 'hunter',
                'buster', 'soccer', 'harley', 'batman', 'andrew', 'tigger', 'sunshine', 'iloveyou'
            ];
        }
        
        // 添加密码黑名单
        if (!empty($this->options['password_blacklist'])) {
            $this->commonPasswords = array_merge($this->commonPasswords, $this->options['password_blacklist']);
        }
        
        // 去重并转换为小写
        $this->commonPasswords = array_unique(array_map('strtolower', $this->commonPasswords));
    }
    
    /**
     * 生成密码哈希
     * @param string $password 明文密码
     * @param array $options 哈希选项
     * @return string 哈希后的密码
     * @throws Exception
     */
    public function hashPassword($password, array $options = []) {
        // 验证密码强度
        if (!$this->validatePasswordStrength($password)) {
            throw new Exception('密码不符合强度要求');
        }
        
        // 检查是否是常见密码
        if ($this->isCommonPassword($password)) {
            throw new Exception('密码过于常见，请选择更安全的密码');
        }
        
        // 合并选项
        $hashOptions = array_merge(
            ['cost' => $this->options['cost']],
            $options
        );
        
        // 生成哈希
        $hash = password_hash($password, $this->options['algo'], $hashOptions);
        
        if ($hash === false) {
            throw new Exception('密码哈希生成失败');
        }
        
        return $hash;
    }
    
    /**
     * 验证密码
     * @param string $password 明文密码
     * @param string $hash 哈希密码
     * @return bool 是否匹配
     */
    public function verifyPassword($password, $hash) {
        if (empty($password) || empty($hash)) {
            return false;
        }
        
        // 使用PHP内置函数验证
        $isValid = password_verify($password, $hash);
        
        // 如果验证成功且需要重新哈希
        if ($isValid && password_needs_rehash($hash, $this->options['algo'], ['cost' => $this->options['cost']])) {
            // 这里应该在调用方更新哈希值
            // 注意：不要在verifyPassword中直接更新数据库
        }
        
        return $isValid;
    }
    
    /**
     * 检查密码是否需要重新哈希
     * @param string $hash 哈希密码
     * @return bool 是否需要重新哈希
     */
    public function needsRehash($hash) {
        return password_needs_rehash($hash, $this->options['algo'], ['cost' => $this->options['cost']]);
    }
    
    /**
     * 验证密码强度
     * @param string $password 待验证的密码
     * @return bool 是否符合强度要求
     */
    public function validatePasswordStrength($password) {
        // 检查长度
        if (strlen($password) < $this->options['min_length']) {
            return false;
        }
        
        // 检查大写字母
        if ($this->options['require_uppercase'] && !preg_match('/[A-Z]/', $password)) {
            return false;
        }
        
        // 检查小写字母
        if ($this->options['require_lowercase'] && !preg_match('/[a-z]/', $password)) {
            return false;
        }
        
        // 检查数字
        if ($this->options['require_number'] && !preg_match('/[0-9]/', $password)) {
            return false;
        }
        
        // 检查特殊字符
        if ($this->options['require_special_char']) {
            $specialCharsPattern = '/' . preg_quote($this->options['special_chars'], '/') . '/';
            if (!preg_match($specialCharsPattern, $password)) {
                return false;
            }
        }
        
        // 检查键盘序列
        if ($this->containsKeyboardSequence($password)) {
            return false;
        }
        
        // 检查重复字符
        if ($this->containsRepeatedCharacters($password)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 检查密码是否是常见密码
     * @param string $password 待检查的密码
     * @return bool 是否是常见密码
     */
    public function isCommonPassword($password) {
        if (!$this->options['prevent_common_passwords']) {
            return false;
        }
        
        // 转换为小写进行比较
        $lowerPassword = strtolower($password);
        
        // 检查是否在常见密码列表中
        return in_array($lowerPassword, $this->commonPasswords);
    }
    
    /**
     * 检查密码是否与历史密码相似
     * @param string $newPassword 新密码
     * @param array $historyPasswords 历史密码哈希列表
     * @return bool 是否与历史密码太相似
     */
    public function isSimilarToHistory($newPassword, array $historyPasswords) {
        if (!$this->options['enforce_history'] || empty($historyPasswords)) {
            return false;
        }
        
        // 检查是否与历史密码相同
        foreach ($historyPasswords as $historyHash) {
            if (password_verify($newPassword, $historyHash)) {
                return true;
            }
        }
        
        // 检查相似性（字符变化小于30%）
        $threshold = 0.3;
        $newPasswordLower = strtolower($newPassword);
        
        foreach ($historyPasswords as $historyHash) {
            // 注意：这里需要明文历史密码才能比较相似性
            // 实际应用中，可能需要存储明文历史密码或使用其他算法
            // 这里仅作为示例
        }
        
        return false;
    }
    
    /**
     * 生成随机密码
     * @param int $length 密码长度
     * @param array $options 生成选项
     * @return string 随机生成的密码
     */
    public function generateRandomPassword($length = 12, array $options = []) {
        // 合并选项
        $options = array_merge($this->options, $options);
        
        // 字符集
        $chars = '';
        
        // 添加小写字母
        if ($options['require_lowercase']) {
            $chars .= 'abcdefghijklmnopqrstuvwxyz';
        }
        
        // 添加大写字母
        if ($options['require_uppercase']) {
            $chars .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        }
        
        // 添加数字
        if ($options['require_number']) {
            $chars .= '0123456789';
        }
        
        // 添加特殊字符
        if ($options['require_special_char']) {
            $chars .= $options['special_chars'];
        }
        
        // 如果没有要求特殊字符，添加一些常见的
        if (empty($chars)) {
            $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%';
        }
        
        $password = '';
        $charsLength = strlen($chars);
        
        // 生成密码
        for ($i = 0; $i < $length; $i++) {
            // 使用random_int获取安全的随机数
            $password .= $chars[random_int(0, $charsLength - 1)];
        }
        
        // 确保密码符合强度要求
        if (!$this->validatePasswordStrength($password)) {
            // 如果不符合，重新生成
            return $this->generateRandomPassword($length, $options);
        }
        
        return $password;
    }
    
    /**
     * 生成密码重置令牌
     * @param int $length 令牌长度
     * @return string 重置令牌
     */
    public function generateResetToken($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
    
    /**
     * 验证令牌是否有效（未过期）
     * @param string $token 令牌
     * @param string $storedToken 存储的令牌
     * @param int $timestamp 令牌生成时间戳
     * @param int $expiry 过期时间（秒）
     * @return bool 是否有效
     */
    public function validateToken($token, $storedToken, $timestamp, $expiry = 3600) {
        // 检查令牌是否为空
        if (empty($token) || empty($storedToken)) {
            return false;
        }
        
        // 检查令牌是否过期
        if (time() - $timestamp > $expiry) {
            return false;
        }
        
        // 使用恒定时间比较防止计时攻击
        return hash_equals($storedToken, $token);
    }
    
    /**
     * 计算密码强度得分
     * @param string $password 密码
     * @return int 强度得分（0-100）
     */
    public function calculatePasswordScore($password) {
        $score = 0;
        $length = strlen($password);
        
        // 长度得分（最多40分）
        $score += min($length * 4, 40);
        
        // 包含小写字母（10分）
        if (preg_match('/[a-z]/', $password)) {
            $score += 10;
        }
        
        // 包含大写字母（10分）
        if (preg_match('/[A-Z]/', $password)) {
            $score += 10;
        }
        
        // 包含数字（10分）
        if (preg_match('/[0-9]/', $password)) {
            $score += 10;
        }
        
        // 包含特殊字符（10分）
        if (preg_match('/[^a-zA-Z0-9]/', $password)) {
            $score += 10;
        }
        
        // 字符多样性（最多20分）
        $uniqueChars = count(array_unique(str_split($password)));
        $diversity = $uniqueChars / $length;
        $score += min($diversity * 20, 20);
        
        // 减去常见密码惩罚
        if ($this->isCommonPassword($password)) {
            $score -= 30;
        }
        
        // 减去键盘序列惩罚
        if ($this->containsKeyboardSequence($password)) {
            $score -= 20;
        }
        
        // 确保分数在0-100之间
        return max(0, min(100, $score));
    }
    
    /**
     * 获取密码强度评级
     * @param int $score 密码强度得分
     * @return string 强度评级
     */
    public function getPasswordStrengthLabel($score) {
        if ($score < 20) {
            return '极弱';
        } elseif ($score < 40) {
            return '弱';
        } elseif ($score < 60) {
            return '中等';
        } elseif ($score < 80) {
            return '强';
        } else {
            return '极强';
        }
    }
    
    /**
     * 检查密码是否包含键盘序列
     * @param string $password 密码
     * @return bool 是否包含键盘序列
     */
    private function containsKeyboardSequence($password) {
        // 常见键盘序列
        $sequences = [
            // 水平序列
            'qwertyuiop', 'asdfghjkl', 'zxcvbnm',
            'poiuytrewq', 'lkjhgfdsa', 'mnbvcxz',
            '1234567890', '0987654321',
            // 垂直序列
            'qazwsxedc', 'wsxedcrfv', 'edcrfvtgb', 'rfvtgbnhy', 'fvtgbnhyj',
            'tgbnhyjuk', 'gbnhyjukm', 'bnm', 'mnb',
            'zaqwsxedc', 'xswzaq', 'cdewsx',
            // 数字序列
            '1qaz2wsx', '2wsx3edc', '3edc4rfv', '4rfv5tgb', '5tgb6yhn', '6yhn7ujm'
        ];
        
        $lowerPassword = strtolower($password);
        
        // 检查是否包含至少3个连续字符的序列
        foreach ($sequences as $seq) {
            $seqLength = strlen($seq);
            for ($i = 0; $i <= $seqLength - 3; $i++) {
                $subseq = substr($seq, $i, 3);
                if (strpos($lowerPassword, $subseq) !== false) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 检查密码是否包含重复字符
     * @param string $password 密码
     * @return bool 是否包含重复字符
     */
    private function containsRepeatedCharacters($password) {
        // 检查连续重复字符
        if (preg_match('/(.)\1{3,}/', $password)) {
            return true;
        }
        
        // 检查模式重复（如ababab）
        if (preg_match('/(.{2,})\1{2,}/', $password)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 创建账户锁定记录
     * @param string $username 用户名
     * @param string $ip IP地址
     * @return array 锁定记录
     */
    public function createLockoutRecord($username, $ip) {
        return [
            'username' => $username,
            'ip' => $ip,
            'locked_at' => time(),
            'expires_at' => time() + $this->options['lockout_duration'],
            'reason' => '多次登录失败'
        ];
    }
    
    /**
     * 检查账户是否被锁定
     * @param array $lockoutRecord 锁定记录
     * @return bool 是否被锁定
     */
    public function isAccountLocked($lockoutRecord) {
        if (empty($lockoutRecord) || !isset($lockoutRecord['expires_at'])) {
            return false;
        }
        
        return time() < $lockoutRecord['expires_at'];
    }
    
    /**
     * 获取剩余锁定时间
     * @param array $lockoutRecord 锁定记录
     * @return int 剩余锁定时间（秒）
     */
    public function getRemainingLockoutTime($lockoutRecord) {
        if (!$this->isAccountLocked($lockoutRecord)) {
            return 0;
        }
        
        return max(0, $lockoutRecord['expires_at'] - time());
    }
    
    /**
     * 记录密码变更
     * @param int $userId 用户ID
     * @param string $passwordHash 新密码哈希
     * @param string $reason 变更原因
     * @return array 变更记录
     */
    public function createPasswordChangeRecord($userId, $passwordHash, $reason = '用户主动修改') {
        return [
            'user_id' => $userId,
            'password_hash' => $passwordHash,
            'changed_at' => time(),
            'changed_by' => $userId, // 自己修改
            'reason' => $reason,
            'ip_address' => $this->getClientIp()
        ];
    }
    
    /**
     * 获取客户端IP地址
     * @return string IP地址
     */
    private function getClientIp() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        // 检查代理IP头
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_REAL_IP'])) {
            $ip = $_SERVER['HTTP_X_REAL_IP'];
        }
        
        return $ip;
    }
    
    /**
     * 更新选项
     * @param array $options 新选项
     */
    public function updateOptions(array $options) {
        $this->options = array_merge($this->options, $options);
        
        // 如果更新了常见密码相关选项，重新加载
        if (isset($options['prevent_common_passwords']) || isset($options['common_passwords_path']) || isset($options['password_blacklist'])) {
            $this->loadCommonPasswords();
        }
    }
    
    /**
     * 获取选项
     * @return array 当前选项
     */
    public function getOptions() {
        return $this->options;
    }
    
    /**
     * 安全地生成随机字符串
     * @param int $length 长度
     * @param string $chars 可选字符
     * @return string 随机字符串
     */
    public function generateRandomString($length = 32, $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') {
        $result = '';
        $charsLength = strlen($chars);
        
        for ($i = 0; $i < $length; $i++) {
            $result .= $chars[random_int(0, $charsLength - 1)];
        }
        
        return $result;
    }
    
    /**
     * 检查密码是否即将过期
     * @param int $lastChangeTime 上次密码变更时间戳
     * @param int $daysWarning 提前警告天数
     * @return bool 是否即将过期
     */
    public function isPasswordExpiringSoon($lastChangeTime, $daysWarning = 7) {
        if (!$this->options['password_expiry_days']) {
            return false;
        }
        
        $expiryTime = $lastChangeTime + ($this->options['password_expiry_days'] * 86400);
        $warningTime = $expiryTime - ($daysWarning * 86400);
        
        return time() > $warningTime && time() < $expiryTime;
    }
    
    /**
     * 检查密码是否已过期
     * @param int $lastChangeTime 上次密码变更时间戳
     * @return bool 是否已过期
     */
    public function isPasswordExpired($lastChangeTime) {
        if (!$this->options['password_expiry_days']) {
            return false;
        }
        
        $expiryTime = $lastChangeTime + ($this->options['password_expiry_days'] * 86400);
        return time() > $expiryTime;
    }
}

// 全局函数：获取密码管理器实例
function passwordManager(array $options = []) {
    static $instance = null;
    
    if ($instance === null) {
        $instance = new PasswordManager($options);
    }
    
    return $instance;
}