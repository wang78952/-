<?php
/**
 * 数据加密系统
 * 提供敏感数据加密、解密、脱敏等功能，确保数据安全
 * 
 * @author System Developer
 * @version 1.0.0
 * @copyright © 2025 发卡系统. All rights reserved.
 */

namespace Security;

use Exception;

class DataEncryption {
    /**
     * 加密算法
     */
    const ALGORITHM_AES_256_GCM = 'aes-256-gcm';
    const ALGORITHM_AES_256_CBC = 'aes-256-cbc';
    const ALGORITHM_RSA = 'RSA';
    
    /**
     * 默认配置
     */
    const DEFAULT_ALGORITHM = self::ALGORITHM_AES_256_GCM;
    const DEFAULT_KEY_LENGTH = 32; // 256位
    const IV_LENGTH = 12; // GCM模式推荐的IV长度
    const TAG_LENGTH = 16; // GCM模式的认证标签长度
    
    /**
     * 密钥管理
     * @var array
     */
    private $keys = [];
    
    /**
     * 数据库实例
     * @var Database
     */
    private $db;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     */
    public function __construct($db) {
        $this->db = $db;
        $this->loadKeys();
    }
    
    /**
     * 加载加密密钥
     */
    private function loadKeys() {
        // 从数据库加载密钥
        $keys = $this->db->query(
            "SELECT * FROM encryption_keys WHERE active = 1 ORDER BY created_at DESC"
        );
        
        foreach ($keys as $key) {
            // 密钥版本管理
            $this->keys[$key['key_version']] = $key['encryption_key'];
        }
        
        // 如果没有活跃密钥，生成默认密钥
        if (empty($this->keys)) {
            $this->generateMasterKey();
        }
    }
    
    /**
     * 生成主密钥
     */
    private function generateMasterKey() {
        // 生成随机密钥
        $key = openssl_random_pseudo_bytes(self::DEFAULT_KEY_LENGTH);
        $keyHex = bin2hex($key);
        $keyVersion = date('YmdHis') . random_int(1000, 9999);
        
        // 存储到数据库
        $this->db->insert('encryption_keys', [
            'key_version' => $keyVersion,
            'encryption_key' => $keyHex,
            'algorithm' => self::DEFAULT_ALGORITHM,
            'active' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => 0
        ]);
        
        // 更新当前密钥
        $this->keys[$keyVersion] = $keyHex;
    }
    
    /**
     * 加密数据
     * @param mixed $data 待加密数据
     * @param string $algorithm 加密算法
     * @return string 加密后的数据（包含版本、IV、标签等信息）
     */
    public function encrypt($data, $algorithm = self::DEFAULT_ALGORITHM) {
        // 序列化数据
        if (!is_string($data)) {
            $data = json_encode($data);
        }
        
        // 获取最新的密钥
        $keyVersions = array_keys($this->keys);
        $keyVersion = end($keyVersions);
        $keyHex = $this->keys[$keyVersion];
        $key = hex2bin($keyHex);
        
        // 根据算法执行加密
        if ($algorithm === self::ALGORITHM_AES_256_GCM) {
            // 生成随机IV
            $iv = openssl_random_pseudo_bytes(self::IV_LENGTH);
            
            // 加密
            $encrypted = openssl_encrypt(
                $data,
                $algorithm,
                $key,
                OPENSSL_RAW_DATA,
                $iv,
                $tag
            );
            
            // 组装加密数据：版本+IV+标签+密文
            $result = $keyVersion . ':' . base64_encode($iv . $tag . $encrypted);
        } else if ($algorithm === self::ALGORITHM_AES_256_CBC) {
            // CBC模式使用16字节IV
            $iv = openssl_random_pseudo_bytes(16);
            
            // 加密
            $encrypted = openssl_encrypt(
                $data,
                $algorithm,
                $key,
                OPENSSL_RAW_DATA,
                $iv
            );
            
            // 组装加密数据
            $result = $keyVersion . ':' . base64_encode($iv . $encrypted);
        } else {
            throw new Exception("不支持的加密算法: {$algorithm}");
        }
        
        return $result;
    }
    
    /**
     * 解密数据
     * @param string $data 加密数据
     * @return mixed 解密后的数据
     */
    public function decrypt($data) {
        // 分割版本和加密数据
        $parts = explode(':', $data, 2);
        if (count($parts) != 2) {
            throw new Exception('无效的加密数据格式');
        }
        
        $keyVersion = $parts[0];
        $encryptedData = base64_decode($parts[1]);
        
        // 检查密钥是否存在
        if (!isset($this->keys[$keyVersion])) {
            throw new Exception("未找到对应的加密密钥版本: {$keyVersion}");
        }
        
        // 获取密钥
        $keyHex = $this->keys[$keyVersion];
        $key = hex2bin($keyHex);
        
        // 查询密钥的算法
        $keyInfo = $this->db->queryFirstRow(
            "SELECT algorithm FROM encryption_keys WHERE key_version = %s",
            $keyVersion
        );
        
        $algorithm = $keyInfo ? $keyInfo['algorithm'] : self::DEFAULT_ALGORITHM;
        
        // 根据算法解密
        if ($algorithm === self::ALGORITHM_AES_256_GCM) {
            // 提取IV、标签和密文
            $iv = substr($encryptedData, 0, self::IV_LENGTH);
            $tag = substr($encryptedData, self::IV_LENGTH, self::TAG_LENGTH);
            $ciphertext = substr($encryptedData, self::IV_LENGTH + self::TAG_LENGTH);
            
            // 解密
            $decrypted = openssl_decrypt(
                $ciphertext,
                $algorithm,
                $key,
                OPENSSL_RAW_DATA,
                $iv,
                $tag
            );
        } else if ($algorithm === self::ALGORITHM_AES_256_CBC) {
            // CBC模式IV长度为16字节
            $iv = substr($encryptedData, 0, 16);
            $ciphertext = substr($encryptedData, 16);
            
            // 解密
            $decrypted = openssl_decrypt(
                $ciphertext,
                $algorithm,
                $key,
                OPENSSL_RAW_DATA,
                $iv
            );
        } else {
            throw new Exception("不支持的解密算法: {$algorithm}");
        }
        
        // 尝试反序列化
        $result = json_decode($decrypted, true);
        
        // 如果不是JSON，返回原字符串
        return $result !== null ? $result : $decrypted;
    }
    
    /**
     * 数据脱敏
     * @param mixed $data 待脱敏数据
     * @param string $dataType 数据类型
     * @return mixed 脱敏后的数据
     */
    public function maskData($data, $dataType) {
        switch ($dataType) {
            case 'phone':
                // 手机号脱敏：138****8888
                return preg_replace('/(\\d{3})\\d{4}(\\d{4})/', '\\1****\\2', $data);
            case 'email':
                // 邮箱脱敏：u***r@example.com
                return preg_replace('/(^.{1})[^@]*(@.*$)/', '\\1***\\2', $data);
            case 'id_card':
                // 身份证脱敏：110***********1234
                return preg_replace('/(\\d{3})\\d{11}(\\d{4})/', '\\1***********\\2', $data);
            case 'bank_card':
                // 银行卡号脱敏：6222 **** **** 1234
                return preg_replace('/(\\d{4})\\d{12}(\\d{4})/', '\\1 **** **** \\2', $data);
            case 'password':
                // 密码脱敏
                return '******';
            case 'credit_card':
                // 信用卡脱敏
                return preg_replace('/(\\d{4})\\d{12}(\\d{4})/', '\\1********\\2', $data);
            case 'address':
                // 地址脱敏：保留省市，隐藏详细地址
                return preg_replace('/(.*?[省市自治区])(.*?)$/', '\\1***', $data);
            case 'array':
                // 数组脱敏
                if (is_array($data)) {
                    $masked = [];
                    foreach ($data as $key => $value) {
                        // 根据键名自动识别数据类型
                        $fieldType = $this->detectFieldType($key);
                        $masked[$key] = $this->maskData($value, $fieldType);
                    }
                    return $masked;
                }
                return $data;
            default:
                // 默认脱敏：保留前3后2
                $len = strlen($data);
                if ($len > 5) {
                    return substr($data, 0, 3) . str_repeat('*', $len - 5) . substr($data, -2);
                }
                return '***';
        }
    }
    
    /**
     * 自动检测字段类型
     * @param string $fieldName 字段名
     * @return string 数据类型
     */
    private function detectFieldType($fieldName) {
        $fieldName = strtolower($fieldName);
        
        if (strpos($fieldName, 'phone') !== false || strpos($fieldName, 'mobile') !== false) {
            return 'phone';
        } else if (strpos($fieldName, 'email') !== false) {
            return 'email';
        } else if (strpos($fieldName, 'idcard') !== false || strpos($fieldName, 'identity') !== false) {
            return 'id_card';
        } else if (strpos($fieldName, 'bank') !== false) {
            return 'bank_card';
        } else if (strpos($fieldName, 'password') !== false) {
            return 'password';
        } else if (strpos($fieldName, 'credit') !== false) {
            return 'credit_card';
        } else if (strpos($fieldName, 'address') !== false) {
            return 'address';
        }
        
        return 'default';
    }
    
    /**
     * 生成随机盐值
     * @param int $length 盐值长度
     * @return string 盐值
     */
    public function generateSalt($length = 16) {
        return bin2hex(openssl_random_pseudo_bytes($length));
    }
    
    /**
     * 密码哈希
     * @param string $password 密码
     * @return string 哈希后的密码
     */
    public function hashPassword($password) {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 2
        ]);
    }
    
    /**
     * 验证密码
     * @param string $password 原始密码
     * @param string $hash 哈希值
     * @return bool 是否匹配
     */
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * 生成加密日志
     * @param string $action 操作类型
     * @param array $details 详细信息
     */
    public function logEncryptionAction($action, $details) {
        // 脱敏敏感信息
        $maskedDetails = $this->maskData($details, 'array');
        
        // 记录日志
        $this->db->insert('encryption_logs', [
            'action_type' => $action,
            'details' => json_encode($maskedDetails),
            'created_at' => date('Y-m-d H:i:s'),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
    }
    
    /**
     * 密钥轮换
     * @return string 新版本号
     */
    public function rotateKeys() {
        // 生成新密钥
        $this->generateMasterKey();
        
        // 标记旧密钥为非活跃
        $keyVersions = array_keys($this->keys);
        $oldVersions = array_slice($keyVersions, 1); // 保留最新版本
        
        foreach ($oldVersions as $version) {
            $this->db->update('encryption_keys', [
                'active' => 0,
                'deactivated_at' => date('Y-m-d H:i:s')
            ], ['key_version' => $version]);
        }
        
        return end($keyVersions);
    }
    
    /**
     * 获取加密统计信息
     * @return array 统计数据
     */
    public function getEncryptionStats() {
        // 统计加密操作次数
        $stats = [];
        
        // 今日加密操作
        $today = date('Y-m-d');
        $encryptCount = $this->db->queryFirstField(
            "SELECT COUNT(*) FROM encryption_logs WHERE action_type = 'encrypt' AND created_at >= %s",
            $today
        );
        
        $decryptCount = $this->db->queryFirstField(
            "SELECT COUNT(*) FROM encryption_logs WHERE action_type = 'decrypt' AND created_at >= %s",
            $today
        );
        
        $stats = [
            'total_keys' => count($this->keys),
            'active_key_version' => end(array_keys($this->keys)),
            'today_encrypt' => $encryptCount,
            'today_decrypt' => $decryptCount,
            'last_rotation' => $this->db->queryFirstField(
                "SELECT MAX(created_at) FROM encryption_keys"
            )
        ];
        
        return $stats;
    }
    
    /**
     * 批量加密数据
     * @param array $data 数据数组
     * @return array 加密后的数据
     */
    public function batchEncrypt(array $data) {
        $result = [];
        foreach ($data as $key => $value) {
            try {
                $result[$key] = $this->encrypt($value);
            } catch (Exception $e) {
                // 记录错误但继续处理其他数据
                $result[$key] = null;
                $this->logEncryptionAction('encrypt_error', [
                    'key' => $key,
                    'error' => $e->getMessage()
                ]);
            }
        }
        return $result;
    }
    
    /**
     * 批量解密数据
     * @param array $data 加密数据数组
     * @return array 解密后的数据
     */
    public function batchDecrypt(array $data) {
        $result = [];
        foreach ($data as $key => $value) {
            try {
                $result[$key] = $this->decrypt($value);
            } catch (Exception $e) {
                // 记录错误但继续处理其他数据
                $result[$key] = null;
                $this->logEncryptionAction('decrypt_error', [
                    'key' => $key,
                    'error' => $e->getMessage()
                ]);
            }
        }
        return $result;
    }
    
    /**
     * 生成唯一标识符
     * @param int $length 长度
     * @return string 唯一ID
     */
    public function generateUniqueId($length = 32) {
        $bytes = openssl_random_pseudo_bytes($length / 2);
        return bin2hex($bytes);
    }
    
    /**
     * 检查数据是否已加密
     * @param string $data 数据
     * @return bool 是否已加密
     */
    public function isEncrypted($data) {
        // 检查是否符合加密数据格式：版本号:base64数据
        return preg_match('/^[0-9a-f]{16}:[A-Za-z0-9+\/=]+$/', $data) === 1;
    }
}
?>