<?php
/**
 * 操作审计日志系统
 * 提供全面的用户操作记录、审计追踪、合规检查功能
 * 
 * @author System Developer
 * @version 1.0.0
 * @copyright © 2025 发卡系统. All rights reserved.
 */

namespace Security;

use Exception;

class AuditLogSystem {
    /**
     * 操作类型常量
     */
    const ACTION_LOGIN = 'login';
    const ACTION_LOGOUT = 'logout';
    const ACTION_CREATE = 'create';
    const ACTION_UPDATE = 'update';
    const ACTION_DELETE = 'delete';
    const ACTION_VIEW = 'view';
    const ACTION_DOWNLOAD = 'download';
    const ACTION_UPLOAD = 'upload';
    const ACTION_EXPORT = 'export';
    const ACTION_IMPORT = 'import';
    const ACTION_PERMISSION_CHANGE = 'permission_change';
    const ACTION_PASSWORD_CHANGE = 'password_change';
    const ACTION_2FA_CHANGE = '2fa_change';
    const ACTION_BLACKLIST_CHANGE = 'blacklist_change';
    const ACTION_RULE_CHANGE = 'rule_change';
    const ACTION_PAYMENT_PROCESS = 'payment_process';
    const ACTION_CARD_ISSUE = 'card_issue';
    const ACTION_CARD_REDEEM = 'card_redeem';
    const ACTION_REFUND = 'refund';
    const ACTION_DISPUTE = 'dispute';
    
    /**
     * 风险级别
     */
    const RISK_LOW = 'low';
    const RISK_MEDIUM = 'medium';
    const RISK_HIGH = 'high';
    const RISK_CRITICAL = 'critical';
    
    /**
     * 数据库实例
     * @var Database
     */
    private $db;
    
    /**
     * Redis实例
     * @var RedisCache
     */
    private $redis;
    
    /**
     * 数据加密实例
     * @var DataEncryption
     */
    private $encryption;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     * @param RedisCache $redis Redis实例
     * @param DataEncryption $encryption 加密实例
     */
    public function __construct($db, $redis, $encryption) {
        $this->db = $db;
        $this->redis = $redis;
        $this->encryption = $encryption;
    }
    
    /**
     * 记录审计日志
     * @param int $userId 用户ID
     * @param string $action 操作类型
     * @param array $details 详细信息
     * @param string $resourceType 资源类型
     * @param int $resourceId 资源ID
     * @param string $riskLevel 风险级别
     * @return int 日志ID
     */
    public function log($userId, $action, $details, $resourceType = null, $resourceId = null, $riskLevel = self::RISK_LOW) {
        try {
            // 获取请求信息
            $ipAddress = $this->getClientIP();
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            $requestUri = $_SERVER['REQUEST_URI'] ?? '';
            $requestMethod = $_SERVER['REQUEST_METHOD'] ?? '';
            $referrer = $_SERVER['HTTP_REFERER'] ?? '';
            
            // 生成请求ID
            $requestId = $this->generateRequestId();
            
            // 脱敏敏感信息
            $maskedDetails = $this->encryption->maskData($details, 'array');
            
            // 插入日志记录
            $this->db->insert('audit_logs', [
                'user_id' => $userId,
                'action_type' => $action,
                'resource_type' => $resourceType,
                'resource_id' => $resourceId,
                'ip_address' => $ipAddress,
                'user_agent' => $userAgent,
                'request_uri' => $requestUri,
                'request_method' => $requestMethod,
                'referrer' => $referrer,
                'request_id' => $requestId,
                'details' => json_encode($maskedDetails),
                'risk_level' => $riskLevel,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $logId = $this->db->insertId();
            
            // 记录到Redis用于实时监控和分析
            $this->cacheToRedis($logId, $userId, $action, $riskLevel);
            
            // 对于高风险操作，触发实时告警
            if ($riskLevel == self::RISK_HIGH || $riskLevel == self::RISK_CRITICAL) {
                $this->triggerAlert($logId, $userId, $action, $riskLevel);
            }
            
            return $logId;
        } catch (Exception $e) {
            // 即使日志记录失败，也不影响主业务流程
            error_log("审计日志记录失败: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * 获取客户端IP地址
     * @return string IP地址
     */
    private function getClientIP() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        
        // 检查代理IP
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } else if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } else if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
            $ip = $_SERVER['HTTP_X_REAL_IP'];
        }
        
        return $ip;
    }
    
    /**
     * 生成请求ID
     * @return string 请求ID
     */
    private function generateRequestId() {
        // 使用时间戳、随机数和用户ID生成唯一请求ID
        $timestamp = time();
        $random = random_int(100000, 999999);
        $userId = $_SESSION['user_id'] ?? 0;
        return "req_{$timestamp}_{$random}_{$userId}";
    }
    
    /**
     * 缓存到Redis
     */
    private function cacheToRedis($logId, $userId, $action, $riskLevel) {
        try {
            // 按用户缓存最近操作
            $userKey = "audit:user:{$userId}:recent";
            $this->redis->lpush($userKey, json_encode([
                'log_id' => $logId,
                'action' => $action,
                'risk' => $riskLevel,
                'time' => date('Y-m-d H:i:s')
            ]));
            $this->redis->ltrim($userKey, 0, 99); // 保留最近100条
            $this->redis->expire($userKey, 86400); // 24小时
            
            // 按操作类型统计
            $actionKey = "audit:action:{$action}:count:" . date('Ymd');
            $this->redis->incr($actionKey);
            $this->redis->expire($actionKey, 604800); // 7天
            
            // 按风险级别统计
            $riskKey = "audit:risk:{$riskLevel}:count:" . date('Ymd');
            $this->redis->incr($riskKey);
            $this->redis->expire($riskKey, 604800); // 7天
            
            // 实时统计计数器
            $this->redis->incr('audit:total_count');
        } catch (Exception $e) {
            // Redis缓存失败不影响主流程
        }
    }
    
    /**
     * 触发告警
     */
    private function triggerAlert($logId, $userId, $action, $riskLevel) {
        // 创建告警记录
        $this->db->insert('audit_alerts', [
            'log_id' => $logId,
            'user_id' => $userId,
            'action_type' => $action,
            'risk_level' => $riskLevel,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        // 发送告警通知（这里可以集成邮件、短信、企业微信等）
        // $this->sendAlertNotification($alertId, $userId, $action, $riskLevel);
    }
    
    /**
     * 查询审计日志
     * @param array $filters 过滤条件
     * @param array $pagination 分页参数
     * @return array 查询结果
     */
    public function queryLogs($filters = [], $pagination = []) {
        $page = isset($pagination['page']) ? intval($pagination['page']) : 1;
        $pageSize = isset($pagination['page_size']) ? intval($pagination['page_size']) : 20;
        $offset = ($page - 1) * $pageSize;
        
        // 构建查询条件
        $whereClause = '';
        $bindParams = [];
        
        if (isset($filters['user_id'])) {
            $whereClause .= " AND user_id = %d";
            $bindParams[] = $filters['user_id'];
        }
        
        if (isset($filters['action_type'])) {
            if (is_array($filters['action_type'])) {
                $placeholders = implode(',', array_fill(0, count($filters['action_type']), '%s'));
                $whereClause .= " AND action_type IN ({$placeholders})";
                $bindParams = array_merge($bindParams, $filters['action_type']);
            } else {
                $whereClause .= " AND action_type = %s";
                $bindParams[] = $filters['action_type'];
            }
        }
        
        if (isset($filters['risk_level'])) {
            $whereClause .= " AND risk_level = %s";
            $bindParams[] = $filters['risk_level'];
        }
        
        if (isset($filters['resource_type'])) {
            $whereClause .= " AND resource_type = %s";
            $bindParams[] = $filters['resource_type'];
        }
        
        if (isset($filters['resource_id'])) {
            $whereClause .= " AND resource_id = %s";
            $bindParams[] = $filters['resource_id'];
        }
        
        if (isset($filters['ip_address'])) {
            $whereClause .= " AND ip_address = %s";
            $bindParams[] = $filters['ip_address'];
        }
        
        if (isset($filters['keyword'])) {
            $whereClause .= " AND (details LIKE %s OR request_uri LIKE %s OR request_id LIKE %s)";
            $keyword = "%{$filters['keyword']}%";
            $bindParams[] = $keyword;
            $bindParams[] = $keyword;
            $bindParams[] = $keyword;
        }
        
        if (isset($filters['start_time'])) {
            $whereClause .= " AND created_at >= %s";
            $bindParams[] = $filters['start_time'];
        }
        
        if (isset($filters['end_time'])) {
            $whereClause .= " AND created_at <= %s";
            $bindParams[] = $filters['end_time'];
        }
        
        // 查询总数
        $total = $this->db->queryFirstField(
            "SELECT COUNT(*) FROM audit_logs WHERE 1=1 {$whereClause}",
            ...$bindParams
        );
        
        // 查询数据
        $logs = $this->db->query(
            "SELECT * FROM audit_logs WHERE 1=1 {$whereClause}
             ORDER BY created_at DESC
             LIMIT %d, %d",
            ...array_merge($bindParams, [$offset, $pageSize])
        );
        
        // 解析详情
        foreach ($logs as &$log) {
            $log['details'] = json_decode($log['details'], true);
        }
        
        return [
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'data' => $logs
        ];
    }
    
    /**
     * 批量记录日志（事务支持）
     * @param array $logs 日志数组
     * @return bool 是否成功
     */
    public function batchLog(array $logs) {
        try {
            // 开始事务
            $this->db->startTransaction();
            
            foreach ($logs as $logData) {
                $this->log(
                    $logData['user_id'],
                    $logData['action'],
                    $logData['details'],
                    $logData['resource_type'] ?? null,
                    $logData['resource_id'] ?? null,
                    $logData['risk_level'] ?? self::RISK_LOW
                );
            }
            
            // 提交事务
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollback();
            error_log("批量审计日志失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取审计统计信息
     * @param string $dateRange 日期范围
     * @return array 统计数据
     */
    public function getAuditStats($dateRange = 'today') {
        $startTime = '';
        switch ($dateRange) {
            case 'today':
                $startTime = date('Y-m-d 00:00:00');
                break;
            case 'yesterday':
                $startTime = date('Y-m-d 00:00:00', strtotime('-1 day'));
                $endTime = date('Y-m-d 00:00:00');
                break;
            case 'week':
                $startTime = date('Y-m-d 00:00:00', strtotime('-7 days'));
                break;
            case 'month':
                $startTime = date('Y-m-d 00:00:00', strtotime('-30 days'));
                break;
            default:
                $startTime = date('Y-m-d 00:00:00');
        }
        
        $endTime = isset($endTime) ? $endTime : date('Y-m-d H:i:s');
        
        // 查询统计数据
        $stats = [
            'total_logs' => $this->db->queryFirstField(
                "SELECT COUNT(*) FROM audit_logs WHERE created_at BETWEEN %s AND %s",
                $startTime, $endTime
            ),
            'by_risk' => $this->db->query(
                "SELECT risk_level, COUNT(*) as count FROM audit_logs 
                 WHERE created_at BETWEEN %s AND %s 
                 GROUP BY risk_level",
                $startTime, $endTime
            ),
            'by_action' => $this->db->query(
                "SELECT action_type, COUNT(*) as count FROM audit_logs 
                 WHERE created_at BETWEEN %s AND %s 
                 GROUP BY action_type 
                 ORDER BY count DESC LIMIT 10",
                $startTime, $endTime
            ),
            'active_users' => $this->db->queryFirstField(
                "SELECT COUNT(DISTINCT user_id) FROM audit_logs 
                 WHERE created_at BETWEEN %s AND %s",
                $startTime, $endTime
            )
        ];
        
        return $stats;
    }
    
    /**
     * 导出审计日志
     * @param array $filters 过滤条件
     * @param string $format 导出格式
     * @return string 导出文件路径
     */
    public function exportLogs($filters, $format = 'csv') {
        // 这里实现日志导出功能
        // 注意：导出大量数据时需要分批处理
        return "导出功能开发中";
    }
    
    /**
     * 验证审计合规性
     * @param int $userId 用户ID
     * @param string $resourceType 资源类型
     * @return array 合规性报告
     */
    public function validateCompliance($userId, $resourceType) {
        // 这里实现合规性检查逻辑
        return [
            'compliant' => true,
            'missing_actions' => [],
            'unauthorized_actions' => []
        ];
    }
    
    /**
     * 检测异常行为模式
     * @param int $userId 用户ID
     * @return array 异常检测结果
     */
    public function detectAnomalies($userId) {
        // 获取用户最近的操作模式
        $recentLogs = $this->db->query(
            "SELECT * FROM audit_logs WHERE user_id = %d ORDER BY created_at DESC LIMIT 50",
            $userId
        );
        
        $anomalies = [];
        
        // 检测异常登录地点
        $this->detectLocationAnomalies($recentLogs, $anomalies);
        
        // 检测异常操作时间
        $this->detectTimeAnomalies($recentLogs, $anomalies);
        
        // 检测操作频率异常
        $this->detectFrequencyAnomalies($recentLogs, $anomalies);
        
        return $anomalies;
    }
    
    /**
     * 检测地点异常
     */
    private function detectLocationAnomalies($logs, &$anomalies) {
        // 这里可以集成IP地理位置查询服务
        // 检测短时间内从不同地理位置登录的情况
    }
    
    /**
     * 检测时间异常
     */
    private function detectTimeAnomalies($logs, &$anomalies) {
        // 分析用户的操作时间模式，检测非常规时间的操作
    }
    
    /**
     * 检测频率异常
     */
    private function detectFrequencyAnomalies($logs, &$anomalies) {
        // 检测短时间内的高频操作
    }
    
    /**
     * 记录系统级审计日志
     * @param string $component 组件名称
     * @param string $action 操作
     * @param array $details 详情
     */
    public function logSystemAction($component, $action, $details) {
        $this->db->insert('system_audit_logs', [
            'component' => $component,
            'action_type' => $action,
            'details' => json_encode($details),
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
}
?>