<?php
/**
 * Web应用防火墙(WAF)系统
 * 提供请求过滤、攻击检测、异常拦截等安全防护功能
 * 
 * @package Security
 * @author System Admin
 */

namespace Security;

use Database\DBConnection;
use Logger\Logger;
use Cache\CacheFactory;

class WAF {
    /**
     * 配置项
     * @var array
     */
    private $config = [
        'enabled' => true,
        'rules_cache_ttl' => 300, // 规则缓存时间（秒）
        'max_log_size' => 10000, // 最大日志记录数量
        'ip_ban_threshold' => 10, // IP封禁阈值（1小时内的攻击次数）
        'ip_ban_duration' => 3600, // IP封禁时长（秒）
        'log_request_body' => false, // 是否记录请求体
        'whitelist_ips' => ['127.0.0.1', '::1'], // 白名单IP
        'sensitive_paths' => ['/admin/', '/api/', '/payment/'], // 敏感路径
        'rule_groups' => [
            'sql_injection' => true,
            'xss' => true,
            'csrf' => true,
            'path_traversal' => true,
            'rate_limit' => true,
            'malicious_ip' => true,
        ],
    ];
    
    /**
     * 数据库连接
     * @var DBConnection
     */
    private $db;
    
    /**
     * 缓存实例
     * @var Cache\CacheInterface
     */
    private $cache;
    
    /**
     * 日志实例
     * @var Logger
     */
    private $logger;
    
    /**
     * 当前请求信息
     * @var array
     */
    private $requestInfo = [];
    
    /**
     * 匹配到的规则
     * @var array
     */
    private $matchedRules = [];
    
    /**
     * 构造函数
     * 
     * @param array $config 配置项
     * @throws \Exception
     */
    public function __construct(array $config = []) {
        $this->config = array_merge($this->config, $config);
        
        // 初始化数据库连接
        $this->db = DBConnection::getInstance();
        
        // 初始化缓存
        $this->cache = CacheFactory::getInstance('redis');
        
        // 初始化日志
        $this->logger = Logger::getInstance('waf');
        
        // 初始化请求信息
        $this->requestInfo = $this->collectRequestInfo();
        
        // 加载规则缓存
        $this->loadRulesFromCache();
    }
    
    /**
     * 收集请求信息
     * 
     * @return array
     */
    private function collectRequestInfo() {
        $info = [
            'ip_address' => $this->getClientIP(),
            'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'GET',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'referer' => $_SERVER['HTTP_REFERER'] ?? '',
            'request_time' => $_SERVER['REQUEST_TIME'] ?? time(),
            'content_type' => $_SERVER['CONTENT_TYPE'] ?? '',
            'request_headers' => getallheaders(),
            'cookies' => $_COOKIE,
            'query_params' => $_GET,
        ];
        
        // 根据配置决定是否记录请求体
        if ($this->config['log_request_body'] && in_array($info['request_method'], ['POST', 'PUT', 'PATCH'])) {
            $info['request_body'] = file_get_contents('php://input') ?? '';
        }
        
        return $info;
    }
    
    /**
     * 获取客户端真实IP
     * 
     * @return string
     */
    private function getClientIP() {
        $ipHeaders = [
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ];
        
        foreach ($ipHeaders as $header) {
            if (isset($_SERVER[$header])) {
                // 处理X-Forwarded-For多个IP的情况
                if ($header === 'HTTP_X_FORWARDED_FOR') {
                    $ips = explode(',', $_SERVER[$header]);
                    $ip = trim($ips[0]);
                } else {
                    $ip = $_SERVER[$header];
                }
                
                // 验证IP格式
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }
    
    /**
     * 从缓存加载规则
     */
    private function loadRulesFromCache() {
        try {
            $cacheKey = 'waf_rules';
            $rules = $this->cache->get($cacheKey);
            
            if (!$rules) {
                $rules = $this->loadRulesFromDatabase();
                $this->cache->set($cacheKey, $rules, $this->config['rules_cache_ttl']);
            }
            
            $this->rules = $rules;
        } catch (\Exception $e) {
            $this->logger->error('Failed to load WAF rules from cache: ' . $e->getMessage());
            // 缓存失败时从数据库加载
            $this->rules = $this->loadRulesFromDatabase();
        }
    }
    
    /**
     * 从数据库加载规则
     * 
     * @return array
     */
    private function loadRulesFromDatabase() {
        try {
            $query = "SELECT id, rule_name, rule_type, pattern, action, severity, description, enabled, priority 
                     FROM waf_rules WHERE enabled = 1 ORDER BY priority ASC";
            $stmt = $this->db->query($query);
            $rules = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            // 按规则类型分组
            $groupedRules = [];
            foreach ($rules as $rule) {
                $ruleType = $rule['rule_type'];
                if (!isset($groupedRules[$ruleType])) {
                    $groupedRules[$ruleType] = [];
                }
                $groupedRules[$ruleType][] = $rule;
            }
            
            return $groupedRules;
        } catch (\Exception $e) {
            $this->logger->error('Failed to load WAF rules from database: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 刷新规则缓存
     */
    public function refreshRules() {
        $this->cache->delete('waf_rules');
        $this->loadRulesFromCache();
        return true;
    }
    
    /**
     * 启动WAF保护
     * 
     * @return bool 是否通过检查
     */
    public function protect() {
        if (!$this->config['enabled']) {
            return true;
        }
        
        // 检查白名单IP
        if ($this->isWhitelistIP()) {
            return true;
        }
        
        // 检查IP是否已被封禁
        if ($this->isIPBanned()) {
            $this->blockRequest('IP已被封禁');
            return false;
        }
        
        // 执行规则检查
        $checkResults = [];
        
        // SQL注入防护
        if ($this->config['rule_groups']['sql_injection']) {
            $checkResults['sql_injection'] = $this->checkSQLInjection();
        }
        
        // XSS攻击防护
        if ($this->config['rule_groups']['xss']) {
            $checkResults['xss'] = $this->checkXSS();
        }
        
        // CSRF防护
        if ($this->config['rule_groups']['csrf']) {
            $checkResults['csrf'] = $this->checkCSRF();
        }
        
        // 路径遍历防护
        if ($this->config['rule_groups']['path_traversal']) {
            $checkResults['path_traversal'] = $this->checkPathTraversal();
        }
        
        // 恶意IP检查
        if ($this->config['rule_groups']['malicious_ip']) {
            $checkResults['malicious_ip'] = $this->checkMaliciousIP();
        }
        
        // 速率限制检查
        if ($this->config['rule_groups']['rate_limit']) {
            $checkResults['rate_limit'] = $this->checkRateLimit();
        }
        
        // 处理检查结果
        foreach ($checkResults as $ruleType => $result) {
            if (!$result['passed']) {
                $this->matchedRules[] = [
                    'rule_type' => $ruleType,
                    'rule_id' => $result['rule_id'] ?? null,
                    'matched_pattern' => $result['matched_pattern'] ?? null,
                    'severity' => $result['severity'] ?? 'medium',
                    'action' => $result['action'] ?? 'block',
                ];
            }
        }
        
        // 记录匹配规则
        if (!empty($this->matchedRules)) {
            $this->logMatchedRules();
            
            // 检查是否需要执行阻止操作
            foreach ($this->matchedRules as $rule) {
                if ($rule['action'] === 'block') {
                    $this->incrementAttackCounter();
                    $this->blockRequest('检测到安全威胁');
                    return false;
                } elseif ($rule['action'] === 'log') {
                    // 仅记录，不阻止
                }
            }
        }
        
        return true;
    }
    
    /**
     * 检查IP是否在白名单
     * 
     * @return bool
     */
    private function isWhitelistIP() {
        $clientIP = $this->requestInfo['ip_address'];
        return in_array($clientIP, $this->config['whitelist_ips']);
    }
    
    /**
     * 检查IP是否被封禁
     * 
     * @return bool
     */
    private function isIPBanned() {
        try {
            $clientIP = $this->requestInfo['ip_address'];
            
            // 从缓存检查封禁状态
            $cacheKey = 'banned_ip:' . $clientIP;
            if ($this->cache->has($cacheKey)) {
                return true;
            }
            
            // 从数据库检查封禁状态
            $query = "SELECT 1 FROM banned_ips WHERE ip_address = :ip AND active = 1 AND (ban_end IS NULL OR ban_end > NOW())";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':ip', $clientIP);
            $stmt->execute();
            
            if ($stmt->fetchColumn()) {
                // 更新缓存
                $this->cache->set($cacheKey, 1, $this->config['ip_ban_duration']);
                return true;
            }
            
            return false;
        } catch (\Exception $e) {
            $this->logger->error('Failed to check banned IP: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * SQL注入检测
     * 
     * @return array
     */
    private function checkSQLInjection() {
        $result = ['passed' => true];
        $patterns = $this->rules['sql_injection'] ?? [];
        
        foreach ($patterns as $pattern) {
            $regex = '/(' . $pattern['pattern'] . ')/i';
            
            // 检查URL
            if (preg_match($regex, $this->requestInfo['request_uri'])) {
                $result = [
                    'passed' => false,
                    'rule_id' => $pattern['id'],
                    'matched_pattern' => $pattern['pattern'],
                    'severity' => $pattern['severity'],
                    'action' => $pattern['action'],
                ];
                break;
            }
            
            // 检查GET参数
            foreach ($this->requestInfo['query_params'] as $param => $value) {
                if (is_string($value) && preg_match($regex, $value)) {
                    $result = [
                        'passed' => false,
                        'rule_id' => $pattern['id'],
                        'matched_pattern' => $pattern['pattern'],
                        'severity' => $pattern['severity'],
                        'action' => $pattern['action'],
                    ];
                    break 2;
                }
            }
            
            // 检查Cookie
            foreach ($this->requestInfo['cookies'] as $cookie => $value) {
                if (is_string($value) && preg_match($regex, $value)) {
                    $result = [
                        'passed' => false,
                        'rule_id' => $pattern['id'],
                        'matched_pattern' => $pattern['pattern'],
                        'severity' => $pattern['severity'],
                        'action' => $pattern['action'],
                    ];
                    break 2;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * XSS攻击检测
     * 
     * @return array
     */
    private function checkXSS() {
        $result = ['passed' => true];
        $patterns = $this->rules['xss'] ?? [];
        
        // 常见XSS模式
        $commonPatterns = [
            '/<script[^>]*>/i',
            '/javascript:/i',
            '/on\w+\s*=/i',
            '/expression\s*\(/i',
            '/vbscript:/i',
        ];
        
        // 检查配置的规则
        foreach ($patterns as $pattern) {
            $regex = '/(' . $pattern['pattern'] . ')/i';
            
            // 检查URL
            if (preg_match($regex, $this->requestInfo['request_uri'])) {
                $result = [
                    'passed' => false,
                    'rule_id' => $pattern['id'],
                    'matched_pattern' => $pattern['pattern'],
                    'severity' => $pattern['severity'],
                    'action' => $pattern['action'],
                ];
                break;
            }
            
            // 检查GET参数
            foreach ($this->requestInfo['query_params'] as $param => $value) {
                if (is_string($value) && preg_match($regex, $value)) {
                    $result = [
                        'passed' => false,
                        'rule_id' => $pattern['id'],
                        'matched_pattern' => $pattern['pattern'],
                        'severity' => $pattern['severity'],
                        'action' => $pattern['action'],
                    ];
                    break 2;
                }
            }
        }
        
        // 使用通用模式进行二次检查
        if ($result['passed']) {
            foreach ($commonPatterns as $regex) {
                if (preg_match($regex, $this->requestInfo['request_uri'])) {
                    $result['passed'] = false;
                    break;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * CSRF防护检查
     * 
     * @return array
     */
    private function checkCSRF() {
        $result = ['passed' => true];
        
        // 检查敏感路径
        $isSensitivePath = false;
        foreach ($this->config['sensitive_paths'] as $path) {
            if (strpos($this->requestInfo['request_uri'], $path) === 0) {
                $isSensitivePath = true;
                break;
            }
        }
        
        // 非GET请求需要检查CSRF令牌
        if ($isSensitivePath && !in_array($this->requestInfo['request_method'], ['GET', 'HEAD', 'OPTIONS'])) {
            // 检查是否有CSRF令牌
            $csrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['csrf_token'] ?? null;
            
            if (!$csrfToken) {
                $result = [
                    'passed' => false,
                    'rule_id' => null,
                    'matched_pattern' => 'csrf_token_missing',
                    'severity' => 'medium',
                    'action' => 'log', // CSRF通常只记录不阻止
                ];
            }
        }
        
        return $result;
    }
    
    /**
     * 路径遍历检测
     * 
     * @return array
     */
    private function checkPathTraversal() {
        $result = ['passed' => true];
        $patterns = $this->rules['path_traversal'] ?? [];
        
        // 常见路径遍历模式
        $commonPatterns = [
            '/\.\./',
            '/\.\.\\/',
            '/%2e%2e/',
            '/\/\.\./',
        ];
        
        // 检查配置的规则
        foreach ($patterns as $pattern) {
            $regex = '/(' . $pattern['pattern'] . ')/i';
            
            if (preg_match($regex, $this->requestInfo['request_uri'])) {
                $result = [
                    'passed' => false,
                    'rule_id' => $pattern['id'],
                    'matched_pattern' => $pattern['pattern'],
                    'severity' => $pattern['severity'],
                    'action' => $pattern['action'],
                ];
                break;
            }
        }
        
        // 使用通用模式进行二次检查
        if ($result['passed']) {
            foreach ($commonPatterns as $regex) {
                if (preg_match($regex, $this->requestInfo['request_uri'])) {
                    $result['passed'] = false;
                    break;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * 恶意IP检查
     * 
     * @return array
     */
    private function checkMaliciousIP() {
        return ['passed' => true]; // 已在isIPBanned中处理
    }
    
    /**
     * 速率限制检查
     * 
     * @return array
     */
    private function checkRateLimit() {
        try {
            $clientIP = $this->requestInfo['ip_address'];
            $requestURI = $this->requestInfo['request_uri'];
            
            // 针对敏感路径的速率限制
            $isSensitivePath = false;
            foreach ($this->config['sensitive_paths'] as $path) {
                if (strpos($requestURI, $path) === 0) {
                    $isSensitivePath = true;
                    break;
                }
            }
            
            if ($isSensitivePath) {
                $cacheKey = 'rate_limit:' . $clientIP . ':' . substr($requestURI, 0, 100);
                $currentCount = $this->cache->get($cacheKey) ?? 0;
                
                if ($currentCount > 30) { // 每分钟最多30次请求
                    return [
                        'passed' => false,
                        'rule_id' => null,
                        'matched_pattern' => 'rate_limit_exceeded',
                        'severity' => 'medium',
                        'action' => 'block',
                    ];
                }
                
                // 增加计数
                $this->cache->set($cacheKey, $currentCount + 1, 60);
            }
            
            return ['passed' => true];
        } catch (\Exception $e) {
            $this->logger->error('Rate limit check failed: ' . $e->getMessage());
            return ['passed' => true]; // 失败时默认通过
        }
    }
    
    /**
     * 增加攻击计数器
     */
    private function incrementAttackCounter() {
        try {
            $clientIP = $this->requestInfo['ip_address'];
            $cacheKey = 'attack_count:' . $clientIP;
            
            $currentCount = $this->cache->get($cacheKey) ?? 0;
            $currentCount++;
            
            $this->cache->set($cacheKey, $currentCount, 3600); // 1小时内的计数
            
            // 检查是否达到封禁阈值
            if ($currentCount >= $this->config['ip_ban_threshold']) {
                $this->banIP($clientIP);
            }
        } catch (\Exception $e) {
            $this->logger->error('Failed to increment attack counter: ' . $e->getMessage());
        }
    }
    
    /**
     * 封禁IP
     * 
     * @param string $ip IP地址
     */
    private function banIP($ip) {
        try {
            $banReason = '多次触发安全规则';
            $banEnd = date('Y-m-d H:i:s', time() + $this->config['ip_ban_duration']);
            
            // 记录到数据库
            $query = "INSERT INTO banned_ips (ip_address, ban_type, reason, banned_by, ban_start, ban_end, active, created_at) 
                     VALUES (:ip, 'waf_ban', :reason, 0, NOW(), :ban_end, 1, NOW())";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':ip', $ip);
            $stmt->bindParam(':reason', $banReason);
            $stmt->bindParam(':ban_end', $banEnd);
            $stmt->execute();
            
            // 更新缓存
            $cacheKey = 'banned_ip:' . $ip;
            $this->cache->set($cacheKey, 1, $this->config['ip_ban_duration']);
            
            // 记录日志
            $this->logger->warning("IP banned: {$ip}, Reason: {$banReason}, Duration: {$this->config['ip_ban_duration']}s");
        } catch (\Exception $e) {
            $this->logger->error('Failed to ban IP: ' . $e->getMessage());
        }
    }
    
    /**
     * 阻止请求
     * 
     * @param string $message 阻止消息
     */
    private function blockRequest($message) {
        // 记录阻止日志
        $this->logBlockedRequest($message);
        
        // 返回403错误
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: application/json');
        
        $response = [
            'error' => 'Forbidden',
            'message' => $message,
            'request_id' => uniqid('req_'),
            'timestamp' => time(),
        ];
        
        echo json_encode($response);
        exit;
    }
    
    /**
     * 记录被阻止的请求
     * 
     * @param string $message 阻止消息
     */
    private function logBlockedRequest($message) {
        try {
            $logData = [
                'ip_address' => $this->requestInfo['ip_address'],
                'request_uri' => $this->requestInfo['request_uri'],
                'request_method' => $this->requestInfo['request_method'],
                'user_agent' => $this->requestInfo['user_agent'],
                'matched_rules' => json_encode($this->matchedRules),
                'block_message' => $message,
                'created_at' => date('Y-m-d H:i:s'),
            ];
            
            // 记录到数据库
            $query = "INSERT INTO waf_logs (rule_id, ip_address, request_uri, request_method, user_agent, matched_pattern, action_taken, severity, created_at) 
                     VALUES (:rule_id, :ip, :uri, :method, :agent, :pattern, 'block', 'high', NOW())";
            
            foreach ($this->matchedRules as $rule) {
                $stmt = $this->db->prepare($query);
                $stmt->bindParam(':rule_id', $rule['rule_id']);
                $stmt->bindParam(':ip', $logData['ip_address']);
                $stmt->bindParam(':uri', $logData['request_uri']);
                $stmt->bindParam(':method', $logData['request_method']);
                $stmt->bindParam(':agent', $logData['user_agent']);
                $stmt->bindParam(':pattern', $rule['matched_pattern']);
                $stmt->execute();
            }
            
            // 记录到系统日志
            $this->logger->warning('WAF blocked request: ' . json_encode($logData));
        } catch (\Exception $e) {
            $this->logger->error('Failed to log blocked request: ' . $e->getMessage());
        }
    }
    
    /**
     * 记录匹配到的规则
     */
    private function logMatchedRules() {
        try {
            foreach ($this->matchedRules as $rule) {
                $query = "INSERT INTO waf_logs (rule_id, ip_address, request_uri, request_method, user_agent, matched_pattern, action_taken, severity, created_at) 
                         VALUES (:rule_id, :ip, :uri, :method, :agent, :pattern, :action, :severity, NOW())";
                
                $stmt = $this->db->prepare($query);
                $stmt->bindParam(':rule_id', $rule['rule_id']);
                $stmt->bindParam(':ip', $this->requestInfo['ip_address']);
                $stmt->bindParam(':uri', $this->requestInfo['request_uri']);
                $stmt->bindParam(':method', $this->requestInfo['request_method']);
                $stmt->bindParam(':agent', $this->requestInfo['user_agent']);
                $stmt->bindParam(':pattern', $rule['matched_pattern']);
                $stmt->bindParam(':action', $rule['action']);
                $stmt->bindParam(':severity', $rule['severity']);
                $stmt->execute();
            }
        } catch (\Exception $e) {
            $this->logger->error('Failed to log matched rules: ' . $e->getMessage());
        }
    }
    
    /**
     * 添加IP到白名单
     * 
     * @param string $ip IP地址
     */
    public function addWhitelistIP($ip) {
        if (!in_array($ip, $this->config['whitelist_ips'])) {
            $this->config['whitelist_ips'][] = $ip;
        }
    }
    
    /**
     * 从白名单移除IP
     * 
     * @param string $ip IP地址
     */
    public function removeWhitelistIP($ip) {
        $key = array_search($ip, $this->config['whitelist_ips']);
        if ($key !== false) {
            unset($this->config['whitelist_ips'][$key]);
        }
    }
    
    /**
     * 获取WAF状态
     * 
     * @return array
     */
    public function getStatus() {
        return [
            'enabled' => $this->config['enabled'],
            'rule_count' => count($this->matchedRules),
            'cache_ttl' => $this->config['rules_cache_ttl'],
        ];
    }
    
    /**
     * 获取WAF配置
     * 
     * @return array
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 设置WAF配置
     * 
     * @param array $config 配置项
     */
    public function setConfig(array $config) {
        $this->config = array_merge($this->config, $config);
    }
}

// 使用示例
/*
$waf = new WAF([
    'enabled' => true,
    'log_request_body' => true,
]);

if (!$waf->protect()) {
    // 请求已被阻止，无需继续处理
    exit;
}
*/