<?php
/**
 * 安全扫描器核心类
 * 负责执行定期安全扫描和漏洞检测
 */

class SecurityScanner {
    
    /**
     * 安全配置
     * @var array
     */
    private $config;
    
    /**
     * 数据库连接
     * @var PDO
     */
    private $db;
    
    /**
     * 日志记录器
     * @var Logger
     */
    private $logger;
    
    /**
     * 安全管理器
     * @var SecurityManager
     */
    private $securityManager;
    
    /**
     * 扫描结果
     * @var array
     */
    private $scanResults = [];
    
    /**
     * 构造函数
     * @param array $config 扫描配置
     * @param PDO $db 数据库连接
     * @param Logger $logger 日志记录器
     * @param SecurityManager $securityManager 安全管理器
     */
    public function __construct($config = [], $db = null, $logger = null, $securityManager = null) {
        $this->config = array_merge($this->getDefaultConfig(), $config);
        $this->db = $db;
        $this->logger = $logger;
        $this->securityManager = $securityManager;
    }
    
    /**
     * 获取默认配置
     * @return array 默认配置
     */
    private function getDefaultConfig() {
        return [
            // 文件扫描配置
            'file_scan' => [
                'enabled' => true,
                'scan_paths' => [
                    __DIR__ . '/../../api',
                    __DIR__ . '/../../includes',
                    __DIR__ . '/../../admin'
                ],
                'ignored_paths' => [
                    '/node_modules/',
                    '/vendor/',
                    '/cache/',
                    '/uploads/',
                    '/logs/'
                ],
                'file_extensions' => ['php', 'js', 'html', 'htm', 'inc'],
                'suspicious_patterns' => [
                    '/eval\s*\(/i',
                    '/base64_decode\s*\(/i',
                    '/shell_exec\s*\(/i',
                    '/system\s*\(/i',
                    '/passthru\s*\(/i',
                    '/exec\s*\(/i',
                    '/\$\_GET\[\s*["\'](?:cmd|exec|shell|system|passthru)["\']\s*\]/i',
                    '/file_put_contents\s*\(.*\$_POST/i',
                    '/<\s*script[^>]*>/i',
                    '/on\w+\s*=\s*["\'][^"\']*\([^"\']*\)/i'
                ]
            ],
            
            // 权限检查配置
            'permission_check' => [
                'enabled' => true,
                'check_paths' => [
                    __DIR__ . '/../../api',
                    __DIR__ . '/../../includes',
                    __DIR__ . '/../../config',
                    __DIR__ . '/../../admin'
                ],
                'max_file_permissions' => 0644,  // 文件最大权限
                'max_dir_permissions' => 0755    // 目录最大权限
            ],
            
            // 数据库安全检查配置
            'database_check' => [
                'enabled' => true,
                'check_user_permissions' => true,
                'check_weak_passwords' => true,
                'check_sensitive_data' => true,
                'check_schema_integrity' => true
            ],
            
            // 配置文件安全检查
            'config_check' => [
                'enabled' => true,
                'check_duplicate_keys' => true,
                'check_missing_required' => true,
                'check_default_values' => true
            ],
            
            // 依赖检查配置
            'dependency_check' => [
                'enabled' => true,
                'check_vulnerable_packages' => true,
                'check_outdated_packages' => true
            ],
            
            // 漏洞扫描配置
            'vulnerability_scan' => [
                'enabled' => true,
                'check_sql_injection' => true,
                'check_xss' => true,
                'check_csrf' => true,
                'check_file_inclusion' => true,
                'check_command_injection' => true
            ],
            
            // SSL/TLS检查配置
            'ssl_check' => [
                'enabled' => true,
                'check_certificate_expiry' => true,
                'check_protocol_version' => true,
                'check_cipher_strength' => true
            ],
            
            // 报告配置
            'reporting' => [
                'generate_pdf' => false,
                'email_report' => true,
                'email_recipients' => ['admin@example.com'],
                'store_in_database' => true,
                'alert_on_critical' => true
            ],
            
            // 修复配置
            'auto_fix' => [
                'enabled' => false,  // 默认不自动修复
                'fix_permissions' => true,
                'fix_config_issues' => true,
                'fix_known_vulnerabilities' => false
            ]
        ];
    }
    
    /**
     * 执行完整的安全扫描
     * @param string $scanType 扫描类型 (full, quick, file, permission, db, etc.)
     * @return array 扫描结果
     */
    public function runScan($scanType = 'full') {
        $this->scanResults = [
            'timestamp' => time(),
            'scan_type' => $scanType,
            'start_time' => date('Y-m-d H:i:s'),
            'scanner_version' => '1.0.0',
            'critical_issues' => 0,
            'high_issues' => 0,
            'medium_issues' => 0,
            'low_issues' => 0,
            'scan_sections' => [],
            'summary' => []
        ];
        
        try {
            // 根据扫描类型执行不同的扫描项目
            switch ($scanType) {
                case 'quick':
                    // 快速扫描：只执行关键检查
                    if ($this->config['file_scan']['enabled']) {
                        $this->scanSuspiciousFiles();
                    }
                    if ($this->config['permission_check']['enabled']) {
                        $this->checkFilePermissions();
                    }
                    break;
                    
                case 'file':
                    // 仅文件扫描
                    if ($this->config['file_scan']['enabled']) {
                        $this->scanSuspiciousFiles();
                        $this->checkFilePermissions();
                    }
                    break;
                    
                case 'database':
                    // 仅数据库扫描
                    if ($this->config['database_check']['enabled']) {
                        $this->checkDatabaseSecurity();
                    }
                    break;
                    
                case 'vulnerability':
                    // 仅漏洞扫描
                    if ($this->config['vulnerability_scan']['enabled']) {
                        $this->scanForVulnerabilities();
                    }
                    break;
                    
                case 'full':
                default:
                    // 完整扫描：执行所有启用的检查
                    
                    // 1. 文件扫描
                    if ($this->config['file_scan']['enabled']) {
                        $this->scanResults['scan_sections']['file_scan'] = $this->scanSuspiciousFiles();
                    }
                    
                    // 2. 权限检查
                    if ($this->config['permission_check']['enabled']) {
                        $this->scanResults['scan_sections']['permission_check'] = $this->checkFilePermissions();
                    }
                    
                    // 3. 数据库检查
                    if ($this->config['database_check']['enabled'] && $this->db) {
                        $this->scanResults['scan_sections']['database_check'] = $this->checkDatabaseSecurity();
                    }
                    
                    // 4. 配置文件检查
                    if ($this->config['config_check']['enabled']) {
                        $this->scanResults['scan_sections']['config_check'] = $this->checkConfigurationFiles();
                    }
                    
                    // 5. 依赖检查
                    if ($this->config['dependency_check']['enabled']) {
                        $this->scanResults['scan_sections']['dependency_check'] = $this->checkDependencies();
                    }
                    
                    // 6. 漏洞扫描
                    if ($this->config['vulnerability_scan']['enabled']) {
                        $this->scanResults['scan_sections']['vulnerability_scan'] = $this->scanForVulnerabilities();
                    }
                    
                    // 7. SSL检查（如果配置了域名）
                    if ($this->config['ssl_check']['enabled'] && isset($this->config['ssl_check']['domain']) && !empty($this->config['ssl_check']['domain'])) {
                        $this->scanResults['scan_sections']['ssl_check'] = $this->checkSslCertificate();
                    }
                    break;
            }
            
            // 计算问题严重程度统计
            $this->calculateSeverityStats();
            
            // 生成扫描摘要
            $this->generateSummary();
            
            // 保存扫描结果
            $this->saveScanResults();
            
            // 发送报告
            $this->sendReport();
            
            // 如果配置了自动修复且有可修复的问题，尝试修复
            if ($this->config['auto_fix']['enabled']) {
                $this->scanResults['auto_fix_results'] = $this->autoFixIssues();
            }
            
        } catch (Exception $e) {
            $this->logError('安全扫描执行失败: ' . $e->getMessage(), $e);
            $this->scanResults['error'] = $e->getMessage();
            $this->scanResults['error_trace'] = $e->getTraceAsString();
        }
        
        $this->scanResults['end_time'] = date('Y-m-d H:i:s');
        $this->scanResults['duration'] = $this->calculateScanDuration();
        
        return $this->scanResults;
    }
    
    /**
     * 扫描可疑文件
     * @return array 文件扫描结果
     */
    private function scanSuspiciousFiles() {
        $results = [
            'status' => 'completed',
            'scanned_files' => 0,
            'suspicious_files' => [],
            'scan_errors' => []
        ];
        
        try {
            foreach ($this->config['file_scan']['scan_paths'] as $scanPath) {
                if (!is_dir($scanPath)) {
                    $results['scan_errors'][] = "扫描路径不存在: $scanPath";
                    continue;
                }
                
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($scanPath, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );
                
                foreach ($iterator as $file) {
                    if (!$file->isFile()) {
                        continue;
                    }
                    
                    // 检查是否在忽略路径中
                    $filePath = $file->getPathname();
                    $shouldSkip = false;
                    
                    foreach ($this->config['file_scan']['ignored_paths'] as $ignoredPath) {
                        if (strpos($filePath, $ignoredPath) !== false) {
                            $shouldSkip = true;
                            break;
                        }
                    }
                    
                    if ($shouldSkip) {
                        continue;
                    }
                    
                    // 检查文件扩展名
                    $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                    if (!in_array($fileExtension, $this->config['file_scan']['file_extensions'])) {
                        continue;
                    }
                    
                    $results['scanned_files']++;
                    
                    // 扫描文件内容中的可疑模式
                    $fileContent = @file_get_contents($filePath);
                    if ($fileContent !== false) {
                        foreach ($this->config['file_scan']['suspicious_patterns'] as $pattern) {
                            if (preg_match($pattern, $fileContent, $matches)) {
                                // 提取匹配的上下文
                                $context = $this->extractContext($fileContent, $matches[0], 100);
                                
                                $results['suspicious_files'][] = [
                                    'file_path' => $filePath,
                                    'pattern' => $pattern,
                                    'matched_content' => $matches[0],
                                    'context' => $context,
                                    'severity' => $this->determinePatternSeverity($pattern),
                                    'timestamp' => time()
                                ];
                                
                                // 每发现一个可疑模式就记录
                                $this->logSecurityIssue(
                                    $this->determinePatternSeverity($pattern),
                                    "发现可疑代码模式",
                                    "在文件 $filePath 中发现可疑代码模式: {$matches[0]}"
                                );
                            }
                        }
                    } else {
                        $results['scan_errors'][] = "无法读取文件: $filePath";
                    }
                }
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['error'] = $e->getMessage();
            $this->logError('文件扫描失败: ' . $e->getMessage(), $e);
        }
        
        return $results;
    }
    
    /**
     * 检查文件权限
     * @return array 权限检查结果
     */
    private function checkFilePermissions() {
        $results = [
            'status' => 'completed',
            'checked_files' => 0,
            'checked_directories' => 0,
            'permission_issues' => [],
            'scan_errors' => []
        ];
        
        try {
            foreach ($this->config['permission_check']['check_paths'] as $checkPath) {
                if (!is_dir($checkPath)) {
                    $results['scan_errors'][] = "检查路径不存在: $checkPath";
                    continue;
                }
                
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($checkPath, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );
                
                foreach ($iterator as $item) {
                    $itemPath = $item->getPathname();
                    $itemPerms = fileperms($itemPath);
                    
                    if ($item->isDir()) {
                        $results['checked_directories']++;
                        
                        // 检查目录权限
                        if (($itemPerms & 0777) > $this->config['permission_check']['max_dir_permissions']) {
                            $results['permission_issues'][] = [
                                'path' => $itemPath,
                                'type' => 'directory',
                                'current_perms' => $this->formatPermissions($itemPerms),
                                'max_allowed' => $this->formatPermissions($this->config['permission_check']['max_dir_permissions']),
                                'severity' => 'medium',
                                'can_fix' => true
                            ];
                            
                            $this->logSecurityIssue(
                                'medium',
                                "目录权限过高",
                                "目录 $itemPath 权限过高: {$this->formatPermissions($itemPerms)}"
                            );
                        }
                    } else {
                        $results['checked_files']++;
                        
                        // 检查文件权限
                        if (($itemPerms & 0666) > $this->config['permission_check']['max_file_permissions']) {
                            $results['permission_issues'][] = [
                                'path' => $itemPath,
                                'type' => 'file',
                                'current_perms' => $this->formatPermissions($itemPerms),
                                'max_allowed' => $this->formatPermissions($this->config['permission_check']['max_file_permissions']),
                                'severity' => 'high',
                                'can_fix' => true
                            ];
                            
                            $this->logSecurityIssue(
                                'high',
                                "文件权限过高",
                                "文件 $itemPath 权限过高: {$this->formatPermissions($itemPerms)}"
                            );
                        }
                    }
                    
                    // 检查是否有世界可写权限（特别危险）
                    if ($itemPerms & 0002) {
                        $results['permission_issues'][] = [
                            'path' => $itemPath,
                            'type' => $item->isDir() ? 'directory' : 'file',
                            'current_perms' => $this->formatPermissions($itemPerms),
                            'issue' => 'world_writable',
                            'severity' => 'critical',
                            'can_fix' => true
                        ];
                        
                        $this->logSecurityIssue(
                            'critical',
                            "世界可写权限",
                            "{$item->isDir() ? '目录' : '文件'} $itemPath 具有世界可写权限，这是严重安全风险!"
                        );
                    }
                }
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['error'] = $e->getMessage();
            $this->logError('权限检查失败: ' . $e->getMessage(), $e);
        }
        
        return $results;
    }
    
    /**
     * 检查数据库安全
     * @return array 数据库检查结果
     */
    private function checkDatabaseSecurity() {
        $results = [
            'status' => 'completed',
            'user_check' => [],
            'password_check' => [],
            'data_check' => [],
            'schema_check' => [],
            'errors' => []
        ];
        
        try {
            // 1. 检查用户权限
            if ($this->config['database_check']['check_user_permissions']) {
                $results['user_check'] = $this->checkDatabaseUsers();
            }
            
            // 2. 检查弱密码
            if ($this->config['database_check']['check_weak_passwords']) {
                $results['password_check'] = $this->checkWeakPasswords();
            }
            
            // 3. 检查敏感数据
            if ($this->config['database_check']['check_sensitive_data']) {
                $results['data_check'] = $this->checkSensitiveData();
            }
            
            // 4. 检查架构完整性
            if ($this->config['database_check']['check_schema_integrity']) {
                $results['schema_check'] = $this->checkSchemaIntegrity();
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['errors'][] = $e->getMessage();
            $this->logError('数据库安全检查失败: ' . $e->getMessage(), $e);
        }
        
        return $results;
    }
    
    /**
     * 计算问题严重程度统计
     */
    private function calculateSeverityStats() {
        foreach ($this->scanResults['scan_sections'] as $sectionName => $sectionResults) {
            if (isset($sectionResults['suspicious_files'])) {
                foreach ($sectionResults['suspicious_files'] as $suspiciousFile) {
                    $severity = $suspiciousFile['severity'] ?? 'low';
                    $this->scanResults["{$severity}_issues"]++;
                }
            }
            
            if (isset($sectionResults['permission_issues'])) {
                foreach ($sectionResults['permission_issues'] as $permIssue) {
                    $severity = $permIssue['severity'] ?? 'low';
                    $this->scanResults["{$severity}_issues"]++;
                }
            }
            
            if (isset($sectionResults['issues'])) {
                foreach ($sectionResults['issues'] as $issue) {
                    $severity = $issue['severity'] ?? 'low';
                    $this->scanResults["{$severity}_issues"]++;
                }
            }
            
            if (isset($sectionResults['weak_passwords'])) {
                foreach ($sectionResults['weak_passwords'] as $weakPass) {
                    $severity = $weakPass['severity'] ?? 'medium';
                    $this->scanResults["{$severity}_issues"]++;
                }
            }
            
            if (isset($sectionResults['vulnerable_packages'])) {
                foreach ($sectionResults['vulnerable_packages'] as $vulnPackage) {
                    $severity = $vulnPackage['severity'] ?? 'high';
                    $this->scanResults["{$severity}_issues"]++;
                }
            }
        }
    }
    
    /**
     * 生成扫描摘要
     */
    private function generateSummary() {
        $totalIssues = $this->scanResults['critical_issues'] + 
                      $this->scanResults['high_issues'] + 
                      $this->scanResults['medium_issues'] + 
                      $this->scanResults['low_issues'];
        
        $this->scanResults['summary'] = [
            'total_issues' => $totalIssues,
            'overall_status' => $this->determineOverallStatus(),
            'recommendations' => $this->generateRecommendations(),
            'key_findings' => $this->extractKeyFindings()
        ];
    }
    
    /**
     * 确定整体状态
     * @return string 状态字符串
     */
    private function determineOverallStatus() {
        if ($this->scanResults['critical_issues'] > 0) {
            return 'critical';
        } elseif ($this->scanResults['high_issues'] > 0) {
            return 'high_risk';
        } elseif ($this->scanResults['medium_issues'] > 0) {
            return 'needs_attention';
        } else {
            return 'secure';
        }
    }
    
    /**
     * 提取关键发现
     * @return array 关键发现列表
     */
    private function extractKeyFindings() {
        $keyFindings = [];
        
        // 提取关键发现
        foreach ($this->scanResults['scan_sections'] as $sectionName => $sectionResults) {
            // 处理文件扫描结果
            if (isset($sectionResults['suspicious_files'])) {
                foreach ($sectionResults['suspicious_files'] as $suspiciousFile) {
                    if ($suspiciousFile['severity'] === 'critical' || $suspiciousFile['severity'] === 'high') {
                        $keyFindings[] = [
                            'type' => 'suspicious_code',
                            'severity' => $suspiciousFile['severity'],
                            'description' => "在 {$suspiciousFile['file_path']} 发现可疑代码模式",
                            'detail' => $suspiciousFile['matched_content']
                        ];
                    }
                }
            }
            
            // 处理权限问题
            if (isset($sectionResults['permission_issues'])) {
                foreach ($sectionResults['permission_issues'] as $permIssue) {
                    if ($permIssue['severity'] === 'critical' || $permIssue['severity'] === 'high') {
                        $keyFindings[] = [
                            'type' => 'permission_issue',
                            'severity' => $permIssue['severity'],
                            'description' => "{$permIssue['type']} {$permIssue['path']} 权限不安全",
                            'detail' => "当前权限: {$permIssue['current_perms']}"
                        ];
                    }
                }
            }
        }
        
        return $keyFindings;
    }
    
    /**
     * 生成安全建议
     * @return array 安全建议列表
     */
    private function generateRecommendations() {
        $recommendations = [];
        
        if ($this->scanResults['critical_issues'] > 0) {
            $recommendations[] = "立即修复所有关键安全问题，这些可能导致系统被入侵";
        }
        
        if ($this->scanResults['high_issues'] > 0) {
            $recommendations[] = "在下次维护窗口前修复所有高风险问题";
        }
        
        // 基于扫描结果生成具体建议
        foreach ($this->scanResults['scan_sections'] as $sectionName => $sectionResults) {
            switch ($sectionName) {
                case 'file_scan':
                    if (!empty($sectionResults['suspicious_files'])) {
                        $recommendations[] = "审查并清理所有可疑代码，移除潜在的恶意或不安全代码";
                    }
                    break;
                    
                case 'permission_check':
                    if (!empty($sectionResults['permission_issues'])) {
                        $recommendations[] = "修复所有文件和目录权限问题，实施最小权限原则";
                    }
                    break;
                    
                case 'database_check':
                    if (isset($sectionResults['user_check']['issues']) && !empty($sectionResults['user_check']['issues'])) {
                        $recommendations[] = "审查数据库用户权限，移除不必要的管理权限，为所有用户设置强密码";
                    }
                    if (isset($sectionResults['password_check']['weak_passwords']) && !empty($sectionResults['password_check']['weak_passwords'])) {
                        $recommendations[] = "强制用户更新弱密码，实施强密码策略";
                    }
                    break;
                    
                case 'dependency_check':
                    if (!empty($sectionResults['outdated_packages'])) {
                        $recommendations[] = "更新所有过时的依赖包到最新的稳定版本";
                    }
                    if (!empty($sectionResults['vulnerable_packages'])) {
                        $recommendations[] = "立即更新所有存在已知漏洞的依赖包";
                    }
                    break;
            }
        }
        
        // 添加常规安全建议
        $recommendations[] = "定期执行安全扫描，建立安全监控机制";
        $recommendations[] = "确保所有敏感数据都经过适当的加密和保护";
        $recommendations[] = "实施安全的开发实践，包括输入验证、输出转义和参数化查询";
        
        return $recommendations;
    }
    
    /**
     * 保存扫描结果
     */
    private function saveScanResults() {
        if ($this->config['reporting']['store_in_database'] && $this->db) {
            try {
                // 创建表（如果不存在）
                $this->createScanResultsTable();
                
                // 保存扫描结果
                $stmt = $this->db->prepare(
                    "INSERT INTO security_scan_results 
                    (scan_type, scan_time, duration, critical_issues, high_issues, 
                    medium_issues, low_issues, scan_data, security_score) 
                    VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?)"
                );
                
                $scanData = json_encode($this->scanResults, JSON_PRETTY_PRINT);
                
                $stmt->execute([
                    $this->scanResults['scan_type'],
                    $this->scanResults['duration'] ?? 0,
                    $this->scanResults['critical_issues'],
                    $this->scanResults['high_issues'],
                    $this->scanResults['medium_issues'],
                    $this->scanResults['low_issues'],
                    $scanData,
                    $this->scanResults['security_score'] ?? 0
                ]);
                
                $this->scanResults['scan_id'] = $this->db->lastInsertId();
            } catch (Exception $e) {
                $this->logError('保存扫描结果到数据库失败: ' . $e->getMessage(), $e);
            }
        }
        
        // 同时保存到日志文件
        try {
            $logFile = __DIR__ . '/../../logs/security_scans.log';
            $logDir = dirname($logFile);
            
            if (!is_dir($logDir)) {
                mkdir($logDir, 0755, true);
            }
            
            $logEntry = date('Y-m-d H:i:s') . " - 扫描类型: {$this->scanResults['scan_type']}, " .
                       "严重问题: {$this->scanResults['critical_issues']}, " .
                       "高风险问题: {$this->scanResults['high_issues']}, " .
                       "中等风险问题: {$this->scanResults['medium_issues']}, " .
                       "低风险问题: {$this->scanResults['low_issues']}, " .
                       "状态: {$this->scanResults['summary']['overall_status']}\n";
            
            file_put_contents($logFile, $logEntry, FILE_APPEND);
        } catch (Exception $e) {
            $this->logError('保存扫描结果到日志文件失败: ' . $e->getMessage(), $e);
        }
    }
    
    /**
     * 创建扫描结果表
     */
    private function createScanResultsTable() {
        try {
            $sql = "
                CREATE TABLE IF NOT EXISTS security_scan_results (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    scan_type VARCHAR(50) NOT NULL,
                    scan_time DATETIME NOT NULL,
                    duration INT DEFAULT 0,
                    critical_issues INT DEFAULT 0,
                    high_issues INT DEFAULT 0,
                    medium_issues INT DEFAULT 0,
                    low_issues INT DEFAULT 0,
                    security_score INT DEFAULT 100,
                    scan_data LONGTEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ";
            
            $this->db->exec($sql);
        } catch (Exception $e) {
            $this->logError('创建扫描结果表失败: ' . $e->getMessage(), $e);
        }
    }
    
    /**
     * 发送报告
     */
    private function sendReport() {
        if (!$this->config['reporting']['enabled']) {
            return;
        }
        
        try {
            // 检查是否需要发送报告（基于问题严重程度）
            if ($this->config['reporting']['alert_on_critical'] && $this->scanResults['critical_issues'] > 0) {
                $this->sendEmailReport();
            } elseif ($this->config['reporting']['alert_on_high'] && $this->scanResults['high_issues'] > 0) {
                $this->sendEmailReport();
            }
            
            // 无论如何都记录报告
            $this->logReport();
        } catch (Exception $e) {
            $this->logError('发送报告失败: ' . $e->getMessage(), $e);
        }
    }
    
    /**
     * 发送邮件报告
     */
    private function sendEmailReport() {
        // 这里应该实现实际的邮件发送逻辑
        // 为了演示，我们只是记录邮件应该被发送
        
        $this->logInfo(
            '安全扫描报告 - ' . 
            '严重问题: ' . $this->scanResults['critical_issues'] . ', ' .
            '高风险问题: ' . $this->scanResults['high_issues'] . ', ' .
            '中等风险问题: ' . $this->scanResults['medium_issues']
        );
    }
    
    /**
     * 记录报告
     */
    private function logReport() {
        $reportFile = __DIR__ . '/../../logs/security_reports.log';
        $reportDir = dirname($reportFile);
        
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }
        
        $reportContent = "\n========= 安全扫描报告 =========\n" .
                       "扫描时间: {$this->scanResults['start_time']}\n" .
                       "扫描类型: {$this->scanResults['scan_type']}\n" .
                       "扫描持续时间: {$this->scanResults['duration']} 秒\n" .
                       "严重问题: {$this->scanResults['critical_issues']}\n" .
                       "高风险问题: {$this->scanResults['high_issues']}\n" .
                       "中等风险问题: {$this->scanResults['medium_issues']}\n" .
                       "低风险问题: {$this->scanResults['low_issues']}\n" .
                       "整体状态: {$this->scanResults['summary']['overall_status']}\n" .
                       "安全评分: {$this->scanResults['security_score']}分\n" .
                       "\n关键发现:\n";
        
        foreach ($this->scanResults['summary']['key_findings'] as $key => $finding) {
            $reportContent .= "- 严重程度: {$finding['severity']} - {$finding['description']}\n";
        }
        
        $reportContent .= "\n安全建议:\n";
        
        foreach ($this->scanResults['summary']['recommendations'] as $key => $recommendation) {
            $reportContent .= "- {$recommendation}\n";
        }
        
        $reportContent .= "========= 报告结束 =========\n";
        
        file_put_contents($reportFile, $reportContent, FILE_APPEND);
    }
    
    /**
     * 自动修复问题
     * @return array 修复结果
     */
    private function autoFixIssues() {
        $fixResults = [
            'fixed' => 0,
            'failed' => 0,
            'skipped' => 0,
            'details' => []
        ];
        
        try {
            // 1. 修复文件权限问题
            if ($this->config['auto_fix']['fix_permissions'] && 
                isset($this->scanResults['scan_sections']['permission_check'])) {
                
                $permResults = $this->fixPermissionIssues();
                $fixResults['details']['permissions'] = $permResults;
                $fixResults['fixed'] += $permResults['fixed'];
                $fixResults['failed'] += $permResults['failed'];
                $fixResults['skipped'] += $permResults['skipped'];
            }
            
            // 2. 修复配置问题（如果启用）
            if ($this->config['auto_fix']['fix_config_issues'] && 
                isset($this->scanResults['scan_sections']['config_check'])) {
                
                $configResults = $this->fixConfigIssues();
                $fixResults['details']['config'] = $configResults;
                $fixResults['fixed'] += $configResults['fixed'];
                $fixResults['failed'] += $configResults['failed'];
                $fixResults['skipped'] += $configResults['skipped'];
            }
            
        } catch (Exception $e) {
            $fixResults['status'] = 'error';
            $fixResults['error'] = $e->getMessage();
            $this->logError('自动修复过程中出错: ' . $e->getMessage(), $e);
        }
        
        return $fixResults;
    }
    
    /**
     * 修复权限问题
     * @return array 修复结果
     */
    private function fixPermissionIssues() {
        $results = [
            'fixed' => 0,
            'failed' => 0,
            'skipped' => 0,
            'details' => []
        ];
        
        if (!isset($this->scanResults['scan_sections']['permission_check']['permission_issues'])) {
            return $results;
        }
        
        foreach ($this->scanResults['scan_sections']['permission_check']['permission_issues'] as $issue) {
            if (!$issue['can_fix']) {
                $results['skipped']++;
                continue;
            }
            
            try {
                if ($issue['type'] === 'file') {
                    chmod($issue['path'], $this->config['permission_check']['max_file_permissions']);
                } else {
                    chmod($issue['path'], $this->config['permission_check']['max_dir_permissions']);
                }
                
                $results['fixed']++;
                $results['details'][] = [
                    'path' => $issue['path'],
                    'type' => $issue['type'],
                    'old_perms' => $issue['current_perms'],
                    'new_perms' => $issue['type'] === 'file' ? 
                        $this->formatPermissions($this->config['permission_check']['max_file_permissions']) : 
                        $this->formatPermissions($this->config['permission_check']['max_dir_permissions'])
                ];
                
                $this->logInfo("已修复 {$issue['type']} {$issue['path']} 的权限");
            } catch (Exception $e) {
                $results['failed']++;
                $this->logError("修复 {$issue['type']} {$issue['path']} 的权限失败: " . $e->getMessage());
            }
        }
        
        return $results;
    }
    
    /**
     * 修复配置问题
     * @return array 修复结果
     */
    private function fixConfigIssues() {
        $results = [
            'fixed' => 0,
            'failed' => 0,
            'skipped' => 0,
            'details' => []
        ];
        
        // 这里应该实现实际的配置修复逻辑
        // 为了安全起见，配置修复通常应该谨慎进行
        
        return $results;
    }
    
    /**
     * 生成安全评分
     */
    private function generateSecurityScore() {
        // 基础分数为100
        $score = 100;
        
        // 根据发现的问题扣分
        $score -= $this->scanResults['critical_issues'] * 20; // 每个严重问题扣20分
        $score -= $this->scanResults['high_issues'] * 10;      // 每个高风险问题扣10分
        $score -= $this->scanResults['medium_issues'] * 5;     // 每个中等风险问题扣5分
        $score -= $this->scanResults['low_issues'] * 1;        // 每个低风险问题扣1分
        
        // 确保分数不会低于0
        $this->scanResults['security_score'] = max(0, round($score));
    }
    
    /**
     * 记录安全问题
     * @param string $severity 严重程度
     * @param string $title 标题
     * @param string $description 描述
     */
    private function logSecurityIssue($severity, $title, $description) {
        $level = 'INFO';
        
        switch ($severity) {
            case 'critical':
                $level = 'CRITICAL';
                break;
            case 'high':
                $level = 'ERROR';
                break;
            case 'medium':
                $level = 'WARN';
                break;
            case 'low':
                $level = 'INFO';
                break;
        }
        
        $message = "[$level] 安全问题 - $title: $description";
        
        if ($this->logger) {
            $this->logger->log($message, ['level' => $level, 'category' => 'security']);
        } else {
            error_log($message);
        }
    }
    
    /**
     * 记录错误
     * @param string $message 错误信息
     * @param Exception|null $exception 异常对象
     */
    private function logError($message, Exception $exception = null) {
        if ($this->logger) {
            $this->logger->error($message, ['exception' => $exception]);
        } else {
            error_log($message . ($exception ? ' - ' . $exception->getMessage() : ''));
        }
    }
    
    /**
     * 记录信息
     * @param string $message 信息
     */
    private function logInfo($message) {
        if ($this->logger) {
            $this->logger->info($message);
        } else {
            error_log($message);
        }
    }
    
    /**
     * 执行定时扫描任务
     */
    public static function runScheduledScan() {
        // 这里应该被定时任务调用
        // 为了演示，我们提供一个静态方法
        
        try {
            // 创建扫描器实例
            $config = require __DIR__ . '/../config/security.php';
            $db = new PDO(
                "mysql:host={$config['db']['host']};dbname={$config['db']['name']}",
                $config['db']['user'],
                $config['db']['pass']
            );
            
            $scanner = new SecurityScanner(['scan_type' => 'scheduled'], $db);
            return $scanner->runScan('full');
        } catch (Exception $e) {
            error_log('定时安全扫描失败: ' . $e->getMessage());
            return ['status' => 'error', 'error' => $e->getMessage()];
        }
    }
}

/**
 * 安全扫描任务 - 用于定时执行
 */
function scheduleSecurityScan() {
    try {
        // 检查是否应该执行扫描
        $lastScanFile = __DIR__ . '/../../logs/last_security_scan.txt';
        $currentTime = time();
        
        if (file_exists($lastScanFile)) {
            $lastScanTime = file_get_contents($lastScanFile);
            $scanInterval = 24 * 60 * 60; // 24小时
            
            if ($currentTime - $lastScanTime < $scanInterval) {
                return; // 未到执行时间
            }
        }
        
        // 执行扫描
        $results = SecurityScanner::runScheduledScan();
        
        // 记录最后扫描时间
        file_put_contents($lastScanFile, $currentTime);
        
        return $results;
    } catch (Exception $e) {
        error_log('调度安全扫描失败: ' . $e->getMessage());
        return null;
    }
}

// 注册自动加载函数
spl_autoload_register(function($className) {
    $file = __DIR__ . '/../' . str_replace('\', '/', $className) . '.php';
    if (file_exists($file)) {
        require $file;
    }
});

// 当文件直接被执行时运行扫描
if (basename($_SERVER['PHP_SELF']) == 'SecurityScanner.php' && php_sapi_name() == 'cli') {
    echo "开始执行安全扫描...\n";
    $results = scheduleSecurityScan();
    echo "扫描完成。\n";
    echo json_encode($results, JSON_PRETTY_PRINT);
    echo "\n";
}
                // 检查是否存在扫描结果表
                $this->createScanResultsTable();
                
                // 保存扫描结果
                $stmt = $this->db->prepare("INSERT INTO security_scan_results 
                    (timestamp, scan_type, start_time, end_time, duration, critical_issues, 
                     high_issues, medium_issues, low_issues, overall_status, summary, raw_results) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                
                $stmt->execute([
                    $this->scanResults['timestamp'],
                    $this->scanResults['scan_type'],
                    $this->scanResults['start_time'],
                    $this->scanResults['end_time'] ?? null,
                    $this->scanResults['duration'] ?? null,
                    $this->scanResults['critical_issues'],
                    $this->scanResults['high_issues'],
                    $this->scanResults['medium_issues'],
                    $this->scanResults['low_issues'],
                    $this->scanResults['summary']['overall_status'] ?? 'unknown',
                    json_encode($this->scanResults['summary']),
                    json_encode($this->scanResults)
                ]);
                
                $this->scanResults['scan_id'] = $this->db->lastInsertId();
            } catch (Exception $e) {
                $this->logError('保存扫描结果失败: ' . $e->getMessage(), $e);
            }
        }
        
        // 同时保存到日志文件
        try {
            $logDir = __DIR__ . '/../../logs/security_scans/';
            if (!is_dir($logDir)) {
                mkdir($logDir, 0755, true);
            }
            
            $logFile = $logDir . 'scan_' . date('Ymd_His') . '.log';
            file_put_contents($logFile, json_encode($this->scanResults, JSON_PRETTY_PRINT));
            $this->scanResults['log_file'] = $logFile;
        } catch (Exception $e) {
            $this->logError('保存扫描日志文件失败: ' . $e->getMessage(), $e);
        }
    }
    
    /**
     * 创建扫描结果表
     */
    private function createScanResultsTable() {
        try {
            // 检测数据库类型
            $dbType = $this->db->getAttribute(PDO::ATTR_DRIVER_NAME);
            
            if ($dbType === 'mysql') {
                $createTableSql = "
                    CREATE TABLE IF NOT EXISTS security_scan_results (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        timestamp INT NOT NULL,
                        scan_type VARCHAR(50) NOT NULL,
                        start_time DATETIME NOT NULL,
                        end_time DATETIME,
                        duration INT,
                        critical_issues INT DEFAULT 0,
                        high_issues INT DEFAULT 0,
                        medium_issues INT DEFAULT 0,
                        low_issues INT DEFAULT 0,
                        overall_status VARCHAR(50) NOT NULL,
                        summary TEXT,
                        raw_results LONGTEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                ";
            } elseif ($dbType === 'pgsql') {
                $createTableSql = "
                    CREATE TABLE IF NOT EXISTS security_scan_results (
                        id SERIAL PRIMARY KEY,
                        timestamp INTEGER NOT NULL,
                        scan_type VARCHAR(50) NOT NULL,
                        start_time TIMESTAMP NOT NULL,
                        end_time TIMESTAMP,
                        duration INTEGER,
                        critical_issues INTEGER DEFAULT 0,
                        high_issues INTEGER DEFAULT 0,
                        medium_issues INTEGER DEFAULT 0,
                        low_issues INTEGER DEFAULT 0,
                        overall_status VARCHAR(50) NOT NULL,
                        summary TEXT,
                        raw_results TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                ";
            }
            
            if (isset($createTableSql)) {
                $this->db->exec($createTableSql);
            }
        } catch (Exception $e) {
            $this->logError('创建扫描结果表失败: ' . $e->getMessage(), $e);
        }
    }
    
    /**
     * 发送安全报告
     */
    private function sendReport() {
        if ($this->config['reporting']['email_report'] && !empty($this->config['reporting']['email_recipients'])) {
            try {
                $subject = "[安全扫描报告] {$this->scanResults['scan_type']} 扫描完成 - {$this->determineOverallStatus()}";
                $body = $this->generateEmailReport();
                
                // 在实际应用中，这里应该使用系统的邮件发送功能
                // 这里仅作示例
                $this->logInfo("安全报告已准备好发送到 " . implode(', ', $this->config['reporting']['email_recipients']));
                $this->logInfo("报告主题: $subject");
                
                // 如果有严重问题，发送警报
                if ($this->config['reporting']['alert_on_critical'] && $this->scanResults['critical_issues'] > 0) {
                    $alertSubject = "[紧急安全警报] 发现 {$this->scanResults['critical_issues']} 个关键安全问题";
                    $alertBody = $this->generateCriticalAlert();
                    $this->logInfo("紧急安全警报已准备好发送");
                }
            } catch (Exception $e) {
                $this->logError('发送安全报告失败: ' . $e->getMessage(), $e);
            }
        }
    }
    
    /**
     * 生成邮件报告
     * @return string 邮件内容
     */
    private function generateEmailReport() {
        $report = "安全扫描报告\n";
        $report .= "================\n\n";
        $report .= "扫描时间: {$this->scanResults['start_time']}\n";
        $report .= "扫描类型: {$this->scanResults['scan_type']}\n";
        $report .= "扫描状态: {$this->scanResults['summary']['overall_status']}\n\n";
        
        $report .= "问题统计:\n";
        $report .= "- 关键问题: {$this->scanResults['critical_issues']}\n";
        $report .= "- 高风险问题: {$this->scanResults['high_issues']}\n";
        $report .= "- 中等风险问题: {$this->scanResults['medium_issues']}\n";
        $report .= "- 低风险问题: {$this->scanResults['low_issues']}\n";
        $report .= "- 总计: {$this->scanResults['summary']['total_issues']}\n\n";
        
        if (!empty($this->scanResults['summary']['key_findings'])) {
            $report .= "关键发现:\n";
            foreach ($this->scanResults['summary']['key_findings'] as $finding) {
                $report .= "- [{$finding['severity']}] {$finding['description']}\n";
            }
            $report .= "\n";
        }
        
        if (!empty($this->scanResults['summary']['recommendations'])) {
            $report .= "安全建议:\n";
            foreach ($this->scanResults['summary']['recommendations'] as $recommendation) {
                $report .= "- $recommendation\n";
            }
        }
        
        return $report;
    }
    
    /**
     * 生成紧急警报
     * @return string 警报内容
     */
    private function generateCriticalAlert() {
        $alert = "紧急安全警报\n";
        $alert .= "================\n\n";
        $alert .= "在最新的安全扫描中发现了 {$this->scanResults['critical_issues']} 个关键安全问题，需要立即处理!\n\n";
        
        $alert .= "关键问题详情:\n";
        foreach ($this->scanResults['summary']['key_findings'] as $finding) {
            if ($finding['severity'] === 'critical') {
                $alert .= "- {$finding['description']}\n";
                $alert .= "  详情: {$finding['detail']}\n";
            }
        }
        
        $alert .= "\n请立即安排安全团队处理这些问题，并在解决后重新运行安全扫描。";
        
        return $alert;
    }
    
    /**
     * 自动修复问题
     * @return array 修复结果
     */
    private function autoFixIssues() {
        $fixResults = [
            'fixed_issues' => 0,
            'failed_fixes' => 0,
            'fix_details' => []
        ];
        
        try {
            // 修复权限问题
            if ($this->config['auto_fix']['fix_permissions']) {
                foreach ($this->scanResults['scan_sections'] as $sectionName => $sectionResults) {
                    if ($sectionName === 'permission_check' && !empty($sectionResults['permission_issues'])) {
                        foreach ($sectionResults['permission_issues'] as $permIssue) {
                            if ($permIssue['can_fix']) {
                                $targetPerms = $permIssue['type'] === 'directory' 
                                    ? $this->config['permission_check']['max_dir_permissions'] 
                                    : $this->config['permission_check']['max_file_permissions'];
                                
                                if (@chmod($permIssue['path'], $targetPerms)) {
                                    $fixResults['fixed_issues']++;
                                    $fixResults['fix_details'][] = [
                                        'type' => 'permission_fix',
                                        'path' => $permIssue['path'],
                                        'old_perms' => $permIssue['current_perms'],
                                        'new_perms' => $this->formatPermissions($targetPerms),
                                        'status' => 'success'
                                    ];
                                    
                                    $this->logInfo("已修复 {$permIssue['type']} {$permIssue['path']} 的权限，从 {$permIssue['current_perms']} 改为 {$this->formatPermissions($targetPerms)}");
                                } else {
                                    $fixResults['failed_fixes']++;
                                    $fixResults['fix_details'][] = [
                                        'type' => 'permission_fix',
                                        'path' => $permIssue['path'],
                                        'old_perms' => $permIssue['current_perms'],
                                        'status' => 'failed',
                                        'error' => '无法修改文件权限'
                                    ];
                                }
                            }
                        }
                    }
                }
            }
            
            // 修复配置问题
            if ($this->config['auto_fix']['fix_config_issues']) {
                // 配置问题修复逻辑
            }
        } catch (Exception $e) {
            $fixResults['error'] = $e->getMessage();
            $this->logError('自动修复过程中出错: ' . $e->getMessage(), $e);
        }
        
        return $fixResults;
    }
    
    /**
     * 辅助方法：计算扫描持续时间
     * @return int 持续时间（秒）
     */
    private function calculateScanDuration() {
        $start = strtotime($this->scanResults['start_time']);
        $end = strtotime($this->scanResults['end_time'] ?? date('Y-m-d H:i:s'));
        return $end - $start;
    }
    
    /**
     * 辅助方法：格式化权限字符串
     * @param int $perms 文件权限
     * @return string 格式化的权限字符串
     */
    private function formatPermissions($perms) {
        $owner = ($perms & 0400) ? 'r' : '-';
        $owner .= ($perms & 0200) ? 'w' : '-';
        $owner .= ($perms & 0100) ? 'x' : '-';
        
        $group = ($perms & 0040) ? 'r' : '-';
        $group .= ($perms & 0020) ? 'w' : '-';
        $group .= ($perms & 0010) ? 'x' : '-';
        
        $other = ($perms & 0004) ? 'r' : '-';
        $other .= ($perms & 0002) ? 'w' : '-';
        $other .= ($perms & 0001) ? 'x' : '-';
        
        return $owner . $group . $other;
    }
    
    /**
     * 辅助方法：提取匹配上下文
     * @param string $content 文件内容
     * @param string $match 匹配的内容
     * @param int $contextLength 上下文长度
     * @return string 上下文内容
     */
    private function extractContext($content, $match, $contextLength = 50) {
        $pos = strpos($content, $match);
        if ($pos === false) return $match;
        
        $start = max(0, $pos - $contextLength);
        $end = min(strlen($content), $pos + strlen($match) + $contextLength);
        
        $context = substr($content, $start, $end - $start);
        if ($start > 0) $context = '...' . $context;
        if ($end < strlen($content)) $context = $context . '...';
        
        return $context;
    }
    
    /**
     * 辅助方法：确定模式的严重程度
     * @param string $pattern 正则表达式模式
     * @return string 严重程度
     */
    private function determinePatternSeverity($pattern) {
        // 高危模式
        $highRiskPatterns = [
            '/eval\s*\(/i',
            '/shell_exec\s*\(/i',
            '/system\s*\(/i',
            '/passthru\s*\(/i',
            '/exec\s*\(/i',
            '/\$\_GET\[\s*["\'](?:cmd|exec|shell|system|passthru)["\']\s*\]/i'
        ];
        
        // 中等风险模式
        $mediumRiskPatterns = [
            '/base64_decode\s*\(/i',
            '/file_put_contents\s*\(.*\$_POST/i'
        ];
        
        foreach ($highRiskPatterns as $highPattern) {
            if ($pattern === $highPattern) {
                return 'critical';
            }
        }
        
        foreach ($mediumRiskPatterns as $mediumPattern) {
            if ($pattern === $mediumPattern) {
                return 'high';
            }
        }
        
        return 'medium';
    }
    
    /**
     * 辅助方法：检查是否为常见弱密码
     * @param string $password 密码
     * @return bool 是否为弱密码
     */
    private function isCommonWeakPassword($password) {
        $commonWeakPasswords = [
            'password', '123456', 'qwerty', 'admin', 'welcome', '12345678', 
            '123456789', '12345', '1234', '111111', '1234567', 'dragon', 
            '123123', 'baseball', 'abc123', 'football', 'monkey', 'letmein',
            '696969', 'shadow', 'master', '666666', 'qwertyuiop', '123321',
            'mustang', '1234567890', 'michael', '654321', 'superman', '1qaz2wsx',
            'pass', 'password1', 'admin123', 'qwerty123'
        ];
        
        $passwordLower = strtolower($password);
        return in_array($passwordLower, $commonWeakPasswords) || strlen($password) < 6;
    }
    
    /**
     * 辅助方法：检查哈希强度
     * @param string $hash 哈希值
     * @return bool 是否为强哈希
     */
    private function looksLikeStrongHash($hash) {
        // 简单的哈希强度检查
        // 检查长度和格式
        $hashLength = strlen($hash);
        
        // bcrypt hash 通常以 $2a$ 或 $2b$ 开头，长度约为 60
        if (preg_match('/^\$2[ayb]\$.{56}$/', $hash)) {
            return true;
        }
        
        // Argon2 哈希以 $argon2i$ 或 $argon2id$ 开头
        if (preg_match('/^\$argon2[ia]d?\$/', $hash) && $hashLength > 40) {
            return true;
        }
        
        // SHA-256 哈希长度为 64 个十六进制字符
        if ($hashLength === 64 && ctype_xdigit($hash)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 辅助方法：检查版本是否过时（示例实现）
     * @param string $packageName 包名
     * @param string $currentVersion 当前版本
     * @return bool 是否过时
     */
    private function isVersionOutdated($packageName, $currentVersion) {
        // 实际应用中，这里应该查询包管理器或在线服务
        // 这里仅作为示例实现
        return false; // 模拟所有版本都是最新的
    }
    
    /**
     * 辅助方法：获取最新版本（示例实现）
     * @param string $packageName 包名
     * @return string 最新版本
     */
    private function getLatestVersion($packageName) {
        return '1.0.0'; // 示例返回
    }
    
    /**
     * 辅助方法：检查是否有已知漏洞（示例实现）
     * @param string $packageName 包名
     * @param string $version 版本号
     * @return bool 是否有已知漏洞
     */
    private function hasKnownVulnerability($packageName, $version) {
        // 实际应用中，这里应该查询 CVE 数据库或漏洞库
        // 这里仅作为示例实现
        return false; // 模拟没有已知漏洞
    }
    
    /**
     * 辅助方法：掩码敏感值
     * @param string $value 原始值
     * @return string 掩码后的值
     */
    private function maskSensitiveValue($value) {
        // 简单的掩码实现
        // 查找可能的密钥或密码部分
        $masked = preg_replace('/(sk_|pk_|api_|AKIA|secret|password|passwd|pwd)([^"\']{3,})/i', '$1***masked***', $value);
        return $masked;
    }
    
    /**
     * 辅助方法：日志记录
     * @param string $message 日志消息
     */
    private function logInfo($message) {
        if ($this->logger) {
            $this->logger->info($message);
        } else {
            error_log("[INFO] $message");
        }
    }
    
    /**
     * 辅助方法：错误日志记录
     * @param string $message 错误消息
     * @param Exception $exception 异常对象
     */
    private function logError($message, Exception $exception = null) {
        if ($this->logger) {
            $this->logger->error($message, ['exception' => $exception]);
        } else {
            error_log("[ERROR] $message");
            if ($exception) {
                error_log("[ERROR] " . $exception->getMessage() . "\n" . $exception->getTraceAsString());
            }
        }
    }
    
    /**
     * 辅助方法：安全问题日志记录
     * @param string $severity 严重程度
     * @param string $title 问题标题
     * @param string $description 问题描述
     */
    private function logSecurityIssue($severity, $title, $description) {
        if ($this->logger) {
            $this->logger->warning("[SECURITY] [$severity] $title: $description");
        } else {
            error_log("[SECURITY] [$severity] $title: $description");
        }
    }
    
    /**
     * 获取上次扫描结果
     * @return array 上次扫描结果
     */
    public function getLastScanResults() {
        if ($this->db) {
            try {
                $stmt = $this->db->prepare("SELECT * FROM security_scan_results ORDER BY id DESC LIMIT 1");
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($result && isset($result['raw_results'])) {
                    $result['raw_results'] = json_decode($result['raw_results'], true);
                }
                
                return $result;
            } catch (Exception $e) {
                $this->logError('获取上次扫描结果失败: ' . $e->getMessage(), $e);
            }
        }
        
        return null;
    }
    
    /**
     * 获取扫描历史
     * @param int $limit 限制数量
     * @return array 扫描历史
     */
    public function getScanHistory($limit = 10) {
        $history = [];
        
        if ($this->db) {
            try {
                $stmt = $this->db->prepare("SELECT * FROM security_scan_results ORDER BY id DESC LIMIT ?");
                $stmt->execute([$limit]);
                $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
                $this->logError('获取扫描历史失败: ' . $e->getMessage(), $e);
            }
        }
        
        return $history;
    }
    
    /**
     * 生成安全评分
     * @return int 安全评分（0-100）
     */
    public function generateSecurityScore() {
        $baseScore = 100;
        $totalIssues = $this->scanResults['critical_issues'] + 
                      $this->scanResults['high_issues'] + 
                      $this->scanResults['medium_issues'] + 
                      $this->scanResults['low_issues'];
        
        // 根据问题严重程度扣分
        $penalty = ($this->scanResults['critical_issues'] * 20) +
                   ($this->scanResults['high_issues'] * 10) +
                   ($this->scanResults['medium_issues'] * 5) +
                   ($this->scanResults['low_issues'] * 1);
        
        $score = max(0, $baseScore - $penalty);
        $this->scanResults['security_score'] = $score;
        
        return $score;
    }
}
                if (!is_dir($scanPath)) {
                    $results['scan_errors'][] = "扫描路径不存在: $scanPath";
                    continue;
                }
                
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($scanPath, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );
                
                foreach ($iterator as $file) {
                    if (!$file->isFile()) {
                        continue;
                    }
                    
                    // 检查是否在忽略路径中
                    $filePath = $file->getPathname();
                    $shouldSkip = false;
                    
                    foreach ($this->config['file_scan']['ignored_paths'] as $ignoredPath) {
                        if (strpos($filePath, $ignoredPath) !== false) {
                            $shouldSkip = true;
                            break;
                        }
                    }
                    
                    if ($shouldSkip) {
                        continue;
                    }
                    
                    // 检查文件扩展名
                    $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                    if (!in_array($fileExtension, $this->config['file_scan']['file_extensions'])) {
                        continue;
                    }
                    
                    $results['scanned_files']++;
                    
                    // 扫描文件内容中的可疑模式
                    $fileContent = @file_get_contents($filePath);
                    if ($fileContent !== false) {
                        foreach ($this->config['file_scan']['suspicious_patterns'] as $pattern) {
                            if (preg_match($pattern, $fileContent, $matches)) {
                                // 提取匹配的上下文
                                $context = $this->extractContext($fileContent, $matches[0], 100);
                                
                                $results['suspicious_files'][] = [
                                    'file_path' => $filePath,
                                    'pattern' => $pattern,
                                    'matched_content' => $matches[0],
                                    'context' => $context,
                                    'severity' => $this->determinePatternSeverity($pattern),
                                    'timestamp' => time()
                                ];
                                
                                // 每发现一个可疑模式就记录
                                $this->logSecurityIssue(
                                    $this->determinePatternSeverity($pattern),
                                    "发现可疑代码模式",
                                    "在文件 $filePath 中发现可疑代码模式: {$matches[0]}"
                                );
                            }
                        }
                    } else {
                        $results['scan_errors'][] = "无法读取文件: $filePath";
                    }
                }
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['error'] = $e->getMessage();
            $this->logError('文件扫描失败: ' . $e->getMessage(), $e);
        }
        
        return $results;
    }
    
    /**
     * 检查文件权限
     * @return array 权限检查结果
     */
    private function checkFilePermissions() {
        $results = [
            'status' => 'completed',
            'checked_files' => 0,
            'checked_directories' => 0,
            'permission_issues' => [],
            'scan_errors' => []
        ];
        
        try {
            foreach ($this->config['permission_check']['check_paths'] as $checkPath) {
                if (!is_dir($checkPath)) {
                    $results['scan_errors'][] = "检查路径不存在: $checkPath";
                    continue;
                }
                
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($checkPath, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );
                
                foreach ($iterator as $item) {
                    $itemPath = $item->getPathname();
                    $itemPerms = fileperms($itemPath);
                    
                    if ($item->isDir()) {
                        $results['checked_directories']++;
                        
                        // 检查目录权限
                        if ($itemPerms & 0777 > $this->config['permission_check']['max_dir_permissions']) {
                            $results['permission_issues'][] = [
                                'path' => $itemPath,
                                'type' => 'directory',
                                'current_perms' => $this->formatPermissions($itemPerms),
                                'max_allowed' => $this->formatPermissions($this->config['permission_check']['max_dir_permissions']),
                                'severity' => 'medium',
                                'can_fix' => true
                            ];
                            
                            $this->logSecurityIssue(
                                'medium',
                                "目录权限过高",
                                "目录 $itemPath 权限过高: {$this->formatPermissions($itemPerms)}"
                            );
                        }
                    } else {
                        $results['checked_files']++;
                        
                        // 检查文件权限
                        if ($itemPerms & 0666 > $this->config['permission_check']['max_file_permissions']) {
                            $results['permission_issues'][] = [
                                'path' => $itemPath,
                                'type' => 'file',
                                'current_perms' => $this->formatPermissions($itemPerms),
                                'max_allowed' => $this->formatPermissions($this->config['permission_check']['max_file_permissions']),
                                'severity' => 'high',
                                'can_fix' => true
                            ];
                            
                            $this->logSecurityIssue(
                                'high',
                                "文件权限过高",
                                "文件 $itemPath 权限过高: {$this->formatPermissions($itemPerms)}"
                            );
                        }
                    }
                    
                    // 检查是否有世界可写权限（特别危险）
                    if ($itemPerms & 0002) {
                        $results['permission_issues'][] = [
                            'path' => $itemPath,
                            'type' => $item->isDir() ? 'directory' : 'file',
                            'current_perms' => $this->formatPermissions($itemPerms),
                            'issue' => 'world_writable',
                            'severity' => 'critical',
                            'can_fix' => true
                        ];
                        
                        $this->logSecurityIssue(
                            'critical',
                            "世界可写权限",
                            "{$item->isDir() ? '目录' : '文件'} $itemPath 具有世界可写权限，这是严重安全风险!"
                        );
                    }
                }
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['error'] = $e->getMessage();
            $this->logError('权限检查失败: ' . $e->getMessage(), $e);
        }
        
        return $results;
    }
    
    /**
     * 检查数据库安全
     * @return array 数据库检查结果
     */
    private function checkDatabaseSecurity() {
        $results = [
            'status' => 'completed',
            'user_check' => [],
            'password_check' => [],
            'data_check' => [],
            'schema_check' => [],
            'errors' => []
        ];
        
        try {
            // 1. 检查用户权限
            if ($this->config['database_check']['check_user_permissions']) {
                $results['user_check'] = $this->checkDatabaseUsers();
            }
            
            // 2. 检查弱密码
            if ($this->config['database_check']['check_weak_passwords']) {
                $results['password_check'] = $this->checkWeakPasswords();
            }
            
            // 3. 检查敏感数据
            if ($this->config['database_check']['check_sensitive_data']) {
                $results['data_check'] = $this->checkSensitiveData();
            }
            
            // 4. 检查架构完整性
            if ($this->config['database_check']['check_schema_integrity']) {
                $results['schema_check'] = $this->checkSchemaIntegrity();
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['errors'][] = $e->getMessage();
            $this->logError('数据库安全检查失败: ' . $e->getMessage(), $e);
        }
        
        return $results;
    }
    
    /**
     * 检查数据库用户
     * @return array 数据库用户检查结果
     */
    private function checkDatabaseUsers() {
        $users = [];
        $issues = [];
        
        try {
            // 检测数据库类型
            $dbType = $this->db->getAttribute(PDO::ATTR_DRIVER_NAME);
            
            switch ($dbType) {
                case 'mysql':
                    // MySQL用户检查
                    $stmt = $this->db->query("SELECT user, host, authentication_string, plugin FROM mysql.user");
                    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // 检查空密码用户
                    foreach ($users as $user) {
                        if (empty($user['authentication_string']) || $user['authentication_string'] === '*') {
                            $issues[] = [
                                'username' => $user['user'] . '@' . $user['host'],
                                'issue' => 'empty_password',
                                'severity' => 'critical',
                                'recommendation' => '立即为该用户设置密码'
                            ];
                            
                            $this->logSecurityIssue(
                                'critical',
                                "数据库用户空密码",
                                "发现数据库用户 {$user['user']}@{$user['host']} 没有设置密码"
                            );
                        }
                        
                        // 检查root用户远程访问
                        if ($user['user'] === 'root' && $user['host'] !== 'localhost' && $user['host'] !== '127.0.0.1') {
                            $issues[] = [
                                'username' => $user['user'] . '@' . $user['host'],
                                'issue' => 'root_remote_access',
                                'severity' => 'high',
                                'recommendation' => '移除root用户的远程访问权限'
                            ];
                            
                            $this->logSecurityIssue(
                                'high',
                                "Root用户远程访问",
                                "Root用户允许从 {$user['host']} 远程访问"
                            );
                        }
                    }
                    
                    // 检查权限分配
                    $stmt = $this->db->query("SELECT user, host, Select_priv, Insert_priv, Update_priv, Delete_priv, Create_priv, Drop_priv, Reload_priv FROM mysql.user");
                    $privileges = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($privileges as $priv) {
                        // 检查过度授权
                        $adminPrivs = ['Reload_priv', 'Create_priv', 'Drop_priv'];
                        $hasAdminPrivs = false;
                        
                        foreach ($adminPrivs as $adminPriv) {
                            if ($priv[$adminPriv] === 'Y' && $priv['user'] !== 'root') {
                                $hasAdminPrivs = true;
                                break;
                            }
                        }
                        
                        if ($hasAdminPrivs) {
                            $issues[] = [
                                'username' => $priv['user'] . '@' . $priv['host'],
                                'issue' => 'excessive_privileges',
                                'severity' => 'medium',
                                'recommendation' => '遵循最小权限原则，移除不必要的管理权限'
                            ];
                            
                            $this->logSecurityIssue(
                                'medium',
                                "数据库用户过度授权",
                                "用户 {$priv['user']}@{$priv['host']} 拥有可能不必要的管理权限"
                            );
                        }
                    }
                    break;
                    
                case 'pgsql':
                    // PostgreSQL用户检查
                    $stmt = $this->db->query("SELECT usename, usecreatedb, usesuper, userepl, passwd FROM pg_user");
                    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($users as $user) {
                        if (empty($user['passwd'])) {
                            $issues[] = [
                                'username' => $user['usename'],
                                'issue' => 'empty_password',
                                'severity' => 'critical',
                                'recommendation' => '立即为该用户设置密码'
                            ];
                        }
                        
                        if ($user['usesuper'] && $user['usename'] !== 'postgres') {
                            $issues[] = [
                                'username' => $user['usename'],
                                'issue' => 'superuser_privileges',
                                'severity' => 'high',
                                'recommendation' => '移除不必要的超级用户权限'
                            ];
                        }
                    }
                    break;
            }
        } catch (Exception $e) {
            $issues[] = ['error' => $e->getMessage()];
        }
        
        return [
            'total_users' => count($users),
            'issues' => $issues
        ];
    }
    
    /**
     * 检查弱密码
     * @return array 弱密码检查结果
     */
    private function checkWeakPasswords() {
        $results = [
            'checked' => 0,
            'weak_passwords' => []
        ];
        
        try {
            // 检查用户表中的密码强度
            $stmt = $this->db->query("SELECT id, username, email FROM users WHERE password IS NOT NULL");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($users as $user) {
                // 检查用户名是否在常见弱密码列表中
                if ($this->isCommonWeakPassword($user['username'])) {
                    $results['weak_passwords'][] = [
                        'user_id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'reason' => '用户名可能被用作密码',
                        'severity' => 'high'
                    ];
                }
                
                // 检查邮箱前缀是否可能用作密码
                $emailPrefix = explode('@', $user['email'])[0];
                if ($this->isCommonWeakPassword($emailPrefix)) {
                    $results['weak_passwords'][] = [
                        'user_id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'reason' => '邮箱前缀可能被用作密码',
                        'severity' => 'high'
                    ];
                }
                
                $results['checked']++;
            }
        } catch (Exception $e) {
            $results['error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * 检查敏感数据
     * @return array 敏感数据检查结果
     */
    private function checkSensitiveData() {
        $results = [
            'tables_checked' => 0,
            'columns_checked' => 0,
            'issues' => []
        ];
        
        try {
            // 检测数据库类型
            $dbType = $this->db->getAttribute(PDO::ATTR_DRIVER_NAME);
            
            // 获取所有表
            $tables = [];
            if ($dbType === 'mysql') {
                $stmt = $this->db->query("SHOW TABLES");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } elseif ($dbType === 'pgsql') {
                $stmt = $this->db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
            
            $results['tables_checked'] = count($tables);
            
            // 敏感数据类型定义
            $sensitiveDataTypes = [
                'password' => ['password', 'passwd', 'pwd'],
                'credit_card' => ['credit_card', 'cc_number', 'card_number', 'cc'],
                'social_security' => ['ssn', 'social_security', 'id_card', 'identity_card'],
                'personal_info' => ['address', 'phone', 'phone_number', 'mobile', 'dob', 'birth_date'],
                'credentials' => ['api_key', 'secret', 'token', 'auth', 'key']
            ];
            
            foreach ($tables as $table) {
                // 获取表结构
                $columns = [];
                if ($dbType === 'mysql') {
                    $stmt = $this->db->query("DESCRIBE $table");
                    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } elseif ($dbType === 'pgsql') {
                    $stmt = $this->db->query("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = '$table'");
                    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                
                $results['columns_checked'] += count($columns);
                
                foreach ($columns as $column) {
                    $columnName = $dbType === 'mysql' ? $column['Field'] : $column['column_name'];
                    $columnNameLower = strtolower($columnName);
                    
                    // 检查是否存在敏感列
                    foreach ($sensitiveDataTypes as $dataType => $patterns) {
                        foreach ($patterns as $pattern) {
                            if (strpos($columnNameLower, $pattern) !== false) {
                                // 对于密码列，检查是否使用了不安全的存储方式
                                if ($dataType === 'password') {
                                    // 检查示例数据以确定加密方式
                                    $sampleQuery = "SELECT $columnName FROM $table LIMIT 1";
                                    $sampleResult = $this->db->query($sampleQuery)->fetchColumn();
                                    
                                    if ($sampleResult) {
                                        // 简单检查密码加密强度
                                        if (strlen($sampleResult) < 32 || !$this->looksLikeStrongHash($sampleResult)) {
                                            $results['issues'][] = [
                                                'table' => $table,
                                                'column' => $columnName,
                                                'data_type' => $dataType,
                                                'issue' => 'weak_password_hashing',
                                                'severity' => 'high',
                                                'recommendation' => '使用强哈希算法如bcrypt或Argon2存储密码'
                                            ];
                                            
                                            $this->logSecurityIssue(
                                                'high',
                                                "密码存储不安全",
                                                "表 $table 的 $columnName 列可能使用了不安全的密码存储方式"
                                            );
                                        }
                                    }
                                } else {
                                    // 其他敏感数据检查
                                    $results['issues'][] = [
                                        'table' => $table,
                                        'column' => $columnName,
                                        'data_type' => $dataType,
                                        'issue' => 'unencrypted_sensitive_data',
                                        'severity' => 'medium',
                                        'recommendation' => '考虑加密敏感数据或使用掩码处理'
                                    ];
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) {
            $results['error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * 检查架构完整性
     * @return array 架构完整性检查结果
     */
    private function checkSchemaIntegrity() {
        $results = [
            'status' => 'completed',
            'primary_keys' => [],
            'foreign_keys' => [],
            'indexes' => [],
            'issues' => []
        ];
        
        try {
            // 检测数据库类型
            $dbType = $this->db->getAttribute(PDO::ATTR_DRIVER_NAME);
            
            // 获取所有表
            $tables = [];
            if ($dbType === 'mysql') {
                $stmt = $this->db->query("SHOW TABLES");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } elseif ($dbType === 'pgsql') {
                $stmt = $this->db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
            
            foreach ($tables as $table) {
                // 检查主键
                if ($dbType === 'mysql') {
                    $stmt = $this->db->query("SHOW KEYS FROM $table WHERE Key_name = 'PRIMARY'");
                    $primaryKey = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$primaryKey) {
                        $results['issues'][] = [
                            'table' => $table,
                            'issue' => 'missing_primary_key',
                            'severity' => 'medium',
                            'recommendation' => '为表添加主键以确保数据完整性和性能'
                        ];
                    } else {
                        $results['primary_keys'][$table] = $primaryKey['Column_name'];
                    }
                    
                    // 检查索引
                    $stmt = $this->db->query("SHOW INDEX FROM $table");
                    $indexes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $results['indexes'][$table] = array_map(function($idx) {
                        return $idx['Column_name'];
                    }, $indexes);
                    
                    // 检查外键约束
                    $stmt = $this->db->query("SELECT COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = '$table' AND REFERENCED_TABLE_NAME IS NOT NULL");
                    $foreignKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $results['foreign_keys'][$table] = $foreignKeys;
                }
            }
        } catch (Exception $e) {
            $results['error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * 检查配置文件
     * @return array 配置文件检查结果
     */
    private function checkConfigurationFiles() {
        $results = [
            'files_checked' => 0,
            'issues' => []
        ];
        
        try {
            // 配置文件列表
            $configFiles = [
                __DIR__ . '/../../includes/SecurityConfig.php',
                __DIR__ . '/../../config/config.php',
                __DIR__ . '/../../.env',
                __DIR__ . '/../../api/config.php'
            ];
            
            foreach ($configFiles as $configFile) {
                if (!file_exists($configFile)) {
                    continue;
                }
                
                $results['files_checked']++;
                
                // 检查配置文件权限
                $filePerms = fileperms($configFile);
                if ($filePerms & 0007) { // 检查是否允许其他人读取
                    $results['issues'][] = [
                        'file' => $configFile,
                        'issue' => 'insecure_config_permissions',
                        'severity' => 'high',
                        'current_perms' => $this->formatPermissions($filePerms),
                        'recommendation' => '限制配置文件权限为 600 或 640'
                    ];
                    
                    $this->logSecurityIssue(
                        'high',
                        "配置文件权限不安全",
                        "配置文件 $configFile 权限过松，可能被未授权用户读取"
                    );
                }
                
                // 检查配置文件中的敏感信息
                $fileContent = file_get_contents($configFile);
                
                // 检查硬编码的API密钥或密码
                $sensitivePatterns = [
                    '/\$[\w]+\s*=\s*["\'](?:sk_|pk_|api_|AKIA|secret|password|passwd|pwd)[^"\']*["\']/i',
                    '/define\(["\'](?:API_|SECRET_|KEY_|PASSWD_)[^"\']*["\'],\s*["\'][^"\']*["\']\)/i',
                    '/\$[\w]+\s*\[\s*["\'](?:password|secret|key|token)["\']\s*\]\s*=\s*["\'][^"\']*["\']/i'
                ];
                
                foreach ($sensitivePatterns as $pattern) {
                    if (preg_match_all($pattern, $fileContent, $matches)) {
                        foreach ($matches[0] as $match) {
                            $results['issues'][] = [
                                'file' => $configFile,
                                'issue' => 'hardcoded_credentials',
                                'severity' => 'critical',
                                'matched_pattern' => $this->maskSensitiveValue($match),
                                'recommendation' => '将敏感信息移至环境变量或安全的密钥管理系统'
                            ];
                            
                            $this->logSecurityIssue(
                                'critical',
                                "配置文件硬编码敏感信息",
                                "在 $configFile 中发现可能的硬编码密钥或密码"
                            );
                        }
                    }
                }
                
                // 检查开发模式配置
                if (preg_match('/(?:DEBUG|DEV|DEVELOPMENT)_?MODE\s*=\s*(?:true|1|on)/i', $fileContent)) {
                    $results['issues'][] = [
                        'file' => $configFile,
                        'issue' => 'development_mode_enabled',
                        'severity' => 'medium',
                        'recommendation' => '在生产环境中禁用开发模式'
                    ];
                    
                    $this->logSecurityIssue(
                        'medium',
                        "开发模式启用",
                        "在可能的生产配置文件 $configFile 中发现开发模式已启用"
                    );
                }
            }
        } catch (Exception $e) {
            $results['error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * 检查依赖
     * @return array 依赖检查结果
     */
    private function checkDependencies() {
        $results = [
            'package_manager' => 'unknown',
            'packages_checked' => 0,
            'outdated_packages' => [],
            'vulnerable_packages' => [],
            'errors' => []
        ];
        
        try {
            // 检查 composer.json
            $composerJsonPath = __DIR__ . '/../../composer.json';
            if (file_exists($composerJsonPath)) {
                $results['package_manager'] = 'composer';
                $composerJson = json_decode(file_get_contents($composerJsonPath), true);
                
                // 获取已安装的包
                $installedPackages = [];
                $composerLockPath = __DIR__ . '/../../composer.lock';
                if (file_exists($composerLockPath)) {
                    $composerLock = json_decode(file_get_contents($composerLockPath), true);
                    if (isset($composerLock['packages'])) {
                        $installedPackages = $composerLock['packages'];
                        $results['packages_checked'] = count($installedPackages);
                    }
                }
                
                // 这里可以实现对已安装包的版本检查和漏洞检查
                // 在实际环境中，可以查询在线漏洞数据库如Packagist或CVE数据库
                // 这里仅做示例实现
                foreach ($installedPackages as $package) {
                    // 模拟检查过时的包
                    $currentVersion = $package['version'] ?? '';
                    if (!empty($currentVersion) && $this->isVersionOutdated($package['name'], $currentVersion)) {
                        $results['outdated_packages'][] = [
                            'name' => $package['name'],
                            'current_version' => $currentVersion,
                            'recommended_version' => $this->getLatestVersion($package['name']),
                            'severity' => 'low'
                        ];
                    }
                    
                    // 模拟检查已知漏洞
                    if ($this->hasKnownVulnerability($package['name'], $currentVersion)) {
                        $results['vulnerable_packages'][] = [
                            'name' => $package['name'],
                            'current_version' => $currentVersion,
                            'vulnerability' => '示例漏洞ID: CVE-2023-XXXX',
                            'severity' => 'high',
                            'fixed_in' => $this->getLatestVersion($package['name'])
                        ];
                        
                        $this->logSecurityIssue(
                            'high',
                            "依赖包存在漏洞",
                            "包 {$package['name']} v{$currentVersion} 存在已知安全漏洞"
                        );
                    }
                }
            }
            
            // 检查 package.json (Node.js 依赖)
            $packageJsonPath = __DIR__ . '/../../package.json';
            if (file_exists($packageJsonPath)) {
                $results['package_manager'] = 'npm';
                $packageJson = json_decode(file_get_contents($packageJsonPath), true);
                $dependencies = array_merge($packageJson['dependencies'] ?? [], $packageJson['devDependencies'] ?? []);
                $results['packages_checked'] = count($dependencies);
                
                // 模拟检查
                foreach ($dependencies as $name => $version) {
                    // 检查版本号模式
                    if (strpos($version, '*') !== false || strpos($version, '^') !== false || strpos($version, '~') !== false) {
                        $results['outdated_packages'][] = [
                            'name' => $name,
                            'current_version' => $version,
                            'issue' => 'unpinned_version',
                            'severity' => 'medium',
                            'recommendation' => '固定依赖版本以避免意外的破坏性更新'
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            $results['errors'][] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * 扫描漏洞
     * @return array 漏洞扫描结果
     */
    private function scanForVulnerabilities() {
        $results = [
            'status' => 'completed',
            'vulnerabilities' => [],
            'errors' => []
        ];
        
        try {
            // 1. 检查SQL注入漏洞
            if ($this->config['vulnerability_scan']['check_sql_injection']) {
                $results['vulnerabilities'][] = $this->checkSqlInjection();
            }
            
            // 2. 检查XSS漏洞
            if ($this->config['vulnerability_scan']['check_xss']) {
                $results['vulnerabilities'][] = $this->checkXssVulnerabilities();
            }
            
            // 3. 检查CSRF漏洞
            if ($this->config['vulnerability_scan']['check_csrf']) {
                $results['vulnerabilities'][] = $this->checkCsrfVulnerabilities();
            }
            
            // 4. 检查文件包含漏洞
            if ($this->config['vulnerability_scan']['check_file_inclusion']) {
                $results['vulnerabilities'][] = $this->checkFileInclusion();
            }
            
            // 5. 检查命令注入漏洞
            if ($this->config['vulnerability_scan']['check_command_injection']) {
                $results['vulnerabilities'][] = $this->checkCommandInjection();
            }
        } catch (Exception $e) {
            $results['status'] = 'error';
            $results['errors'][] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * 检查SQL注入漏洞
     * @return array SQL注入检查结果
     */
    private function checkSqlInjection() {
        $results = [
            'type' => 'sql_injection',
            'files_checked' => 0,
            'potential_vulnerabilities' => []
        ];
        
        try {
            // 扫描可能存在SQL注入的代码模式
            $vulnerablePatterns = [
                '/\$db->query\([^\)\'\