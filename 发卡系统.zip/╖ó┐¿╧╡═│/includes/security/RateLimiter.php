<?php
/**
 * 智能限流系统
 * 实现分布式限流机制，支持多维度限流策略和风控规则引擎
 */

class RateLimiter {
    // 限流类型常量
    const TYPE_IP = 'ip';
    const TYPE_USER = 'user';
    const TYPE_INTERFACE = 'interface';
    const TYPE_CARD = 'card';
    const TYPE_ORDER = 'order';
    
    // 限流策略常量
    const STRATEGY_FIXED_WINDOW = 'fixed_window';
    const STRATEGY_SLIDING_WINDOW = 'sliding_window';
    const STRATEGY_TOKEN_BUCKET = 'token_bucket';
    const STRATEGY_LEAKY_BUCKET = 'leaky_bucket';
    
    // 限流级别常量
    const LEVEL_INFO = 'info';
    const LEVEL_WARNING = 'warning';
    const LEVEL_BLOCK = 'block';
    
    // 单例实例
    private static $instance = null;
    
    // Redis连接
    private $redis = null;
    
    // 限流配置
    private $config = [];
    
    // 风控规则引擎
    private $ruleEngine = null;
    
    // 限流统计
    private $metrics = [
        'requests_allowed' => 0,
        'requests_blocked' => 0,
        'rate_limit_exceeded' => 0,
        '风控_triggers' => 0
    ];
    
    /**
     * 私有构造函数（单例模式）
     */
    private function __construct() {
        $this->loadConfig();
        $this->initializeRedis();
        $this->initializeRuleEngine();
    }
    
    /**
     * 获取限流实例（单例模式）
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 加载限流配置
     */
    private function loadConfig() {
        // 默认限流配置
        $this->config = [
            // Redis配置
            'redis' => [
                'host' => 'localhost',
                'port' => 6379,
                'password' => '',
                'database' => 1,
                'timeout' => 5
            ],
            
            // 限流规则
            'rules' => [
                // IP限流规则
                'ip' => [
                    'default' => [
                        'limit' => 100, // 每分钟最多100次请求
                        'window' => 60, // 时间窗口（秒）
                        'strategy' => self::STRATEGY_SLIDING_WINDOW
                    ],
                    'login' => [
                        'limit' => 10, // 每分钟最多10次登录尝试
                        'window' => 60,
                        'strategy' => self::STRATEGY_FIXED_WINDOW
                    ],
                    'payment' => [
                        'limit' => 20, // 每分钟最多20次支付请求
                        'window' => 60,
                        'strategy' => self::STRATEGY_SLIDING_WINDOW
                    ]
                ],
                
                // 用户限流规则
                'user' => [
                    'default' => [
                        'limit' => 300, // 每分钟最多300次请求
                        'window' => 60,
                        'strategy' => self::STRATEGY_SLIDING_WINDOW
                    ],
                    'order' => [
                        'limit' => 50, // 每分钟最多50次订单操作
                        'window' => 60,
                        'strategy' => self::STRATEGY_SLIDING_WINDOW
                    ],
                    'card_activation' => [
                        'limit' => 30, // 每分钟最多30次卡密激活
                        'window' => 60,
                        'strategy' => self::STRATEGY_FIXED_WINDOW
                    ]
                ],
                
                // 接口限流规则
                'interface' => [
                    'api/v1/login' => [
                        'limit' => 60, // 每分钟最多60次调用
                        'window' => 60,
                        'strategy' => self::STRATEGY_FIXED_WINDOW
                    ],
                    'api/v1/order/create' => [
                        'limit' => 100, // 每分钟最多100次调用
                        'window' => 60,
                        'strategy' => self::STRATEGY_SLIDING_WINDOW
                    ],
                    'api/v1/card/activate' => [
                        'limit' => 120, // 每分钟最多120次调用
                        'window' => 60,
                        'strategy' => self::STRATEGY_SLIDING_WINDOW
                    ]
                ]
            ],
            
            // 风控规则
            '风控_rules' => [
                // 订单频率检测
                'order_frequency' => [
                    'enabled' => true,
                    'threshold' => 5, // 秒内最多5个订单
                    'window' => 10,
                    'action' => 'block'
                ],
                
                // 重复订单检测
                'duplicate_order' => [
                    'enabled' => true,
                    'timeframe' => 300, // 5分钟内
                    'action' => 'warning'
                ],
                
                // 异常金额检测
                'abnormal_amount' => [
                    'enabled' => true,
                    'threshold_percent' => 300, // 比平均高300%
                    'action' => 'block'
                ],
                
                // 卡密批量操作检测
                'batch_card_operation' => [
                    'enabled' => true,
                    'threshold' => 20, // 每分钟最多20次卡密操作
                    'action' => 'block'
                ]
            ],
            
            // 黑名单配置
            'blacklist' => [
                'ip' => [],
                'user' => [],
                'expire_time' => 86400 // 默认黑名单有效期1天
            ],
            
            // 白名单配置
            'whitelist' => [
                'ip' => ['127.0.0.1'], // 本地开发环境IP
                'user' => [],
                'interface' => ['api/v1/health']
            ],
            
            // 缓存配置
            'cache_ttl' => 3600,
            
            // 监控配置
            'monitoring' => [
                'enabled' => true,
                'log_level' => 'warning',
                'alert_threshold' => 100 // 每分钟触发100次限流时告警
            ]
        ];
        
        // 从配置文件加载自定义配置
        if (file_exists(CONFIG_PATH . '/rate_limiter_config.php')) {
            include CONFIG_PATH . '/rate_limiter_config.php';
            if (isset($rateLimiterConfig) && is_array($rateLimiterConfig)) {
                $this->mergeConfig($this->config, $rateLimiterConfig);
            }
        }
    }
    
    /**
     * 合并配置
     */
    private function mergeConfig(&$default, $custom) {
        foreach ($custom as $key => $value) {
            if (is_array($value) && isset($default[$key]) && is_array($default[$key])) {
                $this->mergeConfig($default[$key], $value);
            } else {
                $default[$key] = $value;
            }
        }
    }
    
    /**
     * 初始化Redis连接
     */
    private function initializeRedis() {
        try {
            $redisConfig = $this->config['redis'];
            $this->redis = new Redis();
            $this->redis->connect(
                $redisConfig['host'],
                $redisConfig['port'],
                $redisConfig['timeout']
            );
            
            if (!empty($redisConfig['password'])) {
                $this->redis->auth($redisConfig['password']);
            }
            
            if (isset($redisConfig['database']) && $redisConfig['database'] >= 0) {
                $this->redis->select($redisConfig['database']);
            }
            
            Logger::info('Redis限流系统连接成功');
        } catch (Exception $e) {
            Logger::error('Redis限流系统连接失败: ' . $e->getMessage());
            throw new Exception('无法连接到限流系统Redis服务');
        }
    }
    
    /**
     * 初始化风控规则引擎
     */
    private function initializeRuleEngine() {
        $this->ruleEngine = new RateLimitRuleEngine($this->config['风控_rules'], $this->redis);
    }
    
    /**
     * 检查是否允许请求
     */
    public function isAllowed($context) {
        // 构建请求上下文
        $requestContext = $this->buildRequestContext($context);
        
        // 检查白名单
        if ($this->isWhitelisted($requestContext)) {
            $this->incrementMetric('requests_allowed');
            return [
                'allowed' => true,
                'reason' => 'whitelisted',
                'level' => self::LEVEL_INFO
            ];
        }
        
        // 检查黑名单
        if ($this->isBlacklisted($requestContext)) {
            $this->incrementMetric('requests_blocked');
            $this->logBlockedRequest($requestContext, 'blacklisted');
            return [
                'allowed' => false,
                'reason' => 'blacklisted',
                'level' => self::LEVEL_BLOCK,
                'message' => '您的IP或账号已被限制访问，请联系客服'
            ];
        }
        
        // 执行多维度限流检查
        $limitChecks = [
            $this->checkIPLimit($requestContext),
            $this->checkUserLimit($requestContext),
            $this->checkInterfaceLimit($requestContext)
        ];
        
        // 检查是否有任一限流触发
        foreach ($limitChecks as $check) {
            if (!$check['allowed']) {
                $this->incrementMetric('requests_blocked');
                $this->incrementMetric('rate_limit_exceeded');
                $this->logBlockedRequest($requestContext, $check['reason']);
                
                // 检查是否需要加入黑名单
                if ($this->shouldBlacklist($requestContext, $check)) {
                    $this->addToBlacklist($requestContext);
                }
                
                return $check;
            }
        }
        
        // 执行风控规则检查
        $风控Result = $this->ruleEngine->checkRules($requestContext);
        if (!$风控Result['allowed']) {
            $this->incrementMetric('requests_blocked');
            $this->incrementMetric('风控_triggers');
            $this->logBlockedRequest($requestContext, '风控_rule_triggered');
            
            // 检查是否需要加入黑名单
            if ($风控Result['level'] === self::LEVEL_BLOCK) {
                $this->addToBlacklist($requestContext);
            }
            
            return $风控Result;
        }
        
        // 请求被允许
        $this->incrementMetric('requests_allowed');
        
        // 记录请求信息用于后续分析
        $this->logAllowedRequest($requestContext);
        
        return [
            'allowed' => true,
            'reason' => 'within_limits',
            'level' => self::LEVEL_INFO
        ];
    }
    
    /**
     * 构建请求上下文
     */
    private function buildRequestContext($context) {
        $defaultContext = [
            'ip' => $this->getClientIP(),
            'user_id' => null,
            'interface' => $this->getCurrentInterface(),
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'GET',
            'timestamp' => time(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'referer' => $_SERVER['HTTP_REFERER'] ?? '',
            'request_id' => uniqid('req_', true)
        ];
        
        return array_merge($defaultContext, $context);
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIP() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        
        // 检查代理IP
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        
        return $ip;
    }
    
    /**
     * 获取当前接口
     */
    private function getCurrentInterface() {
        $path = $_SERVER['REQUEST_URI'] ?? '';
        
        // 移除查询参数
        if (strpos($path, '?') !== false) {
            $path = substr($path, 0, strpos($path, '?'));
        }
        
        return $path;
    }
    
    /**
     * 检查IP限流
     */
    private function checkIPLimit($context) {
        $ip = $context['ip'];
        $interface = $context['interface'];
        
        // 获取限流规则
        $ruleKey = 'default';
        if (strpos($interface, '/login') !== false) {
            $ruleKey = 'login';
        } elseif (strpos($interface, '/payment') !== false || strpos($interface, '/order') !== false) {
            $ruleKey = 'payment';
        }
        
        $rule = $this->config['rules']['ip'][$ruleKey] ?? $this->config['rules']['ip']['default'];
        
        // 执行限流检查
        $result = $this->doRateLimitCheck(self::TYPE_IP, $ip, $rule);
        
        if (!$result['allowed']) {
            return [
                'allowed' => false,
                'reason' => 'ip_rate_limit',
                'level' => self::LEVEL_BLOCK,
                'message' => '请求过于频繁，请稍后再试',
                'limit' => $rule['limit'],
                'window' => $rule['window']
            ];
        }
        
        return $result;
    }
    
    /**
     * 检查用户限流
     */
    private function checkUserLimit($context) {
        $userId = $context['user_id'];
        $interface = $context['interface'];
        
        // 如果没有用户ID，跳过用户限流
        if (empty($userId)) {
            return ['allowed' => true, 'reason' => 'no_user_id', 'level' => self::LEVEL_INFO];
        }
        
        // 获取限流规则
        $ruleKey = 'default';
        if (strpos($interface, '/order') !== false) {
            $ruleKey = 'order';
        } elseif (strpos($interface, '/card/activate') !== false) {
            $ruleKey = 'card_activation';
        }
        
        $rule = $this->config['rules']['user'][$ruleKey] ?? $this->config['rules']['user']['default'];
        
        // 执行限流检查
        $result = $this->doRateLimitCheck(self::TYPE_USER, $userId, $rule);
        
        if (!$result['allowed']) {
            return [
                'allowed' => false,
                'reason' => 'user_rate_limit',
                'level' => self::LEVEL_BLOCK,
                'message' => '您的操作过于频繁，请稍后再试',
                'limit' => $rule['limit'],
                'window' => $rule['window']
            ];
        }
        
        return $result;
    }
    
    /**
     * 检查接口限流
     */
    private function checkInterfaceLimit($context) {
        $interface = $context['interface'];
        
        // 获取限流规则（支持模糊匹配）
        $rule = null;
        foreach ($this->config['rules']['interface'] as $pattern => $interfaceRule) {
            if (strpos($interface, $pattern) !== false) {
                $rule = $interfaceRule;
                break;
            }
        }
        
        // 如果没有找到特定规则，使用默认限制（更宽松）
        if ($rule === null) {
            $rule = [
                'limit' => 600, // 每分钟600次
                'window' => 60,
                'strategy' => self::STRATEGY_SLIDING_WINDOW
            ];
        }
        
        // 执行限流检查
        $result = $this->doRateLimitCheck(self::TYPE_INTERFACE, $interface, $rule);
        
        if (!$result['allowed']) {
            return [
                'allowed' => false,
                'reason' => 'interface_rate_limit',
                'level' => self::LEVEL_BLOCK,
                'message' => '系统繁忙，请稍后再试',
                'limit' => $rule['limit'],
                'window' => $rule['window']
            ];
        }
        
        return $result;
    }
    
    /**
     * 执行具体的限流检查
     */
    private function doRateLimitCheck($type, $key, $rule) {
        $cacheKey = "rate_limit:{$type}:{$key}";
        $strategy = $rule['strategy'] ?? self::STRATEGY_FIXED_WINDOW;
        $limit = $rule['limit'];
        $window = $rule['window'];
        
        switch ($strategy) {
            case self::STRATEGY_FIXED_WINDOW:
                return $this->fixedWindowRateLimit($cacheKey, $limit, $window);
                
            case self::STRATEGY_SLIDING_WINDOW:
                return $this->slidingWindowRateLimit($cacheKey, $limit, $window);
                
            case self::STRATEGY_TOKEN_BUCKET:
                return $this->tokenBucketRateLimit($cacheKey, $limit, $window);
                
            case self::STRATEGY_LEAKY_BUCKET:
                return $this->leakyBucketRateLimit($cacheKey, $limit, $window);
                
            default:
                return $this->fixedWindowRateLimit($cacheKey, $limit, $window);
        }
    }
    
    /**
     * 固定窗口限流
     */
    private function fixedWindowRateLimit($key, $limit, $window) {
        $currentCount = $this->redis->incr($key);
        
        // 设置过期时间
        if ($currentCount === 1) {
            $this->redis->expire($key, $window);
        }
        
        $allowed = $currentCount <= $limit;
        
        return [
            'allowed' => $allowed,
            'count' => $currentCount,
            'limit' => $limit,
            'remaining' => max(0, $limit - $currentCount),
            'level' => $allowed ? self::LEVEL_INFO : self::LEVEL_BLOCK
        ];
    }
    
    /**
     * 滑动窗口限流
     */
    private function slidingWindowRateLimit($key, $limit, $window) {
        $now = time();
        $bucketKey = "{$key}:sliding";
        $expireTime = $window * 2; // 过期时间设为窗口的2倍
        
        // 使用管道操作提高性能
        $this->redis->multi();
        
        // 添加当前时间戳
        $this->redis->zAdd($bucketKey, $now, $now);
        
        // 移除过期的时间戳
        $this->redis->zRemRangeByScore($bucketKey, 0, $now - $window);
        
        // 获取当前窗口内的请求数
        $this->redis->zCard($bucketKey);
        
        // 设置过期时间
        $this->redis->expire($bucketKey, $expireTime);
        
        // 执行管道
        $results = $this->redis->exec();
        
        // 第三个结果是窗口内的请求数
        $currentCount = $results[2] ?? 0;
        $allowed = $currentCount <= $limit;
        
        return [
            'allowed' => $allowed,
            'count' => $currentCount,
            'limit' => $limit,
            'remaining' => max(0, $limit - $currentCount),
            'level' => $allowed ? self::LEVEL_INFO : self::LEVEL_BLOCK
        ];
    }
    
    /**
     * 令牌桶限流
     */
    private function tokenBucketRateLimit($key, $limit, $window) {
        $now = microtime(true);
        $rate = $limit / $window; // 每秒生成的令牌数
        
        $tokensKey = "{$key}:tokens";
        $lastRefillKey = "{$key}:last_refill";
        
        // 获取当前令牌数和最后填充时间
        $this->redis->multi();
        $this->redis->get($tokensKey);
        $this->redis->get($lastRefillKey);
        $results = $this->redis->exec();
        
        $currentTokens = (float)($results[0] ?? $limit);
        $lastRefill = (float)($results[1] ?? $now);
        
        // 计算新生成的令牌数
        $elapsed = $now - $lastRefill;
        $newTokens = $elapsed * $rate;
        
        // 更新令牌数，不超过桶容量
        $currentTokens = min($limit, $currentTokens + $newTokens);
        
        // 尝试消费一个令牌
        $allowed = $currentTokens >= 1;
        
        if ($allowed) {
            $currentTokens--;
        }
        
        // 更新Redis中的值
        $this->redis->multi();
        $this->redis->set($tokensKey, $currentTokens);
        $this->redis->set($lastRefillKey, $now);
        $this->redis->expire($tokensKey, $window * 2);
        $this->redis->expire($lastRefillKey, $window * 2);
        $this->redis->exec();
        
        return [
            'allowed' => $allowed,
            'tokens' => $currentTokens,
            'limit' => $limit,
            'level' => $allowed ? self::LEVEL_INFO : self::LEVEL_BLOCK
        ];
    }
    
    /**
     * 漏桶限流
     */
    private function leakyBucketRateLimit($key, $limit, $window) {
        $now = microtime(true);
        $rate = $window / $limit; // 每个请求之间的最小时间间隔
        
        $lastRequestKey = "{$key}:last_request";
        
        // 获取上一次请求时间
        $lastRequest = (float)($this->redis->get($lastRequestKey) ?? 0);
        
        // 计算是否允许请求
        $diff = $now - $lastRequest;
        $allowed = $diff >= $rate || $lastRequest === 0;
        
        // 如果允许，更新最后请求时间
        if ($allowed) {
            $this->redis->set($lastRequestKey, $now);
            $this->redis->expire($lastRequestKey, $window * 2);
        }
        
        return [
            'allowed' => $allowed,
            'rate' => $rate,
            'diff' => $diff,
            'level' => $allowed ? self::LEVEL_INFO : self::LEVEL_BLOCK
        ];
    }
    
    /**
     * 检查是否在白名单
     */
    private function isWhitelisted($context) {
        $ip = $context['ip'];
        $userId = $context['user_id'];
        $interface = $context['interface'];
        
        // 检查IP白名单
        if (in_array($ip, $this->config['whitelist']['ip'])) {
            return true;
        }
        
        // 检查用户白名单
        if (!empty($userId) && in_array($userId, $this->config['whitelist']['user'])) {
            return true;
        }
        
        // 检查接口白名单
        foreach ($this->config['whitelist']['interface'] as $pattern) {
            if (strpos($interface, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 检查是否在黑名单
     */
    private function isBlacklisted($context) {
        $ip = $context['ip'];
        $userId = $context['user_id'];
        
        // 检查Redis黑名单
        $blacklisted = false;
        
        if ($ip) {
            $blacklisted = $blacklisted || $this->redis->sismember('rate_limiter:blacklist:ip', $ip);
        }
        
        if ($userId) {
            $blacklisted = $blacklisted || $this->redis->sismember('rate_limiter:blacklist:user', $userId);
        }
        
        // 检查配置文件中的黑名单
        if (!$blacklisted) {
            if (in_array($ip, $this->config['blacklist']['ip'])) {
                // 将配置文件中的黑名单也加入Redis
                $this->redis->sadd('rate_limiter:blacklist:ip', $ip);
                $blacklisted = true;
            }
            
            if (!empty($userId) && in_array($userId, $this->config['blacklist']['user'])) {
                $this->redis->sadd('rate_limiter:blacklist:user', $userId);
                $blacklisted = true;
            }
        }
        
        return $blacklisted;
    }
    
    /**
     * 添加到黑名单
     */
    private function addToBlacklist($context) {
        $ip = $context['ip'];
        $userId = $context['user_id'];
        $reason = $context['reason'] ?? 'multiple_rate_limit_violations';
        $expireTime = $this->config['blacklist']['expire_time'];
        
        // 记录黑名单信息
        $blacklistInfo = [
            'type' => 'auto_blacklist',
            'reason' => $reason,
            'timestamp' => time(),
            'context' => $context
        ];
        
        // 添加IP到黑名单
        if ($ip) {
            $key = "rate_limiter:blacklist:ip";
            $this->redis->sadd($key, $ip);
            
            // 记录黑名单详情
            $this->redis->hSet("rate_limiter:blacklist:details:{$ip}", 'info', json_encode($blacklistInfo));
            $this->redis->expire("rate_limiter:blacklist:details:{$ip}", $expireTime);
            
            Logger::warning("IP已自动加入黑名单: {$ip}", ['reason' => $reason]);
        }
        
        // 添加用户到黑名单
        if ($userId) {
            $key = "rate_limiter:blacklist:user";
            $this->redis->sadd($key, $userId);
            
            // 记录黑名单详情
            $this->redis->hSet("rate_limiter:blacklist:details:user:{$userId}", 'info', json_encode($blacklistInfo));
            $this->redis->expire("rate_limiter:blacklist:details:user:{$userId}", $expireTime);
            
            Logger::warning("用户已自动加入黑名单: {$userId}", ['reason' => $reason]);
        }
    }
    
    /**
     * 检查是否应该加入黑名单
     */
    private function shouldBlacklist($context, $check) {
        // 检查失败级别
        if ($check['level'] !== self::LEVEL_BLOCK) {
            return false;
        }
        
        // 统计最近的违规次数
        $ip = $context['ip'];
        $violationKey = "rate_limiter:violations:{$ip}";
        $violationCount = $this->redis->incr($violationKey);
        
        // 设置过期时间
        if ($violationCount === 1) {
            $this->redis->expire($violationKey, 3600); // 1小时内的违规次数
        }
        
        // 如果1小时内违规超过10次，加入黑名单
        return $violationCount >= 10;
    }
    
    /**
     * 记录被阻止的请求
     */
    private function logBlockedRequest($context, $reason) {
        if ($this->config['monitoring']['enabled']) {
            $logData = [
                'timestamp' => time(),
                'reason' => $reason,
                'ip' => $context['ip'],
                'user_id' => $context['user_id'],
                'interface' => $context['interface'],
                'method' => $context['method'],
                'user_agent' => $context['user_agent'],
                'request_id' => $context['request_id']
            ];
            
            Logger::warning('请求被限流系统阻止', $logData);
            
            // 记录到Redis用于统计分析
            $this->redis->lPush('rate_limiter:blocked_requests', json_encode($logData));
            $this->redis->lTrim('rate_limiter:blocked_requests', -1000, -1); // 只保留最近1000条
        }
    }
    
    /**
     * 记录允许的请求
     */
    private function logAllowedRequest($context) {
        if ($this->config['monitoring']['enabled'] && $this->config['monitoring']['log_level'] === 'info') {
            $logData = [
                'timestamp' => time(),
                'ip' => $context['ip'],
                'user_id' => $context['user_id'],
                'interface' => $context['interface'],
                'request_id' => $context['request_id']
            ];
            
            // 只记录关键信息，避免日志过大
            Logger::info('请求通过限流检查', ['interface' => $context['interface'], 'ip' => $context['ip']]);
        }
    }
    
    /**
     * 增加指标计数
     */
    private function incrementMetric($name) {
        $this->metrics[$name]++;
        
        // 同步到Redis用于监控
        $this->redis->incr("rate_limiter:metrics:{$name}");
    }
    
    /**
     * 获取限流统计信息
     */
    public function getMetrics() {
        return $this->metrics;
    }
    
    /**
     * 清除限流记录
     */
    public function clearLimits($type, $key) {
        $cacheKey = "rate_limit:{$type}:{$key}";
        $this->redis->del($cacheKey);
        $this->redis->del("{$cacheKey}:sliding");
        $this->redis->del("{$cacheKey}:tokens");
        $this->redis->del("{$cacheKey}:last_refill");
        $this->redis->del("{$cacheKey}:last_request");
    }
    
    /**
     * 从黑名单移除
     */
    public function removeFromBlacklist($type, $key) {
        if ($type === self::TYPE_IP) {
            $this->redis->srem('rate_limiter:blacklist:ip', $key);
            $this->redis->del("rate_limiter:blacklist:details:{$key}");
        } elseif ($type === self::TYPE_USER) {
            $this->redis->srem('rate_limiter:blacklist:user', $key);
            $this->redis->del("rate_limiter:blacklist:details:user:{$key}");
        }
    }
    
    /**
     * 获取黑名单信息
     */
    public function getBlacklist($type = null) {
        $blacklist = [];
        
        if ($type === self::TYPE_IP || $type === null) {
            $ipBlacklist = $this->redis->smembers('rate_limiter:blacklist:ip') ?: [];
            $blacklist['ip'] = array_merge($ipBlacklist, $this->config['blacklist']['ip']);
        }
        
        if ($type === self::TYPE_USER || $type === null) {
            $userBlacklist = $this->redis->smembers('rate_limiter:blacklist:user') ?: [];
            $blacklist['user'] = array_merge($userBlacklist, $this->config['blacklist']['user']);
        }
        
        return $blacklist;
    }
    
    /**
     * 获取限流状态
     */
    public function getStatus() {
        return [
            'version' => '1.0.0',
            'redis_connected' => $this->redis->ping() === '+PONG',
            'active_rules' => count($this->config['rules']),
            '风控_rules' => count(array_filter($this->config['风控_rules'], function($rule) {
                return $rule['enabled'] ?? false;
            })),
            'metrics' => $this->getMetrics(),
            'blacklist_size' => [
                'ip' => count($this->redis->smembers('rate_limiter:blacklist:ip')),
                'user' => count($this->redis->smembers('rate_limiter:blacklist:user'))
            ]
        ];
    }
    
    /**
     * 获取Redis连接
     */
    public function getRedis() {
        return $this->redis;
    }
    
    /**
     * 工厂方法
     */
    public static function getSystem() {
        return self::getInstance();
    }
}

/**
 * 限流规则引擎
 */
class RateLimitRuleEngine {
    private $rules = [];
    private $redis = null;
    
    public function __construct($rules, $redis) {
        $this->rules = $rules;
        $this->redis = $redis;
    }
    
    /**
     * 检查风控规则
     */
    public function checkRules($context) {
        // 遍历所有启用的规则
        foreach ($this->rules as $ruleName => $rule) {
            if (!$rule['enabled']) {
                continue;
            }
            
            // 执行规则检查
            $result = $this->executeRule($ruleName, $rule, $context);
            
            // 如果规则触发，返回相应结果
            if (!$result['allowed']) {
                return $result;
            }
        }
        
        // 所有规则都通过
        return [
            'allowed' => true,
            'reason' => 'all_rules_passed',
            'level' => RateLimiter::LEVEL_INFO
        ];
    }
    
    /**
     * 执行具体规则
     */
    private function executeRule($ruleName, $rule, $context) {
        switch ($ruleName) {
            case 'order_frequency':
                return $this->checkOrderFrequency($rule, $context);
                
            case 'duplicate_order':
                return $this->checkDuplicateOrder($rule, $context);
                
            case 'abnormal_amount':
                return $this->checkAbnormalAmount($rule, $context);
                
            case 'batch_card_operation':
                return $this->checkBatchCardOperation($rule, $context);
                
            default:
                return ['allowed' => true, 'reason' => 'unknown_rule', 'level' => RateLimiter::LEVEL_INFO];
        }
    }
    
    /**
     * 检查订单频率
     */
    private function checkOrderFrequency($rule, $context) {
        // 如果不是订单接口，直接通过
        if (strpos($context['interface'], '/order') === false) {
            return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
        }
        
        $ip = $context['ip'];
        $userId = $context['user_id'];
        $key = $userId ?: $ip;
        $cacheKey = "风控:order_frequency:{$key}";
        $window = $rule['window'];
        $threshold = $rule['threshold'];
        
        // 记录订单请求时间
        $now = time();
        $this->redis->multi();
        $this->redis->zAdd($cacheKey, $now, $now);
        $this->redis->zRemRangeByScore($cacheKey, 0, $now - $window);
        $this->redis->zCard($cacheKey);
        $this->redis->expire($cacheKey, $window * 2);
        $results = $this->redis->exec();
        
        $orderCount = $results[2] ?? 0;
        $allowed = $orderCount <= $threshold;
        
        if (!$allowed) {
            return [
                'allowed' => false,
                'reason' => 'order_frequency_too_high',
                'level' => $rule['action'] === 'block' ? RateLimiter::LEVEL_BLOCK : RateLimiter::LEVEL_WARNING,
                'message' => '订单频率异常，请稍后再试',
                'count' => $orderCount,
                'threshold' => $threshold
            ];
        }
        
        return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
    }
    
    /**
     * 检查重复订单
     */
    private function checkDuplicateOrder($rule, $context) {
        // 如果没有订单数据，直接通过
        if (!isset($context['order_data'])) {
            return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
        }
        
        $orderData = $context['order_data'];
        $userId = $context['user_id'];
        $ip = $context['ip'];
        
        // 生成订单指纹（基于金额、商品、时间等）
        $orderFingerprint = $this->generateOrderFingerprint($orderData);
        $cacheKey = "风控:duplicate_order:{$userId}:{$orderFingerprint}";
        
        // 检查是否存在重复订单
        $exists = $this->redis->exists($cacheKey);
        
        if ($exists) {
            return [
                'allowed' => $rule['action'] !== 'block', // 如果action是block则拒绝
                'reason' => 'possible_duplicate_order',
                'level' => $rule['action'] === 'block' ? RateLimiter::LEVEL_BLOCK : RateLimiter::LEVEL_WARNING,
                'message' => '请勿重复提交相同订单'
            ];
        }
        
        // 记录订单指纹
        $this->redis->setex($cacheKey, $rule['timeframe'], 1);
        
        return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
    }
    
    /**
     * 生成订单指纹
     */
    private function generateOrderFingerprint($orderData) {
        $fingerprintData = [
            $orderData['amount'] ?? 0,
            $orderData['product_id'] ?? '',
            $orderData['card_type'] ?? '',
            date('i', time()) // 精确到分钟
        ];
        
        return md5(implode(':', $fingerprintData));
    }
    
    /**
     * 检查异常金额
     */
    private function checkAbnormalAmount($rule, $context) {
        if (!isset($context['order_data']) || !isset($context['order_data']['amount'])) {
            return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
        }
        
        $amount = $context['order_data']['amount'];
        $userId = $context['user_id'];
        
        // 如果是新用户，无法判断异常
        if (empty($userId)) {
            return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
        }
        
        // 获取用户平均订单金额
        $avgAmount = $this->getUserAverageOrderAmount($userId);
        
        // 如果没有历史数据，记录当前金额
        if ($avgAmount === 0) {
            $this->updateUserAverageOrderAmount($userId, $amount);
            return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
        }
        
        // 检查是否异常（超过平均值的N倍）
        $thresholdMultiplier = $rule['threshold_percent'] / 100;
        $isAbnormal = $amount > $avgAmount * (1 + $thresholdMultiplier);
        
        if ($isAbnormal) {
            return [
                'allowed' => false,
                'reason' => 'abnormal_order_amount',
                'level' => $rule['action'] === 'block' ? RateLimiter::LEVEL_BLOCK : RateLimiter::LEVEL_WARNING,
                'message' => '订单金额异常，请联系客服核实',
                'amount' => $amount,
                'avg_amount' => $avgAmount
            ];
        }
        
        // 更新平均金额
        $this->updateUserAverageOrderAmount($userId, $amount);
        
        return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
    }
    
    /**
     * 获取用户平均订单金额
     */
    private function getUserAverageOrderAmount($userId) {
        $cacheKey = "风控:user_avg_amount:{$userId}";
        $data = $this->redis->hGetAll($cacheKey);
        
        if (empty($data)) {
            return 0;
        }
        
        $totalAmount = (float)($data['total_amount'] ?? 0);
        $orderCount = (int)($data['order_count'] ?? 0);
        
        return $orderCount > 0 ? $totalAmount / $orderCount : 0;
    }
    
    /**
     * 更新用户平均订单金额
     */
    private function updateUserAverageOrderAmount($userId, $amount) {
        $cacheKey = "风控:user_avg_amount:{$userId}";
        
        $this->redis->multi();
        $this->redis->hIncrByFloat($cacheKey, 'total_amount', $amount);
        $this->redis->hIncrBy($cacheKey, 'order_count', 1);
        $this->redis->expire($cacheKey, 2592000); // 30天
        $this->redis->exec();
    }
    
    /**
     * 检查卡密批量操作
     */
    private function checkBatchCardOperation($rule, $context) {
        // 如果不是卡密相关接口，直接通过
        if (strpos($context['interface'], '/card') === false) {
            return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
        }
        
        $ip = $context['ip'];
        $userId = $context['user_id'];
        $key = $userId ?: $ip;
        $cacheKey = "风控:card_operations:{$key}";
        $threshold = $rule['threshold'];
        
        // 统计操作次数
        $operationCount = $this->redis->incr($cacheKey);
        
        // 设置过期时间
        if ($operationCount === 1) {
            $this->redis->expire($cacheKey, 60); // 1分钟
        }
        
        $allowed = $operationCount <= $threshold;
        
        if (!$allowed) {
            return [
                'allowed' => false,
                'reason' => 'batch_card_operation_detected',
                'level' => $rule['action'] === 'block' ? RateLimiter::LEVEL_BLOCK : RateLimiter::LEVEL_WARNING,
                'message' => '检测到批量操作行为，为保护您的账户安全，请稍后再试',
                'count' => $operationCount,
                'threshold' => $threshold
            ];
        }
        
        return ['allowed' => true, 'level' => RateLimiter::LEVEL_INFO];
    }
}