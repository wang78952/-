<?php
/**
 * 安全配置管理类
 * 集中管理系统所有安全相关配置
 * 
 * @package includes/security
 */

class SecurityConfig {
    /**
     * 单例实例
     * @var SecurityConfig
     */
    private static $instance = null;
    
    /**
     * 配置数组
     * @var array
     */
    private $config = [];
    
    /**
     * 默认配置
     * @var array
     */
    private $defaultConfig = [
        // XSS 防护配置
        'xss_protection' => [
            'enabled' => true,
            'strip_tags' => true,
            'htmlspecialchars_flags' => ENT_QUOTES | ENT_SUBSTITUTE,
            'htmlspecialchars_encoding' => 'UTF-8',
            'allowed_html_tags' => [
                'b', 'i', 'u', 'strong', 'em', 'br', 'p', 'a', 'ul', 'ol', 'li',
                'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'code'
            ],
            'allowed_html_attributes' => [
                'href', 'title', 'alt', 'src', 'class', 'id'
            ],
            'allowed_protocols' => ['http', 'https', 'mailto', 'tel']
        ],
        
        // CSRF 防护配置
        'csrf_protection' => [
            'enabled' => true,
            'token_name' => '_csrf_token',
            'token_secret' => null, // 实际使用时必须设置
            'token_expiry' => 3600, // 1小时
            'regenerate_on_login' => true,
            'validate_ajax' => true,
            'ignore_methods' => ['GET', 'HEAD', 'OPTIONS'],
            'cookie_secure' => true,
            'cookie_http_only' => true,
            'cookie_same_site' => 'Strict'
        ],
        
        // 输入验证配置
        'input_validation' => [
            'enabled' => true,
            'trim_input' => true,
            'sanitize_input' => true,
            'strict_types' => true,
            'max_post_size' => 10485760, // 10MB
            'max_upload_size' => 20971520, // 20MB
            'allowed_file_types' => [
                'images' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'],
                'documents' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'],
                'archives' => ['zip', 'rar', '7z', 'tar', 'gz']
            ],
            'allowed_mime_types' => [
                'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
                'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                'text/plain', 'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed',
                'application/x-tar', 'application/gzip'
            ]
        ],
        
        // SQL 注入防护配置
        'sql_injection_protection' => [
            'enabled' => true,
            'use_prepared_statements' => true,
            'enable_query_logging' => true,
            'log_suspicious_queries' => true,
            'block_dangerous_functions' => true,
            'allowed_functions' => [
                'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'WHERE', 'ORDER BY', 'LIMIT',
                'JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN', 'GROUP BY', 'HAVING'
            ],
            'disallowed_patterns' => [
                '/DROP\s+(TABLE|DATABASE|INDEX|VIEW|TRIGGER)/i',
                '/ALTER\s+(TABLE|DATABASE)/i',
                '/CREATE\s+(TABLE|DATABASE|INDEX|VIEW|TRIGGER|FUNCTION|PROCEDURE)/i',
                '/INSERT\s+INTO\s+[^\(]+\s+VALUES\s+\(/i',
                '/UNION\s+ALL?\s+SELECT/i',
                '/EXEC\s+\(/i',
                '/sp_executesql/i',
                '/xp_cmdshell/i',
                '/;--/',
                '/\bsys\.\b/i',
                '/\binformation_schema\b/i'
            ]
        ],
        
        // 密码策略配置
        'password_policy' => [
            'min_length' => 8,
            'max_length' => 128,
            'require_uppercase' => true,
            'require_lowercase' => true,
            'require_number' => true,
            'require_special_char' => true,
            'special_chars' => '!@#$%^&*()-_=+[]{}|;:,.<>?',
            'prevent_common_passwords' => true,
            'max_login_attempts' => 5,
            'lockout_duration' => 300, // 5分钟
            'password_history_limit' => 5,
            'password_expiry_days' => 90
        ],
        
        // 速率限制配置
        'rate_limiting' => [
            'enabled' => true,
            'storage' => 'redis', // redis, memcached, file
            'default_limit' => 100,
            'default_period' => 60, // 1分钟
            'limits' => [
                'login' => ['limit' => 5, 'period' => 60],
                'register' => ['limit' => 3, 'period' => 3600],
                'forgot_password' => ['limit' => 3, 'period' => 3600],
                'api' => ['limit' => 1000, 'period' => 3600],
                'search' => ['limit' => 50, 'period' => 60]
            ],
            'ip_based_limiting' => true,
            'user_based_limiting' => true,
            'exempt_ips' => []
        ],
        
        // IP过滤配置
        'ip_filtering' => [
            'enabled' => false,
            'block_mode' => true, // true为黑名单模式，false为白名单模式
            'blocked_ips' => [],
            'allowed_ips' => [],
            'blocked_countries' => [],
            'allowed_countries' => [],
            'use_ipv6' => true,
            'trust_proxy' => true,
            'proxy_headers' => [
                'HTTP_X_FORWARDED_FOR',
                'HTTP_CLIENT_IP',
                'HTTP_X_REAL_IP',
                'HTTP_X_FORWARDED',
                'HTTP_FORWARDED_FOR',
                'HTTP_FORWARDED'
            ]
        ],
        
        // 文件上传安全配置
        'file_upload' => [
            'enabled' => true,
            'allowed_extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'],
            'max_file_size' => 5 * 1024 * 1024, // 5MB
            'upload_directory' => '/uploads/',
            'randomize_filename' => true,
            'strip_metadata' => true,
            'validate_image_dimensions' => true,
            'max_image_width' => 2000,
            'max_image_height' => 2000,
            'min_image_width' => 10,
            'min_image_height' => 10,
            'scan_for_viruses' => false, // 需要安装ClamAV
            'clamd_socket' => '/var/run/clamav/clamd.sock',
            'chmod_files' => 0644,
            'chmod_directories' => 0755
        ],
        
        // 会话安全配置
        'session_security' => [
            'use_secure_cookies' => true,
            'use_http_only_cookies' => true,
            'use_same_site_cookies' => 'Strict',
            'regenerate_id' => true,
            'regenerate_id_interval' => 300, // 5分钟
            'timeout' => 1800, // 30分钟
            'remember_me_lifetime' => 2592000, // 30天
            'check_user_agent' => true,
            'check_ip_address' => false, // 可能导致动态IP用户问题
            'cookie_path' => '/',
            'cookie_domain' => null,
            'destroy_on_logout' => true
        ],
        
        // 日志配置
        'logging' => [
            'enabled' => true,
            'level' => 'warning', // debug, info, notice, warning, error, critical, alert, emergency
            'path' => '/logs/security.log',
            'max_file_size' => 10 * 1024 * 1024, // 10MB
            'backup_count' => 5,
            'log_invalid_requests' => true,
            'log_blocked_ips' => true,
            'log_failed_logins' => true,
            'log_password_changes' => true,
            'log_permission_changes' => true,
            'log_admin_actions' => true,
            'log_database_errors' => true,
            'log_api_access' => true
        ],
        
        // 错误处理配置
        'error_handling' => [
            'display_errors' => false, // 生产环境应为false
            'log_errors' => true,
            'error_reporting' => E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED,
            'custom_error_page' => '/errors/error.php',
            'not_found_page' => '/errors/404.php',
            'forbidden_page' => '/errors/403.php',
            'internal_error_page' => '/errors/500.php',
            'show_detailed_info' => false, // 生产环境应为false
            'notify_admin' => true,
            'admin_email' => null, // 实际使用时必须设置
            'notify_min_level' => 'error'
        ],
        
        // 数据加密配置
        'encryption' => [
            'enabled' => true,
            'algorithm' => 'AES-256-CBC',
            'hash_algorithm' => 'sha256',
            'key_length' => 32,
            'iv_length' => 16,
            'secret_key' => null, // 实际使用时必须设置
            'pepper' => null, // 额外的加密密钥
            'pbkdf2_iterations' => 100000,
            'data_to_encrypt' => ['email', 'phone', 'address', 'credit_card', 'social_security_number']
        ],
        
        // 权限控制配置
        'access_control' => [
            'enabled' => true,
            'default_role' => 'guest',
            'roles' => [
                'guest', 'user', 'editor', 'admin', 'superadmin'
            ],
            'permissions' => [],
            'role_hierarchy' => [
                'user' => ['guest'],
                'editor' => ['user', 'guest'],
                'admin' => ['editor', 'user', 'guest'],
                'superadmin' => ['admin', 'editor', 'user', 'guest']
            ],
            'use_route_permissions' => true,
            'login_url' => '/login.php',
            'unauthorized_redirect' => '/unauthorized.php'
        ],
        
        // 内容安全策略配置
        'content_security_policy' => [
            'enabled' => false, // 默认关闭，需要根据实际网站调整
            'report_only' => true,
            'default_src' => "'self'",
            'script_src' => "'self'",
            'style_src' => "'self' 'unsafe-inline'",
            'img_src' => "'self' data:",
            'connect_src' => "'self'",
            'font_src' => "'self'",
            'object_src' => "'none'",
            'media_src' => "'self'",
            'frame_src' => "'none'",
            'form_action' => "'self'",
            'frame_ancestors' => "'none'",
            'report_uri' => '/csp-report.php'
        ],
        
        // HTTP安全头配置
        'http_headers' => [
            'enabled' => true,
            'x_content_type_options' => 'nosniff',
            'x_frame_options' => 'DENY',
            'x_xss_protection' => '1; mode=block',
            'strict_transport_security' => 'max-age=31536000; includeSubDomains',
            'referrer_policy' => 'strict-origin-when-cross-origin',
            'x_permitted_cross_domain_policies' => 'none',
            'feature_policy' => 'camera \'none\'; microphone \'none\'; geolocation \'none\';',
            'permissions_policy' => 'camera=(), microphone=(), geolocation=()'
        ],
        
        // 防爬虫配置
        'anti_crawler' => [
            'enabled' => true,
            'block_bots' => true,
            'allowed_user_agents' => [],
            'disallowed_user_agents' => [
                '/bot/i', '/crawler/i', '/spider/i', '/scraper/i', '/harvest/i',
                '/fetch/i', '/downloader/i', '/suckerfish/i', '/slurp/i',
                '/bingbot/i', '/googlebot/i', '/yahoobot/i', '/msnbot/i'
            ],
            'throttle_api_calls' => true,
            'throttle_limit' => 60, // 每分钟请求数
            'challenge_difficult_requests' => true
        ],
        
        // 蜜罐配置
        'honeypot' => [
            'enabled' => true,
            'field_name' => 'email_subscribe', // 看似正常的字段名
            'log_honeypot_triggers' => true,
            'block_ip_on_trigger' => true,
            'block_duration' => 86400 // 24小时
        ],
        
        // API安全配置
        'api_security' => [
            'enabled' => true,
            'require_https' => true,
            'rate_limit' => 1000, // 每小时请求数
            'rate_limit_period' => 3600,
            'require_authentication' => true,
            'token_lifetime' => 86400, // 24小时
            'refresh_token_lifetime' => 604800, // 7天
            'allow_multiple_sessions' => true,
            'validate_content_type' => true,
            'allowed_content_types' => [
                'application/json',
                'application/x-www-form-urlencoded',
                'multipart/form-data'
            ],
            'log_api_usage' => true,
            'log_sensitive_operations' => true
        ],
        
        // 数据库安全配置
        'database_security' => [
            'prevent_sql_injection' => true,
            'use_prepared_statements' => true,
            'validate_input_parameters' => true,
            'minimize_permissions' => true,
            'encrypt_sensitive_data' => true,
            'sanitize_output' => true,
            'log_suspicious_queries' => true,
            'prevent_mass_assignment' => true,
            'allowed_assignment_fields' => [],
            'disallowed_assignment_fields' => [
                'id', 'created_at', 'updated_at', 'deleted_at',
                'password', 'role', 'permissions', 'status'
            ]
        ],
        
        // 验证码配置
        'captcha' => [
            'enabled' => true,
            'type' => 'math', // math, text, recaptcha
            'difficulty' => 'medium', // easy, medium, hard
            'case_sensitive' => false,
            'length' => 6,
            'expiry' => 300, // 5分钟
            'attempts_before_show' => 3,
            'recaptcha_site_key' => null, // 使用reCAPTCHA时设置
            'recaptcha_secret_key' => null, // 使用reCAPTCHA时设置
            'custom_font' => null
        ],
        
        // 自动安全更新配置
        'auto_updates' => [
            'enabled' => false, // 默认关闭
            'check_interval' => 86400, // 24小时
            'auto_apply_minor' => true,
            'auto_apply_patches' => true,
            'notify_before_update' => true,
            'backup_before_update' => true,
            'update_server' => 'https://updates.example.com/check',
            'api_key' => null
        ]
    ];
    
    /**
     * 私有构造函数
     * @param array $customConfig 自定义配置
     */
    private function __construct(array $customConfig = []) {
        $this->config = $this->mergeConfig($this->defaultConfig, $customConfig);
        $this->validateConfig();
    }
    
    /**
     * 获取单例实例
     * @param array $customConfig 自定义配置
     * @return SecurityConfig
     */
    public static function getInstance(array $customConfig = []) {
        if (self::$instance === null) {
            self::$instance = new self($customConfig);
        }
        return self::$instance;
    }
    
    /**
     * 合并配置数组
     * @param array $default 默认配置
     * @param array $custom 自定义配置
     * @return array 合并后的配置
     */
    private function mergeConfig(array $default, array $custom) {
        foreach ($custom as $key => $value) {
            if (is_array($value) && isset($default[$key]) && is_array($default[$key])) {
                $default[$key] = $this->mergeConfig($default[$key], $value);
            } else {
                $default[$key] = $value;
            }
        }
        return $default;
    }
    
    /**
     * 验证配置
     * @throws Exception 配置无效时抛出异常
     */
    private function validateConfig() {
        // 验证必需的密钥
        if ($this->config['csrf_protection']['enabled'] && empty($this->config['csrf_protection']['token_secret'])) {
            throw new Exception('CSRF protection enabled but token_secret is not set');
        }
        
        // 验证加密配置
        if ($this->config['encryption']['enabled'] && empty($this->config['encryption']['secret_key'])) {
            throw new Exception('Encryption enabled but secret_key is not set');
        }
        
        // 验证错误处理配置
        if ($this->config['error_handling']['notify_admin'] && empty($this->config['error_handling']['admin_email'])) {
            throw new Exception('Admin notification enabled but admin_email is not set');
        }
        
        // 验证密码策略
        if ($this->config['password_policy']['min_length'] < 6) {
            throw new Exception('Password minimum length should be at least 6 characters');
        }
        
        // 验证日志路径
        if ($this->config['logging']['enabled']) {
            $logPath = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/') . $this->config['logging']['path'];
            $logDir = dirname($logPath);
            if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
                throw new Exception('Unable to create log directory: ' . $logDir);
            }
        }
    }
    
    /**
     * 获取配置项
     * @param string $key 配置键，支持点号分隔的嵌套键
     * @param mixed $default 默认值
     * @return mixed 配置值或默认值
     */
    public function get($key, $default = null) {
        $keys = explode('.', $key);
        $value = $this->config;
        
        foreach ($keys as $k) {
            if (!is_array($value) || !isset($value[$k])) {
                return $default;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    /**
     * 设置配置项
     * @param string $key 配置键，支持点号分隔的嵌套键
     * @param mixed $value 配置值
     * @return void
     */
    public function set($key, $value) {
        $keys = explode('.', $key);
        $config = &$this->config;
        
        foreach ($keys as $k) {
            if (!isset($config[$k]) || !is_array($config[$k])) {
                $config[$k] = [];
            }
            $config = &$config[$k];
        }
        
        $config = $value;
    }
    
    /**
     * 获取完整配置
     * @return array 配置数组
     */
    public function getAll() {
        return $this->config;
    }
    
    /**
     * 更新配置
     * @param array $newConfig 新配置
     * @return void
     */
    public function update(array $newConfig) {
        $this->config = $this->mergeConfig($this->config, $newConfig);
        $this->validateConfig();
    }
    
    /**
     * 重置为默认配置
     * @return void
     */
    public function reset() {
        $this->config = $this->defaultConfig;
    }
    
    /**
     * 检查配置项是否已启用
     * @param string $key 配置键
     * @return bool 是否启用
     */
    public function isEnabled($key) {
        return $this->get($key . '.enabled', false) === true;
    }
    
    /**
     * 启用配置项
     * @param string $key 配置键
     * @return void
     */
    public function enable($key) {
        $this->set($key . '.enabled', true);
    }
    
    /**
     * 禁用配置项
     * @param string $key 配置键
     * @return void
     */
    public function disable($key) {
        $this->set($key . '.enabled', false);
    }
    
    /**
     * 加载配置文件
     * @param string $filePath 配置文件路径
     * @return bool 是否成功
     */
    public function loadFromFile($filePath) {
        if (!file_exists($filePath)) {
            return false;
        }
        
        $config = include $filePath;
        if (is_array($config)) {
            $this->update($config);
            return true;
        }
        
        return false;
    }
    
    /**
     * 保存配置到文件
     * @param string $filePath 配置文件路径
     * @return bool 是否成功
     */
    public function saveToFile($filePath) {
        $configContent = "<?php\n\nreturn " . var_export($this->config, true) . ";\n";
        return file_put_contents($filePath, $configContent) !== false;
    }
    
    /**
     * 生成随机密钥
     * @param int $length 密钥长度
     * @return string 随机密钥
     */
    public function generateRandomKey($length = 32) {
        $bytes = random_bytes($length);
        return bin2hex($bytes);
    }
    
    /**
     * 自动生成缺失的密钥
     * @return void
     */
    public function autoGenerateKeys() {
        // 生成CSRF密钥
        if (empty($this->config['csrf_protection']['token_secret'])) {
            $this->config['csrf_protection']['token_secret'] = $this->generateRandomKey(64);
        }
        
        // 生成加密密钥
        if (empty($this->config['encryption']['secret_key'])) {
            $this->config['encryption']['secret_key'] = $this->generateRandomKey($this->config['encryption']['key_length']);
        }
        
        // 生成加密pepper
        if (empty($this->config['encryption']['pepper'])) {
            $this->config['encryption']['pepper'] = $this->generateRandomKey(64);
        }
    }
    
    /**
     * 导出配置为JSON
     * @return string JSON配置
     */
    public function toJson() {
        return json_encode($this->config, JSON_PRETTY_PRINT);
    }
    
    /**
     * 从JSON导入配置
     * @param string $json JSON配置
     * @return bool 是否成功
     */
    public function fromJson($json) {
        $config = json_decode($json, true);
        if (is_array($config)) {
            $this->update($config);
            return true;
        }
        return false;
    }
    
    /**
     * 检查当前环境是否安全
     * @return array 安全问题列表
     */
    public function checkSecurity() {
        $issues = [];
        
        // 检查PHP版本
        if (version_compare(PHP_VERSION, '7.4.0', '<')) {
            $issues[] = 'PHP版本过低，建议升级到PHP 7.4或更高版本';
        }
        
        // 检查错误显示设置
        if (ini_get('display_errors') && $this->get('error_handling.display_errors') !== true) {
            $issues[] = 'PHP配置中的display_errors已启用，但安全配置中未启用';
        }
        
        // 检查session配置
        if (!ini_get('session.cookie_httponly') && $this->get('session_security.use_http_only_cookies')) {
            $issues[] = 'PHP配置中的session.cookie_httponly未启用';
        }
        
        if (!ini_get('session.cookie_secure') && $this->get('session_security.use_secure_cookies')) {
            $issues[] = 'PHP配置中的session.cookie_secure未启用';
        }
        
        // 检查密钥是否已设置
        if ($this->get('csrf_protection.enabled') && empty($this->get('csrf_protection.token_secret'))) {
            $issues[] = 'CSRF保护已启用，但未设置token_secret';
        }
        
        if ($this->get('encryption.enabled') && empty($this->get('encryption.secret_key'))) {
            $issues[] = '加密功能已启用，但未设置secret_key';
        }
        
        // 检查上传目录权限
        if ($this->get('file_upload.enabled')) {
            $uploadDir = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/') . $this->get('file_upload.upload_directory');
            if (is_dir($uploadDir) && substr(sprintf('%o', fileperms($uploadDir)), -4) !== '0755') {
                $issues[] = '上传目录权限不安全，建议设置为0755';
            }
        }
        
        return $issues;
    }
}

// 全局函数：获取安全配置实例
function securityConfig(array $customConfig = []) {
    return SecurityConfig::getInstance($customConfig);
}