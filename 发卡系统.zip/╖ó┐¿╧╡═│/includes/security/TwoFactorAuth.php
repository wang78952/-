<?php
/**
 * 双因素认证系统
 * 提供基于TOTP的二次验证功能，增强账户安全性
 * 
 * @author System Developer
 * @version 1.0.0
 * @copyright © 2025 发卡系统. All rights reserved.
 */

namespace Security;

use Exception;

class TwoFactorAuth {
    /**
     * 算法常量定义
     */
    const ALGORITHM_SHA1 = 'sha1';
    const ALGORITHM_SHA256 = 'sha256';
    const ALGORITHM_SHA512 = 'sha512';
    
    /**
     * 默认配置
     */
    const DEFAULT_ALGORITHM = self::ALGORITHM_SHA1;
    const DEFAULT_DIGITS = 6;
    const DEFAULT_PERIOD = 30;
    const DEFAULT_SECRET_LENGTH = 16;
    
    /**
     * 数据库实例
     * @var Database
     */
    protected $db;
    
    /**
     * Redis实例
     * @var RedisCache
     */
    protected $redis;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     * @param RedisCache $redis Redis实例
     */
    public function __construct($db, $redis) {
        $this->db = $db;
        $this->redis = $redis;
    }
    
    /**
     * 生成随机密钥
     * @param int $length 密钥长度
     * @return string 随机密钥
     */
    public function generateSecretKey($length = self::DEFAULT_SECRET_LENGTH) {
        // 生成随机字节
        $bytes = openssl_random_pseudo_bytes($length, $cryptoStrong);
        if (!$cryptoStrong) {
            throw new Exception('无法生成安全的随机密钥');
        }
        
        // 转换为base32编码
        return $this->base32Encode($bytes);
    }
    
    /**
     * 生成TOTP验证码
     * @param string $secret 密钥
     * @param int $period 有效期
     * @param string $algorithm 算法
     * @param int $digits 位数
     * @return string 验证码
     */
    public function generateCode($secret, $period = self::DEFAULT_PERIOD, $algorithm = self::DEFAULT_ALGORITHM, $digits = self::DEFAULT_DIGITS) {
        // 解码base32密钥
        $secretDecoded = $this->base32Decode($secret);
        
        // 获取当前时间戳的周期值
        $timestamp = floor(time() / $period);
        
        // 转换为大端字节序
        $timestampPacked = chr(0) . chr(0) . chr(0) . chr(0) . pack('N', $timestamp);
        
        // HMAC计算
        $hash = hash_hmac($algorithm, $timestampPacked, $secretDecoded, true);
        
        // 动态截断
        $offset = ord($hash[strlen($hash) - 1]) & 0xF;
        $code = (ord($hash[$offset]) & 0x7F) << 24
              | (ord($hash[$offset + 1]) & 0xFF) << 16
              | (ord($hash[$offset + 2]) & 0xFF) << 8
              | (ord($hash[$offset + 3]) & 0xFF);
        
        // 取指定位数
        $code = $code % pow(10, $digits);
        
        // 补零
        return str_pad($code, $digits, '0', STR_PAD_LEFT);
    }
    
    /**
     * 验证TOTP验证码
     * @param string $secret 密钥
     * @param string $code 用户输入的验证码
     * @param int $period 有效期
     * @param int $window 容错窗口（前后几个周期）
     * @return bool 是否验证成功
     */
    public function verifyCode($secret, $code, $period = self::DEFAULT_PERIOD, $window = 1) {
        // 检查验证码格式
        if (!preg_match('/^[0-9]{6}$/', $code)) {
            return false;
        }
        
        // 检查时间窗口
        for ($i = -$window; $i <= $window; $i++) {
            $currentTimestamp = floor(time() / $period) + $i;
            $timestampPacked = chr(0) . chr(0) . chr(0) . chr(0) . pack('N', $currentTimestamp);
            $secretDecoded = $this->base32Decode($secret);
            $hash = hash_hmac('sha1', $timestampPacked, $secretDecoded, true);
            $offset = ord($hash[strlen($hash) - 1]) & 0xF;
            $calculated = (ord($hash[$offset]) & 0x7F) << 24
                        | (ord($hash[$offset + 1]) & 0xFF) << 16
                        | (ord($hash[$offset + 2]) & 0xFF) << 8
                        | (ord($hash[$offset + 3]) & 0xFF);
            $calculated = $calculated % 1000000;
            $calculated = str_pad($calculated, 6, '0', STR_PAD_LEFT);
            
            if ($calculated === $code) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 为用户启用2FA
     * @param int $userId 用户ID
     * @param string $secret 密钥
     * @return bool 是否启用成功
     */
    public function enable2FA($userId, $secret) {
        // 检查用户是否已启用2FA
        $existing = $this->db->queryFirstRow(
            "SELECT * FROM user_2fa WHERE user_id = %d",
            $userId
        );
        
        if ($existing) {
            // 更新现有记录
            return $this->db->update('user_2fa', [
                'secret_key' => $secret,
                'enabled' => 1,
                'updated_at' => date('Y-m-d H:i:s')
            ], ['user_id' => $userId]);
        } else {
            // 创建新记录
            return $this->db->insert('user_2fa', [
                'user_id' => $userId,
                'secret_key' => $secret,
                'enabled' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);
        }
    }
    
    /**
     * 为用户禁用2FA
     * @param int $userId 用户ID
     * @return bool 是否禁用成功
     */
    public function disable2FA($userId) {
        return $this->db->update('user_2fa', [
            'enabled' => 0,
            'updated_at' => date('Y-m-d H:i:s')
        ], ['user_id' => $userId]);
    }
    
    /**
     * 获取用户的2FA状态
     * @param int $userId 用户ID
     * @return array 用户2FA信息
     */
    public function getUser2FAStatus($userId) {
        return $this->db->queryFirstRow(
            "SELECT * FROM user_2fa WHERE user_id = %d",
            $userId
        );
    }
    
    /**
     * 生成QR码URL用于扫描
     * @param string $secret 密钥
     * @param string $label 标签
     * @param string $issuer 发行者
     * @return string QR码URL
     */
    public function generateQRCodeUrl($secret, $label, $issuer = '发卡系统') {
        // 构建otpauth URI
        $otpauth = 'otpauth://totp/' . urlencode($issuer . ':' . $label) . 
                  '?secret=' . $secret . 
                  '&issuer=' . urlencode($issuer) . 
                  '&algorithm=SHA1&digits=6&period=30';
        
        // 返回Google Charts QR码生成URL
        return 'https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=' . urlencode($otpauth);
    }
    
    /**
     * 生成应急恢复码
     * @param int $userId 用户ID
     * @param int $count 恢复码数量
     * @return array 恢复码列表
     */
    public function generateRecoveryCodes($userId, $count = 10) {
        $codes = [];
        
        // 删除旧的恢复码
        $this->db->delete('user_recovery_codes', ['user_id' => $userId]);
        
        // 生成新的恢复码
        for ($i = 0; $i < $count; $i++) {
            $code = $this->generateSecureToken(16);
            $hash = password_hash($code, PASSWORD_ARGON2ID);
            
            $this->db->insert('user_recovery_codes', [
                'user_id' => $userId,
                'code_hash' => $hash,
                'used' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $codes[] = $code;
        }
        
        return $codes;
    }
    
    /**
     * 验证恢复码
     * @param int $userId 用户ID
     * @param string $code 恢复码
     * @return bool 是否有效
     */
    public function verifyRecoveryCode($userId, $code) {
        // 查询所有未使用的恢复码
        $codes = $this->db->query(
            "SELECT * FROM user_recovery_codes WHERE user_id = %d AND used = 0",
            $userId
        );
        
        // 验证每个恢复码
        foreach ($codes as $dbCode) {
            if (password_verify($code, $dbCode['code_hash'])) {
                // 标记为已使用
                $this->db->update('user_recovery_codes', [
                    'used' => 1,
                    'used_at' => date('Y-m-d H:i:s')
                ], ['id' => $dbCode['id']]);
                
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 记录2FA验证日志
     * @param int $userId 用户ID
     * @param bool $success 是否成功
     * @param string $ip IP地址
     * @param string $device 设备信息
     */
    public function log2FAVerification($userId, $success, $ip, $device) {
        $this->db->insert('user_2fa_logs', [
            'user_id' => $userId,
            'success' => $success ? 1 : 0,
            'ip_address' => $ip,
            'user_agent' => $device,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        // 记录到Redis用于监控
        $redisKey = "2fa:{$userId}:attempts:" . date('Ymd');
        $this->redis->incr($redisKey);
        $this->redis->expire($redisKey, 86400); // 24小时过期
    }
    
    /**
     * 检测2FA攻击尝试
     * @param int $userId 用户ID
     * @return bool 是否检测到攻击
     */
    public function detect2FAAttacks($userId) {
        $redisKey = "2fa:{$userId}:attempts:" . date('Ymd');
        $attempts = (int) $this->redis->get($redisKey);
        
        // 如果24小时内失败超过10次，视为攻击
        if ($attempts > 10) {
            // 锁定账户
            $this->db->update('users', [
                'status' => 'locked',
                'lock_reason' => '检测到2FA暴力破解尝试',
                'locked_at' => date('Y-m-d H:i:s')
            ], ['id' => $userId]);
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 生成安全令牌
     * @param int $length 令牌长度
     * @return string 安全令牌
     */
    private function generateSecureToken($length = 32) {
        return bin2hex(openssl_random_pseudo_bytes($length / 2));
    }
    
    /**
     * Base32编码
     * @param string $data 数据
     * @return string Base32编码
     */
    private function base32Encode($data) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $base32 = '';
        $dataBin = '';
        
        // 转换为二进制字符串
        for ($i = 0; $i < strlen($data); $i++) {
            $dataBin .= str_pad(decbin(ord($data[$i])), 8, '0', STR_PAD_LEFT);
        }
        
        // 按5位分组并编码
        for ($i = 0; $i < strlen($dataBin); $i += 5) {
            $chunk = substr($dataBin, $i, 5);
            // 不足5位补零
            $chunk = str_pad($chunk, 5, '0');
            $base32 .= $chars[bindec($chunk)];
        }
        
        // 计算需要添加的填充字符数
        $padLength = (8 - strlen($base32) % 8) % 8;
        $base32 .= str_repeat('=', $padLength);
        
        return $base32;
    }
    
    /**
     * Base32解码
     * @param string $data Base32编码数据
     * @return string 解码后的数据
     */
    private function base32Decode($data) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $data = strtoupper($data);
        $data = str_replace('=', '', $data);
        $dataBin = '';
        
        // 转换为二进制字符串
        for ($i = 0; $i < strlen($data); $i++) {
            $pos = strpos($chars, $data[$i]);
            if ($pos === false) {
                throw new Exception('无效的Base32字符: ' . $data[$i]);
            }
            $dataBin .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }
        
        // 按8位分组并解码
        $result = '';
        for ($i = 0; $i < strlen($dataBin); $i += 8) {
            $chunk = substr($dataBin, $i, 8);
            if (strlen($chunk) < 8) {
                break; // 忽略末尾不足8位的部分
            }
            $result .= chr(bindec($chunk));
        }
        
        return $result;
    }
}
?>