<?php
/**
 * 实时风控反欺诈系统
 * 实现多维度风险评估、行为分析、异常检测和风控决策
 */

class AntiFraudSystem {
    // 风险等级常量
    const RISK_LEVEL_LOW = 0;      // 低风险 (0-20分)
    const RISK_LEVEL_MEDIUM = 1;   // 中风险 (21-50分)
    const RISK_LEVEL_HIGH = 2;     // 高风险 (51-75分)
    const RISK_LEVEL_CRITICAL = 3; // 极高风险 (76-100分)
    
    // 风险决策常量
    const DECISION_PASS = 'pass';             // 通过
    const DECISION_REVIEW = 'review';         // 人工审核
    const DECISION_CHALLENGE = 'challenge';   // 二次验证
    const DECISION_REJECT = 'reject';         // 拒绝
    
    // 评分规则类型
    const RULE_TYPE_USER = 'user';             // 用户相关规则
    const RULE_TYPE_TRANSACTION = 'transaction'; // 交易相关规则
    const RULE_TYPE_BEHAVIOR = 'behavior';     // 行为相关规则
    const RULE_TYPE_DEVICE = 'device';         // 设备相关规则
    const RULE_TYPE_IP = 'ip';                 // IP相关规则
    const RULE_TYPE_FINANCIAL = 'financial';   // 金融相关规则
    
    // 单例实例
    private static $instance = null;
    
    // Redis连接
    private $redis = null;
    
    // 数据库连接
    private $db = null;
    
    // 配置
    private $config = [];
    
    // 风险规则引擎
    private $ruleEngine = null;
    
    // 评分缓存
    private $scoreCache = [];
    
    // 日志记录
    private $logger = null;
    
    /**
     * 私有构造函数（单例模式）
     */
    private function __construct() {
        $this->loadConfig();
        $this->initializeRedis();
        $this->initializeDatabase();
        $this->initializeLogger();
        $this->initializeRuleEngine();
    }
    
    /**
     * 获取风控系统实例（单例模式）
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 加载配置
     */
    private function loadConfig() {
        // 默认配置
        $this->config = [
            // Redis配置
            'redis' => [
                'host' => 'localhost',
                'port' => 6379,
                'password' => '',
                'database' => 2,
                'timeout' => 5
            ],
            
            // 数据库配置
            'database' => [
                'table_prefix' => 'sys_risk_'
            ],
            
            // 风险评分配置
            'scoring' => [
                'weight_factors' => [
                    self::RULE_TYPE_USER => 0.25,
                    self::RULE_TYPE_TRANSACTION => 0.3,
                    self::RULE_TYPE_BEHAVIOR => 0.2,
                    self::RULE_TYPE_DEVICE => 0.15,
                    self::RULE_TYPE_IP => 0.05,
                    self::RULE_TYPE_FINANCIAL => 0.05
                ],
                'score_mapping' => [
                    self::RISK_LEVEL_LOW => [
                        'min' => 0,
                        'max' => 20,
                        'decision' => self::DECISION_PASS
                    ],
                    self::RISK_LEVEL_MEDIUM => [
                        'min' => 21,
                        'max' => 50,
                        'decision' => self::DECISION_CHALLENGE
                    ],
                    self::RISK_LEVEL_HIGH => [
                        'min' => 51,
                        'max' => 75,
                        'decision' => self::DECISION_REVIEW
                    ],
                    self::RISK_LEVEL_CRITICAL => [
                        'min' => 76,
                        'max' => 100,
                        'decision' => self::DECISION_REJECT
                    ]
                ]
            ],
            
            // 风控规则
            'rules' => [
                // 用户相关规则
                self::RULE_TYPE_USER => [
                    'new_user_high_amount' => [
                        'enabled' => true,
                        'description' => '新用户大额交易',
                        'max_days' => 7,
                        'threshold_amount' => 1000,
                        'score' => 30
                    ],
                    'user_blacklist' => [
                        'enabled' => true,
                        'description' => '黑名单用户',
                        'score' => 100
                    ],
                    'user_credit_below_threshold' => [
                        'enabled' => true,
                        'description' => '用户信用分低于阈值',
                        'threshold' => 60,
                        'score' => 40
                    ],
                    'failed_login_count' => [
                        'enabled' => true,
                        'description' => '登录失败次数过多',
                        'threshold' => 5,
                        'timeframe' => 300, // 5分钟
                        'score' => 25
                    ],
                    'recent_account_change' => [
                        'enabled' => true,
                        'description' => '近期修改账户信息',
                        'timeframe' => 86400, // 24小时
                        'score' => 20
                    ]
                ],
                
                // 交易相关规则
                self::RULE_TYPE_TRANSACTION => [
                    'amount_exceeds_limit' => [
                        'enabled' => true,
                        'description' => '交易金额超过用户限额',
                        'score' => 50
                    ],
                    'frequency_abnormal' => [
                        'enabled' => true,
                        'description' => '交易频率异常',
                        'threshold' => 10,
                        'timeframe' => 3600, // 1小时
                        'score' => 35
                    ],
                    'transaction_pattern_change' => [
                        'enabled' => true,
                        'description' => '交易模式突变',
                        'score' => 30
                    ],
                    'multiple_denied_transactions' => [
                        'enabled' => true,
                        'description' => '多次拒绝后重试',
                        'threshold' => 3,
                        'timeframe' => 1800, // 30分钟
                        'score' => 45
                    ],
                    'unusual_transaction_time' => [
                        'enabled' => true,
                        'description' => '非常规交易时间',
                        'score' => 15
                    ]
                ],
                
                // 行为相关规则
                self::RULE_TYPE_BEHAVIOR => [
                    'navigation_speed_abnormal' => [
                        'enabled' => true,
                        'description' => '页面浏览速度异常',
                        'threshold_seconds' => 10,
                        'score' => 25
                    ],
                    'copy_paste_card_info' => [
                        'enabled' => true,
                        'description' => '复制粘贴卡密信息',
                        'score' => 15
                    ],
                    'multiple_tab_usage' => [
                        'enabled' => true,
                        'description' => '多标签页操作',
                        'threshold' => 3,
                        'score' => 20
                    ],
                    'incomplete_form_filling' => [
                        'enabled' => true,
                        'description' => '表单多次不完整提交',
                        'threshold' => 3,
                        'score' => 15
                    ],
                    'mouse_movement_abnormal' => [
                        'enabled' => true,
                        'description' => '鼠标移动模式异常',
                        'score' => 20
                    ]
                ],
                
                // 设备相关规则
                self::RULE_TYPE_DEVICE => [
                    'new_device' => [
                        'enabled' => true,
                        'description' => '新设备登录',
                        'score' => 20
                    ],
                    'device_fingerprint_mismatch' => [
                        'enabled' => true,
                        'description' => '设备指纹不匹配',
                        'score' => 40
                    ],
                    'multiple_accounts_same_device' => [
                        'enabled' => true,
                        'description' => '多账户共用设备',
                        'threshold' => 5,
                        'timeframe' => 86400, // 1天
                        'score' => 35
                    ],
                    'emulator_detection' => [
                        'enabled' => true,
                        'description' => '模拟器检测',
                        'score' => 60
                    ],
                    'browser_tampering' => [
                        'enabled' => true,
                        'description' => '浏览器环境被篡改',
                        'score' => 50
                    ]
                ],
                
                // IP相关规则
                self::RULE_TYPE_IP => [
                    'ip_blacklist' => [
                        'enabled' => true,
                        'description' => '黑名单IP',
                        'score' => 70
                    ],
                    'proxy_vpn_detection' => [
                        'enabled' => true,
                        'description' => '代理/VPN检测',
                        'score' => 45
                    ],
                    'country_risk' => [
                        'enabled' => true,
                        'description' => '高风险国家/地区',
                        'score' => 40
                    ],
                    'ip_user_mismatch' => [
                        'enabled' => true,
                        'description' => 'IP与用户常用地区不符',
                        'score' => 30
                    ],
                    'ip_frequency' => [
                        'enabled' => true,
                        'description' => 'IP使用频率过高',
                        'threshold' => 20,
                        'timeframe' => 3600, // 1小时
                        'score' => 25
                    ]
                ],
                
                // 金融相关规则
                self::RULE_TYPE_FINANCIAL => [
                    'unusual_amount' => [
                        'enabled' => true,
                        'description' => '金额与用户历史不符',
                        'deviation_percent' => 200, // 超过200%
                        'score' => 30
                    ],
                    'card_velocity_check' => [
                        'enabled' => true,
                        'description' => '卡密购买速度过快',
                        'threshold' => 15,
                        'timeframe' => 3600, // 1小时
                        'score' => 35
                    ],
                    'high_risk_product' => [
                        'enabled' => true,
                        'description' => '购买高风险产品',
                        'score' => 20
                    ],
                    'refund_frequency' => [
                        'enabled' => true,
                        'description' => '退款频率过高',
                        'threshold' => 5,
                        'timeframe' => 604800, // 7天
                        'score' => 30
                    ]
                ]
            ],
            
            // 黑名单配置
            'blacklist' => [
                'user' => [],
                'ip' => [],
                'device' => [],
                'product' => []
            ],
            
            // 风险决策配置
            'decision_rules' => [
                self::RISK_LEVEL_LOW => [
                    'decision' => self::DECISION_PASS,
                    'actions' => ['log']
                ],
                self::RISK_LEVEL_MEDIUM => [
                    'decision' => self::DECISION_CHALLENGE,
                    'actions' => ['log', 'challenge', 'alert']
                ],
                self::RISK_LEVEL_HIGH => [
                    'decision' => self::DECISION_REVIEW,
                    'actions' => ['log', 'review', 'alert', 'freeze']
                ],
                self::RISK_LEVEL_CRITICAL => [
                    'decision' => self::DECISION_REJECT,
                    'actions' => ['log', 'reject', 'alert', 'block', 'investigate']
                ]
            ],
            
            // 缓存配置
            'cache' => [
                'score_ttl' => 300, // 5分钟
                'rule_result_ttl' => 600 // 10分钟
            ],
            
            // 设备指纹配置
            'device_fingerprint' => [
                'enabled' => true,
                'collect_browser_info' => true,
                'collect_system_info' => true,
                'collect_network_info' => true,
                'cookie_name' => '_device_fp'
            ],
            
            // 机器学习配置
            'ml_config' => [
                'enabled' => true,
                'model_path' => 'ml_models/fraud_detection_model.bin',
                'features' => [
                    'user_features' => true,
                    'transaction_features' => true,
                    'behavior_features' => true,
                    'temporal_features' => true
                ],
                'score_weight' => 0.3 // 机器学习评分权重
            ]
        ];
        
        // 从配置文件加载自定义配置
        if (file_exists(CONFIG_PATH . '/antifraud_config.php')) {
            include CONFIG_PATH . '/antifraud_config.php';
            if (isset($antifraudConfig) && is_array($antifraudConfig)) {
                $this->mergeConfig($this->config, $antifraudConfig);
            }
        }
    }
    
    /**
     * 合并配置
     */
    private function mergeConfig(&$default, $custom) {
        foreach ($custom as $key => $value) {
            if (is_array($value) && isset($default[$key]) && is_array($default[$key])) {
                $this->mergeConfig($default[$key], $value);
            } else {
                $default[$key] = $value;
            }
        }
    }
    
    /**
     * 初始化Redis连接
     */
    private function initializeRedis() {
        try {
            $redisConfig = $this->config['redis'];
            $this->redis = new Redis();
            $this->redis->connect(
                $redisConfig['host'],
                $redisConfig['port'],
                $redisConfig['timeout']
            );
            
            if (!empty($redisConfig['password'])) {
                $this->redis->auth($redisConfig['password']);
            }
            
            if (isset($redisConfig['database']) && $redisConfig['database'] >= 0) {
                $this->redis->select($redisConfig['database']);
            }
            
            Logger::info('风控系统Redis连接成功');
        } catch (Exception $e) {
            Logger::error('风控系统Redis连接失败: ' . $e->getMessage());
            throw new Exception('无法连接到风控系统Redis服务');
        }
    }
    
    /**
     * 初始化数据库连接
     */
    private function initializeDatabase() {
        try {
            $this->db = Database::getInstance();
            Logger::info('风控系统数据库连接成功');
        } catch (Exception $e) {
            Logger::error('风控系统数据库连接失败: ' . $e->getMessage());
            throw new Exception('无法连接到风控系统数据库');
        }
    }
    
    /**
     * 初始化日志记录器
     */
    private function initializeLogger() {
        $this->logger = Logger::getInstance();
    }
    
    /**
     * 初始化规则引擎
     */
    private function initializeRuleEngine() {
        $this->ruleEngine = new AntiFraudRuleEngine($this->config['rules'], $this->redis, $this->db);
    }
    
    /**
     * 评估交易风险
     * @param array $context 交易上下文信息
     * @return array 风险评估结果
     */
    public function evaluateRisk($context) {
        // 生成请求ID
        $requestId = isset($context['request_id']) ? $context['request_id'] : uniqid('risk_', true);
        
        // 构建完整的评估上下文
        $evaluationContext = $this->buildEvaluationContext($context);
        $evaluationContext['request_id'] = $requestId;
        
        try {
            // 检查缓存中是否有近期评估结果
            $cacheKey = 'risk_eval:' . md5(json_encode($this->getCacheKeyComponents($evaluationContext)));
            $cachedResult = $this->redis->get($cacheKey);
            
            if ($cachedResult) {
                $result = json_decode($cachedResult, true);
                $result['from_cache'] = true;
                $this->logger->info('风控评估结果命中缓存', ['request_id' => $requestId]);
                return $result;
            }
            
            // 记录评估开始
            $startTime = microtime(true);
            $this->logger->info('开始风控评估', ['request_id' => $requestId, 'type' => $evaluationContext['event_type']]);
            
            // 执行多维度规则评估
            $ruleResults = $this->executeRuleEvaluation($evaluationContext);
            
            // 计算综合风险分数
            $riskScore = $this->calculateRiskScore($ruleResults);
            
            // 确定风险等级
            $riskLevel = $this->determineRiskLevel($riskScore);
            
            // 应用机器学习评分
            $mlScore = 0;
            if ($this->config['ml_config']['enabled']) {
                $mlScore = $this->getMachineLearningScore($evaluationContext);
                $riskScore = $this->combineRiskScores($riskScore, $mlScore);
            }
            
            // 生成风控决策
            $decision = $this->makeDecision($riskScore, $riskLevel, $ruleResults);
            
            // 执行决策动作
            $this->executeDecisionActions($decision, $evaluationContext, $ruleResults);
            
            // 构建评估结果
            $evaluationTime = microtime(true) - $startTime;
            $result = [
                'request_id' => $requestId,
                'risk_score' => $riskScore,
                'risk_level' => $riskLevel,
                'risk_level_text' => $this->getRiskLevelText($riskLevel),
                'decision' => $decision,
                'decision_text' => $this->getDecisionText($decision),
                'rule_triggers' => $this->getRuleTriggers($ruleResults),
                'ml_score' => $mlScore,
                'evaluation_time_ms' => round($evaluationTime * 1000, 2),
                'timestamp' => time(),
                'context_summary' => $this->getContextSummary($evaluationContext),
                'recommendations' => $this->getRecommendations($decision, $riskLevel)
            ];
            
            // 缓存评估结果
            $this->redis->setex($cacheKey, $this->config['cache']['score_ttl'], json_encode($result));
            
            // 记录评估结果
            $this->logEvaluationResult($result, $evaluationContext);
            
            // 保存评估记录到数据库
            $this->saveEvaluationRecord($evaluationContext, $result);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error('风控评估失败', [
                'request_id' => $requestId,
                'error' => $e->getMessage(),
                'stack_trace' => $e->getTraceAsString()
            ]);
            
            // 风控失败时的兜底决策
            return $this->getFallbackDecision($evaluationContext);
        }
    }
    
    /**
     * 构建评估上下文
     */
    private function buildEvaluationContext($context) {
        $defaultContext = [
            'event_type' => 'transaction', // 默认事件类型
            'user_id' => null,
            'ip_address' => $this->getClientIP(),
            'device_info' => $this->getDeviceInfo(),
            'timestamp' => time(),
            'amount' => 0,
            'currency' => 'CNY',
            'product_id' => null,
            'transaction_id' => null,
            'payment_method' => null,
            'browser_info' => $this->getBrowserInfo(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'referrer' => $_SERVER['HTTP_REFERER'] ?? '',
            'behavior_data' => [],
            'transaction_history' => [],
            'user_profile' => []
        ];
        
        // 合并用户提供的上下文
        $mergedContext = array_merge($defaultContext, $context);
        
        // 补充用户信息
        if ($mergedContext['user_id']) {
            $mergedContext['user_profile'] = $this->getUserProfile($mergedContext['user_id']);
            $mergedContext['transaction_history'] = $this->getUserTransactionHistory($mergedContext['user_id']);
        }
        
        // 补充设备指纹
        if ($this->config['device_fingerprint']['enabled']) {
            $mergedContext['device_fingerprint'] = $this->getDeviceFingerprint($mergedContext['device_info']);
        }
        
        // 补充IP信息
        $mergedContext['ip_info'] = $this->getIPInfo($mergedContext['ip_address']);
        
        return $mergedContext;
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIP() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        
        // 检查代理IP
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        
        return $ip;
    }
    
    /**
     * 获取设备信息
     */
    private function getDeviceInfo() {
        // 从请求中获取设备信息
        $deviceInfo = [];
        
        // 尝试从Cookie获取设备指纹
        if (isset($_COOKIE[$this->config['device_fingerprint']['cookie_name']])) {
            $deviceInfo['fingerprint'] = $_COOKIE[$this->config['device_fingerprint']['cookie_name']];
        }
        
        // 从HTTP头获取设备信息
        if (isset($_SERVER['HTTP_X_DEVICE_ID'])) {
            $deviceInfo['device_id'] = $_SERVER['HTTP_X_DEVICE_ID'];
        }
        
        if (isset($_SERVER['HTTP_X_DEVICE_TYPE'])) {
            $deviceInfo['device_type'] = $_SERVER['HTTP_X_DEVICE_TYPE'];
        }
        
        return $deviceInfo;
    }
    
    /**
     * 获取浏览器信息
     */
    private function getBrowserInfo() {
        $browserInfo = [
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
            'accept_encoding' => $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '',
            'screen_resolution' => isset($_SERVER['HTTP_X_SCREEN_WIDTH']) && isset($_SERVER['HTTP_X_SCREEN_HEIGHT']) ? 
                $_SERVER['HTTP_X_SCREEN_WIDTH'] . 'x' . $_SERVER['HTTP_X_SCREEN_HEIGHT'] : null,
            'timezone' => $_SERVER['HTTP_X_TIMEZONE'] ?? date_default_timezone_get()
        ];
        
        return $browserInfo;
    }
    
    /**
     * 获取用户资料
     */
    private function getUserProfile($userId) {
        try {
            // 从数据库获取用户信息
            $userProfile = $this->db->queryFirstRow(
                "SELECT * FROM users WHERE id = %s", 
                $userId
            );
            
            if (!$userProfile) {
                return [];
            }
            
            // 获取用户信用信息
            $creditInfo = $this->db->queryFirstRow(
                "SELECT * FROM user_credit WHERE user_id = %s",
                $userId
            );
            
            // 获取用户风控信息
            $riskInfo = $this->db->queryFirstRow(
                "SELECT * FROM user_risk_profile WHERE user_id = %s",
                $userId
            );
            
            return [
                'basic' => $userProfile,
                'credit' => $creditInfo,
                'risk' => $riskInfo,
                'registration_days' => $userProfile ? floor((time() - strtotime($userProfile['created_at'])) / 86400) : 0
            ];
        } catch (Exception $e) {
            $this->logger->error('获取用户资料失败', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return [];
        }
    }
    
    /**
     * 获取用户交易历史
     */
    private function getUserTransactionHistory($userId) {
        try {
            // 获取最近的交易记录
            $transactions = $this->db->query(
                "SELECT * FROM orders WHERE user_id = %s ORDER BY created_at DESC LIMIT 20",
                $userId
            );
            
            // 计算统计信息
            $stats = [
                'total_count' => count($transactions),
                'total_amount' => array_sum(array_column($transactions, 'amount')),
                'avg_amount' => count($transactions) > 0 ? 
                    array_sum(array_column($transactions, 'amount')) / count($transactions) : 0,
                'max_amount' => count($transactions) > 0 ? 
                    max(array_column($transactions, 'amount')) : 0,
                'transaction_dates' => array_map(function($t) {
                    return strtotime($t['created_at']);
                }, $transactions)
            ];
            
            return [
                'recent_transactions' => $transactions,
                'statistics' => $stats
            ];
        } catch (Exception $e) {
            $this->logger->error('获取用户交易历史失败', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return ['recent_transactions' => [], 'statistics' => []];
        }
    }
    
    /**
     * 获取设备指纹
     */
    private function getDeviceFingerprint($deviceInfo) {
        if (isset($deviceInfo['fingerprint'])) {
            return $deviceInfo['fingerprint'];
        }
        
        // 生成设备指纹
        $fingerprintData = [];
        
        if ($this->config['device_fingerprint']['collect_browser_info']) {
            $fingerprintData['browser'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $fingerprintData['accept_headers'] = $_SERVER['HTTP_ACCEPT'] ?? '';
            $fingerprintData['accept_language'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
        }
        
        if ($this->config['device_fingerprint']['collect_system_info']) {
            $fingerprintData['screen_resolution'] = isset($_SERVER['HTTP_X_SCREEN_WIDTH']) ? 
                $_SERVER['HTTP_X_SCREEN_WIDTH'] . 'x' . $_SERVER['HTTP_X_SCREEN_HEIGHT'] : '';
            $fingerprintData['color_depth'] = $_SERVER['HTTP_X_COLOR_DEPTH'] ?? '';
            $fingerprintData['timezone'] = $_SERVER['HTTP_X_TIMEZONE'] ?? '';
        }
        
        if ($this->config['device_fingerprint']['collect_network_info']) {
            $fingerprintData['ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
            $fingerprintData['http_headers'] = $this->getRelevantHeaders();
        }
        
        // 生成指纹哈希
        return md5(json_encode($fingerprintData));
    }
    
    /**
     * 获取相关HTTP头信息
     */
    private function getRelevantHeaders() {
        $headers = [];
        $relevantHeaders = [
            'HTTP_ACCEPT_ENCODING', 'HTTP_DNT', 'HTTP_CONNECTION',
            'HTTP_UPGRADE_INSECURE_REQUESTS', 'HTTP_SEC_FETCH_SITE',
            'HTTP_SEC_FETCH_MODE', 'HTTP_SEC_FETCH_USER', 'HTTP_SEC_FETCH_DEST'
        ];
        
        foreach ($relevantHeaders as $header) {
            if (isset($_SERVER[$header])) {
                $headers[$header] = $_SERVER[$header];
            }
        }
        
        return $headers;
    }
    
    /**
     * 获取IP信息
     */
    private function getIPInfo($ip) {
        try {
            // 从缓存获取IP信息
            $cacheKey = "ip_info:{$ip}";
            $cachedInfo = $this->redis->get($cacheKey);
            
            if ($cachedInfo) {
                return json_decode($cachedInfo, true);
            }
            
            // 这里可以调用IP地理位置API，暂时使用模拟数据
            $ipInfo = [
                'ip' => $ip,
                'country' => 'Unknown',
                'region' => 'Unknown',
                'city' => 'Unknown',
                'isp' => 'Unknown',
                'is_proxy' => false,
                'is_vpn' => false,
                'risk_score' => 0
            ];
            
            // 设置缓存
            $this->redis->setex($cacheKey, 86400, json_encode($ipInfo));
            
            return $ipInfo;
        } catch (Exception $e) {
            $this->logger->error('获取IP信息失败', ['ip' => $ip, 'error' => $e->getMessage()]);
            return ['ip' => $ip];
        }
    }
    
    /**
     * 执行规则评估
     */
    private function executeRuleEvaluation($context) {
        $ruleResults = [];
        
        // 按规则类型分组执行评估
        $ruleTypes = [
            self::RULE_TYPE_USER,
            self::RULE_TYPE_TRANSACTION,
            self::RULE_TYPE_BEHAVIOR,
            self::RULE_TYPE_DEVICE,
            self::RULE_TYPE_IP,
            self::RULE_TYPE_FINANCIAL
        ];
        
        foreach ($ruleTypes as $ruleType) {
            $typeResults = $this->ruleEngine->evaluateRules($ruleType, $context);
            $ruleResults[$ruleType] = $typeResults;
        }
        
        return $ruleResults;
    }
    
    /**
     * 计算风险分数
     */
    private function calculateRiskScore($ruleResults) {
        $totalScore = 0;
        $weightFactors = $this->config['scoring']['weight_factors'];
        $ruleCounts = [];
        $typeScores = [];
        
        // 计算各类规则的总分
        foreach ($ruleResults as $ruleType => $results) {
            $typeScore = 0;
            $triggeredCount = 0;
            
            foreach ($results as $ruleName => $result) {
                if ($result['triggered']) {
                    $typeScore += $result['score'];
                    $triggeredCount++;
                }
            }
            
            $typeScores[$ruleType] = $typeScore;
            $ruleCounts[$ruleType] = $triggeredCount;
        }
        
        // 应用权重计算加权总分
        foreach ($typeScores as $ruleType => $score) {
            $weight = isset($weightFactors[$ruleType]) ? $weightFactors[$ruleType] : 0.1;
            $totalScore += $score * $weight;
        }
        
        // 确保分数在0-100范围内
        return min(100, max(0, $totalScore));
    }
    
    /**
     * 获取机器学习评分
     */
    private function getMachineLearningScore($context) {
        try {
            // 生成机器学习特征
            $features = $this->generateMLFeatures($context);
            
            // 这里应该调用实际的机器学习模型
            // 暂时返回模拟评分
            $mlScore = 0;
            
            // 记录ML评分过程
            $this->logger->info('机器学习评分完成', ['features_count' => count($features)]);
            
            return $mlScore;
        } catch (Exception $e) {
            $this->logger->error('机器学习评分失败', ['error' => $e->getMessage()]);
            return 0;
        }
    }
    
    /**
     * 生成机器学习特征
     */
    private function generateMLFeatures($context) {
        $features = [];
        
        // 用户特征
        if (isset($context['user_profile']['basic'])) {
            $userProfile = $context['user_profile']['basic'];
            $features['user_age_days'] = isset($userProfile['created_at']) ? 
                floor((time() - strtotime($userProfile['created_at'])) / 86400) : 0;
            $features['user_login_count'] = isset($userProfile['login_count']) ? $userProfile['login_count'] : 0;
        }
        
        // 交易特征
        $features['transaction_amount'] = $context['amount'] ?? 0;
        $features['transaction_hour'] = date('G');
        $features['transaction_day_of_week'] = date('w');
        
        // 行为特征
        $features['session_duration_seconds'] = isset($context['session_duration']) ? $context['session_duration'] : 0;
        $features['page_views'] = isset($context['page_views']) ? $context['page_views'] : 0;
        
        return $features;
    }
    
    /**
     * 合并风险分数
     */
    private function combineRiskScores($ruleScore, $mlScore) {
        $mlWeight = $this->config['ml_config']['score_weight'];
        $ruleWeight = 1 - $mlWeight;
        
        return ($ruleScore * $ruleWeight) + ($mlScore * $mlWeight);
    }
    
    /**
     * 确定风险等级
     */
    private function determineRiskLevel($score) {
        if ($score <= 20) return self::RISK_LEVEL_LOW;
        if ($score <= 50) return self::RISK_LEVEL_MEDIUM;
        if ($score <= 75) return self::RISK_LEVEL_HIGH;
        return self::RISK_LEVEL_CRITICAL;
    }
    
    /**
     * 生成风控决策
     */
    private function makeDecision($score, $level, $ruleResults) {
        // 根据风险等级获取默认决策
        $decisionConfig = $this->config['decision_rules'][$level];
        $defaultDecision = $decisionConfig['decision'];
        
        // 应用特殊规则覆盖默认决策
        $overrideDecision = $this->applyDecisionOverrides($score, $level, $ruleResults);
        
        return $overrideDecision ?: $defaultDecision;
    }
    
    /**
     * 应用决策覆盖规则
     */
    private function applyDecisionOverrides($score, $level, $ruleResults) {
        // 检查是否有严重的规则触发
        foreach ($ruleResults as $ruleType => $results) {
            foreach ($results as $ruleName => $result) {
                if ($result['triggered']) {
                    // 黑名单规则直接拒绝
                    if (in_array($ruleName, ['user_blacklist', 'ip_blacklist'])) {
                        return self::DECISION_REJECT;
                    }
                    
                    // 新用户大额交易要求二次验证
                    if ($ruleName === 'new_user_high_amount' && $level < self::RISK_LEVEL_HIGH) {
                        return self::DECISION_CHALLENGE;
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * 执行决策动作
     */
    private function executeDecisionActions($decision, $context, $ruleResults) {
        $decisionConfig = $this->config['decision_rules'][$this->determineRiskLevel($this->calculateRiskScore($ruleResults))];
        $actions = $decisionConfig['actions'];
        
        foreach ($actions as $action) {
            switch ($action) {
                case 'log':
                    $this->logRiskDecision($decision, $context, $ruleResults);
                    break;
                    
                case 'alert':
                    $this->sendRiskAlert($decision, $context, $ruleResults);
                    break;
                    
                case 'block':
                    $this->blockEntity($context);
                    break;
                    
                case 'freeze':
                    $this->freezeTransaction($context);
                    break;
                    
                case 'review':
                    $this->createReviewTask($context, $ruleResults);
                    break;
            }
        }
    }
    
    /**
     * 记录风险决策
     */
    private function logRiskDecision($decision, $context, $ruleResults) {
        $logData = [
            'timestamp' => time(),
            'decision' => $decision,
            'event_type' => $context['event_type'],
            'user_id' => $context['user_id'],
            'amount' => $context['amount'] ?? 0,
            'ip' => $context['ip_address'],
            'request_id' => $context['request_id'],
            'triggered_rules' => $this->getRuleTriggers($ruleResults)
        ];
        
        $this->logger->info('风控决策记录', $logData);
        
        // 保存到数据库
        try {
            $this->db->insert('risk_decisions', [
                'request_id' => $context['request_id'],
                'user_id' => $context['user_id'],
                'event_type' => $context['event_type'],
                'decision' => $decision,
                'amount' => $context['amount'] ?? 0,
                'ip_address' => $context['ip_address'],
                'triggered_rules' => json_encode($this->getRuleTriggers($ruleResults)),
                'context' => json_encode($context),
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            $this->logger->error('保存风控决策失败', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * 发送风险告警
     */
    private function sendRiskAlert($decision, $context, $ruleResults) {
        // 构建告警消息
        $alertMessage = "风控告警: {$decision} - " . 
                       (isset($context['event_type']) ? $context['event_type'] : '未知事件') . 
                       " (请求ID: {$context['request_id']})";
        
        $this->logger->warning($alertMessage, ['rule_triggers' => $this->getRuleTriggers($ruleResults)]);
        
        // 这里可以集成消息推送、邮件等告警机制
    }
    
    /**
     * 阻止实体
     */
    private function blockEntity($context) {
        // 可以实现IP、用户、设备等的阻止逻辑
    }
    
    /**
     * 冻结交易
     */
    private function freezeTransaction($context) {
        if (isset($context['transaction_id'])) {
            try {
                $this->db->update(
                    'orders',
                    ['status' => 'frozen', 'risk_frozen' => 1],
                    ['id' => $context['transaction_id']]
                );
            } catch (Exception $e) {
                $this->logger->error('冻结交易失败', ['transaction_id' => $context['transaction_id'], 'error' => $e->getMessage()]);
            }
        }
    }
    
    /**
     * 创建审核任务
     */
    private function createReviewTask($context, $ruleResults) {
        try {
            $this->db->insert('risk_review_tasks', [
                'request_id' => $context['request_id'],
                'user_id' => $context['user_id'],
                'transaction_id' => $context['transaction_id'] ?? null,
                'event_type' => $context['event_type'],
                'risk_score' => $this->calculateRiskScore($ruleResults),
                'triggered_rules' => json_encode($this->getRuleTriggers($ruleResults)),
                'context' => json_encode($context),
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            $this->logger->error('创建风控审核任务失败', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * 保存评估记录
     */
    private function saveEvaluationRecord($context, $result) {
        try {
            $this->db->insert('risk_evaluations', [
                'request_id' => $result['request_id'],
                'user_id' => $context['user_id'],
                'event_type' => $context['event_type'],
                'risk_score' => $result['risk_score'],
                'risk_level' => $result['risk_level'],
                'decision' => $result['decision'],
                'ml_score' => $result['ml_score'],
                'evaluation_time_ms' => $result['evaluation_time_ms'],
                'triggered_rules' => json_encode($result['rule_triggers']),
                'context' => json_encode($context),
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            $this->logger->error('保存风控评估记录失败', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * 获取缓存键组件
     */
    private function getCacheKeyComponents($context) {
        return [
            'user_id' => $context['user_id'] ?? '',
            'event_type' => $context['event_type'] ?? '',
            'amount' => $context['amount'] ?? 0,
            'ip' => $context['ip_address'] ?? '',
            'timestamp_minute' => floor(time() / 60) // 精确到分钟
        ];
    }
    
    /**
     * 获取触发的规则列表
     */
    private function getRuleTriggers($ruleResults) {
        $triggers = [];
        
        foreach ($ruleResults as $ruleType => $results) {
            foreach ($results as $ruleName => $result) {
                if ($result['triggered']) {
                    $triggers[] = [
                        'type' => $ruleType,
                        'name' => $ruleName,
                        'score' => $result['score'],
                        'description' => $result['description']
                    ];
                }
            }
        }
        
        return $triggers;
    }
    
    /**
     * 获取风险等级文本
     */
    private function getRiskLevelText($level) {
        $levelTexts = [
            self::RISK_LEVEL_LOW => '低风险',
            self::RISK_LEVEL_MEDIUM => '中风险',
            self::RISK_LEVEL_HIGH => '高风险',
            self::RISK_LEVEL_CRITICAL => '极高风险'
        ];
        
        return $levelTexts[$level] ?? '未知风险';
    }
    
    /**
     * 获取决策文本
     */
    private function getDecisionText($decision) {
        $decisionTexts = [
            self::DECISION_PASS => '通过',
            self::DECISION_REVIEW => '人工审核',
            self::DECISION_CHALLENGE => '二次验证',
            self::DECISION_REJECT => '拒绝'
        ];
        
        return $decisionTexts[$decision] ?? '未知决策';
    }
    
    /**
     * 获取上下文摘要
     */
    private function getContextSummary($context) {
        $summary = [];
        
        if (isset($context['user_id'])) $summary['user_id'] = $context['user_id'];
        if (isset($context['event_type'])) $summary['event_type'] = $context['event_type'];
        if (isset($context['amount'])) $summary['amount'] = $context['amount'];
        if (isset($context['ip_address'])) $summary['ip'] = $context['ip_address'];
        if (isset($context['device_fingerprint'])) $summary['device_fp'] = substr($context['device_fingerprint'], 0, 8) . '...';
        
        return $summary;
    }
    
    /**
     * 获取推荐操作
     */
    private function getRecommendations($decision, $level) {
        $recommendations = [];
        
        switch ($decision) {
            case self::DECISION_CHALLENGE:
                $recommendations[] = '请进行身份二次验证';
                $recommendations[] = '检查交易信息是否正确';
                break;
                
            case self::DECISION_REVIEW:
                $recommendations[] = '交易已提交人工审核';
                $recommendations[] = '请耐心等待审核结果';
                break;
                
            case self::DECISION_REJECT:
                $recommendations[] = '交易未通过风控审核';
                $recommendations[] = '如有疑问，请联系客服';
                break;
        }
        
        return $recommendations;
    }
    
    /**
     * 获取兜底决策
     */
    private function getFallbackDecision($context) {
        // 风控系统失败时的兜底策略
        // 对于敏感操作，保守处理
        if (in_array($context['event_type'] ?? '', ['high_risk_transaction', 'large_amount'])) {
            return [
                'request_id' => $context['request_id'],
                'risk_score' => 50, // 中等风险
                'risk_level' => self::RISK_LEVEL_MEDIUM,
                'risk_level_text' => '中风险',
                'decision' => self::DECISION_REVIEW,
                'decision_text' => '人工审核',
                'rule_triggers' => [],
                'ml_score' => 0,
                'evaluation_time_ms' => 0,
                'context_summary' => $this->getContextSummary($context),
                'recommendations' => ['系统风控临时不可用，请稍后再试'],
                'fallback' => true
            ];
        }
        
        // 对于常规操作，可以允许通过
        return [
            'request_id' => $context['request_id'],
            'risk_score' => 0,
            'risk_level' => self::RISK_LEVEL_LOW,
            'risk_level_text' => '低风险',
            'decision' => self::DECISION_PASS,
            'decision_text' => '通过',
            'rule_triggers' => [],
            'ml_score' => 0,
            'evaluation_time_ms' => 0,
            'context_summary' => $this->getContextSummary($context),
            'recommendations' => [],
            'fallback' => true
        ];
    }
    
    /**
     * 记录风控日志
     */
    public function logRiskEvent($eventType, $context, $level = 'info') {
        $logData = array_merge([
            'timestamp' => time(),
            'event_type' => $eventType
        ], $context);
        
        switch ($level) {
            case 'error':
                $this->logger->error('风控事件', $logData);
                break;
            case 'warning':
                $this->logger->warning('风控事件', $logData);
                break;
            case 'debug':
                $this->logger->debug('风控事件', $logData);
                break;
            default:
                $this->logger->info('风控事件', $logData);
        }
    }
    
    /**
     * 更新用户风险画像
     */
    public function updateUserRiskProfile($userId, $riskData) {
        try {
            // 获取现有画像
            $existingProfile = $this->db->queryFirstRow(
                "SELECT * FROM user_risk_profile WHERE user_id = %s",
                $userId
            );
            
            // 合并风险数据
            $profileData = array_merge($existingProfile ?: [], $riskData, [
                'user_id' => $userId,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            
            // 插入或更新
            if ($existingProfile) {
                $this->db->update('user_risk_profile', $profileData, ['user_id' => $userId]);
            } else {
                $profileData['created_at'] = date('Y-m-d H:i:s');
                $this->db->insert('user_risk_profile', $profileData);
            }
            
            return true;
        } catch (Exception $e) {
            $this->logger->error('更新用户风险画像失败', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * 获取系统状态
     */
    public function getSystemStatus() {
        return [
            'version' => '1.0.0',
            'redis_connected' => $this->redis->ping() === '+PONG',
            'db_connected' => true, // 简化处理
            'rules_count' => $this->ruleEngine->getRulesCount(),
            'ml_enabled' => $this->config['ml_config']['enabled'],
            'device_fingerprint_enabled' => $this->config['device_fingerprint']['enabled']
        ];
    }
    
    /**
     * 获取实例（工厂方法）
     */
    public static function getSystem() {
        return self::getInstance();
    }
}

/**
 * 风控规则引擎
 */
class AntiFraudRuleEngine {
    private $rules = [];
    private $redis = null;
    private $db = null;
    
    public function __construct($rules, $redis, $db) {
        $this->rules = $rules;
        $this->redis = $redis;
        $this->db = $db;
    }
    
    /**
     * 评估规则组
     */
    public function evaluateRules($ruleType, $context) {
        if (!isset($this->rules[$ruleType])) {
            return [];
        }
        
        $results = [];
        $rules = $this->rules[$ruleType];
        
        foreach ($rules as $ruleName => $ruleConfig) {
            if (!$ruleConfig['enabled']) {
                continue;
            }
            
            // 执行规则评估
            $result = $this->evaluateRule($ruleType, $ruleName, $ruleConfig, $context);
            $results[$ruleName] = $result;
        }
        
        return $results;
    }
    
    /**
     * 评估单个规则
     */
    private function evaluateRule($ruleType, $ruleName, $ruleConfig, $context) {
        $methodName = 'evaluate' . ucfirst(str_replace('_', '', $ruleName));
        
        // 检查是否存在对应的评估方法
        if (method_exists($this, $methodName)) {
            $triggered = $this->$methodName($ruleConfig, $context);
        } else {
            // 默认检查
            $triggered = false;
        }
        
        return [
            'triggered' => $triggered,
            'score' => $triggered ? $ruleConfig['score'] : 0,
            'description' => $ruleConfig['description'],
            'type' => $ruleType,
            'name' => $ruleName
        ];
    }
    
    /**
     * 评估新用户大额交易规则
     */
    private function evaluateNewUserHighAmount($ruleConfig, $context) {
        // 检查用户是否存在
        if (!isset($context['user_id']) || !isset($context['user_profile']['registration_days'])) {
            return false;
        }
        
        $registrationDays = $context['user_profile']['registration_days'];
        $amount = $context['amount'] ?? 0;
        
        // 检查是否是新用户且交易金额超过阈值
        return ($registrationDays <= $ruleConfig['max_days']) && 
               ($amount > $ruleConfig['threshold_amount']);
    }
    
    /**
     * 评估黑名单用户规则
     */
    private function evaluateUserBlacklist($ruleConfig, $context) {
        if (!isset($context['user_id'])) {
            return false;
        }
        
        // 检查Redis黑名单
        $blacklistKey = 'blacklist:user';
        $isBlacklisted = $this->redis->sismember($blacklistKey, $context['user_id']);
        
        if (!$isBlacklisted) {
            // 检查数据库黑名单
            $blacklistRecord = $this->db->queryFirstRow(
                "SELECT * FROM user_blacklist WHERE user_id = %s AND status = 'active'",
                $context['user_id']
            );
            
            $isBlacklisted = !empty($blacklistRecord);
            
            // 同步到Redis
            if ($isBlacklisted) {
                $this->redis->sadd($blacklistKey, $context['user_id']);
                $this->redis->expire($blacklistKey, 86400); // 1天过期
            }
        }
        
        return $isBlacklisted;
    }
    
    /**
     * 评估用户信用分规则
     */
    private function evaluateUserCreditBelowThreshold($ruleConfig, $context) {
        if (!isset($context['user_id']) || !isset($context['user_profile']['credit'])) {
            return false;
        }
        
        $creditScore = $context['user_profile']['credit']['credit_score'] ?? 0;
        return $creditScore < $ruleConfig['threshold'];
    }
    
    /**
     * 评估登录失败次数规则
     */
    private function evaluateFailedLoginCount($ruleConfig, $context) {
        if (!isset($context['user_id'])) {
            return false;
        }
        
        $userId = $context['user_id'];
        $cacheKey = "failed_logins:{$userId}";
        $failedCount = $this->redis->get($cacheKey) ?? 0;
        
        return $failedCount >= $ruleConfig['threshold'];
    }
    
    /**
     * 评估近期修改账户信息规则
     */
    private function evaluateRecentAccountChange($ruleConfig, $context) {
        if (!isset($context['user_id']) || !isset($context['user_profile']['basic'])) {
            return false;
        }
        
        $profile = $context['user_profile']['basic'];
        
        // 检查是否有近期修改
        if (isset($profile['last_modified']) && $profile['last_modified']) {
            $modifiedTime = strtotime($profile['last_modified']);
            $timeDiff = time() - $modifiedTime;
            
            return $timeDiff <= $ruleConfig['timeframe'];
        }
        
        return false;
    }
    
    /**
     * 评估交易金额超限规则
     */
    private function evaluateAmountExceedsLimit($ruleConfig, $context) {
        if (!isset($context['user_id']) || !isset($context['amount'])) {
            return false;
        }
        
        $userId = $context['user_id'];
        $amount = $context['amount'];
        
        // 获取用户交易限额
        $userLimit = $this->db->queryFirstField(
            "SELECT max_transaction_amount FROM user_limits WHERE user_id = %s",
            $userId
        );
        
        // 如果没有设置限额，使用默认值
        $userLimit = $userLimit ?: 5000;
        
        return $amount > $userLimit;
    }
    
    /**
     * 评估交易频率异常规则
     */
    private function evaluateFrequencyAbnormal($ruleConfig, $context) {
        if (!isset($context['user_id'])) {
            return false;
        }
        
        $userId = $context['user_id'];
        $cacheKey = "transaction_frequency:{$userId}";
        $timeframe = $ruleConfig['timeframe'];
        
        // 记录交易时间
        $now = time();
        $this->redis->multi();
        $this->redis->zAdd($cacheKey, $now, $now);
        $this->redis->zRemRangeByScore($cacheKey, 0, $now - $timeframe);
        $this->redis->zCard($cacheKey);
        $this->redis->expire($cacheKey, $timeframe * 2);
        $results = $this->redis->exec();
        
        $transactionCount = $results[2] ?? 0;
        
        return $transactionCount > $ruleConfig['threshold'];
    }
    
    /**
     * 获取规则数量
     */
    public function getRulesCount() {
        $count = 0;
        
        foreach ($this->rules as $ruleType => $rules) {
            foreach ($rules as $ruleName => $ruleConfig) {
                if ($ruleConfig['enabled']) {
                    $count++;
                }
            }
        }
        
        return $count;
    }
}