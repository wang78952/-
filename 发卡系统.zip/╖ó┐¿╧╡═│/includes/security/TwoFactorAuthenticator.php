<?php
/**
 * 二次验证服务类
 * 实现验证码发送、验证和会话管理
 */

class TwoFactorAuthenticator {
    
    /**
     * 数据库连接
     * @var Database
     */
    private $database;
    
    /**
     * 缓存管理器
     * @var CacheManager
     */
    private $cache;
    
    /**
     * 日志记录器
     * @var Logger
     */
    private $logger;
    
    /**
     * 配置
     * @var array
     */
    private $config;
    
    /**
     * 构造函数
     * @param Database $database 数据库连接
     * @param CacheManager $cache 缓存管理器
     * @param Logger $logger 日志记录器
     */
    public function __construct($database, $cache, $logger) {
        $this->database = $database;
        $this->cache = $cache;
        $this->logger = $logger;
        
        // 加载配置
        $this->config = require 'd:\迅雷下载\发卡系统\config\two_factor.php';
    }
    
    /**
     * 判断操作是否需要二次验证
     * @param string $operation 操作类型
     * @return bool 是否需要二次验证
     */
    public function requiresVerification($operation) {
        if (!$this->config['enabled']) {
            return false;
        }
        
        // 检查操作是否在需要验证的列表中
        foreach ($this->config['risk_levels'] as $level => $operations) {
            if (in_array($operation, $operations) && 
                $this->config['verification_requirements'][$level]['require_two_factor']) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取操作的风险级别
     * @param string $operation 操作类型
     * @return string|null 风险级别
     */
    public function getRiskLevel($operation) {
        foreach ($this->config['risk_levels'] as $level => $operations) {
            if (in_array($operation, $operations)) {
                return $level;
            }
        }
        return null;
    }
    
    /**
     * 生成并发送验证码
     * @param int $userId 用户ID
     * @param string $method 验证方法 (sms/email/totp)
     * @return array 结果数组
     */
    public function sendVerificationCode($userId, $method = null) {
        // 获取用户信息
        $user = $this->database->queryOne("SELECT * FROM users WHERE id = :user_id", ['user_id' => $userId]);
        if (!$user) {
            return ['success' => false, 'error' => '用户不存在'];
        }
        
        // 确定验证方法
        $method = $method ?: $this->config['default_method'];
        
        // 检查方法是否启用
        if (!$this->config['methods'][$method]['enabled']) {
            return ['success' => false, 'error' => '该验证方法未启用'];
        }
        
        // 检查冷却时间
        $cooldownKey = "two_factor:cooldown:{$userId}:{$method}";
        $lastSendTime = $this->cache->get($cooldownKey);
        $cooldownTime = $this->config['methods'][$method]['cooldown'];
        
        if ($lastSendTime && (time() - $lastSendTime < $cooldownTime)) {
            $remainingTime = $cooldownTime - (time() - $lastSendTime);
            return ['success' => false, 'error' => "请在{$remainingTime}秒后再试", 'cooldown' => $remainingTime];
        }
        
        // 生成验证码
        $codeLength = $this->config['methods'][$method]['code_length'];
        $code = $this->generateCode($codeLength);
        
        // 计算过期时间
        $expireTime = time() + $this->config['methods'][$method]['expire_time'];
        $expireTimeStr = date('Y-m-d H:i:s', $expireTime);
        
        // 保存验证码到数据库
        $this->database->query(
            "UPDATE users SET two_factor_code = :code, two_factor_expire_time = :expire_time 
             WHERE id = :user_id",
            [
                'code' => $code,
                'expire_time' => $expireTimeStr,
                'user_id' => $userId
            ]
        );
        
        // 发送验证码
        $sendResult = false;
        switch ($method) {
            case 'sms':
                $sendResult = $this->sendSMS($user['phone'], $code);
                break;
            case 'email':
                $sendResult = $this->sendEmail($user['email'], $code);
                break;
            // TOTP需要单独处理，通常不需要发送
        }
        
        if ($sendResult) {
            // 设置冷却时间
            $this->cache->set($cooldownKey, time(), $cooldownTime);
            
            // 记录日志
            $this->logger->log(
                'two_factor', 
                "验证码已发送: 用户ID={$userId}, 方法={$method}, 过期时间={$expireTimeStr}",
                'info'
            );
            
            return ['success' => true, 'expire_time' => $expireTimeStr, 'method' => $method];
        } else {
            // 发送失败，清除验证码
            $this->database->query(
                "UPDATE users SET two_factor_code = NULL, two_factor_expire_time = NULL 
                 WHERE id = :user_id",
                ['user_id' => $userId]
            );
            
            return ['success' => false, 'error' => '验证码发送失败，请稍后重试'];
        }
    }
    
    /**
     * 验证用户提供的验证码
     * @param int $userId 用户ID
     * @param string $code 验证码
     * @return bool 验证结果
     */
    public function verifyCode($userId, $code) {
        // 获取用户验证码信息
        $result = $this->database->queryOne(
            "SELECT two_factor_code, two_factor_expire_time, failed_attempts 
             FROM users WHERE id = :user_id",
            ['user_id' => $userId]
        );
        
        if (!$result) {
            return false;
        }
        
        // 检查是否被锁定
        if ($result['failed_attempts'] >= $this->config['failure_policy']['max_attempts']) {
            $this->logger->log(
                'two_factor', 
                "账户已锁定: 用户ID={$userId}, 失败次数={$result['failed_attempts']}",
                'warning'
            );
            return false;
        }
        
        // 检查验证码是否存在和是否过期
        if (!$result['two_factor_code'] || 
            time() > strtotime($result['two_factor_expire_time'])) {
            // 增加失败次数
            $this->database->query(
                "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = :user_id",
                ['user_id' => $userId]
            );
            return false;
        }
        
        // 验证验证码
        $isValid = hash_equals($result['two_factor_code'], $code);
        
        if ($isValid) {
            // 验证成功，清除验证码和失败记录
            $this->database->query(
                "UPDATE users SET two_factor_code = NULL, two_factor_expire_time = NULL, 
                 failed_attempts = 0 WHERE id = :user_id",
                ['user_id' => $userId]
            );
            
            // 创建验证会话
            $this->createVerificationSession($userId);
            
            $this->logger->log(
                'two_factor', 
                "验证成功: 用户ID={$userId}",
                'info'
            );
            
            return true;
        } else {
            // 验证失败，增加失败次数
            $failedAttempts = $result['failed_attempts'] + 1;
            $this->database->query(
                "UPDATE users SET failed_attempts = :attempts WHERE id = :user_id",
                [
                    'attempts' => $failedAttempts,
                    'user_id' => $userId
                ]
            );
            
            // 检查是否达到最大尝试次数
            if ($failedAttempts >= $this->config['failure_policy']['max_attempts']) {
                // 设置锁定时间
                $lockoutUntil = date('Y-m-d H:i:s', time() + $this->config['failure_policy']['lockout_duration']);
                $this->database->query(
                    "UPDATE users SET locked_until = :lockout_until WHERE id = :user_id",
                    [
                        'lockout_until' => $lockoutUntil,
                        'user_id' => $userId
                    ]
                );
                
                // 触发告警
                if ($this->config['failure_policy']['alert_on_max_attempts']) {
                    $this->triggerAlert($userId, 'max_attempts_reached');
                }
            }
            
            return false;
        }
    }
    
    /**
     * 创建验证会话
     * @param int $userId 用户ID
     */
    private function createVerificationSession($userId) {
        $sessionKey = "two_factor:session:{$userId}";
        $sessionData = [
            'user_id' => $userId,
            'verified_at' => time(),
            'expires_at' => time() + $this->config['session']['validity_duration']
        ];
        
        $this->cache->set($sessionKey, $sessionData, $this->config['session']['validity_duration']);
    }
    
    /**
     * 检查用户是否已通过二次验证
     * @param int $userId 用户ID
     * @return bool 验证状态
     */
    public function isVerified($userId) {
        if (!$this->config['session']['allow_same_session']) {
            return false;
        }
        
        $sessionKey = "two_factor:session:{$userId}";
        $sessionData = $this->cache->get($sessionKey);
        
        return $sessionData && $sessionData['expires_at'] > time();
    }
    
    /**
     * 生成随机验证码
     * @param int $length 验证码长度
     * @return string 验证码
     */
    private function generateCode($length) {
        // 只使用数字
        $digits = '0123456789';
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $digits[rand(0, strlen($digits) - 1)];
        }
        return $code;
    }
    
    /**
     * 发送短信验证码
     * @param string $phone 手机号
     * @param string $code 验证码
     * @return bool 发送结果
     */
    private function sendSMS($phone, $code) {
        // 这里应该集成真实的短信发送服务
        // 现在只是模拟实现
        $this->logger->log(
            'sms', 
            "发送短信: 手机号={$phone}, 验证码={$code}",
            'info'
        );
        return true;
    }
    
    /**
     * 发送邮箱验证码
     * @param string $email 邮箱地址
     * @param string $code 验证码
     * @return bool 发送结果
     */
    private function sendEmail($email, $code) {
        // 这里应该集成真实的邮件发送服务
        // 现在只是模拟实现
        $this->logger->log(
            'email', 
            "发送邮件: 邮箱={$email}, 验证码={$code}",
            'info'
        );
        return true;
    }
    
    /**
     * 触发告警
     * @param int $userId 用户ID
     * @param string $alertType 告警类型
     */
    private function triggerAlert($userId, $alertType) {
        // 记录告警
        $this->logger->log(
            'security_alert', 
            "安全告警: 用户ID={$userId}, 类型={$alertType}",
            'error'
        );
        
        // 这里可以集成告警通知系统
    }
}