<?php
/**
 * 安全管理器
 * 提供系统级别的安全保护和防护功能
 */

class SecurityManager {
    /**
     * 安全配置
     * @var array
     */
    protected $config = [
        'xss_protection' => true,
        'csrf_protection' => true,
        'sql_injection_protection' => true,
        'input_validation' => true,
        'output_escaping' => true,
        'session_security' => true,
        'password_hashing' => true,
        'ssl_enforcement' => false,
        'rate_limiting' => true,
        'headers_security' => true,
        'ip_ban' => true,
        'error_reporting' => false,
        'file_upload_restrictions' => true,
        'logging_enabled' => true,
        'security_log_path' => '/logs/security.log',
        'max_login_attempts' => 5,
        'csrf_token_expiry' => 3600, // 1小时
        'session_timeout' => 1800, // 30分钟
        'allowed_ips' => [], // 允许的IP白名单，空数组表示允许所有
        'blocked_ips' => [], // 禁止的IP黑名单
        'csp_directives' => [
            'default-src' => "'self'",
            'script-src' => "'self' 'unsafe-inline' 'unsafe-eval'",
            'style-src' => "'self' 'unsafe-inline'",
            'img-src' => "'self' data:",
            'connect-src' => "'self'",
            'font-src' => "'self' data:",
            'object-src' => "'none'",
            'media-src' => "'self'",
            'frame-src' => "'none'",
        ],
    ];
    
    /**
     * 单例实例
     * @var SecurityManager
     */
    protected static $instance = null;
    
    /**
     * CSRF令牌存储
     * @var array
     */
    protected $csrfTokens = [];
    
    /**
     * 速率限制数据
     * @var array
     */
    protected $rateLimitData = [];
    
    /**
     * 登录尝试记录
     * @var array
     */
    protected $loginAttempts = [];
    
    /**
     * 构造函数
     * @param array $config 安全配置
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge($this->config, $config);
        
        // 初始化安全措施
        $this->initializeSecurity();
        
        // 加载安全数据
        $this->loadSecurityData();
    }
    
    /**
     * 获取单例实例
     * @param array $config 安全配置
     * @return SecurityManager
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化安全措施
     */
    protected function initializeSecurity() {
        // 注册自动加载
        spl_autoload_register([$this, 'autoloadSecurityClasses']);
        
        // 设置错误处理
        if (!$this->config['error_reporting']) {
            error_reporting(0);
            ini_set('display_errors', 0);
        }
        
        // 启用安全头
        if ($this->config['headers_security']) {
            $this->setSecurityHeaders();
        }
        
        // 强制SSL
        if ($this->config['ssl_enforcement']) {
            $this->enforceSSL();
        }
        
        // 启动会话安全
        if ($this->config['session_security']) {
            $this->secureSession();
        }
        
        // 输入清理
        if ($this->config['input_validation']) {
            $this->sanitizeGlobals();
        }
        
        // CSRF保护
        if ($this->config['csrf_protection']) {
            $this->initializeCSRFProtection();
        }
        
        // IP过滤
        if ($this->config['ip_ban']) {
            $this->checkIPRestrictions();
        }
        
        // 注册关闭处理
        register_shutdown_function([$this, 'shutdown']);
    }
    
    /**
     * 自动加载安全相关类
     * @param string $className 类名
     */
    public function autoloadSecurityClasses($className) {
        $securityClasses = [
            'XSSProtector' => '/security/XSSProtector.php',
            'CSRFProtector' => '/security/CSRFProtector.php',
            'SQLInjectionProtector' => '/security/SQLInjectionProtector.php',
            'InputValidator' => '/security/InputValidator.php',
            'PasswordManager' => '/security/PasswordManager.php',
            'RateLimiter' => '/security/RateLimiter.php',
            'IPFilter' => '/security/IPFilter.php',
            'FileUploadValidator' => '/security/FileUploadValidator.php',
        ];
        
        if (isset($securityClasses[$className])) {
            $filePath = INCLUDE_PATH . $securityClasses[$className];
            if (file_exists($filePath)) {
                require_once $filePath;
            }
        }
    }
    
    /**
     * 设置安全头
     */
    public function setSecurityHeaders() {
        // 防止点击劫持
        header('X-Frame-Options: DENY');
        
        // XSS保护
        header('X-XSS-Protection: 1; mode=block');
        
        // MIME类型嗅探
        header('X-Content-Type-Options: nosniff');
        
        // 引用策略
        header('Referrer-Policy: strict-origin-when-cross-origin');
        
        // 内容安全策略
        $cspHeader = $this->generateCSPHeader();
        if (!empty($cspHeader)) {
            header("Content-Security-Policy: $cspHeader");
        }
        
        // 期望的安全传输
        header('Expect-CT: max-age=86400, enforce');
        
        // Permissions Policy
        header("Permissions-Policy: accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()");
        
        // 清除X-Powered-By
        header_remove('X-Powered-By');
        
        // 设置安全Cookie属性
        header('Set-Cookie: PHPSESSID=' . session_id() . '; HttpOnly; Secure; SameSite=Strict; Path=/');
    }
    
    /**
     * 生成CSP头
     * @return string CSP头部内容
     */
    protected function generateCSPHeader() {
        $directives = $this->config['csp_directives'];
        $cspParts = [];
        
        foreach ($directives as $directive => $value) {
            $cspParts[] = "$directive $value";
        }
        
        return implode('; ', $cspParts);
    }
    
    /**
     * 强制SSL连接
     */
    public function enforceSSL() {
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            return; // 已经是HTTPS
        }
        
        // 构建HTTPS URL并重定向
        $httpsUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        header('Location: ' . $httpsUrl, true, 301);
        exit();
    }
    
    /**
     * 安全会话设置
     */
    public function secureSession() {
        // 确保会话已启动
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // 设置会话Cookie参数
        session_set_cookie_params([
            'lifetime' => $this->config['session_timeout'],
            'path' => '/',
            'domain' => '',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
        
        // 生成新的会话ID
        session_regenerate_id(true);
        
        // 设置会话超时
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $this->config['session_timeout'])) {
            $this->destroySession();
        }
        
        $_SESSION['last_activity'] = time();
        $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $_SESSION['ip_address'] = $this->getClientIP();
    }
    
    /**
     * 销毁会话
     */
    public function destroySession() {
        session_unset();
        session_destroy();
        setcookie(session_name(), '', time() - 3600, '/', '', true, true);
    }
    
    /**
     * 初始化CSRF保护
     */
    protected function initializeCSRFProtection() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // 生成CSRF令牌
        if (empty($_SESSION['csrf_token'])) {
            $this->generateCSRFToken();
        }
        
        // 检查CSRF令牌是否过期
        if (isset($_SESSION['csrf_token_time']) && 
            (time() - $_SESSION['csrf_token_time'] > $this->config['csrf_token_expiry'])) {
            $this->generateCSRFToken();
        }
        
        // 验证POST请求中的CSRF令牌
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$this->verifyCSRFToken()) {
            $this->logSecurityEvent('CSRF令牌验证失败', $_SERVER['REQUEST_URI'], 403);
            $this->denyAccess('安全验证失败，请刷新页面后重试');
        }
    }
    
    /**
     * 生成CSRF令牌
     * @return string CSRF令牌
     */
    public function generateCSRFToken() {
        $token = bin2hex(random_bytes(32));
        $_SESSION['csrf_token'] = $token;
        $_SESSION['csrf_token_time'] = time();
        return $token;
    }
    
    /**
     * 获取CSRF令牌
     * @return string CSRF令牌
     */
    public function getCSRFToken() {
        if (empty($_SESSION['csrf_token'])) {
            return $this->generateCSRFToken();
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * 验证CSRF令牌
     * @param string $token 可选的令牌值，默认从POST或Header获取
     * @return bool 验证结果
     */
    public function verifyCSRFToken($token = null) {
        // 获取令牌来源
        if ($token === null) {
            $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_GET['csrf_token'] ?? '';
        }
        
        // 获取会话中的令牌
        $sessionToken = $_SESSION['csrf_token'] ?? '';
        
        // 比较令牌
        if (hash_equals($sessionToken, $token)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 生成CSRF令牌隐藏字段
     * @return string HTML隐藏字段
     */
    public function getCSRFTokenField() {
        $token = $this->getCSRFToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '" />';
    }
    
    /**
     * 净化全局输入变量
     */
    public function sanitizeGlobals() {
        // 净化GET变量
        if (!empty($_GET)) {
            $_GET = $this->sanitizeInput($_GET);
        }
        
        // 净化POST变量
        if (!empty($_POST)) {
            $_POST = $this->sanitizeInput($_POST);
        }
        
        // 净化COOKIE变量
        if (!empty($_COOKIE)) {
            $_COOKIE = $this->sanitizeInput($_COOKIE);
        }
        
        // 净化REQUEST变量
        if (!empty($_REQUEST)) {
            $_REQUEST = $this->sanitizeInput($_REQUEST);
        }
        
        // 净化SERVER变量中的关键部分
        if (isset($_SERVER['PHP_SELF'])) {
            $_SERVER['PHP_SELF'] = htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8');
        }
        
        if (isset($_SERVER['HTTP_REFERER'])) {
            $_SERVER['HTTP_REFERER'] = htmlspecialchars($_SERVER['HTTP_REFERER'], ENT_QUOTES, 'UTF-8');
        }
    }
    
    /**
     * 递归净化输入数据
     * @param mixed $input 输入数据
     * @return mixed 净化后的数据
     */
    public function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        } else if (is_string($input)) {
            // 移除NULL字节
            $input = str_replace("\0", '', $input);
            
            // 移除控制字符
            $input = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $input);
            
            // 防止XSS
            $input = $this->sanitizeXSS($input);
            
            return $input;
        }
        return $input;
    }
    
    /**
     * 防止XSS攻击的输入净化
     * @param string $input 输入字符串
     * @return string 净化后的字符串
     */
    public function sanitizeXSS($input) {
        // 基本HTML实体编码
        $clean = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // 移除潜在的危险标签
        $clean = preg_replace('/<script[^>]*>.*?<\/script>/is', '', $clean);
        $clean = preg_replace('/<iframe[^>]*>.*?<\/iframe>/is', '', $clean);
        $clean = preg_replace('/<object[^>]*>.*?<\/object>/is', '', $clean);
        $clean = preg_replace('/<embed[^>]*>/i', '', $clean);
        $clean = preg_replace('/<link[^>]*>/i', '', $clean);
        $clean = preg_replace('/<meta[^>]*>/i', '', $clean);
        $clean = preg_replace('/javascript:/i', '', $clean);
        $clean = preg_replace('/vbscript:/i', '', $clean);
        $clean = preg_replace('/on\w+\s*=/i', '', $clean);
        
        return $clean;
    }
    
    /**
     * 净化SQL查询字符串
     * @param string $query SQL查询
     * @return string 净化后的查询
     */
    public function sanitizeSQL($query) {
        // 基本的SQL注入防护
        $query = str_replace("'", "''", $query);
        $query = str_replace(";", ";", $query);
        $query = str_replace("--", "--", $query);
        $query = str_replace("xp_", "xp_", $query);
        $query = str_replace("sp_", "sp_", $query);
        $query = str_replace("EXEC", "EXEC", $query);
        $query = str_replace("EXECUTE", "EXECUTE", $query);
        $query = str_replace("UNION", "UNION", $query);
        $query = str_replace("SELECT", "SELECT", $query);
        $query = str_replace("INSERT", "INSERT", $query);
        $query = str_replace("UPDATE", "UPDATE", $query);
        $query = str_replace("DELETE", "DELETE", $query);
        
        return $query;
    }
    
    /**
     * 验证和过滤用户输入
     * @param mixed $input 输入数据
     * @param string $type 验证类型
     * @param array $options 验证选项
     * @return array [bool, mixed] [是否有效, 过滤后的值]
     */
    public function validateInput($input, $type = 'string', $options = []) {
        $valid = false;
        $filtered = $input;
        
        switch ($type) {
            case 'string':
                $minLength = $options['min_length'] ?? 0;
                $maxLength = $options['max_length'] ?? PHP_INT_MAX;
                $pattern = $options['pattern'] ?? null;
                
                $filtered = trim($filtered);
                $length = strlen($filtered);
                
                $valid = ($length >= $minLength && $length <= $maxLength);
                
                if ($valid && $pattern !== null) {
                    $valid = preg_match($pattern, $filtered) === 1;
                }
                break;
                
            case 'email':
                $valid = filter_var($filtered, FILTER_VALIDATE_EMAIL) !== false;
                break;
                
            case 'url':
                $valid = filter_var($filtered, FILTER_VALIDATE_URL) !== false;
                break;
                
            case 'int':
                $min = $options['min'] ?? PHP_INT_MIN;
                $max = $options['max'] ?? PHP_INT_MAX;
                
                $filtered = filter_var($filtered, FILTER_VALIDATE_INT, [
                    'options' => ['min_range' => $min, 'max_range' => $max]
                ]);
                
                $valid = $filtered !== false;
                break;
                
            case 'float':
                $min = $options['min'] ?? -PHP_FLOAT_MAX;
                $max = $options['max'] ?? PHP_FLOAT_MAX;
                
                $filtered = filter_var($filtered, FILTER_VALIDATE_FLOAT);
                
                $valid = ($filtered !== false && $filtered >= $min && $filtered <= $max);
                break;
                
            case 'bool':
                $filtered = filter_var($filtered, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                $valid = $filtered !== null;
                break;
                
            case 'ip':
                $flags = $options['flags'] ?? FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6;
                $valid = filter_var($filtered, FILTER_VALIDATE_IP, ['flags' => $flags]) !== false;
                break;
                
            case 'date':
                $format = $options['format'] ?? 'Y-m-d';
                $dateObj = DateTime::createFromFormat($format, $filtered);
                $valid = $dateObj !== false && $dateObj->format($format) === $filtered;
                break;
                
            case 'alphanumeric':
                $valid = ctype_alnum($filtered) || preg_match('/^[a-zA-Z0-9_]+$/', $filtered);
                break;
                
            case 'password':
                // 密码强度验证
                $minLength = $options['min_length'] ?? 8;
                $requireUppercase = $options['require_uppercase'] ?? true;
                $requireLowercase = $options['require_lowercase'] ?? true;
                $requireNumber = $options['require_number'] ?? true;
                $requireSpecial = $options['require_special'] ?? true;
                
                $valid = strlen($filtered) >= $minLength;
                
                if ($valid && $requireUppercase) {
                    $valid = preg_match('/[A-Z]/', $filtered) === 1;
                }
                
                if ($valid && $requireLowercase) {
                    $valid = preg_match('/[a-z]/', $filtered) === 1;
                }
                
                if ($valid && $requireNumber) {
                    $valid = preg_match('/[0-9]/', $filtered) === 1;
                }
                
                if ($valid && $requireSpecial) {
                    $valid = preg_match('/[^a-zA-Z0-9]/', $filtered) === 1;
                }
                break;
                
            default:
                // 自定义验证
                if (isset($options['custom_validator']) && is_callable($options['custom_validator'])) {
                    $customResult = call_user_func($options['custom_validator'], $filtered);
                    $valid = is_bool($customResult) ? $customResult : false;
                }
                break;
        }
        
        return [$valid, $filtered];
    }
    
    /**
     * 检查IP限制
     */
    public function checkIPRestrictions() {
        $clientIP = $this->getClientIP();
        
        // 检查黑名单
        if (!empty($this->config['blocked_ips']) && in_array($clientIP, $this->config['blocked_ips'])) {
            $this->logSecurityEvent('IP在黑名单中', $clientIP, 403);
            $this->denyAccess('您的IP地址已被限制访问');
        }
        
        // 检查白名单（如果非空）
        if (!empty($this->config['allowed_ips']) && !in_array($clientIP, $this->config['allowed_ips'])) {
            $this->logSecurityEvent('IP不在白名单中', $clientIP, 403);
            $this->denyAccess('您的IP地址未被授权访问');
        }
        
        // 检查速率限制
        if ($this->config['rate_limiting'] && !$this->checkRateLimit()) {
            $this->logSecurityEvent('速率限制触发', $clientIP, 429);
            $this->denyAccess('请求过于频繁，请稍后再试', 429);
        }
    }
    
    /**
     * 获取客户端真实IP
     * @return string IP地址
     */
    public function getClientIP() {
        $ipHeaders = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($ipHeaders as $header) {
            if (isset($_SERVER[$header])) {
                // 处理多个IP（X-Forwarded-For可能包含多个IP）
                if ($header === 'HTTP_X_FORWARDED_FOR') {
                    $ips = explode(',', $_SERVER[$header]);
                    $ip = trim($ips[0]);
                } else {
                    $ip = trim($_SERVER[$header]);
                }
                
                // 验证IP格式
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '127.0.0.1'; // 默认值
    }
    
    /**
     * 检查速率限制
     * @param string $action 操作类型
     * @param int $limit 限制次数
     * @param int $period 时间周期（秒）
     * @return bool 是否允许请求
     */
    public function checkRateLimit($action = 'global', $limit = 60, $period = 60) {
        $clientIP = $this->getClientIP();
        $key = "{$clientIP}:{$action}";
        $currentTime = time();
        
        // 清理过期记录
        $this->cleanupRateLimitData($currentTime);
        
        // 获取当前计数
        if (!isset($this->rateLimitData[$key])) {
            $this->rateLimitData[$key] = [
                'count' => 0,
                'timestamp' => $currentTime
            ];
        }
        
        $entry = $this->rateLimitData[$key];
        
        // 检查是否在时间窗口内
        if ($currentTime - $entry['timestamp'] \gt $period) {
            // 重置计数
            $entry['count'] = 1;
            $entry['timestamp'] = $currentTime;
        } else {
            // 增加计数
            $entry['count']++;
        }
        
        // 更新数据
        $this->rateLimitData[$key] = $entry;
        
        // 检查是否超过限制
        if ($entry['count'] \gt $limit) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 清理过期的速率限制数据
     * @param int $currentTime 当前时间戳
     */
    protected function cleanupRateLimitData($currentTime) {
        foreach ($this->rateLimitData as $key => $entry) {
            // 清理超过1小时的数据
            if ($currentTime - $entry['timestamp'] \gt 3600) {
                unset($this->rateLimitData[$key]);
            }
        }
    }
    
    /**
     * 处理登录尝试
     * @param string $username 用户名
     * @param bool $success 是否成功
     * @return bool 是否允许继续尝试
     */
    public function handleLoginAttempt($username, $success) {
        $clientIP = $this->getClientIP();
        $key = "{$clientIP}:{$username}";
        $maxAttempts = $this->config['max_login_attempts'];
        
        if (!isset($this->loginAttempts[$key])) {
            $this->loginAttempts[$key] = [
                'attempts' => 0,
                'last_attempt' => time(),
                'blocked_until' => 0
            ];
        }
        
        $entry = $this->loginAttempts[$key];
        
        // 检查是否被阻止
        if ($entry['blocked_until'] \gt time()) {
            $this->logSecurityEvent('登录尝试被阻止', "用户名: {$username}, IP: {$clientIP}", 403);
            return false;
        }
        
        if ($success) {
            // 登录成功，重置计数
            unset($this->loginAttempts[$key]);
            $this->logSecurityEvent('登录成功', "用户名: {$username}, IP: {$clientIP}", 200);
            return true;
        } else {
            // 登录失败，增加计数
            $entry['attempts']++;
            $entry['last_attempt'] = time();
            
            // 检查是否超过最大尝试次数
            if ($entry['attempts'] \geq $maxAttempts) {
                // 阻止15分钟
                $entry['blocked_until'] = time() + 900;
                $this->logSecurityEvent('登录尝试过多，账户临时锁定', "用户名: {$username}, IP: {$clientIP}", 403);
                $this->loginAttempts[$key] = $entry;
                return false;
            }
            
            $this->loginAttempts[$key] = $entry;
            $this->logSecurityEvent('登录失败', "用户名: {$username}, IP: {$clientIP}", 401);
            return true;
        }
    }
    
    /**
     * 哈希密码
     * @param string $password 原始密码
     * @return string 哈希后的密码
     */
    public function hashPassword($password) {
        // 使用PHP的password_hash函数
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 2
        ]);
    }
    
    /**
     * 验证密码
     * @param string $password 原始密码
     * @param string $hash 哈希值
     * @return bool 验证结果
     */
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * 检查密码是否需要重新哈希（算法或参数更新）
     * @param string $hash 当前哈希值
     * @return bool 是否需要重新哈希
     */
    public function needsRehashPassword($hash) {
        return password_needs_rehash($hash, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 2
        ]);
    }
    
    /**
     * 验证文件上传
     * @param array $file $_FILES数组中的文件项
     * @param array $options 验证选项
     * @return array [bool, string] [是否有效, 错误消息或空字符串]
     */
    public function validateFileUpload($file, $options = []) {
        // 默认选项
        $defaultOptions = [
            'max_size' => 5 * 1024 * 1024, // 5MB
            'allowed_types' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'],
            'allowed_mime_types' => ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            'check_mime_type' => true,
            'check_extension' => true,
            'sanitize_filename' => true
        ];
        
        $options = array_merge($defaultOptions, $options);
        
        // 检查文件是否上传成功
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errorMessages = [
                UPLOAD_ERR_INI_SIZE => '文件大小超过了服务器限制',
                UPLOAD_ERR_FORM_SIZE => '文件大小超过了表单限制',
                UPLOAD_ERR_PARTIAL => '文件只上传了部分',
                UPLOAD_ERR_NO_FILE => '没有文件被上传',
                UPLOAD_ERR_NO_TMP_DIR => '缺少临时文件夹',
                UPLOAD_ERR_CANT_WRITE => '无法写入文件到磁盘',
                UPLOAD_ERR_EXTENSION => '文件上传被PHP扩展阻止'
            ];
            
            $error = $file['error'];
            return [false, $errorMessages[$error] ?? '文件上传失败'];
        }
        
        // 检查文件大小
        if ($file['size'] > $options['max_size']) {
            return [false, '文件大小超过了允许的最大值'];
        }
        
        // 获取文件信息
        $fileInfo = pathinfo($file['name']);
        $extension = strtolower($fileInfo['extension'] ?? '');
        
        // 检查扩展名
        if ($options['check_extension'] && !in_array($extension, $options['allowed_types'])) {
            return [false, '不支持的文件类型'];
        }
        
        // 检查MIME类型
        if ($options['check_mime_type']) {
            // 获取真实MIME类型
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            if (!in_array($mime, $options['allowed_mime_types'])) {
                return [false, '无效的文件类型'];
            }
        }
        
        // 检查是否是真实文件（防止路径遍历攻击）
        if (!is_uploaded_file($file['tmp_name'])) {
            $this->logSecurityEvent('可疑文件上传尝试', $file['name'], 403);
            return [false, '安全检查失败'];
        }
        
        // 检查文件内容（简单的恶意代码检测）
        $content = file_get_contents($file['tmp_name']);
        $suspiciousPatterns = [
            '/\beval\s*\(/i',
            '/\bexec\s*\(/i',
            '/\bshell_exec\s*\(/i',
            '/\bpassthru\s*\(/i',
            '/\bsystem\s*\(/i',
            '/\b\$\$\w+/i',
            '/<\?php/i',
            '/<%/i',
            '/\bon\w+\s*=/i',
            '/javascript:/i'
        ];
        
        foreach ($suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                $this->logSecurityEvent('检测到可疑文件内容', $file['name'], 403);
                return [false, '文件内容包含不安全的代码'];
            }
        }
        
        return [true, ''];
    }
    
    /**
     * 净化文件名
     * @param string $filename 原始文件名
     * @return string 净化后的文件名
     */
    public function sanitizeFilename($filename) {
        // 移除路径信息
        $filename = basename($filename);
        
        // 移除特殊字符
        $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $filename);
        
        // 添加时间戳防止覆盖
        $fileInfo = pathinfo($filename);
        $name = $fileInfo['filename'];
        $extension = $fileInfo['extension'] ?? '';
        
        if (!empty($extension)) {
            return "{$name}_{time()}.{$extension}";
        } else {
            return "{$name}_{time()}";
        }
    }
    
    /**
     * 拒绝访问并显示错误页面
     * @param string $message 错误消息
     * @param int $statusCode HTTP状态码
     */
    public function denyAccess($message = '访问被拒绝', $statusCode = 403) {
        // 设置HTTP状态码
        http_response_code($statusCode);
        
        // 输出错误页面
        echo "<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>访问拒绝</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding: 50px;
                    color: #333;
                    background-color: #f8f9fa;
                }
                .error-container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 30px;
                    background-color: #fff;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                h1 {
                    color: #dc3545;
                    font-size: 2.5rem;
                    margin-bottom: 20px;
                }
                p {
                    font-size: 1.1rem;
                    line-height: 1.6;
                }
                .btn {
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: #007bff;
                    color: white;
                    text-decoration: none;
                    border-radius: 4px;
                    margin-top: 20px;
                    transition: background-color 0.3s;
                }
                .btn:hover {
                    background-color: #0056b3;
                }
            </style>
        </head>
        <body>
            <div class='error-container'>
                <h1>访问拒绝</h1>
                <p>{$message}</p>
                <a href='/' class='btn'>返回首页</a>
            </div>
        </body>
        </html>";
        
        exit();
    }
    
    /**
     * 记录安全事件
     * @param string $event 事件描述
     * @param string $details 详细信息
     * @param int $statusCode HTTP状态码
     */
    public function logSecurityEvent($event, $details = '', $statusCode = 403) {
        if (!$this->config['logging_enabled']) {
            return;
        }
        
        // 创建日志消息
        $timestamp = date('Y-m-d H:i:s');
        $clientIP = $this->getClientIP();
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $requestUri = $_SERVER['REQUEST_URI'] ?? 'Unknown';
        $username = $_SESSION['username'] ?? 'Guest';
        
        $logMessage = "[{$timestamp}] [{$statusCode}] [{$event}] IP: {$clientIP} | User: {$username} | URL: {$requestUri} | UA: {$userAgent} | Details: {$details}\n";
        
        // 写入日志文件
        $logPath = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . $this->config['security_log_path'];
        
        // 确保日志目录存在
        $logDir = dirname($logPath);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // 写入日志
        error_log($logMessage, 3, $logPath);
        
        // 同时输出到PHP错误日志（用于调试）
        error_log("[SECURITY] {$logMessage}");
    }
    
    /**
     * 加载安全数据
     */
    protected function loadSecurityData() {
        // 在实际应用中，这里应该从数据库或缓存加载数据
        // 例如：IP黑名单、速率限制数据、登录尝试记录等
        // 为了演示，这里使用内存存储
    }
    
    /**
     * 保存安全数据
     */
    protected function saveSecurityData() {
        // 在实际应用中，这里应该将数据保存到数据库或缓存
    }
    
    /**
     * 关闭处理
     */
    public function shutdown() {
        // 保存安全数据
        $this->saveSecurityData();
        
        // 检查是否有致命错误
        $error = error_get_last();
        if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
            $this->logSecurityEvent('致命错误', "{$error['message']} in {$error['file']} on line {$error['line']}", 500);
        }
    }
    
    /**
     * 获取安全统计信息
     * @return array 安全统计
     */
    public function getSecurityStats() {
        return [
            'active_sessions' => count($_SESSION) > 0 ? 1 : 0,
            'rate_limited_ips' => count($this->rateLimitData),
            'blocked_login_attempts' => count($this->loginAttempts),
            'csrf_tokens' => count($this->csrfTokens),
            'security_features' => [
                'xss_protection' => $this->config['xss_protection'],
                'csrf_protection' => $this->config['csrf_protection'],
                'sql_injection_protection' => $this->config['sql_injection_protection'],
                'ssl_enforcement' => $this->config['ssl_enforcement'],
                'rate_limiting' => $this->config['rate_limiting'],
                'headers_security' => $this->config['headers_security']
            ]
        ];
    }
    
    /**
     * 执行安全扫描
     * @return array 扫描结果
     */
    public function runSecurityScan() {
        $results = [
            'php_version' => PHP_VERSION,
            'php_settings' => [],
            'file_permissions' => [],
            'suspicious_files' => [],
            'security_score' => 0
        ];
        
        // 检查PHP设置
        $phpSettings = [
            'display_errors' => ini_get('display_errors'),
            'error_reporting' => ini_get('error_reporting'),
            'expose_php' => ini_get('expose_php'),
            'allow_url_fopen' => ini_get('allow_url_fopen'),
            'allow_url_include' => ini_get('allow_url_include'),
            'file_uploads' => ini_get('file_uploads'),
            'max_file_uploads' => ini_get('max_file_uploads'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size')
        ];
        $results['php_settings'] = $phpSettings;
        
        // 检查关键文件权限
        $criticalFiles = [
            '/config/database.php',
            '/includes/config.php',
            '/.htaccess'
        ];
        
        foreach ($criticalFiles as $file) {
            $fullPath = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . $file;
            if (file_exists($fullPath)) {
                $permissions = substr(sprintf('%o', fileperms($fullPath)), -4);
                $results['file_permissions'][] = [
                    'file' => $file,
                    'permissions' => $permissions,
                    'secure' => $permissions <= 644
                ];
            }
        }
        
        // 简单的安全评分
        $score = 100;
        
        if ($phpSettings['display_errors'] == 1) $score -= 10;
        if ($phpSettings['expose_php'] == 1) $score -= 5;
        if ($phpSettings['allow_url_include'] == 1) $score -= 20;
        if ($phpSettings['allow_url_fopen'] == 1) $score -= 5;
        
        foreach ($results['file_permissions'] as $perm) {
            if (!$perm['secure']) $score -= 15;
        }
        
        $results['security_score'] = max(0, $score);
        
        // 记录扫描结果
        $this->logSecurityEvent('安全扫描完成', "安全评分: {$results['security_score']}/100", 200);
        
        return $results;
    }
    
    /**
     * 生成安全报告
     * @return array 安全报告
     */
    public function generateSecurityReport() {
        $report = [
            'generated_at' => date('Y-m-d H:i:s'),
            'server_info' => [
                'php_version' => PHP_VERSION,
                'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'server_os' => PHP_OS
            ],
            'security_settings' => $this->config,
            'security_stats' => $this->getSecurityStats(),
            'scan_results' => $this->runSecurityScan(),
            'recommendations' => $this->generateSecurityRecommendations()
        ];
        
        return $report;
    }
    
    /**
     * 生成安全建议
     * @return array 安全建议列表
     */
    protected function generateSecurityRecommendations() {
        $recommendations = [];
        
        // 检查PHP设置
        if (ini_get('display_errors') == 1) {
            $recommendations[] = '禁用 display_errors 以防止敏感信息泄露';
        }
        
        if (ini_get('expose_php') == 1) {
            $recommendations[] = '禁用 expose_php 以隐藏PHP版本信息';
        }
        
        if (ini_get('allow_url_include') == 1) {
            $recommendations[] = '立即禁用 allow_url_include 以防止远程代码执行';
        }
        
        // 检查安全配置
        if (!$this->config['ssl_enforcement']) {
            $recommendations[] = '启用SSL强制以加密所有通信';
        }
        
        if (!$this->config['headers_security']) {
            $recommendations[] = '启用安全头以增强安全性';
        }
        
        if ($this->config['max_login_attempts'] > 5) {
            $recommendations[] = '减少最大登录尝试次数以防止暴力破解';
        }
        
        return $recommendations;
    }
    
    /**
     * 获取安全配置
     * @return array 配置数组
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 更新安全配置
     * @param array $newConfig 新配置
     */
    public function updateConfig($newConfig) {
        $this->config = array_merge($this->config, $newConfig);
        // 重新应用安全设置
        if ($this->config['headers_security']) {
            $this->setSecurityHeaders();
        }
    }
    
    /**
     * 验证系统安全状态
     * @return bool 安全状态
     */
    public function isSecure() {
        // 执行一系列安全检查
        $isSecure = true;
        
        // 检查关键安全设置
        if (ini_get('allow_url_include') == 1) {
            $isSecure = false;
        }
        
        if (ini_get('display_errors') == 1 && $this->config['error_reporting'] === false) {
            $isSecure = false;
        }
        
        // 检查是否启用了关键安全功能
        $criticalFeatures = ['xss_protection', 'csrf_protection', 'sql_injection_protection', 'input_validation'];
        foreach ($criticalFeatures as $feature) {
            if ($this->config[$feature] === false) {
                $isSecure = false;
            }
        }
        
        return $isSecure;
    }
    
    /**
     * 导出安全日志
     * @param string $format 格式（csv, json）
     * @param string $startDate 开始日期
     * @param string $endDate 结束日期
     * @return string 导出的日志内容
     */
    public function exportSecurityLogs($format = 'csv', $startDate = null, $endDate = null) {
        $logPath = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . $this->config['security_log_path'];
        
        if (!file_exists($logPath)) {
            return '';
        }
        
        // 读取日志文件
        $lines = file($logPath, FILE_IGNORE_NEW_LINES);
        $filteredLogs = [];
        
        // 过滤日期范围
        foreach ($lines as $line) {
            // 解析日期
            if (preg_match('/\[(\d{4}-\d{2}-\d{2})/', $line, $matches)) {
                $logDate = $matches[1];
                
                if ($startDate && $logDate < $startDate) continue;
                if ($endDate && $logDate > $endDate) continue;
                
                $filteredLogs[] = $line;
            }
        }
        
        // 格式转换
        if ($format === 'json') {
            $logsArray = [];
            foreach ($filteredLogs as $line) {
                // 简单的日志解析
                $logsArray[] = ['log' => $line];
            }
            return json_encode($logsArray, JSON_PRETTY_PRINT);
        } else {
            // CSV格式
            $csv = "Date,Time,Status,Event,IP,User,URL,Details\n";
            foreach ($filteredLogs as $line) {
                // 这里应该有更复杂的解析逻辑
                $csv .= str_replace(['[', ']', ' | '], ',', $line) . "\n";
            }
            return $csv;
        }
    }
    
    /**
     * 净化HTML内容（用于富文本）
     * @param string $html HTML内容
     * @param array $allowedTags 允许的标签
     * @return string 净化后的HTML
     */
    public function sanitizeHTML($html, $allowedTags = []) {
        // 默认允许的标签
        $defaultAllowed = [
            'p', 'br', 'strong', 'em', 'u', 's', 'blockquote', 'ul', 'ol', 'li',
            'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'a', 'img', 'table', 'thead', 'tbody',
            'tr', 'td', 'th'
        ];
        
        $allowedTags = !empty($allowedTags) ? $allowedTags : $defaultAllowed;
        
        // 使用HTML Purifier（如果可用）
        if (class_exists('HTMLPurifier')) {
            $config = HTMLPurifier_Config::createDefault();
            $config->set('HTML.Allowed', implode(',', $allowedTags));
            $config->set('HTML.TargetBlank', true);
            $config->set('Attr.AllowedFrameTargets', ['_blank']);
            $config->set('URI.AllowedSchemes', ['http' => true, 'https' => true, 'mailto' => true, 'tel' => true]);
            
            $purifier = new HTMLPurifier($config);
            return $purifier->purify($html);
        } else {
            // 简单的标签过滤（不推荐，仅作为后备）
            $allowedTagsPattern = implode('|', $allowedTags);
            $pattern = "/<(?!\/?(?:{$allowedTagsPattern})\b)[^>]*>/i";
            return preg_replace($pattern, '', $html);
        }
    }
}

// 初始化安全管理器的便捷函数
function initializeSecurity($config = []) {
    return SecurityManager::getInstance($config);
}

// 安全函数助手
function secure_input($input) {
    $security = SecurityManager::getInstance();
    return $security->sanitizeInput($input);
}

function secure_output($output) {
    return htmlspecialchars($output, ENT_QUOTES, 'UTF-8');
}

function generate_csrf_token() {
    $security = SecurityManager::getInstance();
    return $security->getCSRFToken();
}

function csrf_field() {
    $security = SecurityManager::getInstance();
    return $security->getCSRFTokenField();
}

function verify_csrf_token($token = null) {
    $security = SecurityManager::getInstance();
    return $security->verifyCSRFToken($token);
}

function hash_password($password) {
    $security = SecurityManager::getInstance();
    return $security->hashPassword($password);
}

function verify_password($password, $hash) {
    $security = SecurityManager::getInstance();
    return $security->verifyPassword($password, $hash);
}

function check_rate_limit($action = 'global', $limit = 60, $period = 60) {
    $security = SecurityManager::getInstance();
    return $security->checkRateLimit($action, $limit, $period);
}

function log_security_event($event, $details = '', $statusCode = 403) {
    $security = SecurityManager::getInstance();
    return $security->logSecurityEvent($event, $details, $statusCode);
}

function validate_input($input, $type = 'string', $options = []) {
    $security = SecurityManager::getInstance();
    return $security->validateInput($input, $type, $options);
}

function sanitize_file_upload($file, $options = []) {
    $security = SecurityManager::getInstance();
    return $security->validateFileUpload($file, $options);
}

function sanitize_filename($filename) {
    $security = SecurityManager::getInstance();
    return $security->sanitizeFilename($filename);
}

function get_client_ip() {
    $security = SecurityManager::getInstance();
    return $security->getClientIP();
}

function deny_access($message = '访问被拒绝', $statusCode = 403) {
    $security = SecurityManager::getInstance();
    $security->denyAccess($message, $statusCode);
}