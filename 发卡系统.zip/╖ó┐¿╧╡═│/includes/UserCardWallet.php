<?php
require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/CardManager.php';
require_once __DIR__ . '/NotificationManager.php';

/**
 * 用户卡包管理器
 * 负责用户卡密的多渠道同步存档和管理
 */
class UserCardWallet extends BaseService {
    /**
     * @var CardManager
     */
    protected $cardManager;

    /**
     * @var NotificationManager
     */
    protected $notificationManager;

    /**
     * @var Logger
     */
    protected $logger;
    
    public function __construct($cardManager = null, $notificationManager = null, $logger = null) {
        parent::__construct();
        $this->cardManager = $cardManager ?: new CardManager();
        $this->notificationManager = $notificationManager ?: new NotificationManager();
        $this->logger = $logger;
    }
    
    /**
     * 添加卡密到用户卡包
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param array $cards 卡密列表
     * @return bool
     */
    public function addCardsToWallet($userId, $orderId, $cards) {
        try {
            $this->database->beginTransaction();
            
            foreach ($cards as $card) {
                // 检查是否已存在
                $exists = $this->checkCardExists($userId, $card['id']);
                if ($exists) {
                    continue;
                }
                
                // 添加到卡包
                $walletData = array(
                    'user_id' => $userId,
                    'order_id' => $orderId,
                    'card_id' => $card['id'],
                    'card_code' => $card['card_code'],
                    'card_secret' => $card['card_secret'],
                    'product_name' => $card['product_name'],
                    'product_image' => isset($card['product_image']) ? $card['product_image'] : '',
                    'status' => 'unused',
                    'added_at' => date('Y-m-d H:i:s'),
                    'expires_at' => $card['expires_at']
                );
                
                $walletId = $this->insertWalletCard($walletData);
                if (!$walletId) {
                    throw new Exception("Failed to add card to wallet");
                }
                
                // 同步到其他渠道
                $this->syncToOtherChannels($userId, $walletId, $card);
            }
            
            $this->database->commit();
            
            $this->logger->info("Cards added to wallet successfully", array(
                'user_id' => $userId,
                'order_id' => $orderId,
                'card_count' => count($cards)
            ));
            
            return true;
            
        } catch (Exception $e) {
            $this->database->rollBack();
            $this->logger->error("Failed to add cards to wallet", array(
                'user_id' => $userId,
                'order_id' => $orderId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取用户卡包列表
     * @param int $userId 用户ID
     * @param array $filters 筛选条件
     * @param int $page 页码
     * @param int $limit 每页数量
     * @return array
     */
    public function getUserWalletCards($userId, $filters = array(), $page = 1, $limit = 20) {
        try {
            $offset = ($page - 1) * $limit;
            $where = array("user_id = ?");
            $params = array($userId);
            
            if (!empty($filters['status'])) {
                $where[] = "status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['category'])) {
                $where[] = "category = ?";
                $params[] = $filters['category'];
            }
            
            if (!empty($filters['keyword'])) {
                $where[] = "(product_name LIKE ? OR card_code LIKE ?)";
                $params[] = "%{$filters['keyword']}%";
                $params[] = "%{$filters['keyword']}%";
            }
            
            $whereClause = implode(' AND ', $where);
            
            // 获取总数
            $countSql = "SELECT COUNT(*) as total FROM user_wallet_cards WHERE {$whereClause}";
            $stmt = $this->database->prepare($countSql);
            $stmt->execute($params);
            $total = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            // 获取列表
            $sql = "SELECT * FROM user_wallet_cards 
                    WHERE {$whereClause} 
                    ORDER BY added_at DESC 
                    LIMIT {$limit} OFFSET {$offset}";
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 处理卡密状态
            foreach ($cards as &$card) {
                $card['status_text'] = $this->getStatusText($card['status']);
                $card['is_expired'] = $this->isCardExpired($card['expires_at']);
                $card['days_until_expiry'] = $this->getDaysUntilExpiry($card['expires_at']);
                
                // 隐藏部分卡密
                $card['masked_card_code'] = $this->maskCardCode($card['card_code']);
                $card['masked_card_secret'] = $this->maskCardSecret($card['card_secret']);
            }
            
            return array(
                'cards' => $cards,
                'pagination' => array(
                    'current_page' => $page,
                    'per_page' => $limit,
                    'total' => $total,
                    'total_pages' => ceil($total / $limit)
                )
            );
            
        } catch (Exception $e) {
            $this->logger->error("Failed to get user wallet cards", array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
            return array('cards' => array(), 'pagination' => array());
        }
    }
    
    /**
     * 标记卡密为已使用
     * @param int $userId 用户ID
     * @param int $walletId 卡包ID
     * @param array $usageInfo 使用信息
     * @return bool
     */
    public function markCardAsUsed($userId, $walletId, $usageInfo = array()) {
        try {
            // 验证卡密归属
            $card = $this->getWalletCard($userId, $walletId);
            if (!$card) {
                throw new Exception("Card not found or access denied");
            }
            
            if ($card['status'] === 'used') {
                throw new Exception("Card already used");
            }
            
            // 更新状态
            $updateData = array(
                'status' => 'used',
                'used_at' => date('Y-m-d H:i:s'),
                'used_ip' => isset($usageInfo['ip']) ? $usageInfo['ip'] : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''),
                'used_device' => isset($usageInfo['device']) ? $usageInfo['device'] : '',
                'usage_notes' => isset($usageInfo['notes']) ? $usageInfo['notes'] : ''
            );
            
            $result = $this->updateWalletCard($walletId, $updateData);
            if (!$result) {
                throw new Exception("Failed to update card status");
            }
            
            // 同步更新原始卡密状态
            $this->cardManager->redeemCardById($card['card_id'], $usageInfo);
            
            $this->logger->info("Card marked as used", array(
                'user_id' => $userId,
                'wallet_id' => $walletId,
                'card_code' => $card['card_code']
            ));
            
            return true;
            
        } catch (Exception $e) {
            $this->logger->error("Failed to mark card as used", array(
                'user_id' => $userId,
                'wallet_id' => $walletId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 同步到其他渠道
     * @param int $userId 用户ID
     * @param int $walletId 卡包ID
     * @param array $card 卡密信息
     */
    protected function syncToOtherChannels($userId, $walletId, $card) {
        try {
            // 获取用户信息
            $user = $this->getUserInfo($userId);
            if (!$user) {
                return;
            }
            
            // 微信服务通知
            if (!empty($user['wechat_openid'])) {
                $this->syncToWechat($user, $card);
            }
            
            // 支付宝卡包
            if (!empty($user['alipay_user_id'])) {
                $this->syncToAlipay($user, $card);
            }
            
            // 记录同步状态
            $this->updateSyncStatus($walletId, array(
                'wechat_synced' => !empty($user['wechat_openid']),
                'alipay_synced' => !empty($user['alipay_user_id']),
                'synced_at' => date('Y-m-d H:i:s')
            ));
            
        } catch (Exception $e) {
            $this->logger->error("Failed to sync to other channels", array(
                'user_id' => $userId,
                'wallet_id' => $walletId,
                'error' => $e->getMessage()
            ));
        }
    }
    
    /**
     * 同步到微信服务通知
     * @param array $user 用户信息
     * @param array $card 卡密信息
     */
    protected function syncToWechat($user, $card) {
        try {
            $templateData = array(
                'first' => '您的卡密已到账，请及时查收！',
                'keyword1' => $card['product_name'],
                'keyword2' => $card['card_code'],
                'keyword3' => date('Y-m-d H:i:s'),
                'remark' => '点击查看详情，妥善保管您的卡密。'
            );
            
            $result = $this->notificationManager->sendWechatTemplateMessage(
                $user['wechat_openid'],
                'card_delivery_template',
                $templateData,
                array(
                    'url' => $this->getWalletUrl()
                )
            );
            
            if ($result) {
                $this->logger->info("Wechat notification sent successfully", array(
                    'user_id' => $user['id'],
                    'card_code' => $card['card_code']
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->error("Failed to sync to WeChat", array(
                'user_id' => $user['id'],
                'card_code' => $card['card_code'],
                'error' => $e->getMessage()
            ));
        }
    }
    
    /**
     * 同步到支付宝卡包
     * @param array $user 用户信息
     * @param array $card 卡密信息
     */
    protected function syncToAlipay($user, $card) {
        try {
            // 创建支付宝卡券
            $voucherData = array(
                'user_id' => $user['alipay_user_id'],
                'title' => $card['product_name'],
                'card_code' => $card['card_code'],
                'card_secret' => $card['card_secret'],
                'valid_start_time' => date('Y-m-d H:i:s'),
                'valid_end_time' => $card['expires_at'],
                'notify_url' => $this->getAlipayNotifyUrl()
            );
            
            $result = $this->createAlipayVoucher($voucherData);
            
            if ($result) {
                $this->logger->info("Alipay voucher created successfully", array(
                    'user_id' => $user['id'],
                    'card_code' => $card['card_code']
                ));
            }
            
        } catch (Exception $e) {
            $this->logger->error("Failed to sync to Alipay", array(
                'user_id' => $user['id'],
                'card_code' => $card['card_code'],
                'error' => $e->getMessage()
            ));
        }
    }
    
    /**
     * 获取卡包统计信息
     * @param int $userId 用户ID
     * @return array
     */
    public function getWalletStats($userId) {
        try {
            $sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'unused' THEN 1 ELSE 0 END) as unused,
                        SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used,
                        SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired,
                        SUM(CASE WHEN expires_at > NOW() THEN 1 ELSE 0 END) as valid
                    FROM user_wallet_cards 
                    WHERE user_id = ?";
            
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($userId));
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 获取即将过期的卡密数量（7天内）
            $expiringSoonSql = "SELECT COUNT(*) as expiring_soon 
                                FROM user_wallet_cards 
                                WHERE user_id = ? 
                                AND status = 'unused' 
                                AND expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)";
            
            $stmt = $this->database->prepare($expiringSoonSql);
            $stmt->execute(array($userId));
            $expiringSoon = $stmt->fetch(PDO::FETCH_ASSOC)['expiring_soon'];
            
            $stats['expiring_soon'] = intval($expiringSoon);
            
            return $stats;
            
        } catch (Exception $e) {
            $this->logger->error("Failed to get wallet stats", array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
            return array();
        }
    }
    
    /**
     * 批量导出卡密
     * @param int $userId 用户ID
     * @param array $walletIds 卡包ID列表
     * @return array
     */
    public function exportCards($userId, $walletIds = array()) {
        try {
            $where = array("user_id = ?");
            $params = array($userId);
            
            if (!empty($walletIds)) {
                $placeholders = str_repeat('?,', count($walletIds) - 1) . '?';
                $where[] = "id IN ({$placeholders})";
                $params = array_merge($params, $walletIds);
            }
            
            $whereClause = implode(' AND ', $where);
            
            $sql = "SELECT card_code, card_secret, product_name, added_at, expires_at, status 
                    FROM user_wallet_cards 
                    WHERE {$whereClause} 
                    ORDER BY added_at DESC";
            
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 生成CSV内容
            $csvContent = $this->generateCSV($cards);
            
            $this->logger->info("Cards exported successfully", array(
                'user_id' => $userId,
                'card_count' => count($cards)
            ));
            
            return array(
                'success' => true,
                'content' => $csvContent,
                'filename' => 'cards_export_' . date('Y-m-d_H-i-s') . '.csv'
            );
            
        } catch (Exception $e) {
            $this->logger->error("Failed to export cards", array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'error' => $e->getMessage());
        }
    }
    
    // 保护的辅助方法
    
    protected function checkCardExists($userId, $cardId) {
        $sql = "SELECT id FROM user_wallet_cards WHERE user_id = ? AND card_id = ?";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array($userId, $cardId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    protected function insertWalletCard($data) {
        $fields = array_keys($data);
        $placeholders = str_repeat('?,', count($fields) - 1) . '?';
        $sql = "INSERT INTO user_wallet_cards (" . implode(', ', $fields) . ") VALUES ({$placeholders})";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array_values($data));
        return $this->database->lastInsertId();
    }
    
    protected function getWalletCard($userId, $walletId) {
        $sql = "SELECT * FROM user_wallet_cards WHERE user_id = ? AND id = ?";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array($userId, $walletId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    protected function updateWalletCard($walletId, $data) {
        $setClause = array();
        foreach ($data as $field => $value) {
            $setClause[] = "{$field} = ?";
        }
        $sql = "UPDATE user_wallet_cards SET " . implode(', ', $setClause) . " WHERE id = ?";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array_merge(array_values($data), array($walletId)));
        return $stmt->rowCount() > 0;
    }
    
    protected function updateSyncStatus($walletId, $syncData) {
        $setClause = array();
        foreach ($syncData as $field => $value) {
            $setClause[] = "{$field} = ?";
        }
        $sql = "UPDATE user_wallet_cards SET " . implode(', ', $setClause) . " WHERE id = ?";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array_merge(array_values($syncData), array($walletId)));
    }
    
    protected function getUserInfo($userId) {
        $sql = "SELECT id, username, email, wechat_openid, alipay_user_id FROM users WHERE id = ?";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array($userId));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    protected function getStatusText($status) {
        $statusMap = array(
            'unused' => '未使用',
            'used' => '已使用',
            'expired' => '已过期'
        );
        return isset($statusMap[$status]) ? $statusMap[$status] : '未知';
    }
    
    protected function isCardExpired($expiresAt) {
        return $expiresAt && strtotime($expiresAt) < time();
    }
    
    protected function getDaysUntilExpiry($expiresAt) {
        if (!$expiresAt) return null;
        $diff = strtotime($expiresAt) - time();
        return $diff > 0 ? ceil($diff / 86400) : 0;
    }
    
    protected function maskCardCode($cardCode) {
        if (strlen($cardCode) <= 8) return $cardCode;
        return substr($cardCode, 0, 4) . str_repeat('*', strlen($cardCode) - 8) . substr($cardCode, -4);
    }
    
    protected function maskCardSecret($cardSecret) {
        if (strlen($cardSecret) <= 6) return $cardSecret;
        return substr($cardSecret, 0, 3) . str_repeat('*', strlen($cardSecret) - 6) . substr($cardSecret, -3);
    }
    
    protected function getWalletUrl() {
        return $this->config['app_url'] . '/user-center.html#cards';
    }
    
    protected function getAlipayNotifyUrl() {
        return $this->config['app_url'] . '/api/alipay/notify.php';
    }
    
    protected function createAlipayVoucher($data) {
        // 这里需要集成支付宝开放平台API
        // 暂时返回true，实际需要调用支付宝API
        return true;
    }
    
    protected function generateCSV($cards) {
        $csv = "卡密编码,卡密密码,产品名称,添加时间,过期时间,状态\n";
        foreach ($cards as $card) {
            $csv .= "{$card['card_code']},{$card['card_secret']},{$card['product_name']},{$card['added_at']},{$card['expires_at']},{$card['status']}\n";
        }
        return $csv;
    }
}