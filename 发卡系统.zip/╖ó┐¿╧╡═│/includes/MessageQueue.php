\u003c?php
/**
 * 消息队列管理器
 * 提供异步任务处理功能，支持任务入队、出队、重试、失败处理等功能
 */

class MessageQueue {
    private $redis;          // Redis连接对象
    private $config;         // 配置信息
    private $queues = [];    // 队列列表
    private $runningTasks = []; // 正在运行的任务
    private $stats = [       // 统计信息
        'tasks_enqueued' =\u003e 0,
        'tasks_processed' =\u003e 0,
        'tasks_failed' =\u003e 0,
        'tasks_retried' =\u003e 0,
        'tasks_delayed' =\u003e 0,
        'processing_time' =\u003e 0,
        'last_process_time' =\u003e 0
    ];
    private $defaultTimeout = 60; // 默认任务处理超时时间（秒）
    private $defaultMaxRetries = 3; // 默认最大重试次数
    private $workerId;       // 工作进程ID
    private $heartbeatInterval = 10; // 心跳间隔（秒）
    private $lastHeartbeat = 0; // 最后心跳时间
    private $shutdownSignaled = false; // 关闭信号
    
    /**
     * 队列类型
     */
    const TYPE_DEFAULT = 'default';       // 默认队列
    const TYPE_ORDER = 'order';           // 订单处理队列
    const TYPE_CARD = 'card';             // 卡密处理队列
    const TYPE_NOTIFICATION = 'notification'; // 通知队列
    const TYPE_REPORT = 'report';         // 报表生成队列
    const TYPE_PROMOTION = 'promotion';   // 促销处理队列
    const TYPE_LOG = 'log';               // 日志处理队列
    
    /**
     * 任务状态
     */
    const STATUS_PENDING = 'pending';     // 等待处理
    const STATUS_PROCESSING = 'processing'; // 处理中
    const STATUS_COMPLETED = 'completed'; // 完成
    const STATUS_FAILED = 'failed';       // 失败
    const STATUS_RETRYING = 'retrying';   // 重试中
    
    /**
     * 构造函数
     * @param array $config 配置参数
     */
    public function __construct(array $config = []) {
        $this-\u003econfig = array_merge([
            'redis' =\u003e [
                'host' =\u003e 'localhost',
                'port' =\u003e 6379,
                'database' =\u003e 1,
                'auth' =\u003e null,
                'prefix' =\u003e 'mq:'
            ],
            'default_queue' =\u003e self::TYPE_DEFAULT,
            'task_timeout' =\u003e 60, // 任务超时时间（秒）
            'max_retries' =\u003e 3,   // 默认最大重试次数
            'retry_delay' =\u003e 60,  // 默认重试延迟（秒）
            'worker_id' =\u003e null,  // 工作进程ID
            'memory_limit' =\u003e 128, // 内存限制（MB）
            'auto_start_worker' =\u003e false, // 是否自动启动工作进程
            'log_file' =\u003e null,   // 日志文件路径
            'failed_queue' =\u003e 'failed_tasks' // 失败任务队列
        ], $config);
        
        // 设置工作进程ID
        $this-\u003eworkerId = $this-\u003econfig['worker_id'] ?: uniqid('worker_', true);
        
        // 设置默认值
        $this-\u003edefaultTimeout = $this-\u003econfig['task_timeout'];
        $this-\u003edefaultMaxRetries = $this-\u003econfig['max_retries'];
        
        // 初始化Redis连接
        $this-\u003einitsRedis();
        
        // 初始化队列
        $this-\u003einitQueues();
        
        // 注册信号处理
        $this-\u003eregisterSignalHandlers();
        
        // 记录启动信息
        $this-\u003elog("MessageQueue started with worker ID: {$this-\u003eworkerId}");
        
        // 如果配置了自动启动工作进程
        if ($this-\u003econfig['auto_start_worker']) {
            $this-\u003estartWorker();
        }
    }
    
    /**
     * 初始化Redis连接
     */
    private function initsRedis() {
        try {
            // 创建Redis实例
            $this-\u003eredis = new Redis();
            $redisConfig = $this-\u003econfig['redis'];
            
            // 连接Redis
            $this-\u003eredis-\u003econnect(
                $redisConfig['host'],
                $redisConfig['port'],
                2.5, // 连接超时
                null, // 重试间隔
                100,  // 读取超时
                0.1   // 超时时间
            );
            
            // 认证
            if ($redisConfig['auth']) {
                $this-\u003eredis-\u003eauth($redisConfig['auth']);
            }
            
            // 选择数据库
            $this-\u003eredis-\u003eselect($redisConfig['database']);
            
            return true;
        } catch (RedisException $e) {
            $this-\u003elog("Failed to connect to Redis: " . $e-\u003egetMessage(), 'error');
            throw new Exception("Redis connection failed: " . $e-\u003egetMessage());
        }
    }
    
    /**
     * 初始化队列
     */
    private function initQueues() {
        // 定义所有队列
        $this-\u003equeues = [
            self::TYPE_DEFAULT,
            self::TYPE_ORDER,
            self::TYPE_CARD,
            self::TYPE_NOTIFICATION,
            self::TYPE_REPORT,
            self::TYPE_PROMOTION,
            self::TYPE_LOG
        ];
        
        // 确保所有队列和相关数据结构都存在
        foreach ($this-\u003equeues as $queue) {
            $this-\u003eensureQueueExists($queue);
        }
        
        // 确保失败队列存在
        $this-\u003eensureQueueExists($this-\u003econfig['failed_queue']);
    }
    
    /**
     * 确保队列存在
     * @param string $queue 队列名称
     */
    private function ensureQueueExists($queue) {
        try {
            // 获取队列键名
            $queueKey = $this-\u003egetQueueKey($queue);
            
            // 尝试获取队列长度（如果不存在会返回0，但不会报错）
            $this-\u003eredis-\u003elen($queueKey);
        } catch (RedisException $e) {
            $this-\u003elog("Failed to ensure queue {$queue} exists: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 生成队列键名
     * @param string $queue 队列名称
     * @return string 队列键名
     */
    private function getQueueKey($queue) {
        return $this-\u003econfig['redis']['prefix'] . "queue:" . $queue;
    }
    
    /**
     * 生成任务键名
     * @param string $taskId 任务ID
     * @return string 任务键名
     */
    private function getTaskKey($taskId) {
        return $this-\u003econfig['redis']['prefix'] . "task:" . $taskId;
    }
    
    /**
     * 生成处理中任务集合键名
     * @return string 键名
     */
    private function getProcessingKey() {
        return $this-\u003econfig['redis']['prefix'] . "processing";
    }
    
    /**
     * 生成延迟任务键名
     * @return string 键名
     */
    private function getDelayedKey() {
        return $this-\u003econfig['redis']['prefix'] . "delayed";
    }
    
    /**
     * 生成工作进程键名
     * @return string 键名
     */
    private function getWorkersKey() {
        return $this-\u003econfig['redis']['prefix'] . "workers";
    }
    
    /**
     * 生成任务统计键名
     * @return string 键名
     */
    private function getStatsKey() {
        return $this-\u003econfig['redis']['prefix'] . "stats";
    }
    
    /**
     * 生成工作进程信息键名
     * @return string 键名
     */
    private function getWorkerKey() {
        return $this-\u003econfig['redis']['prefix'] . "worker:" . $this-\u003eworkerId;
    }
    
    /**
     * 生成唯一任务ID
     * @return string 任务ID
     */
    private function generateTaskId() {
        return uniqid('task_', true);
    }
    
    /**
     * 任务入队
     * @param mixed $data 任务数据
     * @param string $queue 队列名称
     * @param array $options 选项
     * @return string 任务ID
     */
    public function enqueue($data, $queue = self::TYPE_DEFAULT, array $options = []) {
        try {
            // 验证队列
            if (!in_array($queue, $this-\u003equeues) && $queue != $this-\u003econfig['failed_queue']) {
                throw new InvalidArgumentException("Invalid queue: {$queue}");
            }
            
            // 合并选项
            $options = array_merge([
                'delay' =\u003e 0,        // 延迟执行时间（秒）
                'timeout' =\u003e $this-\u003edefaultTimeout, // 处理超时时间（秒）
                'max_retries' =\u003e $this-\u003edefaultMaxRetries, // 最大重试次数
                'priority' =\u003e 0,     // 优先级（0-10，0最高）
                'created_at' =\u003e time(), // 创建时间
                'task_type' =\u003e 'generic', // 任务类型
            ], $options);
            
            // 生成任务ID
            $taskId = $this-\u003egenerateTaskId();
            
            // 构造任务数据
            $task = [
                'id' =\u003e $taskId,
                'queue' =\u003e $queue,
                'data' =\u003e $data,
                'status' =\u003e self::STATUS_PENDING,
                'attempts' =\u003e 0,
                'max_retries' =\u003e $options['max_retries'],
                'timeout' =\u003e $options['timeout'],
                'priority' =\u003e $options['priority'],
                'created_at' =\u003e $options['created_at'],
                'updated_at' =\u003e time(),
                'scheduled_at' =\u003e $options['created_at'] + $options['delay'],
                'task_type' =\u003e $options['task_type'],
                'worker_id' =\u003e null,
                'started_at' =\u003e null,
                'completed_at' =\u003e null,
                'failed_at' =\u003e null,
                'last_error' =\u003e null,
            ];
            
            // 序列化任务数据
            $serializedTask = json_encode($task);
            
            // 保存任务信息
            $taskKey = $this-\u003egetTaskKey($taskId);
            $this-\u003eredis-\u003eset($taskKey, $serializedTask);
            
            // 设置任务过期时间（24小时）
            $this-\u003eredis-\u003expire($taskKey, 86400);
            
            // 根据是否有延迟决定放入哪个队列
            if ($options['delay'] \u003e 0) {
                // 延迟任务放入有序集合
                $delayedKey = $this-\u003egetDelayedKey();
                $this-\u003eredis-\u003ezadd($delayedKey, $task['scheduled_at'], $taskId);
                
                $this-\u003estats['tasks_delayed']++;
            } else {
                // 普通任务放入对应队列
                $queueKey = $this-\u003egetQueueKey($queue);
                $this-\u003eredis-\u003erpush($queueKey, $taskId);
            }
            
            // 更新统计信息
            $this-\u003estats['tasks_enqueued']++;
            $this-\u003eupdateStats('tasks_enqueued');
            
            // 记录日志
            $this-\u003elog("Task {$taskId} enqueued in {$queue} queue");
            
            return $taskId;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to enqueue task: " . $e-\u003egetMessage(), 'error');
            throw $e;
        }
    }
    
    /**
     * 批量入队
     * @param array $tasks 任务数组
     * @param string $queue 队列名称
     * @param array $options 选项
     * @return array 任务ID数组
     */
    public function enqueueBatch(array $tasks, $queue = self::TYPE_DEFAULT, array $options = []) {
        $taskIds = [];
        
        try {
            // 开始Redis事务
            $this-\u003eredis-\u003emulti();
            
            // 处理每个任务
            foreach ($tasks as $taskData) {
                $taskId = $this-\u003egenerateTaskId();
                $taskIds[] = $taskId;
                
                // 合并选项
                $taskOptions = array_merge($options, isset($taskData['options']) ? $taskData['options'] : []);
                
                // 构造任务数据
                $task = [
                    'id' =\u003e $taskId,
                    'queue' =\u003e $queue,
                    'data' =\u003e $taskData['data'],
                    'status' =\u003e self::STATUS_PENDING,
                    'attempts' =\u003e 0,
                    'max_retries' =\u003e $taskOptions['max_retries'] ?? $this-\u003edefaultMaxRetries,
                    'timeout' =\u003e $taskOptions['timeout'] ?? $this-\u003edefaultTimeout,
                    'priority' =\u003e $taskOptions['priority'] ?? 0,
                    'created_at' =\u003e time(),
                    'updated_at' =\u003e time(),
                    'scheduled_at' =\u003e time() + ($taskOptions['delay'] ?? 0),
                    'task_type' =\u003e $taskOptions['task_type'] ?? 'generic',
                    'worker_id' =\u003e null,
                    'started_at' =\u003e null,
                    'completed_at' =\u003e null,
                    'failed_at' =\u003e null,
                    'last_error' =\u003e null,
                ];
                
                // 序列化任务数据
                $serializedTask = json_encode($task);
                
                // 保存任务信息
                $taskKey = $this-\u003egetTaskKey($taskId);
                $this-\u003eredis-\u003eset($taskKey, $serializedTask);
                $this-\u003eredis-\u003expire($taskKey, 86400);
                
                // 根据是否有延迟决定放入哪个队列
                if (isset($taskOptions['delay']) && $taskOptions['delay'] \u003e 0) {
                    $delayedKey = $this-\u003egetDelayedKey();
                    $this-\u003eredis-\u003ezadd($delayedKey, $task['scheduled_at'], $taskId);
                } else {
                    $queueKey = $this-\u003egetQueueKey($queue);
                    $this-\u003eredis-\u003erpush($queueKey, $taskId);
                }
            }
            
            // 执行事务
            $this-\u003eredis-\u003eexec();
            
            // 更新统计信息
            $taskCount = count($taskIds);
            $this-\u003estats['tasks_enqueued'] += $taskCount;
            $this-\u003eupdateStats('tasks_enqueued', $taskCount);
            
            // 记录日志
            $this-\u003elog("Batch enqueued {$taskCount} tasks in {$queue} queue");
            
            return $taskIds;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to enqueue batch tasks: " . $e-\u003egetMessage(), 'error');
            throw $e;
        }
    }
    
    /**
     * 获取任务
     * @param string $taskId 任务ID
     * @return array|null 任务数据
     */
    public function getTask($taskId) {
        try {
            $taskKey = $this-\u003egetTaskKey($taskId);
            $serializedTask = $this-\u003eredis-\u003 eget($taskKey);
            
            if ($serializedTask === false) {
                return null;
            }
            
            $task = json_decode($serializedTask, true);
            return $task;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to get task {$taskId}: " . $e-\u003egetMessage(), 'error');
            return null;
        }
    }
    
    /**
     * 更新任务
     * @param string $taskId 任务ID
     * @param array $updates 更新数据
     * @return bool 是否成功
     */
    public function updateTask($taskId, array $updates) {
        try {
            // 获取任务
            $task = $this-\u003egetTask($taskId);
            
            if ($task === null) {
                return false;
            }
            
            // 更新数据
            $task = array_merge($task, $updates);
            $task['updated_at'] = time();
            
            // 保存任务
            $taskKey = $this-\u003egetTaskKey($taskId);
            $this-\u003eredis-\u003eset($taskKey, json_encode($task));
            
            return true;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to update task {$taskId}: " . $e-\u003egetMessage(), 'error');
            return false;
        }
    }
    
    /**
     * 出队并处理任务
     * @param string|array $queues 队列名称或队列数组
     * @param callable $callback 处理回调函数
     * @param array $options 选项
     * @return array|null 处理结果
     */
    public function process($queues, callable $callback, array $options = []) {
        try {
            // 合并选项
            $options = array_merge([
                'timeout' =\u003e 5, // 出队超时时间（秒）
                'blocking' =\u003e true, // 是否阻塞等待
            ], $options);
            
            // 确保queues是数组
            if (!is_array($queues)) {
                $queues = [$queues];
            }
            
            // 验证所有队列
            foreach ($queues as $queue) {
                if (!in_array($queue, $this-\u003equeues)) {
                    throw new InvalidArgumentException("Invalid queue: {$queue}");
                }
            }
            
            // 处理延迟任务
            $this-\u003eprocessDelayedTasks();
            
            // 准备队列键名
            $queueKeys = [];
            foreach ($queues as $queue) {
                $queueKeys[] = $this-\u003egetQueueKey($queue);
            }
            
            // 执行出队操作
            $result = null;
            if ($options['blocking']) {
                // 阻塞出队（BLPOP）
                $result = $this-\u003eredis-\u003eblpop($queueKeys, $options['timeout']);
            } else {
                // 非阻塞出队
                foreach ($queueKeys as $queueKey) {
                    $result = $this-\u003eredis-\u003elpop($queueKey);
                    if ($result !== false) {
                        $result = [$queueKey, $result];
                        break;
                    }
                }
            }
            
            // 如果没有任务，返回null
            if ($result === false || $result === null) {
                return null;
            }
            
            // 解析结果
            $queueKey = $result[0];
            $taskId = $result[1];
            
            // 获取任务
            $task = $this-\u003egetTask($taskId);
            
            if ($task === null) {
                $this-\u003elog("Task {$taskId} not found, skipping", 'warning');
                return null;
            }
            
            // 将任务标记为处理中
            $this-\u003eupdateTask($taskId, [
                'status' =\u003e self::STATUS_PROCESSING,
                'worker_id' =\u003e $this-\u003eworkerId,
                'started_at' =\u003e time()
            ]);
            
            // 记录正在运行的任务
            $this-\u003erunningTasks[$taskId] = time();
            
            // 将任务添加到处理中集合
            $processingKey = $this-\u003egetProcessingKey();
            $this-\u003eredis-\u003esadd($processingKey, $taskId);
            $this-\u003eredis-\u003expire($processingKey, 86400);
            
            // 记录开始处理时间
            $startTime = microtime(true);
            
            try {
                // 执行回调函数处理任务
                $callbackResult = call_user_func($callback, $task['data'], $task);
                
                // 更新任务状态为完成
                $this-\u003eupdateTask($taskId, [
                    'status' =\u003e self::STATUS_COMPLETED,
                    'completed_at' =\u003e time(),
                    'result' =\u003e $callbackResult
                ]);
                
                // 更新统计信息
                $this-\u003estats['tasks_processed']++;
                $this-\u003eupdateStats('tasks_processed');
                
                // 计算处理时间
                $processingTime = microtime(true) - $startTime;
                $this-\u003estats['processing_time'] += $processingTime;
                
                // 记录日志
                $this-\u003elog("Task {$taskId} completed in " . number_format($processingTime, 3) . "s");
                
                // 从处理中集合和运行任务列表中移除
                $this-\u003eredis-\u003esrem($processingKey, $taskId);
                unset($this-\u003erunningTasks[$taskId]);
                
                return [
                    'success' =\u003e true,
                    'task_id' =\u003e $taskId,
                    'result' =\u003e $callbackResult,
                    'processing_time' =\u003e $processingTime
                ];
                
            } catch (Exception $e) {
                // 处理任务失败
                return $this-\u003ehandleTaskFailure($task, $e);
            }
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to process tasks: " . $e-\u003egetMessage(), 'error');
            return null;
        }
    }
    
    /**
     * 处理任务失败
     * @param array $task 任务数据
     * @param Exception $e 异常
     * @return array 处理结果
     */
    private function handleTaskFailure(array $task, Exception $e) {
        try {
            $taskId = $task['id'];
            $errorMessage = $e-\u003egetMessage();
            
            // 更新任务失败信息
            $this-\u003eupdateTask($taskId, [
                'status' =\u003e self::STATUS_FAILED,
                'attempts' =\u003e $task['attempts'] + 1,
                'failed_at' =\u003e time(),
                'last_error' =\u003e $errorMessage
            ]);
            
            // 更新统计信息
            $this-\u003estats['tasks_failed']++;
            $this-\u003eupdateStats('tasks_failed');
            
            // 记录日志
            $this-\u003elog("Task {$taskId} failed: {$errorMessage}", 'error');
            
            // 从处理中集合和运行任务列表中移除
            $processingKey = $this-\u003egetProcessingKey();
            $this-\u003eredis-\u003esrem($processingKey, $taskId);
            unset($this-\u003erunningTasks[$taskId]);
            
            // 检查是否需要重试
            if ($task['attempts'] + 1 \u003c= $task['max_retries']) {
                // 计算重试延迟时间（指数退避）
                $retryDelay = pow(2, $task['attempts']) * 10; // 10s, 20s, 40s...
                
                // 重新入队（延迟执行）
                $this-\u003erenqueueTask($task, $retryDelay);
                
                // 更新统计信息
                $this-\u003estats['tasks_retried']++;
                $this-\u003eupdateStats('tasks_retried');
                
                // 记录日志
                $this-\u003elog("Task {$taskId} scheduled for retry in {$retryDelay}s");
                
                return [
                    'success' =\u003e false,
                    'task_id' =\u003e $taskId,
                    'error' =\u003e $errorMessage,
                    'retry_scheduled' =\u003e true,
                    'retry_delay' =\u003e $retryDelay,
                    'attempts' =\u003e $task['attempts'] + 1,
                    'max_retries' =\u003e $task['max_retries']
                ];
            } else {
                // 达到最大重试次数，放入失败队列
                $this-\u003emoveToFailedQueue($task);
                
                return [
                    'success' =\u003e false,
                    'task_id' =\u003e $taskId,
                    'error' =\u003e $errorMessage,
                    'max_retries_reached' =\u003e true,
                    'moved_to_failed_queue' =\u003e true
                ];
            }
            
        } catch (Exception $ex) {
            $this-\u003elog("Failed to handle task failure: " . $ex-\u003egetMessage(), 'error');
            return [
                'success' =\u003e false,
                'task_id' =\u003e $task['id'] ?? 'unknown',
                'error' =\u003e 'Failed to handle task failure: ' . $ex-\u003egetMessage()
            ];
        }
    }
    
    /**
     * 重新入队任务
     * @param array $task 任务数据
     * @param int $delay 延迟时间（秒）
     */
    private function requeueTask(array $task, $delay = 0) {
        // 更新任务状态和重试信息
        $task['status'] = self::STATUS_PENDING;
        $task['scheduled_at'] = time() + $delay;
        $task['updated_at'] = time();
        $task['worker_id'] = null;
        $task['started_at'] = null;
        $task['completed_at'] = null;
        $task['failed_at'] = null;
        
        // 保存任务
        $taskKey = $this-\u003egetTaskKey($task['id']);
        $this-\u003eredis-\u003eset($taskKey, json_encode($task));
        
        if ($delay \u003e 0) {
            // 延迟任务放入有序集合
            $delayedKey = $this-\u003egetDelayedKey();
            $this-\u003eredis-\u003ezadd($delayedKey, $task['scheduled_at'], $task['id']);
        } else {
            // 普通任务放入对应队列
            $queueKey = $this-\u003egetQueueKey($task['queue']);
            $this-\u003eredis-\u003erpush($queueKey, $task['id']);
        }
    }
    
    /**
     * 将任务移到失败队列
     * @param array $task 任务数据
     */
    private function moveToFailedQueue(array $task) {
        try {
            // 更新任务状态
            $task['status'] = self::STATUS_FAILED;
            $task['updated_at'] = time();
            
            // 保存任务
            $taskKey = $this-\u003egetTaskKey($task['id']);
            $this-\u003eredis-\u003eset($taskKey, json_encode($task));
            
            // 设置更长的过期时间（7天）
            $this-\u003eredis-\u003expire($taskKey, 604800);
            
            // 放入失败队列
            $failedQueueKey = $this-\u003egetQueueKey($this-\u003econfig['failed_queue']);
            $this-\u003eredis-\u003erpush($failedQueueKey, $task['id']);
            
            // 记录日志
            $this-\u003elog("Task {$task['id']} moved to failed queue after reaching max retries");
            
        } catch (Exception $e) {
            $this-\u003elog("Failed to move task {$task['id']} to failed queue: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 处理延迟任务
     */
    private function processDelayedTasks() {
        try {
            // 获取当前时间
            $now = time();
            
            // 获取延迟任务键名
            $delayedKey = $this-\u003egetDelayedKey();
            
            // 获取所有过期的延迟任务
            $delayedTasks = $this-\u003eredis-\u003ezrangebyscore($delayedKey, 0, $now);
            
            if (empty($delayedTasks)) {
                return;
            }
            
            // 处理每个延迟任务
            foreach ($delayedTasks as $taskId) {
                // 获取任务
                $task = $this-\u003egetTask($taskId);
                
                if ($task !== null) {
                    // 将任务放入对应队列
                    $queueKey = $this-\u003egetQueueKey($task['queue']);
                    $this-\u003eredis-\u003erpush($queueKey, $taskId);
                }
                
                // 从延迟队列中移除
                $this-\u003eredis-\u003ezrem($delayedKey, $taskId);
            }
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to process delayed tasks: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 开始工作进程
     * @param array $options 选项
     */
    public function startWorker(array $options = []) {
        // 合并选项
        $options = array_merge([
            'queues' =\u003e [self::TYPE_DEFAULT], // 要处理的队列
            'sleep_time' =\u003e 1, // 没有任务时的睡眠时间（秒）
            'max_tasks' =\u003e null, // 最大处理任务数（null表示无限制）
            'max_runtime' =\u003e null, // 最大运行时间（秒，null表示无限制）
            'memory_limit' =\u003e $this-\u003econfig['memory_limit'], // 内存限制（MB）
        ], $options);
        
        // 记录开始时间
        $startTime = time();
        $tasksProcessed = 0;
        
        // 初始化工作进程信息
        $this-\u003eregisterWorker();
        
        // 记录日志
        $this-\u003elog("Worker started, processing queues: " . implode(', ', $options['queues']));
        
        try {
            // 主循环
            while (!$this-\u003eshutdownSignaled) {
                // 检查是否达到最大运行时间
                if ($options['max_runtime'] !== null && (time() - $startTime) \u003e $options['max_runtime']) {
                    $this-\u003elog("Worker reached max runtime of {$options['max_runtime']} seconds, shutting down");
                    break;
                }
                
                // 检查是否达到最大任务数
                if ($options['max_tasks'] !== null && $tasksProcessed \u003e= $options['max_tasks']) {
                    $this-\u003elog("Worker processed {$tasksProcessed} tasks, shutting down");
                    break;
                }
                
                // 检查内存使用
                if ($options['memory_limit'] !== null) {
                    $memoryUsage = $this-\u003egetMemoryUsage();
                    if ($memoryUsage \u003e ($options['memory_limit'] * 1024 * 1024)) {
                        $this-\u003elog("Worker exceeded memory limit of {$options['memory_limit']}MB, shutting down");
                        break;
                    }
                }
                
                // 发送心跳
                $this-\u003esendHeartbeat();
                
                // 处理超时任务
                $this-\u003echeckTimeoutTasks();
                
                // 处理一个任务
                $result = $this-\u003eprocess($options['queues'], function($data, $task) use ($options) {
                    // 执行任务处理
                    // 注意：这里应该调用外部定义的任务处理器
                    // 简化示例，实际应用中应该根据任务类型调用不同的处理器
                    return $this-\u003ehandleTask($data, $task);
                }, ['blocking' =\u003e false]);
                
                // 如果处理了任务，增加计数
                if ($result && $result['success']) {
                    $tasksProcessed++;
                } else {
                    // 没有任务，短暂休眠
                    usleep($options['sleep_time'] * 1000000);
                }
                
                // 短暂让出CPU时间片
                usleep(1000);
            }
            
        } catch (Exception $e) {
            $this-\u003elog("Worker error: " . $e-\u003egetMessage(), 'error');
        } finally {
            // 清理工作进程信息
            $this-\u003eunregisterWorker();
            
            // 记录日志
            $runtime = time() - $startTime;
            $this-\u003elog("Worker stopped after {$runtime} seconds, processed {$tasksProcessed} tasks");
        }
    }
    
    /**
     * 注册工作进程
     */
    private function registerWorker() {
        try {
            // 构造工作进程信息
            $workerInfo = [
                'id' =\u003e $this-\u003eworkerId,
                'pid' =\u003e getmypid(),
                'start_time' =\u003e time(),
                'last_heartbeat' =\u003e time(),
                'status' =\u003e 'running',
                'hostname' =\u003e gethostname(),
                'php_version' =\u003e PHP_VERSION,
            ];
            
            // 保存工作进程信息
            $workerKey = $this-\u003egetWorkerKey();
            $this-\u003eredis-\u003eset($workerKey, json_encode($workerInfo));
            $this-\u003eredis-\u003expire($workerKey, 300); // 5分钟过期
            
            // 添加到工作进程集合
            $workersKey = $this-\u003egetWorkersKey();
            $this-\u003eredis-\u003esadd($workersKey, $this-\u003eworkerId);
            $this-\u003eredis-\u003expire($workersKey, 300);
            
            // 更新最后心跳时间
            $this-\u003elastHeartbeat = time();
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to register worker: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 注销工作进程
     */
    private function unregisterWorker() {
        try {
            // 从工作进程集合中移除
            $workersKey = $this-\u003egetWorkersKey();
            $this-\u003eredis-\u003esrem($workersKey, $this-\u003eworkerId);
            
            // 删除工作进程信息
            $workerKey = $this-\u003egetWorkerKey();
            $this-\u003eredis-\u003edel($workerKey);
            
            // 将所有正在处理的任务标记为失败并重新入队
            foreach ($this-\u003erunningTasks as $taskId =\u003e $startTime) {
                $task = $this-\u003egetTask($taskId);
                if ($task !== null) {
                    $this-\u003ehandleTaskFailure($task, new Exception("Worker shutdown during task processing"));
                }
            }
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to unregister worker: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 发送心跳
     */
    private function sendHeartbeat() {
        try {
            $now = time();
            
            // 检查是否需要发送心跳
            if ($now - $this-\u003elastHeartbeat \u003c $this-\u003eheartbeatInterval) {
                return;
            }
            
            // 更新最后心跳时间
            $this-\u003elastHeartbeat = $now;
            
            // 更新工作进程信息
            $workerKey = $this-\u003egetWorkerKey();
            $workerInfo = $this-\u003eredis-\u003 eget($workerKey);
            
            if ($workerInfo !== false) {
                $workerInfo = json_decode($workerInfo, true);
                $workerInfo['last_heartbeat'] = $now;
                $workerInfo['memory_usage'] = $this-\u003egetMemoryUsage();
                $workerInfo['status'] = 'running';
                
                // 保存更新后的信息
                $this-\u003eredis-\u003eset($workerKey, json_encode($workerInfo));
                $this-\u003eredis-\u003expire($workerKey, 300);
            } else {
                // 工作进程信息不存在，重新注册
                $this-\u003eregisterWorker();
            }
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to send heartbeat: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 检查超时任务
     */
    private function checkTimeoutTasks() {
        try {
            $now = time();
            $processingKey = $this-\u003egetProcessingKey();
            
            // 获取所有正在处理的任务
            $processingTasks = $this-\u003eredis-\u003esmembers($processingKey);
            
            foreach ($processingTasks as $taskId) {
                // 获取任务
                $task = $this-\u003egetTask($taskId);
                
                if ($task !== null && $task['status'] == self::STATUS_PROCESSING && $task['started_at'] !== null) {
                    // 检查是否超时
                    $elapsed = $now - $task['started_at'];
                    if ($elapsed \u003e $task['timeout']) {
                        // 任务超时，视为失败
                        $this-\u003ehandleTaskFailure($task, new Exception("Task processing timed out after {$elapsed}s"));
                    }
                }
            }
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to check timeout tasks: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 处理心跳检测
     */
    private function checkHeartbeat() {
        try {
            $now = time();
            
            // 检查是否需要发送心跳
            if ($now - $this-\u003elastHeartbeat \u003e= $this-\u003eheartbeatInterval) {
                $this-\u003esendHeartbeat();
            }
            
        } catch (Exception $e) {
            // 忽略心跳错误
        }
    }
    
    /**
     * 任务处理器（简化版本）
     * 实际应用中应该根据任务类型调用不同的处理器
     * @param mixed $data 任务数据
     * @param array $task 任务信息
     * @return mixed 处理结果
     */
    private function handleTask($data, array $task) {
        // 根据任务类型处理
        switch ($task['task_type']) {
            case 'order_processing':
                // 订单处理逻辑
                return $this-\u003eprocessOrderTask($data);
                
            case 'card_delivery':
                // 卡密发放逻辑
                return $this-\u003eprocessCardDeliveryTask($data);
                
            case 'notification':
                // 通知发送逻辑
                return $this-\u003eprocessNotificationTask($data);
                
            case 'report_generation':
                // 报表生成逻辑
                return $this-\u003eprocessReportTask($data);
                
            default:
                // 默认处理逻辑
                return [
                    'processed' =\u003e true,
                    'message' =\u003e 'Task processed successfully',
                    'timestamp' =\u003e time(),
                    'data' =\u003e $data
                ];
        }
    }
    
    /**
     * 处理订单任务
     * @param array $data 订单数据
     * @return array 处理结果
     */
    private function processOrderTask(array $data) {
        // 这里应该包含实际的订单处理逻辑
        // 例如：更新订单状态、扣减库存、生成订单记录等
        
        // 简化示例
        return [
            'order_id' =\u003e $data['order_id'] ?? 'unknown',
            'status' =\u003e 'processed',
            'timestamp' =\u003e time(),
            'message' =\u003e 'Order processed successfully'
        ];
    }
    
    /**
     * 处理卡密发放任务
     * @param array $data 卡密发放数据
     * @return array 处理结果
     */
    private function processCardDeliveryTask(array $data) {
        // 这里应该包含实际的卡密发放逻辑
        // 例如：获取卡密、发送卡密、记录发放记录等
        
        // 简化示例
        return [
            'order_id' =\u003e $data['order_id'] ?? 'unknown',
            'user_id' =\u003e $data['user_id'] ?? 'unknown',
            'card_count' =\u003e $data['card_count'] ?? 0,
            'status' =\u003e 'delivered',
            'timestamp' =\u003e time(),
            'message' =\u003e 'Cards delivered successfully'
        ];
    }
    
    /**
     * 处理通知任务
     * @param array $data 通知数据
     * @return array 处理结果
     */
    private function processNotificationTask(array $data) {
        // 这里应该包含实际的通知发送逻辑
        // 例如：发送邮件、短信、推送通知等
        
        // 简化示例
        return [
            'user_id' =\u003e $data['user_id'] ?? 'unknown',
            'notification_type' =\u003e $data['type'] ?? 'unknown',
            'status' =\u003e 'sent',
            'timestamp' =\u003e time(),
            'message' =\u003e 'Notification sent successfully'
        ];
    }
    
    /**
     * 处理报表生成任务
     * @param array $data 报表数据
     * @return array 处理结果
     */
    private function processReportTask(array $data) {
        // 这里应该包含实际的报表生成逻辑
        // 例如：查询数据、生成报表文件、发送报表等
        
        // 简化示例
        return [
            'report_type' =\u003e $data['type'] ?? 'unknown',
            'period' =\u003e $data['period'] ?? 'unknown',
            'status' =\u003e 'generated',
            'timestamp' =\u003e time(),
            'message' =\u003e 'Report generated successfully'
        ];
    }
    
    /**
     * 获取队列长度
     * @param string $queue 队列名称
     * @return int 队列长度
     */
    public function getQueueLength($queue) {
        try {
            $queueKey = $this-\u003egetQueueKey($queue);
            return $this-\u003eredis-\u003elen($queueKey);
        } catch (RedisException $e) {
            $this-\u003elog("Failed to get queue length for {$queue}: " . $e-\u003egetMessage(), 'error');
            return 0;
        }
    }
    
    /**
     * 获取所有队列长度
     * @return array 队列长度数组
     */
    public function getAllQueueLengths() {
        $lengths = [];
        
        try {
            foreach ($this-\u003equeues as $queue) {
                $lengths[$queue] = $this-\u003egetQueueLength($queue);
            }
            
            // 添加失败队列
            $lengths[$this-\u003econfig['failed_queue']] = $this-\u003egetQueueLength($this-\u003econfig['failed_queue']);
            
            // 添加延迟队列
            $delayedKey = $this-\u003egetDelayedKey();
            $lengths['delayed'] = $this-\u003eredis-\u003ezcard($delayedKey);
            
            // 添加处理中队列
            $processingKey = $this-\u003egetProcessingKey();
            $lengths['processing'] = $this-\u003eredis-\u003escard($processingKey);
            
            return $lengths;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to get all queue lengths: " . $e-\u003egetMessage(), 'error');
            return $lengths;
        }
    }
    
    /**
     * 取消任务
     * @param string $taskId 任务ID
     * @return bool 是否成功
     */
    public function cancelTask($taskId) {
        try {
            // 获取任务
            $task = $this-\u003egetTask($taskId);
            
            if ($task === null) {
                return false;
            }
            
            // 只能取消等待处理的任务
            if ($task['status'] != self::STATUS_PENDING) {
                return false;
            }
            
            // 从队列中移除任务
            if ($task['scheduled_at'] \u003e time()) {
                // 从延迟队列移除
                $delayedKey = $this-\u003egetDelayedKey();
                $this-\u003eredis-\u003ezrem($delayedKey, $taskId);
            } else {
                // 从普通队列移除
                $queueKey = $this-\u003egetQueueKey($task['queue']);
                $this-\u003eredis-\u003elrem($queueKey, 0, $taskId);
            }
            
            // 删除任务数据
            $taskKey = $this-\u003egetTaskKey($taskId);
            $this-\u003eredis-\u003edel($taskKey);
            
            return true;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to cancel task {$taskId}: " . $e-\u003egetMessage(), 'error');
            return false;
        }
    }
    
    /**
     * 更新统计信息
     * @param string $key 统计键名
     * @param int $increment 增量值
     */
    private function updateStats($key, $increment = 1) {
        try {
            $statsKey = $this-\u003egetStatsKey();
            $this-\u003eredis-\u003ehincrby($statsKey, $key, $increment);
            $this-\u003eredis-\u003expire($statsKey, 86400);
        } catch (RedisException $e) {
            // 忽略统计错误
        }
    }
    
    /**
     * 获取统计信息
     * @return array 统计数据
     */
    public function getStats() {
        try {
            $statsKey = $this-\u003egetStatsKey();
            $redisStats = $this-\u003eredis-\u003ehgetall($statsKey);
            
            // 合并本地统计和Redis统计
            $stats = array_merge($this-\u003estats, $redisStats);
            
            // 添加队列长度
            $stats['queue_lengths'] = $this-\u003egetAllQueueLengths();
            
            // 添加工作进程信息
            $workersKey = $this-\u003egetWorkersKey();
            $stats['active_workers'] = $this-\u003eredis-\u003escard($workersKey);
            
            // 计算平均处理时间
            if ($stats['tasks_processed'] \u003e 0) {
                $stats['avg_processing_time'] = $stats['processing_time'] / $stats['tasks_processed'];
            } else {
                $stats['avg_processing_time'] = 0;
            }
            
            return $stats;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to get stats: " . $e-\u003egetMessage(), 'error');
            return $this-\u003estats;
        }
    }
    
    /**
     * 重置统计信息
     */
    public function resetStats() {
        try {
            $statsKey = $this-\u003egetStatsKey();
            $this-\u003eredis-\u003edel($statsKey);
            
            $this-\u003estats = [
                'tasks_enqueued' =\u003e 0,
                'tasks_processed' =\u003e 0,
                'tasks_failed' =\u003e 0,
                'tasks_retried' =\u003e 0,
                'tasks_delayed' =\u003e 0,
                'processing_time' =\u003e 0,
                'last_process_time' =\u003e 0
            ];
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to reset stats: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 注册信号处理器
     */
    private function registerSignalHandlers() {
        // 只有在命令行模式下才能注册信号处理器
        if (PHP_SAPI !== 'cli') {
            return;
        }
        
        // 注册SIGTERM信号处理器（优雅关闭）
        if (function_exists('pcntl_signal')) {
            pcntl_signal(SIGTERM, function() {
                $this-\u003escheduleShutdown();
            });
            
            // 注册SIGINT信号处理器（Ctrl+C）
            pcntl_signal(SIGINT, function() {
                $this-\u003escheduleShutdown();
            });
        }
    }
    
    /**
     * 调度关闭
     */
    public function scheduleShutdown() {
        if (!$this-\u003eshutdownSignaled) {
            $this-\u003eshutdownSignaled = true;
            $this-\u003elog("Shutdown signaled, will exit after current task completes");
        }
    }
    
    /**
     * 获取内存使用量
     * @return int 内存使用量（字节）
     */
    private function getMemoryUsage() {
        return memory_get_usage(true);
    }
    
    /**
     * 记录日志
     * @param string $message 日志消息
     * @param string $level 日志级别
     */
    private function log($message, $level = 'info') {
        // 格式化日志消息
        $timestamp = date('Y-m-d H:i:s');
        $formattedMessage = "[{$timestamp}] [{$level}] [{$this-\u003eworkerId}] {$message}\n";
        
        // 输出到标准错误
        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, $formattedMessage);
        } else {
            error_log($formattedMessage);
        }
        
        // 如果配置了日志文件，写入文件
        if ($this-\u003econfig['log_file']) {
            error_log($formattedMessage, 3, $this-\u003econfig['log_file']);
        }
    }
    
    /**
     * 优雅关闭工作进程
     */
    public function shutdown() {
        $this-\u003escheduleShutdown();
    }
    
    /**
     * 清除所有队列
     * @param bool $includeFailed 是否包含失败队列
     */
    public function clearAllQueues($includeFailed = false) {
        try {
            // 清除所有队列
            foreach ($this-\u003equeues as $queue) {
                $queueKey = $this-\u003egetQueueKey($queue);
                $this-\u003eredis-\u003edel($queueKey);
            }
            
            // 清除延迟队列
            $delayedKey = $this-\u003egetDelayedKey();
            $this-\u003eredis-\u003edel($delayedKey);
            
            // 清除处理中队列
            $processingKey = $this-\u003egetProcessingKey();
            $this-\u003eredis-\u003edel($processingKey);
            
            // 如果包含失败队列，清除失败队列
            if ($includeFailed) {
                $failedQueueKey = $this-\u003egetQueueKey($this-\u003econfig['failed_queue']);
                $this-\u003eredis-\u003edel($failedQueueKey);
            }
            
            // 重置统计
            $this-\u003eresetStats();
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to clear all queues: " . $e-\u003egetMessage(), 'error');
        }
    }
    
    /**
     * 重新尝试失败的任务
     * @param int $limit 限制数量
     * @return int 重新入队的任务数量
     */
    public function retryFailedTasks($limit = 10) {
        try {
            // 获取失败队列
            $failedQueueKey = $this-\u003egetQueueKey($this-\u003econfig['failed_queue']);
            
            // 获取失败任务ID列表
            $taskIds = $this-\u003eredis-\u003elrange($failedQueueKey, 0, $limit - 1);
            
            if (empty($taskIds)) {
                return 0;
            }
            
            $count = 0;
            
            // 重新入队每个失败任务
            foreach ($taskIds as $taskId) {
                // 获取任务
                $task = $this-\u003egetTask($taskId);
                
                if ($task !== null) {
                    // 重置任务状态
                    $task['status'] = self::STATUS_PENDING;
                    $task['attempts'] = 0;
                    $task['updated_at'] = time();
                    $task['scheduled_at'] = time();
                    $task['failed_at'] = null;
                    $task['last_error'] = null;
                    $task['worker_id'] = null;
                    $task['started_at'] = null;
                    $task['completed_at'] = null;
                    
                    // 保存任务
                    $taskKey = $this-\u003egetTaskKey($taskId);
                    $this-\u003eredis-\u003eset($taskKey, json_encode($task));
                    
                    // 放入原始队列
                    $originalQueueKey = $this-\u003egetQueueKey($task['queue']);
                    $this-\u003eredis-\u003erpush($originalQueueKey, $taskId);
                    
                    // 从失败队列移除
                    $this-\u003eredis-\u003elrem($failedQueueKey, 1, $taskId);
                    
                    $count++;
                }
            }
            
            return $count;
            
        } catch (RedisException $e) {
            $this-\u003elog("Failed to retry failed tasks: " . $e-\u003egetMessage(), 'error');
            return 0;
        }
    }
    
    /**
     * 关闭Redis连接
     */
    public function close() {
        try {
            if ($this-\u003eredis) {
                $this-\u003eredis-\u003eclose();
                $this-\u003eredis = null;
            }
        } catch (RedisException $e) {
            // 忽略关闭错误
        }
    }
    
    /**
     * 析构函数
     */
    public function __destruct() {
        try {
            // 如果是工作进程，注销工作进程
            if ($this-\u003econfig['auto_start_worker'] || !empty($this-\u003erunningTasks)) {
                $this-\u003eunregisterWorker();
            }
            
            // 关闭Redis连接
            $this-\u003eclose();
        } catch (Exception $e) {
            // 忽略析构函数中的错误
        }
    }
}