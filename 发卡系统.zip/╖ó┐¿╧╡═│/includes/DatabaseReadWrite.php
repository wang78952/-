<?php
/**
 * 数据库读写分离管理器
 * 实现主从分离，所有写操作走主库，读操作走从库，支持自动故障切换和负载均衡
 */

class DatabaseReadWrite {
    private $masterDb;      // 主库连接
    private $slaveDbs = []; // 从库连接池
    private $currentSlaveIndex = 0; // 当前使用的从库索引
    private $config;        // 配置信息
    private $stats = [      // 性能统计
        'master_queries' => 0,
        'slave_queries' => 0,
        'master_failures' => 0,
        'slave_failures' => 0,
        'failover_count' => 0,
        'last_failover_time' => 0
    ];
    private $readWeight = []; // 从库权重数组
    private $readWeightSum = 0; // 权重总和
    private $failedSlaves = []; // 失败的从库记录
    private $lastHeartbeat = 0; // 最后心跳检测时间
    private $heartbeatInterval = 60; // 心跳检测间隔（秒）
    private $connectionTimeout = 3; // 连接超时时间（秒）
    private $useSlaveThreshold = 0; // 使用从库的查询数量阈值（防止从库缓存预热问题）
    
    /**
     * 构造函数
     * @param array $config 配置参数
     */
    public function __construct(array $config = []) {
        $this->config = array_merge([
            'master' => [
                'host' => 'localhost',
                'port' => 3306,
                'username' => 'root',
                'password' => '',
                'database' => 'card_system',
                'charset' => 'utf8mb4',
                'timeout' => 3,
                'options' => [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            ],
            'slaves' => [
                [
                    'host' => 'localhost',
                    'port' => 3306,
                    'username' => 'root',
                    'password' => '',
                    'database' => 'card_system',
                    'charset' => 'utf8mb4',
                    'timeout' => 3,
                    'weight' => 1, // 权重
                    'options' => [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false
                    ]
                ]
            ],
            'use_slaves' => true, // 是否使用从库
            'sticky_session' => true, // 是否启用会话粘性（同一用户会话优先使用同一从库）
            'slave_read_timeout' => 2, // 从库读取超时
            'replication_delay_threshold' => 5, // 复制延迟阈值（秒）
            'use_master_for_reads' => false // 是否对读操作使用主库（调试用）
        ], $config);
        
        // 初始化连接
        $this->initConnections();
        // 初始化权重
        $this->initWeights();
        // 注册析构函数和错误处理器
        register_shutdown_function([$this, 'closeAllConnections']);
    }
    
    /**
     * 初始化主从数据库连接
     */
    private function initConnections() {
        try {
            // 连接主库
            $this->masterDb = $this->createConnection($this->config['master']);
            
            // 连接从库
            if ($this->config['use_slaves'] && !empty($this->config['slaves'])) {
                foreach ($this->config['slaves'] as $slaveConfig) {
                    try {
                        $slaveDb = $this->createConnection($slaveConfig);
                        $this->slaveDbs[] = $slaveDb;
                    } catch (PDOException $e) {
                        $this->stats['slave_failures']++;
                        $this->failedSlaves[] = $slaveConfig['host'] . ':' . $slaveConfig['port'];
                        error_log('Failed to connect to slave database: ' . $e->getMessage());
                    }
                }
            }
            
        } catch (PDOException $e) {
            $this->stats['master_failures']++;
            error_log('Failed to connect to master database: ' . $e->getMessage());
            throw new Exception('Database initialization failed: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 初始化从库权重
     */
    private function initWeights() {
        $this->readWeight = [];
        $this->readWeightSum = 0;
        
        if ($this->config['use_slaves'] && !empty($this->config['slaves'])) {
            foreach ($this->config['slaves'] as $index => $slaveConfig) {
                $weight = isset($slaveConfig['weight']) ? (int)$slaveConfig['weight'] : 1;
                $this->readWeight[$index] = $weight;
                $this->readWeightSum += $weight;
            }
        }
    }
    
    /**
     * 创建数据库连接
     * @param array $config 数据库配置
     * @return PDO 数据库连接对象
     */
    private function createConnection(array $config) {
        $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset={$config['charset']}";
        $options = isset($config['options']) ? $config['options'] : [];
        $timeout = isset($config['timeout']) ? $config['timeout'] : $this->connectionTimeout;
        
        // 设置连接超时选项
        if (defined('PDO::ATTR_TIMEOUT')) {
            $options[PDO::ATTR_TIMEOUT] = $timeout;
        }
        
        // 创建连接
        $pdo = new PDO($dsn, $config['username'], $config['password'], $options);
        
        // 设置连接属性
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        
        // 设置命名参数风格
        if (defined('PDO::ATTR_CASE')) {
            $pdo->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
        }
        
        // 设置空闲超时
        if (isset($config['idle_timeout'])) {
            $pdo->exec("SET SESSION wait_timeout = {$config['idle_timeout']}");
        }
        
        return $pdo;
    }
    
    /**
     * 选择一个从库（权重轮询）
     * @return PDO|null 从库连接对象或null（无可用从库）
     */
    private function selectSlave() {
        // 检查是否使用从库
        if (!$this->config['use_slaves'] || empty($this->slaveDbs)) {
            return null;
        }
        
        // 执行心跳检测（如果需要）
        $this->checkHeartbeat();
        
        // 检查是否有可用从库
        if (count($this->slaveDbs) - count($this->failedSlaves) == 0) {
            return null;
        }
        
        // 权重轮询选择从库
        $selectedIndex = $this->weightedRandomSelect();
        
        // 检查选中的从库是否正常
        if (!isset($this->slaveDbs[$selectedIndex]) || 
            (isset($this->failedSlaves[$selectedIndex]) && 
            (time() - $this->failedSlaves[$selectedIndex]['time'] < 60))) { // 60秒内的故障从库不使用
            
            // 选择下一个可用的从库
            for ($i = 0; $i < count($this->slaveDbs); $i++) {
                $index = ($selectedIndex + $i) % count($this->slaveDbs);
                if (!isset($this->failedSlaves[$index]) || 
                    (time() - $this->failedSlaves[$index]['time'] >= 60)) {
                    
                    $selectedIndex = $index;
                    break;
                }
            }
        }
        
        // 记录当前从库索引
        $this->currentSlaveIndex = $selectedIndex;
        
        // 检查从库是否正常工作
        try {
            $this->checkSlaveHealth($this->slaveDbs[$selectedIndex], $selectedIndex);
            return $this->slaveDbs[$selectedIndex];
        } catch (PDOException $e) {
            $this->markSlaveAsFailed($selectedIndex, $e->getMessage());
            return null;
        }
    }
    
    /**
     * 权重随机选择
     * @return int 选中的从库索引
     */
    private function weightedRandomSelect() {
        // 如果只有一个从库，直接返回
        if (count($this->slaveDbs) == 1) {
            return 0;
        }
        
        // 如果权重没有初始化或无效，使用简单轮询
        if ($this->readWeightSum <= 0 || empty($this->readWeight)) {
            $this->currentSlaveIndex = ($this->currentSlaveIndex + 1) % count($this->slaveDbs);
            return $this->currentSlaveIndex;
        }
        
        // 权重随机
        $rand = mt_rand(1, $this->readWeightSum);
        $sum = 0;
        
        for ($i = 0; $i < count($this->slaveDbs); $i++) {
            $sum += isset($this->readWeight[$i]) ? $this->readWeight[$i] : 1;
            if ($rand <= $sum) {
                return $i;
            }
        }
        
        // 回退到简单轮询
        $this->currentSlaveIndex = ($this->currentSlaveIndex + 1) % count($this->slaveDbs);
        return $this->currentSlaveIndex;
    }
    
    /**
     * 检查从库健康状态
     * @param PDO $slaveDb 从库连接对象
     * @param int $index 从库索引
     * @return bool 是否健康
     */
    private function checkSlaveHealth(PDO $slaveDb, $index) {
        try {
            // 检查连接是否有效
            $result = $slaveDb->query('SELECT 1')->fetchColumn();
            if ($result !== '1') {
                throw new PDOException('Slave health check failed');
            }
            
            // 检查复制延迟
            if ($this->config['replication_delay_threshold'] > 0) {
                $delay = $this->getReplicationDelay($slaveDb);
                if ($delay !== null && $delay > $this->config['replication_delay_threshold']) {
                    // 复制延迟过高，标记为不可用
                    $this->markSlaveAsFailed($index, "Replication delay too high: {$delay}s");
                    return false;
                }
            }
            
            // 如果之前标记为失败，现在恢复了
            if (isset($this->failedSlaves[$index])) {
                unset($this->failedSlaves[$index]);
            }
            
            return true;
        } catch (PDOException $e) {
            $this->markSlaveAsFailed($index, $e->getMessage());
            return false;
        }
    }
    
    /**
     * 标记从库为失败
     * @param int $index 从库索引
     * @param string $reason 失败原因
     */
    private function markSlaveAsFailed($index, $reason) {
        $this->failedSlaves[$index] = [
            'time' => time(),
            'reason' => $reason
        ];
        
        $this->stats['slave_failures']++;
        error_log("Slave {$index} marked as failed: {$reason}");
        
        // 如果所有从库都失败了，考虑故障转移
        if (count($this->failedSlaves) >= count($this->slaveDbs)) {
            $this->triggerFailover();
        }
    }
    
    /**
     * 触发故障转移
     */
    private function triggerFailover() {
        // 记录故障转移信息
        $this->stats['failover_count']++;
        $this->stats['last_failover_time'] = time();
        
        error_log("All slaves failed, trigger failover to master for reads");
        
        // 在实际生产环境中，这里可能还需要：
        // 1. 通知管理员
        // 2. 尝试重新连接从库
        // 3. 可能的自动提升从库为主库等操作
    }
    
    /**
     * 获取复制延迟
     * @param PDO $slaveDb 从库连接
     * @return int|null 复制延迟（秒）或null（无法获取）
     */
    private function getReplicationDelay(PDO $slaveDb) {
        try {
            // MySQL 5.6+ 支持
            $stmt = $slaveDb->query("SHOW SLAVE STATUS");
            $status = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($status && $status['Slave_IO_Running'] == 'Yes' && $status['Slave_SQL_Running'] == 'Yes') {
                return (int)$status['Seconds_Behind_Master'];
            }
            
            return null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * 执行心跳检测
     */
    private function checkHeartbeat() {
        $now = time();
        
        // 心跳检测间隔
        if ($now - $this->lastHeartbeat > $this->heartbeatInterval) {
            $this->lastHeartbeat = $now;
            
            // 检查主库
            if ($this->masterDb) {
                try {
                    $this->masterDb->query('SELECT 1');
                } catch (PDOException $e) {
                    $this->stats['master_failures']++;
                    error_log("Master database heartbeat failed: " . $e->getMessage());
                    // 尝试重连主库
                    $this->reconnectMaster();
                }
            }
            
            // 检查所有从库
            foreach ($this->slaveDbs as $index => $slaveDb) {
                try {
                    $this->checkSlaveHealth($slaveDb, $index);
                } catch (Exception $e) {
                    // 忽略异常，checkSlaveHealth已经处理了
                }
            }
            
            // 尝试恢复故障从库（如果超时）
            $this->attemptRecoverFailedSlaves();
        }
    }
    
    /**
     * 尝试恢复故障从库
     */
    private function attemptRecoverFailedSlaves() {
        foreach ($this->failedSlaves as $index => $failureInfo) {
            // 如果故障超过60秒，尝试重新连接
            if (time() - $failureInfo['time'] > 60) {
                try {
                    // 尝试重新连接
                    $slaveConfig = $this->config['slaves'][$index];
                    $newConnection = $this->createConnection($slaveConfig);
                    $this->slaveDbs[$index] = $newConnection;
                    unset($this->failedSlaves[$index]);
                    
                    error_log("Successfully recovered slave {$index}");
                } catch (PDOException $e) {
                    // 仍然失败，更新故障时间
                    $this->failedSlaves[$index]['time'] = time();
                }
            }
        }
    }
    
    /**
     * 重新连接主库
     */
    private function reconnectMaster() {
        try {
            $this->masterDb = $this->createConnection($this->config['master']);
            error_log("Successfully reconnected to master database");
        } catch (PDOException $e) {
            error_log("Failed to reconnect to master database: " . $e->getMessage());
        }
    }
    
    /**
     * 判断SQL语句类型
     * @param string $sql SQL语句
     * @return bool 是否为写操作
     */
    private function isWriteOperation($sql) {
        // 去除SQL前的空白字符
        $sql = ltrim($sql);
        
        // 检测是否为写操作（忽略注释）
        $writePatterns = [
            '/^\s*INSERT\s+/i',
            '/^\s*UPDATE\s+/i',
            '/^\s*DELETE\s+/i',
            '/^\s*REPLACE\s+/i',
            '/^\s*TRUNCATE\s+/i',
            '/^\s*CREATE\s+/i',
            '/^\s*ALTER\s+/i',
            '/^\s*DROP\s+/i',
            '/^\s*RENAME\s+/i',
            '/^\s*LOCK\s+/i',
            '/^\s*UNLOCK\s+/i',
            '/^\s*SET\s+/i' // 一些SET语句是写操作
        ];
        
        // 去除SQL语句中的注释
        $sqlWithoutComments = $this->removeSqlComments($sql);
        
        foreach ($writePatterns as $pattern) {
            if (preg_match($pattern, $sqlWithoutComments)) {
                // 特殊处理一些不影响数据的SET语句
                if (stripos($sqlWithoutComments, 'SET NAMES') === 0 ||
                    stripos($sqlWithoutComments, 'SET CHARACTER_SET') === 0 ||
                    stripos($sqlWithoutComments, 'SET SESSION TRANSACTION') === 0 ||
                    stripos($sqlWithoutComments, 'SET @@session.sql_mode') === 0) {
                    return false;
                }
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 移除SQL注释
     * @param string $sql SQL语句
     * @return string 去除注释后的SQL
     */
    private function removeSqlComments($sql) {
        // 移除 /* */ 风格注释
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        // 移除 -- 风格注释
        $sql = preg_replace('/--.*$/m', '', $sql);
        
        return $sql;
    }
    
    /**
     * 获取适合执行给定SQL的数据库连接
     * @param string $sql SQL语句
     * @return PDO 数据库连接对象
     */
    private function getConnection($sql) {
        // 判断是否为写操作
        $isWrite = $this->isWriteOperation($sql);
        
        // 所有写操作都走主库
        if ($isWrite) {
            if (!$this->masterDb) {
                throw new Exception('Master database connection not available', 500);
            }
            return $this->masterDb;
        }
        
        // 如果强制使用主库读，或者查询数量阈值未达到，或者没有可用从库
        if ($this->config['use_master_for_reads'] ||
            $this->stats['slave_queries'] < $this->useSlaveThreshold ||
            ($slave = $this->selectSlave()) === null) {
            
            if (!$this->masterDb) {
                throw new Exception('No database connection available', 500);
            }
            return $this->masterDb;
        }
        
        return $slave;
    }
    
    /**
     * 增强的SQL查询执行方法（返回结果集）
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @param array $paramTypes 可选的参数类型定义
     * @return PDOStatement 查询结果对象
     * @throws DatabaseException 当参数验证失败或查询执行出错时
     */
    public function query($sql, array $params = [], array $paramTypes = []) {
        $connection = $this->getConnection($sql);
        $isWrite = $this->isWriteOperation($sql);
        
        try {
            // 验证SQL语句
            if (!$this->isValidSQL($sql)) {
                throw new DatabaseException('无效的SQL语句', 400);
            }
            
            // 准备和执行语句
            $stmt = $connection->prepare($sql);
            
            // 绑定参数
            foreach ($params as $key => $value) {
                // 获取参数类型（优先使用提供的类型定义）
                $typeKey = is_string($key) ? $key : intval($key);
                $definedType = isset($paramTypes[$typeKey]) ? $paramTypes[$typeKey] : null;
                
                // 执行参数类型验证和转换
                list($validatedValue, $paramType) = $this->validateAndConvertParam($value, $definedType);
                
                // 处理命名参数和位置参数
                if (is_string($key)) {
                    // 确保命名参数格式正确
                    $paramName = $key[0] == ':' ? $key : ':' . $key;
                    $stmt->bindValue($paramName, $validatedValue, $paramType);
                } else {
                    // 位置参数从1开始
                    $stmt->bindValue($key + 1, $validatedValue, $paramType);
                }
            }
            
            // 执行查询
            $startTime = microtime(true);
            $stmt->execute();
            $endTime = microtime(true);
            
            // 计算执行时间
            $executionTime = ($endTime - $startTime) * 1000; // 转换为毫秒
            
            // 记录查询统计
            if ($isWrite) {
                $this->stats['master_queries']++;
                // 记录慢查询（写操作）
                if ($executionTime > $this->config['slow_query_threshold_write']) {
                    $this->logSlowQuery($sql, $params, $executionTime, 'master');
                }
            } else {
                $this->stats['slave_queries']++;
                // 记录慢查询（读操作）
                if ($executionTime > $this->config['slow_query_threshold_read']) {
                    $this->logSlowQuery($sql, $params, $executionTime, 'slave');
                }
            }
            
            // 检查结果集大小（可选）
            $this->checkResultSetSize($stmt, $sql);
            
            return $stmt;
            
        } catch (PDOException $e) {
            // 记录错误
            if ($isWrite) {
                $this->stats['master_failures']++;
            } else {
                $this->stats['slave_failures']++;
            }
            
            // 增强的错误信息
            $errorInfo = $e->errorInfo ?? [];
            $errorCode = isset($errorInfo[1]) ? $errorInfo[1] : $e->getCode();
            $errorMessage = "数据库错误 ({$errorCode}): {$e->getMessage()}";
            
            // 记录详细的错误日志（不包含敏感信息）
            $safeParams = $this->maskSensitiveData($params);
            $this->logError($errorMessage, $sql, $safeParams);
            
            // 如果是从库错误，尝试使用主库重试
            if (!$isWrite && $connection !== $this->masterDb) {
                return $this->queryFromMaster($sql, $params);
            }
            
            // 重新抛出异常
            throw new DatabaseException($errorMessage, 500, $e);
        }
    }
    
    /**
     * 从主库执行查询（重试机制）
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @return PDOStatement 查询结果对象
     */
    private function queryFromMaster($sql, array $params = []) {
        try {
            $stmt = $this->masterDb->prepare($sql);
            
            foreach ($params as $key => $value) {
                $paramType = PDO::PARAM_STR;
                
                if (is_int($value)) {
                    $paramType = PDO::PARAM_INT;
                } else if (is_bool($value)) {
                    $paramType = PDO::PARAM_BOOL;
                } else if (is_null($value)) {
                    $paramType = PDO::PARAM_NULL;
                }
                
                if (is_string($key) && $key[0] == ':') {
                    $stmt->bindValue($key, $value, $paramType);
                } else {
                    $stmt->bindValue($key + 1, $value, $paramType);
                }
            }
            
            $stmt->execute();
            
            // 记录使用主库执行的读查询
            $this->stats['master_queries']++;
            
            return $stmt;
            
        } catch (PDOException $e) {
            $this->stats['master_failures']++;
            throw $e;
        }
    }
    
    /**
     * 执行SQL并返回所有结果
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @return array 查询结果数组
     */
    public function fetchAll($sql, array $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * 执行SQL并返回单行结果
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @return array|null 单行结果或null
     */
    public function fetch($sql, array $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    /**
     * 执行SQL并返回单个值
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @return mixed 单个值
     */
    public function fetchColumn($sql, array $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchColumn();
    }
    
    /**
     * 执行写操作SQL
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @param array $paramTypes 可选的参数类型定义
     * @return int 受影响的行数
     * @throws DatabaseException 当参数验证失败或查询执行出错时
     */
    public function execute($sql, array $params = [], array $paramTypes = []) {
        $stmt = $this->query($sql, $params, $paramTypes);
        return $stmt->rowCount();
    }
    
    /**
     * 验证和转换参数
     * @param mixed $value 参数值
     * @param string|null $type 目标类型
     * @return array [验证后的值, PDO参数类型]
     */
    private function validateAndConvertParam($value, $type = null) {
        // 默认类型
        $pdoType = PDO::PARAM_STR;
        
        // 处理null值
        if (is_null($value)) {
            return [$value, PDO::PARAM_NULL];
        }
        
        // 根据指定类型进行转换和验证
        if ($type !== null) {
            switch (strtolower($type)) {
                case 'int':
                case 'integer':
                    // 强制转换为整数
                    $value = filter_var($value, FILTER_VALIDATE_INT);
                    if ($value === false) {
                        throw new DatabaseException('参数必须是有效的整数', 400);
                    }
                    $pdoType = PDO::PARAM_INT;
                    break;
                    
                case 'float':
                case 'double':
                    // 强制转换为浮点数
                    $value = filter_var($value, FILTER_VALIDATE_FLOAT);
                    if ($value === false) {
                        throw new DatabaseException('参数必须是有效的浮点数', 400);
                    }
                    $pdoType = PDO::PARAM_STR; // 浮点数在PDO中使用字符串类型
                    break;
                    
                case 'bool':
                case 'boolean':
                    // 转换为布尔值
                    $value = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                    if ($value === null) {
                        $value = (bool)$value; // 回退到基本转换
                    }
                    $pdoType = PDO::PARAM_BOOL;
                    break;
                    
                case 'string':
                    // 转换为字符串并验证长度
                    $value = (string)$value;
                    // 检查字符串长度（可选配置）
                    if (isset($this->config['max_string_length']) && 
                        strlen($value) > $this->config['max_string_length']) {
                        throw new DatabaseException('字符串参数过长', 400);
                    }
                    $pdoType = PDO::PARAM_STR;
                    break;
                    
                case 'date':
                case 'datetime':
                    // 验证日期格式
                    if (!is_string($value)) {
                        throw new DatabaseException('日期参数必须是字符串', 400);
                    }
                    
                    // 尝试解析日期
                    $date = new DateTime($value);
                    if (!$date) {
                        throw new DatabaseException('无效的日期格式', 400);
                    }
                    
                    // 转换为标准格式
                    $value = $date->format('Y-m-d H:i:s');
                    $pdoType = PDO::PARAM_STR;
                    break;
                    
                case 'json':
                    // 验证JSON格式
                    if (is_array($value)) {
                        $value = json_encode($value);
                    } elseif (!is_string($value) || !$this->isValidJSON($value)) {
                        throw new DatabaseException('无效的JSON格式', 400);
                    }
                    $pdoType = PDO::PARAM_STR;
                    break;
                    
                default:
                    // 未知类型，保持原值但记录警告
                    if (class_exists('LogManager')) {
                        LogManager::log('WARNING', '未知的参数类型', ['type' => $type]);
                    }
            }
        } else {
            // 自动检测类型
            if (is_int($value)) {
                $pdoType = PDO::PARAM_INT;
            } else if (is_bool($value)) {
                $pdoType = PDO::PARAM_BOOL;
            } else if (is_float($value)) {
                // 浮点数在PDO中使用字符串类型
                $pdoType = PDO::PARAM_STR;
            } else if (is_string($value)) {
                // 检查字符串长度（可选配置）
                if (isset($this->config['max_string_length']) && 
                    strlen($value) > $this->config['max_string_length']) {
                    throw new DatabaseException('字符串参数过长', 400);
                }
            } else if (is_array($value)) {
                // 自动将数组转换为JSON
                $value = json_encode($value);
                $pdoType = PDO::PARAM_STR;
            }
        }
        
        return [$value, $pdoType];
    }
    
    /**
     * 验证SQL语句基本格式
     * @param string $sql SQL语句
     * @return bool 是否有效
     */
    private function isValidSQL($sql) {
        // 基本验证
        if (!is_string($sql) || empty(trim($sql))) {
            return false;
        }
        
        // 检查SQL关键字
        $sqlLower = strtolower(trim($sql));
        $validStarters = ['select', 'insert', 'update', 'delete', 'replace', 'call', 'show'];
        
        foreach ($validStarters as $starter) {
            if (strpos($sqlLower, $starter) === 0) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 检查JSON格式是否有效
     * @param string $json JSON字符串
     * @return bool 是否有效
     */
    private function isValidJSON($json) {
        if (!is_string($json)) {
            return false;
        }
        
        json_decode($json);
        return json_last_error() === JSON_ERROR_NONE;
    }
    
    /**
     * 为日志清理SQL语句
     * @param string $sql SQL语句
     * @return string 清理后的SQL
     */
    private function sanitizeSQLForLog($sql) {
        // 移除可能的注释
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        $sql = preg_replace('/--.*$/m', '', $sql);
        
        // 保留前200个字符用于日志
        return substr($sql, 0, 200) . (strlen($sql) > 200 ? '...' : '');
    }
    
    /**
     * 检查结果集大小
     * @param PDOStatement $stmt 语句对象
     * @param string $sql SQL语句
     */
    private function checkResultSetSize($stmt, $sql) {
        // 仅对SELECT查询检查结果集大小
        if (stripos($sql, 'SELECT') === 0) {
            $rowCount = $stmt->rowCount();
            
            // 如果配置了最大结果集大小限制
            if (isset($this->config['max_result_set_size']) && 
                $rowCount > $this->config['max_result_set_size']) {
                if (class_exists('LogManager')) {
                    LogManager::log('WARNING', '查询结果集过大', [
                        'row_count' => $rowCount,
                        'max_allowed' => $this->config['max_result_set_size']
                    ]);
                }
            }
        }
    }
    
    /**
     * 日志记录慢查询
     * @param string $sql SQL语句
     * @param array $params 参数
     * @param float $executionTime 执行时间（毫秒）
     * @param string $type 查询类型
     */
    private function logSlowQuery($sql, array $params, $executionTime, $type) {
        $safeParams = $this->maskSensitiveData($params);
        
        if (class_exists('LogManager')) {
            LogManager::log('WARNING', '慢查询检测', [
                'execution_time' => $executionTime,
                'sql' => $this->sanitizeSQLForLog($sql),
                'params' => $safeParams,
                'query_type' => $type
            ]);
        }
    }
    
    /**
     * 掩码敏感数据
     * @param array $data 数据数组
     * @return array 处理后的数据
     */
    private function maskSensitiveData(array $data) {
        $masked = [];
        $sensitiveFields = ['password', 'token', 'credit', 'card', 'ssn', 'secret', 'key'];
        
        foreach ($data as $key => $value) {
            // 检查是否包含敏感字段名
            $isSensitive = false;
            $keyLower = strtolower(is_string($key) ? $key : '');
            
            foreach ($sensitiveFields as $sensitive) {
                if (strpos($keyLower, $sensitive) !== false) {
                    $isSensitive = true;
                    break;
                }
            }
            
            if ($isSensitive && is_string($value) && strlen($value) > 4) {
                // 掩码敏感值，仅保留首尾字符
                $masked[$key] = substr($value, 0, 2) . str_repeat('*', max(0, strlen($value) - 4)) . substr($value, -2);
            } else if (is_array($value)) {
                // 递归处理嵌套数组
                $masked[$key] = $this->maskSensitiveData($value);
            } else {
                $masked[$key] = $value;
            }
        }
        
        return $masked;
    }
    
    /**
     * 日志记录错误
     * @param string $message 错误信息
     * @param string $sql SQL语句
     * @param array $params 参数
     */
    private function logError($message, $sql, array $params) {
        if (class_exists('LogManager')) {
            LogManager::log('ERROR', $message, [
                'sql' => $this->sanitizeSQLForLog($sql),
                'params_count' => count($params),
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        }
    }
    
    /**
     * 开始事务
     * @return bool 是否成功
     */
    public function beginTransaction() {
        if (!$this->masterDb) {
            return false;
        }
        
        return $this->masterDb->beginTransaction();
    }
    
    /**
     * 提交事务
     * @return bool 是否成功
     */
    public function commit() {
        if (!$this->masterDb) {
            return false;
        }
        
        return $this->masterDb->commit();
    }
    
    /**
     * 回滚事务
     * @return bool 是否成功
     */
    public function rollBack() {
        if (!$this->masterDb) {
            return false;
        }
        
        return $this->masterDb->rollBack();
    }
    
    /**
     * 获取最后插入的ID
     * @param string $name 序列名称（可选）
     * @return string 最后插入的ID
     */
    public function lastInsertId($name = null) {
        if (!$this->masterDb) {
            return 0;
        }
        
        return $this->masterDb->lastInsertId($name);
    }
    
    /**
     * 获取查询统计信息
     * @return array 统计数据
     */
    public function getStats() {
        // 计算一些额外统计数据
        $totalQueries = $this->stats['master_queries'] + $this->stats['slave_queries'];
        $slaveRatio = $totalQueries > 0 ? ($this->stats['slave_queries'] / $totalQueries * 100) : 0;
        
        return [
            'master_queries' => $this->stats['master_queries'],
            'slave_queries' => $this->stats['slave_queries'],
            'slave_ratio' => round($slaveRatio, 2),
            'master_failures' => $this->stats['master_failures'],
            'slave_failures' => $this->stats['slave_failures'],
            'failover_count' => $this->stats['failover_count'],
            'last_failover_time' => $this->stats['last_failover_time'],
            'total_queries' => $totalQueries,
            'active_slaves' => count($this->slaveDbs) - count($this->failedSlaves),
            'failed_slaves' => count($this->failedSlaves)
        ];
    }
    
    /**
     * 重置统计信息
     */
    public function resetStats() {
        $this->stats = [
            'master_queries' => 0,
            'slave_queries' => 0,
            'master_failures' => 0,
            'slave_failures' => 0,
            'failover_count' => $this->stats['failover_count'], // 保持故障转移计数
            'last_failover_time' => $this->stats['last_failover_time'] // 保持最后故障转移时间
        ];
    }
    
    /**
     * 重新连接数据库
     */
    public function reconnect() {
        // 关闭所有现有连接
        $this->closeAllConnections();
        
        // 重新初始化连接
        $this->initConnections();
    }
    
    /**
     * 关闭所有数据库连接
     */
    public function closeAllConnections() {
        // 关闭从库连接
        foreach ($this->slaveDbs as $slaveDb) {
            if ($slaveDb instanceof PDO) {
                try {
                    $slaveDb = null; // PHP的PDO会自动关闭连接
                } catch (Exception $e) {
                    // 忽略关闭连接时的错误
                }
            }
        }
        
        // 关闭主库连接
        if ($this->masterDb instanceof PDO) {
            try {
                $this->masterDb = null;
            } catch (Exception $e) {
                // 忽略关闭连接时的错误
            }
        }
        
        $this->slaveDbs = [];
    }
    
    /**
     * 获取主库连接（高级用法）
     * @return PDO|null 主库连接对象
     */
    public function getMasterConnection() {
        return $this->masterDb;
    }
    
    /**
     * 获取从库连接数组（高级用法）
     * @return array 从库连接数组
     */
    public function getSlaveConnections() {
        return $this->slaveDbs;
    }
    
    /**
     * 动态设置是否使用从库
     * @param bool $useSlaves 是否使用从库
     */
    public function setUseSlaves($useSlaves) {
        $this->config['use_slaves'] = $useSlaves;
    }
    
    /**
     * 动态设置是否对读操作使用主库
     * @param bool $useMaster 是否使用主库
     */
    public function setUseMasterForReads($useMaster) {
        $this->config['use_master_for_reads'] = $useMaster;
    }
    
    /**
     * 获取当前配置
     * @return array 配置信息
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 设置查询数量阈值
     * @param int $threshold 阈值
     */
    public function setReadThreshold($threshold) {
        $this->useSlaveThreshold = $threshold;
    }
    
    /**
     * 析构函数
     */
    public function __destruct() {
        $this->closeAllConnections();
    }
}