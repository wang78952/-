<?php
/**
 * 导入管理器
 * 处理CSV、Excel、JSON等格式的数据导入功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/SecurityUtils.php';

// 导入异常处理相关类
require_once __DIR__ . '/exception/ExceptionHandler.php';
require_once __DIR__ . '/exception/LogManager.php';

class ImportManager extends BaseService {
    protected $logger;
    private $allowedFormats = array('csv', 'xlsx', 'xls', 'json', 'txt');
    private $maxFileSize = 10 * 1024 * 1024; // 10MB
    
    public function __construct($database = null, $logger = null) {
        parent::__construct();
        if ($database) {
            $this->database = $database;
        }
        $this->logger = $logger ? $logger : new Logger();
    }
    
    /**
     * 检查文件是否安全
     * @param string $filePath 文件路径
     * @return bool 是否安全
     */
    private function isSecureFile($filePath) {
        // 基本的MIME类型检查
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $filePath);
        finfo_close($finfo);
        
        // 只允许CSV和Excel相关的MIME类型
        $allowedMimeTypes = [
            'text/csv',
            'text/plain',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];
        
        return in_array($mimeType, $allowedMimeTypes);
    }
    
    /**
     * 导入卡密数据
     */
    public function importCards($file, $options = array()) {
        $context = [
            'file_name' => $this->cleanSensitiveData($file['name']),
            'file_size' => $file['size'],
            'import_type' => 'cards',
            'options' => $this->cleanSensitiveData($options)
        ];
        
        try {
            // 验证文件
            $validationResult = $this->validateImportFile($file);
            if (!$validationResult['success']) {
                throw new ValidationException($validationResult['error'], 400, null, $context);
            }
            
            // 读取和解析文件
            $fileData = $this->parseImportFile($file);
            
            // 验证数据
            $validatedData = $this->validateCardData($fileData);
            
            // 导入数据
            $result = $this->importCardData($validatedData, $options);
            
            // 记录成功日志
            $this->logManager->logInfo(
                'card_import_success', 
                '卡密数据导入成功', 
                array_merge($context, [
                    'imported_count' => $result['imported_count'],
                    'failed_count' => $result['failed_count'],
                    'duplicate_count' => $result['duplicate_count']
                ])
            );
            
            return $result;
            
        } catch (ValidationException $e) {
            // 记录验证错误日志
            $this->logManager->logWarning(
                'card_import_validation_error', 
                '卡密数据导入验证失败', 
                array_merge($context, ['error' => $e->getMessage()])
            );
            
            return ['success' => false, 'error' => $e->getMessage(), 'error_code' => $e->getCode()];
            
        } catch (FileNotFoundException $e) {
            // 记录文件错误日志
            $this->logManager->logError(
                'card_import_file_error', 
                '卡密数据导入文件错误', 
                array_merge($context, ['error' => $e->getMessage()])
            );
            
            return ['success' => false, 'error' => '文件不存在或无法访问', 'error_code' => $e->getCode()];
            
        } catch (Exception $e) {
            // 记录未预期的错误
            $errorId = $this->exceptionHandler->handleException($e, 'card_import', $context);
            
            return ['success' => false, 'error' => '导入过程中发生错误，请联系管理员 (错误ID: ' . $errorId . ')', 'error_code' => 500];
        }
    }
    
    /**
     * 导入产品数据
     */
    public function importProducts($file, $options = array()) {
        $context = [
            'file_name' => $this->cleanSensitiveData($file['name']),
            'file_size' => $file['size'],
            'import_type' => 'products',
            'options' => $this->cleanSensitiveData($options)
        ];
        
        try {
            // 验证文件
            $validationResult = $this->validateImportFile($file);
            if (!$validationResult['success']) {
                throw new ValidationException($validationResult['error'], 400, null, $context);
            }
            
            // 读取和解析文件
            $fileData = $this->parseImportFile($file);
            
            // 验证数据
            $validatedData = $this->validateProductData($fileData);
            
            // 导入数据
            $result = $this->importProductData($validatedData, $options);
            
            // 记录成功日志
            $this->logManager->logInfo(
                'product_import_success', 
                '产品数据导入成功', 
                array_merge($context, [
                    'imported_count' => $result['imported_count'],
                    'failed_count' => $result['failed_count']
                ])
            );
            
            return $result;
            
        } catch (ValidationException $e) {
            // 记录验证错误日志
            $this->logManager->logWarning(
                'product_import_validation_error', 
                '产品数据导入验证失败', 
                array_merge($context, ['error' => $e->getMessage()])
            );
            
            return ['success' => false, 'error' => $e->getMessage(), 'error_code' => $e->getCode()];
            
        } catch (Exception $e) {
            // 记录未预期的错误
            $errorId = $this->exceptionHandler->handleException($e, 'product_import', $context);
            
            return ['success' => false, 'error' => '导入过程中发生错误，请联系管理员 (错误ID: ' . $errorId . ')', 'error_code' => 500];
        }
    }
    
    /**
     * 导入用户数据
     */
    public function importUsers($file, $options = array()) {
        $context = [
            'file_name' => $this->cleanSensitiveData($file['name']),
            'file_size' => $file['size'],
            'import_type' => 'users',
            'options' => $this->cleanSensitiveData($options)
        ];
        
        try {
            // 验证文件
            $validationResult = $this->validateImportFile($file);
            if (!$validationResult['success']) {
                throw new ValidationException($validationResult['error'], 400, null, $context);
            }
            
            // 读取和解析文件
            $fileData = $this->parseImportFile($file);
            
            // 验证数据
            $validatedData = $this->validateUserData($fileData);
            
            // 导入数据
            $result = $this->importUserData($validatedData, $options);
            
            // 记录成功日志
            $this->logManager->logInfo(
                'user_import_success', 
                '用户数据导入成功', 
                array_merge($context, [
                    'imported_count' => $result['imported_count'],
                    'failed_count' => $result['failed_count']
                ])
            );
            
            return $result;
            
        } catch (ValidationException $e) {
            // 记录验证错误日志
            $this->logManager->logWarning(
                'user_import_validation_error', 
                '用户数据导入验证失败', 
                array_merge($context, ['error' => $e->getMessage()])
            );
            
            return ['success' => false, 'error' => $e->getMessage(), 'error_code' => $e->getCode()];
            
        } catch (SecurityException $e) {
            // 记录安全相关错误
            $this->logManager->logSecurity(
                'user_import_security_violation', 
                '用户数据导入安全违规', 
                array_merge($context, ['error' => $e->getMessage()])
            );
            
            return ['success' => false, 'error' => '导入数据中包含安全风险', 'error_code' => $e->getCode()];
            
        } catch (Exception $e) {
            // 记录未预期的错误
            $errorId = $this->exceptionHandler->handleException($e, 'user_import', $context);
            
            return ['success' => false, 'error' => '导入过程中发生错误，请联系管理员 (错误ID: ' . $errorId . ')', 'error_code' => 500];
        }
    }
    
    /**
     * 验证上传文件
     */
    private function validateFile($file) {
        // 检查文件是否存在
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new Exception('文件上传失败');
        }
        
        // 检查文件大小
        if ($file['size'] > $this->maxFileSize) {
            throw new Exception('文件大小超过限制（最大10MB）');
        }
        
        // 检查文件扩展名
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $this->allowedFormats)) {
            throw new Exception('不支持的文件格式，仅支持：' . implode(', ', $this->allowedFormats));
        }
        
        // 安全检查
        if (!$this->isSecureFile($file['tmp_name'])) {
            throw new Exception('文件安全检查失败');
        }
        
        return array(
            'name' => $file['name'],
            'tmp_name' => $file['tmp_name'],
            'size' => $file['size'],
            'extension' => $extension
        );
    }
    
    /**
     * 解析文件
     */
    private function parseFile($filePath, $extension) {
        switch ($extension) {
            case 'csv':
                return $this->parseCSV($filePath);
            case 'xlsx':
            case 'xls':
                return $this->parseExcel($filePath);
            case 'json':
                return $this->parseJSON($filePath);
            case 'txt':
                return $this->parseTXT($filePath);
            default:
                throw new Exception('不支持的文件格式');
        }
    }
    
    /**
     * 解析TXT文件
     */
    private function parseTXT($filePath) {
        $data = array();
        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        if ($lines === false) {
            throw new Exception('无法打开TXT文件');
        }
        
        // 对于简单TXT文件，每一行作为一个卡密
        foreach ($lines as $line) {
            $line = trim($line);
            if (!empty($line)) {
                $data[] = array(
                    'card_code' => $line, // 单行模式下，行内容即为卡密
                    'line_content' => $line // 保留原始行内容
                );
            }
        }
        
        return $data;
        }
    }
    
    /**
     * 从卡密数据中移除重复项
     */
    private function removeDuplicatesFromCardData($data) {
        $uniqueData = array();
        $seenCardCodes = array();
        
        foreach ($data as $item) {
            $cardCode = $item['card_code'] ?? '';
            if (!empty($cardCode) && !isset($seenCardCodes[$cardCode])) {
                $seenCardCodes[$cardCode] = true;
                $uniqueData[] = $item;
            }
        }
        
        return $uniqueData;
    }
    
    /**
     * 生成失败数据的CSV文件供下载
     */
    private function generateFailedRowsCSV($failedRows) {
        // 创建导出目录
        $exportDir = __DIR__ . '/../exports/failed_imports/';
        if (!is_dir($exportDir)) {
            mkdir($exportDir, 0755, true);
        }
        
        // 生成文件名
        $filename = 'failed_cards_' . date('YmdHis') . '.csv';
        $filePath = $exportDir . $filename;
        
        // 创建CSV文件
        $handle = fopen($filePath, 'w');
        if (!$handle) {
            $this->logger->logError('无法创建失败数据CSV文件');
            return null;
        }
        
        // 写入表头
        fputcsv($handle, array('行号', '卡密', '错误信息'));
        
        // 写入数据
        foreach ($failedRows as $failedRow) {
            $cardCode = $failedRow['data']['card_code'] ?? '';
            $errors = implode('; ', $failedRow['errors']);
            
            fputcsv($handle, array($failedRow['row'], $cardCode, $errors));
        }
        
        fclose($handle);
        
        // 返回相对URL
        return '/exports/failed_imports/' . $filename;
    }
    
/**
     * 从粘贴的文本导入卡密
     */
    public function importCardsFromText($text, $productId, $options = array()) {
        try {
            // 记录导入开始
            $this->logger->logInfo("开始从粘贴文本导入卡密", array(
                'text_length' => strlen($text),
                'product_id' => $productId
            ));
            
            // 按行分割文本
            $lines = explode("\n", $text);
            $data = array();
            
            foreach ($lines as $line) {
                $line = trim($line);
                if (!empty($line)) {
                    $data[] = array(
                        'card_code' => $line,
                        'product_id' => $productId, // 从参数传入产品ID
                        'line_content' => $line
                    );
                }
            }
            
            // 去重处理
            $uniqueData = $this->removeDuplicatesFromCardData($data);
            
            // 验证数据
            $validatedData = $this->validateCardData($uniqueData);
            
            // 导入数据
            $result = $this->importCardData($validatedData, $options);
            
            // 增强结果数据
            $result['total_lines'] = count($lines);
            $result['non_empty_lines'] = count($data);
            $result['unique_count'] = count($uniqueData);
            $result['duplicate_count'] = count($data) - count($uniqueData);
            
            // 生成失败数据的CSV文件用于下载重试
            if ($result['failed_count'] > 0) {
                $result['failed_download_url'] = $this->generateFailedRowsCSV($result['failed_rows']);
            }
            
            $this->logger->logInfo("卡密文本导入完成", array(
                'total_lines' => $result['total_lines'],
                'imported_count' => $result['imported_count'],
                'failed_count' => $result['failed_count'],
                'duplicate_count' => $result['duplicate_count']
            ));
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->logError("卡密文本导入失败", array(
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 解析CSV文件
     */
    private function parseCSV($filePath) {
        $data = array();
        $handle = fopen($filePath, 'r');
        
        if (!$handle) {
            throw new Exception('无法打开CSV文件');
        }
        
        // 读取标题行
        $headers = fgetcsv($handle);
        if ($headers === false) {
            fclose($handle);
            throw new Exception('CSV文件格式错误');
        }
        
        // 清理标题
        $headers = array_map('trim', $headers);
        
        // 读取数据行
        $rowIndex = 1;
        while (($row = fgetcsv($handle)) !== false) {
            $rowIndex++;
            
            // 跳过空行
            if (empty(array_filter($row))) {
                continue;
            }
            
            // 确保行列数一致
            if (count($row) !== count($headers)) {
                fclose($handle);
                throw new Exception("第{$rowIndex}行列数不匹配");
            }
            
            $data[] = array_combine($headers, $row);
        }
        
        fclose($handle);
        return $data;
    }
    
    /**
     * 解析Excel文件
     */
    private function parseExcel($filePath) {
        // 这里应该集成PhpSpreadsheet库
        // 为了演示，返回模拟数据
        throw new Exception('Excel文件解析功能需要PhpSpreadsheet库支持');
    }
    
    /**
     * 解析JSON文件
     */
    private function parseJSON($filePath) {
        $content = file_get_contents($filePath);
        if ($content === false) {
            throw new Exception('无法读取JSON文件');
        }
        
        $data = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('JSON文件格式错误：' . json_last_error_msg());
        }
        
        if (!is_array($data)) {
            throw new Exception('JSON文件必须包含数组数据');
        }
        
        return $data;
    }
    
    /**
     * 验证卡密数据
     */
    private function validateCardData($data) {
        $validatedData = array();
        $requiredFields = array('card_code', 'product_id');
        
        foreach ($data as $index => $row) {
            $errors = array();
            
            // 检查必填字段
            foreach ($requiredFields as $field) {
                if (empty($row[$field])) {
                    $errors[] = "缺少必填字段：{$field}";
                }
            }
            
            // 验证产品ID
            if (!empty($row['product_id'])) {
                $product = $this->database->fetch(
                    "SELECT id FROM products WHERE id = ?", 
                    array($row['product_id'])
                );
                if (!$product) {
                    $errors[] = "产品ID不存在：{$row['product_id']}";
                }
            }
            
            // 验证卡密格式
            if (!empty($row['card_code'])) {
                if (strlen($row['card_code']) < 6) {
                    $errors[] = "卡密长度至少6位";
                }
                
                // 检查卡密是否已存在
                $existingCard = $this->database->fetch(
                    "SELECT id FROM cards WHERE card_code = ?", 
                    array($row['card_code'])
                );
                if ($existingCard) {
                    $errors[] = "卡密已存在：{$row['card_code']}";
                }
            }
            
            $validatedData[] = array(
                'row_index' => $index + 1,
                'data' => $row,
                'errors' => $errors,
                'valid' => empty($errors)
            );
        }
        
        return $validatedData;
    }
    
    /**
     * 验证产品数据
     */
    private function validateProductData($data) {
        $validatedData = array();
        $requiredFields = array('name', 'price');
        
        foreach ($data as $index => $row) {
            $errors = array();
            
            // 检查必填字段
            foreach ($requiredFields as $field) {
                if (empty($row[$field])) {
                    $errors[] = "缺少必填字段：{$field}";
                }
            }
            
            // 验证价格
            if (!empty($row['price'])) {
                if (!is_numeric($row['price']) || $row['price'] < 0) {
                    $errors[] = "价格必须为非负数";
                }
            }
            
            // 验证产品名称
            if (!empty($row['name'])) {
                if (strlen($row['name']) > 255) {
                    $errors[] = "产品名称不能超过255个字符";
                }
                
                // 检查产品名称是否已存在
                $existingProduct = $this->database->fetch(
                    "SELECT id FROM products WHERE name = ?", 
                    array($row['name'])
                );
                if ($existingProduct) {
                    $errors[] = "产品名称已存在：{$row['name']}";
                }
            }
            
            $validatedData[] = array(
                'row_index' => $index + 1,
                'data' => $row,
                'errors' => $errors,
                'valid' => empty($errors)
            );
        }
        
        return $validatedData;
    }
    
    /**
     * 验证用户数据
     */
    private function validateUserData($data) {
        $validatedData = array();
        $requiredFields = array('username', 'email');
        
        foreach ($data as $index => $row) {
            $errors = array();
            
            // 检查必填字段
            foreach ($requiredFields as $field) {
                if (empty($row[$field])) {
                    $errors[] = "缺少必填字段：{$field}";
                }
            }
            
            // 验证用户名
            if (!empty($row['username'])) {
                if (strlen($row['username']) < 3 || strlen($row['username']) > 50) {
                    $errors[] = "用户名长度必须在3-50个字符之间";
                }
                
                if (!preg_match('/^[a-zA-Z0-9_]+$/', $row['username'])) {
                    $errors[] = "用户名只能包含字母、数字和下划线";
                }
                
                // 检查用户名是否已存在
                $existingUser = $this->database->fetch(
                    "SELECT id FROM users WHERE username = ?", 
                    array($row['username'])
                );
                if ($existingUser) {
                    $errors[] = "用户名已存在：{$row['username']}";
                }
            }
            
            // 验证邮箱
            if (!empty($row['email'])) {
                if (!filter_var($row['email'], FILTER_VALIDATE_EMAIL)) {
                    $errors[] = "邮箱格式不正确";
                }
                
                // 检查邮箱是否已存在
                $existingEmail = $this->database->fetch(
                    "SELECT id FROM users WHERE email = ?", 
                    array($row['email'])
                );
                if ($existingEmail) {
                    $errors[] = "邮箱已存在：{$row['email']}";
                }
            }
            
            $validatedData[] = array(
                'row_index' => $index + 1,
                'data' => $row,
                'errors' => $errors,
                'valid' => empty($errors)
            );
        }
        
        return $validatedData;
    }
    
    /**
     * 导入卡密数据 - 增强版，支持去重和详细统计
     */
    private function importCardData($validatedData, $options) {
        $importedCount = 0;
        $failedCount = 0;
        $failedRows = array();
        
        // 提取原始数据用于去重计算
        $originalData = array();
        foreach ($validatedData as $item) {
            if (isset($item['data']['card_code'])) {
                $originalData[] = $item['data'];
            }
        }
        
        // 计算去重前的总数
        $totalCount = count($originalData);
        
        // 执行去重
        $uniqueData = $this->removeDuplicatesFromCardData($originalData);
        $duplicateCount = $totalCount - count($uniqueData);
        
        // 创建去重后的数据映射，用于匹配到原始validatedData条目
        $uniqueCardCodes = array_flip(array_column($uniqueData, 'card_code'));
        
        $this->database->beginTransaction();
        
        try {
            foreach ($validatedData as $item) {
                // 跳过重复项
                if (!isset($item['data']['card_code']) || !isset($uniqueCardCodes[$item['data']['card_code']])) {
                    continue;
                }
                
                if (!$item['valid']) {
                    $failedCount++;
                    $failedRows[] = array(
                        'row' => $item['row_index'],
                        'data' => $item['data'],
                        'errors' => $item['errors']
                    );
                    continue;
                }
                
                $data = $item['data'];
                
                // 准备插入数据
                $insertData = array(
                    'card_code' => $data['card_code'],
                    'product_id' => $data['product_id'],
                    'status' => isset($data['status']) ? $data['status'] : 'available',
                    'created_at' => date('Y-m-d H:i:s')
                );
                
                // 添加可选字段
                if (isset($data['user_id'])) {
                    $insertData['user_id'] = $data['user_id'];
                }
                if (isset($data['expires_at'])) {
                    $insertData['expires_at'] = $data['expires_at'];
                }
                if (isset($data['notes'])) {
                    $insertData['notes'] = $data['notes'];
                }
                
                $result = $this->database->insert('cards', $insertData);
                
                if ($result) {
                    $importedCount++;
                } else {
                    $failedCount++;
                    $failedRows[] = array(
                        'row' => $item['row_index'],
                        'data' => $item['data'],
                        'errors' => array('数据库插入失败')
                    );
                }
            }
            
            $this->database->commit();
            
        } catch (Exception $e) {
            $this->database->rollback();
            throw new Exception('导入过程中发生错误：' . $e->getMessage());
        }
        
        // 生成失败数据文件（如果有）
            $failedDownloadUrl = null;
            if (!empty($failedRows)) {
                $failedDownloadUrl = $this->generateFailedRowsCSV($failedRows);
            }
            
            return array(
                'success' => true,
                'total_count' => $totalCount,
                'imported_count' => $importedCount,
                'failed_count' => $failedCount,
                'duplicate_count' => $duplicateCount,
                'failed_rows' => $failedRows,
                'failed_download_url' => $failedDownloadUrl
            );
    }
    
    /**
     * 导入产品数据
     */
    private function importProductData($validatedData, $options) {
        $importedCount = 0;
        $failedCount = 0;
        $failedRows = array();
        
        $this->database->beginTransaction();
        
        try {
            foreach ($validatedData as $item) {
                if (!$item['valid']) {
                    $failedCount++;
                    $failedRows[] = array(
                        'row' => $item['row_index'],
                        'data' => $item['data'],
                        'errors' => $item['errors']
                    );
                    continue;
                }
                
                $data = $item['data'];
                
                // 准备插入数据
                $insertData = array(
                    'name' => $data['name'],
                    'price' => $data['price'],
                    'description' => isset($data['description']) ? $data['description'] : '',
                    'category_id' => isset($data['category_id']) ? $data['category_id'] : null,
                    'status' => isset($data['status']) ? $data['status'] : 'active',
                    'created_at' => date('Y-m-d H:i:s')
                );
                
                // 添加可选字段
                if (isset($data['stock'])) {
                    $insertData['stock'] = $data['stock'];
                }
                if (isset($data['image_url'])) {
                    $insertData['image_url'] = $data['image_url'];
                }
                
                $result = $this->database->insert('products', $insertData);
                
                if ($result) {
                    $importedCount++;
                } else {
                    $failedCount++;
                    $failedRows[] = array(
                        'row' => $item['row_index'],
                        'data' => $item['data'],
                        'errors' => array('数据库插入失败')
                    );
                }
            }
            
            $this->database->commit();
            
        } catch (Exception $e) {
            $this->database->rollback();
            throw new Exception('导入过程中发生错误：' . $e->getMessage());
        }
        
        return array(
            'success' => true,
            'imported_count' => $importedCount,
            'failed_count' => $failedCount,
            'failed_rows' => $failedRows
        );
    }
    
    /**
     * 导入用户数据
     */
    private function importUserData($validatedData, $options) {
        $importedCount = 0;
        $failedCount = 0;
        $failedRows = array();
        
        $this->database->beginTransaction();
        
        try {
            foreach ($validatedData as $item) {
                if (!$item['valid']) {
                    $failedCount++;
                    $failedRows[] = array(
                        'row' => $item['row_index'],
                        'data' => $item['data'],
                        'errors' => $item['errors']
                    );
                    continue;
                }
                
                $data = $item['data'];
                
                // 准备插入数据
                $insertData = array(
                    'username' => $data['username'],
                    'email' => $data['email'],
                    'password' => password_hash(isset($data['password']) ? $data['password'] : '123456', PASSWORD_DEFAULT),
                    'role' => isset($data['role']) ? $data['role'] : 'user',
                    'status' => isset($data['status']) ? $data['status'] : 'active',
                    'created_at' => date('Y-m-d H:i:s')
                );
                
                // 添加可选字段
                if (isset($data['phone'])) {
                    $insertData['phone'] = $data['phone'];
                }
                if (isset($data['real_name'])) {
                    $insertData['real_name'] = $data['real_name'];
                }
                
                $result = $this->database->insert('users', $insertData);
                
                if ($result) {
                    $importedCount++;
                } else {
                    $failedCount++;
                    $failedRows[] = array(
                        'row' => $item['row_index'],
                        'data' => $item['data'],
                        'errors' => array('数据库插入失败')
                    );
                }
            }
            
            $this->database->commit();
            
        } catch (Exception $e) {
            $this->database->rollback();
            throw new Exception('导入过程中发生错误：' . $e->getMessage());
        }
        
        return array(
            'success' => true,
            'imported_count' => $importedCount,
            'failed_count' => $failedCount,
            'failed_rows' => $failedRows
        );
    }
    
    /**
     * 获取导入模板
     */
    public function getImportTemplate($type) {
        $templates = array(
            'cards' => array(
                'headers' => array('card_code', 'product_id', 'batch_id'),
                'example' => array(
                    array('ABC123456789', '1', '0'),
                    array('DEF987654321', '1', '0')
                )
            ),
            'products' => array(
                'headers' => array('name', 'price', 'description', 'category_id', 'stock'),
                'example' => array(
                    array('测试产品1', '99.99', '这是一个测试产品', '1', '100'),
                    array('测试产品2', '199.99', '这是另一个测试产品', '2', '50')
                )
            ),
            'users' => array(
                'headers' => array('username', 'email', 'password', 'role'),
                'example' => array(
                    array('test1', 'test1@example.com', 'password123', 'user'),
                    array('test2', 'test2@example.com', 'password456', 'user')
                )
            )
        );
        
        return isset($templates[$type]) ? $templates[$type] : null;
    }
    
    /**
     * 导出卡密数据为Excel格式 - 支持自定义字段
     */
    public function exportCardsToExcel($filters, $selectedFields) {
        try {
            // 1. 构建查询条件
            $whereClause = '';
            $params = array();
            
            if (!empty($filters['product_id'])) {
                $whereClause .= ' AND product_id = ?';
                $params[] = $filters['product_id'];
            }
            
            if (!empty($filters['status'])) {
                $whereClause .= ' AND status = ?';
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['start_date'])) {
                $whereClause .= ' AND created_at >= ?';
                $params[] = $filters['start_date'];
            }
            
            if (!empty($filters['end_date'])) {
                $whereClause .= ' AND created_at <= ?';
                $params[] = $filters['end_date'] . ' 23:59:59';
            }
            
            // 2. 获取可选字段定义
            $availableFields = $this->getCardAvailableFields();
            
            // 3. 验证并处理所选字段
            $validFields = array();
            foreach ($selectedFields as $field) {
                if (isset($availableFields[$field])) {
                    $validFields[] = $availableFields[$field]['sql'] . ' AS ' . $field;
                }
            }
            
            // 如果没有选择字段，使用默认字段
            if (empty($validFields)) {
                $defaultFields = array('id', 'card_code', 'status', 'created_at');
                foreach ($defaultFields as $field) {
                    $validFields[] = $availableFields[$field]['sql'] . ' AS ' . $field;
                }
            }
            
            // 4. 构建并执行查询
            $fieldsStr = implode(', ', $validFields);
            $query = "SELECT {$fieldsStr} FROM cards WHERE 1=1 {$whereClause}";
            
            if (!empty($filters['limit'])) {
                $query .= ' LIMIT ' . intval($filters['limit']);
            }
            
            $cardsData = $this->database->fetchAll($query, $params);
            
            // 5. 生成Excel文件
            $exportDir = __DIR__ . '/../exports/';
            if (!is_dir($exportDir)) {
                mkdir($exportDir, 0755, true);
            }
            
            // 使用CSV作为替代（如果没有PhpSpreadsheet）
            $filename = 'cards_export_' . date('YmdHis') . '.csv';
            $filePath = $exportDir . $filename;
            
            $handle = fopen($filePath, 'w');
            if (!$handle) {
                return array('success' => false, 'error' => '无法创建导出文件');
            }
            
            // 写入表头
            $headers = array();
            foreach ($selectedFields as $field) {
                if (isset($availableFields[$field])) {
                    $headers[] = $availableFields[$field]['label'];
                }
            }
            
            if (empty($headers)) {
                foreach (array('id', 'card_code', 'status', 'created_at') as $field) {
                    $headers[] = $availableFields[$field]['label'];
                }
            }
            
            fputcsv($handle, $headers);
            
            // 写入数据
            foreach ($cardsData as $card) {
                // 处理数据格式
                $row = array();
                foreach ($selectedFields as $field) {
                    if (isset($card[$field])) {
                        // 根据字段类型格式化数据
                        if ($field == 'status') {
                            $statusMap = array(0 => '未使用', 1 => '已使用', 2 => '已过期', 3 => '已禁用');
                            $row[] = isset($statusMap[$card[$field]]) ? $statusMap[$card[$field]] : $card[$field];
                        } else if (strpos($field, '_at') !== false) {
                            $row[] = date('Y-m-d H:i:s', strtotime($card[$field]));
                        } else {
                            $row[] = $card[$field];
                        }
                    }
                }
                
                if (empty($row)) {
                    // 默认字段输出
                    $defaultRow = array();
                    foreach (array('id', 'card_code', 'status', 'created_at') as $field) {
                        if (isset($card[$field])) {
                            if ($field == 'status') {
                                $statusMap = array(0 => '未使用', 1 => '已使用', 2 => '已过期', 3 => '已禁用');
                                $defaultRow[] = isset($statusMap[$card[$field]]) ? $statusMap[$card[$field]] : $card[$field];
                            } else {
                                $defaultRow[] = $card[$field];
                            }
                        }
                    }
                    fputcsv($handle, $defaultRow);
                } else {
                    fputcsv($handle, $row);
                }
            }
            
            fclose($handle);
            
            // 返回相对URL
            return array(
                'success' => true,
                'file_url' => '/exports/' . $filename,
                'total_exported' => count($cardsData)
            );
        } catch (Exception $e) {
            $this->logger->logError('导出卡密数据失败: ' . $e->getMessage());
            return array('success' => false, 'error' => $e->getMessage());
        }
    }
    
    /**
     * 获取卡密可用的导出字段定义
     */
    private function getCardAvailableFields() {
        return array(
            'id' => array('label' => 'ID', 'sql' => 'id'),
            'card_code' => array('label' => '卡密', 'sql' => 'card_code'),
            'product_id' => array('label' => '产品ID', 'sql' => 'product_id'),
            'batch_id' => array('label' => '批次ID', 'sql' => 'batch_id'),
            'status' => array('label' => '状态', 'sql' => 'status'),
            'created_at' => array('label' => '创建时间', 'sql' => 'created_at'),
            'used_at' => array('label' => '使用时间', 'sql' => 'used_at'),
            'expired_at' => array('label' => '过期时间', 'sql' => 'expired_at'),
            'user_id' => array('label' => '使用用户ID', 'sql' => 'user_id'),
            'card_type' => array('label' => '卡类型', 'sql' => '(SELECT card_type FROM card_batches WHERE id = cards.batch_id)'),
            'activation_status' => array('label' => '激活状态', 'sql' => 'activation_status'),
            'transfer_status' => array('label' => '转赠状态', 'sql' => 'transfer_status'),
            'transfer_code' => array('label' => '转赠码', 'sql' => 'transfer_code')
        );
    }
    
    /**
     * 导出卡密数据为TXT格式（默认格式）
     */
    public function exportCardsToTXT($filters) {
        try {
            // 构建查询条件
            $whereClause = '';
            $params = array();
            
            if (!empty($filters['product_id'])) {
                $whereClause .= ' AND product_id = ?';
                $params[] = $filters['product_id'];
            }
            
            if (!empty($filters['status'])) {
                $whereClause .= ' AND status = ?';
                $params[] = $filters['status'];
            }
            
            // 执行查询
            $query = "SELECT card_code, status, created_at, used_at FROM cards WHERE 1=1 {$whereClause}";
            $cardsData = $this->database->fetchAll($query, $params);
            
            // 生成TXT文件
            $exportDir = __DIR__ . '/../exports/';
            if (!is_dir($exportDir)) {
                mkdir($exportDir, 0755, true);
            }
            
            $filename = 'cards_export_' . date('YmdHis') . '.txt';
            $filePath = $exportDir . $filename;
            
            $handle = fopen($filePath, 'w');
            if (!$handle) {
                return array('success' => false, 'error' => '无法创建导出文件');
            }
            
            // 写入TXT格式数据（卡密+状态+时间）
            foreach ($cardsData as $card) {
                $statusMap = array(0 => '未使用', 1 => '已使用', 2 => '已过期', 3 => '已禁用');
                $statusText = isset($statusMap[$card['status']]) ? $statusMap[$card['status']] : $card['status'];
                $usedTime = !empty($card['used_at']) ? date('Y-m-d H:i:s', strtotime($card['used_at'])) : '未使用';
                
                $line = "卡密: {$card['card_code']}  状态: {$statusText}  创建时间: {$card['created_at']}  使用时间: {$usedTime}\n";
                fwrite($handle, $line);
            }
            
            fclose($handle);
            
            // 返回相对URL
            return array(
                'success' => true,
                'file_url' => '/exports/' . $filename,
                'total_exported' => count($cardsData)
            );
        } catch (Exception $e) {
            $this->logger->logError('导出卡密数据失败: ' . $e->getMessage());
            return array('success' => false, 'error' => $e->getMessage());
        }
    }
}