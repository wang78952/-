<?php
/**
 * Redis缓存管理器
 * 提供高性能的分布式缓存解决方案，支持缓存失效策略、键前缀、命中率统计等功能
 */

class RedisCache {
    private $redis;
    private $config;
    private $stats = array(
        'hits' => 0,
        'misses' => 0,
        'set_operations' => 0,
        'delete_operations' => 0,
        'errors' => 0
    );
    private $prefix = 'card_system:';
    private $defaultTtl = 3600; // 默认过期时间（秒）
    private $enabled = true;
    private $lastError = null;
    
    /**
     * 构造函数
     * @param array $config 配置参数
     */
    public function __construct(array $config = array()) {
        $this->config = array_merge(array(
            'host' => 'localhost',
            'port' => 6379,
            'timeout' => 0.5,
            'read_timeout' => 1,
            'database' => 0,
            'auth' => null,
            'prefix' => 'card_system:',
            'default_ttl' => 3600,
            'enabled' => true,
            'key_patterns' => array(
                'user:*' => 3600,
                'product:*' => 1800,
                'card:*' => 600,
                'category:*' => 7200,
                'config:*' => 86400,
                'stats:*' => 300,
                'order:*' => 900
            )
        ), $config);
        
        $this->prefix = $this->config['prefix'];
        $this->defaultTtl = $this->config['default_ttl'];
        $this->enabled = $this->config['enabled'];
        
        // 尝试连接Redis
        if ($this->enabled) {
            $this->connect();
        }
    }
    
    /**
     * 连接到Redis服务器
     */
    private function connect() {
        try {
            $this->redis = new Redis();
            $this->redis->connect(
                $this->config['host'],
                $this->config['port'],
                $this->config['timeout'],
                null, // 重试间隔
                null, // 读取超时
                $this->config['read_timeout']
            );
            
            // 认证
            if ($this->config['auth']) {
                $this->redis->auth($this->config['auth']);
            }
            
            // 选择数据库
            $this->redis->select($this->config['database']);
            
            return true;
        } catch (RedisException $e) {
            $this->lastError = $e->getMessage();
            $this->enabled = false; // 连接失败，禁用缓存
            error_log("Redis连接失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 生成带前缀的键名
     * @param string $key 原始键名
     * @return string 带前缀的键名
     */
    private function getKey($key) {
        return $this->prefix . $key;
    }
    
    /**
     * 根据键模式获取过期时间
     * @param string $key 键名
     * @return int 过期时间（秒）
     */
    private function getTtlByPattern($key) {
        foreach ($this->config['key_patterns'] as $pattern => $ttl) {
            // 将Redis模式转换为正则表达式
            $regex = '/^' . str_replace('*', '.*', preg_quote($pattern, '/')) . '$/';
            if (preg_match($regex, $key)) {
                return $ttl;
            }
        }
        return $this->defaultTtl;
    }
    
    /**
     * 设置缓存
     * @param string $key 键名
     * @param mixed $value 缓存值
     * @param int|null $ttl 过期时间（秒，null使用默认值）
     * @return bool 是否设置成功
     */
    public function set($key, $value, $ttl = null) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            $ttl = $ttl ?? $this->getTtlByPattern($key);
            
            // 序列化复杂数据类型
            $serializedValue = $this->serialize($value);
            
            // 设置缓存值和过期时间
            if ($ttl > 0) {
                $result = $this->redis->setex($fullKey, $ttl, $serializedValue);
            } else {
                $result = $this->redis->set($fullKey, $serializedValue);
            }
            
            if ($result) {
                $this->stats['set_operations']++;
            }
            
            return $result;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            error_log("Redis set operation failed for key '$key': " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取缓存
     * @param string $key 键名
     * @param mixed $default 默认值（缓存不存在时返回）
     * @return mixed 缓存值或默认值
     */
    public function get($key, $default = null) {
        if (!$this->enabled || !$this->redis) {
            return $default;
        }
        
        try {
            $fullKey = $this->getKey($key);
            $value = $this->redis->get($fullKey);
            
            if ($value !== false) {
                // 缓存命中
                $this->stats['hits']++;
                return $this->unserialize($value);
            } else {
                // 缓存未命中
                $this->stats['misses']++;
                return $default;
            }
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->stats['misses']++; // 发生错误视为未命中
            $this->lastError = $e->getMessage();
            error_log("Redis get operation failed for key '$key': " . $e->getMessage());
            return $default;
        }
    }
    
    /**
     * 批量获取缓存
     * @param array $keys 键名数组
     * @return array 键值对数组
     */
    public function getMultiple(array $keys) {
        if (!$this->enabled || !$this->redis) {
            return array_fill_keys($keys, null);
        }
        
        try {
            // 添加前缀到所有键
            $fullKeys = array_map(array($this, 'getKey'), $keys);
            
            // 批量获取
            $values = $this->redis->mget($fullKeys);
            $result = array();
            
            foreach ($keys as $index => $key) {
                if (isset($values[$index]) && $values[$index] !== false) {
                    $result[$key] = $this->unserialize($values[$index]);
                    $this->stats['hits']++;
                } else {
                    $result[$key] = null;
                    $this->stats['misses']++;
                }
            }
            
            return $result;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->stats['misses'] += count($keys);
            $this->lastError = $e->getMessage();
            error_log("Redis getMultiple operation failed: " . $e->getMessage());
            return array_fill_keys($keys, null);
        }
    }
    
    /**
     * 批量设置缓存
     * @param array $items 键值对数组
     * @param int|null $ttl 过期时间
     * @return bool 是否全部设置成功
     */
    public function setMultiple(array $items, $ttl = null) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        $pipe = $this->redis->multi(Redis::PIPELINE);
        $ttl = $ttl ?? $this->defaultTtl;
        
        try {
            foreach ($items as $key => $value) {
                $fullKey = $this->getKey($key);
                $serializedValue = $this->serialize($value);
                
                if ($ttl > 0) {
                    $pipe->setex($fullKey, $ttl, $serializedValue);
                } else {
                    $pipe->set($fullKey, $serializedValue);
                }
                
                $this->stats['set_operations']++;
            }
            
            $results = $pipe->exec();
            
            // 检查是否有失败的操作
            foreach ($results as $result) {
                if ($result === false) {
                    return false;
                }
            }
            
            return true;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            error_log("Redis setMultiple operation failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查键是否存在
     * @param string $key 键名
     * @return bool 是否存在
     */
    public function has($key) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            $exists = $this->redis->exists($fullKey);
            
            if ($exists) {
                $this->stats['hits']++;
            } else {
                $this->stats['misses']++;
            }
            
            return $exists;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return false;
        }
    }
    
    /**
     * 删除缓存
     * @param string $key 键名
     * @return bool 是否删除成功
     */
    public function delete($key) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            $result = $this->redis->del($fullKey);
            
            if ($result > 0) {
                $this->stats['delete_operations']++;
                return true;
            }
            
            return false;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            error_log("Redis delete operation failed for key '$key': " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 批量删除缓存
     * @param array $keys 键名数组
     * @return int 删除的键数量
     */
    public function deleteMultiple(array $keys) {
        if (!$this->enabled || !$this->redis) {
            return 0;
        }
        
        try {
            // 添加前缀到所有键
            $fullKeys = array_map(array($this, 'getKey'), $keys);
            
            // 批量删除
            $deleted = $this->redis->del($fullKeys);
            
            if ($deleted > 0) {
                $this->stats['delete_operations'] += $deleted;
            }
            
            return $deleted;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            error_log("Redis deleteMultiple operation failed: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * 根据模式删除缓存
     * @param string $pattern 键模式（如 'user:*'）
     * @return int 删除的键数量
     */
    public function deleteByPattern($pattern) {
        if (!$this->enabled || !$this->redis) {
            return 0;
        }
        
        try {
            $fullPattern = $this->prefix . $pattern;
            $keys = $this->redis->keys($fullPattern);
            
            if (empty($keys)) {
                return 0;
            }
            
            // 使用游标分批删除大量键，避免阻塞
            $pipe = $this->redis->multi(Redis::PIPELINE);
            $batchSize = 1000;
            $deleted = 0;
            
            foreach (array_chunk($keys, $batchSize) as $keyBatch) {
                $pipe->del($keyBatch);
                $deleted += count($keyBatch);
            }
            
            $pipe->exec();
            $this->stats['delete_operations'] += $deleted;
            
            return $deleted;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            error_log("Redis deleteByPattern operation failed for pattern '$pattern': " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * 清空所有缓存
     * @return bool 是否清空成功
     */
    public function clear() {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            // 只清除当前前缀的键，避免影响其他应用
            $pattern = $this->prefix . '*';
            $keys = $this->redis->keys($pattern);
            
            if (!empty($keys)) {
                $this->redis->del($keys);
                $this->stats['delete_operations'] += count($keys);
            }
            
            return true;
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            error_log("Redis clear operation failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 设置缓存过期时间
     * @param string $key 键名
     * @param int $ttl 过期时间（秒）
     * @return bool 是否设置成功
     */
    public function expire($key, $ttl) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            return $this->redis->expire($fullKey, $ttl);
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return false;
        }
    }
    
    /**
     * 获取缓存剩余过期时间
     * @param string $key 键名
     * @return int 剩余时间（秒），-1表示永不过期，-2表示键不存在
     */
    public function ttl($key) {
        if (!$this->enabled || !$this->redis) {
            return -2;
        }
        
        try {
            $fullKey = $this->getKey($key);
            return $this->redis->ttl($fullKey);
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return -2;
        }
    }
    
    /**
     * 获取或设置缓存值（如果不存在）
     * @param string $key 键名
     * @param callable $callback 获取值的回调函数
     * @param int|null $ttl 过期时间
     * @return mixed 缓存值
     */
    public function remember($key, callable $callback, $ttl = null) {
        // 尝试获取缓存
        $value = $this->get($key);
        
        if ($value !== null) {
            return $value;
        }
        
        // 缓存未命中，执行回调获取值
        $value = $callback();
        
        // 设置缓存
        $this->set($key, $value, $ttl);
        
        return $value;
    }
    
    /**
     * 获取缓存统计信息
     * @return array 统计数据
     */
    public function getStats() {
        $totalOperations = $this->stats['hits'] + $this->stats['misses'];
        $hitRate = $totalOperations > 0 ? ($this->stats['hits'] / $totalOperations * 100) : 0;
        
        return array(
            'hits' => $this->stats['hits'],
            'misses' => $this->stats['misses'],
            'hit_rate' => round($hitRate, 2),
            'set_operations' => $this->stats['set_operations'],
            'delete_operations' => $this->stats['delete_operations'],
            'errors' => $this->stats['errors'],
            'total_operations' => $totalOperations
        );
    }
    
    /**
     * 重置统计信息
     */
    public function resetStats() {
        $this->stats = array(
            'hits' => 0,
            'misses' => 0,
            'set_operations' => 0,
            'delete_operations' => 0,
            'errors' => 0
        );
    }
    
    /**
     * 检查Redis连接状态
     * @return bool 是否连接正常
     */
    public function isConnected() {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            return $this->redis->ping() === '+PONG';
        } catch (RedisException $e) {
            return false;
        }
    }
    
    /**
     * 序列化数据
     * @param mixed $value 要序列化的值
     * @return string 序列化后的数据
     */
    private function serialize($value) {
        // 使用igbinary扩展如果可用，否则使用json_encode
        if (extension_loaded('igbinary')) {
            return igbinary_serialize($value);
        }
        
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_BIGINT_AS_STRING);
    }
    
    /**
     * 反序列化数据
     * @param string $value 序列化的数据
     * @return mixed 反序列化后的值
     */
    private function unserialize($value) {
        // 尝试igbinary反序列化
        if (extension_loaded('igbinary')) {
            $unserialized = @igbinary_unserialize($value);
            if ($unserialized !== false || $value === igbinary_serialize(false)) {
                return $unserialized;
            }
        }
        
        // 回退到JSON
        return json_decode($value, true);
    }
    
    /**
     * 获取最后一个错误
     * @return string|null 错误信息
     */
    public function getLastError() {
        return $this->lastError;
    }
    
    /**
     * 启用/禁用缓存
     * @param bool $enabled 是否启用
     */
    public function setEnabled($enabled) {
        $this->enabled = $enabled;
        
        // 如果启用且未连接，尝试连接
        if ($enabled && (!$this->redis || !$this->isConnected())) {
            $this->connect();
        }
    }
    
    /**
     * 获取连接对象（用于高级操作）
     * @return Redis|null Redis对象
     */
    public function getRedis() {
        return $this->redis;
    }
    
    /**
     * 原子性递增操作
     * @param string $key 键名
     * @param int $value 递增值
     * @return int|bool 操作后的新值或false（失败）
     */
    public function increment($key, $value = 1) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            return $this->redis->incrBy($fullKey, $value);
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return false;
        }
    }
    
    /**
     * 原子性递减操作
     * @param string $key 键名
     * @param int $value 递减值
     * @return int|bool 操作后的新值或false（失败）
     */
    public function decrement($key, $value = 1) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            return $this->redis->decrBy($fullKey, $value);
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return false;
        }
    }
    
    /**
     * 添加到列表（从右侧）
     * @param string $key 键名
     * @param mixed $value 值
     * @return int|bool 列表长度或false（失败）
     */
    public function rpush($key, $value) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            $serializedValue = $this->serialize($value);
            return $this->redis->rpush($fullKey, $serializedValue);
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return false;
        }
    }
    
    /**
     * 从列表中弹出（从左侧）
     * @param string $key 键名
     * @param int $timeout 阻塞超时（秒）
     * @return mixed 列表项或false（失败/超时）
     */
    public function lpop($key, $timeout = null) {
        if (!$this->enabled || !$this->redis) {
            return false;
        }
        
        try {
            $fullKey = $this->getKey($key);
            $value = $timeout !== null 
                ? $this->redis->blpop(array($fullKey), $timeout)
                : $this->redis->lpop($fullKey);
            
            if ($value === false) {
                return false;
            }
            
            // 如果是阻塞弹出，返回的值是数组 [键名, 值]
            if (is_array($value)) {
                $value = $value[1];
            }
            
            return $this->unserialize($value);
        } catch (RedisException $e) {
            $this->stats['errors']++;
            $this->lastError = $e->getMessage();
            return false;
        }
    }
    
    /**
     * 关闭Redis连接
     */
    public function close() {
        if ($this->redis) {
            try {
                $this->redis->close();
            } catch (RedisException $e) {
                // 忽略关闭连接时的错误
            }
            
            $this->redis = null;
        }
    }
    
    /**
     * 析构函数
     */
    public function __destruct() {
        $this->close();
    }
}