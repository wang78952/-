<?php
/**
 * 邮件服务类
 * 提供邮件发送功能
 */

class EmailService {
    private $config = [];
    private $logger;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 初始化默认配置
        $this->config = [
            'smtp_server' => 'smtp.example.com',
            'smtp_port' => 587,
            'smtp_username' => 'noreply@example.com',
            'smtp_password' => '',
            'from_email' => 'noreply@example.com',
            'from_name' => '发卡系统',
            'use_smtp' => false // 默认使用PHP的mail函数
        ];
        
        // 尝试从配置文件加载邮件配置
        if (file_exists(__DIR__ . '/../config.php')) {
            require_once __DIR__ . '/../config.php';
        }
        
        // 尝试从配置管理器加载邮件配置
        // 安全地加载配置，避免未定义常量错误
        if (class_exists('ConfigManager')) {
            try {
                $configManager = ConfigManager::getInstance();
                $emailConfig = $configManager->get('email', []);
                if (is_array($emailConfig) && !empty($emailConfig)) {
                    $this->config = array_merge($this->config, $emailConfig);
                }
            } catch (\Exception $e) {
                $this->log('Error loading email config from ConfigManager: ' . $e->getMessage(), [], 'error');
            }
        }
        
        // 如果Logger类可用，则使用它
        if (class_exists('Logger')) {
            $this->logger = new Logger();
        }
    }
    
    /**
     * 发送邮件
     * 
     * @param string $to 收件人邮箱
     * @param string $subject 邮件主题
     * @param string $content 邮件内容
     * @param array $options 附加选项
     * @return array 发送结果
     */
    public function sendEmail($to, $subject, $content, $options = []) {
        try {
            // 验证必要参数
            if (empty($to) || empty($subject) || empty($content)) {
                throw new Exception('邮件参数不完整');
            }
            
            // 准备邮件头
            $from = isset($options['from']) ? $options['from'] : "{$this->config['from_name']} <{$this->config['from_email']}>";
            $headers = [
                'From' => $from,
                'Reply-To' => isset($options['reply_to']) ? $options['reply_to'] : $this->config['from_email'],
                'Content-Type' => isset($options['content_type']) ? $options['content_type'] : 'text/html; charset=UTF-8',
                'X-Mailer' => 'PHP/' . phpversion()
            ];
            
            // 构建头信息字符串
            $headerString = '';
            foreach ($headers as $key => $value) {
                $headerString .= "$key: $value\r\n";
            }
            
            // 处理收件人（支持多个）
            if (is_array($to)) {
                $to = implode(', ', $to);
            }
            
            // 发送邮件
            if ($this->config['use_smtp']) {
                // SMTP模式发送（模拟实现）
                $result = $this->sendViaSMTP($to, $subject, $content, $headers);
            } else {
                // 使用PHP mail函数
                $result = @mail($to, $subject, $content, $headerString);
                
                if ($result) {
                    $this->log('邮件发送成功', ['to' => $to, 'subject' => $subject]);
                    return ['success' => true, 'message' => '邮件发送成功'];
                } else {
                    throw new Exception('邮件发送失败');
                }
            }
            
            return $result;
            
        } catch (Exception $e) {
            $errorMessage = $e->getMessage();
            $this->log('邮件发送失败: ' . $errorMessage, ['to' => $to, 'subject' => $subject], 'error');
            return ['success' => false, 'error' => $errorMessage];
        }
    }
    
    /**
     * 模拟SMTP发送（实际项目中应使用PHPMailer或SwiftMailer）
     */
    private function sendViaSMTP($to, $subject, $content, $headers) {
        $this->log('使用SMTP模式发送邮件', ['to' => $to, 'subject' => $subject]);
        
        // 这里是模拟实现，实际项目中应使用成熟的邮件库
        // 例如PHPMailer或SwiftMailer
        
        // 为了测试目的，假设总是成功
        return ['success' => true, 'message' => 'SMTP邮件发送成功'];
    }
    
    /**
     * 记录日志
     */
    private function log($message, $data = [], $level = 'info') {
        if ($this->logger && method_exists($this->logger, $level)) {
            $this->logger->$level($message, $data);
        } else {
            // 简单的错误日志记录
            $logData = json_encode(['message' => $message, 'data' => $data, 'level' => $level]);
            error_log($logData);
        }
    }
    
    /**
     * 发送模板邮件
     * 
     * @param string $to 收件人邮箱
     * @param string $template 模板名称
     * @param array $variables 变量替换数组
     * @return array 发送结果
     */
    public function sendTemplateEmail($to, $template, $variables = []) {
        // 获取模板内容（这里是模拟实现）
        $templates = [
            'welcome' => [
                'subject' => '欢迎使用我们的服务',
                'content' => '尊敬的{username}：<br><br>感谢您注册我们的服务！'
            ],
            'password_reset' => [
                'subject' => '密码重置请求',
                'content' => '尊敬的用户：<br><br>您的密码重置链接：{reset_link}'
            ]
        ];
        
        if (!isset($templates[$template])) {
            return ['success' => false, 'error' => '模板不存在'];
        }
        
        $templateData = $templates[$template];
        
        // 替换变量
        $subject = $templateData['subject'];
        $content = $templateData['content'];
        
        foreach ($variables as $key => $value) {
            $subject = str_replace('{' . $key . '}', $value, $subject);
            $content = str_replace('{' . $key . '}', $value, $content);
        }
        
        return $this->sendEmail($to, $subject, $content);
    }
}