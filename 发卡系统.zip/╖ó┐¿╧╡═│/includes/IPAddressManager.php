<?php
/**
 * IP地址管理器
 * 提供统一的IP地址获取、验证和地理位置查询功能
 */
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/SecurityUtils.php';
require_once __DIR__ . '/Cache.php';

class IPAddressManager {
    private $logger;
    private $cache;
    private $config;
    private $trustedProxies = [];
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->logger = Logger::getInstance();
        $this->cache = Cache::getInstance();
        $this->loadConfig();
    }
    
    /**
     * 加载配置
     */
    private function loadConfig() {
        // 从配置文件加载可信代理IP列表
        $configFile = __DIR__ . '/../config/security.php';
        if (file_exists($configFile)) {
            require_once $configFile;
            if (isset($trustedProxies) && is_array($trustedProxies)) {
                $this->trustedProxies = $trustedProxies;
            }
        }
        
        // 设置默认配置
        $this->config = [
            'ip_headers' => [
                'HTTP_CF_CONNECTING_IP',    // Cloudflare
                'HTTP_X_FORWARDED_FOR',     // 标准转发头
                'HTTP_X_REAL_IP',           // Nginx/Apache配置的真实IP
                'HTTP_CLIENT_IP',           // 客户端IP
                'REMOTE_ADDR'               // 远程地址
            ],
            'cache_ttl' => 86400,         // IP信息缓存时间(秒)
            'geoip_enabled' => true,      // 是否启用地理位置验证
            'maxmind_db_path' => __DIR__ . '/../config/GeoLite2-City.mmdb' // MaxMind数据库路径
        ];
    }
    
    /**
     * 获取客户端真实IP地址
     * @param array $serverVars 可选的服务器变量数组，默认为$_SERVER
     * @return string 客户端IP地址
     */
    public function getClientIP(array $serverVars = null) {
        if ($serverVars === null) {
            $serverVars = $_SERVER;
        }
        
        // 首先检查是否为可信代理环境
        $remoteAddr = $serverVars['REMOTE_ADDR'] ?? '127.0.0.1';
        $isTrustedProxy = in_array($remoteAddr, $this->trustedProxies);
        
        // 按优先级尝试获取IP
        foreach ($this->config['ip_headers'] as $header) {
            if (isset($serverVars[$header])) {
                $ipString = $serverVars[$header];
                
                // 处理多个IP的情况（X-Forwarded-For）
                if (strpos($ipString, ',') !== false) {
                    $ips = explode(',', $ipString);
                    
                    // 对于可信代理，我们可以尝试找到用户真实IP
                    if ($isTrustedProxy) {
                        foreach ($ips as $ip) {
                            $ip = trim($ip);
                            if ($this->isValidPublicIP($ip) && !in_array($ip, $this->trustedProxies)) {
                                $this->logger->info('Client IP detected from trusted proxy', ['ip' => $ip, 'proxy' => $remoteAddr]);
                                return $ip;
                            }
                        }
                    }
                    
                    // 取第一个IP
                    $ip = trim($ips[0]);
                } else {
                    $ip = trim($ipString);
                }
                
                // 验证IP有效性
                if ($this->isValidPublicIP($ip)) {
                    $this->logger->info('Client IP detected', ['ip' => $ip, 'header' => $header]);
                    return $ip;
                }
            }
        }
        
        // 作为最后的手段，返回REMOTE_ADDR
        $this->logger->info('Fallback to REMOTE_ADDR', ['ip' => $remoteAddr]);
        return $remoteAddr;
    }
    
    /**
     * 验证IP地址是否为有效的公网IP
     * @param string $ip IP地址
     * @return bool 是否为有效公网IP
     */
    public function isValidPublicIP($ip) {
        // 使用PHP的过滤器验证IP
        $isValid = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
        return $isValid !== false;
    }
    
    /**
     * 获取IP地址的地理位置信息
     * @param string $ip IP地址
     * @return array 地理位置信息
     */
    public function getGeoLocation($ip) {
        // 检查缓存
        $cacheKey = "ip_geo:{$ip}";
        $cached = $this->cache->get($cacheKey);
        if ($cached !== false) {
            return json_decode($cached, true);
        }
        
        try {
            // 尝试使用MaxMind数据库
            $geoInfo = $this->getGeoInfoFromMaxMind($ip);
            
            // 如果MaxMind失败，使用第三方API
            if (!$geoInfo || !isset($geoInfo['country'])) {
                $geoInfo = $this->getGeoInfoFromAPI($ip);
            }
            
            // 如果都失败了，返回默认信息
            if (!$geoInfo) {
                $geoInfo = [
                    'ip' => $ip,
                    'country' => 'Unknown',
                    'region' => 'Unknown',
                    'city' => 'Unknown',
                    'latitude' => null,
                    'longitude' => null,
                    'isp' => 'Unknown',
                    'timezone' => 'Unknown',
                    'accuracy' => 'low',
                    'timestamp' => time()
                ];
            }
            
            // 缓存结果
            $this->cache->set($cacheKey, json_encode($geoInfo), $this->config['cache_ttl']);
            
            return $geoInfo;
        } catch (Exception $e) {
            $this->logger->error('Failed to get geolocation for IP', ['ip' => $ip, 'error' => $e->getMessage()]);
            return [
                'ip' => $ip,
                'country' => 'Unknown',
                'error' => $e->getMessage(),
                'timestamp' => time()
            ];
        }
    }
    
    /**
     * 从MaxMind数据库获取地理位置信息
     * @param string $ip IP地址
     * @return array|null 地理位置信息
     */
    private function getGeoInfoFromMaxMind($ip) {
        if (!extension_loaded('maxminddb') || !file_exists($this->config['maxmind_db_path'])) {
            return null;
        }
        
        try {
            $reader = new MaxMind\Db\Reader($this->config['maxmind_db_path']);
            $record = $reader->get($ip);
            $reader->close();
            
            if (empty($record)) {
                return null;
            }
            
            return [
                'ip' => $ip,
                'country' => $record['country']['names']['zh-CN'] ?? $record['country']['names']['en'] ?? 'Unknown',
                'region' => $record['subdivisions'][0]['names']['zh-CN'] ?? $record['subdivisions'][0]['names']['en'] ?? 'Unknown',
                'city' => $record['city']['names']['zh-CN'] ?? $record['city']['names']['en'] ?? 'Unknown',
                'latitude' => $record['location']['latitude'] ?? null,
                'longitude' => $record['location']['longitude'] ?? null,
                'accuracy' => 'high',
                'timestamp' => time()
            ];
        } catch (Exception $e) {
            $this->logger->error('MaxMind lookup failed', ['error' => $e->getMessage()]);
            return null;
        }
    }
    
    /**
     * 从第三方API获取地理位置信息
     * @param string $ip IP地址
     * @return array|null 地理位置信息
     */
    private function getGeoInfoFromAPI($ip) {
        try {
            // 使用免费的IP地理位置API
            // 实际项目中建议使用付费的企业级API以获得更高的准确性和稳定性
            $apis = [
                "http://ip-api.com/json/{$ip}?lang=zh-CN&fields=status,country,regionName,city,lat,lon,isp,timezone,query",
                "https://ipinfo.io/{$ip}/json",
                "https://api.ip.sb/geoip/{$ip}"
            ];
            
            foreach ($apis as $apiUrl) {
                $context = stream_context_create([
                    'http' => [
                        'timeout' => 3,
                        'header' => 'User-Agent: Mozilla/5.0 (compatible; IPAddressManager/1.0)'
                    ]
                ]);
                
                $response = @file_get_contents($apiUrl, false, $context);
                if ($response) {
                    $data = json_decode($response, true);
                    if ($data && isset($data['status']) && $data['status'] === 'success') {
                        return [
                            'ip' => $data['query'] ?? $ip,
                            'country' => $data['country'] ?? 'Unknown',
                            'region' => $data['regionName'] ?? 'Unknown',
                            'city' => $data['city'] ?? 'Unknown',
                            'latitude' => $data['lat'] ?? null,
                            'longitude' => $data['lon'] ?? null,
                            'isp' => $data['isp'] ?? 'Unknown',
                            'timezone' => $data['timezone'] ?? 'Unknown',
                            'accuracy' => 'medium',
                            'timestamp' => time()
                        ];
                    } elseif ($data && isset($data['ip'])) {
                        // 处理ipinfo.io的响应格式
                        return [
                            'ip' => $data['ip'] ?? $ip,
                            'country' => $data['country'] ?? 'Unknown',
                            'region' => $data['region'] ?? 'Unknown',
                            'city' => $data['city'] ?? 'Unknown',
                            'latitude' => isset($data['loc']) ? explode(',', $data['loc'])[0] : null,
                            'longitude' => isset($data['loc']) ? explode(',', $data['loc'])[1] : null,
                            'isp' => $data['org'] ?? 'Unknown',
                            'timezone' => $data['timezone'] ?? 'Unknown',
                            'accuracy' => 'medium',
                            'timestamp' => time()
                        ];
                    }
                }
            }
            
            return null;
        } catch (Exception $e) {
            $this->logger->error('IP API lookup failed', ['error' => $e->getMessage()]);
            return null;
        }
    }
    
    /**
     * 验证IP地址是否在允许的国家/地区
     * @param string $ip IP地址
     * @param array $allowedCountries 允许的国家列表（ISO代码）
     * @return bool 是否在允许的国家/地区
     */
    public function isAllowedCountry($ip, array $allowedCountries) {
        if (empty($allowedCountries)) {
            return true; // 没有限制，允许所有国家
        }
        
        $geoInfo = $this->getGeoLocation($ip);
        if (!isset($geoInfo['country'])) {
            return false; // 无法确定地理位置，拒绝访问
        }
        
        // 检查国家是否在允许列表中
        return in_array($geoInfo['country'], $allowedCountries) || 
               in_array(strtoupper($geoInfo['country']), array_map('strtoupper', $allowedCountries));
    }
    
    /**
     * 检查IP地址是否为VPN/代理
     * @param string $ip IP地址
     * @return bool 是否为VPN/代理
     */
    public function isProxy($ip) {
        // 实现VPN/代理检测逻辑
        // 可以通过DNSBL、HTTP头信息分析或第三方API来检测
        
        // 简单的实现方式：检查特定HTTP头
        $proxyHeaders = [
            'HTTP_VIA',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_PROXY_CONNECTION',
            'HTTP_X_PROXY_CONNECTION',
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP'
        ];
        
        foreach ($proxyHeaders as $header) {
            if (isset($_SERVER[$header]) && !empty($_SERVER[$header])) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取IP地址的风险评分
     * @param string $ip IP地址
     * @return int 风险评分（0-100）
     */
    public function getRiskScore($ip) {
        $score = 0;
        
        // 检查是否为私有IP
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE)) {
            $score += 30;
        }
        
        // 检查是否为VPN/代理
        if ($this->isProxy($ip)) {
            $score += 50;
        }
        
        // 检查是否在黑名单中
        $blacklisted = $this->isBlacklisted($ip);
        if ($blacklisted) {
            $score += 100;
        }
        
        // 确保分数在0-100范围内
        return min($score, 100);
    }
    
    /**
     * 检查IP地址是否在黑名单中
     * @param string $ip IP地址
     * @return bool 是否在黑名单中
     */
    private function isBlacklisted($ip) {
        // 这里可以从数据库或配置文件加载黑名单
        // 暂时返回false
        return false;
    }
    
    /**
     * 格式化IP地址，用于日志记录
     * @param string $ip IP地址
     * @return string 格式化的IP地址
     */
    public function formatIP($ip) {
        // 对于IPv6地址，去掉前导零和压缩
        if (strpos($ip, ':') !== false) {
            return inet_ntop(inet_pton($ip));
        }
        return $ip;
    }
}

// 注册全局单例
if (!function_exists('getIPManager')) {
    function getIPManager() {
        static $instance = null;
        if ($instance === null) {
            $instance = new IPAddressManager();
        }
        return $instance;
    }
}