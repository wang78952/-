<?php
/**
 * 缓存管理器
 * 提供Redis和其他缓存服务的统一访问接口，实现热点数据缓存和缓存策略管理
 */

class CacheManager {
    
    /**
     * 缓存服务实例
     * @var RedisCacheService
     */
    private static $redisCacheService = null;
    
    /**
     * 缓存配置
     * @var array
     */
    private static $config = null;
    
    /**
     * 缓存命中率统计
     * @var array
     */
    private static $hitStats = [
        'hits' => 0,
        'misses' => 0,
        'total' => 0
    ];
    
    /**
     * 初始化缓存管理器
     */
    public static function init() {
        // 加载缓存配置
        if (!isset($GLOBALS['cache_config'])) {
            require_once __DIR__ . '/../../config/cache.php';
        }
        
        self::$config = $GLOBALS['cache_config'];
        
        // 初始化Redis缓存服务
        if (self::$config['enabled'] && self::$config['default'] === 'redis') {
            require_once __DIR__ . '/RedisCacheService.php';
            self::$redisCacheService = RedisCacheService::getInstance();
        }
        
        // 初始化热点数据预加载
        if (self::$config['hot_data']['preload_enabled']) {
            self::scheduleHotDataPreload();
        }
    }
    
    /**
     * 获取缓存服务实例
     * @return RedisCacheService|null
     */
    public static function getRedisCacheService() {
        if (self::$redisCacheService === null) {
            self::init();
        }
        return self::$redisCacheService;
    }
    
    /**
     * 获取缓存项
     * @param string $key 缓存键
     * @return mixed|null 缓存值或null
     */
    public static function get($key) {
        if (!self::$config['enabled'] || self::$redisCacheService === null) {
            return null;
        }
        
        try {
            $result = self::$redisCacheService->get($key);
            
            // 更新命中率统计
            if (self::$config['monitoring']['record_hit_rate']) {
                if ($result !== null) {
                    self::$hitStats['hits']++;
                } else {
                    self::$hitStats['misses']++;
                }
                self::$hitStats['total']++;
            }
            
            return $result;
        } catch (Exception $e) {
            self::logError('Cache get error: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 设置缓存项
     * @param string $key 缓存键
     * @param mixed $value 缓存值
     * @param int|null $ttl 过期时间（秒），null则使用默认值
     * @return bool 是否成功
     */
    public static function set($key, $value, $ttl = null) {
        if (!self::$config['enabled'] || self::$redisCacheService === null) {
            return false;
        }
        
        try {
            if ($ttl === null) {
                $ttl = self::$config['stores']['redis']['ttl'];
            }
            return self::$redisCacheService->set($key, $value, $ttl);
        } catch (Exception $e) {
            self::logError('Cache set error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 删除缓存项
     * @param string $key 缓存键
     * @return bool 是否成功
     */
    public static function delete($key) {
        if (!self::$config['enabled'] || self::$redisCacheService === null) {
            return false;
        }
        
        try {
            return self::$redisCacheService->delete($key);
        } catch (Exception $e) {
            self::logError('Cache delete error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 批量获取缓存项
     * @param array $keys 缓存键数组
     * @return array 缓存值数组
     */
    public static function mget($keys) {
        if (!self::$config['enabled'] || self::$redisCacheService === null) {
            return array_fill_keys($keys, null);
        }
        
        try {
            return self::$redisCacheService->mget($keys);
        } catch (Exception $e) {
            self::logError('Cache mget error: ' . $e->getMessage());
            return array_fill_keys($keys, null);
        }
    }
    
    /**
     * 缓存卡密信息
     * @param int $cardId 卡密ID
     * @param array $cardInfo 卡密信息
     * @return bool 是否成功
     */
    public static function cacheCardInfo($cardId, $cardInfo) {
        $key = CACHE_KEY_CARD_INFO($cardId);
        $ttl = self::$config['ttl']['card_info'];
        
        // 记录卡密访问热度
        self::incrementCardHeat($cardId);
        
        return self::set($key, $cardInfo, $ttl);
    }
    
    /**
     * 获取缓存的卡密信息
     * @param int $cardId 卡密ID
     * @return array|null 卡密信息
     */
    public static function getCachedCardInfo($cardId) {
        return self::get(CACHE_KEY_CARD_INFO($cardId));
    }
    
    /**
     * 缓存代理佣金比例
     * @param int $agentId 代理ID
     * @param array $commissionInfo 佣金信息
     * @return bool 是否成功
     */
    public static function cacheAgentCommission($agentId, $commissionInfo) {
        $key = CACHE_KEY_AGENT_COMMISSION($agentId);
        $ttl = self::$config['ttl']['agent_commission'];
        return self::set($key, $commissionInfo, $ttl);
    }
    
    /**
     * 获取缓存的代理佣金信息
     * @param int $agentId 代理ID
     * @return array|null 佣金信息
     */
    public static function getCachedAgentCommission($agentId) {
        return self::get(CACHE_KEY_AGENT_COMMISSION($agentId));
    }
    
    /**
     * 增加卡密访问热度
     * @param int $cardId 卡密ID
     */
    private static function incrementCardHeat($cardId) {
        // 增加卡密访问计数
        $heatKey = CACHE_KEY_PREFIX . "card:heat:" . $cardId;
        self::getRedisCacheService()->increment($heatKey, 1, 86400); // 24小时过期
        
        // 检查是否需要加入热门卡密列表
        $heat = self::getRedisCacheService()->get($heatKey);
        if ($heat >= self::$config['hot_data']['card_heat_threshold']) {
            self::addCardToHotList($cardId);
        }
    }
    
    /**
     * 添加卡密到热门列表
     * @param int $cardId 卡密ID
     */
    private static function addCardToHotList($cardId) {
        $hotListKey = CACHE_KEY_HOT_CARDS();
        // 使用Sorted Set，分数为当前时间戳，便于后续排序
        self::getRedisCacheService()->zAdd($hotListKey, time(), $cardId);
        
        // 保持列表大小
        self::getRedisCacheService()->zRemRangeByRank($hotListKey, 0, - (self::$config['hot_data']['auto_cache_cards_count'] + 1));
    }
    
    /**
     * 预加载热点数据
     */
    public static function preloadHotData() {
        // 预加载热门卡密信息
        self::preloadHotCards();
        
        // 预加载代理佣金配置
        self::preloadAgentCommissions();
    }
    
    /**
     * 预加载热门卡密信息
     */
    private static function preloadHotCards() {
        $hotListKey = CACHE_KEY_HOT_CARDS();
        $hotCards = self::getRedisCacheService()->zRevRange($hotListKey, 0, self::$config['hot_data']['auto_cache_cards_count'] - 1);
        
        // 从数据库加载卡密信息并缓存
        if (!empty($hotCards) && function_exists('getDB')) {
            $db = getDB();
            $cardIds = implode(',', $hotCards);
            $stmt = $db->prepare("SELECT * FROM card_info WHERE id IN ($cardIds)");
            $stmt->execute();
            $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($cards as $card) {
                self::cacheCardInfo($card['id'], $card);
            }
        }
    }
    
    /**
     * 预加载代理佣金配置
     */
    private static function preloadAgentCommissions() {
        // 从数据库加载活跃代理的佣金配置并缓存
        if (function_exists('getDB')) {
            $db = getDB();
            $stmt = $db->prepare("SELECT agent_id, commission_rate, bonus_rules FROM agent_commissions WHERE is_active = 1");
            $stmt->execute();
            $commissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($commissions as $commission) {
                self::cacheAgentCommission($commission['agent_id'], $commission);
            }
        }
    }
    
    /**
     * 安排热点数据定时预加载
     */
    private static function scheduleHotDataPreload() {
        // 注册定时任务或使用其他方式实现定时预加载
        // 这里简化实现，实际生产环境可能需要使用cron任务或消息队列
    }
    
    /**
     * 清除指定卡密的缓存
     * @param int $cardId 卡密ID
     */
    public static function clearCardCache($cardId) {
        $keys = [
            CACHE_KEY_CARD_INFO($cardId),
            CACHE_KEY_CARD_STATUS($cardId),
            CACHE_KEY_PREFIX . "card:heat:" . $cardId
        ];
        
        foreach ($keys as $key) {
            self::delete($key);
        }
    }
    
    /**
     * 清除指定代理的缓存
     * @param int $agentId 代理ID
     */
    public static function clearAgentCache($agentId) {
        $keys = [
            CACHE_KEY_AGENT_INFO($agentId),
            CACHE_KEY_AGENT_COMMISSION($agentId),
            CACHE_KEY_AGENT_STATS($agentId)
        ];
        
        foreach ($keys as $key) {
            self::delete($key);
        }
    }
    
    /**
     * 获取缓存统计信息
     * @return array
     */
    public static function getStats() {
        $hitRate = self::$hitStats['total'] > 0 
            ? round((self::$hitStats['hits'] / self::$hitStats['total']) * 100, 2) 
            : 0;
            
        return [
            'hit_rate' => $hitRate . '%',
            'hits' => self::$hitStats['hits'],
            'misses' => self::$hitStats['misses'],
            'total' => self::$hitStats['total']
        ];
    }
    
    /**
     * 记录错误日志
     * @param string $message 错误信息
     */
    private static function logError($message) {
        // 实际项目中可能会调用日志服务
        if (self::$config['monitoring']['log_operations']) {
            error_log('CacheManager: ' . $message);
        }
    }
}

// 注册自动初始化函数，在脚本启动时自动初始化
register_shutdown_function(function() {
    // 缓存管理器的清理工作
});

// 自动初始化
CacheManager::init();