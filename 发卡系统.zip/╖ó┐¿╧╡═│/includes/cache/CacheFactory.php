\u003c?php
/**
 * 缓存工厂类
 * 提供缓存系统的统一入口，支持多种缓存后端，实现缓存策略管理
 */

class CacheFactory {
    // 缓存实例存储
    private static $instances = [];
    
    // 配置信息
    private static $config;
    
    // 缓存类型常量
    const TYPE_REDIS = 'redis';
    const TYPE_MEMCACHED = 'memcached';
    const TYPE_FILE = 'file';
    const TYPE_NULL = 'null';
    
    /**
     * 获取缓存实例
     * @param string $type 缓存类型
     * @param string $namespace 命名空间
     * @return mixed 缓存实例
     */
    public static function getInstance($type = null, $namespace = 'default') {
        // 如果没有指定类型，使用默认类型
        if ($type === null) {
            $type = self::getDefaultType();
        }
        
        // 构建实例ID
        $instanceId = "{$type}:{$namespace}";
        
        // 如果实例已存在，直接返回
        if (isset(self::$instances[$instanceId])) {
            return self::$instances[$instanceId];
        }
        
        // 创建新实例
        $instance = self::createInstance($type, $namespace);
        
        // 存储实例
        self::$instances[$instanceId] = $instance;
        
        return $instance;
    }
    
    /**
     * 创建缓存实例
     * @param string $type 缓存类型
     * @param string $namespace 命名空间
     * @return mixed 缓存实例
     */
    private static function createInstance($type, $namespace) {
        $config = self::getConfig();
        $options = isset($config[$type]) ? $config[$type] : [];
        
        // 添加命名空间配置
        $options['namespace'] = $namespace;
        
        switch ($type) {
            case self::TYPE_REDIS:
                return self::createRedisInstance($options);
            case self::TYPE_MEMCACHED:
                return self::createMemcachedInstance($options);
            case self::TYPE_FILE:
                return self::createFileInstance($options);
            default:
                return self::createNullInstance();
        }
    }
    
    /**
     * 创建Redis缓存实例
     * @param array $options 配置选项
     * @return RedisCache Redis缓存实例
     */
    private static function createRedisInstance(array $options) {
        // 尝试加载RedisCache类
        if (!class_exists('RedisCache')) {
            require_once INCLUDE_PATH . '/cache/RedisCache.php';
        }
        
        // 创建并返回Redis缓存实例
        $instance = new RedisCache();
        
        // 如果有命名空间，修改前缀
        if (isset($options['namespace']) \u0026\u0026 $options['namespace'] != 'default') {
            // RedisCache类已经处理了前缀，这里可以添加额外的命名空间处理
        }
        
        return $instance;
    }
    
    /**
     * 创建Memcached缓存实例
     * @param array $options 配置选项
     * @return MemcachedCache Memcached缓存实例
     */
    private static function createMemcachedInstance(array $options) {
        // 尝试加载MemcachedCache类
        if (!class_exists('MemcachedCache')) {
            require_once INCLUDE_PATH . '/cache/MemcachedCache.php';
        }
        
        // 创建并返回Memcached缓存实例
        $instance = new MemcachedCache();
        
        return $instance;
    }
    
    /**
     * 创建文件缓存实例
     * @param array $options 配置选项
     * @return FileCache 文件缓存实例
     */
    private static function createFileInstance(array $options) {
        // 尝试加载FileCache类
        if (!class_exists('FileCache')) {
            require_once INCLUDE_PATH . '/cache/FileCache.php';
        }
        
        // 创建并返回文件缓存实例
        $instance = new FileCache($options);
        
        return $instance;
    }
    
    /**
     * 创建空缓存实例
     * @return NullCache 空缓存实例
     */
    private static function createNullInstance() {
        // 尝试加载NullCache类
        if (!class_exists('NullCache')) {
            require_once INCLUDE_PATH . '/cache/NullCache.php';
        }
        
        // 创建并返回空缓存实例
        return new NullCache();
    }
    
    /**
     * 获取默认缓存类型
     * @return string 默认缓存类型
     */
    public static function getDefaultType() {
        $config = self::getConfig();
        return $config['default'] ?? self::TYPE_NULL;
    }
    
    /**
     * 获取缓存配置
     * @return array 配置数组
     */
    public static function getConfig() {
        if (self::$config === null) {
            self::loadConfig();
        }
        return self::$config;
    }
    
    /**
     * 加载缓存配置
     */
    private static function loadConfig() {
        self::$config = [
            'default' =\u003e self::TYPE_REDIS,
            self::TYPE_REDIS =\u003e [
                'host' =\u003e '127.0.0.1',
                'port' =\u003e 6379,
                'password' =\u003e '',
                'database' =\u003e 0,
                'timeout' =\u003e 5,
                'prefix' =\u003e 'card_system:'
            ],
            self::TYPE_MEMCACHED =\u003e [
                'servers' =\u003e [
                    ['127.0.0.1', 11211, 100]
                ],
                'prefix' =\u003e 'card_system:',
                'compression' =\u003e true
            ],
            self::TYPE_FILE =\u003e [
                'path' =\u003e CACHE_PATH,
                'prefix' =\u003e 'card_system_',
                'extension' =\u003e '.cache',
                'serialize' =\u003e true
            ]
        ];
        
        // 尝试从配置文件加载自定义配置
        if (file_exists(CONFIG_PATH . '/cache_config.php')) {
            include CONFIG_PATH . '/cache_config.php';
            if (isset($cacheConfig) \u0026\u0026 is_array($cacheConfig)) {
                self::$config = array_merge(self::$config, $cacheConfig);
            }
        }
    }
    
    /**
     * 清除缓存实例
     * @param string $type 缓存类型
     * @param string $namespace 命名空间
     * @return bool 是否成功
     */
    public static function clearInstance($type = null, $namespace = null) {
        if ($type === null) {
            // 清除所有实例
            self::$instances = [];
            return true;
        }
        
        if ($namespace === null) {
            // 清除指定类型的所有实例
            foreach (array_keys(self::$instances) as $instanceId) {
                if (strpos($instanceId, "{$type}:") === 0) {
                    unset(self::$instances[$instanceId]);
                }
            }
            return true;
        }
        
        // 清除指定类型和命名空间的实例
        $instanceId = "{$type}:{$namespace}";
        if (isset(self::$instances[$instanceId])) {
            unset(self::$instances[$instanceId]);
            return true;
        }
        
        return false;
    }
    
    /**
     * 获取缓存实例数量
     * @return int 实例数量
     */
    public static function getInstanceCount() {
        return count(self::$instances);
    }
    
    /**
     * 检查缓存类型是否可用
     * @param string $type 缓存类型
     * @return bool 是否可用
     */
    public static function isCacheAvailable($type) {
        switch ($type) {
            case self::TYPE_REDIS:
                return class_exists('Redis');
            case self::TYPE_MEMCACHED:
                return class_exists('Memcached');
            case self::TYPE_FILE:
                // 文件缓存总是可用的
                return true;
            case self::TYPE_NULL:
                return true;
            default:
                return false;
        }
    }
    
    /**
     * 获取可用的缓存类型列表
     * @return array 缓存类型数组
     */
    public static function getAvailableTypes() {
        $types = [];
        
        foreach ([self::TYPE_REDIS, self::TYPE_MEMCACHED, self::TYPE_FILE, self::TYPE_NULL] as $type) {
            if (self::isCacheAvailable($type)) {
                $types[] = $type;
            }
        }
        
        return $types;
    }
    
    /**
     * 获取缓存实例的统计信息
     * @return array 统计信息
     */
    public static function getStats() {
        $stats = [
            'instance_count' =\u003e self::getInstanceCount(),
            'available_types' =\u003e self::getAvailableTypes(),
            'default_type' =\u003e self::getDefaultType(),
            'instances' =\u003e []
        ];
        
        foreach (self::$instances as $instanceId =\u003e $instance) {
            if (method_exists($instance, 'getStats')) {
                $stats['instances'][$instanceId] = $instance-\u003 egetStats();
            } else {
                $stats['instances'][$instanceId] = 'no_stats';
            }
        }
        
        return $stats;
    }
    
    /**
     * 预加载所有缓存类型
     */
    public static function preloadAllTypes() {
        foreach ([self::TYPE_REDIS, self::TYPE_MEMCACHED, self::TYPE_FILE, self::TYPE_NULL] as $type) {
            try {
                if (self::isCacheAvailable($type)) {
                    self::getInstance($type, 'preload');
                }
            } catch (Exception $e) {
                // 忽略加载错误
            }
        }
    }
    
    /**
     * 初始化缓存系统
     */
    public static function init() {
        // 加载配置
        self::loadConfig();
        
        // 检查默认缓存类型是否可用
        $defaultType = self::getDefaultType();
        if (!self::isCacheAvailable($defaultType)) {
            // 如果默认类型不可用，降级到文件缓存
            self::$config['default'] = self::TYPE_FILE;
        }
    }
}

// 初始化缓存工厂
CacheFactory::init();