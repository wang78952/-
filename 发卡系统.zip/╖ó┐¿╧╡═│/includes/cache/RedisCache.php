<?php
/**
 * Redis缓存管理器
 * 提供高效的数据缓存、缓存管理、分布式锁和会话存储功能
 */
require_once __DIR__ . '/../PHPExtensions.php';

class RedisCache {
    private $redis;
    private $config;
    private $connected = false;
    private $prefix;
    private $logger;
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->config = $this->loadConfig();
        $this->prefix = $this->config['prefix'] ?? 'card_system:';
        $this->logger = new Logger();
        $this->connect();
    }
    
    /**
     * 加载Redis配置
     */
    private function loadConfig() {
        $config = [];
        
        if (file_exists(ROOT_PATH . '/config/redis_config.php')) {
            include ROOT_PATH . '/config/redis_config.php';
        }
        
        // 默认配置，不使用Redis常量
        return array_merge([
            'host' => '127.0.0.1',
            'port' => 6379,
            'password' => '',
            'database' => 0,
            'prefix' => 'card_system:',
            'timeout' => 5,
            'retry_interval' => 100,
            'max_retries' => 3,
            'serializer' => 1 // 1 是Redis::SERIALIZER_PHP的数值
        ], $config);
    }
    
    /**
     * 连接Redis服务器
     */
    private function connect() {
        try {
            if (class_exists('Redis')) {
                $this->redis = new Redis();
                $this->redis->pconnect($this->config['host'], $this->config['port'], $this->config['timeout']);
                
                if ($this->config['password']) {
                    $this->redis->auth($this->config['password']);
                }
                
                $this->redis->select($this->config['database']);
                
                // 安全设置选项，不直接使用Redis常量
                // OPT_SERIALIZER = 1, OPT_PREFIX_KEY = 4
                try {
                    $this->redis->setOption(1, $this->config['serializer']); // OPT_SERIALIZER
                    $this->redis->setOption(4, $this->prefix); // OPT_PREFIX_KEY
                } catch (Exception $e) {
                    // 如果设置选项失败，继续执行而不中断
                    $this->logger->log('Redis设置选项失败: ' . $e->getMessage(), 'warning', 'cache');
                }
                
                $this->connected = true;
                $this->logger->log('Redis连接成功', 'success', 'cache');
            } else {
                $this->logger->log('Redis扩展未安装，缓存系统已禁用', 'warning', 'cache');
            }
        } catch (Exception $e) {
            $this->logger->log('Redis连接失败: ' . $e->getMessage(), 'error', 'cache');
        }
    }
    
    /**
     * 检查连接状态，自动重连
     */
    private function checkConnection() {
        if (!$this->connected) {
            $this->connect();
        }
        
        // 测试连接
        if ($this->connected) {
            try {
                $this->redis->ping();
            } catch (Exception $e) {
                $this->connected = false;
                $this->connect();
            }
        }
        
        return $this->connected;
    }
    
    /**
     * 设置缓存
     * @param string $key 缓存键名
     * @param mixed $value 缓存值
     * @param int $expire 过期时间(秒)，默认3600秒
     * @return bool 是否成功
     */
    public function set($key, $value, $expire = 3600) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            if ($expire > 0) {
                return $this->redis->setex($key, $expire, $value);
            } else {
                return $this->redis->set($key, $value);
            }
        } catch (Exception $e) {
            $this->logger->log("缓存设置失败 [{$key}]: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 获取缓存
     * @param string $key 缓存键名
     * @param mixed $default 默认值
     * @return mixed 缓存值或默认值
     */
    public function get($key, $default = null) {
        if (!$this->checkConnection()) {
            return $default;
        }
        
        try {
            $value = $this->redis->get($key);
            return $value === false ? $default : $value;
        } catch (Exception $e) {
            $this->logger->log("缓存获取失败 [{$key}]: " . $e->getMessage(), 'error', 'cache');
            return $default;
        }
    }
    
    /**
     * 批量设置缓存
     * @param array $items 键值对数组
     * @param int $expire 过期时间(秒)
     * @return bool 是否成功
     */
    public function mset($items, $expire = 3600) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            $pipe = $this->redis->pipeline();
            
            foreach ($items as $key => $value) {
                if ($expire > 0) {
                    $pipe->setex($key, $expire, $value);
                } else {
                    $pipe->set($key, $value);
                }
            }
            
            $pipe->exec();
            return true;
        } catch (Exception $e) {
            $this->logger->log("批量缓存设置失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 批量获取缓存
     * @param array $keys 键名数组
     * @return array 键值对数组
     */
    public function mget($keys) {
        if (!$this->checkConnection()) {
            return array_fill_keys($keys, null);
        }
        
        try {
            $values = $this->redis->mget($keys);
            $result = [];
            
            foreach ($keys as $index => $key) {
                $result[$key] = $values[$index] !== false ? $values[$index] : null;
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->log("批量缓存获取失败: " . $e->getMessage(), 'error', 'cache');
            return array_fill_keys($keys, null);
        }
    }
    
    /**
     * 删除缓存
     * @param string|array $keys 键名或键名数组
     * @return int 删除的键数量
     */
    public function delete($keys) {
        if (!$this->checkConnection()) {
            return 0;
        }
        
        try {
            return $this->redis->del($keys);
        } catch (Exception $e) {
            $this->logger->log("缓存删除失败: " . $e->getMessage(), 'error', 'cache');
            return 0;
        }
    }
    
    /**
     * 清空所有缓存
     * @return bool 是否成功
     */
    public function flush() {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            // 只清空当前数据库中的缓存，保留其他数据库的数据
            return $this->redis->flushDB();
        } catch (Exception $e) {
            $this->logger->log("缓存清空失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 检查键是否存在
     * @param string $key 键名
     * @return bool 是否存在
     */
    public function exists($key) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            return $this->redis->exists($key) > 0;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 设置过期时间
     * @param string $key 键名
     * @param int $expire 过期时间(秒)
     * @return bool 是否成功
     */
    public function expire($key, $expire) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            return $this->redis->expire($key, $expire);
        } catch (Exception $e) {
            $this->logger->log("设置过期时间失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 获取剩余过期时间
     * @param string $key 键名
     * @return int 剩余秒数，-1表示永不过期，-2表示键不存在
     */
    public function ttl($key) {
        if (!$this->checkConnection()) {
            return -2;
        }
        
        try {
            return $this->redis->ttl($key);
        } catch (Exception $e) {
            return -2;
        }
    }
    
    /**
     * 增加计数器
     * @param string $key 键名
     * @param int $value 增加的值，默认1
     * @return int 增加后的值或false
     */
    public function incr($key, $value = 1) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            if ($value == 1) {
                return $this->redis->incr($key);
            } else {
                return $this->redis->incrBy($key, $value);
            }
        } catch (Exception $e) {
            $this->logger->log("计数器增加失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 减少计数器
     * @param string $key 键名
     * @param int $value 减少的值，默认1
     * @return int 减少后的值或false
     */
    public function decr($key, $value = 1) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            if ($value == 1) {
                return $this->redis->decr($key);
            } else {
                return $this->redis->decrBy($key, $value);
            }
        } catch (Exception $e) {
            $this->logger->log("计数器减少失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 列表操作：左推入
     * @param string $key 键名
     * @param mixed $value 值
     * @param int $maxLength 最大长度，0表示不限制
     * @return int 列表长度或false
     */
    public function lpush($key, $value, $maxLength = 0) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            $pipe = $this->redis->pipeline();
            $pipe->lpush($key, $value);
            
            // 限制列表长度
            if ($maxLength > 0) {
                $pipe->ltrim($key, 0, $maxLength - 1);
            }
            
            $results = $pipe->exec();
            return $results[0];
        } catch (Exception $e) {
            $this->logger->log("列表左推失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 列表操作：获取范围
     * @param string $key 键名
     * @param int $start 开始索引
     * @param int $stop 结束索引，-1表示全部
     * @return array 元素数组
     */
    public function lrange($key, $start = 0, $stop = -1) {
        if (!$this->checkConnection()) {
            return [];
        }
        
        try {
            return $this->redis->lrange($key, $start, $stop);
        } catch (Exception $e) {
            $this->logger->log("列表获取失败: " . $e->getMessage(), 'error', 'cache');
            return [];
        }
    }
    
    /**
     * 哈希表操作：设置字段
     * @param string $key 键名
     * @param string $field 字段名
     * @param mixed $value 值
     * @return bool 是否成功
     */
    public function hset($key, $field, $value) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            return $this->redis->hset($key, $field, $value);
        } catch (Exception $e) {
            $this->logger->log("哈希表设置失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 哈希表操作：获取字段
     * @param string $key 键名
     * @param string $field 字段名
     * @param mixed $default 默认值
     * @return mixed 字段值或默认值
     */
    public function hget($key, $field, $default = null) {
        if (!$this->checkConnection()) {
            return $default;
        }
        
        try {
            $value = $this->redis->hget($key, $field);
            return $value === false ? $default : $value;
        } catch (Exception $e) {
            $this->logger->log("哈希表获取失败: " . $e->getMessage(), 'error', 'cache');
            return $default;
        }
    }
    
    /**
     * 哈希表操作：批量设置字段
     * @param string $key 键名
     * @param array $fields 字段值数组
     * @return bool 是否成功
     */
    public function hmset($key, array $fields) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            return $this->redis->hmset($key, $fields);
        } catch (Exception $e) {
            $this->logger->log("哈希表批量设置失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 哈希表操作：获取所有字段和值
     * @param string $key 键名
     * @return array 字段值数组
     */
    public function hgetall($key) {
        if (!$this->checkConnection()) {
            return [];
        }
        
        try {
            return $this->redis->hgetall($key);
        } catch (Exception $e) {
            $this->logger->log("哈希表获取所有失败: " . $e->getMessage(), 'error', 'cache');
            return [];
        }
    }
    
    /**
     * 集合操作：添加元素
     * @param string $key 键名
     * @param mixed $value 值
     * @return int 添加的元素数量
     */
    public function sadd($key, $value) {
        if (!$this->checkConnection()) {
            return 0;
        }
        
        try {
            return $this->redis->sadd($key, $value);
        } catch (Exception $e) {
            $this->logger->log("集合添加失败: " . $e->getMessage(), 'error', 'cache');
            return 0;
        }
    }
    
    /**
     * 集合操作：移除元素
     * @param string $key 键名
     * @param mixed $value 值
     * @return int 移除的元素数量
     */
    public function srem($key, $value) {
        if (!$this->checkConnection()) {
            return 0;
        }
        
        try {
            return $this->redis->srem($key, $value);
        } catch (Exception $e) {
            $this->logger->log("集合移除失败: " . $e->getMessage(), 'error', 'cache');
            return 0;
        }
    }
    
    /**
     * 集合操作：检查元素是否存在
     * @param string $key 键名
     * @param mixed $value 值
     * @return bool 是否存在
     */
    public function sismember($key, $value) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            return $this->redis->sismember($key, $value);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 集合操作：获取所有元素
     * @param string $key 键名
     * @return array 元素数组
     */
    public function smembers($key) {
        if (!$this->checkConnection()) {
            return [];
        }
        
        try {
            return $this->redis->smembers($key);
        } catch (Exception $e) {
            $this->logger->log("集合获取失败: " . $e->getMessage(), 'error', 'cache');
            return [];
        }
    }
    
    /**
     * 设置操作：添加带分数的元素
     * @param string $key 键名
     * @param float $score 分数
     * @param mixed $value 值
     * @return bool 是否成功
     */
    public function zadd($key, $score, $value) {
        if (!$this->checkConnection()) {
            return false;
        }
        
        try {
            return $this->redis->zadd($key, $score, $value);
        } catch (Exception $e) {
            $this->logger->log("有序集合添加失败: " . $e->getMessage(), 'error', 'cache');
            return false;
        }
    }
    
    /**
     * 设置操作：获取分数范围内的元素
     * @param string $key 键名
     * @param float $min 最小分数
     * @param float $max 最大分数
     * @param array $options 选项
     * @return array 元素数组
     */
    public function zrangebyscore($key, $min, $max, $options = []) {
        if (!$this->checkConnection()) {
            return [];
        }
        
        try {
            return $this->redis->zrangebyscore($key, $min, $max, $options);
        } catch (Exception $e) {
            $this->logger->log("有序集合范围获取失败: " . $e->getMessage(), 'error', 'cache');
            return [];
        }
    }
    
    /**
     * 获取Redis原始连接
     * @return Redis|null Redis连接实例
     */
    public function getRedis() {
        if ($this->checkConnection()) {
            return $this->redis;
        }
        return null;
    }
    
    /**
     * 生成缓存键名
     * @param string $key 基础键名
     * @param array $params 参数数组
     * @return string 格式化后的键名
     */
    public function buildKey($key, $params = []) {
        if (empty($params)) {
            return $key;
        }
        
        // 对参数进行排序，确保键名一致
        ksort($params);
        $parts = [$key];
        
        foreach ($params as $name => $value) {
            $parts[] = "{$name}:{$value}";
        }
        
        return implode(':', $parts);
    }
    
    /**
     * 缓存数据并返回
     * @param string $key 键名
     * @param callable $callback 获取数据的回调函数
     * @param int $expire 过期时间
     * @return mixed 缓存的数据
     */
    public function remember($key, callable $callback, $expire = 3600) {
        // 先尝试从缓存获取
        $cached = $this->get($key);
        if ($cached !== null) {
            return $cached;
        }
        
        // 执行回调获取数据
        $data = $callback();
        
        // 缓存数据
        if ($data !== null) {
            $this->set($key, $data, $expire);
        }
        
        return $data;
    }
    
    /**
     * 获取Redis服务器信息
     * @return array 服务器信息
     */
    public function getInfo() {
        if (!$this->checkConnection()) {
            return [];
        }
        
        try {
            return $this->redis->info();
        } catch (Exception $e) {
            return [];
        }
    }
    
    /**
     * 关闭Redis连接
     */
    public function close() {
        if ($this->connected && $this->redis) {
            try {
                $this->redis->close();
            } catch (Exception $e) {
                // 忽略关闭错误
            }
            $this->connected = false;
        }
    }
    
    /**
     * 析构函数
     */
    public function __destruct() {
        $this->close();
    }
}