<?php
/**
 * Redis缓存服务
 * 提供Redis连接管理和缓存操作接口
 */

require_once __DIR__ . '/../../config/cache.php';

class RedisCacheService {
    /**
     * Redis连接实例
     * @var Redis
     */
    private $redis;
    
    /**
     * 缓存配置
     * @var array
     */
    private $config;
    
    /**
     * 缓存前缀
     * @var string
     */
    private $prefix;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 加载缓存配置
        $this->config = $GLOBALS['cache_config']['redis'] ?? [];
        $this->prefix = $this->config['prefix'] ?? 'card_system:';
        $this->redis = null;
        
        // 尝试连接Redis
        $this->connect();
    }
    
    /**
     * 连接到Redis服务器
     * @return bool 连接是否成功
     */
    private function connect() {
        try {
            // 如果Redis扩展不可用，记录错误并返回
            if (!class_exists('Redis')) {
                error_log('Redis扩展未安装，缓存功能不可用');
                return false;
            }
            
            $this->redis = new Redis();
            
            // 连接Redis服务器
            $host = $this->config['host'] ?? '127.0.0.1';
            $port = $this->config['port'] ?? 6379;
            $timeout = $this->config['timeout'] ?? 0.5;
            
            $this->redis->connect($host, $port, $timeout);
            
            // 如果配置了密码，进行认证
            if (!empty($this->config['password'])) {
                $this->redis->auth($this->config['password']);
            }
            
            // 选择数据库
            $database = $this->config['database'] ?? 0;
            $this->redis->select($database);
            
            // 测试连接
            $this->redis->ping();
            
            return true;
        } catch (Exception $e) {
            error_log('Redis连接失败: ' . $e->getMessage());
            $this->redis = null;
            return false;
        }
    }
    
    /**
     * 获取缓存键名
     * @param string $key 原始键名
     * @return string 带前缀的键名
     */
    private function getKey($key) {
        return $this->prefix . $key;
    }
    
    /**
     * 检查缓存是否可用
     * @return bool 缓存是否可用
     */
    public function isAvailable() {
        return $this->redis !== null;
    }
    
    /**
     * 设置缓存
     * @param string $key 缓存键名
     * @param mixed $value 缓存值
     * @param int $expire 过期时间（秒）
     * @return bool 设置是否成功
     */
    public function set($key, $value, $expire = 3600) {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            $jsonValue = json_encode($value);
            
            if ($expire > 0) {
                return $this->redis->setex($cacheKey, $expire, $jsonValue);
            } else {
                return $this->redis->set($cacheKey, $jsonValue);
            }
        } catch (Exception $e) {
            error_log('Redis set缓存失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取缓存
     * @param string $key 缓存键名
     * @param mixed $default 默认值
     * @return mixed 缓存值或默认值
     */
    public function get($key, $default = null) {
        if (!$this->isAvailable()) {
            return $default;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            $value = $this->redis->get($cacheKey);
            
            if ($value === false) {
                return $default;
            }
            
            return json_decode($value, true);
        } catch (Exception $e) {
            error_log('Redis get缓存失败: ' . $e->getMessage());
            return $default;
        }
    }
    
    /**
     * 删除缓存
     * @param string $key 缓存键名
     * @return bool 删除是否成功
     */
    public function delete($key) {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            return $this->redis->del($cacheKey) > 0;
        } catch (Exception $e) {
            error_log('Redis delete缓存失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查缓存是否存在
     * @param string $key 缓存键名
     * @return bool 缓存是否存在
     */
    public function exists($key) {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            return $this->redis->exists($cacheKey) > 0;
        } catch (Exception $e) {
            error_log('Redis exists检查失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 设置缓存过期时间
     * @param string $key 缓存键名
     * @param int $expire 过期时间（秒）
     * @return bool 设置是否成功
     */
    public function expire($key, $expire) {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            return $this->redis->expire($cacheKey, $expire) > 0;
        } catch (Exception $e) {
            error_log('Redis expire设置失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 清除所有缓存（带前缀）
     * @return bool 清除是否成功
     */
    public function clearAll() {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $keys = $this->redis->keys($this->prefix . '*');
            if (!empty($keys)) {
                return $this->redis->del($keys) >= 0;
            }
            return true;
        } catch (Exception $e) {
            error_log('Redis clearAll失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 设置哈希表字段
     * @param string $key 哈希表键名
     * @param string $field 字段名
     * @param mixed $value 字段值
     * @return bool 设置是否成功
     */
    public function hSet($key, $field, $value) {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            $jsonValue = json_encode($value);
            return $this->redis->hSet($cacheKey, $field, $jsonValue);
        } catch (Exception $e) {
            error_log('Redis hSet失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取哈希表字段
     * @param string $key 哈希表键名
     * @param string $field 字段名
     * @param mixed $default 默认值
     * @return mixed 字段值或默认值
     */
    public function hGet($key, $field, $default = null) {
        if (!$this->isAvailable()) {
            return $default;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            $value = $this->redis->hGet($cacheKey, $field);
            
            if ($value === false) {
                return $default;
            }
            
            return json_decode($value, true);
        } catch (Exception $e) {
            error_log('Redis hGet失败: ' . $e->getMessage());
            return $default;
        }
    }
    
    /**
     * 删除哈希表字段
     * @param string $key 哈希表键名
     * @param string $field 字段名
     * @return bool 删除是否成功
     */
    public function hDel($key, $field) {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            return $this->redis->hDel($cacheKey, $field) > 0;
        } catch (Exception $e) {
            error_log('Redis hDel失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 增加计数器
     * @param string $key 计数器键名
     * @param int $value 增加的值
     * @return int 增加后的值
     */
    public function incrBy($key, $value = 1) {
        if (!$this->isAvailable()) {
            return 0;
        }
        
        try {
            $cacheKey = $this->getKey($key);
            return $this->redis->incrBy($cacheKey, $value);
        } catch (Exception $e) {
            error_log('Redis incrBy失败: ' . $e->getMessage());
            return 0;
        }
    }
}