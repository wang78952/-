<?php
/**
 * 性能优化管理器
 * 提供系统级别的性能优化和资源管理功能
 */

class PerformanceOptimizer {
    /**
     * 性能配置
     * @var array
     */
    protected $config = [
        'enable_opcache' => true,
        'enable_caching' => true,
        'cache_driver' => 'file', // file, memcached, redis
        'cache_ttl' => 3600, // 默认缓存时间（秒）
        'minify_html' => true,
        'minify_css' => true,
        'minify_js' => true,
        'enable_compression' => true,
        'enable_brotli' => true,
        'enable_gzip' => true,
        'prefetch_resources' => true,
        'lazy_load_images' => true,
        'optimize_database' => true,
        'enable_query_cache' => true,
        'enable_object_cache' => true,
        'memory_limit' => '512M',
        'max_execution_time' => 30,
        'enable_profiling' => false,
        'enable_performance_logging' => false,
        'performance_log_path' => '/logs/performance.log',
        'cache_dir' => '/cache',
        'enable_async_loading' => true,
        'prioritize_critical_css' => true,
        'defer_non_critical_js' => true,
        'optimize_font_loading' => true,
        'enable_service_worker' => false,
        'enable_http2_push' => false,
        'max_upload_size' => '10M',
        'max_input_vars' => 1000,
        'enable_page_caching' => true,
        'page_cache_ttl' => 600, // 页面缓存时间（秒）
        'enable_browser_caching' => true,
        'browser_cache_ttl' => 86400, // 浏览器缓存时间（秒）
        'optimize_images' => true,
        'image_compression_quality' => 85,
        'enable_resource_hints' => true,
        'enable_database_indexing' => true,
        'enable_result_caching' => true,
    ];
    
    /**
     * 单例实例
     * @var PerformanceOptimizer
     */
    protected static $instance = null;
    
    /**
     * 缓存对象
     * @var object
     */
    protected $cache = null;
    
    /**
     * 性能指标数据
     * @var array
     */
    protected $performanceData = [
        'start_time' => 0,
        'end_time' => 0,
        'memory_usage' => 0,
        'peak_memory_usage' => 0,
        'database_queries' => 0,
        'cache_hits' => 0,
        'cache_misses' => 0,
        'execution_time' => 0,
    ];
    
    /**
     * 已注册的优化器
     * @var array
     */
    protected $optimizers = [];
    
    /**
     * 构造函数
     * @param array $config 性能配置
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge($this->config, $config);
        
        // 初始化性能优化
        $this->initializePerformance();
        
        // 开始性能计时
        $this->startPerformanceTracking();
        
        // 注册自动加载
        spl_autoload_register([$this, 'autoloadPerformanceClasses']);
        
        // 注册关闭函数
        register_shutdown_function([$this, 'shutdown']);
    }
    
    /**
     * 获取单例实例
     * @param array $config 性能配置
     * @return PerformanceOptimizer
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化性能优化
     */
    protected function initializePerformance() {
        // 设置PHP配置
        $this->setPHPConfiguration();
        
        // 启用缓存
        if ($this->config['enable_caching']) {
            $this->initializeCache();
        }
        
        // 启用压缩
        if ($this->config['enable_compression']) {
            $this->enableCompression();
        }
        
        // 启用OPcache
        if ($this->config['enable_opcache'] && function_exists('opcache_get_status')) {
            $this->enableOPcache();
        }
        
        // 初始化优化器
        $this->initializeOptimizers();
        
        // 设置浏览器缓存头
        if ($this->config['enable_browser_caching']) {
            $this->setBrowserCacheHeaders();
        }
        
        // 初始化实时监控
        if ($this->config['enable_real_time_metrics']) {
            $this->initializeRealTimeMonitoring();
        }
    }
    
    /**
     * 初始化数据库连接
     */
    protected function initializeDatabaseConnection() {
        try {
            // 尝试使用全局数据库连接
            if (defined('DB_HOST') && defined('DB_USER') && defined('DB_PASS') && defined('DB_NAME')) {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_PERSISTENT => true
                ];
                $this->db = new PDO($dsn, DB_USER, DB_PASS, $options);
            }
        } catch (Exception $e) {
            $this->logPerformanceEvent('数据库连接初始化失败', $e->getMessage());
        }
    }
    
    /**
     * 初始化实时监控
     */
    protected function initializeRealTimeMonitoring() {
        // 检查必要的表是否存在
        $this->ensureMetricsTablesExist();
        
        // 收集初始指标
        $this->collectRealTimeMetrics();
    }
    
    /**
     * 确保性能指标表存在
     */
    protected function ensureMetricsTablesExist() {
        if ($this->db === null) return;
        
        try {
            // 创建性能指标表
            $this->db->exec("CREATE TABLE IF NOT EXISTS performance_metrics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                server_load_1min FLOAT,
                server_load_5min FLOAT,
                server_load_15min FLOAT,
                cpu_usage FLOAT,
                memory_usage FLOAT,
                memory_total BIGINT,
                memory_used BIGINT,
                disk_usage FLOAT,
                db_connections_active INT,
                db_connections_idle INT,
                db_connections_max INT,
                db_connection_pool_usage FLOAT,
                avg_query_time FLOAT,
                slow_queries INT,
                api_avg_response_time FLOAT,
                api_p95_response_time FLOAT,
                api_p99_response_time FLOAT,
                collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_collected_at (collected_at)
            )");
            
            // 创建API响应时间表
            $this->db->exec("CREATE TABLE IF NOT EXISTS api_response_times (
                id INT AUTO_INCREMENT PRIMARY KEY,
                endpoint VARCHAR(255),
                method VARCHAR(10),
                response_time FLOAT,
                status_code INT,
                request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_endpoint (endpoint),
                INDEX idx_request_time (request_time)
            )");
        } catch (Exception $e) {
            $this->logPerformanceEvent('创建性能指标表失败', $e->getMessage());
        }
    }
    
    /**
     * 获取服务器负载
     * @return array 负载信息
     */
    public function getServerLoad() {
        $load = [
            '1min' => 0,
            '5min' => 0,
            '15min' => 0
        ];
        
        // Linux/Unix系统
        if (function_exists('sys_getloadavg')) {
            $loadAvg = sys_getloadavg();
            if (count($loadAvg) >= 3) {
                $load['1min'] = $loadAvg[0];
                $load['5min'] = $loadAvg[1];
                $load['15min'] = $loadAvg[2];
            }
        } 
        // Windows系统
        else if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            // 使用WMIC命令获取CPU使用率
            $output = [];
            exec('wmic cpu get loadpercentage /format:list', $output);
            if (!empty($output)) {
                $cpuUsage = 0;
                foreach ($output as $line) {
                    if (strpos($line, 'LoadPercentage=') === 0) {
                        $cpuUsage = intval(str_replace('LoadPercentage=', '', $line));
                        break;
                    }
                }
                // 将CPU使用率转换为类似负载的值
                $load['1min'] = $cpuUsage / 100;
                $load['5min'] = $cpuUsage / 100;
                $load['15min'] = $cpuUsage / 100;
            }
        }
        
        // 更新性能数据
        $this->performanceData['server_load'] = $load;
        return $load;
    }
    
    /**
     * 监控数据库连接池
     * @param PDO $connection 数据库连接对象（可选）
     * @return array 连接池状态
     */
    public function monitorDatabaseConnectionPool($connection = null) {
        $db = $connection ?: $this->db;
        if ($db === null) return $this->performanceData['database'];
        
        $connectionStats = [
            'active_connections' => 0,
            'idle_connections' => 0,
            'max_connections' => 0,
            'connection_pool_usage' => 0,
            'avg_query_time' => 0,
            'slow_queries' => 0
        ];
        
        try {
            // 获取最大连接数
            $stmt = $db->query("SHOW VARIABLES LIKE 'max_connections'");
            $result = $stmt->fetch();
            $connectionStats['max_connections'] = $result ? intval($result['Value']) : 151;
            
            // 获取活跃和空闲连接数
            $stmt = $db->query("SELECT COUNT(*) as active FROM information_schema.processlist WHERE command != 'Sleep'");
            $connectionStats['active_connections'] = $stmt->fetchColumn();
            
            $stmt = $db->query("SELECT COUNT(*) as idle FROM information_schema.processlist WHERE command = 'Sleep'");
            $connectionStats['idle_connections'] = $stmt->fetchColumn();
            
            // 计算连接池使用率
            $totalConnections = $connectionStats['active_connections'] + $connectionStats['idle_connections'];
            $connectionStats['connection_pool_usage'] = ($connectionStats['max_connections'] > 0) 
                ? ($totalConnections / $connectionStats['max_connections']) * 100 
                : 0;
            
            // 获取慢查询数量
            $stmt = $db->query("SHOW GLOBAL STATUS LIKE 'Slow_queries'");
            $result = $stmt->fetch();
            $connectionStats['slow_queries'] = $result ? intval($result['Value']) : 0;
            
            // 获取平均查询时间（如果有慢查询日志表）
            try {
                $stmt = $db->query("SELECT AVG(query_time) as avg_time FROM mysql.slow_log WHERE start_time > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
                $avgTime = $stmt->fetchColumn();
                $connectionStats['avg_query_time'] = $avgTime ? floatval($avgTime) : 0;
            } catch (Exception $e) {
                // 慢查询日志表可能不存在，使用0
            }
        } catch (Exception $e) {
            $this->logPerformanceEvent('数据库连接池监控失败', $e->getMessage());
        }
        
        // 更新性能数据
        $this->performanceData['database'] = array_merge($this->performanceData['database'], $connectionStats);
        return $connectionStats;
    }
    
    /**
     * 开始API调用跟踪
     * @param string $endpoint API端点
     * @param string $method HTTP方法
     */
    public function startApiCallTracking($endpoint, $method = 'GET') {
        if (!$this->config['enable_api_response_tracking']) return;
        
        $this->apiCallStack[] = [
            'endpoint' => $endpoint,
            'method' => $method,
            'start_time' => microtime(true),
            'status_code' => 0
        ];
    }
    
    /**
     * 结束API调用跟踪
     * @param int $statusCode HTTP状态码
     * @return float 响应时间（毫秒）
     */
    public function endApiCallTracking($statusCode = 200) {
        if (!$this->config['enable_api_response_tracking'] || empty($this->apiCallStack)) return 0;
        
        $callInfo = array_pop($this->apiCallStack);
        $endTime = microtime(true);
        $responseTime = ($endTime - $callInfo['start_time']) * 1000; // 转换为毫秒
        
        // 记录响应时间
        $this->performanceData['api']['response_times'][] = $responseTime;
        
        // 更新统计数据
        $this->updateApiResponseStats();
        
        // 保存到数据库
        $this->saveApiResponseTime($callInfo['endpoint'], $callInfo['method'], $responseTime, $statusCode);
        
        return $responseTime;
    }
    
    /**
     * 更新API响应时间统计
     */
    protected function updateApiResponseStats() {
        $responseTimes = $this->performanceData['api']['response_times'];
        if (empty($responseTimes)) return;
        
        // 计算平均响应时间
        $this->performanceData['api']['avg_response_time'] = array_sum($responseTimes) / count($responseTimes);
        
        // 计算P95和P99响应时间
        sort($responseTimes);
        $count = count($responseTimes);
        $this->performanceData['api']['p95_response_time'] = $responseTimes[floor($count * 0.95)];
        $this->performanceData['api']['p99_response_time'] = $responseTimes[floor($count * 0.99)];
    }
    
    /**
     * 保存API响应时间到数据库
     */
    protected function saveApiResponseTime($endpoint, $method, $responseTime, $statusCode) {
        if ($this->db === null) return;
        
        try {
            $stmt = $this->db->prepare("INSERT INTO api_response_times (endpoint, method, response_time, status_code) VALUES (?, ?, ?, ?)");
            $stmt->execute([$endpoint, $method, $responseTime, $statusCode]);
        } catch (Exception $e) {
            $this->logPerformanceEvent('保存API响应时间失败', $e->getMessage());
        }
    }
    
    /**
     * 收集实时性能指标
     * @return array 性能指标
     */
    public function collectRealTimeMetrics() {
        $now = time();
        
        // 检查是否需要收集新的指标
        if ($now - $this->performanceData['last_metrics_collected'] < $this->config['metrics_collection_interval']) {
            return $this->getPerformanceData();
        }
        
        // 收集服务器负载
        $this->getServerLoad();
        
        // 收集数据库连接池信息
        $this->monitorDatabaseConnectionPool();
        
        // 收集内存使用情况
        $memory = $this->getMemoryUsage();
        
        // 收集磁盘使用情况
        $disk = $this->getDiskUsage();
        
        // 保存指标到数据库
        $this->saveMetricsToDatabase();
        
        // 更新最后收集时间
        $this->performanceData['last_metrics_collected'] = $now;
        
        // 清理旧的API响应时间记录
        $this->cleanupOldApiResponseTimes();
        
        return $this->getPerformanceData();
    }
    
    /**
     * 获取内存使用情况
     * @return array 内存信息
     */
    public function getMemoryUsage() {
        $memory = [
            'usage_percent' => 0,
            'total' => 0,
            'used' => 0,
            'free' => 0
        ];
        
        // 获取PHP内存使用
        $memory['used'] = memory_get_usage(true);
        
        // 尝试获取系统内存信息
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            // Windows系统
            $output = [];
            exec('wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /Value', $output);
            
            $totalMemory = 0;
            $freeMemory = 0;
            
            foreach ($output as $line) {
                if (strpos($line, 'TotalVisibleMemorySize=') === 0) {
                    $totalMemory = intval(str_replace('TotalVisibleMemorySize=', '', $line)) * 1024;
                } else if (strpos($line, 'FreePhysicalMemory=') === 0) {
                    $freeMemory = intval(str_replace('FreePhysicalMemory=', '', $line)) * 1024;
                }
            }
            
            $memory['total'] = $totalMemory;
            $memory['free'] = $freeMemory;
            $memory['used'] = $totalMemory - $freeMemory;
            $memory['usage_percent'] = ($totalMemory > 0) ? (($memory['used'] / $totalMemory) * 100) : 0;
        } else {
            // Linux/Unix系统
            if (file_exists('/proc/meminfo')) {
                $meminfo = file_get_contents('/proc/meminfo');
                preg_match('/MemTotal:\s+(\d+) kB/', $meminfo, $totalMatches);
                preg_match('/MemAvailable:\s+(\d+) kB/', $meminfo, $freeMatches);
                
                if (isset($totalMatches[1]) && isset($freeMatches[1])) {
                    $memory['total'] = $totalMatches[1] * 1024;
                    $memory['free'] = $freeMatches[1] * 1024;
                    $memory['used'] = $memory['total'] - $memory['free'];
                    $memory['usage_percent'] = ($memory['total'] > 0) ? (($memory['used'] / $memory['total']) * 100) : 0;
                }
            }
        }
        
        return $memory;
    }
    
    /**
     * 获取磁盘使用情况
     * @return float 使用率百分比
     */
    public function getDiskUsage() {
        $usagePercent = 0;
        
        // 获取网站根目录的磁盘使用情况
        $rootDir = $_SERVER['DOCUMENT_ROOT'] ?? '/';
        
        if (function_exists('disk_free_space') && function_exists('disk_total_space')) {
            $freeSpace = disk_free_space($rootDir);
            $totalSpace = disk_total_space($rootDir);
            
            if ($totalSpace > 0) {
                $usagePercent = (($totalSpace - $freeSpace) / $totalSpace) * 100;
            }
        }
        
        return $usagePercent;
    }
    
    /**
     * 保存性能指标到数据库
     */
    protected function saveMetricsToDatabase() {
        if ($this->db === null) return;
        
        try {
            $memory = $this->getMemoryUsage();
            $diskUsage = $this->getDiskUsage();
            
            $stmt = $this->db->prepare("
                INSERT INTO performance_metrics (
                    server_load_1min, server_load_5min, server_load_15min,
                    cpu_usage, memory_usage, memory_total, memory_used,
                    disk_usage, db_connections_active, db_connections_idle,
                    db_connections_max, db_connection_pool_usage, avg_query_time,
                    slow_queries, api_avg_response_time, api_p95_response_time,
                    api_p99_response_time
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $this->performanceData['server_load']['1min'],
                $this->performanceData['server_load']['5min'],
                $this->performanceData['server_load']['15min'],
                0, // CPU使用率（需要额外收集）
                $memory['usage_percent'],
                $memory['total'],
                $memory['used'],
                $diskUsage,
                $this->performanceData['database']['active_connections'],
                $this->performanceData['database']['idle_connections'],
                $this->performanceData['database']['max_connections'],
                $this->performanceData['database']['connection_pool_usage'],
                $this->performanceData['database']['avg_query_time'],
                $this->performanceData['database']['slow_queries'],
                $this->performanceData['api']['avg_response_time'],
                $this->performanceData['api']['p95_response_time'],
                $this->performanceData['api']['p99_response_time']
            ]);
            
            // 清理旧的性能指标
            $retentionDays = $this->config['metrics_retention_days'] ?? 7;
            $this->db->exec("DELETE FROM performance_metrics WHERE collected_at < DATE_SUB(NOW(), INTERVAL {$retentionDays} DAY)");
        } catch (Exception $e) {
            $this->logPerformanceEvent('保存性能指标失败', $e->getMessage());
        }
    }
    
    /**
     * 清理旧的API响应时间记录
     */
    protected function cleanupOldApiResponseTimes() {
        if ($this->db === null) return;
        
        try {
            // 保留24小时的数据
            $this->db->exec("DELETE FROM api_response_times WHERE request_time < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        } catch (Exception $e) {
            $this->logPerformanceEvent('清理旧API响应时间记录失败', $e->getMessage());
        }
    }
    
    /**
     * 获取实时性能指标摘要
     * @return array 性能指标摘要
     */
    public function getRealTimeMetricsSummary() {
        $this->collectRealTimeMetrics();
        
        return [
            'server_load' => $this->performanceData['server_load'],
            'database' => [
                'connection_pool_usage' => $this->performanceData['database']['connection_pool_usage'],
                'active_connections' => $this->performanceData['database']['active_connections'],
                'max_connections' => $this->performanceData['database']['max_connections'],
                'slow_queries' => $this->performanceData['database']['slow_queries']
            ],
            'api' => [
                'avg_response_time' => $this->performanceData['api']['avg_response_time'],
                'p95_response_time' => $this->performanceData['api']['p95_response_time'],
                'p99_response_time' => $this->performanceData['api']['p99_response_time']
            ],
            'memory' => $this->getMemoryUsage(),
            'disk_usage' => $this->getDiskUsage(),
            'last_updated' => date('Y-m-d H:i:s', $this->performanceData['last_metrics_collected'])
        ];
    }
    
    /**
     * 获取历史性能指标
     * @param string $timeRange 时间范围 (e.g., '1h', '6h', '24h', '7d')
     * @return array 历史指标
     */
    public function getHistoricalMetrics($timeRange = '1h') {
        if ($this->db === null) return [];
        
        // 解析时间范围
        $interval = 1; // 默认1分钟
        $period = 'HOUR';
        
        switch ($timeRange) {
            case '1h':
                $period = 'HOUR';
                $interval = 1;
                break;
            case '6h':
                $period = 'HOUR';
                $interval = 6;
                break;
            case '24h':
                $period = 'DAY';
                $interval = 1;
                break;
            case '7d':
                $period = 'DAY';
                $interval = 7;
                break;
        }
        
        try {
            $stmt = $this->db->prepare("SELECT * FROM performance_metrics WHERE collected_at >= DATE_SUB(NOW(), INTERVAL ? ?) ORDER BY collected_at ASC");
            $stmt->execute([$interval, $period]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $this->logPerformanceEvent('获取历史性能指标失败', $e->getMessage());
            return [];
        }
    }
    
    /**
     * 检查性能指标是否超过阈值
     * @param array $thresholds 阈值配置
     * @return array 超过阈值的指标
     */
    public function checkThresholds($thresholds = []) {
        $this->collectRealTimeMetrics();
        $alerts = [];
        
        // 默认阈值
        $defaultThresholds = [
            'server_load' => 8.0, // 假设8核CPU
            'db_connection_pool_usage' => 80.0, // 百分比
            'api_response_time' => 500.0, // 毫秒
            'memory_usage' => 90.0, // 百分比
            'disk_usage' => 90.0 // 百分比
        ];
        
        $thresholds = array_merge($defaultThresholds, $thresholds);
        
        // 检查服务器负载
        if ($this->performanceData['server_load']['1min'] > $thresholds['server_load']) {
            $alerts[] = [
                'type' => 'server_load',
                'severity' => 'warning',
                'message' => "服务器负载过高: {$this->performanceData['server_load']['1min']}",
                'value' => $this->performanceData['server_load']['1min'],
                'threshold' => $thresholds['server_load']
            ];
        }
        
        // 检查数据库连接池使用率
        if ($this->performanceData['database']['connection_pool_usage'] > $thresholds['db_connection_pool_usage']) {
            $alerts[] = [
                'type' => 'db_connection_pool',
                'severity' => 'warning',
                'message' => "数据库连接池使用率过高: {$this->performanceData['database']['connection_pool_usage']}%",
                'value' => $this->performanceData['database']['connection_pool_usage'],
                'threshold' => $thresholds['db_connection_pool_usage']
            ];
        }
        
        // 检查API响应时间
        if ($this->performanceData['api']['avg_response_time'] > $thresholds['api_response_time']) {
            $alerts[] = [
                'type' => 'api_response_time',
                'severity' => 'warning',
                'message' => "API平均响应时间过长: {$this->performanceData['api']['avg_response_time']}ms",
                'value' => $this->performanceData['api']['avg_response_time'],
                'threshold' => $thresholds['api_response_time']
            ];
        }
        
        // 检查内存使用率
        $memory = $this->getMemoryUsage();
        if ($memory['usage_percent'] > $thresholds['memory_usage']) {
            $alerts[] = [
                'type' => 'memory_usage',
                'severity' => 'warning',
                'message' => "内存使用率过高: {$memory['usage_percent']}%",
                'value' => $memory['usage_percent'],
                'threshold' => $thresholds['memory_usage']
            ];
        }
        
        // 检查磁盘使用率
        $diskUsage = $this->getDiskUsage();
        if ($diskUsage > $thresholds['disk_usage']) {
            $alerts[] = [
                'type' => 'disk_usage',
                'severity' => 'warning',
                'message' => "磁盘使用率过高: {$diskUsage}%",
                'value' => $diskUsage,
                'threshold' => $thresholds['disk_usage']
            ];
        }
        
        return $alerts;
    }

// ... existing code ...
    
    /**
     * 设置PHP配置
     */
    protected function setPHPConfiguration() {
        // 内存限制
        if (!empty($this->config['memory_limit'])) {
            ini_set('memory_limit', $this->config['memory_limit']);
        }
        
        // 最大执行时间
        if (!empty($this->config['max_execution_time'])) {
            set_time_limit($this->config['max_execution_time']);
        }
        
        // 最大输入变量数
        if (!empty($this->config['max_input_vars'])) {
            ini_set('max_input_vars', $this->config['max_input_vars']);
        }
        
        // 启用实时Zend OPcache（如果可用）
        if (function_exists('opcache_compile_file')) {
            ini_set('opcache.enable', 1);
            ini_set('opcache.enable_cli', 1);
            ini_set('opcache.memory_consumption', 128);
            ini_set('opcache.interned_strings_buffer', 8);
            ini_set('opcache.max_accelerated_files', 10000);
            ini_set('opcache.validate_timestamps', 1);
            ini_set('opcache.revalidate_freq', 60);
            ini_set('opcache.fast_shutdown', 1);
        }
        
        // 启用输出缓冲
        if (!ob_get_level()) {
            ob_start();
        }
        
        // 会话优化
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_cache_limiter('private, must-revalidate');
            session_cache_expire(180);
        }
        
        // 文件上传优化
        if (!empty($this->config['max_upload_size'])) {
            $maxSize = $this->convertToBytes($this->config['max_upload_size']);
            ini_set('upload_max_filesize', $this->config['max_upload_size']);
            ini_set('post_max_size', $this->config['max_upload_size']);
        }
        
        // 启用性能监控相关设置
        if ($this->config['enable_real_time_metrics']) {
            // 启用最大执行时间记录
            ini_set('max_execution_time', 60); // 为性能监控留出足够时间
            // 启用错误显示（仅在开发环境）
            if (defined('APP_ENV') && APP_ENV === 'development') {
                ini_set('display_errors', 1);
                error_reporting(E_ALL);
            }
        }
    }
    
    /**
     * 结束性能跟踪
     */
    public function endPerformanceTracking() {
        $this->performanceData['end_time'] = microtime(true);
        $this->performanceData['peak_memory_usage'] = memory_get_peak_usage(true);
        $this->performanceData['execution_time'] = $this->performanceData['end_time'] - $this->performanceData['start_time'];
    }
    
    /**
     * 获取性能数据
     * @return array 性能数据
     */
    public function getPerformanceData() {
        $this->endPerformanceTracking();
        
        // 确保收集最新的实时指标
        $this->collectRealTimeMetrics();
        
        return $this->performanceData;
    }
    
    /**
     * 关闭函数
     */
    public function shutdown() {
        $this->endPerformanceTracking();
        
        // 压缩输出缓冲区
        if ($this->config['minify_html']) {
            $this->compressOutputBuffer();
        }
        
        // 记录性能数据
        if ($this->config['enable_performance_logging']) {
            $this->logPerformanceEvent('页面执行完成');
        }
        
        // 保存最终性能指标
        if ($this->config['enable_real_time_metrics']) {
            $this->saveMetricsToDatabase();
        }
    }
    
    /**
     * 执行性能分析
     * @param callable $callback 要分析的函数
     * @return array 分析结果
     */
    public function profile(callable $callback) {
        if (!$this->config['enable_profiling']) {
            return call_user_func($callback);
        }
        
        $startTime = microtime(true);
        $startMemory = memory_get_usage();
        
        // 执行函数
        $result = call_user_func($callback);
        
        $endTime = microtime(true);
        $endMemory = memory_get_usage();
        
        return [
            'result' => $result,
            'execution_time' => $endTime - $startTime,
            'memory_used' => $endMemory - $startMemory
        ];
    }
}

// 初始化性能优化器的便捷函数
function initializePerformance($config = []) {
    return PerformanceOptimizer::getInstance($config);
}

// 性能优化助手函数
function minify_html($html) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->minifyHTML($html);
}

function minify_css($css) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->minifyCSS($css);
}

function minify_js($js) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->minifyJS($js);
}

function cache_data($key, $value, $ttl = null) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->setCache($key, $value, $ttl);
}

function get_cached_data($key) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->getCache($key);
}

function delete_cached_data($key) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->deleteCache($key);
}

function clear_cache() {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->clearAllCache();
}

function optimize_image($imagePath, $options = []) {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->optimizeImage($imagePath, $options);
}

function get_performance_data() {
    $optimizer = PerformanceOptimizer::getInstance();
    return $optimizer->getPerformanceData();
}

function start_profiling() {
    $optimizer = PerformanceOptimizer::getInstance();
    $optimizer->startPerformanceTracking();
}

// 全局性能追踪函数

/**
 * 自动加载性能相关类
 * @param string $className 类名
 */
protected function autoloadPerformanceClasses($className) {
    // 检查INCLUDE_PATH常量是否已定义，如未定义则设置默认值
    if (!defined('INCLUDE_PATH')) {
        define('INCLUDE_PATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);
    }
    
    // 性能优化相关类的映射
    $performanceClasses = [
        'CompressionManager' => 'CompressionManager.php',
        'CacheManager' => 'CacheManager.php',
        'QueryOptimizer' => 'QueryOptimizer.php',
        'ResourceOptimizer' => 'ResourceOptimizer.php'
    ];
    
    // 如果是性能优化相关类，则尝试加载
    if (isset($performanceClasses[$className])) {
        $filePath = INCLUDE_PATH . $performanceClasses[$className];
        if (file_exists($filePath)) {
            require_once $filePath;
        }
    }
}

/**
 * 执行数据库维护操作
 */
protected function performDatabaseMaintenance() {
    if (!$this->config['optimize_database'] || $this->db === null) return;
    
    try {
        // 获取数据库中所有表
        $tables = $this->db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($tables as $table) {
            // 检查表是否需要优化（表数据超过1000行或碎片率超过10%）
            $rowCount = $this->db->query("SELECT COUNT(*) FROM $table")->fetchColumn();
            $fragmentation = $this->getTableFragmentation($table);
            
            // 修正逻辑运算符：使用||而不是&&，表示只要满足任一条件就进行优化
            if ($rowCount > 1000 || $fragmentation > 10) {
                // 执行优化操作
                $this->db->exec("OPTIMIZE TABLE $table");
                $this->logPerformanceEvent("优化表 {$table}，行数: {$rowCount}，碎片率: {$fragmentation}%");
            }
        }
    } catch (Exception $e) {
        $this->logPerformanceEvent('数据库维护失败', $e->getMessage());
    }
}

/**
 * 获取表的碎片率
 * @param string $table 表名
 * @return float 碎片率百分比
 */
private function getTableFragmentation($table) {
    try {
        $stmt = $this->db->query("SHOW TABLE STATUS LIKE '$table'");
        $status = $stmt->fetch();
        
        if ($status && $status['Data_free'] > 0) {
            $totalSize = $status['Data_length'] + $status['Index_length'] + $status['Data_free'];
            return ($status['Data_free'] / $totalSize) * 100;
        }
    } catch (Exception $e) {
        // 忽略错误，返回0
    }
    
    return 0;
}

function end_profiling() {
    $optimizer = PerformanceOptimizer::getInstance();
    $optimizer->endPerformanceTracking();
    return $optimizer->getPerformanceData();
}
}