<?php
/**
 * 数据压缩管理器类
 * 提供各种数据压缩和解压缩功能，优化资源传输和存储
 * 
 * @package includes/performance
 */

class CompressionManager {
    /**
     * 支持的压缩算法
     */
    const ALGORITHM_GZIP = 'gzip';
    const ALGORITHM_DEFLATE = 'deflate';
    const ALGORITHM_BROTLI = 'brotli';
    const ALGORITHM_ZLIB = 'zlib';
    
    /**
     * 默认压缩级别
     * @var int
     */
    private $defaultCompressionLevel = 6;
    
    /**
     * 压缩阈值（小于此大小的文件不压缩）
     * @var int
     */
    private $compressionThreshold = 1024; // 1KB
    
    /**
     * 支持的文件类型映射
     * @var array
     */
    private $supportedFileTypes = [
        // 文本类型
        'text/plain' => ['gz', 'br'],
        'text/html' => ['gz', 'br'],
        'text/css' => ['gz', 'br'],
        'text/javascript' => ['gz', 'br'],
        'application/javascript' => ['gz', 'br'],
        'application/json' => ['gz', 'br'],
        'application/xml' => ['gz', 'br'],
        'text/xml' => ['gz', 'br'],
        
        // 二进制类型（选择性压缩）
        'application/octet-stream' => ['gz'],
        'application/pdf' => [], // PDF已经压缩
        'image/jpeg' => [], // 图片已压缩
        'image/png' => [], // 图片已压缩
        'image/gif' => [], // 图片已压缩
        'image/webp' => [], // 图片已压缩
        'audio/mpeg' => [], // 音频已压缩
        'video/mp4' => []  // 视频已压缩
    ];
    
    /**
     * 支持的算法
     * @var array
     */
    private $supportedAlgorithms = [];
    
    /**
     * 构造函数
     * @param array $options 配置选项
     */
    public function __construct(array $options = []) {
        // 确保gzdecode函数存在
        $this->ensureGzdecodeExists();
        
        // 确保brotli相关函数存在
        $this->ensureBrotliFunctionsExist();
        
        // 初始化支持的算法
        $this->initializeSupportedAlgorithms();
        
        // 设置选项
        if (isset($options['compression_level'])) {
            $this->defaultCompressionLevel = max(0, min(9, $options['compression_level']));
        }
        
        if (isset($options['compression_threshold'])) {
            $this->compressionThreshold = max(0, $options['compression_threshold']);
        }
    }
    
    /**
     * 初始化支持的算法
     */
    private function initializeSupportedAlgorithms() {
        // 检查gzip支持（同时需要压缩和解压缩函数）
        if (function_exists('gzencode') && (function_exists('gzdecode') || function_exists('gzinflate'))) {
            $this->supportedAlgorithms[self::ALGORITHM_GZIP] = true;
        }
        
        // 检查deflate支持
        if (function_exists('gzdeflate') && function_exists('gzinflate')) {
            $this->supportedAlgorithms[self::ALGORITHM_DEFLATE] = true;
        }
        
        // 检查zlib支持
        if (function_exists('gzcompress') && function_exists('gzuncompress')) {
            $this->supportedAlgorithms[self::ALGORITHM_ZLIB] = true;
        }
        
        // 检查brotli支持（同时需要压缩和解压缩函数）
        if (function_exists('brotli_compress') && function_exists('brotli_uncompress')) {
            $this->supportedAlgorithms[self::ALGORITHM_BROTLI] = true;
        }
    }
    
    /**
     * 确保Brotli相关函数存在
     * 提供brotli_compress和brotli_uncompress的备选实现
     */
    private function ensureBrotliFunctionsExist() {
        // 提供brotli_compress的备选实现
        if (!function_exists('brotli_compress')) {
            function brotli_compress($data, $quality = 6) {
                // 备选实现：使用gzencode作为替代
                // 注意：这不是真正的Brotli压缩，但可以避免未定义函数错误
                $quality = max(0, min(11, $quality));
                // 将Brotli质量级别(0-11)映射到gzip级别(0-9)
                $gzipLevel = floor(($quality / 11) * 9);
                return gzencode($data, $gzipLevel);
            }
        }
        
        // 提供brotli_uncompress的备选实现
        if (!function_exists('brotli_uncompress')) {
            function brotli_uncompress($data) {
                // 备选实现：尝试使用gzdecode作为替代
                // 注意：这不是真正的Brotli解压缩，但可以避免未定义函数错误
                if (function_exists('gzdecode')) {
                    $result = @gzdecode($data);
                    if ($result !== false) {
                        return $result;
                    }
                }
                
                // 如果gzdecode不可用或失败，尝试gzinflate
                if (function_exists('gzinflate')) {
                    try {
                        // 尝试去掉gzip头部进行解压缩
                        $gzheader = substr($data, 0, 10);
                        $header = @unpack('Cmagic/Cmethod/Cflags/Cmtime/Cextra', $gzheader);
                        if ($header && $header['magic'] === 0x1f && ($header['method'] & 0x0f) === 8) {
                            $flags = $header['flags'];
                            $offset = 10;
                            if ($flags & 4) {
                                $length = unpack('v', substr($data, $offset, 2));
                                $offset += 2 + $length[1];
                            }
                            if ($flags & 8) {
                                $offset = strpos($data, "\0", $offset) + 1;
                            }
                            if ($flags & 16) {
                                $offset = strpos($data, "\0", $offset) + 1;
                            }
                            if ($flags & 2) {
                                $offset += 2;
                            }
                            $body = substr($data, $offset, -8);
                            return @gzinflate($body);
                        }
                    } catch (Exception $e) {
                        // 忽略错误，返回false
                    }
                }
                
                return false;
            }
        }
    }
    
    /**
     * 确保gzdecode函数存在（PHP 5.4+）
     */
    private function ensureGzdecodeExists() {
        if (!function_exists('gzdecode')) {
            function gzdecode($data) {
                // 简化的gzdecode实现
                $gzheader = substr($data, 0, 10);
                $header = unpack('Cmagic/Cmethod/Cflags/Cmtime/Cextra', $gzheader);
                if ($header['magic'] !== 0x1f || ($header['method'] & 0x0f) !== 8) {
                    return false;
                }
                $flags = $header['flags'];
                $offset = 10;
                if ($flags & 4) {
                    $length = unpack('v', substr($data, $offset, 2));
                    $offset += 2 + $length[1];
                }
                if ($flags & 8) {
                    $offset = strpos($data, "\0", $offset) + 1;
                }
                if ($flags & 16) {
                    $offset = strpos($data, "\0", $offset) + 1;
                }
                if ($flags & 2) {
                    $offset += 2;
                }
                $body = substr($data, $offset, -8);
                return gzinflate($body);
            }
        }
    }
    
    /**
     * 检查是否支持指定算法
     * @param string $algorithm 算法名称
     * @return bool 是否支持
     */
    public function isAlgorithmSupported($algorithm) {
        return isset($this->supportedAlgorithms[$algorithm]) && $this->supportedAlgorithms[$algorithm];
    }
    
    /**
     * 获取支持的算法列表
     * @return array 支持的算法
     */
    public function getSupportedAlgorithms() {
        return array_keys(array_filter($this->supportedAlgorithms));
    }
    
    /**
     * 根据内容类型获取最佳压缩算法
     * @param string $contentType 内容类型
     * @return string|null 最佳算法或null
     */
    public function getBestAlgorithmForContentType($contentType) {
        // 移除可能的参数部分
        $contentType = strtok($contentType, ';');
        
        // 检查是否在支持列表中
        if (isset($this->supportedFileTypes[$contentType])) {
            $algorithms = $this->supportedFileTypes[$contentType];
            
            // 按优先级检查：br > gz
            foreach ($algorithms as $ext) {
                if ($ext === 'br' && $this->isAlgorithmSupported(self::ALGORITHM_BROTLI)) {
                    return self::ALGORITHM_BROTLI;
                } elseif ($ext === 'gz' && $this->isAlgorithmSupported(self::ALGORITHM_GZIP)) {
                    return self::ALGORITHM_GZIP;
                }
            }
        }
        
        // 默认返回gzip
        if ($this->isAlgorithmSupported(self::ALGORITHM_GZIP)) {
            return self::ALGORITHM_GZIP;
        }
        
        return null;
    }
    
    /**
     * 压缩数据
     * @param string $data 原始数据
     * @param string $algorithm 压缩算法
     * @param int $level 压缩级别
     * @return string|false 压缩后的数据或false
     */
    public function compress($data, $algorithm = self::ALGORITHM_GZIP, $level = null) {
        // 检查数据大小
        if (strlen($data) < $this->compressionThreshold) {
            return $data; // 太小，不压缩
        }
        
        // 设置压缩级别
        if ($level === null) {
            $level = $this->defaultCompressionLevel;
        }
        $level = max(0, min(9, $level));
        
        // 检查算法支持
        if (!$this->isAlgorithmSupported($algorithm)) {
            return false;
        }
        
        // 根据算法进行压缩
        switch ($algorithm) {
            case self::ALGORITHM_GZIP:
                return @gzencode($data, $level);
                
            case self::ALGORITHM_DEFLATE:
                return @gzdeflate($data, $level);
                
            case self::ALGORITHM_ZLIB:
                return @gzcompress($data, $level);
                
            case self::ALGORITHM_BROTLI:
                // Brotli的压缩级别范围是0-11
                $brotliLevel = max(0, min(11, $level));
                
                // 检查brotli_compress函数是否存在
                if (function_exists('brotli_compress')) {
                    try {
                        return @brotli_compress($data, $brotliLevel);
                    } catch (Exception $e) {
                        // 出错时回退到gzip
                    }
                }
                
                // 如果Brotli不可用或失败，回退到gzip
                if ($this->isAlgorithmSupported(self::ALGORITHM_GZIP)) {
                    return @gzencode($data, $level);
                }
                
                return false;
                
            default:
                return false;
        }
    }
    
    /**
     * 解压缩数据
     * @param string $data 压缩数据
     * @param string $algorithm 压缩算法
     * @return string|false 解压后的数据或false
     */
    public function decompress($data, $algorithm = self::ALGORITHM_GZIP) {
        // 检查算法支持
        if (!$this->isAlgorithmSupported($algorithm)) {
            return false;
        }
        
        // 根据算法进行解压
        switch ($algorithm) {
            case self::ALGORITHM_GZIP:
                // 检查gzdecode函数是否存在
                if (!function_exists('gzdecode')) {
                    // 提供一个简单的gzdecode实现作为备选
                    try {
                        $gzheader = substr($data, 0, 10);
                        $header = @unpack('Cmagic/Cmethod/Cflags/Cmtime/Cextra', $gzheader);
                        if ($header['magic'] !== 0x1f || ($header['method'] & 0x0f) !== 8) {
                            return false;
                        }
                        $flags = $header['flags'];
                        $offset = 10;
                        if ($flags & 4) {
                            $length = unpack('v', substr($data, $offset, 2));
                            $offset += 2 + $length[1];
                        }
                        if ($flags & 8) {
                            $offset = strpos($data, "\0", $offset) + 1;
                        }
                        if ($flags & 16) {
                            $offset = strpos($data, "\0", $offset) + 1;
                        }
                        if ($flags & 2) {
                            $offset += 2;
                        }
                        $body = substr($data, $offset, -8);
                        return @gzinflate($body);
                    } catch (Exception $e) {
                        return false;
                    }
                }
                return @gzdecode($data);
                
            case self::ALGORITHM_DEFLATE:
                return @gzinflate($data);
                
            case self::ALGORITHM_ZLIB:
                return @gzuncompress($data);
                
            case self::ALGORITHM_BROTLI:
                // 检查brotli_uncompress函数是否存在
                if (function_exists('brotli_uncompress')) {
                    try {
                        $result = @brotli_uncompress($data);
                        if ($result !== false) {
                            return $result;
                        }
                    } catch (Exception $e) {
                        // 记录错误，但不中断流程
                    }
                }
                
                // Brotli解压缩失败，返回false
                return false;
                
            default:
                return false;
        }
    }
    
    /**
     * 自动压缩数据（根据内容自动选择算法）
     * @param string $data 原始数据
     * @param string $contentType 内容类型
     * @param int $level 压缩级别
     * @return array 包含压缩数据和使用的算法
     */
    public function autoCompress($data, $contentType = 'text/plain', $level = null) {
        $algorithm = $this->getBestAlgorithmForContentType($contentType);
        
        // 如果没有合适的算法，返回原始数据
        if ($algorithm === null) {
            return [
                'data' => $data,
                'algorithm' => null,
                'compressed' => false
            ];
        }
        
        // 尝试压缩
        $compressed = $this->compress($data, $algorithm, $level);
        
        // 检查压缩是否有效（有时压缩后可能更大）
        if ($compressed !== false && strlen($compressed) < strlen($data)) {
            return [
                'data' => $compressed,
                'algorithm' => $algorithm,
                'compressed' => true
            ];
        }
        
        // 压缩后更大，返回原始数据
        return [
            'data' => $data,
            'algorithm' => null,
            'compressed' => false
        ];
    }
    
    /**
     * 压缩文件
     * @param string $inputFile 输入文件路径
     * @param string $outputFile 输出文件路径
     * @param string $algorithm 压缩算法
     * @param int $level 压缩级别
     * @return bool 是否成功
     */
    public function compressFile($inputFile, $outputFile, $algorithm = self::ALGORITHM_GZIP, $level = null) {
        // 检查输入文件是否存在
        if (!file_exists($inputFile)) {
            return false;
        }
        
        // 检查文件大小
        $fileSize = filesize($inputFile);
        if ($fileSize < $this->compressionThreshold) {
            // 文件太小，直接复制
            return copy($inputFile, $outputFile);
        }
        
        // 读取文件内容
        $data = file_get_contents($inputFile);
        if ($data === false) {
            return false;
        }
        
        // 压缩数据
        $compressed = $this->compress($data, $algorithm, $level);
        if ($compressed === false) {
            return false;
        }
        
        // 写入压缩数据到输出文件
        return file_put_contents($outputFile, $compressed) !== false;
    }
    
    /**
     * 解压缩文件
     * @param string $inputFile 压缩文件路径
     * @param string $outputFile 输出文件路径
     * @param string $algorithm 压缩算法
     * @return bool 是否成功
     */
    public function decompressFile($inputFile, $outputFile, $algorithm = self::ALGORITHM_GZIP) {
        // 检查输入文件是否存在
        if (!file_exists($inputFile)) {
            return false;
        }
        
        // 读取压缩数据
        $compressed = file_get_contents($inputFile);
        if ($compressed === false) {
            return false;
        }
        
        // 解压缩数据
        $data = $this->decompress($compressed, $algorithm);
        if ($data === false) {
            return false;
        }
        
        // 写入解压数据到输出文件
        return file_put_contents($outputFile, $data) !== false;
    }
    
    /**
     * 创建压缩后的静态资源
     * @param string $sourceDir 源目录
     * @param string $outputDir 输出目录
     * @param array $options 选项
     * @return array 处理结果
     */
    public function createCompressedAssets($sourceDir, $outputDir, array $options = []) {
        $results = [
            'processed' => 0,
            'compressed' => 0,
            'errors' => 0,
            'details' => []
        ];
        
        // 设置选项
        $algorithm = isset($options['algorithm']) ? $options['algorithm'] : self::ALGORITHM_GZIP;
        $level = isset($options['level']) ? $options['level'] : $this->defaultCompressionLevel;
        $recursive = isset($options['recursive']) ? $options['recursive'] : true;
        
        // 确保源目录存在
        if (!is_dir($sourceDir)) {
            $results['errors']++;
            $results['details'][] = ['path' => $sourceDir, 'error' => '源目录不存在'];
            return $results;
        }
        
        // 创建输出目录
        if (!is_dir($outputDir)) {
            if (!mkdir($outputDir, 0755, true)) {
                $results['errors']++;
                $results['details'][] = ['path' => $outputDir, 'error' => '无法创建输出目录'];
                return $results;
            }
        }
        
        // 获取文件列表
        $files = $this->getFilesFromDirectory($sourceDir, $recursive);
        
        // 处理每个文件
        foreach ($files as $file) {
            $relativePath = str_replace($sourceDir, '', $file);
            $outputFile = $outputDir . $relativePath . '.' . $this->getExtensionForAlgorithm($algorithm);
            
            // 创建输出目录结构
            $outputFileDir = dirname($outputFile);
            if (!is_dir($outputFileDir)) {
                mkdir($outputFileDir, 0755, true);
            }
            
            // 压缩文件
            if ($this->compressFile($file, $outputFile, $algorithm, $level)) {
                $results['processed']++;
                $originalSize = filesize($file);
                $compressedSize = filesize($outputFile);
                
                // 检查是否真正压缩了（有些文件压缩后可能更大）
                if ($compressedSize < $originalSize) {
                    $results['compressed']++;
                    $results['details'][] = [
                        'path' => $file,
                        'output' => $outputFile,
                        'original_size' => $originalSize,
                        'compressed_size' => $compressedSize,
                        'compression_ratio' => round(($originalSize - $compressedSize) / $originalSize * 100, 2)
                    ];
                } else {
                    // 压缩后更大，删除压缩文件
                    unlink($outputFile);
                    $results['details'][] = [
                        'path' => $file,
                        'skipped' => true,
                        'reason' => '压缩后文件更大'
                    ];
                }
            } else {
                $results['errors']++;
                $results['details'][] = [
                    'path' => $file,
                    'error' => '压缩失败'
                ];
            }
        }
        
        return $results;
    }
    
    /**
     * 递归获取目录中的所有文件
     * @param string $dir 目录
     * @param bool $recursive 是否递归
     * @return array 文件列表
     */
    private function getFilesFromDirectory($dir, $recursive = true) {
        $files = [];
        
        if (!is_dir($dir)) {
            return $files;
        }
        
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            
            $path = $dir . '/' . $item;
            
            if (is_dir($path) && $recursive) {
                $files = array_merge($files, $this->getFilesFromDirectory($path, true));
            } elseif (is_file($path)) {
                // 检查文件类型是否适合压缩
                $mimeType = $this->getMimeType($path);
                if ($this->shouldCompressMimeType($mimeType)) {
                    $files[] = $path;
                }
            }
        }
        
        return $files;
    }
    
    /**
     * 获取文件的MIME类型
     * @param string $file 文件路径
     * @return string MIME类型
     */
    private function getMimeType($file) {
        // 使用finfo
        if (function_exists('finfo_file')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file);
            finfo_close($finfo);
            return $mime;
        }
        
        // 回退到文件扩展名
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $extensions = [
            'js' => 'application/javascript',
            'css' => 'text/css',
            'html' => 'text/html',
            'htm' => 'text/html',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'txt' => 'text/plain',
            'svg' => 'image/svg+xml'
        ];
        
        return isset($extensions[$extension]) ? $extensions[$extension] : 'application/octet-stream';
    }
    
    /**
     * 检查MIME类型是否应该压缩
     * @param string $mimeType MIME类型
     * @return bool 是否应该压缩
     */
    private function shouldCompressMimeType($mimeType) {
        // 移除可能的参数
        $mimeType = strtok($mimeType, ';');
        
        // 检查是否在支持的类型列表中
        return isset($this->supportedFileTypes[$mimeType]) && !empty($this->supportedFileTypes[$mimeType]);
    }
    
    /**
     * 获取算法对应的文件扩展名
     * @param string $algorithm 压缩算法
     * @return string 文件扩展名
     */
    private function getExtensionForAlgorithm($algorithm) {
        $extensions = [
            self::ALGORITHM_GZIP => 'gz',
            self::ALGORITHM_BROTLI => 'br',
            self::ALGORITHM_DEFLATE => 'deflate',
            self::ALGORITHM_ZLIB => 'zlib'
        ];
        
        return isset($extensions[$algorithm]) ? $extensions[$algorithm] : 'gz';
    }
    
    /**
     * 启用HTTP压缩
     * @param string $contentType 内容类型
     * @return bool 是否成功启用
     */
    public function enableHttpCompression($contentType = 'text/html') {
        // 检查是否已经启用了压缩
        if (in_array('Content-Encoding', headers_list())) {
            return false;
        }
        
        // 检查浏览器支持的压缩方法
        $acceptEncoding = isset($_SERVER['HTTP_ACCEPT_ENCODING']) ? $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
        $algorithm = null;
        
        // 优先使用Brotli
        if (strpos($acceptEncoding, 'br') !== false && $this->isAlgorithmSupported(self::ALGORITHM_BROTLI)) {
            $algorithm = self::ALGORITHM_BROTLI;
            header('Content-Encoding: br');
        } 
        // 其次使用gzip
        else if (strpos($acceptEncoding, 'gzip') !== false && $this->isAlgorithmSupported(self::ALGORITHM_GZIP)) {
            $algorithm = self::ALGORITHM_GZIP;
            header('Content-Encoding: gzip');
        } 
        // 最后使用deflate
        else if (strpos($acceptEncoding, 'deflate') !== false && $this->isAlgorithmSupported(self::ALGORITHM_DEFLATE)) {
            $algorithm = self::ALGORITHM_DEFLATE;
            header('Content-Encoding: deflate');
        }
        
        if ($algorithm !== null) {
            // 设置Vary头
            header('Vary: Accept-Encoding');
            return true;
        }
        
        return false;
    }
    
    /**
     * 压缩字符串并返回数据URL
     * @param string $data 原始数据
     * @param string $mimeType MIME类型
     * @return string 数据URL
     */
    public function createCompressedDataUrl($data, $mimeType = 'text/plain') {
        $result = $this->autoCompress($data, $mimeType);
        
        if ($result['compressed']) {
            // 对于压缩的数据，需要在data URL中添加编码信息
            // 注意：浏览器不直接支持data URL中的压缩内容
            // 这里只返回base64编码的原始数据
            return 'data:' . $mimeType . ';base64,' . base64_encode($result['data']);
        } else {
            return 'data:' . $mimeType . ';base64,' . base64_encode($data);
        }
    }
    
    /**
     * 获取压缩统计信息
     * @param string $original 原始数据
     * @param string $compressed 压缩数据
     * @return array 统计信息
     */
    public function getCompressionStats($original, $compressed) {
        $originalSize = strlen($original);
        $compressedSize = strlen($compressed);
        
        return [
            'original_size' => $originalSize,
            'compressed_size' => $compressedSize,
            'compression_ratio' => $originalSize > 0 ? round(($originalSize - $compressedSize) / $originalSize * 100, 2) : 0,
            'compression_factor' => $compressedSize > 0 ? round($originalSize / $compressedSize, 2) : 0
        ];
    }
    
    /**
     * 设置压缩阈值
     * @param int $threshold 阈值（字节）
     */
    public function setCompressionThreshold($threshold) {
        $this->compressionThreshold = max(0, $threshold);
    }
    
    /**
     * 设置默认压缩级别
     * @param int $level 压缩级别（0-9）
     */
    public function setDefaultCompressionLevel($level) {
        $this->defaultCompressionLevel = max(0, min(9, $level));
    }
}

// 全局函数：获取压缩管理器实例
function compressionManager(array $options = []) {
    static $instance = null;
    
    if ($instance === null) {
        $instance = new CompressionManager($options);
    }
    
    return $instance;
}