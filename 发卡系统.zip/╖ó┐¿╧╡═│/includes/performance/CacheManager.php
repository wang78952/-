\u003c?php
/**
 * 缓存管理器类
 * 处理不同类型的缓存机制，包括文件缓存、内存缓存、Redis等
 * 
 * @package includes/performance
 */

class CacheManager {
    /**
     * 支持的缓存类型
     */
    const TYPE_FILE = 'file';
    const TYPE_MEMORY = 'memory';
    const TYPE_REDIS = 'redis';
    const TYPE_MEMCACHED = 'memcached';
    
    /**
     * 缓存默认配置
     * @var array
     */
    private $defaultConfig = [
        'type' =\u003e self::TYPE_FILE, // 默认缓存类型
        'prefix' =\u003e 'card_', // 缓存键前缀
        'default_ttl' =\u003e 3600, // 默认过期时间（秒）
        'path' =\u003e null, // 文件缓存路径
        'redis' =\u003e [
            'host' =\u003e '127.0.0.1',
            'port' =\u003e 6379,
            'password' =\u003e null,
            'database' =\u003e 0
        ],
        'memcached' =\u003e [
            'servers' =\u003e [
                ['127.0.0.1', 11211, 100]
            ]
        ],
        'compress' =\u003e false, // 是否压缩数据
        'serialize' =\u003e true, // 是否序列化数据
        'memory_limit' =\u003e 10485760 // 内存缓存限制（10MB）
    ];
    
    /**
     * 当前配置
     * @var array
     */
    private $config = [];
    
    /**
     * 缓存实例
     * @var mixed
     */
    private $cache = null;
    
    /**
     * 内存缓存数据
     * @var array
     */
    private $memoryCache = [];
    
    /**
     * 内存缓存统计
     * @var array
     */
    private $memoryStats = [
        'hits' =\u003e 0,
        'misses' =\u003e 0,
        'sets' =\u003e 0,
        'deletes' =\u003e 0,
        'bytes' =\u003e 0
    ];
    
    /**
     * 构造函数
     * @param array $config 缓存配置
     */
    public function __construct(array $config = []) {
        // 合并配置
        $this-\u003econfig = array_merge_recursive($this-\u003edefaultConfig, $config);
        
        // 初始化缓存
        $this-\u003einitializeCache();
    }
    
    /**
     * 初始化缓存系统
     * @throws Exception
     */
    private function initializeCache() {
        $type = $this-\u003econfig['type'];
        
        switch ($type) {
            case self::TYPE_FILE:
                $this-\u003einitializeFileCache();
                break;
            
            case self::TYPE_MEMORY:
                $this-\u003einitializeMemoryCache();
                break;
            
            case self::TYPE_REDIS:
                $this-\u003einitializeRedisCache();
                break;
            
            case self::TYPE_MEMCACHED:
                $this-\u003einitializeMemcachedCache();
                break;
            
            default:
                throw new Exception("不支持的缓存类型: {$type}");
        }
    }
    
    /**
     * 初始化文件缓存
     * @throws Exception
     */
    private function initializeFileCache() {
        // 设置默认缓存路径
        if ($this-\u003econfig['path'] === null) {
            $this-\u003econfig['path'] = dirname(__DIR__, 3) . '/cache';
        }
        
        // 确保缓存目录存在且可写
        if (!is_dir($this-\u003econfig['path'])) {
            if (!mkdir($this-\u003econfig['path'], 0775, true)) {
                throw new Exception("无法创建缓存目录: {$this-\u003econfig['path']}");
            }
        }
        
        if (!is_writable($this-\u003econfig['path'])) {
            throw new Exception("缓存目录不可写: {$this-\u003econfig['path']}");
        }
        
        // 创建索引文件目录
        $indexDir = $this-\u003econfig['path'] . '/index';
        if (!is_dir($indexDir)) {
            mkdir($indexDir, 0775, true);
        }
    }
    
    /**
     * 初始化内存缓存
     */
    private function initializeMemoryCache() {
        // 内存缓存不需要特殊初始化
        $this-\u003ememoryCache = [];
    }
    
    /**
     * 初始化Redis缓存
     * @throws Exception
     */
    private function initializeRedisCache() {
        if (!class_exists('Redis')) {
            throw new Exception('需要安装Redis扩展以使用Redis缓存');
        }
        
        try {
            $redis = new Redis();
            $redis-\u003econnect($this-\u003econfig['redis']['host'], $this-\u003econfig['redis']['port']);
            
            // 如果设置了密码，进行认证
            if ($this-\u003econfig['redis']['password']) {
                $redis-\u003eauth($this-\u003econfig['redis']['password']);
            }
            
            // 选择数据库
            if (isset($this-\u003econfig['redis']['database'])) {
                $redis-\u003eselect($this-\u003econfig['redis']['database']);
            }
            
            $this-\u003ecache = $redis;
        } catch (Exception $e) {
            throw new Exception("Redis连接失败: " . $e-\u003eggetMessage());
        }
    }
    
    /**
     * 初始化Memcached缓存
     * @throws Exception
     */
    private function initializeMemcachedCache() {
        if (!class_exists('Memcached')) {
            throw new Exception('需要安装Memcached扩展以使用Memcached缓存');
        }
        
        try {
            $memcached = new Memcached();
            
            // 添加服务器
            foreach ($this-\u003econfig['memcached']['servers'] as $server) {
                $memcached-\u003eaddServer($server[0], $server[1], $server[2]);
            }
            
            // 验证连接
            $stats = $memcached-\u003egetStats();
            if (empty($stats)) {
                throw new Exception("Memcached服务器连接失败");
            }
            
            $this-\u003ecache = $memcached;
        } catch (Exception $e) {
            throw new Exception("Memcached初始化失败: " . $e-\u003eggetMessage());
        }
    }
    
    /**
     * 生成缓存键
     * @param string $key 原始键
     * @return string 生成的缓存键
     */
    private function generateKey($key) {
        // 确保键有效
        $key = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $key);
        return $this-\u003econfig['prefix'] . $key;
    }
    
    /**
     * 获取缓存文件路径
     * @param string $key 缓存键
     * @return string 文件路径
     */
    private function getFilePath($key) {
        // 使用哈希分割目录，避免单个目录文件过多
        $hash = md5($key);
        $dir = $this-\u003econfig['path'] . '/' . substr($hash, 0, 2) . '/' . substr($hash, 2, 2);
        
        // 创建目录
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        
        return $dir . '/' . $hash . '.cache';
    }
    
    /**
     * 获取索引文件路径
     * @param string $tag 标签
     * @return string 索引文件路径
     */
    private function getIndexFilePath($tag) {
        $hash = md5($tag);
        return $this-\u003econfig['path'] . '/index/' . $hash . '.index';
    }
    
    /**
     * 添加标签到索引
     * @param string $key 缓存键
     * @param array $tags 标签数组
     */
    private function addToIndex($key, array $tags) {
        if (empty($tags) || $this-\u003econfig['type'] !== self::TYPE_FILE) {
            return;
        }
        
        foreach ($tags as $tag) {
            $indexFile = $this-\u003 egetIndexFilePath($tag);
            $index = [];
            
            // 读取现有索引
            if (file_exists($indexFile)) {
                $content = file_get_contents($indexFile);
                if ($content) {
                    $index = unserialize($content);
                }
            }
            
            // 添加键到索引
            if (!in_array($key, $index)) {
                $index[] = $key;
                file_put_contents($indexFile, serialize($index));
            }
        }
    }
    
    /**
     * 从索引中获取键列表
     * @param string $tag 标签
     * @return array 键列表
     */
    private function getKeysFromIndex($tag) {
        if ($this-\u003econfig['type'] !== self::TYPE_FILE) {
            return [];
        }
        
        $indexFile = $this-\u003 egetIndexFilePath($tag);
        
        if (!file_exists($indexFile)) {
            return [];
        }
        
        $content = file_get_contents($indexFile);
        if (!$content) {
            return [];
        }
        
        $index = unserialize($content);
        return is_array($index) ? $index : [];
    }
    
    /**
     * 序列化数据
     * @param mixed $data 数据
     * @return string 序列化后的数据
     */
    private function serializeData($data) {
        if (!$this-\u003econfig['serialize']) {
            return $data;
        }
        
        $serialized = serialize($data);
        
        // 如果启用了压缩且数据足够大
        if ($this-\u003econfig['compress'] \u0026\u0026 strlen($serialized) \u003e 1024) {
            $serialized = gzcompress($serialized, 6);
            $serialized = 'GZ' . $serialized; // 添加压缩标记
        }
        
        return $serialized;
    }
    
    /**
     * 反序列化数据
     * @param string $data 序列化的数据
     * @return mixed 反序列化后的数据
     */
    private function unserializeData($data) {
        if (!$this-\u003econfig['serialize']) {
            return $data;
        }
        
        // 检查是否压缩
        if (substr($data, 0, 2) === 'GZ') {
            $data = gzuncompress(substr($data, 2));
        }
        
        return unserialize($data);
    }
    
    /**
     * 设置缓存
     * @param string $key 缓存键
     * @param mixed $value 缓存值
     * @param int|false $ttl 过期时间（秒），false表示永不过期
     * @param array $tags 缓存标签
     * @return bool 是否成功
     */
    public function set($key, $value, $ttl = false, array $tags = []) {
        $cacheKey = $this-\u003egenerateKey($key);
        
        // 使用默认TTL
        if ($ttl === false) {
            $ttl = $this-\u003econfig['default_ttl'];
        }
        
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_FILE:
                    return $this-\u003esetFileCache($cacheKey, $value, $ttl, $tags);
                    
                case self::TYPE_MEMORY:
                    return $this-\u003esetMemoryCache($cacheKey, $value, $ttl);
                    
                case self::TYPE_REDIS:
                    return $this-\u003esetRedisCache($cacheKey, $value, $ttl, $tags);
                    
                case self::TYPE_MEMCACHED:
                    return $this-\u003esetMemcachedCache($cacheKey, $value, $ttl);
                    
                default:
                    return false;
            }
        } catch (Exception $e) {
            // 记录错误但不抛出异常
            error_log("缓存设置失败: " . $e-\u003eggetMessage());
            return false;
        }
    }
    
    /**
     * 设置文件缓存
     * @param string $key 缓存键
     * @param mixed $value 缓存值
     * @param int $ttl 过期时间
     * @param array $tags 标签
     * @return bool 是否成功
     */
    private function setFileCache($key, $value, $ttl, array $tags) {
        $filePath = $this-\u003 egetFilePath($key);
        
        // 准备缓存数据
        $data = [
            'value' =\u003e $value,
            'expires' =\u003e $ttl ? time() + $ttl : 0,
            'created' =\u003e time(),
            'ttl' =\u003e $ttl
        ];
        
        // 序列化数据
        $serialized = $this-\u003eserializeData($data);
        
        // 写入文件
        if (file_put_contents($filePath, $serialized) === false) {
            return false;
        }
        
        // 更新索引
        $this-\u003eaddToIndex($key, $tags);
        
        return true;
    }
    
    /**
     * 设置内存缓存
     * @param string $key 缓存键
     * @param mixed $value 缓存值
     * @param int $ttl 过期时间
     * @return bool 是否成功
     */
    private function setMemoryCache($key, $value, $ttl) {
        // 检查内存限制
        $dataSize = strlen(serialize($value));
        if ($this-\u003 ememoryStats['bytes'] + $dataSize \u003e $this-\u003econfig['memory_limit']) {
            // 清理部分内存缓存
            $this-\u003e pruneMemoryCache();
        }
        
        // 设置缓存
        $this-\u003 ememoryCache[$key] = [
            'value' =\u003e $value,
            'expires' =\u003e $ttl ? time() + $ttl : 0,
            'size' =\u003e $dataSize
        ];
        
        // 更新统计
        $this-\u003 ememoryStats['sets']++;
        $this-\u003 ememoryStats['bytes'] += $dataSize;
        
        return true;
    }
    
    /**
     * 清理部分内存缓存
     */
    private function pruneMemoryCache() {
        // 按过期时间排序
        uasort($this-\u003 ememoryCache, function($a, $b) {
            return $a['expires'] - $b['expires'];
        });
        
        // 删除约30%的最旧缓存
        $toRemove = ceil(count($this-\u003 ememoryCache) * 0.3);
        $removed = 0;
        
        foreach ($this-\u003 ememoryCache as $key =\u003e $item) {
            if ($removed \u003e= $toRemove) {
                break;
            }
            
            $this-\u003 ememoryStats['bytes'] -= $item['size'];
            unset($this-\u003 ememoryCache[$key]);
            $removed++;
        }
    }
    
    /**
     * 设置Redis缓存
     * @param string $key 缓存键
     * @param mixed $value 缓存值
     * @param int $ttl 过期时间
     * @param array $tags 标签
     * @return bool 是否成功
     */
    private function setRedisCache($key, $value, $ttl, array $tags) {
        // 序列化数据
        $data = $this-\u003eserializeData($value);
        
        // 设置缓存
        if ($ttl) {
            $result = $this-\u003ecache-\u003esetex($key, $ttl, $data);
        } else {
            $result = $this-\u003ecache-\u003eset($key, $data);
        }
        
        // 设置标签
        if ($result \u0026\u0026 !empty($tags)) {
            foreach ($tags as $tag) {
                $this-\u003ecache-\u003 esadd('tag:' . $tag, $key);
                // 设置标签过期时间（比缓存稍长）
                if ($ttl) {
                    $this-\u003ecache-\u003 eexpire('tag:' . $tag, $ttl + 3600);
                }
            }
        }
        
        return $result;
    }
    
    /**
     * 设置Memcached缓存
     * @param string $key 缓存键
     * @param mixed $value 缓存值
     * @param int $ttl 过期时间
     * @return bool 是否成功
     */
    private function setMemcachedCache($key, $value, $ttl) {
        // Memcached内置序列化，不需要额外处理
        if ($ttl) {
            return $this-\u003ecache-\u003eset($key, $value, 0, $ttl);
        } else {
            return $this-\u003ecache-\u003eset($key, $value);
        }
    }
    
    /**
     * 获取缓存
     * @param string $key 缓存键
     * @param mixed $default 默认值
     * @return mixed 缓存值或默认值
     */
    public function get($key, $default = null) {
        $cacheKey = $this-\u003egenerateKey($key);
        
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_FILE:
                    return $this-\u003 egetFileCache($cacheKey, $default);
                    
                case self::TYPE_MEMORY:
                    return $this-\u003 egetMemoryCache($cacheKey, $default);
                    
                case self::TYPE_REDIS:
                    return $this-\u003 egetRedisCache($cacheKey, $default);
                    
                case self::TYPE_MEMCACHED:
                    return $this-\u003 egetMemcachedCache($cacheKey, $default);
                    
                default:
                    return $default;
            }
        } catch (Exception $e) {
            error_log("缓存获取失败: " . $e-\u003eggetMessage());
            return $default;
        }
    }
    
    /**
     * 获取文件缓存
     * @param string $key 缓存键
     * @param mixed $default 默认值
     * @return mixed 缓存值
     */
    private function getFileCache($key, $default) {
        $filePath = $this-\u003 egetFilePath($key);
        
        // 检查文件是否存在
        if (!file_exists($filePath)) {
            return $default;
        }
        
        // 读取文件
        $content = file_get_contents($filePath);
        if ($content === false) {
            return $default;
        }
        
        // 反序列化
        try {
            $data = $this-\u003eunserializeData($content);
            
            // 检查是否过期
            if ($data['expires'] \u0026\u0026 $data['expires'] \u003c time()) {
                // 删除过期缓存
                unlink($filePath);
                return $default;
            }
            
            return $data['value'];
        } catch (Exception $e) {
            // 数据损坏，删除文件
            @unlink($filePath);
            return $default;
        }
    }
    
    /**
     * 获取内存缓存
     * @param string $key 缓存键
     * @param mixed $default 默认值
     * @return mixed 缓存值
     */
    private function getMemoryCache($key, $default) {
        // 检查是否存在
        if (!isset($this-\u003 ememoryCache[$key])) {
            $this-\u003 ememoryStats['misses']++;
            return $default;
        }
        
        $item = $this-\u003 ememoryCache[$key];
        
        // 检查是否过期
        if ($item['expires'] \u0026\u0026 $item['expires'] \u003c time()) {
            // 删除过期项
            $this-\u003 ememoryStats['bytes'] -= $item['size'];
            unset($this-\u003 ememoryCache[$key]);
            $this-\u003 ememoryStats['misses']++;
            return $default;
        }
        
        // 更新统计
        $this-\u003 ememoryStats['hits']++;
        return $item['value'];
    }
    
    /**
     * 获取Redis缓存
     * @param string $key 缓存键
     * @param mixed $default 默认值
     * @return mixed 缓存值
     */
    private function getRedisCache($key, $default) {
        $data = $this-\u003ecache-\u003 eget($key);
        
        if ($data === false) {
            return $default;
        }
        
        return $this-\u003eunserializeData($data);
    }
    
    /**
     * 获取Memcached缓存
     * @param string $key 缓存键
     * @param mixed $default 默认值
     * @return mixed 缓存值
     */
    private function getMemcachedCache($key, $default) {
        $data = $this-\u003ecache-\u003 eget($key);
        
        if ($data === false) {
            return $default;
        }
        
        return $data;
    }
    
    /**
     * 检查缓存是否存在
     * @param string $key 缓存键
     * @return bool 是否存在
     */
    public function has($key) {
        $cacheKey = $this-\u003egenerateKey($key);
        
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_FILE:
                    $filePath = $this-\u003 egetFilePath($cacheKey);
                    return file_exists($filePath);
                    
                case self::TYPE_MEMORY:
                    return isset($this-\u003 ememoryCache[$cacheKey]) \u0026\u0026 
                           (!$this-\u003 ememoryCache[$cacheKey]['expires'] || $this-\u003 ememoryCache[$cacheKey]['expires'] \u003e time());
                    
                case self::TYPE_REDIS:
                    return $this-\u003ecache-\u003eexists($cacheKey);
                    
                case self::TYPE_MEMCACHED:
                    return $this-\u003ecache-\u003 eget($cacheKey) !== false;
                    
                default:
                    return false;
            }
        } catch (Exception $e) {
            error_log("缓存检查失败: " . $e-\u003eggetMessage());
            return false;
        }
    }
    
    /**
     * 删除缓存
     * @param string $key 缓存键
     * @return bool 是否成功
     */
    public function delete($key) {
        $cacheKey = $this-\u003egenerateKey($key);
        
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_FILE:
                    $filePath = $this-\u003 egetFilePath($cacheKey);
                    if (file_exists($filePath)) {
                        return unlink($filePath);
                    }
                    return true;
                    
                case self::TYPE_MEMORY:
                    if (isset($this-\u003 ememoryCache[$cacheKey])) {
                        $this-\u003 ememoryStats['bytes'] -= $this-\u003 ememoryCache[$cacheKey]['size'];
                        unset($this-\u003 ememoryCache[$cacheKey]);
                        $this-\u003 ememoryStats['deletes']++;
                    }
                    return true;
                    
                case self::TYPE_REDIS:
                    return (bool) $this-\u003ecache-\u003edel($cacheKey);
                    
                case self::TYPE_MEMCACHED:
                    return $this-\u003ecache-\u003edelete($cacheKey);
                    
                default:
                    return false;
            }
        } catch (Exception $e) {
            error_log("缓存删除失败: " . $e-\u003eggetMessage());
            return false;
        }
    }
    
    /**
     * 清除所有缓存
     * @return bool 是否成功
     */
    public function clear() {
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_FILE:
                    return $this-\u003eclearFileCache();
                    
                case self::TYPE_MEMORY:
                    $this-\u003 ememoryCache = [];
                    $this-\u003 ememoryStats = [
                        'hits' =\u003e 0,
                        'misses' =\u003e 0,
                        'sets' =\u003e 0,
                        'deletes' =\u003e 0,
                        'bytes' =\u003e 0
                    ];
                    return true;
                    
                case self::TYPE_REDIS:
                    // 使用前缀删除，避免删除其他应用的缓存
                    $keys = $this-\u003ecache-\u003ekeys($this-\u003econfig['prefix'] . '*');
                    if (!empty($keys)) {
                        return (bool) $this-\u003ecache-\u003edel($keys);
                    }
                    return true;
                    
                case self::TYPE_MEMCACHED:
                    return $this-\u003ecache-\u003eflush();
                    
                default:
                    return false;
            }
        } catch (Exception $e) {
            error_log("缓存清除失败: " . $e-\u003eggetMessage());
            return false;
        }
    }
    
    /**
     * 清除文件缓存
     * @return bool 是否成功
     */
    private function clearFileCache() {
        $cachePath = $this-\u003econfig['path'];
        
        // 删除所有缓存文件
        $this-\u003eremoveDirectory($cachePath . '/index');
        
        // 重新创建索引目录
        mkdir($cachePath . '/index', 0775, true);
        
        // 删除缓存文件目录
        $dirs = glob($cachePath . '/*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            if (basename($dir) !== 'index') {
                $this-\u003eremoveDirectory($dir);
            }
        }
        
        return true;
    }
    
    /**
     * 递归删除目录
     * @param string $dir 目录路径
     * @return bool 是否成功
     */
    private function removeDirectory($dir) {
        if (!is_dir($dir)) {
            return false;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            
            if (is_dir($path)) {
                $this-\u003eremoveDirectory($path);
            } else {
                unlink($path);
            }
        }
        
        return rmdir($dir);
    }
    
    /**
     * 按标签清除缓存
     * @param string|array $tags 标签或标签数组
     * @return bool 是否成功
     */
    public function clearByTag($tags) {
        if (is_string($tags)) {
            $tags = [$tags];
        }
        
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_FILE:
                    return $this-\u003eclearFileCacheByTag($tags);
                    
                case self::TYPE_REDIS:
                    return $this-\u003eclearRedisCacheByTag($tags);
                    
                default:
                    // 其他类型不支持标签
                    return false;
            }
        } catch (Exception $e) {
            error_log("按标签清除缓存失败: " . $e-\u003eggetMessage());
            return false;
        }
    }
    
    /**
     * 按标签清除文件缓存
     * @param array $tags 标签数组
     * @return bool 是否成功
     */
    private function clearFileCacheByTag(array $tags) {
        foreach ($tags as $tag) {
            $indexFile = $this-\u003 egetIndexFilePath($tag);
            
            if (file_exists($indexFile)) {
                $content = file_get_contents($indexFile);
                if ($content) {
                    $keys = unserialize($content);
                    
                    // 删除每个键对应的缓存
                    if (is_array($keys)) {
                        foreach ($keys as $key) {
                            $filePath = $this-\u003 egetFilePath($key);
                            if (file_exists($filePath)) {
                                unlink($filePath);
                            }
                        }
                    }
                }
                
                // 删除索引文件
                unlink($indexFile);
            }
        }
        
        return true;
    }
    
    /**
     * 按标签清除Redis缓存
     * @param array $tags 标签数组
     * @return bool 是否成功
     */
    private function clearRedisCacheByTag(array $tags) {
        foreach ($tags as $tag) {
            $tagKey = 'tag:' . $tag;
            $keys = $this-\u003ecache-\u003esmembers($tagKey);
            
            if (!empty($keys)) {
                // 删除缓存
                $this-\u003ecache-\u003edel($keys);
                // 删除标签
                $this-\u003ecache-\u003edel($tagKey);
            }
        }
        
        return true;
    }
    
    /**
     * 获取缓存统计信息
     * @return array 统计信息
     */
    public function getStats() {
        try {
            switch ($this-\u003econfig['type']) {
                case self::TYPE_MEMORY:
                    return $this-\u003 ememoryStats;
                    
                case self::TYPE_REDIS:
                    return $this-\u003ecache-\u003einfo();
                    
                case self::TYPE_MEMCACHED:
                    return $this-\u003ecache-\u003egetStats();
                    
                default:
                    return [
                        'type' =\u003e $this-\u003econfig['type'],
                        'message' =\u003e '统计信息不可用'
                    ];
            }
        } catch (Exception $e) {
            error_log("获取缓存统计失败: " . $e-\u003eggetMessage());
            return ['error' =\u003e $e-\u003eggetMessage()];
        }
    }
    
    /**
     * 刷新过期缓存
     * @return int 清理的缓存数量
     */
    public function flushExpired() {
        if ($this-\u003econfig['type'] !== self::TYPE_FILE) {
            return 0;
        }
        
        $count = 0;
        $this-\u003eflushExpiredInDir($this-\u003econfig['path'], $count);
        return $count;
    }
    
    /**
     * 递归清理目录中的过期缓存
     * @param string $dir 目录路径
     * @param int \$count 计数器
     */
    private function flushExpiredInDir($dir, $count) {
        $files = array_diff(scandir($dir), ['.', '..']);
        
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            
            if (is_dir($path)) {
                $this-\u003eflushExpiredInDir($path, $count);
            } elseif (pathinfo($file, PATHINFO_EXTENSION) === 'cache') {
                // 检查是否过期
                $content = file_get_contents($path);
                if ($content) {
                    try {
                        $data = $this-\u003eunserializeData($content);
                        if ($data['expires'] \u0026\u0026 $data['expires'] \u003c time()) {
                            unlink($path);
                            $count++;
                        }
                    } catch (Exception $e) {
                        // 数据损坏，删除文件
                        @unlink($path);
                        $count++;
                    }
                }
            }
        }
    }
    
    /**
     * 获取缓存使用情况
     * @return array 使用情况
     */
    public function getUsage() {
        if ($this-\u003econfig['type'] !== self::TYPE_FILE) {
            return ['error' =\u003e '仅文件缓存支持此功能'];
        }
        
        $size = 0;
        $this-\u003ecalculateDirectorySize($this-\u003econfig['path'], $size);
        
        return [
            'type' =\u003e $this-\u003econfig['type'],
            'path' =\u003e $this-\u003econfig['path'],
            'size_bytes' =\u003e $size,
            'size_human' =\u003e $this-\u003eformatBytes($size)
        ];
    }
    
    /**
     * 计算目录大小
     * @param string $dir 目录路径
     * @param int \$size 大小计数器
     */
    private function calculateDirectorySize($dir, $size) {
        $files = array_diff(scandir($dir), ['.', '..']);
        
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            
            if (is_dir($path)) {
                $this-\u003ecalculateDirectorySize($path, $size);
            } else {
                $size += filesize($path);
            }
        }
    }
    
    /**
     * 格式化字节大小
     * @param int $bytes 字节数
     * @return string 格式化的大小
     */
    private function formatBytes($bytes) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        return round($bytes / pow(1024, $pow), 2) . ' ' . $units[$pow];
    }
}

// 全局函数：获取缓存管理器实例
function cacheManager(array $config = []) {
    static $instance = null;
    
    if ($instance === null) {
        $instance = new CacheManager($config);
    }
    
    return $instance;
}