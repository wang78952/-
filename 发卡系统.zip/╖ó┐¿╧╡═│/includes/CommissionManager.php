<?php

/**
 * 佣金管理器
 * 处理佣金计算、提现等功能
 */
class CommissionManager extends BaseService {
    
    public function __construct() {
        parent::__construct();
        // logger已在父类中初始化
    }
    
    /**
     * 计算订单佣金
     */
    public function calculateOrderCommission($orderId) {
        try {
            // 获取订单信息
            $order = $this->database->queryOne(
                "SELECT * FROM orders WHERE id = ? AND commission_calculated = 0",
                array($orderId)
            );
            
            if (!$order) {
                return $this->errorResponse('订单不存在或佣金已计算');
            }
            
            if (!$order['agent_id']) {
                return $this->errorResponse('订单没有关联代理');
            }
            
            // 获取代理信息
            $agent = $this->database->queryOne(
                "SELECT * FROM agents WHERE id = ? AND status = 'active'",
                array($order['agent_id'])
            );
            
            if (!$agent) {
                return $this->errorResponse('代理不存在或未激活');
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 计算直接佣金
            if ($agent['commission_rate'] > 0) {
                $directCommission = $order['total_amount'] * $agent['commission_rate'] / 100;
                
                $commissionId = $this->database->insert('commissions', array(
                    'agent_id' => $agent['id'],
                    'order_id' => $order['id'],
                    'type' => 'direct',
                    'amount' => $directCommission,
                    'rate' => $agent['commission_rate'],
                    'sales_amount' => $order['total_amount'],
                    'description' => '直接销售佣金',
                    'status' => 'pending',
                    'available_at' => date('Y-m-d H:i:s', strtotime('+7 days'))
                ));
                
                // 更新代理总佣金和可提现佣金
                $this->database->update('agents', array(
                    'total_commission' => $agent['total_commission'] + $directCommission,
                    'total_sales' => $agent['total_sales'] + $order['total_amount']
                ), 'id = ?', array($agent['id']));
            }
            
            // 计算间接佣金（二级代理）
            if ($agent['parent_agent_id'] && $agent['sub_commission_rate'] > 0) {
                $parentAgent = $this->database->queryOne(
                    "SELECT * FROM agents WHERE id = ? AND status = 'active'",
                    array($agent['parent_agent_id'])
                );
                
                if ($parentAgent) {
                    $indirectCommission = $order['total_amount'] * $agent['sub_commission_rate'] / 100;
                    
                    $this->database->insert('commissions', array(
                        'agent_id' => $parentAgent['id'],
                        'order_id' => $order['id'],
                        'source_agent_id' => $agent['id'],
                        'type' => 'indirect',
                        'amount' => $indirectCommission,
                        'rate' => $agent['sub_commission_rate'],
                        'sales_amount' => $order['total_amount'],
                        'description' => '下级代理销售佣金',
                        'status' => 'pending',
                        'available_at' => date('Y-m-d H:i:s', strtotime('+7 days'))
                    ));
                    
                    // 更新上级代理总佣金
                    $this->database->update('agents', array(
                        'total_commission' => $parentAgent['total_commission'] + $indirectCommission,
                        'team_sales' => $parentAgent['team_sales'] + $order['total_amount']
                    ), 'id = ?', array($parentAgent['id']));
                }
            }
            
            // 更新订单佣金计算状态
            $this->database->update('orders', array(
                'commission_calculated' => 1
            ), 'id = ?', array($orderId));
            
            $this->database->commit();
            
            // 记录操作日志
            $this->logger->info("订单佣金计算完成", array(
                'order_id' => $orderId,
                'agent_id' => $order['agent_id'],
                'amount' => $order['total_amount']
            ));
            
            return $this->successResponse(array(
                'order_id' => $orderId,
                'message' => '佣金计算完成'
            ));
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error("佣金计算失败: " . $e->getMessage());
            return $this->errorResponse('佣金计算失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取代理佣金列表
     */
    public function getAgentCommissions($agentId, $filters = array(), $page = 1, $limit = 20) {
        try {
            $where = array('agent_id = ?');
            $params = array($agentId);
            
            // 类型筛选
            if (!empty($filters['type'])) {
                $where[] = 'type = ?';
                $params[] = $filters['type'];
            }
            
            // 状态筛选
            if (!empty($filters['status'])) {
                $where[] = 'status = ?';
                $params[] = $filters['status'];
            }
            
            // 时间范围筛选
            if (!empty($filters['start_date'])) {
                $where[] = 'created_at >= ?';
                $params[] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $where[] = 'created_at <= ?';
                $params[] = $filters['end_date'] . ' 23:59:59';
            }
            
            $whereClause = implode(' AND ', $where);
            
            // 计算总数
            $total = $this->database->queryOne(
                "SELECT COUNT(*) as total FROM commissions WHERE {$whereClause}",
                $params
            )['total'];
            
            // 获取分页数据
            $offset = ($page - 1) * $limit;
            $sql = "
                SELECT 
                    c.*,
                    o.order_no,
                    source.agent_code as source_agent_code
                FROM commissions c
                LEFT JOIN orders o ON c.order_id = o.id
                LEFT JOIN agents source ON c.source_agent_id = source.id
                WHERE {$whereClause}
                ORDER BY c.created_at DESC
                LIMIT ? OFFSET ?
            ";
            
            $params[] = $limit;
            $params[] = $offset;
            
            $commissions = $this->database->query($sql, $params);
            
            return $this->successResponse(array(
                'commissions' => $commissions,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                )
            ));
            
        } catch (Exception $e) {
            $this->logger->error("获取佣金列表失败: " . $e->getMessage());
            return $this->errorResponse('获取佣金列表失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取代理佣金统计
     */
    public function getAgentCommissionStats($agentId) {
        try {
            // 获取总佣金统计
            $stats = $this->database->queryOne("
                SELECT 
                    COUNT(*) as total_orders,
                    COALESCE(SUM(amount), 0) as total_commission,
                    COALESCE(SUM(CASE WHEN status = 'available' THEN amount ELSE 0 END), 0) as available_commission,
                    COALESCE(SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END), 0) as pending_commission,
                    COALESCE(SUM(CASE WHEN status = 'withdrawn' THEN amount ELSE 0 END), 0) as withdrawn_commission
                FROM commissions 
                WHERE agent_id = ?
            ", array($agentId));
            
            // 获取本月佣金
            $monthlyStats = $this->database->queryOne("
                SELECT 
                    COUNT(*) as monthly_orders,
                    COALESCE(SUM(amount), 0) as monthly_commission
                FROM commissions 
                WHERE agent_id = ? 
                AND created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
            ", array($agentId));
            
            $stats['monthly_orders'] = $monthlyStats['monthly_orders'];
            $stats['monthly_commission'] = $monthlyStats['monthly_commission'];
            
            return $this->successResponse($stats);
            
        } catch (Exception $e) {
            $this->logger->error("获取佣金统计失败: " . $e->getMessage());
            return $this->errorResponse('获取佣金统计失败：' . $e->getMessage());
        }
    }
    
    /**
     * 申请提现
     */
    public function applyWithdrawal($agentId, $amount, $method, $accountInfo) {
        try {
            // 获取代理信息
            $agent = $this->database->queryOne(
                "SELECT * FROM agents WHERE id = ? AND status = 'active'",
                array($agentId)
            );
            
            if (!$agent) {
                return $this->errorResponse('代理不存在或未激活');
            }
            
            // 检查可提现佣金
            if ($amount > $agent['available_commission']) {
                return $this->errorResponse('提现金额超过可用佣金');
            }
            
            // 获取最低提现金额
            $minWithdrawal = floatval($this->getSystemConfig('agent_min_withdrawal', 100));
            if ($amount < $minWithdrawal) {
                return $this->errorResponse("最低提现金额为 {$minWithdrawal} 元");
            }
            
            // 计算手续费
            $feeRate = floatval($this->getSystemConfig('agent_withdrawal_fee', 0.01));
            $fee = $amount * $feeRate;
            $actualAmount = $amount - $fee;
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 创建提现记录
            $withdrawalId = $this->database->insert('withdrawals', array(
                'agent_id' => $agentId,
                'amount' => $amount,
                'fee' => $fee,
                'actual_amount' => $actualAmount,
                'method' => $method,
                'account_info' => json_encode($accountInfo),
                'status' => 'pending'
            ));
            
            // 冻结相应佣金
            $this->database->update('commissions', array(
                'status' => 'pending',
                'withdrawal_id' => $withdrawalId
            ), 'agent_id = ? AND status = ? AND withdrawal_id IS NULL', array(
                $agentId, 'available'
            ));
            
            // 更新代理可提现佣金
            $this->database->update('agents', array(
                'available_commission' => $agent['available_commission'] - $amount
            ), 'id = ?', array($agentId));
            
            $this->database->commit();
            
            // 记录操作日志
            $this->logger->info("代理申请提现", array(
                'agent_id' => $agentId,
                'withdrawal_id' => $withdrawalId,
                'amount' => $amount,
                'actual_amount' => $actualAmount
            ));
            
            return $this->successResponse(array(
                'withdrawal_id' => $withdrawalId,
                'amount' => $amount,
                'fee' => $fee,
                'actual_amount' => $actualAmount,
                'message' => '提现申请提交成功'
            ));
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error("提现申请失败: " . $e->getMessage());
            return $this->errorResponse('提现申请失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取提现记录
     */
    public function getWithdrawals($agentId = null, $filters = array(), $page = 1, $limit = 20) {
        try {
            $where = array('1=1');
            $params = array();
            
            if ($agentId) {
                $where[] = 'w.agent_id = ?';
                $params[] = $agentId;
            }
            
            // 状态筛选
            if (!empty($filters['status'])) {
                $where[] = 'w.status = ?';
                $params[] = $filters['status'];
            }
            
            // 时间范围筛选
            if (!empty($filters['start_date'])) {
                $where[] = 'w.created_at >= ?';
                $params[] = $filters['start_date'] . ' 00:00:00';
            }
            
            if (!empty($filters['end_date'])) {
                $where[] = 'w.created_at <= ?';
                $params[] = $filters['end_date'] . ' 23:59:59';
            }
            
            $whereClause = implode(' AND ', $where);
            
            // 计算总数
            $total = $this->database->queryOne(
                "SELECT COUNT(*) as total FROM withdrawals w WHERE {$whereClause}",
                $params
            )['total'];
            
            // 获取分页数据
            $offset = ($page - 1) * $limit;
            $sql = "
                SELECT 
                    w.*,
                    a.agent_code,
                    a.contact_name,
                    u.username
                FROM withdrawals w
                LEFT JOIN agents a ON w.agent_id = a.id
                LEFT JOIN users u ON a.user_id = u.id
                WHERE {$whereClause}
                ORDER BY w.created_at DESC
                LIMIT ? OFFSET ?
            ";
            
            $params[] = $limit;
            $params[] = $offset;
            
            $withdrawals = $this->database->query($sql, $params);
            
            return $this->successResponse(array(
                'withdrawals' => $withdrawals,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                )
            ));
            
        } catch (Exception $e) {
            $this->logger->error("获取提现记录失败: " . $e->getMessage());
            return $this->errorResponse('获取提现记录失败：' . $e->getMessage());
        }
    }
    
    /**
     * 处理提现申请
     */
    public function processWithdrawal($withdrawalId, $status, $adminNotes = '', $processedBy = null) {
        try {
            $withdrawal = $this->database->queryOne(
                "SELECT * FROM withdrawals WHERE id = ? AND status = 'pending'",
                array($withdrawalId)
            );
            
            if (!$withdrawal) {
                return $this->errorResponse('提现申请不存在或已处理');
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 更新提现记录
            $this->database->update('withdrawals', array(
                'status' => $status,
                'admin_notes' => $adminNotes,
                'processed_by' => $processedBy,
                'processed_at' => date('Y-m-d H:i:s')
            ), 'id = ?', array($withdrawalId));
            
            if ($status === 'completed') {
                // 提现成功，更新佣金状态为已提现
                $this->database->update('commissions', array(
                    'status' => 'withdrawn',
                    'withdrawn_at' => date('Y-m-d H:i:s')
                ), 'withdrawal_id = ?', array($withdrawalId));
                
            } elseif ($status === 'rejected') {
                // 提现拒绝，恢复佣金状态
                $this->database->update('commissions', array(
                    'status' => 'available',
                    'withdrawal_id' => null
                ), 'withdrawal_id = ?', array($withdrawalId));
                
                // 恢复代理可提现佣金
                $agent = $this->database->queryOne(
                    "SELECT available_commission FROM agents WHERE id = ?",
                    array($withdrawal['agent_id'])
                );
                
                $this->database->update('agents', array(
                    'available_commission' => $agent['available_commission'] + $withdrawal['amount']
                ), 'id = ?', array($withdrawal['agent_id']));
            }
            
            $this->database->commit();
            
            // 记录操作日志
            $this->logger->info("提现申请处理", array(
                'withdrawal_id' => $withdrawalId,
                'status' => $status,
                'processed_by' => $processedBy
            ));
            
            return $this->successResponse(array(
                'withdrawal_id' => $withdrawalId,
                'status' => $status,
                'message' => $status === 'completed' ? '提现处理成功' : '提现申请已拒绝'
            ));
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error("提现处理失败: " . $e->getMessage());
            return $this->errorResponse('提现处理失败：' . $e->getMessage());
        }
    }
    
    /**
     * 更新可用佣金状态
     */
    public function updateAvailableCommissions() {
        try {
            // 将过期的待处理佣金更新为可用
            $this->database->update('commissions', array(
                'status' => 'available'
            ), 'status = ? AND available_at <= NOW()', array('pending'));
            
            // 更新代理的可提现佣金
            $this->database->query("
                UPDATE agents a 
                SET available_commission = (
                    SELECT COALESCE(SUM(amount), 0) 
                    FROM commissions 
                    WHERE agent_id = a.id AND status = 'available'
                )
            ");
            
            $this->logger->info("可用佣金状态更新完成");
            
            return $this->successResponse('可用佣金状态更新完成');
            
        } catch (Exception $e) {
            $this->logger->error("更新可用佣金失败: " . $e->getMessage());
            return $this->errorResponse('更新可用佣金失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取系统配置
     */
    private function getSystemConfig($key, $default = null) {
        $config = $this->database->queryOne(
            "SELECT config_value FROM system_configs WHERE config_key = ?",
            array($key)
        );
        
        return $config ? $config['config_value'] : $default;
    }
}