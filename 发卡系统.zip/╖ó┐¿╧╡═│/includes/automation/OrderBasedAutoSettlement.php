<?php
/**
 * 基于订单完成时间的佣金自动结算系统
 * 实现订单完成后指定时间（默认24小时）自动结算佣金的功能
 * 
 * @package Automation
 * @author System Admin
 */

namespace Automation;

use Affiliate\CommissionSettlementSystem;
use Database\DBConnection;
use Logger\Logger;

class OrderBasedAutoSettlement {
    /**
     * 配置项
     * @var array
     */
    private $config = [
        'auto_settlement_enabled' => true,      // 是否启用自动结算
        'settlement_delay_hours' => 24,         // 订单完成后结算延迟时间（小时）
        'batch_size' => 100,                    // 每批处理订单数量
        'min_settlement_amount' => 0,           // 最小结算金额
        'notification_enabled' => true,         // 是否发送通知
        'run_interval_minutes' => 30,           // 任务运行间隔（分钟）
    ];
    
    /**
     * 数据库连接
     * @var DBConnection
     */
    private $db;
    
    /**
     * 日志实例
     * @var Logger
     */
    private $logger;
    
    /**
     * 佣金结算系统实例
     * @var CommissionSettlementSystem
     */
    private $commissionSystem;
    
    /**
     * 构造函数
     * 
     * @param array $config 配置项
     */
    public function __construct(array $config = []) {
        $this->config = array_merge($this->config, $config);
        
        // 初始化数据库连接
        $this->db = DBConnection::getInstance();
        
        // 初始化日志
        $this->logger = Logger::getInstance('auto_commission_settlement');
        
        // 初始化佣金结算系统
        $this->commissionSystem = new CommissionSettlementSystem();
    }
    
    /**
     * 执行自动结算任务
     * 
     * @return array 执行结果
     */
    public function processAutoSettlement() {
        if (!$this->config['auto_settlement_enabled']) {
            $this->logger->info('自动结算功能已禁用');
            return [
                'success' => true,
                'message' => '自动结算功能已禁用',
                'processed_count' => 0
            ];
        }
        
        try {
            $this->logger->info('开始执行基于订单的自动佣金结算任务');
            
            // 获取符合条件的订单佣金
            $pendingCommissions = $this->getPendingCommissionsForAutoSettlement();
            $totalCount = count($pendingCommissions);
            
            $this->logger->info("找到 {$totalCount} 条待自动结算的佣金记录");
            
            $processedCount = 0;
            $settlementResults = [];
            
            // 分批处理佣金记录
            foreach (array_chunk($pendingCommissions, $this->config['batch_size']) as $batch) {
                $batchResult = $this->processCommissionBatch($batch);
                $processedCount += $batchResult['count'];
                $settlementResults = array_merge($settlementResults, $batchResult['results']);
            }
            
            // 生成结算摘要报告
            $this->generateSettlementSummary($processedCount, $settlementResults);
            
            $this->logger->info("自动佣金结算任务完成，成功处理 {$processedCount}/{$totalCount} 条佣金记录");
            
            return [
                'success' => true,
                'message' => "自动结算完成，共处理 {$processedCount} 条佣金记录",
                'processed_count' => $processedCount,
                'total_count' => $totalCount,
                'results' => $settlementResults
            ];
        } catch (\Exception $e) {
            $this->logger->error("自动佣金结算任务失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取符合自动结算条件的佣金记录
     * 
     * @return array 佣金记录数组
     */
    private function getPendingCommissionsForAutoSettlement() {
        try {
            // 计算结算时间阈值（当前时间减去延迟时间）
            $settlementThreshold = date('Y-m-d H:i:s', time() - ($this->config['settlement_delay_hours'] * 3600));
            
            // 查询符合条件的佣金记录
            $query = "SELECT cr.*, o.completed_at, o.order_no, a.name AS affiliate_name, a.email AS affiliate_email 
                     FROM commission_records cr
                     JOIN orders o ON cr.order_id = o.id
                     JOIN affiliates a ON cr.affiliate_id = a.id
                     WHERE cr.status = 'pending' 
                     AND o.status = 'completed' 
                     AND o.completed_at <= :threshold
                     AND cr.amount >= :min_amount
                     ORDER BY o.completed_at ASC
                     LIMIT :batch_size";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':threshold', $settlementThreshold);
            $stmt->bindParam(':min_amount', $this->config['min_settlement_amount'], \PDO::PARAM_STR);
            $stmt->bindParam(':batch_size', $this->config['batch_size'], \PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            $this->logger->error("获取待结算佣金记录失败: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 处理佣金批次
     * 
     * @param array $commissions 佣金记录数组
     * @return array 处理结果
     */
    private function processCommissionBatch(array $commissions) {
        $processedCount = 0;
        $results = [];
        
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            foreach ($commissions as $commission) {
                // 处理单个佣金结算
                $settlementResult = $this->processSingleSettlement($commission);
                
                if ($settlementResult['success']) {
                    $processedCount++;
                    $results[] = [
                        'commission_id' => $commission['id'],
                        'order_id' => $commission['order_id'],
                        'order_no' => $commission['order_no'],
                        'affiliate_id' => $commission['affiliate_id'],
                        'affiliate_name' => $commission['affiliate_name'],
                        'amount' => $commission['amount'],
                        'settlement_time' => date('Y-m-d H:i:s')
                    ];
                } else {
                    $this->logger->warning("佣金结算失败，佣金ID: {$commission['id']}, 错误: {$settlementResult['error']}");
                }
            }
            
            // 提交事务
            $this->db->commit();
            
            return [
                'count' => $processedCount,
                'results' => $results
            ];
        } catch (\Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            $this->logger->error("佣金批次处理失败: " . $e->getMessage());
            
            return [
                'count' => 0,
                'results' => []
            ];
        }
    }
    
    /**
     * 处理单个佣金结算
     * 
     * @param array $commission 佣金记录
     * @return array 处理结果
     */
    private function processSingleSettlement(array $commission) {
        try {
            // 更新佣金状态为已结算
            $updateQuery = "UPDATE commission_records SET status = 'approved', 
                         settlement_time = NOW(), settlement_type = 'auto' 
                         WHERE id = :id AND status = 'pending'";
            
            $stmt = $this->db->prepare($updateQuery);
            $stmt->bindParam(':id', $commission['id']);
            $stmt->execute();
            
            if ($stmt->rowCount() === 0) {
                return [
                    'success' => false,
                    'error' => '佣金记录已被处理或不存在'
                ];
            }
            
            // 更新代理余额
            $this->updateAffiliateBalance($commission['affiliate_id'], $commission['amount']);
            
            // 记录财务流水
            $this->recordFinancialTransaction($commission);
            
            // 发送通知
            if ($this->config['notification_enabled']) {
                $this->sendSettlementNotification($commission);
            }
            
            return ['success' => true];
        } catch (\Exception $e) {
            $this->logger->error("处理单个佣金结算失败，佣金ID: {$commission['id']}, 错误: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 更新代理余额
     * 
     * @param int $affiliateId 代理ID
     * @param float $amount 金额
     */
    private function updateAffiliateBalance($affiliateId, $amount) {
        $query = "UPDATE affiliates 
                 SET available_balance = available_balance + :amount, 
                     total_commission_earned = total_commission_earned + :amount, 
                     updated_at = NOW() 
                 WHERE id = :id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':id', $affiliateId);
        $stmt->execute();
    }
    
    /**
     * 记录财务交易
     * 
     * @param array $commission 佣金记录
     */
    private function recordFinancialTransaction(array $commission) {
        $query = "INSERT INTO affiliate_financial_logs 
                 (affiliate_id, transaction_type, amount, balance_before, balance_after, 
                 related_id, description, created_at) 
                 VALUES (:affiliate_id, 'commission_settlement', :amount, 
                 (SELECT available_balance FROM affiliates WHERE id = :affiliate_id), 
                 (SELECT available_balance + :amount FROM affiliates WHERE id = :affiliate_id), 
                 :commission_id, :description, NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':affiliate_id', $commission['affiliate_id']);
        $stmt->bindParam(':amount', $commission['amount']);
        $stmt->bindParam(':commission_id', $commission['id']);
        $description = "订单号: {$commission['order_no']} 佣金自动结算";
        $stmt->bindParam(':description', $description);
        $stmt->execute();
    }
    
    /**
     * 发送结算通知
     * 
     * @param array $commission 佣金记录
     */
    private function sendSettlementNotification(array $commission) {
        try {
            // 这里可以集成现有的通知系统
            $notificationData = [
                'affiliate_id' => $commission['affiliate_id'],
                'type' => 'commission_settlement',
                'title' => '您的佣金已自动结算',
                'content' => "订单号 {$commission['order_no']} 的佣金 ¥{$commission['amount']} 已自动结算到您的账户余额",
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 插入通知记录
            $query = "INSERT INTO affiliate_notifications 
                     (affiliate_id, type, title, content, is_read, created_at) 
                     VALUES (:affiliate_id, :type, :title, :content, :is_read, :created_at)";
            
            $stmt = $this->db->prepare($query);
            $stmt->execute($notificationData);
            
            // 可以在这里添加邮件通知逻辑
            $this->logger->info("已发送佣金结算通知给代理 {$commission['affiliate_name']}");
        } catch (\Exception $e) {
            $this->logger->warning("发送结算通知失败: " . $e->getMessage());
            // 通知失败不影响结算流程
        }
    }
    
    /**
     * 生成结算摘要
     * 
     * @param int $processedCount 处理数量
     * @param array $results 结算结果
     */
    private function generateSettlementSummary($processedCount, array $results) {
        if ($processedCount > 0) {
            // 计算总结算金额
            $totalAmount = array_sum(array_column($results, 'amount'));
            
            // 生成摘要记录
            $summaryData = [
                'processed_at' => date('Y-m-d H:i:s'),
                'settlement_count' => $processedCount,
                'total_amount' => $totalAmount,
                'average_amount' => $processedCount > 0 ? $totalAmount / $processedCount : 0,
                'unique_affiliates' => count(array_unique(array_column($results, 'affiliate_id'))),
                'details' => json_encode($results),
                'status' => 'completed'
            ];
            
            $query = "INSERT INTO auto_settlement_summaries 
                     (processed_at, settlement_count, total_amount, average_amount, 
                     unique_affiliates, details, status) 
                     VALUES (:processed_at, :settlement_count, :total_amount, :average_amount, 
                     :unique_affiliates, :details, :status)";
            
            $stmt = $this->db->prepare($query);
            $stmt->execute($summaryData);
            
            $this->logger->info("生成结算摘要: 处理订单 {$processedCount} 个，总金额 ¥{$totalAmount}");
        }
    }
    
    /**
     * 创建自动结算摘要表（如果不存在）
     */
    public function ensureSummaryTableExists() {
        $query = "CREATE TABLE IF NOT EXISTS auto_settlement_summaries (
                 id INT AUTO_INCREMENT PRIMARY KEY,
                 processed_at DATETIME NOT NULL,
                 settlement_count INT NOT NULL DEFAULT 0,
                 total_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
                 average_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
                 unique_affiliates INT NOT NULL DEFAULT 0,
                 details TEXT,
                 status VARCHAR(20) NOT NULL DEFAULT 'completed',
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                 )";
        
        try {
            $this->db->exec($query);
            $this->logger->info("已确保自动结算摘要表存在");
        } catch (\Exception $e) {
            $this->logger->error("创建摘要表失败: " . $e->getMessage());
        }
    }
    
    /**
     * 获取自动结算状态
     * 
     * @return array 状态信息
     */
    public function getSettlementStatus() {
        try {
            // 获取最近结算记录
            $query = "SELECT * FROM auto_settlement_summaries 
                     ORDER BY processed_at DESC LIMIT 1";
            $lastSettlement = $this->db->query($query)->fetch(\PDO::FETCH_ASSOC);
            
            // 获取待结算佣金数量
            $pendingQuery = "SELECT COUNT(*) as pending_count 
                           FROM commission_records cr
                           JOIN orders o ON cr.order_id = o.id
                           WHERE cr.status = 'pending' 
                           AND o.status = 'completed'";
            $pendingCount = $this->db->query($pendingQuery)->fetchColumn();
            
            return [
                'auto_settlement_enabled' => $this->config['auto_settlement_enabled'],
                'settlement_delay_hours' => $this->config['settlement_delay_hours'],
                'run_interval_minutes' => $this->config['run_interval_minutes'],
                'last_settlement' => $lastSettlement,
                'pending_commission_count' => $pendingCount
            ];
        } catch (\Exception $e) {
            $this->logger->error("获取结算状态失败: " . $e->getMessage());
            return [];
        }
    }
}