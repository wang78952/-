<?php
/**
 * 响应式卡片组件
 * 用于在不同设备上提供一致的卡片展示体验
 * 支持移动端、平板和桌面端的自适应布局
 */

class ResponsiveCard {
    /**
     * 卡片配置参数
     * @var array
     */
    private $config = [
        'title' => '',
        'content' => '',
        'image' => '',
        'imageAlt' => '',
        'buttons' => [],
        'tags' => [],
        'footer' => '',
        'class' => '',
        'id' => '',
        'style' => '',
        'mobileOptimized' => true,
        'touchFeedback' => true,
        'lazyLoadImage' => true
    ];
    
    /**
     * 设备类型
     * @var string
     */
    private $deviceType;
    
    /**
     * 构造函数
     * @param array $config 卡片配置
     */
    public function __construct($config = []) {
        // 合并配置
        $this->config = array_merge($this->config, $config);
        
        // 检测设备类型
        $this->deviceType = $this->detectDeviceType();
    }
    
    /**
     * 检测设备类型
     * @return string 设备类型: mobile, tablet, desktop
     */
    private function detectDeviceType() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        // 移动设备检测
        if (preg_match('/(android|iphone|ipad|ipod|blackberry|iemobile|opera mini)/i', $userAgent)) {
            // 检测是否为平板
            if (preg_match('/(ipad|tablet|playbook|silk)/i', $userAgent) || 
                (preg_match('/android/i', $userAgent) && !preg_match('/mobile/i', $userAgent))) {
                return 'tablet';
            }
            return 'mobile';
        }
        
        // 检测屏幕宽度（如果有）
        if (isset($_SERVER['HTTP_X_DEVICE_WIDTH'])) {
            $width = (int)$_SERVER['HTTP_X_DEVICE_WIDTH'];
            if ($width <= 768) {
                return 'mobile';
            } elseif ($width <= 1024) {
                return 'tablet';
            }
        }
        
        return 'desktop';
    }
    
    /**
     * 获取响应式类名
     * @return string 响应式类名
     */
    private function getResponsiveClasses() {
        $classes = ['responsive-card', 'device-' . $this->deviceType];
        
        // 添加配置中的类
        if (!empty($this->config['class'])) {
            if (is_array($this->config['class'])) {
                $classes = array_merge($classes, $this->config['class']);
            } else {
                $classes[] = $this->config['class'];
            }
        }
        
        // 移动端优化类
        if ($this->config['mobileOptimized'] && $this->deviceType === 'mobile') {
            $classes[] = 'mobile-optimized';
        }
        
        // 触摸反馈类
        if ($this->config['touchFeedback'] && in_array($this->deviceType, ['mobile', 'tablet'])) {
            $classes[] = 'touch-feedback';
        }
        
        return implode(' ', $classes);
    }
    
    /**
     * 渲染图片部分
     * @return string 图片HTML
     */
    private function renderImage() {
        if (empty($this->config['image'])) {
            return '';
        }
        
        $imageAttrs = [
            'src' => $this->config['image'],
            'alt' => $this->config['imageAlt'],
            'class' => 'card-image' 
        ];
        
        // 移动端懒加载
        if ($this->config['lazyLoadImage'] && $this->deviceType === 'mobile') {
            $imageAttrs['loading'] = 'lazy';
            $imageAttrs['class'] .= ' lazy-image';
        }
        
        $attrsString = '';
        foreach ($imageAttrs as $key => $value) {
            $attrsString .= " {$key}=\"{$value}\"";
        }
        
        return "<div class='card-image-container'><img{$attrsString}></div>";
    }
    
    /**
     * 渲染标题部分
     * @return string 标题HTML
     */
    private function renderTitle() {
        if (empty($this->config['title'])) {
            return '';
        }
        
        // 根据设备类型选择标题大小
        $titleTag = $this->deviceType === 'mobile' ? 'h3' : 'h2';
        $titleClass = $this->deviceType === 'mobile' ? 'card-title mobile-title' : 'card-title';
        
        return "<{$titleTag} class='{$titleClass}'>{$this->config['title']}</{$titleTag}>";
    }
    
    /**
     * 渲染内容部分
     * @return string 内容HTML
     */
    private function renderContent() {
        if (empty($this->config['content'])) {
            return '';
        }
        
        $contentClass = $this->deviceType === 'mobile' ? 'card-content mobile-content' : 'card-content';
        
        // 移动端内容优化
        $content = $this->config['content'];
        if ($this->deviceType === 'mobile' && $this->config['mobileOptimized']) {
            // 移除多余的空白
            $content = preg_replace('/\s+/', ' ', $content);
            // 限制内容长度（如果需要）
            // $content = $this->truncateContent($content, 200);
        }
        
        return "<div class='{$contentClass}'>{$content}</div>";
    }
    
    /**
     * 渲染标签部分
     * @return string 标签HTML
     */
    private function renderTags() {
        if (empty($this->config['tags'])) {
            return '';
        }
        
        $tagsHtml = '<div class="card-tags">';
        
        foreach ($this->config['tags'] as $tag) {
            $tagClass = $this->deviceType === 'mobile' ? 'card-tag mobile-tag' : 'card-tag';
            $tagsHtml .= "<span class='{$tagClass}'>{$tag}</span>";
        }
        
        $tagsHtml .= '</div>';
        return $tagsHtml;
    }
    
    /**
     * 渲染按钮部分
     * @return string 按钮HTML
     */
    private function renderButtons() {
        if (empty($this->config['buttons'])) {
            return '';
        }
        
        $buttonClass = $this->deviceType === 'mobile' ? 'card-button mobile-button' : 'card-button';
        $buttonGroupClass = $this->deviceType === 'mobile' ? 'card-buttons mobile-buttons' : 'card-buttons';
        
        // 移动端按钮布局调整
        if ($this->deviceType === 'mobile') {
            $buttonGroupClass .= ' vertical-buttons';
        }
        
        $buttonsHtml = "<div class='{$buttonGroupClass}'>";
        
        foreach ($this->config['buttons'] as $button) {
            $btnConfig = [
                'text' => '',
                'href' => '',
                'onclick' => '',
                'class' => '',
                'primary' => false,
                'disabled' => false
            ];
            
            $btnConfig = array_merge($btnConfig, $button);
            $btnClasses = [$buttonClass];
            
            if ($btnConfig['primary']) {
                $btnClasses[] = 'primary-button';
            }
            
            if ($btnConfig['disabled']) {
                $btnClasses[] = 'disabled-button';
            }
            
            if (!empty($btnConfig['class'])) {
                $btnClasses[] = $btnConfig['class'];
            }
            
            $classString = implode(' ', $btnClasses);
            $attrs = ["class=\"{$classString}\""];
            
            if (!empty($btnConfig['onclick'])) {
                $attrs[] = "onclick=\"{$btnConfig['onclick']}\"";
            }
            
            if ($btnConfig['disabled']) {
                $attrs[] = 'disabled';
            }
            
            $attrsString = implode(' ', $attrs);
            
            if (!empty($btnConfig['href'])) {
                $buttonsHtml .= "<a href=\"{$btnConfig['href']}\" {$attrsString}>{$btnConfig['text']}</a>";
            } else {
                $buttonsHtml .= "<button {$attrsString}>{$btnConfig['text']}</button>";
            }
        }
        
        $buttonsHtml .= '</div>';
        return $buttonsHtml;
    }
    
    /**
     * 渲染页脚部分
     * @return string 页脚HTML
     */
    private function renderFooter() {
        if (empty($this->config['footer'])) {
            return '';
        }
        
        $footerClass = $this->deviceType === 'mobile' ? 'card-footer mobile-footer' : 'card-footer';
        
        return "<div class='{$footerClass}'>{$this->config['footer']}</div>";
    }
    
    /**
     * 截断内容（用于长文本）
     * @param string $content 原始内容
     * @param int $length 最大长度
     * @return string 截断后的内容
     */
    private function truncateContent($content, $length = 200) {
        if (mb_strlen($content) <= $length) {
            return $content;
        }
        
        return mb_substr($content, 0, $length) . '...';
    }
    
    /**
     * 获取卡片的JavaScript初始化代码
     * @return string JS初始化代码
     */
    public function getInitJavaScript() {
        $cardId = !empty($this->config['id']) ? $this->config['id'] : 'card-' . uniqid();
        
        $js = [];
        
        // 移动端触摸事件初始化
        if ($this->config['touchFeedback'] && in_array($this->deviceType, ['mobile', 'tablet'])) {
            $js[] = "// 初始化触摸反馈";
            $js[] = "document.getElementById('{$cardId}').addEventListener('touchstart', function() {";
            $js[] = "    this.classList.add('touching');";
            $js[] = "}, { passive: true });";
            $js[] = "";
            $js[] = "document.getElementById('{$cardId}').addEventListener('touchend', function() {";
            $js[] = "    this.classList.remove('touching');";
            $js[] = "}, { passive: true });";
        }
        
        // 图片懒加载初始化
        if ($this->config['lazyLoadImage'] && !empty($this->config['image']) && $this->deviceType === 'mobile') {
            $js[] = "";
            $js[] = "// 初始化图片懒加载";
            $js[] = "if ('IntersectionObserver' in window) {";
            $js[] = "    const observer = new IntersectionObserver((entries) => {";
            $js[] = "        entries.forEach(entry => {";
            $js[] = "            if (entry.isIntersecting) {";
            $js[] = "                const img = entry.target;";
            $js[] = "                img.classList.add('loaded');";
            $js[] = "                observer.unobserve(img);";
            $js[] = "            }";
            $js[] = "        });";
            $js[] = "    });";
            $js[] = "    ";
            $js[] = "    const lazyImg = document.querySelector('#{$cardId} .lazy-image');";
            $js[] = "    if (lazyImg) {";
            $js[] = "        observer.observe(lazyImg);";
            $js[] = "    }";
            $js[] = "}";
        }
        
        if (empty($js)) {
            return '';
        }
        
        return '<script>' . "\n" . implode("\n", $js) . "\n" . '</script>';
    }
    
    /**
     * 获取卡片的CSS样式
     * @return string CSS样式代码
     */
    public static function getCSS() {
        return "
<style>
/* 响应式卡片基础样式 */
.responsive-card {
    position: relative;
    display: flex;
    flex-direction: column;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    transition: all 0.3s ease;
    margin-bottom: 16px;
}

/* 卡片图片样式 */
.card-image-container {
    width: 100%;
    position: relative;
    overflow: hidden;
}

.card-image {
    width: 100%;
    height: auto;
    display: block;
    transition: transform 0.3s ease;
}

/* 卡片内容样式 */
.card-content {
    padding: 16px;
    flex: 1;
}

.card-title {
    margin-top: 0;
    margin-bottom: 12px;
    font-weight: 600;
    line-height: 1.3;
}

/* 标签样式 */
.card-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 16px;
}

.card-tag {
    padding: 4px 8px;
    background-color: #f0f0f0;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

/* 按钮样式 */
.card-buttons {
    display: flex;
    gap: 12px;
    margin-top: 16px;
}

.card-button {
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
    text-align: center;
}

.primary-button {
    background-color: #007bff;
    color: white;
}

.disabled-button {
    opacity: 0.6;
    cursor: not-allowed;
}

/* 页脚样式 */
.card-footer {
    padding: 12px 16px;
    background-color: #f8f9fa;
    border-top: 1px solid #e9ecef;
    font-size: 12px;
    color: #6c757d;
}

/* 移动端优化样式 */
@media (max-width: 767px) {
    .responsive-card.mobile-optimized {
        border-radius: 0;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
        margin-bottom: 12px;
    }
    
    .mobile-title {
        font-size: 18px;
        line-height: 1.2;
        margin-bottom: 8px;
    }
    
    .mobile-content {
        font-size: 14px;
        line-height: 1.5;
        padding: 12px;
    }
    
    .mobile-tag {
        font-size: 11px;
        padding: 3px 6px;
    }
    
    .mobile-buttons {
        flex-direction: column;
        gap: 8px;
        margin-top: 12px;
    }
    
    .mobile-button {
        width: 100%;
        padding: 10px;
        font-size: 15px;
    }
    
    .mobile-footer {
        padding: 8px 12px;
        font-size: 11px;
    }
    
    /* 触摸反馈样式 */
    .touch-feedback {
        -webkit-tap-highlight-color: transparent;
    }
    
    .touch-feedback.touching {
        transform: scale(0.98);
        opacity: 0.9;
    }
    
    /* 懒加载图片样式 */
    .lazy-image {
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .lazy-image.loaded {
        opacity: 1;
    }
}

/* 平板设备样式 */
@media (min-width: 768px) and (max-width: 1023px) {
    .responsive-card {
        margin-bottom: 20px;
        border-radius: 10px;
    }
    
    .card-content {
        padding: 20px;
    }
    
    .card-title {
        font-size: 22px;
    }
}

/* 桌面设备样式 */
@media (min-width: 1024px) {
    .responsive-card {
        margin-bottom: 24px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .responsive-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
    }
    
    .card-content {
        padding: 24px;
    }
    
    .card-title {
        font-size: 24px;
    }
    
    .card-button:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }
    
    .card-image:hover {
        transform: scale(1.02);
    }
}
</style>";
    }
    
    /**
     * 渲染卡片
     * @return string 完整的卡片HTML
     */
    public function render() {
        // 确保有ID
        if (empty($this->config['id'])) {
            $this->config['id'] = 'card-' . uniqid();
        }
        
        $idAttr = !empty($this->config['id']) ? " id=\"{$this->config['id']}\"" : '';
        $styleAttr = !empty($this->config['style']) ? " style=\"{$this->config['style']}\"" : '';
        
        $html = [];
        $html[] = "<div class=\"{$this->getResponsiveClasses()}\"{$idAttr}{$styleAttr}>";
        
        // 根据设备类型决定内容顺序
        if ($this->deviceType === 'mobile') {
            // 移动端顺序: 图片 -> 标题 -> 标签 -> 内容 -> 按钮 -> 页脚
            $html[] = $this->renderImage();
            $html[] = '<div class="card-body">';
            $html[] = $this->renderTitle();
            $html[] = $this->renderTags();
            $html[] = $this->renderContent();
            $html[] = $this->renderButtons();
            $html[] = '</div>';
            $html[] = $this->renderFooter();
        } else {
            // 桌面端顺序: 图片 -> 标题 -> 内容 -> 标签 -> 按钮 -> 页脚
            $html[] = $this->renderImage();
            $html[] = '<div class="card-body">';
            $html[] = $this->renderTitle();
            $html[] = $this->renderContent();
            $html[] = $this->renderTags();
            $html[] = $this->renderButtons();
            $html[] = '</div>';
            $html[] = $this->renderFooter();
        }
        
        $html[] = '</div>';
        
        // 添加初始化脚本（仅在需要时）
        if ($this->config['touchFeedback'] || $this->config['lazyLoadImage']) {
            $html[] = $this->getInitJavaScript();
        }
        
        return implode("\n", $html);
    }
    
    /**
     * 静态工厂方法，快速创建卡片
     * @param array $config 卡片配置
     * @return string 渲染后的卡片HTML
     */
    public static function create($config = []) {
        $card = new self($config);
        return $card->render();
    }
    
    /**
     * 创建响应式卡片组
     * @param array $cards 卡片配置数组
     * @param array $options 卡片组选项
     * @return string 卡片组HTML
     */
    public static function createCardGrid($cards, $options = []) {
        $defaultOptions = [
            'columns' => 3,
            'gap' => '20px',
            'class' => '',
            'id' => ''
        ];
        
        $options = array_merge($defaultOptions, $options);
        $gridClasses = ['card-grid'];
        
        // 检测设备类型设置响应式列数
        $deviceType = isset($_SERVER['HTTP_USER_AGENT']) ? 
            (preg_match('/(android|iphone|ipad|ipod|blackberry|iemobile|opera mini)/i', $_SERVER['HTTP_USER_AGENT']) ? 'mobile' : 'desktop') : 
            'desktop';
        
        if ($deviceType === 'mobile') {
            $gridClasses[] = 'mobile-grid';
            $columns = 1;
        } else {
            // 桌面端根据屏幕宽度调整列数
            $columns = $options['columns'];
            $gridClasses[] = "grid-cols-{$columns}";
        }
        
        if (!empty($options['class'])) {
            $gridClasses[] = $options['class'];
        }
        
        $idAttr = !empty($options['id']) ? " id=\"{$options['id']}\"" : '';
        $styleAttr = " style=\"gap: {$options['gap']}\"";
        
        $html = [];
        $html[] = "<div class=\"{$gridClasses['0']}\"{$idAttr}{$styleAttr}>";
        
        foreach ($cards as $cardConfig) {
            $cardConfig['mobileOptimized'] = true;
            $card = new self($cardConfig);
            $html[] = "<div class='grid-item'>" . $card->render() . "</div>";
        }
        
        $html[] = '</div>';
        
        // 添加卡片组CSS
        $html[] = "
<style>
.card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.grid-cols-1 { grid-template-columns: repeat(1, 1fr); }
.grid-cols-2 { grid-template-columns: repeat(2, 1fr); }
.grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
.grid-cols-4 { grid-template-columns: repeat(4, 1fr); }

.mobile-grid {
    grid-template-columns: 1fr;
    gap: 12px;
}

@media (min-width: 768px) and (max-width: 1023px) {
    .card-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    }
}

@media (max-width: 767px) {
    .grid-item {
        width: 100%;
    }
}
</style>";
        
        return implode("\n", $html);
    }
}