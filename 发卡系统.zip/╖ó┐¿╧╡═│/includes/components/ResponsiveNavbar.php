\u003c?php
/**
 * 响应式导航栏组件
 * 提供桌面端和移动端优化的导航菜单功能
 */

class ResponsiveNavbar {
    /**
     * 导航栏配置
     * @var array
     */
    protected $config = [
        'id' =\u003e 'responsive-navbar',
        'class' =\u003e '',
        'brand' =\u003e [
            'name' =\u003e '发卡系统',
            'url' =\u003e '/',
            'logo' =\u003e '',
            'logo_width' =\u003e '32px',
            'logo_height' =\u003e '32px'
        ],
        'menu_items' =\u003e [],
        'mobile_breakpoint' =\u003e 768,
        'collapse_method' =\u003e 'slide', // slide, fade, flip, none
        'fixed_position' =\u003e true,
        'scroll_effect' =\u003e true,
        'search_enabled' =\u003e false,
        'dark_mode' =\u003e false,
        'show_breadcrumbs' =\u003e false,
        'current_path' =\u003e '',
        'accessibility' =\u003e true,
        'transition_speed' =\u003e '300ms',
        'offcanvas' =\u003e false, // 使用抽屉式菜单
        'offcanvas_position' =\u003e 'left', // left, right
        'mobile_overlay' =\u003e true,
        'double_tap_to_close' =\u003e true,
        'swipe_nav' =\u003e true
    ];
    
    /**
     * 设备检测工具
     * @var MobileDeviceDetector
     */
    protected $deviceDetector;
    
    /**
     * 构造函数
     * @param array $config 导航栏配置
     */
    public function __construct($config = []) {
        // 合并配置
        $this-\u003econfig = $this-\u003emergeConfig($this-\u003econfig, $config);
        
        // 初始化设备检测器
        $this-\u003edeviceDetector = null;
        if (class_exists('MobileDeviceDetector')) {
            $this-\u003edeviceDetector = new MobileDeviceDetector();
        }
        
        // 获取当前路径
        if (empty($this-\u003econfig['current_path'])) {
            $this-\u003econfig['current_path'] = $this-\u003egetCurrentPath();
        }
    }
    
    /**
     * 合并配置数组
     * @param array $base 基础配置
     * @param array $custom 自定义配置
     * @return array 合并后的配置
     */
    protected function mergeConfig($base, $custom) {
        foreach ($custom as $key =\u003e $value) {
            if (isset($base[$key]) && is_array($value) && is_array($base[$key])) {
                $base[$key] = $this-\u003emergeConfig($base[$key], $value);
            } else {
                $base[$key] = $value;
            }
        }
        return $base;
    }
    
    /**
     * 获取当前路径
     * @return string 当前路径
     */
    protected function getCurrentPath() {
        $path = $_SERVER['REQUEST_URI'] ?? '/';
        $pathParts = parse_url($path);
        return $pathParts['path'] ?? '/';
    }
    
    /**
     * 检查是否为移动视图
     * @return bool 是否为移动视图
     */
    public function isMobileView() {
        if ($this-\u003edeviceDetector) {
            $screenWidth = $this-\u003edeviceDetector-\u003 egetScreenWidth();
            return $screenWidth \u003c $this-\u003econfig['mobile_breakpoint'];
        }
        // 默认返回false，让前端JavaScript处理响应式
        return false;
    }
    
    /**
     * 检查菜单项是否为当前激活项
     * @param string $url 菜单项URL
     * @return bool 是否为当前项
     */
    protected function isActiveItem($url) {
        $currentPath = $this-\u003econfig['current_path'];
        
        // 完全匹配
        if ($url === $currentPath) {
            return true;
        }
        
        // 子路径匹配（用于包含关系）
        if (strpos($currentPath, $url) === 0 && $url !== '/') {
            // 避免根路径匹配所有
            return true;
        }
        
        // 处理相对路径
        $basePath = dirname($currentPath);
        if ($basePath !== '/' && $url === $basePath) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 渲染品牌区域
     * @return string 品牌HTML
     */
    protected function renderBrand() {
        $brand = $this-\u003econfig['brand'];
        $brandHtml = "\n        \u003ca href=\"{$brand['url']}\" class=\"navbar-brand\" rel=\"home\" aria-label=\"品牌首页\"\u003e";
        
        // 渲染Logo
        if (!empty($brand['logo'])) {
            $brandHtml .= "\n            \u003cimg src=\"{$brand['logo']}\" alt=\"{$brand['name']}\" " .
                         "width=\"{$brand['logo_width']}\" height=\"{$brand['logo_height']}\" " .
                         "class=\"navbar-brand-logo\" loading=\"lazy\"\u003e";
        }
        
        // 渲染品牌名称
        if (!empty($brand['name'])) {
            $brandHtml .= "\n            \u003cspan class=\"navbar-brand-name\"\u003e{$brand['name']}\u003c/span\u003e";
        }
        
        $brandHtml .= "\n        \u003c/a\u003e";
        return $brandHtml;
    }
    
    /**
     * 渲染搜索表单
     * @return string 搜索表单HTML
     */
    protected function renderSearchForm() {
        if (!$this-\u003econfig['search_enabled']) {
            return '';
        }
        
        $searchId = $this-\u003econfig['id'] . '-search';
        
        return "\n        \u003cdiv class=\"navbar-search\"\u003e\n            \u003cform role=\"search\" method=\"get\" action=\"/search\"\u003e\n                \u003cdiv class=\"search-input-group\"\u003e\n                    \u003cinput\n                        type=\"search\"\n                        id=\"{$searchId}\"\n                        name=\"q\"\n                        placeholder=\"" . __('搜索...') . \"\"\n                        aria-label=\"搜索\"\n                        class=\"search-input\"\n                        autocomplete=\"off\"\n                    \u003e\n                    \u003cbutton\n                        type=\"submit\"\n                        class=\"search-button\"\n                        aria-label=\"搜索提交\"\n                    \u003e\n                        \u003cspan class=\"search-icon\"\u003e\u003c/svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"currentColor\"\u003e\u003cpath d=\"M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z\"/\u003e\u003c/svg\u003e\u003c/span\u003e\n                    \u003c/button\n                \u003c/div\n            \u003c/form\n        \u003c/div\n        ";
    }
    
    /**
     * 渲染菜单项
     * @param array $item 菜单项配置
     * @param int $level 层级
     * @return string 菜单项HTML
     */
    protected function renderMenuItem($item, $level = 0) {
        $isActive = $this-\u003eisActiveItem($item['url'] ?? '#');
        $hasChildren = !empty($item['children']) && is_array($item['children']);
        $itemId = $this-\u003econfig['id'] . '-menu-' . ($item['id'] ?? sanitize_title($item['title'] ?? 'item'));
        $itemClass = ['nav-item'];
        
        // 层级类
        if ($level \u003e 0) {
            $itemClass[] = "nav-item-level-{$level}";
        }
        
        // 激活状态
        if ($isActive) {
            $itemClass[] = 'nav-item-active';
        }
        
        // 子菜单类
        if ($hasChildren) {
            $itemClass[] = 'nav-item-has-children';
        }
        
        // 自定义类
        if (!empty($item['class'])) {
            $itemClass[] = $item['class'];
        }
        
        // 权限控制
        if (isset($item['permission']) && $item['permission'] === false) {
            return '';
        }
        
        // 开始菜单项
        $html = "\n            \u003cli class=\"" . implode(' ', $itemClass) . "\" id=\"{$itemId}\"\u003e";
        
        // 菜单项链接
        $linkAttrs = [];
        $linkAttrs[] = "href=\"{$item['url'] ?? '#'}\"";
        $linkAttrs[] = "class=\"nav-link\"";
        
        if (!empty($item['target'])) {
            $linkAttrs[] = "target=\"{$item['target']}\"";
        }
        
        if (!empty($item['rel'])) {
            $linkAttrs[] = "rel=\"{$item['rel']}\"";
        }
        
        if ($hasChildren && $this-\u003econfig['accessibility']) {
            $linkAttrs[] = "aria-haspopup=\"true\"";
            $linkAttrs[] = "aria-expanded=\"false\"";
        }
        
        if (!empty($item['title'])) {
            $linkAttrs[] = "title=\"{$item['title']}\"";
        }
        
        $html .= "\n                \u003ca " . implode(' ', $linkAttrs) . "\u003e";
        
        // 菜单项图标
        if (!empty($item['icon'])) {
            $html .= "\n                    \u003cspan class=\"nav-link-icon\"\u003e{$item['icon']}\u003c/span\u003e";
        }
        
        // 菜单项文本
        if (!empty($item['title'])) {
            $html .= "\n                    \u003cspan class=\"nav-link-text\"\u003e" . __('{$item['title']}') . "\u003c/span\u003e";
        }
        
        // 子菜单指示器
        if ($hasChildren) {
            $html .= "\n                    \u003cspan class=\"nav-link-dropdown-toggle\" aria-hidden=\"true\"\u003e▼\u003c/span\u003e";
        }
        
        $html .= "\n                \u003c/a\u003e";
        
        // 渲染子菜单
        if ($hasChildren) {
            $submenuClass = ['nav-submenu'];
            if ($level === 0) {
                $submenuClass[] = 'navbar-dropdown';
            }
            
            $html .= "\n                \u003cdiv class=\"" . implode(' ', $submenuClass) . "\"\u003e\n                    \u003cul class=\"nav-submenu-list\"\u003e";
            
            foreach ($item['children'] as $childItem) {
                $html .= $this-\u003erenderMenuItem($childItem, $level + 1);
            }
            
            $html .= "\n                    \u003c/ul\n                \u003c/div\n                ";
        }
        
        $html .= "\n            \u003c/li\u003e";
        
        return $html;
    }
    
    /**
     * 渲染导航菜单
     * @return string 菜单HTML
     */
    protected function renderMenu() {
        $menuItems = $this-\u003econfig['menu_items'];
        
        if (empty($menuItems)) {
            return '';
        }
        
        $menuHtml = "\n        \u003cnav class=\"navbar-nav\" aria-label=\"主导航\"\u003e\n            \u003cul class=\"main-nav-list\"\u003e";
        
        foreach ($menuItems as $item) {
            $menuHtml .= $this-\u003erenderMenuItem($item);
        }
        
        $menuHtml .= "\n            \u003c/ul\n        \u003c/nav\n        ";
        
        return $menuHtml;
    }
    
    /**
     * 渲染移动端菜单按钮
     * @return string 移动端按钮HTML
     */
    protected function renderMobileToggle() {
        $toggleId = $this-\u003econfig['id'] . '-mobile-toggle';
        $ariaExpanded = 'false';
        
        return "\n        \u003cbutton\n            type=\"button\"\n            id=\"{$toggleId}\"\n            class=\"navbar-mobile-toggle\"\n            aria-expanded=\"{$ariaExpanded}\"\n            aria-controls=\"{$this-\u003econfig['id']}-collapse\"\n            aria-label=\"切换导航菜单\"\n            data-toggle=\"collapse\"\n            data-target=\"#{$this-\u003econfig['id']}-collapse\"\n        \u003e\n            \u003cspan class=\"toggle-icon\" aria-hidden=\"true\"\u003e\u003c/svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"\u003e\n                \u003cline x1=\"3\" y1=\"12\" x2=\"21\" y2=\"12\"\u003e\u003c/line\u003e\n                \u003cline x1=\"3\" y1=\"6\" x2=\"21\" y2=\"6\"\u003e\u003c/line\u003e\n                \u003cline x1=\"3\" y1=\"18\" x2=\"21\" y2=\"18\"\u003e\u003c/line\u003e\n            \u003c/svg\u003e\u003c/span\u003e\n            \u003cspan class=\"toggle-icon close\" aria-hidden=\"true\"\u003e\u003c/svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"\u003e\n                \u003cline x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"\u003e\u003c/line\u003e\n                \u003cline x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"\u003e\u003c/line\u003e\n            \u003c/svg\u003e\u003c/span\u003e\n            \u003cspan class=\"sr-only\"\u003e切换菜单\u003c/span\u003e\n        \u003c/button\n        ";
    }
    
    /**
     * 渲染面包屑导航
     * @return string 面包屑HTML
     */
    protected function renderBreadcrumbs() {
        if (!$this-\u003econfig['show_breadcrumbs']) {
            return '';
        }
        
        $path = $this-\u003econfig['current_path'];
        $segments = explode('/', trim($path, '/'));
        $crumbs = [];
        $currentPath = '/';
        
        // 添加首页
        $crumbs[] = [
            'title' =\u003e __('首页'),
            'url' =\u003e '/'
        ];
        
        // 构建路径段
        foreach ($segments as $segment) {
            if (!empty($segment)) {
                $currentPath .= "{$segment}/";
                $crumbs[] = [
                    'title' =\u003e ucfirst(str_replace(['-', '_'], ' ', $segment)),
                    'url' =\u003e $currentPath
                ];
            }
        }
        
        // 渲染面包屑
        $breadcrumbHtml = "\n        \u003cnav class=\"breadcrumb-nav\" aria-label=\"面包屑导航\"\u003e\n            \u003col class=\"breadcrumb\"\u003e";
        
        foreach ($crumbs as $index =\u003e $crumb) {
            $isLast = ($index === count($crumbs) - 1);
            $itemClass = ['breadcrumb-item'];
            
            if ($isLast) {
                $itemClass[] = 'breadcrumb-item-active';
            }
            
            $breadcrumbHtml .= "\n                \u003cli class=\"" . implode(' ', $itemClass) . "\"";
            
            if ($isLast) {
                $breadcrumbHtml .= " aria-current=\"page\"";
            }
            
            $breadcrumbHtml .= "\u003e";
            
            if ($isLast) {
                $breadcrumbHtml .= "\n                    {$crumb['title']}";
            } else {
                $breadcrumbHtml .= "\n                    \u003ca href=\"{$crumb['url']}\"\u003e{$crumb['title']}\u003c/a\u003e";
            }
            
            $breadcrumbHtml .= "\n                \u003c/li\u003e";
        }
        
        $breadcrumbHtml .= "\n            \u003c/ol\n        \u003c/nav\n        ";
        
        return $breadcrumbHtml;
    }
    
    /**
     * 获取组件CSS样式
     * @return string CSS样式
     */
    public static function getCSS() {
        return "\n\u003cstyle\u003e
/* 响应式导航栏基础样式 */
.navbar {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.75rem 1rem;
    background-color: #ffffff;
    border-bottom: 1px solid #e0e0e0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    z-index: 1000;
}

/* 固定定位 */
.navbar.fixed-top {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    width: 100%;
    max-width: 100%;
}

/* 移动端导航容器 */
.navbar-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
}

/* 品牌区域 */
.navbar-brand {
    display: flex;
    align-items: center;
    text-decoration: none;
    color: inherit;
    font-weight: 600;
    font-size: 1.25rem;
    white-space: nowrap;
    transition: color 0.2s ease;
}

.navbar-brand:hover,
.navbar-brand:focus {
    color: #007bff;
}

.navbar-brand-logo {
    vertical-align: middle;
    margin-right: 0.5rem;
    object-fit: contain;
}

/* 导航菜单 */
.navbar-nav {
    display: flex;
    flex-direction: row;
    align-items: center;
    margin: 0;
    padding: 0;
}

.main-nav-list {
    display: flex;
    flex-direction: row;
    list-style: none;
    margin: 0;
    padding: 0;
}

.nav-item {
    position: relative;
    margin: 0 0.25rem;
}

.nav-link {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    color: #333333;
    text-decoration: none;
    font-size: 0.875rem;
    font-weight: 500;
    transition: all 0.2s ease;
    border-radius: 4px;
    white-space: nowrap;
}

.nav-link:hover,
.nav-link:focus {
    color: #007bff;
    background-color: #f8f9fa;
}

.nav-item-active .nav-link {
    color: #007bff;
    background-color: #e3f2fd;
    font-weight: 600;
}

.nav-link-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-right: 0.5rem;
    font-size: 1rem;
}

/* 子菜单 */
.nav-submenu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 160px;
    padding: 0.5rem 0;
    margin: 0.125rem 0 0;
    font-size: 0.875rem;
    color: #333333;
    text-align: left;
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.nav-item-has-children:hover .nav-submenu {
    display: block;
}

.nav-submenu-list {
    list-style: none;
    margin: 0;
    padding: 0;
}

.nav-item-level-1 .nav-link {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
}

.nav-link-dropdown-toggle {
    margin-left: 0.5rem;
    font-size: 0.75rem;
    transition: transform 0.3s ease;
}

.nav-item-has-children:hover .nav-link-dropdown-toggle {
    transform: rotate(180deg);
}

/* 移动端按钮 */
.navbar-mobile-toggle {
    display: none;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    padding: 0.5rem;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s ease;
    color: #333333;
}

.navbar-mobile-toggle:hover,
.navbar-mobile-toggle:focus {
    background-color: #f8f9fa;
    color: #007bff;
}

.toggle-icon {
    display: block;
    transition: all 0.3s ease;
}

.toggle-icon.close {
    display: none;
}

.navbar-mobile-toggle.active .toggle-icon {
    display: none;
}

.navbar-mobile-toggle.active .toggle-icon.close {
    display: block;
}

/* 折叠容器 */
.navbar-collapse {
    display: flex;
    align-items: center;
    flex-grow: 1;
    transition: all 0.3s ease;
}

.navbar-mobile-container {
    display: none;
}

/* 搜索表单 */
.navbar-search {
    margin-left: auto;
    position: relative;
}

.search-input-group {
    display: flex;
    align-items: center;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    overflow: hidden;
    background-color: #f8f9fa;
}

.search-input {
    padding: 0.5rem 1rem;
    border: none;
    background: transparent;
    outline: none;
    font-size: 0.875rem;
    width: 200px;
    transition: all 0.2s ease;
}

.search-input:focus {
    width: 250px;
    background-color: #ffffff;
}

.search-button {
    padding: 0.5rem;
    background: transparent;
    border: none;
    cursor: pointer;
    color: #333333;
    transition: all 0.2s ease;
}

.search-button:hover {
    color: #007bff;
}

/* 面包屑导航 */
.breadcrumb-nav {
    display: none;
    flex-grow: 1;
    margin: 0 1rem;
}

.breadcrumb {
    display: flex;
    flex-wrap: wrap;
    list-style: none;
    margin: 0;
    padding: 0;
    font-size: 0.75rem;
}

.breadcrumb-item {
    margin-right: 0.5rem;
}

.breadcrumb-item + .breadcrumb-item::before {
    display: inline-block;
    content: ">";
    margin-right: 0.5rem;
    color: #6c757d;
}

.breadcrumb-item-active {
    color: #6c757d;
    font-weight: 500;
}

.breadcrumb-item a {
    color: #007bff;
    text-decoration: none;
}

.breadcrumb-item a:hover {
    text-decoration: underline;
}

/* 滚动效果 */
.navbar.scrolled {
    background-color: rgba(255, 255, 255, 0.95);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
}

/* 暗色主题 */
.navbar.dark-mode {
    background-color: #212529;
    border-color: #343a40;
}

.navbar.dark-mode .nav-link,
.navbar.dark-mode .navbar-brand,
.navbar.dark-mode .navbar-mobile-toggle {
    color: #e9ecef;
}

.navbar.dark-mode .nav-link:hover,
.navbar.dark-mode .nav-link:focus,
.navbar.dark-mode .navbar-brand:hover,
.navbar.dark-mode .navbar-brand:focus {
    color: #ffffff;
}

.navbar.dark-mode .nav-submenu {
    background-color: #343a40;
    border-color: #495057;
    color: #e9ecef;
}

.navbar.dark-mode .search-input-group {
    background-color: #495057;
    border-color: #6c757d;
}

.navbar.dark-mode .search-input {
    color: #e9ecef;
}

/* 抽屉式菜单 */
.navbar-offcanvas {
    position: fixed;
    top: 0;
    width: 300px;
    height: 100vh;
    background-color: #ffffff;
    box-shadow: -2px 0 10px rgba(0, 0, 0, 0.15);
    z-index: 1050;
    transform: translateX(-100%);
    transition: transform 0.3s ease;
    overflow-y: auto;
}

.navbar-offcanvas.active {
    transform: translateX(0);
}

.navbar-offcanvas.right {
    left: auto;
    right: 0;
    transform: translateX(100%);
}

.navbar-offcanvas.right.active {
    transform: translateX(0);
}

.navbar-offcanvas .navbar-container {
    flex-direction: column;
    align-items: flex-start;
    padding: 1rem;
}

.navbar-offcanvas .navbar-nav {
    width: 100%;
    flex-direction: column;
}

.navbar-offcanvas .main-nav-list {
    flex-direction: column;
    width: 100%;
}

.navbar-offcanvas .nav-item {
    width: 100%;
    margin: 0.125rem 0;
}

/* 移动设备遮罩层 */
.navbar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1040;
    transition: opacity 0.3s ease;
}

.navbar-overlay.active {
    display: block;
}

/* 响应式断点 */
@media (max-width: 767px) {
    .navbar {
        padding: 0.5rem;
    }
    
    .navbar-mobile-toggle {
        display: flex;
    }
    
    .navbar-collapse {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background-color: #ffffff;
        border-bottom: 1px solid #e0e0e0;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        padding: 0.5rem;
        z-index: 999;
    }
    
    .navbar-collapse.active {
        display: block;
    }
    
    .navbar-nav {
        flex-direction: column;
        width: 100%;
    }
    
    .main-nav-list {
        flex-direction: column;
        width: 100%;
    }
    
    .nav-item {
        width: 100%;
        margin: 0.125rem 0;
    }
    
    .nav-submenu {
        position: relative;
        top: 0;
        left: 0;
        min-width: auto;
        width: 100%;
        border: none;
        box-shadow: none;
        background-color: #f8f9fa;
    }
    
    .nav-link {
        padding: 0.75rem;
        width: 100%;
    }
    
    .nav-item-level-1 .nav-link {
        padding-left: 1.5rem;
    }
    
    .navbar-search {
        margin: 1rem 0;
        width: 100%;
    }
    
    .search-input {
        width: 100%;
    }
    
    .search-input:focus {
        width: 100%;
    }
    
    .breadcrumb-nav {
        display: none;
    }
    
    /* 折叠动画 */
    .navbar-collapse.slide {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
    }
    
    .navbar-collapse.slide.active {
        max-height: 600px;
    }
    
    .navbar-collapse.fade {
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }
    
    .navbar-collapse.fade.active {
        opacity: 1;
        visibility: visible;
    }
    
    /* 抽屉式菜单移动端 */
    .navbar-offcanvas .navbar-overlay {
        display: block;
        opacity: 0;
        pointer-events: none;
    }
    
    .navbar-offcanvas.active .navbar-overlay {
        opacity: 1;
        pointer-events: auto;
    }
}

@media (min-width: 768px) {
    .navbar {
        padding: 0.75rem 2rem;
    }
    
    .nav-item {
        margin: 0 0.5rem;
    }
    
    .navbar-container {
        max-width: 1200px;
        margin: 0 auto;
        width: 100%;
    }
    
    .breadcrumb-nav {
        display: block;
    }
}

@media (min-width: 992px) {
    .nav-link {
        font-size: 0.9375rem;
    }
    
    .nav-submenu {
        min-width: 180px;
    }
}

/* 高对比度模式 */
@media (prefers-contrast: high) {
    .navbar {
        border-width: 2px;
    }
    
    .nav-submenu {
        border-width: 2px;
    }
}

/* 减少动画偏好 */
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
    }
}

/* 触摸设备优化 */
@media (hover: none) {
    .nav-link {
        padding: 0.875rem 1rem;
    }
    
    .nav-item-has-children .nav-submenu {
        display: none;
    }
    
    .nav-item-has-children.active .nav-submenu {
        display: block;
    }
}

/* 打印样式 */
@media print {
    .navbar {
        display: none;
    }
}
\u003c/style\u003e";
    }
    
    /**
     * 获取组件JavaScript代码
     * @return string JavaScript代码
     */
    public function getJavaScript() {
        $navbarId = $this-\u003econfig['id'];
        $mobileBreakpoint = $this-\u003econfig['mobile_breakpoint'];
        $transitionSpeed = $this-\u003econfig['transition_speed'];
        $offcanvas = $this-\u003econfig['offcanvas'] ? 'true' : 'false';
        $offcanvasPosition = $this-\u003econfig['offcanvas_position'];
        $mobileOverlay = $this-\u003econfig['mobile_overlay'] ? 'true' : 'false';
        $doubleTapToClose = $this-\u003econfig['double_tap_to_close'] ? 'true' : 'false';
        $swipeNav = $this-\u003econfig['swipe_nav'] ? 'true' : 'false';
        $scrollEffect = $this-\u003econfig['scroll_effect'] ? 'true' : 'false';
        $collapseMethod = $this-\u003econfig['collapse_method'];
        
        return "\n\u003cscript\u003e
// 响应式导航栏初始化
(function() {
    const navbar = document.getElementById('{$navbarId}');
    const mobileToggle = document.getElementById('{$navbarId}-mobile-toggle');
    const collapse = document.getElementById('{$navbarId}-collapse');
    const windowWidth = window.innerWidth;
    const isMobileView = windowWidth \u003c {$mobileBreakpoint};
    const submenuToggles = document.querySelectorAll('.nav-item-has-children > .nav-link');
    const offcanvas = {$offcanvas};
    const offcanvasPosition = '{$offcanvasPosition}';
    const mobileOverlay = {$mobileOverlay};
    const doubleTapToClose = {$doubleTapToClose};
    const swipeNav = {$swipeNav};
    const scrollEffect = {$scrollEffect};
    const transitionSpeed = '{$transitionSpeed}';
    const collapseMethod = '{$collapseMethod}';
    let lastTap = 0;
    let startX = 0;
    let isSwiping = false;
    
    if (!navbar) return;
    
    // 创建遮罩层
    function createOverlay() {
        if (!mobileOverlay) return null;
        
        let overlay = document.createElement('div');
        overlay.className = 'navbar-overlay';
        overlay.addEventListener('click', function() {
            toggleNavbar();
        });
        
        document.body.appendChild(overlay);
        return overlay;
    }
    
    const overlay = createOverlay();
    
    // 切换导航栏
    function toggleNavbar() {
        if (collapse) {
            collapse.classList.toggle('active');
            
            if (mobileToggle) {
                mobileToggle.classList.toggle('active');
                const expanded = mobileToggle.getAttribute('aria-expanded') === 'true';
                mobileToggle.setAttribute('aria-expanded', !expanded);
            }
            
            if (overlay) {
                overlay.classList.toggle('active');
            }
            
            // 防止背景滚动
            document.body.classList.toggle('navbar-open');
            if (document.body.classList.contains('navbar-open')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        }
    }
    
    // 绑定移动切换按钮
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleNavbar();
        });
        
        // 双击关闭支持
        if (doubleTapToClose) {
            mobileToggle.addEventListener('touchend', function(e) {
                const currentTime = new Date().getTime();
                const tapLength = currentTime - lastTap;
                
                if (tapLength \u003c 300 && tapLength \u003e 0) {
                    toggleNavbar();
                }
                
                lastTap = currentTime;
            });
        }
    }
    
    // 子菜单切换
    submenuToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            if (isMobileView || offcanvas) {
                e.preventDefault();
                const parent = this.parentElement;
                parent.classList.toggle('active');
                
                const submenu = this.nextElementSibling?.classList.contains('nav-submenu') 
                    ? this.nextElementSibling 
                    : null;
                
                if (submenu) {
                    const expanded = this.getAttribute('aria-expanded') === 'true';
                    this.setAttribute('aria-expanded', !expanded);
                    
                    if (collapseMethod === 'slide') {
                        if (submenu.style.maxHeight) {
                            submenu.style.maxHeight = null;
                        } else {
                            submenu.style.maxHeight = submenu.scrollHeight + 'px';
                        }
                    } else if (collapseMethod === 'fade') {
                        submenu.classList.toggle('active');
                    }
                }
            }
        });
    });
    
    // 滑动导航支持
    if (swipeNav && (isMobileView || offcanvas)) {
        document.addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
            isSwiping = true;
        }, { passive: true });
        
        document.addEventListener('touchmove', function(e) {
            if (!isSwiping) return;
            
            const currentX = e.touches[0].clientX;
            const diffX = currentX - startX;
            
            // 左滑或右滑检测
            const threshold = 50;
            if (Math.abs(diffX) \u003e threshold) {
                const isLeftSwipe = diffX \u003c 0;
                
                if ((offcanvasPosition === 'left' && !isLeftSwipe) || 
                    (offcanvasPosition === 'right' && isLeftSwipe)) {
                    toggleNavbar();
                }
                
                isSwiping = false;
            }
        }, { passive: true });
        
        document.addEventListener('touchend', function() {
            isSwiping = false;
        });
    }
    
    // 滚动效果
    if (scrollEffect) {
        let lastScrollTop = 0;
        
        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            if (Math.abs(lastScrollTop - scrollTop) \u003e 5) {
                if (scrollTop \u003e 50) {
                    navbar.classList.add('scrolled');
                    navbar.classList.add('navbar-scrolled-down');
                    navbar.classList.remove('navbar-scrolled-up');
                } else {
                    navbar.classList.remove('scrolled');
                    navbar.classList.remove('navbar-scrolled-down');
                }
                
                lastScrollTop = scrollTop;
            }
        });
    }
    
    // 窗口大小变化处理
    window.addEventListener('resize', function() {
        const newWindowWidth = window.innerWidth;
        const newIsMobileView = newWindowWidth \u003c {$mobileBreakpoint};
        
        if (isMobileView !== newIsMobileView) {
            // 重新初始化导航栏
            if (!newIsMobileView) {
                // 切换到桌面模式
                if (collapse) {
                    collapse.classList.remove('active');
                }
                
                if (mobileToggle) {
                    mobileToggle.classList.remove('active');
                    mobileToggle.setAttribute('aria-expanded', 'false');
                }
                
                if (overlay) {
                    overlay.classList.remove('active');
                }
                
                document.body.classList.remove('navbar-open');
                document.body.style.overflow = '';
            }
        }
    });
    
    // 键盘导航支持
    document.addEventListener('keydown', function(e) {
        // ESC键关闭导航栏
        if (e.key === 'Escape' && collapse && collapse.classList.contains('active')) {
            toggleNavbar();
        }
        
        // Tab键陷阱处理
        if (e.key === 'Tab' && collapse && collapse.classList.contains('active')) {
            const focusable = collapse.querySelectorAll('a[href], button:not([disabled])');
            const firstFocusable = focusable[0];
            const lastFocusable = focusable[focusable.length - 1];
            
            if (e.shiftKey && document.activeElement === firstFocusable) {
                e.preventDefault();
                lastFocusable.focus();
            } else if (!e.shiftKey && document.activeElement === lastFocusable) {
                e.preventDefault();
                firstFocusable.focus();
            }
        }
    });
})();
\u003c/script\u003e";
    }
    
    /**
     * 渲染整个导航栏
     * @return string 完整导航栏HTML
     */
    public function render() {
        $navbarId = $this-\u003econfig['id'];
        $navbarClass = ['navbar'];
        
        // 基础配置类
        if ($this-\u003econfig['fixed_position']) {
            $navbarClass[] = 'fixed-top';
        }
        
        if ($this-\u003econfig['dark_mode']) {
            $navbarClass[] = 'dark-mode';
        }
        
        if ($this-\u003econfig['offcanvas']) {
            $navbarClass[] = 'navbar-offcanvas';
            $navbarClass[] = $this-\u003econfig['offcanvas_position'];
        }
        
        if (!empty($this-\u003econfig['class'])) {
            $navbarClass[] = $this-\u003econfig['class'];
        }
        
        // 合并类名
        $navbarClassString = implode(' ', $navbarClass);
        
        // 开始渲染
        $html = "\n\u003cnav id=\"{$navbarId}\" class=\"{$navbarClassString}\" role=\"navigation\" aria-label=\"主导航\"\u003e";
        
        // 导航容器
        $html .= "\n    \u003cdiv class=\"navbar-container\"\u003e";
        
        // 移动端菜单按钮
        $html .= $this-\u003erenderMobileToggle();
        
        // 品牌区域
        $html .= $this-\u003erenderBrand();
        
        // 面包屑导航
        $html .= $this-\u003erenderBreadcrumbs();
        
        // 导航折叠容器
        $collapseClass = ['navbar-collapse'];
        
        if ($this-\u003econfig['collapse_method'] !== 'none') {
            $collapseClass[] = $this-\u003econfig['collapse_method'];
        }
        
        $html .= "\n    \u003cdiv id=\"{$navbarId}-collapse\" class=\"" . implode(' ', $collapseClass) . "\"\u003e";
        
        // 渲染导航菜单
        $html .= $this-\u003erenderMenu();
        
        // 渲染搜索表单
        $html .= $this-\u003erenderSearchForm();
        
        $html .= "\n    \u003c/div\u003e";
        $html .= "\n    \u003c/div\u003e";
        
        // 结束导航
        $html .= "\n\u003c/nav\u003e";
        
        // 添加CSS和JavaScript
        $html .= self::getCSS();
        $html .= $this-\u003 egetJavaScript();
        
        return $html;
    }
    
    /**
     * 静态工厂方法
     * @param array $config 导航栏配置
     * @return ResponsiveNavbar 导航栏实例
     */
    public static function create($config = []) {
        return new self($config);
    }
    
    /**
     * 快速渲染方法
     * @param array $config 导航栏配置
     * @return string 渲染后的HTML
     */
    public static function render($config = []) {
        $navbar = new self($config);
        return $navbar-\u003erender();
    }
    
    /**
     * 添加菜单项
     * @param array $item 菜单项配置
     * @return self 实例自身，支持链式调用
     */
    public function addMenuItem($item) {
        $this-\u003econfig['menu_items'][] = $item;
        return $this;
    }
    
    /**
     * 设置菜单
     * @param array $menuItems 菜单项数组
     * @return self 实例自身，支持链式调用
     */
    public function setMenuItems($menuItems) {
        $this-\u003econfig['menu_items'] = $menuItems;
        return $this;
    }
    
    /**
     * 设置品牌信息
     * @param array $brand 品牌配置
     * @return self 实例自身，支持链式调用
     */
    public function setBrand($brand) {
        $this-\u003econfig['brand'] = array_merge($this-\u003econfig['brand'], $brand);
        return $this;
    }
    
    /**
     * 获取当前配置
     * @return array 配置数组
     */
    public function getConfig() {
        return $this-\u003econfig;
    }
}