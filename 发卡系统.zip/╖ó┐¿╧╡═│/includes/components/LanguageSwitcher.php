\u003c?php
/**
 * 语言切换器组件
 * 提供用户界面语言切换功能，支持多语言环境
 */

class LanguageSwitcher {
    /**
     * 支持的语言列表
     * @var array
     */
    private $languages = [
        'zh_CN' =\u003e ['name' =\u003e '中文', 'flag' =\u003e '🇨🇳'],
        'en_US' =\u003e ['name' =\u003e 'English', 'flag' =\u003e '🇺🇸']
    ];
    
    /**
     * 当前选中的语言
     * @var string
     */
    private $currentLanguage;
    
    /**
     * 组件配置
     * @var array
     */
    private $config = [
        'class' =\u003e '',
        'id' =\u003e '',
        'showFlags' =\u003e true,
        'showNames' =\u003e true,
        'position' =\u003e 'top-right', // top-right, top-left, bottom-right, bottom-left, inline
        'mobileOptimized' =\u003e true,
        'useCookies' =\u003e true,
        'cookieName' =\u003e 'user_language',
        'cookieExpiry' =\u003e 30, // 30 days
        'dropdownAnimation' =\u003e true,
        'rememberUserChoice' =\u003e true
    ];
    
    /**
     * 设备类型
     * @var string
     */
    private $deviceType;
    
    /**
     * 构造函数
     * @param array $config 组件配置
     * @param array $languages 自定义语言列表
     */
    public function __construct($config = [], $languages = []) {
        // 合并配置
        $this-\u003econfig = array_merge($this-\u003econfig, $config);
        
        // 合并自定义语言
        if (!empty($languages)) {
            $this-\u003elanguages = array_merge($this-\u003elanguages, $languages);
        }
        
        // 检测设备类型
        $this-\u003edeviceType = $this-\u003edetectDeviceType();
        
        // 初始化当前语言
        $this-\u003einitCurrentLanguage();
    }
    
    /**
     * 检测设备类型
     * @return string 设备类型: mobile, tablet, desktop
     */
    private function detectDeviceType() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        if (preg_match('/(android|iphone|ipad|ipod|blackberry|iemobile|opera mini)/i', $userAgent)) {
            return 'mobile';
        }
        
        return 'desktop';
    }
    
    /**
     * 初始化当前语言
     */
    private function initCurrentLanguage() {
        // 优先级: GET参数 -\u003e Cookie -\u003e 浏览器语言 -\u003e 默认语言
        
        // 1. 检查URL中的语言参数
        if (isset($_GET['lang']) \u0026\u0026 array_key_exists($_GET['lang'], $this-\u003elanguages)) {
            $this-\u003ecurrentLanguage = $_GET['lang'];
            
            // 如果启用了Cookie，保存用户选择
            if ($this-\u003econfig['useCookies'] \u0026\u0026 $this-\u003econfig['rememberUserChoice']) {
                $this-\u003esetLanguageCookie($this-\u003ecurrentLanguage);
            }
            
            return;
        }
        
        // 2. 检查Cookie中的语言设置
        if ($this-\u003econfig['useCookies'] \u0026\u0026 isset($_COOKIE[$this-\u003econfig['cookieName']]) \u0026\u0026 
            array_key_exists($_COOKIE[$this-\u003econfig['cookieName']], $this-\u003elanguages)) {
            $this-\u003ecurrentLanguage = $_COOKIE[$this-\u003econfig['cookieName']];
            return;
        }
        
        // 3. 检测浏览器语言
        $browserLang = $this-\u003edetectBrowserLanguage();
        if ($browserLang \u0026\u0026 array_key_exists($browserLang, $this-\u003elanguages)) {
            $this-\u003ecurrentLanguage = $browserLang;
            return;
        }
        
        // 4. 默认使用中文
        $this-\u003ecurrentLanguage = 'zh_CN';
    }
    
    /**
     * 检测浏览器语言
     * @return string|null 语言代码或null
     */
    private function detectBrowserLanguage() {
        $httpAcceptLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
        
        if (empty($httpAcceptLanguage)) {
            return null;
        }
        
        // 解析 Accept-Language 头
        $languages = [];
        preg_match_all('/([a-z]{1,8}(-[a-z]{1,8})?)\s*(;\s*q\s*=\s*(1|0\.[0-9]+))?/i', $httpAcceptLanguage, $langMatches);
        
        if (!empty($langMatches[1])) {
            // 处理语言优先级
            foreach ($langMatches[1] as $index =\u003e $langCode) {
                $quality = !empty($langMatches[4][$index]) ? (float)$langMatches[4][$index] : 1.0;
                $languages[$langCode] = $quality;
            }
            
            // 按优先级排序
            arsort($languages);
            
            // 尝试匹配支持的语言
            foreach ($languages as $langCode =\u003e $quality) {
                // 标准化语言代码格式
                $langCode = str_replace('-', '_', strtolower($langCode));
                
                // 检查精确匹配
                if (array_key_exists($langCode, $this-\u003elanguages)) {
                    return $langCode;
                }
                
                // 检查主要语言匹配（例如 en 匹配 en_US）
                $langParts = explode('_', $langCode);
                if (count($langParts) \u003e 0) {
                    foreach ($this-\u003elanguages as $supportedLang =\u003e $info) {
                        $supportedParts = explode('_', $supportedLang);
                        if ($supportedParts[0] === $langParts[0]) {
                            return $supportedLang;
                        }
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * 设置语言Cookie
     * @param string $language 语言代码
     */
    private function setLanguageCookie($language) {
        $expiry = time() + ($this-\u003econfig['cookieExpiry'] * 24 * 60 * 60);
        setcookie(
            $this-\u003econfig['cookieName'],
            $language,
            $expiry,
            '/', // 全站有效
            '', // 域名
            isset($_SERVER['HTTPS']) \u0026\u0026 $_SERVER['HTTPS'] === 'on',
            true // HttpOnly
        );
    }
    
    /**
     * 获取当前页面的URL（保留查询参数但替换语言参数）
     * @param string $language 目标语言
     * @return string 带语言参数的URL
     */
    private function getUrlWithLanguage($language) {
        $protocol = isset($_SERVER['HTTPS']) \u0026\u0026 $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $path = $_SERVER['REQUEST_URI'] ?? '/';
        
        // 解析URL
        $urlParts = parse_url($path);
        $queryString = isset($urlParts['query']) ? $urlParts['query'] : '';
        parse_str($queryString, $queryParams);
        
        // 设置或替换语言参数
        $queryParams['lang'] = $language;
        
        // 重建查询字符串
        $newQueryString = http_build_query($queryParams);
        $newPath = $urlParts['path'] ?? '/';
        
        if (!empty($newQueryString)) {
            $newPath .= '?' . $newQueryString;
        }
        
        return $protocol . '://' . $host . $newPath;
    }
    
    /**
     * 获取组件的CSS样式
     * @return string CSS样式代码
     */
    public static function getCSS() {
        return "
\u003cstyle\u003e
/* 语言切换器基础样式 */
.language-switcher {
    position: relative;
    display: inline-block;
    z-index: 9999;
}

/* 语言切换按钮 */
.language-switcher .current-language {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s ease;
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -webkit-tap-highlight-color: transparent;
}

.language-switcher .current-language:hover {
    background-color: #f5f5f5;
    border-color: #d0d0d0;
}

/* 语言下拉菜单 */
.language-switcher .language-dropdown {
    position: absolute;
    top: 100%;
    right: 0;
    min-width: 120px;
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    margin-top: 4px;
    display: none;
    overflow: hidden;
}

.language-switcher.open .language-dropdown {
    display: block;
}

/* 语言选项列表 */
.language-switcher .language-list {
    list-style: none;
    margin: 0;
    padding: 0;
}

/* 语言选项 */
.language-switcher .language-item {
    padding: 0;
}

.language-switcher .language-item a {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    color: #333333;
    text-decoration: none;
    transition: background-color 0.2s ease;
    font-size: 14px;
}

.language-switcher .language-item a:hover,
.language-switcher .language-item.active a {
    background-color: #f0f0f0;
}

.language-switcher .language-item.active a {
    font-weight: 600;
    color: #007bff;
}

/* 标志和名称样式 */
.language-switcher .flag {
    font-size: 16px;
    margin-right: 8px;
    display: inline-block;
}

/* 位置样式 */
.language-switcher.top-right {
    position: fixed;
    top: 20px;
    right: 20px;
}

.language-switcher.top-left {
    position: fixed;
    top: 20px;
    left: 20px;
}

.language-switcher.bottom-right {
    position: fixed;
    bottom: 20px;
    right: 20px;
}

.language-switcher.bottom-left {
    position: fixed;
    bottom: 20px;
    left: 20px;
}

.language-switcher.inline {
    position: relative;
    top: auto;
    right: auto;
    bottom: auto;
    left: auto;
    display: inline-block;
}

/* 箭头指示器 */
.language-switcher .arrow {
    margin-left: 8px;
    transition: transform 0.3s ease;
    font-size: 12px;
}

.language-switcher.open .arrow {
    transform: rotate(180deg);
}

/* 响应式样式 */
@media (max-width: 767px) {
    .language-switcher.top-right,
    .language-switcher.top-left {
        top: 10px;
    }
    
    .language-switcher.bottom-right,
    .language-switcher.bottom-left {
        bottom: 10px;
    }
    
    .language-switcher.top-right,
    .language-switcher.bottom-right {
        right: 10px;
    }
    
    .language-switcher.top-left,
    .language-switcher.bottom-left {
        left: 10px;
    }
    
    .language-switcher .current-language {
        padding: 6px 10px;
        font-size: 13px;
    }
    
    .language-switcher .language-item a {
        padding: 6px 10px;
        font-size: 13px;
    }
    
    .language-switcher .flag {
        font-size: 14px;
        margin-right: 6px;
    }
    
    /* 移动端触摸反馈 */
    .language-switcher .current-language,
    .language-switcher .language-item a {
        -webkit-tap-highlight-color: transparent;
        touch-action: manipulation;
    }
}

/* 下拉动画 */
.language-switcher.animation .language-dropdown {
    opacity: 0;
    transform: translateY(-10px);
    transition: opacity 0.3s ease, transform 0.3s ease;
    display: block;
    pointer-events: none;
}

.language-switcher.animation.open .language-dropdown {
    opacity: 1;
    transform: translateY(0);
    pointer-events: auto;
}

/* 无标志模式 */
.language-switcher.no-flags .flag {
    display: none;
}

/* 无名称模式 */
.language-switcher.no-names .language-name {
    display: none;
}

/* 紧凑模式 */
.language-switcher.compact .current-language,
.language-switcher.compact .language-item a {
    padding: 4px 8px;
}

/* 深色主题支持 */
@media (prefers-color-scheme: dark) {
    .language-switcher .current-language {
        background-color: #2d2d2d;
        border-color: #404040;
        color: #ffffff;
    }
    
    .language-switcher .current-language:hover {
        background-color: #3a3a3a;
        border-color: #505050;
    }
    
    .language-switcher .language-dropdown {
        background-color: #2d2d2d;
        border-color: #404040;
    }
    
    .language-switcher .language-item a {
        color: #e0e0e0;
    }
    
    .language-switcher .language-item a:hover,
    .language-switcher .language-item.active a {
        background-color: #3a3a3a;
    }
}

/* 高对比度模式支持 */
@media (prefers-contrast: high) {
    .language-switcher .current-language {
        border-width: 2px;
    }
    
    .language-switcher .language-dropdown {
        border-width: 2px;
    }
}
\u003c/style\u003e";
    }
    
    /**
     * 获取组件的JavaScript代码
     * @return string JavaScript代码
     */
    public function getJavaScript() {
        $switcherId = $this-\u003econfig['id'] ?: 'language-switcher-' . uniqid();
        
        return "
\u003cscript\u003e
// 语言切换器初始化
(function() {
    const switcher = document.getElementById('{$switcherId}');
    const currentLang = switcher.querySelector('.current-language');
    const dropdown = switcher.querySelector('.language-dropdown');
    
    if (!switcher || !currentLang || !dropdown) return;
    
    // 切换下拉菜单
    currentLang.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        switcher.classList.toggle('open');
    });
    
    // 点击语言选项
    const langOptions = switcher.querySelectorAll('.language-item a');
    langOptions.forEach(option =\u003e {
        option.addEventListener('click', function(e) {
            // 允许默认行为（页面跳转）
            // 不需要阻止事件传播，因为已经在选项上处理了
        });
    });
    
    // 点击页面其他地方关闭下拉菜单
    document.addEventListener('click', function() {
        if (switcher.classList.contains('open')) {
            switcher.classList.remove('open');
        }
    });
    
    // 阻止下拉菜单内部点击事件冒泡
    dropdown.addEventListener('click', function(e) {
        e.stopPropagation();
    });
    
    // 移动端触摸事件优化
    if ('ontouchstart' in window) {
        // 触摸反馈
        currentLang.addEventListener('touchstart', function() {
            this.classList.add('touching');
        }, { passive: true });
        
        currentLang.addEventListener('touchend', function() {
            this.classList.remove('touching');
        }, { passive: true });
        
        // 语言选项触摸反馈
        langOptions.forEach(option =\u003e {
            option.addEventListener('touchstart', function() {
                this.classList.add('touching');
            }, { passive: true });
            
            option.addEventListener('touchend', function() {
                this.classList.remove('touching');
            }, { passive: true });
        });
    }
})();
\u003c/script\u003e";
    }
    
    /**
     * 渲染语言切换器组件
     * @return string 完整的组件HTML
     */
    public function render() {
        // 生成唯一ID
        if (empty($this-\u003econfig['id'])) {
            $this-\u003econfig['id'] = 'language-switcher-' . uniqid();
        }
        
        // 构建类名
        $classes = ['language-switcher', $this-\u003econfig['position']];
        
        if (!empty($this-\u003econfig['class'])) {
            $classes[] = $this-\u003econfig['class'];
        }
        
        if ($this-\u003econfig['dropdownAnimation']) {
            $classes[] = 'animation';
        }
        
        if (!$this-\u003econfig['showFlags']) {
            $classes[] = 'no-flags';
        }
        
        if (!$this-\u003econfig['showNames']) {
            $classes[] = 'no-names';
        }
        
        if ($this-\u003econfig['mobileOptimized'] \u0026\u0026 $this-\u003edeviceType === 'mobile') {
            $classes[] = 'mobile-optimized';
        }
        
        $classString = implode(' ', $classes);
        
        // 开始构建HTML
        $html = [];
        $html[] = "\u003cdiv id='{$this-\u003econfig['id']}' class='{$classString}'\u003e";
        
        // 当前语言按钮
        $html[] = "    \u003ca href='#' class='current-language' title='" . __('Change language') . "'\u003e";
        
        // 当前语言显示内容
        if ($this-\u003econfig['showFlags'] \u0026\u0026 isset($this-\u003elanguages[$this-\u003ecurrentLanguage]['flag'])) {
            $html[] = "        \u003cspan class='flag'\u003e{$this-\u003elanguages[$this-\u003ecurrentLanguage]['flag']}\u003c/span\u003e";
        }
        
        if ($this-\u003econfig['showNames'] \u0026\u0026 isset($this-\u003elanguages[$this-\u003ecurrentLanguage]['name'])) {
            $html[] = "        \u003cspan class='language-name'\u003e{$this-\u003elanguages[$this-\u003ecurrentLanguage]['name']}\u003c/span\u003e";
        }
        
        $html[] = "        \u003cspan class='arrow' aria-hidden='true'\u003e▼\u003c/span\u003e";
        $html[] = "    \u003c/a\u003e";
        
        // 语言下拉菜单
        $html[] = "    \u003cdiv class='language-dropdown'\u003e";
        $html[] = "        \u003cul class='language-list'\u003e";
        
        // 生成语言选项
        foreach ($this-\u003elanguages as $langCode =\u003e $langInfo) {
            $isActive = $langCode === $this-\u003ecurrentLanguage;
            $activeClass = $isActive ? 'active' : '';
            $url = $this-\u003 egetUrlWithLanguage($langCode);
            
            $html[] = "            \u003cli class='language-item {$activeClass}'\u003e";
            $html[] = "                \u003ca href='{$url}' title='{$langInfo['name']}'\u003e";
            
            if ($this-\u003econfig['showFlags'] \u0026\u0026 isset($langInfo['flag'])) {
                $html[] = "                    \u003cspan class='flag'\u003e{$langInfo['flag']}\u003c/span\u003e";
            }
            
            if ($this-\u003econfig['showNames'] \u0026\u0026 isset($langInfo['name'])) {
                $html[] = "                    \u003cspan class='language-name'\u003e{$langInfo['name']}\u003c/span\u003e";
            }
            
            $html[] = "                \u003c/a\u003e";
            $html[] = "            \u003c/li\u003e";
        }
        
        $html[] = "        \u003c/ul\u003e";
        $html[] = "    \u003c/div\u003e";
        $html[] = "\u003c/div\u003e";
        
        // 添加JavaScript初始化代码
        $html[] = $this-\u003 egetJavaScript();
        
        return implode("\n", $html);
    }
    
    /**
     * 静态工厂方法，快速创建语言切换器
     * @param array $config 配置参数
     * @param array $languages 语言列表
     * @return string 渲染后的组件HTML
     */
    public static function create($config = [], $languages = []) {
        $switcher = new self($config, $languages);
        return $switcher-\u003erender();
    }
    
    /**
     * 获取当前语言代码
     * @return string 当前语言代码
     */
    public function getCurrentLanguage() {
        return $this-\u003ecurrentLanguage;
    }
    
    /**
     * 设置支持的语言列表
     * @param array $languages 语言列表
     */
    public function setLanguages($languages) {
        $this-\u003elanguages = array_merge($this-\u003elanguages, $languages);
    }
    
    /**
     * 添加新的语言支持
     * @param string $code 语言代码
     * @param string $name 语言名称
     * @param string $flag 语言标志
     */
    public function addLanguage($code, $name, $flag = '') {
        $this-\u003elanguages[$code] = ['name' =\u003e $name, 'flag' =\u003e $flag];
    }
}