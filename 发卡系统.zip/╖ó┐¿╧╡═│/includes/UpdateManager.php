<?php
/**
 * 更新管理器
 * 处理系统更新、版本管理、补丁下载等功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/CacheManager.php';
require_once __DIR__ . '/LogManager.php';

class UpdateManager extends BaseService {
    private $cacheManager;
    private $logManager;
    private $updateDir;
    private $backupDir;
    private $updateServer = 'https://updates.card-system.com/api';
    private $cachePrefix = 'update_';
    
    public function __construct($database = null, $logger = null) {
        parent::__construct();
        $this->cacheManager = CacheManager::getInstance();
        $this->logManager = new LogManager($database, $logger);
        $this->updateDir = __DIR__ . '/../updates/';
        $this->backupDir = __DIR__ . '/../backups/';
        
        // 确保目录存在
        if (!is_dir($this->updateDir)) {
            mkdir($this->updateDir, 0755, true);
        }
        if (!is_dir($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }
    }
    
    /**
     * 检查更新
     */
    public function checkForUpdates() {
        try {
            $currentVersion = $this->getCurrentVersion();
            $updateInfo = $this->fetchUpdateInfo();
            
            if (!$updateInfo['success']) {
                return $updateInfo;
            }
            
            $updates = array();
            foreach ($updateInfo['updates'] as $update) {
                if (version_compare($update['version'], $currentVersion, '>')) {
                    array_push($updates, $update);
                }
            }
            
            // 按版本号排序
            usort($updates, function($a, $b) {
                return version_compare($a['version'], $b['version']);
            });
            
            return array(
                'success' => true,
                'current_version' => $currentVersion,
                'has_updates' => !empty($updates),
                'updates' => $updates,
                'last_check' => date('Y-m-d H:i:s')
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("检查更新失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 下载更新
     */
    public function downloadUpdate($version) {
        try {
            // 验证版本
            $updateInfo = $this->getUpdateInfo($version);
            if (!$updateInfo['success']) {
                return $updateInfo;
            }
            
            $update = $updateInfo['update'];
            
            // 检查是否已下载
            $downloadPath = $this->updateDir . "update_{$version}.zip";
            if (file_exists($downloadPath)) {
                return array('success' => true, 'message' => '更新包已存在', 'path' => $downloadPath);
            }
            
            // 下载更新包
            $downloadResult = $this->downloadFile($update['download_url'], $downloadPath);
            if (!$downloadResult['success']) {
                return $downloadResult;
            }
            
            // 验证文件完整性
            if (!$this->verifyFileIntegrity($downloadPath, $update['checksum'])) {
                unlink($downloadPath);
                return array('success' => false, 'message' => '更新包校验失败');
            }
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'download_update',
                'update',
                array('version' => $version, 'path' => $downloadPath)
            );
            
            return array(
                'success' => true,
                'message' => '更新包下载成功',
                'path' => $downloadPath,
                'size' => filesize($downloadPath)
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("下载更新失败", array('version' => $version, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 安装更新
     */
    public function installUpdate($version, $options = array()) {
        try {
            $downloadPath = $this->updateDir . "update_{$version}.zip";
            
            if (!file_exists($downloadPath)) {
                return array('success' => false, 'message' => '更新包不存在，请先下载');
            }
            
            // 创建备份
            $backupResult = $this->createBackup($version);
            if (!$backupResult['success']) {
                return $backupResult;
            }
            
            // 验证更新信息
            $updateInfo = $this->getUpdateInfo($version);
            if (!$updateInfo['success']) {
                return $updateInfo;
            }
            
            $update = $updateInfo['update'];
            
            // 检查系统要求
            if (!$this->checkSystemRequirements($update['requirements'])) {
                return array('success' => false, 'message' => '系统不满足更新要求');
            }
            
            // 解压更新包
            $extractPath = $this->updateDir . "extract_{$version}/";
            $extractResult = $this->extractUpdate($downloadPath, $extractPath);
            if (!$extractResult['success']) {
                return $extractResult;
            }
            
            // 执行更新脚本
            if (isset($update['install_script'])) {
                $scriptResult = $this->executeInstallScript($extractPath . $update['install_script']);
                if (!$scriptResult['success']) {
                    $this->cleanupExtract($extractPath);
                    return $scriptResult;
                }
            }
            
            // 复制文件
            $copyResult = $this->copyUpdateFiles($extractPath);
            if (!$copyResult['success']) {
                $this->cleanupExtract($extractPath);
                return $copyResult;
            }
            
            // 更新版本信息
            $this->updateVersionInfo($version);
            
            // 清理临时文件
            $this->cleanupExtract($extractPath);
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'install_update',
                'update',
                array('version' => $version, 'backup' => $backupResult['backup_name'])
            );
            
            return array(
                'success' => true,
                'message' => '更新安装成功',
                'version' => $version,
                'backup' => $backupResult['backup_name']
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("安装更新失败", array('version' => $version, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 回滚更新
     */
    public function rollbackUpdate($backupName) {
        try {
            $backupPath = $this->backupDir . $backupName;
            
            if (!file_exists($backupPath)) {
                return array('success' => false, 'message' => '备份文件不存在');
            }
            
            // 解压备份文件
            $extractPath = $this->backupDir . "rollback_" . time() . "/";
            $extractResult = $this->extractUpdate($backupPath, $extractPath);
            if (!$extractResult['success']) {
                return $extractResult;
            }
            
            // 恢复文件
            $restoreResult = $this->restoreBackup($extractPath);
            if (!$restoreResult['success']) {
                $this->cleanupExtract($extractPath);
                return $restoreResult;
            }
            
            // 清理临时文件
            $this->cleanupExtract($extractPath);
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'rollback_update',
                'update',
                array('backup_name' => $backupName)
            );
            
            return array('success' => true, 'message' => '回滚成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("回滚更新失败", array('backup_name' => $backupName, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取更新历史
     */
    public function getUpdateHistory($page = 1, $limit = 20) {
        try {
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT * FROM update_history ORDER BY installed_at DESC LIMIT ? OFFSET ?";
            $updates = $this->database->fetchAll($sql, array($limit, $offset));
            
            $countSql = "SELECT COUNT(*) as total FROM update_history";
            $totalResult = $this->database->fetch($countSql);
            $total = $totalResult['total'];
            
            return array(
                'success' => true,
                'updates' => $updates,
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("获取更新历史失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取当前版本
     */
    private function getCurrentVersion() {
        $configFile = __DIR__ . '/../config/app.php';
        if (file_exists($configFile)) {
            $config = include $configFile;
            return isset($config['version']) ? $config['version'] : '1.0.0';
        }
        return '1.0.0';
    }
    
    /**
     * 获取更新信息
     */
    private function fetchUpdateInfo() {
        try {
            $cacheKey = $this->cachePrefix . 'info';
            $cached = $this->cacheManager->get($cacheKey);
            
            if ($cached !== false) {
                return array('success' => true, 'updates' => $cached);
            }
            
            // 这里应该从更新服务器获取信息
            // 模拟返回数据
            $updates = array(
                array(
                    'version' => '1.1.0',
                    'release_date' => '2024-01-15',
                    'description' => '新增批量导入导出功能',
                    'download_url' => $this->updateServer . '/download/v1.1.0',
                    'checksum' => 'abc123...',
                    'requirements' => array(
                        'php' => '>=7.4',
                        'mysql' => '>=5.7'
                    ),
                    'install_script' => 'install.php'
                ),
                array(
                    'version' => '1.2.0',
                    'release_date' => '2024-02-01',
                    'description' => '优化性能，修复已知问题',
                    'download_url' => $this->updateServer . '/download/v1.2.0',
                    'checksum' => 'def456...',
                    'requirements' => array(
                        'php' => '>=7.4',
                        'mysql' => '>=5.7'
                    )
                )
            );
            
            $this->cacheManager->set($cacheKey, $updates, 3600);
            
            return array('success' => true, 'updates' => $updates);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取特定版本信息
     */
    private function getUpdateInfo($version) {
        $updateInfo = $this->fetchUpdateInfo();
        if (!$updateInfo['success']) {
            return $updateInfo;
        }
        
        foreach ($updateInfo['updates'] as $update) {
            if ($update['version'] === $version) {
                return array('success' => true, 'update' => $update);
            }
        }
        
        return array('success' => false, 'message' => '版本不存在');
    }
    
    /**
     * 下载文件
     */
    private function downloadFile($url, $path) {
        try {
            $context = stream_context_create(array(
                'http' => array(
                    'timeout' => 30,
                    'user_agent' => 'CardSystem-Updater/1.0'
                )
            ));
            
            $content = file_get_contents($url, false, $context);
            if ($content === false) {
                return array('success' => false, 'message' => '下载失败');
            }
            
            if (file_put_contents($path, $content) === false) {
                return array('success' => false, 'message' => '保存文件失败');
            }
            
            return array('success' => true);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 验证文件完整性
     */
    private function verifyFileIntegrity($filePath, $expectedChecksum) {
        $actualChecksum = md5_file($filePath);
        return $actualChecksum === $expectedChecksum;
    }
    
    /**
     * 创建备份
     */
    private function createBackup($version) {
        try {
            $backupName = "backup_before_v{$version}_" . date('Y-m-d_H-i-s') . '.zip';
            $backupPath = $this->backupDir . $backupName;
            
            // 这里应该实现完整的备份逻辑
            // 包括数据库、配置文件、上传文件等
            
            return array(
                'success' => true,
                'backup_name' => $backupName,
                'path' => $backupPath
            );
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 检查系统要求
     */
    private function checkSystemRequirements($requirements) {
        if (isset($requirements['php'])) {
            if (!version_compare(PHP_VERSION, $requirements['php'], '>=')) {
                return false;
            }
        }
        
        if (isset($requirements['mysql'])) {
            try {
                $result = $this->database->fetch("SELECT VERSION() as version");
                $mysqlVersion = $result['version'];
                if (!version_compare($mysqlVersion, $requirements['mysql'], '>=')) {
                    return false;
                }
            } catch (Exception $e) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 解压更新包
     */
    private function extractUpdate($zipPath, $extractPath) {
        try {
            if (!class_exists('ZipArchive')) {
                return array('success' => false, 'message' => 'ZipArchive扩展未安装');
            }
            
            $zip = new ZipArchive();
            if ($zip->open($zipPath) !== true) {
                return array('success' => false, 'message' => '无法打开更新包');
            }
            
            if (!is_dir($extractPath)) {
                mkdir($extractPath, 0755, true);
            }
            
            if (!$zip->extractTo($extractPath)) {
                $zip->close();
                return array('success' => false, 'message' => '解压失败');
            }
            
            $zip->close();
            return array('success' => true);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 执行安装脚本
     */
    private function executeInstallScript($scriptPath) {
        try {
            if (!file_exists($scriptPath)) {
                return array('success' => false, 'message' => '安装脚本不存在');
            }
            
            // 在安全的环境中执行脚本
            include $scriptPath;
            
            return array('success' => true);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 复制更新文件
     */
    private function copyUpdateFiles($extractPath) {
        try {
            $rootPath = __DIR__ . '/../';
            
            // 递归复制文件
            $this->copyDirectory($extractPath, $rootPath);
            
            return array('success' => true);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 更新版本信息
     */
    private function updateVersionInfo($version) {
        try {
            $configFile = __DIR__ . '/../config/app.php';
            $config = array();
            
            if (file_exists($configFile)) {
                $config = include $configFile;
            }
            
            $config['version'] = $version;
            $config['last_updated'] = date('Y-m-d H:i:s');
            
            $content = "<?php\nreturn " . var_export($config, true) . ";\n";
            file_put_contents($configFile, $content);
            
            // 记录更新历史
            $this->database->insert('update_history', array(
                'version' => $version,
                'installed_at' => date('Y-m-d H:i:s'),
                'installed_by' => $this->getCurrentUserId()
            ));
            
        } catch (Exception $e) {
            throw $e;
        }
    }
    
    /**
     * 恢复备份
     */
    private function restoreBackup($backupPath) {
        try {
            $rootPath = __DIR__ . '/../';
            
            // 递归复制备份文件
            $this->copyDirectory($backupPath, $rootPath);
            
            return array('success' => true);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 复制目录
     */
    private function copyDirectory($source, $destination) {
        if (!is_dir($destination)) {
            mkdir($destination, 0755, true);
        }
        
        $files = scandir($source);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            
            $sourcePath = $source . '/' . $file;
            $destPath = $destination . '/' . $file;
            
            if (is_dir($sourcePath)) {
                $this->copyDirectory($sourcePath, $destPath);
            } else {
                copy($sourcePath, $destPath);
            }
        }
    }
    
    /**
     * 清理解压目录
     */
    private function cleanupExtract($extractPath) {
        if (is_dir($extractPath)) {
            $this->removeDirectory($extractPath);
        }
    }
    
    /**
     * 删除目录
     */
    private function removeDirectory($dir) {
        if (is_dir($dir)) {
            $files = array_diff(scandir($dir), array('.', '..'));
            foreach ($files as $file) {
                $path = $dir . '/' . $file;
                is_dir($path) ? $this->removeDirectory($path) : unlink($path);
            }
            return rmdir($dir);
        }
        return false;
    }
    
    /**
     * 获取当前用户ID
     */
    private function getCurrentUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}