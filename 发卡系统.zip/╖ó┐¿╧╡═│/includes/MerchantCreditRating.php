<?php
/**
 * 商户信用评级管理系统
 * 基于商户历史履约率、纠纷率等数据动态调整权限（上架限额、提现速度等）
 */

class MerchantCreditRating {
    private $database;
    private $auditLogger;
    private $config;
    
    /**
     * 信用等级配置
     */
    private $creditLevels = array(
        'excellent' => array('min_score' => 90, 'name' => '优秀', 'color' => '#00a65a'),
        'good' => array('min_score' => 80, 'name' => '良好', 'color' => '#00c0ef'),
        'standard' => array('min_score' => 70, 'name' => '标准', 'color' => '#f39c12'),
        'warning' => array('min_score' => 60, 'name' => '警告', 'color' => '#e74c3c'),
        'poor' => array('min_score' => 0, 'name' => '较差', 'color' => '#c0392b')
    );
    
    /**
     * 评分权重配置
     */
    private $scoreWeights = array(
        'fulfillment_rate' => 0.3,      // 履约率权重
        'dispute_rate' => 0.25,           // 纠纷率权重
        'response_time' => 0.15,           // 响应时间权重
        'compliance_score' => 0.2,        // 合规评分权重
        'transaction_volume' => 0.1       // 交易量权重
    );
    
    /**
     * 构造函数
     * @param Database $database 数据库实例
     * @param AuditLogger $auditLogger 审计日志实例
     */
    public function __construct($database, $auditLogger = null) {
        $this->database = $database;
        $this->auditLogger = $auditLogger;
        $this->config = $this->loadConfig();
    }
    
    /**
     * 加载配置
     */
    private function loadConfig() {
        return array(
            'review_period_days' => 90,     // 评估周期（天）
            'min_transactions_for_rating' => 10,  // 评分所需最小交易数
            'auto_update_schedule' => 'daily',  // 自动更新频率
            'permission_impact' => array(
                'excellent' => array(
                    'max_listings' => 1000,    // 最大上架数量
                    'withdrawal_limit' => 50000, // 单次提现限额
                    'withdrawal_speed' => 'immediate', // 提现速度
                    'priority_support' => true  // 是否享受优先支持
                ),
                'good' => array(
                    'max_listings' => 500,
                    'withdrawal_limit' => 30000,
                    'withdrawal_speed' => 'same_day',
                    'priority_support' => true
                ),
                'standard' => array(
                    'max_listings' => 200,
                    'withdrawal_limit' => 10000,
                    'withdrawal_speed' => 'next_day',
                    'priority_support' => false
                ),
                'warning' => array(
                    'max_listings' => 50,
                    'withdrawal_limit' => 5000,
                    'withdrawal_speed' => 'next_day',
                    'priority_support' => false
                ),
                'poor' => array(
                    'max_listings' => 10,
                    'withdrawal_limit' => 1000,
                    'withdrawal_speed' => '3_day_delay',
                    'priority_support' => false
                )
            )
        );
    }
    
    /**
     * 初始化商户信用评分
     * @param int $merchantId 商户ID
     * @return bool 初始化是否成功
     */
    public function initializeMerchantRating($merchantId) {
        // 检查商户是否已存在评分记录
        $existingRating = $this->database->fetch(
            "SELECT id FROM merchant_credit_ratings WHERE merchant_id = ?",
            array($merchantId)
        );
        
        if ($existingRating) {
            return false; // 已存在记录
        }
        
        // 获取商户信息
        $merchant = $this->database->fetch(
            "SELECT username FROM users WHERE id = ? AND role = 'merchant'",
            array($merchantId)
        );
        
        if (!$merchant) {
            throw new Exception("Invalid merchant ID");
        }
        
        // 初始化为标准信用等级
        $initialData = array(
            'merchant_id' => $merchantId,
            'credit_score' => 75, // 初始分数
            'credit_level' => 'standard',
            'fulfillment_rate' => 100, // 初始履约率
            'dispute_rate' => 0,       // 初始纠纷率
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        // 插入初始评分
        $ratingId = $this->database->insert('merchant_credit_ratings', $initialData);
        
        // 记录审计日志
        if ($this->auditLogger) {
            $this->auditLogger->log(
                0, // 系统操作
                'initialize_merchant_rating',
                '商户信用评级初始化',
                array(
                    'merchant_id' => $merchantId,
                    'merchant_name' => $merchant['username'],
                    'initial_score' => 75,
                    'initial_level' => 'standard'
                ),
                'info'
            );
        }
        
        return (bool) $ratingId;
    }
    
    /**
     * 计算商户信用评分
     * @param int $merchantId 商户ID
     * @return array 评分结果
     */
    public function calculateCreditScore($merchantId) {
        // 获取评估周期内的交易数据
        $periodStart = date('Y-m-d', strtotime("-" . $this->config['review_period_days'] . " days"));
        
        // 获取交易总数
        $totalTransactions = $this->database->fetch(
            "SELECT COUNT(*) as count FROM orders 
             WHERE merchant_id = ? AND created_at >= ?",
            array($merchantId, $periodStart)
        );
        
        // 如果交易数量不足以评分，返回现有评分
        if ($totalTransactions['count'] < $this->config['min_transactions_for_rating']) {
            $currentRating = $this->getMerchantRating($merchantId);
            if (!$currentRating) {
                $this->initializeMerchantRating($merchantId);
                $currentRating = $this->getMerchantRating($merchantId);
            }
            return $currentRating;
        }
        
        // 计算履约率（成功完成的订单比例）
        $fulfilledOrders = $this->database->fetch(
            "SELECT COUNT(*) as count FROM orders 
             WHERE merchant_id = ? AND created_at >= ? 
             AND status = 'completed'",
            array($merchantId, $periodStart)
        );
        
        $fulfillmentRate = ($fulfilledOrders['count'] / $totalTransactions['count']) * 100;
        
        // 计算纠纷率（有纠纷的订单比例）
        $disputedOrders = $this->database->fetch(
            "SELECT COUNT(DISTINCT order_id) as count FROM disputes 
             WHERE merchant_id = ? AND created_at >= ?",
            array($merchantId, $periodStart)
        );
        
        $disputeRate = ($disputedOrders['count'] / $totalTransactions['count']) * 100;
        
        // 计算平均响应时间（小时）
        $avgResponseTime = $this->database->fetch(
            "SELECT AVG(HOUR(TIMEDIFF(response_at, created_at))) as avg_hours 
             FROM merchant_messages 
             WHERE merchant_id = ? AND created_at >= ? 
             AND response_at IS NOT NULL",
            array($merchantId, $periodStart)
        );
        
        // 转换响应时间为评分（越短越好）
        $responseTimeScore = 100;
        if ($avgResponseTime['avg_hours']) {
            // 假设24小时内最佳，超过72小时最差
            $responseHours = min($avgResponseTime['avg_hours'], 72);
            $responseTimeScore = 100 - (($responseHours / 72) * 90); // 最差情况得10分
        }
        
        // 计算合规评分（基于违规记录）
        $violationCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM merchant_violations 
             WHERE merchant_id = ? AND created_at >= ?",
            array($merchantId, $periodStart)
        );
        
        // 违规次数越多，评分越低
        $complianceScore = max(100 - ($violationCount['count'] * 15), 0);
        
        // 交易量评分（基于交易数量变化趋势）
        $prevPeriodStart = date('Y-m-d', strtotime("-" . ($this->config['review_period_days'] * 2) . " days"));
        
        $prevPeriodTransactions = $this->database->fetch(
            "SELECT COUNT(*) as count FROM orders 
             WHERE merchant_id = ? AND created_at >= ? AND created_at < ?",
            array($merchantId, $prevPeriodStart, $periodStart)
        );
        
        // 计算交易量增长率
        $growthRate = 0;
        if ($prevPeriodTransactions['count'] > 0) {
            $growthRate = (($totalTransactions['count'] - $prevPeriodTransactions['count']) / $prevPeriodTransactions['count']) * 100;
        }
        
        // 转换为0-100的评分（增长越好评分越高）
        $transactionScore = min(100, 50 + $growthRate * 2); // 50为基准分，每1%增长加2分，最高100
        $transactionScore = max(0, $transactionScore); // 最低0分
        
        // 计算综合评分
        $totalScore = (
            ($fulfillmentRate * $this->scoreWeights['fulfillment_rate']) +
            ((100 - $disputeRate) * $this->scoreWeights['dispute_rate']) +  // 纠纷率评分反向计算
            ($responseTimeScore * $this->scoreWeights['response_time']) +
            ($complianceScore * $this->scoreWeights['compliance_score']) +
            ($transactionScore * $this->scoreWeights['transaction_volume'])
        );
        
        // 确定信用等级
        $creditLevel = $this->determineCreditLevel($totalScore);
        
        // 记录评分计算详情
        $scoreDetails = array(
            'fulfillment_rate' => round($fulfillmentRate, 2),
            'dispute_rate' => round($disputeRate, 2),
            'response_time_hours' => $avgResponseTime['avg_hours'],
            'response_time_score' => round($responseTimeScore, 2),
            'compliance_score' => round($complianceScore, 2),
            'transaction_growth_rate' => round($growthRate, 2),
            'transaction_score' => round($transactionScore, 2),
            'total_score' => round($totalScore, 2),
            'credit_level' => $creditLevel,
            'period_start' => $periodStart,
            'period_end' => date('Y-m-d'),
            'transaction_count' => $totalTransactions['count']
        );
        
        return $scoreDetails;
    }
    
    /**
     * 更新商户信用评分
     * @param int $merchantId 商户ID
     * @return bool 更新是否成功
     */
    public function updateMerchantRating($merchantId) {
        // 计算新评分
        $scoreDetails = $this->calculateCreditScore($merchantId);
        
        // 检查商户是否已有评分记录
        $currentRating = $this->getMerchantRating($merchantId);
        
        if (!$currentRating) {
            // 初始化评分记录
            $this->initializeMerchantRating($merchantId);
        }
        
        // 准备更新数据
        $updateData = array(
            'credit_score' => $scoreDetails['total_score'],
            'credit_level' => $scoreDetails['credit_level'],
            'fulfillment_rate' => $scoreDetails['fulfillment_rate'],
            'dispute_rate' => $scoreDetails['dispute_rate'],
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        // 更新评分
        $result = $this->database->update(
            'merchant_credit_ratings',
            $updateData,
            array('merchant_id' => $merchantId)
        );
        
        // 记录评分历史
        $this->logRatingHistory($merchantId, $scoreDetails);
        
        // 如果信用等级发生变化，更新权限
        if ($currentRating && $currentRating['credit_level'] != $scoreDetails['credit_level']) {
            $this->updateMerchantPermissions($merchantId, $scoreDetails['credit_level']);
            
            // 记录审计日志
            if ($this->auditLogger) {
                $this->auditLogger->log(
                    0, // 系统操作
                    'merchant_credit_level_changed',
                    '商户信用等级变更',
                    array(
                        'merchant_id' => $merchantId,
                        'old_level' => $currentRating['credit_level'],
                        'new_level' => $scoreDetails['credit_level'],
                        'old_score' => $currentRating['credit_score'],
                        'new_score' => $scoreDetails['total_score']
                    ),
                    'info'
                );
            }
        }
        
        return $result;
    }
    
    /**
     * 获取商户信用评分
     * @param int $merchantId 商户ID
     * @return array|null 评分数据
     */
    public function getMerchantRating($merchantId) {
        $rating = $this->database->fetch(
            "SELECT * FROM merchant_credit_ratings WHERE merchant_id = ?",
            array($merchantId)
        );
        
        if ($rating) {
            // 添加等级描述和颜色
            $rating['level_description'] = $this->creditLevels[$rating['credit_level']]['name'];
            $rating['level_color'] = $this->creditLevels[$rating['credit_level']]['color'];
        }
        
        return $rating;
    }
    
    /**
     * 批量更新所有商户的信用评分
     * @return int 更新的商户数量
     */
    public function updateAllMerchantsRatings() {
        // 获取所有商户ID
        $merchants = $this->database->fetchAll(
            "SELECT id FROM users WHERE role = 'merchant'"
        );
        
        $updatedCount = 0;
        
        foreach ($merchants as $merchant) {
            try {
                if ($this->updateMerchantRating($merchant['id'])) {
                    $updatedCount++;
                }
            } catch (Exception $e) {
                // 记录错误但继续处理其他商户
                error_log("Failed to update rating for merchant " . $merchant['id'] . ": " . $e->getMessage());
            }
        }
        
        return $updatedCount;
    }
    
    /**
     * 获取商户信用报告
     * @param int $merchantId 商户ID
     * @return array 信用报告
     */
    public function getMerchantCreditReport($merchantId) {
        // 获取当前评分
        $currentRating = $this->getMerchantRating($merchantId);
        
        if (!$currentRating) {
            throw new Exception("Merchant rating not found");
        }
        
        // 获取历史评分趋势
        $ratingHistory = $this->database->fetchAll(
            "SELECT * FROM merchant_rating_history 
             WHERE merchant_id = ? 
             ORDER BY created_at DESC 
             LIMIT 6", // 获取最近6条记录
            array($merchantId)
        );
        
        // 获取关键指标详情
        $keyMetrics = $this->database->fetch(
            "SELECT 
                COUNT(o.id) as total_transactions,
                SUM(CASE WHEN o.status = 'completed' THEN 1 ELSE 0 END) as fulfilled_orders,
                COUNT(DISTINCT d.id) as disputes,
                COUNT(DISTINCT v.id) as violations
             FROM orders o
             LEFT JOIN disputes d ON o.id = d.order_id AND d.created_at > DATE_SUB(NOW(), INTERVAL 90 DAY)
             LEFT JOIN merchant_violations v ON v.merchant_id = o.merchant_id AND v.created_at > DATE_SUB(NOW(), INTERVAL 90 DAY)
             WHERE o.merchant_id = ? AND o.created_at > DATE_SUB(NOW(), INTERVAL 90 DAY)",
            array($merchantId)
        );
        
        // 获取权限详情
        $permissions = $this->getMerchantPermissions($merchantId);
        
        // 准备报告数据
        $report = array(
            'merchant_id' => $merchantId,
            'current_rating' => $currentRating,
            'rating_history' => $ratingHistory,
            'key_metrics' => $keyMetrics,
            'permissions' => $permissions,
            'generated_at' => date('Y-m-d H:i:s'),
            'recommendations' => $this->generateImprovementRecommendations($currentRating, $keyMetrics)
        );
        
        return $report;
    }
    
    /**
     * 获取商户权限
     * @param int $merchantId 商户ID
     * @return array 权限配置
     */
    public function getMerchantPermissions($merchantId) {
        // 获取商户信用等级
        $rating = $this->getMerchantRating($merchantId);
        
        if (!$rating) {
            return $this->config['permission_impact']['standard']; // 返回标准权限
        }
        
        $level = $rating['credit_level'];
        
        // 返回该等级对应的权限
        return $this->config['permission_impact'][$level];
    }
    
    /**
     * 更新商户权限
     * @param int $merchantId 商户ID
     * @param string $creditLevel 信用等级
     * @return bool 更新是否成功
     */
    public function updateMerchantPermissions($merchantId, $creditLevel) {
        // 获取权限配置
        $permissions = $this->config['permission_impact'][$creditLevel];
        
        // 检查商户权限记录是否存在
        $existingPermissions = $this->database->fetch(
            "SELECT id FROM merchant_permissions WHERE merchant_id = ?",
            array($merchantId)
        );
        
        $permissionsData = array(
            'merchant_id' => $merchantId,
            'credit_level' => $creditLevel,
            'max_listings' => $permissions['max_listings'],
            'withdrawal_limit' => $permissions['withdrawal_limit'],
            'withdrawal_speed' => $permissions['withdrawal_speed'],
            'priority_support' => $permissions['priority_support'],
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        if ($existingPermissions) {
            // 更新权限
            return $this->database->update(
                'merchant_permissions',
                $permissionsData,
                array('merchant_id' => $merchantId)
            );
        } else {
            // 插入新权限记录
            $permissionsData['created_at'] = date('Y-m-d H:i:s');
            return $this->database->insert('merchant_permissions', $permissionsData) !== false;
        }
    }
    
    /**
     * 记录评分历史
     * @param int $merchantId 商户ID
     * @param array $scoreDetails 评分详情
     */
    private function logRatingHistory($merchantId, $scoreDetails) {
        $historyData = array(
            'merchant_id' => $merchantId,
            'credit_score' => $scoreDetails['total_score'],
            'credit_level' => $scoreDetails['credit_level'],
            'fulfillment_rate' => $scoreDetails['fulfillment_rate'],
            'dispute_rate' => $scoreDetails['dispute_rate'],
            'response_time_score' => $scoreDetails['response_time_score'],
            'compliance_score' => $scoreDetails['compliance_score'],
            'transaction_score' => $scoreDetails['transaction_score'],
            'transaction_count' => $scoreDetails['transaction_count'],
            'created_at' => date('Y-m-d H:i:s')
        );
        
        $this->database->insert('merchant_rating_history', $historyData);
    }
    
    /**
     * 确定信用等级
     * @param float $score 信用分数
     * @return string 信用等级
     */
    private function determineCreditLevel($score) {
        foreach ($this->creditLevels as $level => $config) {
            if ($score >= $config['min_score']) {
                return $level;
            }
        }
        return 'poor'; // 默认最差等级
    }
    
    /**
     * 获取信用等级详情
     * @param string $level 信用等级
     * @return array|null 等级详情
     */
    public function getCreditLevelDetails($level) {
        if (isset($this->creditLevels[$level])) {
            $details = $this->creditLevels[$level];
            $details['level'] = $level;
            $details['permissions'] = $this->config['permission_impact'][$level];
            return $details;
        }
        return null;
    }
    
    /**
     * 生成改进建议
     * @param array $currentRating 当前评分
     * @param array $keyMetrics 关键指标
     * @return array 改进建议列表
     */
    private function generateImprovementRecommendations($currentRating, $keyMetrics) {
        $recommendations = array();
        
        // 基于履约率的建议
        if ($currentRating['fulfillment_rate'] < 90) {
            $recommendations[] = "提高订单履约率，确保按时发货，减少取消订单的情况";
        }
        
        // 基于纠纷率的建议
        if ($currentRating['dispute_rate'] > 5) {
            $recommendations[] = "减少纠纷数量，建议加强与客户的沟通，及时解决问题";
        }
        
        // 基于违规记录的建议
        if ($keyMetrics['violations'] > 0) {
            $recommendations[] = "遵守平台规则，避免违规行为，提高合规性";
        }
        
        // 基于评分等级的一般建议
        if ($currentRating['credit_score'] < 80) {
            $recommendations[] = "增加交易量并保持稳定增长，有助于提升信用评分";
            $recommendations[] = "及时响应用户咨询和投诉，缩短响应时间";
        }
        
        // 高评分商户的建议
        if ($currentRating['credit_score'] >= 80) {
            $recommendations[] = "保持良好表现，优秀的信用评级有助于获得更多平台支持";
        }
        
        return $recommendations;
    }
    
    /**
     * 获取商户信用评级列表
     * @param array $filters 过滤条件
     * @param array $pagination 分页参数
     * @return array 商户评级列表
     */
    public function getMerchantRatingsList($filters = array(), $pagination = array()) {
        $query = "SELECT 
                    mcr.*, 
                    u.username as merchant_name 
                 FROM merchant_credit_ratings mcr
                 JOIN users u ON mcr.merchant_id = u.id
                 WHERE 1=1";
        
        $params = array();
        
        // 应用过滤条件
        if (isset($filters['credit_level'])) {
            $query .= " AND mcr.credit_level = ?";
            $params[] = $filters['credit_level'];
        }
        
        if (isset($filters['min_score'])) {
            $query .= " AND mcr.credit_score >= ?";
            $params[] = $filters['min_score'];
        }
        
        if (isset($filters['max_score'])) {
            $query .= " AND mcr.credit_score <= ?";
            $params[] = $filters['max_score'];
        }
        
        if (isset($filters['merchant_name'])) {
            $query .= " AND u.username LIKE ?";
            $params[] = "%" . $filters['merchant_name'] . "%";
        }
        
        // 添加排序
        $query .= " ORDER BY ";
        $query .= isset($filters['sort_by']) ? $filters['sort_by'] : "mcr.credit_score DESC";
        
        // 应用分页
        if (isset($pagination['limit']) && isset($pagination['offset'])) {
            $query .= " LIMIT ? OFFSET ?";
            $params[] = $pagination['limit'];
            $params[] = $pagination['offset'];
        }
        
        // 获取结果
        $ratings = $this->database->fetchAll($query, $params);
        
        // 添加等级描述和颜色
        foreach ($ratings as &$rating) {
            $rating['level_description'] = $this->creditLevels[$rating['credit_level']]['name'];
            $rating['level_color'] = $this->creditLevels[$rating['credit_level']]['color'];
        }
        
        return $ratings;
    }
    
    /**
     * 记录商户违规行为
     * @param int $merchantId 商户ID
     * @param string $violationType 违规类型
     * @param string $description 违规描述
     * @param string $severity 严重程度
     * @return int 违规记录ID
     */
    public function recordMerchantViolation($merchantId, $violationType, $description, $severity = 'medium') {
        $violationData = array(
            'merchant_id' => $merchantId,
            'violation_type' => $violationType,
            'description' => $description,
            'severity' => $severity,
            'created_at' => date('Y-m-d H:i:s')
        );
        
        $violationId = $this->database->insert('merchant_violations', $violationData);
        
        // 违规可能影响评分，更新评分
        try {
            $this->updateMerchantRating($merchantId);
        } catch (Exception $e) {
            // 记录错误但不阻止操作
            error_log("Failed to update rating after violation: " . $e->getMessage());
        }
        
        // 记录审计日志
        if ($this->auditLogger) {
            $this->auditLogger->log(
                0, // 系统操作
                'record_merchant_violation',
                '记录商户违规',
                array(
                    'merchant_id' => $merchantId,
                    'violation_type' => $violationType,
                    'severity' => $severity,
                    'description' => $description
                ),
                'warning'
            );
        }
        
        return $violationId;
    }
    
    /**
     * 获取商户违规记录
     * @param int $merchantId 商户ID
     * @param array $pagination 分页参数
     * @return array 违规记录列表
     */
    public function getMerchantViolations($merchantId, $pagination = array()) {
        $query = "SELECT * FROM merchant_violations WHERE merchant_id = ?";
        $params = array($merchantId);
        
        // 添加排序
        $query .= " ORDER BY created_at DESC";
        
        // 应用分页
        if (isset($pagination['limit']) && isset($pagination['offset'])) {
            $query .= " LIMIT ? OFFSET ?";
            $params[] = $pagination['limit'];
            $params[] = $pagination['offset'];
        }
        
        return $this->database->fetchAll($query, $params);
    }
}