<?php
/**
 * 路由管理类
 * 提供统一的路由注册和分发功能
 */

class Router {
    private static $instance = null;
    private $routes = array();
    private $middleware = array();
    private $config;
    private $logger;
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->config = ConfigManager::getInstance();
        $this->logger = new Logger();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 注册GET路由
     */
    public function get($path, $handler, $middleware = array()) {
        $this->addRoute('GET', $path, $handler, $middleware);
    }
    
    /**
     * 注册POST路由
     */
    public function post($path, $handler, $middleware = array()) {
        $this->addRoute('POST', $path, $handler, $middleware);
    }
    
    /**
     * 注册PUT路由
     */
    public function put($path, $handler, $middleware = array()) {
        $this->addRoute('PUT', $path, $handler, $middleware);
    }
    
    /**
     * 注册DELETE路由
     */
    public function delete($path, $handler, $middleware = array()) {
        $this->addRoute('DELETE', $path, $handler, $middleware);
    }
    
    /**
     * 注册PATCH路由
     */
    public function patch($path, $handler, $middleware = array()) {
        $this->addRoute('PATCH', $path, $handler, $middleware);
    }
    
    /**
     * 注册OPTIONS路由
     */
    public function options($path, $handler, $middleware = array()) {
        $this->addRoute('OPTIONS', $path, $handler, $middleware);
    }
    
    /**
     * 注册任意方法路由
     */
    public function any($path, $handler, $middleware = array()) {
        $methods = array('GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS');
        foreach ($methods as $method) {
            $this->addRoute($method, $path, $handler, $middleware);
        }
    }
    
    /**
     * 添加路由
     */
    private function addRoute($method, $path, $handler, $middleware = array()) {
        $pattern = $this->convertPathToPattern($path);
        
        array_push($this->routes, array(
            'method' => $method,
            'path' => $path,
            'pattern' => $pattern,
            'handler' => $handler,
            'middleware' => array_merge($this->middleware, $middleware)
        ));
        
        $this->logger->debug("路由注册: {$method} {$path}");
    }
    
    /**
     * 注册全局中间件
     */
    public function middleware($middleware) {
        array_push($this->middleware, $middleware);
    }
    
    /**
     * 路由分组
     */
    public function group($prefix, $callback, $middleware = array()) {
        $previousMiddleware = $this->middleware;
        $this->middleware = array_merge($this->middleware, $middleware);
        
        $callback($this);
        
        $this->middleware = $previousMiddleware;
    }
    
    /**
     * 资源路由
     */
    public function resource($name, $controller, $middleware = array()) {
        $this->get("/{$name}", array($controller, 'index'), $middleware);
        $this->get("/{$name}/create", array($controller, 'create'), $middleware);
        $this->post("/{$name}", array($controller, 'store'), $middleware);
        $this->get("/{$name}/{id}", array($controller, 'show'), $middleware);
        $this->get("/{$name}/{id}/edit", array($controller, 'edit'), $middleware);
        $this->put("/{$name}/{id}", array($controller, 'update'), $middleware);
        $this->delete("/{$name}/{id}", array($controller, 'destroy'), $middleware);
    }
    
    /**
     * API资源路由
     */
    public function apiResource($name, $controller, $middleware = array()) {
        $this->get("/api/{$name}", array($controller, 'index'), $middleware);
        $this->post("/api/{$name}", array($controller, 'store'), $middleware);
        $this->get("/api/{$name}/{id}", array($controller, 'show'), $middleware);
        $this->put("/api/{$name}/{id}", array($controller, 'update'), $middleware);
        $this->delete("/api/{$name}/{id}", array($controller, 'destroy'), $middleware);
    }
    
    /**
     * 分发请求
     */
    public function dispatch() {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // 移除查询字符串
        $uri = strtok($uri, '?');
        
        $this->logger->info("请求分发: {$method} {$uri}");
        
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }
            
            if ($this->matchPattern($route['pattern'], $uri, $params)) {
                return $this->handleRoute($route, $params);
            }
        }
        
        // 404 Not Found
        $this->handle404($method, $uri);
    }
    
    /**
     * 处理路由
     */
    private function handleRoute($route, $params) {
        try {
            // 执行中间件
            foreach ($route['middleware'] as $middleware) {
                $result = $this->executeMiddleware($middleware, $params);
                if ($result === false) {
                    return; // 中间件阻止了请求继续
                }
            }
            
            // 执行处理器
            $response = $this->executeHandler($route['handler'], $params);
            
            // 发送响应
            $this->sendResponse($response);
            
        } catch (Exception $e) {
            $this->handleException($e);
        }
    }
    
    /**
     * 执行中间件
     */
    private function executeMiddleware($middleware, $params) {
        if (is_callable($middleware)) {
            return call_user_func($middleware, $params);
        } elseif (is_string($middleware)) {
            $middlewareClass = new $middleware();
            if (method_exists($middlewareClass, 'handle')) {
                return $middlewareClass->handle($params);
            }
        }
        
        return true;
    }
    
    /**
     * 执行处理器
     */
    private function executeHandler($handler, $params) {
        if (is_callable($handler)) {
            return call_user_func($handler, $params);
        } elseif (is_array($handler)) {
            $controller = new $handler[0]();
            $method = $handler[1];
            
            if (method_exists($controller, $method)) {
                return $controller->$method($params);
            }
        }
        
        throw new Exception("无效的处理器");
    }
    
    /**
     * 发送响应
     */
    private function sendResponse($response) {
        if (is_array($response) || is_object($response)) {
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            echo $response;
        }
    }
    
    /**
     * 处理404错误
     */
    private function handle404($method, $uri) {
        http_response_code(404);
        
        $this->logger->warning("404 Not Found: {$method} {$uri}");
        
        if ($this->isApiRequest()) {
            header('Content-Type: application/json');
            echo json_encode(array(
                'success' => false,
                'message' => 'Not Found',
                'code' => 404
            ));
        } else {
            include __DIR__ . '/../views/errors/404.php';
        }
    }
    
    /**
     * 处理异常
     */
    private function handleException($exception) {
        $this->logger->error("路由异常: " . $exception->getMessage(), array(
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ));
        
        if ($this->config->get('app.debug', false)) {
            throw $exception;
        }
        
        http_response_code(500);
        
        if ($this->isApiRequest()) {
            header('Content-Type: application/json');
            echo json_encode(array(
                'success' => false,
                'message' => 'Internal Server Error',
                'code' => 500
            ));
        } else {
            include __DIR__ . '/../views/errors/500.php';
        }
    }
    
    /**
     * 检查是否为API请求
     */
    private function isApiRequest() {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        return strpos($uri, '/api/') === 0;
    }
    
    /**
     * 将路径转换为正则表达式模式
     */
    private function convertPathToPattern($path) {
        $pattern = preg_replace('/\{([^}]+)\}/', '(?P<$1>[^/]+)', $path);
        $pattern = preg_replace('/\{([^}]+):([^}]+)\}/', '(?P<$1>$2)', $path);
        $pattern = '#^' . $pattern . '$#';
        
        return $pattern;
    }
    
    /**
     * 匹配路径模式
     */
    private function matchPattern($pattern, $uri, &$params) {
        if (preg_match($pattern, $uri, $matches)) {
            $params = array();
            
            foreach ($matches as $key => $value) {
                if (is_string($key)) {
                    $params[$key] = $value;
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 生成URL
     */
    public function url($name, $params = array()) {
        foreach ($this->routes as $route) {
            if ($route['path'] === $name) {
                $url = $route['path'];
                
                foreach ($params as $key => $value) {
                    $url = str_replace('{' . $key . '}', $value, $url);
                }
                
                return $url;
            }
        }
        
        return $name;
    }
    
    /**
     * 重定向
     */
    public function redirect($url, $statusCode = 302) {
        http_response_code($statusCode);
        header("Location: {$url}");
        exit;
    }
    
    /**
     * 获取当前路由信息
     */
    public function getCurrentRoute() {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }
            
            if ($this->matchPattern($route['pattern'], $uri, $params)) {
                return array(
                    'route' => $route,
                    'params' => $params
                );
            }
        }
        
        return null;
    }
    
    /**
     * 获取所有路由
     */
    public function getRoutes() {
        return $this->routes;
    }
    
    /**
     * 缓存路由
     */
    public function cacheRoutes($cacheFile) {
        $cacheData = array(
            'routes' => $this->routes,
            'middleware' => $this->middleware,
            'timestamp' => time()
        );
        
        file_put_contents($cacheFile, serialize($cacheData));
    }
    
    /**
     * 加载缓存的路由
     */
    public function loadCachedRoutes($cacheFile) {
        if (!file_exists($cacheFile)) {
            return false;
        }
        
        $cacheData = unserialize(file_get_contents($cacheFile));
        
        if (isset($cacheData['routes'])) {
            $this->routes = $cacheData['routes'];
        }
        
        if (isset($cacheData['middleware'])) {
            $this->middleware = $cacheData['middleware'];
        }
        
        return true;
    }
    
    /**
     * 防止克隆
     */
    private function __clone() {}
    
    /**
     * 防止反序列化
     */
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

/**
 * 中间件基类
 */
abstract class Middleware {
    abstract public function handle($params);
}

/**
 * 认证中间件
 */
class AuthMiddleware extends Middleware {
    public function handle($params) {
        if (!isset($_SESSION['user_id'])) {
            if (Router::getInstance()->isApiRequest()) {
                http_response_code(401);
                echo json_encode(array(
                    'success' => false,
                    'message' => 'Unauthorized',
                    'code' => 401
                ), JSON_PRETTY_PRINT);
                exit;
            } else {
                Router::getInstance()->redirect('/login.php');
            }
        }
        
        return true;
    }
}

/**
 * CORS中间件
 */
class CorsMiddleware extends Middleware {
    public function handle($params) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
        
        return true;
    }
}

/**
 * 请求日志中间件
 */
class RequestLogMiddleware extends Middleware {
    private $logger;
    
    public function __construct() {
        $this->logger = new Logger();
    }
    
    public function handle($params) {
        $startTime = microtime(true);
        
        // 记录请求开始
        $this->logger->info("请求开始", array(
            'method' => $_SERVER['REQUEST_METHOD'],
            'uri' => $_SERVER['REQUEST_URI'],
            'ip' => $this->getClientIp(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''
        ));
        
        return true;
    }
    
    private function getClientIp() {
        $ipKeys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
    }
}