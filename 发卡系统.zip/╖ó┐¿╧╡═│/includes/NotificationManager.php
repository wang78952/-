<?php
/**
 * 通知管理器
 * 处理邮件、短信、Webhook等通知功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/ConfigManager.php';
// 导入Swift库
require_once __DIR__ . '/../vendor/autoload.php';
// 如果autoload.php不存在，尝试直接加载Swift Mailer库
if (!class_exists('Swift_Mailer') && !class_exists('\Swift_Mailer')) {
    $swiftPath = __DIR__ . '/../vendor/swiftmailer/swiftmailer/lib/';
    if (is_dir($swiftPath)) {
        spl_autoload_register(function($class) use ($swiftPath) {
            // 移除可能的命名空间前缀\
            $className = ltrim($class, '\\');
            $classPath = str_replace('\\', '/', $className);
            
            // 检查是否是Swift类
            if (strpos($className, 'Swift_') === 0) {
                // 处理Swift类的文件路径
                // Swift类通常在Swift目录下，使用下划线分隔的命名约定
                $filePath = $swiftPath . '/' . $classPath . '.php';
                
                // 如果直接路径不存在，尝试修复路径
                if (!file_exists($filePath)) {
                    // 尝试Swift目录下的各个子目录
                    $subDirs = ['', 'Swift/', 'Swift/Mailer/', 'Swift/Transport/', 'Swift/Mime/'];
                    foreach ($subDirs as $subDir) {
                        $testPath = $swiftPath . '/' . $subDir . $classPath . '.php';
                        if (file_exists($testPath)) {
                            $filePath = $testPath;
                            break;
                        }
                    }
                }
                
                if (file_exists($filePath)) {
                    require_once $filePath;
                }
            }
        });
    }
}

class NotificationManager extends BaseService {
    protected $config;
    protected $logger;
    protected $database;
    
    /**
     * 构造函数 - 保持与BaseService的兼容性
     * @param array $options 可选配置选项
     */
    public function __construct($options = array())
    {
        parent::__construct();
        
        // 从配置管理器获取通知配置
        $this->config = $this->config->get('notification', array());
        
        // 如果提供了自定义logger或database，使用它们覆盖默认值
        if (isset($options['logger']) && $options['logger']) {
            $this->logger = $options['logger'];
        }
        
        if (isset($options['database']) && $options['database']) {
            $this->database = $options['database'];
        }
    }
    
    /**
     * 向后兼容的构造函数重载方法
     * @param mixed $database 数据库连接或null
     * @param mixed $logger 日志记录器或null
     * @return NotificationManager 当前实例
     */
    public static function create($database = null, $logger = null)
    {
        $options = array();
        if ($database) {
            $options['database'] = $database;
        }
        if ($logger) {
            $options['logger'] = $logger;
        }
        return new self($options);
    }
    
    /**
     * 发送邮件通知
     */
    public function sendEmail($to, $subject, $content, $template = null) {
        try {
            if (!$this->config['email']['enabled']) {
                return array('success' => false, 'message' => '邮件通知未启用');
            }
            
            $result = $this->sendEmailViaSMTP($to, $subject, $content, $template);
            
            $this->logInfo("邮件发送完成", array(
                'to' => $to,
                'subject' => $subject,
                'result' => $result
            ));
            
            return $result;
            
        } catch (\Exception $e) {
            $this->logError("邮件发送失败", array(
                'to' => $to,
                'subject' => $subject,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 发送短信通知
     */
    public function sendSMS($phone, $content, $template = null) {
        try {
            if (!$this->config['sms']['enabled']) {
                return array('success' => false, 'message' => '短信通知未启用');
            }
            
            $result = $this->sendSMSViaProvider($phone, $content, $template);
            
            $this->logInfo("短信发送完成", array(
                'phone' => $phone,
                'content' => substr($content, 0, 50) . '...',
                'result' => $result
            ));
            
            return $result;
            
        } catch (\Exception $e) {
            $this->logError("短信发送失败", array(
                'phone' => $phone,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 发送Webhook通知
     */
    public function sendWebhook($url, $data, $method = 'POST') {
        try {
            if (!$this->config['webhook']['enabled']) {
                return array('success' => false, 'message' => 'Webhook通知未启用');
            }
            
            $result = $this->sendWebhookRequest($url, $data, $method);
            
            $this->logInfo("Webhook发送完成", array(
                'url' => $url,
                'method' => $method,
                'result' => $result
            ));
            
            return $result;
            
        } catch (\Exception $e) {
            $this->logError("Webhook发送失败", array(
                'url' => $url,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 发送订单通知
     */
    public function sendOrderNotification($orderId, $type, $data = array()) {
        try {
            $order = $this->database->fetch(
                "SELECT o.*, u.email, u.username FROM orders o 
                 JOIN users u ON o.user_id = u.id 
                 WHERE o.id = ?", 
                array($orderId)
            );
            
            if (!$order) {
                throw new Exception('订单不存在');
            }
            
            switch ($type) {
                case 'created':
                    return $this->sendOrderCreatedNotification($order, $data);
                case 'paid':
                    return $this->sendOrderPaidNotification($order, $data);
                case 'completed':
                    return $this->sendOrderCompletedNotification($order, $data);
                case 'cancelled':
                    return $this->sendOrderCancelledNotification($order, $data);
                default:
                    throw new Exception('不支持的通知类型');
            }
            
        } catch (\Exception $e) {
            $this->logError("订单通知发送失败", array(
                'order_id' => $orderId,
                'type' => $type,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 发送卡密通知
     */
    public function sendCardNotification($cardId, $type, $data = array()) {
        try {
            $card = $this->database->fetch(
                "SELECT c.*, u.email, u.username, p.name as product_name 
                 FROM cards c 
                 JOIN users u ON c.user_id = u.id 
                 JOIN products p ON c.product_id = p.id 
                 WHERE c.id = ?", 
                array($cardId)
            );
            
            if (!$card) {
                throw new Exception('卡密不存在');
            }
            
            switch ($type) {
                case 'generated':
                    return $this->sendCardGeneratedNotification($card, $data);
                case 'activated':
                    return $this->sendCardActivatedNotification($card, $data);
                case 'expired':
                    return $this->sendCardExpiredNotification($card, $data);
                default:
                    throw new Exception('不支持的通知类型');
            }
            
        } catch (\Exception $e) {
            $this->logError("卡密通知发送失败", array(
                'card_id' => $cardId,
                'type' => $type,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 通过SMTP发送邮件
     */
    private function sendEmailViaSMTP($to, $subject, $content, $template = null) {
        $config = $this->config['email'];
        
        try {
            // 安全检查：确保Swift相关类存在（同时检查带和不带命名空间前缀的版本）
            if (!class_exists('Swift_SmtpTransport') && !class_exists('\Swift_SmtpTransport') || 
                !class_exists('Swift_Mailer') && !class_exists('\Swift_Mailer') || 
                !class_exists('Swift_Message') && !class_exists('\Swift_Message')) {
                // 如果Swift类不存在，使用PHP内置mail函数作为后备方案
                $headers = "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                $headers .= "From: " . $config['from_name'] . " <" . $config['from_email'] . ">\r\n";
                
                $mailResult = mail($to, $subject, $content, $headers);
                
                if (!$mailResult) {
                    $this->logInfo("使用PHP mail函数发送邮件失败", array(
                        'to' => $to,
                        'subject' => $subject
                    ));
                    return array(
                        'success' => false,
                        'message' => 'Swift Mailer库不可用，且PHP mail函数发送失败'
                    );
                }
                
                $this->logInfo("使用PHP mail函数成功发送邮件（Swift Mailer库不可用）", array(
                    'to' => $to,
                    'subject' => $subject
                ));
                
                return array(
                    'success' => true,
                    'message' => '邮件已通过PHP mail函数发送成功（Swift Mailer库不可用）'
                );
            }
            
            // 创建邮件传输 - 使用可用的类名（尝试带和不带命名空间前缀的版本）
            $transportClass = class_exists('Swift_SmtpTransport') ? 'Swift_SmtpTransport' : '\Swift_SmtpTransport';
            $mailerClass = class_exists('Swift_Mailer') ? 'Swift_Mailer' : '\Swift_Mailer';
            $messageClass = class_exists('Swift_Message') ? 'Swift_Message' : '\Swift_Message';
            
            $transport = (new $transportClass($config['smtp_host'], $config['smtp_port']))
                ->setUsername($config['smtp_username'])
                ->setPassword($config['smtp_password']);
                
            $mailer = new $mailerClass($transport);
            
            // 创建邮件消息
            $message = (new $messageClass($subject))
                ->setFrom(array($config['from_email'] => $config['from_name']))
                ->setTo($to)
                ->setBody($content, 'text/html');
                
            // 发送邮件
            $result = $mailer->send($message);
            
            return array(
                'success' => $result > 0,
                'sent_count' => $result,
                'message' => $result > 0 ? '邮件发送成功' : '邮件发送失败'
            );
        } catch (\Exception $e) {
            // 捕获所有异常，返回友好的错误信息
            $this->logError("发送邮件时发生异常", array(
                'to' => $to,
                'subject' => $subject,
                'error' => $e->getMessage()
            ));
            
            // 尝试使用PHP内置mail函数作为最后的后备方案
            try {
                $headers = "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                $headers .= "From: " . $config['from_name'] . " <" . $config['from_email'] . ">\r\n";
                
                $mailResult = mail($to, $subject, $content, $headers);
                
                if ($mailResult) {
                    $this->logInfo("使用PHP mail函数成功发送邮件（Swift异常后备）", array(
                        'to' => $to,
                        'subject' => $subject
                    ));
                    return array(
                        'success' => true,
                        'message' => '邮件已通过PHP mail函数发送成功（Swift异常后备）'
                    );
                }
            } catch (\Exception $e2) {
                // 忽略PHP mail函数的异常
            }
            
            return array(
                'success' => false,
                'message' => '发送邮件失败: ' . $e->getMessage()
            );
        }
    }
    
    /**
     * 通过服务商发送短信
     */
    private function sendSMSViaProvider($phone, $content, $template = null) {
        $config = $this->config['sms'];
        
        switch ($config['provider']) {
            case 'aliyun':
                return $this->sendSMSViaAliyun($phone, $content, $template);
            default:
                throw new \Exception('不支持的短信服务商');
        }
    }
    
    /**
     * 通过阿里云发送短信
     */
    private function sendSMSViaAliyun($phone, $content, $template = null) {
        // 这里应该集成阿里云短信SDK
        // 为了演示，返回模拟结果
        return array(
            'success' => true,
            'message' => '短信发送成功',
            'phone' => $phone,
            'provider' => 'aliyun'
        );
    }
    
    /**
     * 发送Webhook请求
     */
    private function sendWebhookRequest($url, $data, $method = 'POST') {
        $config = $this->config['webhook'];
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $config['timeout'],
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'User-Agent: ' . (defined('APP_NAME') ? APP_NAME : 'Card System') . ' Webhook Client'
            ),
            CURLOPT_POSTFIELDS => json_encode($data)
        ));
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new \Exception("Webhook请求失败: " . $error);
        }
        
        $success = $httpCode >= 200 && $httpCode < 300;
        
        return array(
            'success' => $success,
            'http_code' => $httpCode,
            'response' => $response,
            'message' => $success ? 'Webhook发送成功' : 'Webhook发送失败'
        );
    }
    
    /**
     * 发送订单创建通知
     */
    private function sendOrderCreatedNotification($order, $data) {
        $subject = "订单创建成功 - #{$order['id']}";
        $content = $this->renderEmailTemplate('order_created', array(
            'order' => $order,
            'user' => array(
                'username' => $order['username'],
                'email' => $order['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($order['email'], $subject, $content);
    }
    
    /**
     * 发送订单支付通知
     */
    private function sendOrderPaidNotification($order, $data) {
        $subject = "订单支付成功 - #{$order['id']}";
        $content = $this->renderEmailTemplate('order_paid', array(
            'order' => $order,
            'user' => array(
                'username' => $order['username'],
                'email' => $order['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($order['email'], $subject, $content);
    }
    
    /**
     * 发送订单完成通知
     */
    private function sendOrderCompletedNotification($order, $data) {
        $subject = "订单完成 - #{$order['id']}";
        $content = $this->renderEmailTemplate('order_completed', array(
            'order' => $order,
            'user' => array(
                'username' => $order['username'],
                'email' => $order['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($order['email'], $subject, $content);
    }
    
    /**
     * 发送订单取消通知
     */
    private function sendOrderCancelledNotification($order, $data) {
        $subject = "订单已取消 - #{$order['id']}";
        $content = $this->renderEmailTemplate('order_cancelled', array(
            'order' => $order,
            'user' => array(
                'username' => $order['username'],
                'email' => $order['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($order['email'], $subject, $content);
    }
    
    /**
     * 发送卡密生成通知
     */
    private function sendCardGeneratedNotification($card, $data) {
        $subject = "卡密生成成功 - {$card['product_name']}";
        $content = $this->renderEmailTemplate('card_generated', array(
            'card' => $card,
            'user' => array(
                'username' => $card['username'],
                'email' => $card['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($card['email'], $subject, $content);
    }
    
    /**
     * 发送卡密激活通知
     */
    private function sendCardActivatedNotification($card, $data) {
        $subject = "卡密已激活 - {$card['product_name']}";
        $content = $this->renderEmailTemplate('card_activated', array(
            'card' => $card,
            'user' => array(
                'username' => $card['username'],
                'email' => $card['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($card['email'], $subject, $content);
    }
    
    /**
     * 发送卡密过期通知
     */
    private function sendCardExpiredNotification($card, $data) {
        $subject = "卡密已过期 - {$card['product_name']}";
        $content = $this->renderEmailTemplate('card_expired', array(
            'card' => $card,
            'user' => array(
                'username' => $card['username'],
                'email' => $card['email']
            ),
            'additional_data' => $data
        ));
        
        return $this->sendEmail($card['email'], $subject, $content);
    }
    
    /**
     * 渲染邮件模板
     */
    private function renderEmailTemplate($template, $data) {
        $templatePath = __DIR__ . "/../templates/email/{$template}.html";
        
        if (!file_exists($templatePath)) {
            // 如果模板不存在，使用默认模板
            return $this->renderDefaultEmailTemplate($data);
        }
        
        ob_start();
        extract($data);
        include $templatePath;
        return ob_get_clean();
    }
    
    /**
     * 渲染默认邮件模板
     */
    private function renderDefaultEmailTemplate($data) {
        $title = isset($data['title']) ? $data['title'] : '通知';
        $content = isset($data['content']) ? $data['content'] : '您有一条新的通知。';
        
        return "
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>{$title}</title>
        </head>
        <body style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='background: #f8f9fa; padding: 20px; border-radius: 5px;'>
                <h2 style='color: #333; margin-top: 0;'>{$title}</h2>
                <div style='color: #666; line-height: 1.6;'>
                    {$content}
                </div>
                <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
                <p style='color: #999; font-size: 12px;'>
                    此邮件由 " . (defined('APP_NAME') ? APP_NAME : 'Card System') . " 系统自动发送，请勿回复。
                </p>
            </div>
        </body>
        </html>";
    }
    
    /**
     * 记录信息日志
     */
    protected function logInfo($message, $data = array()) {
        $this->logger->info($message, array_merge($data, array('component' => 'NotificationManager')));
    }
    
    /**
     * 记录错误日志
     */
    protected function logError($message, $data = array()) {
        $this->logger->error($message, array_merge($data, array('component' => 'NotificationManager')));
    }
    
    /**
     * 发送商户通知
     * @param int $merchantId 商户ID
     * @param string $type 通知类型
     * @param array $data 通知数据
     * @return array 发送结果
     */
    public function sendMerchantNotification($merchantId, $type, $data = array()) {
        try {
            // 获取商户信息
            $merchant = null;
            if ($this->database) {
                $merchant = $this->database->fetch(
                    "SELECT * FROM merchants WHERE id = ?", 
                    array($merchantId)
                );
            }
            
            // 根据通知类型构建主题和内容
            $subject = "商户通知 - " . ucfirst($type);
            $content = $this->renderEmailTemplate('merchant_notification', array(
                'merchant' => $merchant,
                'type' => $type,
                'data' => $data
            ));
            
            // 发送邮件通知
            if ($merchant && isset($merchant['email'])) {
                $result = $this->sendEmail($merchant['email'], $subject, $content);
                
                // 同时保存到通知表
                if ($this->database && $result['success']) {
                    $this->database->insert(
                        'notifications',
                        array(
                            'recipient_id' => $merchantId,
                            'recipient_type' => 'merchant',
                            'type' => $type,
                            'data' => json_encode($data),
                            'created_at' => date('Y-m-d H:i:s'),
                            'read' => 0
                        )
                    );
                }
                
                return $result;
            }
            
            return array('success' => false, 'message' => '商户邮箱未设置');
            
        } catch (Exception $e) {
            $this->logError("发送商户通知失败", array(
                'merchant_id' => $merchantId,
                'type' => $type,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 向后兼容的通用发送方法
     * @param mixed $recipient 接收者（邮箱、手机号或用户ID）
     * @param string $subject 通知主题
     * @param string $content 通知内容
     * @param array $options 可选参数
     * @return bool|array 发送结果（保持与旧版本兼容）
     */
    public function send($recipient, $subject, $content, $options = []) {
        try {
            $channel = $options['channel'] ?? 'email';
            
            // 根据渠道调用相应的方法
            switch ($channel) {
                case 'email':
                    // 假设recipient是邮箱
                    $result = $this->sendEmail($recipient, $subject, $content);
                    return $result['success'] ?? false;
                    
                case 'sms':
                    // 假设recipient是手机号
                    $result = $this->sendSMS($recipient, $content);
                    return $result['success'] ?? false;
                    
                case 'in_app':
                    // 假设recipient是用户ID且是整数
                    if (is_numeric($recipient)) {
                        $result = $this->sendUserNotification(
                            intval($recipient),
                            $options['type'] ?? 'general',
                            ['subject' => $subject, 'content' => $content]
                        );
                        return $result['success'] ?? false;
                    }
                    return false;
                    
                default:
                    $this->logError("未知的通知渠道", ['channel' => $channel]);
                    return false;
            }
        } catch (Exception $e) {
            $this->logError("发送通知失败", [
                'recipient' => $recipient,
                'channel' => $options['channel'] ?? 'unknown',
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
    
    /**
     * 发送用户通知
     * @param int $userId 用户ID
     * @param string $type 通知类型
     * @param array $data 通知数据
     * @return array 发送结果
     */
    public function sendUserNotification($userId, $type, $data = array()) {
        try {
            // 获取用户信息
            $user = null;
            if ($this->database) {
                $user = $this->database->fetch(
                    "SELECT * FROM users WHERE id = ?", 
                    array($userId)
                );
            }
            
            // 根据通知类型构建主题和内容
            $subject = "用户通知 - " . ucfirst($type);
            $content = $this->renderEmailTemplate('user_notification', array(
                'user' => $user,
                'type' => $type,
                'data' => $data
            ));
            
            // 发送邮件通知
            if ($user && isset($user['email'])) {
                $result = $this->sendEmail($user['email'], $subject, $content);
                
                // 同时保存到通知表
                if ($this->database && $result['success']) {
                    $this->database->insert(
                        'notifications',
                        array(
                            'recipient_id' => $userId,
                            'recipient_type' => 'user',
                            'type' => $type,
                            'data' => json_encode($data),
                            'created_at' => date('Y-m-d H:i:s'),
                            'read' => 0
                        )
                    );
                }
                
                return $result;
            }
            
            return array('success' => false, 'message' => '用户邮箱未设置');
            
        } catch (Exception $e) {
            $this->logError("发送用户通知失败", array(
                'user_id' => $userId,
                'type' => $type,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 向后兼容的通知队列处理方法
     * @param int $limit 处理限制
     * @return int 成功处理的通知数
     */
    public function processQueue($limit = 10) {
        // 新版本不使用内存队列，这里返回0表示没有处理的通知
        // 或者可以从数据库读取通知队列进行处理
        return 0;
    }
    
    /**
     * 通用通知发送方法
     * @param int $recipientId 接收者ID
     * @param string $recipientType 接收者类型 (merchant/user)
     * @param string $type 通知类型
     * @param array $data 通知数据
     * @return array 发送结果
     */
    public function sendNotification($recipientId, $recipientType, $type, $data = array()) {
        try {
            if ($recipientType === 'merchant') {
                return $this->sendMerchantNotification($recipientId, $type, $data);
            } elseif ($recipientType === 'user') {
                return $this->sendUserNotification($recipientId, $type, $data);
            }
            
            return array('success' => false, 'message' => '不支持的接收者类型');
            
        } catch (Exception $e) {
            $this->logError("发送通知失败", array(
                'recipient_id' => $recipientId,
                'recipient_type' => $recipientType,
                'type' => $type,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
}