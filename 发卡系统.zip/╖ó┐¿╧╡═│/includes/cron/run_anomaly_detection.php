<?php
/**
 * 异常波动检测定时任务
 * 定期运行异常检测，检测业务指标异常并发送预警通知
 */

// 引入异常检测类
require_once __DIR__ . '/../monitoring/AnomalyDetection.php';

class AnomalyDetectionCron {
    /**
     * 异常检测实例
     * @var AnomalyDetection
     */
    protected $anomalyDetector = null;
    
    /**
     * 日志文件路径
     * @var string
     */
    protected $logFile = null;
    
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        'log' => [
            'enabled' => true,
            'file' => 'logs/anomaly_detection.log',
            'level' => 'info',  // debug, info, warning, error
        ],
        'metrics' => [
            // 需要检测的指标列表，空数组表示检测所有支持的指标
            'detect' => [],
            // 检测算法
            'algorithm' => 'threshold',  // threshold, statistical, machine_learning
            // 时间范围
            'time_ranges' => ['today', 'last_7_days'],
        ],
        'notification' => [
            'enabled' => true,
            // 通知接收人
            'recipients' => [
                'email' => ['admin@example.com'],
                'sms' => ['13800138000'],
            ],
        ],
    ];
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    public function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化日志文件
        $this->initializeLog();
        
        // 初始化异常检测器
        $this->initializeAnomalyDetector();
    }
    
    /**
     * 初始化日志
     */
    protected function initializeLog() {
        if (!$this->config['log']['enabled']) {
            return;
        }
        
        // 确保日志目录存在
        $logDir = dirname($this->config['log']['file']);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $this->logFile = $this->config['log']['file'];
    }
    
    /**
     * 初始化异常检测器
     */
    protected function initializeAnomalyDetector() {
        try {
            $this->anomalyDetector = AnomalyDetection::getInstance();
            $this->log('异常检测器初始化成功');
        } catch (Exception $e) {
            $this->log('异常检测器初始化失败: ' . $e->getMessage(), 'error');
            throw new Exception('无法初始化异常检测器');
        }
    }
    
    /**
     * 运行异常检测
     * @return array 检测结果
     */
    public function run() {
        $this->log('开始运行异常检测...');
        
        try {
            $results = [];
            $anomaliesFound = false;
            
            // 对每个时间范围进行检测
            foreach ($this->config['metrics']['time_ranges'] as $timeRange) {
                $this->log("检测时间范围: {$timeRange}", 'info');
                
                // 执行检测
                $options = [
                    'algorithm' => $this->config['metrics']['algorithm'],
                    'time_range' => $timeRange,
                    'auto_notify' => true,  // 自动发送通知
                ];
                
                $detectionResult = $this->anomalyDetector->detectAnomalies($this->config['metrics']['detect'], $options);
                
                // 记录结果
                $results[$timeRange] = $detectionResult;
                
                // 检查是否发现异常
                foreach ($detectionResult as $metric => $result) {
                    if ($result['is_anomaly']) {
                        $anomaliesFound = true;
                        $this->log("发现异常: 指标={$metric}, 原因={$result['reason']}, 严重程度={$result['severity']}", 'warning');
                    }
                }
            }
            
            // 生成摘要报告
            $report = $this->generateReport($results, $anomaliesFound);
            
            $this->log('异常检测完成');
            
            return [
                'success' => true,
                'results' => $results,
                'anomalies_found' => $anomaliesFound,
                'report' => $report,
            ];
        } catch (Exception $e) {
            $this->log('异常检测运行失败: ' . $e->getMessage(), 'error');
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 生成检测报告
     * @param array $results 检测结果
     * @param bool $anomaliesFound 是否发现异常
     * @return array 报告内容
     */
    protected function generateReport($results, $anomaliesFound) {
        $anomalyCount = 0;
        $anomalies = [];
        $checkedMetrics = 0;
        
        // 统计异常情况
        foreach ($results as $timeRange => $detectionResult) {
            foreach ($detectionResult as $metric => $result) {
                $checkedMetrics++;
                
                if ($result['is_anomaly']) {
                    $anomalyCount++;
                    $anomalies[] = [
                        'metric' => $metric,
                        'time_range' => $timeRange,
                        'severity' => $result['severity'],
                        'reason' => $result['reason'],
                        'current_value' => $result['current_value'],
                        'timestamp' => $result['timestamp'],
                    ];
                }
            }
        }
        
        // 生成报告
        $report = [
            'timestamp' => time(),
            'summary' => [
                'checked_metrics' => $checkedMetrics,
                'anomaly_count' => $anomalyCount,
                'status' => $anomaliesFound ? 'warning' : 'normal',
                'detection_time' => date('Y-m-d H:i:s'),
            ],
            'anomalies' => $anomalies,
        ];
        
        // 保存报告
        $this->saveReport($report);
        
        return $report;
    }
    
    /**
     * 保存报告
     * @param array $report 报告内容
     */
    protected function saveReport($report) {
        try {
            // 确保报告目录存在
            $reportDir = 'reports/anomaly_detection';
            if (!is_dir($reportDir)) {
                mkdir($reportDir, 0755, true);
            }
            
            // 生成文件名
            $filename = $reportDir . '/' . date('Ymd_His') . '_report.json';
            
            // 保存报告
            file_put_contents($filename, json_encode($report, JSON_PRETTY_PRINT));
            
            $this->log("报告已保存: {$filename}", 'info');
        } catch (Exception $e) {
            $this->log("保存报告失败: " . $e->getMessage(), 'error');
        }
    }
    
    /**
     * 记录日志
     * @param string $message 日志消息
     * @param string $level 日志级别
     */
    protected function log($message, $level = 'info') {
        if (!$this->config['log']['enabled']) {
            return;
        }
        
        // 检查日志级别
        $levels = ['debug', 'info', 'warning', 'error'];
        $currentLevelIndex = array_search($this->config['log']['level'], $levels);
        $messageLevelIndex = array_search($level, $levels);
        
        if ($messageLevelIndex < $currentLevelIndex) {
            return;
        }
        
        // 格式化日志消息
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] [{$level}] {$message}\n";
        
        // 写入日志文件
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
        
        // 如果是命令行运行，输出到控制台
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }
}

// 运行定时任务
if (php_sapi_name() === 'cli') {
    // 命令行参数处理
    $options = getopt('c:l:h', ['config:', 'log:', 'help']);
    
    // 显示帮助信息
    if (isset($options['h']) || isset($options['help'])) {
        echo "用法: php run_anomaly_detection.php [选项]\n";
        echo "选项:\n";
        echo "  -c, --config <文件>  指定配置文件路径\n";
        echo "  -l, --log <级别>     设置日志级别 (debug, info, warning, error)\n";
        echo "  -h, --help           显示帮助信息\n";
        exit(0);
    }
    
    // 加载配置文件
    $config = [];
    if (isset($options['c']) || isset($options['config'])) {
        $configFile = isset($options['c']) ? $options['c'] : $options['config'];
        if (file_exists($configFile)) {
            $config = include $configFile;
        } else {
            echo "错误: 配置文件不存在: {$configFile}\n";
            exit(1);
        }
    }
    
    // 设置日志级别
    if (isset($options['l']) || isset($options['log'])) {
        $logLevel = isset($options['l']) ? $options['l'] : $options['log'];
        if (in_array($logLevel, ['debug', 'info', 'warning', 'error'])) {
            $config['log']['level'] = $logLevel;
        } else {
            echo "错误: 无效的日志级别: {$logLevel}\n";
            exit(1);
        }
    }
    
    // 创建并运行异常检测任务
    try {
        $cron = new AnomalyDetectionCron($config);
        $result = $cron->run();
        
        // 输出结果摘要
        if ($result['success']) {
            $anomalyCount = $result['report']['summary']['anomaly_count'] ?? 0;
            echo "\n异常检测完成: \n";
            echo "- 检查指标数: {$result['report']['summary']['checked_metrics']}\n";
            echo "- 发现异常数: {$anomalyCount}\n";
            echo "- 状态: " . ($result['anomalies_found'] ? '警告' : '正常') . "\n";
            echo "- 报告保存路径: reports/anomaly_detection/{$result['report']['summary']['detection_time']}.json\n";
            exit($result['anomalies_found'] ? 2 : 0);
        } else {
            echo "\n异常检测失败: {$result['error']}\n";
            exit(1);
        }
    } catch (Exception $e) {
        echo "\n运行异常: " . $e->getMessage() . "\n";
        exit(1);
    }
}