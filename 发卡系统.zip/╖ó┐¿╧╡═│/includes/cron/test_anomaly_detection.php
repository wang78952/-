<?php
/**
 * 异常波动检测测试脚本
 * 用于验证异常检测功能是否正常工作
 */

// 引入异常检测类和配置
require_once __DIR__ . '/../monitoring/AnomalyDetection.php';
$config = require_once __DIR__ . '/../config/anomaly_detection.php';

class AnomalyDetectionTester {
    /**
     * 异常检测实例
     * @var AnomalyDetection
     */
    protected $anomalyDetector = null;
    
    /**
     * 配置信息
     * @var array
     */
    protected $config = [];
    
    /**
     * 测试结果
     * @var array
     */
    protected $results = [];
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    public function __construct($config = []) {
        $this->config = $config;
        $this->results = [
            'passed' => 0,
            'failed' => 0,
            'total' => 0,
            'tests' => [],
        ];
    }
    
    /**
     * 初始化异常检测器
     * @return bool
     */
    public function initialize() {
        try {
            $this->anomalyDetector = AnomalyDetection::getInstance();
            return true;
        } catch (Exception $e) {
            echo "初始化异常检测器失败: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * 运行所有测试
     */
    public function runAllTests() {
        if (!$this->initialize()) {
            return $this->results;
        }
        
        echo "==============================================\n";
        echo "开始运行异常检测测试...\n";
        echo "==============================================\n";
        
        // 运行各项测试
        $this->testMetricsCollection();
        $this->testThresholdDetection();
        $this->testStatisticalDetection();
        $this->testNotificationSystem();
        $this->testConfigurationLoading();
        $this->testPerformance();
        
        // 显示测试结果摘要
        $this->displaySummary();
        
        return $this->results;
    }
    
    /**
     * 测试指标收集
     */
    protected function testMetricsCollection() {
        echo "\n测试指标收集功能...\n";
        
        try {
            // 获取所有支持的指标
            $supportedMetrics = $this->anomalyDetector->getSupportedMetrics();
            
            // 测试获取当前指标值
            $currentMetrics = $this->anomalyDetector->getCurrentMetrics();
            
            $this->addTestResult('metrics_collection', true, [
                'supported_count' => count($supportedMetrics),
                'collected_count' => count($currentMetrics),
                'metrics' => array_keys($currentMetrics),
            ]);
            
            echo "✓ 指标收集测试通过\n";
        } catch (Exception $e) {
            $this->addTestResult('metrics_collection', false, ['error' => $e->getMessage()]);
            echo "✗ 指标收集测试失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 测试阈值检测
     */
    protected function testThresholdDetection() {
        echo "\n测试阈值检测功能...\n";
        
        try {
            // 模拟异常指标
            $testMetrics = [
                'sales' => [
                    'current' => 500,  // 低于配置的阈值1000
                    'expected_anomaly' => true,
                ],
                'error_rate' => [
                    'current' => 0.06,  // 高于配置的阈值0.05
                    'expected_anomaly' => true,
                ],
                'normal_metric' => [
                    'current' => 100,
                    'expected_anomaly' => false,
                ],
            ];
            
            $results = [];
            $allPassed = true;
            
            foreach ($testMetrics as $metric => $data) {
                // 使用阈值算法检测
                $detectionResult = $this->anomalyDetector->detectAnomalies([$metric], [
                    'algorithm' => 'threshold',
                    'simulation' => true,
                    'simulated_value' => $data['current'],
                ]);
                
                $isAnomaly = isset($detectionResult[$metric]['is_anomaly']) && $detectionResult[$metric]['is_anomaly'];
                $passed = ($isAnomaly === $data['expected_anomaly']);
                $allPassed = $allPassed && $passed;
                
                $results[$metric] = [
                    'value' => $data['current'],
                    'detected' => $isAnomaly,
                    'expected' => $data['expected_anomaly'],
                    'passed' => $passed,
                ];
            }
            
            $this->addTestResult('threshold_detection', $allPassed, ['results' => $results]);
            
            if ($allPassed) {
                echo "✓ 阈值检测测试通过\n";
            } else {
                echo "✗ 阈值检测测试失败\n";
                foreach ($results as $metric => $result) {
                    if (!$result['passed']) {
                        echo "  - {$metric}: 期望值={$result['expected']}, 实际值={$result['detected']}\n";
                    }
                }
            }
        } catch (Exception $e) {
            $this->addTestResult('threshold_detection', false, ['error' => $e->getMessage()]);
            echo "✗ 阈值检测测试失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 测试统计检测
     */
    protected function testStatisticalDetection() {
        echo "\n测试统计检测功能...\n";
        
        try {
            // 使用统计算法检测
            $detectionResult = $this->anomalyDetector->detectAnomalies([], [
                'algorithm' => 'statistical',
                'simulation' => true,
                'time_range' => 'last_7_days',
            ]);
            
            $this->addTestResult('statistical_detection', true, [
                'metrics_count' => count($detectionResult),
                'sample_result' => array_slice($detectionResult, 0, 1),
            ]);
            
            echo "✓ 统计检测测试通过\n";
        } catch (Exception $e) {
            $this->addTestResult('statistical_detection', false, ['error' => $e->getMessage()]);
            echo "✗ 统计检测测试失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 测试通知系统
     */
    protected function testNotificationSystem() {
        echo "\n测试通知系统功能...\n";
        
        try {
            // 测试通知系统（不发送实际通知）
            $testAnomaly = [
                'metric' => 'test_metric',
                'current_value' => 9999,
                'normal_range' => '100-500',
                'severity' => 'high',
                'reason' => '测试异常',
                'algorithm' => 'threshold',
                'timestamp' => date('Y-m-d H:i:s'),
            ];
            
            $notificationResult = $this->anomalyDetector->testNotification($testAnomaly, true);
            
            $this->addTestResult('notification_system', true, [
                'channels' => array_keys($notificationResult),
                'success' => $notificationResult,
            ]);
            
            echo "✓ 通知系统测试通过\n";
        } catch (Exception $e) {
            $this->addTestResult('notification_system', false, ['error' => $e->getMessage()]);
            echo "✗ 通知系统测试失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 测试配置加载
     */
    protected function testConfigurationLoading() {
        echo "\n测试配置加载功能...\n";
        
        try {
            // 检查配置是否包含必要字段
            $requiredFields = ['algorithms', 'metrics', 'notifications', 'global'];
            $missingFields = [];
            
            foreach ($requiredFields as $field) {
                if (!isset($this->config[$field])) {
                    $missingFields[] = $field;
                }
            }
            
            $testPassed = empty($missingFields);
            
            $this->addTestResult('configuration_loading', $testPassed, [
                'missing_fields' => $missingFields,
                'config_keys' => array_keys($this->config),
            ]);
            
            if ($testPassed) {
                echo "✓ 配置加载测试通过\n";
            } else {
                echo "✗ 配置加载测试失败，缺少必要配置字段: " . implode(', ', $missingFields) . "\n";
            }
        } catch (Exception $e) {
            $this->addTestResult('configuration_loading', false, ['error' => $e->getMessage()]);
            echo "✗ 配置加载测试失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 测试性能
     */
    protected function testPerformance() {
        echo "\n测试性能...\n";
        
        try {
            // 测量检测速度
            $startTime = microtime(true);
            $detectionResult = $this->anomalyDetector->detectAnomalies([], [
                'algorithm' => 'threshold',
                'simulation' => true,
                'time_range' => 'today',
            ]);
            $endTime = microtime(true);
            
            $duration = $endTime - $startTime;
            $isFastEnough = ($duration < 1.0); // 应该在1秒内完成
            
            $this->addTestResult('performance', $isFastEnough, [
                'duration_ms' => round($duration * 1000, 2),
                'metrics_count' => count($detectionResult),
                'speed_per_metric_ms' => count($detectionResult) > 0 ? 
                    round(($duration * 1000) / count($detectionResult), 2) : 0,
            ]);
            
            if ($isFastEnough) {
                echo "✓ 性能测试通过 (耗时: " . round($duration * 1000, 2) . "ms)\n";
            } else {
                echo "✗ 性能测试失败 (耗时: " . round($duration * 1000, 2) . "ms > 1000ms)\n";
            }
        } catch (Exception $e) {
            $this->addTestResult('performance', false, ['error' => $e->getMessage()]);
            echo "✗ 性能测试失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 添加测试结果
     */
    protected function addTestResult($testName, $passed, $details = []) {
        $this->results['total']++;
        
        if ($passed) {
            $this->results['passed']++;
        } else {
            $this->results['failed']++;
        }
        
        $this->results['tests'][] = [
            'name' => $testName,
            'passed' => $passed,
            'details' => $details,
        ];
    }
    
    /**
     * 显示测试结果摘要
     */
    protected function displaySummary() {
        echo "\n==============================================\n";
        echo "测试结果摘要:\n";
        echo "==============================================\n";
        echo "总测试数: {$this->results['total']}\n";
        echo "通过: {$this->results['passed']}\n";
        echo "失败: {$this->results['failed']}\n";
        echo "通过率: " . round(($this->results['passed'] / $this->results['total']) * 100, 2) . "%\n";
        echo "==============================================\n";
        
        // 显示失败的测试
        if ($this->results['failed'] > 0) {
            echo "\n失败的测试详情:\n";
            foreach ($this->results['tests'] as $test) {
                if (!$test['passed']) {
                    echo "- {$test['name']}: " . ($test['details']['error'] ?? '未知错误') . "\n";
                }
            }
        }
    }
    
    /**
     * 生成测试报告
     */
    public function generateReport() {
        // 确保报告目录存在
        $reportDir = 'reports/test_results';
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }
        
        // 生成报告文件名
        $filename = $reportDir . '/' . date('Ymd_His') . '_test_report.json';
        
        // 添加报告元数据
        $report = [
            'timestamp' => date('Y-m-d H:i:s'),
            'results' => $this->results,
            'system_info' => [
                'php_version' => phpversion(),
                'memory_limit' => ini_get('memory_limit'),
                'max_execution_time' => ini_get('max_execution_time'),
            ],
        ];
        
        // 保存报告
        file_put_contents($filename, json_encode($report, JSON_PRETTY_PRINT));
        
        echo "\n测试报告已保存到: {$filename}\n";
        
        return $filename;
    }
}

// 运行测试
$tester = new AnomalyDetectionTester($config);
$results = $tester->runAllTests();

// 生成报告
$tester->generateReport();

// 返回退出代码
exit($results['failed'] > 0 ? 1 : 0);