<?php
/**
 * 授权验证和服务器检测模块
 * 用于检测代码是否被非法上传到未经授权的服务器
 * 
 * Copyright © 2025 远
 * 未经许可不得擅自修改或分发此代码
 */

class LicenseValidator {
    // 授权域名列表（白名单）
    private static $authorizedDomains = [
        'localhost',
        '127.0.0.1',
        // 可以在这里添加授权的域名
    ];
    
    // 授权IP列表（白名单）
    private static $authorizedIPs = [
        '127.0.0.1',
        '::1',
        // 可以在这里添加授权的IP地址
    ];
    
    /**
     * 检查当前服务器是否被授权
     * @return bool 是否被授权
     */
    public static function isAuthorizedServer() {
        $serverDomain = $_SERVER['HTTP_HOST'] ?? '';
        $serverIP = $_SERVER['SERVER_ADDR'] ?? '';
        
        // 移除端口号
        $serverDomain = preg_replace('/:\d+$/', '', $serverDomain);
        
        // 检查域名是否在授权列表中
        if (in_array($serverDomain, self::$authorizedDomains)) {
            return true;
        }
        
        // 检查IP是否在授权列表中
        if (in_array($serverIP, self::$authorizedIPs)) {
            return true;
        }
        
        // 如果是本地开发环境，允许运行
        if (self::isLocalDevelopmentEnvironment()) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 检查是否为本地开发环境
     * @return bool 是否为本地开发环境
     */
    private static function isLocalDevelopmentEnvironment() {
        $serverDomain = $_SERVER['HTTP_HOST'] ?? '';
        $serverIP = $_SERVER['SERVER_ADDR'] ?? '';
        
        // 移除端口号
        $serverDomain = preg_replace('/:\d+$/', '', $serverDomain);
        
        // 本地开发环境特征
        $localDomains = ['localhost', '127.0.0.1', '::1'];
        $localIPs = ['127.0.0.1', '::1'];
        
        return in_array($serverDomain, $localDomains) || in_array($serverIP, $localIPs);
    }
    
    /**
     * 获取服务器信息
     * @return array 服务器信息
     */
    public static function getServerInfo() {
        return [
            'domain' => $_SERVER['HTTP_HOST'] ?? '',
            'ip' => $_SERVER['SERVER_ADDR'] ?? '',
            'software' => $_SERVER['SERVER_SOFTWARE'] ?? '',
            'signature' => md5($_SERVER['HTTP_HOST'] ?? '' . $_SERVER['SERVER_ADDR'] ?? '')
        ];
    }
    
    /**
     * 验证许可证
     * @param string $licenseKey 许可证密钥
     * @return bool 是否有效
     */
    public static function validateLicense($licenseKey = '') {
        // 如果是本地环境，跳过许可证验证
        if (self::isLocalDevelopmentEnvironment()) {
            return true;
        }
        
        // 这里可以添加更复杂的许可证验证逻辑
        // 比如连接到授权服务器验证许可证有效性
        
        // 临时返回true以便测试
        return true;
    }
    
    /**
     * 记录未授权访问尝试
     */
    public static function logUnauthorizedAccess() {
        $logDir = __DIR__ . '/../logs';
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . '/unauthorized_access.log';
        $logEntry = date('Y-m-d H:i:s') . " - 未授权访问尝试\n";
        $logEntry .= "服务器域名: " . ($_SERVER['HTTP_HOST'] ?? 'N/A') . "\n";
        $logEntry .= "服务器IP: " . ($_SERVER['SERVER_ADDR'] ?? 'N/A') . "\n";
        $logEntry .= "客户端IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";
        $logEntry .= "请求URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A') . "\n";
        $logEntry .= "User Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'N/A') . "\n";
        $logEntry .= str_repeat('-', 50) . "\n";
        
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * 显示未授权访问错误页面
     */
    public static function showUnauthorizedError() {
        http_response_code(403);
        header('Content-Type: text/html; charset=utf-8');
        
        echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>访问被拒绝</title>
    <style>
        body {
            font-family: "Microsoft YaHei", Arial, sans-serif;
            background-color: #f5f5f5;
            text-align: center;
            padding: 50px;
        }
        .error-container {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 500px;
            margin: 0 auto;
        }
        .error-title {
            color: #e74c3c;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .error-message {
            color: #666;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-title">访问被拒绝</div>
        <div class="error-message">
            <p>检测到未授权的服务器访问。</p>
            <p>此软件只能在授权的服务器上运行。</p>
            <p>如果您是合法用户，请联系技术支持获取授权。</p>
        </div>
    </div>
</body>
</html>';
        exit;
    }
}

// 自动检查授权（除非在排除列表中）
$excludedFiles = ['license_validator.php', 'protect_core_files.php'];
$currentScript = basename($_SERVER['SCRIPT_FILENAME'] ?? '');

if (!in_array($currentScript, $excludedFiles)) {
    // 检查服务器授权
    if (!LicenseValidator::isAuthorizedServer()) {
        // 记录未授权访问
        LicenseValidator::logUnauthorizedAccess();
        
        // 显示错误页面
        LicenseValidator::showUnauthorizedError();
    }
}
?>