<?php

require_once __DIR__ . '/PaymentManager.php';

/**
 * 支付宝支付集成
 */
class AlipayPayment
{
    private $config;
    private $gateway;
    
    public function __construct($config)
    {
        $this->config = $config;
        $this->gateway = $config['sandbox'] ? 
            'https://openapi.alipaydev.com/gateway.do' : 
            'https://openapi.alipay.com/gateway.do';
    }
    
    /**
     * 创建支付订单
     */
    public function createOrder($params)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.page.pay',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'notify_url' => $params['notify_url'],
            'return_url' => $params['return_url'],
            'biz_content' => json_encode(array(
                'out_trade_no' => $params['out_trade_no'],
                'product_code' => 'FAST_INSTANT_TRADE_PAY',
                'total_amount' => number_format($params['total_amount'], 2, '.', ''),
                'subject' => $params['subject'],
                'body' => $params['subject'] . ' - 订单号：' . $params['out_trade_no']
            ))
        );
        
        // 生成签名
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        // 构建支付URL
        $paymentUrl = $this->gateway . '?' . http_build_query($requestParams);
        
        return array(
            'payment_url' => $paymentUrl,
            'out_trade_no' => $params['out_trade_no']
        );
    }
    
    /**
     * 创建手机网站支付订单
     */
    public function createWapOrder($params)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.wap.pay',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'notify_url' => $params['notify_url'],
            'return_url' => $params['return_url'],
            'biz_content' => json_encode(array(
                'out_trade_no' => $params['out_trade_no'],
                'product_code' => 'QUICK_WAP_WAY',
                'total_amount' => number_format($params['total_amount'], 2, '.', ''),
                'subject' => $params['subject'],
                'body' => $params['subject'] . ' - 订单号：' . $params['out_trade_no']
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $paymentUrl = $this->gateway . '?' . http_build_query($requestParams);
        
        return array(
            'payment_url' => $paymentUrl,
            'out_trade_no' => $params['out_trade_no']
        );
    }
    
    /**
     * 创建扫码支付订单
     */
    public function createQrOrder($params)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.precreate',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'notify_url' => $params['notify_url'],
            'biz_content' => json_encode(array(
                'out_trade_no' => $params['out_trade_no'],
                'total_amount' => number_format($params['total_amount'], 2, '.', ''),
                'subject' => $params['subject'],
                'body' => $params['subject'] . ' - 订单号：' . $params['out_trade_no']
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway, $requestParams);
        $result = json_decode($response, true);
        
        if ($result['alipay_trade_precreate_response']['code'] != '10000') {
            throw new Exception('支付宝扫码支付创建失败：' . $result['alipay_trade_precreate_response']['msg']);
        }
        
        return array(
            'qr_code' => $result['alipay_trade_precreate_response']['qr_code'],
            'out_trade_no' => $params['out_trade_no']
        );
    }
    
    /**
     * 查询支付状态
     */
    public function query($outTradeNo)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.query',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'biz_content' => json_encode(array(
                'out_trade_no' => $outTradeNo
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway, $requestParams);
        $result = json_decode($response, true);
        
        return $result['alipay_trade_query_response'];
    }
    
    /**
     * 申请退款
     */
    public function refund($params)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.refund',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'biz_content' => json_encode(array(
                'out_trade_no' => $params['out_trade_no'],
                'refund_no' => $params['refund_no'],
                'refund_amount' => number_format($params['refund_amount'], 2, '.', ''),
                'refund_reason' => isset($params['refund_reason']) ? $params['refund_reason'] : ''
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway, $requestParams);
        $result = json_decode($response, true);
        
        if ($result['alipay_trade_refund_response']['code'] != '10000') {
            throw new Exception('支付宝退款失败：' . $result['alipay_trade_refund_response']['msg']);
        }
        
        return $result['alipay_trade_refund_response'];
    }
    
    /**
     * 查询退款状态
     */
    public function queryRefund($refundNo)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.fastpay.refund.query',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'biz_content' => json_encode(array(
                'out_request_no' => $refundNo
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway, $requestParams);
        $result = json_decode($response, true);
        
        return $result['alipay_trade_fastpay_refund_query_response'];
    }
    
    /**
     * 关闭订单
     */
    public function close($outTradeNo)
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.trade.close',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'biz_content' => json_encode(array(
                'out_trade_no' => $outTradeNo
            ))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway, $requestParams);
        $result = json_decode($response, true);
        
        return $result['alipay_trade_close_response'];
    }
    
    /**
     * 验证回调签名
     */
    public function verifyCallback($data)
    {
        if (!isset($data['sign']) || !isset($data['sign_type'])) {
            return false;
        }
        
        $sign = $data['sign'];
        $signType = $data['sign_type'];
        
        // 移除签名参数
        $unsignedData = $data;
        unset($unsignedData['sign']);
        unset($unsignedData['sign_type']);
        
        // 排序参数
        ksort($unsignedData);
        
        // 生成待签名字符串
        $signString = $this->buildSignString($unsignedData);
        
        // 验证签名
        return $this->verifySign($signString, $sign, $signType);
    }
    
    /**
     * 过滤空值
     */
    private function filterEmptyValue($value)
    {
        return $value !== '' && $value !== null;
    }
    
    /**
     * 生成签名
     */
    private function generateSign($params)
    {
        // 移除空值参数
        $params = array_filter($params, array($this, 'filterEmptyValue'));
        
        // 排序参数
        ksort($params);
        
        // 生成待签名字符串
        $signString = $this->buildSignString($params);
        
        // 使用私钥签名
        $privateKey = $this->formatPrivateKey($this->config['private_key']);
        openssl_sign($signString, $signature, $privateKey, OPENSSL_ALGO_SHA256);
        
        return base64_encode($signature);
    }
    
    /**
     * 构建签名字符串
     */
    private function buildSignString($params)
    {
        $pairs = array();
        foreach ($params as $key => $value) {
            if (is_array($value)) {
                $value = json_encode($value);
            }
            array_push($pairs, $key . '=' . $value);
        }
        return implode('&', $pairs);
    }
    
    /**
     * 验证签名
     */
    private function verifySign($signString, $sign, $signType = 'RSA2')
    {
        $publicKey = $this->formatPublicKey($this->config['public_key']);
        $signature = base64_decode($sign);
        
        $algorithm = $signType === 'RSA2' ? OPENSSL_ALGO_SHA256 : OPENSSL_ALGO_SHA1;
        
        return openssl_verify($signString, $signature, $publicKey, $algorithm) === 1;
    }
    
    /**
     * 格式化私钥
     */
    private function formatPrivateKey($privateKey)
    {
        if (strpos($privateKey, '-----BEGIN PRIVATE KEY-----') === false) {
            $privateKey = "-----BEGIN PRIVATE KEY-----\n" . 
                         chunk_split($privateKey, 64, "\n") . 
                         "-----END PRIVATE KEY-----";
        }
        return $privateKey;
    }
    
    /**
     * 格式化公钥
     */
    private function formatPublicKey($publicKey)
    {
        if (strpos($publicKey, '-----BEGIN PUBLIC KEY-----') === false) {
            $publicKey = "-----BEGIN PUBLIC KEY-----\n" . 
                        chunk_split($publicKey, 64, "\n") . 
                        "-----END PUBLIC KEY-----";
        }
        return $publicKey;
    }
    
    /**
     * 发送HTTP请求
     */
    private function httpRequest($url, $params)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($response === false || !empty($error)) {
            throw new Exception('支付宝API请求失败：' . $error);
        }
        
        if ($httpCode !== 200) {
            throw new Exception('支付宝API请求失败，HTTP状态码：' . $httpCode);
        }
        
        return $response;
    }
    
    /**
     * 获取应用信息
     */
    public function getAppInfo()
    {
        $requestParams = array(
            'app_id' => $this->config['app_id'],
            'method' => 'alipay.open.app.info.query',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'biz_content' => json_encode(array('auth_app_id' => $this->config['app_id']))
        );
        
        $requestParams['sign'] = $this->generateSign($requestParams);
        
        $response = $this->httpRequest($this->gateway, $requestParams);
        $result = json_decode($response, true);
        
        return $result['alipay_open_app_info_query_response'];
    }
    
    /**
     * 1分钱测试支付
     * 创建一个0.01元的测试订单，用于验证支付配置是否正确
     */
    public function createTestPayment()
    {
        try {
            // 验证必要配置
            if (empty($this->config['app_id'])) {
                return array(
                    'success' => false,
                    'error_msg' => '缺少应用ID配置'
                );
            }
            
            if (empty($this->config['private_key'])) {
                return array(
                    'success' => false,
                    'error_msg' => '缺少应用私钥配置'
                );
            }
            
            // 生成测试订单号
            $testOrderNo = 'test_' . date('YmdHis') . '_' . mt_rand(1000, 9999);
            
            // 准备测试参数
            $params = array(
                'out_trade_no' => $testOrderNo,
                'total_amount' => 0.01,
                'subject' => '发卡系统支付测试',
                'notify_url' => $this->config['notify_url'] ?? '',
                'return_url' => $this->config['return_url'] ?? ''
            );
            
            // 创建测试订单
            $result = $this->createOrder($params);
            
            return array(
                'success' => true,
                'pay_url' => $result['payment_url'],
                'out_trade_no' => $result['out_trade_no'],
                'amount' => '0.01元'
            );
        } catch (Exception $e) {
            // 解析错误信息，提供更友好的错误提示
            $errorMsg = $e->getMessage();
            
            // 根据常见错误提供更具体的提示
            if (strpos($errorMsg, '签名验证失败') !== false) {
                $errorMsg = '密钥配置错误，请检查私钥是否正确';
            } elseif (strpos($errorMsg, '应用不存在') !== false) {
                $errorMsg = '应用ID不存在或已被禁用';
            } elseif (strpos($errorMsg, '商户不存在') !== false) {
                $errorMsg = '商户账号不存在或已被禁用';
            } elseif (strpos($errorMsg, 'H5') !== false && strpos($errorMsg, '未开通') !== false) {
                $errorMsg = 'H5支付功能未开通，请在支付宝开放平台开通';
            } elseif (strpos($errorMsg, '支付') !== false && strpos($errorMsg, '未开通') !== false) {
                $errorMsg = '支付功能未开通，请在支付宝开放平台开通';
            } elseif (strpos($errorMsg, '证书') !== false) {
                $errorMsg = '证书配置错误，请检查证书路径是否正确';
            }
            
            return array(
                'success' => false,
                'error_msg' => '测试支付失败：' . $errorMsg
            );
        }
    }
}