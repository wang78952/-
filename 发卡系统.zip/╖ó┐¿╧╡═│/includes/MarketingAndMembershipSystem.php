<?php
/**
 * 营销与会员体系系统类
 * 提供限时秒杀、会员等级与积分、社交分享裂变和邮件/短信营销自动化功能
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/User.php';
require_once __DIR__ . '/EmailService.php';
require_once __DIR__ . '/SMSService.php';

// 确保必要的常量被定义
if (!defined('SITE_NAME')) {
    define('SITE_NAME', '发卡系统');
}

if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost');
}

class MarketingAndMembershipSystem {
    private $db;
    private $logger;
    private $emailService;
    private $smsService;
    private $cache = [];
    private $cacheTimeout = 300; // 5分钟缓存

    /**
     * 构造函数
     */
    public function __construct() {
        $this->db = Database::getInstance();
        $this->logger = new Logger();
        $this->emailService = new EmailService();
        $this->smsService = new SMSService();
    }

    /**
     * 获取当前秒杀活动
     * 
     * @return array 当前秒杀活动列表
     */
    public function getActiveFlashSales() {
        try {
            $cacheKey = "active_flash_sales_" . date('YmdH');
            
            if (isset($this->cache[$cacheKey]) && (time() - $this->cache[$cacheKey]['timestamp']) < $this->cacheTimeout) {
                return $this->cache[$cacheKey]['data'];
            }

            // 获取当前正在进行的秒杀活动
            $query = "
                SELECT * FROM flash_sales 
                WHERE start_time <= NOW() AND end_time >= NOW() 
                AND status = 'active' 
                ORDER BY priority DESC
            ";

            $result = $this->db->query($query);
            $flashSales = [];

            while ($row = $result->fetch_assoc()) {
                // 获取秒杀活动的产品
                $productQuery = "
                    SELECT fsp.*, p.name as product_name, p.price as original_price, p.image_url 
                    FROM flash_sale_products fsp
                    JOIN products p ON fsp.product_id = p.id
                    WHERE fsp.flash_sale_id = {$row['id']}
                    AND fsp.stock > 0
                ";

                $productResult = $this->db->query($productQuery);
                $products = [];
                
                while ($product = $productResult->fetch_assoc()) {
                    $products[] = [
                        'product_id' => $product['product_id'],
                        'name' => $product['product_name'],
                        'original_price' => $product['original_price'],
                        'flash_price' => $product['price'],
                        'discount' => round((1 - ($product['price'] / $product['original_price'])) * 100),
                        'stock' => $product['stock'],
                        'max_per_user' => $product['max_per_user'],
                        'image_url' => $product['image_url'],
                        'sales_count' => $product['sales_count']
                    ];
                }

                $row['products'] = $products;
                $row['time_left'] = $this->calculateTimeLeft($row['end_time']);
                $row['time_progress'] = $this->calculateTimeProgress($row['start_time'], $row['end_time']);
                $flashSales[] = $row;
            }

            // 缓存结果
            $this->cache[$cacheKey] = [
                'data' => $flashSales,
                'timestamp' => time()
            ];

            return $flashSales;
        } catch (Exception $e) {
            $this->logger->error('获取秒杀活动失败', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * 创建秒杀活动
     * 
     * @param array $flashSaleData 秒杀活动数据
     * @return int 创建的活动ID或错误码
     */
    public function createFlashSale($flashSaleData) {
        try {
            $this->db->begin_transaction();

            // 验证活动数据
            if (empty($flashSaleData['name']) || empty($flashSaleData['start_time']) || empty($flashSaleData['end_time'])) {
                throw new Exception('秒杀活动必要字段缺失');
            }

            if (strtotime($flashSaleData['start_time']) >= strtotime($flashSaleData['end_time'])) {
                throw new Exception('开始时间必须早于结束时间');
            }

            // 插入秒杀活动
            $insertQuery = "
                INSERT INTO flash_sales (name, description, start_time, end_time, status, priority, created_at, updated_at)
                VALUES (?, ?, ?, ?, 'active', ?, NOW(), NOW())
            ";

            $stmt = $this->db->prepare($insertQuery);
            $stmt->bind_param(
                'ssssi',
                $flashSaleData['name'],
                $flashSaleData['description'] ?? '',
                $flashSaleData['start_time'],
                $flashSaleData['end_time'],
                $flashSaleData['priority'] ?? 0
            );
            $stmt->execute();
            $flashSaleId = $stmt->insert_id;
            $stmt->close();

            // 插入秒杀商品
            if (!empty($flashSaleData['products'])) {
                foreach ($flashSaleData['products'] as $product) {
                    // 验证商品是否存在且库存充足
                    $productInfo = $this->db->query("SELECT stock, price FROM products WHERE id = ?", [$product['product_id']])->fetch_assoc();
                    if (!$productInfo) {
                        throw new Exception("商品ID {$product['product_id']} 不存在");
                    }

                    if ($productInfo['stock'] < $product['stock']) {
                        throw new Exception("商品库存不足");
                    }

                    // 检查折扣是否合理（最低不低于原价的10%）
                    if ($product['price'] < $productInfo['price'] * 0.1) {
                        throw new Exception("折扣过低，最低不低于原价的10%");
                    }

                    $productStmt = $this->db->prepare("INSERT INTO flash_sale_products (flash_sale_id, product_id, price, stock, max_per_user, sales_count)
                                            VALUES (?, ?, ?, ?, ?, 0)");
                    $productStmt->bind_param(
                        'iidii',
                        $flashSaleId,
                        $product['product_id'],
                        $product['price'],
                        $product['stock'],
                        $product['max_per_user'] ?? 1
                    );
                    $productStmt->execute();
                    $productStmt->close();

                    // 锁定秒杀库存
                    $this->db->query("UPDATE products SET stock = stock - ?, flash_sale_stock = flash_sale_stock + ? WHERE id = ?", [$product['stock'], $product['stock'], $product['product_id']]);
                }
            }

            $this->db->commit();
            
            // 清除缓存
            $this->clearFlashSaleCache();

            // 发送活动通知
            if (!empty($flashSaleData['notify_users'])) {
                $this->notifyUsersAboutFlashSale($flashSaleId);
            }

            return $flashSaleId;
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error('创建秒杀活动失败', ['error' => $e->getMessage(), 'data' => $flashSaleData]);
            return -1;
        }
    }

    /**
     * 处理秒杀订单
     * 
     * @param int $userId 用户ID
     * @param int $flashSaleProductId 秒杀商品ID
     * @param int $quantity 购买数量
     * @return array 处理结果
     */
    public function processFlashSaleOrder($userId, $flashSaleProductId, $quantity = 1) {
        try {
            // 使用事务和行锁确保并发安全
            $this->db->begin_transaction();

            // 检查秒杀商品信息，使用行锁
            $productInfo = $this->db->query("SELECT fsp.*, fs.status, fs.start_time, fs.end_time 
                                            FROM flash_sale_products fsp
                                            JOIN flash_sales fs ON fsp.flash_sale_id = fs.id
                                            WHERE fsp.id = ? 
                                            FOR UPDATE", [$flashSaleProductId])->fetch_assoc();

            if (!$productInfo) {
                throw new Exception('秒杀商品不存在');
            }

            // 检查秒杀活动是否有效
            if ($productInfo['status'] !== 'active' || 
                strtotime($productInfo['start_time']) > time() || 
                strtotime($productInfo['end_time']) < time()) {
                throw new Exception('秒杀活动已结束或未开始');
            }

            // 检查库存
            if ($productInfo['stock'] < $quantity) {
                throw new Exception('库存不足');
            }

            // 检查用户限购
            $userCount = $this->db->query("SELECT COUNT(*) as count FROM flash_sale_orders 
                                         WHERE user_id = ? AND flash_sale_product_id = ?", [$userId, $flashSaleProductId])->fetch_assoc()['count'];

            if ($userCount >= $productInfo['max_per_user']) {
                throw new Exception('超过限购数量');
            }

            // 生成订单
            $orderId = $this->createOrder($userId, $productInfo['product_id'], $productInfo['price'], $quantity, 'flash_sale');

            // 更新秒杀商品库存和销量
            $this->db->query("UPDATE flash_sale_products SET stock = stock - ?, sales_count = sales_count + ? WHERE id = ?", [$quantity, $quantity, $flashSaleProductId]);

            // 记录秒杀订单
            $this->db->query("INSERT INTO flash_sale_orders (user_id, flash_sale_id, flash_sale_product_id, order_id, quantity, created_at)
                             VALUES (?, ?, ?, ?, ?, NOW())", [$userId, $productInfo['flash_sale_id'], $flashSaleProductId, $orderId, $quantity]);

            $this->db->commit();

            // 清除相关缓存
            $this->clearFlashSaleCache();

            return ['success' => true, 'order_id' => $orderId];
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error('处理秒杀订单失败', ['error' => $e->getMessage(), 'user_id' => $userId, 'product_id' => $flashSaleProductId]);
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * 获取用户会员信息
     * 
     * @param int $userId 用户ID
     * @return array 用户会员信息
     */
    public function getUserMembershipInfo($userId) {
        try {
            $cacheKey = "user_membership_{$userId}";
            
            if (isset($this->cache[$cacheKey]) && (time() - $this->cache[$cacheKey]['timestamp']) < $this->cacheTimeout) {
                return $this->cache[$cacheKey]['data'];
            }

            // 获取用户会员信息
            $userInfo = $this->db->query("SELECT u.*, m.level_name, m.discount_rate, m.description as level_description 
                                        FROM users u
                                        LEFT JOIN membership_levels m ON u.membership_level = m.level_id
                                        WHERE u.id = ?", [$userId])->fetch_assoc();

            if (!$userInfo) {
                return null;
            }

            // 获取用户积分历史
            $pointsHistory = $this->db->query("SELECT * FROM user_points_history 
                                             WHERE user_id = ? 
                                             ORDER BY created_at DESC 
                                             LIMIT 20", [$userId])->fetch_all(MYSQLI_ASSOC);

            // 获取下一级别所需积分
            $nextLevel = $this->db->query("SELECT level_id, level_name, min_points, discount_rate 
                                         FROM membership_levels 
                                         WHERE min_points > {$userInfo['points']} 
                                         ORDER BY min_points ASC 
                                         LIMIT 1")->fetch_assoc();

            $data = [
                'user_id' => $userInfo['id'],
                'username' => $userInfo['username'],
                'current_level' => $userInfo['level_name'] ?? '普通用户',
                'current_points' => $userInfo['points'],
                'discount_rate' => $userInfo['discount_rate'] ?? 0,
                'level_description' => $userInfo['level_description'] ?? '',
                'join_date' => $userInfo['created_at'],
                'points_history' => $pointsHistory,
                'next_level' => $nextLevel,
                'points_to_next_level' => $nextLevel ? $nextLevel['min_points'] - $userInfo['points'] : 0
            ];

            // 缓存结果
            $this->cache[$cacheKey] = [
                'data' => $data,
                'timestamp' => time()
            ];

            return $data;
        } catch (Exception $e) {
            $this->logger->error('获取用户会员信息失败', ['error' => $e->getMessage(), 'user_id' => $userId]);
            return null;
        }
    }

    /**
     * 更新用户积分
     * 
     * @param int $userId 用户ID
     * @param int $points 积分变化量（可正可负）
     * @param string $reason 积分变更原因
     * @return bool 是否更新成功
     */
    public function updateUserPoints($userId, $points, $reason) {
        try {
            $this->db->begin_transaction();

            // 获取当前积分
            $currentPoints = $this->db->query("SELECT points FROM users WHERE id = ?", [$userId])->fetch_assoc()['points'];
            $newPoints = $currentPoints + $points;

            if ($newPoints < 0) {
                throw new Exception('积分不足');
            }

            // 更新用户积分
            $this->db->query("UPDATE users SET points = ? WHERE id = ?", [$newPoints, $userId]);

            // 记录积分历史
            $this->db->query("INSERT INTO user_points_history (user_id, points_change, balance_after, reason, created_at)
                             VALUES (?, ?, ?, ?, NOW())", [$userId, $points, $newPoints, $reason]);

            // 检查是否需要升级会员等级
            $this->checkAndUpgradeMembershipLevel($userId, $newPoints);

            $this->db->commit();

            // 清除缓存
            unset($this->cache["user_membership_{$userId}"]);

            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error('更新用户积分失败', ['error' => $e->getMessage(), 'user_id' => $userId, 'points' => $points]);
            return false;
        }
    }

    /**
     * 检查并升级会员等级
     * 
     * @param int $userId 用户ID
     * @param int $currentPoints 当前积分
     */
    private function checkAndUpgradeMembershipLevel($userId, $currentPoints) {
        // 获取可能的升级等级
        $newLevel = $this->db->query("SELECT level_id, level_name, discount_rate 
                                    FROM membership_levels 
                                    WHERE min_points <= {$currentPoints} 
                                    ORDER BY min_points DESC 
                                    LIMIT 1")->fetch_assoc();

        if ($newLevel) {
            // 获取用户当前等级
            $currentLevel = $this->db->query("SELECT membership_level FROM users WHERE id = ?", [$userId])->fetch_assoc()['membership_level'];

            // 如果等级有变化，进行升级
            if ($currentLevel != $newLevel['level_id']) {
                $this->db->query("UPDATE users SET membership_level = ? WHERE id = ?", [$newLevel['level_id'], $userId]);
                
                // 记录升级历史
                $this->db->query("INSERT INTO user_membership_history (user_id, old_level_id, new_level_id, created_at)
                                 VALUES (?, ?, ?, NOW())", [$userId, ($currentLevel ?: 0), $newLevel['level_id']]);

                // 发送升级通知
                $this->sendMembershipUpgradeNotification($userId, $newLevel['level_name']);
            }
        }
    }

    /**
     * 创建社交分享活动
     * 
     * @param array $shareData 分享活动数据
     * @return int 活动ID
     */
    public function createSocialShareCampaign($shareData) {
        try {
            $this->db->begin_transaction();

            // 生成分享活动
            $insertQuery = "
                INSERT INTO social_share_campaigns (name, description, reward_points, reward_type, start_time, end_time, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())
            ";

            $stmt = $this->db->prepare($insertQuery);
            $stmt->bind_param(
                'ssssss',
                $shareData['name'],
                $shareData['description'] ?? '',
                $shareData['reward_points'] ?? 0,
                $shareData['reward_type'] ?? 'points',
                $shareData['start_time'] ?? date('Y-m-d H:i:s'),
                $shareData['end_time'] ?? date('Y-m-d H:i:s', strtotime('+30 days'))
            );
            $stmt->execute();
            $campaignId = $stmt->insert_id;
            $stmt->close();

            // 生成唯一分享码
            $shareCode = $this->generateShareCode($campaignId);
            $this->db->query("UPDATE social_share_campaigns SET share_code = ? WHERE id = ?", [$shareCode, $campaignId]);

            $this->db->commit();
            return $campaignId;
        } catch (Exception $e) {
            $this->db->rollback();
            $this->logger->error('创建社交分享活动失败', ['error' => $e->getMessage(), 'data' => $shareData]);
            return -1;
        }
    }

    /**
     * 处理社交分享
     * 
     * @param int $userId 用户ID
     * @param int $campaignId 活动ID
     * @return array 分享结果
     */
    public function processSocialShare($userId, $campaignId) {
        try {
            // 检查活动是否有效
            $campaignInfo = $this->db->query("SELECT * FROM social_share_campaigns 
                                            WHERE id = {$campaignId} AND status = 'active'")->fetch_assoc();

            if (!$campaignInfo) {
                throw new Exception('分享活动不存在或已结束');
            }

            // 检查用户是否已分享
            $existingShare = $this->db->query("SELECT * FROM social_shares 
                                             WHERE user_id = {$userId} AND campaign_id = {$campaignId}")->fetch_assoc();

            if ($existingShare) {
                // 如果已分享，返回现有分享链接
                return [
                    'success' => true,
                    'share_link' => $existingShare['share_link'],
                    'share_code' => $existingShare['share_code'],
                    'already_shared' => true
                ];
            }

            // 生成唯一分享码和链接
            $shareCode = $this->generateUserShareCode($userId, $campaignId);
            $shareLink = SITE_URL . "/share/{$campaignId}/{$shareCode}";

            // 记录分享
            $this->db->query("INSERT INTO social_shares (user_id, campaign_id, share_code, share_link, created_at)
                             VALUES ({$userId}, {$campaignId}, '{$shareCode}', '{$shareLink}', NOW())");

            // 给分享者奖励
            if ($campaignInfo['reward_points'] > 0) {
                $this->updateUserPoints($userId, $campaignInfo['reward_points'], "参与分享活动奖励");
            }

            return [
                'success' => true,
                'share_link' => $shareLink,
                'share_code' => $shareCode,
                'already_shared' => false,
                'reward_points' => $campaignInfo['reward_points']
            ];
        } catch (Exception $e) {
            $this->logger->error('处理社交分享失败', ['error' => $e->getMessage(), 'user_id' => $userId, 'campaign_id' => $campaignId]);
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * 处理分享回流
     * 
     * @param string $shareCode 分享码
     * @param int $newUserId 新用户ID
     * @return array 回流结果
     */
    public function processShareRedemption($shareCode, $newUserId) {
        try {
            // 查找分享记录
            $shareInfo = $this->db->query("SELECT ss.*, ssc.reward_points, ssc.id as campaign_id 
                                         FROM social_shares ss
                                         JOIN social_share_campaigns ssc ON ss.campaign_id = ssc.id
                                         WHERE ss.share_code = '{$shareCode}'")->fetch_assoc();

            if (!$shareInfo) {
                throw new Exception('无效的分享码');
            }

            // 检查是否已经被兑换
            $existingRedemption = $this->db->query("SELECT * FROM share_redemptions 
                                                  WHERE share_id = {$shareInfo['id']} AND new_user_id = {$newUserId}")->fetch_assoc();

            if ($existingRedemption) {
                throw new Exception('该分享码已被此用户兑换');
            }

            // 检查是否是自己分享给自己
            if ($shareInfo['user_id'] == $newUserId) {
                throw new Exception('不能使用自己的分享码');
            }

            // 记录兑换
            $this->db->query("INSERT INTO share_redemptions (share_id, campaign_id, new_user_id, created_at)
                             VALUES ({$shareInfo['id']}, {$shareInfo['campaign_id']}, {$newUserId}, NOW())");

            // 给新用户奖励
            $newUserReward = $shareInfo['reward_points'] * 2; // 新用户获得双倍奖励
            $this->updateUserPoints($newUserId, $newUserReward, "通过分享注册奖励");

            // 给分享者额外奖励
            $this->updateUserPoints($shareInfo['user_id'], $shareInfo['reward_points'], "分享邀请成功奖励");

            return [
                'success' => true,
                'new_user_reward' => $newUserReward,
                'referrer_reward' => $shareInfo['reward_points'],
                'referrer_user_id' => $shareInfo['user_id']
            ];
        } catch (Exception $e) {
            $this->logger->error('处理分享回流失败', ['error' => $e->getMessage(), 'share_code' => $shareCode, 'new_user_id' => $newUserId]);
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * 创建邮件营销活动
     * 
     * @param array $campaignData 营销活动数据
     * @return int 活动ID
     */
    public function createEmailCampaign($campaignData) {
        try {
            // 验证活动数据
            if (empty($campaignData['name']) || empty($campaignData['subject']) || empty($campaignData['content'])) {
                throw new Exception('必要字段缺失');
            }

            // 插入活动
            $scheduledAt = isset($campaignData['scheduled_at']) ? $campaignData['scheduled_at'] : 'NOW()';
            $this->db->query("INSERT INTO email_campaigns (name, subject, content, status, created_at, scheduled_at)
                            VALUES ('{$campaignData['name']}', '{$campaignData['subject']}', '{$campaignData['content']}', 
                            'pending', NOW(), $scheduledAt)");

            $campaignId = $this->db->insert_id;

            // 处理发送对象
            if (!empty($campaignData['target_users'])) {
                foreach ($campaignData['target_users'] as $userId) {
                    $this->db->query("INSERT INTO email_campaign_recipients (campaign_id, user_id, status)
                                    VALUES ({$campaignId}, {$userId}, 'pending')");
                }
            } elseif (!empty($campaignData['target_segment'])) {
                // 根据分群获取用户
                $users = $this->getUsersBySegment($campaignData['target_segment']);
                foreach ($users as $user) {
                    $this->db->query("INSERT INTO email_campaign_recipients (campaign_id, user_id, status)
                                    VALUES ({$campaignId}, {$user['id']}, 'pending')");
                }
            }

            // 如果是立即发送
            if (empty($campaignData['scheduled_at']) || strtotime($campaignData['scheduled_at']) <= time()) {
                $this->processEmailCampaign($campaignId);
            }

            return $campaignId;
        } catch (Exception $e) {
            $this->logger->error('创建邮件营销活动失败', ['error' => $e->getMessage(), 'data' => $campaignData]);
            return -1;
        }
    }

    /**
     * 创建短信营销活动
     * 
     * @param array $campaignData 营销活动数据
     * @return int 活动ID
     */
    public function createSMSCampaign($campaignData) {
        try {
            // 验证活动数据
            if (empty($campaignData['name']) || empty($campaignData['content'])) {
                throw new Exception('必要字段缺失');
            }

            // 插入活动
            $scheduledAt = isset($campaignData['scheduled_at']) ? $campaignData['scheduled_at'] : 'NOW()';
            $this->db->query("INSERT INTO sms_campaigns (name, content, status, created_at, scheduled_at)
                            VALUES ('{$campaignData['name']}', '{$campaignData['content']}', 
                            'pending', NOW(), $scheduledAt)");

            $campaignId = $this->db->insert_id;

            // 处理发送对象
            if (!empty($campaignData['target_users'])) {
                foreach ($campaignData['target_users'] as $userId) {
                    $this->db->query("INSERT INTO sms_campaign_recipients (campaign_id, user_id, status)
                                    VALUES ({$campaignId}, {$userId}, 'pending')");
                }
            } elseif (!empty($campaignData['target_segment'])) {
                // 根据分群获取用户
                $users = $this->getUsersBySegment($campaignData['target_segment']);
                foreach ($users as $user) {
                    $this->db->query("INSERT INTO sms_campaign_recipients (campaign_id, user_id, status)
                                    VALUES ({$campaignId}, {$user['id']}, 'pending')");
                }
            }

            // 如果是立即发送
            if (empty($campaignData['scheduled_at']) || strtotime($campaignData['scheduled_at']) <= time()) {
                $this->processSMSCampaign($campaignId);
            }

            return $campaignId;
        } catch (Exception $e) {
            $this->logger->error('创建短信营销活动失败', ['error' => $e->getMessage(), 'data' => $campaignData]);
            return -1;
        }
    }

    /**
     * 处理邮件营销活动发送
     * 
     * @param int $campaignId 活动ID
     */
    private function processEmailCampaign($campaignId) {
        try {
            // 获取活动信息
            $campaignInfo = $this->db->query("SELECT * FROM email_campaigns WHERE id = ?", [$campaignId])->fetch_assoc();
            if (!$campaignInfo) return;

            // 更新活动状态
            $this->db->query("UPDATE email_campaigns SET status = 'sending' WHERE id = ?", [$campaignId]);

            // 获取待发送的用户
            $recipients = $this->db->query("SELECT r.*, u.email, u.username FROM email_campaign_recipients r
                                          JOIN users u ON r.user_id = u.id
                                          WHERE r.campaign_id = {$campaignId} AND r.status = 'pending'")->fetch_all(MYSQLI_ASSOC);

            foreach ($recipients as $recipient) {
                try {
                    // 替换邮件中的变量
                    $emailContent = $this->replaceEmailVariables($campaignInfo['content'], $recipient);
                    $emailSubject = $this->replaceEmailVariables($campaignInfo['subject'], $recipient);

                    // 发送邮件
                    $result = $this->emailService->sendEmail($recipient['email'], $emailSubject, $emailContent);

                    if ($result['success']) {
                        $this->db->query("UPDATE email_campaign_recipients 
                                        SET status = 'sent', sent_at = NOW() 
                                        WHERE id = {$recipient['id']}");
                    } else {
                        $this->db->query("UPDATE email_campaign_recipients 
                                        SET status = 'failed', error = '{$result['error']}' 
                                        WHERE id = {$recipient['id']}");
                    }

                    // 限制发送速度，避免触发邮件服务器限制
                    usleep(100000); // 100ms延迟
                } catch (Exception $e) {
                    $this->logger->error('发送邮件失败', ['error' => $e->getMessage(), 'user_id' => $recipient['user_id']]);
                }
            }

            // 更新活动状态为已完成
            $this->db->query("UPDATE email_campaigns SET status = 'completed', sent_at = NOW() WHERE id = ?", [$campaignId]);
        } catch (Exception $e) {
            $this->logger->error('处理邮件活动失败', ['error' => $e->getMessage(), 'campaign_id' => $campaignId]);
            $this->db->query("UPDATE email_campaigns SET status = 'failed', error = ? WHERE id = ?", [$e->getMessage(), $campaignId]);
        }
    }

    /**
     * 处理短信营销活动发送
     * 
     * @param int $campaignId 活动ID
     */
    private function processSMSCampaign($campaignId) {
        try {
            // 获取活动信息
            $campaignInfo = $this->db->query("SELECT * FROM sms_campaigns WHERE id = ?", [$campaignId])->fetch_assoc();
            if (!$campaignInfo) return;

            // 更新活动状态
            $this->db->query("UPDATE sms_campaigns SET status = 'sending' WHERE id = ?", [$campaignId]);

            // 获取待发送的用户
            $recipients = $this->db->query("SELECT r.*, u.phone, u.username FROM sms_campaign_recipients r
                                          JOIN users u ON r.user_id = u.id
                                          WHERE r.campaign_id = ? AND r.status = 'pending' AND u.phone IS NOT NULL", [$campaignId])->fetch_all(MYSQLI_ASSOC);

            foreach ($recipients as $recipient) {
                try {
                    // 替换短信中的变量
                    $smsContent = $this->replaceEmailVariables($campaignInfo['content'], $recipient);

                    // 发送短信
                    $result = $this->smsService->sendSMS($recipient['phone'], $smsContent);

                    if ($result['success']) {
                        $this->db->query("UPDATE sms_campaign_recipients 
                                        SET status = 'sent', sent_at = NOW() 
                                        WHERE id = ?", [$recipient['id']]);
                    } else {
                        $this->db->query("UPDATE sms_campaign_recipients 
                                        SET status = 'failed', error = ? 
                                        WHERE id = ?", [$result['error'], $recipient['id']]);
                    }

                    // 限制发送速度
                    usleep(200000); // 200ms延迟
                } catch (Exception $e) {
                    $this->logger->error('发送短信失败', ['error' => $e->getMessage(), 'user_id' => $recipient['user_id']]);
                }
            }

            // 更新活动状态为已完成
            $this->db->query("UPDATE sms_campaigns SET status = 'completed', sent_at = NOW() WHERE id = ?", [$campaignId]);
        } catch (Exception $e) {
            $this->logger->error('处理短信活动失败', ['error' => $e->getMessage(), 'campaign_id' => $campaignId]);
            $this->db->query("UPDATE sms_campaigns SET status = 'failed', error = ? WHERE id = ?", [$e->getMessage(), $campaignId]);
        }
    }

    /**
     * 替换邮件模板变量
     */
    private function replaceEmailVariables($content, $userData) {
        $variables = [
            '{username}' => $userData['username'] ?? '',
            '{user_id}' => $userData['user_id'] ?? '',
            '{email}' => $userData['email'] ?? '',
            '{site_name}' => SITE_NAME,
            '{site_url}' => SITE_URL,
            '{current_date}' => date('Y-m-d'),
            '{unsubscribe_link}' => SITE_URL . "/unsubscribe/{$userData['user_id']}"
        ];

        foreach ($variables as $key => $value) {
            $content = str_replace($key, $value, $content);
        }

        return $content;
    }

    /**
     * 根据用户分群获取用户列表
     */
    private function getUsersBySegment($segment) {
        $query = "SELECT id, username, email, phone FROM users WHERE 1=1 ";

        switch ($segment) {
            case 'all':
                // 所有用户
                break;
            case 'new_users':
                // 新注册用户（30天内）
                $query .= "AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                break;
            case 'inactive':
                // 不活跃用户（90天未登录）
                $query .= "AND last_activity <= DATE_SUB(NOW(), INTERVAL 90 DAY)";
                break;
            case 'high_value':
                // 高价值用户（消费超过1000元）
                $query .= "AND id IN (SELECT user_id FROM orders GROUP BY user_id HAVING SUM(total_amount) > 1000)";
                break;
            default:
                // 自定义分群
                if (is_array($segment)) {
                    if (!empty($segment['min_points'])) {
                        $query .= "AND points >= {$segment['min_points']}";
                    }
                    if (!empty($segment['membership_level'])) {
                        $query .= "AND membership_level = {$segment['membership_level']}";
                    }
                    if (!empty($segment['registration_date_from'])) {
                        $query .= "AND created_at >= '{$segment['registration_date_from']}'";
                    }
                }
        }

        return $this->db->query($query)->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * 创建订单（内部方法）
     */
    private function createOrder($userId, $productId, $price, $quantity, $orderType = 'normal') {
        // 这里应该调用现有的订单创建逻辑
        $this->db->query("INSERT INTO orders (user_id, total_amount, status, order_type, created_at, updated_at)
                        VALUES ({$userId}, {$price} * {$quantity}, 'pending', '{$orderType}', NOW(), NOW())");
        $orderId = $this->db->insert_id;

        // 添加订单项
        $this->db->query("INSERT INTO order_items (order_id, product_id, merchant_id, price, quantity, created_at)
                        VALUES ({$orderId}, {$productId}, 1, {$price}, {$quantity}, NOW())");

        return $orderId;
    }

    /**
     * 计算秒杀剩余时间
     */
    private function calculateTimeLeft($endTime) {
        $timeLeft = strtotime($endTime) - time();
        
        if ($timeLeft <= 0) {
            return '00:00:00';
        }

        $hours = floor($timeLeft / 3600);
        $minutes = floor(($timeLeft % 3600) / 60);
        $seconds = $timeLeft % 60;

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    /**
     * 计算秒杀时间进度
     */
    private function calculateTimeProgress($startTime, $endTime) {
        $start = strtotime($startTime);
        $end = strtotime($endTime);
        $now = time();
        
        if ($now <= $start) return 0;
        if ($now >= $end) return 100;
        
        return (($now - $start) / ($end - $start)) * 100;
    }

    /**
     * 清除秒杀活动缓存
     */
    private function clearFlashSaleCache() {
        // 清除相关缓存
        foreach (array_keys($this->cache) as $key) {
            if (strpos($key, 'active_flash_sales_') === 0) {
                unset($this->cache[$key]);
            }
        }
    }

    /**
     * 生成活动分享码
     */
    private function generateShareCode($campaignId) {
        return substr(md5($campaignId . time() . mt_rand()), 0, 8);
    }

    /**
     * 生成用户分享码
     */
    private function generateUserShareCode($userId, $campaignId) {
        return substr(md5($userId . $campaignId . time() . mt_rand()), 0, 12);
    }

    /**
     * 发送会员升级通知
     */
    private function sendMembershipUpgradeNotification($userId, $newLevelName) {
        $user = $this->db->query("SELECT username, email FROM users WHERE id = ?", [$userId])->fetch_assoc();
        if (!$user) return;

        $subject = "恭喜！您已升级为{$newLevelName}";
        $content = "尊敬的{$user['username']}：<br><br>"
                 ."恭喜您已成功升级为{$newLevelName}！<br>"
                 ."作为{$newLevelName}，您将享受更多专属特权和优惠。<br><br>"
                 ."感谢您对我们的支持！<br><br>"
                 ."此致<br>"
                 ."客户服务团队";

        $this->emailService->sendEmail($user['email'], $subject, $content);
    }

    /**
     * 发送秒杀活动通知
     */
    private function notifyUsersAboutFlashSale($flashSaleId) {
        // 获取活动信息
        $flashSale = $this->db->query("SELECT * FROM flash_sales WHERE id = ?", [$flashSaleId])->fetch_assoc();
        if (!$flashSale) return;

        // 获取需要通知的用户（活跃用户、高价值用户）
        $users = $this->db->query("SELECT id, username, email FROM users 
                                WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 30 DAY) 
                                OR id IN (SELECT user_id FROM orders GROUP BY user_id HAVING SUM(total_amount) > 500)")->fetch_all(MYSQLI_ASSOC);

        foreach ($users as $user) {
            $subject = "【限时秒杀】{$flashSale['name']}即将开始！";
            $content = "尊敬的{$user['username']}：<br><br>"
                     ."我们的限时秒杀活动 <strong>{$flashSale['name']}</strong> 即将开始！<br>"
                     ."活动时间：{$flashSale['start_time']} 至 {$flashSale['end_time']}<br>"
                     ."点击查看详情：<a href='{SITE_URL}/flash-sale/{$flashSaleId}'>立即查看</a><br><br>"
                     ."数量有限，先到先得！<br><br>"
                     ."此致<br>"
                     ."营销团队";

            $content = str_replace('{SITE_URL}', SITE_URL, $content);
            $this->emailService->sendEmail($user['email'], $subject, $content);
            usleep(50000); // 50ms延迟
        }
    }
}