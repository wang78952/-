<?php
/**
 * 国际化翻译工具
 * 提供多语言支持、翻译缓存和动态翻译能力
 * 
 * @package i18n
 * @author System Administrator
 * @version 1.0
 */

class Translator {
    /**
     * 默认语言
     * @var string
     */
    private $defaultLanguage = 'zh_CN';
    
    /**
     * 当前语言
     * @var string
     */
    private $currentLanguage;
    
    /**
     * 支持的语言列表
     * @var array
     */
    private $supportedLanguages = [
        'zh_CN' => '简体中文',
        'en_US' => 'English',
        'ja_JP' => '日本語',
        'ko_KR' => '한국어',
        'zh_TW' => '繁體中文',
    ];
    
    /**
     * 语言包路径
     * @var string
     */
    private $languageDir;
    
    /**
     * 翻译缓存
     * @var array
     */
    private $translationCache = [];
    
    /**
     * 数据库连接
     * @var mysqli
     */
    private $db;
    
    /**
     * Redis连接（用于缓存）
     * @var Redis
     */
    private $redis;
    
    /**
     * 配置信息
     * @var array
     */
    private $config = [];
    
    /**
     * 构造函数
     * 
     * @param mysqli $db 数据库连接
     * @param Redis $redis Redis连接
     * @param array $config 配置信息
     */
    public function __construct($db = null, $redis = null, $config = []) {
        $this->db = $db;
        $this->redis = $redis;
        // 确保配置是数组类型
        $config = is_array($config) ? $config : [];
        $this->config = array_merge([
            'language_dir' => __DIR__ . '/languages',
            'cache_enabled' => true,
            'cache_ttl' => 3600, // 缓存1小时
            'fallback_enabled' => true,
            'db_enabled' => true,
        ], $config);
        
        $this->languageDir = $this->config['language_dir'];
        
        // 确保语言目录存在
        $this->ensureLanguageDirExists();
        
        // 确保数据库表存在（如果启用了数据库）
        if ($this->db && $this->config['db_enabled']) {
            $this->ensureTablesExist();
        }
        
        // 设置当前语言
        $this->setCurrentLanguage($this->detectUserLanguage());
    }
    
    /**
     * 确保语言目录存在
     */
    private function ensureLanguageDirExists() {
        if (!is_dir($this->languageDir)) {
            mkdir($this->languageDir, 0755, true);
        }
        
        // 为每种支持的语言创建子目录
        foreach ($this->supportedLanguages as $langCode => $langName) {
            $langDir = $this->languageDir . '/' . $langCode;
            if (!is_dir($langDir)) {
                mkdir($langDir, 0755, true);
                // 创建默认的翻译文件
                $this->createDefaultTranslationFile($langCode);
            }
        }
    }
    
    /**
     * 创建默认的翻译文件
     * 
     * @param string $langCode 语言代码
     */
    private function createDefaultTranslationFile($langCode) {
        $defaultTranslations = [];
        
        switch ($langCode) {
            case 'zh_CN':
                $defaultTranslations = [
                    'welcome' => '欢迎使用发卡系统',
                    'login' => '登录',
                    'register' => '注册',
                    'username' => '用户名',
                    'password' => '密码',
                    'logout' => '退出登录',
                    'dashboard' => '控制面板',
                    'products' => '商品',
                    'orders' => '订单',
                    'users' => '用户',
                    'cards' => '卡密',
                    'settings' => '设置',
                    'submit' => '提交',
                    'cancel' => '取消',
                    'save' => '保存',
                    'delete' => '删除',
                    'edit' => '编辑',
                    'add' => '添加',
                    'search' => '搜索',
                    'filter' => '筛选',
                    'sort' => '排序',
                    'export' => '导出',
                    'import' => '导入',
                    'success' => '操作成功',
                    'error' => '操作失败',
                    'warning' => '警告',
                    'info' => '提示',
                    'confirm' => '确认',
                    'cancel' => '取消',
                    'yes' => '是',
                    'no' => '否',
                    'loading' => '加载中...',
                    'page' => '页',
                    'total' => '总计',
                    'per_page' => '每页',
                    'prev' => '上一页',
                    'next' => '下一页',
                    'first' => '首页',
                    'last' => '末页',
                    'not_found' => '未找到相关内容',
                    'access_denied' => '访问被拒绝',
                    'server_error' => '服务器错误',
                    'network_error' => '网络错误',
                    'timeout' => '请求超时',
                    'invalid_input' => '输入格式错误',
                    'required_field' => '此字段为必填项',
                    'email' => '邮箱',
                    'phone' => '电话',
                    'address' => '地址',
                    'city' => '城市',
                    'country' => '国家',
                    'zip' => '邮编',
                    'date' => '日期',
                    'time' => '时间',
                    'amount' => '金额',
                    'currency' => '货币',
                    'quantity' => '数量',
                    'status' => '状态',
                    'created_at' => '创建时间',
                    'updated_at' => '更新时间',
                    'action' => '操作',
                    'view' => '查看',
                    'details' => '详情',
                    'summary' => '摘要',
                    'statistics' => '统计',
                    'reports' => '报表',
                    'help' => '帮助',
                    'about' => '关于',
                    'support' => '支持',
                    'feedback' => '反馈',
                    'terms' => '条款',
                    'privacy' => '隐私',
                    'agreement' => '协议',
                    'license' => '许可证',
                    'version' => '版本',
                    'admin' => '管理员',
                    'user' => '用户',
                    'role' => '角色',
                    'permission' => '权限',
                    'profile' => '个人资料',
                    'change_password' => '修改密码',
                    'notification' => '通知',
                    'message' => '消息',
                    'system' => '系统',
                    'configuration' => '配置',
                    'security' => '安全',
                    'cache' => '缓存',
                    'clear_cache' => '清除缓存',
                    'backup' => '备份',
                    'restore' => '恢复',
                    'language' => '语言',
                    'theme' => '主题',
                    'dark_mode' => '深色模式',
                    'light_mode' => '浅色模式',
                    'auto_mode' => '自动模式',
                    'search_results' => '搜索结果',
                    'results_found' => '找到 {count} 个结果',
                    'no_results' => '没有找到相关结果',
                    'please_wait' => '请稍候...',
                    'done' => '完成',
                    'processing' => '处理中...',
                    'pending' => '待处理',
                    'completed' => '已完成',
                    'failed' => '失败',
                    'canceled' => '已取消',
                    'active' => '启用',
                    'inactive' => '禁用',
                    'enabled' => '已启用',
                    'disabled' => '已禁用',
                    'verify' => '验证',
                    'verification' => '验证',
                    'code' => '代码',
                    'token' => '令牌',
                    'key' => '密钥',
                    'value' => '值',
                    'description' => '描述',
                    'name' => '名称',
                    'title' => '标题',
                    'content' => '内容',
                    'category' => '分类',
                    'tag' => '标签',
                    'keyword' => '关键词',
                    'price' => '价格',
                    'cost' => '成本',
                    'profit' => '利润',
                    'discount' => '折扣',
                    'tax' => '税费',
                    'shipping' => '运费',
                    'payment' => '支付',
                    'method' => '方式',
                    'gateway' => '网关',
                    'transaction' => '交易',
                    'invoice' => '发票',
                    'receipt' => '收据',
                    'refund' => '退款',
                    'balance' => '余额',
                    'deposit' => '存款',
                    'withdraw' => '提现',
                    'commission' => '佣金',
                    'referral' => '推荐',
                    'affiliate' => '联盟',
                    'coupon' => '优惠券',
                    'voucher' => '代金券',
                    'gift_card' => '礼品卡',
                    'redeem' => '兑换',
                    'expire' => '过期',
                    'expired' => '已过期',
                    'valid' => '有效',
                    'invalid' => '无效',
                    'used' => '已使用',
                    'unused' => '未使用',
                    'generate' => '生成',
                    'batch' => '批量',
                    'import' => '导入',
                    'export' => '导出',
                    'download' => '下载',
                    'upload' => '上传',
                    'file' => '文件',
                    'size' => '大小',
                    'format' => '格式',
                    'extension' => '扩展名',
                    'mime_type' => 'MIME类型',
                    'charset' => '字符集',
                    'encoding' => '编码',
                    'utf8' => 'UTF-8',
                    'ascii' => 'ASCII',
                    'unicode' => 'Unicode',
                    'bit' => '比特',
                    'byte' => '字节',
                    'kb' => 'KB',
                    'mb' => 'MB',
                    'gb' => 'GB',
                    'tb' => 'TB',
                    'bps' => '比特/秒',
                    'kbps' => 'KB/秒',
                    'mbps' => 'MB/秒',
                    'gbps' => 'GB/秒',
                    'latency' => '延迟',
                    'ping' => 'Ping',
                    'timeout' => '超时',
                    'connection' => '连接',
                    'disconnect' => '断开连接',
                    'reconnect' => '重新连接',
                    'online' => '在线',
                    'offline' => '离线',
                    'busy' => '忙碌',
                    'idle' => '空闲',
                    'available' => '可用',
                    'unavailable' => '不可用',
                    'maintenance' => '维护',
                    'updating' => '更新中',
                    'deploying' => '部署中',
                    'syncing' => '同步中',
                    'backing_up' => '备份中',
                    'restoring' => '恢复中',
                    'optimizing' => '优化中',
                    'scanning' => '扫描中',
                    'analyzing' => '分析中',
                    'calculating' => '计算中',
                    'generating' => '生成中',
                    'processing' => '处理中',
                    'importing' => '导入中',
                    'exporting' => '导出中',
                    'uploading' => '上传中',
                    'downloading' => '下载中',
                    'compressing' => '压缩中',
                    'decompressing' => '解压中',
                    'encrypting' => '加密中',
                    'decrypting' => '解密中',
                    'hashing' => '哈希中',
                    'signing' => '签名中',
                    'verifying' => '验证中',
                    'logging_in' => '登录中...',
                    'logging_out' => '登出中...',
                    'registering' => '注册中...',
                    'saving' => '保存中...',
                    'deleting' => '删除中...',
                    'updating' => '更新中...',
                    'loading_more' => '加载更多...',
                    'refreshing' => '刷新中...',
                    'filtering' => '筛选中...',
                    'sorting' => '排序中...',
                    'searching' => '搜索中...',
                    'no_data' => '暂无数据',
                    'data_loaded' => '数据加载完成',
                    'server_response' => '服务器响应',
                    'client_error' => '客户端错误',
                    'network_error' => '网络错误',
                    'server_overload' => '服务器过载',
                    'service_unavailable' => '服务暂时不可用',
                    'try_again' => '请稍后再试',
                    'contact_support' => '请联系客服',
                    'suggestions' => '建议',
                    'tips' => '提示',
                    'hints' => '提示',
                    'examples' => '示例',
                    'demo' => '演示',
                    'documentation' => '文档',
                    'tutorial' => '教程',
                    'guide' => '指南',
                    'faq' => '常见问题',
                    'wiki' => '知识库',
                    'forum' => '论坛',
                    'community' => '社区',
                    'blog' => '博客',
                    'news' => '新闻',
                    'updates' => '更新',
                    'changelog' => '更新日志',
                    'features' => '功能',
                    'benefits' => '优势',
                    'specifications' => '规格',
                    'requirements' => '要求',
                    'compatibility' => '兼容性',
                    'supported' => '支持',
                    'unsupported' => '不支持',
                    'deprecated' => '已弃用',
                    'new' => '新增',
                    'improved' => '改进',
                    'fixed' => '修复',
                    'known_issues' => '已知问题',
                    'roadmap' => '路线图',
                    'plans' => '计划',
                    'future' => '未来',
                    'vision' => '愿景',
                    'mission' => '使命',
                    'goal' => '目标',
                    'achievement' => '成就',
                    'milestone' => '里程碑',
                    'success_rate' => '成功率',
                    'failure_rate' => '失败率',
                    'completion_rate' => '完成率',
                    'progress' => '进度',
                    'percentage' => '百分比',
                    'ratio' => '比例',
                    'average' => '平均',
                    'mean' => '均值',
                    'median' => '中位数',
                    'mode' => '众数',
                    'range' => '范围',
                    'min' => '最小值',
                    'max' => '最大值',
                    'sum' => '总和',
                    'total' => '总计',
                    'count' => '计数',
                    'unique' => '唯一',
                    'distinct' => '不同',
                    'duplicate' => '重复',
                    'error_log' => '错误日志',
                    'access_log' => '访问日志',
                    'system_log' => '系统日志',
                    'audit_log' => '审计日志',
                    'debug' => '调试',
                    'info' => '信息',
                    'notice' => '通知',
                    'warning' => '警告',
                    'error' => '错误',
                    'critical' => '严重',
                    'alert' => '警报',
                    'emergency' => '紧急',
                    'fatal' => '致命',
                    'panic' => '恐慌',
                    'success_message' => '操作成功',
                    'error_message' => '操作失败',
                    'warning_message' => '操作警告',
                    'info_message' => '操作提示',
                    'confirmation_message' => '确认操作',
                    'are_you_sure' => '确定要执行此操作吗？',
                    'cannot_be_undone' => '此操作不可撤销',
                    'confirm_delete' => '确定要删除此项吗？',
                    'confirm_logout' => '确定要退出登录吗？',
                    'confirm_submit' => '确定要提交吗？',
                    'confirm_cancel' => '确定要取消吗？',
                    'confirm_save' => '确定要保存吗？',
                    'confirm_update' => '确定要更新吗？',
                    'confirm_restore' => '确定要恢复吗？',
                    'confirm_clear' => '确定要清除吗？',
                    'confirm_reset' => '确定要重置吗？',
                    'confirm_continue' => '确定要继续吗？',
                    'confirm_skip' => '确定要跳过吗？',
                    'confirm_ignore' => '确定要忽略吗？',
                    'confirm_approve' => '确定要批准吗？',
                    'confirm_reject' => '确定要拒绝吗？',
                    'confirm_publish' => '确定要发布吗？',
                    'confirm_unpublish' => '确定要下架吗？',
                    'confirm_enable' => '确定要启用吗？',
                    'confirm_disable' => '确定要禁用吗？',
                    'confirm_lock' => '确定要锁定吗？',
                    'confirm_unlock' => '确定要解锁吗？',
                    'confirm_block' => '确定要封禁吗？',
                    'confirm_unblock' => '确定要解封吗？',
                    'confirm_suspend' => '确定要暂停吗？',
                    'confirm_resume' => '确定要恢复吗？',
                    'confirm_assign' => '确定要分配吗？',
                    'confirm_unassign' => '确定要取消分配吗？',
                    'confirm_complete' => '确定要完成吗？',
                    'confirm_abort' => '确定要中止吗？',
                    'confirm_terminate' => '确定要终止吗？',
                    'confirm_restart' => '确定要重启吗？',
                    'confirm_shutdown' => '确定要关闭吗？',
                    'confirm_power_off' => '确定要关机吗？',
                    'confirm_power_on' => '确定要开机吗？',
                    'confirm_reboot' => '确定要重启吗？',
                    'confirm_switch' => '确定要切换吗？',
                    'confirm_swap' => '确定要交换吗？',
                    'confirm_merge' => '确定要合并吗？',
                    'confirm_split' => '确定要拆分吗？',
                    'confirm_duplicate' => '确定要复制吗？',
                    'confirm_rename' => '确定要重命名吗？',
                    'confirm_move' => '确定要移动吗？',
                    'confirm_copy' => '确定要复制吗？',
                    'confirm_cut' => '确定要剪切吗？',
                    'confirm_paste' => '确定要粘贴吗？',
                    'confirm_upload' => '确定要上传吗？',
                    'confirm_download' => '确定要下载吗？',
                    'confirm_import' => '确定要导入吗？',
                    'confirm_export' => '确定要导出吗？',
                    'confirm_backup' => '确定要备份吗？',
                    'confirm_restore' => '确定要恢复吗？',
                    'confirm_sync' => '确定要同步吗？',
                    'confirm_unsync' => '确定要取消同步吗？',
                    'confirm_connect' => '确定要连接吗？',
                    'confirm_disconnect' => '确定要断开连接吗？',
                    'confirm_link' => '确定要链接吗？',
                    'confirm_unlink' => '确定要取消链接吗？',
                    'confirm_attach' => '确定要附加吗？',
                    'confirm_detach' => '确定要分离吗？',
                    'confirm_embed' => '确定要嵌入吗？',
                    'confirm_remove' => '确定要移除吗？',
                    'confirm_install' => '确定要安装吗？',
                    'confirm_uninstall' => '确定要卸载吗？',
                    'confirm_update' => '确定要更新吗？',
                    'confirm_upgrade' => '确定要升级吗？',
                    'confirm_downgrade' => '确定要降级吗？',
                    'confirm_active' => '确定要激活吗？',
                    'confirm_deactivate' => '确定要停用吗？',
                    'confirm_activate_account' => '确定要激活账户吗？',
                    'confirm_deactivate_account' => '确定要停用账户吗？',
                    'confirm_suspend_account' => '确定要暂停账户吗？',
                    'confirm_unsuspend_account' => '确定要恢复账户吗？',
                    'confirm_close_account' => '确定要关闭账户吗？',
                    'confirm_delete_account' => '确定要删除账户吗？',
                    'account_deleted' => '账户已删除',
                    'account_suspended' => '账户已暂停',
                    'account_activated' => '账户已激活',
                    'account_deactivated' => '账户已停用',
                    'account_created' => '账户创建成功',
                    'account_updated' => '账户更新成功',
                    'login_success' => '登录成功',
                    'login_failed' => '登录失败',
                    'logout_success' => '登出成功',
                    'registration_success' => '注册成功',
                    'registration_failed' => '注册失败',
                    'password_changed' => '密码修改成功',
                    'password_reset' => '密码重置成功',
                    'password_sent' => '密码重置邮件已发送',
                    'email_verified' => '邮箱验证成功',
                    'email_sent' => '邮件已发送',
                    'verification_code_sent' => '验证码已发送',
                    'verification_success' => '验证成功',
                    'verification_failed' => '验证失败',
                    'invalid_code' => '无效的验证码',
                    'code_expired' => '验证码已过期',
                    'limit_reached' => '已达到限制',
                    'quota_exceeded' => '配额已用完',
                    'storage_full' => '存储空间已满',
                    'bandwidth_exceeded' => '带宽已用完',
                    'plan_expired' => '套餐已过期',
                    'upgrade_plan' => '升级套餐',
                    'renew_plan' => '续费套餐',
                    'downgrade_plan' => '降级套餐',
                    'change_plan' => '更换套餐',
                    'view_plan' => '查看套餐',
                    'manage_plan' => '管理套餐',
                    'plan_details' => '套餐详情',
                    'plan_features' => '套餐功能',
                    'plan_limits' => '套餐限制',
                    'plan_pricing' => '套餐价格',
                    'plan_billing' => '套餐计费',
                    'billing_cycle' => '计费周期',
                    'next_billing_date' => '下次计费日期',
                    'last_billing_date' => '上次计费日期',
                    'payment_due' => '待付款',
                    'payment_pending' => '付款处理中',
                    'payment_complete' => '付款完成',
                    'payment_failed' => '付款失败',
                    'payment_refunded' => '付款已退款',
                    'payment_disputed' => '付款有争议',
                    'invoice_generated' => '发票已生成',
                    'invoice_paid' => '发票已付款',
                    'invoice_due' => '发票待付款',
                    'invoice_overdue' => '发票已逾期',
                    'view_invoice' => '查看发票',
                    'download_invoice' => '下载发票',
                    'pay_invoice' => '支付发票',
                    'cancel_invoice' => '取消发票',
                    'generate_invoice' => '生成发票',
                    'tax_invoice' => '税务发票',
                    'receipt_generated' => '收据已生成',
                    'view_receipt' => '查看收据',
                    'download_receipt' => '下载收据',
                    'transaction_id' => '交易ID',
                    'order_id' => '订单ID',
                    'invoice_id' => '发票ID',
                    'receipt_id' => '收据ID',
                    'payment_id' => '支付ID',
                    'transaction_date' => '交易日期',
                    'transaction_amount' => '交易金额',
                    'transaction_status' => '交易状态',
                    'payment_method' => '支付方式',
                    'payment_processor' => '支付处理商',
                    'currency' => '货币',
                    'exchange_rate' => '汇率',
                    'subtotal' => '小计',
                    'tax' => '税费',
                    'shipping' => '运费',
                    'discount' => '折扣',
                    'total' => '总计',
                    'grand_total' => '总金额',
                    'balance_due' => '应付余额',
                    'credit_available' => '可用信用',
                    'refund_amount' => '退款金额',
                    'refund_reason' => '退款原因',
                    'refund_status' => '退款状态',
                    'dispute_reason' => '争议原因',
                    'dispute_status' => '争议状态',
                    'dispute_resolution' => '争议解决',
                    'payment_received' => '收到付款',
                    'payment_sent' => '已发送付款',
                    'deposit_success' => '存款成功',
                    'withdrawal_success' => '提款成功',
                    'deposit_failed' => '存款失败',
                    'withdrawal_failed' => '提款失败',
                    'insufficient_funds' => '余额不足',
                    'funds_added' => '资金已添加',
                    'funds_removed' => '资金已扣除',
                    'balance_updated' => '余额已更新',
                    'wallet' => '钱包',
                    'manage_wallet' => '管理钱包',
                    'fund_wallet' => '充值钱包',
                    'withdraw_funds' => '提取资金',
                    'wallet_history' => '钱包历史',
                    'transaction_history' => '交易历史',
                    'payment_history' => '支付历史',
                    'order_history' => '订单历史',
                    'invoice_history' => '发票历史',
                    'refund_history' => '退款历史',
                    'dispute_history' => '争议历史',
                    'deposit_history' => '存款历史',
                    'withdrawal_history' => '提款历史',
                    'activity_log' => '活动日志',
                    'user_activity' => '用户活动',
                    'system_activity' => '系统活动',
                    'admin_activity' => '管理员活动',
                    'login_attempts' => '登录尝试',
                    'failed_logins' => '失败登录',
                    'suspicious_activity' => '可疑活动',
                    'security_alert' => '安全警报',
                    'unusual_activity' => '异常活动',
                    'account_access' => '账户访问',
                    'new_login' => '新登录',
                    'login_location' => '登录位置',
                    'login_ip' => '登录IP',
                    'login_time' => '登录时间',
                    'last_login' => '最后登录',
                    'device_info' => '设备信息',
                    'browser_info' => '浏览器信息',
                    'os_info' => '操作系统信息',
                    'app_info' => '应用信息',
                    'version_info' => '版本信息',
                    'connection_info' => '连接信息',
                    'network_info' => '网络信息',
                    'location_info' => '位置信息',
                    'geo_info' => '地理位置信息',
                    'timezone_info' => '时区信息',
                    'language_info' => '语言信息',
                    'currency_info' => '货币信息',
                    'user_agent' => '用户代理',
                    'session_info' => '会话信息',
                    'token_info' => '令牌信息',
                    'cookie_info' => 'Cookie信息',
                    'cache_info' => '缓存信息',
                    'storage_info' => '存储信息',
                    'memory_info' => '内存信息',
                    'cpu_info' => 'CPU信息',
                    'disk_info' => '磁盘信息',
                    'network_status' => '网络状态',
                    'server_status' => '服务器状态',
                    'database_status' => '数据库状态',
                    'cache_status' => '缓存状态',
                    'queue_status' => '队列状态',
                    'service_status' => '服务状态',
                    'system_status' => '系统状态',
                    'health_check' => '健康检查',
                    'performance_check' => '性能检查',
                    'security_check' => '安全检查',
                    'diagnostics' => '诊断',
                    'troubleshooting' => '故障排除',
                    'fix' => '修复',
                    'repair' => '修复',
                    'maintain' => '维护',
                    'optimize' => '优化',
                    'tune' => '调优',
                    'configure' => '配置',
                    'customize' => '自定义',
                    'personalize' => '个性化',
                    'theme' => '主题',
                    'layout' => '布局',
                    'design' => '设计',
                    'appearance' => '外观',
                    'colors' => '颜色',
                    'fonts' => '字体',
                    'icons' => '图标',
                    'images' => '图片',
                    'logo' => 'logo',
                    'banner' => '横幅',
                    'background' => '背景',
                    'wallpaper' => '壁纸',
                    'avatar' => '头像',
                    'profile_picture' => '个人头像',
                    'cover_photo' => '封面照片',
                    'upload_avatar' => '上传头像',
                    'upload_photo' => '上传照片',
                    'crop_image' => '裁剪图片',
                    'resize_image' => '调整图片大小',
                    'compress_image' => '压缩图片',
                    'edit_image' => '编辑图片',
                    'delete_image' => '删除图片',
                    'rotate_image' => '旋转图片',
                    'flip_image' => '翻转图片',
                    'filter_image' => '滤镜图片',
                    'enhance_image' => '增强图片',
                    'optimize_image' => '优化图片',
                    'save_image' => '保存图片',
                    'share_image' => '分享图片',
                    'download_image' => '下载图片',
                    'preview_image' => '预览图片',
                    'fullscreen' => '全屏',
                    'exit_fullscreen' => '退出全屏',
                    'zoom_in' => '放大',
                    'zoom_out' => '缩小',
                    'reset_zoom' => '重置缩放',
                    'fit_to_screen' => '适应屏幕',
                    'original_size' => '原始大小',
                    'print' => '打印',
                    'export_to_pdf' => '导出为PDF',
                    'export_to_csv' => '导出为CSV',
                    'export_to_excel' => '导出为Excel',
                    'export_to_word' => '导出为Word',
                    'export_to_image' => '导出为图片',
                    'export_to_json' => '导出为JSON',
                    'export_to_xml' => '导出为XML',
                    'export_to_html' => '导出为HTML',
                    'export_to_text' => '导出为文本',
                    'import_from_csv' => '从CSV导入',
                    'import_from_excel' => '从Excel导入',
                    'import_from_json' => '从JSON导入',
                    'import_from_xml' => '从XML导入',
                    'import_from_html' => '从HTML导入',
                    'import_from_text' => '从文本导入',
                    'import_from_database' => '从数据库导入',
                    'import_from_file' => '从文件导入',
                    'upload_file' => '上传文件',
                    'choose_file' => '选择文件',
                    'drag_drop' => '拖拽文件到此处',
                    'select_files' => '选择文件',
                    'select_all' => '全选',
                    'deselect_all' => '取消全选',
                    'select_invert' => '反向选择',
                    'download_files' => '下载文件',
                    'delete_files' => '删除文件',
                    'move_files' => '移动文件',
                    'copy_files' => '复制文件',
                    'rename_files' => '重命名文件',
                    'compress_files' => '压缩文件',
                    'extract_files' => '解压文件',
                    'share_files' => '分享文件',
                    'preview_files' => '预览文件',
                    'sort_files' => '排序文件',
                    'filter_files' => '筛选文件',
                    'search_files' => '搜索文件',
                    'file_details' => '文件详情',
                    'file_properties' => '文件属性',
                    'file_info' => '文件信息',
                    'file_type' => '文件类型',
                    'file_size' => '文件大小',
                    'file_date' => '文件日期',
                    'file_path' => '文件路径',
                    'file_permissions' => '文件权限',
                    'file_owner' => '文件所有者',
                    'file_group' => '文件组',
                    'file_count' => '文件数量',
                    'folder_count' => '文件夹数量',
                    'total_size' => '总大小',
                    'free_space' => '可用空间',
                    'used_space' => '已用空间',
                    'space_usage' => '空间使用情况',
                    'disk_usage' => '磁盘使用情况',
                    'storage_usage' => '存储使用情况',
                    'file_system' => '文件系统',
                    'mount_point' => '挂载点',
                    'partition' => '分区',
                    'volume' => '卷',
                    'drive' => '驱动器',
                    'storage_device' => '存储设备',
                    'storage_location' => '存储位置',
                    'storage_service' => '存储服务',
                    'cloud_storage' => '云存储',
                    'local_storage' => '本地存储',
                    'external_storage' => '外部存储',
                    'network_storage' => '网络存储',
                    'backup_storage' => '备份存储',
                    'temporary_storage' => '临时存储',
                    'cache_storage' => '缓存存储',
                    'session_storage' => '会话存储',
                    'persistent_storage' => '持久存储',
                    'encrypted_storage' => '加密存储',
                    'secure_storage' => '安全存储',
                    'private_storage' => '私有存储',
                    'public_storage' => '公共存储',
                    'shared_storage' => '共享存储',
                    'storage_limits' => '存储限制',
                    'quota' => '配额',
                    'usage' => '使用量',
                    'remaining' => '剩余',
                    'percentage_used' => '已用百分比',
                    'percentage_remaining' => '剩余百分比',
                    'manage_storage' => '管理存储',
                    'clear_storage' => '清除存储',
                    'upgrade_storage' => '升级存储',
                    'buy_storage' => '购买存储',
                    'free_up_space' => '释放空间',
                    'delete_unused' => '删除未使用',
                    'move_to_trash' => '移到回收站',
                    'empty_trash' => '清空回收站',
                    'restore_from_trash' => '从回收站恢复',
                    'trash' => '回收站',
                    'recycle_bin' => '回收站',
                    'deleted_items' => '已删除项目',
                    'recent_files' => '最近文件',
                    'frequent_files' => '常用文件',
                    'favorite_files' => '收藏文件',
                    'starred_files' => '已加星标文件',
                    'shared_with_me' => '共享给我的',
                    'shared_by_me' => '由我共享的',
                    'shared_links' => '共享链接',
                    'public_links' => '公共链接',
                    'private_links' => '私有链接',
                    'password_protected' => '密码保护',
                    'expires_on' => '过期时间',
                    'access_count' => '访问次数',
                    'download_count' => '下载次数',
                    'view_count' => '查看次数',
                    'share_count' => '分享次数',
                    'embed_count' => '嵌入次数',
                    'link_copied' => '链接已复制',
                    'link_created' => '链接已创建',
                    'link_deleted' => '链接已删除',
                    'link_expired' => '链接已过期',
                    'link_disabled' => '链接已禁用',
                    'link_enabled' => '链接已启用',
                    'manage_links' => '管理链接',
                    'create_link' => '创建链接',
                    'share_link' => '分享链接',
                    'copy_link' => '复制链接',
                    'delete_link' => '删除链接',
                    'disable_link' => '禁用链接',
                    'enable_link' => '启用链接',
                    'set_password' => '设置密码',
                    'remove_password' => '移除密码',
                    'set_expiry' => '设置过期时间',
                    'remove_expiry' => '移除过期时间',
                    'limit_downloads' => '限制下载次数',
                    'allow_downloads' => '允许下载',
                    'disallow_downloads' => '禁止下载',
                    'allow_preview' => '允许预览',
                    'disallow_preview' => '禁止预览',
                    'require_login' => '需要登录',
                    'anyone_with_link' => '任何有链接的人',
                    'specific_people' => '特定人员',
                    'organization_only' => '仅限组织',
                    'domain_only' => '仅限域名',
                    'invite_people' => '邀请人员',
                    'add_people' => '添加人员',
                    'remove_people' => '移除人员',
                    'change_permissions' => '修改权限',
                    'manage_access' => '管理访问权限',
                    'access_level' => '访问级别',
                    'can_edit' => '可编辑',
                    'can_view' => '可查看',
                    'can_comment' => '可评论',
                    'can_share' => '可分享',
                    'read_only' => '只读',
                    'read_write' => '读写',
                    'full_access' => '完全访问',
                    'no_access' => '无访问权限',
                    'pending_access' => '待处理访问',
                    'request_access' => '请求访问权限',
                    'approve_access' => '批准访问权限',
                    'deny_access' => '拒绝访问权限',
                    'revoke_access' => '撤销访问权限',
                    'access_requests' => '访问请求',
                    'manage_requests' => '管理请求',
                    'notifications' => '通知',
                    'manage_notifications' => '管理通知',
                    'notification_settings' => '通知设置',
                    'email_notifications' => '邮件通知',
                    'push_notifications' => '推送通知',
                    'sms_notifications' => '短信通知',
                    'in_app_notifications' => '应用内通知',
                    'desktop_notifications' => '桌面通知',
                    'mobile_notifications' => '移动通知',
                    'web_notifications' => '网页通知',
                    'browser_notifications' => '浏览器通知',
                    'sound_notifications' => '声音通知',
                    'vibration_notifications' => '震动通知',
                    'silent_notifications' => '静音通知',
                    'priority_notifications' => '优先级通知',
                    'important_notifications' => '重要通知',
                    'unread_notifications' => '未读通知',
                    'read_notifications' => '已读通知',
                    'mark_as_read' => '标记为已读',
                    'mark_as_unread' => '标记为未读',
                    'mark_all_read' => '全部标记为已读',
                    'delete_notification' => '删除通知',
                    'clear_notifications' => '清除通知',
                    'notification_preferences' => '通知偏好设置',
                    'notification_channels' => '通知渠道',
                    'notification_topics' => '通知主题',
                    'notification_frequency' => '通知频率',
                    'notification_grouping' => '通知分组',
                    'notification_sound' => '通知声音',
                    'notification_vibration' => '通知震动',
                    'notification_light' => '通知灯光',
                    'notification_banner' => '通知横幅',
                    'notification_lock_screen' => '锁屏通知',
                    'notification_center' => '通知中心',
                    'notification_history' => '通知历史',
                    'notification_archive' => '通知存档',
                    'notification_report' => '通知报告',
                    'notification_analytics' => '通知分析',
                    'notification_delivery' => '通知投递',
                    'notification_engagement' => '通知互动',
                    'notification_click_rate' => '通知点击率',
                    'notification_open_rate' => '通知打开率',
                    'notification_response_rate' => '通知响应率',
                    'notification_unsubscribe' => '取消订阅通知',
                    'subscribe_notifications' => '订阅通知',
                    'mentions' => '提及',
                    'replies' => '回复',
                    'comments' => '评论',
                    'likes' => '点赞',
                    'shares' => '分享',
                    'views' => '查看',
                    'follows' => '关注',
                    'followers' => '粉丝',
                    'following' => '关注中',
                    'unfollow' => '取消关注',
                    'block' => '屏蔽',
                    'unblock' => '取消屏蔽',
                    'mute' => '静音',
                    'unmute' => '取消静音',
                    'report' => '举报',
                    'report_content' => '举报内容',
                    'report_user' => '举报用户',
                    'report_issue' => '举报问题',
                    'report_spam' => '举报垃圾信息',
                    'report_abuse' => '举报滥用',
                    'report_inappropriate' => '举报不当内容',
                    'report_violation' => '举报违规',
                    'report_reason' => '举报原因',
                    'report_description' => '举报描述',
                    'report_submitted' => '举报已提交',
                    'report_under_review' => '举报正在审核',
                    'report_resolved' => '举报已解决',
                    'report_dismissed' => '举报已驳回',
                    'moderation' => '审核',
                    'content_moderation' => '内容审核',
                    'user_moderation' => '用户审核',
                    'comment_moderation' => '评论审核',
                    'post_moderation' => '帖子审核',
                    'image_moderation' => '图片审核',
                    'video_moderation' => '视频审核',
                    'audio_moderation' => '音频审核',
                    'text_moderation' => '文本审核',
                    'real_time_moderation' => '实时审核',
                    'pre_moderation' => '预审',
                    'post_moderation' => '后审',
                    'auto_moderation' => '自动审核',
                    'manual_moderation' => '手动审核',
                    'moderation_queue' => '审核队列',
                    'moderation_rules' => '审核规则',
                    'moderation_actions' => '审核操作',
                    'approve' => '批准',
                    'reject' => '拒绝',
                    'flag' => '标记',
                    'unflag' => '取消标记',
                    'delete' => '删除',
                    'edit' => '编辑',
                    'hide' => '隐藏',
                    'show' => '显示',
                    'ban' => '禁止',
                    'unban' => '解除禁止',
                    'suspend' => '暂停',
                    'unsuspend' => '解除暂停',
                    'warn' => '警告',
                    'block' => '屏蔽',
                    'unblock' => '解除屏蔽',
                    'mute' => '静音',
                    'unmute' => '解除静音',
                    'restrict' => '限制',
                    'unrestrict' => '解除限制',
                    'moderation_report' => '审核报告',
                    'moderation_stats' => '审核统计',
                    'moderation_history' => '审核历史',
                    'moderation_log' => '审核日志',
                    'moderation_analytics' => '审核分析',
                    'moderation_efficiency' => '审核效率',
                    'moderation_accuracy' => '审核准确率',
                    'moderation_speed' => '审核速度',
                    'moderation_backlog' => '审核积压',
                    'moderation_time' => '审核时间',
                    'moderation_performance' => '审核表现',
                    'moderation_quality' => '审核质量',
                    'moderation_feedback' => '审核反馈',
                    'moderation_training' => '审核培训',
                    'moderation_tools' => '审核工具',
                    'moderation_dashboard' => '审核仪表盘',
                    'admin_dashboard' => '管理仪表盘',
                    'user_dashboard' => '用户仪表盘',
                    'dashboard_overview' => '仪表盘概览',
                    'dashboard_stats' => '仪表盘统计',
                    'dashboard_charts' => '仪表盘图表',
                    'dashboard_widgets' => '仪表盘组件',
                    'dashboard_layout' => '仪表盘布局',
                    'dashboard_customization' => '仪表盘自定义',
                    'dashboard_settings' => '仪表盘设置',
                    'add_widget' => '添加组件',
                    'remove_widget' => '移除组件',
                    'move_widget' => '移动组件',
                    'resize_widget' => '调整组件大小',
                    'edit_widget' => '编辑组件',
                    'refresh_widget' => '刷新组件',
                    'widget_settings' => '组件设置',
                    'widget_data' => '组件数据',
                    'widget_chart' => '组件图表',
                    'widget_table' => '组件表格',
                    'widget_list' => '组件列表',
                    'widget_stats' => '组件统计',
                    'widget_graph' => '组件图形',
                    'widget_map' => '组件地图',
                    'widget_calendar' => '组件日历',
                    'widget_todo' => '组件待办',
                    'widget_notes' => '组件笔记',
                    'widget_weather' => '组件天气',
                    'widget_clock' => '组件时钟',
                    'widget_news' => '组件新闻',
                    'widget_alerts' => '组件警报',
                    'widget_activities' => '组件活动',
                    'widget_tasks' => '组件任务',
                    'widget_events' => '组件事件',
                    'widget_messages' => '组件消息',
                    'widget_notifications' => '组件通知',
                    'widget_performance' => '组件性能',
                    'widget_health' => '组件健康',
                    'widget_security' => '组件安全',
                    'widget_traffic' => '组件流量',
                    'widget_conversion' => '组件转化',
                    'widget_sales' => '组件销售',
                    'widget_revenue' => '组件收入',
                    'widget_expenses' => '组件支出',
                    'widget_profit' => '组件利润',
                    'widget_users' => '组件用户',
                    'widget_visitors' => '组件访客',
                    'widget_pageviews' => '组件页面浏览',
                    'widget_sessions' => '组件会话',
                    'widget_duration' => '组件时长',
                    'widget_bounce_rate' => '组件跳出率',
                    'widget_conversion_rate' => '组件转化率',
                    'widget_avg_order_value' => '组件平均订单价值',
                    'widget_cart_abandonment' => '组件购物车放弃率',
                    'widget_customer_acquisition' => '组件客户获取',
                    'widget_customer_retention' => '组件客户留存',
                    'widget_customer_lifetime' => '组件客户生命周期',
                    'widget_customer_value' => '组件客户价值',
                    'widget_churn_rate' => '组件流失率',
                    'widget_growth_rate' => '组件增长率',
                    'widget_market_share' => '组件市场份额',
                    'widget_competitors' => '组件竞争对手',
                    'widget_key_metrics' => '组件关键指标',
                    'widget_kpi' => '组件KPI',
                    'widget_sla' => '组件SLA',
                    'widget_slo' => '组件SLO',
                    'widget_sli' => '组件SLI',
                    'widget_roi' => '组件ROI',
                    'widget_roi_calculator' => '组件ROI计算器',
                    'widget_budget' => '组件预算',
                    'widget_forecast' => '组件预测',
                    'widget_trends' => '组件趋势',
                    'widget_comparison' => '组件比较',
                    'widget_benchmark' => '组件基准',
                    'widget_goals' => '组件目标',
                    'widget_progress' => '组件进度',
                    'widget_achievements' => '组件成就',
                    'widget_milestones' => '组件里程碑',
                    'widget_announcements' => '组件公告',
                    'widget_reminders' => '组件提醒',
                    'widget_deadlines' => '组件截止日期',
                    'widget_upcoming' => '组件即将到来',
                    'widget_recent_activity' => '组件最近活动',
                    'widget_frequent_activity' => '组件频繁活动',
                    'widget_errors' => '组件错误',
                    'widget_warnings' => '组件警告',
                    'widget_alerts' => '组件警报',
                    'widget_notices' => '组件通知',
                    'widget_info' => '组件信息',
                    'widget_helpful_tips' => '组件有用提示',
                    'widget_suggestions' => '组件建议',
                    'widget_quick_actions' => '组件快速操作',
                    'widget_shortcuts' => '组件快捷方式',
                    'widget_toolbar' => '组件工具栏',
                    'widget_search' => '组件搜索',
                    'widget_filter' => '组件筛选',
                    'widget_export' => '组件导出',
                    'widget_print' => '组件打印',
                    'widget_refresh' => '组件刷新',
                    'widget_settings' => '组件设置',
                    'widget_help' => '组件帮助',
                    'widget_close' => '组件关闭',
                    'widget_maximize' => '组件最大化',
                    'widget_minimize' => '组件最小化',
                    'widget_restore' => '组件还原',
                    'widget_fullscreen' => '组件全屏',
                    'widget_collapse' => '组件折叠',
                    'widget_expand' => '组件展开',
                    'widget_pin' => '组件固定',
                    'widget_unpin' => '组件取消固定',
                    'widget_drag' => '组件拖动',
                    'widget_drop' => '组件放置',
                    'widget_resize' => '组件调整大小',
                    'widget_reorder' => '组件重新排序',
                    'widget_layout' => '组件布局',
                    'widget_theme' => '组件主题',
                    'widget_style' => '组件样式',
                    'widget_font' => '组件字体',
                    'widget_color' => '组件颜色',
                    'widget_border' => '组件边框',
                    'widget_shadow' => '组件阴影',
                    'widget_padding' => '组件内边距',
                    'widget_margin' => '组件外边距',
                    'widget_background' => '组件背景',
                    'widget_transparency' => '组件透明度',
                    'widget_animation' => '组件动画',
                    'widget_transition' => '组件过渡',
                    'widget_duration' => '组件持续时间',
                    'widget_delay' => '组件延迟',
                    'widget_speed' => '组件速度',
                    'widget_easing' => '组件缓动',
                    'widget_loop' => '组件循环',
                    'widget_pause' => '组件暂停',
                    'widget_play' => '组件播放',
                    'widget_stop' => '组件停止',
                    'widget_reset' => '组件重置',
                    'widget_auto_refresh' => '组件自动刷新',
                    'widget_refresh_rate' => '组件刷新率',
                    'widget_time_range' => '组件时间范围',
                    'widget_date_range' => '组件日期范围',
                    'widget_granularity' => '组件粒度',
                    'widget_interval' => '组件间隔',
                    'widget_group_by' => '组件分组依据',
                    'widget_order_by' => '组件排序依据',
                    'widget_sort_order' => '组件排序顺序',
                    'widget_limit' => '组件限制',
                    'widget_offset' => '组件偏移',
                    'widget_page' => '组件页码',
                    'widget_per_page' => '组件每页数量',
                    'widget_pagination' => '组件分页',
                    'widget_navigation' => '组件导航',
                    'widget_previous' => '组件上一个',
                    'widget_next' => '组件下一个',
                    'widget_first' => '组件第一个',
                    'widget_last' => '组件最后一个',
                    'widget_total_pages' => '组件总页数',
                    'widget_total_items' => '组件总项目数',
                    'widget_items_per_page' => '组件每页项目数',
                    'widget_current_page' => '组件当前页码',
                    'widget_start_item' => '组件开始项目',
                    'widget_end_item' => '组件结束项目',
                    'widget_range_info' => '组件范围信息',
                    'widget_search_box' => '组件搜索框',
                    'widget_filter_box' => '组件筛选框',
                    'widget_sort_box' => '组件排序框',
                    'widget_select_box' => '组件选择框',
                    'widget_input_box' => '组件输入框',
                    'widget_text_box' => '组件文本框',
                    'widget_check_box' => '组件复选框',
                    'widget_radio_button' => '组件单选按钮',
                    'widget_dropdown' => '组件下拉菜单',
                    'widget_list_box' => '组件列表框',
                    'widget_combo_box' => '组件组合框',
                    'widget_date_picker' => '组件日期选择器',
                    'widget_time_picker' => '组件时间选择器',
                    'widget_datetime_picker' => '组件日期时间选择器',
                    'widget_calendar' => '组件日历',
                    'widget_clock' => '组件时钟',
                    'widget_slider' => '组件滑块',
                    'widget_range_slider' => '组件范围滑块',
                    'widget_progress_bar' => '组件进度条',
                    'widget_spinner' => '组件微调器',
                    'widget_stepper' => '组件步进器',
                    'widget_rating' => '组件评分',
                    'widget_color_picker' => '组件颜色选择器',
                    'widget_font_picker' => '组件字体选择器',
                    'widget_icon_picker' => '组件图标选择器',
                    'widget_file_upload' => '组件文件上传',
                    'widget_image_upload' => '组件图片上传',
                    'widget_video_upload' => '组件视频上传',
                    'widget_audio_upload' => '组件音频上传',
                    'widget_drag_drop' => '组件拖放',
                    'widget_drag_handle' => '组件拖动手柄',
                    'widget_resize_handle' => '组件调整大小手柄',
                    'widget_drag_indicator' => '组件拖动指示器',
                    'widget_resize_indicator' => '组件调整大小指示器',
                    'widget_placeholder' => '组件占位符',
                    'widget_empty_state' => '组件空状态',
                    'widget_loading_state' => '组件加载状态',
                    'widget_error_state' => '组件错误状态',
                    'widget_success_state' => '组件成功状态',
                    'widget_warning_state' => '组件警告状态',
                    'widget_info_state' => '组件信息状态',
                    'widget_confirm_state' => '组件确认状态',
                    'widget_prompt_state' => '组件提示状态',
                    'widget_alert_state' => '组件警报状态',
                    'widget_notice_state' => '组件通知状态',
                    'widget_message_state' => '组件消息状态',
                    'widget_tooltip' => '组件提示',
                    'widget_popover' => '组件弹出框',
                    'widget_dialog' => '组件对话框',
                    'widget_modal' => '组件模态框',
                    'widget_lightbox' => '组件灯箱',
                    'widget_sidebar' => '组件侧边栏',
                    'widget_drawer' => '组件抽屉',
                    'widget_panel' => '组件面板',
                    'widget_card' => '组件卡片',
                    'widget_tile' => '组件瓦片',
                    'widget_list' => '组件列表',
                    'widget_grid' => '组件网格',
                    'widget_table' => '组件表格',
                    'widget_tree' => '组件树',
                    'widget_timeline' => '组件时间线',
                    'widget_calendar_view' => '组件日历视图',
                    'widget_map_view' => '组件地图视图',
                    'widget_chart_view' => '组件图表视图',
                    'widget_gallery_view' => '组件画廊视图',
                    'widget_list_view' => '组件列表视图',
                    'widget_grid_view' => '组件网格视图',
                    'widget_card_view' => '组件卡片视图',
                    'widget_detail_view' => '组件详情视图',
                    'widget_summary_view' => '组件摘要视图',
                    'widget_compact_view' => '组件紧凑视图',
                    'widget_expanded_view' => '组件展开视图',
                    'widget_full_view' => '组件完整视图',
                    'widget_simplified_view' => '组件简化视图',
                    'widget_advanced_view' => '组件高级视图',
                    'widget_basic_view' => '组件基本视图',
                    'widget_pro_view' => '组件专业视图',
                    'widget_expert_view' => '组件专家视图',
                    'widget_custom_view' => '组件自定义视图',
                    'widget_save_view' => '组件保存视图',
                    'widget_load_view' => '组件加载视图',
                    'widget_manage_view' => '组件管理视图',
                    'widget_delete_view' => '组件删除视图',
                    'widget_reset_view' => '组件重置视图',
                    'widget_default_view' => '组件默认视图',
                    'widget_favorite_view' => '组件收藏视图',
                    'widget_recent_view' => '组件最近视图',
                    'widget_frequent_view' => '组件频繁视图',
                    'view_options' => '视图选项',
                    'view_settings' => '视图设置',
                    'view_preferences' => '视图偏好',
                    'view_customization' => '视图自定义',
                    'view_persistence' => '视图持久化',
                    'view_sharing' => '视图分享',
                    'view_embedding' => '视图嵌入',
                    'view_export' => '视图导出',
                    'view_printing' => '视图打印',
                    'view_refreshing' => '视图刷新',
                    'view_loading' => '视图加载',
                    'view_rendering' => '视图渲染',
                    'view_performance' => '视图性能',
                    'view_optimization' => '视图优化',
                    'view_responsive' => '视图响应式',
                    'view_accessibility' => '视图无障碍',
                    'view_usability' => '视图可用性',
                    'view_ui' => '视图界面',
                    'view_ux' => '视图体验',
                    'view_design' => '视图设计',
                    'view_layout' => '视图布局',
                    'view_components' => '视图组件',
                    'view_elements' => '视图元素',
                    'view_sections' => '视图部分',
                    'view_panels' => '视图面板',
                    'view_columns' => '视图列',
                    'view_rows' => '视图行',
                    'view_cells' => '视图单元格',
                    'view_fields' => '视图字段',
                    'view_labels' => '视图标签',
                    'view_values' => '视图值',
                    'view_headers' => '视图标题',
                    'view_footers' => '视图页脚',
                    'view_titles' => '视图标题',
                    'view_subtitles' => '视图副标题',
                    'view_descriptions' => '视图描述',
                    'view_help_text' => '视图帮助文本',
                    'view_placeholder_text' => '视图占位符文本',
                    'view_empty_text' => '视图空文本',
                    'view_error_text' => '视图错误文本',
                    'view_success_text' => '视图成功文本',
                    'view_warning_text' => '视图警告文本',
                    'view_info_text' => '视图信息文本',
                    'view_confirmation_text' => '视图确认文本',
                    'view_prompt_text' => '视图提示文本',
                    'view_alert_text' => '视图警报文本',
                    'view_notice_text' => '视图通知文本',
                    'view_message_text' => '视图消息文本',
                    'view_tooltip_text' => '视图提示文本',
                    'view_popover_text' => '视图弹出框文本',
                    'view_dialog_text' => '视图对话框文本',
                    'view_modal_text' => '视图模态框文本',
                    'view_lightbox_text' => '视图灯箱文本',
                    'view_sidebar_text' => '视图侧边栏文本',
                    'view_drawer_text' => '视图抽屉文本',
                    'view_panel_text' => '视图面板文本',
                    'view_card_text' => '视图卡片文本',
                    'view_tile_text' => '视图瓦片文本',
                    'view_list_text' => '视图列表文本',
                    'view_grid_text' => '视图网格文本',
                    'view_table_text' => '视图表格文本',
                    'view_tree_text' => '视图树文本',
                    'view_timeline_text' => '视图时间线文本',
                    'view_calendar_text' => '视图日历文本',
                    'view_map_text' => '视图地图文本',
                    'view_chart_text' => '视图图表文本',
                    'view_gallery_text' => '视图画廊文本',
                    'view_detail_text' => '视图详情文本',
                    'view_summary_text' => '视图摘要文本',
                    'view_compact_text' => '视图紧凑文本',
                    'view_expanded_text' => '视图展开文本',
                    'view_full_text' => '视图完整文本',
                    'view_simplified_text' => '视图简化文本',
                    'view_advanced_text' => '视图高级文本',
                    'view_basic_text' => '视图基本文本',
                    'view_pro_text' => '视图专业文本',
                    'view_expert_text' => '视图专家文本',
                    'view_custom_text' => '视图自定义文本',
                    'save_view_text' => '保存视图文本',
                    'load_view_text' => '加载视图文本',
                    'manage_view_text' => '管理视图文本',
                    'delete_view_text' => '删除视图文本',
                    'reset_view_text' => '重置视图文本',
                    'default_view_text' => '默认视图文本',
                    'favorite_view_text' => '收藏视图文本',
                    'recent_view_text' => '最近视图文本',
                    'frequent_view_text' => '频繁视图文本'
                ];
                break;
            case 'en_US':
                $defaultTranslations = [
                    'welcome' => 'Welcome to Card Issuing System',
                    'login' => 'Login',
                    'register' => 'Register',
                    'username' => 'Username',
                    'password' => 'Password',
                    'logout' => 'Logout',
                    'dashboard' => 'Dashboard',
                    'products' => 'Products',
                    'orders' => 'Orders',
                    'users' => 'Users',
                    'cards' => 'Cards',
                    'settings' => 'Settings',
                    'submit' => 'Submit',
                    'cancel' => 'Cancel',
                    'save' => 'Save',
                    'delete' => 'Delete',
                    'edit' => 'Edit',
                    'add' => 'Add',
                    'search' => 'Search',
                    'filter' => 'Filter',
                    'sort' => 'Sort',
                    'export' => 'Export',
                    'import' => 'Import',
                    'success' => 'Success',
                    'error' => 'Error',
                    'warning' => 'Warning',
                    'info' => 'Info',
                    'confirm' => 'Confirm',
                    'cancel' => 'Cancel',
                    'yes' => 'Yes',
                    'no' => 'No',
                    'loading' => 'Loading...',
                    'page' => 'Page',
                    'total' => 'Total',
                    'per_page' => 'Per Page',
                    'prev' => 'Previous',
                    'next' => 'Next',
                    'first' => 'First',
                    'last' => 'Last',
                    'not_found' => 'Not Found',
                    'access_denied' => 'Access Denied',
                    'server_error' => 'Server Error',
                    'network_error' => 'Network Error',
                    'timeout' => 'Timeout',
                    'invalid_input' => 'Invalid Input',
                    'required_field' => 'This field is required',
                    'email' => 'Email',
                    'phone' => 'Phone',
                    'address' => 'Address',
                    'city' => 'City',
                    'country' => 'Country',
                    'zip' => 'ZIP Code',
                    'date' => 'Date',
                    'time' => 'Time',
                    'amount' => 'Amount',
                    'currency' => 'Currency',
                    'quantity' => 'Quantity',
                    'status' => 'Status',
                    'created_at' => 'Created At',
                    'updated_at' => 'Updated At',
                    'action' => 'Action',
                    'view' => 'View',
                    'details' => 'Details',
                    'summary' => 'Summary',
                    'statistics' => 'Statistics',
                    'reports' => 'Reports',
                    'help' => 'Help',
                    'about' => 'About',
                    'support' => 'Support',
                    'feedback' => 'Feedback',
                    'terms' => 'Terms',
                    'privacy' => 'Privacy',
                    'agreement' => 'Agreement',
                    'license' => 'License',
                    'version' => 'Version',
                    'admin' => 'Admin',
                    'user' => 'User',
                    'role' => 'Role',
                    'permission' => 'Permission',
                    'profile' => 'Profile',
                    'change_password' => 'Change Password',
                    'notification' => 'Notification',
                    'message' => 'Message',
                    'system' => 'System',
                    'configuration' => 'Configuration',
                    'security' => 'Security',
                    'cache' => 'Cache',
                    'clear_cache' => 'Clear Cache',
                    'backup' => 'Backup',
                    'restore' => 'Restore',
                    'language' => 'Language',
                    'theme' => 'Theme',
                    'dark_mode' => 'Dark Mode',
                    'light_mode' => 'Light Mode',
                    'auto_mode' => 'Auto Mode'
                ];
                break;
            // 其他语言可以在这里继续添加
            default:
                // 使用中文作为默认
                $defaultTranslations = [];
        }
        
        if (!empty($defaultTranslations)) {
            $filePath = $this->languageDir . '/' . $langCode . '/common.php';
            if (!file_exists($filePath)) {
                file_put_contents($filePath, "<?php\nreturn ".var_export($defaultTranslations, true).";\n");
            }
        }
    }
    
    /**
     * 确保数据库表存在
     */
    private function ensureTablesExist() {
        try {
            // 创建语言表
            $this->db->query("CREATE TABLE IF NOT EXISTS `translations` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `key` VARCHAR(255) NOT NULL,
                `language_code` VARCHAR(10) NOT NULL,
                `value` TEXT,
                `context` VARCHAR(255) DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_key_language` (`key`, `language_code`, `context`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
            
            // 创建语言设置表
            $this->db->query("CREATE TABLE IF NOT EXISTS `user_language_settings` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NOT NULL,
                `language_code` VARCHAR(10) NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_user_language` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
            
        } catch (Exception $e) {
            // 记录错误但不中断程序
            error_log("Failed to create translation tables: " . $e->getMessage());
        }
    }
    
    /**
     * 检测用户语言
     * 
     * @return string 语言代码
     */
    private function detectUserLanguage() {
        // 1. 从用户设置中获取
        if ($this->db && isset($_SESSION['user_id'])) {
            // 确保user_id是整数类型
            $userId = is_array($_SESSION['user_id']) || !is_numeric($_SESSION['user_id']) ? 0 : (int)$_SESSION['user_id'];
            // 使用预处理语句修复参数传递类型错误
            $stmt = $this->db->prepare("SELECT language_code FROM user_language_settings WHERE user_id = ?");
            $userIdInt = (int)$userId;
            $stmt->bind_param("i", $userIdInt);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                if (isset($this->supportedLanguages[$row['language_code']])) {
                    return $row['language_code'];
                }
            }
        }
        
        // 2. 从 cookie 中获取
        if (isset($_COOKIE['language'])) {
            if (isset($this->supportedLanguages[$_COOKIE['language']])) {
                return $_COOKIE['language'];
            }
        }
        
        // 3. 从浏览器 Accept-Language 头中获取
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $acceptLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
            
            // 解析 Accept-Language 头
            preg_match_all('/([a-z]{1,8}(-[a-z]{1,8})?)(;q=([0-9.]+))?/', $acceptLanguage, $matches);
            
            $languages = [];
            if (!empty($matches[1])) {
                for ($i = 0; $i < count($matches[1]); $i++) {
                    $langCode = str_replace('-', '_', strtolower($matches[1][$i]));
                    $quality = isset($matches[4][$i]) ? (float)$matches[4][$i] : 1.0;
                    $languages[$langCode] = $quality;
                }
                
                // 按质量排序
                arsort($languages);
                
                // 查找支持的语言
                foreach ($languages as $langCode => $quality) {
                    // 尝试精确匹配
                    if (isset($this->supportedLanguages[$langCode])) {
                        return $langCode;
                    }
                    
                    // 尝试语言代码的第一部分匹配（如 en_US -> en）
                    $langParts = explode('_', $langCode);
                    if (count($langParts) > 1) {
                        $baseLang = $langParts[0];
                        foreach ($this->supportedLanguages as $supportedLang => $langName) {
                            if (strpos($supportedLang, $baseLang . '_') === 0) {
                                return $supportedLang;
                            }
                        }
                    }
                }
            }
        }
        
        // 默认返回默认语言
        return $this->defaultLanguage;
    }
    
    /**
     * 设置当前语言
     * 
     * @param string $langCode 语言代码
     * @return bool 是否设置成功
     */
    public function setCurrentLanguage($langCode) {
        if (!isset($this->supportedLanguages[$langCode])) {
            return false;
        }
        
        $this->currentLanguage = $langCode;
        
        // 保存到 cookie
        setcookie('language', $langCode, time() + 365 * 24 * 60 * 60, '/', '', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on');
        
        // 如果用户已登录，保存到数据库
        if ($this->db && isset($_SESSION['user_id'])) {
            // 确保user_id是整数类型
            $userId = is_array($_SESSION['user_id']) || !is_numeric($_SESSION['user_id']) ? 0 : (int)$_SESSION['user_id'];
            // 使用预处理语句修复参数传递类型错误
            $stmt = $this->db->prepare("INSERT INTO user_language_settings (user_id, language_code) VALUES (?, ?) ON DUPLICATE KEY UPDATE language_code = ?");
            $userIdInt = (int)$userId;
            $langCodeStr = (string)$langCode;
            $stmt->bind_param("iss", $userIdInt, $langCodeStr, $langCodeStr);
            $stmt->execute();
        }
        
        // 清除缓存
        $this->translationCache = [];
        
        return true;
    }
    
    /**
     * 获取当前语言
     * 
     * @return string 当前语言代码
     */
    public function getCurrentLanguage() {
        return $this->currentLanguage;
    }
    
    /**
     * 获取支持的语言列表
     * 
     * @return array 语言列表 [语言代码 => 语言名称]
     */
    public function getSupportedLanguages() {
        return $this->supportedLanguages;
    }
    
    /**
     * 翻译文本
     * 
     * @param string $key 翻译键
     * @param array $params 替换参数
     * @param string $context 上下文
     * @return string 翻译后的文本
     */
    public function trans($key, $params = [], $context = null) {
        // 参数类型检查
        if (!is_string($key)) {
            trigger_error('Translation key must be a string', E_USER_WARNING);
            return (string)$key;
        }
        if (!is_array($params)) {
            $params = [];
        }
        if ($context !== null && !is_string($context)) {
            $context = null;
        }
        
        // 尝试从缓存获取
        $cacheKey = $this->getCacheKey($key, $context);
        if ($this->config['cache_enabled'] && isset($this->translationCache[$cacheKey])) {
            $translation = $this->translationCache[$cacheKey];
        } else {
            // 尝试从数据库获取
            $translation = null;
            if (is_object($this->db) && $this->config['db_enabled']) {
                try {
                    // 使用正确的预处理语句语法
                    if ($context) {
                        // 准备语句
                        $stmt = $this->db->prepare("SELECT value FROM translations WHERE `key` = ? AND language_code = ? AND context = ?");
                        if ($stmt) {
                            // 绑定参数
                            $stmt->bind_param("sss", $key, $this->currentLanguage, $context);
                            // 执行查询
                            $stmt->execute();
                            // 获取结果
                            $result = $stmt->get_result();
                            if ($result && ($row = $result->fetch_assoc()) && isset($row['value'])) {
                                $translation = $row['value'];
                            }
                            $stmt->close();
                        }
                    } else {
                        // 准备语句
                        $stmt = $this->db->prepare("SELECT value FROM translations WHERE `key` = ? AND language_code = ? AND (context IS NULL OR context = '')");
                        if ($stmt) {
                            // 绑定参数
                            $stmt->bind_param("ss", $key, $this->currentLanguage);
                            // 执行查询
                            $stmt->execute();
                            // 获取结果
                            $result = $stmt->get_result();
                            if ($result && ($row = $result->fetch_assoc()) && isset($row['value'])) {
                                $translation = $row['value'];
                            }
                            $stmt->close();
                        }
                    }
                } catch (Exception $e) {
                    // 忽略数据库错误
                }
            }
            
            // 尝试从语言文件获取
            if ($translation === null) {
                $translation = $this->loadFromFile($key, $context);
            }
            
            // 如果启用了回退机制且当前语言不是默认语言，尝试使用默认语言
            if ($translation === null && $this->config['fallback_enabled'] && $this->currentLanguage !== $this->defaultLanguage) {
                $translation = $this->loadFromDefaultLanguage($key, $context);
            }
            
            // 如果还是找不到翻译，返回键本身
            if ($translation === null) {
                $translation = $key;
                
                // 自动添加缺失的翻译到数据库（仅在启用了数据库时）
                if ($this->db && $this->config['db_enabled']) {
                    $this->addMissingTranslation($key, $key, $context);
                }
            }
            
            // 缓存翻译
            if ($this->config['cache_enabled']) {
                $this->translationCache[$cacheKey] = $translation;
                
                // 如果有Redis连接，也缓存到Redis
                if ($this->redis) {
                    try {
                        $redisKey = 'trans:' . $this->currentLanguage . ':' . $cacheKey;
                        $this->redis->setex($redisKey, $this->config['cache_ttl'], $translation);
                    } catch (Exception $e) {
                        // 忽略Redis错误
                    }
                }
            }
        }
        
        // 替换参数
        if (!empty($params)) {
            foreach ($params as $paramName => $paramValue) {
                $translation = str_replace('{' . $paramName . '}', $paramValue, $translation);
            }
        }
        
        return $translation;
    }
    
    /**
     * 获取缓存键
     * 
     * @param string $key 翻译键
     * @param string $context 上下文
     * @return string 缓存键
     */
    private function getCacheKey($key, $context) {
        // 确保key是字符串类型
        $key = (string)$key;
        // 确保context是字符串类型或null
        $context = $context !== null ? (string)$context : null;
        return $context ? $key . ':' . $context : $key;
    }
    
    /**
     * 从语言文件加载翻译
     * 
     * @param string $key 翻译键
     * @param string $context 上下文
     * @return string|null 翻译文本或null
     */
    private function loadFromFile($key, $context) {
        $langDir = $this->languageDir . '/' . $this->currentLanguage;
        
        // 尝试从上下文文件加载
        if ($context) {
            $contextFile = $langDir . '/' . $context . '.php';
            if (file_exists($contextFile)) {
                $translations = require $contextFile;
                if (is_array($translations) && isset($translations[$key])) {
                    return $translations[$key];
                }
            }
        }
        
        // 尝试从公共文件加载
        $commonFile = $langDir . '/common.php';
        if (file_exists($commonFile)) {
            $translations = require $commonFile;
            if (is_array($translations) && isset($translations[$key])) {
                return $translations[$key];
            }
        }
        
        return null;
    }
    
    /**
     * 从默认语言加载翻译
     * 
     * @param string $key 翻译键
     * @param string $context 上下文
     * @return string|null 翻译文本或null
     */
    private function loadFromDefaultLanguage($key, $context) {
        // 如果当前语言已经是默认语言，直接返回null
        if ($this->currentLanguage === $this->defaultLanguage) {
            return null;
        }
        
        $langDir = $this->languageDir . '/' . $this->defaultLanguage;
        
        // 尝试从上下文文件加载
        if ($context) {
            $contextFile = $langDir . '/' . $context . '.php';
            if (file_exists($contextFile)) {
                $translations = require $contextFile;
                if (is_array($translations) && isset($translations[$key])) {
                    return $translations[$key];
                }
            }
        }
        
        // 尝试从公共文件加载
        $commonFile = $langDir . '/common.php';
        if (file_exists($commonFile)) {
            $translations = require $commonFile;
            if (is_array($translations) && isset($translations[$key])) {
                return $translations[$key];
            }
        }
        
        return null;
    }
    
    /**
     * 添加缺失的翻译
     * 
     * @param string $key 翻译键
     * @param string $value 翻译值
     * @param string $context 上下文
     */
    private function addMissingTranslation($key, $value, $context) {
        // 确保参数都是字符串类型
        $key = (string)$key;
        $value = (string)$value;
        $context = $context !== null ? (string)$context : null;
        
        try {
            if ($context) {
                $this->db->query("INSERT INTO translations (`key`, language_code, value, context) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE value = ?", [(string)$key, (string)$this->currentLanguage, (string)$value, (string)$context, (string)$value]);
            } else {
                $this->db->query("INSERT INTO translations (`key`, language_code, value, context) VALUES (?, ?, ?, NULL) ON DUPLICATE KEY UPDATE value = ?", [(string)$key, (string)$this->currentLanguage, (string)$value, (string)$value]);
            }
        } catch (Exception $e) {
            // 忽略数据库错误
        }
    }
    
    /**
     * 设置翻译
     * 
     * @param string $key 翻译键
     * @param string $value 翻译值
     * @param string $context 上下文
     * @param string $langCode 语言代码，默认为当前语言
     * @return bool 是否设置成功
     */
    public function setTranslation($key, $value, $context = null, $langCode = null) {
        if (!$langCode) {
            $langCode = $this->currentLanguage;
        }
        
        if (!isset($this->supportedLanguages[$langCode])) {
            return false;
        }
        
        // 保存到数据库
        $success = false;
        if ($this->db && $this->config['db_enabled']) {
            try {
                if ($context) {
                    $this->db->query("INSERT INTO translations (`key`, language_code, value, context) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE value = ?", [(string)$key, (string)$langCode, (string)$value, (string)$context, (string)$value]);
                } else {
                    $this->db->query("INSERT INTO translations (`key`, language_code, value, context) VALUES (?, ?, ?, NULL) ON DUPLICATE KEY UPDATE value = ?", [(string)$key, (string)$langCode, (string)$value, (string)$value]);
                }
                $success = true;
            } catch (Exception $e) {
                error_log("Failed to set translation: " . $e->getMessage());
            }
        }
        
        // 保存到文件
        try {
            $this->saveToFile($key, $value, $context, $langCode);
            $success = true;
        } catch (Exception $e) {
            error_log("Failed to save translation to file: " . $e->getMessage());
        }
        
        // 清除缓存
        $cacheKey = $this->getCacheKey($key, $context);
        if (isset($this->translationCache[$cacheKey])) {
            unset($this->translationCache[$cacheKey]);
        }
        
        // 清除Redis缓存
        if ($this->redis) {
            try {
                $redisKey = 'trans:' . $langCode . ':' . $cacheKey;
                $this->redis->del($redisKey);
            } catch (Exception $e) {
                // 忽略Redis错误
            }
        }
        
        return $success;
    }
    
    /**
     * 保存翻译到文件
     * 
     * @param string $key 翻译键
     * @param string $value 翻译值
     * @param string $context 上下文
     * @param string $langCode 语言代码
     */
    private function saveToFile($key, $value, $context, $langCode) {
        // 确保参数都是字符串类型
        $key = (string)$key;
        $value = (string)$value;
        $context = $context !== null ? (string)$context : null;
        $langCode = (string)$langCode;
        
        $langDir = $this->languageDir . '/' . $langCode;
        
        // 确定要保存的文件
        $file = $context ? ($langDir . '/' . $context . '.php') : ($langDir . '/common.php');
        
        // 确保目录存在
        if (!is_dir(dirname($file))) {
            mkdir(dirname($file), 0755, true);
        }
        
        // 加载现有翻译
        $translations = [];
        if (file_exists($file)) {
            $translations = require $file;
            if (!is_array($translations)) {
                $translations = [];
            }
        }
        
        // 添加或更新翻译
        $translations[$key] = $value;
        
        // 保存到文件
        file_put_contents($file, "<?php\nreturn ".var_export($translations, true).";\n");
    }
    
    /**
     * 批量设置翻译
     * 
     * @param array $translations 翻译数组 [键 => 值]
     * @param string $context 上下文
     * @param string $langCode 语言代码，默认为当前语言
     * @return bool 是否全部设置成功
     */
    public function setTranslations(array $translations, $context = null, $langCode = null) {
        $allSuccess = true;
        
        foreach ($translations as $key => $value) {
            if (!$this->setTranslation($key, $value, $context, $langCode)) {
                $allSuccess = false;
            }
        }
        
        return $allSuccess;
    }
    
    /**
     * 删除翻译
     * 
     * @param string $key 翻译键
     * @param string $context 上下文
     * @param string $langCode 语言代码，默认为当前语言
     * @return bool 是否删除成功
     */
    public function deleteTranslation($key, $context = null, $langCode = null) {
        // 类型检查
        $key = (string)$key;
        $context = $context !== null ? (string)$context : null;
        $langCode = $langCode !== null ? (string)$langCode : $this->currentLanguage;
        
        if (!isset($this->supportedLanguages[$langCode])) {
            return false;
        }
        
        // 从数据库删除
        $success = false;
        if ($this->db && is_object($this->db) && $this->config['db_enabled']) {
            try {
                if ($context) {
                    $this->db->query("DELETE FROM translations WHERE `key` = ? AND language_code = ? AND context = ?", [$key, $langCode, $context]);
                } else {
                    $this->db->query("DELETE FROM translations WHERE `key` = ? AND language_code = ? AND (context IS NULL OR context = '')", [$key, $langCode]);
                }
                $success = true;
            } catch (Exception $e) {
                error_log("Failed to delete translation: " . $e->getMessage());
            }
        }
        
        // 从文件删除
        try {
            $this->removeFromFile($key, $context, $langCode);
            $success = true;
        } catch (Exception $e) {
            error_log("Failed to remove translation from file: " . $e->getMessage());
        }
        
        // 清除缓存
        $cacheKey = $this->getCacheKey($key, $context);
        if (isset($this->translationCache[$cacheKey])) {
            unset($this->translationCache[$cacheKey]);
        }
        
        // 清除Redis缓存
        if ($this->redis) {
            try {
                $redisKey = 'trans:' . $langCode . ':' . $cacheKey;
                $this->redis->del($redisKey);
            } catch (Exception $e) {
                // 忽略Redis错误
            }
        }
        
        return $success;
    }
    
    /**
     * 从文件中删除翻译
     * 
     * @param string $key 翻译键
     * @param string $context 上下文
     * @param string $langCode 语言代码
     */
    private function removeFromFile($key, $context, $langCode) {
        $langDir = $this->languageDir . '/' . $langCode;
        
        // 确定要删除的文件
        $file = $context ? ($langDir . '/' . $context . '.php') : ($langDir . '/common.php');
        
        if (file_exists($file)) {
            // 加载现有翻译
            $translations = require $file;
            if (is_array($translations) && isset($translations[$key])) {
                // 删除翻译
                unset($translations[$key]);
                
                // 保存到文件
                if (!empty($translations)) {
                    file_put_contents($file, "<?php\nreturn ".var_export($translations, true).";\n");
                } else {
                    // 如果没有翻译了，删除文件
                    unlink($file);
                }
            }
        }
    }
    
    /**
     * 导出翻译
     * 
     * @param string $langCode 语言代码，默认为当前语言
     * @param string $context 上下文，null表示全部
     * @return array 翻译数组
     */
    public function exportTranslations($langCode = null, $context = null) {
        if (!$langCode) {
            $langCode = $this->currentLanguage;
        }
        
        if (!isset($this->supportedLanguages[$langCode])) {
            return [];
        }
        
        $translations = [];
        
        // 从数据库导出
        if ($this->db && $this->config['db_enabled']) {
            if ($context) {
                // 使用预处理语句修复参数传递类型错误
                $stmt = $this->db->prepare("SELECT `key`, value, context FROM translations WHERE language_code = ? AND context = ?");
                $langStr = (string)$langCode;
                $contextStr = (string)$context;
                $stmt->bind_param("ss", $langStr, $contextStr);
                $stmt->execute();
                $result = $stmt->get_result();
            } else {
                // 使用预处理语句修复参数传递类型错误
                $stmt = $this->db->prepare("SELECT `key`, value, context FROM translations WHERE language_code = ?");
                $stmt->bind_param("s", (string)$langCode);
                $stmt->execute();
                $result = $stmt->get_result();
            }
            if (is_object($result)) {
                while ($row = $result->fetch_assoc()) {
                    if (is_array($row) && isset($row['key']) && isset($row['value'])) {
                        $ctx = isset($row['context']) && $row['context'] ? $row['context'] : 'common';
                        if (!isset($translations[$ctx])) {
                            $translations[$ctx] = [];
                        }
                        $translations[$ctx][$row['key']] = $row['value'];
                    }
                }
            }
        } else {
            // 从文件导出
            $langDir = $this->languageDir . '/' . $langCode;
            
            if ($context) {
                // 导出特定上下文
                $file = $langDir . '/' . $context . '.php';
                if (file_exists($file)) {
                    $translations[$context] = require $file;
                }
            } else {
                // 导出所有上下文
                if (is_dir($langDir)) {
                    $files = glob($langDir . '/*.php');
                    foreach ($files as $file) {
                        $ctx = basename($file, '.php');
                        $translations[$ctx] = require $file;
                    }
                }
            }
        }
        
        return $translations;
    }
    
    /**
     * 导入翻译
     * 
     * @param array $translations 翻译数组 [上下文 => [键 => 值]]
     * @param string $langCode 语言代码，默认为当前语言
     * @param bool $replace 是否替换现有翻译
     * @return bool 是否导入成功
     */
    public function importTranslations(array $translations, $langCode = null, $replace = true) {
        // 类型检查和转换
        $langCode = $langCode !== null ? (string)$langCode : $this->currentLanguage;
        $replace = (bool)$replace;
        
        if (!isset($this->supportedLanguages[$langCode])) {
            return false;
        }
        
        foreach ($translations as $context => $contextTranslations) {
            $context = (string)$context;
            
            if (!is_array($contextTranslations)) {
                continue;
            }
            
            foreach ($contextTranslations as $key => $value) {
                $key = (string)$key;
                $value = (string)$value;
                
                // 如果不替换，检查是否已存在
                if (!$replace && $this->hasTranslation($key, $context, $langCode)) {
                    continue;
                }
                
                if (!$this->setTranslation($key, $value, $context === 'common' ? null : $context, $langCode)) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /**
     * 检查翻译是否存在
     * 
     * @param string $key 翻译键
     * @param string $context 上下文
     * @param string $langCode 语言代码，默认为当前语言
     * @return bool 是否存在
     */
    public function hasTranslation($key, $context = null, $langCode = null) {
        // 类型检查和转换
        $key = (string)$key;
        $context = $context !== null ? (string)$context : null;
        $langCode = $langCode !== null ? (string)$langCode : $this->currentLanguage;
        
        if (!isset($this->supportedLanguages[$langCode])) {
            return false;
        }
        
        // 检查缓存
        $cacheKey = $this->getCacheKey($key, $context);
        if (isset($this->translationCache[$cacheKey])) {
            return true;
        }
        
        // 检查数据库
        if ($this->db && is_object($this->db) && $this->config['db_enabled']) {
            try {
                if ($context) {
                    $result = $this->db->query("SELECT COUNT(*) FROM translations WHERE `key` = ? AND language_code = ? AND context = ?", [(string)$key, (string)$langCode, (string)$context]);
                } else {
                    $result = $this->db->query("SELECT COUNT(*) FROM translations WHERE `key` = ? AND language_code = ? AND (context IS NULL OR context = '')", [(string)$key, (string)$langCode]);
                }
                // 安全地获取查询结果
                $rowCount = 0;
                if (is_object($result) && method_exists($result, 'fetch_row') && is_callable([$result, 'fetch_row'])) {
                    $row = $result->fetch_row();
                    if (is_array($row) && isset($row[0])) {
                        // 确保$row[0]不是数组且能安全转换为整数
                        if (is_array($row[0])) {
                            $rowCount = 0;
                        } else {
                            $rowCount = filter_var($row[0], FILTER_VALIDATE_INT, ['options' => ['default' => 0]]);
                        }
                    }
                }
                
                if ($rowCount > 0) {
                    return true;
                }
            } catch (Exception $e) {
                // 如果数据库查询失败，继续检查文件
                error_log("Database translation check failed: " . $e->getMessage());
            }
        }
        
        // 检查文件
        $langDir = $this->languageDir . '/' . $langCode;
        $file = $context ? ($langDir . '/' . $context . '.php') : ($langDir . '/common.php');
        
        if (file_exists($file)) {
            try {
                $translations = require $file;
                if (is_array($translations) && isset($translations[$key])) {
                    return true;
                }
            } catch (Exception $e) {
                error_log("Failed to load translation file: " . $e->getMessage());
            }
        }
        
        return false;
    }
    

    
    /**
     * 清除缓存
     * 
     * @param string|null $langCode 语言代码，null表示所有语言
     */
    public function clearCache($langCode = null) {
        // 验证langCode参数类型
        if ($langCode !== null && !is_string($langCode)) {
            error_log("Invalid langCode type: expected string or null, got " . gettype($langCode));
            return;
        }
        // 清除内存缓存
        $this->translationCache = [];
        
        // 清除Redis缓存
        if ($this->redis) {
            try {
                if ($langCode) {
                    if (isset($this->supportedLanguages[$langCode])) {
                        $keys = $this->redis->keys('trans:' . $langCode . ':*');
                        if (!empty($keys)) {
                            $this->redis->del($keys);
                        }
                    }
                } else {
                    // 清除所有语言的缓存
                    foreach ($this->supportedLanguages as $supportedLang => $langName) {
                        $keys = $this->redis->keys('trans:' . $supportedLang . ':*');
                        if (!empty($keys)) {
                            $this->redis->del($keys);
                        }
                    }
                }
            } catch (Exception $e) {
                // 忽略Redis错误
            }
        }
    }
    
    /**
     * 设置用户语言偏好
     * 
     * @param int|string $userId 用户ID
     * @param string $langCode 语言代码
     * @return bool 是否设置成功
     */
    public function setUserLanguagePreference($userId, $langCode) {
        // 验证并转换userId为整数类型
        if (is_array($userId) || !is_numeric($userId)) {
            error_log("Invalid userId type: expected int, got " . gettype($userId));
            return false;
        }
        
        $userId = (int)$userId;
        // 验证langCode参数类型
        if (!is_string($langCode)) {
            error_log("Invalid langCode type: expected string, got " . gettype($langCode));
            return false;
        }
        
        if (!isset($this->supportedLanguages[$langCode]) || !$this->db || !$this->config['db_enabled']) {
            return false;
        }
        
        try {
            // 使用预处理语句修复参数传递类型错误
            $stmt = $this->db->prepare("INSERT INTO user_language_settings (user_id, language_code) VALUES (?, ?) ON DUPLICATE KEY UPDATE language_code = ?");
            if ($stmt) {
                $userIdInt = (int)$userId;
                $langCodeStr = (string)$langCode;
                $stmt->bind_param("iss", $userIdInt, $langCodeStr, $langCodeStr);
                $stmt->execute();
                return true;
            }
            return false;
        } catch (Exception $e) {
            error_log("Failed to set user language preference: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取用户语言偏好
     * 
     * @param int|string $userId 用户ID
     * @return string|null 语言代码或null
     */
    public function getUserLanguagePreference($userId) {
        // 验证并转换userId为整数类型
        if (is_array($userId) || !is_numeric($userId)) {
            error_log("Invalid userId type: expected int, got " . gettype($userId));
            return null;
        }
        
        $userId = (int)$userId;
        
        if (!$this->db || !$this->config['db_enabled']) {
            return null;
        }
        
        try {
            $result = $this->db->query("SELECT language_code FROM user_language_settings WHERE user_id = ?", [(int)$userId]);
            if ($row = $result->fetch_assoc()) {
                return $row['language_code'];
            }
        } catch (Exception $e) {
            error_log("Failed to get user language preference: " . $e->getMessage());
        }
        
        return null;
    }
    
    /**
     * 获取语言统计信息
     * 
     * @param string|null $langCode 语言代码，null表示所有语言
     * @return array 统计信息
     */
    public function getStatistics($langCode = null) {
        $stats = [];
        // 验证langCode参数类型
        if ($langCode !== null && !is_string($langCode)) {
            error_log("Invalid langCode type: expected string or null, got " . gettype($langCode));
            return $stats;
        }
        
        if ($this->db && $this->config['db_enabled']) {
            if ($langCode) {
                // 特定语言的统计
                if (isset($this->supportedLanguages[$langCode])) {
                    $result = $this->db->query("SELECT COUNT(*) FROM translations WHERE language_code = ?", [$langCode]);
                    if (is_object($result) && ($row = $result->fetch_row()) && is_array($row) && isset($row[0]) && !is_array($row[0])) {
                        $stats[$langCode] = [
                            'total' => (int)$row[0],
                            'contexts' => []
                        ];
                        
                        // 获取上下文统计
                        $result = $this->db->query("SELECT context, COUNT(*) as count FROM translations WHERE language_code = ? GROUP BY context", [$langCode]);
                        if (is_object($result)) {
                            while ($row = $result->fetch_assoc()) {
                                    $ctx = $row['context'] ?: 'common';
                                    // 确保count是整数类型
                                    $count = isset($row['count']) && !is_array($row['count']) ? (int)$row['count'] : 0;
                                    $stats[$langCode]['contexts'][$ctx] = $count;
                                }
                        }
                    }
                }
            } else {
                // 所有语言的统计
                foreach ($this->supportedLanguages as $supportedLang => $langName) {
                    $result = $this->db->query("SELECT COUNT(*) FROM translations WHERE language_code = ?", [$supportedLang]);
                    if (is_object($result) && ($row = $result->fetch_row()) && is_array($row) && isset($row[0]) && !is_array($row[0])) {
                        $stats[$supportedLang] = [
                            'total' => (int)$row[0],
                            'contexts' => []
                        ];
                    }
                }
            }
        }
        
        return $stats;
    }
}

// 快捷函数
if (!function_exists('__')) {
}

/**
 * 翻译快捷函数
 * 
 * @param string $key 翻译键
 * @param array $params 替换参数
 * @param string|null $context 上下文
 * @return string 翻译后的文本
 */
function __($key, $params = [], $context = null) {
    // 验证参数类型
    if (!is_string($key)) {
        error_log("Invalid key type: expected string, got " . gettype($key));
        return '';
    }
    
    if (!is_array($params)) {
        error_log("Invalid params type: expected array, got " . gettype($params));
        $params = [];
    }
    global $translator;
    if (!isset($translator) || !$translator instanceof Translator) {
        return $key;
    }
    return $translator->trans($key, $params, $context);
}

if (!function_exists('trans')) {
    /**
     * 翻译快捷函数（别名）
     * 
     * @param string $key 翻译键
     * @param array $params 替换参数
     * @param string|null $context 上下文
     * @return string 翻译后的文本
     */
    function trans($key, $params = [], $context = null) {
        return __($key, $params, $context);
    }
}