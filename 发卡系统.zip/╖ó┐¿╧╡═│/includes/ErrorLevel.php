<?php
/**
 * 统一的错误级别常量定义
 * 用于整个应用程序的错误处理和日志记录
 */

/**
 * 错误级别常量类
 * 提供统一的错误级别定义，支持字符串和数字两种格式
 */
class ErrorLevel {
    // 字符串格式常量（用于ErrorHandler）
    const DEBUG = 'DEBUG';
    const INFO = 'INFO';
    const WARNING = 'WARNING';
    const ERROR = 'ERROR';
    const CRITICAL = 'CRITICAL';
    const EMERGENCY = 'EMERGENCY';
    
    // 数字格式常量（用于Logger）
    const DEBUG_NUM = 100;
    const INFO_NUM = 200;
    const WARNING_NUM = 300;
    const ERROR_NUM = 400;
    const CRITICAL_NUM = 500;
    const EMERGENCY_NUM = 600;
    
    /**
     * 获取字符串格式的级别名称
     */
    public static function getLevelName($level) {
        $mapping = [
            self::DEBUG_NUM => self::DEBUG,
            self::INFO_NUM => self::INFO,
            self::WARNING_NUM => self::WARNING,
            self::ERROR_NUM => self::ERROR,
            self::CRITICAL_NUM => self::CRITICAL,
            self::EMERGENCY_NUM => self::EMERGENCY
        ];
        
        return isset($mapping[$level]) ? $mapping[$level] : self::ERROR;
    }
    
    /**
     * 获取数字格式的级别值
     */
    public static function getLevelNumber($level) {
        $mapping = [
            self::DEBUG => self::DEBUG_NUM,
            self::INFO => self::INFO_NUM,
            self::WARNING => self::WARNING_NUM,
            self::ERROR => self::ERROR_NUM,
            self::CRITICAL => self::CRITICAL_NUM,
            self::EMERGENCY => self::EMERGENCY_NUM
        ];
        
        return isset($mapping[$level]) ? $mapping[$level] : self::ERROR_NUM;
    }
}