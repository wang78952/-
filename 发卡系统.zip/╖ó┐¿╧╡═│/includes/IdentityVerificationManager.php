<?php
require_once __DIR__ . '/SecurityUtils.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/../config.php';

/**
 * 身份核验管理器
 * 提供用户身份核验、多级审核、卡片激活认证等核心业务功能
 */
class IdentityVerificationManager {
    
    // 身份核验状态
    const VERIFICATION_STATUS_PENDING = 'pending';           // 待核验
    const VERIFICATION_STATUS_IN_REVIEW = 'in_review';        // 审核中
    const VERIFICATION_STATUS_APPROVED = 'approved';         // 已通过
    const VERIFICATION_STATUS_REJECTED = 'rejected';          // 已拒绝
    const VERIFICATION_STATUS_NEED_MORE_INFO = 'need_info';   // 需要补充信息
    
    // 审核级别
    const REVIEW_LEVEL_1 = 1;  // 一级审核
    const REVIEW_LEVEL_2 = 2;  // 二级审核
    const REVIEW_LEVEL_3 = 3;  // 三级审核
    
    // 卡片激活状态
    const ACTIVATION_STATUS_PENDING = 'pending';     // 待激活
    const ACTIVATION_STATUS_ACTIVE = 'active';       // 已激活
    const ACTIVATION_STATUS_SUSPENDED = 'suspended'; // 暂停
    const ACTIVATION_STATUS_BLOCKED = 'blocked';     // 已冻结
    
    /**
     * 创建身份核验申请
     */
    public static function createVerificationRequest($userId, $cardId, $verificationData) {
        try {
            $db = Database::getInstance();
            
            // 加密敏感信息
            $encryptedData = array(
                'id_number' => SecurityUtils::encrypt(isset($verificationData['id_number']) ? $verificationData['id_number'] : ''),
                'id_front_image' => SecurityUtils::encrypt(isset($verificationData['id_front_image']) ? $verificationData['id_front_image'] : ''),
                'id_back_image' => SecurityUtils::encrypt(isset($verificationData['id_back_image']) ? $verificationData['id_back_image'] : ''),
                'selfie_image' => SecurityUtils::encrypt(isset($verificationData['selfie_image']) ? $verificationData['selfie_image'] : ''),
                'phone_number' => SecurityUtils::encrypt(isset($verificationData['phone_number']) ? $verificationData['phone_number'] : ''),
                'email' => SecurityUtils::encrypt(isset($verificationData['email']) ? $verificationData['email'] : ''),
                'address' => SecurityUtils::encrypt(isset($verificationData['address']) ? $verificationData['address'] : ''),
            );
            
            // 生成核验ID
            $verificationId = self::generateVerificationId();
            
            // 插入核验申请
            $sql = "INSERT INTO identity_verifications (
                verification_id, user_id, card_id, verification_type,
                id_number_encrypted, id_front_image_encrypted, id_back_image_encrypted,
                selfie_image_encrypted, phone_number_encrypted, email_encrypted,
                address_encrypted, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            
            $params = array(
                $verificationId,
                $userId,
                $cardId,
                isset($verificationData['verification_type']) ? $verificationData['verification_type'] : 'standard',
                $encryptedData['id_number'],
                $encryptedData['id_front_image'],
                $encryptedData['id_back_image'],
                $encryptedData['selfie_image'],
                $encryptedData['phone_number'],
                $encryptedData['email'],
                $encryptedData['address'],
                self::VERIFICATION_STATUS_PENDING
            );
            
            $db->execute($sql, $params);
            
            // 记录操作日志
            SecurityUtils::logSecurity('INFO', '身份核验申请已创建', array(
                'verification_id' => $verificationId,
                'user_id' => $userId,
                'card_id' => $cardId,
                'verification_type' => isset($verificationData['verification_type']) ? $verificationData['verification_type'] : 'standard'
            ));
            
            return $verificationId;
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '创建身份核验申请失败', array(
                'user_id' => $userId,
                'card_id' => $cardId,
                'error' => $e->getMessage()
            ));
            throw new Exception('创建身份核验申请失败：' . $e->getMessage());
        }
    }
    
    /**
     * 提交审核
     */
    public static function submitForReview($verificationId, $reviewLevel, $reviewerId, $reviewData) {
        try {
            $db = Database::getInstance();
            
            // 检查核验申请是否存在
            $verification = self::getVerificationById($verificationId);
            if (!$verification) {
                throw new Exception('核验申请不存在');
            }
            
            // 检查审核权限
            if (!self::canReview($reviewerId, $reviewLevel)) {
                throw new Exception('无权限进行此级别审核');
            }
            
            // 插入审核记录
            $sql = "INSERT INTO verification_reviews (
                verification_id, review_level, reviewer_id, review_result,
                review_comment, review_data, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW())";
            
            $params = array(
                $verificationId,
                $reviewLevel,
                $reviewerId,
                isset($reviewData['result']) ? $reviewData['result'] : 'approved',
                isset($reviewData['comment']) ? $reviewData['comment'] : '',
                json_encode(isset($reviewData['data']) ? $reviewData['data'] : array())
            );
            
            $db->execute($sql, $params);
            
            // 更新核验状态
            $newStatus = self::determineNewStatus($verificationId, $reviewLevel, isset($reviewData['result']) ? $reviewData['result'] : 'approved');
            self::updateVerificationStatus($verificationId, $newStatus);
            
            // 如果审核通过，自动进入下一级审核
            if ($reviewData['result'] === 'approved' && $reviewLevel < 3) {
                self::submitForNextLevel($verificationId, $reviewLevel + 1);
            }
            
            // 记录操作日志
            SecurityUtils::logSecurity('INFO', '身份核验审核完成', array(
                'verification_id' => $verificationId,
                'review_level' => $reviewLevel,
                'reviewer_id' => $reviewerId,
                'review_result' => isset($reviewData['result']) ? $reviewData['result'] : 'approved'
            ));
            
            return true;
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '身份核验审核失败', array(
                'verification_id' => $verificationId,
                'reviewer_id' => $reviewerId,
                'error' => $e->getMessage()
            ));
            throw new Exception('身份核验审核失败：' . $e->getMessage());
        }
    }
    
    /**
     * 激活卡片
     */
    public static function activateCard($cardId, $activationData) {
        try {
            $db = Database::getInstance();
            
            // 检查卡片是否存在
            $card = self::getCardById($cardId);
            if (!$card) {
                throw new Exception('卡片不存在');
            }
            
            // 检查身份核验是否通过
            $verification = self::getVerificationByCardId($cardId);
            if (!$verification || $verification['status'] !== self::VERIFICATION_STATUS_APPROVED) {
                throw new Exception('身份核验未通过，无法激活卡片');
            }
            
            // 生成激活码
            $activationCode = self::generateActivationCode();
            
            // 插入激活记录
            $sql = "INSERT INTO card_activations (
                card_id, activation_code, activation_method, activation_data,
                status, activated_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())";
            
            $params = array(
                $cardId,
                $activationCode,
                isset($activationData['method']) ? $activationData['method'] : 'online',
                json_encode($activationData),
                self::ACTIVATION_STATUS_ACTIVE,
                isset($activationData['user_id']) ? $activationData['user_id'] : null
            );
            
            $db->execute($sql, $params);
            
            // 更新卡片状态
            self::updateCardStatus($cardId, 'active');
            
            // 记录操作日志
            SecurityUtils::logSecurity('INFO', '卡片激活成功', array(
                'card_id' => $cardId,
                'activation_code' => $activationCode,
                'activation_method' => isset($activationData['method']) ? $activationData['method'] : 'online'
            ));
            
            return $activationCode;
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '卡片激活失败', array(
                'card_id' => $cardId,
                'error' => $e->getMessage()
            ));
            throw new Exception('卡片激活失败：' . $e->getMessage());
        }
    }
    
    /**
     * 获取身份核验信息
     */
    public static function getVerificationById($verificationId) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT * FROM identity_verifications WHERE verification_id = ?";
            $result = $db->queryOne($sql, array($verificationId));
            
            if ($result) {
                // 解密敏感信息
                $result['id_number'] = SecurityUtils::decrypt($result['id_number_encrypted']);
                $result['id_front_image'] = SecurityUtils::decrypt($result['id_front_image_encrypted']);
                $result['id_back_image'] = SecurityUtils::decrypt($result['id_back_image_encrypted']);
                $result['selfie_image'] = SecurityUtils::decrypt($result['selfie_image_encrypted']);
                $result['phone_number'] = SecurityUtils::decrypt($result['phone_number_encrypted']);
                $result['email'] = SecurityUtils::decrypt($result['email_encrypted']);
                $result['address'] = SecurityUtils::decrypt($result['address_encrypted']);
            }
            
            return $result;
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取身份核验信息失败', [
                'verification_id' => $verificationId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
    
    /**
     * 获取审核历史
     */
    public static function getReviewHistory($verificationId) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT vr.*, u.username as reviewer_name 
                    FROM verification_reviews vr
                    LEFT JOIN users u ON vr.reviewer_id = u.id
                    WHERE vr.verification_id = ?
                    ORDER BY vr.review_level ASC, vr.created_at DESC";
            
            return $db->query($sql, array($verificationId));
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取审核历史失败', [
                'verification_id' => $verificationId,
                'error' => $e->getMessage()
            ]);
            return array();
        }
    }
    
    /**
     * 获取待审核列表
     */
    public static function getPendingReviews($reviewerId, $reviewLevel = null) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT iv.*, u.username as applicant_name 
                    FROM identity_verifications iv
                    LEFT JOIN users u ON iv.user_id = u.id
                    WHERE iv.status IN (?, ?, ?)";
            
            $params = array(
                self::VERIFICATION_STATUS_PENDING,
                self::VERIFICATION_STATUS_IN_REVIEW,
                self::VERIFICATION_STATUS_NEED_MORE_INFO
            );
            
            if ($reviewLevel) {
                $sql .= " AND NOT EXISTS (
                    SELECT 1 FROM verification_reviews vr 
                    WHERE vr.verification_id = iv.verification_id 
                    AND vr.review_level >= ?
                )";
                $params[] = $reviewLevel;
            }
            
            $sql .= " ORDER BY iv.created_at ASC";
            
            return $db->query($sql, $params);
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取待审核列表失败', array(
                'reviewer_id' => $reviewerId,
                'error' => $e->getMessage()
            ));
            return array();
        }
    }
    
    /**
     * 检查审核权限
     */
    private static function canReview($reviewerId, $reviewLevel) {
        // 这里应该根据用户角色和权限进行检查
        // 简化实现，假设所有用户都有审核权限
        return true;
    }
    
    /**
     * 确定新的核验状态
     */
    private static function determineNewStatus($verificationId, $reviewLevel, $reviewResult) {
        if ($reviewResult === 'rejected') {
            return self::VERIFICATION_STATUS_REJECTED;
        }
        
        if ($reviewResult === 'need_info') {
            return self::VERIFICATION_STATUS_NEED_MORE_INFO;
        }
        
        if ($reviewLevel >= 3) {
            return self::VERIFICATION_STATUS_APPROVED;
        }
        
        return self::VERIFICATION_STATUS_IN_REVIEW;
    }
    
    /**
     * 更新核验状态
     */
    private static function updateVerificationStatus($verificationId, $status) {
        $db = Database::getInstance();
        
        $sql = "UPDATE identity_verifications SET status = ?, updated_at = NOW() WHERE verification_id = ?";
        $db->execute($sql, array($status, $verificationId));
    }
    
    /**
     * 提交到下一级审核
     */
    private static function submitForNextLevel($verificationId, $nextLevel) {
        // 这里可以发送通知给下一级审核人员
        SecurityUtils::logSecurity('INFO', '身份核验提交到下一级审核', array(
                'verification_id' => $verificationId,
                'next_level' => $nextLevel
            ));
    }
    
    /**
     * 获取卡片信息
     */
    private static function getCardById($cardId) {
        $db = Database::getInstance();
        
        $sql = "SELECT * FROM cards WHERE id = ?";
        return $db->queryOne($sql, array($cardId));
    }
    
    /**
     * 获取卡片对应的身份核验
     */
    private static function getVerificationByCardId($cardId) {
        $db = Database::getInstance();
        
        $sql = "SELECT * FROM identity_verifications WHERE card_id = ? ORDER BY created_at DESC LIMIT 1";
        return $db->queryOne($sql, array($cardId));
    }
    
    /**
     * 更新卡片状态
     */
    private static function updateCardStatus($cardId, $status) {
        $db = Database::getInstance();
        
        $sql = "UPDATE cards SET status = ?, updated_at = NOW() WHERE id = ?";
        $db->execute($sql, array($status, $cardId));
    }
    
    /**
     * 生成核验ID
     */
    private static function generateVerificationId() {
        return 'VR' . date('Ymd') . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
    }
    
    /**
     * 生成激活码
     */
    private static function generateActivationCode() {
        return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 12));
    }
    
    /**
     * 获取核验统计信息
     */
    public static function getVerificationStats($dateRange = null) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT 
                        status,
                        COUNT(*) as count,
                        DATE(created_at) as date
                    FROM identity_verifications";
            
            $params = array();
            if ($dateRange) {
                $sql .= " WHERE created_at BETWEEN ? AND ?";
                $params = array($dateRange['start'], $dateRange['end']);
            }
            
            $sql .= " GROUP BY status, DATE(created_at) ORDER BY date DESC";
            
            return $db->query($sql, $params);
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取核验统计失败', array(
                'error' => $e->getMessage()
            ));
            return array();
        }
    }
    
    /**
     * 获取激活统计信息
     */
    public static function getActivationStats($dateRange = null) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT 
                        status,
                        activation_method,
                        COUNT(*) as count,
                        DATE(created_at) as date
                    FROM card_activations";
            
            $params = array();
            if ($dateRange) {
                $sql .= " WHERE created_at BETWEEN ? AND ?";
                $params = array($dateRange['start'], $dateRange['end']);
            }
            
            $sql .= " GROUP BY status, activation_method, DATE(created_at) ORDER BY date DESC";
            
            return $db->query($sql, $params);
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取激活统计失败', array(
                'error' => $e->getMessage()
            ));
            return array();
        }
    }
    
    /**
     * 获取待激活的卡片列表
     */
    public static function getPendingActivations($userRole = null) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT 
                        c.id,
                        c.card_number,
                        c.card_type,
                        c.status as card_status,
                        iv.verification_id,
                        iv.status as verification_status,
                        iv.created_at as verification_date,
                        u.username as applicant_name,
                        ca.status as activation_status
                    FROM cards c
                    LEFT JOIN identity_verifications iv ON c.id = iv.card_id
                    LEFT JOIN users u ON iv.user_id = u.id
                    LEFT JOIN card_activations ca ON c.id = ca.card_id
                    WHERE iv.status = ? AND c.status = 'pending'
                    ORDER BY iv.created_at ASC";
            
            return $db->query($sql, array(self::VERIFICATION_STATUS_APPROVED));
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取待激活列表失败', array(
                'error' => $e->getMessage()
            ));
            return array();
        }
    }
    
    /**
     * 获取激活历史
     */
    public static function getActivationHistory($userRole = null) {
        try {
            $db = Database::getInstance();
            
            $sql = "SELECT 
                        ca.*,
                        c.card_number,
                        c.card_type,
                        u.username as activated_by_name,
                        iv.verification_id
                    FROM card_activations ca
                    LEFT JOIN cards c ON ca.card_id = c.id
                    LEFT JOIN users u ON ca.activated_by = u.id
                    LEFT JOIN identity_verifications iv ON ca.card_id = iv.card_id
                    ORDER BY ca.created_at DESC
                    LIMIT 100";
            
            return $db->query($sql);
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取激活历史失败', array(
                'error' => $e->getMessage()
            ));
            return array();
        }
    }
    
    /**
     * 获取核验详情
     */
    public static function getVerificationDetails($verificationId, $userId = null, $userRole = null) {
        try {
            $verification = self::getVerificationById($verificationId);
            if (!$verification) {
                throw new Exception('核验申请不存在');
            }
            
            $db = Database::getInstance();
            
            // 获取卡片信息
            $card = $db->queryOne("SELECT * FROM cards WHERE id = ?", array($verification['card_id']));
            
            // 获取审核历史
            $reviewHistory = self::getReviewHistory($verificationId);
            
            // 获取激活记录
            $activationRecord = $db->queryOne(
                "SELECT * FROM card_activations WHERE card_id = ? ORDER BY created_at DESC LIMIT 1", 
                array($verification['card_id'])
            );
            
            return array(
                'verification' => $verification,
                'card' => $card,
                'review_history' => $reviewHistory,
                'activation_record' => $activationRecord
            );
            
        } catch (Exception $e) {
            SecurityUtils::logSecurity('ERROR', '获取核验详情失败', array(
                'verification_id' => $verificationId,
                'error' => $e->getMessage()
            ));
            throw new Exception('获取核验详情失败：' . $e->getMessage());
        }
    }
    
    /**
     * 激活卡片（实例方法版本）
     */
    public function activateCardInstance($verificationId, $userId, $activationCode, $notes = '') {
        try {
            $verification = self::getVerificationById($verificationId);
            if (!$verification) {
                throw new Exception('核验申请不存在');
            }
            
            if ($verification['status'] !== self::VERIFICATION_STATUS_APPROVED) {
                throw new Exception('身份核验未通过，无法激活卡片');
            }
            
            $activationData = array(
                'method' => 'manual',
                'user_id' => $userId,
                'activation_code' => $activationCode,
                'notes' => $notes
            );
            
            $result = self::activateCard($verification['card_id'], $activationData);
            
            return array(
                'success' => true,
                'message' => '卡片激活成功',
                'activation_code' => $result
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
}