<?php
/**
 * 支付服务类
 * 负责处理支付相关的业务逻辑
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../core/Database.php';
require_once __DIR__ . '/../../core/Logger.php';

/**
 * 支付服务类
 * 提供支付处理、支付方式管理、交易记录等功能
 */
class PaymentService extends BaseService {
    private static $instance = null;
    private $alipay;
    private $wechat;
    
    // 异常处理器和日志管理器
    protected $exceptionHandler;
    protected $logManager;
    
    /**
     * 单例模式实现
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct()
    {
        parent::__construct();
        $this->database = $this->getDatabase();
        $this->logger = $this->getLogger();
        
        // 初始化异常处理器和日志管理器
        require_once __DIR__ . '/../../core/exception/ExceptionHandler.php';
        require_once __DIR__ . '/../../core/exception/LogManager.php';
        
        $this->exceptionHandler = \ExceptionHandler\ExceptionHandler::getInstance([
            'debug' => $this->config['debug'] ?? false,
            'environment' => $this->config['environment'] ?? 'production'
        ]);
        
        $this->logManager = \ExceptionHandler\LogManager::getInstance([
            'debug' => $this->config['debug'] ?? false,
            'environment' => $this->config['environment'] ?? 'production',
            'log_dir' => $this->config['log_dir'] ?? __DIR__ . '/../../logs'
        ]);
        
        // 记录初始化日志
        $this->logManager->info('Payment Service initialized');
    }
    
    /**
     * 获取默认配置
     */
    private function getDefaultConfig()
    {
        return array(
            'alipay' => array(
                'app_id' => isset($_ENV['ALIPAY_APP_ID']) ? $_ENV['ALIPAY_APP_ID'] : '',
                'private_key' => isset($_ENV['ALIPAY_PRIVATE_KEY']) ? $_ENV['ALIPAY_PRIVATE_KEY'] : '',
                'public_key' => isset($_ENV['ALIPAY_PUBLIC_KEY']) ? $_ENV['ALIPAY_PUBLIC_KEY'] : '',
                'notify_url' => isset($_ENV['ALIPAY_NOTIFY_URL']) ? $_ENV['ALIPAY_NOTIFY_URL'] : '/payment/alipay/notify',
                'return_url' => isset($_ENV['ALIPAY_RETURN_URL']) ? $_ENV['ALIPAY_RETURN_URL'] : '/payment/alipay/return',
                'sandbox' => isset($_ENV['ALIPAY_SANDBOX']) ? $_ENV['ALIPAY_SANDBOX'] : false
            ),
            'wechat' => array(
                'app_id' => isset($_ENV['WECHAT_APP_ID']) ? $_ENV['WECHAT_APP_ID'] : '',
                'mch_id' => isset($_ENV['WECHAT_MCH_ID']) ? $_ENV['WECHAT_MCH_ID'] : '',
                'key' => isset($_ENV['WECHAT_KEY']) ? $_ENV['WECHAT_KEY'] : '',
                'cert_path' => isset($_ENV['WECHAT_CERT_PATH']) ? $_ENV['WECHAT_CERT_PATH'] : '',
                'key_path' => isset($_ENV['WECHAT_KEY_PATH']) ? $_ENV['WECHAT_KEY_PATH'] : '',
                'notify_url' => isset($_ENV['WECHAT_NOTIFY_URL']) ? $_ENV['WECHAT_NOTIFY_URL'] : '/payment/wechat/notify'
            ),
            'security' => array(
                'sign_timeout' => 600,
                'max_amount' => 50000,
                'min_amount' => 0.01,
                'rate_limit' => 10 // 每分钟最大支付次数
            )
        );
    }
    
    /**
     * 初始化支付方式
     */
    private function initializePaymentMethods()
    {
        if (!empty($this->config['alipay']['app_id'])) {
            $this->alipay = new AlipayPayment($this->config['alipay']);
        }
        
        if (!empty($this->config['wechat']['app_id'])) {
            $this->wechat = new WechatPayment($this->config['wechat']);
        }
    }
    
    /**
     * 创建支付订单
     */
    public function createPayment($paymentData)
    {
        $startTime = microtime(true);
        $orderId = $paymentData['order_id'] ?? uniqid('order_', true);
        $amount = $paymentData['amount'] ?? 0;
        
        // 记录支付开始日志
        $this->logManager->logPaymentOperation(
            'create',
            $orderId,
            $amount,
            $paymentData['currency'] ?? 'CNY',
            'pending'
        );
        
        try {
            $paymentMethod = $paymentData['payment_method'] ?? '';
            $subject = isset($paymentData['subject']) ? $paymentData['subject'] : '';
            $extra = isset($paymentData['extra']) ? $paymentData['extra'] : array();
            
            // 验证参数
            $this->validatePaymentRequest($orderId, $amount, $paymentMethod);
            
            // 检查限流
            $this->checkRateLimit();
            
            // 获取支付方式实例
            $paymentInstance = $this->getPaymentInstance($paymentMethod);
            if (!$paymentInstance) {
                throw new PaymentException('不支持的支付方式', 400);
            }
            
            // 创建支付记录
            $paymentId = $this->createPaymentRecord($orderId, $amount, $paymentMethod, $subject, $extra);
            
            // 调用支付接口
            $result = $paymentInstance->createOrder(array(
                'out_trade_no' => $paymentId,
                'total_amount' => $amount,
                'subject' => $subject ? $subject : '订单支付',
                'notify_url' => $this->getNotifyUrl($paymentMethod),
                'return_url' => $this->getReturnUrl($paymentMethod),
                'extra' => $extra
            ));
            
            // 更新支付记录
            $this->updatePaymentRecord($paymentId, array(
                'payment_data' => json_encode($result),
                'status' => 'pending'
            ));
            
            // 记录成功日志
            $executionTime = microtime(true) - $startTime;
            $this->logManager->info('Payment creation successful', [
                'order_id' => $orderId,
                'payment_method' => $paymentMethod,
                'amount' => $amount,
                'execution_time' => $executionTime,
                'payment_record_id' => $paymentId
            ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
            
            return array(
                'success' => true,
                'id' => $paymentId,
                'out_trade_no' => $paymentId,
                'payment_url' => isset($result['payment_url']) ? $result['payment_url'] : null,
                'qr_code' => isset($result['qr_code']) ? $result['qr_code'] : null,
                'prepay_id' => isset($result['prepay_id']) ? $result['prepay_id'] : null,
                'message' => '支付订单创建成功'
            );
            
        } catch (ValidationException $e) {
            // 处理验证错误
            $this->handlePaymentException($e, 'validation_error', $orderId, $paymentMethod, $paymentData);
            return array(
                'success' => false,
                'error_code' => 'VALIDATION_ERROR',
                'error_message' => $this->config['debug'] ? $e->getMessage() : '请求参数无效',
                'order_id' => $orderId
            );
            
        } catch (PaymentException $e) {
            // 处理支付错误
            $this->handlePaymentException($e, 'payment_error', $orderId, $paymentMethod, $paymentData);
            return array(
                'success' => false,
                'error_code' => 'PAYMENT_ERROR',
                'error_message' => $this->config['debug'] ? $e->getMessage() : '支付处理失败',
                'order_id' => $orderId
            );
            
        } catch (DatabaseException $e) {
            // 处理数据库错误
            $this->handlePaymentException($e, 'database_error', $orderId, $paymentMethod, $paymentData);
            return array(
                'success' => false,
                'error_code' => 'DATABASE_ERROR',
                'error_message' => '系统数据库错误，请稍后再试',
                'order_id' => $orderId
            );
            
        } catch (Exception $e) {
            // 处理其他错误
            $this->handlePaymentException($e, 'system_error', $orderId, $paymentMethod, $paymentData);
            return array(
                'success' => false,
                'error_code' => 'SYSTEM_ERROR',
                'error_message' => '系统错误，请稍后再试',
                'order_id' => $orderId
            );
        }
    }
    
    /**
     * 处理支付回调
     */
    public function handleCallback($paymentMethod, $data)
    {
        $startTime = microtime(true);
        
        // 记录回调开始日志
        $this->logManager->info('Payment callback received', [
            'payment_method' => $paymentMethod,
            'signature' => isset($data['sign']) ? substr($data['sign'], 0, 10) . '...' : 'N/A'
        ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
        
        try {
            $paymentInstance = $this->getPaymentInstance($paymentMethod);
            if (!$paymentInstance) {
                throw new PaymentException('不支持的支付方式', 400);
            }
            
            // 验证回调签名
            if (!$paymentInstance->verifyCallback($data)) {
                throw new PaymentException('回调验证失败', 400);
            }
            
            $paymentId = isset($data['out_trade_no']) ? $data['out_trade_no'] : '';
            $tradeNo = isset($data['trade_no']) ? $data['trade_no'] : '';
            $amount = isset($data['total_amount']) ? $data['total_amount'] : 0;
            $status = $this->mapPaymentStatus($paymentMethod, isset($data['trade_status']) ? $data['trade_status'] : (isset($data['result_code']) ? $data['result_code'] : ''));
            
            // 更新支付记录
            $this->updatePaymentRecord($paymentId, array(
                'trade_no' => $tradeNo,
                'status' => $status,
                'paid_amount' => $amount,
                'callback_data' => json_encode($data),
                'callback_time' => date('Y-m-d H:i:s')
            ));
            
            // 如果支付成功，处理业务逻辑
            if ($status === 'success' || $status === 'paid') {
                $this->processSuccessfulPayment($paymentId, $amount);
            }
            
            // 记录成功日志
            $executionTime = microtime(true) - $startTime;
            $this->logManager->info('Payment callback processed successfully', [
                'order_id' => $paymentId,
                'payment_method' => $paymentMethod,
                'status' => $status,
                'transaction_id' => $tradeNo,
                'execution_time' => $executionTime
            ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
            
            return array(
                'success' => true,
                'message' => '回调处理成功'
            );
            
        } catch (PaymentException $e) {
            // 处理支付回调错误
            $errorId = $this->exceptionHandler->recordError(
                $e->getMessage(),
                \ExceptionHandler\ExceptionHandler::ERROR_TYPE_PAYMENT,
                \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
                [
                    'payment_method' => $paymentMethod,
                    'callback_data' => $this->sanitizeCallbackData($data)
                ]
            );
            
            $this->logManager->error('Payment callback failed', [
                'error_id' => $errorId,
                'payment_method' => $paymentMethod,
                'error_message' => $e->getMessage()
            ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
            
            // 返回错误响应给支付网关
            return false;
            
        } catch (Exception $e) {
            // 处理其他错误
            $errorId = $this->exceptionHandler->recordError(
                $e->getMessage(),
                \ExceptionHandler\ExceptionHandler::ERROR_TYPE_SYSTEM,
                \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
                [
                    'payment_method' => $paymentMethod,
                    'callback_data' => $this->sanitizeCallbackData($data)
                ]
            );
            
            $this->logManager->error('System error during payment callback', [
                'error_id' => $errorId,
                'payment_method' => $paymentMethod,
                'error_message' => $e->getMessage()
            ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
            
            // 返回错误响应给支付网关
            return false;
        }
    }
    
    /**
     * 申请退款
     */
    public function refund($paymentId, $refundAmount, $reason = '')
    {
        $startTime = microtime(true);
        
        // 记录退款开始日志
        $this->logManager->info('Refund process started', [
            'payment_id' => $paymentId,
            'refund_amount' => $refundAmount,
            'reason' => $reason
        ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
        
        try {
            // 获取支付记录
            $payment = $this->getPaymentRecord($paymentId);
            if (!$payment) {
                throw new PaymentException('支付记录不存在', 404);
            }
            
            if ($payment['status'] !== 'success') {
                throw new PaymentException('只能退款已成功的支付', 400);
            }
            
            if ($refundAmount > $payment['amount']) {
                throw new PaymentException('退款金额不能大于支付金额', 400);
            }
            
            $paymentMethod = $payment['payment_method'] ?? '';
            $paymentInstance = $this->getPaymentInstance($paymentMethod);
            if (!$paymentInstance) {
                throw new PaymentException('不支持的支付方式', 400);
            }
            
            // 创建退款记录
            $refundId = $this->createRefundRecord($paymentId, $refundAmount, $reason);
            
            // 调用退款接口
            $result = $paymentInstance->refund(array(
                'out_trade_no' => $paymentId,
                'refund_no' => $refundId,
                'refund_amount' => $refundAmount,
                'refund_reason' => $reason
            ));
            
            // 更新退款记录
            $this->updateRefundRecord($refundId, array(
                'refund_data' => json_encode($result),
                'status' => 'processing'
            ));
            
            // 记录成功日志
            $executionTime = microtime(true) - $startTime;
            $this->logManager->info('Refund processed successfully', [
                'payment_id' => $paymentId,
                'refund_id' => $refundId,
                'refund_amount' => $refundAmount,
                'execution_time' => $executionTime
            ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
            
            return array(
                'success' => true,
                'refund_id' => $refundId,
                'message' => '退款申请已提交'
            );
            
        } catch (PaymentException $e) {
            // 处理退款错误
            $this->handlePaymentException($e, 'refund_error', $paymentId, $paymentMethod, [
                'refund_amount' => $refundAmount,
                'reason' => $reason
            ]);
            
            return array(
                'success' => false,
                'error_code' => 'REFUND_ERROR',
                'error_message' => $this->config['debug'] ? $e->getMessage() : '退款处理失败',
                'payment_id' => $paymentId
            );
            
        } catch (Exception $e) {
            // 处理其他错误
            $errorId = $this->exceptionHandler->recordError(
                $e->getMessage(),
                \ExceptionHandler\ExceptionHandler::ERROR_TYPE_SYSTEM,
                \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
                [
                    'payment_id' => $paymentId,
                    'refund_amount' => $refundAmount,
                    'reason' => $reason
                ]
            );
            
            $this->logManager->error('System error during refund', [
                'error_id' => $errorId,
                'payment_id' => $paymentId,
                'error_message' => $e->getMessage()
            ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
            
            return array(
                'success' => false,
                'error_code' => 'SYSTEM_ERROR',
                'error_message' => '系统错误',
                'error_id' => $errorId
            );
        }
    }
    
    /**
     * 处理支付异常
     */
    protected function handlePaymentException($exception, $errorType, $orderId, $paymentMethod, $contextData = [])
    {
        // 记录异常
        $errorId = $this->exceptionHandler->recordError(
            $exception->getMessage(),
            \ExceptionHandler\ExceptionHandler::ERROR_TYPE_PAYMENT,
            \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
            array_merge([
                'order_id' => $orderId,
                'payment_method' => $paymentMethod,
                'error_type' => $errorType
            ], $this->sanitizeContextData($contextData))
        );
        
        // 记录日志
        $this->logManager->error('Payment error', [
            'error_id' => $errorId,
            'order_id' => $orderId,
            'payment_method' => $paymentMethod,
            'error_type' => $errorType,
            'error_message' => $exception->getMessage()
        ], \ExceptionHandler\LogManager::CHANNEL_PAYMENT);
        
        // 可选：发送警报
        if (method_exists($this, 'sendAlert')) {
            $this->sendAlert([
                'type' => 'payment_error',
                'order_id' => $orderId,
                'error_id' => $errorId,
                'message' => "支付处理失败: {$exception->getMessage()}"
            ]);
        }
    }
    
    /**
     * 清理上下文数据中的敏感信息
     */
    protected function sanitizeContextData($data)
    {
        if (!$data || !is_array($data)) {
            return [];
        }
        
        // 敏感字段
        $sensitiveFields = [
            'card_number', 'card_number_full', 'cvv', 'cvc', 'expiry_date',
            'password', 'token', 'secret', 'api_key', 'private_key'
        ];
        
        // 复制数据
        $sanitizedData = $data;
        
        // 清理敏感字段
        foreach ($sensitiveFields as $field) {
            if (isset($sanitizedData[$field])) {
                $sanitizedData[$field] = '***REDACTED***';
            }
        }
        
        // 部分隐藏信用卡号
        if (isset($sanitizedData['card_number_masked'])) {
            $sanitizedData['card_number_masked'] = '****-****-****-' . substr($sanitizedData['card_number_masked'], -4);
        }
        
        return $sanitizedData;
    }
    
    /**
     * 清理回调数据中的敏感信息
     */
    protected function sanitizeCallbackData($callbackData)
    {
        return $this->sanitizeContextData($callbackData);
    }
    
    /**
     * 处理支付宝异步通知
     */
    public function handleAlipayNotify($data)
    {
        try {
            $paymentInstance = $this->getPaymentInstance('alipay');
            if (!$paymentInstance) {
                $this->logManager->warning('Alipay instance not available');
                return false;
            }
            
            $result = $paymentInstance->verifyNotify($data);
            if (!$result) {
                $this->logManager->warning('Alipay notify verification failed');
                return false;
            }
            
            $paymentId = $data['out_trade_no'];
            $tradeStatus = $data['trade_status'];
            
            if ($tradeStatus === 'TRADE_SUCCESS' || $tradeStatus === 'TRADE_FINISHED') {
                $amount = isset($data['total_amount']) ? $data['total_amount'] : 0;
                $this->logManager->info('Alipay payment completed', ['payment_id' => $paymentId, 'amount' => $amount]);
                return $this->processSuccessfulPayment($paymentId, $amount);
            }
            
            return true;
            
        } catch (Exception $e) {
            $errorId = $this->exceptionHandler->recordError(
                $e->getMessage(),
                \ExceptionHandler\ExceptionHandler::ERROR_TYPE_PAYMENT,
                \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
                ['data' => $this->sanitizeCallbackData($data)]
            );
            
            $this->logManager->error('处理支付宝通知失败', [
                'error_id' => $errorId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
    
    /**
     * 处理微信支付异步通知
     */
    public function handleWechatNotify($rawData)
    {
        try {
            $paymentInstance = $this->getPaymentInstance('wechat');
            if (!$paymentInstance) {
                $this->logManager->warning('Wechat instance not available');
                return false;
            }
            
            $data = $paymentInstance->parseNotifyData($rawData);
            $result = $paymentInstance->verifyNotify($data);
            
            if (!$result) {
                $this->logManager->warning('Wechat notify verification failed');
                return false;
            }
            
            $paymentId = $data['out_trade_no'];
            $resultCode = $data['result_code'];
            
            if ($resultCode === 'SUCCESS') {
                $amount = isset($data['total_amount']) ? $data['total_amount'] : 0;
                $this->logManager->info('Wechat payment completed', ['payment_id' => $paymentId, 'amount' => $amount]);
                return $this->processSuccessfulPayment($paymentId, $amount);
            }
            
            return true;
            
        } catch (Exception $e) {
            $errorId = $this->exceptionHandler->recordError(
                $e->getMessage(),
                \ExceptionHandler\ExceptionHandler::ERROR_TYPE_PAYMENT,
                \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
                ['raw_data' => substr($rawData, 0, 100) . '...']
            );
            
            $this->logManager->error('处理微信支付通知失败', [
                'error_id' => $errorId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
    
    /**
     * 记录回调数据
     */
    public function recordCallback($paymentMethod, $type, $data, $ip)
    {
        try {
            $sql = "INSERT INTO payment_callbacks (payment_method, type, data, ip_address, created_at) 
                    VALUES (?, ?, ?, ?, NOW())";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array(
                $paymentMethod,
                $type,
                is_string($data) ? $data : json_encode($data),
                $ip
            ));
            
            $callbackId = $this->database->lastInsertId();
            $this->logManager->info('Callback recorded', [
                'callback_id' => $callbackId,
                'payment_method' => $paymentMethod,
                'type' => $type
            ]);
            
            return $callbackId;
            
        } catch (Exception $e) {
            $errorId = $this->exceptionHandler->recordError(
                $e->getMessage(),
                \ExceptionHandler\ExceptionHandler::ERROR_TYPE_DATABASE,
                \ExceptionHandler\ExceptionHandler::ERROR_LEVEL_ERROR,
                [
                    'payment_method' => $paymentMethod,
                    'type' => $type
                ]
            );
            
            $this->logManager->error('记录回调失败', [
                'error_id' => $errorId,
                'payment_method' => $paymentMethod,
                'type' => $type,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
    
    /**
     * 处理支付宝异步通知
     */
    public function handleAlipayNotify($data)
    {
        try {
            $paymentInstance = $this->getPaymentInstance('alipay');
            if (!$paymentInstance) {
                return false;
            }
            
            $result = $paymentInstance->verifyNotify($data);
            if (!$result) {
                return false;
            }
            
            $paymentId = $data['out_trade_no'];
            $tradeStatus = $data['trade_status'];
            
            if ($tradeStatus === 'TRADE_SUCCESS' || $tradeStatus === 'TRADE_FINISHED') {
                $amount = isset($data['total_amount']) ? $data['total_amount'] : 0;
                return $this->processSuccessfulPayment($paymentId, $amount);
            }
            
            return true;
            
        } catch (Exception $e) {
            $this->logError('处理支付宝通知失败', array(
                'data' => $data,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 处理支付宝同步返回
     */
    public function handleAlipayReturn($data)
    {
        try {
            $paymentInstance = $this->getPaymentInstance('alipay');
            if (!$paymentInstance) {
                return array('success' => false, 'message' => '支付方式不支持');
            }
            
            $result = $paymentInstance->verifyReturn($data);
            if (!$result) {
                return array('success' => false, 'message' => '验证失败');
            }
            
            $paymentId = $data['out_trade_no'];
            $paymentRecord = $this->getPaymentRecord($paymentId);
            
            if (!$paymentRecord) {
                return array('success' => false, 'message' => '支付记录不存在');
            }
            
            return array(
                'success' => true,
                'payment_id' => $paymentId,
                'status' => $paymentRecord['status'],
                'amount' => $paymentRecord['amount']
            );
            
        } catch (Exception $e) {
            $this->logError('处理支付宝返回失败', array(
                'data' => $data,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 处理微信支付异步通知
     */
    public function handleWechatNotify($rawData)
    {
        try {
            $paymentInstance = $this->getPaymentInstance('wechat');
            if (!$paymentInstance) {
                return false;
            }
            
            $data = $paymentInstance->parseNotifyData($rawData);
            $result = $paymentInstance->verifyNotify($data);
            
            if (!$result) {
                return false;
            }
            
            $paymentId = $data['out_trade_no'];
            $resultCode = $data['result_code'];
            
            if ($resultCode === 'SUCCESS') {
                $amount = isset($data['total_amount']) ? $data['total_amount'] : 0;
                return $this->processSuccessfulPayment($paymentId, $amount);
            }
            
            return true;
            
        } catch (Exception $e) {
            $this->logError('处理微信支付通知失败', array(
                'raw_data' => $rawData,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 记录回调数据
     */
    public function recordCallback($paymentMethod, $type, $data, $ip)
    {
        try {
            $sql = "INSERT INTO payment_callbacks (payment_method, type, data, ip_address, created_at) 
                    VALUES (?, ?, ?, ?, NOW())";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array(
                $paymentMethod,
                $type,
                is_string($data) ? $data : json_encode($data),
                $ip
            ));
            
            return $this->database->lastInsertId();
            
        } catch (Exception $e) {
            $this->logError('记录回调失败', array(
                'payment_method' => $paymentMethod,
                'type' => $type,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 处理支付宝支付
     */
    public function processAlipayPayment($paymentId)
    {
        try {
            $payment = $this->getPaymentRecord($paymentId);
            if (!$payment) {
                throw new Exception('支付记录不存在');
            }
            
            if (!$this->alipay) {
                throw new Exception('支付宝支付未配置');
            }
            
            return $this->alipay->createOrder(array(
                'out_trade_no' => $paymentId,
                'total_amount' => $payment['amount'],
                'subject' => $payment['subject'],
                'notify_url' => $this->getNotifyUrl('alipay'),
                'return_url' => $this->getReturnUrl('alipay')
            ));
            
        } catch (Exception $e) {
            $this->logError('处理支付宝支付失败', array(
                'payment_id' => $paymentId,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    
    /**
     * 处理微信支付
     */
    public function processWechatPayment($paymentId)
    {
        try {
            $payment = $this->getPaymentRecord($paymentId);
            if (!$payment) {
                throw new Exception('支付记录不存在');
            }
            
            if (!$this->wechat) {
                throw new Exception('微信支付未配置');
            }
            
            return $this->wechat->createOrder(array(
                'out_trade_no' => $paymentId,
                'total_amount' => $payment['amount'],
                'subject' => $payment['subject'],
                'notify_url' => $this->getNotifyUrl('wechat'),
                'return_url' => $this->getReturnUrl('wechat')
            ));
            
        } catch (Exception $e) {
            $this->logError('处理微信支付失败', array(
                'payment_id' => $paymentId,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    
    /**
     * 处理余额支付
     */
    public function processBalancePayment($paymentId)
    {
        try {
            $payment = $this->getPaymentRecord($paymentId);
            if (!$payment) {
                throw new Exception('支付记录不存在');
            }
            
            // 获取订单信息
            $order = $this->database->fetch("SELECT * FROM orders WHERE id = ?", array($payment['order_id']));
            if (!$order) {
                throw new Exception('订单不存在');
            }
            
            // 获取用户余额
            $user = $this->database->fetch("SELECT * FROM users WHERE id = ?", array($order['user_id']));
            if (!$user) {
                throw new Exception('用户不存在');
            }
            
            if ($user['balance'] < $payment['amount']) {
                throw new Exception('余额不足');
            }
            
            // 扣除余额
            $this->database->update('users', 
                array('balance' => $user['balance'] - $payment['amount']), 
                'id = ?', 
                array($order['user_id'])
            );
            
            // 更新支付状态
            $this->updatePaymentRecord($paymentId, array(
                'status' => 'success',
                'paid_amount' => $payment['amount'],
                'callback_time' => date('Y-m-d H:i:s')
            ));
            
            // 处理成功支付
            $this->processSuccessfulPayment($paymentId, $payment['amount']);
            
            return array(
                'success' => true,
                'message' => '余额支付成功'
            );
            
        } catch (Exception $e) {
            $this->logError('处理余额支付失败', array(
                'payment_id' => $paymentId,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    
    /**
     * 取消支付
     */
    public function cancelPayment($paymentId)
    {
        try {
            $payment = $this->getPaymentRecord($paymentId);
            if (!$payment) {
                throw new Exception('支付记录不存在');
            }
            
            if ($payment['status'] === 'success') {
                throw new Exception('已成功的支付不能取消');
            }
            
            if ($payment['status'] === 'cancelled') {
                return true;
            }
            
            // 更新支付状态
            $this->updatePaymentRecord($paymentId, array(
                'status' => 'cancelled',
                'cancelled_at' => date('Y-m-d H:i:s')
            ));
            
            return true;
            
        } catch (Exception $e) {
            $this->logError('取消支付失败', array(
                'payment_id' => $paymentId,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    
    /**
     * 创建退款
     */
    public function createRefund($refundData)
    {
        return $this->refund(
            $refundData['payment_id'],
            $refundData['refund_amount'],
            $refundData['refund_reason']
        );
    }
    
    /**
     * 查询退款
     */
    public function queryRefund($refundId)
    {
        try {
            $refund = $this->database->fetch("SELECT * FROM refunds WHERE id = ?", array($refundId));
            if (!$refund) {
                throw new Exception('退款记录不存在');
            }
            
            $payment = $this->getPaymentRecord($refund['payment_id']);
            if (!$payment) {
                throw new Exception('支付记录不存在');
            }
            
            $paymentInstance = $this->getPaymentInstance($payment['payment_method']);
            if (!$paymentInstance) {
                throw new Exception('不支持的支付方式');
            }
            
            // 查询退款状态
            $result = $paymentInstance->queryRefund($refundId);
            
            // 更新本地状态
            if (isset($result['refund_status'])) {
                $status = $this->mapRefundStatus($result['refund_status']);
                $this->updateRefundRecord($refundId, array(
                    'status' => $status,
                    'query_data' => json_encode($result)
                ));
            }
            
            return array(
                'success' => true,
                'refund' => $this->database->fetch("SELECT * FROM refunds WHERE id = ?", array($refundId)),
                'query_result' => $result
            );
            
        } catch (Exception $e) {
            $this->logError('查询退款失败', array(
                'refund_id' => $refundId,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    

    
    /**
     * 映射退款状态
     */
    private function mapRefundStatus($refundStatus)
    {
        $statusMap = array(
            'REFUND_SUCCESS' => 'success',
            'REFUND_FAILED' => 'failed',
            'REFUND_PROCESSING' => 'processing',
            'SUCCESS' => 'success',
            'FAILED' => 'failed',
            'PROCESSING' => 'processing',
            'CLOSED' => 'closed'
        );
        
        return isset($statusMap[$refundStatus]) ? $statusMap[$refundStatus] : 'unknown';
    }
}