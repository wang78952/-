<?php
/**
 * 卡密有效期提醒服务
 * 负责处理卡密有效期提醒的检查和发送
 */
class ExpiryReminderService {
    private $database;
    private $logger;
    private $notificationManager;
    
    /**
     * 构造函数
     * @param Database $database 数据库实例
     * @param Logger $logger 日志实例
     * @param NotificationManager $notificationManager 通知管理器实例
     */
    public function __construct($database = null, $logger = null, $notificationManager = null) {
        $this->database = $database ?: Database::getInstance();
        $this->logger = $logger ?: new Logger('expiry_reminder');
        $this->notificationManager = $notificationManager ?: new NotificationManager();
    }
    
    /**
     * 检查并发送所有需要的卡密有效期提醒
     * @return array 处理结果统计
     */
    public function checkAndSendReminders() {
        $startTime = time();
        $this->logger->info("开始执行卡密有效期提醒检查");
        
        try {
            // 获取今天需要提醒的卡密
            $today = date('Y-m-d H:i:s');
            $reminders = $this->getDueReminders($today);
            
            $totalChecked = count($reminders);
            $totalSent = 0;
            $errors = 0;
            
            foreach ($reminders as $reminder) {
                try {
                    // 获取卡密详情
                    $cardDetails = $this->getCardDetails($reminder['card_id']);
                    if (!$cardDetails) {
                        $this->logger->warning("卡密不存在或已删除，跳过提醒", ['card_id' => $reminder['card_id'], 'reminder_id' => $reminder['id']]);
                        continue;
                    }
                    
                    // 获取用户信息
                    $userInfo = $this->getUserInfo($reminder['user_id']);
                    if (!$userInfo) {
                        $this->logger->warning("用户不存在，跳过提醒", ['user_id' => $reminder['user_id'], 'card_id' => $reminder['card_id']]);
                        continue;
                    }
                    
                    // 解析提醒方式
                    $remindMethods = json_decode($reminder['remind_method'], true) ?: ['email'];
                    
                    // 发送提醒
                    $sent = false;
                    foreach ($remindMethods as $method) {
                        switch ($method) {
                            case 'email':
                                $sent |= $this->sendEmailReminder($userInfo, $cardDetails, $reminder);
                                break;
                            case 'sms':
                                $sent |= $this->sendSmsReminder($userInfo, $cardDetails, $reminder);
                                break;
                            case 'system':
                                $sent |= $this->sendSystemNotification($userInfo, $cardDetails, $reminder);
                                break;
                            default:
                                $this->logger->warning("未知的提醒方式: {$method}", ['card_id' => $reminder['card_id'], 'user_id' => $reminder['user_id']]);
                        }
                    }
                    
                    // 更新提醒状态
                    if ($sent) {
                        $this->updateReminderStatus($reminder['id'], 'sent');
                        $totalSent++;
                    }
                    
                } catch (Exception $e) {
                    $this->logger->error("处理卡密有效期提醒失败", [
                        'reminder_id' => $reminder['id'],
                        'card_id' => $reminder['card_id'],
                        'user_id' => $reminder['user_id'],
                        'error' => $e->getMessage()
                    ]);
                    $errors++;
                }
            }
            
            $executionTime = time() - $startTime;
            $this->logger->info("卡密有效期提醒检查完成", [
                'total_checked' => $totalChecked,
                'total_sent' => $totalSent,
                'errors' => $errors,
                'execution_time' => "{$executionTime}秒"
            ]);
            
            return [
                'total_checked' => $totalChecked,
                'total_sent' => $totalSent,
                'errors' => $errors,
                'execution_time' => $executionTime
            ];
            
        } catch (Exception $e) {
            $this->logger->error("执行卡密有效期提醒检查时发生严重错误: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 获取到期需要提醒的卡密列表
     * @param string $date 检查日期
     * @return array 提醒列表
     */
    private function getDueReminders($date) {
        $sql = "SELECT * FROM card_expiration_reminders 
                WHERE remind_date <= ? AND status = 'pending' 
                ORDER BY remind_date ASC";
        
        return $this->database->query($sql, [$date]);
    }
    
    /**
     * 获取卡密详情
     * @param int $cardId 卡密ID
     * @return array|null 卡密详情
     */
    private function getCardDetails($cardId) {
        $sql = "SELECT c.*, p.name as product_name 
                FROM cards c 
                LEFT JOIN products p ON c.product_id = p.id 
                WHERE c.id = ?";
        
        $result = $this->database->query($sql, [$cardId]);
        return !empty($result) ? $result[0] : null;
    }
    
    /**
     * 获取用户信息
     * @param int $userId 用户ID
     * @return array|null 用户信息
     */
    private function getUserInfo($userId) {
        $sql = "SELECT id, username, email, phone FROM users WHERE id = ?";
        
        $result = $this->database->query($sql, [$userId]);
        return !empty($result) ? $result[0] : null;
    }
    
    /**
     * 发送邮件提醒
     * @param array $userInfo 用户信息
     * @param array $cardDetails 卡密详情
     * @param array $reminder 提醒信息
     * @return bool 是否发送成功
     */
    private function sendEmailReminder($userInfo, $cardDetails, $reminder) {
        if (!isset($userInfo['email']) || empty($userInfo['email'])) {
            $this->logger->warning("用户未设置邮箱，跳过邮件提醒", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id']]);
            return false;
        }
        
        try {
            $emailParams = [
                'recipient' => $userInfo['email'],
                'subject' => "【重要提醒】您的卡密即将到期",
                'template' => 'card_expiry_reminder',
                'data' => [
                    'username' => $userInfo['username'],
                    'card_number' => $this->maskCardNumber($cardDetails['card_code']),
                    'product_name' => $cardDetails['product_name'] ?? '未命名产品',
                    'expire_date' => $this->formatDate($cardDetails['expires_at']),
                    'days_left' => $this->getDaysLeft($cardDetails['expires_at']),
                    'login_url' => $this->getLoginUrl(),
                    'extend_url' => $this->getExtendUrl($cardDetails['id'])
                ]
            ];
            
            $result = $this->notificationManager->sendEmail($emailParams);
            if ($result) {
                $this->logger->info("邮件提醒发送成功", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'email' => $userInfo['email']]);
                return true;
            } else {
                $this->logger->error("邮件提醒发送失败", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'email' => $userInfo['email']]);
                return false;
            }
        } catch (Exception $e) {
            $this->logger->error("发送邮件提醒时发生错误", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * 发送短信提醒
     * @param array $userInfo 用户信息
     * @param array $cardDetails 卡密详情
     * @param array $reminder 提醒信息
     * @return bool 是否发送成功
     */
    private function sendSmsReminder($userInfo, $cardDetails, $reminder) {
        if (!isset($userInfo['phone']) || empty($userInfo['phone'])) {
            $this->logger->warning("用户未设置手机号，跳过短信提醒", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id']]);
            return false;
        }
        
        try {
            $daysLeft = $this->getDaysLeft($cardDetails['expires_at']);
            $maskedNumber = $this->maskCardNumber($cardDetails['card_code']);
            
            $smsContent = "【发卡系统】尊敬的用户，您的卡密{$maskedNumber}将在{$daysLeft}天后到期，请及时使用或申请续期。详情请登录系统查看。";
            
            $smsParams = [
                'phone' => $userInfo['phone'],
                'content' => $smsContent
            ];
            
            $result = $this->notificationManager->sendSms($smsParams);
            if ($result) {
                $this->logger->info("短信提醒发送成功", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'phone' => $userInfo['phone']]);
                return true;
            } else {
                $this->logger->error("短信提醒发送失败", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'phone' => $userInfo['phone']]);
                return false;
            }
        } catch (Exception $e) {
            $this->logger->error("发送短信提醒时发生错误", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * 发送系统通知
     * @param array $userInfo 用户信息
     * @param array $cardDetails 卡密详情
     * @param array $reminder 提醒信息
     * @return bool 是否发送成功
     */
    private function sendSystemNotification($userInfo, $cardDetails, $reminder) {
        try {
            $notificationData = [
                'user_id' => $userInfo['id'],
                'title' => "卡密即将到期提醒",
                'content' => "您的卡密「{$this->maskCardNumber($cardDetails['card_code'])}」将在{$this->getDaysLeft($cardDetails['expires_at'])}天后到期，请及时使用或申请续期。",
                'type' => 'card_expiry',
                'url' => $this->getCardDetailUrl($cardDetails['id']),
                'priority' => 'high'
            ];
            
            $notificationId = $this->notificationManager->createNotification($notificationData);
            if ($notificationId) {
                $this->logger->info("系统通知发送成功", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'notification_id' => $notificationId]);
                return true;
            } else {
                $this->logger->error("系统通知发送失败", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id']]);
                return false;
            }
        } catch (Exception $e) {
            $this->logger->error("发送系统通知时发生错误", ['user_id' => $userInfo['id'], 'card_id' => $cardDetails['id'], 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * 更新提醒状态
     * @param int $reminderId 提醒ID
     * @param string $status 新状态
     * @return bool 是否更新成功
     */
    private function updateReminderStatus($reminderId, $status) {
        $sql = "UPDATE card_expiration_reminders SET status = ?, sent_at = NOW() WHERE id = ?";
        return $this->database->execute($sql, [$status, $reminderId]);
    }
    
    /**
     * 格式化日期显示
     * @param string $date 日期字符串
     * @return string 格式化后的日期
     */
    private function formatDate($date) {
        return date('Y年m月d日 H:i', strtotime($date));
    }
    
    /**
     * 计算剩余天数
     * @param string $expireDate 过期日期
     * @return int 剩余天数
     */
    private function getDaysLeft($expireDate) {
        $expire = strtotime($expireDate);
        $now = time();
        $diff = $expire - $now;
        
        return max(0, floor($diff / (60 * 60 * 24)));
    }
    
    /**
     * 卡密号码脱敏
     * @param string $cardNumber 卡密号码
     * @return string 脱敏后的卡密
     */
    private function maskCardNumber($cardNumber) {
        $length = strlen($cardNumber);
        if ($length <= 8) return $cardNumber; // 太短不脱敏
        
        $prefix = substr($cardNumber, 0, 4);
        $suffix = substr($cardNumber, -4);
        $maskLength = $length - 8;
        $mask = str_repeat('*', $maskLength);
        
        return $prefix . $mask . $suffix;
    }
    
    /**
     * 获取登录URL
     * @return string 登录URL
     */
    private function getLoginUrl() {
        return BASE_URL . '/login.php';
    }
    
    /**
     * 获取卡密详情URL
     * @param int $cardId 卡密ID
     * @return string 卡密详情URL
     */
    private function getCardDetailUrl($cardId) {
        return BASE_URL . "/card-detail.php?id={$cardId}";
    }
    
    /**
     * 获取续期申请URL
     * @param int $cardId 卡密ID
     * @return string 续期申请URL
     */
    private function getExtendUrl($cardId) {
        return BASE_URL . "/extend-card.php?id={$cardId}";
    }
    
    /**
     * 手动触发单张卡密的提醒检查
     * @param int $cardId 卡密ID
     * @param int $userId 用户ID
     * @return bool 是否触发成功
     */
    public function triggerManualCheck($cardId, $userId) {
        try {
            $this->logger->info("开始手动触发卡密有效期提醒检查", ['card_id' => $cardId, 'user_id' => $userId]);
            
            // 检查是否已设置提醒
            $reminder = $this->getActiveReminder($cardId, $userId);
            if (!$reminder) {
                $this->logger->warning("未找到该卡密的有效期提醒设置", ['card_id' => $cardId, 'user_id' => $userId]);
                return false;
            }
            
            // 获取卡密详情
            $cardDetails = $this->getCardDetails($cardId);
            if (!$cardDetails) {
                $this->logger->warning("卡密不存在或已删除", ['card_id' => $cardId, 'user_id' => $userId]);
                return false;
            }
            
            // 获取用户信息
            $userInfo = $this->getUserInfo($userId);
            if (!$userInfo) {
                $this->logger->warning("用户不存在", ['user_id' => $userId, 'card_id' => $cardId]);
                return false;
            }
            
            // 立即发送提醒
            $remindMethods = json_decode($reminder['remind_method'], true) ?: ['email'];
            $sent = false;
            
            foreach ($remindMethods as $method) {
                switch ($method) {
                    case 'email':
                        $sent |= $this->sendEmailReminder($userInfo, $cardDetails, $reminder);
                        break;
                    case 'sms':
                        $sent |= $this->sendSmsReminder($userInfo, $cardDetails, $reminder);
                        break;
                    case 'system':
                        $sent |= $this->sendSystemNotification($userInfo, $cardDetails, $reminder);
                        break;
                }
            }
            
            if ($sent) {
                $this->updateReminderStatus($reminder['id'], 'sent');
                $this->logger->info("手动触发提醒发送成功", ['card_id' => $cardId, 'user_id' => $userId]);
            } else {
                $this->logger->error("手动触发提醒发送失败", ['card_id' => $cardId, 'user_id' => $userId]);
            }
            
            return $sent;
        } catch (Exception $e) {
            $this->logger->error("手动触发卡密有效期提醒时发生错误", ['card_id' => $cardId, 'user_id' => $userId, 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * 获取特定卡密和用户的活跃提醒
     * @param int $cardId 卡密ID
     * @param int $userId 用户ID
     * @return array|null 提醒信息
     */
    private function getActiveReminder($cardId, $userId) {
        $sql = "SELECT * FROM card_expiration_reminders WHERE card_id = ? AND user_id = ? AND status IN ('pending', 'sent') ORDER BY id DESC LIMIT 1";
        
        $result = $this->database->query($sql, [$cardId, $userId]);
        return !empty($result) ? $result[0] : null;
    }
    
    /**
     * 获取用户的所有卡密有效期提醒设置
     * @param int $userId 用户ID
     * @param int $limit 分页限制
     * @param int $offset 偏移量
     * @return array 提醒设置列表
     */
    public function getUserReminders($userId, $limit = 20, $offset = 0) {
        $sql = "SELECT r.*, c.card_code, c.status as card_status, c.expires_at as expire_date, p.name as product_name 
                FROM card_expiration_reminders r
                LEFT JOIN cards c ON r.card_id = c.id
                LEFT JOIN products p ON c.product_id = p.id
                WHERE r.user_id = ?
                ORDER BY r.created_at DESC
                LIMIT ? OFFSET ?";
        
        return $this->database->query($sql, [$userId, $limit, $offset]);
    }
}