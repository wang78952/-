<?php
/**
 * 会员服务类
 * 实现积分累计、等级计算、会员特权管理等功能
 */

class MemberService {
    private $db;
    private $logger;
    private $cache;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     * @param Logger $logger 日志实例
     * @param Cache $cache 缓存实例
     */
    public function __construct($db, $logger, $cache = null) {
        $this->db = $db;
        $this->logger = $logger;
        $this->cache = $cache;
    }
    
    /**
     * 初始化用户会员信息
     * @param int $userId 用户ID
     * @return array 用户会员信息
     */
    public function initUserMember($userId) {
        try {
            // 检查用户是否已有会员记录
            $sql = "SELECT * FROM user_members WHERE user_id = ?";
            $member = $this->db->selectOne($sql, [$userId]);
            
            if (!$member) {
                // 创建新会员记录
                $sql = "INSERT INTO user_members (user_id, member_level_id, current_points, total_points) 
                        VALUES (?, 1, 0, 0)";
                $this->db->execute($sql, [$userId]);
                
                // 获取新创建的会员记录
                $member = $this->db->selectOne($sql, [$userId]);
            }
            
            return $member;
        } catch (Exception $e) {
            $this->logger->error("初始化用户会员信息失败: " . $e->getMessage(), ['user_id' => $userId]);
            throw $e;
        }
    }
    
    /**
     * 获取用户会员信息
     * @param int $userId 用户ID
     * @return array 用户会员信息
     */
    public function getUserMemberInfo($userId) {
        try {
            // 尝试从缓存获取
            $cacheKey = "member_info_{$userId}";
            if ($this->cache) {
                $cachedData = $this->cache->get($cacheKey);
                if ($cachedData) {
                    return $cachedData;
                }
            }
            
            // 初始化会员信息（如果不存在）
            $this->initUserMember($userId);
            
            // 获取会员详细信息
            $sql = "SELECT um.*, ml.name as level_name, ml.level as level_value, ml.discount_rate, 
                       ml.description as level_description, ml.privileges 
                    FROM user_members um
                    LEFT JOIN member_levels ml ON um.member_level_id = ml.id
                    WHERE um.user_id = ?";
            $memberInfo = $this->db->selectOne($sql, [$userId]);
            
            if ($memberInfo) {
                // 解析JSON数据
                $memberInfo['privileges'] = $memberInfo['privileges'] ? json_decode($memberInfo['privileges'], true) : [];
                
                // 获取积分统计
                $memberInfo['point_stats'] = $this->getUserPointStats($userId);
                
                // 获取即将过期积分
                $memberInfo['expiring_points'] = $this->getExpiringPoints($userId);
                
                // 获取距离下一等级所需积分
                $memberInfo['next_level_remaining'] = $this->getNextLevelRemainingPoints($userId);
                
                // 缓存数据
                if ($this->cache) {
                    $this->cache->set($cacheKey, $memberInfo, 3600); // 缓存1小时
                }
            }
            
            return $memberInfo;
        } catch (Exception $e) {
            $this->logger->error("获取用户会员信息失败: " . $e->getMessage(), ['user_id' => $userId]);
            throw $e;
        }
    }
    
    /**
     * 更新用户积分
     * @param int $userId 用户ID
     * @param int $points 积分变动数量（正数增加，负数减少）
     * @param string $type 积分类型
     * @param string $sourceId 来源ID
     * @param string $description 描述
     * @param bool $isManual 是否为手动操作
     * @return bool 是否成功
     */
    public function updateUserPoints($userId, $points, $type = 'manual', $sourceId = null, $description = '', $isManual = false) {
        if ($points == 0) {
            return true;
        }
        
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 获取当前会员信息
            $memberInfo = $this->getUserMemberInfo($userId);
            $currentPoints = $memberInfo['current_points'];
            $totalPoints = $memberInfo['total_points'];
            
            // 计算新积分
            $newPoints = $currentPoints + $points;
            $newTotalPoints = $totalPoints + $points;
            
            if ($newPoints < 0) {
                throw new Exception('积分不足');
            }
            
            // 处理积分过期时间
            $expireDate = null;
            if ($points > 0) {
                // 新增积分设置过期时间（1年后）
                $expireDate = date('Y-m-d', strtotime('+1 year'));
            }
            
            // 更新会员信息
            $sql = "UPDATE user_members SET current_points = ?, total_points = ? WHERE user_id = ?";
            $this->db->execute($sql, [$newPoints, $newTotalPoints, $userId]);
            
            // 记录积分变动
            $sql = "INSERT INTO point_transactions (user_id, type, change_points, balance_points, source_id, description, expire_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $this->db->execute($sql, [$userId, $type, $points, $newPoints, $sourceId, $description, $expireDate]);
            
            // 检查并更新会员等级
            $this->checkAndUpdateMemberLevel($userId, $newPoints);
            
            // 提交事务
            $this->db->commit();
            
            // 清除缓存
            if ($this->cache) {
                $this->cache->delete("member_info_{$userId}");
            }
            
            $this->logger->info("用户积分更新成功", [
                'user_id' => $userId,
                'points' => $points,
                'type' => $type,
                'source_id' => $sourceId
            ]);
            
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            $this->logger->error("用户积分更新失败: " . $e->getMessage(), ['user_id' => $userId]);
            throw $e;
        }
    }
    
    /**
     * 处理订单积分（下单赠送积分）
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param float $orderAmount 订单金额
     * @return bool 是否成功
     */
    public function processOrderPoints($userId, $orderId, $orderAmount) {
        // 按照1:10的比例赠送积分（1元=10积分）
        $points = (int)($orderAmount * 10);
        
        // 会员等级加成
        $memberInfo = $this->getUserMemberInfo($userId);
        $levelBonus = 1.0;
        
        // 根据会员等级给予加成
        switch ($memberInfo['level_value']) {
            case 2: // 银牌
                $levelBonus = 1.1;
                break;
            case 3: // 金牌
                $levelBonus = 1.2;
                break;
            case 4: // 钻石
                $levelBonus = 1.3;
                break;
            case 5: // 黑钻
                $levelBonus = 1.5;
                break;
        }
        
        $finalPoints = (int)($points * $levelBonus);
        
        return $this->updateUserPoints(
            $userId, 
            $finalPoints, 
            'order', 
            $orderId, 
            "订单号{$orderId}赠送积分"
        );
    }
    
    /**
     * 处理订单退款积分
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @return bool 是否成功
     */
    public function processOrderRefundPoints($userId, $orderId) {
        // 查询该订单获得的积分
        $sql = "SELECT change_points FROM point_transactions 
                WHERE user_id = ? AND type = 'order' AND source_id = ?";
        $transaction = $this->db->selectOne($sql, [$userId, $orderId]);
        
        if ($transaction) {
            return $this->updateUserPoints(
                $userId, 
                -$transaction['change_points'], 
                'refund', 
                $orderId, 
                "订单号{$orderId}退款扣除积分"
            );
        }
        
        return true;
    }
    
    /**
     * 处理签到积分
     * @param int $userId 用户ID
     * @return array 签到结果
     */
    public function processDailySignIn($userId) {
        // 检查今天是否已签到
        $today = date('Y-m-d');
        $sql = "SELECT * FROM point_transactions 
                WHERE user_id = ? AND type = 'sign_in' AND DATE(created_at) = ?";
        $todayRecord = $this->db->selectOne($sql, [$userId, $today]);
        
        if ($todayRecord) {
            return [
                'success' => false,
                'message' => '今日已签到',
                'signed_days' => $this->getConsecutiveSignInDays($userId)
            ];
        }
        
        // 获取连续签到天数
        $consecutiveDays = $this->getConsecutiveSignInDays($userId);
        
        // 根据连续签到天数计算积分奖励
        $signInPoints = $this->calculateSignInPoints($consecutiveDays + 1);
        
        // 发放签到积分
        $success = $this->updateUserPoints(
            $userId, 
            $signInPoints, 
            'sign_in', 
            null, 
            "连续签到{$consecutiveDays + 1}天"
        );
        
        if ($success) {
            return [
                'success' => true,
                'points' => $signInPoints,
                'signed_days' => $consecutiveDays + 1,
                'message' => '签到成功'
            ];
        }
        
        return ['success' => false, 'message' => '签到失败'];
    }
    
    /**
     * 计算签到积分
     * @param int $days 连续签到天数
     * @return int 积分数量
     */
    private function calculateSignInPoints($days) {
        // 签到积分规则：1-7天每天递增，7天以上每天10积分
        if ($days <= 7) {
            $points = [5, 10, 15, 20, 25, 30, 50];
            return $points[$days - 1];
        }
        return 10;
    }
    
    /**
     * 获取连续签到天数
     * @param int $userId 用户ID
     * @return int 连续签到天数
     */
    private function getConsecutiveSignInDays($userId) {
        $sql = "SELECT DATE(created_at) as sign_date 
                FROM point_transactions 
                WHERE user_id = ? AND type = 'sign_in' 
                ORDER BY sign_date DESC";
        $records = $this->db->select($sql, [$userId]);
        
        if (empty($records)) {
            return 0;
        }
        
        $consecutiveDays = 0;
        $expectedDate = date('Y-m-d');
        
        foreach ($records as $record) {
            if ($record['sign_date'] == $expectedDate) {
                // 今天已签到，不计入连续天数
                continue;
            }
            
            // 检查是否是连续日期
            if ($record['sign_date'] == date('Y-m-d', strtotime($expectedDate . ' - 1 day'))) {
                $consecutiveDays++;
                $expectedDate = $record['sign_date'];
            } else {
                break;
            }
        }
        
        return $consecutiveDays;
    }
    
    /**
     * 处理邀请奖励积分
     * @param int $inviterId 邀请人ID
     * @param int $newUserId 被邀请人ID
     * @return bool 是否成功
     */
    public function processInviteReward($inviterId, $newUserId) {
        // 检查是否已经奖励过
        $sql = "SELECT * FROM point_transactions 
                WHERE user_id = ? AND type = 'invite' AND source_id = ?";
        $existing = $this->db->selectOne($sql, [$inviterId, $newUserId]);
        
        if ($existing) {
            return true;
        }
        
        // 发放邀请奖励积分
        return $this->updateUserPoints(
            $inviterId, 
            100, // 邀请奖励100积分
            'invite', 
            $newUserId, 
            "邀请用户ID{$newUserId}成功"
        );
    }
    
    /**
     * 检查并更新会员等级
     * @param int $userId 用户ID
     * @param int $currentPoints 当前积分
     * @return bool 是否成功
     */
    private function checkAndUpdateMemberLevel($userId, $currentPoints) {
        // 获取积分对应的会员等级
        $sql = "SELECT id, level FROM member_levels 
                WHERE min_points <= ? AND status = 'active' 
                ORDER BY level DESC LIMIT 1";
        $levelInfo = $this->db->selectOne($sql, [$currentPoints]);
        
        if (!$levelInfo) {
            return false;
        }
        
        $newLevelId = $levelInfo['id'];
        $newLevelValue = $levelInfo['level'];
        
        // 获取用户当前等级
        $memberInfo = $this->getUserMemberInfo($userId);
        $currentLevelId = $memberInfo['member_level_id'];
        $currentLevelValue = $memberInfo['level_value'] ?? 1;
        
        // 如果等级有变化
        if ($newLevelId != $currentLevelId) {
            // 更新会员等级
            $sql = "UPDATE user_members SET member_level_id = ?, last_level_change = NOW() WHERE user_id = ?";
            $result = $this->db->execute($sql, [$newLevelId, $userId]);
            
            if ($result) {
                // 记录等级变更历史
                $changeReason = $newLevelValue > $currentLevelValue ? '积分达到升级条件' : '积分不足降级';
                $sql = "INSERT INTO member_level_history (user_id, old_level_id, new_level_id, change_reason, change_points) 
                        VALUES (?, ?, ?, ?, ?)";
                $this->db->execute($sql, [$userId, $currentLevelId, $newLevelId, $changeReason, $currentPoints]);
                
                $this->logger->info("用户会员等级更新", [
                    'user_id' => $userId,
                    'old_level' => $currentLevelValue,
                    'new_level' => $newLevelValue
                ]);
                
                // 发送等级变更通知
                $this->sendLevelChangeNotification($userId, $currentLevelValue, $newLevelValue);
            }
            
            return $result;
        }
        
        return true;
    }
    
    /**
     * 发送等级变更通知
     * @param int $userId 用户ID
     * @param int $oldLevel 旧等级
     * @param int $newLevel 新等级
     */
    private function sendLevelChangeNotification($userId, $oldLevel, $newLevel) {
        // 这里可以集成通知系统发送等级变更通知
        // 例如邮件、短信、站内信等
        $this->logger->info("发送等级变更通知", [
            'user_id' => $userId,
            'old_level' => $oldLevel,
            'new_level' => $newLevel
        ]);
    }
    
    /**
     * 获取用户积分统计信息
     * @param int $userId 用户ID
     * @return array 积分统计
     */
    private function getUserPointStats($userId) {
        $sql = "SELECT 
                SUM(CASE WHEN type = 'order' THEN change_points ELSE 0 END) as order_points,
                SUM(CASE WHEN type = 'sign_in' THEN change_points ELSE 0 END) as sign_in_points,
                SUM(CASE WHEN type = 'invite' THEN change_points ELSE 0 END) as invite_points,
                SUM(CASE WHEN type = 'activity' THEN change_points ELSE 0 END) as activity_points,
                SUM(CASE WHEN type = 'exchange' THEN -change_points ELSE 0 END) as exchange_points,
                COUNT(DISTINCT CASE WHEN type = 'sign_in' THEN DATE(created_at) END) as total_sign_in_days
                FROM point_transactions 
                WHERE user_id = ?";
        
        $stats = $this->db->selectOne($sql, [$userId]);
        
        return [
            'order_points' => $stats['order_points'] ?? 0,
            'sign_in_points' => $stats['sign_in_points'] ?? 0,
            'invite_points' => $stats['invite_points'] ?? 0,
            'activity_points' => $stats['activity_points'] ?? 0,
            'exchange_points' => $stats['exchange_points'] ?? 0,
            'total_sign_in_days' => $stats['total_sign_in_days'] ?? 0
        ];
    }
    
    /**
     * 获取即将过期的积分
     * @param int $userId 用户ID
     * @return array 即将过期积分信息
     */
    private function getExpiringPoints($userId) {
        $sql = "SELECT SUM(change_points) as expiring_points, expire_date 
                FROM point_transactions 
                WHERE user_id = ? AND type != 'expire' AND change_points > 0 
                AND expire_date BETWEEN DATE(NOW()) AND DATE_ADD(NOW(), INTERVAL 30 DAY)
                GROUP BY expire_date
                ORDER BY expire_date ASC";
        
        return $this->db->select($sql, [$userId]);
    }
    
    /**
     * 获取距离下一等级所需积分
     * @param int $userId 用户ID
     * @return int 所需积分
     */
    private function getNextLevelRemainingPoints($userId) {
        $memberInfo = $this->getUserMemberInfo($userId);
        $currentPoints = $memberInfo['current_points'];
        $currentLevel = $memberInfo['level_value'] ?? 1;
        
        // 获取下一等级所需积分
        $sql = "SELECT min_points FROM member_levels 
                WHERE level > ? AND status = 'active' 
                ORDER BY level ASC LIMIT 1";
        $nextLevel = $this->db->selectOne($sql, [$currentLevel]);
        
        if (!$nextLevel) {
            return 0; // 已经是最高等级
        }
        
        $remainingPoints = $nextLevel['min_points'] - $currentPoints;
        return $remainingPoints > 0 ? $remainingPoints : 0;
    }
    
    /**
     * 清理过期积分
     * @return int 清理的用户数量
     */
    public function cleanupExpiredPoints() {
        try {
            // 获取过期积分的用户列表
            $sql = "SELECT user_id, SUM(pt.change_points) as expired_points 
                    FROM point_transactions pt 
                    JOIN user_members um ON pt.user_id = um.user_id 
                    WHERE pt.expire_date <= DATE(NOW()) AND pt.type != 'expire' AND pt.change_points > 0 
                    GROUP BY user_id";
            
            $expiredUsers = $this->db->select($sql);
            $cleanupCount = 0;
            
            foreach ($expiredUsers as $user) {
                try {
                    $this->updateUserPoints(
                        $user['user_id'], 
                        -$user['expired_points'], 
                        'expire', 
                        null, 
                        '积分过期清理'
                    );
                    $cleanupCount++;
                } catch (Exception $e) {
                    $this->logger->error("清理用户过期积分失败: " . $e->getMessage(), [
                        'user_id' => $user['user_id']
                    ]);
                }
            }
            
            return $cleanupCount;
        } catch (Exception $e) {
            $this->logger->error("清理过期积分失败: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * 获取用户积分明细
     * @param int $userId 用户ID
     * @param int $page 页码
     * @param int $pageSize 每页数量
     * @return array 积分明细列表
     */
    public function getUserPointsHistory($userId, $page = 1, $pageSize = 20) {
        $offset = ($page - 1) * $pageSize;
        $sql = "SELECT * FROM point_transactions 
                WHERE user_id = ? 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?";
        
        $transactions = $this->db->select($sql, [$userId, $pageSize, $offset]);
        
        // 获取总数
        $sql = "SELECT COUNT(*) as total FROM point_transactions WHERE user_id = ?";
        $total = $this->db->selectOne($sql, [$userId])['total'];
        
        return [
            'transactions' => $transactions,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ];
    }
    
    /**
     * 获取会员等级列表
     * @return array 会员等级列表
     */
    public function getMemberLevels() {
        // 尝试从缓存获取
        if ($this->cache) {
            $cachedLevels = $this->cache->get('member_levels');
            if ($cachedLevels) {
                return $cachedLevels;
            }
        }
        
        $sql = "SELECT * FROM member_levels WHERE status = 'active' ORDER BY level ASC";
        $levels = $this->db->select($sql);
        
        // 解析JSON数据
        foreach ($levels as &$level) {
            $level['privileges'] = $level['privileges'] ? json_decode($level['privileges'], true) : [];
        }
        
        // 缓存数据
        if ($this->cache) {
            $this->cache->set('member_levels', $levels, 86400); // 缓存24小时
        }
        
        return $levels;
    }
    
    /**
     * 管理员手动调整用户积分
     * @param int $userId 用户ID
     * @param int $points 调整积分数量
     * @param string $reason 调整原因
     * @param int $adminId 管理员ID
     * @return bool 是否成功
     */
    public function adminAdjustUserPoints($userId, $points, $reason, $adminId) {
        return $this->updateUserPoints(
            $userId, 
            $points, 
            'manual', 
            $adminId, 
            "管理员调整: {$reason}",
            true
        );
    }
    
    /**
     * 检查用户是否有会员特权
     * @param int $userId 用户ID
     * @param string $privilegeName 特权名称
     * @return bool 是否拥有该特权
     */
    public function checkUserPrivilege($userId, $privilegeName) {
        $memberInfo = $this->getUserMemberInfo($userId);
        $privileges = $memberInfo['privileges'] ?? [];
        
        return isset($privileges[$privilegeName]) && $privileges[$privilegeName];
    }
    
    /**
     * 批量更新用户会员等级
     * @return int 处理的用户数量
     */
    public function batchUpdateMemberLevels() {
        // 获取需要检查等级的用户列表（最近24小时内有积分变动的用户）
        $sql = "SELECT DISTINCT user_id FROM point_transactions 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
        $users = $this->db->select($sql);
        
        $processedCount = 0;
        
        foreach ($users as $user) {
            try {
                $memberInfo = $this->getUserMemberInfo($user['user_id']);
                $this->checkAndUpdateMemberLevel($user['user_id'], $memberInfo['current_points']);
                $processedCount++;
            } catch (Exception $e) {
                $this->logger->error("更新用户会员等级失败: " . $e->getMessage(), [
                    'user_id' => $user['user_id']
                ]);
            }
        }
        
        return $processedCount;
    }
}