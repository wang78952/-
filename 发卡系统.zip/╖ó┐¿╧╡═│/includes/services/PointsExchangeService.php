<?php
/**
 * 积分兑换服务类
 * 实现积分商品管理、积分兑换处理、兑换记录查询等功能
 */

class PointsExchangeService {
    private $db;
    private $logger;
    private $cache;
    private $memberService;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     * @param Logger $logger 日志实例
     * @param Cache $cache 缓存实例
     * @param MemberService $memberService 会员服务实例
     */
    public function __construct($db, $logger, $cache = null, $memberService = null) {
        $this->db = $db;
        $this->logger = $logger;
        $this->cache = $cache;
        
        // 如果没传入会员服务，创建一个新实例
        if (!$memberService) {
            require_once __DIR__ . '/MemberService.php';
            $this->memberService = new MemberService($db, $logger, $cache);
        } else {
            $this->memberService = $memberService;
        }
    }
    
    /**
     * 创建积分兑换商品
     * @param array $productData 商品数据
     * @return int 商品ID
     */
    public function createExchangeProduct($productData) {
        // 验证必要字段
        if (empty($productData['name']) || empty($productData['points']) || empty($productData['stock'])) {
            throw new Exception('商品名称、所需积分和库存不能为空');
        }
        
        // 默认值设置
        $status = $productData['status'] ?? 'active';
        $limitPerUser = $productData['limit_per_user'] ?? 0;
        $description = $productData['description'] ?? '';
        $imageUrl = $productData['image_url'] ?? '';
        $startDate = $productData['start_date'] ?? null;
        $endDate = $productData['end_date'] ?? null;
        $sortOrder = $productData['sort_order'] ?? 0;
        $type = $productData['type'] ?? 'physical';
        $metadata = isset($productData['metadata']) ? json_encode($productData['metadata']) : '{}';
        
        try {
            $sql = "INSERT INTO point_exchange_products (name, description, points, stock, status, limit_per_user, 
                    image_url, start_date, end_date, sort_order, type, metadata, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            
            $this->db->execute($sql, [$productData['name'], $description, $productData['points'], 
                                     $productData['stock'], $status, $limitPerUser, $imageUrl, 
                                     $startDate, $endDate, $sortOrder, $type, $metadata]);
            
            $productId = $this->db->lastInsertId();
            
            // 清除缓存
            $this->clearProductCache();
            
            $this->logger->info("积分兑换商品创建成功", ['product_id' => $productId]);
            
            return $productId;
        } catch (Exception $e) {
            $this->logger->error("创建积分兑换商品失败: " . $e->getMessage(), ['data' => $productData]);
            throw $e;
        }
    }
    
    /**
     * 更新积分兑换商品
     * @param int $productId 商品ID
     * @param array $productData 更新数据
     * @return bool 是否成功
     */
    public function updateExchangeProduct($productId, $productData) {
        try {
            // 构建更新字段
            $updateFields = [];
            $updateValues = [];
            
            if (isset($productData['name'])) {
                $updateFields[] = 'name = ?';
                $updateValues[] = $productData['name'];
            }
            if (isset($productData['description'])) {
                $updateFields[] = 'description = ?';
                $updateValues[] = $productData['description'];
            }
            if (isset($productData['points'])) {
                $updateFields[] = 'points = ?';
                $updateValues[] = $productData['points'];
            }
            if (isset($productData['stock'])) {
                $updateFields[] = 'stock = ?';
                $updateValues[] = $productData['stock'];
            }
            if (isset($productData['status'])) {
                $updateFields[] = 'status = ?';
                $updateValues[] = $productData['status'];
            }
            if (isset($productData['limit_per_user'])) {
                $updateFields[] = 'limit_per_user = ?';
                $updateValues[] = $productData['limit_per_user'];
            }
            if (isset($productData['image_url'])) {
                $updateFields[] = 'image_url = ?';
                $updateValues[] = $productData['image_url'];
            }
            if (isset($productData['start_date'])) {
                $updateFields[] = 'start_date = ?';
                $updateValues[] = $productData['start_date'];
            }
            if (isset($productData['end_date'])) {
                $updateFields[] = 'end_date = ?';
                $updateValues[] = $productData['end_date'];
            }
            if (isset($productData['sort_order'])) {
                $updateFields[] = 'sort_order = ?';
                $updateValues[] = $productData['sort_order'];
            }
            if (isset($productData['type'])) {
                $updateFields[] = 'type = ?';
                $updateValues[] = $productData['type'];
            }
            if (isset($productData['metadata'])) {
                $updateFields[] = 'metadata = ?';
                $updateValues[] = json_encode($productData['metadata']);
            }
            
            // 添加更新时间
            $updateFields[] = 'updated_at = NOW()';
            
            if (empty($updateFields)) {
                return true;
            }
            
            // 构建SQL
            $updateValues[] = $productId;
            $sql = "UPDATE point_exchange_products SET " . implode(', ', $updateFields) . " WHERE id = ?";
            
            $result = $this->db->execute($sql, $updateValues);
            
            if ($result) {
                // 清除缓存
                $this->clearProductCache();
                $this->cache->delete("exchange_product_{$productId}");
                
                $this->logger->info("积分兑换商品更新成功", ['product_id' => $productId]);
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("更新积分兑换商品失败: " . $e->getMessage(), ['product_id' => $productId]);
            throw $e;
        }
    }
    
    /**
     * 删除积分兑换商品
     * @param int $productId 商品ID
     * @return bool 是否成功
     */
    public function deleteExchangeProduct($productId) {
        try {
            $sql = "DELETE FROM point_exchange_products WHERE id = ?";
            $result = $this->db->execute($sql, [$productId]);
            
            if ($result) {
                // 清除缓存
                $this->clearProductCache();
                $this->cache->delete("exchange_product_{$productId}");
                
                $this->logger->info("积分兑换商品删除成功", ['product_id' => $productId]);
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("删除积分兑换商品失败: " . $e->getMessage(), ['product_id' => $productId]);
            throw $e;
        }
    }
    
    /**
     * 获取积分兑换商品详情
     * @param int $productId 商品ID
     * @param bool $checkAvailability 是否检查可用性
     * @return array|null 商品详情
     */
    public function getExchangeProduct($productId, $checkAvailability = false) {
        // 尝试从缓存获取
        $cacheKey = "exchange_product_{$productId}";
        if ($this->cache) {
            $cachedData = $this->cache->get($cacheKey);
            if ($cachedData && !$checkAvailability) {
                return $cachedData;
            }
        }
        
        try {
            $sql = "SELECT * FROM point_exchange_products WHERE id = ?";
            $product = $this->db->selectOne($sql, [$productId]);
            
            if (!$product) {
                return null;
            }
            
            // 解析JSON数据
            $product['metadata'] = json_decode($product['metadata'], true);
            
            // 检查商品可用性
            if ($checkAvailability) {
                $product['available'] = $this->checkProductAvailability($product);
                $product['exchangeable_now'] = $this->isProductExchangeableNow($product);
            }
            
            // 缓存数据（不包含可用性检查结果）
            if ($this->cache && !$checkAvailability) {
                $this->cache->set($cacheKey, $product, 3600);
            }
            
            return $product;
        } catch (Exception $e) {
            $this->logger->error("获取积分兑换商品失败: " . $e->getMessage(), ['product_id' => $productId]);
            throw $e;
        }
    }
    
    /**
     * 获取积分兑换商品列表
     * @param array $filters 筛选条件
     * @param int $page 页码
     * @param int $pageSize 每页数量
     * @return array 商品列表
     */
    public function getExchangeProducts($filters = [], $page = 1, $pageSize = 10) {
        // 构建查询条件
        $whereClause = [];
        $params = [];
        $availableOnly = $filters['available_only'] ?? false;
        $status = $filters['status'] ?? null;
        $type = $filters['type'] ?? null;
        $minPoints = $filters['min_points'] ?? null;
        $maxPoints = $filters['max_points'] ?? null;
        $searchKeyword = $filters['search_keyword'] ?? null;
        $sortBy = $filters['sort_by'] ?? 'sort_order';
        $sortOrder = $filters['sort_order'] ?? 'ASC';
        
        // 基础条件
        if ($status) {
            $whereClause[] = "status = ?";
            $params[] = $status;
        }
        
        if ($type) {
            $whereClause[] = "type = ?";
            $params[] = $type;
        }
        
        if ($minPoints !== null) {
            $whereClause[] = "points >= ?";
            $params[] = $minPoints;
        }
        
        if ($maxPoints !== null) {
            $whereClause[] = "points <= ?";
            $params[] = $maxPoints;
        }
        
        if ($searchKeyword) {
            $whereClause[] = "(name LIKE ? OR description LIKE ?)";
            $searchParam = "%{$searchKeyword}%";
            $params[] = $searchParam;
            $params[] = $searchParam;
        }
        
        // 可用商品过滤（需要在应用层处理，因为涉及到库存、日期等动态条件）
        $baseSql = "SELECT * FROM point_exchange_products";
        $countSql = "SELECT COUNT(*) as total FROM point_exchange_products";
        
        if (!empty($whereClause)) {
            $whereSql = " WHERE " . implode(' AND ', $whereClause);
            $baseSql .= $whereSql;
            $countSql .= $whereSql;
        }
        
        // 获取总数（不包含可用性检查的总数）
        $total = $this->db->selectOne($countSql, $params)['total'];
        
        // 添加排序和分页
        $offset = ($page - 1) * $pageSize;
        $sql = $baseSql . " ORDER BY {$sortBy} {$sortOrder} LIMIT ? OFFSET ?";
        $params[] = $pageSize;
        $params[] = $offset;
        
        try {
            $products = $this->db->select($sql, $params);
            
            // 处理每个商品
            foreach ($products as &$product) {
                // 解析JSON数据
                $product['metadata'] = json_decode($product['metadata'], true);
                
                // 如果只需要可用商品
                if ($availableOnly) {
                    $product['available'] = $this->checkProductAvailability($product);
                    $product['exchangeable_now'] = $this->isProductExchangeableNow($product);
                }
            }
            
            return [
                'products' => $products,
                'total' => $total,
                'page' => $page,
                'pageSize' => $pageSize
            ];
        } catch (Exception $e) {
            $this->logger->error("获取积分兑换商品列表失败: " . $e->getMessage(), ['filters' => $filters]);
            throw $e;
        }
    }
    
    /**
     * 用户兑换积分商品
     * @param int $userId 用户ID
     * @param int $productId 商品ID
     * @param array $exchangeData 兑换数据
     * @return array 兑换结果
     */
    public function exchangePointsForProduct($userId, $productId, $exchangeData = []) {
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 获取商品信息
            $product = $this->getExchangeProduct($productId, true);
            
            if (!$product) {
                throw new Exception('商品不存在');
            }
            
            // 检查商品可用性
            if (!$this->checkProductAvailability($product)) {
                throw new Exception('商品暂不可用');
            }
            
            // 检查时间有效性
            if (!$this->isProductExchangeableNow($product)) {
                throw new Exception('当前不在兑换时间范围内');
            }
            
            // 获取用户会员信息
            $memberInfo = $this->memberService->getUserMemberInfo($userId);
            $userPoints = $memberInfo['current_points'];
            
            // 检查积分是否足够
            if ($userPoints < $product['points']) {
                throw new Exception('积分不足');
            }
            
            // 检查用户兑换限制
            if ($product['limit_per_user'] > 0) {
                $exchangeCount = $this->getUserProductExchangeCount($userId, $productId);
                if ($exchangeCount >= $product['limit_per_user']) {
                    throw new Exception('已达到个人兑换限制');
                }
            }
            
            // 处理商品库存
            if ($product['stock'] <= 0) {
                throw new Exception('商品库存不足');
            }
            
            // 准备兑换记录数据
            $address = $exchangeData['address'] ?? null;
            $phone = $exchangeData['phone'] ?? null;
            $contactName = $exchangeData['contact_name'] ?? null;
            $remark = $exchangeData['remark'] ?? '';
            $exchangeCode = $this->generateExchangeCode();
            $orderStatus = 'pending'; // 默认待处理
            
            // 对于虚拟商品，可以直接设置为已完成
            if ($product['type'] == 'virtual' || $product['type'] == 'coupon') {
                $orderStatus = 'completed';
            }
            
            // 插入兑换记录
            $sql = "INSERT INTO point_exchange_records (user_id, product_id, product_name, product_points, 
                    exchange_code, status, contact_name, phone, address, remark, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            
            $this->db->execute($sql, [$userId, $productId, $product['name'], $product['points'],
                                     $exchangeCode, $orderStatus, $contactName, $phone, 
                                     $address, $remark]);
            
            $exchangeId = $this->db->lastInsertId();
            
            // 扣减用户积分
            $this->memberService->updateUserPoints(
                $userId, 
                -$product['points'], 
                'exchange', 
                $exchangeId, 
                "兑换商品: {$product['name']}"
            );
            
            // 更新商品库存
            $sql = "UPDATE point_exchange_products SET stock = stock - 1 WHERE id = ? AND stock > 0";
            $this->db->execute($sql, [$productId]);
            
            // 清除缓存
            $this->cache->delete("exchange_product_{$productId}");
            
            // 如果是虚拟商品，处理虚拟商品发放
            $virtualItemInfo = null;
            if ($product['type'] == 'virtual' || $product['type'] == 'coupon') {
                $virtualItemInfo = $this->processVirtualItemExchange($exchangeId, $product, $userId);
            }
            
            // 提交事务
            $this->db->commit();
            
            $this->logger->info("用户积分兑换成功", [
                'user_id' => $userId,
                'product_id' => $productId,
                'exchange_id' => $exchangeId,
                'points' => $product['points']
            ]);
            
            // 发送通知
            $this->notifyUserAboutExchange($userId, $exchangeId, $product, $orderStatus, $virtualItemInfo);
            
            return [
                'success' => true,
                'exchange_id' => $exchangeId,
                'exchange_code' => $exchangeCode,
                'status' => $orderStatus,
                'virtual_item' => $virtualItemInfo,
                'message' => '兑换成功'
            ];
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            
            $this->logger->error("用户积分兑换失败: " . $e->getMessage(), [
                'user_id' => $userId,
                'product_id' => $productId
            ]);
            
            throw $e;
        }
    }
    
    /**
     * 处理虚拟商品兑换
     * @param int $exchangeId 兑换记录ID
     * @param array $product 商品信息
     * @param int $userId 用户ID
     * @return array 虚拟商品信息
     */
    private function processVirtualItemExchange($exchangeId, $product, $userId) {
        $virtualItemInfo = [];
        $metadata = $product['metadata'];
        
        switch ($product['type']) {
            case 'virtual':
                // 处理虚拟商品兑换码等
                $virtualItemInfo['code'] = $this->generateVirtualCode();
                $virtualItemInfo['usage_instructions'] = $metadata['usage_instructions'] ?? '请查看系统消息获取使用说明';
                break;
                
            case 'coupon':
                // 处理优惠券发放
                if (isset($metadata['coupon_type_id'])) {
                    // 这里可以调用优惠券系统发放优惠券
                    // 简化实现，生成一个优惠券码
                    $virtualItemInfo['coupon_code'] = $this->generateCouponCode();
                    $virtualItemInfo['discount'] = $metadata['discount'] ?? '10%';
                    $virtualItemInfo['valid_until'] = date('Y-m-d', strtotime('+30 days'));
                }
                break;
        }
        
        // 更新兑换记录的虚拟商品信息
        if (!empty($virtualItemInfo)) {
            $sql = "UPDATE point_exchange_records SET virtual_item_info = ? WHERE id = ?";
            $this->db->execute($sql, [json_encode($virtualItemInfo), $exchangeId]);
        }
        
        return $virtualItemInfo;
    }
    
    /**
     * 获取用户兑换记录
     * @param int $userId 用户ID
     * @param array $filters 筛选条件
     * @param int $page 页码
     * @param int $pageSize 每页数量
     * @return array 兑换记录
     */
    public function getUserExchangeRecords($userId, $filters = [], $page = 1, $pageSize = 10) {
        $status = $filters['status'] ?? null;
        $startDate = $filters['start_date'] ?? null;
        $endDate = $filters['end_date'] ?? null;
        $sortBy = $filters['sort_by'] ?? 'created_at';
        $sortOrder = $filters['sort_order'] ?? 'DESC';
        
        // 构建查询条件
        $whereClause = ["user_id = ?"];
        $params = [$userId];
        
        if ($status) {
            $whereClause[] = "status = ?";
            $params[] = $status;
        }
        
        if ($startDate) {
            $whereClause[] = "DATE(created_at) >= ?";
            $params[] = $startDate;
        }
        
        if ($endDate) {
            $whereClause[] = "DATE(created_at) <= ?";
            $params[] = $endDate;
        }
        
        // 构建SQL
        $whereSql = " WHERE " . implode(' AND ', $whereClause);
        $offset = ($page - 1) * $pageSize;
        
        // 获取总数
        $sql = "SELECT COUNT(*) as total FROM point_exchange_records" . $whereSql;
        $total = $this->db->selectOne($sql, $params)['total'];
        
        // 获取记录
        $sql = "SELECT * FROM point_exchange_records" . $whereSql . 
               " ORDER BY {$sortBy} {$sortOrder} LIMIT ? OFFSET ?";
        $params[] = $pageSize;
        $params[] = $offset;
        
        $records = $this->db->select($sql, $params);
        
        // 解析虚拟商品信息
        foreach ($records as &$record) {
            if ($record['virtual_item_info']) {
                $record['virtual_item_info'] = json_decode($record['virtual_item_info'], true);
            }
        }
        
        return [
            'records' => $records,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ];
    }
    
    /**
     * 获取兑换记录
     * @param int $exchangeId 兑换记录ID
     * @return array 兑换记录
     */
    public function getExchangeRecord($exchangeId) {
        $sql = "SELECT r.*, u.username, u.email, p.image_url as product_image, p.type as product_type
                FROM point_exchange_records r
                LEFT JOIN users u ON r.user_id = u.id
                LEFT JOIN point_exchange_products p ON r.product_id = p.id
                WHERE r.id = ?";
        
        $record = $this->db->selectOne($sql, [$exchangeId]);
        
        if ($record && $record['virtual_item_info']) {
            $record['virtual_item_info'] = json_decode($record['virtual_item_info'], true);
        }
        
        return $record;
    }
    
    /**
     * 更新兑换记录状态
     * @param int $exchangeId 兑换记录ID
     * @param string $status 新状态
     * @param string $remark 备注
     * @return bool 是否成功
     */
    public function updateExchangeRecordStatus($exchangeId, $status, $remark = '') {
        try {
            $sql = "UPDATE point_exchange_records SET status = ?, remark = ?, updated_at = NOW() WHERE id = ?";
            $result = $this->db->execute($sql, [$status, $remark, $exchangeId]);
            
            if ($result) {
                // 获取兑换记录详情用于通知
                $record = $this->getExchangeRecord($exchangeId);
                
                // 发送状态变更通知
                $this->notifyUserAboutExchangeStatus($record['user_id'], $exchangeId, $status, $remark);
                
                $this->logger->info("兑换记录状态更新", [
                    'exchange_id' => $exchangeId,
                    'status' => $status
                ]);
            }
            
            return $result;
        } catch (Exception $e) {
            $this->logger->error("更新兑换记录状态失败: " . $e->getMessage(), [
                'exchange_id' => $exchangeId,
                'status' => $status
            ]);
            throw $e;
        }
    }
    
    /**
     * 取消兑换订单
     * @param int $exchangeId 兑换记录ID
     * @param int $userId 用户ID
     * @param string $reason 取消原因
     * @return bool 是否成功
     */
    public function cancelExchangeRecord($exchangeId, $userId, $reason = '') {
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 获取兑换记录
            $record = $this->getExchangeRecord($exchangeId);
            
            if (!$record) {
                throw new Exception('兑换记录不存在');
            }
            
            // 检查权限
            if ($record['user_id'] != $userId) {
                throw new Exception('无权限操作');
            }
            
            // 检查状态，只有待处理的订单可以取消
            if ($record['status'] != 'pending') {
                throw new Exception('当前状态不允许取消');
            }
            
            // 更新状态为已取消
            $sql = "UPDATE point_exchange_records SET status = 'cancelled', remark = ?, updated_at = NOW() WHERE id = ?";
            $this->db->execute($sql, [$reason, $exchangeId]);
            
            // 退还积分
            $this->memberService->updateUserPoints(
                $userId, 
                $record['product_points'], 
                'refund', 
                $exchangeId, 
                "兑换取消退还积分: {$record['product_name']}"
            );
            
            // 恢复库存
            $sql = "UPDATE point_exchange_products SET stock = stock + 1 WHERE id = ?";
            $this->db->execute($sql, [$record['product_id']]);
            
            // 提交事务
            $this->db->commit();
            
            $this->logger->info("兑换记录取消成功", ['exchange_id' => $exchangeId]);
            
            // 发送取消通知
            $this->notifyUserAboutExchangeStatus($userId, $exchangeId, 'cancelled', $reason);
            
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            
            $this->logger->error("取消兑换记录失败: " . $e->getMessage(), [
                'exchange_id' => $exchangeId,
                'user_id' => $userId
            ]);
            
            throw $e;
        }
    }
    
    /**
     * 获取用户已兑换商品数量
     * @param int $userId 用户ID
     * @param int $productId 商品ID
     * @return int 兑换数量
     */
    private function getUserProductExchangeCount($userId, $productId) {
        $sql = "SELECT COUNT(*) as count FROM point_exchange_records 
                WHERE user_id = ? AND product_id = ? AND status != 'cancelled'";
        return $this->db->selectOne($sql, [$userId, $productId])['count'];
    }
    
    /**
     * 检查商品可用性
     * @param array $product 商品信息
     * @return bool 是否可用
     */
    private function checkProductAvailability($product) {
        // 检查状态
        if ($product['status'] != 'active') {
            return false;
        }
        
        // 检查库存
        if ($product['stock'] <= 0) {
            return false;
        }
        
        // 检查时间范围
        if (!$this->isProductExchangeableNow($product)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 检查商品是否在可兑换时间范围内
     * @param array $product 商品信息
     * @return bool 是否在时间范围内
     */
    private function isProductExchangeableNow($product) {
        $now = date('Y-m-d H:i:s');
        
        // 检查开始时间
        if ($product['start_date'] && $now < $product['start_date']) {
            return false;
        }
        
        // 检查结束时间
        if ($product['end_date'] && $now > $product['end_date']) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 生成兑换码
     * @return string 兑换码
     */
    private function generateExchangeCode() {
        // 生成一个唯一的兑换码
        $timestamp = time();
        $random = rand(1000, 9999);
        $code = strtoupper(md5("EXC{$timestamp}{$random}"));
        return substr($code, 0, 12);
    }
    
    /**
     * 生成虚拟商品码
     * @return string 虚拟商品码
     */
    private function generateVirtualCode() {
        $timestamp = time();
        $random = rand(1000, 9999);
        return strtoupper(substr(md5("VIRT{$timestamp}{$random}"), 0, 16));
    }
    
    /**
     * 生成优惠券码
     * @return string 优惠券码
     */
    private function generateCouponCode() {
        $timestamp = time();
        $random = rand(100000, 999999);
        return strtoupper("CP" . date('Ymd') . $random);
    }
    
    /**
     * 清除商品缓存
     */
    private function clearProductCache() {
        if ($this->cache) {
            // 清除商品列表缓存
            $this->cache->deletePattern('exchange_products_*');
        }
    }
    
    /**
     * 发送兑换成功通知
     * @param int $userId 用户ID
     * @param int $exchangeId 兑换记录ID
     * @param array $product 商品信息
     * @param string $status 订单状态
     * @param array $virtualItemInfo 虚拟商品信息
     */
    private function notifyUserAboutExchange($userId, $exchangeId, $product, $status, $virtualItemInfo = null) {
        // 这里可以集成通知系统发送消息
        // 例如站内信、短信、邮件等
        $this->logger->info("发送兑换通知", [
            'user_id' => $userId,
            'exchange_id' => $exchangeId,
            'product_id' => $product['id']
        ]);
    }
    
    /**
     * 发送兑换状态变更通知
     * @param int $userId 用户ID
     * @param int $exchangeId 兑换记录ID
     * @param string $status 新状态
     * @param string $remark 备注
     */
    private function notifyUserAboutExchangeStatus($userId, $exchangeId, $status, $remark = '') {
        // 这里可以集成通知系统发送消息
        $this->logger->info("发送兑换状态变更通知", [
            'user_id' => $userId,
            'exchange_id' => $exchangeId,
            'status' => $status
        ]);
    }
    
    /**
     * 获取积分兑换统计
     * @param array $filters 筛选条件
     * @return array 统计数据
     */
    public function getExchangeStatistics($filters = []) {
        $startDate = $filters['start_date'] ?? null;
        $endDate = $filters['end_date'] ?? null;
        
        $whereClause = [];
        $params = [];
        
        if ($startDate) {
            $whereClause[] = "DATE(created_at) >= ?";
            $params[] = $startDate;
        }
        
        if ($endDate) {
            $whereClause[] = "DATE(created_at) <= ?";
            $params[] = $endDate;
        }
        
        $whereSql = empty($whereClause) ? "" : " WHERE " . implode(' AND ', $whereClause);
        
        // 总兑换次数
        $totalExchangeSql = "SELECT COUNT(*) as total FROM point_exchange_records" . $whereSql;
        $totalExchange = $this->db->selectOne($totalExchangeSql, $params)['total'];
        
        // 总消耗积分
        $totalPointsSql = "SELECT SUM(product_points) as total_points FROM point_exchange_records" . $whereSql;
        $totalPoints = $this->db->selectOne($totalPointsSql, $params)['total_points'] ?? 0;
        
        // 兑换人数
        $uniqueUsersSql = "SELECT COUNT(DISTINCT user_id) as unique_users FROM point_exchange_records" . $whereSql;
        $uniqueUsers = $this->db->selectOne($uniqueUsersSql, $params)['unique_users'];
        
        // 按状态统计
        $statusStatsSql = "SELECT status, COUNT(*) as count FROM point_exchange_records" . $whereSql . " GROUP BY status";
        $statusStats = $this->db->select($statusStatsSql, $params);
        
        return [
            'total_exchanges' => $totalExchange,
            'total_points_consumed' => $totalPoints,
            'unique_users' => $uniqueUsers,
            'status_statistics' => $statusStats
        ];
    }
}