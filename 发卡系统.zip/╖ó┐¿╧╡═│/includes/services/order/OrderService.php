<?php
/**
 * 订单服务类
 * 负责订单的创建、管理、状态更新等核心业务逻辑
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../services/card/CardService.php';
require_once __DIR__ . '/../../services/payment/PaymentService.php';
require_once __DIR__ . '/../../core/TableShardingManager.php';
require_once __DIR__ . '/OrderNoteService.php';
require_once __DIR__ . '/../../AfterSalesManager.php';

/**
 * 订单服务类
 * 支持订单创建、状态流转、与卡片关联、查询导出功能
 */
class OrderService extends BaseService {
    private static $instance = null;
    private $cardService;
    private $paymentService;
    private $noteManager;
    private $afterSalesManager;
    
    // 订单状态常量
    const STATUS_PENDING = 'pending';
    const STATUS_PAID = 'paid';
    const STATUS_PROCESSING = 'processing';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_REFUNDED = 'refunded';
    
    // 支付方式常量
    const PAYMENT_WECHAT = 'wechat';
    const PAYMENT_ALIPAY = 'alipay';
    const PAYMENT_BALANCE = 'balance';
    
    /**
     * 单例模式实现
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        parent::__construct();
        $this->cardService = new CardService();
        $this->paymentService = new PaymentService();
        $this->noteManager = new OrderNoteService($this->database, $this->logger);
        $this->afterSalesManager = new AfterSalesManager($this->database, $this->logger);
    }
    
    /**
     * 创建订单
     */
    public function createOrder($userId, $productId, $quantity = 1, $paymentMethod = null, $remark = '') {
        try {
            // 获取产品信息
            $product = $this->getProduct($productId);
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            // 检查库存
            if ($product['stock'] < $quantity) {
                throw new Exception('库存不足');
            }
            
            // 生成订单号
            $orderNo = $this->generateOrderNo();
            
            // 计算订单金额
            $totalAmount = $product['price'] * $quantity;
            $discountAmount = $this->calculateDiscount($productId, $quantity, null);
            $actualAmount = $totalAmount - $discountAmount;
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 创建订单记录
            $orderData = array(
            'order_no' => $orderNo,
            'user_id' => $userId,
            'product_id' => $productId,
            'product_name' => $product['name'],
            'quantity' => $quantity,
            'unit_price' => $product['price'],
            'total_amount' => $totalAmount,
            'discount_amount' => $discountAmount,
            'actual_amount' => $actualAmount,
            'payment_method' => $paymentMethod,
            'status' => self::STATUS_PENDING,
            'remark' => $remark,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
            
            // 根据创建时间获取分表名
            $shardedTableName = $this->tableShardingManager->getShardedTableName('orders', $orderData['created_at']);
            $orderId = $this->database->insert($shardedTableName, $orderData);
            
            // 预分配卡密（但不立即激活）
            $cardIds = $this->reserveCards($productId, $quantity, $orderId);
            
            // 更新订单卡密关联
            $this->updateOrderCards($orderId, $cardIds);
            
            // 提交事务
            $this->database->commit();
            
            return array(
                'success' => true,
                'order_id' => $orderId,
                'order_no' => $orderNo,
                'amount' => $actualAmount,
                'payment_method' => $paymentMethod,
                'message' => '订单创建成功'
            );
            
        } catch (Exception $e) {
            $this->database->rollback();
            throw new Exception('创建订单失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 更新订单状态
     */
    public function updateOrderStatus($orderId, $newStatus, $remark = '') {
        try {
            // 获取当前订单信息
            $order = $this->getOrder($orderId);
            if (!$order) {
                throw new Exception('订单不存在');
            }
            
            // 验证状态流转是否合法
            if (!$this->isValidStatusTransition($order['status'], $newStatus)) {
                throw new Exception('无效的状态流转');
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 获取订单所在的表
            $orderTable = $this->getOrderTable($orderId);
            
            // 更新订单状态
            $updateData = array(
                'status' => $newStatus,
                'updated_at' => date('Y-m-d H:i:s')
            );
            
            if ($remark) {
                $updateData['remark'] = $remark;
            }
            
            $this->database->update($orderTable, $updateData, 'id = ?', array($orderId));
            
            // 根据状态执行相应操作
            switch ($newStatus) {
                case self::STATUS_PAID:
                    $this->handlePaidOrder($orderId);
                    break;
                case self::STATUS_PROCESSING:
                    $this->handleProcessingOrder($orderId);
                    break;
                case self::STATUS_COMPLETED:
                    $this->handleCompletedOrder($orderId);
                    break;
                case self::STATUS_CANCELLED:
                    $this->handleCancelledOrder($orderId);
                    break;
                case self::STATUS_REFUNDED:
                    $this->handleRefundedOrder($orderId);
                    break;
            }
            
            // 记录状态变更日志
            $this->logOrderStatusChange($orderId, $order['status'], $newStatus, $remark);
            
            // 提交事务
            $this->database->commit();
            
            return array(
                'success' => true,
                'message' => '订单状态更新成功'
            );
            
        } catch (Exception $e) {
            $this->database->rollback();
            throw new Exception('更新订单状态失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 处理已支付订单
     */
    private function handlePaidOrder($orderId) {
        // 激活预分配的卡密
        $orderCards = $this->getOrderCards($orderId);
        foreach ($orderCards as $card) {
            $this->cardManager->activateCard($card['card_id'], $orderId);
        }
        
        // 更新订单支付时间
        $orderTable = $this->getOrderTable($orderId);
        $this->database->update($orderTable, array(
            'paid_at' => date('Y-m-d H:i:s')
        ), 'id = ?', array($orderId));
    }
    
    /**
     * 处理处理中订单
     */
    private function handleProcessingOrder($orderId) {
        // 可以在这里添加处理逻辑，如人工审核等
    }
    
    /**
     * 处理已完成订单
     */
    private function handleCompletedOrder($orderId) {
        // 更新完成时间
        $orderTable = $this->getOrderTable($orderId);
        $this->database->update($orderTable, array(
            'completed_at' => date('Y-m-d H:i:s')
        ), 'id = ?', array($orderId));
    }
    
    /**
     * 处理已取消订单
     */
    private function handleCancelledOrder($orderId) {
        // 释放预分配的卡密
        $orderCards = $this->getOrderCards($orderId);
        foreach ($orderCards as $card) {
            $this->cardManager->releaseCard($card['card_id']);
        }
    }
    
    /**
     * 处理已退款订单
     */
    private function handleRefundedOrder($orderId) {
        // 标记卡密为已退款状态
        $orderCards = $this->getOrderCards($orderId);
        foreach ($orderCards as $card) {
            $this->cardManager->refundCard($card['card_id']);
        }
        
        // 更新退款时间
        $orderTable = $this->getOrderTable($orderId);
        $this->database->update($orderTable, array(
            'refunded_at' => date('Y-m-d H:i:s')
        ), 'id = ?', array($orderId));
    }
    
    /**
     * 获取订单信息
     */
    public function getOrder($orderId) {
        // 如果启用了分表，需要查询所有分表
        if ($this->tableShardingManager->isShardingEnabled('orders')) {
            // 获取最近12个月的分表
            $endDate = new DateTime();
            $startDate = new DateTime('-12 months');
            $shardedTables = $this->tableShardingManager->getShardedTableNamesByDateRange('orders', $startDate, $endDate);
            
            // 生成UNION ALL查询
            $unionSQL = "";
            foreach ($shardedTables as $index => $shardedTable) {
                if ($index > 0) {
                    $unionSQL .= " UNION ALL ";
                }
                $unionSQL .= "SELECT o.*, u.username, u.email FROM {$shardedTable} o LEFT JOIN users u ON o.user_id = u.id WHERE o.id = ?";
            }
            
            // 构建参数
            $params = array_fill(0, count($shardedTables), $orderId);
            
            // 查询所有分表
            $order = $this->database->fetch($unionSQL, $params);
        } else {
            // 未启用分表，直接查询原表
            $sql = "SELECT o.*, u.username, u.email 
                    FROM orders o 
                    LEFT JOIN users u ON o.user_id = u.id 
                    WHERE o.id = ?";
            $order = $this->database->fetch($sql, array($orderId));
        }
        
        // 如果找到了订单，获取卡密、备注和售后信息
        if ($order) {
            $order['cards'] = $this->getOrderCards($orderId);
            $order['notes'] = $this->noteManager->getOrderNotes($orderId);
            $order['after_sales'] = $this->afterSalesManager->getOrderAfterSalesInfo($orderId);
        }
        
        return $order;
    }
    
    /**
     * 根据订单号获取订单信息
     */
    public function getOrderByNo($orderNo) {
        // 如果启用了分表，需要查询所有分表
        if ($this->tableShardingManager->isShardingEnabled('orders')) {
            // 获取最近12个月的分表
            $endDate = new DateTime();
            $startDate = new DateTime('-12 months');
            $shardedTables = $this->tableShardingManager->getShardedTableNamesByDateRange('orders', $startDate, $endDate);
            
            // 生成UNION ALL查询
            $unionSQL = "";
            foreach ($shardedTables as $index => $shardedTable) {
                if ($index > 0) {
                    $unionSQL .= " UNION ALL ";
                }
                $unionSQL .= "SELECT o.*, u.username, u.email FROM {$shardedTable} o LEFT JOIN users u ON o.user_id = u.id WHERE o.order_no = ?";
            }
            
            // 构建参数
            $params = array_fill(0, count($shardedTables), $orderNo);
            
            // 查询所有分表
            return $this->database->fetch($unionSQL, $params);
        } else {
            // 未启用分表，直接查询原表
            $sql = "SELECT o.*, u.username, u.email 
                    FROM orders o 
                    LEFT JOIN users u ON o.user_id = u.id 
                    WHERE o.order_no = ?";
            return $this->database->fetch($sql, array($orderNo));
        }
    }
    
    /**
     * 获取订单列表
     */
    public function getOrderList($filters = array(), $page = 1, $limit = 20) {
        $where = array('1=1');
        $params = array();
        
        // 构建查询条件
        if (!empty($filters['user_id'])) {
            $where[] = "o.user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (!empty($filters['status'])) {
            $where[] = "o.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['payment_method'])) {
            $where[] = "o.payment_method = ?";
            $params[] = $filters['payment_method'];
        }
        
        // 日期范围处理（需要用于确定分表）
        $startDate = !empty($filters['start_date']) ? $filters['start_date'] : null;
        $endDate = !empty($filters['end_date']) ? $filters['end_date'] : null;
        
        // 添加日期条件到WHERE子句
        if (!empty($startDate)) {
            $where[] = "o.created_at >= ?";
            $params[] = $startDate;
        } else {
            // 默认查询最近30天
            $startDate = date('Y-m-d H:i:s', strtotime('-30 days'));
            $where[] = "o.created_at >= ?";
            $params[] = $startDate;
        }
        
        if (!empty($endDate)) {
            $where[] = "o.created_at <= ?";
            $params[] = $endDate;
        }
        
        if (!empty($filters['keyword'])) {
            $where[] = "(o.order_no LIKE ? OR o.product_name LIKE ? OR u.username LIKE ?)";
            $keyword = '%' . $filters['keyword'] . '%';
            $params[] = $keyword;
            $params[] = $keyword;
            $params[] = $keyword;
        }
        
        $whereClause = implode(' AND ', $where);
        
        // 如果启用了分表
        if ($this->tableShardingManager->isShardingEnabled('orders')) {
            // 获取需要查询的分表
            $shardedTables = $this->tableShardingManager->getShardedTableNamesByDateRange('orders', $startDate, $endDate);
            
            // 生成UNION ALL查询用于统计总数
            $countSqls = [];
            $countParams = [];
            
            foreach ($shardedTables as $shardedTable) {
                $countSqls[] = "SELECT COUNT(*) as total FROM {$shardedTable} o LEFT JOIN users u ON o.user_id = u.id WHERE {$whereClause}";
                $countParams = array_merge($countParams, $params);
            }
            
            $countSql = implode(" UNION ALL ", $countSqls);
            $sumCountSql = "SELECT SUM(total) as total FROM ({$countSql}) as subquery";
            $totalResult = $this->database->fetch($sumCountSql, $countParams);
            $total = $totalResult['total'] ? $totalResult['total'] : 0;
            
            // 生成UNION ALL查询用于获取分页数据
            $offset = ($page - 1) * $limit;
            $unionSqls = [];
            $unionParams = [];
            
            foreach ($shardedTables as $shardedTable) {
                $unionSqls[] = "SELECT o.*, u.username, u.email FROM {$shardedTable} o LEFT JOIN users u ON o.user_id = u.id WHERE {$whereClause}";
                $unionParams = array_merge($unionParams, $params);
            }
            
            $unionSql = implode(" UNION ALL ", $unionSqls);
            $sql = "SELECT * FROM ({$unionSql}) as combined ORDER BY created_at DESC LIMIT {$offset}, {$limit}";
            
            $orders = $this->database->fetchAll($sql, $unionParams);
        } else {
            // 未启用分表，直接查询原表
            // 获取总数
            $countSql = "SELECT COUNT(*) as total 
                        FROM orders o 
                        LEFT JOIN users u ON o.user_id = u.id 
                        WHERE {$whereClause}";
            $total = $this->database->fetch($countSql, $params);
            $total = $total['total'];
            
            // 获取分页数据
            $offset = ($page - 1) * $limit;
            $sql = "SELECT o.*, u.username, u.email 
                    FROM orders o 
                    LEFT JOIN users u ON o.user_id = u.id 
                    WHERE {$whereClause} 
                    ORDER BY o.created_at DESC 
                    LIMIT {$offset}, {$limit}";
            
            $orders = $this->database->fetchAll($sql, $params);
        }
        
        // 获取每个订单的卡密信息
        foreach ($orders as &$order) {
            $order['cards'] = $this->getOrderCards($order['id']);
        }
        
        return array(
            'orders' => $orders,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        );
    }
    
    /**
     * 获取订单关联的卡密
     */
    public function getOrderCards($orderId) {
        $sql = "SELECT oc.*, c.card_no, c.card_secret, c.batch_no 
                FROM order_cards oc 
                LEFT JOIN cards c ON oc.card_id = c.id 
                WHERE oc.order_id = ?";
        return $this->database->fetchAll($sql, array($orderId));
    }
    
    /**
     * 更新订单卡密关联
     */
    private function updateOrderCards($orderId, $cardIds) {
        foreach ($cardIds as $cardId) {
            $this->database->insert('order_cards', array(
                'order_id' => $orderId,
                'card_id' => $cardId,
                'created_at' => date('Y-m-d H:i:s')
            ));
        }
    }
    
    /**
     * 预分配卡密
     */
    private function reserveCards($productId, $quantity, $orderId) {
        $cardIds = array();
        
        // 获取可用的卡密批次
        $batches = $this->cardManager->getAvailableBatches($productId, $quantity);
        
        if (count($batches) == 0) {
            throw new Exception('没有可用的卡密批次');
        }
        
        $remainingQuantity = $quantity;
        
        foreach ($batches as $batch) {
            if ($remainingQuantity <= 0) break;
            
            $availableCount = $batch['available_count'];
            $takeQuantity = min($remainingQuantity, $availableCount);
            
            // 从批次中获取卡密
            $cards = $this->cardManager->reserveCardsFromBatch($batch['id'], $takeQuantity, $orderId);
            $cardIds = array_merge($cardIds, $cards);
            
            $remainingQuantity -= $takeQuantity;
        }
        
        if ($remainingQuantity > 0) {
            throw new Exception('卡密库存不足');
        }
        
        return $cardIds;
    }
    
    /**
     * 生成订单号
     */
    private function generateOrderNo() {
        $date = date('Ymd');
        $time = time();
        $random = mt_rand(1000, 9999);
        return "ORD{$date}{$time}{$random}";
    }
    
    /**
     * 验证状态流转是否合法
     */
    private function isValidStatusTransition($fromStatus, $toStatus) {
        $validTransitions = array(
            self::STATUS_PENDING => array(self::STATUS_PAID, self::STATUS_CANCELLED),
            self::STATUS_PAID => array(self::STATUS_PROCESSING, self::STATUS_CANCELLED, self::STATUS_REFUNDED),
            self::STATUS_PROCESSING => array(self::STATUS_COMPLETED, self::STATUS_CANCELLED, self::STATUS_REFUNDED),
            self::STATUS_COMPLETED => array(self::STATUS_REFUNDED),
            self::STATUS_CANCELLED => array(),
            self::STATUS_REFUNDED => array()
        );
        
        return in_array($toStatus, $validTransitions[$fromStatus]);
    }
    
    /**
     * 记录订单状态变更日志
     */
    private function logOrderStatusChange($orderId, $fromStatus, $toStatus, $remark = '') {
        $this->database->insert('order_status_logs', array(
            'order_id' => $orderId,
            'from_status' => $fromStatus,
            'to_status' => $toStatus,
            'remark' => $remark,
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
    
    /**
     * 获取订单状态变更日志
     */
    public function getOrderStatusLogs($orderId) {
        $sql = "SELECT * FROM order_status_logs 
                WHERE order_id = ? 
                ORDER BY created_at DESC";
        return $this->database->fetchAll($sql, array($orderId));
    }
    
    /**
     * 获取产品信息
     */
    public function getProduct($productId) {
        return $this->database->selectOne(
            "SELECT * FROM products WHERE id = ? AND deleted_at IS NULL",
            array($productId)
        );
    }
    
    /**
     * 计算折扣
     */
    private function calculateDiscount($productId, $quantity, $couponCode = null) {
        $discount = 0;
        
        // 数量折扣
        $product = $this->getProduct($productId);
        if ($product && $quantity >= 5) {
            $discount += $product['price'] * 0.05; // 5% 折扣
        }
        
        // 优惠券折扣
        if ($couponCode) {
            $coupon = $this->database->selectOne(
                "SELECT * FROM coupons WHERE code = ? AND status = 'active' AND expires_at > NOW()",
                array($couponCode)
            );
            
            if ($coupon) {
                $discount += $coupon['discount'];
            }
        }
        
        return $discount;
    }
    
    /**
     * 导出订单数据
     */
    public function exportOrders($filters = array(), $format = 'csv') {
        $orders = $this->getOrderList($filters, 1, 10000);
        $orders = $orders['orders'];
        
        if ($format === 'csv') {
            return $this->exportToCSV($orders);
        } elseif ($format === 'excel') {
            return $this->exportToExcel($orders);
        } else {
            throw new Exception('不支持的导出格式');
        }
    }
    
    /**
     * 导出为CSV格式
     */
    private function exportToCSV($orders) {
        $filename = 'orders_' . date('YmdHis') . '.csv';
        $filepath = sys_get_temp_dir() . '/' . $filename;
        
        $file = fopen($filepath, 'w');
        
        // 写入BOM以支持中文
        fwrite($file, "\xEF\xBB\xBF");
        
        // 写入表头
        $headers = array(
            '订单号', '用户名', '产品名称', '数量', '单价', '总金额', 
            '折扣金额', '实付金额', '支付方式', '状态', '创建时间', 
            '支付时间', '完成时间', '备注'
        );
        fputcsv($file, $headers);
        
        // 写入数据
        foreach ($orders as $order) {
            $row = array(
                $order['order_no'],
                $order['username'],
                $order['product_name'],
                $order['quantity'],
                $order['unit_price'],
                $order['total_amount'],
                $order['discount_amount'],
                $order['actual_amount'],
                $order['payment_method'],
                $order['status'],
                $order['created_at'],
                $order['paid_at'],
                $order['completed_at'],
                $order['remark']
            );
            fputcsv($file, $row);
        }
        
        fclose($file);
        
        return array(
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => filesize($filepath)
        );
    }
    
    /**
     * 导出为Excel格式
     */
    private function exportToExcel($orders) {
        // 这里可以使用PHPExcel或其他库来实现Excel导出
        // 为了简化，这里暂时返回CSV格式
        return $this->exportToCSV($orders);
    }
    
    /**
     * 获取订单统计信息
     */
    public function getOrderStatistics($filters = array()) {
        $where = array('1=1');
        $params = array();
        
        // 构建查询条件
        if (!empty($filters['start_date'])) {
            $where[] = "created_at >= ?";
            $params[] = $filters['start_date'];
        }
        
        if (!empty($filters['end_date'])) {
            $where[] = "created_at <= ?";
            $params[] = $filters['end_date'];
        }
        
        $whereClause = implode(' AND ', $where);
        
        // 获取各状态订单数量
        if ($this->tableShardingManager->isShardingEnabled('orders')) {
            // 获取需要查询的分表
            $startDate = !empty($filters['start_date']) ? $filters['start_date'] : date('Y-m-d H:i:s', strtotime('-30 days'));
            $endDate = !empty($filters['end_date']) ? $filters['end_date'] : null;
            $shardedTables = $this->tableShardingManager->getShardedTableNamesByDateRange('orders', $startDate, $endDate);
            
            // 生成UNION ALL查询
            $unionSqls = [];
            $unionParams = [];
            
            foreach ($shardedTables as $shardedTable) {
                $unionSqls[] = "SELECT status, COUNT(*) as count FROM {$shardedTable} WHERE {$whereClause} GROUP BY status";
                $unionParams = array_merge($unionParams, $params);
            }
            
            $unionSql = implode(" UNION ALL ", $unionSqls);
            $sql = "SELECT status, SUM(count) as count FROM ({$unionSql}) as subquery GROUP BY status";
            $statusCounts = $this->database->fetchAll($sql, $unionParams);
        } else {
            $sql = "SELECT status, COUNT(*) as count 
                    FROM orders 
                    WHERE {$whereClause} 
                    GROUP BY status";
            $statusCounts = $this->database->fetchAll($sql, $params);
        }
        
        $statistics = array(
            'total_orders' => 0,
            'pending_orders' => 0,
            'paid_orders' => 0,
            'processing_orders' => 0,
            'completed_orders' => 0,
            'cancelled_orders' => 0,
            'refunded_orders' => 0,
            'total_amount' => 0
        );
        
        foreach ($statusCounts as $row) {
            $statistics['total_orders'] += $row['count'];
            
            switch ($row['status']) {
                case self::STATUS_PENDING:
                    $statistics['pending_orders'] = $row['count'];
                    break;
                case self::STATUS_PAID:
                    $statistics['paid_orders'] = $row['count'];
                    break;
                case self::STATUS_PROCESSING:
                    $statistics['processing_orders'] = $row['count'];
                    break;
                case self::STATUS_COMPLETED:
                    $statistics['completed_orders'] = $row['count'];
                    break;
                case self::STATUS_CANCELLED:
                    $statistics['cancelled_orders'] = $row['count'];
                    break;
                case self::STATUS_REFUNDED:
                    $statistics['refunded_orders'] = $row['count'];
                    break;
            }
        }
        
        // 获取总金额
        if ($this->tableShardingManager->isShardingEnabled('orders')) {
            // 获取需要查询的分表
            $startDate = !empty($filters['start_date']) ? $filters['start_date'] : date('Y-m-d H:i:s', strtotime('-30 days'));
            $endDate = !empty($filters['end_date']) ? $filters['end_date'] : null;
            $shardedTables = $this->tableShardingManager->getShardedTableNamesByDateRange('orders', $startDate, $endDate);
            
            // 生成UNION ALL查询
            $unionSqls = [];
            $unionParams = [];
            $statusInClause = "status IN (?, ?, ?)";
            
            foreach ($shardedTables as $shardedTable) {
                $unionWhereClause = $whereClause;
                if (!empty($whereClause)) {
                    $unionWhereClause .= " AND " . $statusInClause;
                } else {
                    $unionWhereClause = $statusInClause;
                }
                
                $unionSqls[] = "SELECT SUM(total_amount) as total_amount FROM {$shardedTable} WHERE {$unionWhereClause}";
                $unionParams = array_merge($unionParams, $params, array(
                    self::STATUS_PAID, 
                    self::STATUS_PROCESSING, 
                    self::STATUS_COMPLETED
                ));
            }
            
            $unionSql = implode(" UNION ALL ", $unionSqls);
            $sql = "SELECT SUM(total_amount) as total_amount FROM ({$unionSql}) as subquery";
            $result = $this->database->fetch($sql, $unionParams);
        } else {
            $sql = "SELECT SUM(total_amount) as total_amount 
                    FROM orders 
                    WHERE {$whereClause} AND status IN (?, ?, ?)";
            $amountParams = array_merge($params, array(
                self::STATUS_PAID, 
                self::STATUS_PROCESSING, 
                self::STATUS_COMPLETED
            ));
            $result = $this->database->fetch($sql, $amountParams);
        }
        
        $statistics['total_amount'] = $result['total_amount'] ? $result['total_amount'] : 0;
        
        return $statistics;
    }
    
    /**
     * 获取订单所在的分表名
     * @param int $orderId 订单ID
     * @return string 分表名
     */
    private function getOrderTable($orderId) {
        // 如果启用了分表，先查询订单的创建时间以确定分表
        if ($this->tableShardingManager->isShardingEnabled('orders')) {
            // 由于我们需要获取订单所在的表，这里需要先查询所有可能的表
            // 但为了简化，我们可以先获取订单的创建时间
            // 这里使用一个特殊的函数来获取订单的创建时间
            $endDate = new DateTime();
            $startDate = new DateTime('-12 months');
            $shardedTables = $this->tableShardingManager->getShardedTableNamesByDateRange('orders', $startDate, $endDate);
            
            foreach ($shardedTables as $shardedTable) {
                $sql = "SELECT created_at FROM {$shardedTable} WHERE id = ? LIMIT 1";
                $result = $this->database->fetch($sql, array($orderId));
                
                if ($result) {
                    // 找到了订单，返回它所在的表
                    return $shardedTable;
                }
            }
            
            // 没找到，返回默认表
            return 'orders';
        } else {
            return 'orders';
        }
    }
}