<?php
/**
 * 订单备注服务类
 * 负责管理订单备注信息、操作日志等
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../core/SecurityUtils.php';

/**
 * 订单备注服务类
 * 提供订单备注的增删改查、权限控制、敏感信息过滤功能
 */
class OrderNoteService extends BaseService {
    private static $instance = null;
    private $database;
    private $logger;
    private $securityUtils;
    
    /**
     * 单例模式实现
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        parent::__construct();
        $this->database = $this->getDatabase();
        $this->logger = $this->getLogger();
        $this->securityUtils = new SecurityUtils();
    }
    
    /**
     * 添加订单备注
     * @param int $orderId 订单ID
     * @param array $noteData 备注数据
     * @return array 操作结果
     */
    public function addNote($orderId, $noteData) {
        try {
            // 验证订单是否存在
            if (!$this->orderExists($orderId)) {
                return ['success' => false, 'message' => '订单不存在'];
            }
            
            // 准备备注数据
            $data = [
                'order_id' => $orderId,
                'user_id' => isset($noteData['user_id']) ? $noteData['user_id'] : null,
                'user_type' => isset($noteData['user_type']) ? $noteData['user_type'] : 'system',
                'content' => $noteData['content'],
                'is_public' => isset($noteData['is_public']) ? $noteData['is_public'] : 1,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 插入备注
            $noteId = $this->database->insert('order_notes', $data);
            
            if ($noteId) {
                // 记录操作日志
                $this->logOperation('add_note', $orderId, $noteId, $data['user_id']);
                
                return [
                    'success' => true,
                    'note_id' => $noteId,
                    'message' => '备注添加成功'
                ];
            }
            
            return ['success' => false, 'message' => '备注添加失败'];
            
        } catch (Exception $e) {
            $this->logger->error('添加订单备注失败: ' . $e->getMessage());
            return ['success' => false, 'message' => '服务器错误，请稍后重试'];
        }
    }
    
    /**
     * 获取订单的所有备注
     * @param int $orderId 订单ID
     * @param array $options 查询选项
     * @return array 备注列表
     */
    public function getOrderNotes($orderId, $options = []) {
        try {
            // 基础查询
            $sql = "SELECT * FROM order_notes WHERE order_id = ?";
            $params = [$orderId];
            
            // 处理用户可见性过滤
            if (isset($options['user_type']) && $options['user_type'] === 'user') {
                $sql .= " AND is_public = 1";
            }
            
            // 排序
            $sql .= " ORDER BY created_at DESC";
            
            // 执行查询
            $notes = $this->database->fetchAll($sql, $params);
            
            // 格式化时间
            foreach ($notes as &$note) {
                $note['created_at_formatted'] = $this->formatDateTime($note['created_at']);
            }
            
            return $notes;
            
        } catch (Exception $e) {
            $this->logger->error('获取订单备注失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 删除订单备注
     * @param int $noteId 备注ID
     * @param int $userId 操作用户ID
     * @return array 操作结果
     */
    public function deleteNote($noteId, $userId) {
        try {
            // 获取备注信息
            $note = $this->database->fetch("SELECT * FROM order_notes WHERE id = ?", [$noteId]);
            
            if (!$note) {
                return ['success' => false, 'message' => '备注不存在'];
            }
            
            // 权限检查（只有创建者或管理员可以删除）
            if ($note['user_id'] != $userId && !$this->isAdmin($userId)) {
                return ['success' => false, 'message' => '无权删除此备注'];
            }
            
            // 删除备注
            $result = $this->database->delete('order_notes', "id = ?", [$noteId]);
            
            if ($result) {
                // 记录操作日志
                $this->logOperation('delete_note', $note['order_id'], $noteId, $userId);
                
                return ['success' => true, 'message' => '备注删除成功'];
            }
            
            return ['success' => false, 'message' => '备注删除失败'];
            
        } catch (Exception $e) {
            $this->logger->error('删除订单备注失败: ' . $e->getMessage());
            return ['success' => false, 'message' => '服务器错误，请稍后重试'];
        }
    }
    
    /**
     * 检查订单是否存在
     * @param int $orderId 订单ID
     * @return bool 是否存在
     */
    private function orderExists($orderId) {
        $result = $this->database->fetch("SELECT id FROM orders WHERE id = ?", [$orderId]);
        return $result !== false;
    }
    
    /**
     * 检查用户是否为管理员
     * @param int $userId 用户ID
     * @return bool 是否为管理员
     */
    private function isAdmin($userId) {
        $result = $this->database->fetch("SELECT role FROM users WHERE id = ?", [$userId]);
        return $result && $result['role'] === 'admin';
    }
    
    /**
     * 格式化日期时间
     * @param string $datetime 日期时间字符串
     * @return string 格式化后的日期时间
     */
    private function formatDateTime($datetime) {
        return date('Y-m-d H:i:s', strtotime($datetime));
    }
    
    /**
     * 记录操作日志
     * @param string $action 操作类型
     * @param int $orderId 订单ID
     * @param int $noteId 备注ID
     * @param int $userId 用户ID
     */
    private function logOperation($action, $orderId, $noteId, $userId) {
        $this->database->insert('order_operation_logs', [
            'order_id' => $orderId,
            'operation_type' => 'note_' . $action,
            'operation_content' => json_encode([
                'note_id' => $noteId,
                'user_id' => $userId,
                'action' => $action
            ]),
            'operator_id' => $userId,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * 批量获取订单备注
     * @param array $orderIds 订单ID数组
     * @return array 按订单ID分组的备注列表
     */
    public function getBatchOrderNotes($orderIds) {
        try {
            if (empty($orderIds)) {
                return [];
            }
            
            $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
            $sql = "SELECT * FROM order_notes WHERE order_id IN ({$placeholders}) ORDER BY created_at DESC";
            
            $notes = $this->database->fetchAll($sql, $orderIds);
            
            // 按订单ID分组
            $groupedNotes = [];
            foreach ($notes as $note) {
                if (!isset($groupedNotes[$note['order_id']])) {
                    $groupedNotes[$note['order_id']] = [];
                }
                $note['created_at_formatted'] = $this->formatDateTime($note['created_at']);
                $groupedNotes[$note['order_id']][] = $note;
            }
            
            return $groupedNotes;
            
        } catch (Exception $e) {
            $this->logger->error('批量获取订单备注失败: ' . $e->getMessage());
            return [];
        }
    }
}
?>