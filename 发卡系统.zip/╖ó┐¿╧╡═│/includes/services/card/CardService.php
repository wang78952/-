<?php
/**
 * 卡片服务类
 * 负责管理卡片库存、卡密生成、卡片分配等核心业务逻辑
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../core/SecurityManager.php';
require_once __DIR__ . '/../../core/CacheManager.php';
require_once __DIR__ . '/InventoryService.php';

/**
 * 卡片服务类
 * 提供卡片的增删改查、状态管理、批量操作等功能
 */
class CardService extends BaseService {
    private static $instance = null;
    private $security;
    private $cacheManager;
    private $inventoryService;
    
    /**
     * 单例模式实现
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct()
    {
        parent::__construct();
        $this->security = new SecurityManager();
        // 初始化缓存管理器
        $this->cacheManager = CacheManager::getInstance() ?? new CacheManager();
        $this->inventoryService = new InventoryService();
    }
    
    /**
     * 生成卡密
     * @param array $params 生成参数
     * @return array|false
     */
    public function generateCards($params) {
        try {
            $productId = $params['product_id'];
            $quantity = intval($params['quantity']);
            $batchId = isset($params['batch_id']) ? $params['batch_id'] : null;
        $validDays = intval(isset($params['valid_days']) ? $params['valid_days'] : 365);
        $prefix = isset($params['prefix']) ? $params['prefix'] : '';
        $operatorId = isset($params['operator_id']) ? $params['operator_id'] : null;
            
            // 验证参数
            if (empty($productId) || $quantity <= 0 || $quantity > 10000) {
                throw new InvalidArgumentException('Invalid generation parameters');
            }
            
            // 验证产品
            $product = $this->getProduct($productId);
            if (!$product) {
                throw new Exception('Product not found');
            }
            
            // 创建批次记录
            if (!$batchId) {
                $batchId = $this->createBatch([
                    'product_id' => $productId,
                    'quantity' => $quantity,
                    'valid_days' => $validDays,
                    'operator_id' => $operatorId
                ]);
            }
            
            $cards = array();
            $generatedCount = 0;
            $maxRetries = $quantity * 3; // 最多重试3倍数量
            
            while ($generatedCount < $quantity && $maxRetries > 0) {
                try {
                    $cardCode = $this->generateUniqueCardCode($prefix);
                    $cardSecret = $this->generateCardSecret();
                    $encryptedCode = $this->security->encrypt($cardCode);
                    $encryptedSecret = $this->security->encrypt($cardSecret);
                    
                    // 生成搜索索引（部分字符哈希）用于查询
                    $searchIndex = substr(hash('sha256', $cardCode), 0, 16);
                    
                    $cardData = array(
                        'batch_id' => $batchId,
                        'product_id' => $productId,
                        'card_code' => $encryptedCode,
                        'card_code_index' => $searchIndex,
                        'card_secret' => $encryptedSecret,
                        'status' => 'active',
                        'expires_at' => date('Y-m-d H:i:s', strtotime("+{$validDays} days")),
                        'created_at' => date('Y-m-d H:i:s')
                    );
                    
                    $cardId = $this->insertCard($cardData);
                    if ($cardId) {
                        $cards[] = array(
                            'id' => $cardId,
                            'code' => $cardCode,
                            'secret' => $cardSecret, // 返回明文密钥，仅此一次
                            'expires_at' => $cardData['expires_at']
                        );
                        $generatedCount++;
                    }
                } catch (Exception $e) {
                    $this->logger->warning("Card generation failed, retrying", array(
                        'error' => $e->getMessage(),
                        'generated' => $generatedCount,
                        'target' => $quantity
                    ));
                }
                $maxRetries--;
            }
            
            if ($generatedCount < $quantity) {
                throw new Exception("Failed to generate sufficient cards. Generated: {$generatedCount}, Required: {$quantity}");
            }
            
            // 更新批次状态
            $this->updateBatchStatus($batchId, 'completed', $generatedCount);
            
            $this->logger->info("Cards generated successfully", array(
                'batch_id' => $batchId,
                'product_id' => $productId,
                'quantity' => $generatedCount
            ));
            
            return array(
                'batch_id' => $batchId,
                'cards' => $cards,
                'quantity' => $generatedCount
            );
            
        } catch (Exception $e) {
            $this->logger->error("Card generation failed", array(
                'params' => $params,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 验证卡密
     * @param string $cardCode 卡密编码
     * @param string $cardSecret 卡密密码
     * @return array|false
     */
    public function validateCard($cardCode, $cardSecret) {
        try {
            // 尝试从缓存获取卡密信息
            $cacheKey = "card:validate:" . md5($cardCode);
            $cachedCard = $this->cacheManager->get($cacheKey);
            
            if ($cachedCard) {
                // 验证密码
                $decryptedSecret = $this->security->decrypt($cachedCard['card_secret']);
                if ($decryptedSecret === $cardSecret) {
                    // 检查过期时间
                    if ($cachedCard['expires_at'] && strtotime($cachedCard['expires_at']) < time()) {
                        // 更新缓存中的状态为过期
                        $cachedCard['status'] = 'expired';
                        $this->cacheManager->set($cacheKey, $cachedCard, 60); // 短时间缓存过期状态
                        
                        // 更新数据库状态
                        $this->updateCardStatus($cachedCard['id'], 'expired');
                        return false;
                    }
                    
                    // 检查使用状态
                    if ($cachedCard['status'] === 'used') {
                        return false;
                    }
                    
                    return $cachedCard;
                }
            }
            
            // 缓存未命中，从数据库查询
            $sql = "SELECT * FROM cards WHERE card_code = ? AND status IN ('active', 'used')";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($cardCode));
            $card = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$card) {
                $this->logger->warning("Card not found", array('card_code' => $cardCode));
                // 缓存不存在的卡密，短时间缓存
                $this->cacheManager->set($cacheKey, null, 60);
                return false;
            }
            
            // 缓存卡密信息
            $this->cacheManager->set($cacheKey, $card, 300); // 5分钟缓存
            
            // 验证密码
            $decryptedSecret = $this->security->decrypt($card['card_secret']);
            if ($decryptedSecret !== $cardSecret) {
                $this->logger->warning("Card secret mismatch", array(
                    'card_id' => $card['id'],
                    'card_code' => $cardCode
                ));
                return false;
            }
            
            // 检查过期时间
            if ($card['expires_at'] && strtotime($card['expires_at']) < time()) {
                $this->logger->info("Card expired", array(
                    'card_id' => $card['id'],
                    'card_code' => $cardCode,
                    'expires_at' => $card['expires_at']
                ));
                
                // 更新状态为过期
                $this->updateCardStatus($card['id'], 'expired');
                // 更新缓存
                $card['status'] = 'expired';
                $this->cacheManager->set($cacheKey, $card, 60);
                return false;
            }
            
            // 检查使用状态
            if ($card['status'] === 'used') {
                $this->logger->info("Card already used", array(
                    'card_id' => $card['id'],
                    'card_code' => $cardCode,
                    'used_at' => $card['used_at']
                ));
                return false;
            }
            
            return $card;
            
        } catch (Exception $e) {
            $this->logger->error("Card validation failed", array(
                'card_code' => $cardCode,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 核销卡密
     * @param int $cardId 卡密ID
     * @param array $usage 使用信息
     * @return bool
     */
    public function redeemCardById($cardId, $usage = array()) {
        try {
            $this->database->beginTransaction();
            
            // 锁定卡密记录
            $sql = "SELECT * FROM cards WHERE id = ? AND status = 'active' FOR UPDATE";
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($cardId));
            $card = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$card) {
                throw new Exception('Card not found or not active');
            }
            
            // 检查过期时间
            if ($card['expires_at'] && strtotime($card['expires_at']) < time()) {
                $this->updateCardStatus($cardId, 'expired');
                throw new Exception('Card has expired');
            }
            
            // 更新卡密状态
            $updateSql = "UPDATE cards SET 
                          status = 'used', 
                          used_at = NOW(),
                          used_ip = ?,
                          used_user_agent = ?,
                          usage_data = ?
                          WHERE id = ?";
            
            $updateStmt = $this->database->prepare($updateSql);
            $result = $updateStmt->execute(array(
                isset($usage['ip']) ? $usage['ip'] : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''),
                isset($usage['user_agent']) ? $usage['user_agent'] : (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''),
                json_encode(isset($usage['data']) ? $usage['data'] : array()),
                $cardId
            ));
            
            if (!$result) {
                throw new Exception('Failed to update card status');
            }
            
            // 记录使用日志
            $this->logCardUsage($cardId, $usage);
            
            // 更新产品统计
            $this->updateProductStats($card['product_id'], 'used');
            
            $this->database->commit();
            
            $this->logger->info("Card redeemed successfully", array(
                'card_id' => $cardId,
                'card_code' => $card['card_code'],
                'usage' => $usage
            ));
            
            return true;
            
        } catch (Exception $e) {
            $this->database->rollBack();
            $this->logger->error("Card redemption failed", array(
                'card_id' => $cardId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 核销卡密（别名方法）
     * @param int $cardId 卡密ID
     * @param array $usage 使用信息
     * @return bool
     */
    public function redeemCard($cardId, $usage = array()) {
        return $this->redeemCardById($cardId, $usage);
    }
    
    /**
     * 批量核销卡密
     * @param array $cardIds 卡密ID数组
     * @param array $usage 使用信息
     * @return array
     */
    public function batchRedeemCards($cardIds, $usage = array()) {
        $results = array();
        $successCount = 0;
        $failureCount = 0;
        
        foreach ($cardIds as $cardId) {
            try {
                $result = $this->redeemCard($cardId, $usage);
                if ($result) {
                    $results[$cardId] = array('success' => true);
                    $successCount++;
                } else {
                    $results[$cardId] = array('success' => false, 'error' => 'Redemption failed');
                    $failureCount++;
                }
            } catch (Exception $e) {
                $results[$cardId] = array('success' => false, 'error' => $e->getMessage());
                $failureCount++;
            }
        }
        
        $this->logger->info("Batch card redemption completed", array(
            'total' => count($cardIds),
            'success' => $successCount,
            'failure' => $failureCount
        ));
        
        return array(
            'results' => $results,
            'summary' => array(
                'total' => count($cardIds),
                'success' => $successCount,
                'failure' => $failureCount
            )
        );
    }
    
    /**
     * 检测过期卡密
     * @param int $batchSize 批处理大小
     * @return array
     */
    public function detectExpiredCards($batchSize = 1000) {
        try {
            // 查找过期但状态仍为active的卡密
            $sql = "SELECT id, card_code, expires_at 
                    FROM cards 
                    WHERE status = 'active' 
                    AND expires_at < NOW() 
                    ORDER BY expires_at ASC 
                    LIMIT ?";
            
            $stmt = $this->database->prepare($sql);
            $stmt->execute(array($batchSize));
            $expiredCards = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $updateSql = "UPDATE cards SET status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $updateStmt = $this->database->prepare($updateSql);
            
            $updatedCount = 0;
            foreach ($expiredCards as $card) {
                $updateStmt->execute(array($card['id']));
                $this->logger->info("Card expired", array('card_id' => $card['id'], 'card_number' => $card['card_number']));
                $updatedCount++;
            }
            
            $this->logger->info("Batch expired cards processed", array(
                'processed_count' => $updatedCount,
                'batch_size' => $batchSize
            ));
            
            return $updatedCount;
            $updateStmt = $this->database->prepare($updateSql);
            foreach ($expiredCards as $card) {
                $updateStmt->execute(array($card['id']));
                $this->logger->info("Card expired", array('card_id' => $card['id'], 'card_number' => $card['card_number']));
            }
            
            $this->logger->info("Expired cards detection completed", array(
                'detected' => count($expiredCards),
                'updated' => $updatedCount
            ));
            
            return array(
                'detected' => count($expiredCards),
                'updated' => $updatedCount,
                'cards' => $expiredCards
            );
            
        } catch (Exception $e) {
            $this->logger->error("Expired cards detection failed", array(
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 异常检测
     * @return array
     */
    public function detectAnomalies() {
        $anomalies = array();
        
        try {
            // 检测重复卡密
            $duplicateSql = "SELECT card_code, COUNT(*) as count 
                            FROM cards 
                            GROUP BY card_code 
                            HAVING COUNT(*) > 1";
            $stmt = $this->database->prepare($duplicateSql);
            $stmt->execute();
            $duplicates = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($duplicates)) {
                $anomalies['duplicate_cards'] = $duplicates;
            }
            
            // 检测异常使用模式
            $abnormalUsageSql = "SELECT used_ip, COUNT(*) as usage_count 
                                FROM cards 
                                WHERE used_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
                                GROUP BY used_ip 
                                HAVING usage_count > 100";
            $stmt = $this->database->prepare($abnormalUsageSql);
            $stmt->execute();
            $abnormalUsage = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($abnormalUsage)) {
                $anomalies['abnormal_usage'] = $abnormalUsage;
            }
            
            // 检测即将过期的卡密
            $expiringSoonSql = "SELECT COUNT(*) as count 
                               FROM cards 
                               WHERE status = 'active' 
                               AND expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)";
            $stmt = $this->database->prepare($expiringSoonSql);
            $stmt->execute();
            $expiringSoon = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($expiringSoon['count'] > 0) {
                $anomalies['expiring_soon'] = $expiringSoon['count'];
            }
            
            $this->logger->info("Anomaly detection completed", array(
                'anomalies' => $anomalies
            ));
            
            return $anomalies;
            
        } catch (Exception $e) {
            $this->logger->error("Anomaly detection failed", array(
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 生成唯一卡密编码
     * @param string $prefix 前缀
     * @return string
     */
    private function generateUniqueCardCode($prefix = '') {
        $maxRetries = 100;
        
        for ($i = 0; $i < $maxRetries; $i++) {
            $timestamp = date('YmdHis');
            $random = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
            $checksum = $this->generateChecksum($timestamp . $random);
            $cardCode = ($prefix ? $prefix . '-' : '') . $timestamp . $random . $checksum;
            
            // 检查唯一性
            if (!$this->cardCodeExists($cardCode)) {
                return $cardCode;
            }
        }
        
        throw new Exception('Failed to generate unique card code after maximum retries');
    }
    
    /**
     * 生成卡密密码
     * @return string
     */
    private function generateCardSecret() {
        $length = isset($this->config['secret_length']) ? $this->config['secret_length'] : 16;
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $secret = '';
        
        for ($i = 0; $i < $length; $i++) {
            $secret .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        // 添加分隔符提高可读性
        return implode('-', str_split($secret, 4));
    }
    
    /**
     * 生成校验码
     * @param string $data 数据
     * @return string
     */
    private function generateChecksum($data) {
        return substr(md5($data . $this->config['checksum_salt']), 0, 2);
    }
    
    /**
     * 检查卡密编码是否存在
     * @param string $cardCode
     * @return bool
     */
    private function cardCodeExists($cardCode) {
        return $this->database->fetchColumn("SELECT COUNT(*) FROM cards WHERE card_code = ?", array($cardCode)) > 0;
    }
    
    /**
     * 插入卡密记录
     * @param array $cardData
     * @return int|false
     */
    private function insertCard($cardData) {
        $sql = "INSERT INTO cards (batch_id, product_id, card_code, card_secret, status, expires_at, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->database->prepare($sql);
        $result = $stmt->execute(array(
            $cardData['batch_id'],
            $cardData['product_id'],
            $cardData['card_code'],
            $cardData['card_secret'],
            $cardData['status'],
            $cardData['expires_at'],
            $cardData['created_at']
        ));
        
        return $result ? $this->database->lastInsertId() : false;
    }
    
    /**
     * 创建批次记录
     * @param array $batchData
     * @return int|false
     */
    private function createBatch($batchData) {
        $sql = "INSERT INTO card_batches (product_id, quantity, valid_days, status, operator_id, created_at) 
                VALUES (?, ?, ?, 'processing', ?, NOW())";
        
        $stmt = $this->database->prepare($sql);
        $result = $stmt->execute(array(
            $batchData['product_id'],
            $batchData['quantity'],
            $batchData['valid_days'],
            $batchData['operator_id']
        ));
        
        return $result ? $this->database->lastInsertId() : false;
    }
    
    /**
     * 更新批次状态
     * @param int $batchId
     * @param string $status
     * @param int $generatedCount
     * @return bool
     */
    private function updateBatchStatus($batchId, $status, $generatedCount = null) {
        $sql = "UPDATE card_batches SET status = ?";
        $params = array($status);
        
        if ($generatedCount !== null) {
            $sql .= ", generated_count = ?";
            $params[] = $generatedCount;
        }
        
        $sql .= " WHERE id = ?";
        $params[] = $batchId;
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute($params);
    }
    
    /**
     * 更新卡密状态
     * @param int $cardId
     * @param string $status
     * @return bool
     */
    private function updateCardStatus($cardId, $status) {
        $sql = "UPDATE cards SET status = ? WHERE id = ?";
        $stmt = $this->database->prepare($sql);
        return $stmt->execute(array($status, $cardId));
    }
    
    /**
     * 记录卡密使用日志
     * @param int $cardId
     * @param array $usage
     * @return bool
     */
    private function logCardUsage($cardId, $usage) {
        $sql = "INSERT INTO card_usage_logs (card_id, usage_data, ip_address, user_agent, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute(array(
            $cardId,
            json_encode(isset($usage['data']) ? $usage['data'] : array()),
            isset($usage['ip']) ? $usage['ip'] : '',
            isset($usage['user_agent']) ? $usage['user_agent'] : ''
        ));
    }
    
    /**
     * 更新产品统计
     * @param int $productId
     * @param string $action
     * @return bool
     */
    private function updateProductStats($productId, $action) {
        $field = $action === 'used' ? 'used_count' : 'generated_count';
        $sql = "UPDATE products SET {$field} = {$field} + 1 WHERE id = ?";
        $stmt = $this->database->prepare($sql);
        return $stmt->execute(array($productId));
    }
    
    /**
     * 获取产品信息
     * @param int $productId
     * @return array|false
     */
    private function getProduct($productId) {
        // 尝试从缓存获取产品信息
        $productCacheKey = "product:" . $productId;
        $cachedProduct = $this->cacheManager->get($productCacheKey);
        
        if ($cachedProduct) {
            return $cachedProduct;
        }
        
        // 缓存未命中，从数据库查询
        $sql = "SELECT * FROM products WHERE id = ?";
        $stmt = $this->database->prepare($sql);
        $stmt->execute(array($productId));
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 缓存产品信息
        if ($product) {
            $this->cacheManager->set($productCacheKey, $product, 3600); // 1小时缓存
        }
        
        return $product;
    }
    
    /**
     * 加载配置
     * @return array
     */
    private function loadConfig() {
        return array(
            'secret_length' => 16,
            'checksum_salt' => 'card_system_salt_2024',
            'max_generation_batch' => 10000,
            'default_valid_days' => 365
        );
    }
    
    /**
     * 获取卡密列表
     * @param int $page 页码
     * @param int $limit 每页数量
     * @param array $filters 过滤条件
     * @return array
     */
    public function getCards($page = 1, $limit = 20, $filters = array()) {
        try {
            $offset = ($page - 1) * $limit;
            
            // 构建WHERE条件
            $where = array("1=1");
            $params = array();
            
            if (!empty($filters['batch_id'])) {
                $where[] = "c.batch_id = ?";
                $params[] = $filters['batch_id'];
            }
            
            if (!empty($filters['status'])) {
                $where[] = "c.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['product_id'])) {
                $where[] = "c.product_id = ?";
                $params[] = $filters['product_id'];
            }
            
            $whereClause = implode(" AND ", $where);
            
            // 查询总数
            $countSql = "SELECT COUNT(*) FROM cards c WHERE {$whereClause}";
            $total = $this->database->fetchColumn($countSql, $params);
            
            // 查询数据
            $sql = "SELECT c.*, p.name as product_name, cb.quantity as batch_quantity
                    FROM cards c
                    LEFT JOIN products p ON c.product_id = p.id
                    LEFT JOIN card_batches cb ON c.batch_id = cb.id
                    WHERE {$whereClause}
                    ORDER BY c.created_at DESC
                    LIMIT ? OFFSET ?";
            
            $stmt = $this->database->prepare($sql);
            $params[] = $limit;
            $params[] = $offset;
            $stmt->execute($params);
            $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 解密密钥（仅显示部分）
            foreach ($cards as &$card) {
                $card['card_secret'] = substr($card['card_secret'], 0, 8) . '...';
            }
            
            return array(
                'cards' => $cards,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                )
            );
            
        } catch (Exception $e) {
            $this->logger->error("Get cards failed", array(
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 验证卡密（API版本）
     * @param string $cardCode 卡密编码
     * @param string $cardSecret 卡密密码
     * @return array|false
     */
    public function verifyCard($cardCode, $cardSecret = null) {
        $card = $this->validateCard($cardCode, $cardSecret);
        
        if (!$card) {
            return false;
        }
        
        // 返回安全信息
        return array(
            'id' => $card['id'],
            'card_code' => $card['card_code'],
            'status' => $card['status'],
            'product_id' => $card['product_id'],
            'expires_at' => $card['expires_at'],
            'created_at' => $card['created_at']
        );
    }
    
    /**
     * 使用卡密（API版本）
     * @param string $cardCode 卡密编码
     * @param string $cardSecret 卡密密码
     * @param array $usageData 使用数据
     * @return array|false
     */
    public function redeemCardByCode($cardCode, $cardSecret, $usageData = array()) {
        try {
            // 验证卡密
            $card = $this->validateCard($cardCode, $cardSecret);
            if (!$card) {
                return false;
            }
            
            // 核销卡密
            $usage = array(
                'ip' => isset($usageData['ip_address']) ? $usageData['ip_address'] : '',
                'user_agent' => isset($usageData['user_agent']) ? $usageData['user_agent'] : '',
                'data' => $usageData
            );
            
            $result = $this->redeemCardById($card['id'], $usage);
            
            if ($result) {
                return array(
                    'success' => true,
                    'card_id' => $card['id'],
                    'card_code' => $card['card_code'],
                    'product_id' => $card['product_id'],
                    'used_at' => date('Y-m-d H:i:s')
                );
            }
            
            return false;
            
        } catch (Exception $e) {
            $this->logger->error("Redeem card failed", array(
                'card_code' => $cardCode,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取卡密统计
     * @param int $productId 产品ID
     * @param string $dateFrom 开始日期
     * @param string $dateTo 结束日期
     * @return array
     */
    public function getCardStatistics($productId = null, $dateFrom = null, $dateTo = null) {
        try {
            // 生成缓存键
            $cacheKey = "card:stats:" . md5(serialize(compact('productId', 'dateFrom', 'dateTo')));
            
            // 尝试从缓存获取统计数据
            $cachedStats = $this->cacheManager->get($cacheKey);
            if ($cachedStats) {
                return $cachedStats;
            }
            
            // 缓存未命中，构建查询
            $where = array("1=1");
            $params = array();
            
            if ($productId) {
                $where[] = "product_id = ?";
                $params[] = $productId;
            }
            
            if ($dateFrom) {
                $where[] = "created_at >= ?";
                $params[] = $dateFrom;
            }
            
            if ($dateTo) {
                $where[] = "created_at <= ?";
                $params[] = $dateTo;
            }
            
            $whereClause = implode(" AND ", $where);
            
            // 统计查询
            $sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                        SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used,
                        SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired,
                        SUM(CASE WHEN status = 'invalid' THEN 1 ELSE 0 END) as invalid
                    FROM cards 
                    WHERE {$whereClause}";
                    
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 缓存统计结果 (15分钟)
            $this->cacheManager->set($cacheKey, $stats, 900);
            
            return $stats;
            
        } catch (Exception $e) {
            $this->logger->error("Get card statistics failed", array(
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取异常记录
     * @param int $page 页码
     * @param int $limit 每页数量
     * @param array $filters 过滤条件
     * @return array
     */
    public function getAnomalies($page = 1, $limit = 20, $filters = array()) {
        try {
            $offset = ($page - 1) * $limit;
            
            // 构建WHERE条件
            $where = array("1=1");
            $params = array();
            
            if (!empty($filters['anomaly_type'])) {
                $where[] = "anomaly_type = ?";
                $params[] = $filters['anomaly_type'];
            }
            
            if (!empty($filters['severity'])) {
                $where[] = "severity = ?";
                $params[] = $filters['severity'];
            }
            
            if (!empty($filters['status'])) {
                $where[] = "status = ?";
                $params[] = $filters['status'];
            }
            
            $whereClause = implode(" AND ", $where);
            
            // 查询总数
            $countSql = "SELECT COUNT(*) FROM card_anomalies WHERE {$whereClause}";
            $total = $this->database->fetchColumn($countSql, $params);
            
            // 查询数据
            $sql = "SELECT * FROM card_anomalies
                    WHERE {$whereClause}
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?";
            
            $stmt = $this->database->prepare($sql);
            $params[] = $limit;
            $params[] = $offset;
            $stmt->execute($params);
        $anomalies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return array(
            'anomalies' => $anomalies,
            'pagination' => array(
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => ceil($total / $limit)
            )
        );
            
        } catch (Exception $e) {
            $this->logger->error("Get anomalies failed", array(
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 解决异常
     * @param int $anomalyId 异常ID
     * @param string $resolutionNote 解决说明
     * @param int $operatorId 操作员ID
     * @return bool
     */
    public function resolveAnomaly($anomalyId, $resolutionNote = null, $operatorId = null) {
        try {
            $sql = "UPDATE card_anomalies 
                    SET status = 'resolved', 
                        resolution_note = ?, 
                        resolved_at = NOW(),
                        resolved_by = ?
                    WHERE id = ?";
            
            $stmt = $this->database->prepare($sql);
            $result = $stmt->execute(array($resolutionNote, $operatorId, $anomalyId));
            
            if ($result) {
                $this->logger->info("Anomaly resolved", array(
                    'anomaly_id' => $anomalyId,
                    'operator_id' => $operatorId
                ));
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("Resolve anomaly failed", [
                'anomaly_id' => $anomalyId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
    
    /**
     * 过期卡密处理
     * @param int $batchSize 批处理大小
     * @return array
     */
    public function expireCards($days = 30) {
        return $this->detectExpiredCards($days);
    }
    
    /**
     * 导出卡密
     * @param array $filters 过滤条件
     * @param string $format 导出格式
     * @return string
     */
    public function exportCards($filters = array(), $format = 'csv') {
        try {
            // 构建WHERE条件
            $where = array("1=1");
            $params = array();
            
            if (!empty($filters['batch_id'])) {
                $where[] = "batch_id = ?";
                $params[] = $filters['batch_id'];
            }
            
            if (!empty($filters['status'])) {
                $where[] = "status = ?";
                $params[] = $filters['status'];
            }
            
            $whereClause = implode(" AND ", $where);
            
            // 查询数据
            $sql = "SELECT c.card_code, c.status, c.created_at, c.expires_at, 
                           p.name as product_name, cb.quantity as batch_quantity
                    FROM cards c
                    LEFT JOIN products p ON c.product_id = p.id
                    LEFT JOIN card_batches cb ON c.batch_id = cb.id
                    WHERE {$whereClause}
                    ORDER BY c.created_at DESC";
            
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($cards)) {
                return '';
            }
            
            // 根据格式导出
            switch ($format) {
                case 'csv':
                    return $this->exportToCSV($cards);
                case 'excel':
                    return $this->exportToExcel($cards);
                default:
                    return $this->exportToCSV($cards);
            }
            
        } catch (Exception $e) {
            $this->logger->error("Export cards failed", array(
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 批量操作
     * @param string $operation 操作类型
     * @param array $cardIds 卡密ID数组
     * @param array $params 参数
     * @return array
     */
    public function batchOperation($operation, $cardIds, $params = array()) {
        try {
            $results = array();
            $successCount = 0;
            $failureCount = 0;
            
            foreach ($cardIds as $cardId) {
                try {
                    switch ($operation) {
                        case 'activate':
                            $result = $this->updateCardStatus($cardId, 'active');
                            break;
                        case 'deactivate':
                            $result = $this->updateCardStatus($cardId, 'inactive');
                            break;
                        case 'expire':
                            $result = $this->updateCardStatus($cardId, 'expired');
                            break;
                        default:
                            throw new Exception("Unknown operation: {$operation}");
                    }
                    
                    if ($result) {
                        $results[$cardId] = array('success' => true);
                        $successCount++;
                    } else {
                        $results[$cardId] = array('success' => false, 'error' => 'Operation failed');
                        $failureCount++;
                    }
                    
                } catch (Exception $e) {
                    $results[$cardId] = array('success' => false, 'error' => $e->getMessage());
                    $failureCount++;
                }
            }
            
            $this->logger->info("Batch operation completed", array(
                'operation' => $operation,
                'total' => count($cardIds),
                'success' => $successCount,
                'failure' => $failureCount
            ));
            
            return array(
                'results' => $results,
                'summary' => array(
                    'total' => count($cardIds),
                    'success' => $successCount,
                    'failure' => $failureCount
                )
            );
            
        } catch (Exception $e) {
            $this->logger->error("Batch operation failed", array(
                'operation' => $operation,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取配置
     * @return array
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 更新配置
     * @param string $configKey 配置键
     * @param mixed $configValue 配置值
     * @return bool
     */
    public function updateConfig($configKey, $configValue) {
        try {
            // 这里应该更新数据库中的配置表
            // 暂时只更新内存中的配置
            $this->config[$configKey] = $configValue;
            
            $this->logger->info("Config updated", array(
                'key' => $configKey,
                'value' => $configValue
            ));
            
            return true;
            
        } catch (Exception $e) {
            $this->logger->error("Update config failed", array(
                'key' => $configKey,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 激活卡密（为订单使用）
     * @param int $cardId 卡密ID
     * @param int $orderId 订单ID
     * @return bool
     */
    public function activateCard($cardId, $orderId) {
        try {
            $sql = "UPDATE cards 
                    SET status = 'active', 
                        order_id = ?, 
                        activated_at = NOW() 
                    WHERE id = ? AND status = 'reserved'";
            
            $stmt = $this->database->prepare($sql);
            $result = $stmt->execute(array($orderId, $cardId));
            
            if ($result) {
                $this->logger->info("Card activated for order", array(
                    'card_id' => $cardId,
                    'order_id' => $orderId
                ));
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("Activate card failed", array(
                'card_id' => $cardId,
                'order_id' => $orderId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 释放卡密（取消订单时使用）
     * @param int $cardId 卡密ID
     * @return bool
     */
    public function releaseCard($cardId) {
        try {
            $sql = "UPDATE cards 
                    SET status = 'active', 
                        order_id = NULL, 
                        activated_at = NULL 
                    WHERE id = ? AND status = 'reserved'";
            
            $stmt = $this->database->prepare($sql);
            $result = $stmt->execute(array($cardId));
            
            if ($result) {
                $this->logger->info("Card released", array(
                    'card_id' => $cardId
                ));
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("Release card failed", array(
                'card_id' => $cardId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 退款卡密（退款订单时使用）
     * @param int $cardId 卡密ID
     * @return bool
     */
    public function refundCard($cardId) {
        try {
            $sql = "UPDATE cards 
                    SET status = 'refunded', 
                        refunded_at = NOW() 
                    WHERE id = ? AND status IN ('active', 'used')";
            
            $stmt = $this->database->prepare($sql);
            $result = $stmt->execute(array($cardId));
            
            if ($result) {
                $this->logger->info("Card refunded", array(
                    'card_id' => $cardId
                ));
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("Refund card failed", array(
                'card_id' => $cardId,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取可用的卡密批次
     * @param int $productId 产品ID
     * @param int $quantity 需要的数量
     * @return array
     */
    public function getAvailableBatches($productId, $status = 'completed') {
        $sql = "SELECT * FROM card_batches 
                WHERE product_id = ? AND status = ? 
                ORDER BY created_at DESC";
        
        return $this->database->fetchAll($sql, [$productId, $status]);
    }
    
    /**
     * 从批次中预留卡密
     * @param int $batchId 批次ID
     * @param int $quantity 数量
     * @param int $orderId 订单ID
     * @return array
     */
    public function reserveCardsFromBatch($batchId, $quantity) {
        try {
            // 开始事务
            $this->database->beginTransaction();
            
            // 锁定批次中的可用卡密
            $sql = "SELECT id FROM cards 
                    WHERE batch_id = ? AND status = 'active' 
                    ORDER BY id LIMIT ? FOR UPDATE";
            
            $cards = $this->database->fetchAll($sql, [$batchId, $quantity]);
            
            if (count($cards) < $quantity) {
                throw new Exception("批次中可用卡密不足");
            }
            
            // 更新卡密状态为预留
            $cardIds = array_column($cards, 'id');
            $placeholders = implode(',', array_fill(0, count($cardIds), '?'));
            
            $sql = "UPDATE cards SET status = 'reserved' 
                    WHERE id IN ({$placeholders})";
            
            $this->database->execute($sql, $cardIds);
            
            // 提交事务
            $this->database->commit();
            
            return $cardIds;
            
        } catch (Exception $e) {
            // 回滚事务
            $this->database->rollBack();
            throw $e;
        }
    }
    
    /**
     * 检测过期卡密
     */
    public function detectExpiredCards() {
        $sql = "UPDATE cards SET status = 'expired' 
                WHERE status = 'active' AND expires_at < NOW()";
        
        return $this->database->execute($sql);
    }
    
    /**
     * 检测卡密异常
     */
    public function detectAnomalies($days = 30) {
        $cutoffDate = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        // 检测批量使用异常
        $sql = "SELECT card_code, COUNT(*) as usage_count 
                FROM card_usage_logs 
                WHERE created_at > ? AND result = 'success'
                GROUP BY card_code 
                HAVING usage_count > 5";
        
        $anomalies = $this->database->fetchAll($sql, [$cutoffDate]);
        
        // 记录异常
        foreach ($anomalies as $anomaly) {
            $this->logCardAnomaly(null, null, 'abnormal_usage', 
                "卡密 {$anomaly['card_code']} 在短期内被使用 {$anomaly['usage_count']} 次", 
                'high');
        }
        
        return count($anomalies);
    }
    
    /**
     * 记录卡密异常
     */
    private function logCardAnomaly($cardId, $batchId, $type, $description, $severity = 'medium') {
        $sql = "INSERT INTO card_anomalies (
                card_id, batch_id, anomaly_type, severity, 
                description, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, NOW(), NOW())";
        
        $this->database->execute($sql, [$cardId, $batchId, $type, $severity, $description]);
    }
    
    /**
     * 获取动态卡密API数据
     */
    private function getDynamicCardFromApi($apiConfig) {
        $config = json_decode($apiConfig, true);
        $url = $config['url'] ?? '';
        $method = $config['method'] ?? 'GET';
        $headers = $config['headers'] ?? [];
        $params = $config['params'] ?? [];
        
        if (!$url) {
            throw new Exception("API URL未配置");
        }
        
        // 这里应该实现HTTP请求，简化版本
        // 实际实现时需要使用curl或Guzzle等库
        // 模拟返回
        return [
            'card_code' => 'DYN-' . date('YmdHis') . '-' . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT),
            'card_secret' => strtoupper(bin2hex(random_bytes(8))),
            'api_response' => '模拟API返回数据'
        ];
    }
    
    /**
     * 获取卡密类型
     */
    private function getCardTypeByBatch($batchId) {
        $batch = $this->database->fetchOne(
            "SELECT card_type FROM card_batches WHERE id = ?", 
            [$batchId]
        );
        
        return $batch ? $batch['card_type'] : 'fixed';
    }
    
    /**
     * 应用时段卡密规则
     */
    private function applyTimeBasedCardRules($cardId, $batchId) {
        $batch = $this->database->fetchOne(
            "SELECT time_config FROM card_batches WHERE id = ?", 
            [$batchId]
        );
        
        if ($batch && $batch['time_config']) {
            $config = json_decode($batch['time_config'], true);
            $activationDays = $config['activation_days'] ?? 30;
            
            // 更新过期时间为激活后的N天
            $newExpiryDate = date('Y-m-d H:i:s', strtotime("+{$activationDays} days"));
            
            $this->database->execute(
                "UPDATE cards SET expires_at = ? WHERE id = ?",
                [$newExpiryDate, $cardId]
            );
        }
    }
    
    /**
     * 生成卡密转赠码
     */
    public function generateTransferCode($cardId) {
        $transferCode = 'TRF-' . bin2hex(random_bytes(8));
        
        $sql = "UPDATE cards SET transfer_code = ? WHERE id = ?";
        $this->database->execute($sql, [$transferCode, $cardId]);
        
        // 记录转赠
        $sql = "INSERT INTO card_transfers (
                card_id, transfer_code, expire_time, created_at
                ) VALUES (?, ?, ?, NOW())";
        
        $expireTime = date('Y-m-d H:i:s', strtotime("+7 days")); // 7天后过期
        $this->database->execute($sql, [$cardId, $transferCode, $expireTime]);
        
        return $transferCode;
    }
    
    /**
     * 接收转赠卡密
     */
    public function receiveTransferCard($transferCode, $userId) {
        // 验证转赠码
        $transfer = $this->database->fetchOne(
            "SELECT * FROM card_transfers 
             WHERE transfer_code = ? AND status = 'pending' AND expire_time > NOW()",
            [$transferCode]
        );
        
        if (!$transfer) {
            throw new Exception("转赠码无效或已过期");
        }
        
        // 开始事务
        $this->database->beginTransaction();
        
        try {
            // 更新卡密拥有者
            $sql = "UPDATE cards SET original_owner_id = original_owner_id, 
                    transfer_history = CONCAT(IFNULL(transfer_history, '[]'), ?) 
                    WHERE id = ?";
            
            $transferLog = json_encode([
                'from_user_id' => null,
                'to_user_id' => $userId,
                'transfer_time' => date('Y-m-d H:i:s')
            ]);
            
            $this->database->execute($sql, [$transferLog, $transfer['card_id']]);
            
            // 更新转赠记录
            $sql = "UPDATE card_transfers SET 
                    to_user_id = ?, 
                    transfer_time = NOW(), 
                    status = 'completed' 
                    WHERE id = ?";
            
            $this->database->execute($sql, [$userId, $transfer['id']]);
            
            // 提交事务
            $this->database->commit();
            
            return true;
        } catch (Exception $e) {
            $this->database->rollBack();
            throw $e;
        }
    }
    
    /**
     * 卡密权限映射 - 激活卡密时应用权限
     */
    public function applyCardPermissions($cardId, $userId) {
        try {
            // 获取卡密信息
            $card = $this->database->fetchOne(
                "SELECT c.*, cb.card_type, cb.permission_config 
                 FROM cards c
                 LEFT JOIN card_batches cb ON c.batch_id = cb.id
                 WHERE c.id = ?",
                [$cardId]
            );
            
            if (!$card || empty($card['permission_config'])) {
                return true; // 无权限配置，跳过
            }
            
            // 解析权限配置
            $permissions = json_decode($card['permission_config'], true);
            $appliedPermissions = [];
            
            foreach ($permissions as $permission) {
                $permissionType = $permission['type'] ?? '';
                $targetSystem = $permission['target_system'] ?? '';
                $permissionData = $permission['data'] ?? [];
                
                // 根据权限类型处理
                switch ($targetSystem) {
                    case 'game_system':
                        // 游戏系统权限
                        $result = $this->applyGameSystemPermission($userId, $permissionData);
                        if ($result['success']) {
                            $appliedPermissions[] = [
                                'type' => $permissionType,
                                'system' => $targetSystem,
                                'status' => 'success'
                            ];
                        }
                        break;
                        
                    case 'course_system':
                        // 课程系统权限
                        $result = $this->applyCourseSystemPermission($userId, $permissionData);
                        if ($result['success']) {
                            $appliedPermissions[] = [
                                'type' => $permissionType,
                                'system' => $targetSystem,
                                'status' => 'success'
                            ];
                        }
                        break;
                        
                    case 'membership_system':
                        // 会员系统权限
                        $result = $this->applyMembershipPermission($userId, $permissionData);
                        if ($result['success']) {
                            $appliedPermissions[] = [
                                'type' => $permissionType,
                                'system' => $targetSystem,
                                'status' => 'success'
                            ];
                        }
                        break;
                }
            }
            
            // 记录权限应用日志
            $this->logPermissionApplication($cardId, $userId, $appliedPermissions);
            
            return true;
        } catch (Exception $e) {
            $this->logger->logError("应用卡密权限失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 应用游戏系统权限
     */
    private function applyGameSystemPermission($userId, $permissionData) {
        // 这里应该实现与游戏系统的集成，简化版本
        try {
            // 模拟API调用
            $gameId = $permissionData['game_id'] ?? '';
            $vipLevel = $permissionData['vip_level'] ?? 1;
            $duration = $permissionData['duration_days'] ?? 30;
            
            // 记录权限应用
            $this->database->execute(
                "INSERT INTO user_permissions (user_id, permission_type, target_system, 
                permission_data, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                [$userId, 'game_vip', 'game_system', json_encode($permissionData), 'active']
            );
            
            return ['success' => true, 'message' => '游戏VIP权限已应用'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 应用课程系统权限
     */
    private function applyCourseSystemPermission($userId, $permissionData) {
        // 这里应该实现与课程系统的集成
        try {
            $courseIds = $permissionData['course_ids'] ?? [];
            $duration = $permissionData['duration_days'] ?? 365;
            
            // 为每个课程添加权限
            foreach ($courseIds as $courseId) {
                $this->database->execute(
                    "INSERT INTO user_course_permissions (user_id, course_id, 
                    access_type, expires_at, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$userId, $courseId, 'full_access', date('Y-m-d H:i:s', strtotime("+{$duration} days")), 'active']
                );
            }
            
            return ['success' => true, 'message' => '课程访问权限已应用'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 应用会员系统权限
     */
    private function applyMembershipPermission($userId, $permissionData) {
        // 实现会员权限应用
        try {
            $membershipLevel = $permissionData['level'] ?? 'standard';
            $duration = $permissionData['duration_days'] ?? 30;
            
            $this->database->execute(
                "INSERT INTO user_membership (user_id, membership_level, 
                start_date, end_date, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                [$userId, $membershipLevel, date('Y-m-d H:i:s'), date('Y-m-d H:i:s', strtotime("+{$duration} days")), 'active']
            );
            
            return ['success' => true, 'message' => '会员权限已应用'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 记录权限应用日志
     */
    private function logPermissionApplication($cardId, $userId, $appliedPermissions) {
        $this->database->execute(
            "INSERT INTO card_permission_logs (card_id, user_id, 
            applied_permissions, created_at) VALUES (?, ?, ?, NOW())",
            [$cardId, $userId, json_encode($appliedPermissions)]
        );
    }
    
    /**
     * 获取卡密权限配置
     */
    public function getCardPermissionConfig($batchId) {
        $batch = $this->database->fetchOne(
            "SELECT permission_config FROM card_batches WHERE id = ?",
            [$batchId]
        );
        
        return $batch && !empty($batch['permission_config']) 
            ? json_decode($batch['permission_config'], true) 
            : [];
    }
    
    /**
     * 更新卡密批次的权限配置
     */
    public function updateBatchPermissionConfig($batchId, $permissionConfig) {
        return $this->database->execute(
            "UPDATE card_batches SET permission_config = ?, updated_at = NOW() WHERE id = ?",
            [json_encode($permissionConfig), $batchId]
        );
    }
    
    /**
     * 批量激活卡密并应用权限
     */
    public function batchActivateCards($cardIds, $userId) {
        $results = ['success' => 0, 'failed' => 0, 'errors' => []];
        
        foreach ($cardIds as $cardId) {
            try {
                // 激活卡密
                $activateResult = $this->redeemCardById($cardId, $userId, ['action' => 'batch_activate']);
                
                if ($activateResult['success']) {
                    // 应用权限
                    $this->applyCardPermissions($cardId, $userId);
                    $results['success']++;
                } else {
                    $results['failed']++;
                    $results['errors'][] = ['card_id' => $cardId, 'message' => '激活失败'];
                }
            } catch (Exception $e) {
                $results['failed']++;
                $results['errors'][] = ['card_id' => $cardId, 'message' => $e->getMessage()];
            }
        }
        
        return $results;
    }
    
    /**
     * 动态卡密 - 从第三方API实时获取卡密
     */
    public function generateDynamicCards($params) {
        try {
            $apiConfig = json_decode($params['api_config'], true);
            $quantity = $params['quantity'] ?? 1;
            $successCount = 0;
            $failedCount = 0;
            $cardsData = [];
            
            // 为每个卡密调用API
            for ($i = 0; $i < $quantity; $i++) {
                try {
                    // 调用第三方API
                    $apiResult = $this->callDynamicCardAPI($apiConfig);
                    
                    if ($apiResult['success']) {
                        $cardsData[] = [
                            'card_code' => $apiResult['card_code'],
                            'card_secret' => $apiResult['card_secret'],
                            'api_data' => json_encode($apiResult)
                        ];
                        $successCount++;
                    } else {
                        $failedCount++;
                        $this->logger->logError("动态卡密API调用失败: " . ($apiResult['message'] ?? '未知错误'));
                    }
                } catch (Exception $e) {
                    $failedCount++;
                    $this->logger->logError("动态卡密生成异常: " . $e->getMessage());
                }
            }
            
            // 批量插入数据库
            if (!empty($cardsData)) {
                $batchId = $this->createBatch([
                    'product_id' => $params['product_id'],
                    'quantity' => $quantity,
                    'card_type' => 'dynamic',
                    'api_config' => $params['api_config']
                ]);
                
                foreach ($cardsData as $cardData) {
                    $encryptedSecret = $this->securityManager->encrypt($cardData['card_secret']);
                    
                    $this->insertCard([
                        'batch_id' => $batchId,
                        'product_id' => $params['product_id'],
                        'card_code' => $cardData['card_code'],
                        'card_secret' => $encryptedSecret,
                        'status' => 'active',
                        'expires_at' => date('Y-m-d H:i:s', strtotime("+365 days")),
                        'api_data' => $cardData['api_data']
                    ]);
                }
                
                $this->updateBatchStatus($batchId, $successCount, $failedCount);
            }
            
            return [
                'success' => true,
                'generated_count' => $successCount,
                'failed_count' => $failedCount,
                'cards_data' => $cardsData
            ];
        } catch (Exception $e) {
            $this->logger->logError("批量生成动态卡密失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 调用动态卡密第三方API
     */
    private function callDynamicCardAPI($apiConfig) {
        try {
            $url = $apiConfig['url'] ?? '';
            $method = strtoupper($apiConfig['method'] ?? 'GET');
            $headers = $apiConfig['headers'] ?? [];
            $params = $apiConfig['params'] ?? [];
            $auth = $apiConfig['auth'] ?? [];
            
            // 使用curl调用API
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            // 设置请求方法
            if ($method === 'POST') {
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
            }
            
            // 设置headers
            $curlHeaders = ['Content-Type: application/json'];
            foreach ($headers as $key => $value) {
                $curlHeaders[] = "{$key}: {$value}";
            }
            
            // 认证设置
            if (!empty($auth['type'])) {
                if ($auth['type'] === 'basic') {
                    curl_setopt($ch, CURLOPT_USERPWD, "{$auth['username']}:{$auth['password']}");
                } elseif ($auth['type'] === 'bearer') {
                    $curlHeaders[] = "Authorization: Bearer {$auth['token']}";
                }
            }
            
            curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            curl_close($ch);
            
            // 处理响应
            $result = json_decode($response, true);
            
            if ($httpCode === 200 && $result) {
                // 根据API返回格式提取卡密信息
                $cardCodePath = $apiConfig['card_code_path'] ?? 'data.card_code';
                $cardSecretPath = $apiConfig['card_secret_path'] ?? 'data.card_secret';
                
                $cardCode = $this->getValueByPath($result, $cardCodePath);
                $cardSecret = $this->getValueByPath($result, $cardSecretPath);
                
                if ($cardCode && $cardSecret) {
                    return [
                        'success' => true,
                        'card_code' => $cardCode,
                        'card_secret' => $cardSecret,
                        'raw_response' => $result
                    ];
                }
            }
            
            return [
                'success' => false,
                'message' => "API调用失败，HTTP状态码: {$httpCode}",
                'response' => $result
            ];
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 根据路径获取嵌套数组值
     */
    private function getValueByPath($array, $path) {
        $keys = explode('.', $path);
        $value = $array;
        
        foreach ($keys as $key) {
            if (!is_array($value) || !array_key_exists($key, $value)) {
                return null;
            }
            $value = $value[$key];
        }
        
        return $value;
    }
    
    /**
     * 获取卡密详细信息（包含权限信息）
     */
    public function getCardDetails($cardId) {
        // 尝试从缓存获取
        $cacheKey = "card:info:detailed:" . $cardId;
        $cached = $this->cacheManager->get($cacheKey);
        if ($cached) {
            return json_decode($cached, true);
        }
        
        // 查询卡密基本信息
        $card = $this->database->fetchOne(
            "SELECT c.*, cb.batch_no, cb.card_type, cb.permission_config, 
            p.name as product_name 
            FROM cards c
            LEFT JOIN card_batches cb ON c.batch_id = cb.id
            LEFT JOIN products p ON c.product_id = p.id
            WHERE c.id = ?",
            [$cardId]
        );
        
        if (!$card) {
            return null;
        }
        
        // 添加权限信息
        $card['permissions'] = [];
        if (!empty($card['permission_config'])) {
            $card['permissions'] = json_decode($card['permission_config'], true);
        }
        
        // 添加使用记录
        $usageLogs = $this->database->fetchAll(
            "SELECT * FROM card_usage_logs WHERE card_id = ? ORDER BY created_at DESC LIMIT 10",
            [$cardId]
        );
        $card['usage_logs'] = $usageLogs;
        
        // 缓存结果
        $this->cacheManager->set($cacheKey, json_encode($card), 3600);
        
        return $card;
    }
}