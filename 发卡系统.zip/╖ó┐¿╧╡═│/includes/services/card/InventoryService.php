<?php
/**
 * 库存管理器
 * 处理产品库存、卡密库存等库存相关功能
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../core/Database.php';
require_once __DIR__ . '/../../core/Logger.php';

/**
 * 库存服务类
 * 提供库存管理、卡片分配、库存统计等功能
 */
class InventoryService extends BaseService {
    private static $instance = null;
    private $database;
    private $logger;
    
    /**
     * 单例模式实现
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        parent::__construct();
        $this->database = $this->getDatabase();
        $this->logger = $this->getLogger();
    }
    
    /**
     * 获取产品库存信息
     */
    public function getProductStock($productId) {
        try {
            $product = $this->database->fetch(
                "SELECT id, name, stock FROM products WHERE id = ?",
                array($productId)
            );
            
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            // 获取可用卡密数量
            $availableCards = $this->database->fetchColumn(
                "SELECT COUNT(*) FROM cards WHERE product_id = ? AND status = 'available'",
                array($productId)
            );
            
            // 获取已售出卡密数量
            $soldCards = $this->database->fetchColumn(
                "SELECT COUNT(*) FROM cards WHERE product_id = ? AND status = 'sold'",
                array($productId)
            );
            
            return array(
                'product_id' => $productId,
                'product_name' => $product['name'],
                'stock' => $product['stock'],
                'available_cards' => $availableCards,
                'sold_cards' => $soldCards,
                'total_cards' => $availableCards + $soldCards,
                'stock_status' => $this->getStockStatus($product['stock'], $availableCards)
            );
            
        } catch (Exception $e) {
            $this->logger->error("获取产品库存失败", array(
                'product_id' => $productId,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 更新产品库存
     */
    public function updateProductStock($productId, $stock, $reason = '') {
        try {
            $product = $this->database->fetch(
                "SELECT id, name, stock FROM products WHERE id = ?",
                array($productId)
            );
            
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            $oldStock = $product['stock'];
            
            // 更新库存
            $result = $this->database->update(
                'products',
                array('stock' => $stock),
                'id = ?',
                array($productId)
            );
            
            if (!$result) {
                throw new Exception('库存更新失败');
            }
            
            // 记录库存变更日志
            $this->recordStockChange($productId, $oldStock, $stock, $reason);
            
            $this->logger->info("产品库存更新成功", array(
                'product_id' => $productId,
                'product_name' => $product['name'],
                'old_stock' => $oldStock,
                'new_stock' => $stock,
                'reason' => $reason
            ));
            
            return array('success' => true, 'old_stock' => $oldStock, 'new_stock' => $stock);
            
        } catch (Exception $e) {
            $this->logger->error("更新产品库存失败", array(
                'product_id' => $productId,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 增加库存
     */
    public function increaseStock($productId, $quantity, $reason = '') {
        try {
            $product = $this->database->fetch(
                "SELECT id, name, stock FROM products WHERE id = ?",
                array($productId)
            );
            
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            $oldStock = $product['stock'];
            $newStock = $oldStock + $quantity;
            
            // 更新库存
            $result = $this->database->update(
                'products',
                array('stock' => $newStock),
                'id = ?',
                array($productId)
            );
            
            if (!$result) {
                throw new Exception('库存增加失败');
            }
            
            // 记录库存变更日志
            $this->recordStockChange($productId, $oldStock, $newStock, $reason ?: "手动增加库存 {$quantity}");
            
            $this->logger->info("产品库存增加成功", array(
                'product_id' => $productId,
                'product_name' => $product['name'],
                'old_stock' => $oldStock,
                'new_stock' => $newStock,
                'quantity' => $quantity
            ));
            
            return array('success' => true, 'old_stock' => $oldStock, 'new_stock' => $newStock);
            
        } catch (Exception $e) {
            $this->logger->error("减少产品库存失败", array(
                'product_id' => $productId,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 减少库存
     */
    public function decreaseStock($productId, $quantity, $reason = '') {
        try {
            $product = $this->database->fetch(
                "SELECT id, name, stock FROM products WHERE id = ?",
                array($productId)
            );
            
            if (!$product) {
                throw new Exception('产品不存在');
            }
            
            $oldStock = $product['stock'];
            
            if ($oldStock < $quantity) {
                throw new Exception('库存不足，无法减少');
            }
            
            $newStock = $oldStock - $quantity;
            
            // 更新库存
            $result = $this->database->update(
                'products',
                array('stock' => $newStock),
                'id = ?',
                array($productId)
            );
            
            if (!$result) {
                throw new Exception('库存减少失败');
            }
            
            // 记录库存变更日志
            $this->recordStockChange($productId, $oldStock, $newStock, $reason ?: "手动减少库存 {$quantity}");
            
            $this->logger->info("产品库存减少成功", array(
                'product_id' => $productId,
                'product_name' => $product['name'],
                'old_stock' => $oldStock,
                'new_stock' => $newStock,
                'quantity' => $quantity
            ));
            
            return array('success' => true, 'old_stock' => $oldStock, 'new_stock' => $newStock);
            
        } catch (Exception $e) {
            $this->logger->error("获取产品库存失败", array(
                'product_id' => $productId,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 批量更新库存
     */
    public function batchUpdateStock($updates) {
        $successCount = 0;
        $failedCount = 0;
        $results = array();
        
        $this->database->beginTransaction();
        
        try {
            foreach ($updates as $update) {
                $productId = $update['product_id'];
                $stock = $update['stock'];
                $reason = isset($update['reason']) ? $update['reason'] : '';
                
                $result = $this->updateProductStock($productId, $stock, $reason);
                
                if ($result['success']) {
                    $successCount++;
                    $results[] = array(
                        'product_id' => $productId,
                        'success' => true,
                        'old_stock' => $result['old_stock'],
                        'new_stock' => $result['new_stock']
                    );
                } else {
                    $failedCount++;
                    $results[] = array(
                        'product_id' => $productId,
                        'success' => false,
                        'message' => $result['message']
                    );
                }
            }
            
            $this->database->commit();
            
            $this->logger->logInfo("批量库存更新完成", array(
                'total_updates' => count($updates),
                'success_count' => $successCount,
                'failed_count' => $failedCount
            ));
            
            return array(
                'success' => true,
                'success_count' => $successCount,
                'failed_count' => $failedCount,
                'results' => $results
            );
            
        } catch (Exception $e) {
            $this->database->rollback();
            
            $this->logger->error("批量库存更新失败", array(
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取库存预警列表
     */
    public function getStockAlerts($threshold = 10) {
        try {
            $sql = "
                SELECT 
                    p.id,
                    p.name,
                    p.stock,
                    COUNT(CASE WHEN c.status = 'available' THEN 1 END) as available_cards,
                    COUNT(CASE WHEN c.status = 'sold' THEN 1 END) as sold_cards
                FROM products p
                LEFT JOIN cards c ON p.id = c.product_id
                WHERE p.stock <= ? OR COUNT(CASE WHEN c.status = 'available' THEN 1 END) <= ?
                GROUP BY p.id, p.name, p.stock
                ORDER BY p.stock ASC
            ";
            
            $products = $this->database->fetchAll($sql, array($threshold, $threshold));
            
            $alerts = array();
            foreach ($products as $product) {
                $alerts[] = array(
                    'product_id' => $product['id'],
                    'product_name' => $product['name'],
                    'stock' => $product['stock'],
                    'available_cards' => $product['available_cards'],
                    'sold_cards' => $product['sold_cards'],
                    'alert_type' => $this->getAlertType($product['stock'], $product['available_cards']),
                    'alert_level' => $this->getAlertLevel($product['stock'], $product['available_cards'])
                );
            }
            
            return array('success' => true, 'alerts' => $alerts);
            
        } catch (Exception $e) {
            $this->logger->error("获取库存预警失败", array(
                'threshold' => $threshold,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取库存统计
     */
    public function getInventoryStats() {
        try {
            // 总产品数
            $totalProducts = $this->database->fetchColumn("SELECT COUNT(*) FROM products");
            
            // 总库存数
            $totalStock = $this->database->fetchColumn("SELECT SUM(stock) FROM products");
            
            // 低库存产品数
            $lowStockProducts = $this->database->fetchColumn("SELECT COUNT(*) FROM products WHERE stock <= 10");
            
            // 缺货产品数
            $outOfStockProducts = $this->database->fetchColumn("SELECT COUNT(*) FROM products WHERE stock = 0");
            
            // 总卡密数
            $totalCards = $this->database->fetchColumn("SELECT COUNT(*) FROM cards");
            
            // 可用卡密数
            $availableCards = $this->database->fetchColumn("SELECT COUNT(*) FROM cards WHERE status = 'available'");
            
            // 已售出卡密数
            $soldCards = $this->database->fetchColumn("SELECT COUNT(*) FROM cards WHERE status = 'sold'");
            
            return array(
                'success' => true,
                'stats' => array(
                    'total_products' => $totalProducts,
                    'total_stock' => $totalStock ?: 0,
                    'low_stock_products' => $lowStockProducts,
                    'out_of_stock_products' => $outOfStockProducts,
                    'total_cards' => $totalCards,
                    'available_cards' => $availableCards,
                    'sold_cards' => $soldCards,
                    'stock_utilization' => $totalStock > 0 ? round(($soldCards / $totalCards) * 100, 2) : 0
                )
            );
            
        } catch (Exception $e) {
            $this->logger->error("获取库存统计失败", array(
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取库存变更历史
     */
    public function getStockHistory($filters = array()) {
        try {
            $sql = "
                SELECT 
                    h.*,
                    p.name as product_name
                FROM stock_history h
                LEFT JOIN products p ON h.product_id = p.id
                WHERE 1=1
            ";
            $params = array();
            
            // 添加过滤条件
            if (!empty($filters['product_id'])) {
                $sql .= " AND h.product_id = ?";
                $params[] = $filters['product_id'];
            }
            
            if (!empty($filters['date_from'])) {
                $sql .= " AND h.created_at >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND h.created_at <= ?";
                $params[] = $filters['date_to'];
            }
            
            $sql .= " ORDER BY h.created_at DESC";
            
            // 添加分页
            if (!empty($filters['limit'])) {
                $sql .= " LIMIT ?";
                $params[] = $filters['limit'];
            }
            
            $history = $this->database->fetchAll($sql, $params);
            
            return array('success' => true, 'history' => $history);
            
        } catch (Exception $e) {
            $this->logger->error("获取库存变更历史失败", array(
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 自动库存同步
     */
    public function syncStockFromCards() {
        try {
            // 获取所有产品
            $products = $this->database->fetchAll("SELECT id, name, stock FROM products");
            
            $updatedCount = 0;
            foreach ($products as $product) {
                // 计算实际可用卡密数量
                $actualStock = $this->database->fetchColumn(
                    "SELECT COUNT(*) FROM cards WHERE product_id = ? AND status = 'available'",
                    array($product['id'])
                );
                
                // 如果库存不一致，更新产品库存
                if ($product['stock'] != $actualStock) {
                    $this->database->update(
                        'products',
                        array('stock' => $actualStock),
                        'id = ?',
                        array($product['id'])
                    );
                    
                    $this->recordStockChange(
                        $product['id'],
                        $product['stock'],
                        $actualStock,
                        '自动同步库存'
                    );
                    
                    $updatedCount++;
                }
            }
            
            $this->logger->logInfo("库存同步完成", array(
                'total_products' => count($products),
                'updated_count' => $updatedCount
            ));
            
            return array(
                'success' => true,
                'total_products' => count($products),
                'updated_count' => $updatedCount
            );
            
        } catch (Exception $e) {
            $this->logger->error("库存同步失败", array(
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 记录库存变更
     */
    private function recordStockChange($productId, $oldStock, $newStock, $reason) {
        $this->database->insert('stock_history', array(
            'product_id' => $productId,
            'old_stock' => $oldStock,
            'new_stock' => $newStock,
            'change_amount' => $newStock - $oldStock,
            'reason' => $reason,
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
    
    /**
     * 获取库存状态
     */
    private function getStockStatus($stock, $availableCards) {
        if ($stock == 0) {
            return 'out_of_stock';
        } elseif ($stock <= 10) {
            return 'low_stock';
        } elseif ($availableCards < $stock) {
            return 'insufficient_cards';
        } else {
            return 'normal';
        }
    }
    
    /**
     * 获取预警类型
     */
    private function getAlertType($stock, $availableCards) {
        if ($stock == 0) {
            return 'out_of_stock';
        } elseif ($availableCards == 0) {
            return 'no_cards';
        } elseif ($stock <= 10 || $availableCards <= 10) {
            return 'low_stock';
        } else {
            return 'normal';
        }
    }
    
    /**
     * 获取预警级别
     */
    private function getAlertLevel($stock, $availableCards) {
        if ($stock == 0 || $availableCards == 0) {
            return 'critical';
        } elseif ($stock <= 5 || $availableCards <= 5) {
            return 'high';
        } elseif ($stock <= 10 || $availableCards <= 10) {
            return 'medium';
        } else {
            return 'low';
        }
    }
}