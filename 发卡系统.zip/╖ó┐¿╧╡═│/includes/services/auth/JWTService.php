<?php
/**
 * JWT令牌服务类
 * 负责生成、验证和管理JWT令牌
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../core/Database.php';

class JWTService extends BaseService {
    
    private $secretKey;
    private $algorithm;
    private $expirationTime;
    private $refreshExpirationTime;
    private $issuer;
    private $audience;
    
    public function __construct($config = array()) {
        $this->secretKey = isset($config['secret_key']) ? $config['secret_key'] : (isset($_ENV['JWT_SECRET']) ? $_ENV['JWT_SECRET'] : 'default_secret_key_change_this_in_production');
        $this->algorithm = isset($config['algorithm']) ? $config['algorithm'] : 'HS256';
        $this->expirationTime = isset($config['expiration_time']) ? $config['expiration_time'] : 3600; // 1小时
        $this->refreshExpirationTime = isset($config['refresh_expiration_time']) ? $config['refresh_expiration_time'] : 604800; // 7天
        $this->issuer = isset($config['issuer']) ? $config['issuer'] : (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'card-system');
        $this->audience = isset($config['audience']) ? $config['audience'] : 'card-system-users';
    }
    
    /**
     * 生成JWT令牌
     */
    public function generateToken($userId, $userData = array(), $type = 'access') {
        $header = $this->encodeBase64Url(json_encode(array(
            'typ' => 'JWT',
            'alg' => $this->algorithm
        )));
        
        $now = time();
        $expiration = $type === 'refresh' ? $this->refreshExpirationTime : $this->expirationTime;
        
        $payload = $this->encodeBase64Url(json_encode(array(
            'iss' => $this->issuer,
            'aud' => $this->audience,
            'iat' => $now,
            'exp' => $now + $expiration,
            'sub' => $userId,
            'type' => $type,
            'data' => $userData
        )));
        
        $signature = $this->encodeBase64Url($this->sign($header . '.' . $payload));
        
        return $header . '.' . $payload . '.' . $signature;
    }
    
    /**
     * 生成访问令牌和刷新令牌对
     */
    public function generateTokenPair($userId, $userData = array()) {
        return array(
            'access_token' => $this->generateToken($userId, $userData, 'access'),
            'refresh_token' => $this->generateToken($userId, array(), 'refresh'),
            'expires_in' => $this->expirationTime,
            'token_type' => 'Bearer'
        );
    }
    
    /**
     * 验证JWT令牌
     */
    public function verifyToken($token) {
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                throw new Exception('Invalid token format');
            }
            
            list($header, $payload, $signature) = $parts;
            
            // 验证签名
            $expectedSignature = $this->encodeBase64Url($this->sign($header . '.' . $payload));
            if (!hash_equals($expectedSignature, $signature)) {
                throw new Exception('Invalid signature');
            }
            
            // 解码载荷
            $payloadData = json_decode($this->decodeBase64Url($payload), true);
            if ($payloadData === null) {
                throw new Exception('Invalid payload');
            }
            
            // 验证过期时间
            if (isset($payloadData['exp']) && $payloadData['exp'] < time()) {
                throw new Exception('Token expired');
            }
            
            // 验证发行者和受众
            if (isset($payloadData['iss']) && $payloadData['iss'] !== $this->issuer) {
                throw new Exception('Invalid issuer');
            }
            
            if (isset($payloadData['aud']) && $payloadData['aud'] !== $this->audience) {
                throw new Exception('Invalid audience');
            }
            
            return $payloadData;
            
        } catch (Exception $e) {
            throw new Exception('Token verification failed: ' . $e->getMessage());
        }
    }
    
    /**
     * 刷新令牌
     */
    public function refreshToken($refreshToken) {
        try {
            $payload = $this->verifyToken($refreshToken);
            
            if ($payload['type'] !== 'refresh') {
                throw new Exception('Invalid refresh token');
            }
            
            // 从数据库获取用户信息
            $userId = $payload['sub'];
            $userData = $this->getUserData($userId);
            
            if (!$userData) {
                throw new Exception('User not found');
            }
            
            // 生成新的令牌对
            return $this->generateTokenPair($userId, $userData);
            
        } catch (Exception $e) {
            throw new Exception('Token refresh failed: ' . $e->getMessage());
        }
    }
    
    /**
     * 从请求头中提取令牌
     */
    public function extractTokenFromRequest() {
        $headers = getallheaders();
        $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');
        
        if (empty($authHeader)) {
            return null;
        }
        
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
    
    /**
     * 获取当前用户信息
     */
    public function getCurrentUser() {
        $token = $this->extractTokenFromRequest();
        
        if (!$token) {
            throw new Exception('No token provided');
        }
        
        $payload = $this->verifyToken($token);
        
        if ($payload['type'] !== 'access') {
            throw new Exception('Invalid access token');
        }
        
        return array(
            'user_id' => $payload['sub'],
            'data' => isset($payload['data']) ? $payload['data'] : array(),
            'exp' => $payload['exp']
        );
    }
    
    /**
     * 检查令牌是否即将过期
     */
    public function isTokenExpiringSoon($token, $bufferMinutes = 5) {
        try {
            $payload = $this->verifyToken($token);
            $expirationTime = $payload['exp'];
            $currentTime = time();
            $bufferSeconds = $bufferMinutes * 60;
            
            return ($expirationTime - $currentTime) <= $bufferSeconds;
        } catch (Exception $e) {
            return true; // 如果验证失败，认为需要刷新
        }
    }
    
    /**
     * 撤销令牌（将令牌加入黑名单）
     */
    public function revokeToken($token) {
        try {
            $payload = $this->verifyToken($token);
            $tokenId = $this->getTokenId($token);
            
            // 将令牌ID加入黑名单
            $this->addToBlacklist($tokenId, $payload['exp']);
            
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 检查令牌是否被撤销
     */
    public function isTokenRevoked($token) {
        try {
            $tokenId = $this->getTokenId($token);
            return $this->isInBlacklist($tokenId);
        } catch (Exception $e) {
            return true;
        }
    }
    
    /**
     * 生成令牌ID
     */
    private function getTokenId($token) {
        return hash('sha256', $token);
    }
    
    /**
     * 将令牌加入黑名单
     */
    private function addToBlacklist($tokenId, $expirationTime) {
        // 这里应该使用缓存或数据库存储黑名单
        // 简化实现，使用文件存储
        $blacklistFile = __DIR__ . '/../cache/token_blacklist.json';
        $blacklist = array();
        
        if (file_exists($blacklistFile)) {
            $blacklist = json_decode(file_get_contents($blacklistFile), true);
            if (!is_array($blacklist)) {
                $blacklist = array();
            }
        }
        
        $blacklist[$tokenId] = $expirationTime;
        
        // 清理过期的黑名单项
        $currentTime = time();
        $blacklist = array_filter($blacklist, function($exp) use ($currentTime) {
            return $exp > $currentTime;
        });
        
        file_put_contents($blacklistFile, json_encode($blacklist));
    }
    
    /**
     * 检查令牌是否在黑名单中
     */
    private function isInBlacklist($tokenId) {
        $blacklistFile = __DIR__ . '/../cache/token_blacklist.json';
        
        if (!file_exists($blacklistFile)) {
            return false;
        }
        
        $blacklist = json_decode(file_get_contents($blacklistFile), true);
        if (!is_array($blacklist)) {
            $blacklist = array();
        }
        
        if (!isset($blacklist[$tokenId])) {
            return false;
        }
        
        // 检查是否过期
        if ($blacklist[$tokenId] < time()) {
            unset($blacklist[$tokenId]);
            file_put_contents($blacklistFile, json_encode($blacklist));
            return false;
        }
        
        return true;
    }
    
    /**
     * 获取用户数据
     */
    private function getUserData($userId) {
        try {
            $db = Database::getInstance();
            $stmt = $db->prepare("SELECT id, username, email, role, status FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && $user['status'] === 'active') {
                unset($user['password']); // 确保不返回密码
                return $user;
            }
            
            return null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * 签名数据
     */
    private function sign($data) {
        $signature = '';
        switch ($this->algorithm) {
            case 'HS256':
                $signature = hash_hmac('sha256', $data, $this->secretKey, true);
                break;
            case 'HS384':
                $signature = hash_hmac('sha384', $data, $this->secretKey, true);
                break;
            case 'HS512':
                $signature = hash_hmac('sha512', $data, $this->secretKey, true);
                break;
            default:
                throw new Exception('Unsupported algorithm');
        }
        return $signature;
    }
    
    /**
     * Base64 URL编码
     */
    private function encodeBase64Url($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    /**
     * Base64 URL解码
     */
    private function decodeBase64Url($data) {
        $padding = strlen($data) % 4;
        if ($padding) {
            $data .= str_repeat('=', 4 - $padding);
        }
        return base64_decode(strtr($data, '-_', '+/'));
    }
    
    /**
     * 获取令牌信息
     */
    public function getTokenInfo($token) {
        try {
            $payload = $this->verifyToken($token);
            return array(
                'user_id' => $payload['sub'],
                'type' => $payload['type'],
                'issued_at' => $payload['iat'],
                'expires_at' => $payload['exp'],
                'data' => isset($payload['data']) ? $payload['data'] : array(),
                'is_revoked' => $this->isTokenRevoked($token),
                'is_expiring_soon' => $this->isTokenExpiringSoon($token)
            );
        } catch (Exception $e) {
            return array('error' => $e->getMessage());
        }
    }
    
    /**
     * 清理过期的黑名单项
     */
    public function cleanupBlacklist() {
        $blacklistFile = __DIR__ . '/../cache/token_blacklist.json';
        
        if (!file_exists($blacklistFile)) {
            return;
        }
        
        $blacklist = json_decode(file_get_contents($blacklistFile), true);
        if (!is_array($blacklist)) {
            $blacklist = array();
        }
        $currentTime = time();
        
        $blacklist = array_filter($blacklist, function($exp) use ($currentTime) {
            return $exp > $currentTime;
        });
        
        file_put_contents($blacklistFile, json_encode($blacklist));
    }
    
    /**
     * 获取黑名单统计
     */
    public function getBlacklistStats() {
        $blacklistFile = __DIR__ . '/../cache/token_blacklist.json';
        
        if (!file_exists($blacklistFile)) {
            return array('total' => 0, 'expired' => 0, 'active' => 0);
        }
        
        $blacklist = json_decode(file_get_contents($blacklistFile), true);
        if (!is_array($blacklist)) {
            $blacklist = array();
        }
        $currentTime = time();
        
        $active = 0;
        $expired = 0;
        
        foreach ($blacklist as $tokenId => $expirationTime) {
            if ($expirationTime > $currentTime) {
                $active++;
            } else {
                $expired++;
            }
        }
        
        return array(
            'total' => count($blacklist),
            'active' => $active,
            'expired' => $expired
        );
    }
}