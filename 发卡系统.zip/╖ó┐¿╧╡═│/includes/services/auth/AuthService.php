<?php
/**
 * 认证服务类
 * 负责用户认证、权限管理等核心安全功能
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../SecurityUtils.php';
require_once __DIR__ . '/../../core/Database.php';

class AuthService extends BaseService {
    private static $instance = null;
    private $user = null;
    
    // 角色权限常量
    const ROLE_ADMIN = 'admin';
    const ROLE_AGENT = 'agent';
    const ROLE_USER = 'user';
    const ROLE_MANAGER = 'manager';       // 业务管理员
    const ROLE_OPERATOR = 'operator';      // 操作员
    const ROLE_VIEWER = 'viewer';          // 只读用户
    
    // 权限常量
    const PERMISSION_CARD_CREATE = 'card_create';      // 创建卡片
    const PERMISSION_CARD_READ = 'card_read';          // 查看卡片
    const PERMISSION_CARD_UPDATE = 'card_update';      // 更新卡片
    const PERMISSION_CARD_DELETE = 'card_delete';      // 删除卡片
    const PERMISSION_USER_MANAGE = 'user_manage';      // 用户管理
    const PERMISSION_SYSTEM_CONFIG = 'system_config';  // 系统配置
    const PERMISSION_LOG_VIEW = 'log_view';            // 查看日志
    const PERMISSION_EXPORT_DATA = 'export_data';      // 导出数据
    const PERMISSION_IDENTITY_VERIFY = 'identity_verify'; // 身份核验
    const PERMISSION_DASHBOARD_VIEW = 'dashboard_view';   // 查看仪表板
    
    private function __construct() {
        parent::__construct();
        $this->initSession();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化会话
     */
    private function initSession()
    {
        if (session_status() === PHP_SESSION_NONE) {
            // 安全的会话配置
            ini_set('session.cookie_httponly', 1);
            ini_set('session.cookie_secure', 1);
            ini_set('session.use_strict_mode', 1);
            ini_set('session.cookie_samesite', 'Strict');
            
            session_start();
        }
    }
    
    /**
     * 用户登录
     * @param string $username 用户名
     * @param string $password 密码
     * @param string $ip 客户端IP
     * @return array 登录结果
     */
    public function login($username, $password, $ip = '')
    {
        try {
            // 输入验证
            $username = SecurityUtils::validateInput($username, 'general');
            
            // 检查登录失败次数
            if ($this->isLoginBlocked($username, $ip)) {
                $this->logger->logSecurity('WARNING', '登录被阻止', array(
                'username' => $username,
                'ip' => $ip
            ));
                
                return array(
                    'success' => false,
                    'message' => '登录失败次数过多，请稍后再试'
                );
            }
            
            // 查询用户
            $sql = "SELECT id, username, password, role, status, failed_login_count, last_login_time 
                    FROM users WHERE username = :username";
            $user = $this->database->queryOne($sql, array('username' => $username));
            
            if (!$user) {
                $this->recordLoginFailure($username, $ip, '用户不存在');
                return array(
                    'success' => false,
                    'message' => '用户名或密码错误'
                );
            }
            
            // 检查用户状态
            if ($user['status'] !== 'active') {
                $this->logger->logSecurity('WARNING', '尝试登录已禁用账户', array(
                'username' => $username,
                'ip' => $ip,
                'status' => $user['status']
            ));
                
                return array(
                    'success' => false,
                    'message' => '账户已被禁用'
                );
            }
            
            // 验证密码
            if (!SecurityUtils::verifyPassword($password, $user['password'])) {
                $this->recordLoginFailure($username, $ip, '密码错误', $user['id']);
                return array(
                    'success' => false,
                    'message' => '用户名或密码错误'
                );
            }
            
            // 检查是否需要双因素认证
            if ($this->requireTwoFactor('login')) {
                // 记录登录成功前的信息
                $this->recordLoginSuccess($user['id'], $ip);
                
                // 保存临时用户信息到会话，用于双因素验证后恢复
                $_SESSION['temp_user_id'] = $user['id'];
                $_SESSION['temp_username'] = $user['username'];
                $_SESSION['temp_role'] = $user['role'];
                
                // 生成并发送双因素验证码
                $result = $this->sendTwoFactorCode($user['id']);
                
                if (!$result['success']) {
                    $this->logger->logSecurity('ERROR', '双因素验证码发送失败', array(
                        'user_id' => $user['id'],
                        'username' => $username,
                        'error' => $result['error']
                    ));
                    
                    // 清理临时会话数据
                    $this->clearTempUserData();
                    
                    return array(
                        'success' => false,
                        'message' => '验证码发送失败，请稍后重试'
                    );
                }
                
                // 返回需要双因素验证的结果
                return array(
                    'success' => true,
                    'requires_two_factor' => true,
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'message' => '请输入双因素验证码'
                );
            }
            
            // 登录成功，直接创建会话
            $this->recordLoginSuccess($user['id'], $ip);
            $this->createUserSession($user);
            
            $this->logger->logSecurity('INFO', '用户登录成功', array(
                'user_id' => $user['id'],
                'username' => $username,
                'ip' => $ip
            ));
            
            return array(
                'success' => true,
                'message' => '登录成功',
                'user' => array(
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'role' => $user['role']
                )
            );
            
        } catch (Exception $e) {
            $this->logger->logSecurity('ERROR', '登录过程异常', array(
                'username' => $username,
                'ip' => $ip,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => '登录失败，请稍后重试'
            );
        }
    }
    
    /**
     * 完成双因素验证后的登录处理
     * @param int $userId 用户ID
     * @param string $code 验证码
     * @return array 验证结果
     */
    public function completeTwoFactorLogin($userId, $code)
    {
        try {
            // 检查临时会话数据
            if (!isset($_SESSION['temp_user_id']) || $_SESSION['temp_user_id'] != $userId) {
                return array(
                    'success' => false,
                    'message' => '登录状态已过期，请重新登录'
                );
            }
            
            // 验证双因素验证码
            if (!$this->verifyTwoFactor($userId, $code)) {
                return array(
                    'success' => false,
                    'message' => '验证码错误或已过期'
                );
            }
            
            // 创建完整用户会话
            $user = array(
                'id' => $_SESSION['temp_user_id'],
                'username' => $_SESSION['temp_username'],
                'role' => $_SESSION['temp_role']
            );
            
            $this->createUserSession($user);
            $this->clearTempUserData();
            
            $this->logger->logSecurity('INFO', '双因素验证成功，登录完成', array(
                'user_id' => $userId,
                'username' => $user['username']
            ));
            
            return array(
                'success' => true,
                'message' => '双因素验证成功，登录完成'
            );
            
        } catch (Exception $e) {
            $this->logger->logSecurity('ERROR', '双因素验证异常', array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
            
            return array(
                'success' => false,
                'message' => '验证失败，请稍后重试'
            );
        }
    }
    
    /**
     * 清理临时用户数据
     */
    private function clearTempUserData()
    {
        unset($_SESSION['temp_user_id']);
        unset($_SESSION['temp_username']);
        unset($_SESSION['temp_role']);
    }
    
    /**
     * 用户登出
     */
    public function logout()
    {
        if ($this->isLoggedIn()) {
            $this->logger->logSecurity('INFO', '用户登出', array(
                'user_id' => $_SESSION['user_id'],
                'username' => $_SESSION['username']
            ));
        }
        
        // 销毁会话
        session_destroy();
        
        // 清除会话cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        $this->user = null;
    }
    
    /**
     * 检查用户是否已登录
     * @return bool
     */
    public function isLoggedIn()
    {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
    
    /**
     * 获取当前用户信息
     * @return array|null
     */
    public function getCurrentUser()
    {
        if ($this->user === null && $this->isLoggedIn()) {
            $sql = "SELECT id, username, role, status, created_at, last_login_time 
                    FROM users WHERE id = :user_id";
            $this->user = $this->database->queryOne($sql, array('user_id' => $_SESSION['user_id']));
        }
        
        return $this->user;
    }
    
    /**
     * 检查用户权限
     * @param string $permission 权限标识
     * @return bool
     */
    public function hasPermission($permission) 
    {
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        $user = $this->getCurrentUser();
        if (!$user) {
            return false;
        }
        
        // 管理员拥有所有权限
        if ($user['role'] === self::ROLE_ADMIN) {
            return true;
        }
        
        // 获取角色权限映射
        $rolePermissions = $this->getRolePermissions();
        
        return isset($rolePermissions[$user['role']]) && 
               in_array($permission, $rolePermissions[$user['role']]);
    }
    
    /**
     * 获取角色权限映射
     * @return array
     */
    private function getRolePermissions() 
    {
        return array(
            self::ROLE_ADMIN => array(
                self::PERMISSION_CARD_CREATE,
                self::PERMISSION_CARD_READ,
                self::PERMISSION_CARD_UPDATE,
                self::PERMISSION_CARD_DELETE,
                self::PERMISSION_USER_MANAGE,
                self::PERMISSION_SYSTEM_CONFIG,
                self::PERMISSION_LOG_VIEW,
                self::PERMISSION_EXPORT_DATA
            ),
            self::ROLE_MANAGER => array(
                self::PERMISSION_CARD_CREATE,
                self::PERMISSION_CARD_READ,
                self::PERMISSION_CARD_UPDATE,
                self::PERMISSION_LOG_VIEW,
                self::PERMISSION_EXPORT_DATA
            ),
            self::ROLE_OPERATOR => array(
                self::PERMISSION_CARD_CREATE,
                self::PERMISSION_CARD_READ,
                self::PERMISSION_CARD_UPDATE
            ),
            self::ROLE_VIEWER => array(
                self::PERMISSION_CARD_READ
            )
        );
    }
    
    /**
     * 创建用户会话
     * @param array $user 用户信息
     */
    private function createUserSession($user)
    {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['login_time'] = time();
        $_SESSION['csrf_token'] = SecurityUtils::generateCSRFToken();
        
        // 设置会话过期时间（30分钟）
        $_SESSION['expire_time'] = time() + 1800;
    }
    
    /**
     * 检查会话是否过期
     * @return bool
     */
    public function isSessionExpired()
    {
        return isset($_SESSION['expire_time']) && time() > $_SESSION['expire_time'];
    }
    
    /**
     * 刷新会话过期时间
     */
    public function refreshSession()
    {
        if ($this->isLoggedIn()) {
            $_SESSION['expire_time'] = time() + 1800;
        }
    }
    
    /**
     * 记录登录成功
     * @param int $userId 用户ID
     * @param string $ip IP地址
     */
    private function recordLoginSuccess($userId, $ip)
    {
        $sql = "UPDATE users SET 
                last_login_time = NOW(),
                last_login_ip = :ip,
                failed_login_count = 0
                WHERE id = :user_id";
        
        $this->database->update($sql, array(
            'user_id' => $userId,
            'ip' => $ip
        ));
        
        // 记录登录日志
        $this->recordUserLog($userId, 'login', '用户登录成功', $ip);
    }
    
    /**
     * 记录登录失败
     * @param string $username 用户名
     * @param string $ip IP地址
     * @param string $reason 失败原因
     * @param int|null $userId 用户ID（如果存在）
     */
    private function recordLoginFailure($username, $ip, $reason, $userId = null)
    {
        if ($userId) {
            // 更新失败次数
            $sql = "UPDATE users SET 
                    failed_login_count = failed_login_count + 1,
                    last_failed_login_time = NOW(),
                    last_failed_login_ip = :ip
                    WHERE id = :user_id";
            
            $this->database->update($sql, array(
                'user_id' => $userId,
                'ip' => $ip
            ));
        }
        
        $this->logger->logSecurity('WARNING', '登录失败', array(
                'username' => $username,
                'ip' => $ip,
                'reason' => $reason,
                'user_id' => $userId
            ));
    }
    
    /**
     * 检查是否被阻止登录
     * @param string $username 用户名
     * @param string $ip IP地址
     * @return bool
     */
    private function isLoginBlocked($username, $ip)
    {
        // 检查用户失败次数
        $sql = "SELECT failed_login_count, last_failed_login_time 
                FROM users WHERE username = :username";
        $user = $this->database->queryOne($sql, array('username' => $username));
        
        if ($user && $user['failed_login_count'] >= 5) {
            $lastFailedTime = strtotime($user['last_failed_login_time']);
            if (time() - $lastFailedTime < 1800) { // 30分钟内
                return true;
            }
        }
        
        // 检查IP失败次数
        $sql = "SELECT COUNT(*) as count FROM login_logs 
                WHERE ip = :ip AND success = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        $result = $this->database->queryOne($sql, array('ip' => $ip));
        
        return $result && $result['count'] >= 10;
    }
    
    /**
     * 记录用户操作日志
     * @param int $userId 用户ID
     * @param string $action 操作类型
     * @param string $description 操作描述
     * @param string $ip IP地址
     * @param array $context 上下文信息
     */
    public function recordUserLog($userId, $action, $description, $ip = '', $context = array())
    {
        $sql = "INSERT INTO user_logs (user_id, action, description, ip, context, created_at) 
                VALUES (:user_id, :action, :description, :ip, :context, NOW())";
        
        $this->database->insert($sql, array(
            'user_id' => $userId,
            'action' => $action,
            'description' => $description,
            'ip' => $ip ?: SecurityUtils::getClientIP(),
            'context' => json_encode($context)
        ));
    }
    
    /**
     * 获取用户操作日志
     * @param int $userId 用户ID
     * @param int $limit 限制条数
     * @param array $filters 过滤条件
     * @return array
     */
    public function getUserLogs($userId, $limit = 50, $filters = array())
    {
        $sql = "SELECT * FROM user_logs WHERE user_id = :user_id";
        $params = array('user_id' => $userId);
        
        // 添加过滤条件
        if (!empty($filters['action'])) {
            $sql .= " AND action = :action";
            $params['action'] = $filters['action'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND created_at >= :date_from";
            $params['date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND created_at <= :date_to";
            $params['date_to'] = $filters['date_to'];
        }
        
        $sql .= " ORDER BY created_at DESC LIMIT :limit";
        $params['limit'] = $limit;
        
        return $this->database->queryAll($sql, $params);
    }
    
    /**
     * 修改密码
     * @param int $userId 用户ID
     * @param string $oldPassword 旧密码
     * @param string $newPassword 新密码
     * @return array
     */
    public function changePassword($userId, $oldPassword, $newPassword)
    {
        try {
            // 获取用户当前密码
            $sql = "SELECT password FROM users WHERE id = :user_id";
            $user = $this->database->queryOne($sql, array('user_id' => $userId));
            
            if (!$user) {
                return array('success' => false, 'message' => '用户不存在');
            }
            
            // 验证旧密码
            if (!SecurityUtils::verifyPassword($oldPassword, $user['password'])) {
                $this->logger->logSecurity('WARNING', '密码修改失败-旧密码错误', array(
                'user_id' => $userId
            ));
                
                return array('success' => false, 'message' => '旧密码错误');
            }
            
            // 更新密码
            $hashedPassword = SecurityUtils::hashPassword($newPassword);
            $sql = "UPDATE users SET password = :password, updated_at = NOW() WHERE id = :user_id";
            
            $this->database->update($sql, array(
                'user_id' => $userId,
                'password' => $hashedPassword
            ));
            
            $this->logger->logSecurity('INFO', '密码修改成功', array(
                'user_id' => $userId
            ));
            
            return array('success' => true, 'message' => '密码修改成功');
            
        } catch (Exception $e) {
            $this->logger->logSecurity('ERROR', '密码修改异常', array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
            
            return array('success' => false, 'message' => '密码修改失败');
        }
    }
    
    /**
     * 检查是否需要二次验证
     * @param string $operation 操作类型
     * @return bool
     */
    public function requireTwoFactor($operation)
    {
        // 确保TwoFactorAuthenticator类已加载
        if (!class_exists('TwoFactorAuthenticator')) {
            require_once __DIR__ . '/security/TwoFactorAuthenticator.php';
        }
        
        // 创建二次验证实例
        $twoFactor = new TwoFactorAuthenticator($this->database, new CacheManager(), new Logger());
        
        return $twoFactor->requiresVerification($operation);
    }
    
    /**
     * 验证二次验证码
     * @param int $userId 用户ID
     * @param string $code 验证码
     * @return bool
     */
    public function verifyTwoFactor($userId, $code)
    {
        // 确保TwoFactorAuthenticator类已加载
        if (!class_exists('TwoFactorAuthenticator')) {
            require_once 'includes/security/TwoFactorAuthenticator.php';
        }
        
        // 创建二次验证实例
        $twoFactor = new TwoFactorAuthenticator($this->database, new CacheManager(), new Logger());
        
        return $twoFactor->verifyCode($userId, $code);
    }
    
    /**
     * 发送二次验证码
     * @param int $userId 用户ID
     * @param string $method 验证方法
     * @return array 结果数组
     */
    public function sendTwoFactorCode($userId, $method = null)
    {
        // 确保TwoFactorAuthenticator类已加载
        if (!class_exists('TwoFactorAuthenticator')) {
            require_once 'includes/security/TwoFactorAuthenticator.php';
        }
        
        // 创建二次验证实例
        $twoFactor = new TwoFactorAuthenticator($this->database, new CacheManager(), new Logger());
        
        return $twoFactor->sendVerificationCode($userId, $method);
    }
    
    /**
     * 检查用户是否已通过二次验证
     * @param int $userId 用户ID
     * @return bool 验证状态
     */
    public function isTwoFactorVerified($userId)
    {
        // 确保TwoFactorAuthenticator类已加载
        if (!class_exists('TwoFactorAuthenticator')) {
            require_once 'includes/security/TwoFactorAuthenticator.php';
        }
        
        // 创建二次验证实例
        $twoFactor = new TwoFactorAuthenticator($this->database, new CacheManager(), new Logger());
        
        return $twoFactor->isVerified($userId);
    }
    
    /**
     * 要求管理员权限
     * 如果当前用户不是管理员，则终止脚本执行
     */
    public function requireAdmin()
    {
        $instance = self::getInstance();
        
        if (!$instance->isLoggedIn()) {
            header('HTTP/1.1 401 Unauthorized');
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('success' => false, 'message' => '请先登录'));
            exit;
        }
        
        $user = $instance->getCurrentUser();
        if (!$user || $user['role'] !== self::ROLE_ADMIN) {
            header('HTTP/1.1 403 Forbidden');
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('success' => false, 'message' => '需要管理员权限'));
            exit;
        }
    }
    
    /**
     * 通过API令牌获取用户
     * @param string $token API令牌
     * @return array|null 用户信息
     */
    public function getUserByApiToken($token)
    {
        $sql = "SELECT u.*, ut.expires_at 
                FROM users u 
                JOIN user_api_tokens ut ON u.id = ut.user_id 
                WHERE ut.token = ? AND ut.status = 'active' AND ut.expires_at > NOW()";
        
        $user = $this->database->queryOne($sql, array($token));
        
        if ($user) {
            // 更新最后访问时间
            $this->database->update('user_api_tokens', array(
                'last_access_at' => date('Y-m-d H:i:s')
            ), 'token = ?', array($token));
        }
        
        return $user;
    }
    
    /**
     * 验证用户凭据
     * @param string $username 用户名
     * @param string $password 密码
     * @return array|null 用户信息
     */
    public function authenticateUser($username, $password, $ip = '')
    {
        $sql = "SELECT id, username, password, role, status, email 
                FROM users 
                WHERE username = ? AND status = 'active'";
        
        $user = $this->database->queryOne($sql, array($username));
        
        if ($user && SecurityUtils::verifyPassword($password, $user['password'])) {
            // 移除密码字段
            unset($user['password']);
            return $user;
        }
        
        return null;
    }
    
    /**
     * 生成API令牌
     * @param int $userId 用户ID
     * @param int $expiresIn 过期时间（秒）
     * @return string API令牌
     */
    public function generateApiToken($userId, $expiresIn = 86400) 
    {
        $token = SecurityUtils::generateSecureToken(64);
        $expiresAt = date('Y-m-d H:i:s', time() + $expiresIn);
        
        // 撤销旧令牌
        $this->database->update('user_api_tokens', array(
            'status' => 'revoked',
            'revoked_at' => date('Y-m-d H:i:s')
        ), 'user_id = ? AND status = "active"', array($userId));
        
        // 插入新令牌
        $this->database->insert('user_api_tokens', array(
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s'),
            'last_access_at' => date('Y-m-d H:i:s'),
            'status' => 'active'
        ));
        
        return $token;
    }
    
    /**
     * 撤销API令牌
     * @param int $userId 用户ID
     * @return bool
     */
    public function revokeApiToken($userId) 
    {
        return $this->database->update('user_api_tokens', array(
            'status' => 'revoked',
            'revoked_at' => date('Y-m-d H:i:s')
        ), 'user_id = ? AND status = "active"', array($userId)) > 0;
    }
    

    
    /**
     * 获取用户权限
     * @param int $userId 用户ID
     * @return array 权限列表
     */
    public function getUserPermissions($userId) 
    {
        // 获取用户角色
        $sql = "SELECT role FROM users WHERE id = ?";
        $user = $this->database->queryOne($sql, array($userId));
        
        if (!$user) {
            return array();
        }
        
        // 根据角色返回权限
        $rolePermissions = array(
            self::ROLE_ADMIN => array(
                self::PERMISSION_CARD_CREATE,
                self::PERMISSION_CARD_READ,
                self::PERMISSION_CARD_UPDATE,
                self::PERMISSION_CARD_DELETE,
                self::PERMISSION_USER_MANAGE,
                self::PERMISSION_SYSTEM_CONFIG,
                self::PERMISSION_LOG_VIEW,
                self::PERMISSION_EXPORT_DATA,
                self::PERMISSION_IDENTITY_VERIFY,
                self::PERMISSION_DASHBOARD_VIEW
            ),
            self::ROLE_MANAGER => array(
                self::PERMISSION_CARD_CREATE,
                self::PERMISSION_CARD_READ,
                self::PERMISSION_CARD_UPDATE,
                self::PERMISSION_LOG_VIEW,
                self::PERMISSION_EXPORT_DATA,
                self::PERMISSION_IDENTITY_VERIFY,
                self::PERMISSION_DASHBOARD_VIEW
            ),
            self::ROLE_OPERATOR => array(
                self::PERMISSION_CARD_READ,
                self::PERMISSION_CARD_UPDATE,
                self::PERMISSION_DASHBOARD_VIEW
            ),
            self::ROLE_VIEWER => array(
                self::PERMISSION_CARD_READ,
                self::PERMISSION_DASHBOARD_VIEW
            )
        );
        
        return $rolePermissions[$user['role']];
    }
    
    /**
     * 验证API令牌
     * @param string $token API令牌
     * @return bool 是否有效
     */
    public function validateToken($token) 
    {
        $sql = "SELECT u.id, u.username, u.role, u.status 
                FROM users u 
                JOIN user_api_tokens ut ON u.id = ut.user_id 
                WHERE ut.token = ? AND ut.status = 'active' AND ut.expires_at > NOW() AND u.status = 'active'";
        
        $user = $this->database->queryOne($sql, array($token));
        
        if ($user) {
            // 更新最后访问时间
            $this->database->update('user_api_tokens', array(
                'last_access_at' => date('Y-m-d H:i:s')
            ), 'token = ?', array($token));
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 获取令牌载荷信息
     * @param string $token API令牌
     * @return array|null 载荷信息
     */
    public function getTokenPayload($token) 
    {
        $sql = "SELECT u.id, u.username, u.role, u.status, u.email 
                FROM users u 
                JOIN user_api_tokens ut ON u.id = ut.user_id 
                WHERE ut.token = ? AND ut.status = 'active' AND ut.expires_at > NOW() AND u.status = 'active'";
        
        $user = $this->database->queryOne($sql, array($token));
        
        if ($user) {
            // 更新最后访问时间
            $this->database->update('user_api_tokens', array(
                'last_access_at' => date('Y-m-d H:i:s')
            ), 'token = ?', array($token));
            
            return array(
                'user_id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'],
                'email' => $user['email']
            );
        }
        
        return null;
    }
    

    
    /**
     * 要求特定权限
     * @param string $permission 权限名称
     */
    public static function requirePermission($permission) 
    {
        $instance = self::getInstance();
        
        if (!$instance->isLoggedIn()) {
            header('HTTP/1.1 401 Unauthorized');
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('success' => false, 'message' => '请先登录'));
            exit;
        }
        
        if (!$instance->hasPermission($permission)) {
            header('HTTP/1.1 403 Forbidden');
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('success' => false, 'message' => '权限不足'));
            exit;
        }
    }
}