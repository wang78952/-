<?php
/**
 * 会话服务类
 * 负责管理用户会话、登录状态和会话安全
 */

require_once __DIR__ . '/../../core/BaseService.php';
require_once __DIR__ . '/../../core/Database.php';

class SessionService extends BaseService {
    private static $instance = null;
    private $sessionTimeout;
    private $maxConcurrentSessions;
    private $sessionEntropy;
    
    /**
      * 私有构造函数
      */
    private function __construct() {
        $this->sessionTimeout = SESSION_TIMEOUT;
        $this->maxConcurrentSessions = MAX_CONCURRENT_SESSIONS;
        $this->sessionEntropy = SESSION_ENTROPY;
        
        $this->initializeSecureSession();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化安全会话
     */
    private function initializeSecureSession() {
        // 防止会话固定攻击
        $this->preventSessionFixation();
        
        // 设置安全的会话配置
        $this->configureSessionSecurity();
        
        // 启动会话
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // 会话安全检查
        $this->validateSession();
        
        // 更新会话活动时间
        $this->updateSessionActivity();
    }
    
    /**
     * 防止会话固定攻击
     */
    private function preventSessionFixation() {
        // 检查是否需要重新生成会话ID
        if (!isset($_SESSION['initiated'])) {
            session_regenerate_id(true);
            $_SESSION['initiated'] = true;
            $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
            $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
            $_SESSION['created'] = time();
            $_SESSION['last_activity'] = time();
        } else {
            // 定期重新生成会话ID
            if (time() - $_SESSION['created'] > 300) { // 5分钟
                session_regenerate_id(true);
                $_SESSION['created'] = time();
            }
        }
    }
    
    /**
     * 配置会话安全参数
     */
    private function configureSessionSecurity() {
        // 设置会话Cookie参数
        $cookieParams = session_get_cookie_params();
        
        // PHP 7.3+ supports samesite in session_set_cookie_params
        if (version_compare(PHP_VERSION, '7.3.0', '>=')) {
            session_set_cookie_params(array(
                'lifetime' => $cookieParams['lifetime'],
                'path' => $cookieParams['path'],
                'domain' => $cookieParams['domain'],
                'secure' => SESSION_SECURE_COOKIE,
                'httponly' => SESSION_HTTPONLY_COOKIE,
                'samesite' => SESSION_SAMESITE
            ));
        } else {
            // For older PHP versions, use the traditional parameters
            session_set_cookie_params(
                $cookieParams['lifetime'],
                $cookieParams['path'],
                $cookieParams['domain'],
                SESSION_SECURE_COOKIE,
                SESSION_HTTPONLY_COOKIE
            );
        }
        
        // 设置会话名称
        session_name(SESSION_NAME);
        
        // 设置会话保存路径（自定义）
        if (defined('SESSION_SAVE_PATH')) {
            session_save_path(SESSION_SAVE_PATH);
        }
        
        // 设置会话熵长度
        ini_set('session.entropy_length', $this->sessionEntropy);
        
        // 禁用URL传递会话ID
        ini_set('session.use_only_cookies', 1);
        ini_set('session.use_trans_sid', 0);
        
        // 设置垃圾回收概率
        ini_set('session.gc_probability', 1);
        ini_set('session.gc_divisor', 100);
        ini_set('session.gc_maxlifetime', $this->sessionTimeout);
    }
    
    /**
     * 验证会话安全性
     */
    private function validateSession() {
        // 检查会话超时
        if (isset($_SESSION['last_activity'])) {
            if (time() - $_SESSION['last_activity'] > $this->sessionTimeout) {
                $this->destroySession('会话超时');
                throw new SessionException('会话已超时，请重新登录');
            }
        }
        
        // 检查IP地址变化
        if (SESSION_VALIDATE_IP && isset($_SESSION['ip_address'])) {
            if ($_SESSION['ip_address'] !== $_SERVER['REMOTE_ADDR']) {
                $this->destroySession('IP地址变化');
                throw new SessionException('检测到IP地址变化，请重新登录');
            }
        }
        
        // 检查User-Agent变化
        if (SESSION_VALIDATE_USER_AGENT && isset($_SESSION['user_agent'])) {
            if ($_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
                $this->destroySession('User-Agent变化');
                throw new SessionException('检测到浏览器变化，请重新登录');
            }
        }
        
        // 检查并发会话
        if ($this->maxConcurrentSessions > 0 && isset($_SESSION['user_id'])) {
            $this->checkConcurrentSessions($_SESSION['user_id']);
        }
    }
    
    /**
     * 更新会话活动时间
     */
    private function updateSessionActivity() {
        $_SESSION['last_activity'] = time();
        
        // 更新会话指纹
        $_SESSION['fingerprint'] = $this->generateSessionFingerprint();
    }
    
    /**
     * 生成会话指纹
     */
    private function generateSessionFingerprint() {
        $elements = array(
            (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''),
            (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''),
            (isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : ''),
            (isset($_SERVER['HTTP_ACCEPT_CHARSET']) ? $_SERVER['HTTP_ACCEPT_CHARSET'] : '')
        );
        
        return hash('sha256', implode('|', $elements));
    }
    
    /**
     * 检查并发会话
     */
    private function checkConcurrentSessions($userId) {
        try {
            $db = getDB();
            
            // 获取用户当前活跃会话数
            $stmt = $db->prepare("
                SELECT COUNT(*) as session_count 
                FROM user_sessions 
                WHERE user_id = ? AND last_activity > ? AND is_active = 1
            ");
            $stmt->execute(array($userId, time() - $this->sessionTimeout));
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result['session_count'] >= $this->maxConcurrentSessions) {
                // 获取最旧的会话并使其失效
                $stmt = $db->prepare("
                    SELECT session_id 
                    FROM user_sessions 
                    WHERE user_id = ? AND last_activity > ? AND is_active = 1
                    ORDER BY last_activity ASC 
                    LIMIT 1
                ");
                $stmt->execute(array($userId, time() - $this->sessionTimeout));
                $oldSession = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($oldSession) {
                    $this->invalidateSession($oldSession['session_id']);
                    
                    // 记录日志
                    ErrorHandler::getInstance()->logSecurity(
                        'SESSION_LIMIT_EXCEEDED',
                        "用户 {$userId} 超过并发会话限制，已使旧会话失效"
                    );
                }
            }
            
            // 更新当前会话记录
            $this->updateSessionRecord($userId);
            
        } catch (Exception $e) {
            ErrorHandler::getInstance()->logError(ErrorLevel::ERROR, '检查并发会话失败', array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
        }
    }
    
    /**
     * 更新会话记录
     */
    private function updateSessionRecord($userId) {
        try {
            $db = getDB();
            
            $sessionId = session_id();
            $ipAddress = $_SERVER['REMOTE_ADDR'];
            $userAgent = $_SERVER['HTTP_USER_AGENT'];
            $currentTime = time();
            
            // 检查会话记录是否存在
            $stmt = $db->prepare("
                SELECT id FROM user_sessions 
                WHERE session_id = ? AND user_id = ?
            ");
            $stmt->execute(array($sessionId, $userId));
            $exists = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($exists) {
                // 更新现有记录
                $stmt = $db->prepare("
                    UPDATE user_sessions 
                    SET last_activity = ?, ip_address = ?, user_agent = ?, is_active = 1
                    WHERE session_id = ? AND user_id = ?
                ");
                $stmt->execute(array($currentTime, $ipAddress, $userAgent, $sessionId, $userId));
            } else {
                // 插入新记录
                $stmt = $db->prepare("
                    INSERT INTO user_sessions 
                    (session_id, user_id, ip_address, user_agent, created_at, last_activity, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, 1)
                ");
                $stmt->execute(array($sessionId, $userId, $ipAddress, $userAgent, $currentTime, $currentTime));
            }
            
        } catch (Exception $e) {
            // 如果数据库操作失败，不影响会话功能
            ErrorHandler::getInstance()->logError(
                ErrorLevel::WARNING,
                'Failed to update session record',
                array('session_id' => session_id(), 'user_id' => $userId, 'error' => $e->getMessage())
            );
        }
    }
    
    /**
     * 使会话失效
     */
    private function invalidateSession($sessionId) {
        try {
            $db = getDB();
            
            $stmt = $db->prepare("
                UPDATE user_sessions 
                SET is_active = 0, last_activity = ?
                WHERE session_id = ?
            ");
            $stmt->execute(array(time(), $sessionId));
            
        } catch (Exception $e) {
            ErrorHandler::getInstance()->logError(
                ErrorLevel::WARNING,
                'Failed to invalidate session',
                array('session_id' => $sessionId, 'error' => $e->getMessage())
            );
        }
    }
    
    /**
     * 创建用户会话
     */
    public function createSession($userId, $userData = array()) {
        // 销毁现有会话
        $this->destroySession();
        
        // 启动新会话
        session_start();
        
        // 设置会话数据
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_data'] = $userData;
        $_SESSION['initiated'] = true;
        $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
        $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        $_SESSION['created'] = time();
        $_SESSION['last_activity'] = time();
        $_SESSION['fingerprint'] = $this->generateSessionFingerprint();
        
        // 更新会话记录
        $this->updateSessionRecord($userId);
        
        // 记录登录日志
        ErrorHandler::getInstance()->logSecurity(
            'USER_LOGIN',
            "用户 {$userId} 登录成功",
            array('ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''), 'user_agent' => (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''))
        );
    }
    
    /**
     * 销毁会话
     */
    public function destroySession($reason = '用户登出') {
        if (session_status() === PHP_SESSION_ACTIVE) {
            // 记录登出日志
            if (isset($_SESSION['user_id'])) {
                ErrorHandler::getInstance()->logSecurity(
                    'USER_LOGOUT',
                    "用户 {$_SESSION['user_id']} 登出: {$reason}",
                    array('ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''), 'reason' => $reason)
                );
                
                // 使数据库中的会话记录失效
                $this->invalidateSession(session_id());
            }
            
            // 清空会话数据
            $_SESSION = array();
            
            // 删除会话Cookie
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params['path'],
                    $params['domain'],
                    $params['secure'],
                    $params['httponly']
                );
            }
            
            // 销毁会话
            session_destroy();
        }
    }
    
    /**
     * 检查用户是否已登录
     */
    public function isLoggedIn() {
        if (session_status() === PHP_SESSION_NONE) {
            return false;
        }
        
        return isset($_SESSION['user_id']) && 
               isset($_SESSION['initiated']) && 
               isset($_SESSION['last_activity']);
    }
    
    /**
     * 获取当前用户ID
     */
    public function getUserId() {
        return (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null);
    }
    
    /**
     * 获取用户数据
     */
    public function getUserData($key = null) {
        if ($key === null) {
            return (isset($_SESSION['user_data']) ? $_SESSION['user_data'] : array());
        }
        
        return (isset($_SESSION['user_data'][$key]) ? $_SESSION['user_data'][$key] : null);
    }
    
    /**
     * 设置用户数据
     */
    public function setUserData($key, $value) {
        $_SESSION['user_data'][$key] = $value;
    }
    
    /**
     * 获取会话信息
     */
    public function getSessionInfo() {
        return array(
            'session_id' => session_id(),
            'user_id' => (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null),
            'created' => (isset($_SESSION['created']) ? $_SESSION['created'] : null),
            'last_activity' => (isset($_SESSION['last_activity']) ? $_SESSION['last_activity'] : null),
            'ip_address' => (isset($_SESSION['ip_address']) ? $_SESSION['ip_address'] : null),
            'user_agent' => (isset($_SESSION['user_agent']) ? $_SESSION['user_agent'] : null),
            'timeout' => $this->sessionTimeout,
            'time_remaining' => ($this->sessionTimeout - (time() - (isset($_SESSION['last_activity']) ? $_SESSION['last_activity'] : 0)))
        );
    }
    
    /**
     * 清理过期会话
     */
    public function cleanupExpiredSessions() {
        try {
            $db = getDB();
            
            $stmt = $db->prepare("
                UPDATE user_sessions 
                SET is_active = 0 
                WHERE last_activity < ? AND is_active = 1
            ");
            $stmt->execute(array(time() - $this->sessionTimeout));
            
            $affectedRows = $stmt->rowCount();
            
            if ($affectedRows > 0) {
                ErrorHandler::getInstance()->logInfo(
                    "清理了 {$affectedRows} 个过期会话"
                );
            }
            
        } catch (Exception $e) {
            ErrorHandler::getInstance()->logError(
                ErrorLevel::WARNING,
                'Failed to cleanup expired sessions',
                array('error' => $e->getMessage())
            );
        }
    }
    
    /**
     * 获取用户的所有活跃会话
     */
    public function getUserSessions($userId) {
        try {
            $db = getDB();
            
            $stmt = $db->prepare("
                SELECT session_id, ip_address, user_agent, created_at, last_activity, is_active
                FROM user_sessions 
                WHERE user_id = ? AND last_activity > ?
                ORDER BY last_activity DESC
            ");
            $stmt->execute(array($userId, time() - $this->sessionTimeout));
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            ErrorHandler::getInstance()->logError(
                ErrorLevel::WARNING,
                'Failed to get user sessions',
                array('user_id' => $userId, 'error' => $e->getMessage())
            );
            return array();
        }
    }
    
    /**
     * 强制用户所有会话下线
     */
    public function forceLogoutUser($userId) {
        try {
            $db = getDB();
            
            $stmt = $db->prepare("
                UPDATE user_sessions 
                SET is_active = 0 
                WHERE user_id = ? AND is_active = 1
            ");
            $stmt->execute(array($userId));
            
            $affectedRows = $stmt->rowCount();
            
            ErrorHandler::getInstance()->logSecurity(
                'FORCE_LOGOUT',
                "强制用户 {$userId} 的 {$affectedRows} 个会话下线"
            );
            
            return $affectedRows;
            
        } catch (Exception $e) {
            ErrorHandler::getInstance()->logError(
                ErrorLevel::ERROR,
                'Failed to force logout user',
                array('user_id' => $userId, 'error' => $e->getMessage())
            );
            return 0;
        }
    }
}

/**
 * 会话异常类
 */
class SessionException extends Exception {
    public function __construct($message, $code = 0, $previous = null) {
        parent::__construct($message, $code, $previous);
    }
}

/**
 * 便捷函数
 */
function getSessionService() {
    return SessionService::getInstance();
}

function isLoggedIn() {
    return SessionService::getInstance()->isLoggedIn();
}

function getUserId() {
    return SessionService::getInstance()->getUserId();
}

function getUserData($key = null) {
    return SessionService::getInstance()->getUserData($key);
}
?>