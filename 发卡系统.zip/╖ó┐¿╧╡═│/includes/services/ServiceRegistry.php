<?php
/**
 * 服务注册与发现客户端
 * 用于微服务架构中的服务管理
 * 
 * @package CardSystem\Services
 * @author System Developer
 * @version 1.0.0
 */

namespace CardSystem\Services;

use CardSystem\Config\ConfigManager;
use CardSystem\Utils\HttpClient;
use CardSystem\Utils\Logger;

/**
 * ServiceRegistry类 - 服务注册与发现客户端
 */
class ServiceRegistry
{
    /**
     * 配置管理器实例
     * @var ConfigManager
     */
    private $configManager;
    
    /**
     * HTTP客户端实例
     * @var HttpClient
     */
    private $httpClient;
    
    /**
     * 日志记录器实例
     * @var Logger
     */
    private $logger;
    
    /**
     * 服务注册配置
     * @var array
     */
    private $config;
    
    /**
     * 缓存的服务列表
     * @var array
     */
    private $servicesCache = [];
    
    /**
     * 服务列表缓存时间戳
     * @var int
     */
    private $servicesCacheTimestamp = 0;
    
    /**
     * 构造函数
     * 
     * @param ConfigManager $configManager 配置管理器
     * @param HttpClient $httpClient HTTP客户端
     * @param Logger $logger 日志记录器
     */
    public function __construct(ConfigManager $configManager, HttpClient $httpClient, Logger $logger)
    {
        $this->configManager = $configManager;
        $this->httpClient = $httpClient;
        $this->logger = $logger;
        
        // 加载配置
        $this->config = $configManager->get('consul', []);
        
        $this->logger->info('服务注册与发现客户端初始化成功');
    }
    
    /**
     * 注册服务
     * 
     * @param string $serviceName 服务名称
     * @param string $serviceId 服务ID
     * @param string $address 服务地址
     * @param int $port 服务端口
     * @param array $tags 服务标签
     * @param array $checks 健康检查配置
     * @return bool 是否注册成功
     */
    public function registerService($serviceName, $serviceId, $address, $port, $tags = [], $checks = [])
    {
        try {
            if (!$this->config['enabled']) {
                $this->logger->warning('服务注册已禁用');
                return true;
            }
            
            // 构建注册请求
            $payload = [
                'Name' => $serviceName,
                'ID' => $serviceId,
                'Address' => $address,
                'Port' => $port,
                'Tags' => $tags,
                'Checks' => $checks
            ];
            
            // 如果未提供健康检查，使用默认配置
            if (empty($checks)) {
                $payload['Checks'] = [
                    [
                        'HTTP' => "http://{$address}:{$port}/health",
                        'Interval' => $this->config['check_interval'] ?? '30s',
                        'Timeout' => '10s',
                        'DeregisterCriticalServiceAfter' => $this->config['deregister_after'] ?? '1m'
                    ]
                ];
            }
            
            // 发送注册请求
            $url = "{$this->config['address']}/v1/agent/service/register";
            $response = $this->httpClient->put($url, $payload, [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200) {
                $this->logger->info("服务注册成功: {$serviceName} ({$serviceId})");
                return true;
            } else {
                $this->logger->error("服务注册失败: {$serviceName}, 状态码: {$response->status}");
                return false;
            }
        } catch (\Exception $e) {
            $this->logger->error("服务注册异常: {$e->getMessage()}", ['exception' => $e]);
            return false;
        }
    }
    
    /**
     * 注销服务
     * 
     * @param string $serviceId 服务ID
     * @return bool 是否注销成功
     */
    public function deregisterService($serviceId)
    {
        try {
            if (!$this->config['enabled']) {
                return true;
            }
            
            $url = "{$this->config['address']}/v1/agent/service/deregister/{$serviceId}";
            $response = $this->httpClient->put($url, null, [
                'headers' => [
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200) {
                $this->logger->info("服务注销成功: {$serviceId}");
                return true;
            } else {
                $this->logger->error("服务注销失败: {$serviceId}, 状态码: {$response->status}");
                return false;
            }
        } catch (\Exception $e) {
            $this->logger->error("服务注销异常: {$e->getMessage()}", ['exception' => $e]);
            return false;
        }
    }
    
    /**
     * 获取所有服务
     * 
     * @return array 服务列表
     */
    public function getServices()
    {
        try {
            // 检查缓存
            $cacheTtl = $this->config['cache_ttl'] ?? 30; // 默认缓存30秒
            if (!empty($this->servicesCache) && 
                (time() - $this->servicesCacheTimestamp) < $cacheTtl) {
                return $this->servicesCache;
            }
            
            if (!$this->config['enabled']) {
                return $this->configManager->get('microservices', []);
            }
            
            $url = "{$this->config['address']}/v1/catalog/services";
            $response = $this->httpClient->get($url, [
                'headers' => [
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200) {
                $services = json_decode($response->body, true);
                $this->servicesCache = $services;
                $this->servicesCacheTimestamp = time();
                return $services;
            } else {
                $this->logger->error("获取服务列表失败, 状态码: {$response->status}");
                // 返回缓存或配置中的服务列表
                return !empty($this->servicesCache) ? $this->servicesCache : 
                       $this->configManager->get('microservices', []);
            }
        } catch (\Exception $e) {
            $this->logger->error("获取服务列表异常: {$e->getMessage()}", ['exception' => $e]);
            // 异常情况下返回缓存或配置中的服务列表
            return !empty($this->servicesCache) ? $this->servicesCache : 
                   $this->configManager->get('microservices', []);
        }
    }
    
    /**
     * 根据服务名称获取服务实例
     * 
     * @param string $serviceName 服务名称
     * @return array 服务实例列表
     */
    public function getServiceInstances($serviceName)
    {
        try {
            if (!$this->config['enabled']) {
                // 从配置中获取服务信息
                $services = $this->configManager->get('microservices', []);
                return isset($services[$serviceName]) ? [$services[$serviceName]] : [];
            }
            
            $url = "{$this->config['address']}/v1/catalog/service/{$serviceName}";
            $response = $this->httpClient->get($url, [
                'headers' => [
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200) {
                $instances = json_decode($response->body, true);
                return $instances;
            } else {
                $this->logger->error("获取服务实例失败: {$serviceName}, 状态码: {$response->status}");
                return [];
            }
        } catch (\Exception $e) {
            $this->logger->error("获取服务实例异常: {$e->getMessage()}", ['exception' => $e]);
            return [];
        }
    }
    
    /**
     * 获取健康的服务实例
     * 
     * @param string $serviceName 服务名称
     * @return array 健康的服务实例列表
     */
    public function getHealthyServiceInstances($serviceName)
    {
        try {
            if (!$this->config['enabled']) {
                // 从配置中获取服务信息
                $services = $this->configManager->get('microservices', []);
                return isset($services[$serviceName]) ? [$services[$serviceName]] : [];
            }
            
            $url = "{$this->config['address']}/v1/health/service/{$serviceName}?passing=true";
            $response = $this->httpClient->get($url, [
                'headers' => [
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200) {
                $instances = json_decode($response->body, true);
                // 提取服务信息
                $result = [];
                foreach ($instances as $instance) {
                    $result[] = [
                        'Address' => $instance['Service']['Address'],
                        'Port' => $instance['Service']['Port'],
                        'ID' => $instance['Service']['ID'],
                        'Name' => $instance['Service']['Service'],
                        'Tags' => $instance['Service']['Tags'] ?? []
                    ];
                }
                return $result;
            } else {
                $this->logger->error("获取健康服务实例失败: {$serviceName}, 状态码: {$response->status}");
                return [];
            }
        } catch (\Exception $e) {
            $this->logger->error("获取健康服务实例异常: {$e->getMessage()}", ['exception' => $e]);
            return [];
        }
    }
    
    /**
     * 选择一个服务实例（负载均衡）
     * 
     * @param string $serviceName 服务名称
     * @param string $strategy 负载均衡策略: random, round-robin, least-connections
     * @return array|null 选中的服务实例
     */
    public function selectServiceInstance($serviceName, $strategy = 'random')
    {
        // 获取健康的服务实例
        $instances = $this->getHealthyServiceInstances($serviceName);
        
        if (empty($instances)) {
            $this->logger->error("无可用的服务实例: {$serviceName}");
            return null;
        }
        
        // 根据策略选择实例
        switch ($strategy) {
            case 'round-robin':
                // 使用简单的轮询策略
                $index = $this->getRoundRobinIndex($serviceName, count($instances));
                return $instances[$index];
                
            case 'least-connections':
                // 简单模拟最少连接策略（实际应从监控获取）
                // 这里简化为随机选择
                return $instances[array_rand($instances)];
                
            case 'random':
            default:
                // 随机选择
                return $instances[array_rand($instances)];
        }
    }
    
    /**
     * 获取轮询索引
     * 
     * @param string $serviceName 服务名称
     * @param int $total 实例总数
     * @return int 选中的索引
     */
    private function getRoundRobinIndex($serviceName, $total)
    {
        // 使用静态变量存储索引
        static $indices = [];
        
        if (!isset($indices[$serviceName])) {
            $indices[$serviceName] = 0;
        }
        
        $index = $indices[$serviceName];
        $indices[$serviceName] = ($indices[$serviceName] + 1) % $total;
        
        return $index;
    }
    
    /**
     * 获取配置
     * 
     * @param string $key 配置键
     * @param mixed $default 默认值
     * @return mixed 配置值
     */
    public function getConfig($key, $default = null)
    {
        try {
            if (!$this->config['enabled']) {
                return $this->configManager->get($key, $default);
            }
            
            // 转换键格式
            $consulKey = str_replace('.', '/', $key);
            $path = "{$this->config['path']}/{$consulKey}";
            
            $url = "{$this->config['address']}/v1/kv/{$path}?raw=true";
            $response = $this->httpClient->get($url, [
                'headers' => [
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200) {
                // 尝试解析JSON
                $result = json_decode($response->body, true);
                return $result !== null ? $result : $response->body;
            } elseif ($response->status === 404) {
                return $default;
            } else {
                $this->logger->error("获取配置失败: {$key}, 状态码: {$response->status}");
                return $default;
            }
        } catch (\Exception $e) {
            $this->logger->error("获取配置异常: {$e->getMessage()}", ['exception' => $e]);
            return $default;
        }
    }
    
    /**
     * 设置配置
     * 
     * @param string $key 配置键
     * @param mixed $value 配置值
     * @return bool 是否设置成功
     */
    public function setConfig($key, $value)
    {
        try {
            if (!$this->config['enabled']) {
                $this->logger->warning('配置中心已禁用');
                return true;
            }
            
            // 转换键格式
            $consulKey = str_replace('.', '/', $key);
            $path = "{$this->config['path']}/{$consulKey}";
            
            // 序列化值
            $body = is_array($value) ? json_encode($value) : (string)$value;
            
            $url = "{$this->config['address']}/v1/kv/{$path}";
            $response = $this->httpClient->put($url, $body, [
                'headers' => [
                    'X-Consul-Token' => $this->config['token'] ?? ''
                ]
            ]);
            
            if ($response->status === 200 && $response->body === 'true') {
                $this->logger->info("设置配置成功: {$key}");
                return true;
            } else {
                $this->logger->error("设置配置失败: {$key}, 状态码: {$response->status}");
                return false;
            }
        } catch (\Exception $e) {
            $this->logger->error("设置配置异常: {$e->getMessage()}", ['exception' => $e]);
            return false;
        }
    }
    
    /**
     * 注销所有服务并清理资源
     */
    public function shutdown()
    {
        try {
            $this->logger->info('服务注册与发现客户端正在关闭...');
            // 这里可以添加清理逻辑
            $this->servicesCache = [];
            $this->servicesCacheTimestamp = 0;
        } catch (\Exception $e) {
            $this->logger->error("关闭客户端异常: {$e->getMessage()}", ['exception' => $e]);
        }
    }
}