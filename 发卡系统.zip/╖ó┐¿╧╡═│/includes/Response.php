<?php

/**
 * API响应处理类
 * 用于统一处理API响应格式
 */
class Response
{
    /**
     * 返回成功响应
     * @param mixed $data 响应数据
     * @param string $message 成功消息
     * @param int $code HTTP状态码
     */
    public static function success($data = null, $message = 'Success', $code = 200)
    {
        http_response_code($code);
        $response = array(
            'success' => true,
            'message' => $message,
            'data' => $data,
            'timestamp' => time()
        );
        
        echo json_encode($response, JSON_UNESCAPED_SLASHES);
        exit;
    }
    
    /**
     * 返回错误响应
     * @param string $message 错误消息
     * @param int $code HTTP状态码
     * @param mixed $data 错误详情数据
     */
    public static function error($message = 'Error', $code = 400, $data = null)
    {
        http_response_code($code);
        $response = array(
            'success' => false,
            'message' => $message,
            'code' => $code,
            'data' => $data,
            'timestamp' => time()
        );
        
        echo json_encode($response, JSON_UNESCAPED_SLASHES);
        exit;
    }
    
    /**
     * 返回验证错误响应
     * @param array $errors 验证错误列表
     * @param string $message 错误消息
     */
    public static function validationError($errors = array(), $message = 'Validation failed')
    {
        http_response_code(422);
        $response = array(
            'success' => false,
            'message' => $message,
            'errors' => $errors,
            'code' => 422,
            'timestamp' => time()
        );
        
        echo json_encode($response, JSON_UNESCAPED_SLASHES);
        exit;
    }
    
    /**
     * 返回未授权响应
     * @param string $message 错误消息
     */
    public static function unauthorized($message = 'Unauthorized')
    {
        self::error($message, 401);
    }
    
    /**
     * 返回禁止访问响应
     * @param string $message 错误消息
     */
    public static function forbidden($message = 'Forbidden')
    {
        self::error($message, 403);
    }
    
    /**
     * 返回未找到响应
     * @param string $message 错误消息
     */
    public static function notFound($message = 'Not found')
    {
        self::error($message, 404);
    }
    
    /**
     * 返回服务器错误响应
     * @param string $message 错误消息
     */
    public static function serverError($message = 'Internal server error')
    {
        self::error($message, 500);
    }
    
    /**
     * 返回分页响应
     * @param array $items 数据列表
     * @param int $total 总数
     * @param int $page 当前页
     * @param int $limit 每页数量
     * @param string $message 成功消息
     */
    public static function paginated($items, $total, $page, $limit, $message = 'Success')
    {
        $data = array(
            'items' => $items,
            'pagination' => array(
                'total' => (int)$total,
                'page' => (int)$page,
                'limit' => (int)$limit,
                'pages' => ceil($total / $limit),
                'has_next' => ($page * $limit) < $total,
                'has_prev' => $page > 1
            )
        );
        
        self::success($data, $message);
    }
}