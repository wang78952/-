<?php
/**
 * 身份核验服务
 * 提供与第三方身份核验API的集成功能
 */

class VerificationService {
    private $config;
    private $logger;
    private $db;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 加载配置
        $this->config = require_once __DIR__ . '/../config/verification.php';
        $this->logger = new Logger();
        $this->db = Database::getInstance();
    }
    
    /**
     * 执行身份核验
     */
    public function verifyIdentity($verificationData) {
        // 验证必填字段
        $verificationType = isset($verificationData['verification_type']) ? $verificationData['verification_type'] : 'basic';
        
        if (!$this->validateVerificationType($verificationType)) {
            throw new Exception('无效的核验类型');
        }
        
        // 检查必填字段
        $requiredFields = $this->config['identity_verification']['verification_types'][$verificationType]['required_fields'];
        foreach ($requiredFields as $field) {
            if (!isset($verificationData[$field]) || empty($verificationData[$field])) {
                throw new Exception("缺少必填字段: {$field}");
            }
        }
        
        // 执行反欺诈检查
        $fraudCheck = $this->performFraudCheck($verificationData);
        if (!$fraudCheck['passed']) {
            return [
                'status' => 'rejected',
                'data' => [
                    'verification_time' => date('Y-m-d H:i:s'),
                    'verification_method' => 'fraud_detection',
                    'risk_level' => 'high',
                    'details' => [
                        'reason' => $fraudCheck['reason'],
                        'risk_score' => $fraudCheck['risk_score']
                    ]
                ]
            ];
        }
        
        // 根据配置选择验证提供商
        $provider = $this->config['identity_verification']['provider'];
        
        switch ($provider) {
            case 'third_party_api':
                return $this->callThirdPartyApi($verificationData);
            case 'internal_service':
                return $this->callInternalService($verificationData);
            case 'mock':
            default:
                return $this->mockVerification($verificationData);
        }
    }
    
    /**
     * 调用第三方API进行核验
     */
    private function callThirdPartyApi($verificationData) {
        $apiConfig = $this->config['identity_verification']['third_party'];
        
        // 检查API配置
        if (empty($apiConfig['api_key']) || empty($apiConfig['base_url'])) {
            $this->logger->error('身份核验API配置不完整', ['api_config' => ['api_key' => !empty($apiConfig['api_key']), 'base_url' => !empty($apiConfig['base_url'])]]);
            // 降级到模拟模式
            return $this->mockVerification($verificationData, 'api_config_incomplete');
        }
        
        $url = $apiConfig['base_url'] . '/verify';
        $retryCount = $apiConfig['retry_count'];
        $retryInterval = $apiConfig['retry_interval'];
        
        // 准备请求数据
        $requestData = $this->prepareApiRequest($verificationData);
        
        // 添加请求日志
        $this->logger->info('发送身份核验API请求', [
            'url' => $url,
            'verification_type' => $verificationData['verification_type']
        ]);
        
        // 执行API调用（带重试机制）
        for ($i = 0; $i <= $retryCount; $i++) {
            try {
                $result = $this->executeApiRequest($url, $requestData, $apiConfig);
                
                // 处理API响应
                $processedResult = $this->processApiResponse($result);
                
                // 记录结果
                $this->logVerificationResult($processedResult, $verificationData['verification_type']);
                
                return $processedResult;
                
            } catch (Exception $e) {
                $this->logger->error('身份核验API调用失败', [
                    'attempt' => $i + 1,
                    'error' => $e->getMessage()
                ]);
                
                // 如果不是最后一次尝试，则重试
                if ($i < $retryCount) {
                    usleep($retryInterval * 1000);
                }
            }
        }
        
        // 所有重试都失败，降级到备用方案
        if ($this->config['identity_verification']['failover']['enabled']) {
            $this->logger->warning('身份核验API调用失败，启用备用方案', [
                'backup_provider' => $this->config['identity_verification']['failover']['backup_provider']
            ]);
            return $this->mockVerification($verificationData, 'api_failover');
        }
        
        throw new Exception('身份核验服务暂时不可用，请稍后再试');
    }
    
    /**
     * 执行API请求
     */
    private function executeApiRequest($url, $data, $config) {
        $ch = curl_init();
        
        // 设置请求选项
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $config['timeout']);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        
        // 设置请求头
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $config['api_key'],
            'X-Request-ID: ' . $this->generateRequestId(),
            'X-Environment: ' . ($config['sandbox'] ? 'sandbox' : 'production')
        ];
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        // 执行请求
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        // 检查错误
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("API请求错误: {$error}");
        }
        
        curl_close($ch);
        
        // 检查HTTP状态码
        if ($httpCode < 200 || $httpCode >= 300) {
            throw new Exception("API返回错误状态码: {$httpCode}");
        }
        
        return json_decode($response, true);
    }
    
    /**
     * 准备API请求数据
     */
    private function prepareApiRequest($data) {
        // 根据第三方API要求格式化数据
        return [
            'id_card' => isset($data['id_card']) || isset($data['id_number']) ? ($data['id_card'] ?? $data['id_number']) : null,
            'name' => $data['name'] ?? null,
            'phone' => isset($data['phone']) || isset($data['phone_number']) ? ($data['phone'] ?? $data['phone_number']) : null,
            'verification_type' => $data['verification_type'] ?? 'basic',
            'extra_data' => [
                'request_source' => 'card_system',
                'request_time' => date('Y-m-d H:i:s'),
                'client_ip' => SecurityUtils::getClientIP(),
                'device_info' => SecurityUtils::getDeviceInfo()
            ]
        ];
    }
    
    /**
     * 处理API响应
     */
    private function processApiResponse($apiResponse) {
        // 将第三方API响应转换为系统内部格式
        if (isset($apiResponse['status'])) {
            switch ($apiResponse['status']) {
                case 'success':
                case 'approved':
                    return [
                        'status' => 'approved',
                        'data' => [
                            'verification_time' => date('Y-m-d H:i:s'),
                            'verification_method' => 'third_party_api',
                            'match_score' => isset($apiResponse['score']) ? $apiResponse['score'] : 90,
                            'risk_level' => 'low',
                            'details' => $this->extractApiDetails($apiResponse)
                        ]
                    ];
                    
                case 'failed':
                case 'rejected':
                    return [
                        'status' => 'rejected',
                        'data' => [
                            'verification_time' => date('Y-m-d H:i:s'),
                            'verification_method' => 'third_party_api',
                            'match_score' => isset($apiResponse['score']) ? $apiResponse['score'] : 40,
                            'risk_level' => 'high',
                            'details' => [
                                'rejection_reason' => isset($apiResponse['reason']) ? $apiResponse['reason'] : '身份信息不匹配',
                                'api_details' => $this->extractApiDetails($apiResponse)
                            ]
                        ]
                    ];
                    
                default:
                    throw new Exception('API返回未知状态: ' . $apiResponse['status']);
            }
        }
        
        throw new Exception('API返回格式无效');
    }
    
    /**
     * 提取API详细信息
     */
    private function extractApiDetails($apiResponse) {
        $details = [];
        
        if (isset($apiResponse['details'])) {
            $details['api_details'] = $apiResponse['details'];
        }
        
        if (isset($apiResponse['verification_id'])) {
            $details['external_verification_id'] = $apiResponse['verification_id'];
        }
        
        return $details;
    }
    
    /**
     * 调用内部服务进行核验（预留）
     */
    private function callInternalService($verificationData) {
        // 预留内部核验服务实现
        $this->logger->info('调用内部身份核验服务', [
            'verification_type' => $verificationData['verification_type']
        ]);
        
        // 暂时降级到模拟模式
        return $this->mockVerification($verificationData, 'internal_service');
    }
    
    /**
     * 模拟身份核验（用于测试或降级）
     */
    private function mockVerification($verificationData, $mode = 'mock') {
        $this->logger->info('执行模拟身份核验', [
            'mode' => $mode,
            'verification_type' => $verificationData['verification_type']
        ]);
        
        // 基本验证
        $idCard = isset($verificationData['id_card']) || isset($verificationData['id_number']) ? ($verificationData['id_card'] ?? $verificationData['id_number']) : null;
        $name = $verificationData['name'] ?? null;
        $phone = isset($verificationData['phone']) || isset($verificationData['phone_number']) ? ($verificationData['phone'] ?? $verificationData['phone_number']) : null;
        
        // 简单的验证逻辑
        $isValidIdCard = $this->validateIdCard($idCard);
        $isValidPhone = $this->validatePhone($phone);
        $isValidName = $this->validateName($name);
        
        // 生成模拟分数
        $matchScore = $this->generateMockScore($isValidIdCard, $isValidPhone, $isValidName);
        
        if ($matchScore >= 70) {
            return [
                'status' => 'approved',
                'data' => [
                    'verification_time' => date('Y-m-d H:i:s'),
                    'verification_method' => $mode,
                    'match_score' => $matchScore,
                    'risk_level' => 'low',
                    'details' => [
                        'id_card_valid' => $isValidIdCard,
                        'name_match' => $isValidName,
                        'phone_match' => $isValidPhone
                    ]
                ]
            ];
        } else {
            return [
                'status' => 'rejected',
                'data' => [
                    'verification_time' => date('Y-m-d H:i:s'),
                    'verification_method' => $mode,
                    'match_score' => $matchScore,
                    'risk_level' => 'high',
                    'details' => [
                        'id_card_valid' => $isValidIdCard,
                        'name_match' => $isValidName,
                        'phone_match' => $isValidPhone,
                        'rejection_reason' => '身份信息验证未通过'
                    ]
                ]
            ];
        }
    }
    
    /**
     * 执行反欺诈检查
     */
    private function performFraudCheck($verificationData) {
        $fraudConfig = $this->config['fraud_detection'];
        
        if (!$fraudConfig['enabled']) {
            return ['passed' => true];
        }
        
        $clientIP = SecurityUtils::getClientIP();
        $phone = isset($verificationData['phone']) || isset($verificationData['phone_number']) ? ($verificationData['phone'] ?? $verificationData['phone_number']) : null;
        $idCard = isset($verificationData['id_card']) || isset($verificationData['id_number']) ? ($verificationData['id_card'] ?? $verificationData['id_number']) : null;
        
        // 检查IP地址异常
        $ipCheck = $this->checkIpFraud($clientIP, $fraudConfig);
        if (!$ipCheck['passed']) {
            return $ipCheck;
        }
        
        // 检查手机号验证次数
        if ($phone) {
            $phoneCheck = $this->checkPhoneVerificationLimit($phone, $fraudConfig);
            if (!$phoneCheck['passed']) {
                return $phoneCheck;
            }
        }
        
        // 检查身份证验证次数
        if ($idCard) {
            $idCardCheck = $this->checkIdCardVerificationLimit($idCard, $fraudConfig);
            if (!$idCardCheck['passed']) {
                return $idCardCheck;
            }
        }
        
        return ['passed' => true];
    }
    
    /**
     * 检查IP地址异常
     */
    private function checkIpFraud($ip, $fraudConfig) {
        // 检查IP地址在短时间内的验证请求数
        $maxRequests = $fraudConfig['rules']['max_verifications_per_ip'];
        $timeWindow = 3600; // 1小时
        
        $sql = "SELECT COUNT(*) as count FROM verification_logs 
                WHERE client_ip = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)";
        
        $result = $this->db->queryOne($sql, [$ip, $timeWindow]);
        
        if ($result['count'] >= $maxRequests) {
            return [
                'passed' => false,
                'reason' => 'IP地址验证次数过多',
                'risk_score' => 90
            ];
        }
        
        return ['passed' => true];
    }
    
    /**
     * 检查手机号验证次数限制
     */
    private function checkPhoneVerificationLimit($phone, $fraudConfig) {
        $maxVerifications = $fraudConfig['rules']['max_verifications_per_phone'];
        $timeWindow = 86400; // 24小时
        
        // 对手机号进行哈希处理后存储和查询
        $phoneHash = hash('sha256', $phone);
        
        $sql = "SELECT COUNT(*) as count FROM verification_logs 
                WHERE phone_hash = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)";
        
        $result = $this->db->queryOne($sql, [$phoneHash, $timeWindow]);
        
        if ($result['count'] >= $maxVerifications) {
            return [
                'passed' => false,
                'reason' => '手机号验证次数过多',
                'risk_score' => 85
            ];
        }
        
        return ['passed' => true];
    }
    
    /**
     * 检查身份证验证次数限制
     */
    private function checkIdCardVerificationLimit($idCard, $fraudConfig) {
        $maxVerifications = $fraudConfig['rules']['max_verifications_per_id'];
        $timeWindow = 2592000; // 30天
        
        // 对身份证进行哈希处理后存储和查询
        $idCardHash = hash('sha256', $idCard);
        
        $sql = "SELECT COUNT(*) as count FROM verification_logs 
                WHERE id_card_hash = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)";
        
        $result = $this->db->queryOne($sql, [$idCardHash, $timeWindow]);
        
        if ($result['count'] >= $maxVerifications) {
            return [
                'passed' => false,
                'reason' => '身份证验证次数过多',
                'risk_score' => 95
            ];
        }
        
        return ['passed' => true];
    }
    
    /**
     * 验证核验类型
     */
    private function validateVerificationType($verificationType) {
        return isset($this->config['identity_verification']['verification_types'][$verificationType]) && 
               $this->config['identity_verification']['verification_types'][$verificationType]['enabled'];
    }
    
    /**
     * 验证身份证号
     */
    private function validateIdCard($idCard) {
        if (empty($idCard)) {
            return false;
        }
        
        // 基本格式验证
        if (!preg_match('/^\d{17}[\dXx]$/', $idCard)) {
            return false;
        }
        
        // 验证校验码
        return $this->checkIdCardChecksum($idCard);
    }
    
    /**
     * 检查身份证校验码
     */
    private function checkIdCardChecksum($idCard) {
        // 计算校验码逻辑
        $weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
        $codes = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];
        
        $sum = 0;
        for ($i = 0; $i < 17; $i++) {
            $sum += intval($idCard[$i]) * $weights[$i];
        }
        
        $checkCode = $codes[$sum % 11];
        return strtoupper($idCard[17]) === $checkCode;
    }
    
    /**
     * 验证手机号
     */
    private function validatePhone($phone) {
        if (empty($phone)) {
            return true; // 手机号可能不是必填项
        }
        
        return preg_match('/^1[3-9]\d{9}$/', $phone);
    }
    
    /**
     * 验证姓名
     */
    private function validateName($name) {
        if (empty($name)) {
            return false;
        }
        
        // 检查姓名长度
        if (strlen($name) < 2 || strlen($name) > 50) {
            return false;
        }
        
        // 检查是否包含非法字符
        return preg_match('/^[\x{4e00}-\x{9fa5}a-zA-Z\s·]+$/u', $name);
    }
    
    /**
     * 生成模拟分数
     */
    private function generateMockScore($isValidIdCard, $isValidPhone, $isValidName) {
        $score = 0;
        
        if ($isValidIdCard) {
            $score += 50;
        }
        
        if ($isValidName) {
            $score += 30;
        }
        
        if ($isValidPhone) {
            $score += 20;
        }
        
        // 添加一些随机波动
        $score += mt_rand(-10, 10);
        
        return max(0, min(100, $score));
    }
    
    /**
     * 生成请求ID
     */
    private function generateRequestId() {
        return uniqid('vrq_', true);
    }
    
    /**
     * 记录核验结果
     */
    private function logVerificationResult($result, $verificationType) {
        // 记录到系统日志
        $this->logger->info('身份核验完成', [
            'status' => $result['status'],
            'verification_type' => $verificationType,
            'score' => $result['data']['match_score']
        ]);
        
        // 记录到数据库（用于审计和分析）
        $this->recordVerificationLog($result, $verificationType);
    }
    
    /**
     * 记录核验日志到数据库
     */
    private function recordVerificationLog($result, $verificationType) {
        try {
            $sql = "INSERT INTO verification_logs (status, match_score, risk_level, verification_type, client_ip, created_at) 
                    VALUES (?, ?, ?, ?, ?, NOW())";
            
            $this->db->execute($sql, [
                $result['status'],
                $result['data']['match_score'],
                $result['data']['risk_level'],
                $verificationType,
                SecurityUtils::getClientIP()
            ]);
            
        } catch (Exception $e) {
            $this->logger->error('记录核验日志失败', ['error' => $e->getMessage()]);
        }
    }
}