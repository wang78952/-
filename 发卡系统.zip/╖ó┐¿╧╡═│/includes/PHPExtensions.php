<?php

/**
 * PHP扩展存根文件
 * 用于IDE类型检查和代码补全
 * 这些定义仅用于开发时IDE支持，不会影响运行时
 */

// Memcached扩展存根
if (!class_exists('Memcached')) {
    /**
     * Memcached类存根定义
     */
    class Memcached {
        const RES_SUCCESS = 0;
        const RES_FAILURE = 1;
        const RES_HOST_LOOKUP_FAILURE = 2;
        const RES_UNKNOWN_READ_FAILURE = 7;
        const RES_PROTOCOL_ERROR = 8;
        const RES_CLIENT_ERROR = 9;
        const RES_SERVER_ERROR = 10;
        const RES_WRITE_FAILURE = 5;
        const RES_DATA_EXISTS = 12;
        const RES_NOTFOUND = 1;
        const RES_NOTSTORED = 14;
        const RES_PARTIAL_READ = 18;
        const RES_SOME_ERRORS = 19;
        const RES_NO_SERVERS = 20;
        const RES_END = 21;
        const RES_ERRNO = 26;
        const RES_BUFFERED = 32;
        const RES_TIMEOUT = 31;
        const RES_BAD_KEY_PROVIDED = 33;
        const RES_CONNECTION_SOCKET_CREATE_FAILURE = 11;
        const RES_PAYLOAD_FAILURE = 38;
        
        const OPT_COMPRESSION = -1001;
        const OPT_PREFIX_KEY = -1002;
        const OPT_SERIALIZER = -1003;
        const OPT_COMPRESSION_TYPE = -1004;
        const OPT_STORE_LOCK_WAIT = -1005;
        const OPT_STORE_LOCK_WAIT_MAX = -1006;
        const OPT_REMOVE_FAILED_SERVERS = -1007;
        const OPT_SERVER_FAILURE_LIMIT = -1008;
        const OPT_AUTO_EJECT_HOSTS = -1009;
        const OPT_HASH_WITH_PREFIX_KEY = -1010;
        const OPT_NOREPLY = -1011;
        const OPT_SORT_HOSTS = -1012;
        const OPT_VERIFY_KEY = -1013;
        const OPT_USE_UDP = -1014;
        const OPT_NUMBER_OF_REPLICAS = -1015;
        const OPT_RANDOMIZE_REPLICA_READ = -1016;
        const OPT_BLOCKING_IO = -1017;
        const OPT_SERVER_TIMEOUT_LIMIT = -1018;
        const OPT_CONNECT_TIMEOUT = -1019;
        const OPT_DEAD_TIMEOUT = -1021;
        const OPT_RECV_TIMEOUT = -1022;
        const OPT_POLL_TIMEOUT = -1023;
        const OPT_SEND_TIMEOUT = -1024;
        const OPT_TCP_NODELAY = -1025;
        const OPT_SOCKET_SEND_SIZE = -1026;
        const OPT_SOCKET_RECV_SIZE = -1027;
        const OPT_LIBKETAMA_COMPATIBLE = -1028;
        const OPT_BINARY_PROTOCOL = -1029;
        const OPT_NO_BLOCK = -1030;
        const OPT_TCP_KEEPALIVE = -1031;
        const OPT_BUFFER_REQUESTS = -1061;
        const OPT_USER_FLAGS = -1062;
        
        const SERIALIZER_PHP = 1;
        const SERIALIZER_IGBINARY = 2;
        const SERIALIZER_JSON = 3;
        const SERIALIZER_JSON_ARRAY = 4;
        
        const COMPRESSION_FASTLZ = 1;
        const COMPRESSION_ZLIB = 2;
        
        const HASH_DEFAULT = 0;
        const HASH_MD5 = 1;
        const HASH_CRC = 2;
        const HASH_FNV1_64 = 3;
        const HASH_FNV1A_64 = 4;
        const HASH_FNV1_32 = 5;
        const HASH_FNV1A_32 = 6;
        const HASH_HSIEH = 7;
        const HASH_MURMUR = 8;
        
        const DISTRIBUTION_MODULA = 0;
        const DISTRIBUTION_CONSISTENT = 1;
        
        public function __construct($persistent_id = '') {}
        public function addServer($host, $port, $weight = 0) { return true; }
        public function addServers($servers) { return true; }
        public function getServerByKey($server_key) { return array(); }
        public function getStats() { return array(); }
        public function getVersion() { return array(); }
        public function flush($delay = 0) { return true; }
        public function get($key, &$cas_token = null, &$flags = null) { return false; }
        public function getByKey($server_key, $key, &$cas_token = null, &$flags = null) { return false; }
        public function getMulti($keys, &$cas_tokens = null, $flags = null) { return false; }
        public function getMultiByKey($server_key, $keys, &$cas_tokens = null, $flags = null) { return false; }
        public function getDelayed($keys, $with_cas = null, $value_cb = null) { return true; }
        public function getDelayedByKey($server_key, $keys, $with_cas = null, $value_cb = null) { return true; }
        public function fetch() { return false; }
        public function fetchAll() { return array(); }
        public function set($key, $value, $expiration = 0) { return true; }
        public function setByKey($server_key, $key, $value, $expiration = 0) { return true; }
        public function setMulti($items, $expiration = 0) { return true; }
        public function setMultiByKey($server_key, $items, $expiration = 0) { return true; }
        public function cas($cas_token, $key, $value, $expiration = 0) { return true; }
        public function casByKey($cas_token, $server_key, $key, $value, $expiration = 0) { return true; }
        public function add($key, $value, $expiration = 0) { return true; }
        public function addByKey($server_key, $key, $value, $expiration = 0) { return true; }
        public function append($key, $value, $expiration = 0) { return true; }
        public function appendByKey($server_key, $key, $value, $expiration = 0) { return true; }
        public function prepend($key, $value, $expiration = 0) { return true; }
        public function prependByKey($server_key, $key, $value, $expiration = 0) { return true; }
        public function replace($key, $value, $expiration = 0) { return true; }
        public function replaceByKey($server_key, $key, $value, $expiration = 0) { return true; }
        public function delete($key, $time = 0) { return true; }
        public function deleteByKey($server_key, $key, $time = 0) { return true; }
        public function deleteMulti($keys, $time = 0) { return array(); }
        public function deleteMultiByKey($server_key, $keys, $time = 0) { return array(); }
        public function increment($key, $offset = 1, $initial_value = 0, $expiry = 0) { return false; }
        public function decrement($key, $offset = 1, $initial_value = 0, $expiry = 0) { return false; }
        public function getOption($option) { return null; }
        public function setOption($option, $value) { return true; }
        public function setOptions($options) { return true; }
        public function setBucket($host_map, $forward_map, $replicas) { return true; }
        public function quit() { return true; }
        public function getResultCode() { return 0; }
        public function getResultMessage() { return ''; }
        public function isPersistent() { return false; }
        public function isPristine() { return false; }
    }
}

// Redis扩展存根
if (!class_exists('Redis')) {
    /**
     * Redis类存根定义
     */
    class Redis {
        const AFTER = 'after';
        const BEFORE = 'before';
        const MULTI = 1;
        const PIPELINE = 2;
        
        public function __construct() {}
        public function connect($host, $port = 6379, $timeout = 0.0, $reserved = null, $retry_interval = 0, $read_timeout = 0.0) { return true; }
        public function pconnect($host, $port = 6379, $timeout = 0.0, $persistent_id = null, $retry_interval = 0) { return true; }
        public function close() { return true; }
        public function ping() { return true; }
        public function echo($msg) { return $msg; }
        public function get($key) { return false; }
        public function set($key, $value, $timeout = 0) { return true; }
        public function setex($key, $timeout, $value) { return true; }
        public function psetex($key, $timeout, $value) { return true; }
        public function setnx($key, $value) { return true; }
        public function getSet($key, $value) { return false; }
        public function randomKey() { return ''; }
        public function rename($srcKey, $dstKey) { return true; }
        public function renameNx($srcKey, $dstKey) { return true; }
        public function getMultiple($keys) { return array(); }
        public function exists($key) { return 0; }
        public function delete($key1, $key2 = null, $key3 = null) { return 0; }
        public function del($key1, $key2 = null, $key3 = null) { return 0; }
        public function incr($key) { return 0; }
        public function incrBy($key, $value) { return 0; }
        public function incrByFloat($key, $value) { return 0.0; }
        public function decr($key) { return 0; }
        public function decrBy($key, $value) { return 0; }
        public function lPush($key, $value1, $value2 = null) { return 0; }
        public function rPush($key, $value1, $value2 = null) { return 0; }
        public function lPushx($key, $value) { return 0; }
        public function rPushx($key, $value) { return 0; }
        public function lPop($key) { return false; }
        public function rPop($key) { return false; }
        public function blPop($keys, $timeout) { return array(); }
        public function brPop($keys, $timeout) { return array(); }
        public function lLen($key) { return 0; }
        public function lSize($key) { return 0; }
        public function lIndex($key, $index) { return false; }
        public function lGet($key, $index) { return false; }
        public function lSet($key, $index, $value) { return true; }
        public function lRange($key, $start, $end) { return array(); }
        public function lGetRange($key, $start, $end) { return array(); }
        public function lTrim($key, $start, $stop) { return true; }
        public function listTrim($key, $start, $stop) { return true; }
        public function lRem($key, $value, $count) { return 0; }
        public function lRemove($key, $value, $count) { return 0; }
        public function lInsert($key, $position, $pivot, $value) { return 0; }
        public function sAdd($key, $value1, $value2 = null, $valueN = null) { return 0; }
        public function sRem($key, $value1, $value2 = null, $valueN = null) { return 0; }
        public function sRemove($key, $value1, $value2 = null, $valueN = null) { return 0; }
        public function sMove($srcKey, $dstKey, $member) { return true; }
        public function sIsMember($key, $value) { return false; }
        public function sContains($key, $value) { return false; }
        public function sCard($key) { return 0; }
        public function sPop($key) { return false; }
        public function sRandMember($key, $count = null) { return false; }
        public function sInter($key1, $key2, $keyN = null) { return array(); }
        public function sInterStore($dstKey, $key1, $key2, $keyN = null) { return 0; }
        public function sUnion($key1, $key2, $keyN = null) { return array(); }
        public function sUnionStore($dstKey, $key1, $key2, $keyN = null) { return 0; }
        public function sDiff($key1, $key2, $keyN = null) { return array(); }
        public function sDiffStore($dstKey, $key1, $key2, $keyN = null) { return 0; }
        public function sMembers($key) { return array(); }
        public function sGetMembers($key) { return array(); }
        public function sScan($key, &$iterator, $pattern = null, $count = 0) { return array(); }
        public function select($db) { return true; }
        public function move($key, $dbindex) { return true; }
        public function flushAll($async = null) { return true; }
        public function flushDB($async = null) { return true; }
        public function info($section = null) { return array(); }
        public function resetStat() { return true; }
        public function save() { return true; }
        public function bgsave() { return true; }
        public function lastSave() { return 0; }
        public function bgrewriteaof() { return true; }
        public function dbsize() { return 0; }
        public function auth($password) { return true; }
        public function ttl($key) { return 0; }
        public function pttl($key) { return 0; }
        public function persist($key) { return true; }
        public function expire($key, $timeout) { return true; }
        public function expireAt($key, $timestamp) { return true; }
        public function pexpire($key, $milliseconds) { return true; }
        public function pexpireAt($key, $timestamp) { return true; }
        public function keys($pattern) { return array(); }
        public function getKeys($pattern) { return array(); }
        public function type($key) { return 0; }
        public function append($key, $value) { return 0; }
        public function getRange($key, $start, $end) { return ''; }
        public function setRange($key, $offset, $value) { return 0; }
        public function getBit($key, $offset) { return 0; }
        public function setBit($key, $offset, $value) { return 0; }
        public function strlen($key) { return 0; }
        public function bitcount($key) { return 0; }
        public function bitop($operation, $ret_key, $key1, $key2 = null, $key3 = null) { return 0; }
        public function sort($key, $option = null) { return array(); }
        public function sortAsc($key, $pattern = null, $get = null, $start = -1, $end = -1, $list = false) { return array(); }
        public function sortAscAlpha($key, $pattern = null, $get = null, $start = -1, $end = -1, $list = false) { return array(); }
        public function sortDesc($key, $pattern = null, $get = null, $start = -1, $end = -1, $list = false) { return array(); }
        public function sortDescAlpha($key, $pattern = null, $get = null, $start = -1, $end = -1, $list = false) { return array(); }
        public function zAdd($key, $score1, $value1, $score2 = null, $value2 = null, $scoreN = null, $valueN = null) { return 0; }
        public function zRange($key, $start, $end, $withscores = null) { return array(); }
        public function zRem($key, $member1, $member2 = null, $memberN = null) { return 0; }
        public function zDelete($key, $member1, $member2 = null, $memberN = null) { return 0; }
        public function zRangeByScore($key, $start, $end, $options = array()) { return array(); }
        public function zCount($key, $start, $end) { return 0; }
        public function zCard($key) { return 0; }
        public function zScore($key, $member) { return 0.0; }
        public function zRank($key, $member) { return 0; }
        public function zRevRank($key, $member) { return 0; }
        public function zIncrBy($key, $value, $member) { return 0.0; }
        public function zUnion($Output, $ZSetKeys, $Weights = null, $aggregateFunction = 'SUM') { return array(); }
        public function zInter($Output, $ZSetKeys, $Weights = null, $aggregateFunction = 'SUM') { return array(); }
        public function zScan($key, &$iterator, $pattern = null, $count = 0) { return array(); }
        public function hSet($key, $hashKey, $value) { return 0; }
        public function hSetNx($key, $hashKey, $value) { return 0; }
        public function hGet($key, $hashKey) { return false; }
        public function hLen($key) { return 0; }
        public function hDel($key, $hashKey1, $hashKey2 = null, $hashKeyN = null) { return 0; }
        public function hKeys($key) { return array(); }
        public function hVals($key) { return array(); }
        public function hGetAll($key) { return array(); }
        public function hExists($key, $hashKey) { return false; }
        public function hIncrBy($key, $hashKey, $value) { return 0; }
        public function hIncrByFloat($key, $hashKey, $value) { return 0.0; }
        public function hMset($key, $hashKeys) { return true; }
        public function hMGet($key, $hashKeys) { return array(); }
        public function hScan($key, &$iterator, $pattern = null, $count = 0) { return array(); }
        public function config($operation, $key, $value = null) { return array(); }
        public function eval($script, $args = array(), $numKeys = 0) { return null; }
        public function evalSha($scriptSha, $args = array(), $numKeys = 0) { return null; }
        public function script($command, $script = null) { return null; }
        public function getLastError() { return null; }
        public function clearLastError() { return true; }
        public function dump($key) { return false; }
        public function restore($key, $ttl, $value) { return true; }
        public function migrate($host, $port, $key, $db, $timeout, $copy = false, $replace = false) { return true; }
        public function object($info, $key) { return null; }
        public function unwatch() { return true; }
        public function watch($key) { return true; }
        public function multi($mode = 1) { return true; }
        public function exec() { return array(); }
        public function discard() { return true; }
        public function pipeline() { return true; }
        public function publish($channel, $message) { return 0; }
        public function subscribe($channels, $callback) { return array(); }
        public function psubscribe($patterns, $callback) { return array(); }
        public function unsubscribe($channels = null) { return array(); }
        public function punsubscribe($patterns = null) { return array(); }
        public function time() { return array(0, 0); }
        public function role() { return array(); }
        public function setOption($option, $value) { return true; }
        public function getOption($option) { return null; }
        public function client($cmd, $arg = null) { return null; }
    }
}

// APCu扩展存根
if (!class_exists('APCUIterator')) {
    // APCu常量定义
    if (!defined('APC_ITER_ALL')) {
        define('APC_ITER_ALL', 0xFFFFFFFF);
    }
    if (!defined('APC_ITER_TYPE')) {
        define('APC_ITER_TYPE', 1);
    }
    if (!defined('APC_ITER_KEY')) {
        define('APC_ITER_KEY', 2);
    }
    if (!defined('APC_ITER_VALUE')) {
        define('APC_ITER_VALUE', 4);
    }
    if (!defined('APC_ITER_NUM_HITS')) {
        define('APC_ITER_NUM_HITS', 8);
    }
    if (!defined('APC_ITER_MTIME')) {
        define('APC_ITER_MTIME', 16);
    }
    if (!defined('APC_ITER_TTL')) {
        define('APC_ITER_TTL', 32);
    }
    if (!defined('APC_LIST_ACTIVE')) {
        define('APC_LIST_ACTIVE', 1);
    }
    if (!defined('APC_LIST_DELETED')) {
        define('APC_LIST_DELETED', 2);
    }
    
    /**
     * APCUIterator类存根定义
     * 正确实现Iterator和Countable接口
     */
    class APCUIterator implements Iterator, Countable {
        // 内部状态变量
        private $position = 0;
        private $search;
        private $format;
        private $chunk_size;
        private $list;
        
        /**
         * 构造函数
         */
        public function __construct($search = null, $format = APC_ITER_ALL, $chunk_size = 100, $list = APC_LIST_ACTIVE) {
            $this->search = $search;
            $this->format = $format;
            $this->chunk_size = $chunk_size;
            $this->list = $list;
            $this->position = 0;
        }
        
        /**
         * Iterator接口方法 - 重置迭代器位置
         */
        public function rewind() {
            $this->position = 0;
        }
        
        /**
         * Iterator接口方法 - 检查当前位置是否有效
         */
        public function valid() {
            // 由于是存根实现，返回false表示没有有效数据
            return false;
        }
        
        /**
         * Iterator接口方法 - 获取当前键
         */
        public function key() {
            return $this->position;
        }
        
        /**
         * Iterator接口方法 - 获取当前值
         */
        public function current() {
            return null;
        }
        
        /**
         * Iterator接口方法 - 移动到下一个位置
         */
        public function next() {
            ++$this->position;
        }
        
        /**
         * Countable接口方法 - 获取元素数量
         */
        public function count() {
            return $this->getTotalCount();
        }
        
        // 以下是其他方法
        public function getTotalHits() { return 0; }
        public function getTotalSize() { return 0; }
        public function getTotalCount() { return 0; }
        public function getDeletedCount() { return 0; }
        public function getSlotCount() { return 0; }
        public function getMemoryUsage() { return 0; }
        public function getMemoryAvailable() { return 0; }
        public function getExpireTime() { return 0; }
        public function getCreationTime() { return 0; }
        public function getAccessTime() { return 0; }
        public function getRefCount() { return 0; }
        public function getTtl() { return 0; }
        public function getKey() { return ''; }
        public function getValue() { return null; }
        public function getFormat() { return $this->format; }
        public function getChunkSize() { return $this->chunk_size; }
        public function getList() { return $this->list; }
        public function getSearch() { return $this->search; }
    }
}

// APCu函数存根
if (!function_exists('apcu_store')) {
    function apcu_store($key, $var = null, $ttl = 0) { return true; }
}

if (!function_exists('apcu_fetch')) {
    function apcu_fetch($key, &$success = null) { return false; }
}

if (!function_exists('apcu_delete')) {
    function apcu_delete($key) { return true; }
}

if (!function_exists('apcu_exists')) {
    function apcu_exists($key) { return false; }
}

if (!function_exists('apcu_clear_cache')) {
    function apcu_clear_cache() { return true; }
}

if (!function_exists('apcu_inc')) {
    function apcu_inc($key, $step = 1, &$success = null) { return false; }
}

if (!function_exists('apcu_dec')) {
    function apcu_dec($key, $step = 1, &$success = null) { return false; }
}

if (!function_exists('apcu_cache_info')) {
    function apcu_cache_info($limited = false) { return array(); }
}

if (!function_exists('apcu_sma_info')) {
    function apcu_sma_info($limited = false) { return array(); }
}

if (!function_exists('apcu_key_info')) {
    function apcu_key_info($key) { return array(); }
}

if (!function_exists('apcu_add')) {
    function apcu_add($key, $var = null, $ttl = 0) { return true; }
}

if (!function_exists('apcu_cas')) {
    function apcu_cas($key, $old, $new) { return true; }
}

?>