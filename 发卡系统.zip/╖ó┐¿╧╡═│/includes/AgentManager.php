<?php

/**
 * 代理管理器
 * 处理代理注册、审核、管理等功能
 */
class AgentManager extends BaseService {
    private $logger;
    
    public function __construct() {
        parent::__construct();
        $this->logger = Logger::getInstance();
        $this->config = new ConfigManager(); // 添加配置管理器初始化
    }
    
    /**
     * 获取系统配置
     */
    private function getSystemConfig($key, $default = null) {
        $config = $this->database->queryOne(
            "SELECT config_value FROM system_configs WHERE config_key = ?",
            array($key)
        );
        
        return $config ? $config['config_value'] : $default;
    }
    
    /**
     * 获取代理最大层级配置
     */
    private function getMaxAgentLevel() {
        return intval($this->getSystemConfig('agent_max_level', 2));
    }
    
    /**
     * 申请成为代理
     */
    public function applyAgent($userId, $data) {
        try {
            // 验证用户是否存在
            $user = $this->database->queryOne(
                "SELECT id, username, email, phone FROM users WHERE id = ? AND status = 'active'",
                array($userId)
            );
            
            if (!$user) {
                return $this->errorResponse('用户不存在');
            }
            
            // 检查是否已经是代理
            $existingAgent = $this->database->queryOne(
                "SELECT id FROM agents WHERE user_id = ? AND status IN ('pending', 'approved')",
                array($userId)
            );
            
            if ($existingAgent) {
                return $this->errorResponse('您已经是代理');
            }
            
            // 检查是否有待审核的申请
            $pendingApplication = $this->database->queryOne(
                "SELECT id FROM agent_applications WHERE user_id = ? AND status = 'pending'",
                array($userId)
            );
            
            if ($pendingApplication) {
                return $this->errorResponse('您已有待审核的代理申请');
            }
            
            // 验证必填字段
            $requiredFields = array('contact_name', 'contact_phone', 'contact_email');
            foreach ($requiredFields as $field) {
                if (empty($data[$field])) {
                    return $this->errorResponse("字段 {$field} 不能为空");
                }
            }
            
            // 验证手机号格式
            if (!preg_match('/^1[3-9]\d{9}$/', $data['contact_phone'])) {
                return $this->errorResponse('手机号格式不正确');
            }
            
            // 验证邮箱格式
            if (!filter_var($data['contact_email'], FILTER_VALIDATE_EMAIL)) {
                return $this->errorResponse('邮箱格式不正确');
            }
            
            // 处理上级代理
            $superiorId = null;
            $level = 1;
            
            if (!empty($data['superior_id'])) {
                $superior = $this->database->queryOne(
                    "SELECT id, level FROM agents WHERE id = ? AND status = 'approved'",
                    array($data['superior_id'])
                );
                
                if (!$superior) {
                    return $this->errorResponse('上级代理不存在或未激活');
                }
                
                // 检查层级限制
                $maxLevel = $this->getMaxAgentLevel();
                if ($superior['level'] >= $maxLevel) {
                    return $this->errorResponse('无法加入该代理，已达到最大层级');
                }
                
                $superiorId = $superior['id'];
                $level = $superior['level'] + 1;
            }
            
            $applicationData = array(
                'user_id' => $userId,
                'superior_id' => $superiorId,
                'level' => $level,
                'contact_name' => $data['contact_name'],
                'contact_phone' => $data['contact_phone'],
                'contact_email' => $data['contact_email'],
                'contact_address' => isset($data['contact_address']) ? $data['contact_address'] : '',
                'business_license' => isset($data['business_license']) ? $data['business_license'] : '',
                'id_card' => isset($data['id_card']) ? $data['id_card'] : '',
                'application_reason' => isset($data['application_reason']) ? $data['application_reason'] : '',
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            );
            
            $applicationId = $this->database->insert('agent_applications', $applicationData);
            
            if (!$applicationId) {
                return $this->errorResponse('代理申请提交失败');
            }
            
            return $this->successResponse(array(
                'application_id' => $applicationId,
                'message' => '代理申请已提交，请等待审核'
            ));
            
        } catch (Exception $e) {
            $this->logger->error("代理申请失败: " . $e->getMessage());
            return $this->errorResponse('代理申请失败：' . $e->getMessage());
        }
    }
    
    /**
     * 审核代理申请
     */
    public function reviewAgent($applicationId, $status, $reviewerId, $reviewNote = '') {
        try {
            // 验证申请是否存在且待审核
            $application = $this->database->queryOne(
                "SELECT * FROM agent_applications WHERE id = ? AND status = 'pending'",
                array($applicationId)
            );
            
            if (!$application) {
                return $this->errorResponse('代理申请不存在或已审核');
            }
            
            $this->database->beginTransaction();
            
            // 更新申请状态
            $this->database->update('agent_applications', 
                array(
                    'status' => $status,
                    'reviewer_id' => $reviewerId,
                    'review_note' => $reviewNote,
                    'reviewed_at' => date('Y-m-d H:i:s')
                ),
                array('id' => $applicationId)
            );
            
            // 如果审核通过，创建代理记录
            if ($status === 'approved') {
                // 从配置获取默认佣金率，添加默认值作为备选
                $defaultCommission = isset($this->config) ? 
                    $this->config->get('agent.default_commission_rate', 0.1) : 0.1;
                    
                $agentData = array(
                    'user_id' => $application['user_id'],
                    'superior_id' => $application['superior_id'],
                    'level' => $application['level'],
                    'contact_name' => $application['contact_name'],
                    'contact_phone' => $application['contact_phone'],
                    'contact_email' => $application['contact_email'],
                    'contact_address' => $application['contact_address'],
                    'business_license' => $application['business_license'],
                    'id_card' => $application['id_card'],
                    'application_reason' => $application['application_reason'],
                    'commission_rate' => $defaultCommission,
                    'status' => 'active',
                    'created_at' => date('Y-m-d H:i:s')
                );
                
                $agentId = $this->database->insert('agents', $agentData);
                
                if (!$agentId) {
                    throw new Exception('创建代理记录失败');
                }
                
                // 更新用户角色
                $this->database->update('users', 
                    array('role' => 'agent'), 
                    array('id' => $application['user_id'])
                );
                
                $this->database->commit();
                
                return $this->successResponse(array(
                'agent_id' => $agentId,
                'message' => '代理审核通过'
            ));
            } else {
                $this->database->commit();
                
                return $this->successResponse(array(
                    'message' => '代理申请已拒绝'
                ));
            }
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error('代理审核失败', array(
                'application_id' => $applicationId,
                'error' => $e->getMessage()
            ));
            return $this->errorResponse('代理审核失败：' . $e->getMessage());
        }
    }
    
    /**
     * 手动添加代理
     */
    public function addAgent($userId, $data) {
        try {
            // 验证用户是否存在
            $user = $this->database->queryOne(
                "SELECT id, username, email, phone FROM users WHERE id = ? AND status = 'active'",
                array($userId)
            );
            
            if (!$user) {
                return $this->errorResponse('用户不存在');
            }
            
            // 检查是否已经是代理
            $existingAgent = $this->database->queryOne(
                "SELECT id FROM agents WHERE user_id = ?",
                array($userId)
            );
            
            if ($existingAgent) {
                return $this->errorResponse('该用户已经是代理');
            }
            
            // 处理上级代理
            $superiorId = null;
            $level = 1;
            
            if (!empty($data['superior_id'])) {
                $superior = $this->database->queryOne(
                    "SELECT id, level FROM agents WHERE id = ? AND status = 'active'",
                    array($data['superior_id'])
                );
                
                if (!$superior) {
                    return $this->errorResponse('上级代理不存在或已达到最大层级');
                }
                
                // 检查层级限制
                $maxLevel = $this->getMaxAgentLevel();
                if ($superior['level'] >= $maxLevel) {
                    return $this->errorResponse('无法加入该代理，已达到最大层级');
                }
                
                $superiorId = $superior['id'];
                $level = $superior['level'] + 1;
            }
            
            $agentData = array(
                'user_id' => $userId,
                'superior_id' => $superiorId,
                'level' => $level,
                'contact_name' => isset($data['contact_name']) ? $data['contact_name'] : $user['username'],
                'contact_phone' => isset($data['contact_phone']) ? $data['contact_phone'] : $user['phone'],
                'contact_email' => isset($data['contact_email']) ? $data['contact_email'] : $user['email'],
                'contact_address' => isset($data['contact_address']) ? $data['contact_address'] : '',
                'business_license' => isset($data['business_license']) ? $data['business_license'] : '',
                'id_card' => isset($data['id_card']) ? $data['id_card'] : '',
                'application_reason' => isset($data['application_reason']) ? $data['application_reason'] : '',
                'commission_rate' => isset($data['commission_rate']) ? $data['commission_rate'] : $this->config->get('agent.default_commission_rate', 0.1),
                'status' => 'active',
                'created_at' => date('Y-m-d H:i:s')
            );
            
            $agentId = $this->database->insert('agents', $agentData);
            
            if (!$agentId) {
                return $this->errorResponse('代理添加失败');
            }
            
            // 更新用户角色
            $this->database->update('users', 
                array('role' => 'agent'), 
                array('id' => $userId)
            );
            
            return $this->successResponse(array(
                'agent_id' => $agentId,
                'message' => '代理添加成功'
            ));
            
        } catch (Exception $e) {
            $this->logger->error('Add agent failed', array(
                'user_id' => $userId,
                'error' => $e->getMessage()
            ));
            
            return $this->errorResponse('代理添加失败');
        }
    }
    
    /**
     * 获取代理列表
     */
    public function getAgents($filters = array(), $page = 1, $limit = 20) {
        try {
            $offset = ($page - 1) * $limit;
            
            // 构建查询条件
            $whereClause = "WHERE 1=1";
            $params = array();
            
            if (!empty($filters['status'])) {
                $whereClause .= " AND a.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['level'])) {
                $whereClause .= " AND a.level = ?";
                $params[] = $filters['level'];
            }
            
            if (!empty($filters['superior_id'])) {
                $whereClause .= " AND a.superior_id = ?";
                $params[] = $filters['superior_id'];
            }
            
            if (!empty($filters['search'])) {
                $whereClause .= " AND (u.username LIKE ? OR a.contact_name LIKE ? OR a.contact_phone LIKE ?)";
                $searchTerm = '%' . $filters['search'] . '%';
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }
            
            // 获取总数
            $countQuery = "
                SELECT COUNT(*) as total 
                FROM agents a 
                LEFT JOIN users u ON a.user_id = u.id 
                {$whereClause}
            ";
            $total = $this->database->queryOne($countQuery, $params)['total'];
            
            // 获取代理列表
            $query = "
                SELECT 
                    a.*,
                    u.username,
                    u.email,
                    u.status as user_status,
                    s.contact_name as superior_name,
                    (SELECT COUNT(*) FROM agents WHERE superior_id = a.id) as subordinates_count
                FROM agents a 
                LEFT JOIN users u ON a.user_id = u.id 
                LEFT JOIN agents s ON a.superior_id = s.id 
                {$whereClause}
                ORDER BY a.created_at DESC
                LIMIT ? OFFSET ?
            ";
            
            $params[] = $limit;
            $params[] = $offset;
            
            $agents = $this->database->query($query, $params);
            
            return $this->successResponse(array(
                'agents' => $agents,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                )
            ));
            
        } catch (Exception $e) {
            $this->logger->error('Get agents failed', array(
                'filters' => $filters,
                'error' => $e->getMessage()
            ));
            
            return $this->errorResponse('获取代理列表失败');
        }
    }
    
    /**
     * 获取代理详情
     */
    public function getAgent($agentId) {
        try {
            $query = "
                SELECT 
                    a.*,
                    u.username,
                    u.email,
                    u.phone,
                    u.status as user_status,
                    s.contact_name as superior_name,
                    s.contact_phone as superior_phone
                FROM agents a 
                LEFT JOIN users u ON a.user_id = u.id 
                LEFT JOIN agents s ON a.superior_id = s.id 
                WHERE a.id = ?
            ";
            
            $agent = $this->database->queryOne($query, array($agentId));
            
            if (!$agent) {
                return $this->errorResponse('代理不存在');
            }
            
            // 获取下级代理数量
            $subordinatesCount = $this->database->queryOne(
                "SELECT COUNT(*) as count FROM agents WHERE superior_id = ?",
                array($agentId)
            )['count'];
            
            $agent['subordinates_count'] = $subordinatesCount;
            
            return $this->successResponse($agent);
            
        } catch (Exception $e) {
            $this->logger->error('Get agent failed', array(
                'agent_id' => $agentId,
                'error' => $e->getMessage()
            ));
            
            return $this->errorResponse('获取代理详情失败');
        }
    }
    
    /**
     * 更新代理状态
     */
    public function updateAgentStatus($agentId, $status) {
        try {
            // 验证代理是否存在
            $agent = $this->database->queryOne(
                "SELECT id, user_id FROM agents WHERE id = ?",
                array($agentId)
            );
            
            if (!$agent) {
                return $this->errorResponse('代理不存在');
            }
            
            $this->database->beginTransaction();
            
            // 更新代理状态
            $this->database->update('agents', 
                array(
                    'status' => $status,
                    'updated_at' => date('Y-m-d H:i:s')
                ),
                array('id' => $agentId)
            );
            
            // 如果是禁用状态，同时禁用用户
            if ($status === 'disabled') {
                $this->database->update('users', 
                    array('status' => 'disabled'), 
                    array('id' => $agent['user_id'])
                );
            } elseif ($status === 'active') {
                $this->database->update('users', 
                    array('status' => 'active'), 
                    array('id' => $agent['user_id'])
                );
            }
            
            $this->database->commit();
            
            return $this->successResponse(array(
                'message' => '代理状态更新成功'
            ));
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error('Update agent status failed', array(
                'agent_id' => $agentId,
                'status' => $status,
                'error' => $e->getMessage()
            ));
            
            return $this->errorResponse('更新代理状态失败');
        }
    }
    
    /**
     * 根据推荐码获取代理
     */
    public function getAgentByReferralCode($referralCode) {
        try {
            $agent = $this->database->queryOne(
                "SELECT * FROM agents WHERE referral_code = ? AND status = 'active'",
                array($referralCode)
            );
            
            return $agent;
        } catch (Exception $e) {
            $this->logger->error('Get agent by referral code failed', array(
                'referral_code' => $referralCode,
                'error' => $e->getMessage()
            ));
            
            return null;
        }
    }
    
    /**
     * 获取代理关系树
     */
    public function getAgentTree($agentId) {
        try {
            $tree = array();
            $visited = array();
            
            $this->buildAgentTree($agentId, $tree, $visited);
            
            return $tree;
        } catch (Exception $e) {
            $this->logger->error('Get agent tree failed', array(
                'agent_id' => $agentId,
                'error' => $e->getMessage()
            ));
            
            return array();
        }
    }
    
    /**
     * 递归构建代理关系树
     */
    private function buildAgentTree($agentId, &$tree, &$visited, $level = 0, $maxLevel = null) {
        // 如果未指定最大层级，从配置中获取
        if ($maxLevel === null) {
            $maxLevel = $this->getMaxAgentLevel();
        }
        if (in_array($agentId, $visited)) {
            return;
        }
        
        $visited[] = $agentId;
        
        $agent = $this->database->queryOne(
            "SELECT a.*, u.username, u.email 
             FROM agents a 
             LEFT JOIN users u ON a.user_id = u.id 
             WHERE a.id = ?",
            array($agentId)
        );
        
        if (!$agent) {
            return;
        }
        
        $agent['level'] = $level;
        $agent['subordinates'] = array();
        
        // 获取下级代理
        $subordinates = $this->database->query(
            "SELECT a.*, u.username, u.email 
             FROM agents a 
             LEFT JOIN users u ON a.user_id = u.id 
             WHERE a.superior_id = ? AND a.status = 'active'",
            array($agentId)
        );
        
        foreach ($subordinates as $subordinate) {
            $this->buildAgentTree($subordinate['id'], $agent['subordinates'], $visited, $level + 1);
        }
        
        $tree[] = $agent;
    }
    
    /**
     * 获取层级统计
     */
    public function getLevelStats($agentId) {
        try {
            $stats = array(
                'total_subordinates' => 0,
                'level_1_count' => 0,
                'level_2_count' => 0,
                'total_sales' => 0,
                'total_commission' => 0
            );
            
            // 获取直接下级
            $level1Agents = $this->database->query(
                "SELECT id, total_sales, total_commission FROM agents WHERE superior_id = ? AND status = 'active'",
                array($agentId)
            );
            
            $stats['level_1_count'] = count($level1Agents);
            $stats['total_subordinates'] += $stats['level_1_count'];
            
            foreach ($level1Agents as $agent) {
                $stats['total_sales'] += $agent['total_sales'];
                $stats['total_commission'] += $agent['total_commission'];
                
                // 获取二级下级
                $level2Agents = $this->database->query(
                    "SELECT id, total_sales, total_commission FROM agents WHERE superior_id = ? AND status = 'active'",
                    array($agent['id'])
                );
                
                $stats['level_2_count'] += count($level2Agents);
                $stats['total_subordinates'] += $stats['level_2_count'];
                
                foreach ($level2Agents as $level2Agent) {
                    $stats['total_sales'] += $level2Agent['total_sales'];
                    $stats['total_commission'] += $level2Agent['total_commission'];
                    
                    // 不再支持三级代理，代理最多支持二级分销
                }
            }
            
            return $stats;
        } catch (Exception $e) {
            $this->logger->error('Get level stats failed', array(
                'agent_id' => $agentId,
                'error' => $e->getMessage()
            ));
            
            return array();
        }
    }
    
    /**
     * 检查是否会形成循环代理关系
     */
    public function wouldCreateCircularReference($agentId, $newParentId) {
        try {
            $currentAgent = $newParentId;
            $visited = array();
            
            while ($currentAgent && !in_array($currentAgent, $visited)) {
                $visited[] = $currentAgent;
                
                if ($currentAgent == $agentId) {
                    return true; // 会形成循环
                }
                
                $parent = $this->database->queryOne(
                    "SELECT superior_id FROM agents WHERE id = ?",
                    array($currentAgent)
                );
                
                $currentAgent = $parent ? $parent['superior_id'] : null;
            }
            
            return false;
        } catch (Exception $e) {
            $this->logger->error('Check circular reference failed', array(
                'agent_id' => $agentId,
                'new_parent_id' => $newParentId,
                'error' => $e->getMessage()
            ));
            
            return true; // 出错时保守处理
        }
    }
    
    /**
     * 更新代理层级关系
     */
    public function updateAgentHierarchy($agentId, $newParentId) {
        try {
            $this->database->beginTransaction();
            
            // 获取当前代理信息
            $currentAgent = $this->database->queryOne(
                "SELECT * FROM agents WHERE id = ?",
                array($agentId)
            );
            
            if (!$currentAgent) {
                throw new Exception('代理不存在');
            }
            
            // 计算新的层级
            $newLevel = 1;
            if ($newParentId) {
                $parentAgent = $this->database->queryOne(
                    "SELECT level FROM agents WHERE id = ? AND status = 'active'",
                    array($newParentId)
                );
                
                if (!$parentAgent) {
                    throw new Exception('上级代理不存在或未激活');
                }
                
                $newLevel = $parentAgent['level'] + 1;
                
                // 检查层级限制
                $maxLevel = $this->getMaxAgentLevel();
                if ($newLevel > $maxLevel) {
                    throw new Exception('超过最大层级限制');
                }
            }
            
            // 更新代理关系
            $this->database->update('agents', array(
                'superior_id' => $newParentId,
                'level' => $newLevel,
                'updated_at' => date('Y-m-d H:i:s')
            ), 'id = ?', array($agentId));
            
            $this->database->commit();
            
            return array(
                'agent_id' => $agentId,
                'new_parent_id' => $newParentId,
                'new_level' => $newLevel,
                'message' => '代理层级关系更新成功'
            );
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error('Update agent hierarchy failed', array(
                'agent_id' => $agentId,
                'new_parent_id' => $newParentId,
                'error' => $e->getMessage()
            ));
            
            throw $e;
        }
    }
    
    /**
     * 生成推广链接
     */
    public function generateReferralLink($agentId) {
        try {
            $agent = $this->database->queryOne(
                "SELECT referral_code FROM agents WHERE id = ?",
                array($agentId)
            );
            
            if (!$agent) {
                throw new Exception('代理不存在');
            }
            
            $baseUrl = $this->config->get('app.base_url', 'http://localhost');
            $referralLink = $baseUrl . '/register?ref=' . $agent['referral_code'];
            
            return $referralLink;
        } catch (Exception $e) {
            $this->logger->error('Generate referral link failed', array(
                'agent_id' => $agentId,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    
    /**
     * 跟踪推广链接点击
     */
    public function trackReferralClick($referralCode, $ipAddress, $userAgent) {
        try {
            // 验证推荐码
            $agent = $this->database->queryOne(
                "SELECT id FROM agents WHERE referral_code = ? AND status = 'active'",
                array($referralCode)
            );
            
            if (!$agent) {
                throw new Exception('无效的推荐码');
            }
            
            // 记录点击
            $this->database->insert('referral_clicks', array(
                'agent_id' => $agent['id'],
                'referral_code' => $referralCode,
                'ip_address' => $ipAddress,
                'user_agent' => $userAgent,
                'clicked_at' => date('Y-m-d H:i:s')
            ));
            
            return array(
                'agent_id' => $agent['id'],
                'message' => '推广链接点击记录成功'
            );
        } catch (Exception $e) {
            $this->logger->error('Track referral click failed', array(
                'referral_code' => $referralCode,
                'ip_address' => $ipAddress,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
    
    /**
     * 获取推广统计
     */
    public function getReferralStats($agentId, $startDate = '', $endDate = '') {
        try {
            $whereClause = "WHERE agent_id = ?";
            $params = array($agentId);
            
            if ($startDate) {
                $whereClause .= " AND clicked_at >= ?";
                $params[] = $startDate . ' 00:00:00';
            }
            
            if ($endDate) {
                $whereClause .= " AND clicked_at <= ?";
                $params[] = $endDate . ' 23:59:59';
            }
            
            // 获取点击统计
            $clickStats = $this->database->queryOne(
                "SELECT COUNT(*) as total_clicks, COUNT(DISTINCT ip_address) as unique_clicks 
                 FROM referral_clicks {$whereClause}",
                $params
            );
            
            // 获取注册统计
            $registerStats = $this->database->queryOne(
                "SELECT COUNT(*) as total_registrations 
                 FROM users 
                 WHERE referral_code = (SELECT referral_code FROM agents WHERE id = ?) 
                 AND created_at >= ? AND created_at <= ?",
                array($agentId, $startDate ?: '1970-01-01', $endDate ?: '2099-12-31')
            );
            
            return array(
                'total_clicks' => $clickStats['total_clicks'],
                'unique_clicks' => $clickStats['unique_clicks'],
                'total_registrations' => $registerStats['total_registrations'],
                'conversion_rate' => $clickStats['total_clicks'] > 0 
                    ? round(($registerStats['total_registrations'] / $clickStats['total_clicks']) * 100, 2) 
                    : 0
            );
        } catch (Exception $e) {
            $this->logger->error('Get referral stats failed', array(
                'agent_id' => $agentId,
                'start_date' => $startDate,
                'end_date' => $endDate,
                'error' => $e->getMessage()
            ));
            throw $e;
        }
    }
}