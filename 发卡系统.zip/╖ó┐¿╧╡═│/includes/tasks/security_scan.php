<?php
/**
 * 安全扫描定时任务
 * 用于系统定期执行安全扫描和漏洞检测
 */

// 确保文件不被直接访问
if (!defined('BASE_PATH')) {
    die('Access denied');
}

require_once BASE_PATH . '/includes/security/SecurityScanner.php';

/**
 * 执行安全扫描任务
 * @return array 扫描结果
 */
function executeSecurityScanTask() {
    try {
        // 记录开始时间
        $startTime = microtime(true);
        
        // 检查是否应该执行扫描
        if (!shouldRunSecurityScan()) {
            return [
                'status' => 'skipped',
                'message' => '未到计划扫描时间或上次扫描结果仍有效'
            ];
        }
        
        // 执行扫描
        $results = SecurityScanner::runScheduledScan();
        
        // 记录执行结果
        logTaskExecution('security_scan', $results, microtime(true) - $startTime);
        
        return $results;
    } catch (Exception $e) {
        error_log('安全扫描任务执行失败: ' . $e->getMessage());
        return [
            'status' => 'error',
            'error' => $e->getMessage()
        ];
    }
}

/**
 * 检查是否应该执行安全扫描
 * @return bool 是否应该执行扫描
 */
function shouldRunSecurityScan() {
    // 获取配置
    $config = require BASE_PATH . '/includes/config/security.php';
    $lastScanFile = BASE_PATH . '/logs/last_security_scan.txt';
    $currentTime = time();
    
    // 检查是否强制执行
    if (isset($_GET['force']) && $_GET['force'] == 1) {
        return true;
    }
    
    // 如果文件不存在，应该执行扫描
    if (!file_exists($lastScanFile)) {
        return true;
    }
    
    // 获取上次扫描时间
    $lastScanTime = file_get_contents($lastScanFile);
    
    // 计算扫描间隔（默认24小时）
    $scanInterval = isset($config['scan']['interval']) ? $config['scan']['interval'] : 24 * 60 * 60;
    
    // 如果距离上次扫描时间超过配置的间隔，应该执行扫描
    return ($currentTime - $lastScanTime >= $scanInterval);
}

/**
 * 记录任务执行情况
 * @param string $taskName 任务名称
 * @param array $results 任务结果
 * @param float $duration 执行时间
 */
function logTaskExecution($taskName, $results, $duration) {
    $logFile = BASE_PATH . '/logs/task_execution.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $logEntry = date('Y-m-d H:i:s') . " - 任务: {$taskName}, " .
               "状态: {$results['status']}, " .
               "耗时: " . number_format($duration, 2) . " 秒, " .
               "严重问题: " . ($results['critical_issues'] ?? 0) . ", " .
               "高风险问题: " . ($results['high_issues'] ?? 0) . "\n";
    
    file_put_contents($logFile, $logEntry, FILE_APPEND);
}

/**
 * 注册安全扫描任务到任务调度系统
 */
function registerSecurityScanTask() {
    return [
        'name' => 'security_scan',
        'description' => '系统安全扫描和漏洞检测',
        'function' => 'executeSecurityScanTask',
        'schedule' => 'daily',
        'priority' => 'high',
        'enabled' => true
    ];
}

// 当文件被直接调用时执行扫描
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    $results = executeSecurityScanTask();
    echo "安全扫描任务执行完成: " . json_encode($results, JSON_PRETTY_PRINT);
}

// 注册任务
task_register(registerSecurityScanTask());