<?php

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Logger.php';

/**
 * 数据库查询优化类
 * 提供优化的查询方法和性能监控
 */
class QueryOptimizer extends BaseService
{
    protected $database;
    private $queryLog = array();
    private $slowQueryThreshold = 1000; // 毫秒

    public function __construct($database = null)
    {
        parent::__construct();
        if ($database) {
            $this->database = $database;
        } else {
            // 如果没有提供数据库实例，则使用单例
            require_once __DIR__ . '/Database.php';
            $this->database = Database::getInstance();
        }
    }

    /**
     * 记录查询性能
     */
    private function logQueryPerformance($sql, $executionTime, $params = array())
    {
        $this->queryLog[] = array(
            'sql' => $sql,
            'execution_time' => $executionTime,
            'params' => $params,
            'timestamp' => microtime(true),
            'is_slow' => $executionTime > $this->slowQueryThreshold
        );

        // 如果是慢查询，记录到系统日志
        if ($executionTime > $this->slowQueryThreshold) {
            $this->logger->error("Slow Query detected: {$executionTime}ms - {$sql}");
        }
    }

    /**
     * 执行优化的查询
     */
    public function executeQuery($sql, $params = array(), $fetchMode = PDO::FETCH_ASSOC)
    {
        $startTime = microtime(true);
        
        try {
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetchAll($fetchMode);
            
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            $this->logQueryPerformance($sql, $executionTime, $params);
            
            return $result;
        } catch (PDOException $e) {
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            $this->logQueryPerformance($sql, $executionTime, $params);
            
            $this->logger->error("Query execution failed: " . $e->getMessage());
            throw new Exception("Query execution failed: " . $e->getMessage());
        }
    }

    /**
     * 执行优化的单行查询
     */
    public function executeSingleQuery($sql, $params = array(), $fetchMode = PDO::FETCH_ASSOC)
    {
        $startTime = microtime(true);
        
        try {
            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch($fetchMode);
            
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            $this->logQueryPerformance($sql, $executionTime, $params);
            
            return $result;
        } catch (PDOException $e) {
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            $this->logQueryPerformance($sql, $executionTime, $params);
            
            throw new Exception("Query execution failed: " . $e->getMessage());
        }
    }

    /**
     * 优化的卡片搜索查询
     */
    public function searchCardsOptimized($searchTerm = '', $status = '', $limit = 50, $offset = 0)
    {
        $sql = "
            SELECT 
                c.id,
                c.card_number,
                c.cardholder_name,
                c.status,
                c.created_at,
                c.expiry_date,
                u.username as created_by_name,
                CASE 
                    WHEN c.expiry_date < CURDATE() THEN 'expired'
                    WHEN c.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'expiring_soon'
                    ELSE 'valid'
                END as expiry_status
            FROM cards c
            LEFT JOIN users u ON c.created_by = u.id
            WHERE 1=1
        ";
        
        $params = array();
        
        if (!empty($searchTerm)) {
            $sql .= " AND (c.card_number LIKE ? OR c.cardholder_name LIKE ?)";
            $searchParam = '%' . $searchTerm . '%';
            $params[] = $searchParam;
            $params[] = $searchParam;
        }
        
        if (!empty($status)) {
            $sql .= " AND c.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY c.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        return $this->executeQuery($sql, $params);
    }

    /**
     * 获取卡片总数（用于分页）
     */
    public function getCardsCountOptimized($searchTerm = '', $status = '')
    {
        $sql = "
            SELECT COUNT(*) as total
            FROM cards c
            WHERE 1=1
        ";
        
        $params = array();
        
        if (!empty($searchTerm)) {
            $sql .= " AND (c.card_number LIKE ? OR c.cardholder_name LIKE ?)";
            $searchParam = '%' . $searchTerm . '%';
            $params[] = $searchParam;
            $params[] = $searchParam;
        }
        
        if (!empty($status)) {
            $sql .= " AND c.status = ?";
            $params[] = $status;
        }
        
        $result = $this->executeSingleQuery($sql, $params);
        return isset($result['total']) ? $result['total'] : 0;
    }

    /**
     * 优化的系统日志查询
     */
    public function getSystemLogsOptimized($userId = null, $action = '', $startDate = '', $endDate = '', $limit = 100, $offset = 0)
    {
        $sql = "
            SELECT 
                sl.id,
                sl.user_id,
                u.username,
                sl.action,
                sl.description,
                sl.ip_address,
                sl.created_at,
                CASE 
                    WHEN sl.created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 'recent'
                    WHEN sl.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 'today'
                    ELSE 'older'
                END as time_category
            FROM system_logs sl
            LEFT JOIN users u ON sl.user_id = u.id
            WHERE 1=1
        ";
        
        $params = array();
        
        if ($userId) {
            $sql .= " AND sl.user_id = ?";
            $params[] = $userId;
        }
        
        if (!empty($action)) {
            $sql .= " AND sl.action = ?";
            $params[] = $action;
        }
        
        if (!empty($startDate)) {
            $sql .= " AND DATE(sl.created_at) >= ?";
            $params[] = $startDate;
        }
        
        if (!empty($endDate)) {
            $sql .= " AND DATE(sl.created_at) <= ?";
            $params[] = $endDate;
        }
        
        $sql .= " ORDER BY sl.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        return $this->executeQuery($sql, $params);
    }

    /**
     * 获取日志总数
     */
    public function getSystemLogsCountOptimized($userId = null, $action = '', $startDate = '', $endDate = '')
    {
        $sql = "
            SELECT COUNT(*) as total
            FROM system_logs sl
            WHERE 1=1
        ";
        
        $params = array();
        
        if ($userId) {
            $sql .= " AND sl.user_id = ?";
            $params[] = $userId;
        }
        
        if (!empty($action)) {
            $sql .= " AND sl.action = ?";
            $params[] = $action;
        }
        
        if (!empty($startDate)) {
            $sql .= " AND DATE(sl.created_at) >= ?";
            $params[] = $startDate;
        }
        
        if (!empty($endDate)) {
            $sql .= " AND DATE(sl.created_at) <= ?";
            $params[] = $endDate;
        }
        
        $result = $this->executeSingleQuery($sql, $params);
        return isset($result['total']) ? $result['total'] : 0;
    }

    /**
     * 优化的用户活动统计
     */
    public function getUserActivityStatsOptimized($userId, $days = 30)
    {
        $sql = "
            SELECT 
                u.id,
                u.username,
                u.role,
                COUNT(DISTINCT sl.id) as total_activities,
                COUNT(DISTINCT CASE WHEN sl.action LIKE '%login%' THEN sl.id END) as login_count,
                COUNT(DISTINCT CASE WHEN sl.action LIKE '%card%' THEN sl.id END) as card_activities,
                COUNT(DISTINCT CASE WHEN sl.action LIKE '%verification%' THEN sl.id END) as verification_activities,
                MAX(sl.created_at) as last_activity,
                COUNT(DISTINCT iv.id) as verifications_created,
                COUNT(DISTINCT ca.id) as cards_activated
            FROM users u
            LEFT JOIN system_logs sl ON u.id = sl.user_id 
                AND sl.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            LEFT JOIN identity_verifications iv ON u.id = iv.created_by
                AND iv.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            LEFT JOIN card_activations ca ON u.id = ca.activated_by
                AND ca.activation_date >= DATE_SUB(NOW(), INTERVAL ? DAY)
            WHERE u.id = ?
            GROUP BY u.id, u.username, u.role
        ";
        
        $params = array($days, $days, $days, $userId);
        return $this->executeSingleQuery($sql, $params);
    }

    /**
     * 优化的身份核验查询
     */
    public function getIdentityVerificationsOptimized($status = '', $userId = null, $limit = 50, $offset = 0)
    {
        $sql = "
            SELECT 
                iv.id,
                iv.card_id,
                c.card_number as card_number_masked,
                iv.cardholder_name as cardholder_name_masked,
                iv.status,
                iv.verification_type,
                iv.created_at,
                creator.username as creator_name,
                reviewer.username as reviewer_name,
                vr.review_date,
                vr.review_level,
                ca.status as activation_status,
                ca.activation_date
            FROM identity_verifications iv
            LEFT JOIN cards c ON iv.card_id = c.id
            LEFT JOIN users creator ON iv.created_by = creator.id
            LEFT JOIN verification_reviews vr ON iv.id = vr.verification_id
            LEFT JOIN users reviewer ON vr.reviewer_id = reviewer.id
            LEFT JOIN card_activations ca ON iv.id = ca.verification_id
            WHERE 1=1
        ";
        
        $params = array();
        
        if (!empty($status)) {
            $sql .= " AND iv.status = ?";
            $params[] = $status;
        }
        
        if ($userId) {
            $sql .= " AND iv.created_by = ?";
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY iv.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        return $this->executeQuery($sql, $params);
    }

    /**
     * 获取仪表板统计数据
     */
    public function getDashboardStatsOptimized()
    {
        $sql = "
            SELECT 
                (SELECT COUNT(*) FROM users WHERE status = 'active') as active_users,
                (SELECT COUNT(*) FROM cards WHERE status = 'active') as active_cards,
                (SELECT COUNT(*) FROM cards WHERE expiry_date < CURDATE()) as expired_cards,
                (SELECT COUNT(*) FROM cards WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as expiring_soon,
                (SELECT COUNT(*) FROM identity_verifications WHERE status = 'pending') as pending_verifications,
                (SELECT COUNT(*) FROM card_activations WHERE status = 'pending') as pending_activations,
                (SELECT COUNT(*) FROM system_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as activities_today,
                (SELECT COUNT(*) FROM user_sessions WHERE status = 'active' AND expires_at > NOW()) as active_sessions
        ";
        
        return $this->executeSingleQuery($sql);
    }

    /**
     * 获取查询性能统计
     */
    public function getQueryPerformanceStats()
    {
        if (empty($this->queryLog)) {
            return array(
                'total_queries' => 0,
                'avg_execution_time' => 0,
                'slow_queries' => 0,
                'fastest_query' => 0,
                'slowest_query' => 0
            );
        }
        
        $totalQueries = count($this->queryLog);
        $totalTime = array_sum(array_column($this->queryLog, 'execution_time'));
        $slowQueries = count(array_filter($this->queryLog, function($q) { return $q['is_slow']; }));
        $executionTimes = array_column($this->queryLog, 'execution_time');
        
        return array(
            'total_queries' => $totalQueries,
            'avg_execution_time' => round($totalTime / $totalQueries, 2),
            'slow_queries' => $slowQueries,
            'slow_query_rate' => round(($slowQueries / $totalQueries) * 100, 2),
            'fastest_query' => min($executionTimes),
            'slowest_query' => max($executionTimes)
        );
    }

    /**
     * 获取慢查询详情
     */
    public function getSlowQueries()
    {
        return array_filter($this->queryLog, function($q) { return $q['is_slow']; });
    }

    /**
     * 清理查询日志
     */
    public function clearQueryLog()
    {
        $this->queryLog = array();
    }

    /**
     * 批量插入优化
     */
    public function batchInsertOptimized($table, $data, $batchSize = 1000)
    {
        if (empty($data)) {
            return 0;
        }
        
        $columns = array_keys($data[0]);
        $placeholders = implode(',', array_fill(0, count($columns), '?'));
        $sql = "INSERT INTO {$table} (" . implode(',', $columns) . ") VALUES ({$placeholders})";
        
        $totalInserted = 0;
        $batches = array_chunk($data, $batchSize);
        
        foreach ($batches as $batch) {
            $this->database->beginTransaction();
            
            try {
                $stmt = $this->database->prepare($sql);
                
                foreach ($batch as $row) {
                    $stmt->execute(array_values($row));
                    $totalInserted++;
                }
                
                $this->database->commit();
            } catch (Exception $e) {
                $this->database->rollback();
                throw $e;
            }
        }
        
        return $totalInserted;
    }

    /**
     * 数据库健康检查
     */
    public function performHealthCheck()
    {
        $health = array(
            'status' => 'healthy',
            'issues' => array(),
            'recommendations' => array()
        );
        
        try {
            // 检查表大小
            $tableSizeSql = "
                SELECT 
                    TABLE_NAME,
                    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) as size_mb
                FROM information_schema.TABLES 
                WHERE TABLE_SCHEMA = DATABASE()
                ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC
                LIMIT 10
            ";
            
            $largeTables = $this->executeQuery($tableSizeSql);
            
            foreach ($largeTables as $table) {
                if ($table['size_mb'] > 100) { // 超过100MB的表
                    $health['issues'][] = "Table {$table['TABLE_NAME']} is large ({$table['size_mb']} MB)";
                    $health['recommendations'][] = "Consider archiving old data from {$table['TABLE_NAME']}";
                }
            }
            
            // 检查索引使用情况
            $indexSql = "
                SELECT 
                    TABLE_NAME,
                    INDEX_NAME,
                    CARDINALITY
                FROM information_schema.STATISTICS 
                WHERE TABLE_SCHEMA = DATABASE()
                AND CARDINALITY = 0
                AND INDEX_NAME != 'PRIMARY'
            ";
            
            $unusedIndexes = $this->executeQuery($indexSql);
            
            if (!empty($unusedIndexes)) {
                $health['issues'][] = "Found " . count($unusedIndexes) . " potentially unused indexes";
                $health['recommendations'][] = "Review and remove unused indexes to improve write performance";
            }
            
            // 检查查询性能
            $perfStats = $this->getQueryPerformanceStats();
            
            if ($perfStats['slow_query_rate'] > 10) { // 慢查询率超过10%
                $health['issues'][] = "High slow query rate: {$perfStats['slow_query_rate']}%";
                $health['recommendations'][] = "Optimize slow queries and review indexing strategy";
            }
            
            if (!empty($health['issues'])) {
                $health['status'] = 'warning';
            }
            
        } catch (Exception $e) {
            $health['status'] = 'error';
            $health['issues'][] = 'Health check failed: ' . $e->getMessage();
        }
        
        return $health;
    }
}