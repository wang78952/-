<?php
/**
 * 日志管理器
 * 提供结构化日志记录、多级别日志、敏感数据过滤和灵活的日志配置功能
 */

namespace ExceptionHandler;

class LogManager {
    // 日志级别常量
    const LOG_LEVEL_DEBUG = 100;
    const LOG_LEVEL_INFO = 200;
    const LOG_LEVEL_NOTICE = 250;
    const LOG_LEVEL_WARNING = 300;
    const LOG_LEVEL_ERROR = 400;
    const LOG_LEVEL_CRITICAL = 500;
    const LOG_LEVEL_ALERT = 550;
    const LOG_LEVEL_EMERGENCY = 600;
    
    // 日志通道常量
    const CHANNEL_DEFAULT = 'default';
    const CHANNEL_ERROR = 'error';
    const CHANNEL_API = 'api';
    const CHANNEL_DATABASE = 'database';
    const CHANNEL_PAYMENT = 'payment';
    const CHANNEL_FILE = 'file';
    const CHANNEL_SECURITY = 'security';
    const CHANNEL_ACCESS = 'access';
    
    // 日志格式常量
    const FORMAT_TEXT = 'text';
    const FORMAT_JSON = 'json';
    const FORMAT_CSV = 'csv';
    
    // 日志输出方式常量
    const OUTPUT_FILE = 1;
    const OUTPUT_CONSOLE = 2;
    const OUTPUT_SYSLOG = 3;
    const OUTPUT_ALL = 7; // 位掩码：1 | 2 | 3
    
    // 单例实例
    private static $instance;
    
    // 配置信息
    private $config = [
        'default_channel' => self::CHANNEL_DEFAULT,
        'log_format' => self::FORMAT_JSON,
        'output' => self::OUTPUT_FILE | self::OUTPUT_CONSOLE,
        'date_format' => 'Y-m-d H:i:s.u',
        'log_dir' => __DIR__ . '/../../logs',
        'max_file_size' => 10485760, // 10MB
        'max_files' => 10,
        'debug' => false,
        'mask_sensitive_data' => true,
        'environment' => 'production'
    ];
    
    // 通道配置
    private $channels = [
        self::CHANNEL_DEFAULT => [
            'level' => self::LOG_LEVEL_INFO,
            'file' => 'app.log'
        ],
        self::CHANNEL_ERROR => [
            'level' => self::LOG_LEVEL_ERROR,
            'file' => 'error.log'
        ],
        self::CHANNEL_API => [
            'level' => self::LOG_LEVEL_INFO,
            'file' => 'api.log'
        ],
        self::CHANNEL_DATABASE => [
            'level' => self::LOG_LEVEL_INFO,
            'file' => 'database.log'
        ],
        self::CHANNEL_PAYMENT => [
            'level' => self::LOG_LEVEL_INFO,
            'file' => 'payment.log'
        ],
        self::CHANNEL_FILE => [
            'level' => self::LOG_LEVEL_INFO,
            'file' => 'file.log'
        ],
        self::CHANNEL_SECURITY => [
            'level' => self::LOG_LEVEL_WARNING,
            'file' => 'security.log'
        ],
        self::CHANNEL_ACCESS => [
            'level' => self::LOG_LEVEL_INFO,
            'file' => 'access.log'
        ]
    ];
    
    // 请求相关信息
    private $requestInfo = [];
    
    /**
     * 私有构造函数（单例模式）
     */
    private function __construct($config = []) {
        // 合并配置
        if (!empty($config)) {
            $this->config = array_merge($this->config, $config);
            
            // 合并通道配置
            if (isset($config['channels']) && is_array($config['channels'])) {
                foreach ($config['channels'] as $channel => $channelConfig) {
                    $this->channels[$channel] = array_merge(
                        $this->channels[$channel] ?? [],
                        $channelConfig
                    );
                }
            }
        }
        
        // 初始化日志目录
        $this->initLogDirectory();
        
        // 初始化请求信息
        $this->initRequestInfo();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance($config = []) {
        if (!isset(self::$instance)) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化日志目录
     */
    private function initLogDirectory() {
        if (!is_dir($this->config['log_dir'])) {
            mkdir($this->config['log_dir'], 0755, true);
        }
    }
    
    /**
     * 初始化请求信息
     */
    private function initRequestInfo() {
        $this->requestInfo = [
            'request_id' => $this->generateRequestId(),
            'client_ip' => $this->getClientIp(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '',
            'server_name' => isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '',
            'timestamp' => date($this->config['date_format'])
        ];
    }
    
    /**
     * 生成请求ID
     */
    private function generateRequestId() {
        $seed = microtime() . uniqid('', true);
        return substr(md5($seed), 0, 16) . '-' . substr(sha1($seed), 0, 8);
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIp() {
        $ipHeaders = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($ipHeaders as $header) {
            if (isset($_SERVER[$header])) {
                // 处理多个IP（代理情况）
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim(reset($ips));
                
                // 验证IP地址
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '127.0.0.1';
    }
    
    /**
     * 记录日志
     */
    public function log($level, $message, $context = [], $channel = null) {
        // 确定通道
        $channel = $channel ?: $this->config['default_channel'];
        
        // 检查通道配置
        if (!isset($this->channels[$channel])) {
            $channel = $this->config['default_channel'];
        }
        
        // 检查日志级别
        if ($level < $this->channels[$channel]['level']) {
            return false;
        }
        
        // 过滤敏感数据
        if ($this->config['mask_sensitive_data']) {
            $context = $this->filterSensitiveData($context);
        }
        
        // 构建日志条目
        $logEntry = $this->buildLogEntry($level, $message, $context, $channel);
        
        // 格式化日志
        $formattedLog = $this->formatLog($logEntry);
        
        // 输出日志
        $this->outputLog($formattedLog, $channel);
        
        return true;
    }
    
    /**
     * 构建日志条目
     */
    private function buildLogEntry($level, $message, $context, $channel) {
        // 构建日志条目
        $logEntry = [
            'timestamp' => date($this->config['date_format']),
            'level' => $this->getLevelName($level),
            'level_code' => $level,
            'message' => $message,
            'channel' => $channel,
            'environment' => $this->config['environment']
        ];
        
        // 添加请求信息
        $logEntry['request'] = $this->requestInfo;
        
        // 添加上下文信息
        if (!empty($context)) {
            $logEntry['context'] = $context;
        }
        
        // 添加系统信息
        $logEntry['system'] = [
            'php_version' => PHP_VERSION,
            'memory_usage' => memory_get_usage(true),
            'memory_limit' => ini_get('memory_limit'),
            'server_timezone' => date_default_timezone_get()
        ];
        
        // 在调试模式下添加更多信息
        if ($this->config['debug']) {
            $logEntry['debug'] = [
                'caller' => $this->getCallerInfo(),
                'trace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 10)
            ];
        }
        
        return $logEntry;
    }
    
    /**
     * 获取调用者信息
     */
    private function getCallerInfo() {
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 10);
        
        // 跳过前几帧（日志方法内部调用）
        for ($i = 0; $i < count($trace); $i++) {
            if (!isset($trace[$i]['class']) || $trace[$i]['class'] !== get_class($this)) {
                return [
                    'file' => $trace[$i]['file'] ?? 'unknown',
                    'line' => $trace[$i]['line'] ?? 0,
                    'function' => $trace[$i]['function'] ?? 'unknown',
                    'class' => $trace[$i]['class'] ?? '',
                    'type' => $trace[$i]['type'] ?? ''
                ];
            }
        }
        
        return ['file' => 'unknown', 'line' => 0, 'function' => 'unknown'];
    }
    
    /**
     * 获取日志级别名称
     */
    private function getLevelName($level) {
        $levels = [
            self::LOG_LEVEL_DEBUG => 'DEBUG',
            self::LOG_LEVEL_INFO => 'INFO',
            self::LOG_LEVEL_NOTICE => 'NOTICE',
            self::LOG_LEVEL_WARNING => 'WARNING',
            self::LOG_LEVEL_ERROR => 'ERROR',
            self::LOG_LEVEL_CRITICAL => 'CRITICAL',
            self::LOG_LEVEL_ALERT => 'ALERT',
            self::LOG_LEVEL_EMERGENCY => 'EMERGENCY'
        ];
        
        return $levels[$level] ?? 'UNKNOWN';
    }
    
    /**
     * 过滤敏感数据
     */
    private function filterSensitiveData($data) {
        // 如果不是数组或对象，直接返回
        if (!is_array($data) && !is_object($data)) {
            return $data;
        }
        
        // 将对象转换为数组
        if (is_object($data)) {
            $data = (array) $data;
        }
        
        // 敏感字段列表
        $sensitiveFields = [
            'password',
            'passwd',
            'secret',
            'token',
            'key',
            'api',
            'auth',
            'credit',
            'card',
            'cvv',
            'cvc',
            'ssn',
            'social',
            'account',
            'routing',
            'iban',
            'bic',
            'swift',
            'phone',
            'mobile',
            'email',
            'address',
            'birthdate',
            'passport',
            'license'
        ];
        
        // 递归过滤敏感数据
        foreach ($data as $key => &$value) {
            $keyLower = strtolower($key);
            
            // 检查是否包含敏感字段名
            foreach ($sensitiveFields as $sensitiveField) {
                if (strpos($keyLower, $sensitiveField) !== false) {
                    $value = '***REDACTED***';
                    break;
                }
            }
            
            // 递归过滤嵌套数据
            if (is_array($value) || is_object($value)) {
                $value = $this->filterSensitiveData($value);
            }
        }
        
        return $data;
    }
    
    /**
     * 格式化日志
     */
    private function formatLog($logEntry) {
        switch ($this->config['log_format']) {
            case self::FORMAT_JSON:
                return $this->formatJson($logEntry);
            case self::FORMAT_CSV:
                return $this->formatCsv($logEntry);
            case self::FORMAT_TEXT:
            default:
                return $this->formatText($logEntry);
        }
    }
    
    /**
     * 格式化为JSON
     */
    private function formatJson($logEntry) {
        return json_encode($logEntry, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
    /**
     * 格式化为CSV
     */
    private function formatCsv($logEntry) {
        $csvFields = [
            $logEntry['timestamp'],
            $logEntry['level'],
            $logEntry['channel'],
            $logEntry['message'],
            $logEntry['request']['request_id'],
            $logEntry['request']['client_ip'],
            $logEntry['request']['request_uri'],
            isset($logEntry['context']) ? json_encode($logEntry['context']) : ''
        ];
        
        $fp = fopen('php://temp', 'r+');
        fputcsv($fp, $csvFields);
        rewind($fp);
        $csv = fread($fp, 1024);
        fclose($fp);
        
        return trim($csv);
    }
    
    /**
     * 格式化为文本
     */
    private function formatText($logEntry) {
        $text = sprintf(
            '[%s] [%s] [%s] %s',
            $logEntry['timestamp'],
            $logEntry['channel'],
            $logEntry['level'],
            $logEntry['message']
        );
        
        // 添加请求ID
        $text .= ' (Request ID: ' . $logEntry['request']['request_id'] . ')';
        
        // 在调试模式下添加更多信息
        if ($this->config['debug'] && isset($logEntry['debug'])) {
            $text .= '\nCaller: ' . $logEntry['debug']['caller']['file'] . ':' . $logEntry['debug']['caller']['line'];
        }
        
        // 添加上下文信息
        if (isset($logEntry['context']) && !empty($logEntry['context'])) {
            $text .= '\nContext: ' . json_encode($logEntry['context'], JSON_UNESCAPED_UNICODE);
        }
        
        return $text;
    }
    
    /**
     * 输出日志
     */
    private function outputLog($formattedLog, $channel) {
        // 输出到文件
        if ($this->config['output'] & self::OUTPUT_FILE) {
            $this->writeToFile($formattedLog, $channel);
        }
        
        // 输出到控制台
        if ($this->config['output'] & self::OUTPUT_CONSOLE) {
            $this->writeToConsole($formattedLog);
        }
        
        // 输出到syslog
        if ($this->config['output'] & self::OUTPUT_SYSLOG) {
            $this->writeToSyslog($formattedLog, $channel);
        }
    }
    
    /**
     * 写入日志文件
     */
    private function writeToFile($formattedLog, $channel) {
        // 获取日志文件路径
        $logFilePath = $this->getLogFilePath($channel);
        
        // 检查是否需要轮转日志
        $this->checkLogRotation($logFilePath);
        
        // 写入日志文件
        error_log($formattedLog . "\n", 3, $logFilePath);
    }
    
    /**
     * 获取日志文件路径
     */
    private function getLogFilePath($channel) {
        // 获取通道配置
        $channelConfig = $this->channels[$channel] ?? $this->channels[self::CHANNEL_DEFAULT];
        
        // 构建日志文件路径
        return $this->config['log_dir'] . '/' . $channelConfig['file'];
    }
    
    /**
     * 检查日志文件轮转
     */
    private function checkLogRotation($logFilePath) {
        // 如果日志文件不存在，直接返回
        if (!file_exists($logFilePath)) {
            return;
        }
        
        // 检查文件大小
        if (filesize($logFilePath) >= $this->config['max_file_size']) {
            // 执行日志轮转
            $this->rotateLog($logFilePath);
        }
    }
    
    /**
     * 执行日志轮转
     */
    private function rotateLog($logFilePath) {
        // 关闭现有文件句柄
        if (is_resource(fopen($logFilePath, 'r'))) {
            @fclose(fopen($logFilePath, 'r'));
        }
        
        // 删除最旧的日志文件
        $maxIndex = $this->config['max_files'] - 1;
        if (file_exists($logFilePath . '.' . $maxIndex)) {
            unlink($logFilePath . '.' . $maxIndex);
        }
        
        // 轮转日志文件
        for ($i = $maxIndex - 1; $i >= 0; $i--) {
            if (file_exists($logFilePath . '.' . $i)) {
                rename($logFilePath . '.' . $i, $logFilePath . '.' . ($i + 1));
            }
        }
        
        // 重命名当前日志文件
        if (file_exists($logFilePath)) {
            rename($logFilePath, $logFilePath . '.0');
        }
    }
    
    /**
     * 写入控制台
     */
    private function writeToConsole($formattedLog) {
        error_log($formattedLog);
    }
    
    /**
     * 写入syslog
     */
    private function writeToSyslog($formattedLog, $channel) {
        // 将日志级别映射到syslog优先级
        $syslogPriorityMap = [
            self::LOG_LEVEL_DEBUG => LOG_DEBUG,
            self::LOG_LEVEL_INFO => LOG_INFO,
            self::LOG_LEVEL_NOTICE => LOG_NOTICE,
            self::LOG_LEVEL_WARNING => LOG_WARNING,
            self::LOG_LEVEL_ERROR => LOG_ERR,
            self::LOG_LEVEL_CRITICAL => LOG_CRIT,
            self::LOG_LEVEL_ALERT => LOG_ALERT,
            self::LOG_LEVEL_EMERGENCY => LOG_EMERG
        ];
        
        // 获取syslog优先级
        $priority = $syslogPriorityMap[$this->channels[$channel]['level']] ?? LOG_INFO;
        
        // 打开syslog连接
        openlog('card_system', LOG_ODELAY, LOG_USER);
        
        // 写入syslog
        syslog($priority, $formattedLog);
        
        // 关闭syslog连接
        closelog();
    }
    
    /**
     * 记录调试日志
     */
    public function debug($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_DEBUG, $message, $context, $channel);
    }
    
    /**
     * 记录信息日志
     */
    public function info($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_INFO, $message, $context, $channel);
    }
    
    /**
     * 记录通知日志
     */
    public function notice($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_NOTICE, $message, $context, $channel);
    }
    
    /**
     * 记录警告日志
     */
    public function warning($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_WARNING, $message, $context, $channel);
    }
    
    /**
     * 记录错误日志
     */
    public function error($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_ERROR, $message, $context, $channel);
    }
    
    /**
     * 记录严重错误日志
     */
    public function critical($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_CRITICAL, $message, $context, $channel);
    }
    
    /**
     * 记录警报日志
     */
    public function alert($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_ALERT, $message, $context, $channel);
    }
    
    /**
     * 记录紧急错误日志
     */
    public function emergency($message, $context = [], $channel = null) {
        return $this->log(self::LOG_LEVEL_EMERGENCY, $message, $context, $channel);
    }
    
    /**
     * 记录API访问日志
     */
    public function logApiAccess($endpoint, $method, $statusCode, $responseTime, $userId = 'guest') {
        $context = [
            'endpoint' => $endpoint,
            'method' => $method,
            'status_code' => $statusCode,
            'response_time' => $responseTime,
            'user_id' => $userId
        ];
        
        return $this->info('API Access', $context, self::CHANNEL_API);
    }
    
    /**
     * 记录数据库操作日志
     */
    public function logDatabaseOperation($query, $params = [], $executionTime = 0, $affectedRows = 0) {
        $context = [
            'query' => $this->maskQueryParams($query, $params),
            'execution_time' => $executionTime,
            'affected_rows' => $affectedRows
        ];
        
        return $this->info('Database Operation', $context, self::CHANNEL_DATABASE);
    }
    
    /**
     * 记录数据库错误日志
     */
    public function logDatabaseError($query, $error, $params = []) {
        $context = [
            'query' => $this->maskQueryParams($query, $params),
            'error' => $error
        ];
        
        return $this->error('Database Error', $context, self::CHANNEL_DATABASE);
    }
    
    /**
     * 记录支付操作日志
     */
    public function logPaymentOperation($operation, $orderId, $amount, $currency, $status) {
        $context = [
            'operation' => $operation,
            'order_id' => $orderId,
            'amount' => $amount,
            'currency' => $currency,
            'status' => $status
        ];
        
        return $this->info('Payment Operation', $context, self::CHANNEL_PAYMENT);
    }
    
    /**
     * 记录支付错误日志
     */
    public function logPaymentError($operation, $orderId, $error, $amount = null, $currency = null) {
        $context = [
            'operation' => $operation,
            'order_id' => $orderId,
            'error' => $error,
            'amount' => $amount,
            'currency' => $currency
        ];
        
        return $this->error('Payment Error', $context, self::CHANNEL_PAYMENT);
    }
    
    /**
     * 记录文件操作日志
     */
    public function logFileOperation($operation, $filePath, $size = null, $result = 'success') {
        $context = [
            'operation' => $operation,
            'file_path' => $filePath,
            'size' => $size,
            'result' => $result
        ];
        
        $level = ($result === 'success') ? self::LOG_LEVEL_INFO : self::LOG_LEVEL_ERROR;
        
        return $this->log($level, 'File Operation', $context, self::CHANNEL_FILE);
    }
    
    /**
     * 记录安全事件日志
     */
    public function logSecurityEvent($event, $details = [], $severity = 'medium') {
        $context = [
            'event' => $event,
            'details' => $details,
            'severity' => $severity
        ];
        
        // 根据严重程度设置日志级别
        $level = self::LOG_LEVEL_WARNING;
        if ($severity === 'high') {
            $level = self::LOG_LEVEL_ERROR;
        } elseif ($severity === 'critical') {
            $level = self::LOG_LEVEL_CRITICAL;
        }
        
        return $this->log($level, 'Security Event', $context, self::CHANNEL_SECURITY);
    }
    
    /**
     * 记录访问日志
     */
    public function logAccess($userId, $resource, $action, $result = 'success') {
        $context = [
            'user_id' => $userId,
            'resource' => $resource,
            'action' => $action,
            'result' => $result
        ];
        
        return $this->info('Access', $context, self::CHANNEL_ACCESS);
    }
    
    /**
     * 屏蔽查询参数中的敏感信息
     */
    private function maskQueryParams($query, $params) {
        if (!$this->config['mask_sensitive_data'] || empty($params)) {
            return $query;
        }
        
        // 敏感参数类型
        $sensitiveParamTypes = ['password', 'token', 'key', 'card', 'ssn'];
        
        // 复制查询
        $maskedQuery = $query;
        
        // 替换参数
        foreach ($params as $key => $value) {
            // 检查参数名是否包含敏感词
            $keyLower = strtolower($key);
            $isSensitive = false;
            
            foreach ($sensitiveParamTypes as $sensitiveType) {
                if (strpos($keyLower, $sensitiveType) !== false) {
                    $isSensitive = true;
                    break;
                }
            }
            
            // 如果是敏感参数，替换为掩码
            if ($isSensitive && $value !== null) {
                $maskedQuery = str_replace($value, '?', $maskedQuery);
            }
        }
        
        return $maskedQuery;
    }
    
    /**
     * 设置配置
     */
    public function setConfig($key, $value = null) {
        if (is_array($key)) {
            $this->config = array_merge($this->config, $key);
        } else {
            $this->config[$key] = $value;
        }
        
        return $this;
    }
    
    /**
     * 获取配置
     */
    public function getConfig($key = null) {
        if ($key === null) {
            return $this->config;
        }
        
        return $this->config[$key] ?? null;
    }
    
    /**
     * 设置通道配置
     */
    public function setChannelConfig($channel, $config) {
        if (!isset($this->channels[$channel])) {
            $this->channels[$channel] = [];
        }
        
        $this->channels[$channel] = array_merge($this->channels[$channel], $config);
        
        return $this;
    }
    
    /**
     * 获取通道配置
     */
    public function getChannelConfig($channel) {
        return $this->channels[$channel] ?? null;
    }
    
    /**
     * 设置请求信息
     */
    public function setRequestInfo($info) {
        $this->requestInfo = array_merge($this->requestInfo, $info);
        
        return $this;
    }
    
    /**
     * 获取请求ID
     */
    public function getRequestId() {
        return $this->requestInfo['request_id'];
    }
    
    /**
     * 刷新日志缓冲区
     */
    public function flush() {
        // 强制刷新PHP输出缓冲区
        ob_flush();
        flush();
        
        return $this;
    }
}