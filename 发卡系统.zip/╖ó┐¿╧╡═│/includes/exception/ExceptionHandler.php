<?php
/**
 * 统一异常处理器
 * 提供全面的异常捕获、处理、日志记录和错误响应功能
 */

namespace ExceptionHandler;

class ExceptionHandler {
    // 错误级别常量
    const ERROR_LEVEL_INFO = 1;
    const ERROR_LEVEL_WARNING = 2;
    const ERROR_LEVEL_ERROR = 3;
    const ERROR_LEVEL_CRITICAL = 4;
    const ERROR_LEVEL_EMERGENCY = 5;
    
    // 错误类型常量
    const ERROR_TYPE_VALIDATION = 'VALIDATION_ERROR';
    const ERROR_TYPE_DATABASE = 'DATABASE_ERROR';
    const ERROR_TYPE_PAYMENT = 'PAYMENT_ERROR';
    const ERROR_TYPE_FILE = 'FILE_ERROR';
    const ERROR_TYPE_API = 'API_ERROR';
    const ERROR_TYPE_SECURITY = 'SECURITY_ERROR';
    const ERROR_TYPE_SYSTEM = 'SYSTEM_ERROR';
    
    // 单例实例
    private static $instance;
    
    // 配置信息
    private $config = [
        'debug' => false,
        'error_log_path' => __DIR__ . '/../../logs/error.log',
        'request_id_header' => 'X-Request-ID',
        'user_id_header' => 'X-User-ID',
        'mask_sensitive_data' => true,
        'environment' => 'production'
    ];
    
    // 已处理的错误ID列表（防止重复处理）
    private $processedErrors = [];
    
    /**
     * 私有构造函数（单例模式）
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge($this->config, $config);
        
        // 确保日志目录存在
        $logDir = dirname($this->config['error_log_path']);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // 设置错误和异常处理器
        $this->setupErrorHandlers();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance($config = []) {
        if (!isset(self::$instance)) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 设置全局错误和异常处理器
     */
    private function setupErrorHandlers() {
        // 注册异常处理器
        set_exception_handler([$this, 'handleException']);
        
        // 注册错误处理器
        set_error_handler([$this, 'handleError']);
        
        // 注册致命错误处理器
        register_shutdown_function([$this, 'handleFatalError']);
    }
    
    /**
     * 生成唯一错误ID
     */
    public function generateErrorId($context = '') {
        $seed = microtime() . $context . mt_rand();
        return substr(md5($seed), 0, 16) . '-' . substr(sha1($seed), 0, 8);
    }
    
    /**
     * 从请求中获取请求ID
     */
    public function getRequestId() {
        $header = $this->config['request_id_header'];
        // 从HTTP头获取或生成新的
        if (isset($_SERVER['HTTP_' . strtoupper(str_replace('-', '_', $header))])) {
            return $_SERVER['HTTP_' . strtoupper(str_replace('-', '_', $header))];
        }
        
        // 生成新的请求ID
        return $this->generateErrorId('request');
    }
    
    /**
     * 处理异常
     */
    public function handleException($exception) {
        // 生成错误ID
        $errorId = $this->generateErrorId($exception->getMessage());
        
        // 检查是否已处理
        if (in_array($errorId, $this->processedErrors)) {
            return;
        }
        $this->processedErrors[] = $errorId;
        
        // 确定错误类型和级别
        $errorType = self::ERROR_TYPE_SYSTEM;
        $errorLevel = self::ERROR_LEVEL_ERROR;
        
        // 根据异常类型设置错误类型
        if ($exception instanceof \ValidationException) {
            $errorType = self::ERROR_TYPE_VALIDATION;
            $errorLevel = self::ERROR_LEVEL_WARNING;
        } elseif ($exception instanceof \DatabaseException) {
            $errorType = self::ERROR_TYPE_DATABASE;
            $errorLevel = self::ERROR_LEVEL_CRITICAL;
        } elseif ($exception instanceof \PaymentException) {
            $errorType = self::ERROR_TYPE_PAYMENT;
            $errorLevel = self::ERROR_LEVEL_ERROR;
        } elseif ($exception instanceof \FileException) {
            $errorType = self::ERROR_TYPE_FILE;
            $errorLevel = self::ERROR_LEVEL_ERROR;
        } elseif ($exception instanceof \ApiException) {
            $errorType = self::ERROR_TYPE_API;
            $errorLevel = self::ERROR_LEVEL_WARNING;
        } elseif ($exception instanceof \SecurityException) {
            $errorType = self::ERROR_TYPE_SECURITY;
            $errorLevel = self::ERROR_LEVEL_CRITICAL;
        }
        
        // 构建错误上下文
        $context = $this->buildErrorContext($exception);
        
        // 记录错误
        $this->logError($exception, $errorId, $errorType, $errorLevel, $context);
        
        // 生成错误响应
        $response = $this->buildErrorResponse($exception, $errorId, $errorType, $context);
        
        // 发送错误响应
        $this->sendErrorResponse($response);
        
        // 清理资源
        exit(1);
    }
    
    /**
     * 处理PHP错误
     */
    public function handleError($errorCode, $errorMessage, $errorFile, $errorLine, $errorContext) {
        // 如果错误已被抑制，则不处理
        if (error_reporting() === 0) {
            return false;
        }
        
        // 确定错误级别
        switch ($errorCode) {
            case E_NOTICE:
            case E_USER_NOTICE:
                $errorLevel = self::ERROR_LEVEL_INFO;
                break;
            case E_WARNING:
            case E_USER_WARNING:
                $errorLevel = self::ERROR_LEVEL_WARNING;
                break;
            case E_ERROR:
            case E_USER_ERROR:
            case E_RECOVERABLE_ERROR:
                $errorLevel = self::ERROR_LEVEL_ERROR;
                break;
            default:
                $errorLevel = self::ERROR_LEVEL_WARNING;
        }
        
        // 生成错误ID
        $errorId = $this->generateErrorId($errorMessage . $errorFile . $errorLine);
        
        // 构建错误信息
        $errorInfo = [
            'message' => $errorMessage,
            'code' => $errorCode,
            'file' => $errorFile,
            'line' => $errorLine
        ];
        
        // 构建上下文
        $context = $this->buildErrorContext(null, $errorInfo);
        
        // 记录错误
        $this->logError(null, $errorId, self::ERROR_TYPE_SYSTEM, $errorLevel, $context, $errorInfo);
        
        // 对于严重错误，生成异常并处理
        if ($errorLevel >= self::ERROR_LEVEL_ERROR) {
            $exception = new \ErrorException($errorMessage, $errorCode, 0, $errorFile, $errorLine);
            $this->handleException($exception);
        }
        
        return true;
    }
    
    /**
     * 处理致命错误
     */
    public function handleFatalError() {
        $lastError = error_get_last();
        
        if ($lastError && in_array($lastError['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
            // 生成错误ID
            $errorId = $this->generateErrorId($lastError['message']);
            
            // 构建上下文
            $context = $this->buildErrorContext(null, $lastError);
            
            // 记录致命错误
            $this->logError(null, $errorId, self::ERROR_TYPE_SYSTEM, self::ERROR_LEVEL_EMERGENCY, $context, $lastError);
            
            // 发送致命错误响应
            $response = $this->buildErrorResponse(null, $errorId, self::ERROR_TYPE_SYSTEM, $context, $lastError);
            $this->sendErrorResponse($response);
        }
    }
    
    /**
     * 构建错误上下文信息
     */
    private function buildErrorContext($exception = null, $errorInfo = []) {
        // 获取基本信息
        $requestId = $this->getRequestId();
        $userId = $this->getUserId();
        $clientIp = $this->getClientIp();
        
        // 构建上下文数组
        $context = [
            'timestamp' => date('Y-m-d H:i:s.u'),
            'request_id' => $requestId,
            'user_id' => $userId,
            'client_ip' => $clientIp,
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '',
            'server_name' => isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '',
            'php_version' => PHP_VERSION,
            'memory_usage' => memory_get_usage(true),
            'memory_limit' => ini_get('memory_limit'),
            'environment' => $this->config['environment']
        ];
        
        // 添加异常信息
        if ($exception) {
            $context['exception'] = [
                'class' => get_class($exception),
                'message' => $exception->getMessage(),
                'code' => $exception->getCode(),
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'trace' => $this->config['debug'] ? $exception->getTrace() : []
            ];
        }
        
        // 添加错误信息
        if ($errorInfo) {
            $context['error_info'] = $errorInfo;
        }
        
        // 添加请求参数（经过敏感数据过滤）
        $context['request_data'] = $this->filterSensitiveData([
            'get' => isset($_GET) ? $_GET : [],
            'post' => isset($_POST) ? $_POST : [],
            'cookie' => isset($_COOKIE) ? $_COOKIE : [],
            'files' => isset($_FILES) ? $this->filterFileInfo($_FILES) : [],
            'headers' => $this->getAllHeaders()
        ]);
        
        return $context;
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIp() {
        $ipHeaders = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($ipHeaders as $header) {
            if (isset($_SERVER[$header])) {
                // 处理多个IP（代理情况）
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim(reset($ips));
                
                // 验证IP地址
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '127.0.0.1';
    }
    
    /**
     * 获取用户ID
     */
    private function getUserId() {
        $header = $this->config['user_id_header'];
        $serverHeader = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
        
        return isset($_SERVER[$serverHeader]) ? $_SERVER[$serverHeader] : 
               (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'guest');
    }
    
    /**
     * 获取所有HTTP头
     */
    private function getAllHeaders() {
        if (function_exists('getallheaders')) {
            return $this->filterSensitiveHeaders(getallheaders());
        }
        
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        
        return $this->filterSensitiveHeaders($headers);
    }
    
    /**
     * 过滤敏感HTTP头
     */
    private function filterSensitiveHeaders($headers) {
        $sensitiveHeaders = [
            'Authorization',
            'Cookie',
            'Set-Cookie',
            'Proxy-Authorization',
            'X-API-Key',
            'X-Auth-Token',
            'X-CSRF-Token'
        ];
        
        foreach ($sensitiveHeaders as $sensitiveHeader) {
            if (isset($headers[$sensitiveHeader])) {
                $headers[$sensitiveHeader] = '***REDACTED***';
            }
        }
        
        return $headers;
    }
    
    /**
     * 过滤敏感数据
     */
    private function filterSensitiveData($data) {
        if (!$this->config['mask_sensitive_data']) {
            return $data;
        }
        
        // 如果不是数组或对象，直接返回
        if (!is_array($data) && !is_object($data)) {
            return $data;
        }
        
        // 将对象转换为数组
        if (is_object($data)) {
            $data = (array) $data;
        }
        
        // 敏感字段列表
        $sensitiveFields = [
            'password',
            'passwd',
            'secret',
            'token',
            'key',
            'api',
            'auth',
            'credit',
            'card',
            'cvv',
            'cvc',
            'ssn',
            'social',
            'account',
            'routing',
            'iban',
            'bic',
            'swift'
        ];
        
        // 递归过滤敏感数据
        foreach ($data as $key => &$value) {
            $keyLower = strtolower($key);
            
            // 检查是否包含敏感字段名
            foreach ($sensitiveFields as $sensitiveField) {
                if (strpos($keyLower, $sensitiveField) !== false) {
                    $value = '***REDACTED***';
                    break;
                }
            }
            
            // 递归过滤嵌套数据
            if (is_array($value) || is_object($value)) {
                $value = $this->filterSensitiveData($value);
            }
        }
        
        return $data;
    }
    
    /**
     * 过滤文件信息（移除敏感路径信息）
     */
    private function filterFileInfo($files) {
        if (!is_array($files) || empty($files)) {
            return [];
        }
        
        $filteredFiles = [];
        
        foreach ($files as $key => $file) {
            if (is_array($file) && isset($file['name'])) {
                // 单个文件
                $filteredFiles[$key] = [
                    'name' => $file['name'],
                    'type' => $file['type'],
                    'size' => $file['size'],
                    'error' => $file['error'],
                    'tmp_name' => '***REDACTED***'
                ];
            } else if (is_array($file)) {
                // 多个文件（数组形式）
                $filteredFiles[$key] = $this->filterFileInfo($file);
            }
        }
        
        return $filteredFiles;
    }
    
    /**
     * 记录错误到日志文件
     */
    public function logError($exception, $errorId, $errorType, $errorLevel, $context, $errorInfo = []) {
        // 构建日志消息
        $logMessage = [
            'timestamp' => date('Y-m-d H:i:s.u'),
            'error_id' => $errorId,
            'error_type' => $errorType,
            'error_level' => $this->getErrorLevelName($errorLevel),
            'message' => $exception ? $exception->getMessage() : ($errorInfo['message'] ?? 'Unknown error'),
            'context' => $context
        ];
        
        // 转换为JSON字符串
        $logLine = json_encode($logMessage, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        // 写入日志文件
        error_log($logLine . "\n", 3, $this->config['error_log_path']);
        
        // 在开发环境中同时输出到控制台
        if ($this->config['debug']) {
            error_log($logLine);
        }
    }
    
    /**
     * 获取错误级别名称
     */
    private function getErrorLevelName($level) {
        $levels = [
            self::ERROR_LEVEL_INFO => 'INFO',
            self::ERROR_LEVEL_WARNING => 'WARNING',
            self::ERROR_LEVEL_ERROR => 'ERROR',
            self::ERROR_LEVEL_CRITICAL => 'CRITICAL',
            self::ERROR_LEVEL_EMERGENCY => 'EMERGENCY'
        ];
        
        return $levels[$level] ?? 'UNKNOWN';
    }
    
    /**
     * 构建错误响应
     */
    public function buildErrorResponse($exception = null, $errorId, $errorType, $context, $errorInfo = []) {
        // 确定HTTP状态码
        $statusCode = 500; // 默认服务器错误
        
        // 根据错误类型设置状态码
        if ($exception instanceof \ValidationException || $errorType === self::ERROR_TYPE_VALIDATION) {
            $statusCode = 400; // 验证错误
        } elseif ($exception instanceof \ApiException || $errorType === self::ERROR_TYPE_API) {
            $statusCode = 400; // API错误
        } elseif ($exception instanceof \SecurityException || $errorType === self::ERROR_TYPE_SECURITY) {
            $statusCode = 403; // 安全错误
        }
        
        // 获取错误消息
        $message = $exception ? $exception->getMessage() : ($errorInfo['message'] ?? '服务器内部错误');
        
        // 构建错误响应
        $response = [
            'success' => false,
            'error' => [
                'id' => $errorId,
                'code' => $errorType,
                'message' => $this->config['environment'] === 'production' && $statusCode >= 500 ? 
                    '服务器内部错误，请稍后再试' : $message,
                'timestamp' => $context['timestamp'],
                'request_id' => $context['request_id']
            ]
        ];
        
        // 在开发环境中添加详细信息
        if ($this->config['debug']) {
            if ($exception) {
                $response['error']['exception'] = [
                    'class' => get_class($exception),
                    'file' => $exception->getFile(),
                    'line' => $exception->getLine(),
                    'trace' => $exception->getTraceAsString()
                ];
            }
            
            if ($errorInfo) {
                $response['error']['error_info'] = $errorInfo;
            }
        }
        
        return [
            'status_code' => $statusCode,
            'body' => $response
        ];
    }
    
    /**
     * 发送错误响应
     */
    public function sendErrorResponse($response) {
        // 检查是否已经发送过头信息
        if (!headers_sent()) {
            // 设置状态码
            http_response_code($response['status_code']);
            
            // 设置内容类型
            header('Content-Type: application/json; charset=UTF-8');
            
            // 添加错误ID到响应头
            header('X-Error-ID: ' . $response['body']['error']['id']);
            
            // 添加请求ID到响应头
            header('X-Request-ID: ' . $response['body']['error']['request_id']);
            
            // 设置Cache-Control头
            header('Cache-Control: no-cache, no-store, must-revalidate');
            header('Pragma: no-cache');
            header('Expires: 0');
        }
        
        // 输出JSON响应
        echo json_encode($response['body'], JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * 手动记录错误
     */
    public function recordError($message, $errorType = self::ERROR_TYPE_SYSTEM, $errorLevel = self::ERROR_LEVEL_ERROR, $context = []) {
        // 生成错误ID
        $errorId = $this->generateErrorId($message);
        
        // 合并上下文
        $fullContext = array_merge($this->buildErrorContext(), $context);
        
        // 构建错误信息
        $errorInfo = ['message' => $message, 'code' => 0];
        
        // 记录错误
        $this->logError(null, $errorId, $errorType, $errorLevel, $fullContext, $errorInfo);
        
        return $errorId;
    }
    
    /**
     * 记录信息日志
     */
    public function logInfo($message, $context = []) {
        return $this->recordError($message, self::ERROR_TYPE_SYSTEM, self::ERROR_LEVEL_INFO, $context);
    }
    
    /**
     * 记录警告日志
     */
    public function logWarning($message, $context = []) {
        return $this->recordError($message, self::ERROR_TYPE_SYSTEM, self::ERROR_LEVEL_WARNING, $context);
    }
    
    /**
     * 记录错误日志
     */
    public function logError($message, $context = []) {
        return $this->recordError($message, self::ERROR_TYPE_SYSTEM, self::ERROR_LEVEL_ERROR, $context);
    }
    
    /**
     * 记录严重错误日志
     */
    public function logCritical($message, $context = []) {
        return $this->recordError($message, self::ERROR_TYPE_SYSTEM, self::ERROR_LEVEL_CRITICAL, $context);
    }
    
    /**
     * 记录紧急错误日志
     */
    public function logEmergency($message, $context = []) {
        return $this->recordError($message, self::ERROR_TYPE_SYSTEM, self::ERROR_LEVEL_EMERGENCY, $context);
    }
    
    /**
     * 设置配置
     */
    public function setConfig($key, $value = null) {
        if (is_array($key)) {
            $this->config = array_merge($this->config, $key);
        } else {
            $this->config[$key] = $value;
        }
        
        return $this;
    }
    
    /**
     * 获取配置
     */
    public function getConfig($key = null) {
        if ($key === null) {
            return $this->config;
        }
        
        return $this->config[$key] ?? null;
    }
}

// 自定义异常类
exception_class('ValidationException', 'Exception');
exception_class('DatabaseException', 'Exception');
exception_class('PaymentException', 'Exception');
exception_class('FileException', 'Exception');
exception_class('ApiException', 'Exception');
exception_class('SecurityException', 'Exception');

/**
 * 辅助函数：创建异常类
 */
function exception_class($name, $parent = 'Exception') {
    if (!class_exists($name)) {
        eval("class $name extends $parent {}");
    }
}