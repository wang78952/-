<?php
/**
 * 日志相关异常类
 * 用于处理日志系统中的各种异常情况
 * 
 * @author System Administrator
 * @version 1.0.0
 * @copyright 2024 发卡系统
 */

/**
 * LogException 类 - 日志系统异常
 */
class LogException extends Exception {
    /**
     * 异常类型常量
     */
    const TYPE_FILE_ACCESS = 1001;  // 文件访问异常
    const TYPE_DATABASE = 1002;     // 数据库异常
    const TYPE_CONFIG = 1003;       // 配置异常
    const TYPE_ENCRYPTION = 1004;   // 加密异常
    const TYPE_REMOTE = 1005;       // 远程日志异常
    const TYPE_VALIDATION = 1006;   // 数据验证异常
    
    /**
     * 异常类型
     * @var int
     */
    private $errorType;
    
    /**
     * 上下文信息
     * @var array
     */
    private $context;
    
    /**
     * 构造函数
     * @param string $message 异常消息
     * @param int $code 错误码
     * @param Throwable $previous 前一个异常
     * @param int $errorType 异常类型
     * @param array $context 上下文信息
     */
    public function __construct($message = '', $code = 0, Throwable $previous = null, $errorType = 0, array $context = []) {
        parent::__construct($message, $code, $previous);
        $this->errorType = $errorType;
        $this->context = $context;
        
        // 设置默认消息
        if (empty($message)) {
            $this->message = $this->getDefaultMessage($code, $errorType);
        }
        
        // 设置默认错误类型
        if ($errorType === 0) {
            $this->errorType = $this->determineDefaultType($code);
        }
    }
    
    /**
     * 获取异常类型
     * @return int 异常类型
     */
    public function getErrorType() {
        return $this->errorType;
    }
    
    /**
     * 获取上下文信息
     * @return array 上下文信息
     */
    public function getContext() {
        return $this->context;
    }
    
    /**
     * 获取默认异常消息
     * @param int $code 错误码
     * @param int $errorType 错误类型
     * @return string 默认消息
     */
    private function getDefaultMessage($code, $errorType) {
        switch ($errorType) {
            case self::TYPE_FILE_ACCESS:
                return "日志文件访问异常，错误码: {$code}";
            case self::TYPE_DATABASE:
                return "日志数据库操作异常，错误码: {$code}";
            case self::TYPE_CONFIG:
                return "日志配置异常，错误码: {$code}";
            case self::TYPE_ENCRYPTION:
                return "日志加密异常，错误码: {$code}";
            case self::TYPE_REMOTE:
                return "远程日志异常，错误码: {$code}";
            case self::TYPE_VALIDATION:
                return "日志数据验证异常，错误码: {$code}";
            default:
                return "日志系统异常，错误码: {$code}";
        }
    }
    
    /**
     * 根据错误码确定默认类型
     * @param int $code 错误码
     * @return int 错误类型
     */
    private function determineDefaultType($code) {
        // HTTP状态码对应
        if ($code >= 400 && $code < 500) {
            return self::TYPE_VALIDATION;
        } elseif ($code >= 500) {
            return self::TYPE_DATABASE;
        }
        return self::TYPE_CONFIG;
    }
    
    /**
     * 将异常转换为数组格式
     * @return array 异常信息数组
     */
    public function toArray() {
        return [
            'message' => $this->getMessage(),
            'code' => $this->getCode(),
            'type' => $this->getErrorType(),
            'type_name' => $this->getTypeName(),
            'file' => $this->getFile(),
            'line' => $this->getLine(),
            'trace' => $this->getTraceAsString(),
            'context' => $this->context,
            'previous' => $this->getPrevious() ? $this->getPrevious()->getMessage() : null
        ];
    }
    
    /**
     * 获取类型名称
     * @return string 类型名称
     */
    public function getTypeName() {
        switch ($this->errorType) {
            case self::TYPE_FILE_ACCESS:
                return 'file_access';
            case self::TYPE_DATABASE:
                return 'database';
            case self::TYPE_CONFIG:
                return 'config';
            case self::TYPE_ENCRYPTION:
                return 'encryption';
            case self::TYPE_REMOTE:
                return 'remote';
            case self::TYPE_VALIDATION:
                return 'validation';
            default:
                return 'unknown';
        }
    }
    
    /**
     * 判断是否为关键错误（需要立即处理）
     * @return bool 是否为关键错误
     */
    public function isCritical() {
        return in_array($this->errorType, [
            self::TYPE_FILE_ACCESS,
            self::TYPE_DATABASE,
            self::TYPE_CONFIG
        ]) || $this->getCode() >= 500;
    }
    
    /**
     * 转换为JSON格式
     * @return string JSON字符串
     */
    public function toJson() {
        return json_encode($this->toArray());
    }
}