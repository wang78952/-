<?php
/**
 * 自动备份调度器
 * 实现定时备份、备份策略管理和调度功能
 */

require_once __DIR__ . '/BackupManager.php';
require_once __DIR__ . '/ErrorHandler.php';

class BackupScheduler {
    private static $instance = null;
    private $backupManager;
    private $scheduleFile;
    private $lockFile;
    private $schedules;
    
    /**
     *// 备份类型常量
    const BACKUP_TYPE_DATABASE = 'database';
    const BACKUP_TYPE_FILES = 'files';
    const BACKUP_TYPE_LOGS = 'logs';
    const BACKUP_TYPE_FULL = 'full';
    const BACKUP_TYPE_INCREMENTAL = 'incremental';
    
    /**
     * 调度频率常量
     */
    const FREQUENCY_HOURLY = 'hourly';
    const FREQUENCY_DAILY = 'daily';
    const FREQUENCY_WEEKLY = 'weekly';
    const FREQUENCY_MONTHLY = 'monthly';
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->backupManager = BackupManager::getInstance();
        $this->scheduleFile = __DIR__ . '/../config/backup_schedules.json';
        $this->lockFile = __DIR__ . '/../config/backup_scheduler.lock';
        $this->ensureConfigDirectory();
        $this->loadSchedules();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 确保配置目录存在
     */
    private function ensureConfigDirectory() {
        $configDir = dirname($this->scheduleFile);
        if (!file_exists($configDir)) {
            mkdir($configDir, 0755, true);
        }
    }
    
    /**
     * 加载调度配置
     */
    private function loadSchedules() {
        if (file_exists($this->scheduleFile)) {
            $content = file_get_contents($this->scheduleFile);
            $this->schedules = json_decode($content, true) ?: array();
        } else {
            $this->schedules = $this->getDefaultSchedules();
            $this->saveSchedules();
        }
    }
    
    /**
     * 保存调度配置
     */
    private function saveSchedules() {
        file_put_contents($this->scheduleFile, json_encode($this->schedules, JSON_PRETTY_PRINT));
    }
    
    /**
     * 获取默认调度配置
     */
    private function getDefaultSchedules() {
        return array(
            array(
                'id' => 'daily_database',
                'name' => '每日数据库备份',
                'type' => self::BACKUP_TYPE_DATABASE,
                'frequency' => self::FREQUENCY_DAILY,
                'time' => '02:00',
                'enabled' => true,
                'max_backups' => 7,
                'description' => '每日凌晨2点自动备份数据库'
            ),
            array(
                'id' => 'weekly_full',
                'name' => '每周完整备份',
                'type' => self::BACKUP_TYPE_FULL,
                'frequency' => self::FREQUENCY_WEEKLY,
                'time' => '03:00',
                'day_of_week' => 0, // 周日
                'enabled' => true,
                'max_backups' => 4,
                'description' => '每周日凌晨3点完整备份'
            ),
            array(
                'id' => 'monthly_logs',
                'name' => '每月日志备份',
                'type' => self::BACKUP_TYPE_LOGS,
                'frequency' => self::FREQUENCY_MONTHLY,
                'time' => '04:00',
                'day_of_month' => 1,
                'enabled' => true,
                'max_backups' => 12,
                'description' => '每月1号凌晨4点备份日志'
            ),
            array(
                'id' => 'hourly_incremental',
                'name' => '每小时增量备份',
                'type' => self::BACKUP_TYPE_INCREMENTAL,
                'frequency' => self::FREQUENCY_HOURLY,
                'time' => '00:30',
                'enabled' => false,
                'max_backups' => 24,
                'description' => '每小时30分执行增量备份'
            )
        );
    }
    
    /**
     * 添加新的调度任务
     */
    public function addSchedule($name, $type, $frequency, $time, $options = array()) {
        $schedule = array(
            'id' => uniqid('schedule_'),
            'name' => $name,
            'type' => $type,
            'frequency' => $frequency,
            'time' => $time,
            'enabled' => true,
            'max_backups' => 10,
            'description' => isset($options['description']) ? $options['description'] : '',
            'created_at' => date('Y-m-d H:i:s')
        );
        
        // 添加特定频率的配置
        if ($frequency === self::FREQUENCY_WEEKLY && isset($options['day_of_week'])) {
            $schedule['day_of_week'] = $options['day_of_week'];
        } elseif ($frequency === self::FREQUENCY_MONTHLY && isset($options['day_of_month'])) {
            $schedule['day_of_month'] = $options['day_of_month'];
        }
        
        if (isset($options['max_backups'])) {
            $schedule['max_backups'] = $options['max_backups'];
        }
        
        // Validate schedule data before adding
        if (empty($schedule['id']) || empty($schedule['name']) || empty($schedule['type']) || empty($schedule['frequency'])) {
            throw new Exception('Invalid schedule data: missing required fields');
        }
        array_push($this->schedules, $schedule);
        $this->saveSchedules();
        
        return $schedule['id'];
    }
    
    /**
     * 删除调度任务
     */
    public function removeSchedule($scheduleId) {
        $this->schedules = array_filter($this->schedules, function($schedule) use ($scheduleId) {
            return $schedule['id'] !== $scheduleId;
        });
        $this->saveSchedules();
        return true;
    }
    
    /**
     * 启用/禁用调度任务
     */
    public function toggleSchedule($scheduleId, $enabled) {
        foreach ($this->schedules as &$schedule) {
            if ($schedule['id'] === $scheduleId) {
                $schedule['enabled'] = (bool)$enabled;
                $schedule['updated_at'] = date('Y-m-d H:i:s');
                $this->saveSchedules();
                return true;
            }
        }
        return false;
    }
    
    /**
     * 获取所有调度任务
     */
    public function getSchedules() {
        return $this->schedules;
    }
    
    /**
     * 获取启用的调度任务
     */
    public function getEnabledSchedules() {
        return array_filter($this->schedules, function($schedule) {
            return $schedule['enabled'];
        });
    }
    
    /**
     * 检查并执行到期的调度任务
     */
    public function runScheduledBackups() {
        // 检查锁文件，防止重复执行
        if ($this->isLocked()) {
            return array('success' => false, 'message' => '备份调度器正在运行中');
        }
        
        try {
            $this->acquireLock();
            $results = array();
            $enabledSchedules = $this->getEnabledSchedules();
            
            foreach ($enabledSchedules as $schedule) {
                if ($this->shouldRunNow($schedule)) {
                    $result = $this->executeBackup($schedule);
                    $results[] = $result;
                    
                    // 更新最后执行时间
                    $this->updateLastRunTime($schedule['id']);
                }
            }
            
            $this->releaseLock();
            
            return array(
                'success' => true,
                'executed_count' => count($results),
                'results' => $results
            );
            
        } catch (Exception $e) {
            $this->releaseLock();
            
            $errorHandler = ErrorHandler::getInstance();
            $errorHandler->logError("调度备份执行失败", ErrorLevel::ERROR, array(
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ));
            
            return array(
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    
    /**
     * 检查是否应该立即执行
     */
    private function shouldRunNow($schedule) {
        $now = new DateTime();
        $lastRun = $this->getLastRunTime($schedule['id']);
        
        // 如果从未执行过，检查是否到了执行时间
        if (!$lastRun) {
            return $this->isTimeToRun($schedule, $now);
        }
        
        // 检查是否到了下次执行时间
        $nextRun = $this->calculateNextRunTime($schedule, $lastRun);
        return $now >= $nextRun;
    }
    
    /**
     * 检查是否到了执行时间
     */
    private function isTimeToRun($schedule, DateTime $now) {
        $scheduleTime = explode(':', $schedule['time']);
        $scheduleHour = (int)$scheduleTime[0];
        $scheduleMinute = (int)$scheduleTime[1];
        
        switch ($schedule['frequency']) {
            case self::FREQUENCY_HOURLY:
                return $now->format('i') == $scheduleMinute;
                
            case self::FREQUENCY_DAILY:
                return $now->format('H:i') == sprintf('%02d:%02d', $scheduleHour, $scheduleMinute);
                
            case self::FREQUENCY_WEEKLY:
                if ($now->format('H:i') == sprintf('%02d:%02d', $scheduleHour, $scheduleMinute)) {
                    return $now->format('w') == $schedule['day_of_week'];
                }
                return false;
                
            case self::FREQUENCY_MONTHLY:
                if ($now->format('H:i') == sprintf('%02d:%02d', $scheduleHour, $scheduleMinute)) {
                    return $now->format('j') == $schedule['day_of_month'];
                }
                return false;
                
            default:
                return false;
        }
    }
    
    /**
     * 计算下次执行时间
     */
    private function calculateNextRunTime($schedule, DateTime $lastRun) {
        $scheduleTime = explode(':', $schedule['time']);
        $scheduleHour = (int)$scheduleTime[0];
        $scheduleMinute = (int)$scheduleTime[1];
        
        $nextRun = clone $lastRun;
        
        switch ($schedule['frequency']) {
            case self::FREQUENCY_HOURLY:
                $nextRun->add(new DateInterval('PT1H'));
                $nextRun->setTime($nextRun->format('H'), $scheduleMinute, 0);
                break;
                
            case self::FREQUENCY_DAILY:
                $nextRun->add(new DateInterval('P1D'));
                $nextRun->setTime($scheduleHour, $scheduleMinute, 0);
                break;
                
            case self::FREQUENCY_WEEKLY:
                $nextRun->add(new DateInterval('P7D'));
                $nextRun->setTime($scheduleHour, $scheduleMinute, 0);
                break;
                
            case self::FREQUENCY_MONTHLY:
                $nextRun->add(new DateInterval('P1M'));
                $nextRun->setTime($scheduleHour, $scheduleMinute, 0);
                break;
        }
        
        return $nextRun;
    }
    
    /**
     * 执行备份
     */
    private function executeBackup($schedule) {
        try {
            $description = "[自动备份] " . $schedule['name'] . " - " . date('Y-m-d H:i:s');
            
            // 设置最大备份数量
            $this->backupManager->setMaxBackups($schedule['max_backups']);
            
            switch ($schedule['type']) {
                case self::BACKUP_TYPE_DATABASE:
                    $result = $this->backupManager->createDatabaseBackup($description, false, null, true);
                    break;
                    
                case self::BACKUP_TYPE_FILES:
                    $result = $this->backupFiles($description);
                    break;
                    
                case self::BACKUP_TYPE_LOGS:
                    $result = $this->backupLogs($description);
                    break;
                    
                case self::BACKUP_TYPE_FULL:
                    $result = $this->fullBackup($description);
                    break;
                    
                case self::BACKUP_TYPE_INCREMENTAL:
                    // 执行增量备份
                    $result = $this->backupManager->createIncrementalBackup($description, true);
                    // 如果增量备份失败（可能没有完整备份作为基础），创建完整备份
                    if (isset($result['success']) && !$result['success'] && isset($result['error']) && strpos($result['error'], '找不到最近的完整备份') !== false) {
                        $errorHandler = ErrorHandler::getInstance();
                        $errorHandler->logInfo("增量备份失败，创建完整备份作为替代", array(
                            'schedule_id' => $schedule['id'],
                            'schedule_name' => $schedule['name']
                        ));
                        // 创建完整备份作为替代
                        $result = $this->backupManager->createDatabaseBackup($description . " - 自动降级为完整备份", false, null, true);
                    }
                    break;
                    
                default:
                    throw new Exception("未知的备份类型: " . $schedule['type']);
            }
            
            if ($result['success']) {
                $errorHandler = ErrorHandler::getInstance();
                $errorHandler->logInfo("自动备份执行成功", array(
                    'schedule_id' => $schedule['id'],
                    'schedule_name' => $schedule['name'],
                    'backup_file' => isset($result['filename']) ? $result['filename'] : 'N/A'
                ));
            }
            
            return array(
                'schedule_id' => $schedule['id'],
                'schedule_name' => $schedule['name'],
                'success' => $result['success'],
                'result' => $result
            );
            
        } catch (Exception $e) {
            return array(
                'schedule_id' => $schedule['id'],
                'schedule_name' => $schedule['name'],
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    
    /**
     * 备份文件
     */
    private function backupFiles($description) {
        // 实现文件备份逻辑
        $backupDir = __DIR__ . '/../backups/files';
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "files_backup_{$timestamp}.tar.gz";
        $filepath = $backupDir . '/' . $filename;
        
        // 这里应该实现实际的文件打包逻辑
        // 为了示例，我们创建一个空文件
        file_put_contents($filepath, "文件备份占位符");
        
        return array(
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => filesize($filepath)
        );
    }
    
    /**
     * 备份日志
     */
    private function backupLogs($description) {
        // 实现日志备份逻辑
        $backupDir = __DIR__ . '/../backups/logs';
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "logs_backup_{$timestamp}.tar.gz";
        $filepath = $backupDir . '/' . $filename;
        
        // 这里应该实现实际的日志打包逻辑
        file_put_contents($filepath, "日志备份占位符");
        
        return array(
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => filesize($filepath)
        );
    }
    
    /**
     * 完整备份
     */
    private function fullBackup($description) {
        $results = array();
        
        // 备份数据库
        $dbResult = $this->backupManager->createDatabaseBackup($description . " - 数据库部分");
        $results['database'] = $dbResult;
        
        // 备份文件
        $filesResult = $this->backupFiles($description . " - 文件部分");
        $results['files'] = $filesResult;
        
        // 备份日志
        $logsResult = $this->backupLogs($description . " - 日志部分");
        $results['logs'] = $logsResult;
        
        $success = $dbResult['success'] && $filesResult['success'] && $logsResult['success'];
        
        return array(
            'success' => $success,
            'type' => 'full',
            'components' => $results
        );
    }
    
    /**
     * 获取最后执行时间
     */
    private function getLastRunTime($scheduleId) {
        $runTimesFile = __DIR__ . '/../config/backup_run_times.json';
        
        if (!file_exists($runTimesFile)) {
            return null;
        }
        
        $runTimes = json_decode(file_get_contents($runTimesFile), true) ?: array();
        return isset($runTimes[$scheduleId]) ? new DateTime($runTimes[$scheduleId]) : null;
    }
    
    /**
     * 更新最后执行时间
     */
    private function updateLastRunTime($scheduleId) {
        $runTimesFile = __DIR__ . '/../config/backup_run_times.json';
        
        $runTimes = array();
        if (file_exists($runTimesFile)) {
            $runTimes = json_decode(file_get_contents($runTimesFile), true) ?: array();
        }
        
        $runTimes[$scheduleId] = date('Y-m-d H:i:s');
        file_put_contents($runTimesFile, json_encode($runTimes, JSON_PRETTY_PRINT));
    }
    
    /**
     * 检查锁文件
     */
    private function isLocked() {
        return file_exists($this->lockFile);
    }
    
    /**
     * 获取锁
     */
    private function acquireLock() {
        if (file_put_contents($this->lockFile, date('Y-m-d H:i:s')) === false) {
            throw new Exception("无法创建锁文件");
        }
    }
    
    /**
     * 释放锁
     */
    private function releaseLock() {
        if (file_exists($this->lockFile)) {
            unlink($this->lockFile);
        }
    }
    
    /**
     * 获取调度统计信息
     */
    public function getScheduleStats() {
        $stats = array(
            'total_schedules' => count($this->schedules),
            'enabled_schedules' => count($this->getEnabledSchedules()),
            'last_run_check' => date('Y-m-d H:i:s'),
            'next_runs' => array()
        );
        
        foreach ($this->getEnabledSchedules() as $schedule) {
            $lastRun = $this->getLastRunTime($schedule['id']);
            $nextRun = $lastRun ? $this->calculateNextRunTime($schedule, $lastRun) : null;
            
            $stats['next_runs'][] = array(
                'schedule_name' => $schedule['name'],
                'frequency' => $schedule['frequency'],
                'last_run' => $lastRun ? $lastRun->format('Y-m-d H:i:s') : '从未执行',
                'next_run' => $nextRun ? $nextRun->format('Y-m-d H:i:s') : '待计算'
            );
        }
        
        return $stats;
    }
    
    /**
     * 防止克隆
     */
    private function __clone() {}
    
    /**
     * 防止反序列化
     */
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}