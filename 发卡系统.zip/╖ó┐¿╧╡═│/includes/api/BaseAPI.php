<?php
/**
 * API基础类
 * 提供API接口通用功能，如请求处理、响应格式化、用户验证等
 */

// 引入验证和保护类
require_once __DIR__ . '/../EnhancedValidator.php';
require_once __DIR__ . '/../InjectionProtection.php';

class BaseAPI {
    protected $userId;
    protected $userRole;
    protected $db;
    protected $requestMethod;
    protected $requestData;
    protected $validator;
    protected $protection;
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->db = Database::getInstance();
        $this->requestMethod = $_SERVER['REQUEST_METHOD'];
        $this->validator = EnhancedValidator::getInstance();
        $this->protection = InjectionProtection::getInstance();
        $this->initUser();
    }
    
    /**
     * 初始化用户信息
     */
    private function initUser() {
        // 从Session或Token中获取用户信息
        if (isset($_SESSION['user_id'])) {
            $this->userId = $_SESSION['user_id'];
            $this->userRole = $_SESSION['user_role'] ?? 'user';
        } else if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            // 处理Bearer Token认证
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
            if (strpos($authHeader, 'Bearer ') === 0) {
                $token = substr($authHeader, 7);
                $this->verifyToken($token);
            }
        }
    }
    
    /**
     * 验证Token (增强安全性)
     */
    private function verifyToken($token) {
        try {
            // 清理token以防止注入
            $cleanToken = $this->protection->cleanInput($token);
            
            // 使用参数化查询
            $db = Database::getInstance();
            $result = $db->query("SELECT user_id, role FROM api_tokens WHERE token = ? AND expires_at > NOW()", [$cleanToken]);
            
            if ($row = $result->fetch_assoc()) {
                $this->userId = intval($row['user_id']);
                $this->userRole = $this->protection->cleanInput($row['role'] ?? 'user');
            } else {
                // Token无效时记录安全事件
                $this->logAPI('无效的API令牌', 'security', "尝试使用无效令牌: {$cleanToken}");
            }
        } catch (Exception $e) {
            // 记录验证失败的异常
            $this->logAPI('Token验证异常', 'error', $e->getMessage());
        }
    }
    
    /**
     * 获取并清理URL参数
     */
    protected function getParam($name, $default = null, $type = null) {
        $value = null;
        
        if (isset($_GET[$name])) {
            $value = $_GET[$name];
        } elseif (isset($_POST[$name])) {
            $value = $_POST[$name];
        } else {
            // 尝试从JSON请求体中获取
            $this->loadRequestBody();
            if (isset($this->requestData[$name])) {
                $value = $this->requestData[$name];
            }
        }
        
        // 如果未找到值，返回默认值
        if ($value === null) {
            return $default;
        }
        
        // 清理输入值
        $cleanValue = $this->protection->cleanInput($value);
        
        // 类型转换（如果指定）
        if ($type !== null) {
            try {
                $cleanValue = $this->validator->validateAndConvert($type, $cleanValue);
            } catch (Exception $e) {
                // 类型转换失败时记录警告并返回默认值
                $this->logAPI('参数类型转换失败', 'warning', "字段: {$name}, 值: {$value}, 错误: {$e->getMessage()}");
                return $default;
            }
        }
        
        return $cleanValue;
    }
    
    /**
     * 获取JSON数据
     */
    protected function getJSONData() {
        $this->loadRequestBody();
        return $this->requestData;
    }
    
    /**
     * 加载并验证请求体
     */
    private function loadRequestBody() {
        if ($this->requestData !== null) {
            return;
        }
        
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        
        if (strpos($contentType, 'application/json') !== false) {
            // 读取并清理输入流
            $input = file_get_contents('php://input');
            
            // 检查是否为空
            if (empty(trim($input))) {
                $this->requestData = [];
                return;
            }
            
            // 尝试解码JSON
            $jsonData = json_decode($input, true);
            
            // 检查JSON格式是否有效
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->logAPI('无效的JSON请求', 'error', json_last_error_msg());
                $this->requestData = [];
                return;
            }
            
            // 递归清理和验证JSON数据
            $this->requestData = $this->cleanAndValidateData($jsonData);
        } else {
            $this->requestData = [];
        }
    }
    
    /**
     * 递归清理和验证数据
     */
    private function cleanAndValidateData($data) {
        if (is_array($data)) {
            $cleanData = [];
            foreach ($data as $key => $value) {
                // 清理键名
                $cleanKey = $this->protection->cleanInput($key);
                // 递归清理值
                $cleanData[$cleanKey] = $this->cleanAndValidateData($value);
            }
            return $cleanData;
        } elseif (is_string($data)) {
            return $this->protection->cleanInput($data);
        } else {
            // 保留其他数据类型，但确保数值类型有效
            if (is_numeric($data) && !is_infinite($data) && !is_nan($data)) {
                return $data;
            } elseif (is_bool($data) || $data === null) {
                return $data;
            }
            
            // 其他类型转换为字符串并清理
            return $this->protection->cleanInput(strval($data));
        }
    
    /**
     * 成功响应
     */
    protected function successResponse($data = [], $message = '操作成功') {
        $response = [
            'code' => 200,
            'success' => true,
            'message' => $message,
            'data' => $data
        ];
        
        $this->sendResponse($response);
    }
    
    /**
     * 错误响应
     */
    protected function errorResponse($code = 400, $message = '操作失败') {
        $response = [
            'code' => $code,
            'success' => false,
            'message' => $message,
            'data' => null
        ];
        
        $this->sendResponse($response, $code);
    }
    
    /**
     * 发送响应
     */
    private function sendResponse($response, $httpCode = 200) {
        // 设置HTTP状态码
        http_response_code($httpCode);
        
        // 设置响应头
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        
        // 发送JSON响应
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * 检查用户是否登录
     */
    protected function checkLogin() {
        if (!$this->userId) {
            $this->errorResponse(401, '请先登录');
        }
        return true;
    }
    
    /**
     * 检查用户是否为管理员
     */
    protected function checkAdmin() {
        $this->checkLogin();
        
        if ($this->userRole !== 'admin' && $this->userRole !== 'super_admin') {
            $this->errorResponse(403, '没有管理员权限');
        }
        return true;
    }
    
    /**
     * 检查用户是否为代理
     */
    protected function checkAgent() {
        $this->checkLogin();
        
        if ($this->userRole !== 'agent' && $this->userRole !== 'admin' && $this->userRole !== 'super_admin') {
            $this->errorResponse(403, '没有代理权限');
        }
        return true;
    }
    
    /**
     * 增强的数据验证
     */
    protected function validate($data, $rules) {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            // 解析规则字符串为数组
            $ruleArray = $this->parseValidationRules($rule);
            
            // 必填验证
            if (isset($ruleArray['required']) && $ruleArray['required'] === true && 
                (empty($data[$field]) || $data[$field] === null || $data[$field] === '')) {
                $errors[$field] = $field . '不能为空';
                continue;
            }
            
            // 如果字段为空且不是必填，跳过后续验证
            if ((empty($data[$field]) || $data[$field] === null) && 
                (!isset($ruleArray['required']) || $ruleArray['required'] === false)) {
                continue;
            }
            
            // 获取字段值
            $fieldValue = $data[$field] ?? '';
            
            // 根据数据类型进行验证
            if (isset($ruleArray['type'])) {
                try {
                    switch ($ruleArray['type']) {
                        case 'string':
                            if (!is_string($fieldValue)) {
                                $fieldValue = strval($fieldValue);
                            }
                            // 字符串长度验证
                            if (isset($ruleArray['min'])) {
                                if (strlen($fieldValue) < $ruleArray['min']) {
                                    $errors[$field] = "{$field}长度不能小于{$ruleArray['min']}个字符";
                                    continue;
                                }
                            }
                            if (isset($ruleArray['max'])) {
                                if (strlen($fieldValue) > $ruleArray['max']) {
                                    $errors[$field] = "{$field}长度不能超过{$ruleArray['max']}个字符";
                                    continue;
                                }
                            }
                            // 正则验证
                            if (isset($ruleArray['pattern'])) {
                                if (!preg_match($ruleArray['pattern'], $fieldValue)) {
                                    $errors[$field] = "{$field}格式不正确";
                                    continue;
                                }
                            }
                            break;
                            
                        case 'integer':
                            if (!is_numeric($fieldValue)) {
                                $errors[$field] = "{$field}必须是数字";
                                continue;
                            }
                            $intValue = intval($fieldValue);
                            // 数值范围验证
                            if (isset($ruleArray['min'])) {
                                if ($intValue < $ruleArray['min']) {
                                    $errors[$field] = "{$field}不能小于{$ruleArray['min']}";
                                    continue;
                                }
                            }
                            if (isset($ruleArray['max'])) {
                                if ($intValue > $ruleArray['max']) {
                                    $errors[$field] = "{$field}不能大于{$ruleArray['max']}";
                                    continue;
                                }
                            }
                            break;
                            
                        case 'float':
                            if (!is_numeric($fieldValue)) {
                                $errors[$field] = "{$field}必须是数字";
                                continue;
                            }
                            $floatValue = floatval($fieldValue);
                            // 数值范围验证
                            if (isset($ruleArray['min'])) {
                                if ($floatValue < $ruleArray['min']) {
                                    $errors[$field] = "{$field}不能小于{$ruleArray['min']}";
                                    continue;
                                }
                            }
                            if (isset($ruleArray['max'])) {
                                if ($floatValue > $ruleArray['max']) {
                                    $errors[$field] = "{$field}不能大于{$ruleArray['max']}";
                                    continue;
                                }
                            }
                            break;
                            
                        case 'email':
                            if (!filter_var($fieldValue, FILTER_VALIDATE_EMAIL)) {
                                $errors[$field] = "{$field}格式不正确";
                                continue;
                            }
                            break;
                            
                        case 'url':
                            if (!filter_var($fieldValue, FILTER_VALIDATE_URL)) {
                                $errors[$field] = "{$field}格式不正确";
                                continue;
                            }
                            break;
                            
                        case 'phone':
                            if (!preg_match('/^1[3-9]\d{9}$/', $fieldValue)) {
                                $errors[$field] = "{$field}格式不正确";
                                continue;
                            }
                            break;
                    }
                } catch (Exception $e) {
                    $errors[$field] = "{$field}验证失败: {$e->getMessage()}";
                    continue;
                }
            }
            
            // 自定义验证
            if (isset($ruleArray['custom']) && is_callable($ruleArray['custom'])) {
                try {
                    $customResult = call_user_func($ruleArray['custom'], $fieldValue, $data);
                    if ($customResult !== true) {
                        $errors[$field] = $customResult === false ? "{$field}验证失败" : $customResult;
                    }
                } catch (Exception $e) {
                    $errors[$field] = "{$field}自定义验证失败: {$e->getMessage()}";
                }
            }
        }
        
        // 记录验证失败信息
        if (!empty($errors)) {
            $errorMessage = json_encode($errors, JSON_UNESCAPED_UNICODE);
            $this->logAPI('请求参数验证失败', 'error', $errorMessage);
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * 解析验证规则字符串为数组
     */
    private function parseValidationRules($rule) {
        $ruleArray = [];
        
        // 如果已经是数组，直接返回
        if (is_array($rule)) {
            return $rule;
        }
        
        // 分割规则字符串
        $ruleParts = explode('|', $rule);
        
        foreach ($ruleParts as $part) {
            if ($part === 'required') {
                $ruleArray['required'] = true;
            } elseif (strpos($part, 'min:') === 0) {
                $ruleArray['min'] = intval(substr($part, 4));
            } elseif (strpos($part, 'max:') === 0) {
                $ruleArray['max'] = intval(substr($part, 4));
            } elseif (strpos($part, 'type:') === 0) {
                $ruleArray['type'] = substr($part, 5);
            } elseif ($part === 'email') {
                $ruleArray['type'] = 'email';
            } elseif ($part === 'url') {
                $ruleArray['type'] = 'url';
            } elseif ($part === 'phone') {
                $ruleArray['type'] = 'phone';
            }
        }
        
        return $ruleArray;
    }
    
    /**
     * 安全的SQL查询，防止SQL注入
     */
    protected function safeQuery($query, $params = []) {
        // 确保参数经过正确转义
        foreach ($params as &$param) {
            $param = $this->protection->cleanSQL($param);
        }
        
        // 使用预处理语句执行查询
        return $this->db->query($query, $params);
    }
    
    /**
     * 记录API日志
     */
    protected function logAPI($action, $status = 'success', $message = '') {
        try {
            $ip = $_SERVER['REMOTE_ADDR'];
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $userId = $this->userId ?? 0;
            
            $query = "INSERT INTO api_logs (user_id, action, status, message, ip_address, user_agent, created_at) 
                     VALUES ({$userId}, '{$this->db->escapeString($action)}', '{$this->db->escapeString($status)}', 
                             '{$this->db->escapeString($message)}', '{$this->db->escapeString($ip)}', 
                             '{$this->db->escapeString($userAgent)}', NOW())";
            
            $this->db->query($query);
        } catch (Exception $e) {
            // 日志记录失败不影响主流程
        }
    }
    
    /**
     * 生成唯一ID
     */
    protected function generateUniqueId($prefix = '') {
        $timestamp = time();
        $random = mt_rand(1000, 9999);
        $uniqueId = $prefix . $timestamp . $random;
        return $uniqueId;
    }
    
    /**
     * 生成访问令牌
     */
    protected function generateToken($userId) {
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));
        
        // 存储token到数据库
        $this->db->query("INSERT INTO api_tokens (user_id, token, expires_at, created_at) 
                         VALUES ({$userId}, '{$token}', '{$expiresAt}', NOW())");
        
        return $token;
    }
    
    /**
     * 增强的分页参数处理
     */
    protected function getPaginationParams() {
        // 使用类型转换参数获取分页参数
        $page = $this->getParam('page', 1, 'integer');
        $pageSize = $this->getParam('page_size', 20, 'integer');
        
        // 限制有效值范围
        $page = max(1, $page);
        $pageSize = max(1, min(100, $pageSize));
        $offset = ($page - 1) * $pageSize;
        
        return [
            'page' => $page,
            'page_size' => $pageSize,
            'offset' => $offset
        ];
    }
    
    /**
     * 生成分页响应
     */
    protected function paginateResponse($items, $total, $page, $pageSize) {
        $response = [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'total_pages' => ceil($total / $pageSize)
        ];
        
        return $response;
    }
}