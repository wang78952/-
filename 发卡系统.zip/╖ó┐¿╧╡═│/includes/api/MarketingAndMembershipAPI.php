<?php
/**
 * 营销与会员体系API接口
 * 提供秒杀活动、会员积分、社交分享和营销自动化等功能的API接口
 */

require_once __DIR__ . '/../MarketingAndMembershipSystem.php';
require_once __DIR__ . '/BaseAPI.php';

class MarketingAndMembershipAPI extends BaseAPI {
    private $marketingSystem;

    /**
     * 构造函数
     */
    public function __construct() {
        parent::__construct();
        $this->marketingSystem = new MarketingAndMembershipSystem();
    }

    /**
     * 处理API请求
     */
    public function handleRequest() {
        // 获取操作类型
        $action = $this->getParam('action', '');
        
        try {
            // 根据操作类型调用不同的处理方法
            switch ($action) {
                // 秒杀活动相关接口
                case 'get_active_flash_sales':
                    $this->getActiveFlashSales();
                    break;
                case 'get_flash_sale_detail':
                    $this->getFlashSaleDetail();
                    break;
                case 'create_flash_sale_order':
                    $this->createFlashSaleOrder();
                    break;
                case 'admin_create_flash_sale':
                    $this->adminCreateFlashSale();
                    break;
                case 'admin_update_flash_sale':
                    $this->adminUpdateFlashSale();
                    break;
                case 'admin_get_flash_sales':
                    $this->adminGetFlashSales();
                    break;
                    
                // 会员积分相关接口
                case 'get_user_membership_info':
                    $this->getUserMembershipInfo();
                    break;
                case 'get_membership_levels':
                    $this->getMembershipLevels();
                    break;
                case 'admin_update_user_points':
                    $this->adminUpdateUserPoints();
                    break;
                case 'admin_get_user_membership_stats':
                    $this->adminGetUserMembershipStats();
                    break;
                    
                // 社交分享相关接口
                case 'create_social_share':
                    $this->createSocialShare();
                    break;
                case 'get_user_shares':
                    $this->getUserShares();
                    break;
                case 'process_share_redemption':
                    $this->processShareRedemption();
                    break;
                case 'admin_create_share_campaign':
                    $this->adminCreateShareCampaign();
                    break;
                    
                // 营销自动化相关接口
                case 'admin_create_email_campaign':
                    $this->adminCreateEmailCampaign();
                    break;
                case 'admin_create_sms_campaign':
                    $this->adminCreateSMSCampaign();
                    break;
                case 'admin_get_campaigns':
                    $this->adminGetCampaigns();
                    break;
                
                default:
                    $this->errorResponse(400, '无效的操作类型');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '服务器内部错误: ' . $e->getMessage());
        }
    }

    /**
     * 获取当前激活的秒杀活动
     */
    private function getActiveFlashSales() {
        try {
            $flashSales = $this->marketingSystem->getActiveFlashSales();
            $this->successResponse([
                'flash_sales' => $flashSales,
                'count' => count($flashSales)
            ]);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取秒杀活动失败: ' . $e->getMessage());
        }
    }

    /**
     * 获取秒杀活动详情
     */
    private function getFlashSaleDetail() {
        try {
            $flashSaleId = $this->getParam('flash_sale_id', 0);
            if (!$flashSaleId) {
                $this->errorResponse(400, '缺少秒杀活动ID');
            }

            // 这里应该调用MarketingAndMembershipSystem中的方法来获取详情
            // 为了演示，我们直接从数据库获取
            $db = Database::getInstance();
            $flashSale = $db->query("SELECT * FROM flash_sales WHERE id = ?", [$flashSaleId])->fetch_assoc();
            
            if (!$flashSale) {
                $this->errorResponse(404, '秒杀活动不存在');
            }

            // 获取秒杀商品
            $products = $db->query("SELECT fsp.*, p.name, p.description, p.image_url, p.original_price 
                               FROM flash_sale_products fsp
                               JOIN products p ON fsp.product_id = p.id
                               WHERE fsp.flash_sale_id = ?", [$flashSaleId])->fetch_all(MYSQLI_ASSOC);

            $flashSale['products'] = $products;
            $flashSale['time_left'] = $this->calculateTimeLeft($flashSale['end_time']);
            $flashSale['time_progress'] = $this->calculateTimeProgress($flashSale['start_time'], $flashSale['end_time']);

            $this->successResponse($flashSale);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取秒杀活动详情失败: ' . $e->getMessage());
        }
    }

    /**
     * 创建秒杀订单
     */
    private function createFlashSaleOrder() {
        try {
            // 验证用户登录
            $this->checkLogin();
            
            $flashSaleProductId = $this->getParam('flash_sale_product_id', 0);
            $quantity = $this->getParam('quantity', 1);
            
            if (!$flashSaleProductId) {
                $this->errorResponse(400, '缺少秒杀商品ID');
            }

            if ($quantity < 1 || $quantity > 10) {
                $this->errorResponse(400, '购买数量必须在1-10之间');
            }

            $result = $this->marketingSystem->processFlashSaleOrder($this->userId, $flashSaleProductId, $quantity);
            
            if ($result['success']) {
                $this->successResponse([
                    'order_id' => $result['order_id'],
                    'message' => '秒杀订单创建成功'
                ]);
            } else {
                $this->errorResponse(400, $result['error']);
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '创建秒杀订单失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员创建秒杀活动
     */
    private function adminCreateFlashSale() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $data = $this->getJSONData();
            
            // 验证必要字段
            if (empty($data['name']) || empty($data['start_time']) || empty($data['end_time'])) {
                $this->errorResponse(400, '缺少必要字段');
            }

            $flashSaleId = $this->marketingSystem->createFlashSale($data);
            
            if ($flashSaleId > 0) {
                $this->successResponse([
                    'flash_sale_id' => $flashSaleId,
                    'message' => '秒杀活动创建成功'
                ]);
            } else {
                $this->errorResponse(500, '秒杀活动创建失败');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '创建秒杀活动失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员更新秒杀活动
     */
    private function adminUpdateFlashSale() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $flashSaleId = $this->getParam('flash_sale_id', 0);
            $data = $this->getJSONData();
            
            if (!$flashSaleId) {
                $this->errorResponse(400, '缺少秒杀活动ID');
            }

            // 这里应该调用MarketingAndMembershipSystem中的方法来更新
            // 为了演示，我们直接更新数据库
            $db = Database::getInstance();
            
            // 构建更新语句
            $updates = [];
            $params = [];
            if (isset($data['name'])) {
                $updates[] = "name = ?";
                $params[] = $data['name'];
            }
            if (isset($data['description'])) {
                $updates[] = "description = ?";
                $params[] = $data['description'];
            }
            if (isset($data['start_time'])) {
                $updates[] = "start_time = ?";
                $params[] = $data['start_time'];
            }
            if (isset($data['end_time'])) {
                $updates[] = "end_time = ?";
                $params[] = $data['end_time'];
            }
            if (isset($data['status'])) {
                $updates[] = "status = ?";
                $params[] = $data['status'];
            }
            if (isset($data['priority'])) {
                $updates[] = "priority = ?";
                $params[] = $data['priority'];
            }
            $updates[] = "updated_at = NOW()";
            $params[] = $flashSaleId;
            
            $updateQuery = "UPDATE flash_sales SET " . implode(', ', $updates) . " WHERE id = ?";
            $db->query($updateQuery, $params);
            
            $this->successResponse(['message' => '秒杀活动更新成功']);
        } catch (Exception $e) {
            $this->errorResponse(500, '更新秒杀活动失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员获取秒杀活动列表
     */
    private function adminGetFlashSales() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $status = $this->getParam('status', '');
            $page = $this->getParam('page', 1);
            $pageSize = $this->getParam('page_size', 20);
            
            $offset = ($page - 1) * $pageSize;
            
            $db = Database::getInstance();
            $query = "SELECT * FROM flash_sales WHERE 1=1";
            $params = [];
            
            if ($status) {
                $query .= " AND status = ?";
                $params[] = $status;
            }
            
            $query .= " ORDER BY created_at DESC LIMIT ?, ?";
            $params[] = $offset;
            $params[] = $pageSize;
            
            $flashSales = $db->query($query, $params)->fetch_all(MYSQLI_ASSOC);
            
            // 获取总数
            $countQuery = "SELECT COUNT(*) as count FROM flash_sales WHERE 1=1";
            $countParams = [];
            if ($status) {
                $countQuery .= " AND status = ?";
                $countParams[] = $status;
            }
            $total = $db->query($countQuery, $countParams)->fetch_assoc()['count'];
            
            $this->successResponse([
                'flash_sales' => $flashSales,
                'total' => $total,
                'page' => $page,
                'page_size' => $pageSize
            ]);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取秒杀活动列表失败: ' . $e->getMessage());
        }
    }

    /**
     * 获取用户会员信息
     */
    private function getUserMembershipInfo() {
        try {
            // 验证用户登录
            $this->checkLogin();
            
            $targetUserId = $this->getParam('user_id', 0);
            
            // 只能查看自己的信息，除非是管理员
            if ($targetUserId && $targetUserId != $this->userId) {
                $this->checkAdmin();
                $userId = $targetUserId;
            } else {
                $userId = $this->userId;
            }
            
            $info = $this->marketingSystem->getUserMembershipInfo($userId);
            
            if ($info) {
                $this->successResponse($info);
            } else {
                $this->errorResponse(404, '用户不存在');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '获取用户会员信息失败: ' . $e->getMessage());
        }
    }

    /**
     * 获取会员等级列表
     */
    private function getMembershipLevels() {
        try {
            $db = Database::getInstance();
            $levels = $db->query("SELECT * FROM membership_levels ORDER BY min_points ASC")->fetch_all(MYSQLI_ASSOC);
            
            $this->successResponse($levels);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取会员等级失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员更新用户积分
     */
    private function adminUpdateUserPoints() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $userId = $this->getParam('user_id', 0);
            $points = $this->getParam('points', 0);
            $reason = $this->getParam('reason', '管理员手动调整');
            
            if (!$userId || $points == 0) {
                $this->errorResponse(400, '缺少必要参数');
            }

            $success = $this->marketingSystem->updateUserPoints($userId, $points, $reason);
            
            if ($success) {
                $this->successResponse(['message' => '用户积分更新成功']);
            } else {
                $this->errorResponse(500, '用户积分更新失败');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '更新用户积分失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员获取会员统计信息
     */
    private function adminGetUserMembershipStats() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $db = Database::getInstance();
            $stats = $db->query("SELECT * FROM v_user_membership_stats")->fetch_all(MYSQLI_ASSOC);
            
            $this->successResponse(['stats' => $stats]);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取会员统计信息失败: ' . $e->getMessage());
        }
    }

    /**
     * 创建社交分享
     */
    private function createSocialShare() {
        try {
            // 验证用户登录
            $this->checkLogin();
            
            $campaignId = $this->getParam('campaign_id', 0);
            
            if (!$campaignId) {
                $this->errorResponse(400, '缺少活动ID');
            }

            $result = $this->marketingSystem->processSocialShare($this->userId, $campaignId);
            
            if ($result['success']) {
                $this->successResponse([
                    'share_link' => $result['share_link'],
                    'share_code' => $result['share_code'],
                    'already_shared' => $result['already_shared'] ?? false,
                    'message' => $result['already_shared'] ? '您已参与分享' : '分享创建成功'
                ]);
            } else {
                $this->errorResponse(400, $result['error']);
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '创建社交分享失败: ' . $e->getMessage());
        }
    }

    /**
     * 获取用户的分享列表
     */
    private function getUserShares() {
        try {
            // 验证用户登录
            $this->checkLogin();
            
            $db = Database::getInstance();
            $shares = $db->query("SELECT ss.*, ssc.name as campaign_name, ssc.reward_points 
                           FROM social_shares ss
                           JOIN social_share_campaigns ssc ON ss.campaign_id = ssc.id
                           WHERE ss.user_id = {$this->userId}
                           ORDER BY ss.created_at DESC")->fetch_all(MYSQLI_ASSOC);
            
            $this->successResponse(['shares' => $shares]);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取用户分享列表失败: ' . $e->getMessage());
        }
    }

    /**
     * 处理分享兑换
     */
    private function processShareRedemption() {
        try {
            // 验证用户登录
            $this->checkLogin();
            
            $shareCode = $this->getParam('share_code', '');
            
            if (!$shareCode) {
                $this->errorResponse(400, '缺少分享码');
            }

            $result = $this->marketingSystem->processShareRedemption($shareCode, $this->userId);
            
            if ($result['success']) {
                $this->successResponse([
                    'new_user_reward' => $result['new_user_reward'],
                    'referrer_reward' => $result['referrer_reward'],
                    'message' => '分享码兑换成功，获得积分奖励'
                ]);
            } else {
                $this->errorResponse(400, $result['error']);
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '处理分享兑换失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员创建分享活动
     */
    private function adminCreateShareCampaign() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $data = $this->getJSONData();
            
            if (empty($data['name'])) {
                $this->errorResponse(400, '缺少活动名称');
            }

            $campaignId = $this->marketingSystem->createSocialShareCampaign($data);
            
            if ($campaignId > 0) {
                $this->successResponse([
                    'campaign_id' => $campaignId,
                    'message' => '分享活动创建成功'
                ]);
            } else {
                $this->errorResponse(500, '分享活动创建失败');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '创建分享活动失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员创建邮件营销活动
     */
    private function adminCreateEmailCampaign() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $data = $this->getJSONData();
            
            if (empty($data['name']) || empty($data['subject']) || empty($data['content'])) {
                $this->errorResponse(400, '缺少必要字段');
            }

            $campaignId = $this->marketingSystem->createEmailCampaign($data);
            
            if ($campaignId > 0) {
                $this->successResponse([
                    'campaign_id' => $campaignId,
                    'message' => '邮件营销活动创建成功'
                ]);
            } else {
                $this->errorResponse(500, '邮件营销活动创建失败');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '创建邮件营销活动失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员创建短信营销活动
     */
    private function adminCreateSMSCampaign() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $data = $this->getJSONData();
            
            if (empty($data['name']) || empty($data['content'])) {
                $this->errorResponse(400, '缺少必要字段');
            }

            $campaignId = $this->marketingSystem->createSMSCampaign($data);
            
            if ($campaignId > 0) {
                $this->successResponse([
                    'campaign_id' => $campaignId,
                    'message' => '短信营销活动创建成功'
                ]);
            } else {
                $this->errorResponse(500, '短信营销活动创建失败');
            }
        } catch (Exception $e) {
            $this->errorResponse(500, '创建短信营销活动失败: ' . $e->getMessage());
        }
    }

    /**
     * 管理员获取营销活动列表
     */
    private function adminGetCampaigns() {
        try {
            // 验证管理员权限
            $this->checkAdmin();
            
            $type = $this->getParam('type', ''); // email, sms, social_share
            $page = $this->getParam('page', 1);
            $pageSize = $this->getParam('page_size', 20);
            
            $offset = ($page - 1) * $pageSize;
            
            $db = Database::getInstance();
            
            // 确定表名并进行验证
            switch ($type) {
                case 'email':
                    $table = 'email_campaigns';
                    break;
                case 'sms':
                    $table = 'sms_campaigns';
                    break;
                case 'social_share':
                    $table = 'social_share_campaigns';
                    break;
                default:
                    $this->errorResponse(400, '无效的活动类型');
                    return;
            }
            
            // 表名白名单验证
            $allowedTables = ['email_campaigns', 'sms_campaigns', 'social_share_campaigns'];
            if (!in_array($table, $allowedTables)) {
                $this->errorResponse(400, '无效的表名');
                return;
            }
            
            // 使用预处理语句处理LIMIT参数
            $query = "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT ?, ?";
            $campaigns = $db->query($query, [$offset, $pageSize])->fetch_all(MYSQLI_ASSOC);
            
            // 获取总数
            $count = $db->query("SELECT COUNT(*) as count FROM {$table}")->fetch_assoc()['count'];
            
            $this->successResponse([
                'campaigns' => $campaigns,
                'total' => $count,
                'page' => $page,
                'page_size' => $pageSize
            ]);
        } catch (Exception $e) {
            $this->errorResponse(500, '获取营销活动列表失败: ' . $e->getMessage());
        }
    }

    /**
     * 计算剩余时间
     */
    private function calculateTimeLeft($endTime) {
        $timeLeft = strtotime($endTime) - time();
        
        if ($timeLeft <= 0) {
            return '00:00:00';
        }

        $hours = floor($timeLeft / 3600);
        $minutes = floor(($timeLeft % 3600) / 60);
        $seconds = $timeLeft % 60;

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    /**
     * 计算时间进度
     */
    private function calculateTimeProgress($startTime, $endTime) {
        $start = strtotime($startTime);
        $end = strtotime($endTime);
        $now = time();
        
        if ($now <= $start) return 0;
        if ($now >= $end) return 100;
        
        return (($now - $start) / ($end - $start)) * 100;
    }
}

// 实例化并处理请求
$api = new MarketingAndMembershipAPI();
$api->handleRequest();