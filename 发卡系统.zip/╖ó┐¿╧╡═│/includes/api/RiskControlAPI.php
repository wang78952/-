\u003c?php
/**
 * 风控API接口
 * 提供风控评估、黑名单管理、规则配置等功能接口
 */

class RiskControlAPI extends BaseAPI {
    // API接口版本
    const API_VERSION = '1.0.0';
    
    // 风控系统实例
    private $antiFraudSystem = null;
    
    // 数据库连接
    private $db = null;
    
    // Redis连接
    private $redis = null;
    
    /**
     * 构造函数
     */
    public function __construct() {
        parent::__construct();
        
        // 初始化风控系统
        $this-\u003eantiFraudSystem = AntiFraudSystem::getInstance();
        
        // 获取数据库连接
        $this-\u003edb = Database::getInstance();
        
        // 获取Redis连接
        $this-\u003eredis = RedisCache::getInstance();
    }
    
    /**
     * 路由API请求
     */
    public function route($action, $params = []) {
        try {
            // 验证请求参数
            if (!$this-\u003evalidateRequest($action, $params)) {
                return $this-\u003eerror('请求参数验证失败', 400);
            }
            
            // 执行对应的API方法
            switch ($action) {
                // 风险评估接口
                case 'evaluate_risk':
                    return $this-\u003eevaluateRisk($params);
                    
                // 黑名单管理接口
                case 'blacklist_add':
                    return $this-\u003eaddBlacklist($params);
                case 'blacklist_remove':
                    return $this-\u003eremoveBlacklist($params);
                case 'blacklist_query':
                    return $this-\u003equeryBlacklist($params);
                case 'blacklist_list':
                    return $this-\u003elistBlacklists($params);
                    
                // 风控规则接口
                case 'rule_add':
                    return $this-\u003eaddRule($params);
                case 'rule_update':
                    return $this-\u003eupdateRule($params);
                case 'rule_delete':
                    return $this-\u003edeleteRule($params);
                case 'rule_get':
                    return $this-\u003egetRule($params);
                case 'rule_list':
                    return $this-\u003elistRules($params);
                case 'rule_toggle':
                    return $this-\u003etoggleRuleStatus($params);
                    
                // 风控报表接口
                case 'report_summary':
                    return $this-\u003egetReportSummary($params);
                case 'report_risk_trend':
                    return $this-\u003egetRiskTrendReport($params);
                case 'report_high_risk_users':
                    return $this-\u003egetHighRiskUsersReport($params);
                case 'report_rule_effectiveness':
                    return $this-\u003egetRuleEffectivenessReport($params);
                    
                // 风控审核接口
                case 'review_task_list':
                    return $this-\u003elistReviewTasks($params);
                case 'review_task_get':
                    return $this-\u003egetReviewTask($params);
                case 'review_task_assign':
                    return $this-\u003eassignReviewTask($params);
                case 'review_task_process':
                    return $this-\u003eprocessReviewTask($params);
                case 'review_task_export':
                    return $this-\u003eexportReviewTasks($params);
                    
                // 用户信用管理接口
                case 'user_credit_get':
                    return $this-\u003egetUserCredit($params);
                case 'user_credit_update':
                    return $this-\u003eupdateUserCredit($params);
                case 'user_credit_history':
                    return $this-\u003egetUserCreditHistory($params);
                    
                // 风控系统管理接口
                case 'system_status':
                    return $this-\u003esystemStatus();
                case 'system_config_get':
                    return $this-\u003egetSystemConfig($params);
                case 'system_config_update':
                    return $this-\u003eupdateSystemConfig($params);
                case 'sync_blacklist':
                    return $this-\u003esyncBlacklist();
                    
                // 异常行为管理接口
                case 'abnormal_behavior_list':
                    return $this-\u003elistAbnormalBehaviors($params);
                case 'abnormal_behavior_process':
                    return $this-\u003eprocessAbnormalBehavior($params);
                    
                // 风控日志查询接口
                case 'risk_log_query':
                    return $this-\u003equeryRiskLogs($params);
                case 'risk_log_export':
                    return $this-\u003eexportRiskLogs($params);
                    
                // 接口文档
                case 'api_docs':
                    return $this-\u003egenerateApiDocs();
                    
                // 接口健康检查
                case 'health_check':
                    return $this-\u003ehealthCheck();
                    
                default:
                    return $this-\u003eerror('未知的API操作', 404);
            }
        } catch (Exception $e) {
            // 记录错误日志
            Logger::error('风控API执行异常', [
                'action' =\u003e $action,
                'error' =\u003e $e-\u003egetMessage(),
                'stack' =\u003e $e-\u003egetTraceAsString()
            ]);
            
            return $this-\u003eerror('API执行异常: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 验证请求参数
     */
    private function validateRequest($action, $params) {
        // 检查必要的API密钥
        if (!isset($params['api_key']) || !$this-\u003evalidateApiKey($params['api_key'])) {
            return false;
        }
        
        // 根据不同的action验证参数
        switch ($action) {
            case 'evaluate_risk':
                // 检查必要参数
                if (!isset($params['event_type']) || !isset($params['context'])) {
                    return false;
                }
                break;
                
            case 'blacklist_add':
            case 'blacklist_remove':
                if (!isset($params['type']) || !isset($params['value'])) {
                    return false;
                }
                break;
                
            case 'rule_add':
            case 'rule_update':
                if (!isset($params['rule_name']) || !isset($params['rule_type']) || !isset($params['rule_config'])) {
                    return false;
                }
                break;
                
            case 'rule_delete':
            case 'rule_get':
            case 'rule_toggle':
                if (!isset($params['rule_id']) && !isset($params['rule_code'])) {
                    return false;
                }
                break;
        }
        
        return true;
    }
    
    /**
     * 验证API密钥
     */
    private function validateApiKey($apiKey) {
        // 从数据库验证API密钥
        $apiKeyInfo = $this-\u003edb-\u003equeryFirstRow(
            "SELECT * FROM api_keys WHERE api_key = %s AND status = 'active' AND has_risk_permission = 1",
            $apiKey
        );
        
        return !empty($apiKeyInfo);
    }
    
    /**
     * 风险评估接口
     */
    public function evaluateRisk($params) {
        try {
            // 获取评估参数
            $eventType = $params['event_type'];
            $context = isset($params['context']) ? json_decode($params['context'], true) : [];
            $requestId = isset($params['request_id']) ? $params['request_id'] : uniqid('risk_', true);
            
            // 构建评估上下文
            $evaluationParams = [
                'event_type' =\u003e $eventType,
                'request_id' =\u003e $requestId,
                'api_key' =\u003e $params['api_key'],
                'timestamp' =\u003e time()
            ];
            
            // 合并用户提供的上下文
            $evaluationParams = array_merge($evaluationParams, $context);
            
            // 执行风险评估
            $result = $this-\u003eantiFraudSystem-\u003eevaluateRisk($evaluationParams);
            
            // 返回评估结果
            return $this-\u003esuccess([
                'request_id' =\u003e $result['request_id'],
                'risk_score' =\u003e $result['risk_score'],
                'risk_level' =\u003e $result['risk_level'],
                'risk_level_text' =\u003e $result['risk_level_text'],
                'decision' =\u003e $result['decision'],
                'decision_text' =\u003e $result['decision_text'],
                'rule_triggers' =\u003e $result['rule_triggers'],
                'recommendations' =\u003e $result['recommendations'],
                'timestamp' =\u003e $result['timestamp']
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('风险评估失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 添加黑名单
     */
    public function addBlacklist($params) {
        try {
            $type = $params['type']; // user, ip, device
            $value = $params['value'];
            $reason = isset($params['reason']) ? $params['reason'] : '安全风险';
            $expireTime = isset($params['expire_time']) ? $params['expire_time'] : null;
            $operatorId = isset($params['operator_id']) ? $params['operator_id'] : 0;
            
            // 验证黑名单类型
            if (!in_array($type, ['user', 'ip', 'device'])) {
                return $this-\u003eerror('无效的黑名单类型', 400);
            }
            
            // 检查是否已在黑名单中
            $existing = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM {$type}_blacklist WHERE {$type == 'user' ? 'user_id' : 'ip_address' == 'ip' ? 'ip_address' : 'device_fingerprint'} = %s AND status = 'active'",
                $value
            );
            
            if ($existing) {
                return $this-\u003eerror('该对象已在黑名单中', 400);
            }
            
            // 插入黑名单记录
            $tableName = $type == 'user' ? 'user_blacklist' : ($type == 'ip' ? 'ip_blacklist' : 'device_blacklist');
            $fieldName = $type == 'user' ? 'user_id' : ($type == 'ip' ? 'ip_address' : 'device_fingerprint');
            
            $this-\u003edb-\u003einsert($tableName, [
                $fieldName =\u003e $value,
                'reason' =\u003e $reason,
                'blocked_by' =\u003e $operatorId,
                'expire_time' =\u003e $expireTime,
                'status' =\u003e 'active',
                'notes' =\u003e isset($params['notes']) ? $params['notes'] : ''
            ]);
            
            // 更新Redis黑名单缓存
            $redisKey = "blacklist:{$type}";
            $this-\u003eredis-\u003esadd($redisKey, $value);
            
            // 如果有过期时间，设置缓存过期
            if ($expireTime) {
                $expireSeconds = strtotime($expireTime) - time();
                if ($expireSeconds \u003e 0) {
                    // 使用Sorted Set存储带过期时间的黑名单
                    $expireKey = "blacklist:{$type}:expire";
                    $this-\u003eredis-\u003ezAdd($expireKey, strtotime($expireTime), $value);
                }
            }
            
            return $this-\u003esuccess([
                'message' =\u003e '黑名单添加成功',
                'type' =\u003e $type,
                'value' =\u003e $value,
                'added_at' =\u003e date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('添加黑名单失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 移除黑名单
     */
    public function removeBlacklist($params) {
        try {
            $type = $params['type'];
            $value = $params['value'];
            $operatorId = isset($params['operator_id']) ? $params['operator_id'] : 0;
            
            // 验证黑名单类型
            if (!in_array($type, ['user', 'ip', 'device'])) {
                return $this-\u003eerror('无效的黑名单类型', 400);
            }
            
            // 更新数据库状态
            $tableName = $type == 'user' ? 'user_blacklist' : ($type == 'ip' ? 'ip_blacklist' : 'device_blacklist');
            $fieldName = $type == 'user' ? 'user_id' : ($type == 'ip' ? 'ip_address' : 'device_fingerprint');
            
            $affected = $this-\u003edb-\u003eupdate($tableName, 
                ['status' =\u003e 'inactive', 'removed_by' =\u003e $operatorId, 'removed_at' =\u003e date('Y-m-d H:i:s')],
                [$fieldName =\u003e $value, 'status' =\u003e 'active']
            );
            
            if ($affected == 0) {
                return $this-\u003eerror('未找到对应的黑名单记录', 404);
            }
            
            // 从Redis缓存移除
            $redisKey = "blacklist:{$type}";
            $this-\u003eredis-\u003esrem($redisKey, $value);
            
            // 从过期列表移除
            $expireKey = "blacklist:{$type}:expire";
            $this-\u003eredis-\u003ezRem($expireKey, $value);
            
            return $this-\u003esuccess([
                'message' =\u003e '黑名单移除成功',
                'type' =\u003e $type,
                'value' =\u003e $value
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('移除黑名单失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 查询黑名单
     */
    public function queryBlacklist($params) {
        try {
            $type = $params['type'];
            $value = $params['value'];
            
            // 检查Redis缓存
            $redisKey = "blacklist:{$type}";
            $isBlacklisted = $this-\u003eredis-\u003esismember($redisKey, $value);
            
            if (!$isBlacklisted) {
                // 检查数据库
                $tableName = $type == 'user' ? 'user_blacklist' : ($type == 'ip' ? 'ip_blacklist' : 'device_blacklist');
                $fieldName = $type == 'user' ? 'user_id' : ($type == 'ip' ? 'ip_address' : 'device_fingerprint');
                
                $record = $this-\u003edb-\u003equeryFirstRow(
                    "SELECT * FROM {$tableName} WHERE {$fieldName} = %s AND status = 'active'",
                    $value
                );
                
                $isBlacklisted = !empty($record);
                
                // 更新缓存
                if ($isBlacklisted) {
                    $this-\u003eredis-\u003esadd($redisKey, $value);
                }
            }
            
            return $this-\u003esuccess([
                'is_blacklisted' =\u003e $isBlacklisted,
                'type' =\u003e $type,
                'value' =\u003e $value
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('查询黑名单失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 列出黑名单
     */
    public function listBlacklists($params) {
        try {
            $type = isset($params['type']) ? $params['type'] : 'user';
            $page = isset($params['page']) ? intval($params['page']) : 1;
            $pageSize = isset($params['page_size']) ? intval($params['page_size']) : 20;
            $offset = ($page - 1) * $pageSize;
            
            // 构建查询条件
            $whereClause = 'status = \'active\'';
            $bindParams = [];
            
            if (isset($params['keyword'])) {
                $keyword = $params['keyword'];
                $fieldName = $type == 'user' ? 'user_id' : ($type == 'ip' ? 'ip_address' : 'device_fingerprint');
                $whereClause .= " AND {$fieldName} LIKE %s";
                $bindParams[] = "%{$keyword}%";
            }
            
            if (isset($params['start_time'])) {
                $whereClause .= " AND blocked_at \u003e= %s";
                $bindParams[] = $params['start_time'];
            }
            
            if (isset($params['end_time'])) {
                $whereClause .= " AND blocked_at \u003c= %s";
                $bindParams[] = $params['end_time'];
            }
            
            // 查询数据
            $tableName = $type == 'user' ? 'user_blacklist' : ($type == 'ip' ? 'ip_blacklist' : 'device_blacklist');
            $total = $this-\u003edb-\u003equeryFirstField(
                "SELECT COUNT(*) FROM {$tableName} WHERE {$whereClause}",
                ...$bindParams
            );
            
            $records = $this-\u003edb-\u003equery(
                "SELECT * FROM {$tableName} WHERE {$whereClause} ORDER BY blocked_at DESC LIMIT %d, %d",
                ...array_merge($bindParams, [$offset, $pageSize])
            );
            
            return $this-\u003esuccess([
                'total' =\u003e $total,
                'page' =\u003e $page,
                'page_size' =\u003e $pageSize,
                'data' =\u003e $records
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取黑名单列表失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 添加风控规则
     */
    public function addRule($params) {
        try {
            // 验证规则参数
            $requiredFields = ['rule_name', 'rule_code', 'rule_type', 'description', 'rule_config', 'risk_score'];
            foreach ($requiredFields as $field) {
                if (!isset($params[$field])) {
                    return $this-\u003eerror("缺少必要参数: {$field}", 400);
                }
            }
            
            // 检查规则代码是否已存在
            $existing = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_rules WHERE rule_code = %s",
                $params['rule_code']
            );
            
            if ($existing) {
                return $this-\u003eerror('规则代码已存在', 400);
            }
            
            // 插入规则记录
            $this-\u003edb-\u003einsert('risk_rules', [
                'rule_name' =\u003e $params['rule_name'],
                'rule_code' =\u003e $params['rule_code'],
                'rule_type' =\u003e $params['rule_type'],
                'description' =\u003e $params['description'],
                'rule_config' =\u003e is_array($params['rule_config']) ? json_encode($params['rule_config']) : $params['rule_config'],
                'risk_score' =\u003e $params['risk_score'],
                'priority' =\u003e isset($params['priority']) ? $params['priority'] : 1,
                'status' =\u003e isset($params['status']) ? $params['status'] : 'enabled',
                'created_by' =\u003e isset($params['created_by']) ? $params['created_by'] : 0
            ]);
            
            $ruleId = $this-\u003edb-\u003einsertId();
            
            // 刷新规则缓存
            $this-\u003eclearRuleCache();
            
            return $this-\u003esuccess([
                'message' =\u003e '规则添加成功',
                'rule_id' =\u003e $ruleId,
                'rule_code' =\u003e $params['rule_code']
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('添加规则失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 更新风控规则
     */
    public function updateRule($params) {
        try {
            // 获取规则ID或代码
            if (!isset($params['rule_id']) && !isset($params['rule_code'])) {
                return $this-\u003eerror('缺少规则ID或规则代码', 400);
            }
            
            // 构建查询条件
            if (isset($params['rule_id'])) {
                $where = ['id' =\u003e $params['rule_id']];
            } else {
                $where = ['rule_code' =\u003e $params['rule_code']];
            }
            
            // 构建更新数据
            $updateData = [];
            $fields = ['rule_name', 'description', 'rule_config', 'risk_score', 'priority', 'status'];
            
            foreach ($fields as $field) {
                if (isset($params[$field])) {
                    $updateData[$field] = $field == 'rule_config' && is_array($params[$field]) ? 
                        json_encode($params[$field]) : $params[$field];
                }
            }
            
            if (empty($updateData)) {
                return $this-\u003eerror('没有需要更新的数据', 400);
            }
            
            $updateData['updated_at'] = date('Y-m-d H:i:s');
            if (isset($params['updated_by'])) {
                $updateData['updated_by'] = $params['updated_by'];
            }
            
            // 执行更新
            $affected = $this-\u003edb-\u003eupdate('risk_rules', $updateData, $where);
            
            if ($affected == 0) {
                return $this-\u003eerror('未找到对应的规则记录', 404);
            }
            
            // 刷新规则缓存
            $this-\u003eclearRuleCache();
            
            return $this-\u003esuccess([
                'message' =\u003e '规则更新成功',
                'affected_rows' =\u003e $affected
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('更新规则失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 删除风控规则
     */
    public function deleteRule($params) {
        try {
            // 构建查询条件
            if (isset($params['rule_id'])) {
                $where = ['id' =\u003e $params['rule_id']];
            } else if (isset($params['rule_code'])) {
                $where = ['rule_code' =\u003e $params['rule_code']];
            } else {
                return $this-\u003eerror('缺少规则ID或规则代码', 400);
            }
            
            // 执行删除
            $affected = $this-\u003edb-\u003eupdate('risk_rules', 
                ['status' =\u003e 'deleted', 'deleted_at' =\u003e date('Y-m-d H:i:s')],
                $where
            );
            
            if ($affected == 0) {
                return $this-\u003eerror('未找到对应的规则记录', 404);
            }
            
            // 刷新规则缓存
            $this-\u003eclearRuleCache();
            
            return $this-\u003esuccess([
                'message' =\u003e '规则删除成功',
                'affected_rows' =\u003e $affected
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('删除规则失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取风控规则详情
     */
    public function getRule($params) {
        try {
            // 构建查询条件
            if (isset($params['rule_id'])) {
                $whereClause = 'id = %s';
                $bindParam = $params['rule_id'];
            } else if (isset($params['rule_code'])) {
                $whereClause = 'rule_code = %s';
                $bindParam = $params['rule_code'];
            } else {
                return $this-\u003eerror('缺少规则ID或规则代码', 400);
            }
            
            // 查询规则
            $rule = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_rules WHERE {$whereClause}",
                $bindParam
            );
            
            if (!$rule) {
                return $this-\u003eerror('未找到对应的规则记录', 404);
            }
            
            // 解析JSON配置
            if (isset($rule['rule_config'])) {
                $rule['rule_config'] = json_decode($rule['rule_config'], true);
            }
            
            return $this-\u003esuccess($rule);
        } catch (Exception $e) {
            return $this-\u003eerror('获取规则详情失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 列出风控规则
     */
    public function listRules($params) {
        try {
            $page = isset($params['page']) ? intval($params['page']) : 1;
            $pageSize = isset($params['page_size']) ? intval($params['page_size']) : 20;
            $offset = ($page - 1) * $pageSize;
            
            // 构建查询条件
            $whereClause = 'status != \'deleted\'';
            $bindParams = [];
            
            if (isset($params['rule_type'])) {
                $whereClause .= " AND rule_type = %s";
                $bindParams[] = $params['rule_type'];
            }
            
            if (isset($params['status'])) {
                $whereClause .= " AND status = %s";
                $bindParams[] = $params['status'];
            }
            
            if (isset($params['keyword'])) {
                $whereClause .= " AND (rule_name LIKE %s OR rule_code LIKE %s OR description LIKE %s)";
                $bindParams[] = "%{$params['keyword']}%";
                $bindParams[] = "%{$params['keyword']}%";
                $bindParams[] = "%{$params['keyword']}%";
            }
            
            // 查询数据
            $total = $this-\u003edb-\u003equeryFirstField(
                "SELECT COUNT(*) FROM risk_rules WHERE {$whereClause}",
                ...$bindParams
            );
            
            $records = $this-\u003edb-\u003equery(
                "SELECT * FROM risk_rules WHERE {$whereClause} ORDER BY priority ASC, created_at DESC LIMIT %d, %d",
                ...array_merge($bindParams, [$offset, $pageSize])
            );
            
            // 解析JSON配置
            foreach ($records as &$rule) {
                if (isset($rule['rule_config'])) {
                    $rule['rule_config'] = json_decode($rule['rule_config'], true);
                }
            }
            
            return $this-\u003esuccess([
                'total' =\u003e $total,
                'page' =\u003e $page,
                'page_size' =\u003e $pageSize,
                'data' =\u003e $records
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取规则列表失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 切换规则状态
     */
    public function toggleRuleStatus($params) {
        try {
            // 构建查询条件
            if (isset($params['rule_id'])) {
                $where = ['id' =\u003e $params['rule_id']];
            } else if (isset($params['rule_code'])) {
                $where = ['rule_code' =\u003e $params['rule_code']];
            } else {
                return $this-\u003eerror('缺少规则ID或规则代码', 400);
            }
            
            // 获取当前状态
            $rule = $this-\u003edb-\u003equeryFirstRow("SELECT * FROM risk_rules WHERE ", $where);
            if (!$rule) {
                return $this-\u003eerror('未找到对应的规则记录', 404);
            }
            
            // 切换状态
            $newStatus = $rule['status'] == 'enabled' ? 'disabled' : 'enabled';
            $affected = $this-\u003edb-\u003eupdate('risk_rules', 
                ['status' =\u003e $newStatus, 'updated_at' =\u003e date('Y-m-d H:i:s')],
                $where
            );
            
            // 刷新规则缓存
            $this-\u003eclearRuleCache();
            
            return $this-\u003esuccess([
                'message' =\u003e '规则状态切换成功',
                'rule_id' =\u003e $rule['id'],
                'new_status' =\u003e $newStatus
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('切换规则状态失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取报表摘要
     */
    public function getReportSummary($params) {
        try {
            $dateRange = $this-\u003eprepareDateRange($params);
            
            // 查询风控决策统计
            $decisions = $this-\u003edb-\u003equery(
                "SELECT decision, COUNT(*) as count, AVG(risk_score) as avg_score 
                 FROM risk_evaluations 
                 WHERE created_at \u003e= %s AND created_at \u003c= %s 
                 GROUP BY decision",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            // 查询风险等级分布
            $levels = $this-\u003edb-\u003equery(
                "SELECT risk_level, COUNT(*) as count 
                 FROM risk_evaluations 
                 WHERE created_at \u003e= %s AND created_at \u003c= %s 
                 GROUP BY risk_level",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            // 查询高风险规则
            $highRiskRules = $this-\u003edb-\u003equery(
                "SELECT triggered_rules, COUNT(*) as trigger_count 
                 FROM risk_evaluations 
                 WHERE created_at \u003e= %s AND created_at \u003c= %s AND risk_level \u003e= 3 
                 GROUP BY triggered_rules 
                 ORDER BY trigger_count DESC LIMIT 10",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            // 查询评估总量
            $totalEvaluations = $this-\u003edb-\u003equeryFirstField(
                "SELECT COUNT(*) FROM risk_evaluations WHERE created_at \u003e= %s AND created_at \u003c= %s",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            // 查询平均响应时间
            $avgResponseTime = $this-\u003edb-\u003equeryFirstField(
                "SELECT AVG(evaluation_time_ms) FROM risk_evaluations WHERE created_at \u003e= %s AND created_at \u003c= %s",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            return $this-\u003esuccess([
                'date_range' =\u003e $dateRange,
                'total_evaluations' =\u003e $totalEvaluations,
                'avg_response_time' =\u003e round($avgResponseTime, 2),
                'decision_distribution' =\u003e $decisions,
                'risk_level_distribution' =\u003e $levels,
                'high_risk_rules' =\u003e $highRiskRules
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取报表摘要失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取风险趋势报表
     */
    public function getRiskTrendReport($params) {
        try {
            $dateRange = $this-\u003eprepareDateRange($params);
            $granularity = isset($params['granularity']) ? $params['granularity'] : 'day'; // day, hour
            
            // 构建时间分组表达式
            $timeGroupExpr = $granularity == 'hour' ? 
                "DATE_FORMAT(created_at, '%Y-%m-%d %H:00:00')" : 
                "DATE(created_at)";
            
            // 查询风险趋势
            $trends = $this-\u003edb-\u003equery(
                "SELECT {$timeGroupExpr} as time_point, 
                        COUNT(*) as total_count, 
                        AVG(risk_score) as avg_risk_score, 
                        SUM(CASE WHEN risk_level = 1 THEN 1 ELSE 0 END) as low_risk_count,
                        SUM(CASE WHEN risk_level = 2 THEN 1 ELSE 0 END) as medium_risk_count,
                        SUM(CASE WHEN risk_level = 3 THEN 1 ELSE 0 END) as high_risk_count,
                        SUM(CASE WHEN risk_level = 4 THEN 1 ELSE 0 END) as critical_risk_count
                 FROM risk_evaluations 
                 WHERE created_at \u003e= %s AND created_at \u003c= %s 
                 GROUP BY {$timeGroupExpr} 
                 ORDER BY time_point",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            return $this-\u003esuccess([
                'date_range' =\u003e $dateRange,
                'granularity' =\u003e $granularity,
                'data' =\u003e $trends
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取风险趋势报表失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取高风险用户报表
     */
    public function getHighRiskUsersReport($params) {
        try {
            $dateRange = $this-\u003eprepareDateRange($params);
            $page = isset($params['page']) ? intval($params['page']) : 1;
            $pageSize = isset($params['page_size']) ? intval($params['page_size']) : 50;
            $offset = ($page - 1) * $pageSize;
            
            // 查询高风险用户
            $total = $this-\u003edb-\u003equeryFirstField(
                "SELECT COUNT(DISTINCT user_id) FROM risk_evaluations 
                 WHERE created_at \u003e= %s AND created_at \u003c= %s AND risk_level \u003e= 3 AND user_id IS NOT NULL",
                $dateRange['start_time'], $dateRange['end_time']
            );
            
            $users = $this-\u003edb-\u003equery(
                "SELECT r.user_id, u.username, u.email, 
                        COUNT(*) as evaluation_count, 
                        AVG(r.risk_score) as avg_risk_score, 
                        MAX(r.risk_score) as max_risk_score,
                        SUM(CASE WHEN r.decision = 'reject' THEN 1 ELSE 0 END) as reject_count,
                        SUM(CASE WHEN r.decision = 'review' THEN 1 ELSE 0 END) as review_count,
                        MAX(r.created_at) as last_evaluation
                 FROM risk_evaluations r
                 LEFT JOIN users u ON r.user_id = u.id
                 WHERE r.created_at \u003e= %s AND r.created_at \u003c= %s AND r.risk_level \u003e= 3 AND r.user_id IS NOT NULL
                 GROUP BY r.user_id, u.username, u.email
                 ORDER BY avg_risk_score DESC
                 LIMIT %d, %d",
                $dateRange['start_time'], $dateRange['end_time'], $offset, $pageSize
            );
            
            return $this-\u003esuccess([
                'date_range' =\u003e $dateRange,
                'total' =\u003e $total,
                'page' =\u003e $page,
                'page_size' =\u003e $pageSize,
                'data' =\u003e $users
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取高风险用户报表失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取规则有效性报表
     */
    public function getRuleEffectivenessReport($params) {
        try {
            $dateRange = $this-\u003eprepareDateRange($params);
            
            // 这里需要分析触发的规则数据
            // 简化实现，实际应该解析triggered_rules字段
            
            return $this-\u003esuccess([
                'date_range' =\u003e $dateRange,
                'data' =\u003e []
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取规则有效性报表失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 列出审核任务
     */
    public function listReviewTasks($params) {
        try {
            $page = isset($params['page']) ? intval($params['page']) : 1;
            $pageSize = isset($params['page_size']) ? intval($params['page_size']) : 20;
            $offset = ($page - 1) * $pageSize;
            
            // 构建查询条件
            $whereClause = '';
            $bindParams = [];
            
            if (isset($params['status'])) {
                $whereClause .= " AND status = %s";
                $bindParams[] = $params['status'];
            }
            
            if (isset($params['reviewer_id'])) {
                $whereClause .= " AND reviewer_id = %s";
                $bindParams[] = $params['reviewer_id'];
            }
            
            if (isset($params['priority'])) {
                $whereClause .= " AND priority = %s";
                $bindParams[] = $params['priority'];
            }
            
            if (isset($params['event_type'])) {
                $whereClause .= " AND event_type = %s";
                $bindParams[] = $params['event_type'];
            }
            
            // 查询数据
            $total = $this-\u003edb-\u003equeryFirstField(
                "SELECT COUNT(*) FROM risk_review_tasks WHERE 1=1 {$whereClause}",
                ...$bindParams
            );
            
            $tasks = $this-\u003edb-\u003equery(
                "SELECT * FROM risk_review_tasks WHERE 1=1 {$whereClause} 
                 ORDER BY priority DESC, created_at DESC 
                 LIMIT %d, %d",
                ...array_merge($bindParams, [$offset, $pageSize])
            );
            
            return $this-\u003esuccess([
                'total' =\u003e $total,
                'page' =\u003e $page,
                'page_size' =\u003e $pageSize,
                'data' =\u003e $tasks
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取审核任务列表失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取审核任务详情
     */
    public function getReviewTask($params) {
        try {
            $taskId = isset($params['task_id']) ? $params['task_id'] : (isset($params['id']) ? $params['id'] : null);
            
            if (!$taskId) {
                return $this-\u003eerror('缺少任务ID', 400);
            }
            
            $task = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_review_tasks WHERE id = %s OR task_id = %s",
                $taskId, $taskId
            );
            
            if (!$task) {
                return $this-\u003eerror('未找到对应的审核任务', 404);
            }
            
            // 解析JSON数据
            if (isset($task['triggered_rules'])) {
                $task['triggered_rules'] = json_decode($task['triggered_rules'], true);
            }
            
            if (isset($task['context'])) {
                $task['context'] = json_decode($task['context'], true);
            }
            
            // 获取相关的风控评估记录
            $evaluation = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_evaluations WHERE request_id = %s",
                $task['request_id']
            );
            
            return $this-\u003esuccess([
                'task' =\u003e $task,
                'evaluation' =\u003e $evaluation
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取审核任务详情失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 分配审核任务
     */
    public function assignReviewTask($params) {
        try {
            $taskId = isset($params['task_id']) ? $params['task_id'] : null;
            $reviewerId = isset($params['reviewer_id']) ? $params['reviewer_id'] : null;
            
            if (!$taskId || !$reviewerId) {
                return $this-\u003eerror('缺少必要参数', 400);
            }
            
            // 检查任务是否存在
            $task = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_review_tasks WHERE id = %s OR task_id = %s",
                $taskId, $taskId
            );
            
            if (!$task) {
                return $this-\u003eerror('未找到对应的审核任务', 404);
            }
            
            if ($task['status'] != 'pending') {
                return $this-\u003eerror('任务已被处理，无法重新分配', 400);
            }
            
            // 更新任务状态
            $affected = $this-\u003edb-\u003eupdate('risk_review_tasks', [
                'reviewer_id' =\u003e $reviewerId,
                'status' =\u003e 'assigned',
                'assigned_at' =\u003e date('Y-m-d H:i:s')
            ], [
                'id' =\u003e $task['id']
            ]);
            
            return $this-\u003esuccess([
                'message' =\u003e '任务分配成功',
                'task_id' =\u003e $task['task_id'],
                'reviewer_id' =\u003e $reviewerId
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('分配审核任务失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 处理审核任务
     */
    public function processReviewTask($params) {
        try {
            $taskId = isset($params['task_id']) ? $params['task_id'] : null;
            $reviewDecision = isset($params['review_decision']) ? $params['review_decision'] : null;
            $reviewNotes = isset($params['review_notes']) ? $params['review_notes'] : '';
            $processedBy = isset($params['processed_by']) ? $params['processed_by'] : 0;
            
            if (!$taskId || !$reviewDecision) {
                return $this-\u003eerror('缺少必要参数', 400);
            }
            
            // 验证决策结果
            $validDecisions = ['approve', 'reject', 'challenge', 'manual_review'];
            if (!in_array($reviewDecision, $validDecisions)) {
                return $this-\u003eerror('无效的决策结果', 400);
            }
            
            // 获取任务信息
            $task = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_review_tasks WHERE id = %s OR task_id = %s",
                $taskId, $taskId
            );
            
            if (!$task) {
                return $this-\u003eerror('未找到对应的审核任务', 404);
            }
            
            if ($task['status'] == 'completed') {
                return $this-\u003eerror('任务已完成，无法重复处理', 400);
            }
            
            // 更新任务状态
            $affected = $this-\u003edb-\u003eupdate('risk_review_tasks', [
                'status' =\u003e 'completed',
                'review_decision' =\u003e $reviewDecision,
                'review_notes' =\u003e $reviewNotes,
                'processed_by' =\u003e $processedBy,
                'processed_at' =\u003e date('Y-m-d H:i:s')
            ], [
                'id' =\u003e $task['id']
            ]);
            
            // 更新对应的风控评估记录
            $this-\u003edb-\u003eupdate('risk_evaluations', 
                ['final_decision' =\u003e $reviewDecision, 'processed_by' =\u003e $processedBy],
                ['request_id' =\u003e $task['request_id']]
            );
            
            // 如果是拒绝，将用户加入黑名单
            if ($reviewDecision == 'reject' && $task['user_id']) {
                $this-\u003eaddBlacklist([
                    'type' =\u003e 'user',
                    'value' =\u003e $task['user_id'],
                    'reason' =\u003e '人工审核拒绝: ' . $reviewNotes,
                    'operator_id' =\u003e $processedBy
                ]);
            }
            
            return $this-\u003esuccess([
                'message' =\u003e '任务处理成功',
                'task_id' =\u003e $task['task_id'],
                'review_decision' =\u003e $reviewDecision
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('处理审核任务失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 导出审核任务
     */
    public function exportReviewTasks($params) {
        try {
            // 这里应该生成Excel或CSV文件
            // 返回下载链接
            
            return $this-\u003esuccess([
                'message' =\u003e '导出功能暂未实现',
                'file_url' =\u003e ''
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('导出审核任务失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取用户信用信息
     */
    public function getUserCredit($params) {
        try {
            $userId = $params['user_id'];
            
            // 查询用户信用
            $credit = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM user_credit WHERE user_id = %s",
                $userId
            );
            
            if (!$credit) {
                return $this-\u003eerror('未找到用户信用信息', 404);
            }
            
            // 查询用户风险画像
            $profile = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM user_risk_profile WHERE user_id = %s",
                $userId
            );
            
            // 查询最近的风控评估
            $recentEvaluation = $this-\u003edb-\u003equeryFirstRow(
                "SELECT * FROM risk_evaluations WHERE user_id = %s ORDER BY created_at DESC LIMIT 1",
                $userId
            );
            
            return $this-\u003esuccess([
                'credit' =\u003e $credit,
                'risk_profile' =\u003e $profile,
                'recent_evaluation' =\u003e $recentEvaluation
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取用户信用信息失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 更新用户信用
     */
    public function updateUserCredit($params) {
        try {
            $userId = $params['user_id'];
            $creditScore = isset($params['credit_score']) ? $params['credit_score'] : null;
            $changeReason = isset($params['reason']) ? $params['reason'] : '手动调整';
            $operatorId = isset($params['operator_id']) ? $params['operator_id'] : 0;
            
            if (!$creditScore) {
                return $this-\u003eerror('缺少信用分数', 400);
            }
            
            // 更新用户信用
            $affected = $this-\u003edb-\u003eupdate('user_credit', [
                'credit_score' =\u003e $creditScore,
                'last_credit_change' =\u003e date('Y-m-d H:i:s')
            ], [
                'user_id' =\u003e $userId
            ]);
            
            if ($affected == 0) {
                // 如果不存在，创建新记录
                $this-\u003edb-\u003einsert('user_credit', [
                    'user_id' =\u003e $userId,
                    'credit_score' =\u003e $creditScore,
                    'credit_level' =\u003e 'normal',
                    'last_credit_change' =\u003e date('Y-m-d H:i:s')
                ]);
            }
            
            // 记录信用变更历史
            $this-\u003edb-\u003einsert('user_credit_history', [
                'user_id' =\u003e $userId,
                'credit_score' =\u003e $creditScore,
                'change_reason' =\u003e $changeReason,
                'changed_by' =\u003e $operatorId,
                'changed_at' =\u003e date('Y-m-d H:i:s')
            ]);
            
            // 更新用户风险画像
            $this-\u003eantiFraudSystem-\u003eupdateUserRiskProfile($userId, [
                'last_credit_check' =\u003e date('Y-m-d H:i:s'),
                'credit_score' =\u003e $creditScore
            ]);
            
            return $this-\u003esuccess([
                'message' =\u003e '用户信用更新成功',
                'user_id' =\u003e $userId,
                'new_credit_score' =\u003e $creditScore
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('更新用户信用失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取用户信用历史
     */
    public function getUserCreditHistory($params) {
        try {
            $userId = $params['user_id'];
            $page = isset($params['page']) ? intval($params['page']) : 1;
            $pageSize = isset($params['page_size']) ? intval($params['page_size']) : 20;
            $offset = ($page - 1) * $pageSize;
            
            // 查询历史记录
            $total = $this-\u003edb-\u003equeryFirstField(
                "SELECT COUNT(*) FROM user_credit_history WHERE user_id = %s",
                $userId
            );
            
            $records = $this-\u003edb-\u003equery(
                "SELECT * FROM user_credit_history 
                 WHERE user_id = %s 
                 ORDER BY changed_at DESC 
                 LIMIT %d, %d",
                $userId, $offset, $pageSize
            );
            
            return $this-\u003esuccess([
                'user_id' =\u003e $userId,
                'total' =\u003e $total,
                'page' =\u003e $page,
                'page_size' =\u003e $pageSize,
                'data' =\u003e $records
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取用户信用历史失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 获取系统状态
     */
    public function systemStatus() {
        try {
            // 获取风控系统状态
            $systemStatus = $this-\u003eantiFraudSystem-\u003egetSystemStatus();
            
            // 获取数据库连接状态
            $dbStatus = [
                'connected' =\u003e $this-\u003edb-\u003econnected(),
                'version' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT VERSION()")
            ];
            
            // 获取Redis连接状态
            $redisStatus = [
                'connected' =\u003e $this-\u003eredis-\u003econnected(),
                'version' =\u003e $this-\u003eredis-\u003einfo('server')['redis_version'] ?? 'unknown',
                'memory_used' =\u003e $this-\u003eredis-\u003einfo('memory')['used_memory_human'] ?? 'unknown'
            ];
            
            // 获取规则统计
            $ruleStats = [
                'total' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT COUNT(*) FROM risk_rules WHERE status != 'deleted'"),
                'enabled' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT COUNT(*) FROM risk_rules WHERE status = 'enabled'"),
                'disabled' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT COUNT(*) FROM risk_rules WHERE status = 'disabled'")
            ];
            
            // 获取黑名单统计
            $blacklistStats = [
                'users' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT COUNT(*) FROM user_blacklist WHERE status = 'active'"),
                'ips' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT COUNT(*) FROM ip_blacklist WHERE status = 'active'"),
                'devices' =\u003e $this-\u003edb-\u003equeryFirstField("SELECT COUNT(*) FROM device_blacklist WHERE status = 'active'")
            ];
            
            // 获取最近24小时的评估统计
            $last24hStats = $this-\u003edb-\u003equeryFirstRow(
                "SELECT COUNT(*) as evaluation_count, 
                        AVG(risk_score) as avg_risk_score,
                        AVG(evaluation_time_ms) as avg_response_time,
                        SUM(CASE WHEN decision = 'reject' THEN 1 ELSE 0 END) as reject_count
                 FROM risk_evaluations 
                 WHERE created_at \u003e= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
            );
            
            return $this-\u003esuccess([
                'api_version' =\u003e self::API_VERSION,
                'timestamp' =\u003e time(),
                'system_status' =\u003e $systemStatus,
                'database' =\u003e $dbStatus,
                'redis' =\u003e $redisStatus,
                'rules' =\u003e $ruleStats,
                'blacklists' =\u003e $blacklistStats,
                'last_24h' =\u003e $last24hStats
            ]);
        } catch (Exception $e) {
            return $this-\u003eerror('获取系统状态失败: ' . $e-\u003egetMessage(), 500);
        }
    }
    
    /**
     * 同步黑名单
     */
    public function syncBlacklist() {
        try {
            // 清理Redis黑名单缓存
            $this-\u003eredis-\u003edel('blacklist:user', 'blacklist:ip', 'blacklist:device');
            
            // 重新加载用户黑名单
            $users = $this-\u003edb-\u003equery(
                "SELECT user_id FROM user_blacklist WHERE status = 'active' AND (expire_time IS NULL OR expire_time \u003e NOW())"
            );
            foreach ($users as $user) {
                $this-\u003eredis-\u003esadd('blacklist:user', $user['user_id']);
            }
            
            // 重新加载IP黑名单
            $ips = $this-\u003edb-\u003equery(
                "SELECT ip_address FROM ip_blacklist WHERE status = 'active' AND (expire_time IS NULL OR expire_time \u003e NOW())"
            );
            foreach ($ips as $ip) {
                $this-\u003eredis-\u003esadd('blacklist:ip', $ip['ip_address']);
            }
            
            // 重新加载设备黑名单
            $devices = $this-\u003edb-\u003equery(
                "SELECT device_fingerprint FROM device_blacklist WHERE status = 'active' AND (expire_time IS NULL OR expire_time \u003e NOW())"
            );
            foreach ($devices as $device) {
                $this-\u003eredis-\u003esadd('blacklist:device', $device['device_fingerprint']);
            }
            
            return $this-\u003esuccess([
                'message' =\u003e '黑名单同步成功',
                'user_count' =\u003e count