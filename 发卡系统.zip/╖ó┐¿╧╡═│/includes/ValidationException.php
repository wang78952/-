<?php
/**
 * 验证异常类
 * 用于处理输入验证失败的异常
 */

class ValidationException extends Exception {
    private $errors;
    
    /**
     * 构造函数
     * @param string $message 异常消息
     * @param array $errors 验证错误详情
     * @param int $code 异常代码
     * @param Exception|null $previous 前一个异常
     */
    public function __construct($message = "验证失败", $errors = array(), $code = 0, Exception $previous = null) {
        parent::__construct($message, $code, $previous);
        $this->errors = $errors;
    }
    
    /**
     * 获取验证错误详情
     * @return array
     */
    public function getErrors() {
        return $this->errors;
    }
    
    /**
     * 设置验证错误详情
     * @param array $errors
     */
    public function setErrors($errors) {
        $this->errors = $errors;
    }
    
    /**
     * 获取第一个错误消息
     * @return string
     */
    public function getFirstError() {
        if (empty($this->errors)) {
            return $this->getMessage();
        }
        
        return reset($this->errors);
    }
    
    /**
     * 获取所有错误消息
     * @return array
     */
    public function getErrorMessages() {
        return array_values($this->errors);
    }
    
    /**
     * 检查是否有特定字段的错误
     * @param string $field 字段名
     * @return bool
     */
    public function hasFieldError($field) {
        return isset($this->errors[$field]);
    }
    
    /**
     * 获取特定字段的错误
     * @param string $field 字段名
     * @return string|null
     */
    public function getFieldError($field) {
        return isset($this->errors[$field]) ? $this->errors[$field] : null;
    }
    
    /**
     * 获取格式化的错误信息（用于API响应）
     * @return array
     */
    public function toArray() {
        return [
            'message' => $this->getMessage(),
            'errors' => $this->errors,
            'code' => $this->getCode()
        ];
    }
    
    /**
     * 转换为JSON字符串
     * @return string
     */
    public function toJson() {
        return json_encode($this->toArray());
    }
}