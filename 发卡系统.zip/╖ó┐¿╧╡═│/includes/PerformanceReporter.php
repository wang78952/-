<?php
require_once __DIR__ . '/init.php';

/**
 * 数据库性能监控报告生成器
 */
class PerformanceReporter {
    private $database;
    private $optimizer;
    
    public function __construct() {
        $this->database = Database::getInstance();
        $this->optimizer = new DatabaseOptimizer();
    }
    
    /**
     * 生成完整的性能报告
     */
    public function generateReport() {
        $report = array(
            'timestamp' => date('Y-m-d H:i:s'),
            'database_health' => $this->checkDatabaseHealth(),
            'query_performance' => $this->analyzeQueryPerformance(),
            'index_analysis' => $this->analyzeIndexes(),
            'cache_efficiency' => $this->analyzeCacheEfficiency(),
            'optimization_suggestions' => $this->getOptimizationSuggestions(),
            'performance_metrics' => $this->getPerformanceMetrics()
        );
        
        return $report;
    }
    
    /**
     * 检查数据库健康状态
     */
    private function checkDatabaseHealth() {
        $health = array();
        
        // 检查表大小
        $tables = $this->database->query("
            SELECT 
                table_name,
                ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb,
                table_rows
            FROM information_schema.tables 
            WHERE table_schema = DATABASE()
            ORDER BY (data_length + index_length) DESC
            LIMIT 10
        ");
        
        $health['largest_tables'] = $tables;
        
        // 检查连接数
        $connections = $this->database->queryOne("SHOW STATUS LIKE 'Threads_connected'");
        $health['active_connections'] = isset($connections['Value']) ? $connections['Value'] : 0;
        
        // 检查慢查询
        $slowQueries = $this->database->queryOne("SHOW STATUS LIKE 'Slow_queries'");
        $health['slow_queries_count'] = isset($slowQueries['Value']) ? $slowQueries['Value'] : 0;
        
        return $health;
    }
    
    /**
     * 分析查询性能
     */
    private function analyzeQueryPerformance() {
        $analysis = array();
        
        // 分析常见查询的执行时间
        $testQueries = array(
            'cards_count' => "SELECT COUNT(*) FROM cards",
            'users_count' => "SELECT COUNT(*) FROM users",
            'orders_count' => "SELECT COUNT(*) FROM orders",
            'verifications_count' => "SELECT COUNT(*) FROM identity_verifications",
            'complex_join' => "
                SELECT c.id, c.card_number, u.username 
                FROM cards c 
                LEFT JOIN users u ON c.created_by = u.id 
                WHERE c.status = 'active' 
                LIMIT 10
            "
        );
        
        foreach ($testQueries as $name => $query) {
            $start = microtime(true);
            $this->database->query($query);
            $executionTime = microtime(true) - $start;
            
            $analysis[$name] = array(
                'query' => $query,
                'execution_time' => round($executionTime * 1000, 2), // 毫秒
                'performance_rating' => $this->ratePerformance($executionTime)
            );
        }
        
        return $analysis;
    }
    
    /**
     * 分析索引使用情况
     */
    private function analyzeIndexes() {
        $indexes = array();
        
        // 获取所有表的索引信息
        $tables = array('cards', 'users', 'orders', 'identity_verifications', 'system_logs');
        
        foreach ($tables as $table) {
            $tableIndexes = $this->database->query("SHOW INDEX FROM {$table}");
            $indexes[$table] = $tableIndexes;
            
            // 检查缺失的索引建议
            $missingIndexes = $this->suggestMissingIndexes($table);
            if (!empty($missingIndexes)) {
                $indexes[$table . '_missing'] = $missingIndexes;
            }
        }
        
        return $indexes;
    }
    
    /**
     * 建议缺失的索引
     */
    private function suggestMissingIndexes($table) {
        $suggestions = array();
        
        switch ($table) {
            case 'cards':
                $suggestions[] = "建议在 status, created_at 上添加复合索引";
                $suggestions[] = "建议在 card_type, bank 上添加复合索引";
                break;
            case 'users':
                $suggestions[] = "建议在 status, role 上添加复合索引";
                $suggestions[] = "建议在 last_login 上添加索引";
                break;
            case 'orders':
                $suggestions[] = "建议在 user_id, status 上添加复合索引";
                $suggestions[] = "建议在 created_at 上添加索引";
                break;
            case 'identity_verifications':
                $suggestions[] = "建议在 status, verification_type 上添加复合索引";
                $suggestions[] = "建议在 task_id 上添加唯一索引";
                break;
            case 'system_logs':
                $suggestions[] = "建议在 level, created_at 上添加复合索引";
                $suggestions[] = "建议在 user_id, action 上添加复合索引";
                break;
        }
        
        return $suggestions;
    }
    
    /**
     * 分析缓存效率
     */
    private function analyzeCacheEfficiency() {
        $cacheStats = array();
        
        // 测试缓存命中率
        $testKeys = array('card_stats', 'user_stats', 'verification_stats');
        $hits = 0;
        $total = count($testKeys);
        
        foreach ($testKeys as $key) {
            // 第一次访问（缓存未命中）
            $start = microtime(true);
            $this->optimizer->clearCache();
            $this->optimizer->getCardStats();
            $missTime = microtime(true) - $start;
            
            // 第二次访问（缓存命中）
            $start = microtime(true);
            $this->optimizer->getCardStats();
            $hitTime = microtime(true) - $start;
            
            if ($hitTime < $missTime) {
                $hits++;
            }
            
            $cacheStats[$key] = array(
                'miss_time' => round($missTime * 1000, 2),
                'hit_time' => round($hitTime * 1000, 2),
                'improvement' => round((($missTime - $hitTime) / $missTime) * 100, 2)
            );
        }
        
        $cacheStats['hit_rate'] = round(($hits / $total) * 100, 2);
        
        return $cacheStats;
    }
    
    /**
     * 获取优化建议
     */
    private function getOptimizationSuggestions() {
        $suggestions = array();
        
        // 基于分析结果生成建议
        array_push($suggestions, array(
            'category' => '查询优化',
            'priority' => 'high',
            'suggestion' => '使用 DatabaseOptimizer 合并多个统计查询，减少数据库访问次数',
            'implementation' => '在控制器中使用 $this->optimizer->getCardStats() 替代多个独立查询'
        ));
        
        array_push($suggestions, array(
            'category' => '索引优化',
            'priority' => 'medium',
            'suggestion' => '为经常查询的字段组合添加复合索引',
            'implementation' => '执行 ALTER TABLE 语句添加建议的索引'
        ));
        
        array_push($suggestions, array(
            'category' => '缓存策略',
            'priority' => 'medium',
            'suggestion' => '对频繁访问的统计数据实施缓存策略',
            'implementation' => '使用 DatabaseOptimizer 的缓存功能，设置合理的缓存过期时间'
        ));
        
        array_push($suggestions, array(
            'category' => '批量操作',
            'priority' => 'low',
            'suggestion' => '使用批量插入替代循环单条插入',
            'implementation' => '使用 $this->optimizer->batchInsert() 方法'
        ));
        
        return $suggestions;
    }
    
    /**
     * 获取性能指标
     */
    private function getPerformanceMetrics() {
        $metrics = array();
        
        // 数据库连接时间
        $start = microtime(true);
        $db = Database::getInstance();
        $metrics['connection_time'] = round((microtime(true) - $start) * 1000, 2);
        
        // 内存使用情况
        $metrics['memory_usage'] = array(
            'current' => round(memory_get_usage() / 1024 / 1024, 2) . ' MB',
            'peak' => round(memory_get_peak_usage() / 1024 / 1024, 2) . ' MB'
        );
        
        // 页面加载时间（模拟）
        $start = microtime(true);
        $this->optimizer->getCardStats();
        $this->optimizer->getUserStats();
        $this->optimizer->getVerificationStats();
        $metrics['typical_page_load'] = round((microtime(true) - $start) * 1000, 2) . ' ms';
        
        return $metrics;
    }
    
    /**
     * 评估性能等级
     */
    private function ratePerformance($executionTime) {
        if ($executionTime < 0.01) {
            return 'excellent';
        } elseif ($executionTime < 0.05) {
            return 'good';
        } elseif ($executionTime < 0.1) {
            return 'fair';
        } else {
            return 'poor';
        }
    }
    
    /**
     * 输出HTML格式的报告
     */
    public function displayHtmlReport() {
        $report = $this->generateReport();
        
        echo "<!DOCTYPE html>\n";
        echo "<html>\n<head>\n";
        echo "<title>数据库性能报告</title>\n";
        echo "<meta charset='UTF-8'>\n";
        echo "<style>\n";
        echo "body { font-family: Arial, sans-serif; margin: 20px; }\n";
        echo ".header { background: #f4f4f4; padding: 20px; border-radius: 5px; }\n";
        echo ".section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }\n";
        echo ".excellent { color: green; }\n";
        echo ".good { color: blue; }\n";
        echo ".fair { color: orange; }\n";
        echo ".poor { color: red; }\n";
        echo "table { width: 100%; border-collapse: collapse; margin: 10px 0; }\n";
        echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n";
        echo "th { background-color: #f2f2f2; }\n";
        echo "</style>\n";
        echo "</head>\n<body>\n";
        
        echo "<div class='header'>\n";
        echo "<h1>数据库性能监控报告</h1>\n";
        echo "<p>生成时间: {$report['timestamp']}</p>\n";
        echo "</div>\n";
        
        // 数据库健康状态
        echo "<div class='section'>\n";
        echo "<h2>数据库健康状态</h2>\n";
        echo "<table>\n";
        echo "<tr><th>指标</th><th>数值</th></tr>\n";
        echo "<tr><td>活跃连接数</td><td>{$report['database_health']['active_connections']}</td></tr>\n";
        echo "<tr><td>慢查询数量</td><td>{$report['database_health']['slow_queries_count']}</td></tr>\n";
        echo "</table>\n";
        
        echo "<h3>最大的表</h3>\n";
        echo "<table>\n";
        echo "<tr><th>表名</th><th>大小(MB)</th><th>行数</th></tr>\n";
        foreach ($report['database_health']['largest_tables'] as $table) {
            echo "<tr><td>{$table['table_name']}</td><td>{$table['size_mb']}</td><td>{$table['table_rows']}</td></tr>\n";
        }
        echo "</table>\n";
        echo "</div>\n";
        
        // 查询性能分析
        echo "<div class='section'>\n";
        echo "<h2>查询性能分析</h2>\n";
        echo "<table>\n";
        echo "<tr><th>查询类型</th><th>执行时间(ms)</th><th>性能评级</th></tr>\n";
        foreach ($report['query_performance'] as $name => $data) {
            $class = $data['performance_rating'];
            echo "<tr><td>{$name}</td><td>{$data['execution_time']}</td><td class='{$class}'>{$data['performance_rating']}</td></tr>\n";
        }
        echo "</table>\n";
        echo "</div>\n";
        
        // 缓存效率
        echo "<div class='section'>\n";
        echo "<h2>缓存效率分析</h2>\n";
        echo "<p>缓存命中率: {$report['cache_efficiency']['hit_rate']}%</p>\n";
        echo "<table>\n";
        echo "<tr><th>缓存键</th><th>未命中时间(ms)</th><th>命中时间(ms)</th><th>性能提升(%)</th></tr>\n";
        foreach ($report['cache_efficiency'] as $key => $data) {
            if ($key !== 'hit_rate' && is_array($data)) {
                echo "<tr><td>{$key}</td><td>{$data['miss_time']}</td><td>{$data['hit_time']}</td><td>{$data['improvement']}</td></tr>\n";
            }
        }
        echo "</table>\n";
        echo "</div>\n";
        
        // 优化建议
        echo "<div class='section'>\n";
        echo "<h2>优化建议</h2>\n";
        echo "<table>\n";
        echo "<tr><th>类别</th><th>优先级</th><th>建议</th></tr>\n";
        foreach ($report['optimization_suggestions'] as $suggestion) {
            echo "<tr><td>{$suggestion['category']}</td><td>{$suggestion['priority']}</td><td>{$suggestion['suggestion']}</td></tr>\n";
        }
        echo "</table>\n";
        echo "</div>\n";
        
        // 性能指标
        echo "<div class='section'>\n";
        echo "<h2>性能指标</h2>\n";
        echo "<table>\n";
        echo "<tr><th>指标</th><th>数值</th></tr>\n";
        echo "<tr><td>数据库连接时间</td><td>{$report['performance_metrics']['connection_time']} ms</td></tr>\n";
        echo "<tr><td>当前内存使用</td><td>{$report['performance_metrics']['memory_usage']['current']}</td></tr>\n";
        echo "<tr><td>峰值内存使用</td><td>{$report['performance_metrics']['memory_usage']['peak']}</td></tr>\n";
        echo "<tr><td>典型页面加载时间</td><td>{$report['performance_metrics']['typical_page_load']}</td></tr>\n";
        echo "</table>\n";
        echo "</div>\n";
        
        echo "</body>\n</html>\n";
    }
}

// 运行报告
if (php_sapi_name() === 'cli') {
    $reporter = new PerformanceReporter();
    $report = $reporter->generateReport();
    echo json_encode($report, JSON_PRETTY_PRINT);
} else {
    $reporter = new PerformanceReporter();
    $reporter->displayHtmlReport();
}
?>