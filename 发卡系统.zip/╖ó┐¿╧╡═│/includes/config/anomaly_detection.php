<?php
/**
 * 异常波动检测配置文件
 * 定义异常检测规则、指标阈值和通知设置
 */

return [
    // 全局配置
    'global' => [
        'enabled' => true,
        'check_interval' => 300,  // 检查间隔(秒)
        'timezone' => 'Asia/Shanghai',
    ],
    
    // 检测算法配置
    'algorithms' => [
        // 默认算法
        'default' => 'threshold',  // threshold, statistical, machine_learning
        
        // 阈值检测算法配置
        'threshold' => [
            'min_value' => [],  // 最小阈值，如 ['sales' => 0, 'active_users' => 10]
            'max_value' => [],  // 最大阈值，如 ['error_rate' => 0.05, 'refund_rate' => 0.2]
            'percent_change' => [  // 百分比变化阈值
                'min' => -0.5,  // 允许最小下降50%
                'max' => 0.5,   // 允许最大上升50%
                'time_window' => 3600,  // 时间窗口(秒)
            ],
        ],
        
        // 统计检测算法配置
        'statistical' => [
            'z_score_threshold' => 2.5,  // Z分数阈值，高于此值视为异常
            'moving_average_days' => 7,  // 移动平均天数
            'standard_deviation_days' => 7,  // 标准差计算天数
        ],
        
        // 机器学习算法配置 (如果实现了机器学习模型)
        'machine_learning' => [
            'model_path' => 'models/anomaly_detection.model',
            'prediction_threshold' => 0.7,  // 预测概率阈值
            'retrain_interval' => 7,  // 模型重训练间隔(天)
        ],
    ],
    
    // 业务指标检测配置
    'metrics' => [
        // 销售额相关指标
        'sales' => [
            'enabled' => true,
            'algorithm' => 'statistical',  // 优先级高于全局默认算法
            'threshold' => [
                'daily_min' => 1000,  // 日销售额最低阈值
                'percent_change' => [
                    'min' => -0.3,  // 允许下降最多30%
                    'max' => 2.0,   // 允许上升最多200%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email', 'sms'],
                'severity' => 'high',  // high, medium, low
                'recipients' => [],  // 为空时使用全局接收人
            ],
        ],
        
        // 卡密激活率
        'activation_rate' => [
            'enabled' => true,
            'algorithm' => 'threshold',
            'threshold' => [
                'min' => 0.6,  // 最低激活率60%
                'percent_change' => [
                    'min' => -0.2,  // 允许下降最多20%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'medium',
            ],
        ],
        
        // 订单转化率
        'conversion_rate' => [
            'enabled' => true,
            'algorithm' => 'statistical',
            'threshold' => [
                'percent_change' => [
                    'min' => -0.3,  // 允许下降最多30%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'medium',
            ],
        ],
        
        // 代理推广效果
        'affiliate_efficiency' => [
            'enabled' => true,
            'algorithm' => 'threshold',
            'threshold' => [
                'percent_change' => [
                    'min' => -0.25,  // 允许下降最多25%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'medium',
            ],
        ],
        
        // 错误率
        'error_rate' => [
            'enabled' => true,
            'algorithm' => 'threshold',
            'threshold' => [
                'max' => 0.05,  // 最大错误率5%
                'percent_change' => [
                    'max' => 1.0,  // 允许上升最多100%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email', 'sms'],
                'severity' => 'high',
            ],
        ],
        
        // 支付失败率
        'payment_failure_rate' => [
            'enabled' => true,
            'algorithm' => 'threshold',
            'threshold' => [
                'max' => 0.03,  // 最大失败率3%
                'percent_change' => [
                    'max' => 0.5,  // 允许上升最多50%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email', 'sms'],
                'severity' => 'high',
            ],
        ],
        
        // 卡密验证异常率
        'verification_exception_rate' => [
            'enabled' => true,
            'algorithm' => 'threshold',
            'threshold' => [
                'max' => 0.02,  // 最大异常率2%
                'percent_change' => [
                    'max' => 0.8,  // 允许上升最多80%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email', 'sms'],
                'severity' => 'high',
            ],
        ],
        
        // 用户活跃度
        'user_activity' => [
            'enabled' => true,
            'algorithm' => 'statistical',
            'threshold' => [
                'percent_change' => [
                    'min' => -0.4,  // 允许下降最多40%
                ],
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'medium',
            ],
        ],
    ],
    
    // 系统性能指标检测配置
    'performance_metrics' => [
        // CPU使用率
        'cpu_usage' => [
            'enabled' => true,
            'threshold' => [
                'max' => 0.85,  // 最大CPU使用率85%
                'check_duration' => 300,  // 连续检查时间(秒)
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'high',
            ],
        ],
        
        // 内存使用率
        'memory_usage' => [
            'enabled' => true,
            'threshold' => [
                'max' => 0.9,  // 最大内存使用率90%
                'check_duration' => 300,  // 连续检查时间(秒)
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'high',
            ],
        ],
        
        // 数据库连接池使用率
        'db_connection_pool' => [
            'enabled' => true,
            'threshold' => [
                'max' => 0.8,  // 最大连接池使用率80%
                'check_duration' => 180,  // 连续检查时间(秒)
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email', 'sms'],
                'severity' => 'high',
            ],
        ],
        
        // 接口响应时间
        'api_response_time' => [
            'enabled' => true,
            'threshold' => [
                'max' => 2.0,  // 最大响应时间2秒
                'p95_max' => 3.0,  // 95%请求最大响应时间3秒
            ],
            'notification' => [
                'enabled' => true,
                'channels' => ['email'],
                'severity' => 'medium',
            ],
        ],
    ],
    
    // 时间范围配置
    'time_ranges' => [
        'today' => [
            'enabled' => true,
            'update_interval' => 3600,  // 更新间隔(秒)
        ],
        'last_7_days' => [
            'enabled' => true,
            'update_interval' => 86400,  // 更新间隔(秒)
        ],
        'last_30_days' => [
            'enabled' => true,
            'update_interval' => 86400,  // 更新间隔(秒)
        ],
    ],
    
    // 通知配置
    'notifications' => [
        'enabled' => true,
        
        // 全局接收人
        'recipients' => [
            'email' => [
                'admin@example.com',
                'developer@example.com',
            ],
            'sms' => [
                '13800138000',  // 管理员电话
                '13900139000',  // 技术负责人电话
            ],
            'wechat' => [
                'admin_id',
                'tech_lead_id',
            ],
        ],
        
        // 通知规则
        'rules' => [
            // 告警合并
            'grouping' => [
                'enabled' => true,
                'time_window' => 300,  // 合并窗口(秒)
                'same_metric' => true,  // 相同指标的告警合并
                'same_reason' => true,  // 相同原因的告警合并
            ],
            
            // 告警冷却
            'throttling' => [
                'enabled' => true,
                'min_interval' => 3600,  // 最小通知间隔(秒)
                'max_per_day' => 10,  // 每日最大通知次数
            ],
            
            // 告警升级
            'escalation' => [
                'enabled' => true,
                'rules' => [
                    [
                        'severity' => 'high',
                        'channels' => ['email', 'sms'],
                    ],
                    [
                        'severity' => 'medium',
                        'channels' => ['email'],
                    ],
                    [
                        'severity' => 'low',
                        'channels' => ['email'],
                    ],
                ],
                // 未解决告警升级规则
                'unresolved' => [
                    [
                        'minutes' => 30,
                        'channels' => ['email', 'sms', 'wechat'],
                    ],
                    [
                        'minutes' => 120,
                        'channels' => ['email', 'sms', 'wechat'],
                        'recipients' => ['manager@example.com'],  // 升级通知接收人
                    ],
                ],
            ],
        ],
        
        // 通知模板
        'templates' => [
            'subject' => [
                'high' => '[严重告警] 系统指标异常: {metric}',
                'medium' => '[警告] 系统指标异常: {metric}',
                'low' => '[注意] 系统指标异常: {metric}',
            ],
            'message' => [
                'email' => '尊敬的管理员:\n\n检测到系统异常指标:\n\n指标名称: {metric}\n当前值: {current_value}\n正常范围: {normal_range}\n异常程度: {severity}\n异常原因: {reason}\n检测时间: {timestamp}\n检测算法: {algorithm}\n\n请及时处理，谢谢!\n\n--\n系统自动发送，请勿回复',
                'sms' => '[系统告警] 指标{metric}异常:{current_value},程度:{severity},原因:{reason},请及时处理',
                'wechat' => '⚠️ 系统告警\n指标: {metric}\n值: {current_value}\n程度: {severity}\n原因: {reason}\n时间: {timestamp}',
            ],
        ],
    ],
    
    // 历史数据配置
    'history' => [
        'enabled' => true,
        'retention_days' => 90,  // 历史数据保留天数
        'store_interval' => 3600,  // 数据存储间隔(秒)
        'aggregation' => [
            'hourly' => 24,  // 保留最近24小时的小时级数据
            'daily' => 90,   // 保留最近90天的天级数据
            'weekly' => 52,  // 保留最近52周的周级数据
        ],
    ],
    
    // 白名单配置，用于忽略特定情况的告警
    'whitelist' => [
        'enabled' => true,
        'time_periods' => [
            // 维护窗口
            'maintenance' => [
                ['start' => '0 3 * * 0', 'end' => '0 5 * * 0'],  // 每周日 3:00-5:00
            ],
            // 节假日
            'holidays' => [
                '2024-02-10',  // 春节
                '2024-02-11',
                '2024-02-12',
                '2024-02-13',
                '2024-02-14',
                '2024-02-15',
                '2024-02-16',
            ],
        ],
        'conditions' => [
            // 特定条件下忽略告警
            ['metric' => 'sales', 'time' => '00:00-06:00', 'days' => ['sat', 'sun']],
        ],
    ],
    
    // 调试配置
    'debug' => [
        'enabled' => false,
        'log_level' => 'debug',  // debug, info, warning, error
        'simulation' => false,  // 启用模拟模式，不发送实际通知
        'test_notification' => false,  // 发送测试通知
    ],
];