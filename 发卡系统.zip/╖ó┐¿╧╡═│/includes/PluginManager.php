<?php

/**
 * 插件管理器
 * 
 * 负责插件的加载、注册、管理和生命周期控制
 * 支持动态加载插件、依赖管理、配置管理和钩子系统
 * 
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

require_once __DIR__ . '/Logger.php';

// 插件接口定义
interface PluginInterface {
    public function initialize();
    public function enable();
    public function disable();
    public function cleanup();
    public function getConfig();
    public function setConfig($config);
    public function getVersion();
    public function getName();
    public function getDescription();
    public function getInfo();
    public function getHooks();
    public function updateConfig($config);
}

class PluginManager {
    private static $instance = null;
    private $plugins = array();
    private $hooks = array();
    private $configs = array();
    private $dependencies = array();
    private $loadedPlugins = array();
    private $pluginPath;
    private $database;
    private $logger;
    
    /**
     * 获取单例实例
     * @return PluginManager
     */
    public static function getInstance($database = null, $logger = null) {
        if (self::$instance === null) {
            self::$instance = new self($database, $logger);
        }
        return self::$instance;
    }
    
    /**
     * 私有构造函数，防止外部实例化
     */
    private function __construct($database = null, $logger = null) {
        $this->pluginPath = __DIR__ . '/../plugins/';
        $this->database = $database;
        $this->logger = $logger ?: new Logger();
        
        // 初始化插件目录
        $this->initializePluginDirectory();
        
        // 加载已启用的插件
        $this->loadEnabledPlugins();
    }
    
    /**
     * 初始化插件目录结构
     */
    private function initializePluginDirectory() {
        $directories = array(
            'plugins/',
            'plugins/core/',
            'plugins/payment/',
            'plugins/verification/',
            'plugins/notifications/',
            'plugins/analytics/',
            'plugins/security/',
            'plugins/third-party/'
        );
        
        foreach ($directories as $dir) {
            $fullPath = __DIR__ . '/../' . $dir;
            if (!is_dir($fullPath)) {
                mkdir($fullPath, 0755, true);
            }
        }
    }
    
    /**
     * 注册插件
     */
    public function registerPlugin($pluginName, $pluginClass, $config = array()) {
        if (isset($this->plugins[$pluginName])) {
            throw new Exception("Plugin {$pluginName} is already registered");
        }
        
        $this->plugins[$pluginName] = array(
            'class' => $pluginClass,
            'config' => $config,
            'status' => 'registered',
            'registered_at' => date('Y-m-d H:i:s')
        );
        
        $this->logger->info("Plugin registered", array(
              'plugin' => $pluginName,
              'class' => $pluginClass
          ));
        
        return true;
    }
    
    /**
     * 加载插件
     */
    public function loadPlugin($pluginName) {
        if (!isset($this->plugins[$pluginName])) {
            throw new Exception("Plugin {$pluginName} is not registered");
        }
        
        if (isset($this->loadedPlugins[$pluginName])) {
            return $this->loadedPlugins[$pluginName];
        }
        
        $pluginInfo = $this->plugins[$pluginName];
        $pluginClass = $pluginInfo['class'];
        $config = $pluginInfo['config'];
        
        // 检查依赖
        if (!$this->checkDependencies($pluginName)) {
            throw new Exception("Plugin {$pluginName} dependencies not satisfied");
        }
        
        // 加载插件文件
        $pluginFile = $this->getPluginFile($pluginName);
        if (file_exists($pluginFile)) {
            require_once $pluginFile;
        }
        
        // 检查类是否存在
        if (!class_exists($pluginClass)) {
            throw new Exception("Plugin class {$pluginClass} not found");
        }
        
        $plugin = new $pluginClass($this->database, $config);
        
        if (method_exists($plugin, 'init')) {
            $plugin->init();
        }
        
        $this->loadedPlugins[$pluginName] = $plugin;
        $this->plugins[$pluginName]['loaded'] = true;
        $this->plugins[$pluginName]['instance'] = $plugin;
        
        if (method_exists($plugin, 'getDependencies')) {
            $dependencies = $plugin->getDependencies();
            $this->dependencies[$pluginName] = $dependencies;
        }
        
        if (method_exists($plugin, 'getHooks')) {
            $hooks = $plugin->getHooks();
            foreach ($hooks as $hook => $method) {
                $this->registerHook($hook, $pluginName, $method);
            }
        }
        
        $this->logger->info("Plugin loaded", array(
            'plugin' => $pluginName
        ));
        
        return true;
    }
    

    /**
     * 卸载插件
     */
    public function unloadPlugin($pluginName) {
        if (!isset($this->loadedPlugins[$pluginName])) {
            return true;
        }

        $plugin = $this->loadedPlugins[$pluginName];

        // 调用插件清理方法
        if (method_exists($plugin, 'cleanup')) {
            $plugin->cleanup();
        }
        
        // 移除插件钩子
        $this->removePluginHooks($pluginName);
        
        unset($this->loadedPlugins[$pluginName]);
        $this->plugins[$pluginName]['loaded'] = false;
        
        $this->logger->info("Plugin unloaded", array(
             'plugin' => $pluginName
         ));
        
        return true;
    }
    
    /**
     * 启用插件
     */
    public function enablePlugin($pluginName) {
        if (!isset($this->plugins[$pluginName])) {
            throw new Exception("Plugin {$pluginName} is not registered");
        }
        
        $plugin = $this->loadPlugin($pluginName);
        
        if (method_exists($plugin, 'enable')) {
            $plugin->enable();
        }
        
        $this->plugins[$pluginName]['status'] = 'enabled';
        $this->plugins[$pluginName]['enabled_at'] = date('Y-m-d H:i:s');
        
        // 保存到数据库
        $this->savePluginStatus($pluginName, 'enabled');
        
        $this->logger->info("Plugin enabled", array(
            'plugin' => $pluginName
        ));
        
        return true;
    }
    
    /**
     * 禁用插件
     */
    public function disablePlugin($pluginName) {
        if (!isset($this->loadedPlugins[$pluginName])) {
            return true;
        }
        
        $plugin = $this->loadedPlugins[$pluginName];
        
        if (method_exists($plugin, 'disable')) {
            $plugin->disable();
        }
        
        $this->plugins[$pluginName]['status'] = 'disabled';
        $this->plugins[$pluginName]['disabled_at'] = date('Y-m-d H:i:s');
        
        // 保存到数据库
        $this->savePluginStatus($pluginName, 'disabled');
        
        $this->logger->info("Plugin disabled", array(
            'plugin' => $pluginName
        ));
        
        return true;
    }
    
    /**
     * 注册钩子
     */
    public function registerHook($hookName, $callback, $priority = 10) {
        if (!isset($this->hooks[$hookName])) {
            $this->hooks[$hookName] = array();
        }
        
        array_push($this->hooks[$hookName], array(
            'callback' => $callback,
            'priority' => $priority
        ));        
        // 按优先级排序
        usort($this->hooks[$hookName], function($a, $b) {
            return $a['priority'] - $b['priority'];
        });
        return true;
    }
    
    /**
     * 执行钩子
     */
    public function executeHook($hookName, $data = null) {
        if (!isset($this->hooks[$hookName])) {
            return $data;
        }
        
        $result = $data;
        
        foreach ($this->hooks[$hookName] as $hook) {
            try {
                $result = call_user_func($hook['callback'], $result);
            } catch (Exception $e) {
                $this->logger->error("Hook execution failed", array(
                    'hook' => $hookName,
                    'error' => $e->getMessage()
                ));
            }
        }
        
        return $result;
    }
    
    /**
     * 扫描插件目录
     */
    public function scanPlugins() {
        $plugins = array();
        
        $directories = array(
            'plugins/core/',
            'plugins/payment/',
            'plugins/verification/',
            'plugins/notifications/',
            'plugins/analytics/',
            'plugins/security/',
            'plugins/third-party/'
        );
        
        foreach ($directories as $dir) {
            $fullPath = __DIR__ . '/../' . $dir;
            if (is_dir($fullPath)) {
                $items = scandir($fullPath);
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }
                    
                    $pluginPath = $fullPath . $item;
                    if (is_dir($pluginPath)) {
                        $pluginInfo = $this->parsePluginInfo($pluginPath);
                        if ($pluginInfo) {
                            $plugins[$item] = $pluginInfo;
                        }
                    }
                }
            }
        }
        
        return $plugins;
    }
    
    /**
     * 解析插件信息
     */
    private function parsePluginInfo($pluginPath) {
        $manifestFile = $pluginPath . '/plugin.json';
        
        if (!file_exists($manifestFile)) {
            return null;
        }
        
        $manifest = json_decode(file_get_contents($manifestFile), true);
        if (!$manifest) {
            return null;
        }
        
        return array_merge(array(
            'path' => $pluginPath,
            'main_file' => $pluginPath . '/' . (isset($manifest['main_file']) ? $manifest['main_file'] : 'plugin.php'),
            'config_file' => $pluginPath . '/' . (isset($manifest['config_file']) ? $manifest['config_file'] : 'config.json')
        ), $manifest);
    }
    
    /**
     * 自动发现并注册插件
     */
    public function autoDiscoverPlugins() {
        $discoveredPlugins = $this->scanPlugins();
        
        foreach ($discoveredPlugins as $pluginName => $pluginInfo) {
            if (!isset($this->plugins[$pluginName])) {
                $this->registerPlugin(
                    $pluginName,
                    isset($pluginInfo['class']) ? $pluginInfo['class'] : ucfirst($pluginName) . 'Plugin',
                    isset($pluginInfo['config']) ? $pluginInfo['config'] : array()
                );
            }
        }
        
        return count($discoveredPlugins);
    }
    
    /**
     * 加载已启用的插件
     */
    private function loadEnabledPlugins() {
        if (!$this->database) {
            return;
        }
        
        try {
            $db = $this->database->getConnection();
            $sql = "SELECT plugin_name FROM plugins WHERE status = 'enabled'";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            
            $enabledPlugins = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($enabledPlugins as $pluginName) {
                try {
                    $this->enablePlugin($pluginName);
                } catch (Exception $e) {
                    $this->logger->error("Failed to load enabled plugin", array(
                        'plugin' => $pluginName,
                        'error' => $e->getMessage()
                    ));
                }
            }
        } catch (Exception $e) {
            $this->logger->error("Failed to load enabled plugins", array(
                'error' => $e->getMessage()
            ));
        }
    }
    
    /**
     * 保存插件状态到数据库
     */
    private function savePluginStatus($pluginName, $status) {
        if (!$this->database) {
            return;
        }
        
        try {
            $db = $this->database->getConnection();
            $sql = "INSERT INTO plugins (plugin_name, status, updated_at) 
                    VALUES (?, ?, NOW()) 
                    ON DUPLICATE KEY UPDATE status = ?, updated_at = NOW()";
            
            $stmt = $db->prepare($sql);
            $stmt->execute(array($pluginName, $status, $status));
        } catch (Exception $e) {
            $this->logger->error("Failed to save plugin status", array(
                'plugin' => $pluginName,
                'status' => $status,
                'error' => $e->getMessage()
            ));
        }
    }
    
    /**
     * 检查插件依赖
     */
    private function checkDependencies($pluginName) {
        if (!isset($this->dependencies[$pluginName])) {
            return true;
        }
        
        $dependencies = $this->dependencies[$pluginName];
        
        foreach ($dependencies as $dep) {
            if (!isset($this->loadedPlugins[$dep])) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 注册插件钩子
     */
    private function registerPluginHooks($plugin, $pluginName) {
        if (method_exists($plugin, 'getHooks')) {
            $hooks = $plugin->getHooks();
            foreach ($hooks as $hookName => $callback) {
                $this->registerHook($hookName, $callback);
            }
        }
    }
    
    /**
     * 移除插件钩子
     */
    private function removePluginHooks($pluginName) {
        foreach ($this->hooks as $hookName => $hooks) {
            $this->hooks[$hookName] = array_filter($hooks, function($hook) use ($pluginName) {
                return !isset($hook['plugin']) || $hook['plugin'] !== $pluginName;
            });
        }
    }
    
    /**
     * 获取插件文件路径
     */
    private function getPluginFile($pluginName) {
        if (isset($this->plugins[$pluginName]['path'])) {
            return $this->plugins[$pluginName]['path'] . '/plugin.php';
        }
        
        return $this->pluginPath . $pluginName . '/plugin.php';
    }
    
    /**
     * 获取已加载的插件列表
     */
    public function getLoadedPlugins() {
        return $this->loadedPlugins;
    }
    
    /**
     * 获取已启用的插件列表
     */
    public function getEnabledPlugins() {
        $enabledPlugins = array();
        
        foreach ($this->loadedPlugins as $pluginName => $plugin) {
            if ($this->isPluginEnabled($pluginName)) {
                $enabledPlugins[$pluginName] = $plugin;
            }
        }
        
        return $enabledPlugins;
    }
    
    /**
     * 获取已注册的插件列表
     */
    public function getRegisteredPlugins() {
        return $this->plugins;
    }
    
    /**
     * 获取插件信息
     */
    public function getPluginInfo($pluginName) {
        return isset($this->plugins[$pluginName]) ? $this->plugins[$pluginName] : null;
    }
    
    /**
     * 检查插件是否已加载
     */
    public function isPluginLoaded($pluginName) {
        return isset($this->loadedPlugins[$pluginName]);
    }
    
    /**
     * 检查插件是否已启用
     */
    public function isPluginEnabled($pluginName) {
        return isset($this->plugins[$pluginName]) && 
               $this->plugins[$pluginName]['status'] === 'enabled';
    }
    
    /**
     * 获取插件配置
     */
    public function getPluginConfig($pluginName) {
        return isset($this->plugins[$pluginName]['config']) ? $this->plugins[$pluginName]['config'] : array();
    }
    
    /**
     * 更新插件配置
     */
    public function updatePluginConfig($pluginName, $config) {
        if (!isset($this->plugins[$pluginName])) {
            return false;
        }
        
        $this->plugins[$pluginName]['config'] = $config;
        
        // 如果插件已加载，更新配置
        if (isset($this->loadedPlugins[$pluginName])) {
            $plugin = $this->loadedPlugins[$pluginName];
            if (method_exists($plugin, 'updateConfig')) {
                $plugin->updateConfig($config);
            }
        }
        
        return true;
    }
    
    /**
     * 安装插件
     */
    public function installPlugin($pluginPath) {
        if (!file_exists($pluginPath)) {
            throw new Exception("Plugin path does not exist: {$pluginPath}");
        }
        
        $pluginInfo = $this->parsePluginInfo($pluginPath);
        if (!$pluginInfo) {
            throw new Exception("Invalid plugin manifest");
        }
        
        $pluginName = $pluginInfo['name'];
        
        // 复制插件文件到插件目录
        $targetPath = $this->pluginPath . $pluginName;
        if (!is_dir($targetPath)) {
            mkdir($targetPath, 0755, true);
        }
        
        $this->recursiveCopy($pluginPath, $targetPath);
        
        // 注册插件
        $this->registerPlugin(
            $pluginName,
            isset($pluginInfo['class']) ? $pluginInfo['class'] : ucfirst($pluginName) . 'Plugin',
            isset($pluginInfo['config']) ? $pluginInfo['config'] : array()
        );
        
        $this->logger->info("Plugin installed", array(
            'plugin' => $pluginName,
            'path' => $targetPath
        ));
        
        return true;
    }
    
    /**
     * 卸载插件
     */
    public function uninstallPlugin($pluginName) {
        // 禁用并卸载插件
        if ($this->isPluginEnabled($pluginName)) {
            $this->disablePlugin($pluginName);
        }
        
        if ($this->isPluginLoaded($pluginName)) {
            $this->unloadPlugin($pluginName);
        }
        
        // 删除插件注册信息
        unset($this->plugins[$pluginName]);
        
        // 删除插件文件
        $pluginPath = $this->pluginPath . $pluginName;
        if (is_dir($pluginPath)) {
            $this->recursiveDelete($pluginPath);
        }
        
        // 从数据库删除
        if ($this->database) {
            try {
                $db = $this->database->getConnection();
                $sql = "DELETE FROM plugins WHERE plugin_name = ?";
                $stmt = $db->prepare($sql);
                $stmt->execute(array($pluginName));
            } catch (Exception $e) {
                $this->logger->error("Failed to remove plugin from database", array(
                    'plugin' => $pluginName,
                    'error' => $e->getMessage()
                ));
            }
        }
        
        $this->logger->info("Plugin uninstalled", array(
            'plugin' => $pluginName
        ));
        
        return true;
    }
    
    /**
     * 递归复制目录
     */
    private function recursiveCopy($src, $dst) {
        $dir = opendir($src);
        @mkdir($dst);
        
        while (false !== ($file = readdir($dir))) {
            if (($file != '.') && ($file != '..')) {
                if (is_dir($src . '/' . $file)) {
                    $this->recursiveCopy($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        
        closedir($dir);
    }
    
    /**
     * 递归删除目录
     */
    private function recursiveDelete($dir) {
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        
        foreach (scandir($dir) as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->recursiveDelete($path) : unlink($path);
        }
        
        return rmdir($dir);
    }
    
    /**
     * 初始化插件管理器
     */
    public function initialize() {
        $this->logger->info("Plugin manager initializing");
        
        // 确保插件目录存在
        $this->initializePluginDirectory();
        
        // 加载已启用的插件
        $this->loadEnabledPlugins();
        
        $this->logger->info("Plugin manager initialized successfully");
        
        return true;
    }

/**
 * 基础插件类
 * 提供插件的基础功能实现
 */
abstract class BasePlugin implements PluginInterface {
    protected $config;
    protected $database;
    protected $logger;
    protected $name;
    protected $version;
    protected $description;
    
    public function __construct($config = array(), $database = null, $logger = null) {
        $this->config = $config;
        $this->database = $database;
        $this->logger = $logger ?: new Logger();
    }
    
    public function initialize() {
        $this->logger->info("Plugin initializing", array(
            'plugin' => $this->name,
            'version' => $this->version
        ));
    }
    
    public function enable() {
        $this->logger->info("Plugin enabled", array(
            'plugin' => $this->name
        ));
    }
    
    public function disable() {
        $this->logger->info("Plugin disabled", array(
            'plugin' => $this->name
        ));
    }
    
    public function cleanup() {
        $this->logger->info("Plugin cleanup", array(
            'plugin' => $this->name
        ));
    }
    
    public function getConfig() {
        return $this->config;
    }
    
    public function setConfig($config) {
        $this->config = $config;
    }
    
    public function getVersion() {
        return $this->version;
    }
    
    public function getName() {
        return $this->name;
    }
    
    public function getDescription() {
        return $this->description;
    }
    
    public function getInfo() {
        return array(
            'name' => $this->name,
            'version' => $this->version,
            'description' => $this->description,
            'config' => $this->config
        );
    }
    
    public function getHooks() {
        return array();
    }
    
    public function updateConfig($config) {
        $this->config = array_merge($this->config, $config);
    }
    
    protected function getConfigValue($key, $default = null) {
        return isset($this->config[$key]) ? $this->config[$key] : $default;
    }
    
    protected function setConfigValue($key, $value) {
        $this->config[$key] = $value;
    }
}
?>