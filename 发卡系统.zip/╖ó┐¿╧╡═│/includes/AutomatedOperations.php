<?php
/**
 * 自动化运维系统
 * 实现自动部署、版本回滚、故障自愈等运维功能
 */

class AutomatedOperations {
    private $db;
    private $config;
    private $logger;
    private $deploy_history = [];
    private $health_checks = [];
    
    /**
     * 构造函数
     */
    public function __construct($db, $config = []) {
        $this->db = $db;
        $this->config = array_merge([
            'deploy_path' => '/var/www/card-system',
            'backup_path' => '/var/backups/card-system',
            'git_repo' => 'https://github.com/your-org/card-system.git',
            'deploy_branch' => 'main',
            'health_check_endpoint' => 'http://localhost/api/health',
            'max_rollback_versions' => 10,
            'notification_email' => 'admin@example.com',
            'maintenance_mode_file' => '/var/www/card-system/maintenance.html',
            'services' => [
                'nginx',
                'php-fpm',
                'mysql',
                'redis'
            ],
            'auto_heal_enabled' => true,
            'deploy_timeout' => 300, // 5分钟
        ], $config);
        
        $this->logger = new AuditLogger($db);
        $this->loadDeployHistory();
        $this->setupHealthChecks();
    }
    
    /**
     * 部署新版本
     */
    public function deploy($branch = null, $commit_hash = null) {
        $this->logOperation('deployment_start', ['branch' => $branch, 'commit' => $commit_hash]);
        
        try {
            // 创建备份
            $backup_id = $this->createBackup();
            
            // 进入维护模式
            $this->enableMaintenanceMode();
            
            // 执行部署
            $deploy_result = $this->executeDeployment($branch, $commit_hash);
            
            // 健康检查
            $health_check_passed = $this->runHealthCheck();
            
            if ($health_check_passed) {
                // 部署成功
                $this->disableMaintenanceMode();
                $this->saveDeployRecord($backup_id, $branch, $commit_hash, true);
                $this->notifySuccess('部署成功', $deploy_result);
                $this->logOperation('deployment_success', $deploy_result);
                return ['status' => 'success', 'message' => '部署成功', 'deploy_id' => $backup_id];
            } else {
                // 回滚
                $this->rollback($backup_id);
                $this->disableMaintenanceMode();
                $this->saveDeployRecord($backup_id, $branch, $commit_hash, false);
                $this->notifyFailure('部署失败，已自动回滚', ['error' => '健康检查失败']);
                $this->logOperation('deployment_failed', ['error' => '健康检查失败']);
                return ['status' => 'error', 'message' => '部署失败，已自动回滚'];
            }
        } catch (Exception $e) {
            // 发生错误，回滚
            $this->disableMaintenanceMode();
            $this->notifyFailure('部署过程中发生错误', ['error' => $e->getMessage()]);
            $this->logOperation('deployment_error', ['error' => $e->getMessage()]);
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 回滚到指定版本
     */
    public function rollback($backup_id) {
        $this->logOperation('rollback_start', ['backup_id' => $backup_id]);
        
        try {
            // 验证备份存在
            if (!file_exists($this->config['backup_path'] . '/' . $backup_id . '.tar.gz')) {
                throw new Exception('备份文件不存在');
            }
            
            // 创建回滚前的备份
            $pre_rollback_backup = $this->createBackup('pre_rollback');
            
            // 进入维护模式
            $this->enableMaintenanceMode();
            
            // 执行回滚
            $this->extractBackup($backup_id);
            
            // 重启服务
            $this->restartServices();
            
            // 健康检查
            $health_check_passed = $this->runHealthCheck();
            
            if ($health_check_passed) {
                $this->disableMaintenanceMode();
                $this->logOperation('rollback_success', ['backup_id' => $backup_id]);
                $this->notifySuccess('回滚成功', ['backup_id' => $backup_id]);
                return ['status' => 'success', 'message' => '回滚成功'];
            } else {
                // 回滚失败，恢复到回滚前状态
                $this->extractBackup($pre_rollback_backup);
                $this->restartServices();
                $this->disableMaintenanceMode();
                $this->logOperation('rollback_failed', ['backup_id' => $backup_id]);
                $this->notifyFailure('回滚失败，已恢复', ['backup_id' => $backup_id]);
                return ['status' => 'error', 'message' => '回滚失败，已恢复到回滚前状态'];
            }
        } catch (Exception $e) {
            $this->disableMaintenanceMode();
            $this->logOperation('rollback_error', ['error' => $e->getMessage()]);
            $this->notifyFailure('回滚过程中发生错误', ['error' => $e->getMessage()]);
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 运行系统健康检查
     */
    public function runHealthCheck() {
        $this->logOperation('health_check_start');
        
        $results = [];
        $all_passed = true;
        
        foreach ($this->health_checks as $check_name => $check_function) {
            try {
                $result = call_user_func($check_function);
                $results[$check_name] = $result;
                
                if (!$result['passed']) {
                    $all_passed = false;
                }
            } catch (Exception $e) {
                $results[$check_name] = [
                    'passed' => false,
                    'error' => $e->getMessage()
                ];
                $all_passed = false;
            }
        }
        
        $this->logOperation('health_check_complete', ['passed' => $all_passed, 'results' => $results]);
        
        // 如果健康检查失败且开启了自动修复
        if (!$all_passed && $this->config['auto_heal_enabled']) {
            $this->attemptAutoHeal($results);
        }
        
        return $all_passed;
    }
    
    /**
     * 自动修复系统故障
     */
    public function attemptAutoHeal($health_check_results) {
        $this->logOperation('auto_heal_start', ['failed_checks' => $health_check_results]);
        
        $healing_actions = [];
        
        foreach ($health_check_results as $check_name => $result) {
            if (!$result['passed']) {
                switch ($check_name) {
                    case 'service_check':
                        // 重启失败的服务
                        foreach ($result['failed_services'] as $service) {
                            $healing_actions[] = $this->restartService($service);
                        }
                        break;
                    
                    case 'database_check':
                        // 数据库连接问题，尝试重启MySQL服务
                        $healing_actions[] = $this->restartService('mysql');
                        break;
                    
                    case 'redis_check':
                        // Redis连接问题，尝试重启Redis服务
                        $healing_actions[] = $this->restartService('redis');
                        break;
                    
                    case 'file_permission_check':
                        // 文件权限问题，修复权限
                        $healing_actions[] = $this->fixFilePermissions();
                        break;
                    
                    case 'api_check':
                        // API响应问题，重启PHP-FPM和Nginx
                        $healing_actions[] = $this->restartService('php-fpm');
                        $healing_actions[] = $this->restartService('nginx');
                        break;
                }
            }
        }
        
        // 再次运行健康检查确认修复
        $healing_successful = $this->runHealthCheck();
        
        $this->logOperation('auto_heal_complete', [
            'successful' => $healing_successful,
            'actions' => $healing_actions
        ]);
        
        if ($healing_successful) {
            $this->notifySuccess('自动修复成功', ['actions' => $healing_actions]);
        } else {
            $this->notifyFailure('自动修复失败，需要人工干预', ['actions' => $healing_actions]);
        }
        
        return $healing_successful;
    }
    
    /**
     * 获取部署历史
     */
    public function getDeployHistory($limit = 20) {
        $query = "SELECT * FROM deploy_history ORDER BY deployed_at DESC LIMIT ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$limit]);
        
        return $stmt->fetchAll();
    }
    
    /**
     * 清理旧备份
     */
    public function cleanupOldBackups() {
        $this->logOperation('cleanup_start');
        
        // 获取备份列表
        $backups = glob($this->config['backup_path'] . '/*.tar.gz');
        sort($backups, SORT_NUMERIC);
        
        // 删除超过保留数量的备份
        while (count($backups) > $this->config['max_rollback_versions']) {
            $oldest_backup = array_shift($backups);
            if (file_exists($oldest_backup)) {
                unlink($oldest_backup);
                $this->logOperation('backup_cleanup', ['deleted' => $oldest_backup]);
            }
        }
        
        $this->logOperation('cleanup_complete');
        return count($backups);
    }
    
    /**
     * 执行定时维护任务
     */
    public function runScheduledMaintenance() {
        $this->logOperation('scheduled_maintenance_start');
        
        try {
            // 运行数据库优化
            $this->optimizeDatabase();
            
            // 清理日志文件
            $this->cleanupLogs();
            
            // 清理旧备份
            $this->cleanupOldBackups();
            
            // 检查磁盘空间
            $this->checkDiskSpace();
            
            $this->logOperation('scheduled_maintenance_complete');
            return ['status' => 'success', 'message' => '定时维护完成'];
        } catch (Exception $e) {
            $this->logOperation('scheduled_maintenance_error', ['error' => $e->getMessage()]);
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 获取系统状态概览
     */
    public function getSystemStatus() {
        $performance_monitor = new PerformanceMonitor($this->db);
        $metrics = $performance_monitor->collectMetrics();
        
        $status = [
            'timestamp' => time(),
            'health_status' => $this->runHealthCheck() ? 'healthy' : 'degraded',
            'performance' => $metrics,
            'deploy_status' => $this->getCurrentDeployStatus(),
            'recent_alerts' => $performance_monitor->getCurrentAlerts(),
            'service_status' => $this->checkServices(),
            'disk_space' => $metrics['disk'] ?? [],
        ];
        
        return $status;
    }
    
    // ------------------------- 私有辅助方法 ------------------------- //
    
    /**
     * 创建系统备份
     */
    private function createBackup($prefix = '') {
        $backup_id = ($prefix ? $prefix . '_' : '') . date('YmdHis') . '_' . uniqid();
        $backup_file = $this->config['backup_path'] . '/' . $backup_id . '.tar.gz';
        
        // 确保备份目录存在
        if (!file_exists($this->config['backup_path'])) {
            mkdir($this->config['backup_path'], 0755, true);
        }
        
        // 创建备份命令
        $command = "tar -czf {$backup_file} -C {$this->config['deploy_path']} .";
        
        $this->logOperation('backup_start', ['backup_id' => $backup_id]);
        
        // 执行备份
        exec($command, $output, $return_var);
        
        if ($return_var === 0) {
            $this->logOperation('backup_complete', ['backup_id' => $backup_id]);
            return $backup_id;
        } else {
            throw new Exception('备份创建失败: ' . implode("\n", $output));
        }
    }
    
    /**
     * 提取备份文件
     */
    private function extractBackup($backup_id) {
        $backup_file = $this->config['backup_path'] . '/' . $backup_id . '.tar.gz';
        
        if (!file_exists($backup_file)) {
            throw new Exception('备份文件不存在: ' . $backup_file);
        }
        
        // 提取备份
        $command = "tar -xzf {$backup_file} -C {$this->config['deploy_path']}";
        
        exec($command, $output, $return_var);
        
        if ($return_var !== 0) {
            throw new Exception('备份提取失败: ' . implode("\n", $output));
        }
        
        // 修复文件权限
        $this->fixFilePermissions();
    }
    
    /**
     * 执行部署
     */
    private function executeDeployment($branch, $commit_hash) {
        $target_branch = $branch ?: $this->config['deploy_branch'];
        $deploy_path = $this->config['deploy_path'];
        
        // 克隆或拉取代码
        if (!file_exists($deploy_path . '/.git')) {
            // 首次部署
            $command = "git clone -b {$target_branch} {$this->config['git_repo']} {$deploy_path}";
        } else {
            // 更新代码
            $command = "cd {$deploy_path} && git fetch origin && git checkout {$target_branch} && git pull origin {$target_branch}";
        }
        
        exec($command, $output, $return_var);
        
        if ($return_var !== 0) {
            throw new Exception('代码更新失败: ' . implode("\n", $output));
        }
        
        // 如果指定了特定提交，切换到该提交
        if ($commit_hash) {
            $command = "cd {$deploy_path} && git checkout {$commit_hash}";
            exec($command, $output, $return_var);
            
            if ($return_var !== 0) {
                throw new Exception('切换到指定提交失败: ' . implode("\n", $output));
            }
        }
        
        // 安装依赖
        $this->installDependencies();
        
        // 运行数据库迁移
        $this->runDatabaseMigrations();
        
        // 清理缓存
        $this->clearCache();
        
        return [
            'branch' => $target_branch,
            'commit_hash' => $commit_hash,
            'deploy_time' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * 安装依赖
     */
    private function installDependencies() {
        $command = "cd {$this->config['deploy_path']} && composer install --no-dev --optimize-autoloader";
        exec($command, $output, $return_var);
        
        if ($return_var !== 0) {
            throw new Exception('依赖安装失败: ' . implode("\n", $output));
        }
    }
    
    /**
     * 运行数据库迁移
     */
    private function runDatabaseMigrations() {
        $command = "cd {$this->config['deploy_path']} && php migrate.php";
        exec($command, $output, $return_var);
        
        if ($return_var !== 0) {
            throw new Exception('数据库迁移失败: ' . implode("\n", $output));
        }
    }
    
    /**
     * 清理缓存
     */
    private function clearCache() {
        // 清理Redis缓存
        try {
            $redis = new Redis();
            $redis->connect('127.0.0.1', 6379);
            $redis->flushDB();
            $redis->close();
        } catch (Exception $e) {
            $this->logOperation('cache_clear_warning', ['error' => $e->getMessage()]);
        }
        
        // 清理应用缓存目录
        $cache_dir = $this->config['deploy_path'] . '/cache';
        if (file_exists($cache_dir)) {
            $this->deleteDirectory($cache_dir);
            mkdir($cache_dir, 0755, true);
        }
    }
    
    /**
     * 启用维护模式
     */
    private function enableMaintenanceMode() {
        $maintenance_content = file_get_contents($this->config['deploy_path'] . '/templates/maintenance.html');
        file_put_contents($this->config['maintenance_mode_file'], $maintenance_content);
        $this->logOperation('maintenance_mode_enabled');
    }
    
    /**
     * 禁用维护模式
     */
    private function disableMaintenanceMode() {
        if (file_exists($this->config['maintenance_mode_file'])) {
            unlink($this->config['maintenance_mode_file']);
        }
        $this->logOperation('maintenance_mode_disabled');
    }
    
    /**
     * 重启所有服务
     */
    private function restartServices() {
        foreach ($this->config['services'] as $service) {
            $this->restartService($service);
        }
    }
    
    /**
     * 重启单个服务
     */
    private function restartService($service) {
        // 根据操作系统使用不同的命令
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $command = "net stop {$service} && net start {$service}";
        } else {
            $command = "systemctl restart {$service}";
        }
        
        exec($command, $output, $return_var);
        
        $result = ['service' => $service, 'success' => $return_var === 0];
        $this->logOperation('service_restart', $result);
        
        return $result;
    }
    
    /**
     * 检查服务状态
     */
    private function checkServices() {
        $results = [];
        
        foreach ($this->config['services'] as $service) {
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                $command = "sc query {$service}";
                exec($command, $output);
                $results[$service] = ['running' => strpos(implode(' ', $output), 'RUNNING') !== false];
            } else {
                $command = "systemctl is-active {$service}";
                exec($command, $output, $return_var);
                $results[$service] = ['running' => $return_var === 0];
            }
        }
        
        return $results;
    }
    
    /**
     * 设置健康检查项
     */
    private function setupHealthChecks() {
        // 服务检查
        $this->health_checks['service_check'] = function() {
            $services = $this->checkServices();
            $failed_services = [];
            
            foreach ($services as $service => $status) {
                if (!$status['running']) {
                    $failed_services[] = $service;
                }
            }
            
            return [
                'passed' => empty($failed_services),
                'failed_services' => $failed_services
            ];
        };
        
        // 数据库连接检查
        $this->health_checks['database_check'] = function() {
            try {
                $stmt = $this->db->prepare("SELECT 1");
                $stmt->execute();
                return ['passed' => true];
            } catch (Exception $e) {
                return ['passed' => false, 'error' => $e->getMessage()];
            }
        };
        
        // Redis连接检查
        $this->health_checks['redis_check'] = function() {
            try {
                $redis = new Redis();
                $connected = $redis->connect('127.0.0.1', 6379);
                if ($connected) {
                    $redis->close();
                }
                return ['passed' => $connected];
            } catch (Exception $e) {
                return ['passed' => false, 'error' => $e->getMessage()];
            }
        };
        
        // API健康检查
        $this->health_checks['api_check'] = function() {
            try {
                $ch = curl_init($this->config['health_check_endpoint']);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                $response = curl_exec($ch);
                $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                $data = json_decode($response, true);
                return ['passed' => $status_code === 200 && $data['status'] === 'healthy'];
            } catch (Exception $e) {
                return ['passed' => false, 'error' => $e->getMessage()];
            }
        };
        
        // 文件权限检查
        $this->health_checks['file_permission_check'] = function() {
            $paths_to_check = [
                $this->config['deploy_path'] . '/uploads',
                $this->config['deploy_path'] . '/cache',
                $this->config['deploy_path'] . '/logs'
            ];
            
            $failed_paths = [];
            
            foreach ($paths_to_check as $path) {
                if (file_exists($path) && !is_writable($path)) {
                    $failed_paths[] = $path;
                }
            }
            
            return [
                'passed' => empty($failed_paths),
                'failed_paths' => $failed_paths
            ];
        };
    }
    
    /**
     * 修复文件权限
     */
    private function fixFilePermissions() {
        $command = "chown -R www-data:www-data {$this->config['deploy_path']} && chmod -R 755 {$this->config['deploy_path']}";
        exec($command, $output, $return_var);
        
        // 为特定目录设置更宽松的权限
        $writable_dirs = ['uploads', 'cache', 'logs'];
        foreach ($writable_dirs as $dir) {
            $full_path = $this->config['deploy_path'] . '/' . $dir;
            if (file_exists($full_path)) {
                exec("chmod -R 775 {$full_path}", $output, $return_var);
            }
        }
        
        return ['success' => $return_var === 0];
    }
    
    /**
     * 优化数据库
     */
    private function optimizeDatabase() {
        try {
            $tables = $this->db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($tables as $table) {
                $this->db->exec("OPTIMIZE TABLE {$table}");
                $this->db->exec("ANALYZE TABLE {$table}");
            }
            
            $this->logOperation('database_optimized');
        } catch (Exception $e) {
            $this->logOperation('database_optimize_error', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * 清理日志文件
     */
    private function cleanupLogs() {
        $log_dir = $this->config['deploy_path'] . '/logs';
        if (file_exists($log_dir)) {
            $logs = glob($log_dir . '/*.log.*');
            foreach ($logs as $log) {
                if (file_exists($log)) {
                    unlink($log);
                }
            }
            
            // 压缩当前日志
            $current_log = $log_dir . '/app.log';
            if (file_exists($current_log) && filesize($current_log) > 10485760) { // 10MB
                $archive_log = $current_log . '.' . date('YmdHis') . '.gz';
                $content = file_get_contents($current_log);
                file_put_contents($archive_log, gzencode($content));
                file_put_contents($current_log, '');
            }
        }
    }
    
    /**
     * 检查磁盘空间
     */
    private function checkDiskSpace() {
        $disk_space = disk_free_space($this->config['deploy_path']);
        $disk_total = disk_total_space($this->config['deploy_path']);
        $disk_usage = 100 - (($disk_space / $disk_total) * 100);
        
        if ($disk_usage > 90) {
            $this->notifyWarning('磁盘空间不足', ['usage_percent' => $disk_usage]);
        }
        
        return ['usage_percent' => $disk_usage, 'free_bytes' => $disk_space];
    }
    
    /**
     * 获取当前部署状态
     */
    private function getCurrentDeployStatus() {
        $query = "SELECT * FROM deploy_history ORDER BY deployed_at DESC LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        return $stmt->fetch() ?: ['status' => 'unknown'];
    }
    
    /**
     * 保存部署记录
     */
    private function saveDeployRecord($backup_id, $branch, $commit_hash, $success) {
        $query = "INSERT INTO deploy_history (
            backup_id, branch, commit_hash, status, deployed_by, deployed_at
        ) VALUES (?, ?, ?, ?, ?, NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([
            $backup_id,
            $branch,
            $commit_hash,
            $success ? 'success' : 'failed',
            'automated'
        ]);
    }
    
    /**
     * 加载部署历史
     */
    private function loadDeployHistory() {
        $this->deploy_history = $this->getDeployHistory();
    }
    
    /**
     * 记录操作日志
     */
    private function logOperation($action, $details = []) {
        $this->logger->logSecurityEvent($action, $details, 'automated_operations');
    }
    
    /**
     * 发送成功通知
     */
    private function notifySuccess($subject, $details = []) {
        $this->sendNotification('success', $subject, $details);
    }
    
    /**
     * 发送警告通知
     */
    private function notifyWarning($subject, $details = []) {
        $this->sendNotification('warning', $subject, $details);
    }
    
    /**
     * 发送失败通知
     */
    private function notifyFailure($subject, $details = []) {
        $this->sendNotification('error', $subject, $details);
    }
    
    /**
     * 发送通知
     */
    private function sendNotification($type, $subject, $details = []) {
        // 这里可以实现邮件、短信、企业微信等多种通知方式
        $message = "[$type] $subject\n" . json_encode($details, JSON_PRETTY_PRINT);
        
        // 记录到日志
        $this->logOperation('notification_sent', ['type' => $type, 'subject' => $subject]);
        
        // 发送邮件通知
        mail($this->config['notification_email'], "[运维通知] $subject", $message);
    }
    
    /**
     * 删除目录
     */
    private function deleteDirectory($dir) {
        if (!file_exists($dir)) return true;
        if (!is_dir($dir)) return unlink($dir);
        
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') continue;
            if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) return false;
        }
        
        return rmdir($dir);
    }
    
    /**
     * 获取时间条件
     */
    private function getTimeCondition($time_range) {
        switch ($time_range) {
            case '1h': return "DATE_SUB(NOW(), INTERVAL 1 HOUR)";
            case '6h': return "DATE_SUB(NOW(), INTERVAL 6 HOUR)";
            case '24h': return "DATE_SUB(NOW(), INTERVAL 1 DAY)";
            case '7d': return "DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case '30d': return "DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default: return "DATE_SUB(NOW(), INTERVAL 1 DAY)";
        }
    }
}