<?php
/**
 * 性能监控组件
 * 监控系统性能指标，包括响应时间、内存使用、数据库查询等
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/ErrorLevel.php';

class PerformanceMonitor extends BaseService {
    private static $instance = null;
    protected $logger;
    protected $metrics = array();
    protected $startTime;
    protected $startMemory;
    protected $queries = array();
    protected $slowQueryThreshold = 1000; // 毫秒
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->logger = Logger::getInstance();
        $this->startTime = microtime(true);
        $this->startMemory = memory_get_usage(true);
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 开始计时
     */
    public function startTimer($name) {
        $this->metrics[$name] = array(
            'start_time' => microtime(true),
            'start_memory' => memory_get_usage(true),
            'end_time' => null,
            'end_memory' => null,
            'duration' => null,
            'memory_used' => null
        );
    }
    
    /**
     * 结束计时
     */
    public function endTimer($name) {
        if (!isset($this->metrics[$name])) {
            $this->logger->warning("性能监控: 计时器 '{$name}' 不存在");
            return;
        }
        
        $this->metrics[$name]['end_time'] = microtime(true);
        $this->metrics[$name]['end_memory'] = memory_get_usage(true);
        $this->metrics[$name]['duration'] = ($this->metrics[$name]['end_time'] - $this->metrics[$name]['start_time']) * 1000; // 毫秒
        $this->metrics[$name]['memory_used'] = $this->metrics[$name]['end_memory'] - $this->metrics[$name]['start_memory'];
        
        // 记录性能日志
        $this->logger->logPerformance($name, $this->metrics[$name]['duration'], array(
            'memory_used' => $this->metrics[$name]['memory_used'],
            'start_memory' => $this->metrics[$name]['start_memory'],
            'end_memory' => $this->metrics[$name]['end_memory']
        ));
        
        // 性能告警
        if ($this->metrics[$name]['duration'] > $this->slowQueryThreshold) {
            $this->logger->warning("性能警告: {$name} 执行时间过长", array(
                'duration_ms' => $this->metrics[$name]['duration'],
                'threshold_ms' => $this->slowQueryThreshold,
                'memory_used' => $this->metrics[$name]['memory_used']
            ));
        }
    }
    
    /**
     * 记录数据库查询
     */
    public function recordQuery($sql, $params = array(), $duration = null) {
        $query = array(
            'sql' => $sql,
            'params' => $params,
            'timestamp' => microtime(true),
            'duration' => $duration
        );
        
        array_push($this->queries, $query);
        
        // 慢查询告警
        if ($duration && $duration > $this->slowQueryThreshold) {
            $this->logger->warning("慢查询检测", array(
                'sql' => $sql,
                'params' => $params,
                'duration_ms' => $duration,
                'threshold_ms' => $this->slowQueryThreshold
            ));
        }
    }
    
    /**
     * 获取性能指标
     */
    public function getMetrics() {
        $totalTime = (microtime(true) - $this->startTime) * 1000;
        $totalMemory = memory_get_usage(true) - $this->startMemory;
        $peakMemory = memory_get_peak_usage(true);
        
        return array(
            'total_execution_time' => $totalTime,
            'total_memory_used' => $totalMemory,
            'peak_memory' => $peakMemory,
            'query_count' => count($this->queries),
            'total_query_time' => array_sum(array_column($this->queries, 'duration')),
            'timers' => $this->metrics,
            'queries' => $this->queries,
            'memory_usage' => array(
                'current' => memory_get_usage(true),
                'peak' => $peakMemory,
                'start' => $this->startMemory,
                'used' => $totalMemory
            )
        );
    }
    
    /**
     * 记录页面性能
     */
    public function recordPagePerformance($page, $additionalData = array()) {
        $metrics = $this->getMetrics();
        
        $performanceData = array_merge(array(
            'page' => $page,
            'execution_time' => $metrics['total_execution_time'],
            'memory_used' => $metrics['total_memory_used'],
            'peak_memory' => $metrics['peak_memory'],
            'query_count' => $metrics['query_count'],
            'total_query_time' => $metrics['total_query_time'],
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'ip_address' => $this->getClientIp(),
            'user_id' => $this->getCurrentUserId(),
            'timestamp' => date('Y-m-d H:i:s')
        ), $additionalData);
        
        // 记录到性能日志
        $this->logger->info('页面性能统计', $performanceData);
        
        // 性能告警
        if ($metrics['total_execution_time'] > 5000) { // 超过5秒
            $this->logger->warning("页面响应时间过长", array(
                'page' => $page,
                'execution_time' => $metrics['total_execution_time'],
                'threshold' => 5000
            ));
        }
        
        if ($metrics['total_memory_used'] > 50 * 1024 * 1024) { // 超过50MB
            $this->logger->warning("页面内存使用过多", array(
                'page' => $page,
                'memory_used' => $metrics['total_memory_used'],
                'threshold' => 50 * 1024 * 1024
            ));
        }
        
        return $performanceData;
    }
    
    /**
     * 记录API性能
     */
    public function recordApiPerformance($endpoint, $method, $responseCode, $additionalData = array()) {
        $metrics = $this->getMetrics();
        
        $apiData = array_merge(array(
            'endpoint' => $endpoint,
            'method' => $method,
            'response_code' => $responseCode,
            'execution_time' => $metrics['total_execution_time'],
            'memory_used' => $metrics['total_memory_used'],
            'query_count' => $metrics['query_count'],
            'total_query_time' => $metrics['total_query_time'],
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'ip_address' => $this->getClientIp(),
            'user_id' => $this->getCurrentUserId(),
            'timestamp' => date('Y-m-d H:i:s')
        ), $additionalData);
        
        // 记录到API性能日志
        $this->logger->info('API性能统计', $apiData);
        
        // API性能告警
        if ($metrics['total_execution_time'] > 2000) { // API超过2秒
            $this->logger->warning("API响应时间过长", array(
                'endpoint' => $endpoint,
                'method' => $method,
                'execution_time' => $metrics['total_execution_time'],
                'threshold' => 2000
            ));
        }
        
        return $apiData;
    }
    
    /**
     * 获取性能统计
     */
    public function getPerformanceStats($hours = 24) {
        $stats = array(
            'total_requests' => 0,
            'avg_response_time' => 0,
            'max_response_time' => 0,
            'min_response_time' => PHP_FLOAT_MAX,
            'avg_memory_usage' => 0,
            'max_memory_usage' => 0,
            'total_queries' => 0,
            'slow_queries' => 0,
            'error_rate' => 0,
            'by_hour' => array(),
            'by_endpoint' => array()
        );
        
        // 这里应该从日志文件或数据库中读取性能数据
        // 为了示例，这里返回模拟数据
        return $stats;
    }
    
    /**
     * 检查系统健康状态
     */
    public function checkSystemHealth() {
        $health = array(
            'status' => 'healthy',
            'checks' => array(),
            'timestamp' => date('Y-m-d H:i:s')
        );
        
        // 检查内存使用
        $memoryUsage = memory_get_usage(true);
        $memoryLimit = $this->parseMemoryLimit(ini_get('memory_limit'));
        $memoryUsagePercent = ($memoryUsage / $memoryLimit) * 100;
        
        $health['checks']['memory'] = array(
            'status' => $memoryUsagePercent < 80 ? 'ok' : 'warning',
            'usage' => $memoryUsage,
            'limit' => $memoryLimit,
            'percentage' => round($memoryUsagePercent, 2)
        );
        
        // 检查磁盘空间
        $diskFree = disk_free_space('/');
        $diskTotal = disk_total_space('/');
        $diskUsagePercent = (($diskTotal - $diskFree) / $diskTotal) * 100;
        
        $health['checks']['disk'] = array(
            'status' => $diskUsagePercent < 90 ? 'ok' : 'warning',
            'free' => $diskFree,
            'total' => $diskTotal,
            'percentage' => round($diskUsagePercent, 2)
        );
        
        // 检查数据库连接
        try {
            $database = Database::getInstance();
            $database->query("SELECT 1");
            $health['checks']['database'] = array(
                'status' => 'ok',
                'message' => '数据库连接正常'
            );
        } catch (Exception $e) {
            $health['checks']['database'] = array(
                'status' => 'error',
                'message' => '数据库连接失败: ' . $e->getMessage()
            );
            $health['status'] = 'unhealthy';
        }
        
        // 检查缓存
        try {
            $cache = CacheManager::getInstance();
            $cache->set('health_check', 'ok', 60);
            $result = $cache->get('health_check');
            $health['checks']['cache'] = array(
                'status' => $result === 'ok' ? 'ok' : 'warning',
                'message' => $result === 'ok' ? '缓存系统正常' : '缓存系统异常'
            );
        } catch (Exception $e) {
            $health['checks']['cache'] = array(
                'status' => 'error',
                'message' => '缓存系统不可用: ' . $e->getMessage()
            );
        }
        
        // 检查日志文件
        $logFile = LOG_PATH . '/app.log';
        $health['checks']['logs'] = array(
            'status' => is_writable(dirname($logFile)) ? 'ok' : 'error',
            'path' => $logFile,
            'writable' => is_writable(dirname($logFile))
        );
        
        return $health;
    }
    
    /**
     * 解析内存限制
     */
    protected function parseMemoryLimit($limit) {
        $limit = trim($limit);
        $last = strtolower($limit[strlen($limit) - 1]);
        $value = (int) $limit;
        
        switch ($last) {
            case 'g':
                $value *= 1024;
            case 'm':
                $value *= 1024;
            case 'k':
                $value *= 1024;
        }
        
        return $value;
    }
    
    /**
     * 获取客户端IP
     */
    protected function getClientIp() {
        $ipKeys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
        
        foreach ($ipKeys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
    }
    
    /**
     * 获取当前用户ID
     */
    protected function getCurrentUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}

// 初始化性能监控
$performanceMonitor = PerformanceMonitor::getInstance();

// 注册关闭函数来记录页面性能
// 使用命名函数替代匿名函数，确保PHP 5.3兼容
function recordPerformanceData() {
    global $performanceMonitor;
    
    $requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $requestMethod = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
    
    // 判断是否为API请求
    if (strpos($requestUri, '/api/') === 0) {
        $endpoint = parse_url($requestUri, PHP_URL_PATH);
        $responseCode = http_response_code();
        $performanceMonitor->recordApiPerformance($endpoint, $requestMethod, $responseCode);
    } else {
        $page = $requestUri ?: 'index';
        $performanceMonitor->recordPagePerformance($page);
    }
}

register_shutdown_function('recordPerformanceData');
?>