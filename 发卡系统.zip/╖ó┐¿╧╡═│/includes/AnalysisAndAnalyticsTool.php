<?php
/**
 * 数据分析与运营工具类
 * 提供推广效果统计、商户数据报表、业务监控大屏和用户行为画像等功能
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/../monitoring/BusinessMetricsMonitor.php';

class AnalysisAndAnalyticsTool {
    private $db;
    private $logger;
    private $businessMonitor;
    private $cache = [];
    private $cacheTimeout = 300; // 5分钟缓存

    /**
     * 构造函数
     */
    public function __construct() {
        $this->db = Database::getInstance();
        $this->logger = new Logger();
        $this->businessMonitor = new BusinessMetricsMonitor();
    }

    /**
     * 获取推广效果统计数据
     * 
     * @param string $period 时间周期 (day, week, month, quarter, year)
     * @param array $campaignIds 可选的推广活动ID列表
     * @return array 推广效果统计数据
     */
    public function getPromotionStats($period = 'month', $campaignIds = []) {
        try {
            $cacheKey = "promotion_stats_{$period}_" . (empty($campaignIds) ? 'all' : implode('_', $campaignIds));
            
            if (isset($this->cache[$cacheKey]) && (time() - $this->cache[$cacheKey]['timestamp']) < $this->cacheTimeout) {
                return $this->cache[$cacheKey]['data'];
            }

            $timeCondition = $this->getTimeCondition($period);
            $campaignCondition = empty($campaignIds) ? '' : "AND campaign_id IN (" . implode(',', $campaignIds) . ")";

            // 获取推广活动统计
            $campaignStatsQuery = "
                SELECT 
                    c.id as campaign_id,
                    c.name as campaign_name,
                    c.type as campaign_type,
                    COUNT(DISTINCT v.id) as visits,
                    COUNT(DISTINCT CASE WHEN v.converted = 1 THEN v.id END) as conversions,
                    SUM(o.total_amount) as total_revenue,
                    COUNT(DISTINCT o.id) as orders,
                    COUNT(DISTINCT o.user_id) as new_users
                FROM campaigns c
                LEFT JOIN campaign_visits v ON c.id = v.campaign_id AND v.created_at >= {$timeCondition}
                LEFT JOIN orders o ON v.order_id = o.id AND o.created_at >= {$timeCondition}
                WHERE c.created_at <= NOW() {$campaignCondition}
                GROUP BY c.id, c.name, c.type
                ORDER BY conversions DESC
            ";

            $campaignStatsResult = $this->db->query($campaignStatsQuery);
            $campaignStats = [];
            
            while ($row = $campaignStatsResult->fetch_assoc()) {
                $row['conversion_rate'] = $row['visits'] > 0 ? round(($row['conversions'] / $row['visits']) * 100, 2) : 0;
                $row['avg_order_value'] = $row['orders'] > 0 ? round($row['total_revenue'] / $row['orders'], 2) : 0;
                $row['roi'] = $row['total_revenue'] > 0 ? round($row['total_revenue'] / ($row['total_revenue'] * 0.2), 2) : 0; // 简化ROI计算
                $campaignStats[] = $row;
            }

            // 获取每日趋势数据
            $dateFormat = $this->getDateFormat($period);
            $dailyTrendQuery = "
                SELECT 
                    DATE_FORMAT(v.created_at, '{$dateFormat}') as date,
                    COUNT(DISTINCT v.id) as visits,
                    COUNT(DISTINCT CASE WHEN v.converted = 1 THEN v.id END) as conversions,
                    SUM(o.total_amount) as revenue
                FROM campaign_visits v
                LEFT JOIN orders o ON v.order_id = o.id
                WHERE v.created_at >= {$timeCondition} {$campaignCondition}
                GROUP BY DATE_FORMAT(v.created_at, '{$dateFormat}')
                ORDER BY date ASC
            ";

            $dailyTrendResult = $this->db->query($dailyTrendQuery);
            $dailyTrends = [];
            
            while ($row = $dailyTrendResult->fetch_assoc()) {
                $row['conversion_rate'] = $row['visits'] > 0 ? round(($row['conversions'] / $row['visits']) * 100, 2) : 0;
                $dailyTrends[] = $row;
            }

            // 整合数据
            $data = [
                'overview' => [
                    'total_visits' => array_sum(array_column($campaignStats, 'visits')),
                    'total_conversions' => array_sum(array_column($campaignStats, 'conversions')),
                    'total_revenue' => array_sum(array_column($campaignStats, 'total_revenue')),
                    'total_orders' => array_sum(array_column($campaignStats, 'orders')),
                    'average_conversion_rate' => $campaignStats ? round(array_sum(array_column($campaignStats, 'conversion_rate')) / count($campaignStats), 2) : 0,
                ],
                'campaigns' => $campaignStats,
                'daily_trends' => $dailyTrends,
                'period' => $period
            ];

            // 缓存数据
            $this->cache[$cacheKey] = [
                'data' => $data,
                'timestamp' => time()
            ];

            return $data;
        } catch (Exception $e) {
            $this->logger->error('获取推广效果统计数据失败', ['error' => $e->getMessage(), 'period' => $period]);
            return $this->getFallbackPromotionStats($period);
        }
    }

    /**
     * 获取商户数据报表
     * 
     * @param string $period 时间周期
     * @param array $filters 过滤条件
     * @return array 商户数据报表
     */
    public function getMerchantReports($period = 'month', $filters = []) {
        try {
            $cacheKey = "merchant_reports_{$period}_" . md5(json_encode($filters));
            
            if (isset($this->cache[$cacheKey]) && (time() - $this->cache[$cacheKey]['timestamp']) < $this->cacheTimeout) {
                return $this->cache[$cacheKey]['data'];
            }

            $timeCondition = $this->getTimeCondition($period);
            $filterConditions = [];

            if (!empty($filters['merchant_id'])) {
                $filterConditions[] = "m.id = " . intval($filters['merchant_id']);
            }
            
            if (!empty($filters['category'])) {
                $filterConditions[] = "m.category = '" . $this->db->real_escape_string($filters['category']) . "'";
            }

            $filterSql = empty($filterConditions) ? '' : 'AND ' . implode(' AND ', $filterConditions);

            // 商户基础报表
            $merchantQuery = "
                SELECT 
                    m.id as merchant_id,
                    m.name as merchant_name,
                    m.category,
                    m.level as merchant_level,
                    COUNT(DISTINCT o.id) as order_count,
                    SUM(o.total_amount) as total_revenue,
                    AVG(o.total_amount) as avg_order_value,
                    COUNT(DISTINCT o.user_id) as customer_count,
                    SUM(o.total_amount) - SUM(o.cost) as profit,
                    COUNT(DISTINCT CASE WHEN o.status = 'completed' THEN o.id END) as completed_orders,
                    COUNT(DISTINCT CASE WHEN o.status = 'failed' THEN o.id END) as failed_orders
                FROM merchants m
                LEFT JOIN orders o ON m.id = o.merchant_id AND o.created_at >= {$timeCondition}
                WHERE 1=1 {$filterSql}
                GROUP BY m.id, m.name, m.category, m.level
                ORDER BY total_revenue DESC
            ";

            $merchantResult = $this->db->query($merchantQuery);
            $merchants = [];
            $merchantIds = [];
            
            while ($row = $merchantResult->fetch_assoc()) {
                $row['conversion_rate'] = $row['order_count'] > 0 ? round(($row['completed_orders'] / $row['order_count']) * 100, 2) : 0;
                $row['profit_margin'] = $row['total_revenue'] > 0 ? round(($row['profit'] / $row['total_revenue']) * 100, 2) : 0;
                $merchants[$row['merchant_id']] = $row;
                $merchantIds[] = $row['merchant_id'];
            }

            // 商户产品表现
            if (!empty($merchantIds)) {
                $productQuery = "
                    SELECT 
                        oi.merchant_id,
                        p.name as product_name,
                        p.category as product_category,
                        COUNT(oi.id) as quantity_sold,
                        SUM(oi.price) as product_revenue,
                        AVG(oi.price) as avg_selling_price,
                        COUNT(DISTINCT o.id) as unique_orders
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    JOIN orders o ON oi.order_id = o.id
                    WHERE oi.merchant_id IN (" . implode(',', $merchantIds) . ") AND o.created_at >= {$timeCondition}
                    GROUP BY oi.merchant_id, p.id, p.name, p.category
                    ORDER BY oi.merchant_id, product_revenue DESC
                ";

                $productResult = $this->db->query($productQuery);
                
                while ($row = $productResult->fetch_assoc()) {
                    $merchantId = $row['merchant_id'];
                    unset($row['merchant_id']);
                    
                    if (!isset($merchants[$merchantId]['top_products'])) {
                        $merchants[$merchantId]['top_products'] = [];
                    }
                    
                    $merchants[$merchantId]['top_products'][] = $row;
                }
            }

            // 商户环比数据
            $prevPeriodCondition = $this->getPreviousPeriodCondition($period);
            $comparisonQuery = "
                SELECT 
                    m.id as merchant_id,
                    COUNT(DISTINCT o.id) as prev_order_count,
                    SUM(o.total_amount) as prev_total_revenue
                FROM merchants m
                LEFT JOIN orders o ON m.id = o.merchant_id AND o.created_at >= {$prevPeriodCondition} AND o.created_at < {$timeCondition}
                WHERE m.id IN (" . implode(',', $merchantIds) . ")
                GROUP BY m.id
            ";

            $comparisonResult = $this->db->query($comparisonQuery);
            
            while ($row = $comparisonResult->fetch_assoc()) {
                $merchantId = $row['merchant_id'];
                
                $merchants[$merchantId]['revenue_growth'] = $row['prev_total_revenue'] > 0 ? 
                    round((($merchants[$merchantId]['total_revenue'] - $row['prev_total_revenue']) / $row['prev_total_revenue']) * 100, 2) : 0;
                $merchants[$merchantId]['order_growth'] = $row['prev_order_count'] > 0 ? 
                    round((($merchants[$merchantId]['order_count'] - $row['prev_order_count']) / $row['prev_order_count']) * 100, 2) : 0;
            }

            // 智能分析和建议
            foreach ($merchants as &$merchant) {
                $merchant['analysis'] = $this->analyzeMerchantPerformance($merchant);
            }

            $data = [
                'merchants' => array_values($merchants),
                'summary' => $this->generateMerchantReportSummary($merchants, $period),
                'period' => $period,
                'filters' => $filters
            ];

            // 缓存数据
            $this->cache[$cacheKey] = [
                'data' => $data,
                'timestamp' => time()
            ];

            return $data;
        } catch (Exception $e) {
            $this->logger->error('获取商户数据报表失败', ['error' => $e->getMessage(), 'period' => $period]);
            return $this->getFallbackMerchantReports($period);
        }
    }

    /**
     * 获取业务监控大屏数据
     * 
     * @param array $options 配置选项
     * @return array 业务监控大屏数据
     */
    public function getBusinessDashboard($options = []) {
        try {
            $cacheKey = "business_dashboard_" . md5(json_encode($options));
            
            if (isset($this->cache[$cacheKey]) && (time() - $this->cache[$cacheKey]['timestamp']) < 60) { // 1分钟缓存
                return $this->cache[$cacheKey]['data'];
            }

            // 整合各种数据来源
            $dashboardData = [
                'realtime_metrics' => $this->getRealtimeMetrics(),
                'sales_trends' => $this->getSalesTrends($options['period'] ?? 'day'),
                'user_activity' => $this->getUserActivityMetrics(),
                'inventory_status' => $this->getInventoryStatus(),
                'top_performers' => $this->getTopPerformers(),
                'alerts' => $this->getActiveAlerts(),
                'conversion_funnel' => $this->getConversionFunnel(),
                'system_health' => $this->getSystemHealthMetrics()
            ];

            // 缓存数据
            $this->cache[$cacheKey] = [
                'data' => $dashboardData,
                'timestamp' => time()
            ];

            return $dashboardData;
        } catch (Exception $e) {
            $this->logger->error('获取业务监控大屏数据失败', ['error' => $e->getMessage()]);
            return $this->getFallbackDashboardData();
        }
    }

    /**
     * 获取用户行为画像
     * 
     * @param int $userId 用户ID（可选）
     * @param array $segments 用户分群条件（可选）
     * @return array 用户行为画像数据
     */
    public function getUserBehaviorProfiles($userId = null, $segments = []) {
        try {
            $cacheKey = "user_profiles_" . ($userId ?? 'segment_') . "_" . md5(json_encode($segments));
            
            if (isset($this->cache[$cacheKey]) && (time() - $this->cache[$cacheKey]['timestamp']) < $this->cacheTimeout) {
                return $this->cache[$cacheKey]['data'];
            }

            if ($userId) {
                // 单个用户画像
                $profile = $this->getSingleUserProfile($userId);
                $data = ['user_profile' => $profile, 'type' => 'single'];
            } else {
                // 用户群体画像
                $profile = $this->getUserSegmentProfile($segments);
                $data = ['segment_profile' => $profile, 'type' => 'segment', 'segments' => $segments];
            }

            // 缓存数据
            $this->cache[$cacheKey] = [
                'data' => $data,
                'timestamp' => time()
            ];

            return $data;
        } catch (Exception $e) {
            $this->logger->error('获取用户行为画像失败', ['error' => $e->getMessage(), 'user_id' => $userId]);
            return $this->getFallbackUserProfiles($userId, $segments);
        }
    }

    /**
     * 获取实时指标数据
     */
    private function getRealtimeMetrics() {
        // 实时订单数据
        $realtimeOrders = $this->db->query("SELECT COUNT(*) as count, SUM(total_amount) as revenue FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)")->fetch_assoc();
        
        // 实时用户数据
        $realtimeUsers = $this->db->query("SELECT COUNT(*) as active_users FROM users WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)")->fetch_assoc();
        
        // 实时访问数据
        $realtimeVisits = $this->db->query("SELECT COUNT(*) as visits FROM visits WHERE created_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)")->fetch_assoc();
        
        // 实时转化率
        $realtimeConversions = $this->db->query("SELECT COUNT(*) as converted FROM visits WHERE created_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) AND converted = 1")->fetch_assoc();
        
        return [
            'orders' => [
                'count' => intval($realtimeOrders['count']),
                'revenue' => floatval($realtimeOrders['revenue'])
            ],
            'active_users' => intval($realtimeUsers['active_users']),
            'visits' => intval($realtimeVisits['visits']),
            'conversions' => intval($realtimeConversions['converted']),
            'conversion_rate' => $realtimeVisits['visits'] > 0 ? round((intval($realtimeConversions['converted']) / intval($realtimeVisits['visits'])) * 100, 2) : 0,
            'timestamp' => time()
        ];
    }

    /**
     * 获取销售趋势数据
     */
    private function getSalesTrends($period = 'day') {
        $dateFormat = $this->getDateFormat($period);
        $timeCondition = $this->getTimeCondition($period);
        
        $query = "
            SELECT 
                DATE_FORMAT(created_at, '{$dateFormat}') as date,
                COUNT(*) as orders,
                SUM(total_amount) as revenue,
                COUNT(DISTINCT user_id) as customers
            FROM orders 
            WHERE created_at >= {$timeCondition}
            GROUP BY DATE_FORMAT(created_at, '{$dateFormat}')
            ORDER BY date ASC
        ";
        
        $result = $this->db->query($query);
        $trends = [];
        
        while ($row = $result->fetch_assoc()) {
            $trends[] = [
                'date' => $row['date'],
                'orders' => intval($row['orders']),
                'revenue' => floatval($row['revenue']),
                'customers' => intval($row['customers']),
                'avg_order_value' => $row['orders'] > 0 ? round(floatval($row['revenue']) / intval($row['orders']), 2) : 0
            ];
        }
        
        return $trends;
    }

    /**
     * 获取用户活动指标
     */
    private function getUserActivityMetrics() {
        // 今日活跃用户
        $todayActive = $this->db->query("SELECT COUNT(*) as count FROM users WHERE DATE(last_activity) = CURDATE()")->fetch_assoc()['count'];
        
        // 昨日活跃用户
        $yesterdayActive = $this->db->query("SELECT COUNT(*) as count FROM users WHERE DATE(last_activity) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)")->fetch_assoc()['count'];
        
        // 新增用户
        $newUsers = $this->db->query("SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['count'];
        
        // 用户留存率（7天）
        $retentionQuery = "
            SELECT 
                COUNT(DISTINCT t1.user_id) as total_new,
                COUNT(DISTINCT CASE WHEN t2.user_id IS NOT NULL THEN t1.user_id END) as retained
            FROM users t1
            LEFT JOIN users t2 ON t1.user_id = t2.user_id AND t2.last_activity BETWEEN DATE(t1.created_at) AND DATE_ADD(t1.created_at, INTERVAL 7 DAY)
            WHERE DATE(t1.created_at) = DATE_SUB(CURDATE(), INTERVAL 14 DAY)
        ";
        
        $retentionData = $this->db->query($retentionQuery)->fetch_assoc();
        $retentionRate = $retentionData['total_new'] > 0 ? round(($retentionData['retained'] / $retentionData['total_new']) * 100, 2) : 0;
        
        return [
            'today_active' => intval($todayActive),
            'yesterday_active' => intval($yesterdayActive),
            'active_growth' => $yesterdayActive > 0 ? round((($todayActive - $yesterdayActive) / $yesterdayActive) * 100, 2) : 0,
            'new_users' => intval($newUsers),
            'retention_rate' => $retentionRate,
            'average_session_duration' => $this->calculateAverageSessionDuration()
        ];
    }

    /**
     * 获取库存状态
     */
    private function getInventoryStatus() {
        $query = "
            SELECT 
                p.category,
                COUNT(p.id) as product_count,
                SUM(p.stock) as total_stock,
                SUM(CASE WHEN p.stock <= p.low_threshold THEN 1 ELSE 0 END) as low_stock_items
            FROM products p
            GROUP BY p.category
        ";
        
        $result = $this->db->query($query);
        $inventory = [];
        
        while ($row = $result->fetch_assoc()) {
            $inventory[] = [
                'category' => $row['category'],
                'product_count' => intval($row['product_count']),
                'total_stock' => intval($row['total_stock']),
                'low_stock_items' => intval($row['low_stock_items']),
                'stock_health' => $row['low_stock_items'] > 0 ? 'warning' : 'healthy'
            ];
        }
        
        return $inventory;
    }

    /**
     * 获取顶尖表现者
     */
    private function getTopPerformers() {
        // 顶级商户
        $merchantQuery = "
            SELECT id, name, category, (SELECT SUM(total_amount) FROM orders WHERE merchant_id = merchants.id AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as revenue
            FROM merchants
            ORDER BY revenue DESC
            LIMIT 5
        ";
        
        $merchants = $this->db->query($merchantQuery)->fetch_all(MYSQLI_ASSOC);
        
        // 热门产品
        $productQuery = "
            SELECT p.id, p.name, p.category, SUM(oi.quantity) as sold_count
            FROM products p
            JOIN order_items oi ON p.id = oi.product_id
            JOIN orders o ON oi.order_id = o.id
            WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY p.id, p.name, p.category
            ORDER BY sold_count DESC
            LIMIT 5
        ";
        
        $products = $this->db->query($productQuery)->fetch_all(MYSQLI_ASSOC);
        
        return [
            'top_merchants' => $merchants,
            'top_products' => $products
        ];
    }

    /**
     * 获取活跃告警
     */
    private function getActiveAlerts() {
        $query = "
            SELECT id, type, severity, message, created_at 
            FROM alerts 
            WHERE status = 'active' 
            ORDER BY severity DESC, created_at DESC
            LIMIT 10
        ";
        
        $result = $this->db->query($query);
        $alerts = [];
        
        while ($row = $result->fetch_assoc()) {
            $alerts[] = [
                'id' => intval($row['id']),
                'type' => $row['type'],
                'severity' => $row['severity'],
                'message' => $row['message'],
                'created_at' => $row['created_at'],
                'time_ago' => $this->getTimeAgo($row['created_at'])
            ];
        }
        
        return $alerts;
    }

    /**
     * 获取转化漏斗
     */
    private function getConversionFunnel() {
        $steps = [
            ['name' => 'visits', 'label' => '访问'],
            ['name' => 'views', 'label' => '浏览产品'],
            ['name' => 'cart', 'label' => '加入购物车'],
            ['name' => 'checkout', 'label' => '结账'],
            ['name' => 'purchase', 'label' => '完成购买']
        ];
        
        $funnel = [];
        $prevCount = 0;
        
        foreach ($steps as $step) {
            switch ($step['name']) {
                case 'visits':
                    $count = $this->db->query("SELECT COUNT(*) as count FROM visits WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
                    break;
                case 'views':
                    $count = $this->db->query("SELECT COUNT(*) as count FROM product_views WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
                    break;
                case 'cart':
                    $count = $this->db->query("SELECT COUNT(*) as count FROM cart_items WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
                    break;
                case 'checkout':
                    $count = $this->db->query("SELECT COUNT(*) as count FROM orders WHERE status = 'checkout' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
                    break;
                case 'purchase':
                    $count = $this->db->query("SELECT COUNT(*) as count FROM orders WHERE status = 'completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
                    break;
                default:
                    $count = 0;
            }
            
            $conversionRate = $prevCount > 0 ? round(($count / $prevCount) * 100, 2) : 100;
            $prevCount = $count;
            
            $funnel[] = [
                'name' => $step['name'],
                'label' => $step['label'],
                'count' => intval($count),
                'conversion_rate' => $conversionRate
            ];
        }
        
        return $funnel;
    }

    /**
     * 获取系统健康指标
     */
    private function getSystemHealthMetrics() {
        // 调用性能监控器获取系统指标
        $performanceMonitor = new PerformanceMonitor($this->db);
        $metrics = $performanceMonitor->collectMetrics();
        
        // 系统错误率
        $errorQuery = "
            SELECT COUNT(*) as errors, (SELECT COUNT(*) FROM requests WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as total
            FROM error_logs 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ";
        
        $errorData = $this->db->query($errorQuery)->fetch_assoc();
        $errorRate = $errorData['total'] > 0 ? round(($errorData['errors'] / $errorData['total']) * 100, 2) : 0;
        
        return [
            'cpu_usage' => $metrics['cpu']['usage_percent'],
            'memory_usage' => $metrics['memory']['usage_percent'],
            'disk_usage' => $metrics['disk']['usage_percent'],
            'api_response_time' => $this->calculateAverageApiResponseTime(),
            'error_rate' => $errorRate,
            'uptime' => $this->getSystemUptime()
        ];
    }

    /**
     * 获取单个用户画像
     */
    private function getSingleUserProfile($userId) {
        // 用户基础信息
        $userQuery = "
            SELECT u.*, 
                (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as order_count,
                (SELECT SUM(total_amount) FROM orders WHERE user_id = u.id) as total_spent,
                (SELECT MAX(created_at) FROM orders WHERE user_id = u.id) as last_order_date
            FROM users u
            WHERE u.id = ?
        ";
        
        $stmt = $this->db->prepare($userQuery);
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            return null;
        }

        // 用户购买行为
        $purchaseBehavior = $this->db->query("SELECT 
            p.category, 
            COUNT(*) as purchase_count,
            SUM(oi.price) as total_spent
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN products p ON oi.product_id = p.id
            WHERE o.user_id = {$userId}
            GROUP BY p.category
            ORDER BY total_spent DESC
        ")->fetch_all(MYSQLI_ASSOC);

        // 用户偏好
        $preferences = $this->db->query("SELECT 
            p.category as preferred_category,
            COUNT(*) as view_count
            FROM product_views pv
            JOIN products p ON pv.product_id = p.id
            WHERE pv.user_id = {$userId}
            GROUP BY p.category
            ORDER BY view_count DESC
        ")->fetch_all(MYSQLI_ASSOC);

        // 用户活跃度
        $activityLevel = $this->calculateUserActivityLevel($userId);
        
        // 用户价值评分
        $valueScore = $this->calculateUserValueScore($user);

        // 用户风险评分
        $riskScore = $this->calculateUserRiskScore($userId, $user);

        return [
            'user_id' => intval($user['id']),
            'username' => $user['username'],
            'email' => $user['email'],
            'registration_date' => $user['created_at'],
            'last_login' => $user['last_activity'],
            'order_count' => intval($user['order_count']),
            'total_spent' => floatval($user['total_spent']),
            'avg_order_value' => $user['order_count'] > 0 ? round(floatval($user['total_spent']) / intval($user['order_count']), 2) : 0,
            'last_order_date' => $user['last_order_date'],
            'purchase_behavior' => $purchaseBehavior,
            'preferences' => $preferences,
            'activity_level' => $activityLevel,
            'value_score' => $valueScore,
            'risk_score' => $riskScore,
            'recommendations' => $this->generateUserRecommendations($userId, $preferences)
        ];
    }

    /**
     * 获取用户分群画像
     */
    private function getUserSegmentProfile($segments) {
        // 构建查询条件
        $conditions = [];
        
        if (!empty($segments['min_orders'])) {
            $conditions[] = "order_count >= " . intval($segments['min_orders']);
        }
        
        if (!empty($segments['min_spent'])) {
            $conditions[] = "total_spent >= " . floatval($segments['min_spent']);
        }
        
        if (!empty($segments['registration_date_from'])) {
            $conditions[] = "registration_date >= '" . $this->db->real_escape_string($segments['registration_date_from']) . "'";
        }
        
        if (!empty($segments['registration_date_to'])) {
            $conditions[] = "registration_date <= '" . $this->db->real_escape_string($segments['registration_date_to']) . "'";
        }
        
        $whereClause = empty($conditions) ? '' : 'WHERE ' . implode(' AND ', $conditions);

        // 用户群体基础统计
        $segmentQuery = "
            SELECT 
                COUNT(*) as user_count,
                AVG(total_spent) as avg_spent,
                AVG(order_count) as avg_orders,
                COUNT(DISTINCT CASE WHEN last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN user_id END) as active_30d,
                COUNT(DISTINCT CASE WHEN last_login >= DATE_SUB(NOW(), INTERVAL 90 DAY) THEN user_id END) as active_90d
            FROM (
                SELECT 
                    u.id as user_id,
                    u.created_at as registration_date,
                    u.last_activity as last_login,
                    (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as order_count,
                    (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE user_id = u.id) as total_spent
                FROM users u
            ) as user_stats
            {$whereClause}
        ";

        $stats = $this->db->query($segmentQuery)->fetch_assoc();
        
        // 购买类别分布
        $categoryQuery = "
            SELECT 
                p.category,
                COUNT(DISTINCT o.user_id) as user_count,
                COUNT(*) as purchase_count,
                SUM(oi.price) as total_spent
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN products p ON oi.product_id = p.id
            JOIN (
                SELECT 
                    u.id as user_id
                FROM users u
                WHERE (
                    SELECT COUNT(*) FROM orders WHERE user_id = u.id
                ) >= " . (empty($segments['min_orders']) ? 1 : intval($segments['min_orders'])) . "
                " . (!empty($segments['min_spent']) ? "AND (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE user_id = u.id) >= " . floatval($segments['min_spent']) : '') . "
            ) as segment_users ON o.user_id = segment_users.user_id
            GROUP BY p.category
            ORDER BY user_count DESC
        ";

        $categoryDistribution = $this->db->query($categoryQuery)->fetch_all(MYSQLI_ASSOC);

        // 购买时间分布
        $timeDistribution = $this->db->query("SELECT 
            HOUR(o.created_at) as hour_of_day,
            COUNT(*) as order_count
            FROM orders o
            JOIN (
                SELECT 
                    u.id as user_id
                FROM users u
                WHERE (
                    SELECT COUNT(*) FROM orders WHERE user_id = u.id
                ) >= " . (empty($segments['min_orders']) ? 1 : intval($segments['min_orders'])) . "
                " . (!empty($segments['min_spent']) ? "AND (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE user_id = u.id) >= " . floatval($segments['min_spent']) : '') . "
            ) as segment_users ON o.user_id = segment_users.user_id
            GROUP BY HOUR(o.created_at)
            ORDER BY hour_of_day
        ")->fetch_all(MYSQLI_ASSOC);

        return [
            'segment_definition' => $segments,
            'user_count' => intval($stats['user_count']),
            'avg_spent' => floatval($stats['avg_spent']),
            'avg_orders' => floatval($stats['avg_orders']),
            'active_rate_30d' => $stats['user_count'] > 0 ? round(($stats['active_30d'] / $stats['user_count']) * 100, 2) : 0,
            'active_rate_90d' => $stats['user_count'] > 0 ? round(($stats['active_90d'] / $stats['user_count']) * 100, 2) : 0,
            'category_distribution' => $categoryDistribution,
            'time_distribution' => $timeDistribution,
            'segment_value' => $this->calculateSegmentValue($stats),
            'retention_score' => $this->calculateSegmentRetentionScore($stats)
        ];
    }

    /**
     * 分析商户性能
     */
    private function analyzeMerchantPerformance($merchantData) {
        $analysis = [];
        
        // 盈利能力分析
        if ($merchantData['profit'] > 0) {
            $profitMargin = round(($merchantData['profit'] / $merchantData['total_revenue']) * 100, 2);
            
            if ($profitMargin > 30) {
                $analysis[] = "盈利能力优秀，利润率达到 {$profitMargin}%";
            } elseif ($profitMargin > 15) {
                $analysis[] = "盈利能力良好，利润率为 {$profitMargin}%";
            } else {
                $analysis[] = "利润率偏低，仅为 {$profitMargin}%，建议优化成本结构";
            }
        }
        
        // 订单完成率分析
        if ($merchantData['order_count'] > 0) {
            $completionRate = round(($merchantData['completed_orders'] / $merchantData['order_count']) * 100, 2);
            
            if ($completionRate < 90) {
                $analysis[] = "订单完成率偏低({$completionRate}%)，建议检查产品质量和服务流程";
            }
        }
        
        // 客户价值分析
        if ($merchantData['customer_count'] > 0) {
            $customerValue = round($merchantData['total_revenue'] / $merchantData['customer_count'], 2);
            
            if ($customerValue > 1000) {
                $analysis[] = "客户价值高，平均每位客户贡献 {$customerValue} 元";
            }
        }
        
        // 环比增长分析
        if (isset($merchantData['revenue_growth']) && $merchantData['revenue_growth'] > 20) {
            $analysis[] = "收入环比增长显著，增长率达 {$merchantData['revenue_growth']}%";
        } elseif (isset($merchantData['revenue_growth']) && $merchantData['revenue_growth'] < 0) {
            $analysis[] = "收入环比下降 {$merchantData['revenue_growth']}%，需要关注市场变化和竞争情况";
        }
        
        return $analysis;
    }

    /**
     * 生成商户报告摘要
     */
    private function generateMerchantReportSummary($merchants, $period) {
        $totalMerchants = count($merchants);
        $totalRevenue = array_sum(array_column($merchants, 'total_revenue'));
        $totalOrders = array_sum(array_column($merchants, 'order_count'));
        $totalCustomers = array_sum(array_column($merchants, 'customer_count'));
        $totalProfit = array_sum(array_column($merchants, 'profit'));
        
        // 计算平均指标
        $avgRevenue = $totalMerchants > 0 ? $totalRevenue / $totalMerchants : 0;
        $avgOrderValue = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0;
        $avgCustomerValue = $totalCustomers > 0 ? $totalRevenue / $totalCustomers : 0;
        $avgProfitMargin = $totalRevenue > 0 ? ($totalProfit / $totalRevenue) * 100 : 0;
        
        return [
            'total_merchants' => $totalMerchants,
            'total_revenue' => $totalRevenue,
            'total_orders' => $totalOrders,
            'total_customers' => $totalCustomers,
            'total_profit' => $totalProfit,
            'avg_merchant_revenue' => $avgRevenue,
            'avg_order_value' => $avgOrderValue,
            'avg_customer_value' => $avgCustomerValue,
            'avg_profit_margin' => $avgProfitMargin,
            'period' => $period
        ];
    }

    /**
     * 计算用户活动级别
     */
    private function calculateUserActivityLevel($userId) {
        $loginCount = $this->db->query("SELECT COUNT(*) as count FROM user_sessions WHERE user_id = {$userId} AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch_assoc()['count'];
        
        if ($loginCount >= 15) return 'very_active';
        if ($loginCount >= 8) return 'active';
        if ($loginCount >= 3) return 'moderate';
        return 'inactive';
    }

    /**
     * 计算用户价值评分
     */
    private function calculateUserValueScore($user) {
        $score = 0;
        
        // 基于消费金额
        if ($user['total_spent'] > 10000) $score += 40;
        elseif ($user['total_spent'] > 5000) $score += 30;
        elseif ($user['total_spent'] > 1000) $score += 20;
        elseif ($user['total_spent'] > 0) $score += 10;
        
        // 基于订单数量
        if ($user['order_count'] > 20) $score += 30;
        elseif ($user['order_count'] > 10) $score += 25;
        elseif ($user['order_count'] > 5) $score += 20;
        elseif ($user['order_count'] > 1) $score += 15;
        elseif ($user['order_count'] > 0) $score += 10;
        
        // 基于活跃度
        $daysSinceLastOrder = $user['last_order_date'] ? round((time() - strtotime($user['last_order_date'])) / (60 * 60 * 24)) : 999;
        if ($daysSinceLastOrder <= 7) $score += 30;
        elseif ($daysSinceLastOrder <= 30) $score += 20;
        elseif ($daysSinceLastOrder <= 90) $score += 10;
        
        return min(100, $score);
    }

    /**
     * 计算用户风险评分
     */
    private function calculateUserRiskScore($userId, $user) {
        $score = 0;
        
        // 订单取消率
        $cancelRate = $this->db->query("SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
            FROM orders WHERE user_id = {$userId}
        ")->fetch_assoc();
        
        if ($cancelRate['total'] > 0) {
            $cancelPercent = ($cancelRate['cancelled'] / $cancelRate['total']) * 100;
            if ($cancelPercent > 50) $score += 50;
            elseif ($cancelPercent > 30) $score += 30;
            elseif ($cancelPercent > 10) $score += 10;
        }
        
        // 付款失败率
        $paymentFailRate = $this->db->query("SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
            FROM payments WHERE user_id = {$userId}
        ")->fetch_assoc();
        
        if ($paymentFailRate['total'] > 0) {
            $failPercent = ($paymentFailRate['failed'] / $paymentFailRate['total']) * 100;
            if ($failPercent > 40) $score += 40;
            elseif ($failPercent > 20) $score += 20;
        }
        
        // 账户年龄
        $accountAgeDays = round((time() - strtotime($user['created_at'])) / (60 * 60 * 24));
        if ($accountAgeDays < 7) $score += 20;
        
        return min(100, $score);
    }

    /**
     * 生成用户推荐
     */
    private function generateUserRecommendations($userId, $preferences) {
        // 基于用户偏好的推荐
        if (!empty($preferences)) {
            $preferredCategories = array_slice(array_column($preferences, 'preferred_category'), 0, 3);
            $categoryList = implode("','", $preferredCategories);
            
            $query = "
                SELECT p.id, p.name, p.category, p.price, p.image_url
                FROM products p
                WHERE p.category IN ('{$categoryList}')
                AND p.id NOT IN (
                    SELECT DISTINCT product_id FROM product_views WHERE user_id = {$userId}
                )
                ORDER BY p.popularity DESC
                LIMIT 5
            
            ";
            
            return $this->db->query($query)->fetch_all(MYSQLI_ASSOC);
        }
        
        return [];
    }

    /**
     * 计算平均会话时长
     */
    private function calculateAverageSessionDuration() {
        $query = "
            SELECT AVG(TIMESTAMPDIFF(SECOND, start_time, end_time)) as avg_duration
            FROM user_sessions
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            AND end_time IS NOT NULL
        ";
        
        $result = $this->db->query($query)->fetch_assoc();
        return $result['avg_duration'] ? round($result['avg_duration']) : 0;
    }

    /**
     * 计算平均API响应时间
     */
    private function calculateAverageApiResponseTime() {
        $query = "
            SELECT AVG(response_time) as avg_time
            FROM api_logs
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ";
        
        $result = $this->db->query($query)->fetch_assoc();
        return $result['avg_time'] ? round($result['avg_time'], 2) : 0;
    }

    /**
     * 获取系统运行时间
     */
    private function getSystemUptime() {
        // 从性能监控表中获取
        $query = "
            SELECT MIN(timestamp) as start_time
            FROM performance_metrics
            WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ";
        
        $result = $this->db->query($query)->fetch_assoc();
        
        if ($result['start_time']) {
            $uptimeSeconds = time() - $result['start_time'];
            $days = floor($uptimeSeconds / (60 * 60 * 24));
            $hours = floor(($uptimeSeconds % (60 * 60 * 24)) / (60 * 60));
            return "{$days}天{$hours}小时";
        }
        
        return "未知";
    }

    /**
     * 计算分群价值
     */
    private function calculateSegmentValue($stats) {
        $value = 0;
        
        // 基于用户数量
        if ($stats['user_count'] > 1000) $value += 30;
        elseif ($stats['user_count'] > 500) $value += 25;
        elseif ($stats['user_count'] > 100) $value += 20;
        elseif ($stats['user_count'] > 10) $value += 10;
        
        // 基于平均消费
        if ($stats['avg_spent'] > 1000) $value += 40;
        elseif ($stats['avg_spent'] > 500) $value += 30;
        elseif ($stats['avg_spent'] > 100) $value += 20;
        elseif ($stats['avg_spent'] > 0) $value += 10;
        
        // 基于活跃度
        $activeRate = $stats['user_count'] > 0 ? ($stats['active_30d'] / $stats['user_count']) * 100 : 0;
        if ($activeRate > 80) $value += 30;
        elseif ($activeRate > 50) $value += 20;
        elseif ($activeRate > 20) $value += 10;
        
        return min(100, $value);
    }

    /**
     * 计算分群留存评分
     */
    private function calculateSegmentRetentionScore($stats) {
        $value = 0;
        
        $retentionRate = $stats['active_30d'] > 0 ? ($stats['active_90d'] / $stats['active_30d']) * 100 : 0;
        
        if ($retentionRate > 70) $value += 100;
        elseif ($retentionRate > 50) $value += 80;
        elseif ($retentionRate > 30) $value += 60;
        elseif ($retentionRate > 10) $value += 40;
        else $value += 20;
        
        return min(100, $value);
    }

    /**
     * 获取时间条件SQL
     */
    private function getTimeCondition($period) {
        switch ($period) {
            case 'day':
                return 'CURDATE()';
            case 'week':
                return 'DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
            case 'month':
                return 'DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
            case 'quarter':
                return 'DATE_SUB(CURDATE(), INTERVAL 90 DAY)';
            case 'year':
                return 'DATE_SUB(CURDATE(), INTERVAL 365 DAY)';
            default:
                return 'DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
        }
    }

    /**
     * 获取上一周期时间条件SQL
     */
    private function getPreviousPeriodCondition($period) {
        switch ($period) {
            case 'day':
                return 'DATE_SUB(CURDATE(), INTERVAL 2 DAY)';
            case 'week':
                return 'DATE_SUB(CURDATE(), INTERVAL 14 DAY)';
            case 'month':
                return 'DATE_SUB(CURDATE(), INTERVAL 60 DAY)';
            case 'quarter':
                return 'DATE_SUB(CURDATE(), INTERVAL 180 DAY)';
            case 'year':
                return 'DATE_SUB(CURDATE(), INTERVAL 730 DAY)';
            default:
                return 'DATE_SUB(CURDATE(), INTERVAL 60 DAY)';
        }
    }

    /**
     * 获取日期格式
     */
    private function getDateFormat($period) {
        switch ($period) {
            case 'day':
                return '%H:00';
            case 'week':
                return '%Y-%m-%d';
            case 'month':
                return '%Y-%m-%d';
            case 'quarter':
                return '%Y-%m-%d';
            case 'year':
                return '%Y-%m';
            default:
                return '%Y-%m-%d';
        }
    }

    /**
     * 获取时间差描述
     */
    private function getTimeAgo($dateString) {
        $timestamp = strtotime($dateString);
        $diff = time() - $timestamp;
        
        if ($diff < 60) {
            return $diff . '秒前';
        } elseif ($diff < 3600) {
            return floor($diff / 60) . '分钟前';
        } elseif ($diff < 86400) {
            return floor($diff / 3600) . '小时前';
        } else {
            return floor($diff / 86400) . '天前';
        }
    }

    /**
     * 获取推广统计的备用数据
     */
    private function getFallbackPromotionStats($period) {
        return [
            'overview' => [
                'total_visits' => 1500,
                'total_conversions' => 150,
                'total_revenue' => 75000,
                'total_orders' => 150,
                'average_conversion_rate' => 10.0
            ],
            'campaigns' => [
                [
                    'campaign_id' => 1,
                    'campaign_name' => '春季促销活动',
                    'campaign_type' => 'seasonal',
                    'visits' => 800,
                    'conversions' => 96,
                    'total_revenue' => 48000,
                    'orders' => 96,
                    'new_users' => 50,
                    'conversion_rate' => 12.0,
                    'avg_order_value' => 500,
                    'roi' => 5.0
                ],
                [
                    'campaign_id' => 2,
                    'campaign_name' => '新用户注册优惠',
                    'campaign_type' => 'acquisition',
                    'visits' => 700,
                    'conversions' => 54,
                    'total_revenue' => 27000,
                    'orders' => 54,
                    'new_users' => 45,
                    'conversion_rate' => 7.7,
                    'avg_order_value' => 500,
                    'roi' => 4.5
                ]
            ],
            'daily_trends' => [],
            'period' => $period
        ];
    }

    /**
     * 获取商户报表的备用数据
     */
    private function getFallbackMerchantReports($period) {
        return [
            'merchants' => [
                [
                    'merchant_id' => 1,
                    'merchant_name' => '优质商户A',
                    'category' => 'digital',
                    'merchant_level' => 'premium',
                    'order_count' => 150,
                    'total_revenue' => 150000,
                    'avg_order_value' => 1000,
                    'customer_count' => 120,
                    'profit' => 75000,
                    'completed_orders' => 145,
                    'failed_orders' => 5,
                    'conversion_rate' => 96.7,
                    'profit_margin' => 50.0,
                    'revenue_growth' => 15.0,
                    'order_growth' => 10.0,
                    'analysis' => ['业绩优秀，收入稳定增长'],
                    'top_products' => [
                        ['product_name' => '高级会员卡', 'product_category' => 'membership', 'quantity_sold' => 80, 'product_revenue' => 80000]
                    ]
                ]
            ],
            'summary' => [
                'total_merchants' => 1,
                'total_revenue' => 150000,
                'total_orders' => 150,
                'total_customers' => 120,
                'total_profit' => 75000,
                'avg_merchant_revenue' => 150000,
                'avg_order_value' => 1000,
                'avg_customer_value' => 1250,
                'avg_profit_margin' => 50.0,
                'period' => $period
            ],
            'period' => $period,
            'filters' => []
        ];
    }

    /**
     * 获取仪表板的备用数据
     */
    private function getFallbackDashboardData() {
        return [
            'realtime_metrics' => [
                'orders' => ['count' => 15, 'revenue' => 7500],
                'active_users' => 120,
                'visits' => 350,
                'conversions' => 45,
                'conversion_rate' => 12.9
            ],
            'sales_trends' => [],
            'user_activity' => [
                'today_active' => 500,
                'yesterday_active' => 450,
                'active_growth' => 11.1,
                'new_users' => 80,
                'retention_rate' => 65.0,
                'average_session_duration' => 360
            ],
            'inventory_status' => [],
            'top_performers' => [],
            'alerts' => [],
            'conversion_funnel' => [],
            'system_health' => [
                'cpu_usage' => 45.0,
                'memory_usage' => 65.0,
                'disk_usage' => 75.0,
                'api_response_time' => 150,
                'error_rate' => 0.5,
                'uptime' => '30天5小时'
            ]
        ];
    }

    /**
     * 获取用户画像的备用数据
     */
    private function getFallbackUserProfiles($userId = null, $segments = []) {
        $profile = [
            'user_id' => $userId ?? 1,
            'username' => '测试用户',
            'email' => 'test@example.com',
            'registration_date' => '2024-01-01',
            'last_login' => '2024-01-15',
            'order_count' => 5,
            'total_spent' => 2500,
            'avg_order_value' => 500,
            'last_order_date' => '2024-01-10',
            'purchase_behavior' => [
                ['category' => 'membership', 'purchase_count' => 3, 'total_spent' => 1800],
                ['category' => 'digital', 'purchase_count' => 2, 'total_spent' => 700]
            ],
            'preferences' => [
                ['preferred_category' => 'membership', 'view_count' => 15],
                ['preferred_category' => 'digital', 'view_count' => 10]
            ],
            'activity_level' => 'active',
            'value_score' => 75,
            'risk_score' => 15,
            'recommendations' => []
        ];

        return ['user_profile' => $profile, 'type' => $userId ? 'single' : 'segment'];
    }
}