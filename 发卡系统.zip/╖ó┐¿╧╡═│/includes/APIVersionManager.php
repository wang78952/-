<?php
/**
 * API版本控制管理类
 * 提供API版本管理、路由分发、兼容性处理等功能
 */

class APIVersionManager {
    
    private $versions = array();
    private $defaultVersion = 'v1';
    private $currentVersion = 'v1';
    private $versionHeader = 'API-Version';
    private $supportedVersions = array('v1', 'v2');
    
    public function __construct($config = array()) {
        $this->defaultVersion = isset($config['default_version']) ? $config['default_version'] : 'v1';
        $this->versionHeader = isset($config['version_header']) ? $config['version_header'] : 'API-Version';
        $this->supportedVersions = isset($config['supported_versions']) ? $config['supported_versions'] : array('v1', 'v2');
        
        $this->initializeVersions();
    }
    
    /**
     * 初始化版本信息
     */
    private function initializeVersions() {
        // v1版本配置
        $this->versions['v1'] = array(
            'routes' => array(
                'GET' => array(
                    '/users' => 'UserController@index',
                    '/users/{id}' => 'UserController@show',
                    '/products' => 'ProductController@index',
                    '/products/{id}' => 'ProductController@show',
                    '/orders' => 'OrderController@index',
                    '/orders/{id}' => 'OrderController@show'
                ),
                'POST' => array(
                    '/users' => 'UserController@store',
                    '/products' => 'ProductController@store',
                    '/orders' => 'OrderController@store',
                    '/auth/login' => 'AuthController@login',
                    '/auth/logout' => 'AuthController@logout'
                ),
                'PUT' => array(
                    '/users/{id}' => 'UserController@update',
                    '/products/{id}' => 'ProductController@update',
                    '/orders/{id}' => 'OrderController@update'
                ),
                'DELETE' => array(
                    '/users/{id}' => 'UserController@destroy',
                    '/products/{id}' => 'ProductController@destroy',
                    '/orders/{id}' => 'OrderController@destroy'
                )
            ),
            'middleware' => array('auth', 'rate_limit'),
            'deprecated' => false,
            'deprecation_date' => null,
            'sunset_date' => null
        );
        
        // v2版本配置
        $this->versions['v2'] = array(
            'routes' => array(
                'GET' => array(
                    '/users' => 'UserControllerV2@index',
                    '/users/{id}' => 'UserControllerV2@show',
                    '/products' => 'ProductControllerV2@index',
                    '/products/{id}' => 'ProductControllerV2@show',
                    '/orders' => 'OrderControllerV2@index',
                    '/orders/{id}' => 'OrderControllerV2@show',
                    '/stats' => 'StatsController@index'
                ),
                'POST' => array(
                    '/users' => 'UserControllerV2@store',
                    '/products' => 'ProductControllerV2@store',
                    '/orders' => 'OrderControllerV2@store',
                    '/auth/login' => 'AuthControllerV2@login',
                    '/auth/logout' => 'AuthControllerV2@logout',
                    '/auth/refresh' => 'AuthControllerV2@refresh',
                    '/batch' => 'BatchController@process'
                ),
                'PUT' => array(
                    '/users/{id}' => 'UserControllerV2@update',
                    '/products/{id}' => 'ProductControllerV2@update',
                    '/orders/{id}' => 'OrderControllerV2@update'
                ),
                'DELETE' => array(
                    '/users/{id}' => 'UserControllerV2@destroy',
                    '/products/{id}' => 'ProductControllerV2@destroy',
                    '/orders/{id}' => 'OrderControllerV2@destroy'
                ),
                'PATCH' => array(
                    '/users/{id}' => 'UserControllerV2@patch',
                    '/products/{id}' => 'ProductControllerV2@patch',
                    '/orders/{id}' => 'OrderControllerV2@patch'
                )
            ),
            'middleware' => array('auth', 'rate_limit', 'api_key'),
            'deprecated' => false,
            'deprecation_date' => null,
            'sunset_date' => null
        );
    }
    
    /**
     * 获取请求版本
     */
    public function getRequestVersion() {
        // 1. 从URL路径获取版本
        $requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if (preg_match('/^\/api\/(v\d+)/', $requestUri, $matches)) {
            $version = $matches[1];
            if ($this->isVersionSupported($version)) {
                return $version;
            }
        }
        
        // 2. 从请求头获取版本
        $headers = getallheaders();
        $versionHeader = isset($headers[$this->versionHeader]) ? $headers[$this->versionHeader] : (isset($headers[strtolower($this->versionHeader)]) ? $headers[strtolower($this->versionHeader)] : '');
        if ($versionHeader && $this->isVersionSupported($versionHeader)) {
            return $versionHeader;
        }
        
        // 3. 从查询参数获取版本
        $versionParam = isset($_GET['version']) ? $_GET['version'] : (isset($_GET['api_version']) ? $_GET['api_version'] : '');
        if ($versionParam && $this->isVersionSupported($versionParam)) {
            return $versionParam;
        }
        
        // 4. 返回默认版本
        return $this->defaultVersion;
    }
    
    /**
     * 检查版本是否支持
     */
    public function isVersionSupported($version) {
        return in_array($version, $this->supportedVersions);
    }
    
    /**
     * 获取路由信息
     */
    public function getRoute($method, $path, $version = null) {
        $version = isset($version) ? $version : $this->getRequestVersion();
        
        if (!$this->isVersionSupported($version)) {
            throw new APIVersionException("Version {$version} is not supported", 400);
        }
        
        $versionConfig = $this->versions[$version];
        $routes = $versionConfig['routes'];
        
        // 标准化路径
        $path = $this->normalizePath($path);
        
        // 查找精确匹配
        if (isset($routes[$method][$path])) {
            return array(
                'handler' => $routes[$method][$path],
                'version' => $version,
                'middleware' => $versionConfig['middleware'],
                'params' => array()
            );
        }
        
        // 查找参数化路由
        foreach ($routes[$method] as $route => $handler) {
            $params = $this->matchRoute($route, $path);
            if ($params !== false) {
                return array(
                    'handler' => $handler,
                    'version' => $version,
                    'middleware' => $versionConfig['middleware'],
                    'params' => $params
                );
            }
        }
        
        throw new APIVersionException("Route not found: {$method} {$path}", 404);
    }
    
    /**
     * 标准化路径
     */
    private function normalizePath($path) {
        // 移除API前缀
        $path = preg_replace('/^\/api\/(v\d+)\//', '/', $path);
        
        // 移除查询字符串
        $path = explode('?', $path)[0];
        
        // 确保路径以/开头
        if (substr($path, 0, 1) !== '/') {
            $path = '/' . $path;
        }
        
        return $path;
    }
    
    /**
     * 匹配路由参数
     */
    private function matchRoute($route, $path) {
        $routePattern = preg_replace('/\{([^}]+)\}/', '([^/]+)', $route);
        $routePattern = '/^' . str_replace('/', '\/', $routePattern) . '$/';
        
        if (preg_match($routePattern, $path, $matches)) {
            // 提取参数名
            preg_match_all('/\{([^}]+)\}/', $route, $paramNames);
            $params = array();
            
            for ($i = 1; $i < count($matches); $i++) {
                $paramName = isset($paramNames[1][$i - 1]) ? $paramNames[1][$i - 1] : 'param' . $i;
                $params[$paramName] = $matches[$i];
            }
            
            return $params;
        }
        
        return false;
    }
    
    /**
     * 处理API请求
     */
    public function handleRequest() {
        try {
            $method = $_SERVER['REQUEST_METHOD'];
            $path = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
            $version = $this->getRequestVersion();
            
            // 设置响应头
            $this->setVersionHeaders($version);
            
            // 获取路由信息
            $route = $this->getRoute($method, $path, $version);
            
            // 执行中间件
            $this->executeMiddleware($route['middleware']);
            
            // 执行处理器
            $response = $this->executeHandler($route['handler'], $route['params']);
            
            // 发送响应
            $this->sendResponse($response, $version);
            
        } catch (APIVersionException $e) {
            $this->sendErrorResponse($e->getMessage(), $e->getCode(), isset($version) ? $version : $this->defaultVersion);
        } catch (Exception $e) {
            $this->sendErrorResponse('Internal Server Error', 500, isset($version) ? $version : $this->defaultVersion);
        }
    }
    
    /**
     * 设置版本相关响应头
     */
    private function setVersionHeaders($version) {
        header("API-Version: {$version}");
        header("API-Supported-Versions: " . implode(', ', $this->supportedVersions));
        header("API-Default-Version: {$this->defaultVersion}");
        
        // 检查版本是否已弃用
        if (isset($this->versions[$version]['deprecated']) && $this->versions[$version]['deprecated']) {
            $deprecationDate = $this->versions[$version]['deprecation_date'];
            $sunsetDate = $this->versions[$version]['sunset_date'];
            
            if ($deprecationDate) {
                header("Deprecation: true");
                header("Sunset: {$sunsetDate}");
                header("Link: </api/v2>; rel=\"successor-version\"");
            }
        }
    }
    
    /**
     * 执行中间件
     */
    private function executeMiddleware($middleware) {
        foreach ($middleware as $middlewareName) {
            $this->executeMiddlewareItem($middlewareName);
        }
    }
    
    /**
     * 执行单个中间件
     */
    private function executeMiddlewareItem($middlewareName) {
        switch ($middlewareName) {
            case 'auth':
                $this->authenticate();
                break;
            case 'rate_limit':
                $this->applyRateLimit();
                break;
            case 'api_key':
                $this->validateApiKey();
                break;
            case 'cors':
                $this->handleCORS();
                break;
            default:
                // 尝试加载自定义中间件
                if (class_exists($middlewareName)) {
                    $middleware = new $middlewareName();
                    $middleware->handle();
                }
        }
    }
    
    /**
     * 身份验证
     */
    private function authenticate() {
        $token = $this->extractToken();
        if (!$token) {
            throw new APIVersionException('Authentication required', 401);
        }
        
        $jwtManager = new JWTManager();
        try {
            $user = $jwtManager->getCurrentUser();
            $_SESSION['current_user'] = $user;
        } catch (Exception $e) {
            throw new APIVersionException('Invalid token', 401);
        }
    }
    
    /**
     * 提取令牌
     */
    private function extractToken() {
        $headers = getallheaders();
        $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');
        
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
    
    /**
     * 应用速率限制
     */
    private function applyRateLimit() {
        $clientId = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
        $limit = 100; // 每小时100次请求
        $window = 3600; // 1小时窗口
        
        // 这里应该使用Redis或数据库实现速率限制
        // 简化实现，使用文件存储
        $rateLimitFile = __DIR__ . '/../cache/rate_limit_' . md5($clientId);
        $currentData = array();
        
        if (file_exists($rateLimitFile)) {
            $currentData = json_decode(file_get_contents($rateLimitFile), true) ?: array();
        }
        
        $currentTime = time();
        $windowStart = $currentTime - $window;
        
        // 清理过期记录
        $currentData = array_filter($currentData, function($timestamp) use ($windowStart) {
            return $timestamp > $windowStart;
        });
        
        // 检查是否超过限制
        if (count($currentData) >= $limit) {
            throw new APIVersionException('Rate limit exceeded', 429);
        }
        
        // 记录当前请求
        $currentData[] = $currentTime;
        file_put_contents($rateLimitFile, json_encode($currentData));
        
        // 设置速率限制响应头
        header("X-RateLimit-Limit: {$limit}");
        header("X-RateLimit-Remaining: " . ($limit - count($currentData)));
        header("X-RateLimit-Reset: " . ($currentTime + $window));
    }
    
    /**
     * 验证API密钥
     */
    private function validateApiKey() {
        $headers = getallheaders();
        $apiKey = isset($headers['X-API-Key']) ? $headers['X-API-Key'] : (isset($headers['x-api-key']) ? $headers['x-api-key'] : '');
        
        if (empty($apiKey)) {
            throw new APIVersionException('API key required', 401);
        }
        
        // 验证API密钥（这里应该查询数据库）
        if (!$this->isValidApiKey($apiKey)) {
            throw new APIVersionException('Invalid API key', 401);
        }
    }
    
    /**
     * 检查API密钥是否有效
     */
    private function isValidApiKey($apiKey) {
        // 实际应该查询数据库验证API密钥
        try {
            $db = Database::getInstance();
            $stmt = $db->prepare("SELECT id FROM api_sessions WHERE api_token = ? AND expires_at > NOW()");
            $stmt->execute(array($apiKey));
            return $stmt->fetch() !== false;
        } catch (Exception $e) {
            // 数据库查询失败时记录日志并拒绝访问
            error_log("API key validation failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 处理CORS
     */
    private function handleCORS() {
        header("Access-Control-Allow-Origin: *");
        $methods = array('GET', 'POST', 'PUT', 'DELETE', 'OPTIONS');
        header("Access-Control-Allow-Methods: " . implode(', ', $methods));
        $headers = array('Content-Type', 'Authorization', 'X-API-Key', 'API-Version');
        header("Access-Control-Allow-Headers: " . implode(', ', $headers));
        header("Access-Control-Max-Age: 86400");
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
    
    /**
     * 执行处理器
     */
    private function executeHandler($handler, $params) {
        list($controllerName, $methodName) = explode('@', $handler);
        
        $controllerClass = $controllerName;
        if (!class_exists($controllerClass)) {
            // 尝试加载控制器文件
            $controllerFile = __DIR__ . "/../controllers/{$controllerName}.php";
            if (file_exists($controllerFile)) {
                require_once $controllerFile;
            }
        }
        
        if (!class_exists($controllerClass)) {
            throw new APIVersionException("Controller not found: {$controllerClass}", 500);
        }
        
        $controller = new $controllerClass();
        
        if (!method_exists($controller, $methodName)) {
            throw new APIVersionException("Method not found: {$methodName}", 500);
        }
        
        return $controller->$methodName($params);
    }
    
    /**
     * 发送响应
     */
    private function sendResponse($data, $version) {
        header('Content-Type: application/json');
        
        $response = array(
            'success' => true,
            'data' => $data,
            'version' => $version,
            'timestamp' => time()
        );
        
        echo json_encode($response, 128); // JSON_PRETTY_PRINT = 128
        exit;
    }
    
    /**
     * 发送错误响应
     */
    private function sendErrorResponse($message, $code, $version) {
        http_response_code($code);
        header('Content-Type: application/json');
        
        $response = array(
            'success' => false,
            'error' => array(
                'message' => $message,
                'code' => $code
            ),
            'version' => $version,
            'timestamp' => time()
        );
        
        echo json_encode($response, 128); // JSON_PRETTY_PRINT = 128
        exit;
    }
    
    /**
     * 添加新版本
     */
    public function addVersion($version, $config) {
        $this->versions[$version] = $config;
        array_push($this->supportedVersions, $version);
    }
    
    /**
     * 弃用版本
     */
    public function deprecateVersion($version, $deprecationDate = null, $sunsetDate = null) {
        if (isset($this->versions[$version])) {
            $this->versions[$version]['deprecated'] = true;
            $this->versions[$version]['deprecation_date'] = $deprecationDate;
            $this->versions[$version]['sunset_date'] = $sunsetDate;
        }
    }
    
    /**
     * 获取版本信息
     */
    public function getVersionInfo($version = null) {
        if ($version) {
            return isset($this->versions[$version]) ? $this->versions[$version] : null;
        }
        
        return $this->versions;
    }
    
    /**
     * 获取支持的版本列表
     */
    public function getSupportedVersions() {
        return $this->supportedVersions;
    }
}

/**
 * API版本异常类
 */
class APIVersionException extends Exception {
    public function __construct($message, $code = 0, Exception $previous = null) {
        parent::__construct($message, $code, $previous);
    }
}