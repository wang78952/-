<?php
/**
 * 移动设备检测器
 * 用于检测用户设备类型、浏览器信息和屏幕参数，支持响应式设计实现
 */

class MobileDeviceDetector {
    /**
     * 设备类型常量
     */
    const DEVICE_TYPE_DESKTOP = 'desktop';
    const DEVICE_TYPE_TABLET = 'tablet';
    const DEVICE_TYPE_MOBILE = 'mobile';
    const DEVICE_TYPE_BOT = 'bot';
    const DEVICE_TYPE_UNKNOWN = 'unknown';
    
    /**
     * 操作系统常量
     */
    const OS_IOS = 'ios';
    const OS_ANDROID = 'android';
    const OS_WINDOWS = 'windows';
    const OS_MACOS = 'macos';
    const OS_LINUX = 'linux';
    const OS_CHROMEOS = 'chromeos';
    const OS_UNKNOWN = 'unknown';
    
    /**
     * 浏览器常量
     */
    const BROWSER_CHROME = 'chrome';
    const BROWSER_SAFARI = 'safari';
    const BROWSER_FIREFOX = 'firefox';
    const BROWSER_EDGE = 'edge';
    const BROWSER_IE = 'ie';
    const BROWSER_OPERA = 'opera';
    const BROWSER_SAMSUNG = 'samsung';
    const BROWSER_UC = 'ucbrowser';
    const BROWSER_UNKNOWN = 'unknown';
    
    /**
     * 设备信息缓存
     * @var array
     */
    protected static $deviceInfo = null;
    
    /**
     * 获取用户代理字符串
     * @return string 用户代理
     */
    public static function getUserAgent() {
        return isset($_SERVER['HTTP_USER_AGENT']) ? trim($_SERVER['HTTP_USER_AGENT']) : '';
    }
    
    /**
     * 检测设备类型
     * @return string 设备类型常量
     */
    public static function detectDeviceType() {
        $deviceInfo = self::getDeviceInfo();
        return $deviceInfo['device_type'];
    }
    
    /**
     * 检测操作系统
     * @return string 操作系统常量
     */
    public static function detectOS() {
        $deviceInfo = self::getDeviceInfo();
        return $deviceInfo['os'];
    }
    
    /**
     * 检测浏览器
     * @return string 浏览器常量
     */
    public static function detectBrowser() {
        $deviceInfo = self::getDeviceInfo();
        return $deviceInfo['browser'];
    }
    
    /**
     * 检测浏览器版本
     * @return float 浏览器版本号
     */
    public static function detectBrowserVersion() {
        $deviceInfo = self::getDeviceInfo();
        return $deviceInfo['browser_version'];
    }
    
    /**
     * 检查是否为移动设备（手机或平板）
     * @return bool 是否为移动设备
     */
    public static function isMobile() {
        $deviceType = self::detectDeviceType();
        return $deviceType === self::DEVICE_TYPE_MOBILE || $deviceType === self::DEVICE_TYPE_TABLET;
    }
    
    /**
     * 检查是否为智能手机
     * @return bool 是否为智能手机
     */
    public static function isSmartphone() {
        return self::detectDeviceType() === self::DEVICE_TYPE_MOBILE;
    }
    
    /**
     * 检查是否为平板设备
     * @return bool 是否为平板设备
     */
    public static function isTablet() {
        return self::detectDeviceType() === self::DEVICE_TYPE_TABLET;
    }
    
    /**
     * 检查是否为桌面设备
     * @return bool 是否为桌面设备
     */
    public static function isDesktop() {
        return self::detectDeviceType() === self::DEVICE_TYPE_DESKTOP;
    }
    
    /**
     * 检查是否为机器人或爬虫
     * @return bool 是否为机器人
     */
    public static function isBot() {
        return self::detectDeviceType() === self::DEVICE_TYPE_BOT;
    }
    
    /**
     * 检查是否为iOS设备
     * @return bool 是否为iOS设备
     */
    public static function isIOS() {
        return self::detectOS() === self::OS_IOS;
    }
    
    /**
     * 检查是否为Android设备
     * @return bool 是否为Android设备
     */
    public static function isAndroid() {
        return self::detectOS() === self::OS_ANDROID;
    }
    
    /**
     * 检查是否为Windows设备
     * @return bool 是否为Windows设备
     */
    public static function isWindows() {
        return self::detectOS() === self::OS_WINDOWS;
    }
    
    /**
     * 检查是否为Safari浏览器
     * @return bool 是否为Safari浏览器
     */
    public static function isSafari() {
        return self::detectBrowser() === self::BROWSER_SAFARI;
    }
    
    /**
     * 检查是否为Chrome浏览器
     * @return bool 是否为Chrome浏览器
     */
    public static function isChrome() {
        return self::detectBrowser() === self::BROWSER_CHROME;
    }
    
    /**
     * 检查是否为Firefox浏览器
     * @return bool 是否为Firefox浏览器
     */
    public static function isFirefox() {
        return self::detectBrowser() === self::BROWSER_FIREFOX;
    }
    
    /**
     * 检查是否为Edge浏览器
     * @return bool 是否为Edge浏览器
     */
    public static function isEdge() {
        return self::detectBrowser() === self::BROWSER_EDGE;
    }
    
    /**
     * 检查是否为IE浏览器
     * @return bool 是否为IE浏览器
     */
    public static function isIE() {
        return self::detectBrowser() === self::BROWSER_IE;
    }
    
    /**
     * 检查是否支持触摸事件
     * @return bool 是否支持触摸
     */
    public static function supportsTouch() {
        // 通过UA检测常见触摸设备
        $userAgent = self::getUserAgent();
        $touchDevicePatterns = [
            '/iphone|ipad|ipod/i',
            '/android/i',
            '/blackberry/i',
            '/windows phone/i',
            '/iemobile/i',
            '/tablet/i',
            '/mobile/i',
            '/touch/i'
        ];
        
        foreach ($touchDevicePatterns as $pattern) {
            if (preg_match($pattern, $userAgent)) {
                return true;
            }
        }
        
        // 检查HTTP头
        if (isset($_SERVER['HTTP_X_WAP_PROFILE']) || 
            isset($_SERVER['HTTP_PROFILE']) || 
            isset($_SERVER['HTTP_X_OPERAMINI_FEATURES'])) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 获取屏幕宽度信息
     * @return int 屏幕宽度估计值（像素）
     */
    public static function getScreenWidth() {
        // 通过UA和HTTP头获取屏幕宽度信息
        $userAgent = self::getUserAgent();
        $deviceType = self::detectDeviceType();
        
        // 特定设备的常见屏幕宽度估计
        $widthEstimates = [
            // 移动设备宽度估计
            ['pattern' => '/iphone\s*[0-9,]+/', 'device_type' => self::DEVICE_TYPE_MOBILE, 'width' => 375],
            ['pattern' => '/iphone/i', 'device_type' => self::DEVICE_TYPE_MOBILE, 'width' => 320],
            ['pattern' => '/samsung.*galaxy\s*s[0-9]+/', 'device_type' => self::DEVICE_TYPE_MOBILE, 'width' => 360],
            ['pattern' => '/nexus\s*[0-9]/', 'device_type' => self::DEVICE_TYPE_MOBILE, 'width' => 360],
            
            // 平板设备宽度估计
            ['pattern' => '/ipad.*(pro|air)/i', 'device_type' => self::DEVICE_TYPE_TABLET, 'width' => 1024],
            ['pattern' => '/ipad/i', 'device_type' => self::DEVICE_TYPE_TABLET, 'width' => 768],
            ['pattern' => '/samsung.*galaxy\s*tab/i', 'device_type' => self::DEVICE_TYPE_TABLET, 'width' => 800],
            ['pattern' => '/kindle/i', 'device_type' => self::DEVICE_TYPE_TABLET, 'width' => 600],
        ];
        
        // 尝试匹配特定设备
        foreach ($widthEstimates as $estimate) {
            if (preg_match($estimate['pattern'], $userAgent) && $deviceType === $estimate['device_type']) {
                return $estimate['width'];
            }
        }
        
        // 根据设备类型返回默认宽度
        switch ($deviceType) {
            case self::DEVICE_TYPE_MOBILE:
                return 360;
            case self::DEVICE_TYPE_TABLET:
                return 768;
            case self::DEVICE_TYPE_DESKTOP:
            default:
                return 1280;
        }
    }
    
    /**
     * 获取屏幕高度信息
     * @return int 屏幕高度估计值（像素）
     */
    public static function getScreenHeight() {
        $width = self::getScreenWidth();
        $deviceType = self::detectDeviceType();
        
        // 根据设备类型和宽度估算高度（使用常见的宽高比）
        switch ($deviceType) {
            case self::DEVICE_TYPE_MOBILE:
                // 手机通常有9:16或18:9宽高比
                return (int)($width * 16 / 9);
            case self::DEVICE_TYPE_TABLET:
                // 平板通常有4:3宽高比
                return (int)($width * 3 / 4);
            case self::DEVICE_TYPE_DESKTOP:
            default:
                // 桌面通常有16:9宽高比
                return (int)($width * 9 / 16);
        }
    }
    
    /**
     * 获取设备像素比（DPR）
     * @return float 设备像素比
     */
    public static function getDevicePixelRatio() {
        $deviceInfo = self::getDeviceInfo();
        return $deviceInfo['dpr'];
    }
    
    /**
     * 获取响应式设计断点
     * @return string 当前匹配的断点
     */
    public static function getBreakpoint() {
        $width = self::getScreenWidth();
        
        // 标准断点定义（像素）
        if ($width < 576) {
            return 'xs'; // 超小屏幕（手机）
        } elseif ($width < 768) {
            return 'sm'; // 小屏幕（平板竖屏）
        } elseif ($width < 992) {
            return 'md'; // 中等屏幕（平板横屏）
        } elseif ($width < 1200) {
            return 'lg'; // 大屏幕（桌面小显示器）
        } else {
            return 'xl'; // 超大屏幕（桌面大显示器）
        }
    }
    
    /**
     * 获取完整设备信息
     * @return array 设备信息数组
     */
    public static function getDeviceInfo() {
        if (self::$deviceInfo === null) {
            self::$deviceInfo = self::parseDeviceInfo();
        }
        
        return self::$deviceInfo;
    }
    
    /**
     * 解析设备信息
     * @return array 解析后的设备信息
     */
    protected static function parseDeviceInfo() {
        $userAgent = self::getUserAgent();
        $info = [
            'user_agent' => $userAgent,
            'device_type' => self::DEVICE_TYPE_UNKNOWN,
            'os' => self::OS_UNKNOWN,
            'os_version' => 0,
            'browser' => self::BROWSER_UNKNOWN,
            'browser_version' => 0,
            'dpr' => 1.0,
            'supports_touch' => false
        ];
        
        // 检测机器人
        if (self::isBotFromUA($userAgent)) {
            $info['device_type'] = self::DEVICE_TYPE_BOT;
            return $info;
        }
        
        // 检测操作系统
        $info['os'] = self::parseOS($userAgent);
        $info['os_version'] = self::parseOSVersion($userAgent, $info['os']);
        
        // 检测浏览器
        $info['browser'] = self::parseBrowser($userAgent);
        $info['browser_version'] = self::parseBrowserVersion($userAgent, $info['browser']);
        
        // 检测设备类型
        $info['device_type'] = self::parseDeviceType($userAgent, $info['os'], $info['browser']);
        
        // 检测触摸支持
        $info['supports_touch'] = self::supportsTouch();
        
        // 估算设备像素比
        $info['dpr'] = self::estimateDevicePixelRatio($userAgent, $info['device_type'], $info['os']);
        
        return $info;
    }
    
    /**
     * 从UA检测机器人
     * @param string $userAgent 用户代理
     * @return bool 是否为机器人
     */
    protected static function isBotFromUA($userAgent) {
        $botPatterns = [
            '/bot/',
            '/crawler/',
            '/spider/',
            '/slurp/',
            '/bingbot/',
            '/googlebot/',
            '/mediapartners-google/',
            '/baiduspider/',
            '/yandexbot/',
            '/sogou/',
            '/ia_archiver/',
            '/msnbot/',
            '/duckduckbot/',
            '/teoma/',
            '/libwww-perl/',
            '/python-urllib/',
            '/nutch/',
            '/scrapy/',
            '/phantomjs/',
            '/headlesschrome/',
            '/facebookexternalhit/',
            '/twitterbot/',
            '/linkedinbot/',
            '/instagram/',
            '/pinterestbot/'
        ];
        
        $userAgent = strtolower($userAgent);
        foreach ($botPatterns as $pattern) {
            if (preg_match($pattern, $userAgent)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 解析操作系统
     * @param string $userAgent 用户代理
     * @return string 操作系统
     */
    protected static function parseOS($userAgent) {
        $osPatterns = [
            [self::OS_IOS, '/(iphone|ipad|ipod)/i'],
            [self::OS_ANDROID, '/android/i'],
            [self::OS_WINDOWS, '/windows/i'],
            [self::OS_MACOS, '/macintosh|mac os x/i'],
            [self::OS_LINUX, '/linux(?! android)/i'], // 排除Android
            [self::OS_CHROMEOS, '/cros/i']
        ];
        
        foreach ($osPatterns as [$os, $pattern]) {
            if (preg_match($pattern, $userAgent)) {
                return $os;
            }
        }
        
        return self::OS_UNKNOWN;
    }
    
    /**
     * 解析操作系统版本
     * @param string $userAgent 用户代理
     * @param string $os 操作系统
     * @return float 版本号
     */
    protected static function parseOSVersion($userAgent, $os) {
        switch ($os) {
            case self::OS_IOS:
                if (preg_match('/os (\d+(?:\_\d+)*)/i', $userAgent, $matches)) {
                    return (float)str_replace('_', '.', $matches[1]);
                }
                break;
            case self::OS_ANDROID:
                if (preg_match('/android (\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::OS_WINDOWS:
                if (preg_match('/windows nt (\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::OS_MACOS:
                if (preg_match('/mac os x (\d+(?:\_\d+)*)/i', $userAgent, $matches)) {
                    return (float)str_replace('_', '.', $matches[1]);
                }
                break;
        }
        return 0;
    }
    
    /**
     * 解析浏览器
     * @param string $userAgent 用户代理
     * @return string 浏览器
     */
    protected static function parseBrowser($userAgent) {
        $browserPatterns = [
            [self::BROWSER_CHROME, '/chrome\/\d+/i', '/edg/i'], // Chrome但不是Edge
            [self::BROWSER_EDGE, '/edg\/\d+/i'],
            [self::BROWSER_SAFARI, '/safari\/\d+/i', '/chrome/i'], // Safari但不是Chrome
            [self::BROWSER_FIREFOX, '/firefox\/\d+/i'],
            [self::BROWSER_IE, '/msie/i'],
            [self::BROWSER_OPERA, '/opera|opr\/\d+/i'],
            [self::BROWSER_SAMSUNG, '/samsungbrowser\/\d+/i'],
            [self::BROWSER_UC, '/ucbrowser\/\d+/i']
        ];
        
        foreach ($browserPatterns as $browserDef) {
            $browser = $browserDef[0];
            $matchPattern = $browserDef[1];
            $excludePatterns = array_slice($browserDef, 2);
            
            if (preg_match($matchPattern, $userAgent)) {
                $exclude = false;
                foreach ($excludePatterns as $excludePattern) {
                    if (preg_match($excludePattern, $userAgent)) {
                        $exclude = true;
                        break;
                    }
                }
                
                if (!$exclude) {
                    return $browser;
                }
            }
        }
        
        return self::BROWSER_UNKNOWN;
    }
    
    /**
     * 解析浏览器版本
     * @param string $userAgent 用户代理
     * @param string $browser 浏览器
     * @return float 版本号
     */
    protected static function parseBrowserVersion($userAgent, $browser) {
        switch ($browser) {
            case self::BROWSER_CHROME:
                if (preg_match('/chrome\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_EDGE:
                if (preg_match('/edg\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_SAFARI:
                if (preg_match('/version\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_FIREFOX:
                if (preg_match('/firefox\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_IE:
                if (preg_match('/msie (\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_OPERA:
                if (preg_match('/(?:opera|opr)\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_SAMSUNG:
                if (preg_match('/samsungbrowser\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
            case self::BROWSER_UC:
                if (preg_match('/ucbrowser\/(\d+(?:\.\d+)*)/i', $userAgent, $matches)) {
                    return (float)$matches[1];
                }
                break;
        }
        return 0;
    }
    
    /**
     * 解析设备类型
     * @param string $userAgent 用户代理
     * @param string $os 操作系统
     * @param string $browser 浏览器
     * @return string 设备类型
     */
    protected static function parseDeviceType($userAgent, $os, $browser) {
        // 移动设备关键词
        $mobilePatterns = [
            '/mobile/i',
            '/phone/i',
            '/iphone/i',
            '/ipod/i',
            '/android.*mobile/i',
            '/blackberry/i',
            '/windows phone/i',
            '/symbian/i',
            '/webos/i'
        ];
        
        // 平板设备关键词
        $tabletPatterns = [
            '/ipad/i',
            '/android(?!.*mobile)/i',
            '/tablet/i',
            '/kindle/i',
            '/playbook/i',
            '/silk/i'
        ];
        
        // 检查平板设备
        foreach ($tabletPatterns as $pattern) {
            if (preg_match($pattern, $userAgent)) {
                return self::DEVICE_TYPE_TABLET;
            }
        }
        
        // 检查移动设备
        foreach ($mobilePatterns as $pattern) {
            if (preg_match($pattern, $userAgent)) {
                return self::DEVICE_TYPE_MOBILE;
            }
        }
        
        // 默认为桌面设备
        return self::DEVICE_TYPE_DESKTOP;
    }
    
    /**
     * 估算设备像素比
     * @param string $userAgent 用户代理
     * @param string $deviceType 设备类型
     * @param string $os 操作系统
     * @return float 设备像素比估计值
     */
    protected static function estimateDevicePixelRatio($userAgent, $deviceType, $os) {
        // 根据设备类型和操作系统估计DPR
        switch ($deviceType) {
            case self::DEVICE_TYPE_MOBILE:
            case self::DEVICE_TYPE_TABLET:
                // 大多数现代移动设备和平板的DPR为2.0或更高
                if ($os === self::OS_IOS) {
                    // iOS设备的常见DPR
                    if (preg_match('/ipad.*pro/i', $userAgent)) {
                        return 2.0;
                    } elseif (preg_match('/iphone\s*x|iphone\s*1[1-4]/i', $userAgent)) {
                        return 3.0;
                    }
                    return 2.0;
                } elseif ($os === self::OS_ANDROID) {
                    // 大多数Android设备的DPR为2.0或3.0
                    return 2.0;
                }
                return 2.0;
            
            case self::DEVICE_TYPE_DESKTOP:
            default:
                // 大多数桌面显示器的DPR为1.0
                // 高分屏桌面显示器可能有2.0或更高的DPR
                if (preg_match('/macintosh.*retina|windows.*surface/i', $userAgent)) {
                    return 2.0;
                }
                return 1.0;
        }
    }
    
    /**
     * 生成响应式设计的CSS媒体查询类名
     * @return string 包含当前断点信息的类名
     */
    public static function getResponsiveClass() {
        $deviceType = self::detectDeviceType();
        $breakpoint = self::getBreakpoint();
        $os = self::detectOS();
        $supportsTouch = self::supportsTouch() ? 'touch' : 'no-touch';
        
        return "device-{$deviceType} breakpoint-{$breakpoint} os-{$os} {$supportsTouch}";
    }
    
    /**
     * 获取设备图标类名
     * @return string Font Awesome或其他图标库的类名
     */
    public static function getDeviceIconClass() {
        $deviceType = self::detectDeviceType();
        $os = self::detectOS();
        
        switch ($deviceType) {
            case self::DEVICE_TYPE_MOBILE:
                switch ($os) {
                    case self::OS_IOS:
                        return 'fa-apple';
                    case self::OS_ANDROID:
                        return 'fa-android';
                    default:
                        return 'fa-mobile';
                }
            case self::DEVICE_TYPE_TABLET:
                return 'fa-tablet';
            case self::DEVICE_TYPE_DESKTOP:
                return 'fa-desktop';
            case self::DEVICE_TYPE_BOT:
                return 'fa-robot';
            default:
                return 'fa-question-circle';
        }
    }
    
    /**
     * 为响应式设计生成CSS样式类
     * @return string CSS样式
     */
    public static function getResponsiveCSS() {
        $deviceType = self::detectDeviceType();
        $breakpoint = self::getBreakpoint();
        
        return ".device-{$deviceType} { /* 设备特定样式 */ }
.breakpoint-{$breakpoint} { /* 断点特定样式 */ }
";
    }
    
    /**
     * 获取详细的设备诊断报告
     * @return array 诊断信息数组
     */
    public static function getDiagnosticReport() {
        $deviceInfo = self::getDeviceInfo();
        $width = self::getScreenWidth();
        $height = self::getScreenHeight();
        $breakpoint = self::getBreakpoint();
        
        return [
            'user_agent' => $deviceInfo['user_agent'],
            'device' => [
                'type' => $deviceInfo['device_type'],
                'supports_touch' => $deviceInfo['supports_touch'],
                'icon_class' => self::getDeviceIconClass()
            ],
            'display' => [
                'width' => $width,
                'height' => $height,
                'aspect_ratio' => round($width / $height, 2),
                'dpr' => $deviceInfo['dpr'],
                'breakpoint' => $breakpoint
            ],
            'os' => [
                'name' => $deviceInfo['os'],
                'version' => $deviceInfo['os_version']
            ],
            'browser' => [
                'name' => $deviceInfo['browser'],
                'version' => $deviceInfo['browser_version']
            ],
            'css_class' => self::getResponsiveClass(),
            'timestamp' => time()
        ];
    }
    
    /**
     * 清除设备信息缓存
     */
    public static function clearCache() {
        self::$deviceInfo = null;
    }
}