<?php
/**
 * 自动报警系统
 * 提供错误日志监控、性能异常检测和分级报警功能
 */

class AlarmSystem {
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        // 报警配置
        'enable_alarm' => true,
        'min_interval_between_alerts' => 5, // 两次相同报警的最小间隔（分钟）
        
        // 邮件配置
        'email_enabled' => true,
        'email_from' => 'alarm@example.com',
        'email_smtp_host' => 'smtp.example.com',
        'email_smtp_port' => 587,
        'email_smtp_user' => 'alarm@example.com',
        'email_smtp_pass' => 'password',
        'email_smtp_secure' => 'tls',
        'email_recipients' => [
            // 不同级别的收件人
            'critical' => ['admin@example.com'],
            'warning' => ['admin@example.com', 'tech@example.com'],
            'info' => ['tech@example.com']
        ],
        
        // 短信配置
        'sms_enabled' => true,
        'sms_api_url' => 'https://api.sms.example.com/send',
        'sms_api_key' => 'your_api_key',
        'sms_api_secret' => 'your_api_secret',
        'sms_recipients' => [
            // 不同级别的收件人
            'critical' => ['13800138000'],
            'warning' => ['13800138000', '13900139000'],
            // 通常不会发送info级别的短信
        ],
        
        // 错误监控配置
        'error_monitor_enabled' => true,
        'error_patterns' => [
            // 支付失败相关错误
            'payment_failure' => [
                'patterns' => ['支付失败', 'Payment Failed', 'Transaction Error', 'Charge Error'],
                'level' => 'critical',
                'channels' => ['email', 'sms']
            ],
            
            // 卡密验证异常
            'card_verification_error' => [
                'patterns' => ['卡密验证异常', 'Invalid Card', 'Verification Failed', 'Card Error'],
                'level' => 'critical',
                'channels' => ['email', 'sms']
            ],
            
            // 数据库连接错误
            'database_error' => [
                'patterns' => ['数据库连接', 'Database Error', 'Connection Failed', 'SQL Error'],
                'level' => 'critical',
                'channels' => ['email', 'sms']
            ],
            
            // 权限错误
            'permission_error' => [
                'patterns' => ['权限错误', 'Permission Denied', 'Access Error'],
                'level' => 'warning',
                'channels' => ['email']
            ],
            
            // 业务逻辑错误
            'business_logic_error' => [
                'patterns' => ['业务逻辑错误', 'Logic Error', 'Business Error'],
                'level' => 'warning',
                'channels' => ['email']
            ],
            
            // 性能警告
            'performance_warning' => [
                'patterns' => ['性能警告', 'Performance Warning', 'Slow Query', 'High Load'],
                'level' => 'warning',
                'channels' => ['email']
            ],
        ],
        
        // 日志监控配置
        'log_files' => [
            'error_log' => '/logs/error.log',
            'payment_log' => '/logs/payment.log',
            'card_log' => '/logs/card.log',
            'api_log' => '/logs/api.log'
        ],
        
        // 报警阈值配置
        'thresholds' => [
            'error_count_per_minute' => 10, // 每分钟错误数阈值
            'payment_failure_rate' => 5, // 支付失败率阈值（百分比）
            'slow_query_threshold' => 2, // 慢查询阈值（秒）
            'api_response_time_threshold' => 1, // API响应时间阈值（秒）
        ],
        
        // 异常波动配置
        'metric_anomaly_detection' => [
            'enabled' => true,
            'window_size' => 60, // 窗口大小（分钟）
            'threshold_factor' => 2.5, // 阈值倍数，超过这个倍数的标准差视为异常
        ],
        
        // 报警历史保留时间（天）
        'alarm_history_retention_days' => 30,
    ];
    
    /**
     * 数据库连接
     * @var PDO
     */
    protected $db = null;
    
    /**
     * 报警历史记录，用于防止报警风暴
     * @var array
     */
    protected $alarmHistory = [];
    
    /**
     * 单例实例
     * @var AlarmSystem
     */
    protected static $instance = null;
    
    /**
     * 性能优化器实例
     * @var PerformanceOptimizer
     */
    protected $performanceOptimizer = null;
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化数据库连接
        $this->initializeDatabaseConnection();
        
        // 初始化报警表
        $this->initializeAlarmTables();
        
        // 初始化性能优化器
        if (class_exists('PerformanceOptimizer')) {
            $this->performanceOptimizer = PerformanceOptimizer::getInstance();
        }
        
        // 注册错误处理器
        if ($this->config['error_monitor_enabled']) {
            $this->registerErrorHandlers();
        }
        
        // 加载历史报警记录
        $this->loadAlarmHistory();
    }
    
    /**
     * 获取单例实例
     * @param array $config 配置信息
     * @return AlarmSystem
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化数据库连接
     */
    protected function initializeDatabaseConnection() {
        try {
            // 尝试使用全局数据库连接
            if (defined('DB_HOST') && defined('DB_USER') && defined('DB_PASS') && defined('DB_NAME')) {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ];
                $this->db = new PDO($dsn, DB_USER, DB_PASS, $options);
            }
        } catch (Exception $e) {
            error_log('无法连接到数据库: ' . $e->getMessage());
        }
    }
    
    /**
     * 初始化报警表
     */
    protected function initializeAlarmTables() {
        if ($this->db === null) return;
        
        try {
            // 创建报警记录表
            $this->db->exec("CREATE TABLE IF NOT EXISTS alarm_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                alarm_type VARCHAR(100) NOT NULL,
                severity ENUM('critical', 'warning', 'info') NOT NULL,
                title VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                source VARCHAR(255),
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_severity (severity),
                INDEX idx_created_at (created_at),
                INDEX idx_alarm_type (alarm_type)
            )");
            
            // 创建业务指标表
            $this->db->exec("CREATE TABLE IF NOT EXISTS business_metrics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                metric_name VARCHAR(100) NOT NULL,
                metric_value FLOAT NOT NULL,
                metric_date DATE NOT NULL,
                metric_hour INT,
                metric_minute INT,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY idx_metric_time (metric_name, metric_date, metric_hour, metric_minute),
                INDEX idx_metric_name (metric_name),
                INDEX idx_metric_date (metric_date)
            )");
            
            // 创建错误统计临时表
            $this->db->exec("CREATE TABLE IF NOT EXISTS error_statistics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                error_type VARCHAR(100) NOT NULL,
                error_count INT NOT NULL DEFAULT 0,
                period_start TIMESTAMP NOT NULL,
                period_end TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_error_type (error_type),
                INDEX idx_period (period_start, period_end)
            )");
        } catch (Exception $e) {
            error_log('创建报警表失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 注册错误处理器
     */
    protected function registerErrorHandlers() {
        // 注册错误处理器
        set_error_handler(function($errno, $errstr, $errfile, $errline) {
            // 忽略注意和严格错误
            if ($errno & (E_NOTICE | E_STRICT)) {
                return false;
            }
            
            $errorLevel = ($errno & (E_ERROR | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR | E_RECOVERABLE_ERROR)) 
                ? 'critical' : 'warning';
            
            $this->triggerAlarm([
                'type' => 'php_error',
                'severity' => $errorLevel,
                'title' => 'PHP错误',
                'message' => "[{$errno}] {$errstr} in {$errfile} on line {$errline}",
                'source' => 'php_error_handler'
            ]);
            
            // 返回false表示继续使用PHP默认错误处理
            return false;
        });
        
        // 注册异常处理器
        set_exception_handler(function($exception) {
            $this->triggerAlarm([
                'type' => 'php_exception',
                'severity' => 'critical',
                'title' => 'PHP异常',
                'message' => get_class($exception) . ": " . $exception->getMessage() . " in " . 
                            $exception->getFile() . " on line " . $exception->getLine(),
                'source' => 'php_exception_handler',
                'metadata' => [
                    'trace' => $exception->getTraceAsString(),
                    'code' => $exception->getCode()
                ]
            ]);
            
            // 继续使用PHP默认异常处理
            return false;
        });
        
        // 注册关闭函数
        register_shutdown_function(function() {
            $error = error_get_last();
            if ($error !== null && isset($error['type']) && 
                $error['type'] & (E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR)) {
                
                $this->triggerAlarm([
                    'type' => 'php_fatal_error',
                    'severity' => 'critical',
                    'title' => 'PHP致命错误',
                    'message' => "[{$error['type']}] {$error['message']} in {$error['file']} on line {$error['line']}",
                    'source' => 'php_shutdown_function'
                ]);
            }
        });
    }
    
    /**
     * 加载报警历史，防止报警风暴
     */
    protected function loadAlarmHistory() {
        if ($this->db === null) return;
        
        try {
            $stmt = $this->db->prepare("SELECT alarm_type, created_at FROM alarm_history WHERE created_at > DATE_SUB(NOW(), INTERVAL ? MINUTE) ORDER BY created_at DESC");
            $stmt->execute([$this->config['min_interval_between_alerts']]);
            
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($history as $item) {
                $this->alarmHistory[$item['alarm_type']] = strtotime($item['created_at']);
            }
        } catch (Exception $e) {
            error_log('加载报警历史失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 检查是否需要发送报警（防报警风暴）
     * @param string $alarmType 报警类型
     * @return bool 是否需要发送
     */
    protected function shouldSendAlarm($alarmType) {
        // 检查配置中是否启用报警
        if (!$this->config['enable_alarm']) {
            return false;
        }
        
        // 如果之前没有这个类型的报警记录，直接返回true
        if (!isset($this->alarmHistory[$alarmType])) {
            return true;
        }
        
        // 计算与上次报警的时间差
        $lastAlarmTime = $this->alarmHistory[$alarmType];
        $timeDiffMinutes = (time() - $lastAlarmTime) / 60;
        
        // 如果时间差超过最小间隔，允许再次报警
        return $timeDiffMinutes >= $this->config['min_interval_between_alerts'];
    }
    
    /**
     * 触发报警
     * @param array $alarmInfo 报警信息
     * @return bool 是否成功触发
     */
    public function triggerAlarm(array $alarmInfo) {
        // 验证必要字段
        if (!isset($alarmInfo['type'], $alarmInfo['severity'], $alarmInfo['title'], $alarmInfo['message'])) {
            error_log('报警信息缺少必要字段');
            return false;
        }
        
        // 检查是否需要发送报警
        if (!$this->shouldSendAlarm($alarmInfo['type'])) {
            return false;
        }
        
        // 记录报警历史
        $this->logAlarmHistory($alarmInfo);
        
        // 根据严重性选择通知渠道
        $channels = $this->getNotificationChannelsForSeverity($alarmInfo['severity']);
        
        // 发送报警
        $sent = false;
        foreach ($channels as $channel) {
            if ($this->sendNotification($channel, $alarmInfo)) {
                $sent = true;
            }
        }
        
        return $sent;
    }
    
    /**
     * 根据严重性获取通知渠道
     * @param string $severity 严重性级别
     * @return array 通知渠道列表
     */
    protected function getNotificationChannelsForSeverity($severity) {
        $channels = [];
        
        switch ($severity) {
            case 'critical':
                if ($this->config['email_enabled']) {
                    $channels[] = 'email';
                }
                if ($this->config['sms_enabled']) {
                    $channels[] = 'sms';
                }
                break;
            case 'warning':
                if ($this->config['email_enabled']) {
                    $channels[] = 'email';
                }
                break;
            case 'info':
                if ($this->config['email_enabled']) {
                    $channels[] = 'email';
                }
                break;
        }
        
        return $channels;
    }
    
    /**
     * 发送通知
     * @param string $channel 通知渠道
     * @param array $alarmInfo 报警信息
     * @return bool 是否发送成功
     */
    protected function sendNotification($channel, array $alarmInfo) {
        switch ($channel) {
            case 'email':
                return $this->sendEmailNotification($alarmInfo);
            case 'sms':
                return $this->sendSmsNotification($alarmInfo);
            default:
                error_log("未知的通知渠道: {$channel}");
                return false;
        }
    }
    
    /**
     * 发送邮件通知
     * @param array $alarmInfo 报警信息
     * @return bool 是否发送成功
     */
    protected function sendEmailNotification(array $alarmInfo) {
        if (!$this->config['email_enabled']) {
            return false;
        }
        
        $severity = $alarmInfo['severity'];
        $recipients = $this->config['email_recipients'][$severity] ?? [];
        
        if (empty($recipients)) {
            error_log("没有为级别 {$severity} 配置邮件收件人");
            return false;
        }
        
        // 构建邮件内容
        $subject = "[{$severity}] {$alarmInfo['title']}";
        
        // HTML邮件内容
        $htmlBody = "<html>
<head>
    <title>{$subject}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 15px; }
        .critical { background-color: #ffdddd; border-left: 6px solid #f44336; }
        .warning { background-color: #ffffcc; border-left: 6px solid #ffeb3b; }
        .info { background-color: #ddffdd; border-left: 6px solid #4caf50; }
        .details { margin-top: 15px; padding: 15px; background-color: #f1f1f1; }
        .meta { font-size: 0.9em; color: #666; margin-top: 10px; }
    </style>
</head>
<body>
    <div class='alert {$severity}'>
        <h2>{$alarmInfo['title']}</h2>
        <p>{$alarmInfo['message']}</p>
    </div>
    <div class='details'>
        <p><strong>报警类型:</strong> {$alarmInfo['type']}</p>
        <p><strong>时间:</strong> " . date('Y-m-d H:i:s') . "</p>";
        
        if (isset($alarmInfo['source'])) {
            $htmlBody .= "<p><strong>来源:</strong> {$alarmInfo['source']}</p>";
        }
        
        if (isset($alarmInfo['metadata'])) {
            $htmlBody .= "<div class='meta'><strong>元数据:</strong><pre>" . json_encode($alarmInfo['metadata'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre></div>";
        }
        
        $htmlBody .= "</div>
</body>
</html>";
        
        // 纯文本内容
        $textBody = "{$subject}

{$alarmInfo['message']}

---
报警类型: {$alarmInfo['type']}";
        
        if (isset($alarmInfo['source'])) {
            $textBody .= "
来源: {$alarmInfo['source']}";
        }
        
        $textBody .= "
时间: " . date('Y-m-d H:i:s') . "\n";
        
        // 使用PHPMailer或原生mail函数发送邮件
        return $this->sendMail($recipients, $subject, $htmlBody, $textBody);
    }
    
    /**
     * 发送邮件
     * @param array $recipients 收件人列表
     * @param string $subject 主题
     * @param string $htmlBody HTML内容
     * @param string $textBody 纯文本内容
     * @return bool 是否发送成功
     */
    protected function sendMail(array $recipients, $subject, $htmlBody, $textBody) {
        try {
            // 创建邮件头
            $headers = [
                'From: ' . $this->config['email_from'],
                'Reply-To: ' . $this->config['email_from'],
                'X-Mailer: PHP/' . phpversion(),
                'MIME-Version: 1.0',
                'Content-Type: multipart/alternative; boundary="boundary"
',
            ];
            
            // 构建邮件内容
            $message = "This is a MIME encoded message.\r\n\r\n";
            $message .= "--boundary\r\n";
            $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $message .= $textBody . "\r\n\r\n";
            $message .= "--boundary\r\n";
            $message .= "Content-Type: text/html; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $message .= $htmlBody . "\r\n\r\n";
            $message .= "--boundary--";
            
            // 发送邮件到所有收件人
            foreach ($recipients as $recipient) {
                mail($recipient, $subject, $message, implode("\r\n", $headers));
            }
            
            return true;
        } catch (Exception $e) {
            error_log('发送邮件失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 发送短信通知
     * @param array $alarmInfo 报警信息
     * @return bool 是否发送成功
     */
    protected function sendSmsNotification(array $alarmInfo) {
        if (!$this->config['sms_enabled']) {
            return false;
        }
        
        $severity = $alarmInfo['severity'];
        
        // 只有严重级别才发送短信
        if ($severity !== 'critical') {
            return false;
        }
        
        $recipients = $this->config['sms_recipients'][$severity] ?? [];
        
        if (empty($recipients)) {
            error_log("没有为级别 {$severity} 配置短信收件人");
            return false;
        }
        
        // 构建短信内容（简短）
        $message = "【系统报警】{$alarmInfo['title']}：{$alarmInfo['message']}。请及时处理。";
        
        // 短信通常有长度限制，截断过长的消息
        $message = substr($message, 0, 160);
        
        // 发送短信到所有收件人
        foreach ($recipients as $recipient) {
            if (!$this->sendSms($recipient, $message)) {
                error_log("发送短信到 {$recipient} 失败");
            }
        }
        
        return true;
    }
    
    /**
     * 发送短信
     * @param string $phoneNumber 手机号码
     * @param string $message 短信内容
     * @return bool 是否发送成功
     */
    protected function sendSms($phoneNumber, $message) {
        try {
            // 准备API请求参数
            $params = [
                'api_key' => $this->config['sms_api_key'],
                'api_secret' => $this->config['sms_api_secret'],
                'phone' => $phoneNumber,
                'content' => $message,
                'timestamp' => time()
            ];
            
            // 创建签名
            ksort($params);
            $signString = implode('', $params);
            $sign = md5($signString);
            $params['sign'] = $sign;
            
            // 发送请求
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->config['sms_api_url']);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            curl_close($ch);
            
            // 解析响应
            $result = json_decode($response, true);
            
            // 检查是否发送成功（根据API的实际响应格式调整）
            return $httpCode === 200 && isset($result['code']) && $result['code'] === 0;
        } catch (Exception $e) {
            error_log('发送短信失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 记录报警历史
     * @param array $alarmInfo 报警信息
     * @return bool 是否成功记录
     */
    protected function logAlarmHistory(array $alarmInfo) {
        // 更新内存中的历史记录
        $this->alarmHistory[$alarmInfo['type']] = time();
        
        // 如果数据库连接可用，记录到数据库
        if ($this->db === null) {
            return false;
        }
        
        try {
            // 准备元数据
            $metadata = isset($alarmInfo['metadata']) ? json_encode($alarmInfo['metadata'], JSON_UNESCAPED_UNICODE) : null;
            
            // 插入数据库
            $stmt = $this->db->prepare(
                "INSERT INTO alarm_history (alarm_type, severity, title, message, source, metadata) 
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            
            $stmt->execute([
                $alarmInfo['type'],
                $alarmInfo['severity'],
                $alarmInfo['title'],
                $alarmInfo['message'],
                $alarmInfo['source'] ?? null,
                $metadata
            ]);
            
            // 清理旧的报警历史
            $this->cleanupOldAlarmHistory();
            
            return true;
        } catch (Exception $e) {
            error_log('记录报警历史失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 清理旧的报警历史
     */
    protected function cleanupOldAlarmHistory() {
        if ($this->db === null) return;
        
        try {
            $retentionDays = $this->config['alarm_history_retention_days'] ?? 30;
            $this->db->exec(
                "DELETE FROM alarm_history WHERE created_at < DATE_SUB(NOW(), INTERVAL {$retentionDays} DAY)"
            );
        } catch (Exception $e) {
            error_log('清理报警历史失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 监控日志文件中的错误
     * @param string $logFile 日志文件路径
     * @param int $lines 检查最近多少行
     */
    public function monitorLogFile($logFile, $lines = 100) {
        // 检查文件是否存在
        $fullPath = $_SERVER['DOCUMENT_ROOT'] . $logFile;
        if (!file_exists($fullPath)) {
            error_log("日志文件不存在: {$fullPath}");
            return;
        }
        
        // 获取文件的最后N行
        $logContent = $this->getLastLinesOfFile($fullPath, $lines);
        
        // 检查日志内容中的错误模式
        $this->checkLogContentForErrors($logContent, $logFile);
    }
    
    /**
     * 获取文件的最后N行
     * @param string $filePath 文件路径
     * @param int $lines 行数
     * @return string 内容
     */
    protected function getLastLinesOfFile($filePath, $lines) {
        // 使用Linux tail命令或PHP读取
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            // Windows系统
            $output = [];
            exec("powershell -Command \"Get-Content '{$filePath}' -Tail {$lines}\"", $output);
            return implode(PHP_EOL, $output);
        } else {
            // Linux/Unix系统
            $output = [];
            exec("tail -n {$lines} '{$filePath}'", $output);
            return implode(PHP_EOL, $output);
        }
    }
    
    /**
     * 检查日志内容中的错误模式
     * @param string $logContent 日志内容
     * @param string $source 日志来源
     */
    protected function checkLogContentForErrors($logContent, $source) {
        // 遍历配置的错误模式
        foreach ($this->config['error_patterns'] as $errorType => $errorConfig) {
            // 检查每个模式
            foreach ($errorConfig['patterns'] as $pattern) {
                // 使用正则表达式查找匹配
                $regex = '/' . preg_quote($pattern, '/') . '/i';
                if (preg_match_all($regex, $logContent, $matches, PREG_OFFSET_CAPTURE)) {
                    // 获取错误上下文
                    $errorLines = [];
                    $logLines = explode(PHP_EOL, $logContent);
                    
                    // 提取包含错误的行
                    foreach ($matches[0] as $match) {
                        $matchPos = $match[1];
                        $lineNum = substr_count(substr($logContent, 0, $matchPos), PHP_EOL);
                        
                        if (isset($logLines[$lineNum])) {
                            $errorLines[] = $logLines[$lineNum];
                        }
                    }
                    
                    // 如果有匹配的错误行
                    if (!empty($errorLines)) {
                        // 构建错误消息
                        $uniqueLines = array_unique($errorLines);
                        $errorMessage = implode(PHP_EOL, $uniqueLines);
                        
                        // 触发报警
                        $this->triggerAlarm([
                            'type' => $errorType,
                            'severity' => $errorConfig['level'],
                            'title' => $this->getErrorTypeTitle($errorType),
                            'message' => $errorMessage,
                            'source' => $source,
                            'metadata' => [
                                'matched_pattern' => $pattern,
                                'match_count' => count($matches[0])
                            ]
                        ]);
                    }
                }
            }
        }
    }
    
    /**
     * 获取错误类型的标题
     * @param string $errorType 错误类型
     * @return string 标题
     */
    protected function getErrorTypeTitle($errorType) {
        $titles = [
            'payment_failure' => '支付失败',
            'card_verification_error' => '卡密验证异常',
            'database_error' => '数据库错误',
            'permission_error' => '权限错误',
            'business_logic_error' => '业务逻辑错误',
            'performance_warning' => '性能警告',
            'php_error' => 'PHP错误',
            'php_exception' => 'PHP异常',
            'php_fatal_error' => 'PHP致命错误'
        ];
        
        return $titles[$errorType] ?? $errorType;
    }
    
    /**
     * 监控所有配置的日志文件
     */
    public function monitorAllLogFiles() {
        foreach ($this->config['log_files'] as $logName => $logPath) {
            $this->monitorLogFile($logPath);
        }
    }
    
    /**
     * 检查业务指标异常
     * @param string $metricName 指标名称
     * @param float $currentValue 当前值
     * @param array $metadata 元数据
     * @return bool 是否检测到异常
     */
    public function checkBusinessMetricAnomaly($metricName, $currentValue, array $metadata = []) {
        // 保存当前指标
        $this->saveBusinessMetric($metricName, $currentValue, $metadata);
        
        // 如果未启用异常检测，直接返回
        if (!$this->config['metric_anomaly_detection']['enabled']) {
            return false;
        }
        
        // 获取历史数据
        $historicalData = $this->getHistoricalBusinessMetrics($metricName);
        
        // 如果历史数据不足，无法检测异常
        if (count($historicalData) < 24) { // 需要至少24个数据点
            return false;
        }
        
        // 计算平均值和标准差
        $values = array_column($historicalData, 'metric_value');
        $mean = array_sum($values) / count($values);
        
        $variance = 0;
        foreach ($values as $value) {
            $variance += pow($value - $mean, 2);
        }
        $variance /= count($values);
        $stdDev = sqrt($variance);
        
        // 获取阈值
        $thresholdFactor = $this->config['metric_anomaly_detection']['threshold_factor'];
        
        // 检测异常
        $isAnomaly = abs($currentValue - $mean) > ($thresholdFactor * $stdDev);
        
        // 如果是异常，触发报警
        if ($isAnomaly) {
            $this->triggerAlarm([
                'type' => 'business_metric_anomaly',
                'severity' => 'warning',
                'title' => "业务指标异常波动 - {$metricName}",
                'message' => "指标 {$metricName} 出现异常波动：\n" .
                           "当前值: {$currentValue}\n" .
                           "平均值: {$mean}\n" .
                           "波动范围: {$thresholdFactor}倍标准差",
                'source' => 'business_metric_monitor',
                'metadata' => array_merge($metadata, [
                    'metric_name' => $metricName,
                    'current_value' => $currentValue,
                    'mean' => $mean,
                    'std_dev' => $stdDev,
                    'threshold_factor' => $thresholdFactor
                ])
            ]);
        }
        
        return $isAnomaly;
    }
    
    /**
     * 保存业务指标
     * @param string $metricName 指标名称
     * @param float $metricValue 指标值
     * @param array $metadata 元数据
     * @return bool 是否保存成功
     */
    public function saveBusinessMetric($metricName, $metricValue, array $metadata = []) {
        if ($this->db === null) return false;
        
        try {
            $now = new DateTime();
            $date = $now->format('Y-m-d');
            $hour = $now->format('G');
            $minute = $now->format('i');
            
            $metadataJson = json_encode($metadata, JSON_UNESCAPED_UNICODE);
            
            // 尝试更新，如果不存在则插入
            $stmt = $this->db->prepare(
                "INSERT INTO business_metrics (metric_name, metric_value, metric_date, metric_hour, metric_minute, metadata) 
                 VALUES (?, ?, ?, ?, ?, ?) 
                 ON DUPLICATE KEY UPDATE 
                 metric_value = VALUES(metric_value), 
                 metadata = VALUES(metadata),
                 created_at = CURRENT_TIMESTAMP"
            );
            
            $stmt->execute([$metricName, $metricValue, $date, $hour, $minute, $metadataJson]);
            return true;
        } catch (Exception $e) {
            error_log('保存业务指标失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取历史业务指标
     * @param string $metricName 指标名称
     * @param int $hours 小时数
     * @return array 历史指标数据
     */
    public function getHistoricalBusinessMetrics($metricName, $hours = 24) {
        if ($this->db === null) return [];
        
        try {
            $stmt = $this->db->prepare(
                "SELECT * FROM business_metrics 
                 WHERE metric_name = ? AND metric_date >= DATE_SUB(NOW(), INTERVAL ? HOUR) 
                 ORDER BY metric_date DESC, metric_hour DESC, metric_minute DESC LIMIT 1000"
            );
            
            $stmt->execute([$metricName, $hours]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log('获取历史业务指标失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 检查支付失败率
     * @param int $totalPayments 总支付次数
     * @param int $failedPayments 失败支付次数
     * @return bool 是否超过阈值
     */
    public function checkPaymentFailureRate($totalPayments, $failedPayments) {
        if ($totalPayments == 0) {
            return false;
        }
        
        // 计算失败率
        $failureRate = ($failedPayments / $totalPayments) * 100;
        
        // 检查是否超过阈值
        if ($failureRate >= $this->config['thresholds']['payment_failure_rate']) {
            $this->triggerAlarm([
                'type' => 'payment_failure_rate_high',
                'severity' => 'critical',
                'title' => '支付失败率过高',
                'message' => "当前支付失败率: {$failureRate}%，超过阈值 {$this->config['thresholds']['payment_failure_rate']}%\n" .
                           "总支付次数: {$totalPayments}\n" .
                           "失败次数: {$failedPayments}",
                'source' => 'payment_monitor',
                'metadata' => [
                    'total_payments' => $totalPayments,
                    'failed_payments' => $failedPayments,
                    'failure_rate' => $failureRate,
                    'threshold' => $this->config['thresholds']['payment_failure_rate']
                ]
            ]);
            return true;
        }
        
        return false;
    }
    
    /**
     * 检查卡密激活率异常
     * @param int $totalCards 总卡密数
     * @param int $activatedCards 已激活卡密数
     * @return bool 是否检测到异常
     */
    public function checkCardActivationRate($totalCards, $activatedCards) {
        if ($totalCards == 0) {
            return false;
        }
        
        // 计算激活率
        $activationRate = ($activatedCards / $totalCards) * 100;
        
        // 保存指标
        $this->saveBusinessMetric('card_activation_rate', $activationRate, [
            'total_cards' => $totalCards,
            'activated_cards' => $activatedCards
        ]);
        
        // 使用异常检测函数检查
        return $this->checkBusinessMetricAnomaly('card_activation_rate', $activationRate, [
            'total_cards' => $totalCards,
            'activated_cards' => $activatedCards
        ]);
    }
    
    /**
     * 检查订单转化率异常
     * @param int $totalVisits 总访问数
     * @param int $completedOrders 完成订单数
     * @return bool 是否检测到异常
     */
    public function checkOrderConversionRate($totalVisits, $completedOrders) {
        if ($totalVisits == 0) {
            return false;
        }
        
        // 计算转化率
        $conversionRate = ($completedOrders / $totalVisits) * 100;
        
        // 保存指标
        $this->saveBusinessMetric('order_conversion_rate', $conversionRate, [
            'total_visits' => $totalVisits,
            'completed_orders' => $completedOrders
        ]);
        
        // 使用异常检测函数检查
        return $this->checkBusinessMetricAnomaly('order_conversion_rate', $conversionRate, [
            'total_visits' => $totalVisits,
            'completed_orders' => $completedOrders
        ]);
    }
    
    /**
     * 检查代理推广效果异常
     * @param string $agentId 代理ID
     * @param int $promotionCount 推广次数
     * @param int $successCount 成功次数
     * @return bool 是否检测到异常
     */
    public function checkAgentPromotionEffect($agentId, $promotionCount, $successCount) {
        if ($promotionCount == 0) {
            return false;
        }
        
        // 计算成功率
        $successRate = ($successCount / $promotionCount) * 100;
        
        // 保存指标
        $this->saveBusinessMetric('agent_promotion_rate_' . $agentId, $successRate, [
            'agent_id' => $agentId,
            'promotion_count' => $promotionCount,
            'success_count' => $successCount
        ]);
        
        // 使用异常检测函数检查
        return $this->checkBusinessMetricAnomaly('agent_promotion_rate_' . $agentId, $successRate, [
            'agent_id' => $agentId,
            'promotion_count' => $promotionCount,
            'success_count' => $successCount
        ]);
    }
    
    /**
     * 检查性能指标
     * @param array $metrics 性能指标
     * @return array 超过阈值的指标列表
     */
    public function checkPerformanceMetrics(array $metrics) {
        $alerts = [];
        
        // 检查服务器负载
        if (isset($metrics['server_load']) && isset($metrics['server_load']['1min'])) {
            if ($metrics['server_load']['1min'] > $this->config['thresholds']['server_load'] ?? 8.0) {
                $alerts[] = [
                    'type' => 'server_load',
                    'severity' => 'warning',
                    'message' => "服务器负载过高: {$metrics['server_load']['1min']}",
                    'value' => $metrics['server_load']['1min'],
                    'threshold' => $this->config['thresholds']['server_load'] ?? 8.0
                ];
            }
        }
        
        // 检查数据库连接池
        if (isset($metrics['database']) && isset($metrics['database']['connection_pool_usage'])) {
            if ($metrics['database']['connection_pool_usage'] > ($this->config['thresholds']['db_connection_pool_usage'] ?? 80.0)) {
                $alerts[] = [
                    'type' => 'db_connection_pool',
                    'severity' => 'warning',
                    'message' => "数据库连接池使用率过高: {$metrics['database']['connection_pool_usage']}%",
                    'value' => $metrics['database']['connection_pool_usage'],
                    'threshold' => $this->config['thresholds']['db_connection_pool_usage'] ?? 80.0
                ];
            }
        }
        
        // 检查API响应时间
        if (isset($metrics['api']) && isset($metrics['api']['avg_response_time'])) {
            if ($metrics['api']['avg_response_time'] > ($this->config['thresholds']['api_response_time_threshold'] * 1000)) {
                $alerts[] = [
                    'type' => 'api_response_time',
                    'severity' => 'warning',
                    'message' => "API平均响应时间过长: {$metrics['api']['avg_response_time']}ms",
                    'value' => $metrics['api']['avg_response_time'],
                    'threshold' => ($this->config['thresholds']['api_response_time_threshold'] ?? 1.0) * 1000
                ];
            }
        }
        
        // 为每个超过阈值的指标触发报警
        foreach ($alerts as $alert) {
            $this->triggerAlarm([
                'type' => $alert['type'],
                'severity' => $alert['severity'],
                'title' => '性能指标异常',
                'message' => $alert['message'],
                'source' => 'performance_monitor',
                'metadata' => $alert
            ]);
        }
        
        return $alerts;
    }
    
    /**
     * 获取报警历史
     * @param int $limit 限制数量
     * @param string $severity 严重性过滤
     * @return array 报警历史
     */
    public function getAlarmHistory($limit = 100, $severity = null) {
        if ($this->db === null) return [];
        
        try {
            $query = "SELECT * FROM alarm_history";
            $params = [];
            
            if ($severity) {
                $query .= " WHERE severity = ?";
                $params[] = $severity;
            }
            
            $query .= " ORDER BY created_at DESC LIMIT ?";
            $params[] = $limit;
            
            $stmt = $this->db->prepare($query);
            $stmt->execute($params);
            
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 解析元数据
            foreach ($result as &$item) {
                if (!empty($item['metadata'])) {
                    $item['metadata'] = json_decode($item['metadata'], true);
                }
            }
            
            return $result;
        } catch (Exception $e) {
            error_log('获取报警历史失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取业务指标摘要
     * @return array 指标摘要
     */
    public function getBusinessMetricsSummary() {
        if ($this->db === null) return [];
        
        try {
            // 获取核心指标
            $metrics = ['card_activation_rate', 'order_conversion_rate'];
            $result = [];
            
            foreach ($metrics as $metric) {
                $stmt = $this->db->prepare(
                    "SELECT * FROM business_metrics 
                     WHERE metric_name = ? 
                     ORDER BY created_at DESC LIMIT 1"
                );
                $stmt->execute([$metric]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($row) {
                    if (!empty($row['metadata'])) {
                        $row['metadata'] = json_decode($row['metadata'], true);
                    }
                    $result[$metric] = $row;
                }
            }
            
            // 获取代理推广指标
            $stmt = $this->db->prepare(
                "SELECT * FROM business_metrics 
                 WHERE metric_name LIKE 'agent_promotion_rate_%' 
                 ORDER BY created_at DESC LIMIT 10"
            );
            $stmt->execute();
            $agentMetrics = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($agentMetrics as &$metric) {
                if (!empty($metric['metadata'])) {
                    $metric['metadata'] = json_decode($metric['metadata'], true);
                }
            }
            
            $result['agent_promotion_metrics'] = $agentMetrics;
            
            return $result;
        } catch (Exception $e) {
            error_log('获取业务指标摘要失败: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取配置
     * @return array 配置
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 更新配置
     * @param array $newConfig 新配置
     */
    public function updateConfig(array $newConfig) {
        $this->config = array_merge_recursive($this->config, $newConfig);
    }
}

// 初始化报警系统的便捷函数
function initializeAlarmSystem($config = []) {
    return AlarmSystem::getInstance($config);
}

// 手动触发报警的便捷函数
function triggerAlarm($type, $title, $message, $severity = 'warning', $source = 'manual', $metadata = []) {
    $alarmSystem = AlarmSystem::getInstance();
    return $alarmSystem->triggerAlarm([
        'type' => $type,
        'severity' => $severity,
        'title' => $title,
        'message' => $message,
        'source' => $source,
        'metadata' => $metadata
    ]);
}