<?php
/**
 * 错误日志监控系统
 * 提供异常捕获、错误日志分析、实时监控和可视化功能
 * 
 * @package CardSystem\Monitoring
 * @author System Developer
 * @version 1.0.0
 */

// 定义必要的常量
if (!defined('DEBUG_BACKTRACE_IGNORE_ARGS')) {
    define('DEBUG_BACKTRACE_IGNORE_ARGS', 1);
}

// 移除不存在的命名空间引用
require_once __DIR__ . '/../Logger.php';

/**
 * ErrorLogMonitor类 - 错误日志监控系统
 */
class ErrorLogMonitor
{
    /**
     * 配置管理器实例
     * @var object
     */
    private $configManager;
    
    /**
     * 日志记录器实例
     * @var object
     */
    private $logger;
    
    /**
     * Redis客户端实例
     * @var object
     */
    private $redisClient;
    
    /**
     * 文件存储实例
     * @var object
     */
    private $fileStorage;
    
    /**
     * 错误监控配置
     * @var array
     */
    private $config;
    
    /**
     * 最近错误缓存
     * @var array
     */
    private $recentErrors = [];
    
    /**
     * 错误聚合数据
     * @var array
     */
    private $errorAggregates = [];
    
    /**
     * 构造函数
     * 
     * @param object $configManager 配置管理器
     * @param object $logger 日志记录器
     * @param object $redisClient Redis客户端
     * @param object $fileStorage 文件存储
     */
    public function __construct($configManager = null, $logger = null, 
                             $redisClient = null, $fileStorage = null)
    {
        // 如果没有提供实例，则创建默认实例
        $this->logger = $logger ?? new Logger();
        // 其他参数如果为null，提供合理的默认值
        $this->configManager = $configManager ?? (object)['get' => function($key, $default = []) { return $default; }];
        $this->redisClient = $redisClient;
        $this->fileStorage = $fileStorage;
        
        // 加载配置
        $this->config = $this->configManager->get('error_monitoring', []);
        
        // 初始化错误处理器
        $this->initErrorHandlers();
        
        // 加载历史错误数据
        $this->loadRecentErrors();
        
        $this->logger->info('错误日志监控系统初始化成功');
    }
    
    /**
     * 初始化错误处理器
     */
    private function initErrorHandlers()
    {
        if ($this->config['enabled']) {
            // 注册PHP错误处理器
            set_error_handler([$this, 'handleError']);
            
            // 注册PHP异常处理器
            set_exception_handler([$this, 'handleException']);
            
            // 注册关闭函数处理器
            register_shutdown_function([$this, 'handleShutdown']);
            
            $this->logger->info('PHP错误处理器已成功注册');
        }
    }
    
    /**
     * 错误处理器
     * 
     * @param int $errno 错误号
     * @param string $errstr 错误消息
     * @param string $errfile 错误文件
     * @param int $errline 错误行号
     * @return bool 是否处理了错误
     */
    public function handleError($errno, $errstr, $errfile, $errline)
    {
        // 忽略被@抑制的错误
        if (error_reporting() === 0) {
            return false;
        }
        
        // 根据配置决定是否处理该类型错误
        $errorTypes = $this->config['error_types'] ?? [E_ERROR, E_WARNING, E_PARSE, E_NOTICE];
        if (!in_array($errno, $errorTypes)) {
            return false;
        }
        
        // 获取错误类型
        $errorType = $this->getErrorTypeName($errno);
        
        // 构建错误数据
        $errorData = [
            'type' => $errorType,
            'message' => $errstr,
            'file' => $errfile,
            'line' => $errline,
            'stack_trace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS),
            'request_info' => $this->getRequestInfo(),
            'timestamp' => time(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'environment' => $this->config['environment'] ?? 'production',
            'error_code' => $errno
        ];
        
        // 处理错误
        $this->processError($errorData);
        
        // 返回true表示我们处理了错误，false表示让PHP继续处理
        return $this->config['override_default_handler'] ?? false;
    }
    
    /**
     * 异常处理器
     * 
     * @param \Exception $exception 异常对象
     */
    public function handleException($exception)
    {
        // 构建异常数据
        $errorData = [
            'type' => 'Exception',
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'stack_trace' => $exception->getTrace(),
            'request_info' => $this->getRequestInfo(),
            'timestamp' => time(),
            'user_id' => $this->getCurrentUserId(),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'environment' => $this->config['environment'] ?? 'production',
            'error_code' => $exception->getCode(),
            'exception_class' => get_class($exception)
        ];
        
        // 处理异常
        $this->processError($errorData);
        
        // 决定是否显示错误（根据环境）
        if ($this->config['show_errors'] ?? false) {
            echo "\n\nAn error occurred:\n";
            echo $exception->getMessage() . "\n";
            echo "In file: " . $exception->getFile() . " on line " . $exception->getLine() . "\n";
        }
    }
    
    /**
     * 关闭函数处理器
     */
    public function handleShutdown()
    {
        // 检查是否有致命错误
        $error = error_get_last();
        if ($error && ($error['type'] & (E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR))) {
            // 构建致命错误数据
            $errorData = [
                'type' => 'Fatal Error',
                'message' => $error['message'],
                'file' => $error['file'],
                'line' => $error['line'],
                'stack_trace' => [],
                'request_info' => $this->getRequestInfo(),
                'timestamp' => time(),
                'user_id' => $this->getCurrentUserId(),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'environment' => $this->config['environment'] ?? 'production',
                'error_code' => $error['type']
            ];
            
            // 处理致命错误
            $this->processError($errorData);
            
            // 记录到系统日志
            $this->logger->critical("致命错误: {$error['message']} in {$error['file']}:{$error['line']}");
        }
    }
    
    /**
     * 处理错误数据
     * 
     * @param array $errorData 错误数据
     */
    private function processError($errorData)
    {
        // 生成错误ID
        $errorId = uniqid('err_', true);
        $errorData['id'] = $errorId;
        
        // 存储错误
        $this->storeError($errorData);
        
        // 添加到最近错误列表
        $this->addRecentError($errorData);
        
        // 更新错误聚合数据
        $this->updateErrorAggregates($errorData);
        
        // 检查是否需要报警
        $this->checkForAlert($errorData);
        
        // 如果是严重错误，立即报警
        if ($this->isCriticalError($errorData)) {
            $this->triggerImmediateAlert($errorData);
        }
    }
    
    /**
     * 存储错误
     * 
     * @param array $errorData 错误数据
     */
    private function storeError($errorData)
    {
        try {
            // 存储到Redis（用于实时监控）
            if ($this->redisClient && is_object($this->redisClient)) {
                if (method_exists($this->redisClient, 'hset')) {
                    $this->redisClient->hset('card_system:errors', $errorData['id'], json_encode($errorData));
                }
                
                // 设置过期时间（例如7天）
                if (method_exists($this->redisClient, 'expire')) {
                    $this->redisClient->expire('card_system:errors:' . $errorData['id'], 7 * 24 * 60 * 60);
                } else if (method_exists($this->redisClient, 'xpire')) {
                    // 兼容Redis客户端API差异
                    $this->redisClient->xpire('card_system:errors:' . $errorData['id'], 7 * 24 * 60 * 60);
                }
            }
            
            // 同时记录到文件（用于长期存储）
            if ($this->fileStorage && is_object($this->fileStorage) && method_exists($this->fileStorage, 'append')) {
                $logFile = $this->getLogFilePath($errorData['timestamp']);
                $this->fileStorage->append($logFile, json_encode($errorData) . "\n");
            }
            
        } catch (\Exception $e) {
            // 防止错误处理器本身出错
            $this->logger->warning("错误日志存储失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 添加到最近错误列表
     * 
     * @param array $errorData 错误数据
     */
    private function addRecentError($errorData)
    {
        // 限制最近错误数量，避免内存占用过多
        $maxRecentErrors = $this->config['max_recent_errors'] ?? 100;
        
        // 添加到数组开头
        array_unshift($this->recentErrors, $errorData);
        
        // 如果超过限制，移除最旧的错误
        if (count($this->recentErrors) > $maxRecentErrors) {
            $this->recentErrors = array_slice($this->recentErrors, 0, $maxRecentErrors);
        }
        
        // 也存储到Redis，以便在集群环境中共享
        try {
            if ($this->redisClient && is_object($this->redisClient) && 
                method_exists($this->redisClient, 'lpush') && 
                method_exists($this->redisClient, 'ltrim')) {
                $this->redisClient->lpush('card_system:recent_errors', json_encode($errorData));
                $this->redisClient->ltrim('card_system:recent_errors', 0, $maxRecentErrors - 1);
            }
        } catch (\Exception $e) {
            // 忽略Redis错误
        }
    }
    
    /**
     * 更新错误聚合数据
     * 
     * @param array $errorData 错误数据
     */
    private function updateErrorAggregates($errorData)
    {
        $errorKey = $this->generateErrorKey($errorData);
        
        if (!isset($this->errorAggregates[$errorKey])) {
            $this->errorAggregates[$errorKey] = [
                'message' => $errorData['message'],
                'type' => $errorData['type'],
                'file' => $errorData['file'],
                'line' => $errorData['line'],
                'count' => 0,
                'first_seen' => $errorData['timestamp'],
                'last_seen' => $errorData['timestamp'],
                'sample_ids' => [],
                'affected_ips' => []
            ];
        }
        
        // 更新聚合数据
        $this->errorAggregates[$errorKey]['count']++;
        $this->errorAggregates[$errorKey]['last_seen'] = $errorData['timestamp'];
        $this->errorAggregates[$errorKey]['sample_ids'][] = $errorData['id'];
        $this->errorAggregates[$errorKey]['affected_ips'][] = $errorData['ip_address'];
        
        // 去重IP
        $this->errorAggregates[$errorKey]['affected_ips'] = array_unique($this->errorAggregates[$errorKey]['affected_ips']);
        
        // 限制样本ID数量
        if (count($this->errorAggregates[$errorKey]['sample_ids']) > 10) {
            $this->errorAggregates[$errorKey]['sample_ids'] = array_slice($this->errorAggregates[$errorKey]['sample_ids'], -10);
        }
    }
    
    /**
     * 检查是否需要报警
     * 
     * @param array $errorData 错误数据
     */
    private function checkForAlert($errorData)
    {
        // 检查错误率阈值
        $errorRate = $this->calculateErrorRate();
        $threshold = $this->config['error_rate_threshold'] ?? 5; // 5%的错误率
        
        if ($errorRate > $threshold) {
            $this->triggerAlert(
                '错误率超过阈值',
                "当前错误率: {$errorRate}%, 阈值: {$threshold}%",
                'high'
            );
        }
        
        // 检查是否是重复错误
        $errorKey = $this->generateErrorKey($errorData);
        $repeatCount = $this->errorAggregates[$errorKey]['count'] ?? 1;
        $repeatThreshold = $this->config['repeat_error_threshold'] ?? 10;
        
        if ($repeatCount > $repeatThreshold && $repeatCount % $repeatThreshold === 0) {
            $this->triggerAlert(
                '重复错误告警',
                "错误已重复 {$repeatCount} 次: {$errorData['message']} in {$errorData['file']}:{$errorData['line']}",
                'medium'
            );
        }
    }
    
    /**
     * 触发立即告警（用于严重错误）
     * 
     * @param array $errorData 错误数据
     */
    private function triggerImmediateAlert($errorData)
    {
        $this->triggerAlert(
            '严重错误告警',
            "{$errorData['type']}: {$errorData['message']} in {$errorData['file']}:{$errorData['line']}",
            'critical',
            $errorData
        );
    }
    

    

    

    
    /**
     * 触发告警
     * 
     * @param string $title 告警标题
     * @param string $message 告警消息
     * @param string $severity 严重程度
     * @param array $metadata 附加数据
     */
    private function triggerAlert($title, $message, $severity = 'medium', $metadata = [])
    {
        // 构建告警数据
        $alertData = [
            'id' => uniqid('alert_', true),
            'title' => $title,
            'message' => $message,
            'severity' => $severity,
            'timestamp' => time(),
            'metadata' => $metadata,
            'status' => 'unresolved',
            'environment' => $this->config['environment'] ?? 'production'
        ];
        
        // 存储告警
        try {
            $this->redisClient->hset('card_system:alerts', $alertData['id'], json_encode($alertData));
            
            // 发送告警通知
            $this->sendAlertNotifications($alertData);
        } catch (\Exception $e) {
            // 忽略错误，防止告警系统本身出错
            error_log("发送告警失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 发送告警通知
     * 
     * @param array $alertData 告警数据
     */
    private function sendAlertNotifications($alertData)
    {
        // 获取通知渠道配置
        $notifications = $this->config['notifications'] ?? [];
        
        // 根据严重程度决定通知方式
        if ($alertData['severity'] === 'critical') {
            // 关键错误发送所有可用通知
            foreach ($notifications as $channel => $config) {
                if ($config['enabled']) {
                    $this->sendNotification($channel, $alertData, $config);
                }
            }
        } elseif ($alertData['severity'] === 'high') {
            // 高优先级错误发送邮件和短信
            foreach (['email', 'sms'] as $channel) {
                if (isset($notifications[$channel]) && $notifications[$channel]['enabled']) {
                    $this->sendNotification($channel, $alertData, $notifications[$channel]);
                }
            }
        } else {
            // 中低优先级错误只发送邮件
            if (isset($notifications['email']) && $notifications['email']['enabled']) {
                $this->sendNotification('email', $alertData, $notifications['email']);
            }
        }
    }
    
    /**
     * 发送具体通知
     * 
     * @param string $channel 通知渠道
     * @param array $alertData 告警数据
     * @param array $config 通知配置
     */
    private function sendNotification($channel, $alertData, $config)
    {
        try {
            switch ($channel) {
                case 'email':
                    $this->sendEmailNotification($alertData, $config);
                    break;
                    
                case 'sms':
                    $this->sendSmsNotification($alertData, $config);
                    break;
                    
                case 'webhook':
                    $this->sendWebhookNotification($alertData, $config);
                    break;
                    
                case 'slack':
                    $this->sendSlackNotification($alertData, $config);
                    break;
                    
                default:
                    $this->logger->warning("未知的通知渠道: {$channel}");
            }
        } catch (\Exception $e) {
            $this->logger->warning("发送{$channel}通知失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 发送邮件通知
     * 
     * @param array $alertData 告警数据
     * @param array $config 邮件配置
     */
    private function sendEmailNotification($alertData, $config)
    {
        // 简化实现，实际应集成邮件发送库
        $recipients = implode(', ', $config['recipients'] ?? []);
        $subject = "[{$alertData['severity']}] {$alertData['title']}";
        
        // 构建邮件内容
        $body = "<h2>{$alertData['title']}</h2>\n";
        $body .= "<p>{$alertData['message']}</p>\n";
        $body .= "<p><strong>严重程度:</strong> {$alertData['severity']}</p>\n";
        $body .= "<p><strong>时间:</strong> " . date('Y-m-d H:i:s', $alertData['timestamp']) . "</p>\n";
        $body .= "<p><strong>环境:</strong> {$alertData['environment']}</p>\n";
        
        // 如果有错误详情，添加到邮件中
        if (!empty($alertData['metadata'])) {
            $body .= "<h3>详细信息:</h3>\n";
            $body .= "<pre>" . json_encode($alertData['metadata'], JSON_PRETTY_PRINT) . "</pre>\n";
        }
        
        // 记录但不实际发送（实际项目中应集成邮件发送库）
        $this->logger->notice("邮件通知已记录 (收件人: {$recipients}, 主题: {$subject})");
    }
    
    /**
     * 发送短信通知
     * 
     * @param array $alertData 告警数据
     * @param array $config 短信配置
     */
    private function sendSmsNotification($alertData, $config)
    {
        // 简化实现，实际应集成短信发送API
        $phones = implode(', ', $config['phone_numbers'] ?? []);
        $message = "[卡系统] {$alertData['title']}: {$alertData['message']} ({$alertData['severity']})";
        
        // 记录但不实际发送（实际项目中应集成短信发送API）
        $this->logger->notice("短信通知已记录 (号码: {$phones}, 内容: {$message})");
    }
    
    /**
     * 发送Webhook通知
     * 
     * @param array $alertData 告警数据
     * @param array $config Webhook配置
     */
    private function sendWebhookNotification($alertData, $config)
    {
        // 简化实现，实际应发送HTTP请求到指定URL
        $webhookUrl = $config['url'] ?? '';
        $this->logger->notice("Webhook通知已记录 (URL: {$webhookUrl})");
    }
    
    /**
     * 发送Slack通知
     * 
     * @param array $alertData 告警数据
     * @param array $config Slack配置
     */
    private function sendSlackNotification($alertData, $config)
    {
        // 简化实现，实际应发送到Slack Webhook
        $webhookUrl = $config['webhook_url'] ?? '';
        $channel = $config['channel'] ?? '#alerts';
        
        // 构建Slack消息
        $slackMessage = [
            'channel' => $channel,
            'username' => '错误监控系统',
            'icon_emoji' => ':warning:',
            'text' => "*[{$alertData['severity']}] {$alertData['title']}*\n{$alertData['message']}"
        ];
        
        $this->logger->notice("Slack通知已记录 (渠道: {$channel})");
    }
    
    /**
     * 加载最近错误数据
     */
    private function loadRecentErrors()
    {
        try {
            // 从Redis加载最近错误
            $recentErrors = $this->redisClient->lrange('card_system:recent_errors', 0, -1);
            
            if (!empty($recentErrors)) {
                foreach ($recentErrors as $errorJson) {
                    $this->recentErrors[] = json_decode($errorJson, true);
                }
            }
        } catch (\Exception $e) {
            // 忽略Redis错误，使用空列表
        }
    }
    
    /**
     * 获取错误日志文件路径
     * 
     * @param int $timestamp 时间戳
     * @return string 文件路径
     */
    private function getLogFilePath($timestamp)
    {
        $logDir = $this->config['log_directory'] ?? 'logs/errors';
        $date = date('Y-m-d', $timestamp);
        
        return "{$logDir}/error_{$date}.log";
    }
    
    /**
     * 生成错误键（用于聚合相似错误）
     * 
     * @param array $errorData 错误数据
     * @return string 错误键
     */
    private function generateErrorKey($errorData)
    {
        // 使用错误消息、类型、文件和行号生成唯一键
        // 为了更好的聚合，可能需要移除动态部分（如ID、时间戳等）
        $sanitizedMessage = $this->sanitizeErrorMessage($errorData['message']);
        return "{$errorData['type']}:{$errorData['file']}:{$errorData['line']}:{$sanitizedMessage}";
    }
    
    /**
     * 清理错误消息中的动态部分
     * 
     * @param string $message 错误消息
     * @return string 清理后的消息
     */
    private function sanitizeErrorMessage($message)
    {
        // 替换可能变化的数字和ID
        $message = preg_replace('/\b\d+\b/', '?', $message);
        
        // 替换可能变化的哈希值
        $message = preg_replace('/[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}/', '?', $message);
        
        // 替换可能变化的字符串值
        $message = preg_replace('/["\'][^"\']*["\']/', '"?"', $message);
        
        return $message;
    }
    
    /**
     * 计算错误率
     * 
     * @return float 错误率（百分比）
     */
    private function calculateErrorRate()
    {   
        try {
            // 从Redis获取总请求数和错误数
            $totalRequests = $this->redisClient->get('card_system:total_requests') ?? 0;
            $errorCount = $this->redisClient->get('card_system:error_count') ?? 0;
            
            if ($totalRequests == 0) {
                return 0;
            }
            
            return ($errorCount / $totalRequests) * 100;
        } catch (\Exception $e) {
            // 发生错误时返回模拟数据
            return rand(0, 10);
        }
    }
    
    /**
     * 判断是否是严重错误
     * 
     * @param array $errorData 错误数据
     * @return bool 是否是严重错误
     */
    private function isCriticalError($errorData)
    {
        $criticalTypes = [
            'Fatal Error',
            'E_ERROR',
            'E_PARSE',
            'E_CORE_ERROR',
            'E_COMPILE_ERROR'
        ];
        
        return in_array($errorData['type'], $criticalTypes) || 
               ($errorData['error_code'] !== null && in_array($errorData['error_code'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR]));
    }
    
    /**
     * 获取错误类型名称
     * 
     * @param int $errorCode 错误代码
     * @return string 错误类型名称
     */
    private function getErrorTypeName($errorCode)
    {
        $errorTypes = [
            E_ERROR => 'E_ERROR',
            E_WARNING => 'E_WARNING',
            E_PARSE => 'E_PARSE',
            E_NOTICE => 'E_NOTICE',
            E_CORE_ERROR => 'E_CORE_ERROR',
            E_CORE_WARNING => 'E_CORE_WARNING',
            E_COMPILE_ERROR => 'E_COMPILE_ERROR',
            E_COMPILE_WARNING => 'E_COMPILE_WARNING',
            E_USER_ERROR => 'E_USER_ERROR',
            E_USER_WARNING => 'E_USER_WARNING',
            E_USER_NOTICE => 'E_USER_NOTICE',
            E_STRICT => 'E_STRICT',
            E_RECOVERABLE_ERROR => 'E_RECOVERABLE_ERROR',
            E_DEPRECATED => 'E_DEPRECATED',
            E_USER_DEPRECATED => 'E_USER_DEPRECATED'
        ];
        
        return $errorTypes[$errorCode] ?? "Unknown Error ($errorCode)";
    }
    
    /**
     * 获取请求信息
     * 
     * @return array 请求信息
     */
    private function getRequestInfo()
    {
        $request = [];
        
        // 获取请求URL
        if (isset($_SERVER['HTTP_HOST']) && isset($_SERVER['REQUEST_URI'])) {
            $request['url'] = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        }
        
        // 获取请求方法
        $request['method'] = $_SERVER['REQUEST_METHOD'] ?? 'unknown';
        
        // 获取请求参数
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $request['params'] = $_GET;
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $request['params'] = $_POST;
            
            // 尝试获取JSON请求体
            if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
                $request['json_body'] = json_decode(file_get_contents('php://input'), true);
            }
        }
        
        // 获取请求头
        $request['headers'] = $this->getRequestHeaders();
        
        // 获取Cookie信息（但可能包含敏感信息，实际应用中应谨慎记录）
        $request['cookies'] = []; // 空数组，避免记录敏感信息
        
        return $request;
    }
    
    /**
     * 获取请求头
     * 
     * @return array 请求头
     */
    private function getRequestHeaders()
    {
        $headers = [];
        
        // PHP >= 5.4.0
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
        } else {
            // 兼容旧版本PHP
            foreach ($_SERVER as $name => $value) {
                if (substr($name, 0, 5) === 'HTTP_') {
                    $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
                }
            }
        }
        
        return $headers;
    }
    
    /**
     * 获取当前用户ID
     * 
     * @return mixed 用户ID或null
     */
    private function getCurrentUserId()
    {
        // 实际应用中应从会话或认证系统获取
        if (isset($_SESSION['user_id'])) {
            return $_SESSION['user_id'];
        }
        
        return null;
    }
    
    /**
     * 获取最近错误列表
     * 
     * @param int $limit 限制数量
     * @return array 错误列表
     */
    public function getRecentErrors($limit = 50)
    {
        return array_slice($this->recentErrors, 0, $limit);
    }
    
    /**
     * 获取错误聚合数据
     * 
     * @param int $limit 限制数量
     * @return array 错误聚合数据
     */
    public function getErrorAggregates($limit = 20)
    {
        // 按错误计数排序
        uasort($this->errorAggregates, function($a, $b) {
            return $b['count'] - $a['count'];
        });
        
        // 返回前N个
        return array_slice($this->errorAggregates, 0, $limit, true);
    }
    
    /**
     * 获取错误统计信息
     * 
     * @param string $timeRange 时间范围
     * @return array 错误统计
     */
    public function getErrorStats($timeRange = '24h')
    {
        // 简化实现，返回模拟数据
        return [
            'total_errors' => rand(10, 100),
            'unique_errors' => rand(5, 20),
            'error_rate' => rand(0, 5),
            'top_error_types' => [
                ['type' => 'E_WARNING', 'count' => rand(10, 50)],
                ['type' => 'E_NOTICE', 'count' => rand(5, 30)],
                ['type' => 'Exception', 'count' => rand(3, 20)],
                ['type' => 'E_ERROR', 'count' => rand(0, 5)]
            ],
            'error_trend' => $this->generateErrorTrend($timeRange)
        ];
    }
    
    /**
     * 生成错误趋势数据
     * 
     * @param string $timeRange 时间范围
     * @return array 趋势数据
     */
    private function generateErrorTrend($timeRange)
    {
        // 简化实现，返回模拟数据
        $trend = [];
        $now = time();
        
        // 根据时间范围生成不同粒度的数据点
        $points = 24; // 默认24小时，每小时一个点
        $interval = 3600; // 1小时
        
        if ($timeRange === '7d') {
            $points = 7;
            $interval = 86400; // 1天
        } elseif ($timeRange === '1h') {
            $points = 60;
            $interval = 60; // 1分钟
        }
        
        for ($i = $points - 1; $i >= 0; $i--) {
            $timestamp = $now - ($i * $interval);
            $trend[] = [
                'timestamp' => $timestamp,
                'count' => rand(0, 10),
                'unique_count' => rand(0, 5)
            ];
        }
        
        return $trend;
    }
    
    /**
     * 获取告警列表
     * 
     * @param string $status 状态筛选
     * @param int $limit 限制数量
     * @return array 告警列表
     */
    public function getAlerts($status = 'unresolved', $limit = 50)
    {
        try {
            $alerts = [];
            $alertIds = $this->redisClient->hkeys('card_system:alerts');
            
            foreach ($alertIds as $alertId) {
                $alertJson = $this->redisClient->hget('card_system:alerts', $alertId);
                $alert = json_decode($alertJson, true);
                
                if ($status === 'all' || $alert['status'] === $status) {
                    $alerts[] = $alert;
                }
            }
            
            // 按时间降序排序
            usort($alerts, function($a, $b) {
                return $b['timestamp'] - $a['timestamp'];
            });
            
            return array_slice($alerts, 0, $limit);
        } catch (\Exception $e) {
            // 发生错误时返回空列表
            return [];
        }
    }
    
    /**
     * 标记告警为已解决
     * 
     * @param string $alertId 告警ID
     * @param string $resolution 解决说明
     * @return bool 是否成功
     */
    public function resolveAlert($alertId, $resolution = '')
    {
        try {
            $alertJson = $this->redisClient->hget('card_system:alerts', $alertId);
            
            if ($alertJson) {
                $alert = json_decode($alertJson, true);
                $alert['status'] = 'resolved';
                $alert['resolved_at'] = time();
                $alert['resolution'] = $resolution;
                
                $this->redisClient->hset('card_system:alerts', $alertId, json_encode($alert));
                return true;
            }
            
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }
    
    /**
     * 清理旧的错误日志
     * 
     * @param int $daysToKeep 保留天数
     * @return int 删除的文件数
     */
    public function cleanupOldLogs($daysToKeep = 30)
    {
        $logDir = $this->config['log_directory'] ?? 'logs/errors';
        $cutoffTime = time() - ($daysToKeep * 24 * 60 * 60);
        $deletedCount = 0;
        
        try {
            $files = $this->fileStorage->scandir($logDir);
            
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') {
                    continue;
                }
                
                $filePath = "{$logDir}/{$file}";
                $fileTime = $this->fileStorage->mtime($filePath);
                
                if ($fileTime < $cutoffTime) {
                    $this->fileStorage->unlink($filePath);
                    $deletedCount++;
                }
            }
        } catch (\Exception $e) {
            $this->logger->warning("清理日志文件失败: {$e->getMessage()}");
        }
        
        return $deletedCount;
    }
    
    /**
     * 关闭错误监控系统
     */
    public function shutdown()
    {
        $this->logger->info('错误日志监控系统正在关闭...');
        
        // 恢复默认错误处理器
        restore_error_handler();
        restore_exception_handler();
        
        // 清理资源
        $this->recentErrors = [];
        $this->errorAggregates = [];
    }
}