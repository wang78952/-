<?php
/**
 * 监控数据可视化系统
 * 负责监控数据的图表展示、数据可视化和性能分析报告生成
 * 
 * @package MonitoringSystem
 * @author System Administrator
 * @version 1.0
 */

class MonitoringVisualization {
    /**
     * 数据存储对象
     * @var MonitoringDataStorage
     */
    private $dataStorage;
    
    /**
     * 配置信息
     * @var array
     */
    private $config;
    
    /**
     * 构造函数
     * 
     * @param MonitoringDataStorage $dataStorage 数据存储对象
     * @param array $config 配置信息
     */
    public function __construct($dataStorage, $config = []) {
        $this->dataStorage = $dataStorage;
        $this->config = array_merge([
            'default_chart_width' => 800,
            'default_chart_height' => 400,
            'theme' => 'dark', // light or dark
            'timezone' => 'Asia/Shanghai',
            'chart_library' => 'chart.js', // chart.js or d3.js
        ], $config);
        
        // 设置时区
        date_default_timezone_set($this->config['timezone']);
    }
    
    /**
     * 生成系统性能监控图表数据
     * 
     * @param string $serverId 服务器ID
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param array $metrics 需要展示的指标
     * @param string $aggregation 聚合方式
     * @return array 图表数据
     */
    public function generateSystemMetricsChart($serverId, $startTime, $endTime, $metrics = ['cpu_usage', 'memory_usage', 'disk_usage'], $aggregation = 'hour') {
        // 获取原始数据
        $historyData = $this->dataStorage->getSystemMetricsHistory($serverId, $startTime, $endTime, $aggregation);
        
        // 处理图表数据
        $labels = [];
        $datasets = [];
        
        // 准备数据集
        foreach ($metrics as $metric) {
            $datasets[] = $this->prepareMetricDataset($metric, $this->getMetricConfig($metric));
        }
        
        // 填充数据
        foreach ($historyData as $record) {
            $labels[] = $record['time'];
            
            foreach ($metrics as $index => $metric) {
                $dataField = $this->getFieldNameForMetric($metric);
                if (isset($record[$dataField])) {
                    $datasets[$index]['data'][] = floatval($record[$dataField]);
                } else {
                    $datasets[$index]['data'][] = null;
                }
            }
        }
        
        // 生成图表配置
        $chartConfig = [
            'type' => 'line',
            'data' => [
                'labels' => $labels,
                'datasets' => $datasets,
            ],
            'options' => $this->getDefaultChartOptions([
                'title' => [
                    'display' => true,
                    'text' => "服务器 {$serverId} 性能监控",
                    'fontSize' => 16,
                ],
                'scales' => [
                    'y' => [
                        'beginAtZero' => true,
                        'max' => 100,
                        'title' => [
                            'display' => true,
                            'text' => '使用率 (%)',
                        ],
                    ],
                ],
            ]),
        ];
        
        return $chartConfig;
    }
    
    /**
     * 生成数据库性能监控图表数据
     * 
     * @param string $dbInstance 数据库实例
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param array $metrics 需要展示的指标
     * @param string $aggregation 聚合方式
     * @return array 图表数据
     */
    public function generateDatabaseMetricsChart($dbInstance, $startTime, $endTime, $metrics = ['connections', 'active_queries', 'response_time'], $aggregation = 'hour') {
        // 获取原始数据
        $historyData = $this->dataStorage->getDatabaseMetricsHistory($dbInstance, $startTime, $endTime, $aggregation);
        
        // 处理图表数据
        $labels = [];
        $datasets = [];
        
        // 准备数据集
        foreach ($metrics as $metric) {
            $datasets[] = $this->prepareMetricDataset($metric, $this->getMetricConfig($metric));
        }
        
        // 填充数据
        foreach ($historyData as $record) {
            $labels[] = $record['time'];
            
            foreach ($metrics as $index => $metric) {
                $dataField = $this->getFieldNameForMetric($metric);
                if (isset($record[$dataField])) {
                    $datasets[$index]['data'][] = floatval($record[$dataField]);
                } else {
                    $datasets[$index]['data'][] = null;
                }
            }
        }
        
        // 生成图表配置
        $chartConfig = [
            'type' => 'line',
            'data' => [
                'labels' => $labels,
                'datasets' => $datasets,
            ],
            'options' => $this->getDefaultChartOptions([
                'title' => [
                    'display' => true,
                    'text' => "数据库 {$dbInstance} 性能监控",
                    'fontSize' => 16,
                ],
            ]),
        ];
        
        return $chartConfig;
    }
    
    /**
     * 生成应用性能监控图表数据
     * 
     * @param string $endpoint 端点
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param array $metrics 需要展示的指标
     * @param string $aggregation 聚合方式
     * @return array 图表数据
     */
    public function generateApplicationMetricsChart($endpoint, $startTime, $endTime, $metrics = ['response_time', 'requests', 'errors'], $aggregation = 'hour') {
        // 获取原始数据
        $historyData = $this->dataStorage->getApplicationMetricsHistory($endpoint, $startTime, $endTime, $aggregation);
        
        // 处理图表数据
        $labels = [];
        $datasets = [];
        
        // 准备数据集
        foreach ($metrics as $metric) {
            $datasets[] = $this->prepareMetricDataset($metric, $this->getMetricConfig($metric));
        }
        
        // 填充数据
        foreach ($historyData as $record) {
            $labels[] = $record['time'];
            
            foreach ($metrics as $index => $metric) {
                $dataField = $this->getFieldNameForMetric($metric);
                if (isset($record[$dataField])) {
                    $datasets[$index]['data'][] = floatval($record[$dataField]);
                } else {
                    $datasets[$index]['data'][] = null;
                }
            }
        }
        
        // 生成图表配置
        $chartConfig = [
            'type' => 'line',
            'data' => [
                'labels' => $labels,
                'datasets' => $datasets,
            ],
            'options' => $this->getDefaultChartOptions([
                'title' => [
                    'display' => true,
                    'text' => "API {$endpoint} 性能监控",
                    'fontSize' => 16,
                ],
            ]),
        ];
        
        return $chartConfig;
    }
    
    /**
     * 生成HTTP状态码分布饼图
     * 
     * @param string $endpoint 端点
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 图表数据
     */
    public function generateStatusCodesPieChart($endpoint, $startTime, $endTime) {
        // 获取原始数据
        $historyData = $this->dataStorage->getApplicationMetricsHistory($endpoint, $startTime, $endTime, 'day');
        
        // 汇总状态码数据
        $statusCodes = ['2xx' => 0, '3xx' => 0, '4xx' => 0, '5xx' => 0];
        
        foreach ($historyData as $record) {
            $statusCodes['2xx'] += isset($record['total_2xx']) ? $record['total_2xx'] : 0;
            $statusCodes['3xx'] += isset($record['total_3xx']) ? $record['total_3xx'] : 0;
            $statusCodes['4xx'] += isset($record['total_4xx']) ? $record['total_4xx'] : 0;
            $statusCodes['5xx'] += isset($record['total_5xx']) ? $record['total_5xx'] : 0;
        }
        
        // 准备图表数据
        $labels = array_keys($statusCodes);
        $data = array_values($statusCodes);
        $colors = ['#28a745', '#007bff', '#ffc107', '#dc3545'];
        
        // 生成图表配置
        $chartConfig = [
            'type' => 'pie',
            'data' => [
                'labels' => $labels,
                'datasets' => [
                    [
                        'data' => $data,
                        'backgroundColor' => $colors,
                        'borderColor' => $this->getThemeBorderColor(),
                        'borderWidth' => 1,
                    ],
                ],
            ],
            'options' => $this->getDefaultChartOptions([
                'title' => [
                    'display' => true,
                    'text' => "API {$endpoint} HTTP 状态码分布",
                    'fontSize' => 16,
                ],
                'plugins' => [
                    'datalabels' => [
                        'display' => true,
                        'formatter' => 'function(value, context) {\n' .
                                       '  const sum = context.dataset.data.reduce((acc, val) => acc + val, 0);\n' .
                                       '  const percentage = Math.round((value / sum) * 100) + \'%\';\n' .
                                       '  return value > 0 ? percentage : \'\';\n' .
                                       '}',
                    ],
                ],
            ]),
        ];
        
        return $chartConfig;
    }
    
    /**
     * 生成告警统计柱状图
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 图表数据
     */
    public function generateAlertStatisticsChart($startTime, $endTime) {
        // 获取告警历史
        $alerts = $this->dataStorage->getAlertsHistory($startTime, $endTime);
        
        // 按时间和级别统计
        $stats = [];
        foreach ($alerts as $alert) {
            $date = date('Y-m-d', strtotime($alert['timestamp']));
            if (!isset($stats[$date])) {
                $stats[$date] = ['info' => 0, 'warning' => 0, 'critical' => 0];
            }
            $stats[$date][$alert['level']]++;
        }
        
        // 排序日期
        ksort($stats);
        
        // 准备图表数据
        $labels = array_keys($stats);
        $datasets = [
            [
                'label' => '信息',
                'backgroundColor' => '#007bff',
                'data' => array_map(function($day) { return $day['info']; }, $stats),
            ],
            [
                'label' => '警告',
                'backgroundColor' => '#ffc107',
                'data' => array_map(function($day) { return $day['warning']; }, $stats),
            ],
            [
                'label' => '严重',
                'backgroundColor' => '#dc3545',
                'data' => array_map(function($day) { return $day['critical']; }, $stats),
            ],
        ];
        
        // 生成图表配置
        $chartConfig = [
            'type' => 'bar',
            'data' => [
                'labels' => $labels,
                'datasets' => $datasets,
            ],
            'options' => $this->getDefaultChartOptions([
                'title' => [
                    'display' => true,
                    'text' => "告警统计图表",
                    'fontSize' => 16,
                ],
                'scales' => [
                    'x' => [
                        'stacked' => true,
                    ],
                    'y' => [
                        'stacked' => true,
                        'beginAtZero' => true,
                        'title' => [
                            'display' => true,
                            'text' => '告警数量',
                        ],
                    ],
                ],
            ]),
        ];
        
        return $chartConfig;
    }
    
    /**
     * 生成系统资源使用热力图
     * 
     * @param string $serverId 服务器ID
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param string $metric 指标类型
     * @return array 热力图数据
     */
    public function generateResourceUsageHeatmap($serverId, $startTime, $endTime, $metric = 'cpu_usage') {
        // 获取原始数据
        $historyData = $this->dataStorage->getSystemMetricsHistory($serverId, $startTime, $endTime, 'hour');
        
        // 处理热力图数据
        $heatmapData = [];
        $dates = [];
        $hours = [];
        
        // 提取日期和小时
        foreach ($historyData as $record) {
            $date = substr($record['time'], 0, 10);
            $hour = intval(substr($record['time'], 11, 2));
            
            if (!in_array($date, $dates)) {
                $dates[] = $date;
            }
            if (!in_array($hour, $hours)) {
                $hours[] = $hour;
            }
            
            $dataField = $this->getFieldNameForMetric($metric);
            $value = isset($record[$dataField]) ? $record[$dataField] : 0;
            
            $heatmapData["{$date}_{$hour}"] = floatval($value);
        }
        
        // 排序
        sort($dates);
        sort($hours);
        
        // 生成热力图配置
        $heatmap = [
            'metric' => $metric,
            'metric_name' => $this->getMetricConfig($metric)['label'],
            'dates' => $dates,
            'hours' => $hours,
            'data' => $heatmapData,
            'min_value' => min(array_values($heatmapData)),
            'max_value' => max(array_values($heatmapData)),
        ];
        
        return $heatmap;
    }
    
    /**
     * 生成系统健康状态仪表盘
     * 
     * @param string $serverId 服务器ID
     * @return array 仪表盘数据
     */
    public function generateSystemHealthDashboard($serverId) {
        // 设置时间范围（最近24小时）
        $endTime = date('Y-m-d H:i:s');
        $startTime = date('Y-m-d H:i:s', strtotime('-24 hours'));
        
        // 获取系统指标
        $systemMetrics = $this->dataStorage->getSystemMetricsHistory($serverId, $startTime, $endTime, 'hour');
        
        // 获取最新指标
        $latestMetrics = end($systemMetrics);
        
        // 获取活跃告警
        $activeAlerts = $this->dataStorage->getActiveAlerts();
        $serverAlerts = array_filter($activeAlerts, function($alert) use ($serverId) {
            return strpos($alert['source'], $serverId) !== false;
        });
        
        // 准备仪表盘数据
        $dashboard = [
            'server_id' => $serverId,
            'last_updated' => $latestMetrics['time'] ?? date('Y-m-d H:i:s'),
            'health_score' => $this->calculateHealthScore($latestMetrics, $serverAlerts),
            'metrics' => [
                'cpu_usage' => [
                    'value' => isset($latestMetrics['avg_cpu']) ? $latestMetrics['avg_cpu'] : 0,
                    'status' => $this->getMetricStatus('cpu_usage', isset($latestMetrics['avg_cpu']) ? $latestMetrics['avg_cpu'] : 0),
                    'history' => array_map(function($item) { return $item['avg_cpu'] ?? 0; }, $systemMetrics),
                ],
                'memory_usage' => [
                    'value' => isset($latestMetrics['avg_memory']) ? $latestMetrics['avg_memory'] : 0,
                    'status' => $this->getMetricStatus('memory_usage', isset($latestMetrics['avg_memory']) ? $latestMetrics['avg_memory'] : 0),
                    'history' => array_map(function($item) { return $item['avg_memory'] ?? 0; }, $systemMetrics),
                ],
                'disk_usage' => [
                    'value' => isset($latestMetrics['avg_disk']) ? $latestMetrics['avg_disk'] : 0,
                    'status' => $this->getMetricStatus('disk_usage', isset($latestMetrics['avg_disk']) ? $latestMetrics['avg_disk'] : 0),
                    'history' => array_map(function($item) { return $item['avg_disk'] ?? 0; }, $systemMetrics),
                ],
            ],
            'alerts' => [
                'active' => count($serverAlerts),
                'critical' => count(array_filter($serverAlerts, function($alert) { return $alert['level'] === 'critical'; })),
                'warning' => count(array_filter($serverAlerts, function($alert) { return $alert['level'] === 'warning'; })),
            ],
            'network' => [
                'in' => isset($latestMetrics['total_network_in']) ? $latestMetrics['total_network_in'] : 0,
                'out' => isset($latestMetrics['total_network_out']) ? $latestMetrics['total_network_out'] : 0,
            ],
            'labels' => array_map(function($item) { return $item['time']; }, $systemMetrics),
        ];
        
        return $dashboard;
    }
    
    /**
     * 生成API性能排名表
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param int $limit 限制数量
     * @return array 排名数据
     */
    public function generateApiPerformanceRanking($startTime, $endTime, $limit = 10) {
        // 这里需要一个专门的方法来获取所有端点性能，暂时使用示例数据
        // 实际项目中应该在dataStorage中添加一个方法来获取所有端点的性能数据
        $apiRanking = [
            [
                'endpoint' => '/api/products',
                'avg_response_time' => 0.12,
                'total_requests' => 12500,
                'error_rate' => 0.2,
                'status' => 'good',
            ],
            [
                'endpoint' => '/api/orders',
                'avg_response_time' => 0.35,
                'total_requests' => 8700,
                'error_rate' => 0.5,
                'status' => 'good',
            ],
            [
                'endpoint' => '/api/users/profile',
                'avg_response_time' => 0.08,
                'total_requests' => 24300,
                'error_rate' => 0.1,
                'status' => 'excellent',
            ],
            [
                'endpoint' => '/api/payments',
                'avg_response_time' => 0.89,
                'total_requests' => 5600,
                'error_rate' => 1.2,
                'status' => 'warning',
            ],
            [
                'endpoint' => '/api/search',
                'avg_response_time' => 0.56,
                'total_requests' => 32100,
                'error_rate' => 0.3,
                'status' => 'good',
            ],
        ];
        
        // 排序（按响应时间升序）
        usort($apiRanking, function($a, $b) {
            return $a['avg_response_time'] <=> $b['avg_response_time'];
        });
        
        // 限制数量
        $apiRanking = array_slice($apiRanking, 0, $limit);
        
        return $apiRanking;
    }
    
    /**
     * 准备指标数据集
     * 
     * @param string $metric 指标名称
     * @param array $config 指标配置
     * @return array 数据集配置
     */
    private function prepareMetricDataset($metric, $config) {
        return [
            'label' => $config['label'],
            'borderColor' => $config['color'],
            'backgroundColor' => $this->addOpacityToColor($config['color'], 0.1),
            'borderWidth' => 2,
            'fill' => true,
            'tension' => 0.1,
            'data' => [],
        ];
    }
    
    /**
     * 获取指标配置
     * 
     * @param string $metric 指标名称
     * @return array 指标配置
     */
    private function getMetricConfig($metric) {
        $configs = [
            'cpu_usage' => [
                'label' => 'CPU使用率',
                'color' => '#dc3545',
                'unit' => '%',
                'thresholds' => [
                    'warning' => 70,
                    'critical' => 90,
                ],
            ],
            'memory_usage' => [
                'label' => '内存使用率',
                'color' => '#ffc107',
                'unit' => '%',
                'thresholds' => [
                    'warning' => 80,
                    'critical' => 95,
                ],
            ],
            'disk_usage' => [
                'label' => '磁盘使用率',
                'color' => '#28a745',
                'unit' => '%',
                'thresholds' => [
                    'warning' => 85,
                    'critical' => 95,
                ],
            ],
            'connections' => [
                'label' => '数据库连接数',
                'color' => '#17a2b8',
                'unit' => '',
                'thresholds' => [
                    'warning' => 500,
                    'critical' => 800,
                ],
            ],
            'active_queries' => [
                'label' => '活跃查询数',
                'color' => '#6610f2',
                'unit' => '',
                'thresholds' => [
                    'warning' => 100,
                    'critical' => 200,
                ],
            ],
            'response_time' => [
                'label' => '响应时间',
                'color' => '#fd7e14',
                'unit' => 'ms',
                'thresholds' => [
                    'warning' => 500,
                    'critical' => 1000,
                ],
            ],
            'requests' => [
                'label' => '请求数',
                'color' => '#20c997',
                'unit' => '',
                'thresholds' => [],
            ],
            'errors' => [
                'label' => '错误数',
                'color' => '#dc3545',
                'unit' => '',
                'thresholds' => [
                    'warning' => 10,
                    'critical' => 50,
                ],
            ],
        ];
        
        return isset($configs[$metric]) ? $configs[$metric] : ['label' => $metric, 'color' => '#000000', 'unit' => ''];
    }
    
    /**
     * 获取指标对应的字段名
     * 
     * @param string $metric 指标名称
     * @return string 字段名
     */
    private function getFieldNameForMetric($metric) {
        $fieldMap = [
            'cpu_usage' => 'avg_cpu',
            'memory_usage' => 'avg_memory',
            'disk_usage' => 'avg_disk',
            'connections' => 'avg_connections',
            'active_queries' => 'avg_active_queries',
            'response_time' => 'avg_response_time',
            'requests' => 'total_requests',
            'errors' => 'total_errors',
        ];
        
        return isset($fieldMap[$metric]) ? $fieldMap[$metric] : $metric;
    }
    
    /**
     * 获取默认图表配置
     * 
     * @param array $customOptions 自定义配置
     * @return array 图表配置
     */
    private function getDefaultChartOptions($customOptions = []) {
        $themeTextColor = $this->config['theme'] === 'dark' ? '#ffffff' : '#000000';
        $themeGridColor = $this->config['theme'] === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
        
        $defaultOptions = [
            'responsive' => true,
            'maintainAspectRatio' => false,
            'plugins' => [
                'legend' => [
                    'display' => true,
                    'position' => 'top',
                    'labels' => [
                        'color' => $themeTextColor,
                        'font' => [
                            'size' => 12,
                        ],
                    ],
                ],
                'tooltip' => [
                    'mode' => 'index',
                    'intersect' => false,
                ],
            ],
            'scales' => [
                'x' => [
                    'grid' => [
                        'color' => $themeGridColor,
                    ],
                    'ticks' => [
                        'color' => $themeTextColor,
                    ],
                ],
                'y' => [
                    'grid' => [
                        'color' => $themeGridColor,
                    ],
                    'ticks' => [
                        'color' => $themeTextColor,
                    ],
                ],
            ],
            'interaction' => [
                'mode' => 'nearest',
                'axis' => 'x',
                'intersect' => false,
            ],
        ];
        
        return $this->mergeDeep($defaultOptions, $customOptions);
    }
    
    /**
     * 获取指标状态
     * 
     * @param string $metric 指标名称
     * @param float $value 指标值
     * @return string 状态 (good, warning, critical)
     */
    private function getMetricStatus($metric, $value) {
        $config = $this->getMetricConfig($metric);
        
        if (isset($config['thresholds'])) {
            if (isset($config['thresholds']['critical']) && $value >= $config['thresholds']['critical']) {
                return 'critical';
            } elseif (isset($config['thresholds']['warning']) && $value >= $config['thresholds']['warning']) {
                return 'warning';
            }
        }
        
        return 'good';
    }
    
    /**
     * 计算健康分数
     * 
     * @param array $metrics 指标数据
     * @param array $alerts 告警数据
     * @return int 健康分数 (0-100)
     */
    private function calculateHealthScore($metrics, $alerts) {
        $score = 100;
        
        // 检查关键指标
        if (isset($metrics['avg_cpu']) && $metrics['avg_cpu'] > 90) {
            $score -= 30;
        } elseif (isset($metrics['avg_cpu']) && $metrics['avg_cpu'] > 70) {
            $score -= 10;
        }
        
        if (isset($metrics['avg_memory']) && $metrics['avg_memory'] > 95) {
            $score -= 30;
        } elseif (isset($metrics['avg_memory']) && $metrics['avg_memory'] > 80) {
            $score -= 10;
        }
        
        if (isset($metrics['avg_disk']) && $metrics['avg_disk'] > 95) {
            $score -= 30;
        } elseif (isset($metrics['avg_disk']) && $metrics['avg_disk'] > 85) {
            $score -= 10;
        }
        
        // 检查告警
        $criticalAlerts = array_filter($alerts, function($alert) { return $alert['level'] === 'critical'; });
        $warningAlerts = array_filter($alerts, function($alert) { return $alert['level'] === 'warning'; });
        
        $score -= count($criticalAlerts) * 25;
        $score -= count($warningAlerts) * 5;
        
        // 确保分数在0-100范围内
        return max(0, min(100, $score));
    }
    
    /**
     * 合并深度数组
     * 
     * @param array $array1 第一个数组
     * @param array $array2 第二个数组
     * @return array 合并后的数组
     */
    private function mergeDeep(array $array1, array $array2) {
        foreach ($array2 as $key => $value) {
            if (is_array($value) && isset($array1[$key]) && is_array($array1[$key])) {
                $array1[$key] = $this->mergeDeep($array1[$key], $value);
            } else {
                $array1[$key] = $value;
            }
        }
        return $array1;
    }
    
    /**
     * 为颜色添加透明度
     * 
     * @param string $color 颜色值
     * @param float $opacity 透明度
     * @return string 带透明度的颜色
     */
    private function addOpacityToColor($color, $opacity) {
        if (strpos($color, '#') === 0) {
            // 处理十六进制颜色
            $color = substr($color, 1);
            if (strlen($color) === 3) {
                $color = $color[0] . $color[0] . $color[1] . $color[1] . $color[2] . $color[2];
            }
            $r = hexdec($color[0] . $color[1]);
            $g = hexdec($color[2] . $color[3]);
            $b = hexdec($color[4] . $color[5]);
            return "rgba($r, $g, $b, $opacity)";
        }
        return $color;
    }
    
    /**
     * 获取主题边框颜色
     * 
     * @return string 边框颜色
     */
    private function getThemeBorderColor() {
        return $this->config['theme'] === 'dark' ? '#444444' : '#dddddd';
    }
    
    /**
     * 为给定时间段获取开始时间
     * 
     * @param string $period 时间段
     * @param string $endTime 结束时间
     * @return string 开始时间
     */
    private function getStartTimeForPeriod($period, $endTime) {
        switch ($period) {
            case 'day':
                return date('Y-m-d H:i:s', strtotime('-24 hours', strtotime($endTime)));
            case 'week':
                return date('Y-m-d H:i:s', strtotime('-7 days', strtotime($endTime)));
            case 'month':
                return date('Y-m-d H:i:s', strtotime('-30 days', strtotime($endTime)));
            default:
                return date('Y-m-d H:i:s', strtotime('-24 hours', strtotime($endTime)));
        }
    }
}

// 使用示例
/*
$db = new mysqli('localhost', 'username', 'password', 'monitoring_db');
$redis = new Redis();
$redis->connect('localhost', 6379);

$dataStorage = new MonitoringDataStorage($db, $redis);
$visualization = new MonitoringVisualization($dataStorage, ['theme' => 'dark']);

// 生成CPU和内存使用图表
$chartConfig = $visualization->generateSystemMetricsChart(
    'web-server-01',
    date('Y-m-d H:i:s', strtotime('-7 days')),
    date('Y-m-d H:i:s'),
    ['cpu_usage', 'memory_usage']
);

// 将图表配置转为JSON供前端使用
$chartJson = json_encode($chartConfig);

// 生成仪表盘数据
$dashboard = $visualization->generateSystemHealthDashboard('web-server-01');
*/