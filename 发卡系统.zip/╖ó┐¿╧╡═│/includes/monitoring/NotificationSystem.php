<?php
/**
 * 通知系统
 * 负责通过不同渠道（邮件、短信等）发送通知
 */

class NotificationSystem {
    /**
     * 支持的通知渠道
     */
    const CHANNEL_EMAIL = 'email';
    const CHANNEL_SMS = 'sms';
    const CHANNEL_WEBHOOK = 'webhook';
    const CHANNEL_WECHAT = 'wechat';
    
    /**
     * 支持的严重级别
     */
    const SEVERITY_CRITICAL = 'critical';
    const SEVERITY_WARNING = 'warning';
    const SEVERITY_INFO = 'info';
    
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        // 全局开关
        'enabled' => true,
        
        // 邮件配置
        'email' => [
            'enabled' => true,
            'from' => 'alerts@example.com',
            'reply_to' => 'alerts@example.com',
            'smtp' => [
                'host' => 'smtp.example.com',
                'port' => 587,
                'username' => 'alerts@example.com',
                'password' => 'your_smtp_password',
                'encryption' => 'tls', // ssl, tls, 或空字符串
                'auth' => true,
            ],
            'templates' => [
                'critical' => [
                    'subject' => '[紧急] {{title}}',
                    'body_template' => 'mail/critical.html',
                ],
                'warning' => [
                    'subject' => '[警告] {{title}}',
                    'body_template' => 'mail/warning.html',
                ],
                'info' => [
                    'subject' => '[信息] {{title}}',
                    'body_template' => 'mail/info.html',
                ],
            ],
            'recipients' => [
                'critical' => ['admin@example.com'],
                'warning' => ['admin@example.com', 'tech@example.com'],
                'info' => ['tech@example.com'],
            ],
        ],
        
        // 短信配置
        'sms' => [
            'enabled' => true,
            'provider' => 'default', // 默认、阿里云、腾讯云等
            'api_url' => 'https://api.sms.example.com/send',
            'api_key' => 'your_api_key',
            'api_secret' => 'your_api_secret',
            'signature' => '【发卡系统】',
            'templates' => [
                'critical' => 'SMS_123456', // 短信模板ID
                'warning' => 'SMS_123457',
            ],
            'recipients' => [
                'critical' => ['13800138000'],
                'warning' => ['13800138000', '13900139000'],
                // 通常不发送info级别的短信
            ],
            // 短信内容长度限制
            'max_length' => 160,
            // 阿里云特定配置
            'alicloud' => [
                'region_id' => 'cn-hangzhou',
                'access_key_id' => '',
                'access_key_secret' => '',
            ],
            // 腾讯云特定配置
            'tencent' => [
                'app_id' => '',
                'secret_id' => '',
                'secret_key' => '',
                'region' => 'ap-guangzhou',
            ],
        ],
        
        // Webhook配置
        'webhook' => [
            'enabled' => false,
            'url' => 'https://your-webhook-url.com',
            'method' => 'POST',
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Notification-Token' => 'your_token',
            ],
            // 哪些严重级别发送webhook
            'severities' => ['critical', 'warning'],
        ],
        
        // 微信配置
        'wechat' => [
            'enabled' => false,
            'type' => 'work', // work(企业微信), mini(小程序), official(公众号)
            // 企业微信配置
            'work' => [
                'corpid' => '',
                'corpsecret' => '',
                'agentid' => '',
                // 接收者，多个用|分隔
                'touser' => '@all',
            ],
            // 公众号配置
            'official' => [
                'appid' => '',
                'secret' => '',
                'template_id' => '',
            ],
            // 哪些严重级别发送微信消息
            'severities' => ['critical', 'warning'],
        ],
        
        // 通知策略配置
        'strategies' => [
            // 按严重级别选择渠道
            'severity_channels' => [
                'critical' => ['email', 'sms', 'webhook', 'wechat'],
                'warning' => ['email', 'webhook', 'wechat'],
                'info' => ['email'],
            ],
            // 工作时间配置（小时，24小时制）
            'working_hours' => [
                'start' => 9, // 上午9点
                'end' => 18,  // 下午6点
                'weekdays' => [1, 2, 3, 4, 5], // 周一到周五
            ],
            // 在非工作时间，只发送critical级别
            'non_working_hours_only_critical' => true,
        ],
        
        // 重试配置
        'retry' => [
            'enabled' => true,
            'max_attempts' => 3,
            'interval_seconds' => 30,
        ],
        
        // 通知速率限制（每分钟）
        'rate_limits' => [
            'email' => 10,  // 每分钟最多10封邮件
            'sms' => 5,     // 每分钟最多5条短信
            'webhook' => 20,
            'wechat' => 10,
        ],
        
        // 通知历史配置
        'history' => [
            'enabled' => true,
            'retention_days' => 30,
        ],
    ];
    
    /**
     * 数据库连接
     * @var PDO
     */
    protected $db = null;
    
    /**
     * 速率限制计数器
     * @var array
     */
    protected $rateLimitCounters = [];
    
    /**
     * 速率限制重置时间
     * @var array
     */
    protected $rateLimitResetTimes = [];
    
    /**
     * 单例实例
     * @var NotificationSystem
     */
    protected static $instance = null;
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化数据库连接
        $this->initializeDatabase();
        
        // 初始化表结构
        $this->initializeTables();
        
        // 初始化速率限制计数器
        $this->initializeRateLimits();
    }
    
    /**
     * 获取单例实例
     * @param array $config 配置信息
     * @return NotificationSystem
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化数据库连接
     */
    protected function initializeDatabase() {
        try {
            // 尝试使用全局数据库连接
            if (defined('DB_HOST') && defined('DB_USER') && defined('DB_PASS') && defined('DB_NAME')) {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ];
                $this->db = new PDO($dsn, DB_USER, DB_PASS, $options);
            }
        } catch (Exception $e) {
            error_log('通知系统数据库连接失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 初始化数据库表
     */
    protected function initializeTables() {
        if ($this->db === null || !$this->config['history']['enabled']) {
            return;
        }
        
        try {
            // 创建通知历史表
            $this->db->exec("CREATE TABLE IF NOT EXISTS notification_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                notification_id VARCHAR(50) NOT NULL,
                channel VARCHAR(20) NOT NULL,
                severity VARCHAR(20) NOT NULL,
                title VARCHAR(255) NOT NULL,
                recipient TEXT NOT NULL,
                status ENUM('pending', 'sending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
                error_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                sent_at TIMESTAMP NULL,
                INDEX idx_channel (channel),
                INDEX idx_severity (severity),
                INDEX idx_status (status),
                INDEX idx_created_at (created_at)
            )");
            
            // 创建通知模板表
            $this->db->exec("CREATE TABLE IF NOT EXISTS notification_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                type VARCHAR(50) NOT NULL,
                channel VARCHAR(20) NOT NULL,
                severity VARCHAR(20) NOT NULL,
                subject VARCHAR(255),
                content TEXT,
                variables TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY idx_type_channel_severity (type, channel, severity)
            )");
            
            // 创建通知接收者表
            $this->db->exec("CREATE TABLE IF NOT EXISTS notification_recipients (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(255),
                phone VARCHAR(20),
                wechat_id VARCHAR(100),
                enabled BOOLEAN DEFAULT TRUE,
                severity_levels VARCHAR(50), -- critical,warning,info
                channels VARCHAR(50), -- email,sms,wechat
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_enabled (enabled)
            )");
        } catch (Exception $e) {
            error_log('通知系统表初始化失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 初始化速率限制计数器
     */
    protected function initializeRateLimits() {
        $channels = [self::CHANNEL_EMAIL, self::CHANNEL_SMS, self::CHANNEL_WEBHOOK, self::CHANNEL_WECHAT];
        
        foreach ($channels as $channel) {
            $this->rateLimitCounters[$channel] = 0;
            $this->rateLimitResetTimes[$channel] = time() + 60; // 60秒后重置
        }
    }
    
    /**
     * 发送通知
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    public function send(array $notification) {
        // 验证必要字段
        if (!isset($notification['title'], $notification['message'], $notification['severity'])) {
            return ['success' => false, 'error' => '缺少必要字段: title, message, severity'];
        }
        
        // 验证严重级别
        if (!in_array($notification['severity'], [self::SEVERITY_CRITICAL, self::SEVERITY_WARNING, self::SEVERITY_INFO])) {
            return ['success' => false, 'error' => '无效的严重级别'];
        }
        
        // 检查是否在非工作时间且只允许critical级别
        if (!$this->isWorkingHours() && $this->config['strategies']['non_working_hours_only_critical']) {
            if ($notification['severity'] !== self::SEVERITY_CRITICAL) {
                return ['success' => false, 'error' => '非工作时间只允许critical级别的通知'];
            }
        }
        
        // 生成通知ID
        $notification['id'] = isset($notification['id']) ? $notification['id'] : $this->generateNotificationId();
        
        // 确定要使用的渠道
        $channels = $this->getChannelsForSeverity($notification['severity']);
        
        // 发送结果
        $results = ['success' => true, 'channels' => []];
        
        // 发送到每个渠道
        foreach ($channels as $channel) {
            // 检查渠道是否启用
            if (!$this->isChannelEnabled($channel)) {
                continue;
            }
            
            // 检查速率限制
            if (!$this->checkRateLimit($channel)) {
                $results['channels'][$channel] = ['success' => false, 'error' => '超过速率限制'];
                $results['success'] = false;
                continue;
            }
            
            // 发送通知
            $result = $this->sendByChannel($channel, $notification);
            $results['channels'][$channel] = $result;
            
            if (!$result['success']) {
                $results['success'] = false;
            }
        }
        
        return $results;
    }
    
    /**
     * 生成通知ID
     * @return string 通知ID
     */
    protected function generateNotificationId() {
        return 'NOTIF-' . date('YmdHis') . '-' . substr(md5(uniqid()), 0, 6);
    }
    
    /**
     * 根据严重级别获取渠道列表
     * @param string $severity 严重级别
     * @return array 渠道列表
     */
    protected function getChannelsForSeverity($severity) {
        return $this->config['strategies']['severity_channels'][$severity] ?? [];
    }
    
    /**
     * 检查渠道是否启用
     * @param string $channel 渠道
     * @return bool 是否启用
     */
    protected function isChannelEnabled($channel) {
        return $this->config['enabled'] && $this->config[$channel]['enabled'] ?? false;
    }
    
    /**
     * 检查速率限制
     * @param string $channel 渠道
     * @return bool 是否可以发送
     */
    protected function checkRateLimit($channel) {
        // 检查是否需要重置计数器
        if (time() >= ($this->rateLimitResetTimes[$channel] ?? 0)) {
            $this->rateLimitCounters[$channel] = 0;
            $this->rateLimitResetTimes[$channel] = time() + 60; // 60秒后重置
        }
        
        // 检查是否超过限制
        $limit = $this->config['rate_limits'][$channel] ?? 100; // 默认限制较高
        
        if ($this->rateLimitCounters[$channel] >= $limit) {
            return false;
        }
        
        // 增加计数
        $this->rateLimitCounters[$channel]++;
        return true;
    }
    
    /**
     * 通过特定渠道发送通知
     * @param string $channel 渠道
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendByChannel($channel, array $notification) {
        try {
            // 记录通知到历史
            $historyId = $this->logNotification($channel, $notification);
            
            switch ($channel) {
                case self::CHANNEL_EMAIL:
                    $result = $this->sendEmail($notification);
                    break;
                case self::CHANNEL_SMS:
                    $result = $this->sendSms($notification);
                    break;
                case self::CHANNEL_WEBHOOK:
                    $result = $this->sendWebhook($notification);
                    break;
                case self::CHANNEL_WECHAT:
                    $result = $this->sendWechat($notification);
                    break;
                default:
                    throw new Exception("未知的通知渠道: {$channel}");
            }
            
            // 更新历史记录状态
            if (isset($historyId)) {
                $this->updateNotificationHistory($historyId, $result['success'], $result['error'] ?? null);
            }
            
            return $result;
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 发送邮件
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendEmail(array $notification) {
        // 获取收件人
        $recipients = $this->getEmailRecipients($notification['severity']);
        if (empty($recipients)) {
            return ['success' => false, 'error' => '未配置邮件收件人'];
        }
        
        // 生成主题和内容
        $subject = $this->renderTemplate($this->getEmailSubjectTemplate($notification['severity']), $notification);
        $body = $this->renderEmailBody($notification);
        
        // 发送给每个收件人
        $results = [];
        foreach ($recipients as $recipient) {
            // 使用SMTP发送或原生mail函数
            if ($this->config['email']['smtp']['auth']) {
                $result = $this->sendEmailWithSmtp($recipient, $subject, $body, $notification);
            } else {
                $result = $this->sendEmailWithNative($recipient, $subject, $body, $notification);
            }
            $results[$recipient] = $result;
        }
        
        // 检查是否全部成功
        $allSuccess = true;
        foreach ($results as $result) {
            if (!$result['success']) {
                $allSuccess = false;
                break;
            }
        }
        
        return [
            'success' => $allSuccess,
            'recipients' => $recipients,
            'results' => $results,
        ];
    }
    
    /**
     * 获取邮件收件人
     * @param string $severity 严重级别
     * @return array 收件人列表
     */
    protected function getEmailRecipients($severity) {
        // 从配置获取收件人
        $recipients = $this->config['email']['recipients'][$severity] ?? [];
        
        // 如果启用了数据库，可以从数据库获取
        if ($this->db !== null) {
            try {
                $stmt = $this->db->prepare(
                    "SELECT email FROM notification_recipients 
                     WHERE enabled = true 
                     AND (severity_levels LIKE ? OR severity_levels = 'all') 
                     AND (channels LIKE '%email%' OR channels = 'all')"
                );
                $stmt->execute(["%{$severity}%"]);
                $dbRecipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                // 合并并去重
                $recipients = array_unique(array_merge($recipients, $dbRecipients));
            } catch (Exception $e) {
                error_log('从数据库获取邮件收件人失败: ' . $e->getMessage());
            }
        }
        
        return array_filter($recipients);
    }
    
    /**
     * 获取邮件主题模板
     * @param string $severity 严重级别
     * @return string 主题模板
     */
    protected function getEmailSubjectTemplate($severity) {
        return $this->config['email']['templates'][$severity]['subject'] ?? '[通知] {{title}}';
    }
    
    /**
     * 渲染邮件正文
     * @param array $notification 通知信息
     * @return string 邮件正文
     */
    protected function renderEmailBody(array $notification) {
        $severity = $notification['severity'];
        $templatePath = $this->config['email']['templates'][$severity]['body_template'] ?? null;
        
        // 如果配置了模板文件，尝试读取
        if ($templatePath && file_exists($_SERVER['DOCUMENT_ROOT'] . '/templates/' . $templatePath)) {
            $template = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/templates/' . $templatePath);
        } else {
            // 使用默认模板
            $template = $this->getDefaultEmailTemplate($severity);
        }
        
        // 渲染模板
        return $this->renderTemplate($template, $notification);
    }
    
    /**
     * 获取默认邮件模板
     * @param string $severity 严重级别
     * @return string 默认模板
     */
    protected function getDefaultEmailTemplate($severity) {
        $color = '3498db'; // 默认蓝色
        $levelText = '信息';
        
        switch ($severity) {
            case self::SEVERITY_CRITICAL:
                $color = 'e74c3c'; // 红色
                $levelText = '紧急';
                break;
            case self::SEVERITY_WARNING:
                $color = 'f39c12'; // 橙色
                $levelText = '警告';
                break;
        }
        
        return "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>{{title}}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { padding: 10px 0; border-bottom: 1px solid #eee; }
        .level-badge { display: inline-block; padding: 5px 10px; background-color: #{{color}}; color: white; border-radius: 3px; font-size: 12px; }
        .title { margin: 15px 0; font-size: 20px; font-weight: bold; }
        .content { padding: 15px; background-color: #f9f9f9; border-radius: 5px; }
        .footer { margin-top: 20px; padding-top: 10px; border-top: 1px solid #eee; font-size: 12px; color: #666; text-align: center; }
        .metadata { margin-top: 15px; padding: 10px; background-color: #f1f1f1; border-radius: 3px; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <span class='level-badge'>{{levelText}}</span>
        </div>
        <div class='title'>{{title}}</div>
        <div class='content'>
            {{message}}
        </div>
        {% if metadata %}
        <div class='metadata'>
            <strong>元数据:</strong>
            <pre>{{metadata}}</pre>
        </div>
        {% endif %}
        <div class='footer'>
            此邮件由系统自动发送，请勿回复。<br>
            时间: {{timestamp}}
        </div>
    </div>
</body>
</html>";
    }
    
    /**
     * 使用SMTP发送邮件
     * @param string $recipient 收件人
     * @param string $subject 主题
     * @param string $body 正文
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendEmailWithSmtp($recipient, $subject, $body, array $notification) {
        try {
            // 获取SMTP配置
            $smtp = $this->config['email']['smtp'];
            
            // 构建SMTP命令
            $socket = fsockopen(
                $smtp['host'], 
                $smtp['port'], 
                $errno, 
                $errstr, 
                30
            );
            
            if (!$socket) {
                throw new Exception("无法连接到SMTP服务器: {$errstr}");
            }
            
            // 处理SMTP响应
            $this->smtpSendCommand($socket, "EHLO {$smtp['host']}");
            
            // 开始TLS加密
            if ($smtp['encryption'] === 'tls') {
                $this->smtpSendCommand($socket, "STARTTLS");
                stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                $this->smtpSendCommand($socket, "EHLO {$smtp['host']}");
            }
            
            // 认证
            if ($smtp['auth']) {
                $this->smtpSendCommand($socket, "AUTH LOGIN");
                $this->smtpSendCommand($socket, base64_encode($smtp['username']));
                $this->smtpSendCommand($socket, base64_encode($smtp['password']));
            }
            
            // 设置发件人和收件人
            $this->smtpSendCommand($socket, "MAIL FROM: <{$this->config['email']['from']}>");
            $this->smtpSendCommand($socket, "RCPT TO: <{$recipient}>");
            $this->smtpSendCommand($socket, "DATA");
            
            // 构建邮件头和正文
            $headers = [
                "From: {$this->config['email']['from']}",
                "Reply-To: {$this->config['email']['reply_to']}",
                "To: {$recipient}",
                "Subject: {$subject}",
                "MIME-Version: 1.0",
                "Content-Type: text/html; charset=UTF-8",
                "Date: " . date('r'),
                "X-Mailer: NotificationSystem",
                "", // 空行分隔头部和正文
            ];
            
            // 发送头部和正文
            fwrite($socket, implode("\r\n", $headers));
            fwrite($socket, $body . "\r\n.");
            
            // 检查响应
            $response = $this->smtpReadResponse($socket);
            if (substr($response, 0, 3) !== '250') {
                throw new Exception("发送邮件失败: {$response}");
            }
            
            // 退出SMTP会话
            $this->smtpSendCommand($socket, "QUIT");
            fclose($socket);
            
            return ['success' => true];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 使用PHP原生mail函数发送邮件
     * @param string $recipient 收件人
     * @param string $subject 主题
     * @param string $body 正文
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendEmailWithNative($recipient, $subject, $body, array $notification) {
        try {
            // 构建头部
            $headers = [
                "From: {$this->config['email']['from']}",
                "Reply-To: {$this->config['email']['reply_to']}",
                "MIME-Version: 1.0",
                "Content-Type: text/html; charset=UTF-8",
                "X-Mailer: NotificationSystem",
            ];
            
            // 如果使用UTF-8，需要编码主题
            $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
            
            // 发送邮件
            $result = mail($recipient, $encodedSubject, $body, implode("\r\n", $headers));
            
            if ($result) {
                return ['success' => true];
            } else {
                return ['success' => false, 'error' => '邮件发送失败，检查PHP配置'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 发送SMTP命令
     * @param resource $socket 套接字资源
     * @param string $command 命令
     */
    protected function smtpSendCommand($socket, $command) {
        fwrite($socket, "{$command}\r\n");
        $this->smtpReadResponse($socket);
    }
    
    /**
     * 读取SMTP响应
     * @param resource $socket 套接字资源
     * @return string 响应内容
     * @throws Exception
     */
    protected function smtpReadResponse($socket) {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) == ' ') {
                break;
            }
        }
        return $response;
    }
    
    /**
     * 发送短信
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendSms(array $notification) {
        // 获取收件人
        $recipients = $this->getSmsRecipients($notification['severity']);
        if (empty($recipients)) {
            return ['success' => false, 'error' => '未配置短信收件人'];
        }
        
        // 生成短信内容
        $content = $this->generateSmsContent($notification);
        
        // 根据不同的提供商发送
        $provider = $this->config['sms']['provider'];
        
        // 发送给每个收件人
        $results = [];
        foreach ($recipients as $recipient) {
            switch ($provider) {
                case 'alicloud':
                    $result = $this->sendSmsWithAliyun($recipient, $content, $notification);
                    break;
                case 'tencent':
                    $result = $this->sendSmsWithTencent($recipient, $content, $notification);
                    break;
                default:
                    $result = $this->sendSmsWithApi($recipient, $content, $notification);
                    break;
            }
            $results[$recipient] = $result;
        }
        
        // 检查是否全部成功
        $allSuccess = true;
        foreach ($results as $result) {
            if (!$result['success']) {
                $allSuccess = false;
                break;
            }
        }
        
        return [
            'success' => $allSuccess,
            'recipients' => $recipients,
            'results' => $results,
        ];
    }
    
    /**
     * 获取短信收件人
     * @param string $severity 严重级别
     * @return array 收件人列表
     */
    protected function getSmsRecipients($severity) {
        // 从配置获取收件人
        $recipients = $this->config['sms']['recipients'][$severity] ?? [];
        
        // 如果启用了数据库，可以从数据库获取
        if ($this->db !== null) {
            try {
                $stmt = $this->db->prepare(
                    "SELECT phone FROM notification_recipients 
                     WHERE enabled = true 
                     AND (severity_levels LIKE ? OR severity_levels = 'all') 
                     AND (channels LIKE '%sms%' OR channels = 'all')"
                );
                $stmt->execute(["%{$severity}%"]);
                $dbRecipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                // 合并并去重
                $recipients = array_unique(array_merge($recipients, $dbRecipients));
            } catch (Exception $e) {
                error_log('从数据库获取短信收件人失败: ' . $e->getMessage());
            }
        }
        
        return array_filter($recipients);
    }
    
    /**
     * 生成短信内容
     * @param array $notification 通知信息
     * @return string 短信内容
     */
    protected function generateSmsContent(array $notification) {
        // 构建短信内容
        $content = $this->config['sms']['signature'] ?? '';
        
        // 添加严重级别
        $severityText = $notification['severity'] === self::SEVERITY_CRITICAL ? '[紧急]' : 
                        ($notification['severity'] === self::SEVERITY_WARNING ? '[警告]' : '[信息]');
        $content .= $severityText . ' ' . $notification['title'] . '\n';
        
        // 添加消息内容，截取长度
        $maxLength = $this->config['sms']['max_length'] - mb_strlen($content);
        $message = mb_substr($notification['message'], 0, $maxLength);
        $content .= $message;
        
        return $content;
    }
    
    /**
     * 通过API发送短信
     * @param string $recipient 收件人
     * @param string $content 内容
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendSmsWithApi($recipient, $content, array $notification) {
        try {
            // 准备API请求参数
            $params = [
                'api_key' => $this->config['sms']['api_key'],
                'api_secret' => $this->config['sms']['api_secret'],
                'phone' => $recipient,
                'content' => $content,
                'timestamp' => time(),
            ];
            
            // 创建签名
            ksort($params);
            $signString = implode('', $params);
            $params['sign'] = md5($signString);
            
            // 发送请求
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->config['sms']['api_url']);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            curl_close($ch);
            
            // 解析响应
            $result = json_decode($response, true);
            
            // 检查是否成功
            if ($httpCode !== 200 || !isset($result['code']) || $result['code'] !== 0) {
                throw new Exception("短信发送失败: " . ($result['message'] ?? "未知错误"));
            }
            
            return ['success' => true, 'response' => $result];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 使用阿里云发送短信
     * @param string $recipient 收件人
     * @param string $content 内容
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendSmsWithAliyun($recipient, $content, array $notification) {
        try {
            // 阿里云SMS API需要模板和参数，这里简化处理
            // 实际应用中应该使用阿里云SDK或按文档构造请求
            $apiUrl = "https://dysmsapi.aliyuncs.com";
            
            // 获取配置
            $config = $this->config['sms']['alicloud'];
            $accessKeyId = $config['access_key_id'];
            $accessKeySecret = $config['access_key_secret'];
            $regionId = $config['region_id'];
            
            // 准备公共参数
            $params = [
                'AccessKeyId' => $accessKeyId,
                'Action' => 'SendSms',
                'Format' => 'JSON',
                'PhoneNumbers' => $recipient,
                'RegionId' => $regionId,
                'SignName' => $this->config['sms']['signature'] ?? '',
                'TemplateCode' => $this->getSmsTemplateCode($notification['severity']),
                'Timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                'Version' => '2017-05-25',
                'SignatureMethod' => 'HMAC-SHA1',
                'SignatureNonce' => uniqid(),
                'SignatureVersion' => '1.0',
            ];
            
            // 准备模板参数
            $templateParams = [
                'title' => $notification['title'],
                'message' => $notification['message'],
                'severity' => $notification['severity'],
            ];
            $params['TemplateParam'] = json_encode($templateParams);
            
            // 生成签名
            ksort($params);
            $canonicalizedQueryString = '';
            foreach ($params as $key => $value) {
                $canonicalizedQueryString .= '&' . $this->percentEncode($key) . '=' . $this->percentEncode($value);
            }
            $canonicalizedQueryString = ltrim($canonicalizedQueryString, '&');
            
            $stringToSign = "GET&%2F&" . $this->percentEncode($canonicalizedQueryString);
            $signature = base64_encode(hash_hmac('sha1', $stringToSign, $accessKeySecret . '&', true));
            
            $params['Signature'] = $signature;
            
            // 发送请求
            $url = $apiUrl . '?' . http_build_query($params);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            curl_close($ch);
            
            // 解析响应
            $result = json_decode($response, true);
            
            // 检查是否成功
            if (!isset($result['Code']) || $result['Code'] !== 'OK') {
                throw new Exception("阿里云短信发送失败: " . ($result['Message'] ?? "未知错误"));
            }
            
            return ['success' => true, 'response' => $result];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 使用腾讯云发送短信
     * @param string $recipient 收件人
     * @param string $content 内容
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendSmsWithTencent($recipient, $content, array $notification) {
        try {
            // 腾讯云SMS API需要模板和参数，这里简化处理
            // 实际应用中应该使用腾讯云SDK或按文档构造请求
            $config = $this->config['sms']['tencent'];
            $appId = $config['app_id'];
            $secretId = $config['secret_id'];
            $secretKey = $config['secret_key'];
            $region = $config['region'];
            
            // 准备请求参数
            $params = [
                'Action' => 'SendSms',
                'PhoneNumberSet.0' => '+86' . $recipient, // 腾讯云需要带国家码
                'TemplateID' => $this->getSmsTemplateCode($notification['severity']),
                'SmsSdkAppid' => $appId,
                'Sign' => $this->config['sms']['signature'] ?? '',
                'Region' => $region,
                'Timestamp' => time(),
                'Nonce' => rand(10000, 99999),
                'SecretId' => $secretId,
            ];
            
            // 准备模板参数
            $templateParams = [
                'title' => $notification['title'],
                'message' => $notification['message'],
            ];
            $params['TemplateParamSet.0'] = json_encode($templateParams);
            
            // 生成签名
            ksort($params);
            $signStr = '';
            foreach ($params as $key => $value) {
                $signStr .= $key . '=' . $value . '&';
            }
            $signStr = substr($signStr, 0, -1);
            
            $signature = base64_encode(hash_hmac('sha1', $signStr, $secretKey, true));
            $params['Signature'] = $signature;
            
            // 发送请求
            $url = "https://sms.tencentcloudapi.com";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            curl_close($ch);
            
            // 解析响应
            $result = json_decode($response, true);
            
            // 检查是否成功
            if (!isset($result['Response']) || !isset($result['Response']['SendStatusSet'][0]) ||
                $result['Response']['SendStatusSet'][0]['Code'] !== 'Ok') {
                $errorMsg = $result['Response']['Error']['Message'] ?? "未知错误";
                throw new Exception("腾讯云短信发送失败: " . $errorMsg);
            }
            
            return ['success' => true, 'response' => $result];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 获取短信模板代码
     * @param string $severity 严重级别
     * @return string 模板代码
     */
    protected function getSmsTemplateCode($severity) {
        return $this->config['sms']['templates'][$severity] ?? $this->config['sms']['templates']['warning'] ?? '';
    }
    
    /**
     * URL编码（阿里云要求的方式）
     * @param string $str 字符串
     * @return string 编码后的字符串
     */
    protected function percentEncode($str) {
        $res = urlencode($str);
        $res = str_replace('+', '%20', $res);
        $res = str_replace('*', '%2A', $res);
        $res = str_replace('%7E', '~', $res);
        return $res;
    }
    
    /**
     * 发送Webhook
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendWebhook(array $notification) {
        try {
            // 准备Webhook配置
            $config = $this->config['webhook'];
            
            // 检查是否为支持的严重级别
            if (!in_array($notification['severity'], $config['severities'])) {
                return ['success' => false, 'error' => '该严重级别不支持Webhook'];
            }
            
            // 构建Webhook数据
            $data = [
                'notification_id' => $notification['id'],
                'timestamp' => time(),
                'severity' => $notification['severity'],
                'title' => $notification['title'],
                'message' => $notification['message'],
                'metadata' => $notification['metadata'] ?? [],
            ];
            
            // 发送请求
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $config['url']);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $config['method']);
            
            // 设置请求体
            if (strtoupper($config['method']) === 'POST' || strtoupper($config['method']) === 'PUT') {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
            
            // 设置头信息
            $headers = [];
            foreach ($config['headers'] as $key => $value) {
                $headers[] = "{$key}: {$value}";
            }
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            curl_close($ch);
            
            // 检查响应
            if ($httpCode >= 200 && $httpCode < 300) {
                return ['success' => true, 'response' => $response, 'http_code' => $httpCode];
            } else {
                throw new Exception("Webhook请求失败: HTTP {$httpCode}, 响应: {$response}");
            }
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 发送微信消息
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendWechat(array $notification) {
        try {
            // 检查是否为支持的严重级别
            if (!in_array($notification['severity'], $this->config['wechat']['severities'])) {
                return ['success' => false, 'error' => '该严重级别不支持微信消息'];
            }
            
            // 根据类型发送
            switch ($this->config['wechat']['type']) {
                case 'work':
                    return $this->sendWechatWorkMessage($notification);
                case 'official':
                    return $this->sendWechatOfficialMessage($notification);
                default:
                    throw new Exception("不支持的微信类型: {$this->config['wechat']['type']}");
            }
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 发送企业微信消息
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendWechatWorkMessage(array $notification) {
        try {
            // 获取配置
            $config = $this->config['wechat']['work'];
            
            // 获取access_token
            $accessToken = $this->getWechatWorkAccessToken($config['corpid'], $config['corpsecret']);
            
            // 发送消息
            $apiUrl = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={$accessToken}";
            
            // 构建消息内容
            $message = [
                'touser' => $config['touser'],
                'msgtype' => 'text',
                'agentid' => $config['agentid'],
                'text' => [
                    'content' => $this->generateWechatWorkContent($notification),
                ],
                'safe' => 0,
            ];
            
            // 发送请求
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message, JSON_UNESCAPED_UNICODE));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            curl_close($ch);
            
            // 解析响应
            $result = json_decode($response, true);
            
            // 检查是否成功
            if (!isset($result['errcode']) || $result['errcode'] !== 0) {
                throw new Exception("企业微信消息发送失败: " . ($result['errmsg'] ?? "未知错误"));
            }
            
            return ['success' => true, 'response' => $result];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 获取企业微信access_token
     * @param string $corpid 企业ID
     * @param string $corpsecret 应用密钥
     * @return string access_token
     * @throws Exception
     */
    protected function getWechatWorkAccessToken($corpid, $corpsecret) {
        // 这里可以实现缓存机制，避免频繁请求
        // 简化处理，直接请求
        $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={$corpid}&corpsecret={$corpsecret}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($response, true);
        
        if (!isset($result['errcode']) || $result['errcode'] !== 0) {
            throw new Exception("获取企业微信access_token失败: " . ($result['errmsg'] ?? "未知错误"));
        }
        
        return $result['access_token'];
    }
    
    /**
     * 生成企业微信消息内容
     * @param array $notification 通知信息
     * @return string 消息内容
     */
    protected function generateWechatWorkContent(array $notification) {
        $content = '';
        
        // 添加严重级别
        $severityEmoji = $notification['severity'] === self::SEVERITY_CRITICAL ? '⚠️紧急⚠️' : 
                        ($notification['severity'] === self::SEVERITY_WARNING ? '⚠️警告⚠️' : 'ℹ️信息ℹ️');
        $content .= $severityEmoji . ' ' . $notification['title'] . "\n\n";
        
        // 添加消息内容
        $content .= $notification['message'] . "\n\n";
        
        // 添加时间
        $content .= '时间: ' . date('Y-m-d H:i:s');
        
        return $content;
    }
    
    /**
     * 发送公众号消息（简化版）
     * @param array $notification 通知信息
     * @return array 发送结果
     */
    protected function sendWechatOfficialMessage(array $notification) {
        try {
            // 公众号消息需要openid，这里简化处理
            // 实际应用中应该使用正确的模板和参数
            return ['success' => false, 'error' => '公众号消息功能暂未实现'];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 检查是否在工作时间
     * @return bool 是否在工作时间
     */
    protected function isWorkingHours() {
        $now = new DateTime();
        $hour = (int)$now->format('G'); // 24小时制
        $weekday = (int)$now->format('N'); // 1-7，周一到周日
        
        // 检查是否在工作日
        if (!in_array($weekday, $this->config['strategies']['working_hours']['weekdays'])) {
            return false;
        }
        
        // 检查是否在工作时间范围内
        $startHour = $this->config['strategies']['working_hours']['start'];
        $endHour = $this->config['strategies']['working_hours']['end'];
        
        return $hour >= $startHour && $hour < $endHour;
    }
    
    /**
     * 渲染模板
     * @param string $template 模板
     * @param array $data 数据
     * @return string 渲染后的内容
     */
    protected function renderTemplate($template, array $data) {
        // 简单的模板替换
        $result = $template;
        
        // 替换变量 {{变量名}}
        foreach ($data as $key => $value) {
            $search = "{{{$key}}}";
            $replace = is_array($value) ? json_encode($value, JSON_PRETTY_PRINT) : (string)$value;
            $result = str_replace($search, $replace, $result);
        }
        
        // 处理条件 {% if 变量 %}...{% endif %}
        preg_match_all('/\{%\s*if\s+(\w+)\s*%\}(.*?)\{%\s*endif\s*%\}/s', $result, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $variable = $match[1];
            $content = $match[2];
            $fullMatch = $match[0];
            
            if (isset($data[$variable]) && $data[$variable]) {
                $result = str_replace($fullMatch, $content, $result);
            } else {
                $result = str_replace($fullMatch, '', $result);
            }
        }
        
        return $result;
    }
    
    /**
     * 记录通知到历史
     * @param string $channel 渠道
     * @param array $notification 通知信息
     * @return int 历史记录ID
     */
    protected function logNotification($channel, array $notification) {
        if ($this->db === null || !$this->config['history']['enabled']) {
            return null;
        }
        
        try {
            // 获取收件人
            $recipients = [];
            switch ($channel) {
                case self::CHANNEL_EMAIL:
                    $recipients = $this->getEmailRecipients($notification['severity']);
                    break;
                case self::CHANNEL_SMS:
                    $recipients = $this->getSmsRecipients($notification['severity']);
                    break;
            }
            
            // 插入记录
            $stmt = $this->db->prepare(
                "INSERT INTO notification_history (notification_id, channel, severity, title, recipient, status) 
                 VALUES (?, ?, ?, ?, ?, 'pending')"
            );
            
            $stmt->execute([
                $notification['id'],
                $channel,
                $notification['severity'],
                $notification['title'],
                implode(',', $recipients),
            ]);
            
            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log('记录通知历史失败: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 更新通知历史状态
     * @param int $historyId 历史记录ID
     * @param bool $success 是否成功
     * @param string $error 错误信息
     */
    protected function updateNotificationHistory($historyId, $success, $error = null) {
        if ($this->db === null || !$this->config['history']['enabled']) {
            return;
        }
        
        try {
            $status = $success ? 'sent' : 'failed';
            
            $stmt = $this->db->prepare(
                "UPDATE notification_history 
                 SET status = ?, error_message = ?, sent_at = CURRENT_TIMESTAMP 
                 WHERE id = ?"
            );
            
            $stmt->execute([$status, $error, $historyId]);
        } catch (Exception $e) {
            error_log('更新通知历史失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 清理过期的通知历史
     */
    public function cleanupOldHistory() {
        if ($this->db === null || !$this->config['history']['enabled']) {
            return;
        }
        
        try {
            $days = $this->config['history']['retention_days'];
            $this->db->exec(
                "DELETE FROM notification_history 
                 WHERE created_at < DATE_SUB(NOW(), INTERVAL {$days} DAY)"
            );
        } catch (Exception $e) {
            error_log('清理通知历史失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 添加通知模板
     * @param array $template 模板信息
     * @return bool 是否成功
     */
    public function addTemplate(array $template) {
        if ($this->db === null) {
            return false;
        }
        
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO notification_templates (type, channel, severity, subject, content, variables) 
                 VALUES (?, ?, ?, ?, ?, ?) 
                 ON DUPLICATE KEY UPDATE 
                 subject = VALUES(subject), 
                 content = VALUES(content), 
                 variables = VALUES(variables)"
            );
            
            $stmt->execute([
                $template['type'],
                $template['channel'],
                $template['severity'],
                $template['subject'] ?? '',
                $template['content'] ?? '',
                json_encode($template['variables'] ?? []),
            ]);
            
            return true;
        } catch (Exception $e) {
            error_log('添加通知模板失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 添加通知接收者
     * @param array $recipient 接收者信息
     * @return bool 是否成功
     */
    public function addRecipient(array $recipient) {
        if ($this->db === null) {
            return false;
        }
        
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO notification_recipients (name, email, phone, wechat_id, enabled, severity_levels, channels) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            
            $stmt->execute([
                $recipient['name'],
                $recipient['email'] ?? '',
                $recipient['phone'] ?? '',
                $recipient['wechat_id'] ?? '',
                $recipient['enabled'] ?? true,
                $recipient['severity_levels'] ?? 'critical,warning,info',
                $recipient['channels'] ?? 'email,sms,wechat',
            ]);
            
            return true;
        } catch (Exception $e) {
            error_log('添加通知接收者失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取配置
     * @return array 配置
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 更新配置
     * @param array $newConfig 新配置
     */
    public function updateConfig(array $newConfig) {
        $this->config = array_merge_recursive($this->config, $newConfig);
    }
}

// 初始化通知系统的便捷函数
function initializeNotificationSystem($config = []) {
    return NotificationSystem::getInstance($config);
}

// 发送通知的便捷函数
function sendNotification($title, $message, $severity = NotificationSystem::SEVERITY_WARNING, $metadata = []) {
    $notificationSystem = NotificationSystem::getInstance();
    return $notificationSystem->send([
        'title' => $title,
        'message' => $message,
        'severity' => $severity,
        'metadata' => $metadata,
    ]);
}