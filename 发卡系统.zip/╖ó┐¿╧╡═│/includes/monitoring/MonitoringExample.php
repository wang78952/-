<?php

/**
 * 监控工具使用示例
 * 展示如何集成和使用性能分析器和任务监控器
 */

// 引入必要的类
require_once __DIR__ . '/PerformanceProfiler.php';
require_once __DIR__ . '/TaskMonitor.php';

/**
 * 性能监控示例
 */
function performanceMonitoringExample() {
    echo "\n===== 性能监控示例 =====\n";
    
    // 初始化性能分析器
    $profiler = PerformanceProfiler::getInstance([
        'enabled' => true,
        'log_slow_queries' => true,
        'slow_query_threshold' => 0.001, // 简化示例的阈值
        'log_file' => __DIR__ . '/../logs/slow_queries.log',
    ]);
    
    // 开始计时
    $profiler->startTimer('example_operation');
    
    // 添加内存快照
    $profiler->addMemorySnapshot('操作开始');
    
    // 模拟一些操作
    for ($i = 0; $i < 1000; $i++) {
        // 模拟函数调用
        $result = simulateHeavyOperation();
        $profiler->logFunctionCall('simulateHeavyOperation', [], $result, 0.0001 * $i);
    }
    
    // 模拟数据库查询
    $profiler->logQuery(
        "SELECT * FROM cards WHERE status = 'active' LIMIT 1000",
        ['status' => 'active'],
        0.5, // 500ms 查询
        ''
    );
    
    // 添加另一个内存快照
    $profiler->addMemorySnapshot('操作完成');
    
    // 停止计时器
    $duration = $profiler->stopTimer('example_operation');
    
    // 获取并显示报告
    $report = $profiler->getReport();
    echo "总执行时间: " . number_format($duration, 4) . " 秒\n";
    echo "峰值内存: " . $report['execution_summary']['peak_memory'] . "\n";
    echo "总查询数: " . $report['execution_summary']['total_queries'] . "\n";
    
    // 生成HTML报告
    $htmlReport = $profiler->exportHtml(true);
    file_put_contents(__DIR__ . '/../logs/performance_report.html', $htmlReport);
    echo "HTML报告已生成: logs/performance_report.html\n";
}

/**
 * 任务监控示例
 */
function taskMonitoringExample() {
    echo "\n===== 任务监控示例 =====\n";
    
    // 初始化任务监控器
    $monitor = TaskMonitor::getInstance([
        'data_store' => 'file',
        'file_path' => __DIR__ . '/../logs/task_monitor.json',
    ]);
    
    // 创建一个新任务
    $taskId = $monitor->createTask('数据库批量更新任务', [
        'table' => 'cards',
        'operation' => 'update_status',
        'total_records' => 10000,
    ]);
    
    echo "创建任务: {$taskId}\n";
    
    // 开始任务
    $monitor->startTask($taskId);
    echo "任务已开始\n";
    
    // 模拟任务执行
    for ($i = 0; $i <= 100; $i += 10) {
        // 更新进度
        $monitor->updateProgress($taskId, $i, [
            'processed_records' => ($i / 100) * 10000,
            'memory_usage' => memory_get_usage(),
        ]);
        
        echo "任务进度: {$i}%\n";
        
        // 模拟处理延迟
        usleep(100000); // 100ms
    }
    
    // 完成任务
    $monitor->completeTask($taskId, [
        'success' => true,
        'processed_records' => 10000,
        'errors' => 0,
    ]);
    
    echo "任务已完成\n";
    
    // 获取任务信息
    $task = $monitor->getTask($taskId);
    echo "任务执行时间: {$task['duration']} 秒\n";
    
    // 显示任务列表
    $tasks = $monitor->getTasks();
    echo "\n所有任务 (共" . count($tasks) . "):\n";
    foreach ($tasks as $t) {
        echo "- {$t['name']}: {$t['status']} ({$t['progress']}%)\n";
    }
}

/**
 * 异步任务监控示例
 */
function asyncTaskMonitoringExample() {
    echo "\n===== 异步任务监控示例 =====\n";
    
    // 初始化任务监控器
    $monitor = TaskMonitor::getInstance([
        'file_path' => __DIR__ . '/../logs/task_monitor.json',
    ]);
    
    // 模拟创建异步任务（实际应用中这会在另一个进程中执行）
    $asyncTaskId = $monitor->createTask('异步数据处理任务', [
        'type' => 'data_import',
        'source' => 'data.csv',
        'records' => 50000,
    ]);
    
    echo "创建异步任务: {$asyncTaskId}\n";
    echo "在实际应用中，这个任务会被提交到异步队列\n";
    
    // 模拟任务执行过程
    // 实际应用中这部分会在工作进程中执行
    $monitor->startTask($asyncTaskId);
    
    // 这里模拟任务执行的一部分
    for ($i = 0; $i <= 30; $i += 10) {
        $monitor->updateProgress($asyncTaskId, $i, [
            'processed' => ($i / 100) * 50000,
            'errors' => rand(0, 10),
        ]);
        usleep(50000);
    }
    
    echo "任务已开始执行，当前进度: 30%\n";
    echo "在实际应用中，你可以随时检查任务状态:\n";
    echo "\$task = \$monitor->getTask('{$asyncTaskId}');\n";
    echo "echo \$task['progress'] . '%';\n";
}

/**
 * 集成到数据库操作的示例
 */
function databaseIntegrationExample() {
    echo "\n===== 数据库操作集成示例 =====\n";
    
    // 初始化性能分析器
    $profiler = PerformanceProfiler::getInstance([
        'profile_all_queries' => true,
    ]);
    
    // 假设我们有一个数据库连接
    // 在实际应用中，你应该使用现有的数据库连接
    class MockDatabase {
        private $profiler;
        
        public function __construct($profiler) {
            $this->profiler = $profiler;
        }
        
        public function query($sql, $params = []) {
            $start = microtime(true);
            
            // 模拟查询执行
            usleep(10000 + rand(0, 90000)); // 10-100ms
            
            $duration = microtime(true) - $start;
            
            // 记录查询
            $this->profiler->logQuery($sql, $params, $duration, '');
            
            return [
                'success' => true,
                'duration' => $duration,
                'affected_rows' => rand(0, 1000),
            ];
        }
    }
    
    // 创建模拟数据库连接
    $db = new MockDatabase($profiler);
    
    // 执行一些查询
    $results = [];
    for ($i = 0; $i < 5; $i++) {
        $results[] = $db->query(
            "UPDATE cards SET last_used = NOW() WHERE id > ? AND status = ?",
            [$i * 1000, 'active']
        );
    }
    
    // 获取查询统计
    $slowQueries = $profiler->getSlowQueries();
    echo "慢查询数量: " . count($slowQueries) . "\n";
    
    foreach ($slowQueries as $query) {
        echo "  - " . number_format($query['duration'], 4) . "s: " . substr($query['sql'], 0, 50) . "...\n";
    }
}

/**
 * 模拟耗时操作
 */
function simulateHeavyOperation() {
    // 简单的计算密集型操作
    $sum = 0;
    for ($i = 0; $i < 1000; $i++) {
        $sum += sqrt($i) * log($i + 1);
    }
    return $sum;
}

/**
 * 数据库批量处理监控示例
 */
function batchProcessingMonitoringExample() {
    echo "\n===== 数据库批量处理监控示例 =====\n";
    
    // 初始化监控器
    $monitor = TaskMonitor::getInstance();
    $profiler = PerformanceProfiler::getInstance();
    
    // 创建批量处理任务
    $taskId = $monitor->createTask('数据库分片批量处理', [
        'operation' => 'batch_update',
        'table' => 'cards',
        'batch_size' => 1000,
        'total_partitions' => 10,
    ]);
    
    $monitor->startTask($taskId);
    
    // 模拟分片处理
    for ($partition = 1; $partition <= 10; $partition++) {
        $profiler->startTimer("partition_{$partition}");
        
        // 模拟当前分片的数据处理
        $processed = $partition * 1000;
        $progress = ($partition / 10) * 100;
        
        // 更新任务进度
        $monitor->updateProgress($taskId, $progress, [
            'partition' => $partition,
            'processed' => $processed,
            'memory' => memory_get_usage(),
        ]);
        
        echo "处理分片 {$partition}/10: {$processed} 条记录\n";
        
        // 模拟每批次之间的延迟
        usleep(50000); // 50ms
        
        // 记录分片处理时间
        $profiler->stopTimer("partition_{$partition}");
        
        // 记录分片查询
        $profiler->logQuery(
            "UPDATE cards SET status = 'processed' WHERE id BETWEEN ? AND ?",
            [($partition - 1) * 1000 + 1, $partition * 1000],
            0.2 + ($partition * 0.01),
            ''
        );
    }
    
    // 完成任务
    $monitor->completeTask($taskId, [
        'total_processed' => 10000,
        'success_rate' => 99.8,
        'errors' => 20,
    ]);
    
    echo "批量处理任务完成\n";
    
    // 生成最终报告
    $report = $profiler->getReport();
    echo "总处理时间: " . number_format($report['execution_summary']['total_time'], 4) . " 秒\n";
    echo "数据库查询总数: " . $report['execution_summary']['total_queries'] . "\n";
}

/**
 * 运行所有示例
 */
function runAllMonitoringExamples() {
    // 确保日志目录存在
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
        echo "警告: 无法创建日志目录\n";
    }
    
    // 运行各个示例
    performanceMonitoringExample();
    taskMonitoringExample();
    asyncTaskMonitoringExample();
    databaseIntegrationExample();
    batchProcessingMonitoringExample();
    
    echo "\n===== 示例完成 =====\n";
    echo "1. 性能分析报告已保存到 logs/performance_report.html\n";
    echo "2. 任务监控数据已保存到 logs/task_monitor.json\n";
    echo "3. 慢查询日志已保存到 logs/slow_queries.log\n";
    
    echo "\n===== 集成建议 =====\n";
    echo "1. 在应用程序入口点初始化性能分析器\n";
    echo "2. 为所有数据库查询添加性能监控\n";
    echo "3. 为长时间运行的任务创建任务监控记录\n";
    echo "4. 定期查看性能报告，识别需要优化的地方\n";
    echo "5. 设置定时任务清理旧的监控数据\n";
}

/**
 * 集成指导 - 如何在实际应用中使用这些工具
 */
function integrationGuide() {
    $guide = <<<EOT

===== 监控工具集成指南 =====

1. 性能分析器集成:
   - 在应用入口文件中初始化:
     \$profiler = PerformanceProfiler::getInstance(['enabled' => true, ...]);
   - 为关键操作添加计时:
     \$profiler->startTimer('critical_operation');
     // 执行操作
     \$profiler->stopTimer('critical_operation');
   - 集成到数据库层:
     在数据库抽象类中添加查询日志功能

2. 任务监控器集成:
   - 为异步任务创建监控记录
   - 在任务执行过程中定期更新进度
   - 提供API端点查询任务状态

3. 最佳实践:
   - 在生产环境中设置合理的慢查询阈值
   - 定期清理监控数据避免磁盘空间浪费
   - 为监控数据创建备份策略
   - 设置基于监控数据的告警机制

4. 配置建议:
   - 开发环境: 开启所有监控功能
   - 测试环境: 模拟生产环境配置
   - 生产环境: 根据性能影响调整监控级别

EOT;
    
    return $guide;
}

// 如果直接运行此文件，执行示例
if (basename(__FILE__) === basename($_SERVER['PHP_SELF'])) {
    runAllMonitoringExamples();
    echo integrationGuide();
}