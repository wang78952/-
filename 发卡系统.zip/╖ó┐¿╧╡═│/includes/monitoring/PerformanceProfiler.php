<?php

/**
 * 性能分析器
 * 用于监控代码执行时间、内存使用和函数调用统计
 */
class PerformanceProfiler {
    /**
     * 单例实例
     */
    private static $instance = null;
    
    /**
     * 性能数据
     */
    private $data = [
        'timers' => [],          // 计时器数据
        'memory_snapshots' => [], // 内存快照
        'function_calls' => [],  // 函数调用统计
        'query_logs' => [],      // SQL查询日志
        'global_stats' => [
            'start_time' => 0,
            'end_time' => 0,
            'peak_memory' => 0,
            'total_queries' => 0,
            'slow_queries' => 0,
        ],
    ];
    
    /**
     * 配置
     */
    private $config = [
        'enabled' => true,              // 是否启用
        'log_slow_queries' => true,     // 是否记录慢查询
        'slow_query_threshold' => 1.0,  // 慢查询阈值(秒)
        'max_log_size' => 1000,         // 最大日志条目数
        'log_file' => null,             // 日志文件路径
        'profile_all_queries' => false, // 是否分析所有查询
    ];
    
    /**
     * 构造函数
     */
    private function __construct($config = []) {
        $this->config = array_merge($this->config, $config);
        $this->data['global_stats']['start_time'] = microtime(true);
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 开始计时器
     * @param string $name 计时器名称
     */
    public function startTimer($name) {
        if (!$this->config['enabled']) return;
        
        $this->data['timers'][$name] = [
            'start' => microtime(true),
            'end' => null,
            'duration' => null,
        ];
    }
    
    /**
     * 停止计时器
     * @param string $name 计时器名称
     * @return float 持续时间(秒)
     */
    public function stopTimer($name) {
        if (!$this->config['enabled'] || !isset($this->data['timers'][$name])) {
            return 0;
        }
        
        $timer = &$this->data['timers'][$name];
        $timer['end'] = microtime(true);
        $timer['duration'] = $timer['end'] - $timer['start'];
        
        return $timer['duration'];
    }
    
    /**
     * 获取计时器持续时间
     * @param string $name 计时器名称
     * @return float 持续时间(秒)
     */
    public function getTimerDuration($name) {
        if (!isset($this->data['timers'][$name]) || !$this->data['timers'][$name]['duration']) {
            return 0;
        }
        return $this->data['timers'][$name]['duration'];
    }
    
    /**
     * 添加内存快照
     * @param string $label 标签
     */
    public function addMemorySnapshot($label) {
        if (!$this->config['enabled']) return;
        
        $memory = memory_get_usage(true);
        $peak_memory = memory_get_peak_usage(true);
        
        $this->data['memory_snapshots'][] = [
            'label' => $label,
            'time' => microtime(true),
            'memory' => $memory,
            'peak_memory' => $peak_memory,
        ];
        
        // 更新全局峰值内存
        if ($peak_memory > $this->data['global_stats']['peak_memory']) {
            $this->data['global_stats']['peak_memory'] = $peak_memory;
        }
        
        // 限制日志大小
        $this->limitLogSize('memory_snapshots');
    }
    
    /**
     * 记录函数调用
     * @param string $function 函数名
     * @param array $params 参数
     * @param mixed $result 结果
     * @param float $duration 执行时间
     */
    public function logFunctionCall($function, $params = [], $result = null, $duration = null) {
        if (!$this->config['enabled']) return;
        
        // 更新函数调用统计
        if (!isset($this->data['function_calls'][$function])) {
            $this->data['function_calls'][$function] = [
                'count' => 0,
                'total_time' => 0,
                'avg_time' => 0,
                'min_time' => null,
                'max_time' => 0,
            ];
        }
        
        $stats = &$this->data['function_calls'][$function];
        $stats['count']++;
        
        if ($duration !== null) {
            $stats['total_time'] += $duration;
            $stats['avg_time'] = $stats['total_time'] / $stats['count'];
            $stats['min_time'] = $stats['min_time'] === null ? $duration : min($stats['min_time'], $duration);
            $stats['max_time'] = max($stats['max_time'], $duration);
        }
    }
    
    /**
     * 记录数据库查询
     * @param string $sql SQL语句
     * @param array $params 参数
     * @param float $duration 执行时间
     * @param string $error 错误信息
     */
    public function logQuery($sql, $params = [], $duration = 0, $error = '') {
        if (!$this->config['enabled']) return;
        
        $this->data['global_stats']['total_queries']++;
        
        // 检查是否为慢查询
        $isSlowQuery = $this->config['log_slow_queries'] && $duration >= $this->config['slow_query_threshold'];
        
        if ($isSlowQuery) {
            $this->data['global_stats']['slow_queries']++;
        }
        
        // 记录查询日志（慢查询或配置了分析所有查询）
        if ($isSlowQuery || $this->config['profile_all_queries']) {
            $queryLog = [
                'sql' => $sql,
                'params' => $params,
                'duration' => $duration,
                'time' => microtime(true),
                'error' => $error,
                'trace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5),
            ];
            
            $this->data['query_logs'][] = $queryLog;
            $this->limitLogSize('query_logs');
            
            // 记录到文件
            if ($isSlowQuery && $this->config['log_file']) {
                $this->logSlowQueryToFile($queryLog);
            }
        }
    }
    
    /**
     * 获取性能报告
     * @return array 性能报告
     */
    public function getReport() {
        // 更新全局结束时间
        if (!$this->data['global_stats']['end_time']) {
            $this->data['global_stats']['end_time'] = microtime(true);
        }
        
        // 计算总执行时间
        $total_time = $this->data['global_stats']['end_time'] - $this->data['global_stats']['start_time'];
        
        // 格式化报告
        $report = [
            'execution_summary' => [
                'total_time' => $total_time,
                'peak_memory' => $this->formatBytes($this->data['global_stats']['peak_memory']),
                'total_queries' => $this->data['global_stats']['total_queries'],
                'slow_queries' => $this->data['global_stats']['slow_queries'],
                'avg_query_time' => $this->data['global_stats']['total_queries'] > 0 
                    ? ($total_time / $this->data['global_stats']['total_queries']) : 0,
            ],
            'timers' => $this->data['timers'],
            'top_functions' => $this->getTopFunctions(),
            'slow_queries' => $this->getSlowQueries(),
            'memory_usage' => $this->data['memory_snapshots'],
        ];
        
        return $report;
    }
    
    /**
     * 获取最慢的查询
     * @param int $limit 限制数量
     * @return array 慢查询列表
     */
    public function getSlowQueries($limit = 10) {
        $slowQueries = array_filter($this->data['query_logs'], function($log) {
            return $log['duration'] >= $this->config['slow_query_threshold'];
        });
        
        // 按执行时间降序排序
        usort($slowQueries, function($a, $b) {
            return $b['duration'] <=> $a['duration'];
        });
        
        return array_slice($slowQueries, 0, $limit);
    }
    
    /**
     * 获取调用最多的函数
     * @param int $limit 限制数量
     * @return array 函数列表
     */
    public function getTopFunctions($limit = 10) {
        $functions = $this->data['function_calls'];
        
        // 按调用次数降序排序
        usort($functions, function($a, $b) {
            return $b['count'] <=> $a['count'];
        });
        
        return array_slice($functions, 0, $limit);
    }
    
    /**
     * 导出性能数据为JSON
     * @param bool $return 是否返回而不是输出
     * @return string|null JSON数据
     */
    public function exportJson($return = false) {
        $report = $this->getReport();
        $json = json_encode($report, JSON_PRETTY_PRINT);
        
        if ($return) {
            return $json;
        } else {
            echo $json;
            return null;
        }
    }
    
    /**
     * 导出性能数据为HTML报告
     * @param bool $return 是否返回而不是输出
     * @return string|null HTML报告
     */
    public function exportHtml($return = false) {
        $report = $this->getReport();
        
        $html = "";
        $html .= "<!DOCTYPE html><html><head>";
        $html .= "<meta charset='UTF-8'><title>性能分析报告</title>";
        $html .= "<style>";       
        $html .= "body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }";
        $html .= ".container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
        $html .= "h1 { color: #333; margin-bottom: 30px; }";
        $html .= ".summary { background: #e8f4f8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }";
        $html .= ".summary table { width: 100%; border-collapse: collapse; }";
        $html .= ".summary td { padding: 8px; border-bottom: 1px solid #ddd; }";
        $html .= ".summary td:first-child { font-weight: bold; width: 30%; }";
        $html .= "h2 { color: #444; margin-top: 30px; border-bottom: 2px solid #eee; padding-bottom: 10px; }";
        $html .= ".table-container { overflow-x: auto; }";
        $html .= "table { width: 100%; border-collapse: collapse; margin-top: 15px; }";
        $html .= "th { background: #f0f0f0; padding: 10px; text-align: left; font-weight: bold; }";
        $html .= "td { padding: 8px; border-bottom: 1px solid #eee; }";
        $html .= ".slow { background: #fff8f8; color: #c00; }";
        $html .= ".timer-bar { height: 10px; background: #ddd; border-radius: 5px; margin-top: 5px; overflow: hidden; }";
        $html .= ".timer-fill { background: #4CAF50; height: 100%; }";
        $html .= ".sql-code { background: #f8f8f8; padding: 10px; border-left: 3px solid #666; font-family: monospace; white-space: pre-wrap; }";
        $html .= "</style>";
        $html .= "</head><body><div class='container'>";
        
        // 标题
        $html .= "<h1>性能分析报告</h1>";
        
        // 执行摘要
        $html .= "<div class='summary'>";
        $html .= "<table>";
        $html .= "<tr><td>总执行时间:</td><td>".number_format($report['execution_summary']['total_time'], 4)." 秒</td></tr>";
        $html .= "<tr><td>峰值内存:</td><td>".$report['execution_summary']['peak_memory'] . "</td></tr>";
        $html .= "<tr><td>总查询数:</td><td>".$report['execution_summary']['total_queries'] . "</td></tr>";
        $html .= "<tr><td>慢查询数:</td><td>".$report['execution_summary']['slow_queries'] . "</td></tr>";
        $html .= "<tr><td>平均查询时间:</td><td>".number_format($report['execution_summary']['avg_query_time'], 4)." 秒</td></tr>";
        $html .= "</table>";
        $html .= "</div>";
        
        // 计时器数据
        if (!empty($report['timers'])) {
            $html .= "<h2>计时器</h2>";
            $html .= "<div class='table-container'><table>";
            $html .= "<tr><th>名称</th><th>时间(秒)</th><th>占比</th></tr>";
            
            foreach ($report['timers'] as $name => $timer) {
                if ($timer['duration']) {
                    $percentage = ($timer['duration'] / $report['execution_summary']['total_time']) * 100;
                    $html .= "<tr>";
                    $html .= "<td>".$name . "</td>";
                    $html .= "<td>".number_format($timer['duration'], 4)."</td>";
                    $html .= "<td>".number_format($percentage, 1)."%</td>";
                    $html .= "</tr>";
                    $html .= "<tr><td colspan='3'><div class='timer-bar'><div class='timer-fill' style='width: ".$percentage."%'></div></div></td></tr>";
                }
            }
            
            $html .= "</table></div>";
        }
        
        // 慢查询
        if (!empty($report['slow_queries'])) {
            $html .= "<h2>慢查询</h2>";
            
            foreach ($report['slow_queries'] as $index => $query) {
                $html .= "<div class='slow' style='margin-bottom: 20px; padding: 15px; border-radius: 5px;'>";
                $html .= "<strong>查询 ".($index + 1).":</strong> ".number_format($query['duration'], 4)." 秒<br>";
                $html .= "<div class='sql-code'>".htmlspecialchars($query['sql'])."</div>";
                $html .= "</div>";
            }
        }
        
        // 内存使用
        if (!empty($report['memory_usage'])) {
            $html .= "<h2>内存使用</h2>";
            $html .= "<div class='table-container'><table>";
            $html .= "<tr><th>标签</th><th>时间</th><th>内存使用</th><th>峰值内存</th></tr>";
            
            foreach ($report['memory_usage'] as $snapshot) {
                $html .= "<tr>";
                $html .= "<td>".$snapshot['label'] . "</td>";
                $html .= "<td>".date('H:i:s', $snapshot['time']) . "</td>";
                $html .= "<td>".$this->formatBytes($snapshot['memory']) . "</td>";
                $html .= "<td>".$this->formatBytes($snapshot['peak_memory']) . "</td>";
                $html .= "</tr>";
            }
            
            $html .= "</table></div>";
        }
        
        $html .= "</div></body></html>";
        
        if ($return) {
            return $html;
        } else {
            echo $html;
            return null;
        }
    }
    
    /**
     * 重置性能数据
     */
    public function reset() {
        $this->data = [
            'timers' => [],
            'memory_snapshots' => [],
            'function_calls' => [],
            'query_logs' => [],
            'global_stats' => [
                'start_time' => microtime(true),
                'end_time' => 0,
                'peak_memory' => 0,
                'total_queries' => 0,
                'slow_queries' => 0,
            ],
        ];
    }
    
    /**
     * 设置配置
     * @param array $config 配置数组
     */
    public function setConfig($config) {
        $this->config = array_merge($this->config, $config);
    }
    
    /**
     * 启用/禁用分析器
     * @param bool $enabled 是否启用
     */
    public function setEnabled($enabled) {
        $this->config['enabled'] = $enabled;
    }
    
    /**
     * 记录慢查询到文件
     * @param array $queryLog 查询日志
     */
    private function logSlowQueryToFile($queryLog) {
        try {
            $logEntry = "[" . date('Y-m-d H:i:s') . "] 慢查询 (" . 
                        number_format($queryLog['duration'], 4) . "s): " . 
                        $queryLog['sql'] . "\n";
            
            if (!empty($queryLog['params'])) {
                $logEntry .= "参数: " . json_encode($queryLog['params']) . "\n";
            }
            
            $logEntry .= "堆栈跟踪:\n";
            foreach ($queryLog['trace'] as $frame) {
                if (isset($frame['file']) && isset($frame['line'])) {
                    $logEntry .= "  " . $frame['file'] . ":" . $frame['line'] . "\n";
                }
            }
            
            $logEntry .= "\n";
            
            file_put_contents($this->config['log_file'], $logEntry, FILE_APPEND);
        } catch (Exception $e) {
            // 忽略日志写入错误
        }
    }
    
    /**
     * 限制日志大小
     * @param string $logType 日志类型
     */
    private function limitLogSize($logType) {
        if (isset($this->data[$logType]) && 
            count($this->data[$logType]) > $this->config['max_log_size']) {
            
            // 保留最新的条目
            $this->data[$logType] = array_slice(
                $this->data[$logType], 
                -$this->config['max_log_size']
            );
        }
    }
    
    /**
     * 格式化字节数
     * @param int $bytes 字节数
     * @return string 格式化后的字符串
     */
    private function formatBytes($bytes) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
}