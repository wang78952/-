<?php

/**
 * 任务监控器
 * 用于监控长时间运行的任务状态和性能指标
 */
class TaskMonitor {
    /**
     * 任务状态常量
     */
    const STATUS_PENDING = 'pending';      // 等待中
    const STATUS_RUNNING = 'running';      // 运行中
    const STATUS_COMPLETED = 'completed';  // 已完成
    const STATUS_FAILED = 'failed';        // 失败
    const STATUS_PAUSED = 'paused';        // 暂停
    const STATUS_CANCELLED = 'cancelled';  // 取消
    
    /**
     * 单例实例
     */
    private static $instance = null;
    
    /**
     * 监控数据存储
     */
    private $dataStore = null;
    
    /**
     * 配置
     */
    private $config = [
        'data_store' => 'file',          // 数据存储方式(file/database)
        'file_path' => null,             // 文件存储路径
        'cleanup_interval' => 86400,     // 清理间隔(秒)
        'max_history' => 30,             // 最大历史记录天数
        'status_check_interval' => 5,    // 状态检查间隔(秒)
    ];
    
    /**
     * 构造函数
     */
    private function __construct($config = []) {
        $this->config = array_merge($this->config, $config);
        
        // 初始化数据存储
        $this->initDataStore();
        
        // 定期清理
        $this->scheduleCleanup();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化数据存储
     */
    private function initDataStore() {
        if ($this->config['data_store'] === 'file') {
            // 文件存储实现
            $this->dataStore = new FileTaskDataStore([
                'file_path' => $this->config['file_path'] ?: 'task_monitor.json'
            ]);
        } else if ($this->config['data_store'] === 'database') {
            // 数据库存储实现
            $this->dataStore = new DatabaseTaskDataStore();
        } else {
            throw new Exception("不支持的数据存储类型: " . $this->config['data_store']);
        }
    }
    
    /**
     * 创建任务记录
     * @param string $task_name 任务名称
     * @param array $task_data 任务数据
     * @return string 任务ID
     */
    public function createTask($task_name, $task_data = []) {
        $task_id = $this->generateTaskId();
        
        $task = [
            'id' => $task_id,
            'name' => $task_name,
            'data' => $task_data,
            'status' => self::STATUS_PENDING,
            'created_at' => time(),
            'updated_at' => time(),
            'started_at' => null,
            'completed_at' => null,
            'progress' => 0,
            'duration' => null,
            'memory_usage' => 0,
            'error_message' => null,
            'retries' => 0,
            'metadata' => [],
        ];
        
        $this->dataStore->saveTask($task);
        
        return $task_id;
    }
    
    /**
     * 开始任务
     * @param string $task_id 任务ID
     * @return bool 是否成功
     */
    public function startTask($task_id) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task) {
            return false;
        }
        
        $task['status'] = self::STATUS_RUNNING;
        $task['started_at'] = time();
        $task['updated_at'] = time();
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 更新任务进度
     * @param string $task_id 任务ID
     * @param float $progress 进度(0-100)
     * @param array $metadata 元数据
     * @return bool 是否成功
     */
    public function updateProgress($task_id, $progress, $metadata = []) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task || $task['status'] !== self::STATUS_RUNNING) {
            return false;
        }
        
        $task['progress'] = min(100, max(0, $progress));
        $task['updated_at'] = time();
        $task['memory_usage'] = memory_get_usage(true);
        $task['metadata'] = array_merge($task['metadata'], $metadata);
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 完成任务
     * @param string $task_id 任务ID
     * @param array $result 结果数据
     * @return bool 是否成功
     */
    public function completeTask($task_id, $result = []) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task) {
            return false;
        }
        
        $task['status'] = self::STATUS_COMPLETED;
        $task['completed_at'] = time();
        $task['updated_at'] = time();
        $task['progress'] = 100;
        $task['duration'] = $task['completed_at'] - $task['started_at'];
        $task['result'] = $result;
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 失败任务
     * @param string $task_id 任务ID
     * @param string $error_message 错误信息
     * @return bool 是否成功
     */
    public function failTask($task_id, $error_message) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task) {
            return false;
        }
        
        $task['status'] = self::STATUS_FAILED;
        $task['updated_at'] = time();
        $task['error_message'] = $error_message;
        $task['duration'] = time() - $task['started_at'];
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 暂停任务
     * @param string $task_id 任务ID
     * @return bool 是否成功
     */
    public function pauseTask($task_id) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task || $task['status'] !== self::STATUS_RUNNING) {
            return false;
        }
        
        $task['status'] = self::STATUS_PAUSED;
        $task['updated_at'] = time();
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 恢复任务
     * @param string $task_id 任务ID
     * @return bool 是否成功
     */
    public function resumeTask($task_id) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task || $task['status'] !== self::STATUS_PAUSED) {
            return false;
        }
        
        $task['status'] = self::STATUS_RUNNING;
        $task['updated_at'] = time();
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 取消任务
     * @param string $task_id 任务ID
     * @return bool 是否成功
     */
    public function cancelTask($task_id) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task || 
            $task['status'] === self::STATUS_COMPLETED ||
            $task['status'] === self::STATUS_FAILED ||
            $task['status'] === self::STATUS_CANCELLED) {
            return false;
        }
        
        $task['status'] = self::STATUS_CANCELLED;
        $task['updated_at'] = time();
        
        return $this->dataStore->saveTask($task);
    }
    
    /**
     * 获取任务信息
     * @param string $task_id 任务ID
     * @return array|null 任务信息
     */
    public function getTask($task_id) {
        return $this->dataStore->getTask($task_id);
    }
    
    /**
     * 获取任务列表
     * @param array $filters 过滤条件
     * @param int $limit 限制数量
     * @param int $offset 偏移量
     * @return array 任务列表
     */
    public function getTasks($filters = [], $limit = 50, $offset = 0) {
        return $this->dataStore->getTasks($filters, $limit, $offset);
    }
    
    /**
     * 获取运行中的任务
     * @return array 运行中任务列表
     */
    public function getRunningTasks() {
        return $this->getTasks(['status' => self::STATUS_RUNNING]);
    }
    
    /**
     * 获取统计信息
     * @return array 统计信息
     */
    public function getStats() {
        $tasks = $this->getTasks();
        $stats = [
            'total' => count($tasks),
            'by_status' => [
                self::STATUS_PENDING => 0,
                self::STATUS_RUNNING => 0,
                self::STATUS_COMPLETED => 0,
                self::STATUS_FAILED => 0,
                self::STATUS_PAUSED => 0,
                self::STATUS_CANCELLED => 0,
            ],
            'avg_duration' => 0,
            'slow_tasks' => 0,
        ];
        
        $totalDuration = 0;
        $completedTasks = 0;
        
        foreach ($tasks as $task) {
            $stats['by_status'][$task['status']]++;
            
            if ($task['status'] === self::STATUS_COMPLETED && $task['duration']) {
                $totalDuration += $task['duration'];
                $completedTasks++;
                
                // 慢任务定义为超过5分钟
                if ($task['duration'] > 300) {
                    $stats['slow_tasks']++;
                }
            }
        }
        
        $stats['avg_duration'] = $completedTasks > 0 ? $totalDuration / $completedTasks : 0;
        
        return $stats;
    }
    
    /**
     * 检查任务是否超时
     * @param string $task_id 任务ID
     * @param int $timeout_seconds 超时时间(秒)
     * @return bool 是否超时
     */
    public function isTaskTimedOut($task_id, $timeout_seconds) {
        $task = $this->dataStore->getTask($task_id);
        
        if (!$task || $task['status'] !== self::STATUS_RUNNING || !$task['started_at']) {
            return false;
        }
        
        $elapsed = time() - $task['started_at'];
        return $elapsed > $timeout_seconds;
    }
    
    /**
     * 自动清理过期数据
     */
    public function cleanupOldTasks() {
        $cutoff_time = time() - ($this->config['max_history'] * 86400);
        
        $this->dataStore->deleteTasks([
            'completed_before' => $cutoff_time
        ]);
    }
    
    /**
     * 生成任务ID
     * @return string 任务ID
     */
    private function generateTaskId() {
        return 'task_' . uniqid() . '_' . rand(1000, 9999);
    }
    
    /**
     * 调度定期清理
     */
    private function scheduleCleanup() {
        // 这里使用简单的时间检查
        // 在实际应用中可以使用cron或定时任务
        $last_cleanup = $this->dataStore->getLastCleanupTime();
        
        if (!$last_cleanup || (time() - $last_cleanup) > $this->config['cleanup_interval']) {
            $this->cleanupOldTasks();
            $this->dataStore->setLastCleanupTime(time());
        }
    }
}

/**
 * 文件任务数据存储
 */
class FileTaskDataStore {
    /**
     * 数据文件路径
     */
    private $filePath = null;
    
    /**
     * 缓存数据
     */
    private $cache = null;
    
    /**
     * 构造函数
     */
    public function __construct($config = []) {
        $this->filePath = $config['file_path'] ?? 'task_monitor.json';
        
        // 确保目录存在
        $dir = dirname($this->filePath);
        if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
            throw new Exception("无法创建目录: {$dir}");
        }
        
        // 初始化缓存
        $this->loadData();
    }
    
    /**
     * 加载数据
     */
    private function loadData() {
        if (!file_exists($this->filePath)) {
            $this->cache = ['tasks' => [], 'last_cleanup' => 0];
            return;
        }
        
        try {
            $content = file_get_contents($this->filePath);
            $data = json_decode($content, true);
            
            if (!is_array($data)) {
                $this->cache = ['tasks' => [], 'last_cleanup' => 0];
            } else {
                $this->cache = $data;
            }
        } catch (Exception $e) {
            $this->cache = ['tasks' => [], 'last_cleanup' => 0];
        }
    }
    
    /**
     * 保存数据
     */
    private function saveData() {
        try {
            $content = json_encode($this->cache, JSON_PRETTY_PRINT);
            file_put_contents($this->filePath, $content);
        } catch (Exception $e) {
            throw new Exception("无法保存任务数据: " . $e->getMessage());
        }
    }
    
    /**
     * 保存任务
     */
    public function saveTask($task) {
        $this->cache['tasks'][$task['id']] = $task;
        $this->saveData();
        return true;
    }
    
    /**
     * 获取任务
     */
    public function getTask($task_id) {
        return isset($this->cache['tasks'][$task_id]) ? $this->cache['tasks'][$task_id] : null;
    }
    
    /**
     * 获取任务列表
     */
    public function getTasks($filters = [], $limit = 50, $offset = 0) {
        $tasks = array_values($this->cache['tasks']);
        
        // 应用过滤
        if (!empty($filters)) {
            $tasks = array_filter($tasks, function($task) use ($filters) {
                foreach ($filters as $key => $value) {
                    if ($key === 'completed_before' && isset($task['completed_at'])) {
                        if ($task['completed_at'] > $value) return false;
                    } else if (isset($task[$key]) && $task[$key] !== $value) {
                        return false;
                    }
                }
                return true;
            });
        }
        
        // 按更新时间倒序排序
        usort($tasks, function($a, $b) {
            return $b['updated_at'] <=> $a['updated_at'];
        });
        
        // 应用分页
        return array_slice($tasks, $offset, $limit);
    }
    
    /**
     * 删除任务
     */
    public function deleteTasks($filters = []) {
        $deleted = 0;
        
        foreach ($this->cache['tasks'] as $task_id => $task) {
            $shouldDelete = true;
            
            foreach ($filters as $key => $value) {
                if ($key === 'completed_before' && isset($task['completed_at'])) {
                    if ($task['completed_at'] > $value) {
                        $shouldDelete = false;
                    }
                } else if (isset($task[$key]) && $task[$key] !== $value) {
                    $shouldDelete = false;
                }
            }
            
            if ($shouldDelete) {
                unset($this->cache['tasks'][$task_id]);
                $deleted++;
            }
        }
        
        if ($deleted > 0) {
            $this->saveData();
        }
        
        return $deleted;
    }
    
    /**
     * 获取上次清理时间
     */
    public function getLastCleanupTime() {
        return $this->cache['last_cleanup'] ?? 0;
    }
    
    /**
     * 设置上次清理时间
     */
    public function setLastCleanupTime($time) {
        $this->cache['last_cleanup'] = $time;
        $this->saveData();
    }
}

/**
 * 数据库任务数据存储
 * 注：这里提供接口，实际使用时需要实现
 */
class DatabaseTaskDataStore {
    // 数据库实现需要根据具体的数据库连接方式实现
    // 这里仅提供接口定义
    
    public function saveTask($task) { /* 实现数据库保存 */ }
    public function getTask($task_id) { /* 实现数据库查询 */ }
    public function getTasks($filters = [], $limit = 50, $offset = 0) { /* 实现数据库查询 */ }
    public function deleteTasks($filters = []) { /* 实现数据库删除 */ }
    public function getLastCleanupTime() { /* 实现数据库查询 */ }
    public function setLastCleanupTime($time) { /* 实现数据库更新 */ }
}