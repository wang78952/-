<?php
/**
 * 异常波动预警系统
 * 基于历史数据检测业务指标异常，支持多种检测算法和自动报警功能
 */

// 引入业务指标收集器
require_once __DIR__ . '/../business/BusinessMetricsCollector.php';
// 引入通知系统
require_once __DIR__ . '/NotificationSystem.php';

class AnomalyDetection {
    /**
     * 业务指标收集器实例
     * @var BusinessMetricsCollector
     */
    protected $metricsCollector = null;
    
    /**
     * 通知系统实例
     * @var NotificationSystem
     */
    protected $notificationSystem = null;
    
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        // 检测算法配置
        'algorithm' => [
            'default' => 'threshold',  // 默认算法: threshold(阈值检测), statistical(统计检测), machine_learning(机器学习)
            'supported' => ['threshold', 'statistical', 'machine_learning'],
        ],
        
        // 阈值检测配置
        'threshold_detection' => [
            // 卡密相关阈值
            'card_activation_rate_min' => 30,     // 卡密激活率最低阈值(%)
            'card_activation_rate_change' => 20,  // 卡密激活率变化阈值(%)
            'card_activation_spike' => 50,        // 卡密激活率骤增阈值(%)
            
            // 订单相关阈值
            'order_conversion_rate_min' => 20,    // 订单转化率最低阈值(%)
            'order_conversion_rate_change' => 20, // 订单转化率变化阈值(%)
            'order_amount_change' => 30,          // 订单金额变化阈值(%)
            'order_volume_spike' => 100,          // 订单量骤增阈值(%)
            
            // 用户相关阈值
            'new_users_change' => 50,             // 新增用户变化阈值(%)
            'user_active_change' => 40,           // 活跃用户变化阈值(%)
            
            // 代理相关阈值
            'proxy_revenue_change' => 30,         // 代理收入变化阈值(%)
            
            // 错误相关阈值
            'error_rate_max' => 5,                // 错误率最高阈值(%)
            'payment_failure_rate' => 10,         // 支付失败率阈值(%)
            'verification_error_rate' => 15,      // 验证失败率阈值(%)
        ],
        
        // 统计检测配置
        'statistical_detection' => [
            'z_score_threshold' => 2.5,           // Z分数阈值
            'moving_average_period' => 7,         // 移动平均周期
            'min_samples' => 14,                  // 最小样本量
        ],
        
        // 机器学习检测配置
        'ml_detection' => [
            'model_type' => 'arima',              // 模型类型: arima, lstm, prophet
            'train_period' => 30,                 // 训练周期(天)
            'forecast_period' => 7,               // 预测周期(天)
            'error_margin' => 15,                 // 误差允许范围(%)
        ],
        
        // 时间序列分析配置
        'time_series' => [
            'consider_trend' => true,             // 考虑趋势
            'consider_seasonality' => true,       // 考虑季节性
            'seasonality_periods' => [
                'daily' => 24,                    // 日周期
                'weekly' => 7,                    // 周周期
                'monthly' => 30,                  // 月周期
            ],
        ],
        
        // 历史数据配置
        'historical_data' => [
            'max_retention_days' => 90,           // 最大保留天数
            'collection_interval' => 60,          // 数据收集间隔(分钟)
        ],
        
        // 告警配置
        'alert' => [
            'min_anomaly_duration' => 10,         // 最小异常持续时间(分钟)
            'alert_cooldown' => 30,               // 告警冷却时间(分钟)
            'auto_resolve_timeout' => 60,         // 自动解决超时(分钟)
            'suppress_similar_alerts' => true,    // 是否抑制相似告警
            'similarity_threshold' => 80,         // 相似度阈值(%)
        ],
        
        // 通知配置
        'notification' => [
            'enabled' => true,                    // 是否启用通知
            'channels' => ['email', 'sms'],       // 默认通知渠道
            'severity_mapping' => [               // 严重程度到通知渠道的映射
                'critical' => ['email', 'sms'],
                'warning' => ['email'],
                'info' => [],
            ],
        ],
    ];
    
    /**
     * 历史数据缓存
     * @var array
     */
    protected $historicalDataCache = [];
    
    /**
     * 告警历史记录
     * @var array
     */
    protected $alertHistory = [];
    
    /**
     * 单例实例
     * @var AnomalyDetection
     */
    protected static $instance = null;
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化依赖组件
        $this->initializeDependencies();
    }
    
    /**
     * 获取单例实例
     * @param array $config 配置信息
     * @return AnomalyDetection
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化依赖组件
     */
    protected function initializeDependencies() {
        try {
            // 初始化业务指标收集器
            $this->metricsCollector = BusinessMetricsCollector::getInstance();
            
            // 初始化通知系统
            $this->notificationSystem = NotificationSystem::getInstance();
            
            // 加载告警历史记录
            $this->loadAlertHistory();
        } catch (Exception $e) {
            error_log('初始化异常检测系统失败: ' . $e->getMessage());
            throw new Exception('异常检测系统初始化失败');
        }
    }
    
    /**
     * 检测异常
     * @param string $metricName 指标名称
     * @param array $options 检测选项
     * @return array 检测结果
     */
    public function detectAnomaly($metricName, $options = []) {
        try {
            // 验证指标名称
            if (!in_array($metricName, $this->getSupportedMetrics())) {
                throw new InvalidArgumentException("不支持的指标名称: {$metricName}");
            }
            
            // 合并选项
            $defaultOptions = [
                'algorithm' => $this->config['algorithm']['default'],
                'time_range' => 'last_7_days',
                'auto_notify' => true,
                'severity' => 'warning',
            ];
            $options = array_merge($defaultOptions, $options);
            
            // 检查算法是否支持
            if (!in_array($options['algorithm'], $this->config['algorithm']['supported'])) {
                throw new InvalidArgumentException("不支持的算法: {$options['algorithm']}");
            }
            
            // 获取历史数据
            $historicalData = $this->getHistoricalData($metricName, $options['time_range']);
            
            // 根据选择的算法进行检测
            switch ($options['algorithm']) {
                case 'threshold':
                    $result = $this->detectAnomalyByThreshold($metricName, $historicalData, $options);
                    break;
                case 'statistical':
                    $result = $this->detectAnomalyByStatistical($metricName, $historicalData, $options);
                    break;
                case 'machine_learning':
                    $result = $this->detectAnomalyByMachineLearning($metricName, $historicalData, $options);
                    break;
                default:
                    throw new InvalidArgumentException("未知的检测算法: {$options['algorithm']}");
            }
            
            // 处理检测结果
            $processedResult = $this->processDetectionResult($metricName, $result, $options);
            
            // 如果检测到异常且启用了自动通知，则发送通知
            if ($processedResult['is_anomaly'] && $options['auto_notify']) {
                $this->sendAnomalyNotification($metricName, $processedResult, $options);
            }
            
            return $processedResult;
        } catch (Exception $e) {
            error_log("检测指标'{$metricName}'异常时出错: " . $e->getMessage());
            return [
                'is_anomaly' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
    
    /**
     * 批量检测异常
     * @param array $metrics 要检测的指标列表
     * @param array $options 检测选项
     * @return array 检测结果
     */
    public function detectAnomalies($metrics = [], $options = []) {
        $results = [];
        
        // 如果未指定指标，则检测所有支持的指标
        if (empty($metrics)) {
            $metrics = $this->getSupportedMetrics();
        }
        
        // 逐个检测指标
        foreach ($metrics as $metricName) {
            $results[$metricName] = $this->detectAnomaly($metricName, $options);
        }
        
        return $results;
    }
    
    /**
     * 阈值检测算法
     * @param string $metricName 指标名称
     * @param array $historicalData 历史数据
     * @param array $options 检测选项
     * @return array 检测结果
     */
    protected function detectAnomalyByThreshold($metricName, $historicalData, $options = []) {
        $result = [
            'is_anomaly' => false,
            'score' => 0,
            'reason' => '',
            'suggestion' => '',
            'metric' => $metricName,
            'current_value' => $historicalData['current'] ?? 0,
            'previous_value' => $historicalData['previous'] ?? 0,
            'trend' => 'stable',
        ];
        
        // 如果没有足够的数据
        if (!isset($historicalData['current']) || !isset($historicalData['previous'])) {
            $result['reason'] = '历史数据不足，无法进行检测';
            return $result;
        }
        
        // 计算变化率
        $changeRate = $this->calculateChangeRate($historicalData['current'], $historicalData['previous']);
        $result['change_rate'] = $changeRate;
        
        // 根据指标类型应用不同的阈值检测
        switch ($metricName) {
            case 'card_activation_rate':
                $result = $this->checkCardActivationAnomaly($result, $changeRate);
                break;
                
            case 'order_conversion_rate':
                $result = $this->checkOrderConversionAnomaly($result, $changeRate);
                break;
                
            case 'order_amount':
                $result = $this->checkOrderAmountAnomaly($result, $changeRate);
                break;
                
            case 'order_volume':
                $result = $this->checkOrderVolumeAnomaly($result, $changeRate);
                break;
                
            case 'new_users':
                $result = $this->checkNewUsersAnomaly($result, $changeRate);
                break;
                
            case 'active_users':
                $result = $this->checkActiveUsersAnomaly($result, $changeRate);
                break;
                
            case 'proxy_revenue':
                $result = $this->checkProxyRevenueAnomaly($result, $changeRate);
                break;
                
            case 'error_rate':
                $result = $this->checkErrorRateAnomaly($result, $changeRate);
                break;
                
            case 'payment_failure_rate':
                $result = $this->checkPaymentFailureAnomaly($result, $changeRate);
                break;
                
            case 'verification_error_rate':
                $result = $this->checkVerificationErrorAnomaly($result, $changeRate);
                break;
        }
        
        return $result;
    }
    
    /**
     * 统计检测算法
     * @param string $metricName 指标名称
     * @param array $historicalData 历史数据
     * @param array $options 检测选项
     * @return array 检测结果
     */
    protected function detectAnomalyByStatistical($metricName, $historicalData, $options = []) {
        $result = [
            'is_anomaly' => false,
            'score' => 0,
            'reason' => '',
            'suggestion' => '',
            'metric' => $metricName,
            'current_value' => $historicalData['current'] ?? 0,
        ];
        
        // 检查是否有足够的历史数据进行统计分析
        if (!isset($historicalData['time_series']) || count($historicalData['time_series']) < $this->config['statistical_detection']['min_samples']) {
            $result['reason'] = '历史数据不足，无法进行统计分析';
            return $result;
        }
        
        // 提取时间序列数据
        $values = array_column($historicalData['time_series'], 'value');
        $currentValue = $historicalData['current'] ?? end($values);
        
        // 计算统计量
        $mean = $this->calculateMean($values);
        $stdDev = $this->calculateStandardDeviation($values);
        $zScore = $stdDev > 0 ? ($currentValue - $mean) / $stdDev : 0;
        
        // 设置结果
        $result['mean'] = $mean;
        $result['std_dev'] = $stdDev;
        $result['z_score'] = $zScore;
        $result['threshold'] = $this->config['statistical_detection']['z_score_threshold'];
        
        // 判断是否异常
        if (abs($zScore) > $this->config['statistical_detection']['z_score_threshold']) {
            $result['is_anomaly'] = true;
            $result['score'] = abs($zScore);
            $result['reason'] = "统计异常: Z分数({$zScore})超过阈值({$this->config['statistical_detection']['z_score_threshold']})";
            $result['suggestion'] = $zScore > 0 ? "指标值({$currentValue})显著高于平均值({$mean})" : "指标值({$currentValue})显著低于平均值({$mean})";
        }
        
        // 考虑趋势和季节性
        if ($this->config['time_series']['consider_trend'] || $this->config['time_series']['consider_seasonality']) {
            // 应用时间序列调整
            $adjustedResult = $this->adjustForTimeSeries($metricName, $result, $historicalData);
            if ($adjustedResult) {
                $result = array_merge($result, $adjustedResult);
            }
        }
        
        return $result;
    }
    
    /**
     * 机器学习检测算法
     * @param string $metricName 指标名称
     * @param array $historicalData 历史数据
     * @param array $options 检测选项
     * @return array 检测结果
     */
    protected function detectAnomalyByMachineLearning($metricName, $historicalData, $options = []) {
        // 注意：这里实现一个简化版的机器学习检测
        // 实际应用中可能需要更复杂的算法和模型训练
        
        $result = [
            'is_anomaly' => false,
            'score' => 0,
            'reason' => '',
            'suggestion' => '',
            'metric' => $metricName,
            'current_value' => $historicalData['current'] ?? 0,
        ];
        
        // 检查是否有足够的历史数据
        if (!isset($historicalData['time_series']) || count($historicalData['time_series']) < $this->config['ml_detection']['train_period']) {
            $result['reason'] = '历史数据不足，无法进行机器学习分析';
            return $result;
        }
        
        // 提取时间序列数据
        $timeSeries = $historicalData['time_series'];
        $currentValue = $historicalData['current'] ?? end(array_column($timeSeries, 'value'));
        
        // 使用简单的预测模型 (线性回归)
        $predictionResult = $this->predictWithLinearRegression($timeSeries);
        $predictedValue = $predictionResult['predicted_value'];
        $errorMargin = $this->config['ml_detection']['error_margin'] / 100;
        $predictionInterval = [$predictedValue * (1 - $errorMargin), $predictedValue * (1 + $errorMargin)];
        
        // 设置结果
        $result['predicted_value'] = $predictedValue;
        $result['prediction_interval'] = $predictionInterval;
        $result['error_margin'] = $errorMargin;
        
        // 判断是否异常
        if ($currentValue < $predictionInterval[0] || $currentValue > $predictionInterval[1]) {
            $result['is_anomaly'] = true;
            $result['score'] = max(
                abs(($currentValue - $predictionInterval[0]) / $predictionInterval[0]),
                abs(($currentValue - $predictionInterval[1]) / $predictionInterval[1])
            ) * 100;
            $result['reason'] = "预测异常: 当前值({$currentValue})超出预测范围[{$predictionInterval[0]}, {$predictionInterval[1]}]";
            $result['suggestion'] = "预期值约为{$predictedValue}，建议调查此偏差";
        }
        
        return $result;
    }
    
    /**
     * 处理检测结果
     * @param string $metricName 指标名称
     * @param array $result 检测结果
     * @param array $options 检测选项
     * @return array 处理后的结果
     */
    protected function processDetectionResult($metricName, $result, $options = []) {
        // 添加基本信息
        $result['timestamp'] = time();
        $result['algorithm'] = $options['algorithm'] ?? $this->config['algorithm']['default'];
        $result['severity'] = $options['severity'] ?? 'warning';
        
        // 调整严重程度
        if ($result['is_anomaly']) {
            $result['severity'] = $this->determineSeverity($metricName, $result['score']);
        }
        
        // 检查告警冷却和抑制
        if ($result['is_anomaly']) {
            // 检查是否应该抑制告警
            if ($this->shouldSuppressAlert($metricName, $result)) {
                $result['is_anomaly'] = false;
                $result['suppressed'] = true;
                $result['suppression_reason'] = '类似告警已触发';
            } else {
                // 记录告警
                $this->recordAlert($metricName, $result);
            }
        }
        
        return $result;
    }
    
    /**
     * 发送异常通知
     * @param string $metricName 指标名称
     * @param array $result 检测结果
     * @param array $options 检测选项
     */
    protected function sendAnomalyNotification($metricName, $result, $options = []) {
        // 检查通知是否启用
        if (!$this->config['notification']['enabled']) {
            return;
        }
        
        try {
            // 根据严重程度获取通知渠道
            $severity = $result['severity'] ?? 'warning';
            $channels = isset($this->config['notification']['severity_mapping'][$severity])
                ? $this->config['notification']['severity_mapping'][$severity]
                : $this->config['notification']['channels'];
            
            // 如果没有通知渠道，直接返回
            if (empty($channels)) {
                return;
            }
            
            // 构建通知内容
            $notification = $this->buildNotificationContent($metricName, $result);
            
            // 发送通知
            foreach ($channels as $channel) {
                $this->notificationSystem->send($channel, $notification);
            }
        } catch (Exception $e) {
            error_log("发送异常通知失败: " . $e->getMessage());
        }
    }
    
    /**
     * 构建通知内容
     * @param string $metricName 指标名称
     * @param array $result 检测结果
     * @return array 通知内容
     */
    protected function buildNotificationContent($metricName, $result) {
        // 指标名称映射
        $metricNameMapping = [
            'card_activation_rate' => '卡密激活率',
            'order_conversion_rate' => '订单转化率',
            'order_amount' => '订单金额',
            'order_volume' => '订单量',
            'new_users' => '新增用户数',
            'active_users' => '活跃用户数',
            'proxy_revenue' => '代理收入',
            'error_rate' => '错误率',
            'payment_failure_rate' => '支付失败率',
            'verification_error_rate' => '卡密验证错误率',
        ];
        
        $metricDisplayName = isset($metricNameMapping[$metricName]) ? $metricNameMapping[$metricName] : $metricName;
        
        // 严重程度映射
        $severityMapping = [
            'critical' => '严重',
            'warning' => '警告',
            'info' => '信息',
        ];
        
        $severityDisplay = isset($severityMapping[$result['severity']]) ? $severityMapping[$result['severity']] : $result['severity'];
        
        // 构建标题和内容
        $title = "【业务异常预警】{$metricDisplayName}异常";
        $content = "检测到{$metricDisplayName}异常，严重程度: {$severityDisplay}\n";
        $content .= "异常原因: {$result['reason']}\n";
        $content .= "当前值: {$result['current_value']}\n";
        
        if (isset($result['previous_value'])) {
            $content .= "上期值: {$result['previous_value']}\n";
        }
        
        if (isset($result['change_rate'])) {
            $content .= "变化率: {$result['change_rate']}%\n";
        }
        
        if (isset($result['suggestion'])) {
            $content .= "建议: {$result['suggestion']}\n";
        }
        
        $content .= "检测时间: " . date('Y-m-d H:i:s') . "\n";
        $content .= "检测算法: {$result['algorithm']}\n";
        
        return [
            'title' => $title,
            'content' => $content,
            'severity' => $result['severity'],
            'metric' => $metricName,
            'timestamp' => $result['timestamp'],
        ];
    }
    
    /**
     * 获取历史数据
     * @param string $metricName 指标名称
     * @param string $timeRange 时间范围
     * @return array 历史数据
     */
    protected function getHistoricalData($metricName, $timeRange = 'last_7_days') {
        // 检查缓存
        $cacheKey = "{$metricName}_{$timeRange}";
        if (isset($this->historicalDataCache[$cacheKey])) {
            return $this->historicalDataCache[$cacheKey];
        }
        
        // 从指标收集器获取数据
        $data = [];
        
        try {
            // 根据指标类型获取不同的历史数据
            switch ($metricName) {
                case 'card_activation_rate':
                    $data = $this->getCardActivationRateData($timeRange);
                    break;
                case 'order_conversion_rate':
                    $data = $this->getOrderConversionRateData($timeRange);
                    break;
                case 'order_amount':
                    $data = $this->getOrderAmountData($timeRange);
                    break;
                case 'order_volume':
                    $data = $this->getOrderVolumeData($timeRange);
                    break;
                case 'new_users':
                    $data = $this->getNewUsersData($timeRange);
                    break;
                case 'active_users':
                    $data = $this->getActiveUsersData($timeRange);
                    break;
                case 'proxy_revenue':
                    $data = $this->getProxyRevenueData($timeRange);
                    break;
                case 'error_rate':
                    $data = $this->getErrorRateData($timeRange);
                    break;
                case 'payment_failure_rate':
                    $data = $this->getPaymentFailureRateData($timeRange);
                    break;
                case 'verification_error_rate':
                    $data = $this->getVerificationErrorRateData($timeRange);
                    break;
            }
            
            // 缓存数据
            $this->historicalDataCache[$cacheKey] = $data;
        } catch (Exception $e) {
            error_log("获取历史数据失败: " . $e->getMessage());
        }
        
        return $data;
    }
    
    /**
     * 检查是否应该抑制告警
     * @param string $metricName 指标名称
     * @param array $result 检测结果
     * @return bool 是否抑制
     */
    protected function shouldSuppressAlert($metricName, $result) {
        if (!$this->config['alert']['suppress_similar_alerts']) {
            return false;
        }
        
        // 获取最近的告警历史
        $recentAlerts = $this->getRecentAlerts($metricName);
        
        // 检查是否有相似的告警
        foreach ($recentAlerts as $alert) {
            // 检查时间间隔
            $timeDiff = time() - $alert['timestamp'];
            if ($timeDiff < $this->config['alert']['alert_cooldown'] * 60) {
                // 计算相似度
                $similarity = $this->calculateAlertSimilarity($result, $alert);
                
                // 如果相似度超过阈值，则抑制告警
                if ($similarity >= $this->config['alert']['similarity_threshold']) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 记录告警
     * @param string $metricName 指标名称
     * @param array $result 检测结果
     */
    protected function recordAlert($metricName, $result) {
        $alert = [
            'metric' => $metricName,
            'timestamp' => time(),
            'score' => $result['score'],
            'severity' => $result['severity'],
            'current_value' => $result['current_value'],
            'previous_value' => $result['previous_value'] ?? 0,
            'change_rate' => $result['change_rate'] ?? 0,
            'reason' => $result['reason'],
            'status' => 'active',
        ];
        
        // 保存告警
        $this->alertHistory[] = $alert;
        
        // 保存到数据库 (这里简化处理)
        $this->saveAlertToDatabase($alert);
    }
    
    /**
     * 计算告警相似度
     * @param array $alert1 告警1
     * @param array $alert2 告警2
     * @return float 相似度(0-100)
     */
    protected function calculateAlertSimilarity($alert1, $alert2) {
        // 简单的相似度计算
        $similarity = 0;
        
        // 检查值变化范围
        if (isset($alert1['change_rate']) && isset($alert2['change_rate'])) {
            $changeDiff = abs($alert1['change_rate'] - $alert2['change_rate']);
            $maxChange = max(abs($alert1['change_rate']), abs($alert2['change_rate']));
            $similarity += $maxChange > 0 ? (1 - $changeDiff / $maxChange) * 60 : 60;
        }
        
        // 检查严重程度
        if ($alert1['severity'] === $alert2['severity']) {
            $similarity += 20;
        }
        
        // 检查原因相似度 (简单实现)
        if (isset($alert1['reason']) && isset($alert2['reason'])) {
            $commonWords = $this->countCommonWords($alert1['reason'], $alert2['reason']);
            $totalWords = $this->countWords($alert1['reason']) + $this->countWords($alert2['reason']) - $commonWords;
            $similarity += $totalWords > 0 ? ($commonWords / $totalWords) * 20 : 0;
        }
        
        return min($similarity, 100);
    }
    
    /**
     * 计算变化率
     * @param float $current 当前值
     * @param float $previous 先前值
     * @return float 变化率(%)
     */
    protected function calculateChangeRate($current, $previous) {
        if ($previous == 0) {
            return $current > 0 ? 100 : 0;
        }
        return (($current - $previous) / $previous) * 100;
    }
    
    /**
     * 计算平均值
     * @param array $values 数值数组
     * @return float 平均值
     */
    protected function calculateMean($values) {
        if (empty($values)) {
            return 0;
        }
        return array_sum($values) / count($values);
    }
    
    /**
     * 计算标准差
     * @param array $values 数值数组
     * @return float 标准差
     */
    protected function calculateStandardDeviation($values) {
        if (empty($values) || count($values) == 1) {
            return 0;
        }
        
        $mean = $this->calculateMean($values);
        $squaredDiffs = array_map(function($value) use ($mean) {
            return pow($value - $mean, 2);
        }, $values);
        
        $variance = array_sum($squaredDiffs) / (count($values) - 1);
        return sqrt($variance);
    }
    
    /**
     * 使用线性回归预测
     * @param array $timeSeries 时间序列数据
     * @return array 预测结果
     */
    protected function predictWithLinearRegression($timeSeries) {
        $n = count($timeSeries);
        
        // 准备数据
        $x = [];
        $y = [];
        
        for ($i = 0; $i < $n; $i++) {
            $x[] = $i; // 使用索引作为x值
            $y[] = $timeSeries[$i]['value'] ?? 0;
        }
        
        // 计算线性回归参数
        $sumX = array_sum($x);
        $sumY = array_sum($y);
        $sumXY = 0;
        $sumX2 = 0;
        
        for ($i = 0; $i < $n; $i++) {
            $sumXY += $x[$i] * $y[$i];
            $sumX2 += $x[$i] * $x[$i];
        }
        
        // 计算斜率和截距
        $slope = ($n * $sumXY - $sumX * $sumY) / ($n * $sumX2 - $sumX * $sumX);
        $intercept = ($sumY - $slope * $sumX) / $n;
        
        // 预测下一个值
        $nextX = $n;
        $predictedValue = $slope * $nextX + $intercept;
        
        return [
            'predicted_value' => $predictedValue,
            'slope' => $slope,
            'intercept' => $intercept,
        ];
    }
    
    /**
     * 确定严重程度
     * @param string $metricName 指标名称
     * @param float $score 异常分数
     * @return string 严重程度
     */
    protected function determineSeverity($metricName, $score) {
        // 基于分数确定严重程度
        if ($score >= 5) {
            return 'critical';
        } elseif ($score >= 2) {
            return 'warning';
        } else {
            return 'info';
        }
    }
    
    /**
     * 获取支持的指标列表
     * @return array 指标列表
     */
    public function getSupportedMetrics() {
        return [
            'card_activation_rate',
            'order_conversion_rate',
            'order_amount',
            'order_volume',
            'new_users',
            'active_users',
            'proxy_revenue',
            'error_rate',
            'payment_failure_rate',
            'verification_error_rate',
        ];
    }
    
    /**
     * 检查卡密激活率异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkCardActivationAnomaly($result, $changeRate) {
        // 检查最低阈值
        if ($result['current_value'] < $this->config['threshold_detection']['card_activation_rate_min']) {
            $result['is_anomaly'] = true;
            $result['score'] = 3;
            $result['reason'] = "卡密激活率({$result['current_value']}%)低于最低阈值({$this->config['threshold_detection']['card_activation_rate_min']}%)";
            $result['suggestion'] = "建议检查卡密发放流程和用户激活引导";
            $result['trend'] = 'down';
        } 
        // 检查变化率
        elseif (abs($changeRate) >= $this->config['threshold_detection']['card_activation_rate_change']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2;
            $result['reason'] = "卡密激活率变化率({$changeRate}%)超过阈值({$this->config['threshold_detection']['card_activation_rate_change']}%)";
            $result['suggestion'] = $changeRate > 0 ? "激活率大幅提升，建议确认是否有促销活动" : "激活率大幅下降，建议检查卡密质量和发放渠道";
            $result['trend'] = $changeRate > 0 ? 'up' : 'down';
        }
        // 检查骤增
        elseif ($changeRate >= $this->config['threshold_detection']['card_activation_spike']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2.5;
            $result['reason'] = "卡密激活率骤增({$changeRate}%)，超过阈值({$this->config['threshold_detection']['card_activation_spike']}%)";
            $result['suggestion'] = "建议确认是否有异常批量激活行为";
            $result['trend'] = 'up';
        }
        
        return $result;
    }
    
    /**
     * 检查订单转化率异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkOrderConversionAnomaly($result, $changeRate) {
        // 检查最低阈值
        if ($result['current_value'] < $this->config['threshold_detection']['order_conversion_rate_min']) {
            $result['is_anomaly'] = true;
            $result['score'] = 3;
            $result['reason'] = "订单转化率({$result['current_value']}%)低于最低阈值({$this->config['threshold_detection']['order_conversion_rate_min']}%)";
            $result['suggestion'] = "建议检查商品定价、用户体验和购买流程";
            $result['trend'] = 'down';
        }
        // 检查变化率
        elseif (abs($changeRate) >= $this->config['threshold_detection']['order_conversion_rate_change']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2;
            $result['reason'] = "订单转化率变化率({$changeRate}%)超过阈值({$this->config['threshold_detection']['order_conversion_rate_change']}%)";
            $result['suggestion'] = $changeRate > 0 ? "转化率提升，保持现有策略" : "转化率下降，建议检查价格敏感度和竞争对手活动";
            $result['trend'] = $changeRate > 0 ? 'up' : 'down';
        }
        
        return $result;
    }
    
    /**
     * 检查订单金额异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkOrderAmountAnomaly($result, $changeRate) {
        // 检查变化率
        if (abs($changeRate) >= $this->config['threshold_detection']['order_amount_change']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2;
            $result['reason'] = "订单金额变化率({$changeRate}%)超过阈值({$this->config['threshold_detection']['order_amount_change']}%)";
            $result['suggestion'] = $changeRate > 0 ? "订单金额增加，检查是否有大额订单或价格调整" : "订单金额下降，检查销售策略和客户购买力";
            $result['trend'] = $changeRate > 0 ? 'up' : 'down';
        }
        
        return $result;
    }
    
    /**
     * 检查订单量异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkOrderVolumeAnomaly($result, $changeRate) {
        // 检查骤增
        if ($changeRate >= $this->config['threshold_detection']['order_volume_spike']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2.5;
            $result['reason'] = "订单量骤增({$changeRate}%)，超过阈值({$this->config['threshold_detection']['order_volume_spike']}%)";
            $result['suggestion'] = "建议确认是否有营销活动或异常下单行为";
            $result['trend'] = 'up';
        }
        
        return $result;
    }
    
    /**
     * 检查新增用户异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkNewUsersAnomaly($result, $changeRate) {
        // 检查变化率
        if (abs($changeRate) >= $this->config['threshold_detection']['new_users_change']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2;
            $result['reason'] = "新增用户变化率({$changeRate}%)超过阈值({$this->config['threshold_detection']['new_users_change']}%)";
            $result['suggestion'] = $changeRate > 0 ? "用户增长迅速，检查营销渠道效果" : "用户增长放缓，考虑增加获客渠道";
            $result['trend'] = $changeRate > 0 ? 'up' : 'down';
        }
        
        return $result;
    }
    
    /**
     * 检查活跃用户异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkActiveUsersAnomaly($result, $changeRate) {
        // 检查变化率
        if (abs($changeRate) >= $this->config['threshold_detection']['user_active_change']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2;
            $result['reason'] = "活跃用户变化率({$changeRate}%)超过阈值({$this->config['threshold_detection']['user_active_change']}%)";
            $result['suggestion'] = $changeRate > 0 ? "用户活跃度提升，继续保持" : "用户活跃度下降，建议改善产品体验";
            $result['trend'] = $changeRate > 0 ? 'up' : 'down';
        }
        
        return $result;
    }
    
    /**
     * 检查代理收入异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkProxyRevenueAnomaly($result, $changeRate) {
        // 检查变化率
        if (abs($changeRate) >= $this->config['threshold_detection']['proxy_revenue_change']) {
            $result['is_anomaly'] = true;
            $result['score'] = 2;
            $result['reason'] = "代理收入变化率({$changeRate}%)超过阈值({$this->config['threshold_detection']['proxy_revenue_change']}%)";
            $result['suggestion'] = $changeRate > 0 ? "代理业绩提升，考虑给予激励" : "代理业绩下滑，建议提供支持和培训";
            $result['trend'] = $changeRate > 0 ? 'up' : 'down';
        }
        
        return $result;
    }
    
    /**
     * 检查错误率异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkErrorRateAnomaly($result, $changeRate) {
        // 检查最高阈值
        if ($result['current_value'] > $this->config['threshold_detection']['error_rate_max']) {
            $result['is_anomaly'] = true;
            $result['score'] = 3.5;
            $result['reason'] = "错误率({$result['current_value']}%)超过最高阈值({$this->config['threshold_detection']['error_rate_max']}%)";
            $result['suggestion'] = "建议立即检查系统日志和错误原因";
            $result['trend'] = 'up';
        }
        
        return $result;
    }
    
    /**
     * 检查支付失败率异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkPaymentFailureAnomaly($result, $changeRate) {
        // 检查最高阈值
        if ($result['current_value'] > $this->config['threshold_detection']['payment_failure_rate']) {
            $result['is_anomaly'] = true;
            $result['score'] = 3.5;
            $result['reason'] = "支付失败率({$result['current_value']}%)超过最高阈值({$this->config['threshold_detection']['payment_failure_rate']}%)";
            $result['suggestion'] = "建议立即检查支付接口和支付流程";
            $result['trend'] = 'up';
        }
        
        return $result;
    }
    
    /**
     * 检查卡密验证错误率异常
     * @param array $result 初始结果
     * @param float $changeRate 变化率
     * @return array 更新后的结果
     */
    protected function checkVerificationErrorAnomaly($result, $changeRate) {
        // 检查最高阈值
        if ($result['current_value'] > $this->config['threshold_detection']['verification_error_rate']) {
            $result['is_anomaly'] = true;
            $result['score'] = 3.5;
            $result['reason'] = "卡密验证错误率({$result['current_value']}%)超过最高阈值({$this->config['threshold_detection']['verification_error_rate']}%)";
            $result['suggestion'] = "建议检查卡密生成和验证系统";
            $result['trend'] = 'up';
        }
        
        return $result;
    }
    
    /**
     * 获取卡密激活率历史数据
     * @param string $timeRange 时间范围
     * @return array 历史数据
     */
    protected function getCardActivationRateData($timeRange) {
        try {
            // 从指标收集器获取数据
            $data = $this->metricsCollector->getCardActivationRate($timeRange);
            
            // 获取时间序列数据
            $timeSeries = $this->metricsCollector->getMetricsTrend('activation_rate', $timeRange);
            
            return [
                'current' => $data['rate'] ?? 0,
                'previous' => $data['previous_rate'] ?? 0,
                'time_series' => $timeSeries,
            ];
        } catch (Exception $e) {
            return ['current' => 0, 'previous' => 0, 'time_series' => []];
        }
    }
    
    /**
     * 获取订单转化率历史数据
     * @param string $timeRange 时间范围
     * @return array 历史数据
     */
    protected function getOrderConversionRateData($timeRange) {
        try {
            // 从指标收集器获取数据
            $data = $this->metricsCollector->getOrderConversionRate($timeRange);
            
            // 获取时间序列数据
            $timeSeries = $this->metricsCollector->getMetricsTrend('conversion_rate', $timeRange);
            
            return [
                'current' => $data['rate'] ?? 0,
                'previous' => $data['previous_rate'] ?? 0,
                'time_series' => $timeSeries,
            ];
        } catch (Exception $e) {
            return ['current' => 0, 'previous' => 0, 'time_series' => []];
        }
    }
    
    // 其他指标的历史数据获取方法...
    
    /**
     * 获取最近的告警
     * @param string $metricName 指标名称
     * @param int $limit 限制数量
     * @return array 最近的告警
     */
    protected function getRecentAlerts($metricName, $limit = 10) {
        $alerts = [];
        
        foreach ($this->alertHistory as $alert) {
            if ($alert['metric'] === $metricName) {
                $alerts[] = $alert;
            }
        }
        
        // 按时间排序
        usort($alerts, function($a, $b) {
            return $b['timestamp'] - $a['timestamp'];
        });
        
        // 限制数量
        return array_slice($alerts, 0, $limit);
    }
    
    /**
     * 加载告警历史
     */
    protected function loadAlertHistory() {
        // 从数据库加载告警历史 (简化处理)
        $this->alertHistory = [];
    }
    
    /**
     * 保存告警到数据库
     * @param array $alert 告警数据
     */
    protected function saveAlertToDatabase($alert) {
        // 简化处理，实际应该保存到数据库
        error_log("保存告警: " . json_encode($alert));
    }
    
    /**
     * 计算两个字符串的共同词数
     * @param string $str1 字符串1
     * @param string $str2 字符串2
     * @return int 共同词数
     */
    protected function countCommonWords($str1, $str2) {
        $words1 = $this->extractWords($str1);
        $words2 = $this->extractWords($str2);
        
        return count(array_intersect($words1, $words2));
    }
    
    /**
     * 计算字符串的词数
     * @param string $str 字符串
     * @return int 词数
     */
    protected function countWords($str) {
        return count($this->extractWords($str));
    }
    
    /**
     * 提取字符串中的词语
     * @param string $str 字符串
     * @return array 词语数组
     */
    protected function extractWords($str) {
        // 简单的分词实现
        $str = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $str);
        $str = mb_strtolower($str, 'UTF-8');
        return array_filter(preg_split('/\s+/', $str));
    }
    
    /**
     * 调整时间序列影响
     * @param string $metricName 指标名称
     * @param array $result 检测结果
     * @param array $historicalData 历史数据
     * @return array|null 调整后的数据
     */
    protected function adjustForTimeSeries($metricName, $result, $historicalData) {
        // 简化实现，实际应该考虑趋势和季节性
        return null;
    }
}