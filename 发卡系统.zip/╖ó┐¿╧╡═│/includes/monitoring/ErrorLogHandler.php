<?php
/**
 * 错误日志处理器
 * 负责监控系统错误日志，分析错误模式，并将严重错误转发给报警系统
 */

// 引入通知系统
require_once __DIR__ . '/NotificationSystem.php';

class ErrorLogHandler {
    /**
     * 配置信息
     * @var array
     */
    protected $config = [
        // 日志文件路径配置
        'log_files' => [
            'error' => '/logs/error.log',
            'payment' => '/logs/payment.log',
            'card' => '/logs/card.log',
            'api' => '/logs/api.log',
            'system' => '/logs/system.log',
        ],
        
        // 检查间隔（秒）
        'check_interval' => 60,
        
        // 日志文件编码
        'log_encoding' => 'UTF-8',
        
        // 最大文件大小（MB），超过将进行归档
        'max_log_size_mb' => 50,
        
        // 错误日志自动清理（天）
        'log_retention_days' => 30,
        
        // 是否启用实时监控
        'realtime_monitoring' => true,
        
        // 忽略的错误模式
        'ignore_patterns' => [
            'DEBUG:',
            'Notice:',
            'Strict Standards:',
            'Deprecated:',
        ],
        
        // 错误分类配置
        'error_categories' => [
            // 关键业务错误
            'business_critical' => [
                'patterns' => [
                    '支付失败',
                    'Transaction Failed',
                    '卡密验证异常',
                    'Invalid Card',
                    'Verification Failed',
                    'Order Processing Error',
                    '订单处理错误',
                    '数据库连接失败',
                    'Database Connection Failed',
                ],
                'min_severity' => 'critical',
                'notification_required' => true,
            ],
            
            // 安全相关错误
            'security' => [
                'patterns' => [
                    'Authentication Failed',
                    '登录失败',
                    'Invalid Token',
                    'Security Violation',
                    'SQL Injection Attempt',
                    'XSS Attack',
                    'CSRF Token Error',
                ],
                'min_severity' => 'warning',
                'notification_required' => true,
            ],
            
            // 系统错误
            'system' => [
                'patterns' => [
                    'Fatal error',
                    'Fatal Error',
                    'Segmentation Fault',
                    '内存不足',
                    'Out of Memory',
                    'File Permission Error',
                    '文件权限错误',
                ],
                'min_severity' => 'critical',
                'notification_required' => true,
            ],
            
            // 应用逻辑错误
            'application' => [
                'patterns' => [
                    'Logic Error',
                    '业务逻辑错误',
                    'Undefined index',
                    'Undefined variable',
                    'Undefined offset',
                    'Cannot use object of type',
                    'Type error',
                    'TypeError',
                ],
                'min_severity' => 'warning',
                'notification_required' => false,
            ],
        ],
        
        // 错误统计配置
        'error_statistics' => [
            'enabled' => true,
            'sampling_interval' => 5, // 分钟
        ],
        
        // 错误日志格式正则表达式
        'log_format_regex' => '/^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] (.+)\[(\d+)\]: (\w+): (.+)$/',
    ];
    
    /**
     * AlarmSystem实例
     * @var AlarmSystem
     */
    protected $alarmSystem = null;
    
    /**
     * 通知系统实例
     * @var NotificationSystem
     */
    protected $notificationSystem = null;
    
    /**
     * 日志文件处理状态
     * @var array
     */
    protected $fileStatus = [];
    
    /**
     * 错误计数器
     * @var array
     */
    protected $errorCounters = [];
    
    /**
     * 上次统计时间
     * @var int
     */
    protected $lastStatisticsTime = 0;
    
    /**
     * 单例实例
     * @var ErrorLogHandler
     */
    protected static $instance = null;
    
    /**
     * 构造函数
     * @param array $config 配置信息
     */
    private function __construct($config = []) {
        // 合并配置
        $this->config = array_merge_recursive($this->config, $config);
        
        // 初始化报警系统
        if (class_exists('AlarmSystem')) {
            $this->alarmSystem = AlarmSystem::getInstance();
        }
        
        // 初始化通知系统
        $this->initializeNotificationSystem();
        
        // 初始化文件状态
        $this->initializeFileStatus();
        
        // 初始化错误计数器
        $this->initializeErrorCounters();
        
        // 记录上次统计时间
        $this->lastStatisticsTime = time();
        
        // 立即执行一次日志检查
        $this->checkAllLogFiles();
    }
    
    /**
     * 获取单例实例
     * @param array $config 配置信息
     * @return ErrorLogHandler
     */
    public static function getInstance($config = []) {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
        return self::$instance;
    }
    
    /**
     * 初始化文件状态
     */
    protected function initializeFileStatus() {
        foreach ($this->config['log_files'] as $type => $path) {
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . $path;
            $this->fileStatus[$type] = [
                'path' => $path,
                'full_path' => $fullPath,
                'last_size' => file_exists($fullPath) ? filesize($fullPath) : 0,
                'last_checked' => time(),
                'error_count' => 0,
            ];
        }
    }
    
    /**
     * 初始化错误计数器
     */
    protected function initializeErrorCounters() {
        foreach (array_keys($this->config['error_categories']) as $category) {
            $this->errorCounters[$category] = 0;
        }
        $this->errorCounters['total'] = 0;
    }
    
    /**
     * 检查所有日志文件
     */
    public function checkAllLogFiles() {
        foreach (array_keys($this->config['log_files']) as $type) {
            $this->checkLogFile($type);
        }
        
        // 检查是否需要进行统计
        $this->checkAndRunStatistics();
    }
    
    /**
     * 检查指定的日志文件
     * @param string $type 日志类型
     * @return int 新发现的错误数量
     */
    public function checkLogFile($type) {
        // 检查是否有该类型的日志配置
        if (!isset($this->fileStatus[$type])) {
            error_log("未知的日志类型: {$type}");
            return 0;
        }
        
        $fileStatus = &$this->fileStatus[$type];
        
        // 检查文件是否存在
        if (!file_exists($fileStatus['full_path'])) {
            // 如果文件不存在但之前存在过，可能是被轮转或删除了
            if ($fileStatus['last_size'] > 0) {
                error_log("日志文件已被删除或轮转: {$fileStatus['path']}");
                $fileStatus['last_size'] = 0;
                $fileStatus['error_count'] = 0;
            }
            return 0;
        }
        
        // 获取当前文件大小
        $currentSize = filesize($fileStatus['full_path']);
        
        // 如果文件大小小于上次检查时的大小，说明文件被轮转或重置
        if ($currentSize < $fileStatus['last_size']) {
            $fileStatus['last_size'] = 0;
            $fileStatus['error_count'] = 0;
        }
        
        // 如果文件大小没有变化，不需要检查
        if ($currentSize == $fileStatus['last_size']) {
            return 0;
        }
        
        // 计算需要读取的字节数
        $bytesToRead = $currentSize - $fileStatus['last_size'];
        
        // 打开文件并定位到上次读取的位置
        $handle = fopen($fileStatus['full_path'], 'r');
        if (!$handle) {
            error_log("无法打开日志文件: {$fileStatus['path']}");
            return 0;
        }
        
        // 移动到上次读取的位置
        fseek($handle, $fileStatus['last_size']);
        
        // 读取新增内容
        $newContent = fread($handle, $bytesToRead);
        fclose($handle);
        
        // 更新文件状态
        $fileStatus['last_size'] = $currentSize;
        $fileStatus['last_checked'] = time();
        
        // 处理新增内容
        return $this->processNewLogContent($newContent, $type);
    }
    
    /**
     * 处理新的日志内容
     * @param string $content 新内容
     * @param string $logType 日志类型
     * @return int 发现的错误数量
     */
    protected function processNewLogContent($content, $logType) {
        // 根据换行符分割日志行
        $lines = explode(PHP_EOL, $content);
        $errorCount = 0;
        
        // 处理每一行日志
        foreach ($lines as $line) {
            // 跳过空行
            if (trim($line) === '') {
                continue;
            }
            
            // 跳过忽略的模式
            if ($this->shouldIgnoreLine($line)) {
                continue;
            }
            
            // 分析日志行
            $errorInfo = $this->parseLogLine($line, $logType);
            
            // 如果识别为错误，进行处理
            if ($errorInfo && $errorInfo['is_error']) {
                // 处理错误
                $this->handleError($errorInfo, $line);
                $errorCount++;
            }
        }
        
        return $errorCount;
    }
    
    /**
     * 检查是否应该忽略该行日志
     * @param string $line 日志行
     * @return bool 是否忽略
     */
    protected function shouldIgnoreLine($line) {
        foreach ($this->config['ignore_patterns'] as $pattern) {
            if (stripos($line, $pattern) !== false) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 解析日志行，提取错误信息
     * @param string $line 日志行
     * @param string $logType 日志类型
     * @return array 解析后的错误信息
     */
    protected function parseLogLine($line, $logType) {
        $result = [
            'raw_line' => $line,
            'log_type' => $logType,
            'timestamp' => null,
            'source' => null,
            'error_level' => null,
            'message' => null,
            'category' => 'unknown',
            'severity' => 'info',
            'is_error' => false,
            'notification_required' => false,
        ];
        
        // 使用正则表达式解析标准格式的日志行
        if (preg_match($this->config['log_format_regex'], $line, $matches)) {
            $result['timestamp'] = $matches[1];
            $result['source'] = $matches[2];
            $result['error_level'] = $matches[4];
            $result['message'] = $matches[5];
        } else {
            // 如果无法匹配标准格式，将整行作为消息
            $result['message'] = $line;
            
            // 尝试从消息中提取错误级别
            if (preg_match('/(ERROR|WARNING|FATAL|CRITICAL|INFO|DEBUG)/i', $line, $levelMatch)) {
                $result['error_level'] = $levelMatch[1];
            }
        }
        
        // 确定错误严重性
        $result['severity'] = $this->determineSeverity($result['error_level'], $result['message']);
        
        // 确定错误类别
        $result['category'] = $this->categorizeError($result['message']);
        
        // 判断是否需要通知
        $result['notification_required'] = $this->shouldSendNotification($result['severity'], $result['category']);
        
        // 判断是否为错误
        $result['is_error'] = $result['severity'] !== 'info' && $result['severity'] !== 'debug';
        
        return $result;
    }
    
    /**
     * 根据错误级别和消息确定严重性
     * @param string $errorLevel 错误级别
     * @param string $message 错误消息
     * @return string 严重性级别
     */
    protected function determineSeverity($errorLevel, $message) {
        // 默认严重性
        $severity = 'info';
        
        // 根据错误级别确定
        if ($errorLevel) {
            $errorLevel = strtoupper($errorLevel);
            switch ($errorLevel) {
                case 'CRITICAL':
                case 'FATAL':
                case 'EMERGENCY':
                case 'ALERT':
                    $severity = 'critical';
                    break;
                case 'ERROR':
                case 'WARNING':
                    $severity = 'warning';
                    break;
                case 'INFO':
                    $severity = 'info';
                    break;
                case 'DEBUG':
                    $severity = 'debug';
                    break;
            }
        }
        
        // 根据消息内容调整严重性
        $criticalPatterns = [
            '支付失败',
            'Transaction Failed',
            '卡密验证异常',
            '数据库连接失败',
            'Fatal error',
            '内存不足',
            'Out of Memory',
            'Segmentation Fault',
            '登录失败',
            'Authentication Failed',
        ];
        
        foreach ($criticalPatterns as $pattern) {
            if (stripos($message, $pattern) !== false) {
                return 'critical';
            }
        }
        
        $warningPatterns = [
            'Warning:',
            'Warning ',
            '错误:',
            'Error:',
            'Invalid',
            'Failed to',
            'Cannot',
            'SQL Error',
            '数据库错误',
        ];
        
        foreach ($warningPatterns as $pattern) {
            if (stripos($message, $pattern) !== false && $severity !== 'critical') {
                return 'warning';
            }
        }
        
        return $severity;
    }
    
    /**
     * 对错误进行分类
     * @param string $message 错误消息
     * @return string 错误类别
     */
    protected function categorizeError($message) {
        // 默认类别
        $category = 'unknown';
        $highestPriority = 0;
        
        // 检查每个类别
        foreach ($this->config['error_categories'] as $catName => $catConfig) {
            $priority = 0;
            
            foreach ($catConfig['patterns'] as $pattern) {
                if (stripos($message, $pattern) !== false) {
                    $priority++;
                }
            }
            
            // 选择匹配模式最多的类别
            if ($priority > $highestPriority) {
                $highestPriority = $priority;
                $category = $catName;
            }
        }
        
        return $category;
    }
    
    /**
     * 判断是否需要发送通知
     * @param string $severity 严重性
     * @param string $category 错误类别
     * @return bool 是否需要发送通知
     */
    protected function shouldSendNotification($severity, $category) {
        // 如果严重性为critical，总是发送通知
        if ($severity === 'critical') {
            return true;
        }
        
        // 检查类别配置
        if (isset($this->config['error_categories'][$category])) {
            $catConfig = $this->config['error_categories'][$category];
            
            if ($catConfig['notification_required']) {
                // 检查最小严重性要求
                $severityLevels = ['info', 'warning', 'critical'];
                $severityIndex = array_search($severity, $severityLevels);
                $minSeverityIndex = array_search($catConfig['min_severity'], $severityLevels);
                
                if ($severityIndex !== false && $minSeverityIndex !== false && 
                    $severityIndex >= $minSeverityIndex) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 处理错误
     * @param array $errorInfo 错误信息
     * @param string $rawLine 原始日志行
     */
    protected function handleError(array $errorInfo, $rawLine) {
        // 更新错误计数器
        $this->errorCounters[$errorInfo['category']]++;
        $this->errorCounters['total']++;
        
        // 记录到错误统计
        $this->logErrorToStatistics($errorInfo);
        
        // 如果需要通知，发送到报警系统
        if ($errorInfo['notification_required'] && $this->alarmSystem !== null) {
            $this->sendToAlarmSystem($errorInfo, $rawLine);
        }
        
        // 记录到系统日志
        $this->logError($errorInfo, $rawLine);
    }
    
    /**
     * 初始化通知系统
     */
    protected function initializeNotificationSystem() {
        try {
            $this->notificationSystem = NotificationSystem::getInstance();
        } catch (Exception $e) {
            error_log('初始化通知系统失败: ' . $e->getMessage());
            $this->notificationSystem = null;
        }
    }
    
    /**
     * 将错误发送到报警系统
     * @param array $errorInfo 错误信息
     * @param string $rawLine 原始日志行
     */
    protected function sendToAlarmSystem(array $errorInfo, $rawLine) {
        // 根据错误类型和消息创建报警
        $alarmType = 'error_' . $errorInfo['category'];
        $alarmTitle = $this->generateAlarmTitle($errorInfo);
        $alarmMessage = $this->generateAlarmMessage($errorInfo, $rawLine);
        
        // 构建元数据
        $metadata = [
            'log_type' => $errorInfo['log_type'],
            'timestamp' => $errorInfo['timestamp'],
            'source' => $errorInfo['source'],
            'error_level' => $errorInfo['error_level'],
            'category' => $errorInfo['category'],
            'raw_line' => $rawLine,
        ];
        
        // 发送报警
        $this->alarmSystem->triggerAlarm([
            'type' => $alarmType,
            'severity' => $errorInfo['severity'],
            'title' => $alarmTitle,
            'message' => $alarmMessage,
            'source' => 'error_log_handler',
            'metadata' => $metadata,
        ]);
        
        // 通过通知系统发送通知
        if ($this->notificationSystem) {
            $this->sendThroughNotificationSystem($errorInfo, $rawLine);
        }
    }
    
    /**
     * 通过通知系统发送通知
     * @param array $errorInfo 错误信息
     * @param string $rawLine 原始日志行
     */
    protected function sendThroughNotificationSystem(array $errorInfo, $rawLine) {
        try {
            // 根据错误严重性确定通知级别
            $notificationLevel = $this->getNotificationLevel($errorInfo['severity']);
            
            // 构建通知内容
            $title = "[错误报警] {$this->getSeverityName($errorInfo['severity'])}级别错误: {$errorInfo['message']}";
            $message = "错误类别: {$errorInfo['category']}\n" .
                      "日志类型: {$errorInfo['log_type']}\n" .
                      "错误级别: {$errorInfo['error_level']}\n" .
                      "发生时间: {$errorInfo['timestamp']}\n" .
                      "原始日志: {$rawLine}";
            
            // 发送通知
            $this->notificationSystem->send([
                'level' => $notificationLevel,
                'title' => $title,
                'message' => $message,
                'metadata' => [
                    'error_info' => $errorInfo,
                    'raw_line' => $rawLine
                ]
            ]);
        } catch (Exception $e) {
            error_log('通过通知系统发送错误通知失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取通知级别
     * @param string $severity 错误严重性
     * @return string 通知级别
     */
    protected function getNotificationLevel($severity) {
        switch ($severity) {
            case 'critical':
                return NotificationSystem::LEVEL_CRITICAL;
            case 'warning':
                return NotificationSystem::LEVEL_WARNING;
            case 'info':
            case 'debug':
                return NotificationSystem::LEVEL_INFO;
            default:
                return NotificationSystem::LEVEL_WARNING;
        }
    }
    
    /**
     * 生成报警标题
     * @param array $errorInfo 错误信息
     * @return string 报警标题
     */
    protected function generateAlarmTitle(array $errorInfo) {
        // 获取类别名称的中文翻译
        $categoryNames = [
            'business_critical' => '业务关键错误',
            'security' => '安全错误',
            'system' => '系统错误',
            'application' => '应用程序错误',
            'unknown' => '未知错误',
        ];
        
        $categoryName = $categoryNames[$errorInfo['category']] ?? $errorInfo['category'];
        $logTypeName = $this->getLogTypeName($errorInfo['log_type']);
        
        return "[{$logTypeName}] {$categoryName}";
    }
    
    /**
     * 获取日志类型的可读名称
     * @param string $logType 日志类型
     * @return string 可读名称
     */
    protected function getLogTypeName($logType) {
        $logTypeNames = [
            'error' => '错误日志',
            'payment' => '支付日志',
            'card' => '卡密日志',
            'api' => 'API日志',
            'system' => '系统日志',
        ];
        
        return $logTypeNames[$logType] ?? $logType;
    }
    
    /**
     * 生成报警消息
     * @param array $errorInfo 错误信息
     * @param string $rawLine 原始日志行
     * @return string 报警消息
     */
    protected function generateAlarmMessage(array $errorInfo, $rawLine) {
        $message = "发现{$this->getSeverityName($errorInfo['severity'])}级别错误:\n";
        $message .= "错误类别: {$errorInfo['category']}\n";
        $message .= "日志类型: {$errorInfo['log_type']}\n";
        
        if ($errorInfo['timestamp']) {
            $message .= "发生时间: {$errorInfo['timestamp']}\n";
        }
        
        if ($errorInfo['source']) {
            $message .= "错误源: {$errorInfo['source']}\n";
        }
        
        $message .= "错误信息: {$errorInfo['message']}\n\n";
        $message .= "原始日志行: {$rawLine}";
        
        return $message;
    }
    
    /**
     * 获取严重性的可读名称
     * @param string $severity 严重性
     * @return string 可读名称
     */
    protected function getSeverityName($severity) {
        $severityNames = [
            'critical' => '严重',
            'warning' => '警告',
            'info' => '信息',
            'debug' => '调试',
        ];
        
        return $severityNames[$severity] ?? $severity;
    }
    
    /**
     * 将错误记录到统计
     * @param array $errorInfo 错误信息
     */
    protected function logErrorToStatistics(array $errorInfo) {
        // 这里可以实现将错误信息保存到数据库或其他存储
        // 目前仅做记录
    }
    
    /**
     * 记录错误到系统
     * @param array $errorInfo 错误信息
     * @param string $rawLine 原始日志行
     */
    protected function logError(array $errorInfo, $rawLine) {
        // 这里可以实现自定义的错误日志记录
        // 例如保存到数据库或其他文件
    }
    
    /**
     * 检查并运行统计
     */
    protected function checkAndRunStatistics() {
        // 检查是否启用了统计
        if (!$this->config['error_statistics']['enabled']) {
            return;
        }
        
        // 计算距离上次统计的时间
        $timeSinceLastStats = time() - $this->lastStatisticsTime;
        $sampleInterval = $this->config['error_statistics']['sampling_interval'] * 60; // 转换为秒
        
        // 如果超过采样间隔，运行统计
        if ($timeSinceLastStats >= $sampleInterval) {
            $this->runStatistics();
            $this->lastStatisticsTime = time();
        }
    }
    
    /**
     * 运行错误统计
     */
    protected function runStatistics() {
        // 创建统计报告
        $statistics = [
            'timestamp' => time(),
            'period' => $this->config['error_statistics']['sampling_interval'], // 分钟
            'error_counts' => $this->errorCounters,
            'summary' => $this->generateStatisticsSummary(),
        ];
        
        // 检查是否有异常多的错误
        $this->checkForErrorSpikes($statistics);
        
        // 重置计数器（保留类别计数，但重置总计数）
        $this->errorCounters['total'] = 0;
        
        // 记录统计信息
        $this->logStatistics($statistics);
    }
    
    /**
     * 检查是否有异常多的错误
     * @param array $statistics 统计信息
     */
    protected function checkForErrorSpikes(array $statistics) {
        // 这里可以实现检测错误峰值的逻辑
        // 例如，如果在短时间内错误数量突增，可以发送报警
        $totalErrors = $statistics['error_counts']['total'];
        $periodMinutes = $statistics['period'];
        
        // 如果每分钟错误数超过阈值，发送报警
        $errorsPerMinute = $totalErrors / $periodMinutes;
        $threshold = 10; // 每分钟10个错误
        
        if ($errorsPerMinute > $threshold && $this->alarmSystem !== null) {
            $this->alarmSystem->triggerAlarm([
                'type' => 'error_rate_spike',
                'severity' => 'warning',
                'title' => '错误率异常升高',
                'message' => "在过去{$periodMinutes}分钟内，系统错误数量异常升高。\n" .
                           "总错误数: {$totalErrors}\n" .
                           "每分钟错误数: {$errorsPerMinute}\n" .
                           "阈值: {$threshold}/分钟\n" .
                           "错误分布:\n" . $statistics['summary'],
                'source' => 'error_statistics',
                'metadata' => $statistics,
            ]);
        }
    }
    
    /**
     * 生成统计摘要
     * @return string 统计摘要
     */
    protected function generateStatisticsSummary() {
        $summary = "";
        
        foreach ($this->errorCounters as $category => $count) {
            if ($category !== 'total' && $count > 0) {
                $summary .= "{$category}: {$count}\n";
            }
        }
        
        return $summary;
    }
    
    /**
     * 记录统计信息
     * @param array $statistics 统计信息
     */
    protected function logStatistics(array $statistics) {
        // 这里可以实现将统计信息保存到数据库或日志文件
        // 目前仅记录到PHP错误日志
        $logMessage = "[ERROR_STATISTICS] 时间: " . date('Y-m-d H:i:s') . ", " .
                     "总错误数: " . $statistics['error_counts']['total'] . ", " .
                     "周期: " . $statistics['period'] . "分钟\n" .
                     $statistics['summary'];
        
        error_log($logMessage);
    }
    
    /**
     * 清理过期日志
     */
    public function cleanupOldLogs() {
        // 获取保留时间（天）
        $retentionDays = $this->config['log_retention_days'];
        
        foreach ($this->config['log_files'] as $type => $path) {
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . $path;
            
            // 检查文件是否存在
            if (file_exists($fullPath)) {
                // 检查文件年龄
                $fileAge = time() - filectime($fullPath);
                $retentionSeconds = $retentionDays * 24 * 60 * 60;
                
                // 如果文件超过保留时间，进行归档或删除
                if ($fileAge > $retentionSeconds) {
                    $this->archiveOrDeleteLog($fullPath, $type);
                }
            }
        }
    }
    
    /**
     * 归档或删除日志文件
     * @param string $filePath 文件路径
     * @param string $type 日志类型
     */
    protected function archiveOrDeleteLog($filePath, $type) {
        // 获取归档目录
        $archiveDir = dirname($filePath) . '/archives';
        
        // 创建归档目录（如果不存在）
        if (!is_dir($archiveDir)) {
            mkdir($archiveDir, 0755, true);
        }
        
        // 创建归档文件名
        $timestamp = date('Ymd_His');
        $archiveName = "{$type}_{$timestamp}.log.gz";
        $archivePath = "{$archiveDir}/{$archiveName}";
        
        // 尝试压缩并移动文件
        if ($this->compressFile($filePath, $archivePath)) {
            // 如果压缩成功，删除原文件
            unlink($filePath);
            error_log("日志文件已归档: {$filePath} -> {$archivePath}");
        } else {
            // 如果压缩失败，尝试直接删除
            unlink($filePath);
            error_log("日志文件已删除: {$filePath}");
        }
    }
    
    /**
     * 压缩文件
     * @param string $source 源文件
     * @param string $destination 目标文件
     * @return bool 是否成功
     */
    protected function compressFile($source, $destination) {
        try {
            // 使用gzencode压缩文件内容
            $content = file_get_contents($source);
            $compressed = gzencode($content, 9);
            
            // 写入压缩文件
            return file_put_contents($destination, $compressed) !== false;
        } catch (Exception $e) {
            error_log("压缩文件失败: {$e->getMessage()}");
            return false;
        }
    }
    
    /**
     * 检查日志文件大小
     */
    public function checkLogFileSizes() {
        foreach ($this->config['log_files'] as $type => $path) {
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . $path;
            
            // 检查文件是否存在
            if (file_exists($fullPath)) {
                // 获取文件大小（MB）
                $fileSizeMB = filesize($fullPath) / (1024 * 1024);
                
                // 如果超过最大大小，进行轮转
                if ($fileSizeMB > $this->config['max_log_size_mb']) {
                    $this->rotateLogFile($fullPath, $type);
                }
            }
        }
    }
    
    /**
     * 轮转日志文件
     * @param string $filePath 文件路径
     * @param string $type 日志类型
     */
    protected function rotateLogFile($filePath, $type) {
        // 创建备份文件名
        $backupPath = $filePath . '.' . date('Ymd_His') . '.bak';
        
        // 重命名文件
        if (rename($filePath, $backupPath)) {
            // 创建新的空日志文件
            touch($filePath);
            
            // 尝试压缩备份文件
            $gzPath = $backupPath . '.gz';
            if ($this->compressFile($backupPath, $gzPath)) {
                // 如果压缩成功，删除未压缩的备份
                unlink($backupPath);
                error_log("日志文件已轮转并压缩: {$filePath} -> {$gzPath}");
            } else {
                error_log("日志文件已轮转: {$filePath} -> {$backupPath}");
            }
        } else {
            error_log("轮转日志文件失败: {$filePath}");
        }
    }
    
    /**
     * 生成统计摘要
     * @return array 统计信息
     */
    public function getStatistics() {
        return [
            'error_counters' => $this->errorCounters,
            'last_checked' => $this->getLastCheckedTimes(),
            'file_status' => $this->fileStatus,
        ];
    }
    
    /**
     * 获取最后检查时间
     * @return array 最后检查时间
     */
    protected function getLastCheckedTimes() {
        $result = [];
        foreach ($this->fileStatus as $type => $status) {
            $result[$type] = [
                'last_checked' => $status['last_checked'],
                'formatted' => date('Y-m-d H:i:s', $status['last_checked']),
            ];
        }
        return $result;
    }
    
    /**
     * 手动记录错误
     * @param string $message 错误消息
     * @param string $level 错误级别
     * @param string $category 错误类别
     */
    public function logErrorManually($message, $level = 'error', $category = 'application') {
        // 创建错误信息
        $errorInfo = [
            'log_type' => 'manual',
            'timestamp' => date('Y-m-d H:i:s'),
            'source' => 'manual',
            'error_level' => $level,
            'message' => $message,
            'category' => $category,
            'severity' => $this->determineSeverity($level, $message),
            'notification_required' => true, // 手动记录的错误通常需要通知
            'is_error' => true,
        ];
        
        // 处理错误
        $this->handleError($errorInfo, "[MANUAL] {$message}");
    }
    
    /**
     * 获取配置
     * @return array 配置
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 更新配置
     * @param array $newConfig 新配置
     */
    public function updateConfig(array $newConfig) {
        $this->config = array_merge_recursive($this->config, $newConfig);
    }
}

// 初始化错误日志处理器的便捷函数
function initializeErrorLogHandler($config = []) {
    return ErrorLogHandler::getInstance($config);
}