<?php
/**
 * 自动报警系统
 * 提供全面的监控告警、多渠道通知和告警管理功能
 * 
 * @package CardSystem\Monitoring
 * @author System Developer
 * @version 1.0.0
 */

// 移除不存在的命名空间引用

// 尝试引入基本的Logger类
if (file_exists(__DIR__ . '/../Logger.php')) {
    require_once __DIR__ . '/../Logger.php';
}

/**
 * AlertSystem类 - 自动报警系统
 */
class AlertSystem
{
    /**
     * 告警严重程度常量
     */
    const SEVERITY_CRITICAL = 'critical';
    const SEVERITY_HIGH = 'high';
    const SEVERITY_MEDIUM = 'medium';
    const SEVERITY_LOW = 'low';
    
    /**
     * 告警状态常量
     */
    const STATUS_UNRESOLVED = 'unresolved';
    const STATUS_RESOLVED = 'resolved';
    const STATUS_ACKNOWLEDGED = 'acknowledged';
    const STATUS_SUPPRESSED = 'suppressed';
    
    // 额外的常量定义，确保向后兼容性
    public static $SEVERITY_MEDIUM = 'medium';
    public static $STATUS_UNRESOLVED = 'unresolved';
    
    /**
     * 配置管理器实例
     * @var object
     */
    private $configManager;
    
    /**
     * 日志记录器实例
     * @var object
     */
    private $logger;
    
    /**
     * Redis客户端实例
     * @var object
     */
    private $redisClient;
    
    /**
     * HTTP客户端实例
     * @var object
     */
    private $httpClient;
    
    /**
     * 告警配置
     * @var array
     */
    private $config;
    
    /**
     * 告警规则
     * @var array
     */
    private $alertRules = [];
    
    /**
     * 当前活跃告警
     * @var array
     */
    private $activeAlerts = [];
    
    /**
     * 告警发送器
     * @var array
     */
    private $notifiers = [];
    
    /**
     * 构造函数
     * 
     * @param object $configManager 配置管理器
     * @param object $logger 日志记录器
     * @param object $redisClient Redis客户端
     * @param object $httpClient HTTP客户端
     */
    public function __construct($configManager = null, $logger = null, 
                             $redisClient = null, $httpClient = null)
    {
        // 提供默认值，防止未定义类型错误
        $this->configManager = $configManager ?? (object)['get' => function($key, $default = []) { return $default; }];
        
        // 如果没有提供logger，尝试创建默认的Logger实例
        $this->logger = $logger;
        if (!$this->logger && class_exists('Logger')) {
            try {
                $this->logger = new Logger();
            } catch (\Exception $e) {
                // 如果Logger类不可用，创建一个简单的日志对象
                $this->logger = (object)[
                    'info' => function($message) { error_log('[INFO] ' . $message); },
                    'warning' => function($message) { error_log('[WARNING] ' . $message); },
                    'error' => function($message) { error_log('[ERROR] ' . $message); }
                ];
            }
        }
        
        $this->redisClient = $redisClient;
        $this->httpClient = $httpClient;
        
        // 加载配置
        $this->config = $configManager->get('alert_system', []);
        
        // 加载告警规则
        $this->loadAlertRules();
        
        // 初始化告警发送器
        $this->initNotifiers();
        
        // 加载活跃告警
        $this->loadActiveAlerts();
        
        $this->logger->info('自动报警系统初始化成功');
        $this->logger->info("加载了 " . count($this->alertRules) . " 条告警规则");
    }
    
    /**
     * 加载告警规则
     */
    private function loadAlertRules()
    {
        // 从配置加载默认规则
        $defaultRules = $this->config['rules'] ?? [];
        
        // 从Redis加载自定义规则
        try {
            $customRules = json_decode($this->redisClient->get('card_system:alert_rules') ?? '[]', true);
        } catch (\Exception $e) {
            $this->logger->warning("从Redis加载告警规则失败: {$e->getMessage()}");
            $customRules = [];
        }
        
        // 合并规则
        $this->alertRules = array_merge($defaultRules, $customRules);
        
        // 为每个规则添加默认值和验证
        foreach ($this->alertRules as &$rule) {
            $this->normalizeAlertRule($rule);
        }
    }
    
    /**
     * 标准化告警规则
     * 
     * @param array $rule 告警规则
     */
    private function normalizeAlertRule(&$rule)
    {
        // 添加默认值
        $rule += [
            'id' => uniqid('rule_', true),
            'name' => '未命名规则',
            'description' => '',
            'severity' => self::SEVERITY_MEDIUM,
            'enabled' => true,
            'conditions' => [],
            'notification_channels' => ['email'],
            'throttle_minutes' => 15,
            'auto_resolve_minutes' => 60,
            'suppression_periods' => [],
            'dependencies' => [],
            'created_at' => time(),
            'updated_at' => time()
        ];
        
        // 验证严重性
        if (!in_array($rule['severity'], [self::SEVERITY_CRITICAL, self::SEVERITY_HIGH, self::SEVERITY_MEDIUM, self::SEVERITY_LOW])) {
            $rule['severity'] = self::SEVERITY_MEDIUM;
        }
    }
    
    /**
     * 初始化告警发送器
     */
    private function initNotifiers()
    {
        // 初始化不同的通知发送器
        $this->notifiers = [
            'email' => new EmailNotifier($this->config, $this->logger),
            'sms' => new SmsNotifier($this->config, $this->logger),
            'webhook' => new WebhookNotifier($this->config, $this->logger, $this->httpClient),
            'slack' => new SlackNotifier($this->config, $this->logger, $this->httpClient),
            'dingtalk' => new DingTalkNotifier($this->config, $this->logger, $this->httpClient),
            'wechat' => new WechatNotifier($this->config, $this->logger, $this->httpClient),
            'telegram' => new TelegramNotifier($this->config, $this->logger, $this->httpClient)
        ];
        
        // 启用配置的通知渠道
        foreach ($this->notifiers as $channel => $notifier) {
            $enabled = $this->config['channels'][$channel]['enabled'] ?? false;
            $notifier->setEnabled($enabled);
        }
    }
    
    /**
     * 加载活跃告警
     */
    private function loadActiveAlerts()
    {
        try {
            $alerts = $this->redisClient->hgetall('card_system:alerts');
            
            foreach ($alerts as $alertId => $alertJson) {
                $alert = json_decode($alertJson, true);
                
                if ($alert['status'] === self::STATUS_UNRESOLVED || 
                    $alert['status'] === self::STATUS_ACKNOWLEDGED) {
                    $this->activeAlerts[$alertId] = $alert;
                }
            }
            
            $this->logger->info("加载了 " . count($this->activeAlerts) . " 条活跃告警");
        } catch (\Exception $e) {
            $this->logger->warning("加载活跃告警失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 检查告警规则并触发告警
     * 
     * @param string $metricName 指标名称
     * @param mixed $metricValue 指标值
     * @param array $context 上下文信息
     * @return array 触发的告警列表
     */
    public function checkAndTriggerAlerts($metricName, $metricValue, $context = [])
    {
        $triggeredAlerts = [];
        
        // 遍历所有规则
        foreach ($this->alertRules as $rule) {
            // 跳过禁用的规则
            if (!$rule['enabled']) {
                continue;
            }
            
            // 检查规则条件
            if ($this->evaluateRuleConditions($rule, $metricName, $metricValue, $context)) {
                // 检查告警抑制
                if ($this->isAlertSuppressed($rule)) {
                    $this->logger->notice("告警规则 {$rule['name']} 已被抑制");
                    continue;
                }
                
                // 检查告警频率限制
                if ($this->isRateLimited($rule)) {
                    $this->logger->notice("告警规则 {$rule['name']} 已达到频率限制");
                    continue;
                }
                
                // 检查依赖关系
                if (!$this->checkRuleDependencies($rule)) {
                    $this->logger->notice("告警规则 {$rule['name']} 的依赖未满足");
                    continue;
                }
                
                // 创建告警
                $alert = $this->createAlert($rule, $metricName, $metricValue, $context);
                
                // 记录告警
                $this->storeAlert($alert);
                
                // 发送通知
                $this->sendAlertNotifications($alert);
                
                // 更新频率限制
                $this->updateRateLimit($rule);
                
                $triggeredAlerts[] = $alert;
            }
        }
        
        return $triggeredAlerts;
    }
    
    /**
     * 评估规则条件
     * 
     * @param array $rule 告警规则
     * @param string $metricName 指标名称
     * @param mixed $metricValue 指标值
     * @param array $context 上下文信息
     * @return bool 是否满足条件
     */
    private function evaluateRuleConditions($rule, $metricName, $metricValue, $context)
    {
        $conditions = $rule['conditions'] ?? [];
        
        // 如果规则没有特定的指标名称，则匹配所有
        if (isset($conditions['metric_name']) && $conditions['metric_name'] !== $metricName) {
            return false;
        }
        
        // 检查阈值条件
        if (isset($conditions['threshold'])) {
            $threshold = $conditions['threshold'];
            $operator = $conditions['operator'] ?? 'gt'; // 默认大于
            
            if (!$this->evaluateThreshold($metricValue, $threshold, $operator)) {
                return false;
            }
        }
        
        // 检查持续时间条件
        if (isset($conditions['duration'])) {
            // 这里需要检查指标是否在指定时间内持续满足条件
            // 简化实现，实际应查询历史数据
        }
        
        // 检查阈值变化条件
        if (isset($conditions['threshold_change'])) {
            // 检查指标变化是否超过阈值
            // 简化实现，实际应查询历史数据并计算变化率
        }
        
        // 检查上下文条件
        if (isset($conditions['context']) && !empty($conditions['context'])) {
            foreach ($conditions['context'] as $key => $value) {
                if (!isset($context[$key]) || $context[$key] !== $value) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /**
     * 评估阈值条件
     * 
     * @param mixed $value 当前值
     * @param mixed $threshold 阈值
     * @param string $operator 操作符
     * @return bool 是否满足条件
     */
    private function evaluateThreshold($value, $threshold, $operator)
    {
        switch ($operator) {
            case 'gt':
                return $value > $threshold;
            case 'gte':
                return $value >= $threshold;
            case 'lt':
                return $value < $threshold;
            case 'lte':
                return $value <= $threshold;
            case 'eq':
                return $value === $threshold;
            case 'neq':
                return $value !== $threshold;
            case 'contains':
                return strpos($value, $threshold) !== false;
            case 'regex':
                return preg_match($threshold, $value) === 1;
            default:
                return false;
        }
    }
    
    /**
     * 检查告警是否被抑制
     * 
     * @param array $rule 告警规则
     * @return bool 是否被抑制
     */
    private function isAlertSuppressed($rule)
    {
        // 检查全局抑制
        if ($this->config['suppression_enabled'] ?? false) {
            return true;
        }
        
        // 检查规则特定的抑制时间段
        $suppressionPeriods = $rule['suppression_periods'] ?? [];
        
        foreach ($suppressionPeriods as $period) {
            if ($this->isCurrentTimeInPeriod($period)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 检查当前时间是否在指定时间段内
     * 
     * @param array $period 时间段配置
     * @return bool 是否在时间段内
     */
    private function isCurrentTimeInPeriod($period)
    {
        $now = new \DateTime();
        $currentDay = strtolower($now->format('l'));
        $currentTime = $now->format('H:i');
        
        // 检查星期几
        if (isset($period['days']) && !in_array($currentDay, $period['days'])) {
            return false;
        }
        
        // 检查时间范围
        if (isset($period['start_time']) && isset($period['end_time'])) {
            if ($currentTime < $period['start_time'] || $currentTime > $period['end_time']) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 检查告警频率限制
     * 
     * @param array $rule 告警规则
     * @return bool 是否达到频率限制
     */
    private function isRateLimited($rule)
    {
        $ruleId = $rule['id'];
        $throttleMinutes = $rule['throttle_minutes'] ?? 15;
        
        try {
            $lastTriggered = $this->redisClient->get("card_system:alert_last_triggered:{$ruleId}");
            
            if ($lastTriggered && (time() - $lastTriggered) < ($throttleMinutes * 60)) {
                return true;
            }
        } catch (\Exception $e) {
            // Redis错误时跳过频率限制检查，避免告警丢失
            $this->logger->warning("检查告警频率限制失败: {$e->getMessage()}");
        }
        
        return false;
    }
    
    /**
     * 更新告警频率限制
     * 
     * @param array $rule 告警规则
     */
    private function updateRateLimit($rule)
    {
        $ruleId = $rule['id'];
        $throttleMinutes = $rule['throttle_minutes'] ?? 15;
        
        try {
            $this->redisClient->setex(
                "card_system:alert_last_triggered:{$ruleId}",
                $throttleMinutes * 60,
                time()
            );
        } catch (\Exception $e) {
            $this->logger->warning("更新告警频率限制失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 检查规则依赖关系
     * 
     * @param array $rule 告警规则
     * @return bool 依赖是否满足
     */
    private function checkRuleDependencies($rule)
    {
        $dependencies = $rule['dependencies'] ?? [];
        
        foreach ($dependencies as $dependencyRuleId) {
            // 检查依赖规则是否存在且启用
            $found = false;
            foreach ($this->alertRules as $depRule) {
                if ($depRule['id'] === $dependencyRuleId) {
                    $found = true;
                    if (!$depRule['enabled']) {
                        return false;
                    }
                    break;
                }
            }
            
            if (!$found) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 创建告警
     * 
     * @param array $rule 告警规则
     * @param string $metricName 指标名称
     * @param mixed $metricValue 指标值
     * @param array $context 上下文信息
     * @return array 告警信息
     */
    private function createAlert($rule, $metricName, $metricValue, $context)
    {
        $alertId = uniqid('alert_', true);
        
        // 构建告警描述
        $description = $this->generateAlertDescription($rule, $metricName, $metricValue, $context);
        
        return [
            'id' => $alertId,
            'rule_id' => $rule['id'],
            'rule_name' => $rule['name'],
            'title' => $rule['name'],
            'description' => $description,
            'severity' => $rule['severity'],
            'metric_name' => $metricName,
            'metric_value' => $metricValue,
            'status' => self::STATUS_UNRESOLVED,
            'created_at' => time(),
            'updated_at' => time(),
            'context' => $context,
            'environment' => $this->config['environment'] ?? 'production',
            'notification_channels' => $rule['notification_channels'] ?? ['email'],
            'acknowledged_by' => null,
            'acknowledged_at' => null,
            'resolved_by' => null,
            'resolved_at' => null,
            'resolution_note' => null,
            'auto_resolve_at' => time() + ($rule['auto_resolve_minutes'] ?? 60) * 60
        ];
    }
    
    /**
     * 生成告警描述
     * 
     * @param array $rule 告警规则
     * @param string $metricName 指标名称
     * @param mixed $metricValue 指标值
     * @param array $context 上下文信息
     * @return string 告警描述
     */
    private function generateAlertDescription($rule, $metricName, $metricValue, $context)
    {
        $description = $rule['description'] ?? '';
        
        // 如果没有自定义描述，生成默认描述
        if (empty($description)) {
            $description = "指标 {$metricName} 的值 {$metricValue} 触发了告警规则 {$rule['name']}";
        }
        
        // 添加上下文信息
        if (!empty($context)) {
            $description .= "\n\n上下文信息:\n";
            foreach ($context as $key => $value) {
                $description .= "- {$key}: {$value}\n";
            }
        }
        
        return $description;
    }
    
    /**
     * 存储告警
     * 
     * @param array $alert 告警信息
     */
    public function storeAlert($alert)
    {
        try {
            // 存储告警到Redis
            $this->redisClient->hset('card_system:alerts', $alert['id'], json_encode($alert));
            
            // 设置过期时间（例如30天）
            $this->redisClient->xpire('card_system:alerts:' . $alert['id'], 30 * 24 * 60 * 60);
            
            // 添加到活跃告警列表
            $this->activeAlerts[$alert['id']] = $alert;
            
            // 记录到日志
            $this->logger->notice("创建告警: {$alert['title']} (ID: {$alert['id']}, 严重程度: {$alert['severity']})");
        } catch (\Exception $e) {
            $this->logger->error("存储告警失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 发送告警通知
     * 
     * @param array $alert 告警信息
     */
    public function sendAlertNotifications($alert)
    {
        $channels = $alert['notification_channels'] ?? [];
        
        foreach ($channels as $channel) {
            if (isset($this->notifiers[$channel])) {
                $notifier = $this->notifiers[$channel];
                
                try {
                    $result = $notifier->send($alert);
                    
                    if ($result['success']) {
                        $this->logger->notice("通过 {$channel} 发送告警通知成功: {$alert['id']}");
                    } else {
                        $this->logger->warning("通过 {$channel} 发送告警通知失败: {$result['error']}");
                    }
                } catch (\Exception $e) {
                    $this->logger->warning("通过 {$channel} 发送告警通知异常: {$e->getMessage()}");
                }
            } else {
                $this->logger->warning("未知的告警通知渠道: {$channel}");
            }
        }
    }
    
    /**
     * 确认告警
     * 
     * @param string $alertId 告警ID
     * @param string $userId 用户ID
     * @param string $note 备注
     * @return bool 是否成功
     */
    public function acknowledgeAlert($alertId, $userId, $note = '')
    {
        if (!isset($this->activeAlerts[$alertId])) {
            return false;
        }
        
        $alert = $this->activeAlerts[$alertId];
        
        // 只处理未解决的告警
        if ($alert['status'] !== self::STATUS_UNRESOLVED) {
            return false;
        }
        
        // 更新告警状态
        $alert['status'] = self::STATUS_ACKNOWLEDGED;
        $alert['acknowledged_by'] = $userId;
        $alert['acknowledged_at'] = time();
        $alert['updated_at'] = time();
        $alert['acknowledgment_note'] = $note;
        
        // 保存更新
        $this->activeAlerts[$alertId] = $alert;
        
        try {
            $this->redisClient->hset('card_system:alerts', $alertId, json_encode($alert));
            $this->logger->notice("告警 {$alertId} 已被 {$userId} 确认");
            
            return true;
        } catch (\Exception $e) {
            $this->logger->error("更新告警确认状态失败: {$e->getMessage()}");
            return false;
        }
    }
    
    /**
     * 解决告警
     * 
     * @param string $alertId 告警ID
     * @param string $userId 用户ID
     * @param string $resolutionNote 解决说明
     * @return bool 是否成功
     */
    public function resolveAlert($alertId, $userId, $resolutionNote = '')
    {
        if (!isset($this->activeAlerts[$alertId])) {
            return false;
        }
        
        $alert = $this->activeAlerts[$alertId];
        
        // 只处理未解决的告警
        if ($alert['status'] === self::STATUS_RESOLVED) {
            return false;
        }
        
        // 更新告警状态
        $alert['status'] = self::STATUS_RESOLVED;
        $alert['resolved_by'] = $userId;
        $alert['resolved_at'] = time();
        $alert['updated_at'] = time();
        $alert['resolution_note'] = $resolutionNote;
        
        // 从活跃告警中移除
        unset($this->activeAlerts[$alertId]);
        
        try {
            $this->redisClient->hset('card_system:alerts', $alertId, json_encode($alert));
            $this->logger->notice("告警 {$alertId} 已被 {$userId} 解决");
            
            return true;
        } catch (\Exception $e) {
            $this->logger->error("更新告警解决状态失败: {$e->getMessage()}");
            return false;
        }
    }
    
    /**
     * 自动解决超时告警
     * 
     * @return int 自动解决的告警数量
     */
    public function autoResolveTimedOutAlerts()
    {
        $resolvedCount = 0;
        $now = time();
        
        foreach ($this->activeAlerts as $alertId => $alert) {
            if ($alert['status'] !== self::STATUS_UNRESOLVED && 
                $alert['status'] !== self::STATUS_ACKNOWLEDGED) {
                continue;
            }
            
            if (isset($alert['auto_resolve_at']) && $now > $alert['auto_resolve_at']) {
                // 自动解决告警
                $this->resolveAlert($alertId, 'system', '自动解决（超时）');
                $resolvedCount++;
            }
        }
        
        if ($resolvedCount > 0) {
            $this->logger->notice("自动解决了 {$resolvedCount} 个超时告警");
        }
        
        return $resolvedCount;
    }
    
    /**
     * 手动触发测试告警
     * 
     * @param string $severity 严重程度
     * @param string $message 消息
     * @param array $channels 通知渠道
     * @return array 触发的告警
     */
    public function triggerTestAlert($severity = self::SEVERITY_MEDIUM, $message = '这是一条测试告警', $channels = ['email'])
    {
        $alertId = uniqid('test_alert_', true);
        
        $testAlert = [
            'id' => $alertId,
            'rule_id' => 'test_rule',
            'rule_name' => '测试告警',
            'title' => '测试告警',
            'description' => $message,
            'severity' => $severity,
            'metric_name' => 'test.metric',
            'metric_value' => 'test_value',
            'status' => self::STATUS_UNRESOLVED,
            'created_at' => time(),
            'updated_at' => time(),
            'context' => ['test' => true, 'timestamp' => time()],
            'environment' => $this->config['environment'] ?? 'production',
            'notification_channels' => $channels
        ];
        
        // 发送通知
        $this->sendAlertNotifications($testAlert);
        
        return $testAlert;
    }
    
    /**
     * 获取最近告警列表
     * 
     * @param int $limit 限制数量，默认10条
     * @return array 最近的告警列表
     */
    public function getRecentAlerts($limit = 10)
    {
        // 默认过滤未解决和已确认的告警
        $filters = ['status' => self::STATUS_UNRESOLVED];
        
        // 调用现有的getAlerts方法
        return $this->getAlerts($filters, $limit, 0);
    }
    
    /**
     * 获取告警列表
     * 
     * @param array $filters 过滤条件
     * @param int $limit 限制数量
     * @param int $offset 偏移量
     * @return array 告警列表
     */
    public function getAlerts($filters = [], $limit = 50, $offset = 0)
    {
        $alerts = [];
        
        try {
            // 从Redis获取所有告警
            $allAlerts = $this->redisClient->hgetall('card_system:alerts');
            
            foreach ($allAlerts as $alertJson) {
                $alert = json_decode($alertJson, true);
                
                // 应用过滤条件
                if ($this->applyAlertFilters($alert, $filters)) {
                    $alerts[] = $alert;
                }
            }
            
            // 按创建时间排序
            usort($alerts, function($a, $b) {
                return $b['created_at'] - $a['created_at'];
            });
            
            // 应用分页
            $alerts = array_slice($alerts, $offset, $limit);
        } catch (\Exception $e) {
            $this->logger->warning("获取告警列表失败: {$e->getMessage()}");
        }
        
        return $alerts;
    }
    
    /**
     * 应用告警过滤条件
     * 
     * @param array $alert 告警信息
     * @param array $filters 过滤条件
     * @return bool 是否匹配
     */
    private function applyAlertFilters($alert, $filters)
    {
        foreach ($filters as $key => $value) {
            if (!isset($alert[$key])) {
                return false;
            }
            
            if ($alert[$key] !== $value) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 获取告警统计信息
     * 
     * @param string $timeRange 时间范围
     * @return array 告警统计
     */
    public function getAlertStats($timeRange = '24h')
    {
        // 简化实现，返回模拟数据
        $totalAlerts = rand(10, 100);
        $criticalAlerts = rand(0, 10);
        $highAlerts = rand(2, 20);
        $mediumAlerts = rand(5, 30);
        $lowAlerts = rand(3, 40);
        $unresolvedAlerts = rand(5, 50);
        
        return [
            'total_alerts' => $totalAlerts,
            'by_severity' => [
                self::SEVERITY_CRITICAL => $criticalAlerts,
                self::SEVERITY_HIGH => $highAlerts,
                self::SEVERITY_MEDIUM => $mediumAlerts,
                self::SEVERITY_LOW => $lowAlerts
            ],
            'unresolved_alerts' => $unresolvedAlerts,
            'resolved_alerts' => $totalAlerts - $unresolvedAlerts,
            'alert_trend' => $this->generateAlertTrend($timeRange),
            'top_alert_sources' => $this->generateTopAlertSources()
        ];
    }
    
    /**
     * 生成告警趋势数据
     * 
     * @param string $timeRange 时间范围
     * @return array 趋势数据
     */
    private function generateAlertTrend($timeRange)
    {
        // 简化实现，返回模拟数据
        $trend = [];
        $now = time();
        
        // 根据时间范围生成不同粒度的数据点
        $points = 24; // 默认24小时，每小时一个点
        $interval = 3600; // 1小时
        
        if ($timeRange === '7d') {
            $points = 7;
            $interval = 86400; // 1天
        } elseif ($timeRange === '1h') {
            $points = 60;
            $interval = 60; // 1分钟
        }
        
        for ($i = $points - 1; $i >= 0; $i--) {
            $timestamp = $now - ($i * $interval);
            $trend[] = [
                'timestamp' => $timestamp,
                'critical' => rand(0, 2),
                'high' => rand(0, 5),
                'medium' => rand(0, 8),
                'low' => rand(0, 10),
                'total' => rand(0, 25)
            ];
        }
        
        return $trend;
    }
    
    /**
     * 生成告警来源TOP数据
     * 
     * @return array 来源统计
     */
    private function generateTopAlertSources()
    {
        // 简化实现，返回模拟数据
        return [
            ['source' => '请求错误率', 'count' => rand(10, 30)],
            ['source' => '数据库连接', 'count' => rand(5, 20)],
            ['source' => '系统负载', 'count' => rand(3, 15)],
            ['source' => 'API响应时间', 'count' => rand(2, 10)],
            ['source' => '内存使用率', 'count' => rand(1, 8)]
        ];
    }
    
    /**
     * 添加自定义告警规则
     * 
     * @param array $rule 告警规则
     * @return array 保存的规则
     */
    public function addAlertRule($rule)
    {
        // 标准化规则
        $this->normalizeAlertRule($rule);
        
        // 添加到规则列表
        $this->alertRules[] = $rule;
        
        // 保存到Redis
        try {
            $this->redisClient->set('card_system:alert_rules', json_encode($this->alertRules));
        } catch (\Exception $e) {
            $this->logger->error("保存告警规则失败: {$e->getMessage()}");
        }
        
        return $rule;
    }
    
    /**
     * 更新告警规则
     * 
     * @param string $ruleId 规则ID
     * @param array $updates 更新内容
     * @return bool 是否成功
     */
    public function updateAlertRule($ruleId, $updates)
    {
        foreach ($this->alertRules as &$rule) {
            if ($rule['id'] === $ruleId) {
                // 合并更新
                $rule = array_merge($rule, $updates);
                $rule['updated_at'] = time();
                
                // 保存到Redis
                try {
                    $this->redisClient->set('card_system:alert_rules', json_encode($this->alertRules));
                    return true;
                } catch (\Exception $e) {
                    $this->logger->error("更新告警规则失败: {$e->getMessage()}");
                    return false;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 删除告警规则
     * 
     * @param string $ruleId 规则ID
     * @return bool 是否成功
     */
    public function deleteAlertRule($ruleId)
    {
        $originalCount = count($this->alertRules);
        
        // 过滤掉指定的规则
        $this->alertRules = array_filter($this->alertRules, function($rule) use ($ruleId) {
            return $rule['id'] !== $ruleId;
        });
        
        // 检查是否成功删除
        if (count($this->alertRules) === $originalCount) {
            return false;
        }
        
        // 保存到Redis
        try {
            $this->redisClient->set('card_system:alert_rules', json_encode($this->alertRules));
            return true;
        } catch (\Exception $e) {
            $this->logger->error("删除告警规则失败: {$e->getMessage()}");
            return false;
        }
    }
    
    /**
     * 关闭自动报警系统
     */
    public function shutdown()
    {
        $this->logger->info('自动报警系统正在关闭...');
        
        // 清理资源
        $this->activeAlerts = [];
    }
}

/**
 * 通知发送器接口
 */
interface AlertNotifier
{
    public function send($alert);
    public function setEnabled($enabled);
}

/**
 * 邮件通知发送器
 */
class EmailNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $enabled = false;
    
    public function __construct($config, $logger)
    {
        $this->config = $config['channels']['email'] ?? [];
        $this->logger = $logger;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => '邮件通知已禁用'];
        }
        
        // 获取收件人
        $recipients = $this->config['recipients'] ?? [];
        
        // 构建邮件内容
        $subject = "[{$alert['severity']}] {$alert['title']}";
        $body = $this->buildEmailBody($alert);
        
        // 这里应该调用实际的邮件发送库
        // 简化实现，只记录日志
        $this->logger->notice("准备发送邮件告警: 主题={$subject}, 收件人=" . implode(', ', $recipients));
        
        return ['success' => true, 'message' => '邮件已发送'];
    }
    
    private function buildEmailBody($alert)
    {
        $body = "<h2>{$alert['title']}</h2>\n";
        $body .= "<p>{$alert['description']}</p>\n";
        $body .= "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse: collapse; margin-top: 20px; width: 100%;'\u003e\n";
        $body .= "<tr style='background-color: #f2f2f2;'\u003e\n";
        $body .= "<td\u003e告警ID</td\u003e\n";
        $body .= "<td\u003e{$alert['id']}</td\u003e\n";
        $body .= "</tr\u003e\n";
        $body .= "<tr\u003e\n";
        $body .= "<td\u003e严重程度</td\u003e\n";
        $body .= "<td\u003e{$alert['severity']}</td\u003e\n";
        $body .= "</tr\u003e\n";
        $body .= "<tr style='background-color: #f2f2f2;'\u003e\n";
        $body .= "<td\u003e触发时间</td\u003e\n";
        $body .= "<td\u003e" . date('Y-m-d H:i:s', $alert['created_at']) . "</td\u003e\n";
        $body .= "</tr\u003e\n";
        $body .= "<tr\u003e\n";
        $body .= "<td\u003e环境</td\u003e\n";
        $body .= "<td\u003e{$alert['environment']}</td\u003e\n";
        $body .= "</tr\u003e\n";
        $body .= "</table\u003e\n";
        
        if (!empty($alert['context'])) {
            $body .= "<h3\u003e上下文信息</h3\u003e\n";
            $body .= "<pre\u003e" . json_encode($alert['context'], JSON_PRETTY_PRINT) . "</pre\u003e\n";
        }
        
        return $body;
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
    
    /**
     * 触发告警 - 接受告警数据数组
     * 
     * @param array $alertData 告警数据数组，包含alert_type、severity、title、message和details等字段
     * @return array 触发的告警信息
     */
    public function triggerAlert($alertData)
    {
        if (!is_array($alertData)) {
            $this->logger->error('triggerAlert方法需要数组参数');
            return null;
        }
        
        $alertId = uniqid('alert_', true);
        
        // 构建告警信息
        $alert = [
            'id' => $alertId,
            'rule_id' => $alertData['alert_type'] ?? 'manual',
            'rule_name' => $alertData['title'] ?? '手动告警',
            'title' => $alertData['title'] ?? '未命名告警',
            'description' => $alertData['message'] ?? '无描述',
            'severity' => $alertData['severity'] ?? self::SEVERITY_MEDIUM,
            'metric_name' => $alertData['alert_type'] ?? 'manual',
            'metric_value' => 1,
            'status' => self::STATUS_UNRESOLVED,
            'created_at' => time(),
            'updated_at' => time(),
            'context' => $alertData['details'] ?? [],
            'environment' => $this->config['environment'] ?? 'production',
            'notification_channels' => ['email'],
            'acknowledged_by' => null,
            'acknowledged_at' => null,
            'resolved_by' => null,
            'resolved_at' => null,
            'resolution_note' => null,
            'auto_resolve_at' => time() + 60 * 60 // 默认1小时后自动解决
        ];
        
        // 记录告警
        $this->storeAlert($alert);
        
        // 发送通知
        $this->sendAlertNotifications($alert);
        
        return $alert;
    }
}

/**
 * 短信通知发送器
 */
class SmsNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $enabled = false;
    
    public function __construct($config, $logger)
    {
        $this->config = $config['channels']['sms'] ?? [];
        $this->logger = $logger;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => '短信通知已禁用'];
        }
        
        // 获取接收人
        $recipients = $this->config['recipients'] ?? [];
        
        // 构建短信内容（确保内容简洁）
        $message = $this->buildSmsMessage($alert);
        
        // 这里应该调用实际的短信发送API
        // 简化实现，只记录日志
        $this->logger->notice("准备发送短信告警: 内容={$message}, 收件人=" . implode(', ', $recipients));
        
        return ['success' => true, 'message' => '短信已发送'];
    }
    
    private function buildSmsMessage($alert)
    {
        $severityMap = [
            'critical' => '【严重】',
            'high' => '【高危】',
            'medium' => '【中危】',
            'low' => '【低危】'
        ];
        
        $severityPrefix = $severityMap[$alert['severity']] ?? '';
        $message = "{$severityPrefix}{$alert['title']}: {$alert['description']}";
        
        // 短信长度限制
        if (mb_strlen($message) > 140) {
            $message = mb_substr($message, 0, 137) . '...';
        }
        
        return $message;
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
}

/**
 * Webhook通知发送器
 */
class WebhookNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $httpClient;
    private $enabled = false;
    
    public function __construct($config, $logger, $httpClient)
    {
        $this->config = $config['channels']['webhook'] ?? [];
        $this->logger = $logger;
        $this->httpClient = $httpClient;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => 'Webhook通知已禁用'];
        }
        
        // 获取Webhook URL
        $url = $this->config['url'] ?? '';
        
        if (empty($url)) {
            return ['success' => false, 'error' => 'Webhook URL未配置'];
        }
        
        // 发送HTTP请求
        try {
            $response = $this->httpClient->post($url, $alert, [
                'Content-Type' => 'application/json'
            ]);
            
            return ['success' => true, 'message' => 'Webhook请求已发送'];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
}

/**
 * Slack通知发送器
 */
class SlackNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $httpClient;
    private $enabled = false;
    
    public function __construct($config, $logger, $httpClient)
    {
        $this->config = $config['channels']['slack'] ?? [];
        $this->logger = $logger;
        $this->httpClient = $httpClient;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => 'Slack通知已禁用'];
        }
        
        $webhookUrl = $this->config['webhook_url'] ?? '';
        
        if (empty($webhookUrl)) {
            return ['success' => false, 'error' => 'Slack Webhook URL未配置'];
        }
        
        // 构建Slack消息
        $message = $this->buildSlackMessage($alert);
        
        try {
            $response = $this->httpClient->post($webhookUrl, $message, [
                'Content-Type' => 'application/json'
            ]);
            
            return ['success' => true, 'message' => 'Slack消息已发送'];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function buildSlackMessage($alert)
    {
        // 根据严重程度设置颜色
        $colorMap = [
            'critical' => '#ff0000',
            'high' => '#ff7700',
            'medium' => '#ffcc00',
            'low' => '#00ccff'
        ];
        
        $color = $colorMap[$alert['severity']] ?? '#cccccc';
        
        return [
            'username' => '自动报警系统',
            'icon_emoji' => ':warning:',
            'attachments' => [
                [
                    'color' => $color,
                    'title' => $alert['title'],
                    'title_link' => '',
                    'text' => $alert['description'],
                    'fields' => [
                        ['title' => '严重程度', 'value' => $alert['severity'], 'short' => true],
                        ['title' => '告警ID', 'value' => $alert['id'], 'short' => true],
                        ['title' => '环境', 'value' => $alert['environment'], 'short' => true],
                        ['title' => '时间', 'value' => date('Y-m-d H:i:s', $alert['created_at']), 'short' => true]
                    ]
                ]
            ]
        ];
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
}

/**
 * 钉钉通知发送器
 */
class DingTalkNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $httpClient;
    private $enabled = false;
    
    public function __construct($config, $logger, $httpClient)
    {
        $this->config = $config['channels']['dingtalk'] ?? [];
        $this->logger = $logger;
        $this->httpClient = $httpClient;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => '钉钉通知已禁用'];
        }
        
        $webhookUrl = $this->config['webhook_url'] ?? '';
        
        if (empty($webhookUrl)) {
            return ['success' => false, 'error' => '钉钉Webhook URL未配置'];
        }
        
        // 构建钉钉消息
        $message = $this->buildDingTalkMessage($alert);
        
        try {
            $response = $this->httpClient->post($webhookUrl, $message, [
                'Content-Type' => 'application/json'
            ]);
            
            return ['success' => true, 'message' => '钉钉消息已发送'];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function buildDingTalkMessage($alert)
    {
        // 构建Markdown内容
        $markdown = "# {$alert['title']}\n";
        $markdown .= "## 告警描述\n{$alert['description']}\n\n";
        $markdown .= "## 告警详情\n";
        $markdown .= "- **告警ID**: {$alert['id']}\n";
        $markdown .= "- **严重程度**: {$alert['severity']}\n";
        $markdown .= "- **环境**: {$alert['environment']}\n";
        $markdown .= "- **时间**: " . date('Y-m-d H:i:s', $alert['created_at']) . "\n";
        
        return [
            'msgtype' => 'markdown',
            'markdown' => [
                'title' => $alert['title'],
                'text' => $markdown
            ]
        ];
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
}

/**
 * 企业微信通知发送器
 */
class WechatNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $httpClient;
    private $enabled = false;
    
    public function __construct($config, $logger, $httpClient)
    {
        $this->config = $config['channels']['wechat'] ?? [];
        $this->logger = $logger;
        $this->httpClient = $httpClient;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => '企业微信通知已禁用'];
        }
        
        // 获取企业微信配置
        $corpid = $this->config['corpid'] ?? '';
        $corpsecret = $this->config['corpsecret'] ?? '';
        $agentid = $this->config['agentid'] ?? '';
        
        // 构建企业微信消息
        $message = $this->buildWechatMessage($alert);
        
        // 这里应该实现实际的企业微信消息发送逻辑
        // 简化实现，只记录日志
        $this->logger->notice("准备发送企业微信告警: 标题={$alert['title']}, 应用ID={$agentid}");
        
        return ['success' => true, 'message' => '企业微信消息已发送'];
    }
    
    private function buildWechatMessage($alert)
    {
        // 构建企业微信消息格式
        return [
            'touser' => '@all',
            'msgtype' => 'text',
            'agentid' => $this->config['agentid'] ?? '',
            'text' => [
                'content' => "[{$alert['severity']}] {$alert['title']}\n{$alert['description']}\n\n告警ID: {$alert['id']}\n时间: " . date('Y-m-d H:i:s', $alert['created_at'])
            ]
        ];
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
}

/**
 * Telegram通知发送器
 */
class TelegramNotifier implements AlertNotifier
{
    private $config;
    private $logger;
    private $httpClient;
    private $enabled = false;
    
    public function __construct($config, $logger, $httpClient)
    {
        $this->config = $config['channels']['telegram'] ?? [];
        $this->logger = $logger;
        $this->httpClient = $httpClient;
        $this->enabled = $this->config['enabled'] ?? false;
    }
    
    public function send($alert)
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => 'Telegram通知已禁用'];
        }
        
        $botToken = $this->config['bot_token'] ?? '';
        $chatId = $this->config['chat_id'] ?? '';
        
        // 构建Telegram消息
        $message = $this->buildTelegramMessage($alert);
        
        // 构建API URL
        $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
        
        try {
            $response = $this->httpClient->post($url, [
                'chat_id' => $chatId,
                'text' => $message,
                'parse_mode' => 'HTML'
            ], [
                'Content-Type' => 'application/json'
            ]);
            
            return ['success' => true, 'message' => 'Telegram消息已发送'];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function buildTelegramMessage($alert)
    {
        $message = "<b>[{$alert['severity']}] {$alert['title']}</b>\n\n";
        $message .= "{$alert['description']}\n\n";
        $message .= "<pre\u003e告警ID: {$alert['id']}\n";
        $message .= "环境: {$alert['environment']}\n";
        $message .= "时间: " . date('Y-m-d H:i:s', $alert['created_at']) . "</pre\u003e";
        
        return $message;
    }
    
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }
}