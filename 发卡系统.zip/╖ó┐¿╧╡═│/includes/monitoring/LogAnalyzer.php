\u003c?php
/**
 * 系统日志分析工具
 * 负责日志收集、解析、分析和异常检测
 * 
 * @package MonitoringSystem
 * @author System Administrator
 * @version 1.0
 */

class LogAnalyzer {
    /**
     * 日志文件路径
     * @var array
     */
    private $logFiles;
    
    /**
     * 日志格式规则
     * @var array
     */
    private $logFormats;
    
    /**
     * 数据库连接
     * @var mysqli
     */
    private $db;
    
    /**
     * Redis连接
     * @var Redis
     */
    private $redis;
    
    /**
     * 配置信息
     * @var array
     */
    private $config;
    
    /**
     * 分析结果缓存
     * @var array
     */
    private $cache;
    
    /**
     * 构造函数
     * 
     * @param mysqli $db 数据库连接
     * @param Redis $redis Redis连接
     * @param array $config 配置信息
     */
    public function __construct($db, $redis, $config = []) {
        $this-\u003edb = $db;
        $this-\u003eredis = $redis;
        $this-\u003econfig = array_merge([
            'log_directory' =\u003e '/var/log/',
            'log_retention_days' =\u003e 14,
            'max_lines_per_analysis' =\u003e 100000,
            'patterns' =\u003e [],
            'redis_prefix' =\u003e 'log_analyzer:',
            'cache_ttl' =\u003e 300, // 缓存5分钟
        ], $config);
        
        $this-\u003elogFiles = [];
        $this-\u003elogFormats = $this-\u003egetDefaultLogFormats();
        $this-\u003ecache = [];
        
        // 确保日志表存在
        $this-\u003eensureTablesExist();
    }
    
    /**
     * 获取默认日志格式
     * 
     * @return array 日志格式配置
     */
    private function getDefaultLogFormats() {
        return [
            'apache_access' =\u003e [
                'pattern' =\u003e '/^(\\S+) \\S+ \\S+ \[(.*?)\\] "(.*?)" (\\d+) (\\d+) "(.*?)" "(.*?)"$/',
                'fields' =\u003e ['ip', 'timestamp', 'request', 'status', 'size', 'referer', 'user_agent'],
            ],
            'nginx_access' =\u003e [
                'pattern' =\u003e '/^(\\S+) \\S+ \\S+ \[(.*?)\\] "(.*?)" (\\d+) (\\d+) "(.*?)" "(.*?)"(?: "(.*?)")?$/',
                'fields' =\u003e ['ip', 'remote_user', 'timestamp', 'request', 'status', 'size', 'referer', 'user_agent', 'http_x_forwarded_for'],
            ],
            'php_error' =\u003e [
                'pattern' =\u003e '/^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}) (\\w+)\\s*(\\w+): (.*?) in (.*?) on line (\\d+)/',
                'fields' =\u003e ['timestamp', 'severity', 'type', 'message', 'file', 'line'],
            ],
            'mysql_error' =\u003e [
                'pattern' =\u003e '/^(\\d{6} \\d{2}:\\d{2}:\\d{2}) (\\w+).*?: (.*?)$/',
                'fields' =\u003e ['timestamp', 'type', 'message'],
            ],
            'application_log' =\u003e [
                'pattern' =\u003e '/^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2},\\d{3}) \\[(\\w+)\\] (.*?): (.*?)$/',
                'fields' =\u003e ['timestamp', 'level', 'source', 'message'],
            ],
        ];
    }
    
    /**
     * 确保必要的数据表存在
     */
    private function ensureTablesExist() {
        // 创建日志分析表
        $this-\u003edb-\u003equery("
            CREATE TABLE IF NOT EXISTS `log_analysis` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `log_file` VARCHAR(255) NOT NULL,
                `log_type` VARCHAR(50) NOT NULL,
                `level` ENUM('debug', 'info', 'warning', 'error', 'critical') NULL,
                `ip` VARCHAR(45) NULL,
                `status` INT NULL,
                `request` VARCHAR(255) NULL,
                `user_agent` TEXT NULL,
                `message` TEXT NOT NULL,
                `details` JSON NOT NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_log_file` (`log_file`),
                INDEX `idx_level` (`level`),
                INDEX `idx_ip` (`ip`),
                INDEX `idx_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建日志异常模式表
        $this-\u003edb-\u003equery("
            CREATE TABLE IF NOT EXISTS `log_exception_patterns` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `name` VARCHAR(100) NOT NULL,
                `pattern` VARCHAR(255) NOT NULL,
                `regex` BOOLEAN NOT NULL DEFAULT 1,
                `severity` ENUM('info', 'warning', 'critical') NOT NULL DEFAULT 'warning',
                `description` TEXT NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_pattern` (`pattern`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建日志分析结果表
        $this-\u003edb-\u003equery("
            CREATE TABLE IF NOT EXISTS `log_analysis_results` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `date` DATE NOT NULL,
                `log_file` VARCHAR(255) NOT NULL,
                `total_entries` INT NOT NULL,
                `error_count` INT NOT NULL,
                `warning_count` INT NOT NULL,
                `unique_ips` INT NOT NULL,
                `top_errors` JSON NOT NULL,
                `top_paths` JSON NOT NULL,
                `performance_metrics` JSON NOT NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_date_file` (`date`, `log_file`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建默认的异常模式
        $this-\u003ecreateDefaultExceptionPatterns();
    }
    
    /**
     * 创建默认的异常模式
     */
    private function createDefaultExceptionPatterns() {
        $patterns = [
            ['name' =\u003e 'PHP Fatal Error', 'pattern' =\u003e 'PHP Fatal error:', 'regex' =\u003e 1, 'severity' =\u003e 'critical', 'description' =\u003e 'PHP致命错误，应用程序崩溃'],
            ['name' =\u003e 'PHP Parse Error', 'pattern' =\u003e 'PHP Parse error:', 'regex' =\u003e 1, 'severity' =\u003e 'critical', 'description' =\u003e 'PHP语法错误'],
            ['name' =\u003e 'Database Connection Error', 'pattern' =\u003e '(Database connection failed|Failed to connect to database)', 'regex' =\u003e 1, 'severity' =\u003e 'critical', 'description' =\u003e '数据库连接失败'],
            ['name' =\u003e 'Out of Memory', 'pattern' =\u003e '(Allowed memory size|out of memory)', 'regex' =\u003e 1, 'severity' =\u003e 'critical', 'description' =\u003e '内存溢出错误'],
            ['name' =\u003e 'SQL Injection Attempt', 'pattern' =\u003e '(\\'\\s*OR\\s*\\'|\\'\\s*UNION\\s*SELECT)', 'regex' =\u003e 1, 'severity' =\u003e 'critical', 'description' =\u003e 'SQL注入攻击尝试'],
            ['name' =\u003e 'File Permission Error', 'pattern' =\u003e 'Permission denied', 'regex' =\u003e 1, 'severity' =\u003e 'warning', 'description' =\u003e '文件权限错误'],
            ['name' =\u003e '404 Not Found', 'pattern' =\u003e '" 404 ', 'regex' =\u003e 1, 'severity' =\u003e 'info', 'description' =\u003e '页面未找到'],
            ['name' =\u003e '500 Internal Server Error', 'pattern' =\u003e '" 500 ', 'regex' =\u003e 1, 'severity' =\u003e 'warning', 'description' =\u003e '服务器内部错误'],
            ['name' =\u003e 'Slow Query', 'pattern' =\u003e 'SLOW QUERY', 'regex' =\u003e 1, 'severity' =\u003e 'warning', 'description' =\u003e '慢查询'],
        ];
        
        foreach ($patterns as $pattern) {
            $stmt = $this-\u003edb-\u003eprepare("
                INSERT INTO `log_exception_patterns` (`name`, `pattern`, `regex`, `severity`, `description`) 
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE `updated_at` = CURRENT_TIMESTAMP
            ");
            
            $stmt-\u003ebind_param(
                'ssiss',
                $pattern['name'], $pattern['pattern'], $pattern['regex'], $pattern['severity'], $pattern['description']
            );
            $stmt-\u003eexecute();
        }
    }
    
    /**
     * 添加要分析的日志文件
     * 
     * @param string $filePath 日志文件路径
     * @param string $logType 日志类型
     * @return bool 是否成功添加
     */
    public function addLogFile($filePath, $logType = 'application_log') {
        if (!file_exists($filePath)) {
            error_log("Log file does not exist: $filePath");
            return false;
        }
        
        $this-\u003elogFiles[] = ['path' =\u003e $filePath, 'type' =\u003e $logType];
        return true;
    }
    
    /**
     * 批量添加日志文件
     * 
     * @param array $files 文件配置数组
     * @return int 添加成功的文件数量
     */
    public function addLogFiles($files) {
        $count = 0;
        foreach ($files as $file) {
            if (is_array($file) \u0026\u0026 isset($file['path'], $file['type'])) {
                if ($this-\u003eaddLogFile($file['path'], $file['type'])) {
                    $count++;
                }
            }
        }
        return $count;
    }
    
    /**
     * 扫描目录中的日志文件
     * 
     * @param string $directory 目录路径
     * @param string $pattern 文件名匹配模式
     * @param string $logType 日志类型
     * @return int 添加的文件数量
     */
    public function scanLogDirectory($directory, $pattern = '*.log', $logType = 'application_log') {
        if (!is_dir($directory)) {
            error_log("Directory does not exist: $directory");
            return 0;
        }
        
        $files = glob($directory . '/' . $pattern);
        $count = 0;
        
        foreach ($files as $file) {
            if (is_file($file)) {
                if ($this-\u003eaddLogFile($file, $logType)) {
                    $count++;
                }
            }
        }
        
        return $count;
    }
    
    /**
     * 分析单个日志文件
     * 
     * @param string $filePath 日志文件路径
     * @param string $logType 日志类型
     * @param int $limit 最大读取行数
     * @return array 分析结果
     */
    public function analyzeLogFile($filePath, $logType = 'application_log', $limit = null) {
        if (!file_exists($filePath)) {
            error_log("Log file does not exist: $filePath");
            return ['error' =\u003e "File not found: $filePath"];
        }
        
        // 检查缓存
        $cacheKey = $this-\u003egetCacheKey('analyze', $filePath, $logType, $limit);
        $cachedResult = $this-\u003egetFromCache($cacheKey);
        if ($cachedResult) {
            return $cachedResult;
        }
        
        $limit = $limit ?? $this-\u003econfig['max_lines_per_analysis'];
        $logFormat = isset($this-\u003elogFormats[$logType]) ? $this-\u003elogFormats[$logType] : $this-\u003elogFormats['application_log'];
        
        $results = [
            'file' =\u003e $filePath,
            'type' =\u003e $logType,
            'total_lines' =\u003e 0,
            'parsed_lines' =\u003e 0,
            'unparsed_lines' =\u003e 0,
            'errors' =\u003e [],
            'warnings' =\u003e [],
            'info' =\u003e [],
            'severity_counts' =\u003e ['debug' =\u003e 0, 'info' =\u003e 0, 'warning' =\u003e 0, 'error' =\u003e 0, 'critical' =\u003e 0],
            'ip_addresses' =\u003e [],
            'status_codes' =\u003e [],
            'top_errors' =\u003e [],
            'timestamps' =\u003e [],
            'exceptions' =\u003e [],
        ];
        
        $file = fopen($filePath, 'r');
        $lineCount = 0;
        
        while (($line = fgets($file)) !== false \u0026\u0026 $lineCount \u003c $limit) {
            $lineCount++;
            $line = trim($line);
            
            if (empty($line)) {
                continue;
            }
            
            // 尝试解析日志行
            $parsed = $this-\u003eparseLogLine($line, $logFormat);
            
            if ($parsed) {
                $results['parsed_lines']++;
                
                // 处理解析后的字段
                $this-\u003eprocessParsedLogLine($parsed, $results);
                
                // 检测异常模式
                $this-\u003edetectExceptionPatterns($line, $parsed, $results);
                
                // 保存到数据库
                $this-\u003esaveLogEntry($parsed, $filePath, $logType);
            } else {
                $results['unparsed_lines']++;
                $results['info'][] = "无法解析的日志行: $line";
            }
        }
        
        fclose($file);
        $results['total_lines'] = $lineCount;
        
        // 生成统计数据
        $results['top_errors'] = $this-\u003egenerateTopErrors($results['errors'], 10);
        $results['unique_ips'] = count(array_unique($results['ip_addresses']));
        $results['timestamp_range'] = $this-\u003egetTimestampRange($results['timestamps']);
        
        // 保存到缓存
        $this-\u003esaveToCache($cacheKey, $results);
        
        // 保存分析结果到数据库
        $this-\u003esaveAnalysisResults($results);
        
        return $results;
    }
    
    /**
     * 解析日志行
     * 
     * @param string $line 日志行
     * @param array $logFormat 日志格式
     * @return array|null 解析结果
     */
    private function parseLogLine($line, $logFormat) {
        if (!isset($logFormat['pattern']) || !isset($logFormat['fields'])) {
            return null;
        }
        
        $pattern = $logFormat['pattern'];
        $fields = $logFormat['fields'];
        
        if (preg_match($pattern, $line, $matches)) {
            array_shift($matches); // 移除完整匹配
            
            $result = [];
            foreach ($fields as $index =\u003e $field) {
                if (isset($matches[$index])) {
                    $result[$field] = $matches[$index];
                }
            }
            
            // 规范化时间戳
            if (isset($result['timestamp'])) {
                $result['timestamp'] = $this-\u003enormalizeTimestamp($result['timestamp']);
            } else {
                $result['timestamp'] = date('Y-m-d H:i:s');
            }
            
            // 提取严重级别
            if (isset($result['level']) || isset($result['severity'])) {
                $level = isset($result['level']) ? $result['level'] : $result['severity'];
                $result['level'] = $this-\u003enormalizeSeverityLevel($level);
            }
            
            return $result;
        }
        
        return null;
    }
    
    /**
     * 处理解析后的日志行
     * 
     * @param array $parsed 解析结果
     * @param array $results 分析结果
     */
    private function processParsedLogLine($parsed, \u0026$results) {
        // 处理严重级别
        if (isset($parsed['level'])) {
            $level = strtolower($parsed['level']);
            if (isset($results['severity_counts'][$level])) {
                $results['severity_counts'][$level]++;
            } else {
                $results['severity_counts']['info']++;
            }
        } else {
            $results['severity_counts']['info']++;
        }
        
        // 处理IP地址
        if (isset($parsed['ip'])) {
            $results['ip_addresses'][] = $parsed['ip'];
        }
        
        // 处理状态码
        if (isset($parsed['status']) \u0026\u0026 is_numeric($parsed['status'])) {
            $status = intval($parsed['status']);
            if (!isset($results['status_codes'][$status])) {
                $results['status_codes'][$status] = 0;
            }
            $results['status_codes'][$status]++;
            
            // 4xx和5xx错误
            if ($status \u003e= 400 \u0026\u0026 $status \u003c 500) {
                $results['warnings'][] = $parsed;
            } elseif ($status \u003e= 500) {
                $results['errors'][] = $parsed;
            }
        }
        
        // 保存时间戳
        if (isset($parsed['timestamp'])) {
            $results['timestamps'][] = $parsed['timestamp'];
        }
        
        // 检查消息中的错误关键字
        if (isset($parsed['message'])) {
            $message = strtolower($parsed['message']);
            if (strpos($message, 'error') !== false || strpos($message, 'exception') !== false) {
                $results['errors'][] = $parsed;
            } elseif (strpos($message, 'warning') !== false || strpos($message, 'notice') !== false) {
                $results['warnings'][] = $parsed;
            }
        }
    }
    
    /**
     * 检测异常模式
     * 
     * @param string $line 原始日志行
     * @param array $parsed 解析结果
     * @param array $results 分析结果
     */
    private function detectExceptionPatterns($line, $parsed, \u0026$results) {
        // 从数据库获取异常模式
        $stmt = $this-\u003edb-\u003eprepare("SELECT * FROM `log_exception_patterns`");
        $stmt-\u003eexecute();
        $patterns = $stmt-\u003eget_result();
        
        while ($pattern = $patterns-\u003efetch_assoc()) {
            $match = false;
            
            if ($pattern['regex']) {
                $match = preg_match('/' . $pattern['pattern'] . '/i', $line) === 1;
            } else {
                $match = strpos(strtolower($line), strtolower($pattern['pattern'])) !== false;
            }
            
            if ($match) {
                $exception = [
                    'pattern_id' =\u003e $pattern['id'],
                    'pattern_name' =\u003e $pattern['name'],
                    'severity' =\u003e $pattern['severity'],
                    'description' =\u003e $pattern['description'],
                    'log_line' =\u003e $line,
                    'parsed_data' =\u003e $parsed,
                ];
                
                $results['exceptions'][] = $exception;
                
                // 根据严重程度添加到相应的类别
                switch ($pattern['severity']) {
                    case 'critical':
                    case 'error':
                        $results['errors'][] = $exception;
                        break;
                    case 'warning':
                        $results['warnings'][] = $exception;
                        break;
                    default:
                        $results['info'][] = $exception;
                }
            }
        }
    }
    
    /**
     * 保存日志条目到数据库
     * 
     * @param array $parsed 解析后的日志
     * @param string $logFile 日志文件
     * @param string $logType 日志类型
     */
    private function saveLogEntry($parsed, $logFile, $logType) {
        // 提取关键信息
        $timestamp = isset($parsed['timestamp']) ? $parsed['timestamp'] : date('Y-m-d H:i:s');
        $level = isset($parsed['level']) ? $this-\u003enormalizeSeverityLevel($parsed['level']) : null;
        $ip = isset($parsed['ip']) ? $parsed['ip'] : null;
        $status = isset($parsed['status']) \u0026\u0026 is_numeric($parsed['status']) ? intval($parsed['status']) : null;
        $request = isset($parsed['request']) ? substr($parsed['request'], 0, 255) : null;
        $userAgent = isset($parsed['user_agent']) ? $parsed['user_agent'] : null;
        
        // 生成消息内容
        $message = $this-\u003egenerateLogMessage($parsed);
        
        // 移除已单独存储的字段，保留其他作为details
        $details = $parsed;
        unset($details['timestamp'], $details['level'], $details['ip'], $details['status'], $details['request'], $details['user_agent']);
        $detailsJson = json_encode($details);
        
        // 保存到数据库
        $stmt = $this-\u003edb-\u003eprepare("
            INSERT INTO `log_analysis` (
                `timestamp`, `log_file`, `log_type`, `level`, `ip`, `status`, 
                `request`, `user_agent`, `message`, `details`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt-\u003ebind_param(
            'ssssisssss',
            $timestamp, $logFile, $logType, $level, $ip, $status, 
            $request, $userAgent, $message, $detailsJson
        );
        
        $stmt-\u003eexecute();
    }
    
    /**
     * 生成日志消息
     * 
     * @param array $parsed 解析后的日志
     * @return string 消息内容
     */
    private function generateLogMessage($parsed) {
        if (isset($parsed['message'])) {
            return $parsed['message'];
        } elseif (isset($parsed['request'])) {
            return $parsed['request'];
        }
        
        // 如果没有直接的消息字段，尝试构建一个
        $parts = [];
        foreach ($parsed as $key =\u003e $value) {
            if (is_scalar($value) \u0026\u0026 !empty($value) \u0026\u0026 $key !== 'timestamp') {
                $parts[] = "$key: $value";
            }
        }
        
        return implode(', ', $parts);
    }
    
    /**
     * 生成错误统计
     * 
     * @param array $errors 错误列表
     * @param int $limit 限制数量
     * @return array 错误统计
     */
    private function generateTopErrors($errors, $limit = 10) {
        $errorCounts = [];
        
        foreach ($errors as $error) {
            $message = isset($error['message']) ? $error['message'] : 'Unknown error';
            // 提取错误消息的前100个字符作为键
            $key = substr($message, 0, 100);
            
            if (!isset($errorCounts[$key])) {
                $errorCounts[$key] = 0;
            }
            $errorCounts[$key]++;
        }
        
        // 按出现次数排序
        arsort($errorCounts);
        
        // 取前N个
        $topErrors = array_slice($errorCounts, 0, $limit, true);
        
        // 转换格式
        $result = [];
        foreach ($topErrors as $message =\u003e $count) {
            $result[] = ['message' =\u003e $message, 'count' =\u003e $count];
        }
        
        return $result;
    }
    
    /**
     * 获取时间戳范围
     * 
     * @param array $timestamps 时间戳列表
     * @return array 时间范围
     */
    private function getTimestampRange($timestamps) {
        if (empty($timestamps)) {
            return ['start' =\u003e null, 'end' =\u003e null];
        }
        
        return [
            'start' =\u003e min($timestamps),
            'end' =\u003e max($timestamps),
        ];
    }
    
    /**
     * 保存分析结果到数据库
     * 
     * @param array $results 分析结果
     */
    private function saveAnalysisResults($results) {
        $date = date('Y-m-d');
        $logFile = $results['file'];
        
        // 准备数据
        $totalEntries = $results['parsed_lines'];
        $errorCount = count($results['errors']);
        $warningCount = count($results['warnings']);
        $uniqueIps = count(array_unique($results['ip_addresses']));
        $topErrors = json_encode($results['top_errors']);
        
        // 生成请求路径统计
        $topPaths = $this-\u003egenerateTopPaths($results);
        $topPathsJson = json_encode($topPaths);
        
        // 生成性能指标
        $performanceMetrics = $this-\u003egeneratePerformanceMetrics($results);
        $performanceMetricsJson = json_encode($performanceMetrics);
        
        // 保存或更新数据库
        $stmt = $this-\u003edb-\u003eprepare("
            INSERT INTO `log_analysis_results` (
                `date`, `log_file`, `total_entries`, `error_count`, `warning_count`,
                `unique_ips`, `top_errors`, `top_paths`, `performance_metrics`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                `total_entries` = VALUES(`total_entries`),
                `error_count` = VALUES(`error_count`),
                `warning_count` = VALUES(`warning_count`),
                `unique_ips` = VALUES(`unique_ips`),
                `top_errors` = VALUES(`top_errors`),
                `top_paths` = VALUES(`top_paths`),
                `performance_metrics` = VALUES(`performance_metrics`)
        ");
        
        $stmt-\u003ebind_param(
            'ssiiissss',
            $date, $logFile, $totalEntries, $errorCount, $warningCount,
            $uniqueIps, $topErrors, $topPathsJson, $performanceMetricsJson
        );
        
        $stmt-\u003eexecute();
    }
    
    /**
     * 生成请求路径统计
     * 
     * @param array $results 分析结果
     * @param int $limit 限制数量
     * @return array 路径统计
     */
    private function generateTopPaths($results, $limit = 10) {
        $pathCounts = [];
        
        // 从解析的日志中提取路径信息
        foreach ($results['errors'] as $error) {
            if (isset($error['request'])) {
                $path = $this-\u003eextractPathFromRequest($error['request']);
                if ($path) {
                    $pathCounts[$path] = isset($pathCounts[$path]) ? $pathCounts[$path] + 1 : 1;
                }
            }
        }
        
        // 排序并取前N个
        arsort($pathCounts);
        $topPaths = array_slice($pathCounts, 0, $limit, true);
        
        // 转换格式
        $result = [];
        foreach ($topPaths as $path =\u003e $count) {
            $result[] = ['path' =\u003e $path, 'count' =\u003e $count];
        }
        
        return $result;
    }
    
    /**
     * 从请求中提取路径
     * 
     * @param string $request 请求字符串
     * @return string 路径
     */
    private function extractPathFromRequest($request) {
        // 假设请求格式如 "GET /path/to/resource HTTP/1.1"
        if (preg_match('/^[A-Z]+\\s+([^\\s]+)/', $request, $matches)) {
            // 移除查询参数
            $path = explode('?', $matches[1])[0];
            return $path;
        }
        
        return $request;
    }
    
    /**
     * 生成性能指标
     * 
     * @param array $results 分析结果
     * @return array 性能指标
     */
    private function generatePerformanceMetrics($results) {
        // 这里应该基于日志中的响应时间等信息生成性能指标
        // 暂时返回一些基本统计信息
        return [
            'request_rate' =\u003e 0,
            'avg_response_time' =\u003e null,
            'max_response_time' =\u003e null,
            'min_response_time' =\u003e null,
            'error_rate' =\u003e $results['parsed_lines'] \u003e 0 ? (count($results['errors']) / $results['parsed_lines']) * 100 : 0,
            'warning_rate' =\u003e $results['parsed_lines'] \u003e 0 ? (count($results['warnings']) / $results['parsed_lines']) * 100 : 0,
        ];
    }
    
    /**
     * 分析所有添加的日志文件
     * 
     * @param int $limit 每个文件的最大读取行数
     * @return array 分析结果
     */
    public function analyzeAllLogFiles($limit = null) {
        $allResults = [];
        $summary = [
            'total_files' =\u003e count($this-\u003elogFiles),
            'total_lines' =\u003e 0,
            'total_errors' =\u003e 0,
            'total_warnings' =\u003e 0,
            'file_results' =\u003e [],
        ];
        
        foreach ($this-\u003elogFiles as $file) {
            $result = $this-\u003eanalyzeLogFile($file['path'], $file['type'], $limit);
            $allResults[] = $result;
            
            // 更新汇总信息
            $summary['file_results'][] = [
                'file' =\u003e $file['path'],
                'lines' =\u003e $result['total_lines'] ?? 0,
                'errors' =\u003e count($result['errors'] ?? []),
                'warnings' =\u003e count($result['warnings'] ?? []),
            ];
            
            $summary['total_lines'] += $result['total_lines'] ?? 0;
            $summary['total_errors'] += count($result['errors'] ?? []);
            $summary['total_warnings'] += count($result['warnings'] ?? []);
        }
        
        return [
            'summary' =\u003e $summary,
            'results' =\u003e $allResults,
        ];
    }
    
    /**
     * 搜索日志内容
     * 
     * @param string $searchTerm 搜索词
     * @param array $options 搜索选项
     * @return array 搜索结果
     */
    public function searchLogs($searchTerm, $options = []) {
        $defaults = [
            'log_files' =\u003e [],
            'start_time' =\u003e null,
            'end_time' =\u003e null,
            'severity' =\u003e null,
            'limit' =\u003e 1000,
            'regex' =\u003e false,
        ];
        
        $options = array_merge($defaults, $options);
        
        // 构建查询
        $whereClause = [];
        $params = [];
        $types = '';
        
        // 搜索词条件
        if ($options['regex']) {
            $whereClause[] = "(`message` REGEXP ? OR `details` REGEXP ?)";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $types .= 'ss';
        } else {
            $whereClause[] = "(`message` LIKE ? OR `details` LIKE ?)";
            $params[] = "%$searchTerm%";
            $params[] = "%$searchTerm%";
            $types .= 'ss';
        }
        
        // 日志文件条件
        if (!empty($options['log_files'])) {
            $placeholders = implode(',', array_fill(0, count($options['log_files']), '?'));
            $whereClause[] = "`log_file` IN ($placeholders)";
            foreach ($options['log_files'] as $file) {
                $params[] = $file;
                $types .= 's';
            }
        }
        
        // 时间范围条件
        if ($options['start_time']) {
            $whereClause[] = "`timestamp` \u003e= ?";
            $params[] = $options['start_time'];
            $types .= 's';
        }
        
        if ($options['end_time']) {
            $whereClause[] = "`timestamp` \u003c= ?";
            $params[] = $options['end_time'];
            $types .= 's';
        }
        
        // 严重级别条件
        if ($options['severity']) {
            $whereClause[] = "`level` = ?";
            $params[] = $options['severity'];
            $types .= 's';
        }
        
        // 构建SQL
        $sql = "SELECT * FROM `log_analysis` WHERE " . implode(' AND ', $whereClause) . " ORDER BY `timestamp` DESC LIMIT ?";
        $params[] = $options['limit'];
        $types .= 'i';
        
        // 执行查询
        $stmt = $this-\u003edb-\u003eprepare($sql);
        
        // 绑定参数
        if (count($params) \u003e 0) {
            $stmt-\u003ebind_param($types, ...$params);
        }
        
        $stmt-\u003eexecute();
        $result = $stmt-\u003eget_result();
        
        $logs = [];
        while ($row = $result-\u003efetch_assoc()) {
            // 解析JSON字段
            $row['details'] = json_decode($row['details'], true);
            $logs[] = $row;
        }
        
        return [
            'search_term' =\u003e $searchTerm,
            'results_count' =\u003e count($logs),
            'logs' =\u003e $logs,
        ];
    }
    
    /**
     * 清理过期日志数据
     * 
     * @param int $days 保留天数
     * @return int 删除的记录数
     */
    public function cleanupOldLogs($days = null) {
        $days = $days ?? $this-\u003econfig['log_retention_days'];
        $cutoffDate = date('Y-m-d', strtotime("-$days days"));
        
        $deletedRows = 0;
        
        // 清理日志分析表
        $stmt = $this-\u003edb-\u003eprepare("DELETE FROM `log_analysis` WHERE `timestamp` \u003c ? LIMIT ?");
        $stmt-\u003ebind_param('si', $cutoffDate, 10000);
        
        // 分批删除以避免锁定表
        $rowCount = 0;
        do {
            $stmt-\u003eexecute();
            $rowCount = $this-\u003edb-\u003eaffected_rows;
            $deletedRows += $rowCount;
        } while ($rowCount \u003e 0);
        
        // 清理分析结果表
        $stmt = $this-\u003edb-\u003eprepare("DELETE FROM `log_analysis_results` WHERE `date` \u003c ?");
        $stmt-\u003ebind_param('s', $cutoffDate);
        $stmt-\u003eexecute();
        $deletedRows += $this-\u003edb-\u003eaffected_rows;
        
        return $deletedRows;
    }
    
    /**
     * 获取日志统计信息
     * 
     * @param string $startDate 开始日期
     * @param string $endDate 结束日期
     * @return array 统计信息
     */
    public function getLogStatistics($startDate = null, $endDate = null) {
        $startDate = $startDate ?? date('Y-m-d', strtotime('-7 days'));
        $endDate = $endDate ?? date('Y-m-d');
        
        // 检查缓存
        $cacheKey = $this-\u003egetCacheKey('stats', $startDate, $endDate);
        $cachedResult = $this-\u003egetFromCache($cacheKey);
        if ($cachedResult) {
            return $cachedResult;
        }
        
        $stats = [
            'date_range' =\u003e ['start' =\u003e $startDate, 'end' =\u003e $endDate],
            'daily_stats' =\u003e [],
            'severity_counts' =\u003e [],
            'top_errors' =\u003e [],
            'log_files' =\u003e [],
        ];
        
        // 获取每日统计
        $stmt = $this-\u003edb-\u003eprepare("
            SELECT 
                DATE(`timestamp`) as `date`,
                COUNT(*) as `total`,
                SUM(CASE WHEN `level` = 'error' OR `level` = 'critical' THEN 1 ELSE 0 END) as `errors`,
                SUM(CASE WHEN `level` = 'warning' THEN 1 ELSE 0 END) as `warnings`
            FROM `log_analysis`
            WHERE DATE(`timestamp`) BETWEEN ? AND ?
            GROUP BY `date`
            ORDER BY `date`
        ");
        
        $stmt-\u003ebind_param('ss', $startDate, $endDate);
        $stmt-\u003eexecute();
        $result = $stmt-\u003eget_result();
        
        while ($row = $result-\u003efetch_assoc()) {
            $stats['daily_stats'][] = $row;
        }
        
        // 获取严重级别统计
        $stmt = $this-\u003edb-\u003eprepare("
            SELECT `level`, COUNT(*) as `count`
            FROM `log_analysis`
            WHERE DATE(`timestamp`) BETWEEN ? AND ?
            GROUP BY `level`
        ");
        
        $stmt-\u003ebind_param('ss', $startDate, $endDate);
        $stmt-\u003eexecute();
        $result = $stmt-\u003eget_result();
        
        while ($row = $result-\u003efetch_assoc()) {
            $stats['severity_counts'][$row['level']] = $row['count'];
        }
        
        // 获取日志文件统计
        $stmt = $this-\u003edb-\u003eprepare("
            SELECT `log_file`, COUNT(*) as `count`
            FROM `log_analysis`
            WHERE DATE(`timestamp`) BETWEEN ? AND ?
            GROUP BY `log_file`
            ORDER BY `count` DESC
        ");
        
        $stmt-\u003ebind_param('ss', $startDate, $endDate);
        $stmt-\u003eexecute();
        $result = $stmt-\u003eget_result();
        
        while ($row = $result-\u003efetch_assoc()) {
            $stats['log_files'][] = $row;
        }
        
        // 保存到缓存
        $this-\u003esaveToCache($cacheKey, $stats);
        
        return $stats;
    }
    
    /**
     * 规范化时间戳
     * 
     * @param string $timestamp 时间戳字符串
     * @return string 规范化后的时间戳
     */
    private function normalizeTimestamp($timestamp) {
        // 尝试解析各种时间格式
        $formats = [
            'Y-m-d H:i:s',
            'd/M/Y:H:i:s O',
            'Y-m-d H:i:s,u',
            'Y/m/d H:i:s',
        ];
        
        foreach ($formats as $format) {
            $date = DateTime::createFromFormat($format, $timestamp);
            if ($date) {
                return $date-\u003eformat('Y-m-d H:i:s');
            }
        }
        
        // 如果都失败，返回当前时间
        return date('Y-m-d H:i:s');
    }
    
    /**
     * 规范化严重级别
     * 
     * @param string $level 原始级别
     * @return string 规范化的级别
     */
    private function normalizeSeverityLevel($level) {
        $level = strtolower($level);
        
        $validLevels = ['debug', 'info', 'warning', 'error', 'critical'];
        
        if (in_array($level, $validLevels)) {
            return $level;
        }
        
        // 映射常见的别名
        $aliases = [
            'notice' =\u003e 'info',
            'warn' =\u003e 'warning',
            'err' =\u003e 'error',
            'crit' =\u003e 'critical',
            'emergency' =\u003e 'critical',
            'alert' =\u003e 'critical',
        ];
        
        return isset($aliases[$level]) ? $aliases[$level] : 'info';
    }
    
    /**
     * 获取缓存键
     * 
     * @param string $prefix 前缀
     * @param mixed ...$args 其他参数
     * @return string 缓存键
     */
    private function getCacheKey($prefix, ...$args) {
        $parts = array_merge([$prefix], $args);
        return $this-\u003econfig['redis_prefix'] . md5(implode(':', $parts));
    }
    
    /**
     * 从缓存获取数据
     * 
     * @param string $key 缓存键
     * @return mixed 缓存数据
     */
    private function getFromCache($key) {
        // 首先检查内存缓存
        if (isset($this-\u003ecache[$key])) {
            return $this-\u003ecache[$key];
        }
        
        // 检查Redis缓存
        try {
            $data = $this-\u003eredis-\u003eget($key);
            if ($data) {
                $result = json_decode($data, true);
                // 更新内存缓存
                $this-\u003ecache[$key] = $result;
                return $result;
            }
        } catch (Exception $e) {
            // Redis错误时静默继续
            error_log("Redis cache error: " . $e-\u003eggetMessage());
        }
        
        return null;
    }
    
    /**
     * 保存数据到缓存
     * 
     * @param string $key 缓存键
     * @param mixed $data 要缓存的数据
     */
    private function saveToCache($key, $data) {
        // 更新内存缓存
        $this-\u003ecache[$key] = $data;
        
        // 更新Redis缓存
        try {
            $this-\u003eredis-\u003esetex($key, $this-\u003econfig['cache_ttl'], json_encode($data));
        } catch (Exception $e) {
            // Redis错误时静默继续
            error_log("Redis cache error: " . $e-\u003eggetMessage());
        }
    }
    
    /**
     * 添加异常检测模式
     * 
     * @param string $name 模式名称
     * @param string $pattern 模式表达式
     * @param bool $regex 是否为正则表达式
     * @param string $severity 严重级别
     * @param string $description 描述
     * @return bool 是否成功
     */
    public function addExceptionPattern($name, $pattern, $regex = true, $severity = 'warning', $description = '') {
        $stmt = $this-\u003edb-\u003eprepare("
            INSERT INTO `log_exception_patterns` (`name`, `pattern`, `regex`, `severity`, `description`)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `regex` = VALUES(`regex`), 
                   `severity` = VALUES(`severity`), `description` = VALUES(`description`)
        
        ");
        
        $stmt-\u003ebind_param('ssiss', $name, $pattern, $regex, $severity, $description);
        return $stmt-\u003eexecute();
    }
    
    /**
     * 移除异常检测模式
     * 
     * @param int $patternId 模式ID
     * @return bool 是否成功
     */
    public function removeExceptionPattern($patternId) {
        $stmt = $this-\u003edb-\u003eprepare("DELETE FROM `log_exception_patterns` WHERE `id` = ?");
        $stmt-\u003ebind_param('i', $patternId);
        return $stmt-\u003eexecute();
    }
    
    /**
     * 获取所有异常检测模式
     * 
     * @return array 异常模式列表
     */
    public function getExceptionPatterns() {
        $stmt = $this-\u003edb-\u003eprepare("SELECT * FROM `log_exception_patterns` ORDER BY `severity` DESC, `name` ASC");
        $stmt-\u003eexecute();
        $result = $stmt-\u003eget_result();
        
        $patterns = [];
        while ($row = $result-\u003efetch_assoc()) {
            $patterns[] = $row;
        }
        
        return $patterns;
    }
    
    /**
     * 生成性能指标
     * 
     * @param array $results 分析结果
     * @return array 性能指标
     */
    private function generatePerformanceMetrics($results) {
        // 这里应该基于实际的日志内容生成性能指标
        // 例如响应时间、请求率等
        return [
            'request_rate' =\u003e 0,
            'error_rate' =\u003e 0,
            'response_times' =\u003e [],
        ];
    }
    
    /**
     * 析构函数，清理资源
     */
    public function __destruct() {
        // 数据库连接会在脚本结束时自动关闭
        // Redis连接会在脚本结束时自动关闭
    }
}

// 使用示例
/*
$db = new mysqli('localhost', 'username', 'password', 'monitoring_db');
$redis = new Redis();
$redis-\u003econnect('localhost', 6379);

$logAnalyzer = new LogAnalyzer($db, $redis);

// 添加日志文件
$logAnalyzer-\u003eaddLogFile('/var/log/apache2/access.log', 'apache_access');
$logAnalyzer-\u003eaddLogFile('/var/log/php7.4-fpm.log', 'php_error');

// 分析单个日志文件
$result = $logAnalyzer-\u003eanalyzeLogFile('/var/log/apache2/access.log', 'apache_access');
print_r($result);

// 分析所有日志文件
$allResults = $logAnalyzer-\u003eanalyzeAllLogFiles();
print_r($allResults);

// 搜索日志
$searchResults = $logAnalyzer-\u003esearchLogs('Error 500', ['severity' =\u003e 'error']);
print_r($searchResults);

// 获取统计信息
$stats = $logAnalyzer-\u003 egetLogStatistics(date('Y-m-d', strtotime('-7 days')), date('Y-m-d'));
print_r($stats);

// 清理过期日志数据
$deletedRows = $logAnalyzer-\u003ecleanupOldLogs(14);
echo "清理了 $deletedRows 条过期日志记录\n";
*/