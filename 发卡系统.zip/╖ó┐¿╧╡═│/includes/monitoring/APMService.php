<?php
/**
 * 系统性能监控APM服务
 * 提供性能指标收集、分析和可视化功能
 * 
 * @package CardSystem\Monitoring
 * @author System Developer
 * @version 1.0.0
 */

// 移除不存在的命名空间引用

// 尝试引入基本的Logger类
if (file_exists(__DIR__ . '/../Logger.php')) {
    require_once __DIR__ . '/../Logger.php';
}

/**
 * APMService类 - 应用性能监控服务
 */
class APMService
{
    /**
     * 配置管理器实例
     * @var object
     */
    private $configManager;
    
    /**
     * HTTP客户端实例
     * @var object
     */
    private $httpClient;
    
    /**
     * 日志记录器实例
     * @var object
     */
    private $logger;
    
    /**
     * Redis客户端实例
     * @var object
     */
    private $redisClient;
    
    /**
     * APM配置
     * @var array
     */
    private $config;
    
    /**
     * 性能数据收集器
     * @var array
     */
    private $collectors = [];
    
    /**
     * 活动事务列表
     * @var array
     */
    private $activeTransactions = [];
    
    /**
     * 指标缓存
     * @var array
     */
    private $metricsCache = [];
    
    /**
     * 构造函数
     * 
     * @param object $configManager 配置管理器
     * @param object $httpClient HTTP客户端
     * @param object $logger 日志记录器
     * @param object $redisClient Redis客户端
     */
    public function __construct($configManager = null, $httpClient = null, 
                             $logger = null, $redisClient = null)
    {
        // 提供默认值，防止未定义类型错误
        $this->configManager = $configManager ?? (object)['get' => function($key, $default = []) { return $default; }];
        $this->httpClient = $httpClient;
        
        // 如果没有提供logger，尝试创建默认的Logger实例
        $this->logger = $logger;
        if (!$this->logger && class_exists('Logger')) {
            try {
                $this->logger = new Logger();
            } catch (\Exception $e) {
                // 如果Logger类不可用，创建一个简单的日志对象
                $this->logger = (object)[
                    'info' => function($message) { error_log('[INFO] ' . $message); },
                    'warning' => function($message) { error_log('[WARNING] ' . $message); },
                    'error' => function($message) { error_log('[ERROR] ' . $message); }
                ];
            }
        }
        
        $this->redisClient = $redisClient;
        
        // 加载配置
        $this->config = $this->configManager->get('monitoring', []);
        
        // 初始化收集器
        $this->initCollectors();
        
        // 安全地调用logger方法
        if ($this->logger && is_object($this->logger) && isset($this->logger->info) && is_callable($this->logger->info)) {
            ($this->logger->info)('APM监控服务初始化成功');
        }
    }
    
    /**
     * 初始化性能数据收集器
     */
    private function initCollectors()
    {
        // 注册各种收集器
        $this->collectors = [
            'request_metrics' => new RequestMetricsCollector(),
            'database_metrics' => new DatabaseMetricsCollector(),
            'memory_metrics' => new MemoryMetricsCollector(),
            'error_metrics' => new ErrorMetricsCollector(),
            'redis_metrics' => new RedisMetricsCollector()
        ];
        
        $this->logger->info("初始化了 " . count($this->collectors) . " 个性能数据收集器");
    }
    
    /**
     * 开始性能事务记录
     * 
     * @param string $transactionName 事务名称
     * @param string $type 事务类型
     * @return string 事务ID
     */
    public function startTransaction($transactionName, $type = 'request')
    {
        if (!$this->config['metrics_enabled']) {
            return null;
        }
        
        $transactionId = uniqid('tx_', true);
        $this->activeTransactions[$transactionId] = [
            'id' => $transactionId,
            'name' => $transactionName,
            'type' => $type,
            'start_time' => microtime(true),
            'start_memory' => memory_get_usage(true),
            'spans' => [],
            'tags' => [],
            'status' => 'active'
        ];
        
        return $transactionId;
    }
    
    /**
     * 结束性能事务记录
     * 
     * @param string $transactionId 事务ID
     * @param string $status 事务状态
     * @return array 事务统计信息
     */
    public function endTransaction($transactionId, $status = 'success')
    {
        if (!$this->config['metrics_enabled'] || !isset($this->activeTransactions[$transactionId])) {
            return null;
        }
        
        $transaction = $this->activeTransactions[$transactionId];
        $transaction['end_time'] = microtime(true);
        $transaction['end_memory'] = memory_get_usage(true);
        $transaction['duration'] = $transaction['end_time'] - $transaction['start_time'];
        $transaction['memory_used'] = $transaction['end_memory'] - $transaction['start_memory'];
        $transaction['status'] = $status;
        
        // 移除活动事务
        unset($this->activeTransactions[$transactionId]);
        
        // 记录事务统计
        $this->updateTransactionMetrics($transaction);
        
        // 如果启用了追踪，发送到追踪系统
        if ($this->config['tracing_enabled']) {
            $this->sendTransactionToTracing($transaction);
        }
        
        return $transaction;
    }
    
    /**
     * 记录事务内的子操作（span）
     * 
     * @param string $transactionId 事务ID
     * @param string $spanName Span名称
     * @param string $type Span类型
     * @return string Span ID
     */
    public function startSpan($transactionId, $spanName, $type = 'general')
    {
        if (!$this->config['metrics_enabled'] || !isset($this->activeTransactions[$transactionId])) {
            return null;
        }
        
        $spanId = uniqid('span_', true);
        $this->activeTransactions[$transactionId]['spans'][$spanId] = [
            'id' => $spanId,
            'name' => $spanName,
            'type' => $type,
            'start_time' => microtime(true),
            'start_memory' => memory_get_usage(true),
            'tags' => [],
            'status' => 'active'
        ];
        
        return $spanId;
    }
    
    /**
     * 结束Span记录
     * 
     * @param string $transactionId 事务ID
     * @param string $spanId Span ID
     * @param string $status 状态
     */
    public function endSpan($transactionId, $spanId, $status = 'success')
    {
        if (!$this->config['metrics_enabled'] || !isset($this->activeTransactions[$transactionId]) ||
            !isset($this->activeTransactions[$transactionId]['spans'][$spanId])) {
            return;
        }
        
        $span = $this->activeTransactions[$transactionId]['spans'][$spanId];
        $span['end_time'] = microtime(true);
        $span['end_memory'] = memory_get_usage(true);
        $span['duration'] = $span['end_time'] - $span['start_time'];
        $span['memory_used'] = $span['end_memory'] - $span['start_memory'];
        $span['status'] = $status;
        
        // 更新Span信息
        $this->activeTransactions[$transactionId]['spans'][$spanId] = $span;
        
        // 更新相关指标
        if ($span['type'] === 'database') {
            $this->updateDatabaseMetrics($span);
        } elseif ($span['type'] === 'redis') {
            $this->updateRedisMetrics($span);
        }
    }
    
    /**
     * 收集所有性能指标
     * 
     * @return array 所有性能指标
     */
    public function collectAllMetrics()
    {
        $metrics = [];
        
        // 从所有收集器收集指标
        foreach ($this->collectors as $name => $collector) {
            try {
                $collectorMetrics = $collector->collect();
                $metrics = array_merge($metrics, $collectorMetrics);
            } catch (\Exception $e) {
                $this->logger->error("收集器 {$name} 收集指标异常: {$e->getMessage()}");
            }
        }
        
        // 添加系统级指标
        $metrics = array_merge($metrics, $this->collectSystemMetrics());
        
        // 缓存指标
        $this->metricsCache = $metrics;
        
        // 存储到Redis
        try {
            $this->redisClient->set('card_system:apm:metrics', json_encode($metrics), 60);
        } catch (\Exception $e) {
            $this->logger->warning("存储APM指标到Redis失败: {$e->getMessage()}");
        }
        
        return $metrics;
    }
    
    /**
     * 收集系统级指标
     * 
     * @return array 系统指标
     */
    private function collectSystemMetrics()
    {
        return [
            'system.timestamp' => time(),
            'system.php_version' => PHP_VERSION,
            'system.server_info' => $_SERVER['SERVER_SOFTWARE'] ?? '',
            'system.memory_usage' => memory_get_usage(true),
            'system.memory_peak' => memory_get_peak_usage(true),
            'system.active_transactions' => count($this->activeTransactions),
            'system.uptime' => time() - $_SERVER['REQUEST_TIME']
        ];
    }
    
    /**
     * 更新事务指标
     * 
     * @param array $transaction 事务信息
     */
    private function updateTransactionMetrics($transaction)
    {
        // 更新请求指标收集器
        if ($transaction['type'] === 'request') {
            $this->collectors['request_metrics']->addRequestMetric(
                $transaction['duration'],
                $transaction['memory_used'],
                $transaction['status']
            );
        }
    }
    
    /**
     * 更新数据库指标
     * 
     * @param array $span Span信息
     */
    private function updateDatabaseMetrics($span)
    {
        $this->collectors['database_metrics']->addQueryMetric(
            $span['duration'],
            $span['status']
        );
    }
    
    /**
     * 更新Redis指标
     * 
     * @param array $span Span信息
     */
    private function updateRedisMetrics($span)
    {
        $this->collectors['redis_metrics']->addCommandMetric(
            $span['duration'],
            $span['status']
        );
    }
    
    /**
     * 发送事务到追踪系统
     * 
     * @param array $transaction 事务信息
     */
    private function sendTransactionToTracing($transaction)
    {
        try {
            $exporter = $this->config['tracing_exporter'] ?? 'jaeger';
            
            switch ($exporter) {
                case 'jaeger':
                    $this->sendToJaeger($transaction);
                    break;
                
                case 'zipkin':
                    $this->sendToZipkin($transaction);
                    break;
                    
                default:
                    $this->logger->warning("未知的追踪导出器: {$exporter}");
            }
        } catch (\Exception $e) {
            $this->logger->warning("发送追踪数据失败: {$e->getMessage()}");
        }
    }
    
    /**
     * 发送到Jaeger
     * 
     * @param array $transaction 事务信息
     */
    private function sendToJaeger($transaction)
    {
        $endpoint = $this->config['tracing_endpoint'] ?? 'http://jaeger:14268/api/traces';
        
        // 构建Jaeger格式的追踪数据
        $spanData = [
            'traceID' => $transaction['id'],
            'spanID' => $transaction['id'],
            'operationName' => $transaction['name'],
            'references' => [],
            'startTime' => (int)($transaction['start_time'] * 1000000),
            'duration' => (int)($transaction['duration'] * 1000000),
            'tags' => [
                ['key' => 'transaction.type', 'type' => 'string', 'value' => $transaction['type']],
                ['key' => 'transaction.status', 'type' => 'string', 'value' => $transaction['status']],
                ['key' => 'memory.used', 'type' => 'long', 'value' => $transaction['memory_used']]
            ]
        ];
        
        // 添加子Span
        $spans = [$spanData];
        foreach ($transaction['spans'] as $span) {
            $spans[] = [
                'traceID' => $transaction['id'],
                'spanID' => $span['id'],
                'operationName' => $span['name'],
                'references' => [
                    ['refType' => 'CHILD_OF', 'traceID' => $transaction['id'], 'spanID' => $transaction['id']]
                ],
                'startTime' => (int)($span['start_time'] * 1000000),
                'duration' => (int)($span['duration'] * 1000000),
                'tags' => [
                    ['key' => 'span.type', 'type' => 'string', 'value' => $span['type']],
                    ['key' => 'span.status', 'type' => 'string', 'value' => $span['status']]
                ]
            ];
        }
        
        // 发送追踪数据
        $payload = ['spans' => $spans];
        $this->httpClient->post($endpoint, $payload, [
            'Content-Type' => 'application/json'
        ]);
    }
    
    /**
     * 发送到Zipkin
     * 
     * @param array $transaction 事务信息
     */
    private function sendToZipkin($transaction)
    {
        // 实现Zipkin追踪发送逻辑
        // 此部分略，与Jaeger类似但格式不同
    }
    
    /**
     * 获取性能指标数据用于监控面板
     * 
     * @param string $timeRange 时间范围
     * @return array 监控面板数据
     */
    public function getDashboardData($timeRange = '1h')
    {
        // 确保有最新指标
        if (empty($this->metricsCache)) {
            $this->collectAllMetrics();
        }
        
        // 构建面板数据
        $dashboard = [
            'overview' => [
                'requests_per_minute' => $this->metricsCache['request.rate'] ?? 0,
                'avg_response_time' => $this->metricsCache['request.avg_duration'] ?? 0,
                'error_rate' => $this->metricsCache['error.rate'] ?? 0,
                'memory_usage' => $this->metricsCache['system.memory_usage'] ?? 0,
                'uptime' => $this->metricsCache['system.uptime'] ?? 0
            ],
            'charts' => [
                'response_time_trend' => $this->getResponseTimeTrend($timeRange),
                'request_rate_trend' => $this->getRequestRateTrend($timeRange),
                'error_rate_trend' => $this->getErrorRateTrend($timeRange),
                'memory_usage_trend' => $this->getMemoryUsageTrend($timeRange)
            ],
            'top_slowest' => [
                'endpoints' => $this->getTopSlowestEndpoints(10),
                'database_queries' => $this->getTopSlowestDatabaseQueries(10)
            ],
            'timestamp' => time()
        ];
        
        return $dashboard;
    }
    
    /**
     * 获取响应时间趋势
     * 
     * @param string $timeRange 时间范围
     * @return array 响应时间趋势数据
     */
    private function getResponseTimeTrend($timeRange)
    {
        // 这里简化处理，实际应该从历史数据中获取
        $points = [];
        $now = time();
        $minutes = $this->getTimeRangeMinutes($timeRange);
        
        for ($i = $minutes; $i >= 0; $i--) {
            $timestamp = $now - ($i * 60);
            // 生成模拟数据，实际应从数据库或Redis中获取
            $avgResponseTime = rand(50, 200) / 1000; // 50-200ms
            $points[] = [
                'timestamp' => $timestamp,
                'value' => $avgResponseTime
            ];
        }
        
        return $points;
    }
    
    /**
     * 获取请求率趋势
     * 
     * @param string $timeRange 时间范围
     * @return array 请求率趋势数据
     */
    private function getRequestRateTrend($timeRange)
    {
        // 类似响应时间趋势，简化处理
        $points = [];
        $now = time();
        $minutes = $this->getTimeRangeMinutes($timeRange);
        
        for ($i = $minutes; $i >= 0; $i--) {
            $timestamp = $now - ($i * 60);
            $requestsPerMinute = rand(100, 500);
            $points[] = [
                'timestamp' => $timestamp,
                'value' => $requestsPerMinute
            ];
        }
        
        return $points;
    }
    
    /**
     * 获取错误率趋势
     * 
     * @param string $timeRange 时间范围
     * @return array 错误率趋势数据
     */
    private function getErrorRateTrend($timeRange)
    {
        // 类似上面的方法，简化处理
        $points = [];
        $now = time();
        $minutes = $this->getTimeRangeMinutes($timeRange);
        
        for ($i = $minutes; $i >= 0; $i--) {
            $timestamp = $now - ($i * 60);
            $errorRate = rand(0, 5); // 0-5%
            $points[] = [
                'timestamp' => $timestamp,
                'value' => $errorRate
            ];
        }
        
        return $points;
    }
    
    /**
     * 获取内存使用趋势
     * 
     * @param string $timeRange 时间范围
     * @return array 内存使用趋势数据
     */
    private function getMemoryUsageTrend($timeRange)
    {
        // 类似上面的方法，简化处理
        $points = [];
        $now = time();
        $minutes = $this->getTimeRangeMinutes($timeRange);
        $baseMemory = $this->metricsCache['system.memory_usage'] ?? 100 * 1024 * 1024; // 100MB
        
        for ($i = $minutes; $i >= 0; $i--) {
            $timestamp = $now - ($i * 60);
            $memoryUsage = $baseMemory + rand(-10 * 1024 * 1024, 10 * 1024 * 1024);
            $points[] = [
                'timestamp' => $timestamp,
                'value' => $memoryUsage
            ];
        }
        
        return $points;
    }
    
    /**
     * 获取最慢的端点
     * 
     * @param int $limit 限制数量
     * @return array 最慢的端点列表
     */
    private function getTopSlowestEndpoints($limit = 10)
    {
        // 简化处理，实际应从性能日志或数据库中获取
        return [
            ['endpoint' => '/api/v1/orders', 'avg_duration' => 0.45, 'count' => 150],
            ['endpoint' => '/api/v1/cards/batch', 'avg_duration' => 0.32, 'count' => 80],
            ['endpoint' => '/api/v1/users/profile', 'avg_duration' => 0.28, 'count' => 200],
            ['endpoint' => '/api/v1/affiliate/reports', 'avg_duration' => 0.25, 'count' => 50],
            ['endpoint' => '/api/v1/payments/verify', 'avg_duration' => 0.22, 'count' => 120]
        ];
    }
    
    /**
     * 获取最慢的数据库查询
     * 
     * @param int $limit 限制数量
     * @return array 最慢的数据库查询列表
     */
    private function getTopSlowestDatabaseQueries($limit = 10)
    {
        // 简化处理，实际应从性能日志或数据库中获取
        return [
            ['query' => 'SELECT * FROM orders WHERE created_at > ? ORDER BY id DESC', 'avg_duration' => 0.18, 'count' => 45],
            ['query' => 'SELECT * FROM users WHERE last_login > ?', 'avg_duration' => 0.15, 'count' => 32],
            ['query' => 'UPDATE cards SET status = ? WHERE id IN (?)', 'avg_duration' => 0.12, 'count' => 58],
            ['query' => 'SELECT COUNT(*) FROM transactions WHERE user_id = ?', 'avg_duration' => 0.10, 'count' => 75]
        ];
    }
    
    /**
     * 将时间范围转换为分钟数
     * 
     * @param string $timeRange 时间范围字符串
     * @return int 分钟数
     */
    private function getTimeRangeMinutes($timeRange)
    {
        $range = strtolower(trim($timeRange));
        
        if (strpos($range, 'h') !== false) {
            $hours = (int)str_replace('h', '', $range);
            return $hours * 60;
        } elseif (strpos($range, 'd') !== false) {
            $days = (int)str_replace('d', '', $range);
            return $days * 24 * 60;
        } elseif (strpos($range, 'm') !== false) {
            $minutes = (int)str_replace('m', '', $range);
            return $minutes;
        }
        
        // 默认1小时
        return 60;
    }
    
    /**
     * 获取Prometheus格式的指标数据
     * 
     * @return string Prometheus格式的指标
     */
    public function getPrometheusMetrics()
    {
        // 确保有最新指标
        if (empty($this->metricsCache)) {
            $this->collectAllMetrics();
        }
        
        $prometheusMetrics = "";
        
        // 转换指标为Prometheus格式
        foreach ($this->metricsCache as $name => $value) {
            // 添加指标注释
            $prometheusMetrics .= "# HELP card_system_" . str_replace('.', '_', $name) . " Card System Metric\n";
            $prometheusMetrics .= "# TYPE card_system_" . str_replace('.', '_', $name) . " gauge\n";
            
            // 添加指标值
            $prometheusMetrics .= "card_system_" . str_replace('.', '_', $name) . " " . $value . "\n";
        }
        
        return $prometheusMetrics;
    }
    
    /**
     * 检查系统健康状态
     * 
     * @return array 健康状态信息
     */
    public function checkSystemHealth()
    {
        $health = [
            'status' => 'healthy',
            'components' => [],
            'timestamp' => time()
        ];
        
        // 检查各组件健康状态
        $components = ['database', 'redis', 'file_system', 'memory'];
        
        foreach ($components as $component) {
            $componentHealth = $this->checkComponentHealth($component);
            $health['components'][$component] = $componentHealth;
            
            // 如果任何组件不健康，整体状态降级
            if ($componentHealth['status'] !== 'healthy') {
                $health['status'] = 'degraded';
            }
        }
        
        return $health;
    }
    
    /**
     * 检查单个组件健康状态
     * 
     * @param string $component 组件名称
     * @return array 组件健康状态
     */
    private function checkComponentHealth($component)
    {
        switch ($component) {
            case 'database':
                // 检查数据库连接
                return $this->checkDatabaseHealth();
                
            case 'redis':
                // 检查Redis连接
                return $this->checkRedisHealth();
                
            case 'file_system':
                // 检查文件系统
                return $this->checkFileSystemHealth();
                
            case 'memory':
                // 检查内存使用
                return $this->checkMemoryHealth();
                
            default:
                return ['status' => 'unknown', 'message' => '未知组件'];
        }
    }
    
    /**
     * 检查数据库健康状态
     * 
     * @return array 数据库健康状态
     */
    private function checkDatabaseHealth()
    {
        try {
            // 这里应该有实际的数据库连接检查
            // 简化处理，假设健康
            return ['status' => 'healthy', 'message' => '数据库连接正常'];
        } catch (\Exception $e) {
            return ['status' => 'unhealthy', 'message' => "数据库连接失败: {$e->getMessage()}"];
        }
    }
    
    /**
     * 检查Redis健康状态
     * 
     * @return array Redis健康状态
     */
    private function checkRedisHealth()
    {
        try {
            $pong = $this->redisClient->ping();
            return ['status' => 'healthy', 'message' => 'Redis连接正常'];
        } catch (\Exception $e) {
            return ['status' => 'unhealthy', 'message' => "Redis连接失败: {$e->getMessage()}"];
        }
    }
    
    /**
     * 检查文件系统健康状态
     * 
     * @return array 文件系统健康状态
     */
    private function checkFileSystemHealth()
    {
        try {
            // 检查磁盘空间
            $diskFree = disk_free_space('/');
            $diskTotal = disk_total_space('/');
            $diskUsedPercent = (($diskTotal - $diskFree) / $diskTotal) * 100;
            
            if ($diskUsedPercent > 90) {
                return ['status' => 'unhealthy', 'message' => "磁盘空间不足: {$diskUsedPercent}% 已使用"];
            } elseif ($diskUsedPercent > 80) {
                return ['status' => 'warning', 'message' => "磁盘空间警告: {$diskUsedPercent}% 已使用"];
            }
            
            return ['status' => 'healthy', 'message' => "磁盘空间正常: {$diskUsedPercent}% 已使用"];
        } catch (\Exception $e) {
            return ['status' => 'unknown', 'message' => "无法检查文件系统: {$e->getMessage()}"];
        }
    }
    
    /**
     * 检查内存健康状态
     * 
     * @return array 内存健康状态
     */
    private function checkMemoryHealth()
    {
        $memoryUsage = memory_get_usage(true);
        $memoryLimit = $this->getMemoryLimit();
        $memoryUsedPercent = ($memoryUsage / $memoryLimit) * 100;
        
        if ($memoryUsedPercent > 90) {
            return ['status' => 'unhealthy', 'message' => "内存使用率过高: {$memoryUsedPercent}% 已使用"];
        } elseif ($memoryUsedPercent > 80) {
            return ['status' => 'warning', 'message' => "内存使用率警告: {$memoryUsedPercent}% 已使用"];
        }
        
        return ['status' => 'healthy', 'message' => "内存使用率正常: {$memoryUsedPercent}% 已使用"];
    }
    
    /**
     * 获取PHP内存限制
     * 
     * @return int 内存限制（字节）
     */
    private function getMemoryLimit()
    {
        $memoryLimit = ini_get('memory_limit');
        if ($memoryLimit == -1) {
            return PHP_INT_MAX; // 无限制
        }
        
        $unit = strtolower(substr($memoryLimit, -1));
        $number = (int)$memoryLimit;
        
        switch ($unit) {
            case 'g':
                return $number * 1024 * 1024 * 1024;
            case 'm':
                return $number * 1024 * 1024;
            case 'k':
                return $number * 1024;
            default:
                return $number;
        }
    }
    
    /**
     * 关闭APM服务
     */
    public function shutdown()
    {
        $this->logger->info('APM监控服务正在关闭...');
        
        // 清理资源
        $this->activeTransactions = [];
        $this->metricsCache = [];
    }
}

/**
 * 基础收集器接口
 */
interface MetricsCollector
{
    public function collect();
}

/**
 * 请求指标收集器
 */
class RequestMetricsCollector implements MetricsCollector
{
    private $requests = [];
    
    public function collect()
    {
        // 简化实现，返回模拟数据
        return [
            'request.rate' => rand(100, 500),
            'request.count' => count($this->requests),
            'request.avg_duration' => rand(50, 200) / 1000,
            'request.max_duration' => rand(300, 1000) / 1000
        ];
    }
    
    public function addRequestMetric($duration, $memoryUsed, $status)
    {
        $this->requests[] = [
            'duration' => $duration,
            'memory_used' => $memoryUsed,
            'status' => $status,
            'timestamp' => microtime(true)
        ];
        
        // 保持数组大小合理
        if (count($this->requests) > 1000) {
            array_shift($this->requests);
        }
    }
}

/**
 * 数据库指标收集器
 */
class DatabaseMetricsCollector implements MetricsCollector
{
    private $queries = [];
    
    public function collect()
    {
        return [
            'database.query_count' => count($this->queries),
            'database.avg_query_time' => rand(10, 100) / 1000,
            'database.slow_query_count' => rand(0, 5)
        ];
    }
    
    public function addQueryMetric($duration, $status)
    {
        $this->queries[] = [
            'duration' => $duration,
            'status' => $status,
            'timestamp' => microtime(true)
        ];
        
        if (count($this->queries) > 1000) {
            array_shift($this->queries);
        }
    }
}

/**
 * Redis指标收集器
 */
class RedisMetricsCollector implements MetricsCollector
{
    private $commands = [];
    
    public function collect()
    {
        return [
            'redis.command_count' => count($this->commands),
            'redis.avg_command_time' => rand(1, 20) / 1000
        ];
    }
    
    public function addCommandMetric($duration, $status)
    {
        $this->commands[] = [
            'duration' => $duration,
            'status' => $status,
            'timestamp' => microtime(true)
        ];
        
        if (count($this->commands) > 1000) {
            array_shift($this->commands);
        }
    }
}

/**
 * 内存指标收集器
 */
class MemoryMetricsCollector implements MetricsCollector
{
    public function collect()
    {
        return [
            'memory.usage' => memory_get_usage(true),
            'memory.peak_usage' => memory_get_peak_usage(true),
            'memory.allocated' => memory_get_usage()
        ];
    }
}

/**
 * 错误指标收集器
 */
class ErrorMetricsCollector implements MetricsCollector
{
    public function collect()
    {
        // 简化实现，返回模拟数据
        return [
            'error.count' => rand(0, 10),
            'error.rate' => rand(0, 5),
            'error.fatal_count' => rand(0, 2)
        ];
    }
}