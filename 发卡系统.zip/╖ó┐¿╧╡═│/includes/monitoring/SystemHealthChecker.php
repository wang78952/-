<?php
/**
 * 系统健康检查器 - 提供系统各组件健康状态的实时监控和报告
 * 实现CPU、内存、磁盘、数据库、Redis等资源监控和性能指标采集
 */
class SystemHealthChecker {
    private $db;           // 数据库连接
    private $redis;        // Redis连接
    private $logger;       // 日志记录器
    private $config;       // 健康检查配置
    private $alertSystem;  // 告警系统引用
    private $metricsStore = []; // 指标存储 - 初始化为空数组

    /**
     * 构造函数
     * @param array $config 配置参数
     */
    public function __construct($config = []) {
        // 初始化数据库连接
        $this->db = new Database();
        
        // 初始化日志记录器
        $this->logger = new Logger('system_health');
        
        // 初始化告警系统
        $this->alertSystem = new AlertSystem();
        
        // 初始化配置
        $this->config = array_merge($this->getDefaultConfig(), $config);
        
        // 初始化Redis连接（如果可用）
        $this->redis = null;
        try {
            $this->redis = new Redis();
            $this->redis->connect($this->config['redis']['host'], $this->config['redis']['port']);
        } catch (Exception $e) {
            $this->logger->warning('无法连接到Redis: ' . $e->getMessage());
        }
        
        // 初始化metricsStore属性，防止在storeMetrics方法中访问未定义属性
        $this->metricsStore = [];
    }

    /**
     * 获取默认配置
     * @return array 默认配置数组
     */
    private function getDefaultConfig() {
        return [
            'check_interval' => 60, // 检查间隔（秒）
            'memory_threshold' => 80, // 内存使用率阈值（%）
            'cpu_threshold' => 85,    // CPU使用率阈值（%）
            'disk_threshold' => 90,   // 磁盘使用率阈值（%）
            'db_connection_timeout' => 5, // 数据库连接超时（秒）
            'redis_connection_timeout' => 3, // Redis连接超时（秒）
            'response_time_threshold' => 2, // 响应时间阈值（秒）
            'log_retention_days' => 7, // 日志保留天数
            'alerts' => [
                'enabled' => true,
                'notification_channels' => ['email', 'webhook'],
                'retry_count' => 3
            ]
        ];
    }

    /**
     * 运行完整的健康检查
     * @return array 健康检查报告
     */
    public function runFullHealthCheck() {
        $startTime = microtime(true);
        
        // 收集所有健康指标
        $report = [
            'timestamp' => date('Y-m-d H:i:s'),
            'system' => $this->checkSystemResources(),
            'database' => $this->checkDatabaseHealth(),
            'redis' => $this->checkRedisHealth(),
            'application' => $this->checkApplicationHealth(),
            'network' => $this->checkNetworkHealth(),
            'performance' => $this->checkPerformance(),
            'storage' => $this->checkStorageHealth(),
            'security' => $this->checkSecurityStatus(),
            'response_time' => (microtime(true) - $startTime) * 1000 // 毫秒
        ];

        // 评估整体健康状态
        $report['status'] = $this->evaluateOverallHealth($report);
        
        // 记录健康检查结果
        $this->logHealthCheck($report);
        
        // 检查是否需要告警
        $this->checkForAlerts($report);
        
        // 存储历史指标
        $this->storeMetrics($report);
        
        return $report;
    }

    /**
     * 检查系统资源使用情况
     * @return array 系统资源状态
     */
    private function checkSystemResources() {
        $metrics = [
            'cpu_usage' => $this->getCpuUsage(),
            'memory_usage' => $this->getMemoryUsage(),
            'load_average' => $this->getLoadAverage(),
            'uptime' => $this->getSystemUptime(),
            'process_count' => $this->getProcessCount(),
            'thread_count' => $this->getThreadCount()
        ];

        // 检查阈值
        $metrics['status'] = $this->checkResourceThresholds($metrics);
        
        return $metrics;
    }

    /**
     * 获取CPU使用率
     * @return float CPU使用率百分比
     */
    private function getCpuUsage() {
        if (PHP_OS_FAMILY === 'Windows') {
            // Windows系统获取CPU使用率
            $output = shell_exec('wmic cpu get loadpercentage /value');
            preg_match('/LoadPercentage=(\d+)/', $output, $matches);
            return isset($matches[1]) ? (float)$matches[1] : 0;
        } else {
            // Linux/Unix系统获取CPU使用率
            $load = sys_getloadavg();
            $cpuCount = shell_exec('nproc') ?: 1;
            return ($load[0] / $cpuCount) * 100;
        }
    }

    /**
     * 获取内存使用情况
     * @return array 内存使用详情
     */
    private function getMemoryUsage() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('systeminfo | findstr "Total Physical Memory Available Physical Memory"');
            // 解析Windows内存信息
            preg_match('/Total Physical Memory:\s+(\d+)\s+MB/', $output, $totalMatches);
            preg_match('/Available Physical Memory:\s+(\d+)\s+MB/', $output, $availableMatches);
            
            $total = isset($totalMatches[1]) ? (int)$totalMatches[1] : 0;
            $available = isset($availableMatches[1]) ? (int)$availableMatches[1] : 0;
            $used = $total - $available;
            $usagePercent = $total > 0 ? ($used / $total) * 100 : 0;
        } else {
            // Linux/Unix系统通过/proc/meminfo获取内存信息
            $memInfo = file_get_contents('/proc/meminfo');
            preg_match('/MemTotal:\s+(\d+)\s+kB/', $memInfo, $totalMatches);
            preg_match('/MemAvailable:\s+(\d+)\s+kB/', $memInfo, $availableMatches);
            
            $total = isset($totalMatches[1]) ? (int)$totalMatches[1] / 1024 : 0; // 转换为MB
            $available = isset($availableMatches[1]) ? (int)$availableMatches[1] / 1024 : 0;
            $used = $total - $available;
            $usagePercent = $total > 0 ? ($used / $total) * 100 : 0;
        }

        return [
            'total_mb' => $total,
            'used_mb' => $used,
            'available_mb' => $available,
            'usage_percent' => $usagePercent
        ];
    }

    /**
     * 获取系统负载平均值
     * @return array 负载平均值
     */
    private function getLoadAverage() {
        if (PHP_OS_FAMILY === 'Windows') {
            // Windows系统模拟负载平均值
            $cpuUsage = $this->getCpuUsage();
            return [
                '1min' => $cpuUsage / 100,
                '5min' => $cpuUsage / 100,
                '15min' => $cpuUsage / 100
            ];
        } else {
            $load = sys_getloadavg();
            return [
                '1min' => $load[0] ?? 0,
                '5min' => $load[1] ?? 0,
                '15min' => $load[2] ?? 0
            ];
        }
    }

    /**
     * 获取系统运行时间
     * @return array 系统运行时间
     */
    private function getSystemUptime() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('systeminfo | findstr "System Boot Time"');
            preg_match('/System Boot Time:\s+(\w+\s+\d+,\s+\d+\s+\d+:\d+:\d+\s+\w+)/', $output, $matches);
            
            if (isset($matches[1])) {
                $bootTime = new DateTime($matches[1]);
                $now = new DateTime();
                $diff = $now->diff($bootTime);
                
                return [
                    'days' => (int)$diff->format('%a'),
                    'hours' => (int)$diff->format('%H'),
                    'minutes' => (int)$diff->format('%i'),
                    'seconds' => (int)$diff->format('%s'),
                    'formatted' => $diff->format('%a days, %H hours, %i minutes')
                ];
            }
        } else {
            // Linux/Unix系统通过/proc/uptime获取运行时间
            $uptime = file_get_contents('/proc/uptime');
            $uptimeSeconds = (float)explode(' ', $uptime)[0];
            
            return [
                'days' => floor($uptimeSeconds / 86400),
                'hours' => floor(($uptimeSeconds % 86400) / 3600),
                'minutes' => floor(($uptimeSeconds % 3600) / 60),
                'seconds' => floor($uptimeSeconds % 60),
                'formatted' => sprintf('%d days, %d hours, %d minutes', 
                    floor($uptimeSeconds / 86400),
                    floor(($uptimeSeconds % 86400) / 3600),
                    floor(($uptimeSeconds % 3600) / 60))
            ];
        }
        
        return [
            'days' => 0,
            'hours' => 0,
            'minutes' => 0,
            'seconds' => 0,
            'formatted' => 'Unknown'
        ];
    }

    /**
     * 获取进程数量
     * @return int 进程数量
     */
    private function getProcessCount() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('tasklist | find /v "find" /c');
            return (int)$output;
        } else {
            $output = shell_exec('ps aux | wc -l');
            return (int)$output - 1; // 减去标题行
        }
    }

    /**
     * 获取线程数量
     * @return int 线程数量
     */
    private function getThreadCount() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('wmic process get ThreadCount | find /v "ThreadCount" | find /v "" /c');
            return (int)$output;
        } else {
            $output = shell_exec('ps -eLf | wc -l');
            return (int)$output - 1; // 减去标题行
        }
    }

    /**
     * 检查资源阈值
     * @param array $metrics 资源指标
     * @return string 状态 (healthy, warning, critical)
     */
    private function checkResourceThresholds($metrics) {
        // 检查CPU使用率
        if ($metrics['cpu_usage'] >= $this->config['cpu_threshold']) {
            return 'critical';
        }
        
        // 检查内存使用率
        if ($metrics['memory_usage']['usage_percent'] >= $this->config['memory_threshold']) {
            return 'critical';
        }
        
        // 检查负载平均值（Linux/Unix系统）
        if (PHP_OS_FAMILY !== 'Windows') {
            $cpuCount = shell_exec('nproc') ?: 1;
            if ($metrics['load_average']['1min'] > $cpuCount * 1.5) {
                return 'warning';
            }
        }
        
        return 'healthy';
    }

    /**
     * 检查数据库健康状态
     * @return array 数据库健康状态
     */
    private function checkDatabaseHealth() {
        $startTime = microtime(true);
        
        try {
            // 检查连接 - 使用更通用的方式检查数据库连接
            $queryTime = microtime(true);
            $result = $this->db->query("SELECT 1 AS test");
            $connected = ($result !== false);
            $queryTime = (microtime(true) - $queryTime) * 1000; // 毫秒
            
            // 检查数据库状态
            $dbStatus = $this->getDatabaseStatus();
            
            // 检查连接池状态
            $connectionPool = $this->getConnectionPoolStatus();
            
            // 检查表状态
            $tableStatus = $this->checkTableStatus();
            
            $metrics = [
                'connected' => $connected,
                'response_time' => (microtime(true) - $startTime) * 1000, // 毫秒
                'query_performance' => $queryTime,
                'version' => $dbStatus['version'] ?? 'Unknown',
                'connections' => $dbStatus['connections'] ?? 0,
                'active_queries' => $dbStatus['active_queries'] ?? 0,
                'connection_pool' => $connectionPool,
                'tables' => $tableStatus,
                'status' => 'healthy'
            ];
            
            // 根据指标确定状态
            if (!$connected) {
                $metrics['status'] = 'critical';
            } elseif ($metrics['query_performance'] > 500) { // 500ms
                $metrics['status'] = 'warning';
            }
            
            return $metrics;
        } catch (Exception $e) {
            return [
                'connected' => false,
                'error' => $e->getMessage(),
                'response_time' => (microtime(true) - $startTime) * 1000,
                'status' => 'critical'
            ];
        }
    }

    /**
     * 获取数据库状态信息
     * @return array 数据库状态
     */
    private function getDatabaseStatus() {
        try {
            // 根据数据库类型获取状态信息
            $result = $this->db->query("SELECT VERSION() AS version");
            $version = $result->fetch_assoc()['version'] ?? 'Unknown';
            
            // 获取连接数和活动查询
            $connections = 0;
            $activeQueries = 0;
            
            // MySQL特定查询
            if (strpos($version, 'MySQL') !== false || strpos($version, 'MariaDB') !== false) {
                $result = $this->db->query("SHOW STATUS LIKE 'Threads_connected'");
                $row = $result->fetch_assoc();
                $connections = $row['Value'] ?? 0;
                
                $result = $this->db->query("SHOW STATUS LIKE 'Questions'");
                $row = $result->fetch_assoc();
                $queries = $row['Value'] ?? 0;
            }
            
            return [
                'version' => $version,
                'connections' => $connections,
                'active_queries' => $activeQueries
            ];
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * 获取连接池状态
     * @return array 连接池状态
     */
    private function getConnectionPoolStatus() {
        // 模拟连接池状态
        return [
            'active' => 1,
            'idle' => 4,
            'total' => 5,
            'max' => 10,
            'utilization' => 50
        ];
    }

    /**
     * 检查数据库表状态
     * @return array 表状态
     */
    private function checkTableStatus() {
        try {
            $result = $this->db->query("SHOW TABLE STATUS");
            $tables = [];
            $problemTables = 0;
            
            while ($row = $result->fetch_assoc()) {
                $tableStatus = [
                    'name' => $row['Name'],
                    'engine' => $row['Engine'] ?? 'Unknown',
                    'rows' => $row['Rows'] ?? 0,
                    'size' => $row['Data_length'] + $row['Index_length'] ?? 0,
                    'auto_increment' => $row['Auto_increment'] ?? 0,
                    'update_time' => $row['Update_time'] ?? 'Never'
                ];
                
                // 检查表是否有问题
                if ($row['Engine'] === null || $row['Data_free'] > 10485760) { // 10MB
                    $problemTables++;
                }
                
                $tables[] = $tableStatus;
            }
            
            return [
                'total' => count($tables),
                'problematic' => $problemTables,
                'status' => $problemTables > 0 ? 'warning' : 'healthy'
            ];
        } catch (Exception $e) {
            return ['error' => $e->getMessage(), 'status' => 'unknown'];
        }
    }

    /**
     * 检查Redis健康状态
     * @return array Redis健康状态
     */
    private function checkRedisHealth() {
        $metrics = [];
        
        // 检查Redis连接
        $metrics['connected'] = $this->isRedisConnected();
        $metrics['key_count'] = 0;
        $metrics['memory_usage'] = null;
        $metrics['status'] = $metrics['connected'] ? 'healthy' : 'warning';
        
        // 如果连接成功，获取更多信息
        if ($metrics['connected'] && isset($this->redis) && is_object($this->redis)) {
            // 获取Redis键数量
            $metrics['key_count'] = $this->getRedisKeyCount();
            
            // 获取Redis信息
            $info = $this->getRedisInfo();
            $metrics['version'] = isset($info['redis_version']) ? $info['redis_version'] : 'Unknown';
            $metrics['memory_usage'] = isset($info['used_memory_human']) ? $info['used_memory_human'] : 'Unknown';
        }
        
        return $metrics;
    }
    
    /**
     * 检查Redis连接状态
     * @return bool 是否连接
     */
    private function isRedisConnected() {
        try {
            if (!isset($this->redis) || !is_object($this->redis)) {
                return false;
            }
            
            if (method_exists($this->redis, 'ping')) {
                try {
                    return $this->redis->ping() !== false;
                } catch (Exception $e) {
                    return false;
                }
            }
            
            // 尝试执行一个简单的命令来验证连接
            if (method_exists($this->redis, 'get') || method_exists($this->redis, 'set')) {
                return true; // 假设连接可用
            }
            
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 获取Redis信息（适配层方法）
     * @return array Redis信息
     */
    private function getRedisInfo() {
        try {
            // 确保redis对象存在
            if (!isset($this->redis) || !is_object($this->redis)) {
                return [
                    'redis_version' => 'Unknown',
                    'redis_mode' => 'Unknown',
                    'used_memory' => 0,
                    'used_memory_human' => '0B',
                    'used_memory_rss' => 0,
                    'maxmemory' => 0,
                    'maxmemory_human' => '0B',
                    'connected_clients' => 0
                ];
            }
            
            if (method_exists($this->redis, 'info')) {
                try {
                    $info = $this->redis->info();
                    // 确保返回的是数组
                    if (is_array($info)) {
                        return $info;
                    }
                } catch (Exception $e) {
                    // 出错时返回模拟信息
                }
            }
            
            // 返回模拟信息
            return [
                'redis_version' => 'Unknown',
                'redis_mode' => 'Unknown',
                'used_memory' => 0,
                'used_memory_human' => '0B',
                'used_memory_rss' => 0,
                'maxmemory' => 0,
                'maxmemory_human' => '0B',
                'connected_clients' => 0
            ];
        } catch (Exception $e) {
            return [];
        }
    }
    
    /**
     * 获取Redis键数量（适配层方法）
     * @return int 键数量
     */
    private function getRedisKeyCount() {
        try {
            // 确保redis对象存在
            if (!isset($this->redis) || !is_object($this->redis)) {
                return 0;
            }
            
            if (method_exists($this->redis, 'dbSize')) {
                try {
                    $count = $this->redis->dbSize();
                    // 确保返回的是整数
                    return is_numeric($count) ? (int)$count : 0;
                } catch (Exception $e) {
                    // 出错时继续尝试其他方法
                }
            }
            
            // 尝试其他可能的方法
            if (method_exists($this->redis, 'keys')) {
                try {
                    $keys = $this->redis->keys('*');
                    // 确保返回的是数组
                    return is_array($keys) ? count($keys) : 0;
                } catch (Exception $e) {
                    // 出错时返回0
                }
            }
            
            return 0;
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * 检查应用程序健康状态
     * @return array 应用程序健康状态
     */
    private function checkApplicationHealth() {
        $metrics = [
            'php_version' => PHP_VERSION,
            'php_sapi' => PHP_SAPI,
            'memory_limit' => ini_get('memory_limit'),
            'execution_time' => ini_get('max_execution_time'),
            'uploads_enabled' => ini_get('file_uploads'),
            'max_upload_size' => ini_get('upload_max_filesize'),
            'modules_loaded' => count(get_loaded_extensions()),
            'error_reporting' => error_reporting(),
            'display_errors' => ini_get('display_errors'),
            'logs_enabled' => $this->logger !== null,
            'status' => 'healthy'
        ];

        // 检查PHP错误
        $errorCount = $this->getRecentErrorCount();
        $metrics['recent_errors'] = $errorCount;
        
        if ($errorCount > 10) { // 如果最近有超过10个错误
            $metrics['status'] = 'warning';
        }
        
        return $metrics;
    }

    /**
     * 获取最近的错误数量
     * @param int $minutes 过去几分钟内的错误
     * @return int 错误数量
     */
    private function getRecentErrorCount($minutes = 5) {
        // 这里应该从日志或数据库中获取错误数量
        // 现在返回一个模拟值
        return 0; // 修改为固定值以避免随机波动
    }

    /**
     * 检查网络健康状态
     * @return array 网络健康状态
     */
    private function checkNetworkHealth() {
        $metrics = [];
        
        // 检查外部连接
        $externalConnectivity = $this->checkExternalConnectivity();
        $metrics['external_connectivity'] = $externalConnectivity['status'];
        $metrics['dns_resolution'] = $this->checkDnsResolution();
        
        // 检查网络延迟
        $latency = $this->checkNetworkLatency();
        $metrics['latency'] = $latency['avg'] ?? 0;
        
        // 确定网络状态
        $metrics['status'] = 'healthy';
        if ($metrics['external_connectivity'] !== 'healthy') {
            $metrics['status'] = $metrics['external_connectivity'];
        } elseif ($metrics['latency'] > 500) { // 500ms
            $metrics['status'] = 'warning';
        }
        
        return $metrics;
    }

    /**
     * 检查外部连接
     * @return array 外部连接状态
     */
    private function checkExternalConnectivity() {
        $hosts = ['8.8.8.8', '1.1.1.1']; // Google DNS, Cloudflare DNS
        $success = 0;
        $total = count($hosts);
        
        foreach ($hosts as $host) {
            $startTime = microtime(true);
            $connection = @fsockopen($host, 53, $errno, $errstr, 2); // 2秒超时
            $latency = (microtime(true) - $startTime) * 1000;
            
            if ($connection) {
                fclose($connection);
                $success++;
            }
        }
        
        $status = 'healthy';
        if ($success === 0) {
            $status = 'critical';
        } elseif ($success < $total) {
            $status = 'warning';
        }
        
        return [
            'status' => $status,
            'success_count' => $success,
            'total_count' => $total
        ];
    }

    /**
     * 检查DNS解析
     * @return string DNS解析状态
     */
    private function checkDnsResolution() {
        $domains = ['www.google.com', 'www.baidu.com'];
        $success = 0;
        
        foreach ($domains as $domain) {
            $ip = gethostbyname($domain);
            if ($ip !== $domain) { // 解析成功
                $success++;
            }
        }
        
        if ($success === 0) {
            return 'critical';
        } elseif ($success < count($domains)) {
            return 'warning';
        }
        
        return 'healthy';
    }

    /**
     * 检查网络延迟
     * @return array 网络延迟数据
     */
    private function checkNetworkLatency() {
        $hosts = ['8.8.8.8', '1.1.1.1'];
        $latencies = [];
        
        foreach ($hosts as $host) {
            $startTime = microtime(true);
            $connection = @fsockopen($host, 53, $errno, $errstr, 2);
            if ($connection) {
                fclose($connection);
                $latency = (microtime(true) - $startTime) * 1000; // 转换为毫秒
                $latencies[] = $latency;
            }
        }
        
        if (empty($latencies)) {
            return ['avg' => 0, 'min' => 0, 'max' => 0, 'status' => 'critical'];
        }
        
        return [
            'avg' => array_sum($latencies) / count($latencies),
            'min' => min($latencies),
            'max' => max($latencies),
            'status' => 'healthy'
        ];
    }

    /**
     * 检查性能指标
     * @return array 性能指标
     */
    private function checkPerformance() {
        // 模拟性能指标收集
        $metrics = [
            'request_rate' => $this->calculateRequestRate(),
            'response_time' => $this->getAverageResponseTime(),
            'throughput' => $this->calculateThroughput(),
            'error_rate' => $this->calculateErrorRate(),
            'status' => 'healthy'
        ];
        
        // 检查性能阈值
        if ($metrics['error_rate'] > 5) { // 错误率超过5%
            $metrics['status'] = 'warning';
        }
        
        return $metrics;
    }

    /**
     * 计算请求率
     * @return float 请求率（每秒请求数）
     */
    private function calculateRequestRate() {
        // 模拟返回请求率
        return rand(10, 100);
    }

    /**
     * 获取平均响应时间
     * @return float 平均响应时间（毫秒）
     */
    private function getAverageResponseTime() {
        // 模拟返回平均响应时间
        return rand(50, 200);
    }

    /**
     * 计算吞吐量
     * @return float 吞吐量（字节/秒）
     */
    private function calculateThroughput() {
        // 模拟返回吞吐量
        return rand(100000, 1000000);
    }

    /**
     * 计算错误率
     * @return float 错误率（百分比）
     */
    private function calculateErrorRate() {
        // 模拟返回错误率
        return rand(0, 5);
    }

    /**
     * 检查存储健康状态
     * @return array 存储健康状态
     */
    private function checkStorageHealth() {
        $disks = $this->getDiskUsage();
        $fileSystem = $this->getFileSystemStatus();
        $backupStatus = $this->checkBackupStatus();
        
        $metrics = [
            'disks' => $disks,
            'file_system' => $fileSystem,
            'backups' => $backupStatus,
            'status' => 'healthy'
        ];
        
        // 检查磁盘空间阈值
        foreach ($disks as $disk) {
            if ($disk['usage_percent'] >= $this->config['disk_threshold']) {
                $metrics['status'] = 'warning';
                break;
            }
        }
        
        return $metrics;
    }

    /**
     * 获取磁盘使用情况
     * @return array 磁盘使用情况
     */
    private function getDiskUsage() {
        $disks = [];
        
        if (PHP_OS_FAMILY === 'Windows') {
            // Windows系统获取磁盘信息
            $output = shell_exec('wmic logicaldisk get caption,size,freespace');
            $lines = explode(PHP_EOL, $output);
            
            foreach ($lines as $line) {
                $parts = preg_split('/\s+/', trim($line));
                if (count($parts) >= 3 && preg_match('/^[A-Z]:$/', $parts[0])) {
                    $drive = $parts[0];
                    $freeSpace = (int)$parts[1];
                    $totalSize = (int)$parts[2];
                    
                    if ($totalSize > 0) {
                        $usedSpace = $totalSize - $freeSpace;
                        $usagePercent = ($usedSpace / $totalSize) * 100;
                        
                        $disks[] = [
                            'device' => $drive,
                            'total_bytes' => $totalSize,
                            'used_bytes' => $usedSpace,
                            'free_bytes' => $freeSpace,
                            'usage_percent' => $usagePercent,
                            'total_gb' => round($totalSize / (1024 * 1024 * 1024), 2),
                            'used_gb' => round($usedSpace / (1024 * 1024 * 1024), 2),
                            'free_gb' => round($freeSpace / (1024 * 1024 * 1024), 2)
                        ];
                    }
                }
            }
        } else {
            // Linux/Unix系统获取磁盘信息
            $output = shell_exec('df -h');
            $lines = explode(PHP_EOL, $output);
            
            foreach ($lines as $line) {
                if (preg_match('/^(\/dev\/\w+)\s+(\d+\.?\d*\w?)\s+(\d+\.?\d*\w?)\s+(\d+\.?\d*\w?)\s+(\d+)%\s+(.+)$/', $line, $matches)) {
                    $disks[] = [
                        'device' => $matches[1],
                        'mount_point' => $matches[6],
                        'total' => $matches[2],
                        'used' => $matches[3],
                        'free' => $matches[4],
                        'usage_percent' => (int)$matches[5]
                    ];
                }
            }
        }
        
        return $disks;
    }

    /**
     * 获取文件系统状态
     * @return array 文件系统状态
     */
    private function getFileSystemStatus() {
        // 模拟文件系统状态
        return [
            'open_files' => rand(100, 500),
            'max_open_files' => 1024,
            'inode_usage' => [
                'total' => 1000000,
                'used' => rand(10000, 50000),
                'free' => 950000,
                'percent' => 5
            ]
        ];
    }

    /**
     * 检查备份状态
     * @return array 备份状态
     */
    private function checkBackupStatus() {
        // 模拟备份状态
        $lastBackup = new DateTime('-' . rand(0, 7) . ' days');
        
        return [
            'last_backup' => $lastBackup->format('Y-m-d H:i:s'),
            'status' => 'healthy',
            'size' => rand(100, 1000) . 'MB',
            'type' => 'full',
            'location' => 'remote_storage'
        ];
    }

    /**
     * 检查安全状态
     * @return array 安全状态
     */
    private function checkSecurityStatus() {
        $metrics = [
            'firewall_status' => $this->checkFirewallStatus(),
            'malware_scan' => $this->checkMalwareScan(),
            'security_updates' => $this->checkSecurityUpdates(),
            'failed_logins' => $this->checkFailedLogins(),
            'status' => 'healthy'
        ];
        
        // 检查安全问题
        if (isset($metrics['failed_logins']['count']) && $metrics['failed_logins']['count'] > 10) { // 最近失败登录次数
            $metrics['status'] = 'warning';
        }
        
        return $metrics;
    }

    /**
     * 检查防火墙状态
     * @return string 防火墙状态
     */
    private function checkFirewallStatus() {
        // 模拟防火墙状态检查
        return 'active';
    }

    /**
     * 检查恶意软件扫描状态
     * @return string 扫描状态
     */
    private function checkMalwareScan() {
        return 'not_scanned'; // 模拟返回未扫描状态
    }

    /**
     * 检查安全更新状态
     * @return array 安全更新信息
     */
    private function checkSecurityUpdates() {
        return ['status' => 'unknown', 'pending_updates' => 0];
    }

    /**
     * 检查失败的登录尝试
     * @return array 失败登录信息
     */
    private function checkFailedLogins() {
        return ['count' => 0, 'last_attempt' => null];
    }

    /**
     * 评估整体健康状态
     * @param array $report 健康检查报告
     * @return string 整体健康状态
     */
    private function evaluateOverallHealth($report) {
        // 如果有任何组件处于critical状态，整体状态为critical
        if ($report['database']['status'] === 'critical' ||
            $report['redis']['status'] === 'critical' ||
            $report['system']['status'] === 'critical' ||
            $report['network']['status'] === 'critical') {
            return 'critical';
        }
        
        // 如果有多个组件处于warning状态，整体状态为warning
        $warningCount = 0;
        foreach (['database', 'redis', 'system', 'application', 'network', 'performance', 'storage', 'security'] as $component) {
            if (isset($report[$component]['status']) && $report[$component]['status'] === 'warning') {
                $warningCount++;
            }
        }
        
        if ($warningCount >= 3) {
            return 'warning';
        }
        
        return 'healthy';
    }

    /**
     * 记录健康检查结果
     * @param array $report 健康检查报告
     */
    private function logHealthCheck($report) {
        $logMessage = "Health Check: Status={$report['status']}, ResponseTime={$report['response_time']}ms";
        
        // 简化日志数据，避免复杂数组嵌套导致的类型错误
        $logData = [
            'status' => $report['status'] ?? 'unknown',
            'response_time' => $report['response_time'] ?? 0,
            'timestamp' => time()
        ];
        
        // 根据状态选择日志级别
        if ($report['status'] === 'critical') {
            $this->logger->error($logMessage, $logData);
        } elseif ($report['status'] === 'warning') {
            $this->logger->warning($logMessage, $logData);
        } else {
            $this->logger->info($logMessage, $logData);
        }
    }

    /**
     * 检查是否需要发送告警
     * @param array $report 健康检查报告
     */
    private function checkForAlerts($report) {
        // 确保alertSystem存在且是对象
        if (!isset($this->alertSystem) || !is_object($this->alertSystem)) {
            return;
        }
        
        // 安全发送告警的辅助函数
        $safeTriggerAlert = function($alertData) {
            try {
                if (isset($this->alertSystem) && is_object($this->alertSystem)) {
                    // 使用更安全的方法调用方式
                    if (method_exists($this->alertSystem, 'triggerAlert') && is_callable([$this->alertSystem, 'triggerAlert'])) {
                        $this->alertSystem->triggerAlert($alertData);
                        return true;
                    } elseif (method_exists($this->alertSystem, 'createAlert') && is_callable([$this->alertSystem, 'createAlert'])) {
                        // 检查是否需要多个参数
                        $reflection = new ReflectionMethod($this->alertSystem, 'createAlert');
                        $params = $reflection->getParameters();
                        // 使用triggerAlert方法替代createAlert（createAlert是私有方法）
                        if (isset($this->alertSystem) && method_exists($this->alertSystem, 'triggerAlert')) {
                            $this->alertSystem->triggerAlert($alertData);
                        } else {
                            $this->logger->warning('无法发送告警: 告警系统或triggerAlert方法不可用');
                        }
                        return true;
                    }
                }
                
                // 如果没有alertSystem或方法不存在，记录到日志
                if (isset($this->logger) && is_object($this->logger)) {
                    $logMessage = "无法发送告警: {$alertData['title']} - {$alertData['message']}";
                    if (method_exists($this->logger, 'error')) {
                        $this->logger->error($logMessage);
                    } elseif (method_exists($this->logger, 'logError')) {
                        $this->logger->logError($logMessage);
                    }
                }
            } catch (Exception $e) {
                // 记录告警发送失败，但不中断流程
                if (isset($this->logger) && is_object($this->logger)) {
                    try {
                        $this->logger->error('Failed to send alert: ' . $e->getMessage());
                    } catch (Exception $logEx) {
                        // 忽略日志记录错误
                    }
                }
            }
            return false;
        };
                

        
        if ($report['status'] === 'critical') {
            $alertData = [
                'alert_type' => 'system_health',
                'severity' => 'critical',
                'title' => '系统健康状态严重异常',
                'message' => "系统整体健康状态为CRITICAL，请立即检查。响应时间: {$report['response_time']}ms",
                'details' => $report
            ];
            
            // 安全地调用alertSystem的triggerAlert方法
            if (isset($this->alertSystem) && method_exists($this->alertSystem, 'triggerAlert')) {
                $this->alertSystem->triggerAlert($alertData);
            } else {
                $this->logger->warning('无法发送告警: 告警系统不可用');
            }
        }
        
        // 检查各个组件的告警条件
        if (isset($report['database']['status']) && $report['database']['status'] === 'critical') {
            // 安全地调用alertSystem的triggerAlert方法
            if (isset($this->alertSystem) && method_exists($this->alertSystem, 'triggerAlert')) {
                $this->alertSystem->triggerAlert([
                    'alert_type' => 'database_health',
                    'severity' => 'critical',
                    'title' => '数据库连接失败',
                    'message' => '无法连接到数据库或数据库响应异常',
                    'details' => $report['database']
                ]);
            } else {
                $this->logger->warning('无法发送告警: 告警系统不可用');
            }
        }
    }

    /**
     * 存储指标数据
     * @param array $report 健康检查报告
     */
    private function storeMetrics($report) {
        // 添加防御性编程检查，确保metricsStore属性已初始化
        if (!isset($this->metricsStore) || !is_array($this->metricsStore)) {
            $this->metricsStore = [];
        }
        
        // 应该将指标数据存储到数据库或时序数据库中
        // 这里只是简单地存储在内存中
        $this->metricsStore[] = [
            'timestamp' => $report['timestamp'],
            'status' => $report['status'],
            'cpu_usage' => $report['system']['cpu_usage'] ?? 0,
            'memory_usage' => $report['system']['memory_usage']['usage_percent'] ?? 0,
            'db_response_time' => $report['database']['response_time'] ?? 0
        ];
        
        // 限制内存中存储的指标数量
        if (count($this->metricsStore) > 1000) {
            array_shift($this->metricsStore);
        }
    }

    /**
     * 获取历史指标数据（公开方法）
     * @param int $limit 限制返回的记录数
     * @return array 历史指标数据
     */
    public function getHistoricalMetrics($limit = 100) {
        // 添加防御性编程检查，确保metricsStore属性已初始化
        if (!isset($this->metricsStore) || !is_array($this->metricsStore)) {
            $this->metricsStore = [];
        }
        return array_slice($this->metricsStore, -$limit);
    }

    /**
     * 生成健康状态仪表板数据
     * @return array 仪表板数据
     */
    public function generateDashboardData() {
        $healthCheck = $this->runFullHealthCheck();
        $historicalMetrics = $this->getHistoricalMetrics(60); // 获取最近60条记录
        
        // 确保alertSystem存在且有getRecentAlerts方法
        $alerts = [];
        try {
            if (isset($this->alertSystem) && is_object($this->alertSystem) && method_exists($this->alertSystem, 'getRecentAlerts') && is_callable([$this->alertSystem, 'getRecentAlerts'])) {
                $result = $this->alertSystem->getRecentAlerts(10);
                // 确保返回的是数组
                $alerts = is_array($result) ? $result : [];
            }
        } catch (Exception $e) {
            $alerts = [];
        }
        
        // 安全获取状态值，避免未定义索引
        $getStatus = function($path, $default = 'unknown') use ($healthCheck) {
            $parts = explode('.', $path);
            $value = $healthCheck;
            
            foreach ($parts as $part) {
                if (!isset($value[$part])) {
                    return $default;
                }
                $value = $value[$part];
            }
            
            return $value;
        };
        
        return [
            'current_status' => $getStatus('status', 'unknown'),
            'response_time' => $getStatus('response_time', 0),
            'system_metrics' => [
                'cpu' => $getStatus('system.cpu_usage', 0),
                'memory' => $getStatus('system.memory_usage.usage_percent', 0),
                'disk' => (string)$this->getHighestDiskUsage($getStatus('storage.disks', []))
            ],
            'service_metrics' => [
                'database' => $getStatus('database.status', 'unknown'),
                'redis' => $getStatus('redis.status', 'unknown'),
                'network' => $getStatus('network.status', 'unknown')
            ],
            'performance_trends' => $this->generatePerformanceTrends($historicalMetrics),
            'alerts' => $alerts,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * 获取最高磁盘使用率
     * @param array $disks 磁盘信息数组
     * @return array 最高使用率的磁盘信息
     */
    private function getHighestDiskUsage($disks) {
        if (empty($disks)) {
            return ['path' => '/', 'usage_percent' => 0];
        }
        
        $maxDisk = $disks[0];
        foreach ($disks as $disk) {
            if ($disk['usage_percent'] > $maxDisk['usage_percent']) {
                $maxDisk = $disk;
            }
        }
        
        return $maxDisk;
    }

    /**
     * 生成性能趋势数据
     * @param array $historicalMetrics 历史指标数据
     * @return array 性能趋势
     */
    private function generatePerformanceTrends($historicalMetrics) {
        // 模拟返回性能趋势数据
        return ['cpu' => [], 'memory' => [], 'response_time' => []];
    }

    /**
     * 运行自动化修复任务
     * @return array 修复结果
     */
    public function runAutoRemediation() {
        $healthCheck = $this->runFullHealthCheck();
        $remediationResults = [];
        
        // 根据不同的健康问题执行修复
        if ($healthCheck['database']['status'] === 'warning' && 
            $healthCheck['database']['query_performance'] > 500) {
            // 执行数据库优化
            $result = $this->optimizeDatabase();
            $remediationResults[] = $result;
        }
        
        if ($healthCheck['system']['memory_usage']['usage_percent'] > 90) {
            // 清理内存缓存
            $result = $this->cleanMemoryCache();
            $remediationResults[] = $result;
        }
        
        return [
            'health_before' => $healthCheck['status'],
            'remediation_actions' => $remediationResults,
            'health_after' => $this->runFullHealthCheck()['status'],
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * 优化数据库
     * @return array 优化结果
     */
    private function optimizeDatabase() {
        try {
            // 检查数据库连接是否存在且可用
            if (!isset($this->db) || !is_object($this->db)) {
                throw new Exception('数据库连接不可用');
            }
            
            // 执行数据库优化操作
            $result = $this->db->query("OPTIMIZE TABLE system_metrics");
            $optimized = $result !== false;
            
            return [
                'status' => $optimized ? 'success' : 'warning', 
                'message' => $optimized ? '数据库优化成功' : '数据库优化部分完成',
                'timestamp' => date('Y-m-d H:i:s')
            ];
        } catch (Exception $e) {
            if (isset($this->logger) && method_exists($this->logger, 'error')) {
                $this->logger->error('数据库优化失败: ' . $e->getMessage());
            }
            return [
                'status' => 'error', 
                'message' => '数据库优化失败: ' . $e->getMessage()
            ];
        }
    }

    /**
     * 清理内存缓存
     * @return array 清理结果
     */
    private function cleanMemoryCache() {
        try {
            $results = ['status' => 'success', 'cleaned' => []];
            
            // 清理Redis缓存（如果可用）
            if (isset($this->redis) && $this->redis !== null && method_exists($this->redis, 'flushDB')) {
                $this->redis->flushDB();
                $results['cleaned'][] = 'redis';
            }
            
            // 清理内存中的指标存储
            if (isset($this->metricsStore)) {
                $this->metricsStore = [];
                $results['cleaned'][] = 'metrics_store';
            }
            
            // 尝试清理PHP内存缓存
            if (function_exists('apcu_clear_cache')) {
                apcu_clear_cache();
                $results['cleaned'][] = 'apcu_cache';
            }
            
            $results['message'] = '内存缓存清理成功';
            return $results;
        } catch (Exception $e) {
            if (isset($this->logger) && method_exists($this->logger, 'error')) {
                $this->logger->error('内存缓存清理失败: ' . $e->getMessage());
            }
            return [
                'status' => 'error', 
                'message' => '内存缓存清理失败: ' . $e->getMessage()
            ];
        }
    }

    /**
     * 获取Prometheus格式的指标
     * @return string Prometheus指标格式
     */
    public function getPrometheusMetrics() {
        try {
            // 首先确保runFullHealthCheck方法存在且可调用
            if (!method_exists($this, 'runFullHealthCheck')) {
                throw new Exception('runFullHealthCheck方法未定义');
            }
            
            $healthCheck = $this->runFullHealthCheck();
            $metrics = [];
            
            // 系统指标 - 添加防御性编程检查
            $metrics[] = "# HELP system_cpu_usage CPU使用率百分比";
            $metrics[] = "# TYPE system_cpu_usage gauge";
            $cpuUsage = isset($healthCheck['system']['cpu_usage']) ? $healthCheck['system']['cpu_usage'] : 0;
            $metrics[] = "system_cpu_usage {$cpuUsage}";
            
            $metrics[] = "# HELP system_memory_usage 内存使用率百分比";
            $metrics[] = "# TYPE system_memory_usage gauge";
            $memoryUsage = isset($healthCheck['system']['memory_usage']['usage_percent']) ? 
                          $healthCheck['system']['memory_usage']['usage_percent'] : 0;
            $metrics[] = "system_memory_usage {$memoryUsage}";
            
            // 数据库指标 - 添加防御性编程检查
            $metrics[] = "# HELP database_response_time 数据库响应时间（毫秒）";
            $metrics[] = "# TYPE database_response_time gauge";
            $dbResponseTime = isset($healthCheck['database']['response_time']) ? $healthCheck['database']['response_time'] : 0;
            $metrics[] = "database_response_time {$dbResponseTime}";
            
            $metrics[] = "# HELP database_connected 数据库连接状态";
            $metrics[] = "# TYPE database_connected gauge";
            $dbConnected = isset($healthCheck['database']['connected']) ? $healthCheck['database']['connected'] : false;
            $metrics[] = "database_connected " . ($dbConnected ? 1 : 0);
            
            // Redis指标 - 添加防御性编程检查
            $metrics[] = "# HELP redis_connected Redis连接状态";
            $metrics[] = "# TYPE redis_connected gauge";
            $redisConnected = isset($healthCheck['redis']['connected']) ? $healthCheck['redis']['connected'] : false;
            $metrics[] = "redis_connected " . ($redisConnected ? 1 : 0);
            
            // 整体健康状态 - 添加防御性编程检查
            $statusMap = ['healthy' => 0, 'warning' => 1, 'critical' => 2];
            $healthValue = isset($healthCheck['status']) && isset($statusMap[$healthCheck['status']]) ? $statusMap[$healthCheck['status']] : 0;
            
            $metrics[] = "# HELP system_health_status 系统整体健康状态（0=healthy, 1=warning, 2=critical）";
            $metrics[] = "# TYPE system_health_status gauge";
            $metrics[] = "system_health_status {$healthValue}";
            
            return implode(PHP_EOL, $metrics) . PHP_EOL;
        } catch (Exception $e) {
            // 记录错误并返回基本指标
            if (isset($this->logger) && method_exists($this->logger, 'error')) {
                $this->logger->error('获取Prometheus指标失败: ' . $e->getMessage());
            }
            
            // 返回最小化的指标集，确保API调用不会完全失败
            $minMetrics = [];
            $minMetrics[] = "# HELP system_health_status 系统整体健康状态（0=healthy, 1=warning, 2=critical）";
            $minMetrics[] = "# TYPE system_health_status gauge";
            $minMetrics[] = "system_health_status 1";
            
            return implode(PHP_EOL, $minMetrics) . PHP_EOL;
        }
    }

    /**
     * 导出健康检查报告
     * @param string $format 格式 (json, csv, html)
     * @return mixed 导出的报告
     */
    public function exportHealthReport($format = 'json') {
        $healthCheck = $this->runFullHealthCheck();
        
        switch (strtolower($format)) {
            case 'json':
                return json_encode($healthCheck, JSON_PRETTY_PRINT);
                
            case 'csv':
                return $this->exportToCsv($healthCheck);
                
            case 'html':
                return $this->generateHtmlReport($healthCheck);
                
            default:
                throw new Exception("不支持的导出格式: {$format}");
        }
    }

    /**
     * 导出为CSV格式
     * @param array $report 健康检查报告
     * @return string CSV格式的报告
     */
    private function exportToCsv($report) {
        $csv = "时间戳,系统状态,CPU使用率,内存使用率,数据库状态,Redis状态,网络状态,响应时间\n";
        $csv .= "{$report['timestamp']},{$report['status']},{$report['system']['cpu_usage']},".
                "{$report['system']['memory_usage']['usage_percent']},{$report['database']['status']},".
                "{$report['redis']['status']},{$report['network']['status']},{$report['response_time']}";
        
        return $csv;
    }

    /**
     * 生成HTML报告
     * @param array $report 健康检查报告
     * @return string HTML格式的报告
     */
    private function generateHtmlReport($report) {
        // 这里应该生成一个完整的HTML报告
        // 现在返回一个简单的HTML结构
        $html = "<html><head><title>系统健康检查报告</title></head><body>";
        $html .= "<h1>系统健康检查报告</h1>";
        $html .= "<p>时间: {$report['timestamp']}</p>";
        $html .= "<p>状态: {$report['status']}</p>";
        $html .= "</body></html>";
        
        return $html;
    }
}
?>