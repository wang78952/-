<?php
/**
 * 监控数据存储系统
 * 负责系统监控数据的存储、查询和管理历史记录功能
 * 
 * @package MonitoringSystem
 * @author System Administrator
 * @version 1.0
 */

class MonitoringDataStorage {
    /**
     * 数据库连接对象
     * @var mysqli
     */
    private $db;
    
    /**
     * Redis连接对象
     * @var Redis
     */
    private $redis;
    
    /**
     * 配置信息
     * @var array
     */
    private $config;
    
    /**
     * 构造函数
     * 
     * @param mysqli $db 数据库连接对象
     * @param Redis $redis Redis连接对象
     * @param array $config 配置信息
     */
    public function __construct($db, $redis, $config = []) {
        $this->db = $db;
        $this->redis = $redis;
        $this->config = array_merge([
            'data_retention_days' => 30,
            'redis_prefix' => 'monitoring:',
            'metrics_interval' => 60,
            'batch_size' => 1000,
        ], $config);
        
        // 确保数据表存在
        $this->ensureTablesExist();
    }
    
    /**
     * 确保必要的数据表存在
     */
    private function ensureTablesExist() {
        // 创建系统性能指标表
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `monitoring_system_metrics` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `server_id` VARCHAR(50) NOT NULL,
                `cpu_usage` FLOAT NOT NULL,
                `memory_usage` FLOAT NOT NULL,
                `disk_usage` FLOAT NOT NULL,
                `network_in` BIGINT NOT NULL,
                `network_out` BIGINT NOT NULL,
                `load_avg_1` FLOAT NOT NULL,
                `load_avg_5` FLOAT NOT NULL,
                `load_avg_15` FLOAT NOT NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_server` (`server_id`),
                INDEX `idx_time_server` (`timestamp`, `server_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建数据库性能指标表
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `monitoring_db_metrics` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `db_instance` VARCHAR(50) NOT NULL,
                `connections` INT NOT NULL,
                `active_queries` INT NOT NULL,
                `response_time` FLOAT NOT NULL,
                `slow_queries` INT NOT NULL,
                `query_cache_hit_rate` FLOAT NOT NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_db` (`db_instance`),
                INDEX `idx_time_db` (`timestamp`, `db_instance`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建Redis性能指标表
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `monitoring_redis_metrics` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `redis_instance` VARCHAR(50) NOT NULL,
                `memory_used` BIGINT NOT NULL,
                `connections` INT NOT NULL,
                `commands_processed` BIGINT NOT NULL,
                `hit_rate` FLOAT NOT NULL,
                `keyspace_hits` BIGINT NOT NULL,
                `keyspace_misses` BIGINT NOT NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_redis` (`redis_instance`),
                INDEX `idx_time_redis` (`timestamp`, `redis_instance`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建应用性能指标表
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `monitoring_app_metrics` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `endpoint` VARCHAR(255) NOT NULL,
                `response_time` FLOAT NOT NULL,
                `requests` INT NOT NULL,
                `errors` INT NOT NULL,
                `status_2xx` INT NOT NULL,
                `status_3xx` INT NOT NULL,
                `status_4xx` INT NOT NULL,
                `status_5xx` INT NOT NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_endpoint` (`endpoint`),
                INDEX `idx_time_endpoint` (`timestamp`, `endpoint`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建告警历史表
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `monitoring_alert_history` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `alert_id` VARCHAR(50) NOT NULL,
                `level` ENUM('info', 'warning', 'critical') NOT NULL,
                `type` VARCHAR(50) NOT NULL,
                `source` VARCHAR(100) NOT NULL,
                `description` TEXT NOT NULL,
                `details` JSON NOT NULL,
                `status` ENUM('active', 'resolved', 'ignored') NOT NULL DEFAULT 'active',
                `resolved_at` DATETIME NULL,
                `resolved_by` VARCHAR(100) NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_alert_id` (`alert_id`),
                INDEX `idx_status` (`status`),
                INDEX `idx_level` (`level`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // 创建系统事件表
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `monitoring_system_events` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `timestamp` DATETIME NOT NULL,
                `event_type` VARCHAR(50) NOT NULL,
                `source` VARCHAR(100) NOT NULL,
                `message` TEXT NOT NULL,
                `details` JSON NOT NULL,
                INDEX `idx_timestamp` (`timestamp`),
                INDEX `idx_event_type` (`event_type`),
                INDEX `idx_source` (`source`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }
    
    /**
     * 存储系统性能指标
     * 
     * @param array $metrics 性能指标数据
     * @return bool 是否成功
     */
    public function storeSystemMetrics($metrics) {
        $requiredFields = ['timestamp', 'server_id', 'cpu_usage', 'memory_usage', 'disk_usage'];
        
        // 验证必要字段
        foreach ($requiredFields as $field) {
            if (!isset($metrics[$field])) {
                error_log("Missing required field for system metrics: $field");
                return false;
            }
        }
        
        // 补充默认值
        $metrics = array_merge([
            'network_in' => 0,
            'network_out' => 0,
            'load_avg_1' => 0,
            'load_avg_5' => 0,
            'load_avg_15' => 0,
        ], $metrics);
        
        // 先存储到Redis以便实时查询
        $redisKey = $this->config['redis_prefix'] . 'system_metrics:' . $metrics['server_id'];
        $redisData = json_encode($metrics);
        $this->redis->hset($redisKey, $metrics['timestamp'], $redisData);
        $this->redis->expire($redisKey, 3600); // 保留1小时
        
        // 存储到数据库
        $stmt = $this->db->prepare("
            INSERT INTO `monitoring_system_metrics` (
                `timestamp`, `server_id`, `cpu_usage`, `memory_usage`, `disk_usage`,
                `network_in`, `network_out`, `load_avg_1`, `load_avg_5`, `load_avg_15`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            'ssdffffff',
            $metrics['timestamp'], $metrics['server_id'], $metrics['cpu_usage'],
            $metrics['memory_usage'], $metrics['disk_usage'], $metrics['network_in'],
            $metrics['network_out'], $metrics['load_avg_1'], $metrics['load_avg_5'],
            $metrics['load_avg_15']
        );
        
        return $stmt->execute();
    }
    
    /**
     * 存储数据库性能指标
     * 
     * @param array $metrics 数据库性能指标
     * @return bool 是否成功
     */
    public function storeDatabaseMetrics($metrics) {
        $requiredFields = ['timestamp', 'db_instance', 'connections', 'response_time'];
        
        // 验证必要字段
        foreach ($requiredFields as $field) {
            if (!isset($metrics[$field])) {
                error_log("Missing required field for database metrics: $field");
                return false;
            }
        }
        
        // 补充默认值
        $metrics = array_merge([
            'active_queries' => 0,
            'slow_queries' => 0,
            'query_cache_hit_rate' => 0,
        ], $metrics);
        
        // 先存储到Redis以便实时查询
        $redisKey = $this->config['redis_prefix'] . 'db_metrics:' . $metrics['db_instance'];
        $redisData = json_encode($metrics);
        $this->redis->hset($redisKey, $metrics['timestamp'], $redisData);
        $this->redis->expire($redisKey, 3600);
        
        // 存储到数据库
        $stmt = $this->db->prepare("
            INSERT INTO `monitoring_db_metrics` (
                `timestamp`, `db_instance`, `connections`, `active_queries`,
                `response_time`, `slow_queries`, `query_cache_hit_rate`
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            'ssddddd',
            $metrics['timestamp'], $metrics['db_instance'], $metrics['connections'],
            $metrics['active_queries'], $metrics['response_time'], $metrics['slow_queries'],
            $metrics['query_cache_hit_rate']
        );
        
        return $stmt->execute();
    }
    
    /**
     * 存储Redis性能指标
     * 
     * @param array $metrics Redis性能指标
     * @return bool 是否成功
     */
    public function storeRedisMetrics($metrics) {
        $requiredFields = ['timestamp', 'redis_instance', 'memory_used', 'connections'];
        
        // 验证必要字段
        foreach ($requiredFields as $field) {
            if (!isset($metrics[$field])) {
                error_log("Missing required field for Redis metrics: $field");
                return false;
            }
        }
        
        // 补充默认值
        $metrics = array_merge([
            'commands_processed' => 0,
            'hit_rate' => 0,
            'keyspace_hits' => 0,
            'keyspace_misses' => 0,
        ], $metrics);
        
        // 先存储到Redis以便实时查询
        $redisKey = $this->config['redis_prefix'] . 'redis_metrics:' . $metrics['redis_instance'];
        $redisData = json_encode($metrics);
        $this->redis->hset($redisKey, $metrics['timestamp'], $redisData);
        $this->redis->expire($redisKey, 3600);
        
        // 存储到数据库
        $stmt = $this->db->prepare("
            INSERT INTO `monitoring_redis_metrics` (
                `timestamp`, `redis_instance`, `memory_used`, `connections`,
                `commands_processed`, `hit_rate`, `keyspace_hits`, `keyspace_misses`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            'ssdldddd',
            $metrics['timestamp'], $metrics['redis_instance'], $metrics['memory_used'],
            $metrics['connections'], $metrics['commands_processed'], $metrics['hit_rate'],
            $metrics['keyspace_hits'], $metrics['keyspace_misses']
        );
        
        return $stmt->execute();
    }
    
    /**
     * 存储应用性能指标
     * 
     * @param array $metrics 应用性能指标
     * @return bool 是否成功
     */
    public function storeApplicationMetrics($metrics) {
        $requiredFields = ['timestamp', 'endpoint', 'response_time', 'requests'];
        
        // 验证必要字段
        foreach ($requiredFields as $field) {
            if (!isset($metrics[$field])) {
                error_log("Missing required field for application metrics: $field");
                return false;
            }
        }
        
        // 补充默认值
        $metrics = array_merge([
            'errors' => 0,
            'status_2xx' => 0,
            'status_3xx' => 0,
            'status_4xx' => 0,
            'status_5xx' => 0,
        ], $metrics);
        
        // 先存储到Redis以便实时查询
        $redisKey = $this->config['redis_prefix'] . 'app_metrics:' . md5($metrics['endpoint']);
        $redisData = json_encode($metrics);
        $this->redis->hset($redisKey, $metrics['timestamp'], $redisData);
        $this->redis->expire($redisKey, 3600);
        
        // 存储到数据库
        $stmt = $this->db->prepare("
            INSERT INTO `monitoring_app_metrics` (
                `timestamp`, `endpoint`, `response_time`, `requests`, `errors`,
                `status_2xx`, `status_3xx`, `status_4xx`, `status_5xx`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            'ssddiiiii',
            $metrics['timestamp'], $metrics['endpoint'], $metrics['response_time'],
            $metrics['requests'], $metrics['errors'], $metrics['status_2xx'],
            $metrics['status_3xx'], $metrics['status_4xx'], $metrics['status_5xx']
        );
        
        return $stmt->execute();
    }
    
    /**
     * 存储告警信息
     * 
     * @param array $alert 告警数据
     * @return bool 是否成功
     */
    public function storeAlert($alert) {
        $requiredFields = ['timestamp', 'alert_id', 'level', 'type', 'source', 'description'];
        
        // 验证必要字段
        foreach ($requiredFields as $field) {
            if (!isset($alert[$field])) {
                error_log("Missing required field for alert: $field");
                return false;
            }
        }
        
        // 补充默认值
        $alert = array_merge([
            'details' => (object)[],
            'status' => 'active',
        ], $alert);
        
        // 存储到Redis的活跃告警列表
        if ($alert['status'] === 'active') {
            $redisKey = $this->config['redis_prefix'] . 'active_alerts';
            $this->redis->sadd($redisKey, $alert['alert_id']);
            $redisAlertKey = $this->config['redis_prefix'] . 'alert:' . $alert['alert_id'];
            $this->redis->set($redisAlertKey, json_encode($alert));
            $this->redis->expire($redisAlertKey, 86400); // 保留24小时
        }
        
        // 存储到数据库
        $stmt = $this->db->prepare("
            INSERT INTO `monitoring_alert_history` (
                `timestamp`, `alert_id`, `level`, `type`, `source`,
                `description`, `details`, `status`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $detailsJson = json_encode($alert['details']);
        $stmt->bind_param(
            'ssssssis',
            $alert['timestamp'], $alert['alert_id'], $alert['level'], $alert['type'],
            $alert['source'], $alert['description'], $detailsJson, $alert['status']
        );
        
        return $stmt->execute();
    }
    
    /**
     * 解析告警状态
     * 
     * @param string $alertId 告警ID
     * @param string $status 新状态
     * @param string $resolvedBy 处理人
     * @return bool 是否成功
     */
    public function resolveAlert($alertId, $status = 'resolved', $resolvedBy = 'system') {
        // 验证状态值
        if (!in_array($status, ['resolved', 'ignored'])) {
            error_log("Invalid alert status: $status");
            return false;
        }
        
        // 从Redis中移除活跃告警
        $redisKey = $this->config['redis_prefix'] . 'active_alerts';
        $this->redis->srem($redisKey, $alertId);
        $redisAlertKey = $this->config['redis_prefix'] . 'alert:' . $alertId;
        $this->redis->del($redisAlertKey);
        
        // 更新数据库中的告警状态
        $stmt = $this->db->prepare("
            UPDATE `monitoring_alert_history` 
            SET `status` = ?, `resolved_at` = NOW(), `resolved_by` = ?
            WHERE `alert_id` = ? AND `status` = 'active'
        ");
        
        $stmt->bind_param('sss', $status, $resolvedBy, $alertId);
        return $stmt->execute();
    }
    
    /**
     * 存储系统事件
     * 
     * @param array $event 事件数据
     * @return bool 是否成功
     */
    public function storeEvent($event) {
        $requiredFields = ['timestamp', 'event_type', 'source', 'message'];
        
        // 验证必要字段
        foreach ($requiredFields as $field) {
            if (!isset($event[$field])) {
                error_log("Missing required field for event: $field");
                return false;
            }
        }
        
        // 补充默认值
        $event = array_merge([
            'details' => (object)[],
        ], $event);
        
        // 存储到数据库
        $stmt = $this->db->prepare("
            INSERT INTO `monitoring_system_events` (
                `timestamp`, `event_type`, `source`, `message`, `details`
            ) VALUES (?, ?, ?, ?, ?)
        ");
        
        $detailsJson = json_encode($event['details']);
        $stmt->bind_param(
            'sssss',
            $event['timestamp'], $event['event_type'], $event['source'],
            $event['message'], $detailsJson
        );
        
        return $stmt->execute();
    }
    
    /**
     * 获取系统性能指标历史数据
     * 
     * @param string $serverId 服务器ID
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param string $aggregation 聚合方式 (minute, hour, day)
     * @return array 指标数据
     */
    public function getSystemMetricsHistory($serverId, $startTime, $endTime, $aggregation = 'hour') {
        // 根据聚合方式确定时间格式
        $timeFormat = $this->getTimeFormatForAggregation($aggregation);
        
        $stmt = $this->db->prepare("
            SELECT 
                DATE_FORMAT(`timestamp`, ?) as `time`,
                AVG(`cpu_usage`) as `avg_cpu`,
                MAX(`cpu_usage`) as `max_cpu`,
                AVG(`memory_usage`) as `avg_memory`,
                MAX(`memory_usage`) as `max_memory`,
                AVG(`disk_usage`) as `avg_disk`,
                MAX(`disk_usage`) as `max_disk`,
                SUM(`network_in`) as `total_network_in`,
                SUM(`network_out`) as `total_network_out`,
                AVG(`load_avg_1`) as `avg_load_1`
            FROM `monitoring_system_metrics`
            WHERE `server_id` = ? AND `timestamp` BETWEEN ? AND ?
            GROUP BY `time`
            ORDER BY `time` ASC
        ");
        
        $stmt->bind_param('sssss', $timeFormat, $serverId, $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * 获取数据库性能指标历史数据
     * 
     * @param string $dbInstance 数据库实例
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param string $aggregation 聚合方式
     * @return array 指标数据
     */
    public function getDatabaseMetricsHistory($dbInstance, $startTime, $endTime, $aggregation = 'hour') {
        // 根据聚合方式确定时间格式
        $timeFormat = $this->getTimeFormatForAggregation($aggregation);
        
        $stmt = $this->db->prepare("
            SELECT 
                DATE_FORMAT(`timestamp`, ?) as `time`,
                AVG(`connections`) as `avg_connections`,
                MAX(`connections`) as `max_connections`,
                AVG(`active_queries`) as `avg_active_queries`,
                MAX(`active_queries`) as `max_active_queries`,
                AVG(`response_time`) as `avg_response_time`,
                MAX(`response_time`) as `max_response_time`,
                SUM(`slow_queries`) as `total_slow_queries`,
                AVG(`query_cache_hit_rate`) as `avg_cache_hit_rate`
            FROM `monitoring_db_metrics`
            WHERE `db_instance` = ? AND `timestamp` BETWEEN ? AND ?
            GROUP BY `time`
            ORDER BY `time` ASC
        ");
        
        $stmt->bind_param('sssss', $timeFormat, $dbInstance, $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * 获取应用性能指标历史数据
     * 
     * @param string $endpoint 端点
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param string $aggregation 聚合方式
     * @return array 指标数据
     */
    public function getApplicationMetricsHistory($endpoint, $startTime, $endTime, $aggregation = 'hour') {
        // 根据聚合方式确定时间格式
        $timeFormat = $this->getTimeFormatForAggregation($aggregation);
        
        $stmt = $this->db->prepare("
            SELECT 
                DATE_FORMAT(`timestamp`, ?) as `time`,
                AVG(`response_time`) as `avg_response_time`,
                MAX(`response_time`) as `max_response_time`,
                SUM(`requests`) as `total_requests`,
                SUM(`errors`) as `total_errors`,
                SUM(`status_2xx`) as `total_2xx`,
                SUM(`status_3xx`) as `total_3xx`,
                SUM(`status_4xx`) as `total_4xx`,
                SUM(`status_5xx`) as `total_5xx`
            FROM `monitoring_app_metrics`
            WHERE `endpoint` = ? AND `timestamp` BETWEEN ? AND ?
            GROUP BY `time`
            ORDER BY `time` ASC
        ");
        
        $stmt->bind_param('sssss', $timeFormat, $endpoint, $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * 获取告警历史
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @param array $filters 过滤条件
     * @return array 告警数据
     */
    public function getAlertsHistory($startTime, $endTime, $filters = []) {
        // 构建查询条件
        $whereClause = "`timestamp` BETWEEN ? AND ?";
        $params = [$startTime, $endTime];
        $paramTypes = "ss";
        
        // 添加过滤条件
        if (isset($filters['level']) && !empty($filters['level'])) {
            $whereClause .= " AND `level` = ?";
            $params[] = $filters['level'];
            $paramTypes .= "s";
        }
        
        if (isset($filters['status']) && !empty($filters['status'])) {
            $whereClause .= " AND `status` = ?";
            $params[] = $filters['status'];
            $paramTypes .= "s";
        }
        
        if (isset($filters['type']) && !empty($filters['type'])) {
            $whereClause .= " AND `type` = ?";
            $params[] = $filters['type'];
            $paramTypes .= "s";
        }
        
        if (isset($filters['source']) && !empty($filters['source'])) {
            $whereClause .= " AND `source` = ?";
            $params[] = $filters['source'];
            $paramTypes .= "s";
        }
        
        // 构建预处理语句
        $query = "
            SELECT * FROM `monitoring_alert_history`
            WHERE $whereClause
            ORDER BY `timestamp` DESC
            LIMIT 1000
        ";
        
        $stmt = $this->db->prepare($query);
        
        // 绑定参数
        if (count($params) > 0) {
            $stmt->bind_param($paramTypes, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            // 解析JSON字段
            if (isset($row['details'])) {
                $row['details'] = json_decode($row['details'], true);
            }
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * 获取当前活跃告警
     * 
     * @return array 活跃告警列表
     */
    public function getActiveAlerts() {
        $redisKey = $this->config['redis_prefix'] . 'active_alerts';
        $alertIds = $this->redis->smembers($redisKey);
        
        $alerts = [];
        foreach ($alertIds as $alertId) {
            $alertKey = $this->config['redis_prefix'] . 'alert:' . $alertId;
            $alertJson = $this->redis->get($alertKey);
            
            if ($alertJson) {
                $alert = json_decode($alertJson, true);
                if ($alert && $alert['status'] === 'active') {
                    $alerts[] = $alert;
                }
            }
        }
        
        // 如果Redis中没有数据，则从数据库获取
        if (empty($alerts)) {
            $stmt = $this->db->prepare("
                SELECT * FROM `monitoring_alert_history`
                WHERE `status` = 'active'
                ORDER BY `timestamp` DESC
                LIMIT 100
            ");
            
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                if (isset($row['details'])) {
                    $row['details'] = json_decode($row['details'], true);
                }
                $alerts[] = $row;
            }
            
            // 同时更新Redis缓存
            foreach ($alerts as $alert) {
                $alertKey = $this->config['redis_prefix'] . 'alert:' . $alert['alert_id'];
                $this->redis->set($alertKey, json_encode($alert));
                $this->redis->expire($alertKey, 86400);
                $this->redis->sadd($redisKey, $alert['alert_id']);
            }
        }
        
        return $alerts;
    }
    
    /**
     * 执行数据清理，删除过期数据
     * 
     * @return int 删除的记录数
     */
    public function cleanupOldData() {
        $retentionDays = $this->config['data_retention_days'];
        $cutoffDate = date('Y-m-d H:i:s', strtotime("-$retentionDays days"));
        
        $deletedRows = 0;
        
        // 清理各表数据
        $tables = [
            'monitoring_system_metrics',
            'monitoring_db_metrics',
            'monitoring_redis_metrics',
            'monitoring_app_metrics',
        ];
        
        foreach ($tables as $table) {
            $stmt = $this->db->prepare("DELETE FROM `$table` WHERE `timestamp` < ? LIMIT ?");
            $stmt->bind_param('si', $cutoffDate, $this->config['batch_size']);
            
            // 分批删除以避免锁定表
            $rowCount = 0;
            do {
                $stmt->execute();
                $rowCount = $this->db->affected_rows;
                $deletedRows += $rowCount;
            } while ($rowCount > 0);
        }
        
        // 清理已解决且时间较久的告警记录
        $alertRetentionDays = $retentionDays * 2; // 告警保留时间更长
        $alertCutoffDate = date('Y-m-d H:i:s', strtotime("-$alertRetentionDays days"));
        
        $stmt = $this->db->prepare(
            "DELETE FROM `monitoring_alert_history` 
             WHERE `status` != 'active' AND `timestamp` < ?
             LIMIT ?"
        );
        $stmt->bind_param('si', $alertCutoffDate, $this->config['batch_size']);
        
        $rowCount = 0;
        do {
            $stmt->execute();
            $rowCount = $this->db->affected_rows;
            $deletedRows += $rowCount;
        } while ($rowCount > 0);
        
        // 清理系统事件记录
        $eventRetentionDays = 14;
        $eventCutoffDate = date('Y-m-d H:i:s', strtotime("-$eventRetentionDays days"));
        
        $stmt = $this->db->prepare(
            "DELETE FROM `monitoring_system_events` 
             WHERE `timestamp` < ?
             LIMIT ?"
        );
        $stmt->bind_param('si', $eventCutoffDate, $this->config['batch_size']);
        
        $rowCount = 0;
        do {
            $stmt->execute();
            $rowCount = $this->db->affected_rows;
            $deletedRows += $rowCount;
        } while ($rowCount > 0);
        
        return $deletedRows;
    }
    
    /**
     * 为指定的聚合方式获取时间格式
     * 
     * @param string $aggregation 聚合方式
     * @return string MySQL日期格式
     */
    private function getTimeFormatForAggregation($aggregation) {
        switch ($aggregation) {
            case 'minute':
                return '%Y-%m-%d %H:%i';
            case 'hour':
                return '%Y-%m-%d %H:00';
            case 'day':
                return '%Y-%m-%d 00:00';
            default:
                return '%Y-%m-%d %H:00';
        }
    }
    
    /**
     * 生成监控报告
     * 
     * @param string $period 报告周期 (day, week, month)
     * @return array 报告数据
     */
    public function generateReport($period = 'week') {
        // 计算时间范围
        $endTime = date('Y-m-d H:i:s');
        $startTime = $this->getStartTimeForPeriod($period, $endTime);
        
        $report = [
            'period' => $period,
            'start_time' => $startTime,
            'end_time' => $endTime,
            'system_metrics' => [],
            'database_metrics' => [],
            'application_metrics' => [],
            'alerts_summary' => [],
            'events_summary' => [],
        ];
        
        // 系统指标汇总
        $report['system_metrics'] = $this->getSystemMetricsSummary($startTime, $endTime);
        
        // 数据库指标汇总
        $report['database_metrics'] = $this->getDatabaseMetricsSummary($startTime, $endTime);
        
        // 应用指标汇总
        $report['application_metrics'] = $this->getApplicationMetricsSummary($startTime, $endTime);
        
        // 告警汇总
        $report['alerts_summary'] = $this->getAlertsSummary($startTime, $endTime);
        
        // 事件汇总
        $report['events_summary'] = $this->getEventsSummary($startTime, $endTime);
        
        return $report;
    }
    
    /**
     * 获取系统指标汇总
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 汇总数据
     */
    private function getSystemMetricsSummary($startTime, $endTime) {
        $stmt = $this->db->prepare("
            SELECT 
                AVG(`cpu_usage`) as `avg_cpu`,
                MAX(`cpu_usage`) as `max_cpu`,
                AVG(`memory_usage`) as `avg_memory`,
                MAX(`memory_usage`) as `max_memory`,
                AVG(`disk_usage`) as `avg_disk`,
                MAX(`disk_usage`) as `max_disk`,
                SUM(`network_in`) as `total_network_in`,
                SUM(`network_out`) as `total_network_out`
            FROM `monitoring_system_metrics`
            WHERE `timestamp` BETWEEN ? AND ?
        ");
        
        $stmt->bind_param('ss', $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc() ?: [];
    }
    
    /**
     * 获取数据库指标汇总
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 汇总数据
     */
    private function getDatabaseMetricsSummary($startTime, $endTime) {
        $stmt = $this->db->prepare("
            SELECT 
                AVG(`connections`) as `avg_connections`,
                MAX(`connections`) as `max_connections`,
                AVG(`response_time`) as `avg_response_time`,
                MAX(`response_time`) as `max_response_time`,
                SUM(`slow_queries`) as `total_slow_queries`
            FROM `monitoring_db_metrics`
            WHERE `timestamp` BETWEEN ? AND ?
        ");
        
        $stmt->bind_param('ss', $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc() ?: [];
    }
    
    /**
     * 获取应用指标汇总
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 汇总数据
     */
    private function getApplicationMetricsSummary($startTime, $endTime) {
        $stmt = $this->db->prepare("
            SELECT 
                SUM(`requests`) as `total_requests`,
                SUM(`errors`) as `total_errors`,
                AVG(`response_time`) as `avg_response_time`,
                SUM(`status_2xx`) as `total_2xx`,
                SUM(`status_3xx`) as `total_3xx`,
                SUM(`status_4xx`) as `total_4xx`,
                SUM(`status_5xx`) as `total_5xx`
            FROM `monitoring_app_metrics`
            WHERE `timestamp` BETWEEN ? AND ?
        ");
        
        $stmt->bind_param('ss', $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc() ?: [];
    }
    
    /**
     * 获取告警汇总
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 汇总数据
     */
    private function getAlertsSummary($startTime, $endTime) {
        $stmt = $this->db->prepare("
            SELECT 
                `level`,
                COUNT(*) as `count`
            FROM `monitoring_alert_history`
            WHERE `timestamp` BETWEEN ? AND ?
            GROUP BY `level`
        ");
        
        $stmt->bind_param('ss', $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $summary = ['info' => 0, 'warning' => 0, 'critical' => 0];
        while ($row = $result->fetch_assoc()) {
            $summary[$row['level']] = $row['count'];
        }
        
        return $summary;
    }
    
    /**
     * 获取事件汇总
     * 
     * @param string $startTime 开始时间
     * @param string $endTime 结束时间
     * @return array 汇总数据
     */
    private function getEventsSummary($startTime, $endTime) {
        $stmt = $this->db->prepare("
            SELECT 
                `event_type`,
                COUNT(*) as `count`
            FROM `monitoring_system_events`
            WHERE `timestamp` BETWEEN ? AND ?
            GROUP BY `event_type`
            ORDER BY `count` DESC
            LIMIT 10
        ");
        
        $stmt->bind_param('ss', $startTime, $endTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $summary = [];
        while ($row = $result->fetch_assoc()) {
            $summary[$row['event_type']] = $row['count'];
        }
        
        return $summary;
    }
    
    /**
     * 根据报告周期获取开始时间
     * 
     * @param string $period 报告周期
     * @param string $endTime 结束时间
     * @return string 开始时间
     */
    private function getStartTimeForPeriod($period, $endTime) {
        switch ($period) {
            case 'day':
                return date('Y-m-d H:i:s', strtotime('-1 day', strtotime($endTime)));
            case 'week':
                return date('Y-m-d H:i:s', strtotime('-1 week', strtotime($endTime)));
            case 'month':
                return date('Y-m-d H:i:s', strtotime('-1 month', strtotime($endTime)));
            default:
                return date('Y-m-d H:i:s', strtotime('-1 week', strtotime($endTime)));
        }
    }
    
    /**
     * 析构函数，清理资源
     */
    public function __destruct() {
        // 数据库连接会在脚本结束时自动关闭
        // Redis连接会在脚本结束时自动关闭
    }
}

// 使用示例
/*
$db = new mysqli('localhost', 'username', 'password', 'monitoring_db');
$redis = new Redis();
$redis->connect('localhost', 6379);

$storage = new MonitoringDataStorage($db, $redis);

// 存储系统指标
$storage->storeSystemMetrics([
    'timestamp' => date('Y-m-d H:i:s'),
    'server_id' => 'web-server-01',
    'cpu_usage' => 45.2,
    'memory_usage' => 67.8,
    'disk_usage' => 42.5,
]);

// 生成报告
$report = $storage->generateReport('week');
print_r($report);

// 清理旧数据
$deletedRows = $storage->cleanupOldData();
echo "清理了 $deletedRows 条旧数据\n";
*/