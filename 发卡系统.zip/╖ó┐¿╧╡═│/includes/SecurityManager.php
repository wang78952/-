<?php
/**
 * 安全管理器
 * 负责系统安全相关功能：HTTPS强制、密钥管理、数据脱敏、XSS防护、接口限流、登录风控、操作日志
 */
require_once __DIR__ . '/BaseService.php';

class SecurityManager extends BaseService {
    protected $config;
    protected $rateLimiter;
    protected $loginProtection;
    protected $auditLogger;
    
    public function __construct() {
        parent::__construct();
        $this->config = $this->loadSecurityConfig();
        $this->rateLimiter = new RateLimiter($this->database);
        $this->loginProtection = new LoginProtection($this->database);
        $this->auditLogger = new AuditLogger($this->database);
        
        // 初始化安全措施
        $this->initializeSecurity();
    }
      
      /**
       * 获取当前密钥版本
       */
      private function getCurrentKeyVersion() {
          $versionFile = dirname(__FILE__) . '/../keys/key_version.txt';
          if (file_exists($versionFile)) {
              $version = trim(file_get_contents($versionFile));
              if (is_numeric($version) && $version > 0) {
                  return intval($version);
              }
          }
          // 默认版本1
          return 1;
      }
      
      /**
     * 初始化安全措施
     */
    private function initializeSecurity() {
        // 强制HTTPS
        $this->enforceHTTPS();
        
        // 设置安全头
        $this->setSecurityHeaders();
        
        // 启动会话安全
        $this->secureSession();
        
        // 输入过滤
        $this->sanitizeGlobalInput();
    }
    
    /**
     * 强制HTTPS
     */
    private function enforceHTTPS() {
        if (!$this->isHTTPS() && $this->config['force_https']) {
            $httpsUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            header('Location: ' . $httpsUrl, true, 301);
            exit;
        }
    }
    
    /**
     * 检查是否为HTTPS
     */
    private function isHTTPS() {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
               $_SERVER['SERVER_PORT'] == 443 ||
               (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    }
    
    /**
     * 设置安全头
     */
    private function setSecurityHeaders() {
        // 防止XSS攻击
        header('X-XSS-Protection: 1; mode=block');
        
        // 防止内容类型嗅探
        header('X-Content-Type-Options: nosniff');
        
        // 防止点击劫持
        header('X-Frame-Options: SAMEORIGIN');
        
        // 强制HTTPS（HSTS）
        if ($this->config['force_https']) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
        
        // 内容安全策略
        if (!empty($this->config['csp_policy'])) {
            header('Content-Security-Policy: ' . $this->config['csp_policy']);
        }
        
        // 权限策略
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
        
        // 引用策略
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }
    
    /**
     * 安全会话设置
     */
    private function secureSession() {
        // 仅HTTPS传输cookie
        ini_set('session.cookie_secure', $this->isHTTPS());
        
        // 防止JavaScript访问cookie
        ini_set('session.cookie_httponly', true);
        
        // SameSite属性
        ini_set('session.cookie_samesite', 'Strict');
        
        // 会话ID重新生成
        if (session_status() === PHP_SESSION_ACTIVE && !isset($_SESSION['security_initialized'])) {
            session_regenerate_id(true);
            $_SESSION['security_initialized'] = true;
        }
    }
    
    /**
     * 全局输入数据清理
     */
    private function sanitizeGlobalInput() {
        // 清理GET数据
        $_GET = $this->sanitizeArray($_GET);
        
        // 清理POST数据
        $_POST = $this->sanitizeArray($_POST);
        
        // 清理REQUEST数据
        $_REQUEST = $this->sanitizeArray($_REQUEST);
        
        // 清理COOKIE数据
        $_COOKIE = $this->sanitizeArray($_COOKIE);
    }
    
    /**
     * 递归清理数组数据
     */
    private function sanitizeArray($data) {
        if (is_array($data)) {
            return array_map([$this, 'sanitizeArray'], $data);
        } elseif (is_string($data)) {
            return $this->sanitizeString($data);
        }
        return $data;
    }
    
    /**
     * 清理字符串数据
     */
    private function sanitizeString($string) {
        // 移除HTML标签
        $string = strip_tags($string);
        
        // 转义特殊字符
        $string = htmlspecialchars($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // 移除潜在危险字符
        $dangerousChars = array('<', '>', '"', "'", '&', '\x00', '\n', '\r', '\t', '\\');
        $string = str_replace($dangerousChars, '', $string);
        
        return $string;
    }
    
    /**
     * 数据脱敏处理
     */
    public function maskSensitiveData($data, $dataType) {
        try {
            // 空数据处理
            if (empty($data)) {
                return $data;
            }
            
            // 获取脱敏规则
            $maskingRules = $this->securityConfig['data_masking'] ?? array();
            
            switch ($dataType) {
                case 'email':
                    return $this->maskEmail($data, $maskingRules['email'] ?? array());
                case 'phone':
                    return $this->maskPhone($data, $maskingRules['phone'] ?? array());
                case 'card':
                    return $this->maskCard($data, $maskingRules['card'] ?? array());
                case 'id_card':
                    return $this->maskIdCard($data, $maskingRules['id_card'] ?? array());
                case 'password':
                    return '******';
                default:
                    // 如果没有特定的数据类型规则，使用通用脱敏
                    return $this->maskPartial($data, 2, 2);
            }
        } catch (Exception $e) {
            $this->logger->error('数据脱敏失败: ' . $e->getMessage());
            return $data; // 出错时返回原始数据避免显示错误
        }
    }
    
    /**
     * 邮箱脱敏
     */
    private function maskEmail($email, $rules = array()) {
        // 确保是有效的邮箱格式
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $email;
        }
        
        // 分离用户名和域名
        list($username, $domain) = explode('@', $email, 2);
        
        // 如果用户名太短，全部替换
        if (strlen($username) <= 3) {
            return '***@' . $domain;
        }
        
        // 根据规则确定显示的字符数
        $showChars = $rules['show_chars'] ?? 2;
        $maskedUsername = substr($username, 0, $showChars) . str_repeat('*', strlen($username) - $showChars);
        
        return $maskedUsername . '@' . $domain;
    }
    
    /**
     * 手机号脱敏
     */
    private function maskPhone($phone, $rules = array()) {
        // 移除所有非数字字符
        $phone = preg_replace('/\D/', '', $phone);
        
        // 中国手机号格式处理
        if (preg_match('/^1\d{10}$/', $phone)) {
            return substr($phone, 0, 3) . '****' . substr($phone, 7);
        }
        
        // 国际手机号通用处理
        $length = strlen($phone);
        if ($length <= 7) {
            return substr($phone, 0, 2) . str_repeat('*', $length - 2);
        }
        
        return substr($phone, 0, 3) . str_repeat('*', $length - 6) . substr($phone, -3);
    }
    
    /**
     * 银行卡号脱敏
     */
    private function maskCard($cardNumber, $rules = array()) {
        // 移除所有非数字字符
        $cardNumber = preg_replace('/\D/', '', $cardNumber);
        
        $length = strlen($cardNumber);
        if ($length <= 8) {
            return str_repeat('*', $length);
        }
        
        $showFirst = $rules['show_first'] ?? 4;
        $showLast = $rules['show_last'] ?? 4;
        
        $maskLength = $length - ($showFirst + $showLast);
        if ($maskLength < 1) {
            $maskLength = 1;
        }
        
        return substr($cardNumber, 0, $showFirst) . str_repeat('*', $maskLength) . substr($cardNumber, -$showLast);
    }
    
    /**
     * 接口限流检查
     */
    public function checkRateLimit($identifier, $limit, $window) {
        return $this->rateLimiter->check($identifier, $limit, $window);
    }
    
    /**
     * 登录保护检查
     */
    public function checkLoginProtection($username, $ipAddress) {
        try {
            // 检查是否有锁定记录
            $lockRecord = $this->loginProtection->getLockRecord($username, $ipAddress);
            
            if ($lockRecord && $lockRecord['lock_until'] > time()) {
                return array(
                    'blocked' => true,
                    'reason' => '账户已被临时锁定',
                    'remaining_time' => $lockRecord['lock_until'] - time()
                );
            } else if ($lockRecord && $lockRecord['lock_until'] <= time()) {
                // 锁定时间已过，重置失败计数
                $this->loginProtection->resetFailureCount($username, $ipAddress);
            }
            
            return array('blocked' => false);
        } catch (Exception $e) {
            $this->logger->error('登录保护检查失败: ' . $e->getMessage());
            // 出错时保守处理，返回允许登录避免永久锁定
            return array('blocked' => false);
        }
    }
    
    /**
     * 记录登录失败
     */
    public function recordLoginFailure($username, $ipAddress) {
        try {
            // 获取配置的最大失败次数和锁定时间
            $maxFailures = (int) ($this->config['security'] ?? [])['max_login_failures'] ?? 5;
            $lockTime = (int) ($this->config['security'] ?? [])['login_lock_time'] ?? 300;
            
            // 记录失败
            $this->loginProtection->recordFailure($username, $ipAddress, $maxFailures, $lockTime);
            return true;
        } catch (Exception $e) {
            $this->logger->error('记录登录失败时出错: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 记录登录成功
     */
    public function recordLoginSuccess($identifier, $ip, $userAgent) {
        $this->loginProtection->recordSuccess($identifier, $ip, $userAgent);
    }
    
    /**
     * 记录审计日志
     */
    public function logAudit($userId, $action, $resource, $details = array()) {
        $this->auditLogger->log($userId, $action, $resource, $details);
    }
    
    /**
     * 生成CSRF令牌
     */
    public function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * 验证CSRF令牌
     */
    public function validateCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * 生成安全密码哈希
     */
    public function hashPassword($password) {
        return password_hash($password, PASSWORD_ARGON2ID, array(
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3
        ));
    }
    
    /**
     * 验证密码
     */
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * 生成随机令牌
     */
    public function generateToken($length = 32) {
        try {
            // 使用安全的随机数生成
            if (function_exists('random_bytes')) {
                return bin2hex(random_bytes($length / 2));
            } else if (function_exists('openssl_random_pseudo_bytes')) {
                return bin2hex(openssl_random_pseudo_bytes($length / 2));
            } else {
                // 最后的备选方案，但不推荐在生产环境使用
                $token = '';
                $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                for ($i = 0; $i < $length; $i++) {
                    $token .= $chars[mt_rand(0, strlen($chars) - 1)];
                }
                return $token;
            }
        } catch (Exception $e) {
            $this->logger->error('生成令牌失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 加密数据
     */
    public function encrypt($data, $key = null) {
        try {
            $encryptionKey = $key ?: $this->getEncryptionKey();
            
            if (empty($encryptionKey)) {
                throw new Exception('加密密钥未设置');
            }
            
            // 使用安全的加密方法
            if (function_exists('openssl_encrypt')) {
                $iv = random_bytes(openssl_cipher_iv_length('AES-256-CBC'));
                $encrypted = openssl_encrypt(
                    json_encode($data),
                    'AES-256-CBC',
                    $encryptionKey,
                    0,
                    $iv
                );
                
                if ($encrypted === false) {
                    throw new Exception('加密失败');
                }
                
                return base64_encode($iv . $encrypted);
            }
            
            throw new Exception('不支持的加密方法');
        } catch (Exception $e) {
            $this->logger->error('数据加密失败: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 解密数据
     */
    public function decrypt($encryptedData, $key = null) {
        try {
            $actualKey = $key ?: $this->getEncryptionKey();
            
            // 检查输入
            if (empty($encryptedData)) {
                return null;
            }
            
            // 解密数据
            $data = base64_decode($encryptedData);
            
            if ($data === false) {
                throw new Exception('无效的加密数据');
            }
            
            // 提取iv
            $ivSize = openssl_cipher_iv_length('AES-256-CBC');
            $iv = substr($data, 0, $ivSize);
            $encrypted = substr($data, $ivSize);
            
            if (empty($iv) || empty($encrypted)) {
                throw new Exception('加密数据格式错误');
            }
            
            // 解密
            $decrypted = openssl_decrypt(
                $encrypted,
                'AES-256-CBC',
                $actualKey,
                0,
                $iv
            );
            
            if ($decrypted === false) {
                throw new Exception('解密失败: ' . openssl_error_string());
            }
            
            return json_decode($decrypted, true);
        } catch (Exception $e) {
            $this->logger->error('解密过程出错: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 验证文件上传
     */
    public function validateFileUpload($file, $allowedTypes = array(), $maxSize = 5 * 1024 * 1024) {
        try {
            // 检查是否有错误
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $errorMessages = array(
                    UPLOAD_ERR_INI_SIZE => '上传文件超出服务器限制',
                    UPLOAD_ERR_FORM_SIZE => '上传文件超出表单限制',
                    UPLOAD_ERR_PARTIAL => '上传文件不完整',
                    UPLOAD_ERR_NO_FILE => '未选择文件',
                    UPLOAD_ERR_NO_TMP_DIR => '临时文件夹不存在',
                    UPLOAD_ERR_CANT_WRITE => '文件写入失败',
                    UPLOAD_ERR_EXTENSION => '文件上传被扩展阻止'
                );
                
                return array(
                    'valid' => false,
                    'error' => $errorMessages[$file['error']] ?? '未知上传错误'
                );
            }
            
            // 检查文件大小
            if ($file['size'] > $maxSize) {
                return array(
                    'valid' => false,
                    'error' => '文件大小超过限制: ' . ($maxSize / (1024 * 1024)) . 'MB'
                );
            }
            
            // 获取文件信息
            $fileInfo = pathinfo($file['name']);
            $extension = strtolower($fileInfo['extension'] ?? '');
            $mimeType = mime_content_type($file['tmp_name']);
            
            // 检查文件类型
            if (!empty($allowedTypes)) {
                if (!in_array($extension, $allowedTypes) && !in_array($mimeType, $allowedTypes)) {
                    return array(
                        'valid' => false,
                        'error' => '不支持的文件类型: ' . $extension
                    );
                }
            }
            
            // 恶意文件检查
            if ($this->containsMaliciousContent($file['tmp_name'], $extension, $mimeType)) {
                return array(
                    'valid' => false,
                    'error' => '检测到潜在的恶意内容'
                );
            }
            
            // 生成安全的文件名
            $safeFilename = $this->generateSafeFilename($file['name']);
            
            return array(
                'valid' => true,
                'file' => $file,
                'safe_filename' => $safeFilename,
                'extension' => $extension,
                'mime_type' => $mimeType
            );
        } catch (Exception $e) {
            $this->logger->error('文件上传验证失败: ' . $e->getMessage());
            return array(
                'valid' => false,
                'error' => '文件验证过程中发生错误'
            );
        }
    }
    
    /**
     * 检查文件是否包含恶意内容
     */
    private function containsMaliciousContent($filePath, $extension, $mimeType) {
        // 针对特定文件类型的检查
        switch ($extension) {
            case 'php':
            case 'php3':
            case 'php4':
            case 'php5':
            case 'phtml':
                // 禁止上传PHP文件
                return true;
                
            case 'jpg':
            case 'jpeg':
                // 检查是否是伪装的PHP文件
                if (!preg_match('/^image\/jpeg$/i', $mimeType)) {
                    return true;
                }
                break;
                
            case 'png':
                if (!preg_match('/^image\/png$/i', $mimeType)) {
                    return true;
                }
                break;
                
            case 'pdf':
                // 检查是否包含JavaScript
                $content = file_get_contents($filePath);
                if (preg_match('/<script/i', $content)) {
                    return true;
                }
                break;
        }
        
        // 通用恶意代码检查
        $content = file_get_contents($filePath);
        $suspiciousPatterns = array(
            '/eval\(/i',
            '/base64_decode\(/i',
            '/system\(/i',
            '/exec\(/i',
            '/shell_exec\(/i',
            '/passthru\(/i',
            '/`.*`/',
            '/\$_POST/i',
            '/\$_GET/i',
            '/\$_REQUEST/i',
            '/\$_SERVER/i',
            '/\$_FILES/i',
            '/<\?php/i',
            '/\?>/i',
            '/<script/i',
            '/javascript:/i',
            '/onload=/i',
            '/onerror=/i',
            '/onclick=/i'
        );
        
        foreach ($suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取客户端真实IP
     */
    public function getClientIP() {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    /**
     * 检查IP是否在白名单
     */
    public function isIPWhitelisted($ip) {
        return in_array($ip, $this->config['ip_whitelist']);
    }
    
    /**
     * 检查IP是否在黑名单
     */
    public function isIPBlacklisted($ip) {
        return in_array($ip, $this->config['ip_blacklist']);
    }
    
    /**
     * 加载安全配置
     */
    private function loadSecurityConfig() {
        return array(
            'force_https' => true,
            'csp_policy' => "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'",
            'encryption_key' => $this->getEncryptionKey(),
            'data_masking' => array(
                'default' => array(
                    'email' => array('type' => 'email', 'keep_start' => 2, 'keep_end' => 0),
                    'phone' => array('type' => 'phone', 'keep_start' => 3, 'keep_end' => 4),
                    'card_number' => array('type' => 'card', 'keep_start' => 4, 'keep_end' => 4),
                    'id_card' => array('type' => 'id_card', 'keep_start' => 6, 'keep_end' => 4),
                    'bank_account' => array('type' => 'bank_account', 'keep_start' => 4, 'keep_end' => 4)
                ),
                'admin' => array(
                    'email' => array('type' => 'email', 'keep_start' => 3, 'keep_end' => 2),
                    'phone' => array('type' => 'phone', 'keep_start' => 4, 'keep_end' => 3)
                )
            ),
            'ip_whitelist' => array(),
            'ip_blacklist' => array()
        );
    }
    
    /**
     * 获取加密密钥
     */
    private function getEncryptionKey($version = null) {
        try {
            $keyDir = dirname(__FILE__) . '/../keys/';
            if (!is_dir($keyDir)) {
                mkdir($keyDir, 0750, true);
            }
            
            // 获取当前密钥版本
            $currentVersion = $version ?: $this->getCurrentKeyVersion();
            $keyFile = $keyDir . 'encryption_' . $currentVersion . '.key';
            
            if (file_exists($keyFile)) {
                $key = file_get_contents($keyFile);
                if ($key && strlen($key) >= 32) {
                    return substr($key, 0, 32);
                }
            }
            
            // 如果指定版本的密钥不存在，生成新密钥
            $newKey = random_bytes(32);
            file_put_contents($keyFile, $newKey);
            chmod($keyFile, 0600);
            
            // 如果是新版本密钥，更新当前版本
            if (!$version) {
                $this->setCurrentKeyVersion($currentVersion);
            }
            
            return $newKey;
        } catch (Exception $e) {
            $this->logger->error('获取加密密钥失败: ' . $e->getMessage());
            // 使用备用密钥（生产环境中不应该使用）
            return substr(hash('sha256', 'fallback_encryption_key'), 0, 32);
        }
    }
    

    
    /**
     * 设置当前密钥版本
     */
    private function setCurrentKeyVersion($version) {
        $versionFile = dirname(__FILE__) . '/../keys/key_version.txt';
        file_put_contents($versionFile, $version);
        chmod($versionFile, 0600);
    }
    

    
    /**
     * 轮换加密密钥（高权限操作）
     */
    public function rotateEncryptionKey($adminUserId) {
        try {
            // 记录轮换操作
            $this->auditLogger->log('security', 'key_rotation', [
                'admin_user_id' => $adminUserId,
                'action' => 'initiated_key_rotation',
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            
            // 获取当前版本并增加1
            $currentVersion = $this->getCurrentKeyVersion();
            $newVersion = $currentVersion + 1;
            
            // 生成新版本密钥
            $this->getEncryptionKey($newVersion);
            
            // 更新当前版本
            $this->setCurrentKeyVersion($newVersion);
            
            // 记录成功
            $this->auditLogger->log('security', 'key_rotation', [
                'admin_user_id' => $adminUserId,
                'action' => 'key_rotation_completed',
                'from_version' => $currentVersion,
                'to_version' => $newVersion,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            
            $this->logger->info('加密密钥轮换成功', [
                'from_version' => $currentVersion,
                'to_version' => $newVersion
            ]);
            
            return ['success' => true, 'new_version' => $newVersion];
        } catch (Exception $e) {
            $this->auditLogger->log('security', 'key_rotation', [
                'admin_user_id' => $adminUserId,
                'action' => 'key_rotation_failed',
                'error' => $e->getMessage(),
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            $this->logger->error('密钥轮换失败: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 加密数据，增加版本信息
     */
    public function encrypt($data) {
        try {
            $key = $this->getEncryptionKey();
            $iv = random_bytes(16);
            $version = $this->getCurrentKeyVersion();
            
            // 添加版本信息到数据中
            $dataToEncrypt = [
                'v' => $version,
                'd' => $data
            ];
            
            $jsonData = json_encode($dataToEncrypt, JSON_UNESCAPED_UNICODE);
            $encrypted = openssl_encrypt(
                $jsonData,
                'AES-256-CBC',
                $key,
                0,
                $iv
            );
            
            if ($encrypted === false) {
                throw new Exception('加密失败: ' . openssl_error_string());
            }
            
            // 将IV和加密数据组合并Base64编码
            $result = base64_encode($iv . $encrypted);
            return $result;
        } catch (Exception $e) {
            $this->logger->error('加密过程出错: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 解密数据，支持多版本密钥
     */
    public function decrypt($encryptedData, $key = null) {
        try {
            // 检查输入
            if (empty($encryptedData)) {
                return null;
            }
            
            // 解密数据
            $data = base64_decode($encryptedData);
            
            if ($data === false) {
                throw new Exception('无效的加密数据');
            }
            
            // 提取iv
            $ivSize = openssl_cipher_iv_length('AES-256-CBC');
            $iv = substr($data, 0, $ivSize);
            $encrypted = substr($data, $ivSize);
            
            if (empty($iv) || empty($encrypted)) {
                throw new Exception('加密数据格式错误');
            }
            
            // 尝试使用当前密钥解密
            if ($key) {
                $actualKey = substr($key, 0, 32);
            } else {
                // 先使用当前密钥尝试解密
                $actualKey = $this->getEncryptionKey();
            }
            
            $decrypted = openssl_decrypt(
                $encrypted,
                'AES-256-CBC',
                $actualKey,
                0,
                $iv
            );
            
            if ($decrypted === false) {
                // 如果解密失败，尝试使用历史版本密钥（最多尝试3个历史版本）
                $currentVersion = $this->getCurrentKeyVersion();
                for ($v = $currentVersion - 1; $v >= max(1, $currentVersion - 3); $v--) {
                    $historicalKey = $this->getEncryptionKey($v);
                    $decrypted = openssl_decrypt(
                        $encrypted,
                        'AES-256-CBC',
                        $historicalKey,
                        0,
                        $iv
                    );
                    if ($decrypted !== false) {
                        break;
                    }
                }
            }
            
            if ($decrypted === false) {
                throw new Exception('解密失败: ' . openssl_error_string());
            }
            
            // 解析JSON数据
            $result = json_decode($decrypted, true);
            
            // 如果是新版本格式，返回原始数据
            if (is_array($result) && isset($result['d'])) {
                return $result['d'];
            }
            
            // 兼容旧版本格式
            return $result;
        } catch (Exception $e) {
            $this->logger->error('解密过程出错: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 获取当前密钥版本
     */
    private function getCurrentKeyVersion() {
        $versionFile = dirname(__FILE__) . '/../keys/key_version.txt';
        if (file_exists($versionFile)) {
            $version = trim(file_get_contents($versionFile));
            if (is_numeric($version) && $version > 0) {
                return intval($version);
            }
        }
        // 默认版本1
        return 1;
    }
}

/**
 * 限流器
 */
class RateLimiter {
    private $database;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function check($identifier, $limit, $window) {
        $now = time();
        $windowStart = $now - $window;
        
        // 清理过期记录
        $this->cleanup($windowStart);
        
        // 检查当前窗口内的请求数
        $count = $this->database->fetch(
            "SELECT COUNT(*) as count FROM rate_limits WHERE identifier = ? AND timestamp > ?",
            array($identifier, $windowStart)
        );
        
        if ($count['count'] >= $limit) {
            return false;
        }
        
        // 记录当前请求
        $this->database->insert("rate_limits", array(
            'identifier' => $identifier,
            'timestamp' => $now
        ));
        
        return true;
    }
    
    private function cleanup($before) {
        $this->database->execute(
            "DELETE FROM rate_limits WHERE timestamp < ?",
            array($before)
        );
    }
}

/**
 * 登录保护
 */
class LoginProtection {
    private $database;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function check($identifier) {
        $result = $this->database->fetch(
            "SELECT failure_count, last_failure_time FROM login_protection WHERE identifier = ?",
            array($identifier)
        );
        
        if (!$result) {
            return true;
        }
        
        $failureCount = $result['failure_count'];
        $lastFailureTime = strtotime($result['last_failure_time']);
        $now = time();
        
        // 如果失败次数超过阈值且在锁定时间内
        if ($failureCount >= 5 && ($now - $lastFailureTime) < 1800) { // 30分钟锁定
            return false;
        }
        
        // 如果超过30分钟，重置失败次数
        if (($now - $lastFailureTime) > 1800) {
            $this->resetFailures($identifier);
        }
        
        return true;
    }
    
    public function recordFailure($identifier, $ip, $userAgent) {
        $this->database->execute(
            "INSERT INTO login_protection (identifier, failure_count, last_failure_time, ip_address, user_agent) 
             VALUES (?, 1, NOW(), ?, ?)
             ON DUPLICATE KEY UPDATE 
             failure_count = failure_count + 1,
             last_failure_time = NOW(),
             ip_address = VALUES(ip_address),
             user_agent = VALUES(user_agent)",
            array($identifier, $ip, $userAgent)
        );
    }
    
    public function recordSuccess($identifier, $ip, $userAgent) {
        $this->resetFailures($identifier);
        
        // 记录成功登录日志
        $this->database->insert("login_logs", array(
            'identifier' => $identifier,
            'ip_address' => $ip,
            'user_agent' => $userAgent,
            'status' => 'success',
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
    
    private function resetFailures($identifier) {
        $this->database->update(
            "login_protection",
            array('failure_count' => 0),
            array('identifier' => $identifier)
        );
    }
}

/**
 * 审计日志记录器
 */
class AuditLogger {
    private $database;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function log($userId, $action, $resource, $details = array()) {
        $this->database->insert("audit_logs", array(
            'user_id' => $userId,
            'action' => $action,
            'resource' => $resource,
            'details' => json_encode($details),
            'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
}