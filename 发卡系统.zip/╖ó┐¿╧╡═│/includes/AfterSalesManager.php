<?php
/**
 * 售后管理系统
 * 处理订单售后申请、处理、退款/补发等操作
 */
class AfterSalesManager {
    
    /**
     * @var Database 数据库连接实例
     */
    private $database;
    
    /**
     * @var Logger 日志实例
     */
    private $logger;
    
    /**
     * @var OrderManager 订单管理器
     */
    private $orderManager;
    
    /**
     * @var CardManager 卡密管理器
     */
    private $cardManager;
    
    /**
     * 售后状态常量
     */
    const STATUS_PENDING = 'pending';           // 待处理
    const STATUS_PROCESSING = 'processing';     // 处理中
    const STATUS_APPROVED = 'approved';         // 已批准
    const STATUS_REJECTED = 'rejected';         // 已拒绝
    const STATUS_COMPLETED = 'completed';       // 已完成
    const STATUS_CANCELLED = 'cancelled';       // 已取消
    
    /**
     * 售后类型常量
     */
    const TYPE_REFUND = 'refund';               // 退款
    const TYPE_RESEND = 'resend';               // 补发
    const TYPE_COMPLAINT = 'complaint';         // 投诉
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->database = new Database();
        $this->logger = new Logger();
        $this->orderManager = new OrderManager();
        $this->cardManager = new CardManager();
    }
    
    /**
     * 创建售后申请
     * @param int $orderId 订单ID
     * @param array $data 售后申请数据
     * @return array 操作结果
     */
    public function createAfterSales($orderId, $data) {
        try {
            // 获取订单信息
            $order = $this->orderManager->getOrder($orderId);
            if (!$order) {
                return ['success' => false, 'message' => '订单不存在'];
            }
            
            // 检查订单状态
            if ($order['status'] !== 'completed' && $order['status'] !== 'paid') {
                return ['success' => false, 'message' => '只有已完成或已支付的订单才能申请售后'];
            }
            
            // 检查是否已有售后申请
            $existing = $this->database->fetch(
                "SELECT id FROM order_after_sales WHERE order_id = ?", 
                [$orderId]
            );
            if ($existing) {
                return ['success' => false, 'message' => '该订单已有售后申请'];
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 准备售后数据
            $afterSalesData = [
                'order_id' => $orderId,
                'user_id' => $data['user_id'],
                'type' => $data['type'] ?? self::TYPE_REFUND,
                'reason' => $data['reason'],
                'description' => $data['description'] ?? '',
                'evidence_urls' => json_encode($data['evidence_urls'] ?? []),
                'status' => self::STATUS_PENDING,
                'amount' => $data['amount'] ?? $order['actual_amount'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            // 创建售后记录
            $afterSalesId = $this->database->insert('order_after_sales', $afterSalesData);
            
            // 更新订单售后状态
            $this->database->update('orders', 
                ['after_sales_status' => 'pending_processing'], 
                'id = ?', 
                [$orderId]
            );
            
            // 更新卡密状态
            if (!empty($data['card_ids'])) {
                foreach ($data['card_ids'] as $cardId) {
                    $this->database->update('order_cards', 
                        ['is_after_sales' => 1, 'after_sales_id' => $afterSalesId], 
                        'order_id = ? AND card_id = ?', 
                        [$orderId, $cardId]
                    );
                }
            }
            
            // 记录操作日志
            $this->addAfterSalesLog($afterSalesId, $data['user_id'], 'user', 'create', '创建售后申请');
            
            // 提交事务
            $this->database->commit();
            
            return [
                'success' => true,
                'after_sales_id' => $afterSalesId,
                'message' => '售后申请提交成功'
            ];
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error('创建售后申请失败: ' . $e->getMessage());
            return ['success' => false, 'message' => '服务器错误，请稍后重试'];
        }
    }
    
    /**
     * 处理售后申请
     * @param int $afterSalesId 售后ID
     * @param array $data 处理数据
     * @return array 操作结果
     */
    public function processAfterSales($afterSalesId, $data) {
        try {
            // 获取售后信息
            $afterSales = $this->database->fetch(
                "SELECT * FROM order_after_sales WHERE id = ?", 
                [$afterSalesId]
            );
            
            if (!$afterSales) {
                return ['success' => false, 'message' => '售后申请不存在'];
            }
            
            // 检查状态
            if (!in_array($afterSales['status'], [self::STATUS_PENDING, self::STATUS_PROCESSING])) {
                return ['success' => false, 'message' => '该售后申请已处理完毕'];
            }
            
            // 开始事务
            $this->database->beginTransaction();
            
            // 获取订单信息
            $order = $this->orderManager->getOrder($afterSales['order_id']);
            
            // 根据操作类型处理
            $result = [];
            if ($data['action'] === 'approve') {
                // 批准售后
                $result = $this->approveAfterSales($afterSales, $order, $data);
            } elseif ($data['action'] === 'reject') {
                // 拒绝售后
                $result = $this->rejectAfterSales($afterSales, $data);
            } elseif ($data['action'] === 'cancel') {
                // 取消售后
                $result = $this->cancelAfterSales($afterSales);
            } else {
                throw new Exception('无效的操作类型');
            }
            
            if (!$result['success']) {
                $this->database->rollback();
                return $result;
            }
            
            // 记录操作日志
            $this->addAfterSalesLog(
                $afterSalesId, 
                $data['admin_id'], 
                'merchant', 
                $data['action'], 
                $data['admin_note'] ?? ''
            );
            
            // 提交事务
            $this->database->commit();
            
            return $result;
            
        } catch (Exception $e) {
            $this->database->rollback();
            $this->logger->error('处理售后申请失败: ' . $e->getMessage());
            return ['success' => false, 'message' => '服务器错误，请稍后重试'];
        }
    }
    
    /**
     * 批准售后
     * @param array $afterSales 售后信息
     * @param array $order 订单信息
     * @param array $data 处理数据
     * @return array 操作结果
     */
    private function approveAfterSales($afterSales, $order, $data) {
        // 更新售后状态
        $this->database->update('order_after_sales', 
            [
                'status' => self::STATUS_APPROVED,
                'admin_id' => $data['admin_id'],
                'admin_note' => $data['admin_note'] ?? '',
                'processed_at' => date('Y-m-d H:i:s')
            ], 
            'id = ?', 
            [$afterSales['id']]
        );
        
        // 根据售后类型进行不同处理
        if ($afterSales['type'] === self::TYPE_REFUND) {
            // 处理退款
            return $this->processRefund($afterSales, $order, $data);
        } elseif ($afterSales['type'] === self::TYPE_RESEND) {
            // 处理补发
            return $this->processResend($afterSales, $order, $data);
        }
        
        return ['success' => true, 'message' => '售后申请已批准'];
    }
    
    /**
     * 处理退款
     * @param array $afterSales 售后信息
     * @param array $order 订单信息
     * @param array $data 处理数据
     * @return array 操作结果
     */
    private function processRefund($afterSales, $order, $data) {
        // 创建退款订单
        $refundOrderId = $this->createRefundOrder($order, $afterSales['amount']);
        
        // 更新售后记录关联退款订单
        $this->database->update('order_after_sales', 
            [
                'refund_order_id' => $refundOrderId,
                'status' => self::STATUS_COMPLETED
            ], 
            'id = ?', 
            [$afterSales['id']]
        );
        
        // 更新原订单状态
        $this->database->update('orders', 
            [
                'status' => $data['full_refund'] ? 'refunded' : 'partial_refund',
                'after_sales_status' => 'completed'
            ], 
            'id = ?', 
            [$order['id']]
        );
        
        // 更新卡密状态
        $this->database->update('order_cards', 
            ['status' => 'refunded', 'refund_amount' => $afterSales['amount']], 
            'after_sales_id = ?', 
            [$afterSales['id']]
        );
        
        return [
            'success' => true,
            'message' => '退款处理成功',
            'refund_order_id' => $refundOrderId
        ];
    }
    
    /**
     * 处理补发
     * @param array $afterSales 售后信息
     * @param array $order 订单信息
     * @param array $data 处理数据
     * @return array 操作结果
     */
    private function processResend($afterSales, $order, $data) {
        // 获取需要补发的卡密数量
        $cardCount = count($data['card_ids'] ?? []) ?: 1;
        
        // 分配新卡密
        $newCardIds = $this->cardManager->reserveCards($order['product_id'], $cardCount, 0);
        
        // 关联新卡密到售后记录
        foreach ($newCardIds as $index => $newCardId) {
            $oldCardId = $data['card_ids'][$index] ?? 0;
            
            // 记录替换关系
            if ($oldCardId) {
                $this->database->update('order_cards', 
                    ['replace_card_id' => $newCardId], 
                    'card_id = ?', 
                    [$oldCardId]
                );
            }
            
            // 创建新的订单卡密关联
            $this->database->insert('order_cards', [
                'order_id' => $order['id'],
                'card_id' => $newCardId,
                'status' => 'activated',
                'after_sales_id' => $afterSales['id'],
                'created_at' => date('Y-m-d H:i:s'),
                'activated_at' => date('Y-m-d H:i:s')
            ]);
        }
        
        // 更新售后状态为已完成
        $this->database->update('order_after_sales', 
            ['status' => self::STATUS_COMPLETED], 
            'id = ?', 
            [$afterSales['id']]
        );
        
        // 更新订单售后状态
        $this->database->update('orders', 
            ['after_sales_status' => 'completed'], 
            'id = ?', 
            [$order['id']]
        );
        
        return [
            'success' => true,
            'message' => '卡密补发成功',
            'new_card_ids' => $newCardIds
        ];
    }
    
    /**
     * 拒绝售后
     * @param array $afterSales 售后信息
     * @param array $data 处理数据
     * @return array 操作结果
     */
    private function rejectAfterSales($afterSales, $data) {
        // 更新售后状态
        $this->database->update('order_after_sales', 
            [
                'status' => self::STATUS_REJECTED,
                'admin_id' => $data['admin_id'],
                'admin_note' => $data['admin_note'] ?? '',
                'processed_at' => date('Y-m-d H:i:s')
            ], 
            'id = ?', 
            [$afterSales['id']]
        );
        
        // 更新订单售后状态
        $this->database->update('orders', 
            ['after_sales_status' => null], 
            'id = ?', 
            [$afterSales['order_id']]
        );
        
        // 重置卡密状态
        $this->database->update('order_cards', 
            ['is_after_sales' => 0, 'after_sales_id' => null], 
            'after_sales_id = ?', 
            [$afterSales['id']]
        );
        
        return ['success' => true, 'message' => '售后申请已拒绝'];
    }
    
    /**
     * 取消售后
     * @param array $afterSales 售后信息
     * @return array 操作结果
     */
    private function cancelAfterSales($afterSales) {
        // 更新售后状态
        $this->database->update('order_after_sales', 
            ['status' => self::STATUS_CANCELLED], 
            'id = ?', 
            [$afterSales['id']]
        );
        
        // 更新订单售后状态
        $this->database->update('orders', 
            ['after_sales_status' => null], 
            'id = ?', 
            [$afterSales['order_id']]
        );
        
        return ['success' => true, 'message' => '售后申请已取消'];
    }
    
    /**
     * 创建退款订单
     * @param array $order 原订单信息
     * @param float $amount 退款金额
     * @return int 退款订单ID
     */
    private function createRefundOrder($order, $amount) {
        // 创建退款订单记录
        $refundOrderData = [
            'order_no' => $this->generateRefundOrderNo(),
            'user_id' => $order['user_id'],
            'product_id' => $order['product_id'],
            'product_name' => $order['product_name'] . '(退款)',
            'quantity' => $order['quantity'],
            'unit_price' => $order['unit_price'],
            'total_amount' => -$amount,
            'discount_amount' => 0,
            'actual_amount' => -$amount,
            'payment_method' => $order['payment_method'],
            'status' => 'completed',
            'remark' => '售后退款',
            'parent_order_id' => $order['id'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            'completed_at' => date('Y-m-d H:i:s')
        ];
        
        return $this->database->insert('orders', $refundOrderData);
    }
    
    /**
     * 添加售后处理日志
     * @param int $afterSalesId 售后ID
     * @param int $operatorId 操作人ID
     * @param string $operatorType 操作人类型
     * @param string $action 操作动作
     * @param string $content 操作内容
     */
    public function addAfterSalesLog($afterSalesId, $operatorId, $operatorType, $action, $content) {
        $this->database->insert('after_sales_logs', [
            'after_sales_id' => $afterSalesId,
            'operator_id' => $operatorId,
            'operator_type' => $operatorType,
            'action' => $action,
            'content' => $content,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * 获取售后申请列表
     * @param array $filters 过滤条件
     * @param int $page 页码
     * @param int $limit 每页数量
     * @return array 分页数据
     */
    public function getAfterSalesList($filters = [], $page = 1, $limit = 20) {
        try {
            // 构建查询条件
            $whereClause = "1=1";
            $params = [];
            
            if (isset($filters['order_id'])) {
                $whereClause .= " AND order_id = ?";
                $params[] = $filters['order_id'];
            }
            
            if (isset($filters['user_id'])) {
                $whereClause .= " AND user_id = ?";
                $params[] = $filters['user_id'];
            }
            
            if (isset($filters['status'])) {
                $whereClause .= " AND status = ?";
                $params[] = $filters['status'];
            }
            
            if (isset($filters['type'])) {
                $whereClause .= " AND type = ?";
                $params[] = $filters['type'];
            }
            
            // 获取总数
            $countSql = "SELECT COUNT(*) as total FROM order_after_sales WHERE {$whereClause}";
            $total = $this->database->fetch($countSql, $params);
            $total = $total['total'];
            
            // 分页查询
            $offset = ($page - 1) * $limit;
            $sql = "SELECT * FROM order_after_sales WHERE {$whereClause} ORDER BY created_at DESC LIMIT {$offset}, {$limit}";
            $list = $this->database->fetchAll($sql, $params);
            
            // 格式化数据
            foreach ($list as &$item) {
                $item['evidence_urls'] = json_decode($item['evidence_urls'], true) ?: [];
                $item['logs'] = $this->getAfterSalesLogs($item['id']);
                $item['order_info'] = $this->orderManager->getOrder($item['order_id']);
            }
            
            return [
                'list' => $list,
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'pages' => ceil($total / $limit)
            ];
            
        } catch (Exception $e) {
            $this->logger->error('获取售后列表失败: ' . $e->getMessage());
            return ['list' => [], 'total' => 0, 'page' => 1, 'limit' => $limit, 'pages' => 0];
        }
    }
    
    /**
     * 获取售后处理日志
     * @param int $afterSalesId 售后ID
     * @return array 日志列表
     */
    public function getAfterSalesLogs($afterSalesId) {
        $sql = "SELECT * FROM after_sales_logs WHERE after_sales_id = ? ORDER BY created_at DESC";
        return $this->database->fetchAll($sql, [$afterSalesId]);
    }
    
    /**
     * 获取订单关联的售后信息
     * @param int $orderId 订单ID
     * @return array 售后信息列表
     */
    public function getOrderAfterSalesInfo($orderId) {
        $sql = "SELECT * FROM order_after_sales WHERE order_id = ? ORDER BY created_at DESC";
        $afterSalesList = $this->database->fetchAll($sql, [$orderId]);
        
        // 格式化售后信息
        foreach ($afterSalesList as &$afterSales) {
            $afterSales['evidence_urls'] = json_decode($afterSales['evidence_urls'], true) ?: [];
        }
        
        return $afterSalesList;
    }
    
    /**
     * 获取售后详情
     * @param int $afterSalesId 售后ID
     * @return array 售后详情信息
     */
    public function getAfterSalesDetail($afterSalesId) {
        $sql = "SELECT * FROM order_after_sales WHERE id = ?";
        $afterSales = $this->database->fetch($sql, [$afterSalesId]);
        
        if ($afterSales) {
            $afterSales['evidence_urls'] = json_decode($afterSales['evidence_urls'], true) ?: [];
            $afterSales['logs'] = $this->getAfterSalesLogs($afterSalesId);
            $afterSales['order_info'] = $this->orderManager->getOrder($afterSales['order_id']);
            
            // 获取关联的卡密信息
            $cardsSql = "SELECT oc.*, c.card_no, c.card_password 
                         FROM order_cards oc 
                         LEFT JOIN cards c ON oc.card_id = c.id
                         WHERE oc.after_sales_id = ?";
            $afterSales['related_cards'] = $this->database->fetchAll($cardsSql, [$afterSalesId]);
        }
        
        return $afterSales;
    }
    
    /**
     * 生成退款订单号
     * @return string 退款订单号
     */
    private function generateRefundOrderNo() {
        return 'REF' . date('YmdHis') . mt_rand(1000, 9999);
    }
}
?>