<?php
/**
 * 风控管理器
 * 负责实时风控反欺诈、规则引擎、风险评分等功能
 */

class RiskManager {
    private $database;
    private $config;
    private $securityManager;
    
    /**
     * 构造函数
     * @param Database $database 数据库实例
     * @param SecurityManager $securityManager 安全管理器实例
     */
    public function __construct($database, $securityManager) {
        $this->database = $database;
        $this->securityManager = $securityManager;
        $this->config = $this->loadConfig();
    }
    
    /**
     * 加载风控配置
     */
    private function loadConfig() {
        return array(
            'risk_thresholds' => array(
                'low' => 0,
                'medium' => 50,
                'high' => 80,
                'critical' => 120
            ),
            'ip_check_enabled' => true,
            'device_fingerprinting_enabled' => true,
            'behavior_analysis_enabled' => true,
            'real_time_monitoring_enabled' => true,
            'auto_block_threshold' => 150
        );
    }
    
    /**
     * 检查操作是否存在风险
     * @param string $eventType 事件类型
     * @param array $data 事件数据
     * @return array 风险评估结果
     */
    public function checkRisk($eventType, $data) {
        $triggeredRules = array();
        $riskScore = 0;
        $action = 'allow'; // 默认允许
        
        // 获取相关规则
        $rules = $this->getRulesByType($eventType);
        
        // 检查每条规则
        foreach ($rules as $rule) {
            if ($this->evaluateRule($rule, $data)) {
                $triggeredRules[] = array(
                    'rule_id' => $rule['id'],
                    'rule_name' => $rule['rule_name'],
                    'risk_score' => $rule['risk_score']
                );
                $riskScore += $rule['risk_score'];
            }
        }
        
        // 额外的风险检查
        switch ($eventType) {
            case 'login':
                $additionalScore = $this->checkLoginRisk($data);
                $riskScore += $additionalScore;
                break;
            case 'transaction':
                $additionalScore = $this->checkTransactionRisk($data);
                $riskScore += $additionalScore;
                break;
            case 'registration':
                $additionalScore = $this->checkRegistrationRisk($data);
                $riskScore += $additionalScore;
                break;
        }
        
        // 确定风险等级
        $riskLevel = $this->determineRiskLevel($riskScore);
        
        // 确定操作
        if ($riskScore >= $this->config['auto_block_threshold']) {
            $action = 'block';
        } elseif ($riskScore >= $this->config['risk_thresholds']['high']) {
            $action = 'review';
        } elseif ($riskScore >= $this->config['risk_thresholds']['medium']) {
            $action = 'verify';
        }
        
        // 记录风控事件
        $eventId = $this->logRiskEvent($eventType, $data, $triggeredRules, $riskScore, $riskLevel);
        
        return array(
            'risk_score' => $riskScore,
            'risk_level' => $riskLevel,
            'triggered_rules' => $triggeredRules,
            'action' => $action,
            'event_id' => $eventId
        );
    }
    
    /**
     * 根据事件类型获取规则
     */
    private function getRulesByType($eventType) {
        return $this->database->fetchAll(
            "SELECT * FROM risk_rules WHERE rule_type = ? AND status = 'enabled' ORDER BY priority ASC",
            array($eventType)
        );
    }
    
    /**
     * 评估规则
     */
    private function evaluateRule($rule, $data) {
        $conditions = json_decode($rule['conditions'], true);
        
        switch ($rule['rule_name']) {
            case '多次登录失败':
                return $this->evaluateLoginFailureRule($conditions, $data);
            case '异常IP登录':
                return $this->evaluateAbnormalIpRule($conditions, $data);
            case '批量注册检测':
                return $this->evaluateBulkRegistrationRule($conditions, $data);
            case '高频交易检测':
                return $this->evaluateHighFrequencyTransactionRule($conditions, $data);
            case '异常交易金额':
                return $this->evaluateAbnormalAmountRule($conditions, $data);
            case '批量退款检测':
                return $this->evaluateBulkRefundRule($conditions, $data);
            case '异常地点访问':
                return $this->evaluateLocationAccessRule($conditions, $data);
            default:
                return $this->evaluateGenericRule($conditions, $data);
        }
    }
    
    /**
     * 评估登录失败规则
     */
    private function evaluateLoginFailureRule($conditions, $data) {
        if (!isset($data['user_id']) && !isset($data['identifier'])) {
            return false;
        }
        
        $identifier = isset($data['identifier']) ? $data['identifier'] : '';
        $timeWindow = $conditions['time_window'];
        $maxAttempts = $conditions['max_attempts'];
        
        $count = $this->database->fetch(
            "SELECT COUNT(*) as count FROM login_logs 
             WHERE identifier = ? AND status = 'failure' 
             AND created_at >= DATE_SUB(NOW(), INTERVAL ? SECOND)",
            array($identifier, $timeWindow)
        );
        
        return $count['count'] >= $maxAttempts;
    }
    
    /**
     * 评估异常IP规则
     */
    private function evaluateAbnormalIpRule($conditions, $data) {
        if (!isset($data['user_id']) || !isset($data['ip_address'])) {
            return false;
        }
        
        $userId = $data['user_id'];
        $ipAddress = $data['ip_address'];
        $daysToCheck = $conditions['days_to_check'];
        
        $count = $this->database->fetch(
            "SELECT COUNT(*) as count FROM login_logs 
             WHERE identifier = ? AND ip_address = ? 
             AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)",
            array($userId, $ipAddress, $daysToCheck)
        );
        
        // 如果这是新IP，返回true
        return $count['count'] == 0;
    }
    
    /**
     * 评估批量注册规则
     */
    private function evaluateBulkRegistrationRule($conditions, $data) {
        if (!isset($data['ip_address'])) {
            return false;
        }
        
        $ipAddress = $data['ip_address'];
        $timeWindow = $conditions['time_window'];
        $maxRegistrations = $conditions['max_registrations'];
        
        $count = $this->database->fetch(
            "SELECT COUNT(*) as count FROM users 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? SECOND)",
            array($timeWindow)
        );
        
        return $count['count'] >= $maxRegistrations;
    }
    
    /**
     * 评估通用规则
     */
    private function evaluateGenericRule($conditions, $data) {
        // 这是一个通用评估函数，可以根据具体的规则条件进行扩展
        return false;
    }
    
    /**
     * 评估高频交易规则
     */
    private function evaluateHighFrequencyTransactionRule($conditions, $data) {
        if (!isset($data['user_id'])) {
            return false;
        }
        
        $userId = $data['user_id'];
        $timeWindow = $conditions['time_window'];
        $maxTransactions = $conditions['max_transactions'];
        
        $count = $this->database->fetch(
            "SELECT COUNT(*) as count FROM orders 
             WHERE user_id = ? 
             AND created_at >= DATE_SUB(NOW(), INTERVAL ? SECOND)",
            array($userId, $timeWindow)
        );
        
        return $count['count'] >= $maxTransactions;
    }
    
    /**
     * 评估异常交易金额规则
     */
    private function evaluateAbnormalAmountRule($conditions, $data) {
        if (!isset($data['user_id']) || !isset($data['amount'])) {
            return false;
        }
        
        $userId = $data['user_id'];
        $currentAmount = $data['amount'];
        $percentageThreshold = $conditions['percentage_deviation'];
        
        // 获取用户历史平均交易金额
        $avgAmount = $this->database->fetch(
            "SELECT AVG(amount) as avg_amount FROM orders 
             WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            array($userId)
        );
        
        if ($avgAmount['avg_amount'] > 0) {
            $percentageChange = abs($currentAmount - $avgAmount['avg_amount']) / $avgAmount['avg_amount'] * 100;
            return $percentageChange >= $percentageThreshold;
        }
        
        return false;
    }
    
    /**
     * 评估批量退款规则
     */
    private function evaluateBulkRefundRule($conditions, $data) {
        if (!isset($data['user_id']) && !isset($data['merchant_id'])) {
            return false;
        }
        
        $userId = isset($data['user_id']) ? $data['user_id'] : null;
        $merchantId = isset($data['merchant_id']) ? $data['merchant_id'] : null;
        $timeWindow = $conditions['time_window'];
        $maxRefunds = $conditions['max_refunds'];
        
        $query = "SELECT COUNT(*) as count FROM orders WHERE status = 'refunded' AND created_at >= DATE_SUB(NOW(), INTERVAL ? SECOND";
        $params = array($timeWindow);
        
        if ($userId) {
            $query .= " AND user_id = ?";
            $params[] = $userId;
        } elseif ($merchantId) {
            $query .= " AND merchant_id = ?";
            $params[] = $merchantId;
        }
        
        $query .= ")";
        
        $count = $this->database->fetch($query, $params);
        
        return $count['count'] >= $maxRefunds;
    }
    
    /**
     * 评估异常地点访问规则
     */
    private function evaluateLocationAccessRule($conditions, $data) {
        // 注意：此方法需要地理位置API支持，这里简化处理
        return false;
    }
    
    /**
     * 检查登录风险
     */
    private function checkLoginRisk($data) {
        $score = 0;
        
        // 检查IP是否在黑名单
        if (isset($data['ip_address']) && $this->securityManager->isIPBlacklisted($data['ip_address'])) {
            $score += 50;
        }
        
        // 检查设备指纹
        if (isset($data['device_id'])) {
            $deviceRisk = $this->checkDeviceRisk($data['device_id']);
            $score += $deviceRisk;
        }
        
        return $score;
    }
    
    /**
     * 检查交易风险
     */
    private function checkTransactionRisk($data) {
        $score = 0;
        
        // 检查商户信用
        if (isset($data['merchant_id'])) {
            $merchantRisk = $this->checkMerchantRisk($data['merchant_id']);
            $score += $merchantRisk;
        }
        
        // 检查用户历史行为
        if (isset($data['user_id'])) {
            $userBehaviorRisk = $this->checkUserBehaviorRisk($data['user_id']);
            $score += $userBehaviorRisk;
        }
        
        return $score;
    }
    
    /**
     * 检查注册风险
     */
    private function checkRegistrationRisk($data) {
        $score = 0;
        
        // 检查IP注册历史
        if (isset($data['ip_address'])) {
            $ipScore = $this->checkIPRegistrationHistory($data['ip_address']);
            $score += $ipScore;
        }
        
        return $score;
    }
    
    /**
     * 检查设备风险
     */
    private function checkDeviceRisk($deviceId) {
        $device = $this->database->fetch(
            "SELECT risk_score, anomaly_count FROM device_fingerprints WHERE device_id = ?",
            array($deviceId)
        );
        
        if ($device) {
            return $device['risk_score'] > 0 ? $device['risk_score'] : ($device['anomaly_count'] * 5);
        }
        
        return 0;
    }
    
    /**
     * 检查商户风险
     */
    private function checkMerchantRisk($merchantId) {
        $merchant = $this->database->fetch(
            "SELECT credit_score, credit_level FROM merchant_credit_rating WHERE merchant_id = ?",
            array($merchantId)
        );
        
        if ($merchant) {
            // 风险分数与信用分数成反比
            $baseScore = 100 - ($merchant['credit_score'] / 2); // 将200分的信用分转换为0-100的风险分
            
            // 对于特别差的商户，额外增加风险分
            if ($merchant['credit_level'] == 'bad') {
                $baseScore += 50;
            } elseif ($merchant['credit_level'] == 'poor') {
                $baseScore += 25;
            }
            
            return max(0, $baseScore);
        }
        
        return 0;
    }
    
    /**
     * 检查用户行为风险
     */
    private function checkUserBehaviorRisk($userId) {
        // 检查用户的异常行为数量
        $anomalyCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM user_behaviors 
             WHERE user_id = ? AND behavior_type IN ('unusual_login', 'suspicious_activity') 
             AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)",
            array($userId)
        );
        
        return $anomalyCount['count'] * 10;
    }
    
    /**
     * 检查IP注册历史
     */
    private function checkIPRegistrationHistory($ipAddress) {
        $registrationCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM users 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            array()
        );
        
        return $registrationCount['count'] * 15;
    }
    
    /**
     * 确定风险等级
     */
    private function determineRiskLevel($score) {
        if ($score >= $this->config['risk_thresholds']['critical']) {
            return 'critical';
        } elseif ($score >= $this->config['risk_thresholds']['high']) {
            return 'high';
        } elseif ($score >= $this->config['risk_thresholds']['medium']) {
            return 'medium';
        } else {
            return 'low';
        }
    }
    
    /**
     * 记录风控事件
     */
    private function logRiskEvent($eventType, $data, $triggeredRules, $riskScore, $riskLevel) {
        $eventData = array(
            'event_type' => $eventType,
            'user_id' => isset($data['user_id']) ? $data['user_id'] : null,
            'merchant_id' => isset($data['merchant_id']) ? $data['merchant_id'] : null,
            'ip_address' => isset($data['ip_address']) ? $data['ip_address'] : null,
            'device_id' => isset($data['device_id']) ? $data['device_id'] : null,
            'user_agent' => isset($data['user_agent']) ? $data['user_agent'] : null,
            'related_data' => json_encode(array_filter($data, function($key) {
                return !in_array($key, array('user_id', 'merchant_id', 'ip_address', 'device_id', 'user_agent'));
            }, ARRAY_FILTER_USE_KEY)),
            'triggered_rules' => json_encode($triggeredRules),
            'risk_score' => $riskScore,
            'risk_level' => $riskLevel
        );
        
        return $this->database->insert('risk_events', $eventData);
    }
    
    /**
     * 记录用户行为
     * @param int $userId 用户ID
     * @param string $behaviorType 行为类型
     * @param array $behaviorData 行为数据
     */
    public function logUserBehavior($userId, $behaviorType, $behaviorData) {
        $data = array(
            'user_id' => $userId,
            'behavior_type' => $behaviorType,
            'behavior_data' => json_encode($behaviorData),
            'ip_address' => $this->securityManager->getClientIP(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null
        );
        
        return $this->database->insert('user_behaviors', $data);
    }
    
    /**
     * 检测并记录IP异常
     * @param string $ipAddress IP地址
     * @param string $anomalyType 异常类型
     */
    public function detectIPAnomaly($ipAddress, $anomalyType) {
        // 检查是否已经记录了此IP的异常
        $existingAnomaly = $this->database->fetch(
            "SELECT id, anomaly_count FROM ip_anomalies WHERE ip_address = ? AND anomaly_type = ?",
            array($ipAddress, $anomalyType)
        );
        
        if ($existingAnomaly) {
            // 更新现有记录
            $this->database->update('ip_anomalies', array(
                'anomaly_count' => $existingAnomaly['anomaly_count'] + 1,
                'last_detected' => date('Y-m-d H:i:s')
            ), array('id' => $existingAnomaly['id']));
        } else {
            // 创建新记录
            $this->database->insert('ip_anomalies', array(
                'ip_address' => $ipAddress,
                'anomaly_type' => $anomalyType,
                'anomaly_count' => 1,
                'last_detected' => date('Y-m-d H:i:s'),
                'risk_level' => 'medium' // 默认风险等级
            ));
        }
    }
    
    /**
     * 生成设备指纹
     * @param array $browserData 浏览器数据
     * @return string 设备ID
     */
    public function generateDeviceFingerprint($browserData) {
        // 简化的设备指纹生成逻辑
        $fingerprintData = array(
            isset($browserData['user_agent']) ? $browserData['user_agent'] : '',
            isset($browserData['screen_resolution']) ? $browserData['screen_resolution'] : '',
            isset($browserData['timezone']) ? $browserData['timezone'] : '',
            isset($browserData['language']) ? $browserData['language'] : ''
        );
        
        $deviceId = md5(implode('|', $fingerprintData));
        
        // 检查是否已有此设备ID
        $existingDevice = $this->database->fetch(
            "SELECT id FROM device_fingerprints WHERE device_id = ?",
            array($deviceId)
        );
        
        if (!$existingDevice) {
            // 创建新设备记录
            $this->database->insert('device_fingerprints', array(
                'device_id' => $deviceId,
                'browser' => isset($browserData['browser']) ? $browserData['browser'] : null,
                'os' => isset($browserData['os']) ? $browserData['os'] : null,
                'screen_resolution' => isset($browserData['screen_resolution']) ? $browserData['screen_resolution'] : null,
                'device_type' => isset($browserData['device_type']) ? $browserData['device_type'] : null,
                'last_seen' => date('Y-m-d H:i:s')
            ));
        } else {
            // 更新最后出现时间
            $this->database->update('device_fingerprints', array(
                'last_seen' => date('Y-m-d H:i:s')
            ), array('device_id' => $deviceId));
        }
        
        return $deviceId;
    }
    
    /**
     * 更新商户信用评分
     * @param int $merchantId 商户ID
     */
    public function updateMerchantCreditScore($merchantId) {
        // 调用存储过程更新商户信用评分
        $this->database->execute(
            "CALL UpdateMerchantCreditScore(?)",
            array($merchantId)
        );
    }
    
    /**
     * 获取风控仪表盘数据
     * @return array 仪表盘数据
     */
    public function getDashboardData() {
        return $this->database->fetch(
            "SELECT * FROM v_risk_dashboard"
        );
    }
    
    /**
     * 获取风控统计数据
     * @param int $days 统计天数
     * @return array 统计数据
     */
    public function getRiskStatistics($days = 7) {
        $endDate = date('Y-m-d');
        $startDate = date('Y-m-d', strtotime("-$days days"));
        
        return $this->database->fetchAll(
            "SELECT 
                DATE(created_at) as date,
                COUNT(*) as total_events,
                SUM(CASE WHEN risk_level = 'critical' THEN 1 ELSE 0 END) as critical_events,
                SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END) as high_events,
                SUM(CASE WHEN risk_level = 'medium' THEN 1 ELSE 0 END) as medium_events,
                SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END) as low_events
             FROM risk_events 
             WHERE created_at BETWEEN ? AND ?
             GROUP BY DATE(created_at)
             ORDER BY date ASC",
            array("$startDate 00:00:00", "$endDate 23:59:59")
        );
    }
}