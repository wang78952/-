<?php
/**
 * CDN资源管理器
 * 处理静态资源的CDN URL生成和管理
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/CacheManager.php';

class CDNManager extends BaseService {
    private static $instance;
    private $config;
    private $cacheManager;
    private $versionCache;
    private $isDevelopment;
    
    // 私有构造函数
    private function __construct() {
        parent::__construct();
        
        // 加载CDN配置
        $this->config = require_once __DIR__ . '/../config/cdn.php';
        $this->cacheManager = CacheManager::getInstance() ?? new CacheManager();
        $this->isDevelopment = defined('DEBUG_MODE') && DEBUG_MODE;
        $this->versionCache = null;
        
        // 开发环境时使用开发配置
        if ($this->isDevelopment) {
            $this->config['enabled'] = $this->config['development']['enabled'];
            $this->config['base_url'] = $this->config['development']['base_url'];
        }
    }
    
    /**
     * 获取资源URL
     * @param string $path 资源相对路径
     * @param string $type 资源类型 (css, js, images, lang)
     * @return string 完整的资源URL
     */
    public function getResourceUrl($path, $type = null) {
        // 如果CDN未启用，直接返回相对路径
        if (!$this->config['enabled']) {
            return $this->addVersionToUrl($path);
        }
        
        // 确定资源类型
        if (!$type) {
            $type = $this->detectResourceType($path);
        }
        
        // 检查资源类型是否启用了CDN
        if ($type && isset($this->config['resources'][$type]) && !$this->config['resources'][$type]['enabled']) {
            return $this->addVersionToUrl($path);
        }
        
        // 构建CDN路径
        $cdnPath = $this->buildCdnPath($path, $type);
        
        // 构建完整URL
        $fullUrl = $this->config['base_url'] . $cdnPath;
        
        // 添加版本号
        return $this->addVersionToUrl($fullUrl, $path);
    }
    
    /**
     * 检测资源类型
     * @param string $path 资源路径
     * @return string 资源类型
     */
    private function detectResourceType($path) {
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        
        switch ($extension) {
            case 'css':
                return 'css';
            case 'js':
                return 'js';
            case 'json':
                if (strpos($path, '/lang/') !== false || strpos($path, '/assets/lang/') !== false) {
                    return 'lang';
                }
                break;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'svg':
            case 'webp':
                return 'images';
        }
        
        return null;
    }
    
    /**
     * 构建CDN路径
     * @param string $path 相对路径
     * @param string $type 资源类型
     * @return string CDN路径
     */
    private function buildCdnPath($path, $type) {
        // 如果路径已经是完整URL，直接返回
        if (strpos($path, 'http://') === 0 || strpos($path, 'https://') === 0) {
            return $path;
        }
        
        // 处理相对路径
        if (strpos($path, '/') !== 0) {
            $path = '/' . $path;
        }
        
        // 根据资源类型调整路径
        if ($type && isset($this->config['resources'][$type])) {
            $resourceConfig = $this->config['resources'][$type];
            
            // 如果路径已经包含资源基础路径，转换为CDN路径
            if (strpos($path, $resourceConfig['base_path']) === 0) {
                $path = $resourceConfig['cdn_path'] . substr($path, strlen($resourceConfig['base_path']));
            }
        }
        
        return $path;
    }
    
    /**
     * 加载版本缓存
     */
    private function loadVersionCache() {
        if ($this->versionCache !== null) {
            return;
        }
        
        // 尝试从缓存获取版本信息
        $cacheKey = 'cdn:versions';
        $this->versionCache = $this->cacheManager->get($cacheKey);
        
        // 如果缓存未命中，尝试从文件加载
        if ($this->versionCache === false) {
            $versionFile = $this->config['versioning']['file_path'];
            if (file_exists($versionFile)) {
                $this->versionCache = json_decode(file_get_contents($versionFile), true);
            }
            
            // 如果文件不存在，初始化空数组
            if (!is_array($this->versionCache)) {
                $this->versionCache = array();
            }
            
            // 缓存版本信息 (24小时)
            $this->cacheManager->set($cacheKey, $this->versionCache, 86400);
        }
    }
    
    /**
     * 添加版本号到URL
     * @param string $url 原始URL
     * @param string $originalPath 原始路径（用于生成哈希）
     * @return string 添加了版本号的URL
     */
    private function addVersionToUrl($url, $originalPath = null) {
        if (!$this->config['versioning']['enabled']) {
            return $url;
        }
        
        // 如果URL已经包含查询参数，不重复添加
        if (strpos($url, '?') !== false) {
            return $url;
        }
        
        $version = $this->getVersionString($originalPath);
        return $url . '?v=' . $version;
    }
    
    /**
     * 获取版本字符串
     * @param string $path 资源路径
     * @return string 版本字符串
     */
    private function getVersionString($path = null) {
        $strategy = $this->config['versioning']['strategy'];
        
        switch ($strategy) {
            case 'fixed':
                return $this->config['versioning']['fixed_version'];
                
            case 'timestamp':
                // 获取资源类型对应的缓存时间间隔
                $type = $path ? $this->detectResourceType($path) : null;
                $cacheTime = 86400; // 默认24小时
                
                if ($type && isset($this->config['resources'][$type]['cache_time'])) {
                    $cacheTime = $this->config['resources'][$type]['cache_time'];
                }
                
                // 根据缓存时间间隔生成时间戳
                return floor(time() / $cacheTime);
                
            case 'hash':
            default:
                // 加载版本缓存
                $this->loadVersionCache();
                
                // 如果提供了路径，尝试获取或生成哈希
                if ($path) {
                    // 构建实际文件路径
                    $filePath = $_SERVER['DOCUMENT_ROOT'] . $path;
                    
                    // 如果文件存在且在缓存中，返回缓存的哈希
                    if (file_exists($filePath) && isset($this->versionCache[$path])) {
                        $cacheEntry = $this->versionCache[$path];
                        $fileMtime = filemtime($filePath);
                        
                        // 检查文件是否修改
                        if ($cacheEntry['mtime'] === $fileMtime) {
                            return $cacheEntry['hash'];
                        }
                    }
                    
                    // 生成新的哈希
                    $fileContent = file_get_contents($filePath);
                    $hash = substr(md5($fileContent), 0, 8);
                    
                    // 更新缓存
                    $this->versionCache[$path] = array(
                        'hash' => $hash,
                        'mtime' => filemtime($filePath)
                    );
                    
                    // 保存到文件
                    $this->saveVersionCache();
                    
                    return $hash;
                }
                
                // 如果没有提供路径，使用应用版本
                return defined('APP_VERSION') ? APP_VERSION : '1.0.0';
        }
    }
    
    /**
     * 保存版本缓存
     */
    private function saveVersionCache() {
        if (!is_array($this->versionCache)) {
            return;
        }
        
        // 保存到文件
        $versionFile = $this->config['versioning']['file_path'];
        $dir = dirname($versionFile);
        
        // 确保目录存在
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        file_put_contents($versionFile, json_encode($this->versionCache));
        
        // 更新内存缓存
        $this->cacheManager->set('cdn:versions', $this->versionCache, 86400);
    }
    
    /**
     * 清除CDN缓存
     * @param string $path 特定资源路径，如果为null则清除所有
     * @return bool 是否成功
     */
    public function clearCache($path = null) {
        try {
            // 清除内存缓存
            if ($path) {
                if (isset($this->versionCache[$path])) {
                    unset($this->versionCache[$path]);
                    $this->saveVersionCache();
                }
            } else {
                $this->versionCache = array();
                $this->saveVersionCache();
            }
            
            // 清除缓存管理器中的版本缓存
            $this->cacheManager->delete('cdn:versions');
            
            return true;
        } catch (Exception $e) {
            $this->logger->error('Failed to clear CDN cache', array(
                'path' => $path,
                'error' => $e->getMessage()
            ));
            return false;
        }
    }
    
    /**
     * 获取预加载资源列表
     * @return array 预加载资源数组
     */
    public function getPreloadResources() {
        if (!$this->config['preload']['enabled']) {
            return array();
        }
        
        $preload = array();
        $resources = $this->config['preload']['resources'];
        
        // 处理关键CSS
        if (!empty($resources['critical_css'])) {
            foreach ($resources['critical_css'] as $path) {
                $preload[] = array(
                    'url' => $this->getResourceUrl($path, 'css'),
                    'type' => 'style',
                    'as' => 'style'
                );
            }
        }
        
        // 处理关键JS
        if (!empty($resources['critical_js'])) {
            foreach ($resources['critical_js'] as $path) {
                $preload[] = array(
                    'url' => $this->getResourceUrl($path, 'js'),
                    'type' => 'script',
                    'as' => 'script'
                );
            }
        }
        
        return $preload;
    }
    
    /**
     * 生成预加载HTML标签
     * @return string HTML标签字符串
     */
    public function generatePreloadTags() {
        $resources = $this->getPreloadResources();
        $tags = array();
        
        foreach ($resources as $resource) {
            $tag = sprintf('<link rel="preload" href="%s" as="%s"', 
                htmlspecialchars($resource['url']), 
                htmlspecialchars($resource['as'])
            );
            
            if (isset($resource['type'])) {
                $tag .= ' type="' . htmlspecialchars($resource['type']) . '"';
            }
            
            $tag .= '>';
            $tags[] = $tag;
        }
        
        return implode(PHP_EOL, $tags);
    }
    
    /**
     * 获取单例实例
     * @return CDNManager
     */
    public static function getInstance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}