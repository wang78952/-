<?php
/**
 * 审计日志记录器
 * 负责详细记录系统中的敏感操作，支持完整的日志查询和回溯功能
 */

class AuditLogger {
    private $database;
    private $securityManager;
    private $config;
    
    /**
     * 构造函数
     * @param Database $database 数据库实例
     * @param SecurityManager $securityManager 安全管理器实例
     */
    public function __construct($database, $securityManager = null) {
        $this->database = $database;
        $this->securityManager = $securityManager;
        $this->config = $this->loadConfig();
    }
    
    /**
     * 加载审计日志配置
     */
    private function loadConfig() {
        return array(
            'log_levels' => array('debug', 'info', 'warning', 'error', 'critical'),
            'max_retention_days' => 90,
            'sensitive_operations' => array(
                'user_management' => array('create_user', 'update_user', 'delete_user', 'change_user_role'),
                'payment_management' => array('process_payment', 'refund_payment', 'update_payment_status'),
                'card_management' => array('create_card', 'update_card', 'delete_card', 'change_card_status'),
                'system_config' => array('update_config', 'change_security_settings', 'manage_permissions')
            ),
            'require_approval' => array(
                'delete_user', 'change_user_role', 'refund_payment', 'change_security_settings'
            )
        );
    }
    
    /**
     * 记录审计日志
     * @param int $userId 用户ID
     * @param string $action 操作动作
     * @param string $resource 操作资源
     * @param array $details 操作详情
     * @param string $level 日志级别
     * @return int 日志记录ID
     */
    public function log($userId, $action, $resource, $details = array(), $level = 'info') {
        // 获取用户名
        $username = $this->getUsernameById($userId);
        
        // 准备日志数据
        $logData = array(
            'user_id' => $userId,
            'username' => $username,
            'action' => $action,
            'resource' => $resource,
            'resource_id' => isset($details['resource_id']) ? $details['resource_id'] : null,
            'details' => json_encode($details),
            'ip_address' => $this->getClientIP(),
            'user_agent' => $this->getUserAgent(),
            'session_id' => $this->getSessionId(),
            'created_at' => date('Y-m-d H:i:s')
        );
        
        // 插入审计日志
        $logId = $this->database->insert('audit_logs', $logData);
        
        // 检查是否需要记录为敏感操作
        if ($this->isSensitiveOperation($action)) {
            $this->logSensitiveOperation($userId, $action, $resource, $details);
        }
        
        return $logId;
    }
    
    /**
     * 记录敏感操作
     * @param int $userId 用户ID
     * @param string $operationType 操作类型
     * @param string $resource 操作资源
     * @param array $details 操作详情
     */
    public function logSensitiveOperation($userId, $operationType, $resource, $details = array()) {
        // 获取用户名
        $username = $this->getUsernameById($userId);
        
        // 确定风险等级
        $riskLevel = $this->determineRiskLevel($operationType, $details);
        
        // 检查是否需要审批
        $approvalRequired = $this->requiresApproval($operationType);
        
        // 准备敏感操作数据
        $operationData = array(
            'user_id' => $userId,
            'username' => $username,
            'operation_type' => $operationType,
            'operation_name' => $resource,
            'target_data' => isset($details['target_data']) ? json_encode($details['target_data']) : null,
            'old_values' => isset($details['old_values']) ? json_encode($details['old_values']) : null,
            'new_values' => isset($details['new_values']) ? json_encode($details['new_values']) : null,
            'ip_address' => $this->getClientIP(),
            'user_agent' => $this->getUserAgent(),
            'risk_level' => $riskLevel,
            'approval_required' => $approvalRequired ? 1 : 0
        );
        
        // 插入敏感操作日志
        return $this->database->insert('sensitive_operations', $operationData);
    }
    
    /**
     * 审批敏感操作
     * @param int $operationId 操作ID
     * @param int $approverId 审批人ID
     * @param bool $approved 是否批准
     * @param string $notes 审批说明
     */
    public function approveSensitiveOperation($operationId, $approverId, $approved, $notes = '') {
        // 检查操作是否存在
        $operation = $this->database->fetch(
            "SELECT id FROM sensitive_operations WHERE id = ? AND approval_required = 1 AND approved_at IS NULL",
            array($operationId)
        );
        
        if (!$operation) {
            throw new Exception("Invalid operation or already approved");
        }
        
        // 更新审批状态
        return $this->database->update('sensitive_operations', array(
            'approved_by' => $approverId,
            'approved_at' => date('Y-m-d H:i:s'),
            'approval_notes' => $approved ? $notes : "Rejected: " . $notes
        ), array('id' => $operationId));
    }
    
    /**
     * 记录安全事件
     * @param string $eventType 事件类型
     * @param string $severity 严重程度
     * @param string $title 事件标题
     * @param array $details 事件详情
     */
    public function logSecurityEvent($eventType, $severity, $title, $details = array()) {
        $eventData = array(
            'event_type' => $eventType,
            'severity' => $severity,
            'title' => $title,
            'description' => isset($details['description']) ? $details['description'] : '',
            'source_ip' => $this->getClientIP(),
            'target_user' => isset($details['target_user']) ? $details['target_user'] : null,
            'target_resource' => isset($details['target_resource']) ? $details['target_resource'] : null,
            'details' => json_encode($details),
            'status' => 'open'
        );
        
        return $this->database->insert('security_events', $eventData);
    }
    
    /**
     * 更新安全事件状态
     * @param int $eventId 事件ID
     * @param string $status 状态
     * @param array $updateData 更新数据
     */
    public function updateSecurityEvent($eventId, $status, $updateData = array()) {
        $data = array('status' => $status);
        
        if ($status == 'resolved' || $status == 'investigating') {
            $data['assigned_to'] = isset($updateData['assigned_to']) ? $updateData['assigned_to'] : null;
        }
        
        if ($status == 'resolved') {
            $data['resolved_by'] = isset($updateData['resolved_by']) ? $updateData['resolved_by'] : null;
            $data['resolved_at'] = date('Y-m-d H:i:s');
            $data['resolution_notes'] = isset($updateData['resolution_notes']) ? $updateData['resolution_notes'] : '';
        }
        
        return $this->database->update('security_events', $data, array('id' => $eventId));
    }
    
    /**
     * 查询审计日志
     * @param array $filters 过滤条件
     * @param array $pagination 分页参数
     * @return array 日志列表
     */
    public function queryAuditLogs($filters = array(), $pagination = array()) {
        $query = "SELECT * FROM audit_logs WHERE 1=1";
        $params = array();
        
        // 应用过滤条件
        if (isset($filters['user_id'])) {
            $query .= " AND user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (isset($filters['action'])) {
            $query .= " AND action = ?";
            $params[] = $filters['action'];
        }
        
        if (isset($filters['resource'])) {
            $query .= " AND resource LIKE ?";
            $params[] = "%" . $filters['resource'] . "%";
        }
        
        if (isset($filters['start_date'])) {
            $query .= " AND created_at >= ?";
            $params[] = $filters['start_date'] . " 00:00:00";
        }
        
        if (isset($filters['end_date'])) {
            $query .= " AND created_at <= ?";
            $params[] = $filters['end_date'] . " 23:59:59";
        }
        
        // 添加排序
        $query .= " ORDER BY created_at DESC";
        
        // 应用分页
        if (isset($pagination['limit']) && isset($pagination['offset'])) {
            $query .= " LIMIT ? OFFSET ?";
            $params[] = $pagination['limit'];
            $params[] = $pagination['offset'];
        }
        
        // 获取结果
        $logs = $this->database->fetchAll($query, $params);
        
        // 解析JSON详情
        foreach ($logs as &$log) {
            if ($log['details']) {
                $log['details'] = json_decode($log['details'], true);
            }
        }
        
        return $logs;
    }
    
    /**
     * 查询敏感操作日志
     * @param array $filters 过滤条件
     * @param array $pagination 分页参数
     * @return array 敏感操作列表
     */
    public function querySensitiveOperations($filters = array(), $pagination = array()) {
        $query = "SELECT * FROM sensitive_operations WHERE 1=1";
        $params = array();
        
        // 应用过滤条件
        if (isset($filters['user_id'])) {
            $query .= " AND user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (isset($filters['operation_type'])) {
            $query .= " AND operation_type = ?";
            $params[] = $filters['operation_type'];
        }
        
        if (isset($filters['risk_level'])) {
            $query .= " AND risk_level = ?";
            $params[] = $filters['risk_level'];
        }
        
        if (isset($filters['approval_required'])) {
            $query .= " AND approval_required = ?";
            $params[] = $filters['approval_required'] ? 1 : 0;
        }
        
        if (isset($filters['start_date'])) {
            $query .= " AND created_at >= ?";
            $params[] = $filters['start_date'] . " 00:00:00";
        }
        
        if (isset($filters['end_date'])) {
            $query .= " AND created_at <= ?";
            $params[] = $filters['end_date'] . " 23:59:59";
        }
        
        // 添加排序
        $query .= " ORDER BY created_at DESC";
        
        // 应用分页
        if (isset($pagination['limit']) && isset($pagination['offset'])) {
            $query .= " LIMIT ? OFFSET ?";
            $params[] = $pagination['limit'];
            $params[] = $pagination['offset'];
        }
        
        // 获取结果
        $operations = $this->database->fetchAll($query, $params);
        
        // 解析JSON字段
        foreach ($operations as &$operation) {
            if ($operation['target_data']) {
                $operation['target_data'] = json_decode($operation['target_data'], true);
            }
            if ($operation['old_values']) {
                $operation['old_values'] = json_decode($operation['old_values'], true);
            }
            if ($operation['new_values']) {
                $operation['new_values'] = json_decode($operation['new_values'], true);
            }
        }
        
        return $operations;
    }
    
    /**
     * 查询安全事件
     * @param array $filters 过滤条件
     * @param array $pagination 分页参数
     * @return array 安全事件列表
     */
    public function querySecurityEvents($filters = array(), $pagination = array()) {
        $query = "SELECT * FROM security_events WHERE 1=1";
        $params = array();
        
        // 应用过滤条件
        if (isset($filters['event_type'])) {
            $query .= " AND event_type = ?";
            $params[] = $filters['event_type'];
        }
        
        if (isset($filters['severity'])) {
            $query .= " AND severity = ?";
            $params[] = $filters['severity'];
        }
        
        if (isset($filters['status'])) {
            $query .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        if (isset($filters['source_ip'])) {
            $query .= " AND source_ip = ?";
            $params[] = $filters['source_ip'];
        }
        
        if (isset($filters['target_user'])) {
            $query .= " AND target_user LIKE ?";
            $params[] = "%" . $filters['target_user'] . "%";
        }
        
        if (isset($filters['start_date'])) {
            $query .= " AND created_at >= ?";
            $params[] = $filters['start_date'] . " 00:00:00";
        }
        
        if (isset($filters['end_date'])) {
            $query .= " AND created_at <= ?";
            $params[] = $filters['end_date'] . " 23:59:59";
        }
        
        // 添加排序
        $query .= " ORDER BY ";
        $query .= isset($filters['sort_by']) ? $filters['sort_by'] : "created_at DESC";
        
        // 应用分页
        if (isset($pagination['limit']) && isset($pagination['offset'])) {
            $query .= " LIMIT ? OFFSET ?";
            $params[] = $pagination['limit'];
            $params[] = $pagination['offset'];
        }
        
        // 获取结果
        $events = $this->database->fetchAll($query, $params);
        
        // 解析JSON详情
        foreach ($events as &$event) {
            if ($event['details']) {
                $event['details'] = json_decode($event['details'], true);
            }
        }
        
        return $events;
    }
    
    /**
     * 获取用户审计摘要
     * @param int $userId 用户ID
     * @param int $days 统计天数
     * @return array 用户审计摘要
     */
    public function getUserAuditSummary($userId, $days = 30) {
        $startDate = date('Y-m-d', strtotime("-$days days"));
        
        // 获取用户操作统计
        $actionStats = $this->database->fetchAll(
            "SELECT action, COUNT(*) as count 
             FROM audit_logs 
             WHERE user_id = ? AND created_at >= ? 
             GROUP BY action 
             ORDER BY count DESC",
            array($userId, $startDate . " 00:00:00")
        );
        
        // 获取敏感操作数量
        $sensitiveOpsCount = $this->database->fetch(
            "SELECT COUNT(*) as count 
             FROM sensitive_operations 
             WHERE user_id = ? AND created_at >= ?",
            array($userId, $startDate . " 00:00:00")
        );
        
        // 获取最近的操作
        $recentActions = $this->database->fetchAll(
            "SELECT * FROM audit_logs 
             WHERE user_id = ? 
             ORDER BY created_at DESC 
             LIMIT 10",
            array($userId)
        );
        
        return array(
            'user_id' => $userId,
            'username' => $this->getUsernameById($userId),
            'period_days' => $days,
            'action_statistics' => $actionStats,
            'sensitive_operations_count' => $sensitiveOpsCount['count'],
            'recent_actions' => $recentActions
        );
    }
    
    /**
     * 清理过期的审计日志
     * @param int $days 保留天数
     */
    public function cleanupOldLogs($days = null) {
        $days = $days ?: $this->config['max_retention_days'];
        $cutoffDate = date('Y-m-d H:i:s', strtotime("-$days days"));
        
        // 清理审计日志
        $this->database->execute(
            "DELETE FROM audit_logs WHERE created_at < ?",
            array($cutoffDate)
        );
        
        // 清理不再需要的敏感操作日志
        $this->database->execute(
            "DELETE FROM sensitive_operations WHERE created_at < ? AND approved_at IS NOT NULL",
            array($cutoffDate)
        );
        
        return true;
    }
    
    /**
     * 判断是否为敏感操作
     */
    private function isSensitiveOperation($action) {
        foreach ($this->config['sensitive_operations'] as $category) {
            if (in_array($action, $category)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 判断操作是否需要审批
     */
    private function requiresApproval($operationType) {
        return in_array($operationType, $this->config['require_approval']);
    }
    
    /**
     * 确定风险等级
     */
    private function determineRiskLevel($operationType, $details) {
        // 基于操作类型和详情确定风险等级
        $riskLevels = array(
            'delete_user' => 'critical',
            'change_user_role' => 'high',
            'refund_payment' => 'high',
            'change_security_settings' => 'critical',
            'update_config' => 'medium',
            'create_user' => 'medium',
            'update_user' => 'medium'
        );
        
        return isset($riskLevels[$operationType]) ? $riskLevels[$operationType] : 'low';
    }
    
    /**
     * 根据用户ID获取用户名
     */
    private function getUsernameById($userId) {
        if ($userId) {
            $user = $this->database->fetch(
                "SELECT username FROM users WHERE id = ?",
                array($userId)
            );
            return $user ? $user['username'] : "unknown";
        }
        return "system";
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIP() {
        if ($this->securityManager) {
            return $this->securityManager->getClientIP();
        }
        
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    /**
     * 获取用户代理
     */
    private function getUserAgent() {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    }
    
    /**
     * 获取会话ID
     */
    private function getSessionId() {
        return isset($_SESSION['PHPSESSID']) ? $_SESSION['PHPSESSID'] : '';
    }
    
    /**
     * 获取审计统计数据
     * @param int $days 统计天数
     * @return array 统计数据
     */
    public function getAuditStatistics($days = 30) {
        $startDate = date('Y-m-d', strtotime("-$days days"));
        
        // 审计日志统计
        $auditLogsCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM audit_logs WHERE created_at >= ?",
            array($startDate . " 00:00:00")
        );
        
        // 敏感操作统计
        $sensitiveOpsCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM sensitive_operations WHERE created_at >= ?",
            array($startDate . " 00:00:00")
        );
        
        // 安全事件统计
        $securityEventsCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM security_events WHERE created_at >= ?",
            array($startDate . " 00:00:00")
        );
        
        // 高风险操作统计
        $highRiskOpsCount = $this->database->fetch(
            "SELECT COUNT(*) as count FROM sensitive_operations 
             WHERE created_at >= ? AND risk_level IN ('high', 'critical')",
            array($startDate . " 00:00:00")
        );
        
        return array(
            'period_days' => $days,
            'total_audit_logs' => $auditLogsCount['count'],
            'total_sensitive_operations' => $sensitiveOpsCount['count'],
            'total_security_events' => $securityEventsCount['count'],
            'high_risk_operations' => $highRiskOpsCount['count']
        );
    }
}