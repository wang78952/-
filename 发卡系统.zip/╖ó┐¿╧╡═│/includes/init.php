<?php
/**
 * 系统初始化文件
 * 统一加载所有必要的配置和类文件
 */

// 定义基本路径常量
define('ROOT_PATH', dirname(dirname(__FILE__)));
define('CORE_PATH', ROOT_PATH . '/includes/core');
define('SERVICES_PATH', ROOT_PATH . '/includes/services');
define('CONFIG_PATH', ROOT_PATH . '/config');

// 错误报告设置
error_reporting(E_ALL);
ini_set('display_errors', DEBUG_MODE ? 1 : 0);
ini_set('log_errors', 1);
ini_set('error_log', LOG_PATH . '/php_errors.log');

// 时区设置
date_default_timezone_set('Asia/Shanghai');

// 字符编码设置
mb_internal_encoding('UTF-8');

// 会话设置
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 加载配置文件管理器
function loadConfig($filename) {
    $configPath = CONFIG_PATH . '/' . $filename . '.php';
    if (file_exists($configPath)) {
        return require_once $configPath;
    }
    return null;
}

// 加载核心配置文件
require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/monitoring.php';

// 核心类文件加载
require_once __DIR__ . '/core/BaseService.php';
require_once __DIR__ . '/ErrorLevel.php';
require_once __DIR__ . '/SecurityConfig.php';
require_once __DIR__ . '/ErrorHandler.php';
require_once __DIR__ . '/GlobalExceptionHandler.php';
require_once __DIR__ . '/core/Logger.php';
require_once __DIR__ . '/core/SecurityUtils.php';
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/PerformanceMonitor.php';
require_once __DIR__ . '/DatabaseOptimizer.php';
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/core/ConfigManager.php';
require_once __DIR__ . '/services/auth/AuthService.php';
require_once __DIR__ . '/core/CacheManager.php';

// 加载服务类文件
require_once __DIR__ . '/NotificationManager.php';
require_once __DIR__ . '/ImportManager.php';
require_once __DIR__ . '/ExportManager.php';
require_once __DIR__ . '/services/card/InventoryService.php';
require_once __DIR__ . '/LogManager.php';
require_once __DIR__ . '/SystemManager.php';
require_once __DIR__ . '/TemplateManager.php';
require_once __DIR__ . '/UpdateManager.php';
require_once __DIR__ . '/CDNManager.php';

// 初始化错误处理器
$errorHandler = ErrorHandler::getInstance();

// 初始化日志器
$logger = Logger::getInstance();

// 初始化数据库连接
try {
    $database = Database::getInstance();
} catch (Exception $e) {
    $errorHandler->handleException($e);
    die('数据库连接失败');
}

// 初始化缓存管理器
try {
    $cacheManager = CacheManager::getInstance();
} catch (Exception $e) {
    $logger->warning('缓存初始化失败', array('error' => $e->getMessage()));
}

// 初始化认证服务
try {
    $authService = AuthService::getInstance();
} catch (Exception $e) {
    $logger->error('认证服务初始化失败', array('error' => $e->getMessage()));
}

// 设置安全头部
if (!headers_sent()) {
    $securityHeaders = array(
        'X-Content-Type-Options: nosniff',
        'X-Frame-Options: DENY',
        'X-XSS-Protection: 1; mode=block',
        'Strict-Transport-Security: max-age=31536000; includeSubDomains',
        'Content-Security-Policy: default-src \'self\'',
        'Referrer-Policy: strict-origin-when-cross-origin'
    );
    
    foreach ($securityHeaders as $header) {
        header($header);
    }
}

// 初始化CDN管理器
try {
    $cdnManager = CDNManager::getInstance();
} catch (Exception $e) {
    $logger->warning('CDN管理器初始化失败', array('error' => $e->getMessage()));
}

// 记录系统启动日志
$logger->info('系统初始化完成', array(
    'timestamp' => date('Y-m-d H:i:s'),
    'memory_usage' => memory_get_usage(true),
    'peak_memory' => memory_get_peak_usage(true),
    'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'CLI',
    'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'CLI'
));

// 注册关闭函数
// 使用命名函数替代匿名函数，确保PHP 5.3兼容
function handleShutdown() {
    global $logger;
    
    $error = error_get_last();
    if ($error && in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR))) {
        $logger->critical('脚本致命错误', array(
            'type' => $error['type'],
            'message' => $error['message'],
            'file' => $error['file'],
            'line' => $error['line']
        ));
    }
    
    $logger->info('脚本执行完成', array(
        'execution_time' => microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'],
        'memory_usage' => memory_get_usage(true),
        'peak_memory' => memory_get_peak_usage(true)
    ));
}

register_shutdown_function('handleShutdown');


/**
 * 获取系统实例
 */
function getSystemInstance($service) {
    static $instances = array();
    
    if (!isset($instances[$service])) {
        switch ($service) {
            case 'database':
                $instances[$service] = Database::getInstance();
                break;
            case 'cache':
                $instances[$service] = CacheManager::getInstance();
                break;
            case 'auth':
                $instances[$service] = AuthManager::getInstance();
                break;
            case 'logger':
                $instances[$service] = Logger::getInstance();
                break;
            case 'errorHandler':
                $instances[$service] = ErrorHandler::getInstance();
                break;
            default:
                throw new Exception("未知的服务: {$service}");
        }
    }
    
    return $instances[$service];
}

/**
 * 快速日志记录函数
 */
function log_message($level, $message, $context = array()) {
    $logger = getSystemInstance('logger');
    $logger->log($level, $message, $context);
}

/**
 * 快速缓存操作函数
 */
function cache_get($key, $default = null) {
    try {
        $cache = getSystemInstance('cache');
        return $cache->get($key, $default);
    } catch (Exception $e) {
        log_message(ErrorLevel::WARNING, '缓存读取失败', array('key' => $key, 'error' => $e->getMessage()));
        return $default;
    }
}

function cache_set($key, $value, $ttl = null) {
    try {
        $cache = getSystemInstance('cache');
        return $cache->set($key, $value, $ttl);
    } catch (Exception $e) {
        log_message(ErrorLevel::WARNING, '缓存写入失败', array('key' => $key, 'error' => $e->getMessage()));
        return false;
    }
}

function cache_delete($key) {
    try {
        $cache = getSystemInstance('cache');
        return $cache->delete($key);
    } catch (Exception $e) {
        log_message(ErrorLevel::WARNING, '缓存删除失败', array('key' => $key, 'error' => $e->getMessage()));
        return false;
    }
}

/**
 * 数据库快捷操作函数
 */
function db_query($sql, $params = array()) {
    try {
        $database = getSystemInstance('database');
        return $database->query($sql, $params);
    } catch (Exception $e) {
        log_message(ErrorLevel::ERROR, '数据库查询失败', array('sql' => $sql, 'params' => $params, 'error' => $e->getMessage()));
        throw $e;
    }
}

function db_fetch($sql, $params = array()) {
    try {
        $database = getSystemInstance('database');
        return $database->fetch($sql, $params);
    } catch (Exception $e) {
        log_message(ErrorLevel::ERROR, '数据库获取失败', array('sql' => $sql, 'params' => $params, 'error' => $e->getMessage()));
        throw $e;
    }
}

function db_fetch_all($sql, $params = array()) {
    try {
        $database = getSystemInstance('database');
        return $database->fetchAll($sql, $params);
    } catch (Exception $e) {
        log_message(ErrorLevel::ERROR, '数据库获取全部失败', array('sql' => $sql, 'params' => $params, 'error' => $e->getMessage()));
        throw $e;
    }
}

function db_insert($table, $data = array()) {
    try {
        $database = getSystemInstance('database');
        return $database->insert($table, $data);
    } catch (Exception $e) {
        log_message(ErrorLevel::ERROR, '数据库插入失败', array('table' => $table, 'data' => $data, 'error' => $e->getMessage()));
        throw $e;
    }
}

function db_update($table, $data, $where) {
    try {
        $database = getSystemInstance('database');
        return $database->update($table, $data, $where);
    } catch (Exception $e) {
        log_message(ErrorLevel::ERROR, '数据库更新失败', array('table' => $table, 'data' => $data, 'where' => $where, 'error' => $e->getMessage()));
        throw $e;
    }
}

function db_delete($table, $where, $params = array()) {
    try {
        $database = getSystemInstance('database');
        return $database->delete($table, $where, $params);
    } catch (Exception $e) {
        log_message(ErrorLevel::ERROR, '数据库删除失败', array('table' => $table, 'where' => $where, 'error' => $e->getMessage()));
        throw $e;
    }
}
?>