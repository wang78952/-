<?php

/**
 * 数据库读写分离管理器
 * 负责管理主从数据库连接，实现负载均衡和故障转移
 */
require_once __DIR__ . '/../Logger.php';

class DatabaseReplicaManager {
    // 数据库连接实例
    private static $masterConnection;
    private static $slaveConnections = [];
    private static $connectionPool = [];
    
    // 配置信息
    private static $config;
    
    // Logger实例
    private static $logger;
    
    // 负载均衡算法
    const LB_ROUND_ROBIN = 'round_robin';
    const LB_RANDOM = 'random';
    const LB_WEIGHTED = 'weighted';
    const LB_LEAST_CONNECTIONS = 'least_connections';
    
    // 当前轮询索引
    private static $currentSlaveIndex = 0;
    
    // 连接状态监控
    private static $connectionStatus = [];
    private static $lastHealthCheck = 0;
    private static $healthCheckInterval = 30; // 30秒检查一次
    
    /**
     * 初始化数据库连接管理
     */
    public static function init() {
        self::loadConfig();
        // 初始化logger实例
        self::$logger = new Logger();
        self::connectMaster();
        self::connectSlaves();
    }
    
    /**
     * 加载数据库配置
     */
    private static function loadConfig() {
        // 默认配置
        self::$config = [
            'master' => [
                'host' => 'localhost',
                'port' => 3306,
                'user' => 'root',
                'password' => '',
                'database' => 'card_system',
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'timeout' => 10,
                'options' => [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_PERSISTENT => true
                ]
            ],
            'slaves' => [
                [
                    'host' => 'localhost',
                    'port' => 3307,
                    'user' => 'root',
                    'password' => '',
                    'database' => 'card_system',
                    'charset' => 'utf8mb4',
                    'weight' => 1,
                    'timeout' => 5,
                    'options' => [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_PERSISTENT => true
                    ]
                ]
            ],
            'load_balancing' => self::LB_ROUND_ROBIN,
            'failover' => true,
            'connection_pool_size' => 10,
            'health_check_interval' => 30
        ];
        
        // 从配置文件加载自定义配置
        if (file_exists(ROOT_PATH . '/config/database_replica_config.php')) {
            include ROOT_PATH . '/config/database_replica_config.php';
            if (isset($replicaConfig) && is_array($replicaConfig)) {
                self::mergeConfig(self::$config, $replicaConfig);
            }
        }
        
        // 设置健康检查间隔
        self::$healthCheckInterval = self::$config['health_check_interval'] ?? 30;
    }
    
    /**
     * 合并配置
     */
    private static function mergeConfig(&$default, $custom) {
        foreach ($custom as $key => $value) {
            if (is_array($value) && isset($default[$key]) && is_array($default[$key])) {
                self::mergeConfig($default[$key], $value);
            } else {
                $default[$key] = $value;
            }
        }
    }
    
    /**
     * 连接主数据库
     */
    private static function connectMaster() {
        try {
            $config = self::$config['master'];
            $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset={$config['charset']}";
            
            self::$masterConnection = new PDO($dsn, $config['user'], $config['password'], $config['options']);
            self::$masterConnection->exec("SET collation_connection = '{$config['collation']}'");
            self::$masterConnection->exec("SET NAMES '{$config['charset']}'");
            
            self::$connectionStatus['master'] = [
                'status' => 'connected',
                'last_error' => null,
                'last_connected' => time()
            ];
            
            self::$logger->info('主数据库连接成功: ' . $config['host'] . ':' . $config['port']);
        } catch (PDOException $e) {
            self::$connectionStatus['master'] = [
                'status' => 'error',
                'last_error' => $e->getMessage(),
                'last_connected' => 0
            ];
            self::$logger->error('主数据库连接失败: ' . $e->getMessage());
            throw new Exception('无法连接到主数据库');
        }
    }
    
    /**
     * 连接从数据库
     */
    private static function connectSlaves() {
        $slaves = self::$config['slaves'] ?? [];
        
        foreach ($slaves as $index => $slaveConfig) {
            try {
                $dsn = "mysql:host={$slaveConfig['host']};port={$slaveConfig['port']};dbname={$slaveConfig['database']};charset={$slaveConfig['charset']}";
                $connection = new PDO($dsn, $slaveConfig['user'], $slaveConfig['password'], $slaveConfig['options']);
                $connection->exec("SET collation_connection = '{$slaveConfig['collation']}'");
                $connection->exec("SET NAMES '{$slaveConfig['charset']}'");
                
                self::$slaveConnections[$index] = $connection;
                self::$connectionStatus['slave_' . $index] = [
                    'status' => 'connected',
                    'last_error' => null,
                    'last_connected' => time(),
                    'weight' => $slaveConfig['weight'] ?? 1,
                    'connections' => 0
                ];
                
                self::$logger->info('从数据库连接成功: ' . $slaveConfig['host'] . ':' . $slaveConfig['port']);
            } catch (PDOException $e) {
                self::$connectionStatus['slave_' . $index] = [
                    'status' => 'error',
                    'last_error' => $e->getMessage(),
                    'last_connected' => 0,
                    'weight' => 0
                ];
                self::$logger->error('从数据库连接失败 [' . $slaveConfig['host'] . ':' . $slaveConfig['port'] . ']: ' . $e->getMessage());
            }
        }
    }
    
    /**
     * 获取主数据库连接
     */
    public static function getMasterConnection() {
        // 检查连接是否有效
        if (!self::isConnectionValid(self::$masterConnection)) {
            self::reconnectMaster();
        }
        
        return self::$masterConnection;
    }
    
    /**
     * 获取从数据库连接
     */
    public static function getSlaveConnection() {
        // 执行健康检查
        self::performHealthCheck();
        
        // 获取可用的从库
        $availableSlaves = self::getAvailableSlaves();
        
        // 如果没有可用的从库，返回主库连接（降级处理）
        if (empty($availableSlaves)) {
            self::$logger->warning('没有可用的从数据库，使用主数据库进行读取操作');
            return self::getMasterConnection();
        }
        
        // 根据负载均衡算法选择从库
        $slaveIndex = self::selectSlaveByLoadBalancing($availableSlaves);
        $connection = self::$slaveConnections[$slaveIndex] ?? null;
        
        // 检查连接有效性
        if (!self::isConnectionValid($connection)) {
            self::reconnectSlave($slaveIndex);
            $connection = self::$slaveConnections[$slaveIndex] ?? null;
        }
        
        // 更新连接计数
        if (isset(self::$connectionStatus['slave_' . $slaveIndex])) {
            self::$connectionStatus['slave_' . $slaveIndex]['connections']++;
        }
        
        return $connection;
    }
    
    /**
     * 根据SQL类型自动选择合适的连接
     */
    public static function getConnection($sql) {
        $sql = trim(strtoupper($sql));
        
        // 写操作使用主库
        if (strpos($sql, 'INSERT') === 0 || 
            strpos($sql, 'UPDATE') === 0 || 
            strpos($sql, 'DELETE') === 0 || 
            strpos($sql, 'REPLACE') === 0 || 
            strpos($sql, 'CREATE') === 0 || 
            strpos($sql, 'ALTER') === 0 || 
            strpos($sql, 'DROP') === 0 || 
            strpos($sql, 'TRUNCATE') === 0) {
            return self::getMasterConnection();
        }
        
        // 读操作使用从库
        return self::getSlaveConnection();
    }
    
    /**
     * 获取可用的从库列表
     */
    private static function getAvailableSlaves() {
        $available = [];
        
        foreach (array_keys(self::$slaveConnections) as $index) {
            $statusKey = 'slave_' . $index;
            if (isset(self::$connectionStatus[$statusKey]) && 
                self::$connectionStatus[$statusKey]['status'] === 'connected') {
                $available[] = $index;
            }
        }
        
        return $available;
    }
    
    /**
     * 根据负载均衡算法选择从库
     */
    private static function selectSlaveByLoadBalancing(array $availableSlaves) {
        $lbMethod = self::$config['load_balancing'] ?? self::LB_ROUND_ROBIN;
        
        switch ($lbMethod) {
            case self::LB_ROUND_ROBIN:
                return self::selectRoundRobin($availableSlaves);
            case self::LB_RANDOM:
                return self::selectRandom($availableSlaves);
            case self::LB_WEIGHTED:
                return self::selectWeighted($availableSlaves);
            case self::LB_LEAST_CONNECTIONS:
                return self::selectLeastConnections($availableSlaves);
            default:
                return self::selectRoundRobin($availableSlaves);
        }
    }
    
    /**
     * 轮询选择
     */
    private static function selectRoundRobin(array $availableSlaves) {
        if (empty($availableSlaves)) return null;
        
        $index = self::$currentSlaveIndex % count($availableSlaves);
        self::$currentSlaveIndex++;
        
        return $availableSlaves[$index];
    }
    
    /**
     * 随机选择
     */
    private static function selectRandom(array $availableSlaves) {
        if (empty($availableSlaves)) return null;
        
        $index = array_rand($availableSlaves);
        return $availableSlaves[$index];
    }
    
    /**
     * 权重选择
     */
    private static function selectWeighted(array $availableSlaves) {
        if (empty($availableSlaves)) return null;
        
        $weightedPool = [];
        
        foreach ($availableSlaves as $slaveIndex) {
            $weight = self::$connectionStatus['slave_' . $slaveIndex]['weight'] ?? 1;
            for ($i = 0; $i < $weight; $i++) {
                $weightedPool[] = $slaveIndex;
            }
        }
        
        return $weightedPool[array_rand($weightedPool)];
    }
    
    /**
     * 最少连接数选择
     */
    private static function selectLeastConnections(array $availableSlaves) {
        if (empty($availableSlaves)) return null;
        
        $minConnections = PHP_INT_MAX;
        $selectedSlave = $availableSlaves[0];
        
        foreach ($availableSlaves as $slaveIndex) {
            $connections = self::$connectionStatus['slave_' . $slaveIndex]['connections'] ?? 0;
            if ($connections < $minConnections) {
                $minConnections = $connections;
                $selectedSlave = $slaveIndex;
            }
        }
        
        return $selectedSlave;
    }
    
    /**
     * 检查连接有效性
     */
    private static function isConnectionValid($connection) {
        if ($connection === null) return false;
        
        try {
            return $connection->ping();
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 重新连接主库
     */
    private static function reconnectMaster() {
        self::$logger->warning('主数据库连接已断开，正在重新连接...');
        try {
            self::connectMaster();
            self::$logger->info('主数据库重新连接成功');
        } catch (Exception $e) {
            self::$logger->error('主数据库重新连接失败: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 重新连接指定从库
     */
    private static function reconnectSlave($slaveIndex) {
        self::$logger->warning('从数据库连接已断开，正在重新连接...');
        try {
            $slaveConfig = self::$config['slaves'][$slaveIndex] ?? null;
            if ($slaveConfig) {
                $dsn = "mysql:host={$slaveConfig['host']};port={$slaveConfig['port']};dbname={$slaveConfig['database']};charset={$slaveConfig['charset']}";
                $connection = new PDO($dsn, $slaveConfig['user'], $slaveConfig['password'], $slaveConfig['options']);
                $connection->exec("SET collation_connection = '{$slaveConfig['collation']}'");
                $connection->exec("SET NAMES '{$slaveConfig['charset']}'");
                
                self::$slaveConnections[$slaveIndex] = $connection;
                self::$connectionStatus['slave_' . $slaveIndex] = [
                    'status' => 'connected',
                    'last_error' => null,
                    'last_connected' => time(),
                    'weight' => $slaveConfig['weight'] ?? 1,
                    'connections' => 0
                ];
                self::$logger->info('从数据库重新连接成功: ' . $slaveConfig['host'] . ':' . $slaveConfig['port']);
            }
        } catch (Exception $e) {
            self::$connectionStatus['slave_' . $slaveIndex]['status'] = 'error';
            self::$connectionStatus['slave_' . $slaveIndex]['last_error'] = $e->getMessage();
            self::$logger->error('从数据库重新连接失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 执行健康检查
     */
    private static function performHealthCheck() {
        $now = time();
        
        // 检查是否需要执行健康检查
        if ($now - self::$lastHealthCheck < self::$healthCheckInterval) {
            return;
        }
        
        self::$lastHealthCheck = $now;
        
        // 检查主库健康状态
        self::checkMasterHealth();
        
        // 检查从库健康状态
        self::checkSlavesHealth();
    }
    
    /**
     * 检查主库健康状态
     */
    private static function checkMasterHealth() {
        try {
            $connection = self::$masterConnection;
            if ($connection) {
                $stmt = $connection->prepare("SELECT 1");
                $stmt->execute();
                $result = $stmt->fetchColumn();
                
                if ($result === 1) {
                    self::$connectionStatus['master']['status'] = 'connected';
                }
            }
        } catch (Exception $e) {
                self::$connectionStatus['master']['status'] = 'error';
                self::$connectionStatus['master']['last_error'] = $e->getMessage();
                Logger::getInstance()->error('主数据库健康检查失败: ' . $e->getMessage());
                self::reconnectMaster();
            }
    }
    
    /**
     * 检查从库健康状态
     */
    private static function checkSlavesHealth() {
        foreach (array_keys(self::$slaveConnections) as $slaveIndex) {
            try {
                $connection = self::$slaveConnections[$slaveIndex];
                if ($connection) {
                    $stmt = $connection->prepare("SELECT 1");
                    $stmt->execute();
                    $result = $stmt->fetchColumn();
                    
                    if ($result === 1) {
                        self::$connectionStatus['slave_' . $slaveIndex]['status'] = 'connected';
                    }
                }
            } catch (Exception $e) {
                self::$connectionStatus['slave_' . $slaveIndex]['status'] = 'error';
                self::$connectionStatus['slave_' . $slaveIndex]['last_error'] = $e->getMessage();
                Logger::getInstance()->error('从数据库健康检查失败 [' . $slaveIndex . ']: ' . $e->getMessage());
                self::reconnectSlave($slaveIndex);
            }
        }
    }
    
    /**
     * 获取数据库状态信息
     */
    public static function getStatus() {
        $status = [
            'master' => self::$connectionStatus['master'] ?? [],
            'slaves' => [],
            'stats' => [
                'total_slaves' => count(self::$slaveConnections),
                'available_slaves' => count(self::getAvailableSlaves()),
                'load_balancing' => self::$config['load_balancing'],
                'last_health_check' => date('Y-m-d H:i:s', self::$lastHealthCheck)
            ]
        ];
        
        foreach (array_keys(self::$slaveConnections) as $slaveIndex) {
            $status['slaves'][] = [
                'index' => $slaveIndex,
                'config' => self::$config['slaves'][$slaveIndex] ?? [],
                'status' => self::$connectionStatus['slave_' . $slaveIndex] ?? []
            ];
        }
        
        return $status;
    }
    
    /**
     * 关闭所有数据库连接
     */
    public static function closeAllConnections() {
        // 关闭主库连接
        if (self::$masterConnection) {
            self::$masterConnection = null;
        }
        
        // 关闭所有从库连接
        self::$slaveConnections = [];
        self::$connectionPool = [];
        
        Logger::getInstance()->info('所有数据库连接已关闭');
    }
    
    /**
     * 刷新从库连接池
     */
    public static function refreshSlaveConnections() {
        self::closeAllConnections();
        self::connectMaster();
        self::connectSlaves();
        Logger::getInstance()->info('数据库连接池已刷新');
    }
    
    /**
     * 获取读查询统计信息
     */
    public static function getReadStats() {
        $stats = [];
        foreach (array_keys(self::$connectionStatus) as $connectionKey) {
            if (strpos($connectionKey, 'slave_') === 0) {
                $stats[$connectionKey] = [
                    'connections' => self::$connectionStatus[$connectionKey]['connections'] ?? 0,
                    'status' => self::$connectionStatus[$connectionKey]['status'] ?? 'unknown'
                ];
            }
        }
        return $stats;
    }
}

// 初始化数据库读写分离管理器
DatabaseReplicaManager::init();