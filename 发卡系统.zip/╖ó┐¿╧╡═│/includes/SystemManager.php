<?php
/**
 * 系统管理器
 * 处理系统配置、缓存清理、性能监控等系统管理功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/CacheManager.php';
require_once __DIR__ . '/LogManager.php';

class SystemManager extends BaseService {
    private $cacheManager;
    private $logManager;
    private $configDir;
    
    public function __construct($database = null, $logger = null) {
        parent::__construct();
        $this->cacheManager = CacheManager::getInstance();
        $this->logManager = new LogManager($database, $logger);
        $this->configDir = __DIR__ . '/../config/';
    }
    
    /**
     * 获取系统信息
     */
    public function getSystemInfo() {
        try {
            $systemInfo = array(
                'server' => array(
                    'os' => PHP_OS,
                    'php_version' => PHP_VERSION,
                    'web_server' => isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown',
                    'memory_limit' => ini_get('memory_limit'),
                    'max_execution_time' => ini_get('max_execution_time'),
                    'upload_max_filesize' => ini_get('upload_max_filesize'),
                    'post_max_size' => ini_get('post_max_size')
                ),
                'database' => array(
                    'version' => $this->getDatabaseVersion(),
                    'size' => $this->getDatabaseSize(),
                    'connection_status' => $this->testDatabaseConnection()
                ),
                'application' => array(
                    'version' => $this->getApplicationVersion(),
                    'environment' => $this->getEnvironment(),
                    'debug_mode' => $this->isDebugMode(),
                    'timezone' => date_default_timezone_get(),
                    'cache_status' => $this->getCacheStatus()
                ),
                'performance' => array(
                    'memory_usage' => memory_get_usage(true),
                    'memory_peak' => memory_get_peak_usage(true),
                    'uptime' => $this->getSystemUptime()
                )
            );
            
            return array('success' => true, 'system_info' => $systemInfo);
            
        } catch (Exception $e) {
                $this->logManager->logError("获取系统信息失败", array(
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ));
                return array('success' => false, 'message' => '获取系统信息失败');
            }
    }
    
    /**
     * 获取系统配置
     */
    public function getSystemConfig() {
        try {
            $config = array(
                'site' => $this->getConfig('site'),
                'email' => $this->getConfig('email'),
                'payment' => $this->getConfig('payment'),
                'security' => $this->getConfig('security'),
                'cache' => $this->getConfig('cache'),
                'notification' => $this->getConfig('notification')
            );
            
            return array('success' => true, 'config' => $config);
            
        } catch (Exception $e) {
            $this->logManager->logError("获取系统配置失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 更新系统配置
     */
    public function updateSystemConfig($section, $config) {
        try {
            $configFile = $this->configDir . $section . '.php';
            
            if (!file_exists($configFile)) {
                throw new Exception('配置文件不存在');
            }
            
            // 备份原配置
            $backupFile = $configFile . '.backup.' . date('Y-m-d-H-i-s');
            copy($configFile, $backupFile);
            
            // 写入新配置
            $content = "<?php\nreturn " . var_export($config, true) . ";\n";
            file_put_contents($configFile, $content);
            
            // 清除相关缓存
            $this->cacheManager->delete("config_{$section}");
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'update_config',
                $section,
                array('config' => $config)
            );
            
            return array('success' => true, 'message' => '配置更新成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("更新系统配置失败", array(
                'section' => $section,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 清理系统缓存
     */
    public function clearCache($type = 'all') {
        try {
            $cleared = array();
            
            switch ($type) {
                case 'all':
                    $cleared['application'] = $this->clearApplicationCache();
                    $cleared['database'] = $this->clearDatabaseCache();
                    $cleared['session'] = $this->clearSessionCache();
                    $cleared['template'] = $this->clearTemplateCache();
                    break;
                    
                case 'application':
                    $cleared['application'] = $this->clearApplicationCache();
                    break;
                    
                case 'database':
                    $cleared['database'] = $this->clearDatabaseCache();
                    break;
                    
                case 'session':
                    $cleared['session'] = $this->clearSessionCache();
                    break;
                    
                case 'template':
                    $cleared['template'] = $this->clearTemplateCache();
                    break;
                    
                default:
                    throw new Exception('不支持的缓存类型');
            }
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'clear_cache',
                $type,
                array('cleared' => $cleared)
            );
            
            return array('success' => true, 'cleared' => $cleared);
            
        } catch (Exception $e) {
            $this->logManager->logError("清理缓存失败", array(
                'type' => $type,
                'error' => $e->getMessage()
            ));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取系统性能监控数据
     */
    public function getPerformanceMetrics() {
        try {
            $metrics = array(
                'cpu' => $this->getCpuUsage(),
                'memory' => $this->getMemoryUsage(),
                'disk' => $this->getDiskUsage(),
                'network' => $this->getNetworkStats(),
                'database' => $this->getDatabaseStats(),
                'cache' => $this->getCacheStats(),
                'requests' => $this->getRequestStats()
            );
            
            return array('success' => true, 'metrics' => $metrics);
            
        } catch (Exception $e) {
            $this->logManager->logError("获取性能指标失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 系统健康检查
     */
    public function healthCheck() {
        try {
            $checks = array(
                'database' => $this->checkDatabase(),
                'cache' => $this->checkCache(),
                'filesystem' => $this->checkFilesystem(),
                'permissions' => $this->checkPermissions(),
                'php_extensions' => $this->checkPhpExtensions(),
                'security' => $this->checkSecurity()
            );
            
            $overall = array(
                'status' => 'healthy',
                'issues' => array(),
                'warnings' => array()
            );
            
            foreach ($checks as $component => $result) {
                if ($result['status'] === 'error') {
                    $overall['status'] = 'critical';
                    array_push($overall['issues'], "{$component}: {$result['message']}");
                } elseif ($result['status'] === 'warning') {
                    if ($overall['status'] === 'healthy') {
                        $overall['status'] = 'warning';
                    }
                    array_push($overall['warnings'], "{$component}: {$result['message']}");
                }
            }
            
            $this->logManager->logSystem('info', "系统健康检查完成", array(
                'status' => $overall['status'],
                'issues_count' => count($overall['issues']),
                'warnings_count' => count($overall['warnings'])
            ));
            
            return array(
                'success' => true,
                'overall' => $overall,
                'checks' => $checks
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("系统健康检查失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 备份系统
     */
    public function backupSystem($options = array()) {
        try {
            $backupDir = __DIR__ . '/../backups/';
            if (!is_dir($backupDir)) {
                mkdir($backupDir, 0755, true);
            }
            
            $backupName = 'system_backup_' . date('Y-m-d_H-i-s');
            $backupPath = $backupDir . $backupName;
            
            $results = array();
            
            // 备份数据库
            if ((isset($options['database']) ? $options['database'] : true)) {
                $results['database'] = $this->backupDatabase($backupPath . '_database.sql');
            }
            
            // 备份配置文件
            if ((isset($options['config']) ? $options['config'] : true)) {
                $results['config'] = $this->backupConfig($backupPath . '_config.zip');
            }
            
            // 备份上传文件
            if ((isset($options['uploads']) ? $options['uploads'] : true)) {
                $results['uploads'] = $this->backupUploads($backupPath . '_uploads.zip');
            }
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'backup_system',
                'system',
                array('backup_name' => $backupName, 'results' => $results)
            );
            
            return array(
                'success' => true,
                'backup_name' => $backupName,
                'results' => $results
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("系统备份失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取数据库版本
     */
    private function getDatabaseVersion() {
        try {
            $result = $this->database->fetch("SELECT VERSION() as version");
            return (isset($result['version']) ? $result['version'] : 'Unknown');
        } catch (Exception $e) {
            return 'Error: ' . $e->getMessage();
        }
    }
    
    /**
     * 获取数据库大小
     */
    private function getDatabaseSize() {
        try {
            $result = $this->database->fetch("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size FROM information_schema.tables WHERE table_schema = DATABASE()");
            return (isset($result['size']) ? $result['size'] : 0) . ' MB';
        } catch (Exception $e) {
            return 'Error: ' . $e->getMessage();
        }
    }
    
    /**
     * 测试数据库连接
     */
    private function testDatabaseConnection() {
        try {
            $this->database->fetch("SELECT 1");
            return 'Connected';
        } catch (Exception $e) {
            return 'Error: ' . $e->getMessage();
        }
    }
    
    /**
     * 获取应用版本
     */
    private function getApplicationVersion() {
        $configFile = $this->configDir . 'app.php';
        if (file_exists($configFile)) {
            $config = include $configFile;
            return (isset($config['version']) ? $config['version'] : '1.0.0');
        }
        return '1.0.0';
    }
    
    /**
     * 获取环境
     */
    private function getEnvironment() {
        return (isset($_ENV['APP_ENV']) ? $_ENV['APP_ENV'] : 'production');
    }
    
    /**
     * 检查调试模式
     */
    private function isDebugMode() {
        return (isset($_ENV['DEBUG']) ? $_ENV['DEBUG'] : false);
    }
    
    /**
     * 获取缓存状态
     */
    private function getCacheStatus() {
        try {
            $testKey = 'system_test_' . time();
            $this->cacheManager->set($testKey, 'test', 60);
            $value = $this->cacheManager->get($testKey);
            $this->cacheManager->delete($testKey);
            
            return $value === 'test' ? 'Working' : 'Error';
        } catch (Exception $e) {
            return 'Error: ' . $e->getMessage();
        }
    }
    
    /**
     * 获取系统运行时间
     */
    private function getSystemUptime() {
        if (function_exists('sys_getloadavg')) {
            $load = sys_getloadavg();
            return (isset($load[0]) ? $load[0] : 'Unknown');
        }
        return 'Unknown';
    }
    
    /**
     * 获取配置
     */
    private function getConfig($section) {
        $configFile = $this->configDir . $section . '.php';
        if (file_exists($configFile)) {
            return include $configFile;
        }
        return array();
    }
    
    /**
     * 清理应用缓存
     */
    private function clearApplicationCache() {
        $this->cacheManager->clear();
        return true;
    }
    
    /**
     * 清理数据库缓存
     */
    private function clearDatabaseCache() {
        // 清理查询缓存
        $this->database->execute("RESET QUERY CACHE");
        return true;
    }
    
    /**
     * 清理会话缓存
     */
    private function clearSessionCache() {
        $sessionDir = session_save_path();
        if (is_dir($sessionDir)) {
            $files = glob($sessionDir . '/sess_*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
        }
        return true;
    }
    
    /**
     * 清理模板缓存
     */
    private function clearTemplateCache() {
        $templateCacheDir = __DIR__ . '/../cache/templates/';
        if (is_dir($templateCacheDir)) {
            $this->removeDirectory($templateCacheDir);
            mkdir($templateCacheDir, 0755, true);
        }
        return true;
    }
    
    /**
     * 获取CPU使用率
     */
    private function getCpuUsage() {
        if (function_exists('sys_getloadavg')) {
            $load = sys_getloadavg();
            return array(
                'load_1min' => (isset($load[0]) ? $load[0] : 0),
                'load_5min' => (isset($load[1]) ? $load[1] : 0),
                'load_15min' => (isset($load[2]) ? $load[2] : 0)
            );
        }
        return array('error' => 'Not available');
    }
    
    /**
     * 获取内存使用情况
     */
    private function getMemoryUsage() {
        return array(
            'current' => memory_get_usage(true),
            'peak' => memory_get_peak_usage(true),
            'limit' => $this->parseMemoryLimit(ini_get('memory_limit'))
        );
    }
    
    /**
     * 获取磁盘使用情况
     */
    private function getDiskUsage() {
        $root = __DIR__ . '/../';
        $free = disk_free_space($root);
        $total = disk_total_space($root);
        
        return array(
            'free' => $free,
            'total' => $total,
            'used' => $total - $free,
            'percentage' => round((($total - $free) / $total) * 100, 2)
        );
    }
    
    /**
     * 获取网络统计
     */
    private function getNetworkStats() {
        // 这里可以实现更复杂的网络统计
        return array('status' => 'Not implemented');
    }
    
    /**
     * 获取数据库统计
     */
    private function getDatabaseStats() {
        try {
            $stats = $this->database->fetchAll("
                SELECT 
                    table_name as 'table',
                    table_rows as 'rows',
                    ROUND(((data_length + index_length) / 1024 / 1024), 2) as 'size_mb'
                FROM information_schema.tables 
                WHERE table_schema = DATABASE()
                ORDER BY (data_length + index_length) DESC
            ");
            
            return $stats;
        } catch (Exception $e) {
            return array('error' => $e->getMessage());
        }
    }
    
    /**
     * 获取缓存统计
     */
    private function getCacheStats() {
        try {
            $stats = $this->cacheManager->getStats();
            return $stats ?: array('status' => 'Not available');
        } catch (Exception $e) {
            return array('error' => $e->getMessage());
        }
    }
    
    /**
     * 获取请求统计
     */
    private function getRequestStats() {
        // 这里可以实现请求统计
        return array('status' => 'Not implemented');
    }
    
    /**
     * 检查数据库
     */
    private function checkDatabase() {
        try {
            $this->database->fetch("SELECT 1");
            return array('status' => 'ok', 'message' => 'Database connection is working');
        } catch (Exception $e) {
            return array('status' => 'error', 'message' => $e->getMessage());
        }
    }
    
    /**
     * 检查缓存
     */
    private function checkCache() {
        try {
            $testKey = 'health_check_' . time();
            $this->cacheManager->set($testKey, 'test', 60);
            $value = $this->cacheManager->get($testKey);
            $this->cacheManager->delete($testKey);
            
            if ($value === 'test') {
                return array('status' => 'ok', 'message' => 'Cache is working');
            } else {
                return array('status' => 'error', 'message' => 'Cache is not working');
            }
        } catch (Exception $e) {
            return array('status' => 'error', 'message' => $e->getMessage());
        }
    }
    
    /**
     * 检查文件系统
     */
    private function checkFilesystem() {
        $writableDirs = array(
            __DIR__ . '/../cache/',
            __DIR__ . '/../logs/',
            __DIR__ . '/../uploads/',
            __DIR__ . '/../backups/'
        );
        
        foreach ($writableDirs as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            
            if (!is_writable($dir)) {
                return array('status' => 'error', 'message' => "Directory {$dir} is not writable");
            }
        }
        
        return array('status' => 'ok', 'message' => 'Filesystem is working');
    }
    
    /**
     * 检查权限
     */
    private function checkPermissions() {
        $requiredFiles = array(
            $this->configDir . 'database.php',
            $this->configDir . 'app.php'
        );
        
        foreach ($requiredFiles as $file) {
            if (file_exists($file) && is_readable($file)) {
                if (substr(decoct(fileperms($file)), -4) !== '0600') {
                    return array('status' => 'warning', 'message' => "File {$file} has insecure permissions");
                }
            }
        }
        
        return array('status' => 'ok', 'message' => 'Permissions are secure');
    }
    
    /**
     * 检查PHP扩展
     */
    private function checkPhpExtensions() {
        $requiredExtensions = array('pdo', 'pdo_mysql', 'json', 'mbstring', 'openssl');
        $missing = array();
        
        foreach ($requiredExtensions as $ext) {
            if (!extension_loaded($ext)) {
                array_push($missing, $ext);
            }
        }
        
        if (!empty($missing)) {
            return array('status' => 'error', 'message' => 'Missing extensions: ' . implode(', ', $missing));
        }
        
        return array('status' => 'ok', 'message' => 'All required extensions are loaded');
    }
    
    /**
     * 检查安全配置
     */
    private function checkSecurity() {
        $issues = array();
        
        if (ini_get('display_errors')) {
            array_push($issues, 'display_errors is enabled');
        }
        
        if (!ini_get('expose_php')) {
            array_push($issues, 'expose_php should be disabled');
        }
        
        if (!empty($issues)) {
            return array('status' => 'warning', 'message' => implode(', ', $issues));
        }
        
        return array('status' => 'ok', 'message' => 'Security configuration is good');
    }
    
    /**
     * 备份数据库
     */
    private function backupDatabase($backupFile) {
        // 这里应该实现数据库备份逻辑
        // 可以使用mysqldump命令或PHP实现
        return array('status' => 'success', 'file' => $backupFile);
    }
    
    /**
     * 备份配置
     */
    private function backupConfig($backupFile) {
        // 这里应该实现配置文件备份逻辑
        return array('status' => 'success', 'file' => $backupFile);
    }
    
    /**
     * 备份上传文件
     */
    private function backupUploads($backupFile) {
        // 这里应该实现上传文件备份逻辑
        return array('status' => 'success', 'file' => $backupFile);
    }
    
    /**
     * 删除目录
     */
    private function removeDirectory($dir) {
        if (is_dir($dir)) {
            $files = array_diff(scandir($dir), array('.', '..'));
            foreach ($files as $file) {
                $path = $dir . '/' . $file;
                is_dir($path) ? $this->removeDirectory($path) : unlink($path);
            }
            return rmdir($dir);
        }
        return false;
    }
    
    /**
     * 解析内存限制
     */
    private function parseMemoryLimit($value) {
        $unit = strtolower(substr($value, -1));
        $value = (int) $value;
        
        switch ($unit) {
            case 'g':
                return $value * 1024 * 1024 * 1024;
            case 'm':
                return $value * 1024 * 1024;
            case 'k':
                return $value * 1024;
            default:
                return $value;
        }
    }
    
    /**
     * 获取当前用户ID
     */
    private function getCurrentUserId() {
        // 这里应该从会话或认证系统获取当前用户ID
        return (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null);
    }
}