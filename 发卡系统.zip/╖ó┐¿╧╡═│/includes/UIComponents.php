/**
 * 通用UI组件库
 * 提供可复用的UI组件和交互效果
 */

class UIComponents {
    
    /**
     * 显示加载动画
     */
    public static function showLoading($message = '加载中...') {
        return '
        <div class="loading-overlay" id="loadingOverlay">
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
                <div class="loading-text">' . htmlspecialchars($message) . '</div>
            </div>
        </div>';
    }
    
    /**
     * 显示成功提示
     */
    public static function showSuccess($message, $duration = 3000) {
        return '
        <div class="toast success-toast" id="successToast" data-duration="' . $duration . '">
            <div class="toast-header">
                <i class="fas fa-check-circle text-success me-2"></i>
                <strong class="me-auto">成功</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ' . htmlspecialchars($message) . '
            </div>
        </div>';
    }
    
    /**
     * 显示错误提示
     */
    public static function showError($message, $duration = 5000) {
        return '
        <div class="toast error-toast" id="errorToast" data-duration="' . $duration . '">
            <div class="toast-header">
                <i class="fas fa-exclamation-circle text-danger me-2"></i>
                <strong class="me-auto">错误</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ' . htmlspecialchars($message) . '
            </div>
        </div>';
    }
    
    /**
     * 显示警告提示
     */
    public static function showWarning($message, $duration = 4000) {
        return '
        <div class="toast warning-toast" id="warningToast" data-duration="' . $duration . '">
            <div class="toast-header">
                <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                <strong class="me-auto">警告</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ' . htmlspecialchars($message) . '
            </div>
        </div>';
    }
    
    /**
     * 显示信息提示
     */
    public static function showInfo($message, $duration = 3000) {
        return '
        <div class="toast info-toast" id="infoToast" data-duration="' . $duration . '">
            <div class="toast-header">
                <i class="fas fa-info-circle text-info me-2"></i>
                <strong class="me-auto">信息</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ' . htmlspecialchars($message) . '
            </div>
        </div>';
    }
    
    /**
     * 确认对话框
     */
    public static function confirmDialog($message, $title = '确认操作', $confirmText = '确认', $cancelText = '取消') {
        return '
        <div class="modal fade" id="confirmModal" tabindex="-1">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">' . htmlspecialchars($title) . '</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>' . htmlspecialchars($message) . '</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">' . htmlspecialchars($cancelText) . '</button>
                        <button type="button" class="btn btn-primary" id="confirmBtn">' . htmlspecialchars($confirmText) . '</button>
                    </div>
                </div>
            </div>
        </div>';
    }
    
    /**
     * 进度条
     */
    public static function progressBar($percentage = 0, $label = '', $type = 'primary') {
        return '
        <div class="progress mb-3">
            <div class="progress-bar bg-' . $type . '" role="progressbar" 
                 style="width: ' . $percentage . '%;" 
                 aria-valuenow="' . $percentage . '" 
                 aria-valuemin="0" 
                 aria-valuemax="100">
                ' . ($label ? htmlspecialchars($label) : $percentage . '%') . '
            </div>
        </div>';
    }
    
    /**
     * 徽章
     */
    public static function badge($text, $type = 'primary') {
        return '<span class="badge bg-' . $type . '">' . htmlspecialchars($text) . '</span>';
    }
    
    /**
     * 状态徽章
     */
    public static function statusBadge($status, $typeMap = array()) {
        $defaultTypes = array(
            'active' => 'success',
            'inactive' => 'secondary',
            'pending' => 'warning',
            'completed' => 'primary',
            'failed' => 'danger',
            'cancelled' => 'dark'
        );
        
        $type = (isset($typeMap[$status]) ? $typeMap[$status] : (isset($defaultTypes[$status]) ? $defaultTypes[$status] : 'secondary'));
        
        return '<span class="badge bg-' . $type . '">' . htmlspecialchars($status) . '</span>';
    }
    
    /**
     * 分页组件
     */
    public static function pagination($currentPage, $totalPages, $baseUrl, $maxVisible = 5) {
        if ($totalPages <= 1) {
            return '';
        }
        
        $html = '<nav aria-label="分页导航"><ul class="pagination justify-content-center">';
        
        // 上一页
        if ($currentPage > 1) {
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?page=' . ($currentPage - 1) . '">上一页</a></li>';
        } else {
            $html .= '<li class="page-item disabled"><span class="page-link">上一页</span></li>';
        }
        
        // 页码
        $start = max(1, $currentPage - floor($maxVisible / 2));
        $end = min($totalPages, $start + $maxVisible - 1);
        
        if ($start > 1) {
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?page=1">1</a></li>';
            if ($start > 2) {
                $html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        
        for ($i = $start; $i <= $end; $i++) {
            if ($i == $currentPage) {
                $html .= '<li class="page-item active"><span class="page-link">' . $i . '</span></li>';
            } else {
                $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?page=' . $i . '">' . $i . '</a></li>';
            }
        }
        
        if ($end < $totalPages) {
            if ($end < $totalPages - 1) {
                $html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?page=' . $totalPages . '">' . $totalPages . '</a></li>';
        }
        
        // 下一页
        if ($currentPage < $totalPages) {
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?page=' . ($currentPage + 1) . '">下一页</a></li>';
        } else {
            $html .= '<li class="page-item disabled"><span class="page-link">下一页</span></li>';
        }
        
        $html .= '</ul></nav>';
        
        return $html;
    }
    
    /**
     * 搜索框
     */
    public static function searchBox($placeholder = '搜索...', $name = 'search', $value = '') {
        return '
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="' . htmlspecialchars($name) . '" 
                   placeholder="' . htmlspecialchars($placeholder) . '" 
                   value="' . htmlspecialchars($value) . '">
            <button class="btn btn-outline-secondary" type="submit">
                <i class="fas fa-search"></i> 搜索
            </button>
        </div>';
    }
    
    /**
     * 表格工具栏
     */
    public static function tableToolbar($actions = array()) {
        $html = '<div class="table-toolbar mb-3">';
        
        // 左侧操作按钮
        if (!empty($actions['left'])) {
            $html .= '<div class="btn-group me-2">';
            foreach ($actions['left'] as $action) {
                $html .= '<button type="button" class="btn ' . (isset($action['class']) ? $action['class'] : 'btn-primary') . '" ';
                if (!empty($action['id'])) {
                    $html .= 'id="' . htmlspecialchars($action['id']) . '" ';
                }
                if (!empty($action['onclick'])) {
                    $html .= 'onclick="' . htmlspecialchars($action['onclick']) . '" ';
                }
                $html .= '>' . htmlspecialchars($action['text']) . '</button>';
            }
            $html .= '</div>';
        }
        
        // 右侧搜索框
        if (!empty($actions['search'])) {
            $html .= '<div class="float-end">';
            $html .= '<div class="input-group" style="width: 250px;">';
            $html .= '<input type="text" class="form-control" placeholder="' . htmlspecialchars((isset($actions['search']['placeholder']) ? $actions['search']['placeholder'] : '搜索...')) . '" id="tableSearch">';
            $html .= '<button class="btn btn-outline-secondary" type="button" id="tableSearchBtn">';
            $html .= '<i class="fas fa-search"></i>';
            $html .= '</button>';
            $html .= '</div>';
            $html .= '</div>';
        }
        
        $html .= '<div class="clearfix"></div></div>';
        
        return $html;
    }
    
    /**
     * 空状态提示
     */
    public static function emptyState($message = '暂无数据', $icon = 'fa-inbox', $action = null) {
        $html = '
        <div class="empty-state text-center py-5">
            <div class="empty-state-icon mb-3">
                <i class="fas ' . $icon . ' fa-3x text-muted"></i>
            </div>
            <div class="empty-state-text text-muted mb-3">
                ' . htmlspecialchars($message) . '
            </div>';
        
        if ($action) {
            $html .= '<button type="button" class="btn ' . ((isset($action['class']) ? $action['class'] : 'btn-primary')) . '" ';
            if (!empty($action['onclick'])) {
                $html .= 'onclick="' . htmlspecialchars($action['onclick']) . '" ';
            }
            $html .= '>' . htmlspecialchars($action['text']) . '</button>';
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * 卡片组件
     */
    public static function card($title, $content, $options = array()) {
        $headerClass = (isset($options['header_class']) ? $options['header_class'] : '');
        $bodyClass = (isset($options['body_class']) ? $options['body_class'] : '');
        $footer = (isset($options['footer']) ? $options['footer'] : '');
        
        $html = '<div class="card ' . (isset($options['class']) ? $options['class'] : '') . '">';
        
        if ($title) {
            $html .= '<div class="card-header ' . $headerClass . '">';
            $html .= '<h5 class="card-title mb-0">' . htmlspecialchars($title) . '</h5>';
            $html .= '</div>';
        }
        
        $html .= '<div class="card-body ' . $bodyClass . '">';
        $html .= $content;
        $html .= '</div>';
        
        if ($footer) {
            $html .= '<div class="card-footer">' . $footer . '</div>';
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * 统计卡片
     */
    public static function statCard($title, $value, $icon, $color = 'primary', $trend = null) {
        $trendHtml = '';
        if ($trend !== null) {
            $trendIcon = $trend > 0 ? 'fa-arrow-up' : 'fa-arrow-down';
            $trendColor = $trend > 0 ? 'text-success' : 'text-danger';
            $trendHtml = '<div class="stat-trend ' . $trendColor . '">
                <i class="fas ' . $trendIcon . '"></i> ' . abs($trend) . '%</div>';
        }
        
        return '
        <div class="stat-card">
            <div class="stat-card-icon bg-' . $color . ' text-white">
                <i class="fas ' . $icon . '"></i>
            </div>
            <div class="stat-card-content">
                <div class="stat-card-title">' . htmlspecialchars($title) . '</div>
                <div class="stat-card-value">' . htmlspecialchars($value) . '</div>
                ' . $trendHtml . '
            </div>
        </div>';
    }
    
    /**
     * 步骤条
     */
    public static function steps($steps, $currentStep) {
        $html = '<div class="steps">';
        
        foreach ($steps as $index => $step) {
            $isActive = $index == $currentStep;
            $isCompleted = $index < $currentStep;
            
            $html .= '<div class="step ' . ($isActive ? 'active' : '') . ' ' . ($isCompleted ? 'completed' : '') . '">';
            $html .= '<div class="step-number">';
            if ($isCompleted) {
                $html .= '<i class="fas fa-check"></i>';
            } else {
                $html .= ($index + 1);
            }
            $html .= '</div>';
            $html .= '<div class="step-title">' . htmlspecialchars($step) . '</div>';
            $html .= '</div>';
            
            if ($index < count($steps) - 1) {
                $html .= '<div class="step-line"></div>';
            }
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * 标签页
     */
    public static function tabs($tabs, $activeTab = 0) {
        $html = '<ul class="nav nav-tabs" id="customTabs" role="tablist">';
        
        foreach ($tabs as $index => $tab) {
            $isActive = $index == $activeTab;
            $html .= '<li class="nav-item" role="presentation">';
            $html .= '<button class="nav-link ' . ($isActive ? 'active' : '') . '" 
                     id="' . htmlspecialchars($tab['id']) . '-tab" 
                     data-bs-toggle="tab" 
                     data-bs-target="#' . htmlspecialchars($tab['id']) . '" 
                     type="button" role="tab">';
            $html .= '<i class="fas ' . ((isset($tab['icon']) ? $tab['icon'] : 'fa-file')) . ' me-2"></i>';
            $html .= htmlspecialchars($tab['title']);
            $html .= '</button>';
            $html .= '</li>';
        }
        
        $html .= '</ul>';
        $html .= '<div class="tab-content" id="customTabContent">';
        
        foreach ($tabs as $index => $tab) {
            $isActive = $index == $activeTab;
            $html .= '<div class="tab-pane fade ' . ($isActive ? 'show active' : '') . '" 
                     id="' . htmlspecialchars($tab['id']) . '" 
                     role="tabpanel">';
            $html .= isset($tab['content']) ? $tab['content'] : '';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * 模态框
     */
    public static function modal($id, $title, $content, $size = 'md', $footer = null) {
        $html = '
        <div class="modal fade" id="' . htmlspecialchars($id) . '" tabindex="-1">
            <div class="modal-dialog modal-' . $size . '">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">' . htmlspecialchars($title) . '</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        ' . $content . '
                    </div>';
        
        if ($footer !== null) {
            $html .= '<div class="modal-footer">' . $footer . '</div>';
        }
        
        $html .= '
                </div>
            </div>
        </div>';
        
        return $html;
    }
}