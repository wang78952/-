<?php
/**
 * 高级日志管理器
 * 处理系统日志、操作日志、错误日志等日志相关功能，支持日志加密、告警、远程日志传输
 * @author System Administrator
 * @version 1.2.0
 * @copyright 2024 发卡系统
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/SecurityUtils.php';
require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/exceptions/LogException.php';

class LogManager extends BaseService {
    // 日志目录和配置
    private $logDir;
    private $maxLogSize = 10 * 1024 * 1024; // 10MB
    private $logRetentionDays = 30;
    private $encryptionKey = null;
    private $remoteLogEnabled = false;
    private $remoteLogEndpoint = null;
    private $alarmThresholds = [];
    private $alarmChannels = [];
    
    // 有效的日志级别
    private $validLogLevels = ['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug'];
    
    /**
     * 构造函数
     * @param Database $database 数据库连接
     * @param LogManager $logger 日志管理器（避免循环依赖）
     * @throws LogException 当日志初始化失败时抛出
     */
    public function __construct($database = null, $logger = null) {
        parent::__construct();
        
        // 加载配置
        $config = Config::getInstance();
        $logConfig = $config->get('logging', []);
        
        // 设置日志目录
        $this->logDir = isset($logConfig['log_dir']) ? $logConfig['log_dir'] : __DIR__ . '/../logs/';
        $this->maxLogSize = isset($logConfig['max_log_size']) ? $logConfig['max_log_size'] : 10 * 1024 * 1024;
        $this->logRetentionDays = isset($logConfig['retention_days']) ? $logConfig['retention_days'] : 30;
        
        // 设置加密
        if (isset($logConfig['encryption_enabled']) && $logConfig['encryption_enabled']) {
            $this->encryptionKey = isset($logConfig['encryption_key']) ? $logConfig['encryption_key'] : null;
        }
        
        // 设置远程日志
        if (isset($logConfig['remote_log']) && $logConfig['remote_log']['enabled']) {
            $this->remoteLogEnabled = true;
            $this->remoteLogEndpoint = $logConfig['remote_log']['endpoint'];
        }
        
        // 设置告警配置
        if (isset($logConfig['alarms'])) {
            $this->alarmThresholds = $logConfig['alarms']['thresholds'] ?? [];
            $this->alarmChannels = $logConfig['alarms']['channels'] ?? [];
        }
        
        // 创建日志目录
        try {
            if (!is_dir($this->logDir)) {
                mkdir($this->logDir, 0755, true);
                chmod($this->logDir, 0755);
            }
            
            // 验证目录权限
            if (!is_writable($this->logDir)) {
                throw new LogException('日志目录不可写: ' . $this->logDir);
            }
        } catch (Exception $e) {
            error_log('日志系统初始化失败: ' . $e->getMessage());
            throw new LogException('日志系统初始化失败: ' . $e->getMessage(), 500, $e);
        }
        
        // 记录初始化日志
        if ($logger) {
            $logger->logSystem('info', '日志系统初始化完成', [
                'log_dir' => $this->logDir,
                'max_size' => $this->maxLogSize,
                'retention' => $this->logRetentionDays,
                'encryption_enabled' => !!$this->encryptionKey,
                'remote_log_enabled' => $this->remoteLogEnabled
            ]);
        }
    }
    
    /**
     * 记录系统日志
     * @param string $level 日志级别 (emergency, alert, critical, error, warning, notice, info, debug)
     * @param string $message 日志消息
     * @param array $context 上下文信息
     * @return bool 记录是否成功
     * @throws LogException 当日志级别无效时抛出
     */
    public function logSystem($level, $message, $context = array()) {
        // 验证日志级别
        if (!in_array($level, $this->validLogLevels)) {
            throw new LogException('无效的日志级别: ' . $level);
        }
        $logData = array(
            'type' => 'system',
            'level' => $level,
            'message' => $message,
            'context' => $context,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'cli'),
            'user_agent' => (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'cli')
        );
        
        return $this->writeLog($logData);
    }
    
    /**
     * 记录操作日志
     */
    public function logOperation($action, $resource, $details = array()) {
        // 兼容BaseService的方法签名，userId从会话中获取
        $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        
        $logData = array(
            'type' => 'operation',
            'user_id' => $userId,
            'action' => $action,
            'resource' => $resource,
            'details' => $details,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'cli'),
            'user_agent' => (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'cli')
        );
        
        return $this->writeLog($logData);
    }
    
    /**
     * 记录安全日志
     */
    public function logSecurity($event, $details = array()) {
        $logData = array(
            'type' => 'security',
            'event' => $event,
            'details' => $details,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'cli'),
            'user_agent' => (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'cli')
        );
        
        return $this->writeLog($logData);
    }
    
    /**
     * 记录错误日志
     */
    public function logError($message, $context = array()) {
        $logData = array(
            'type' => 'error',
            'message' => $message,
            'context' => $context,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'cli'),
            'user_agent' => (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'cli'),
            'stack_trace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS)
        );
        
        return $this->writeLog($logData);
    }
    
    /**
     * 记录性能日志
     */
    public function logPerformance($action, $duration, $details = array()) {
        $logData = array(
            'type' => 'performance',
            'action' => $action,
            'duration' => $duration,
            'details' => $details,
            'timestamp' => date('Y-m-d H:i:s'),
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true)
        );
        
        return $this->writeLog($logData);
    }
    
    /**
     * 记录API日志
     */
    public function logApi($method, $endpoint, $request, $response, $duration) {
        $logData = array(
            'type' => 'api',
            'method' => $method,
            'endpoint' => $endpoint,
            'request' => $request,
            'response' => $response,
            'duration' => $duration,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'cli'),
            'user_agent' => (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'cli')
        );
        
        return $this->writeLog($logData);
    }
    
    /**
     * 写入日志
     * @param array $logData 日志数据
     * @return bool 记录是否成功
     */
    private function writeLog($logData) {
        try {
            // 检查是否需要告警
            $this->checkAndSendAlerts($logData);
            
            // 清理敏感数据
            $logData = $this->sanitizeSensitiveData($logData);
            
            // 写入文件日志
            $this->writeToFile($logData);
            
            // 写入数据库日志（如果需要）
            $this->writeToDatabase($logData);
            
            // 发送远程日志
            if ($this->remoteLogEnabled && $this->shouldSendRemoteLog($logData)) {
                $this->sendRemoteLog($logData);
            }
            
            return true;
        } catch (Exception $e) {
            // 紧急错误处理，避免递归日志调用
            error_log("日志写入失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查并发送告警
     * @param array $logData 日志数据
     */
    private function checkAndSendAlerts($logData) {
        $level = $logData['level'] ?? 'info';
        $type = $logData['type'] ?? 'unknown';
        
        // 检查告警阈值
        if (isset($this->alarmThresholds[$type]) && 
            in_array($level, $this->alarmThresholds[$type])) {
            
            foreach ($this->alarmChannels as $channel) {
                $this->sendAlarm($channel, $logData);
            }
        }
    }
    
    /**
     * 发送告警
     * @param string $channel 告警通道
     * @param array $logData 日志数据
     */
    private function sendAlarm($channel, $logData) {
        // 实际环境中实现邮件、短信等告警通道
        try {
            $message = "告警: {$logData['type']} - {$logData['message']}";
            error_log("[告警] [{$channel}] {$message}");
        } catch (Exception $e) {
            error_log("告警发送失败: " . $e->getMessage());
        }
    }
    
    /**
     * 清理敏感数据
     * @param array $logData 日志数据
     * @return array 清理后的数据
     */
    private function sanitizeSensitiveData($logData) {
        $sensitiveKeys = ['password', 'password_hash', 'token', 'api_key', 'credit_card', 'bank_account'];
        $sanitizedData = $logData;
        
        // 递归清理数组中的敏感数据
        $this->sanitizeArray($sanitizedData, $sensitiveKeys);
        
        return $sanitizedData;
    }
    
    /**
     * 递归清理数组中的敏感数据
     * @param array $data 数据数组
     * @param array $sensitiveKeys 敏感关键字数组
     */
    private function sanitizeArray(&$data, $sensitiveKeys) {
        if (!is_array($data)) return;
        
        foreach ($data as $key => &$value) {
            if (is_array($value)) {
                $this->sanitizeArray($value, $sensitiveKeys);
            } else if (is_string($key) && in_array(strtolower($key), $sensitiveKeys)) {
                $value = '*** 已隐藏 ***';
            } else if (is_string($value) && SecurityUtils::containsSensitiveData($value)) {
                $value = '*** 包含敏感信息 ***';
            }
        }
    }
    
    /**
     * 判断是否应该发送远程日志
     * @param array $logData 日志数据
     * @return bool 是否发送
     */
    private function shouldSendRemoteLog($logData) {
        // 只发送重要日志到远程
        $remoteLogTypes = ['security', 'error', 'critical'];
        $remoteLogLevels = ['emergency', 'alert', 'critical', 'error'];
        
        return in_array($logData['type'] ?? '', $remoteLogTypes) || 
               in_array($logData['level'] ?? '', $remoteLogLevels);
    }
    
    /**
     * 发送远程日志
     * @param array $logData 日志数据
     */
    private function sendRemoteLog($logData) {
        try {
            $options = [
                'http' => [
                    'header' => "Content-type: application/json\r\n",
                    'method' => 'POST',
                    'content' => json_encode($logData)
                ]
            ];
            
            $context = stream_context_create($options);
            file_get_contents($this->remoteLogEndpoint, false, $context);
        } catch (Exception $e) {
            error_log("远程日志发送失败: " . $e->getMessage());
        }
    }
    
    /**
     * 写入文件日志
     * @param array $logData 日志数据
     */
    private function writeToFile($logData) {
        $filename = $this->getLogFilename($logData['type']);
        $filepath = $this->logDir . $filename;
        
        // 检查目录权限
        if (!is_writable($this->logDir)) {
            error_log("日志目录不可写: " . $this->logDir);
            return;
        }
        
        // 检查文件大小，如果超过限制则轮转
        if (file_exists($filepath)) {
            // 使用更安全的文件大小检查
            clearstatcache(true, $filepath);
            if (filesize($filepath) > $this->maxLogSize) {
                $this->rotateLogFile($filepath);
            }
        }
        
        // 格式化日志条目
        $logEntry = $this->formatLogEntry($logData);
        
        // 如果启用了加密，对日志内容进行加密
        if ($this->encryptionKey && in_array($logData['type'], ['security', 'error'])) {
            $logEntry = SecurityUtils::encrypt($logEntry, $this->encryptionKey) . PHP_EOL;
        }
        
        // 使用更安全的文件写入方式
        $fileHandle = @fopen($filepath, 'a');
        if ($fileHandle) {
            @flock($fileHandle, LOCK_EX);
            @fwrite($fileHandle, $logEntry);
            @fflush($fileHandle);
            @flock($fileHandle, LOCK_UN);
            @fclose($fileHandle);
        } else {
            error_log("无法打开日志文件: " . $filepath);
        }
    }
    
    /**
     * 写入数据库日志
     * @param array $logData 日志数据
     */
    private function writeToDatabase($logData) {
        // 只记录重要日志到数据库
        $importantTypes = ['operation', 'security', 'error', 'critical', 'alert'];
        $databaseLogEnabled = Config::getInstance()->get('logging.database_enabled', true);
        
        if ($databaseLogEnabled && in_array($logData['type'], $importantTypes)) {
            $this->database->insert('system_logs', array(
                'type' => $logData['type'],
                'level' => (isset($logData['level']) ? $logData['level'] : 'info'),
                'user_id' => (isset($logData['user_id']) ? $logData['user_id'] : null),
                'action' => (isset($logData['action']) ? $logData['action'] : (isset($logData['event']) ? $logData['event'] : '')),
                'resource' => (isset($logData['resource']) ? $logData['resource'] : ''),
                'message' => (isset($logData['message']) ? $logData['message'] : ''),
                'details' => json_encode((isset($logData['details']) ? $logData['details'] : (isset($logData['context']) ? $logData['context'] : array()))),
                'ip' => $logData['ip'],
                'user_agent' => $logData['user_agent'],
                'created_at' => $logData['timestamp']
            ));
        }
    }
    
    /**
     * 获取日志文件名
     */
    private function getLogFilename($type) {
        $date = date('Y-m-d');
        return "{$type}-{$date}.log";
    }
    
    /**
     * 格式化日志条目
     */
    private function formatLogEntry($logData) {
        $timestamp = $logData['timestamp'];
        $type = strtoupper($logData['type']);
        $level = (isset($logData['level']) ? $logData['level'] : 'INFO');
        $ip = $logData['ip'];
        
        // 基础信息
        $entry = "[{$timestamp}] [{$type}] [{$level}] [{$ip}] ";
        
        // 根据类型添加特定信息
        switch ($logData['type']) {
            case 'operation':
                $entry .= "User {$logData['user_id']} {$logData['action']} on {$logData['resource']}";
                if (!empty($logData['details'])) {
                    $entry .= " - " . json_encode($logData['details']);
                }
                break;
                
            case 'security':
                $entry .= "Security event: {$logData['event']}";
                if (!empty($logData['details'])) {
                    $entry .= " - " . json_encode($logData['details']);
                }
                break;
                
            case 'error':
                $entry .= "Error: {$logData['message']}";
                if (!empty($logData['context'])) {
                    $entry .= " - " . json_encode($logData['context']);
                }
                break;
                
            case 'performance':
                $entry .= "Performance: {$logData['action']} took {$logData['duration']}ms";
                if (!empty($logData['details'])) {
                    $entry .= " - " . json_encode($logData['details']);
                }
                break;
                
            case 'api':
                $entry .= "API {$logData['method']} {$logData['endpoint']} - {$logData['duration']}ms";
                break;
                
            default:
                $entry .= (isset($logData['message']) ? $logData['message'] : '');
                if (!empty($logData['context'])) {
                    $entry .= " - " . json_encode($logData['context']);
                }
        }
        
        return $entry . PHP_EOL;
    }
    
    /**
     * 高级日志轮转
     * @param string $filepath 文件路径
     */
    private function rotateLogFile($filepath) {
        try {
            // 获取文件类型和日期
            $fileInfo = pathinfo($filepath);
            $date = date('Ymd_His');
            $backupFile = "{$filepath}.{$date}.gz";
            
            // 压缩备份
            if (function_exists('gzencode')) {
                $content = file_get_contents($filepath);
                $compressed = gzencode($content, 9);
                file_put_contents($backupFile, $compressed);
                
                // 验证备份是否成功
                if (file_exists($backupFile) && filesize($backupFile) > 0) {
                    // 清空原文件而不是删除（保持文件权限）
                    file_put_contents($filepath, '');
                    $this->logSystem('info', "日志文件已轮转并压缩", ['filepath' => $filepath]);
                }
            } else {
                // 如果没有gzencode函数，使用简单的重命名
                $backupFile = "{$filepath}.{$date}";
                rename($filepath, $backupFile);
                // 创建新文件
                file_put_contents($filepath, '');
            }
        } catch (Exception $e) {
            error_log("日志轮转失败: " . $e->getMessage());
            // 尝试简单的重命名作为后备方案
            try {
                $backupFile = "{$filepath}.emergency";
                rename($filepath, $backupFile);
                file_put_contents($filepath, '');
            } catch (Exception $e) {
                error_log("紧急日志轮转也失败: " . $e->getMessage());
            }
        }
    }
    
    /**
     * 设置日志加密密钥
     * @param string $key 加密密钥
     */
    public function setEncryptionKey($key) {
        $this->encryptionKey = $key;
    }
    
    /**
     * 设置远程日志配置
     * @param bool $enabled 是否启用
     * @param string $endpoint 远程端点
     */
    public function setRemoteLogConfig($enabled, $endpoint) {
        $this->remoteLogEnabled = $enabled;
        $this->remoteLogEndpoint = $endpoint;
    }
    
    /**
     * 获取日志统计信息（增强版）
     * @param array $filters 过滤条件
     * @return array 统计信息
     */
    public function getEnhancedLogStats($filters = []) {
        try {
            $stats = parent::getLogStats($filters);
            
            // 添加文件日志统计
            $fileStats = [
                'total_files' => 0,
                'total_size' => 0,
                'files_by_type' => []
            ];
            
            $logFiles = $this->getLogFiles();
            foreach ($logFiles as $file) {
                $fileStats['total_files']++;
                $fileStats['total_size'] += $file['size'];
                
                if (!isset($fileStats['files_by_type'][$file['type']])) {
                    $fileStats['files_by_type'][$file['type']] = 0;
                }
                $fileStats['files_by_type'][$file['type']]++;
            }
            
            return [
                'success' => true,
                'db_stats' => $stats['stats'],
                'file_stats' => $fileStats
            ];
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 查询日志
     */
    public function queryLogs($filters = array(), $page = 1, $limit = 50) {
        try {
            $offset = ($page - 1) * $limit;
            
            $sql = "
                SELECT 
                    id,
                    type,
                    level,
                    user_id,
                    action,
                    resource,
                    message,
                    details,
                    ip,
                    user_agent,
                    created_at
                FROM system_logs
                WHERE 1=1
            ";
            $params = array();
            
            // 添加过滤条件
            if (!empty($filters['type'])) {
                $sql .= " AND type = ?";
                $params[] = $filters['type'];
            }
            
            if (!empty($filters['level'])) {
                $sql .= " AND level = ?";
                $params[] = $filters['level'];
            }
            
            if (!empty($filters['user_id'])) {
                $sql .= " AND user_id = ?";
                $params[] = $filters['user_id'];
            }
            
            if (!empty($filters['action'])) {
                $sql .= " AND action LIKE ?";
                $params[] = "%{$filters['action']}%";
            }
            
            if (!empty($filters['date_from'])) {
                $sql .= " AND created_at >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND created_at <= ?";
                $params[] = $filters['date_to'];
            }
            
            // 获取总数
            $countSql = str_replace("SELECT id, type, level, user_id, action, resource, message, details, ip, user_agent, created_at", "SELECT COUNT(*)", $sql);
            $total = $this->database->fetchColumn($countSql, $params);
            
            // 获取数据
            $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            
            $logs = $this->database->fetchAll($sql, $params);
            
            // 解析details字段
            foreach ($logs as &$log) {
                $log['details'] = json_decode($log['details'], true) ?: array();
            }
            
            return array(
                'success' => true,
                'logs' => $logs,
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            );
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取日志统计
     */
    public function getLogStats($filters = array()) {
        try {
            $sql = "
                SELECT 
                    type,
                    level,
                    COUNT(*) as count
                FROM system_logs
                WHERE 1=1
            ";
            $params = array();
            
            // 添加过滤条件
            if (!empty($filters['date_from'])) {
                $sql .= " AND created_at >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND created_at <= ?";
                $params[] = $filters['date_to'];
            }
            
            $sql .= " GROUP BY type, level";
            
            $stats = $this->database->fetchAll($sql, $params);
            
            // 组织统计数据
            $result = array();
            foreach ($stats as $stat) {
                $type = $stat['type'];
                $level = $stat['level'];
                
                if (!isset($result[$type])) {
                    $result[$type] = array();
                }
                
                $result[$type][$level] = $stat['count'];
            }
            
            return array('success' => true, 'stats' => $result);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 清理过期日志
     */
    public function cleanOldLogs($days = null) {
        try {
            $days = $days ?: $this->logRetentionDays;
            $cutoffDate = date('Y-m-d H:i:s', strtotime("-{$days} days"));
            
            // 清理数据库日志
            $deletedCount = $this->database->fetchColumn(
                "SELECT COUNT(*) FROM system_logs WHERE created_at < ?",
                [$cutoffDate]
            );
            
            $this->database->execute(
                "DELETE FROM system_logs WHERE created_at < ?",
                [$cutoffDate]
            );
            
            // 清理文件日志
            $this->cleanLogFiles($days);
            
            $this->logSystem('info', "过期日志清理完成", array(
                'days' => $days,
                'deleted_count' => $deletedCount
            ));
            
            return array(
                'success' => true,
                'deleted_count' => $deletedCount,
                'days' => $days
            );
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 清理日志文件
     */
    private function cleanLogFiles($days) {
        $cutoffTime = time() - ($days * 24 * 60 * 60);
        
        if (is_dir($this->logDir)) {
            $files = scandir($this->logDir);
            
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') {
                    continue;
                }
                
                $filepath = $this->logDir . $file;
                
                if (is_file($filepath) && filemtime($filepath) < $cutoffTime) {
                    unlink($filepath);
                }
            }
        }
    }
    
    /**
     * 获取日志文件列表
     */
    public function getLogFiles() {
        $files = array();
        
        if (is_dir($this->logDir)) {
            $items = scandir($this->logDir);
            
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                
                $filepath = $this->logDir . $item;
                
                if (is_file($filepath) && pathinfo($item, PATHINFO_EXTENSION) === 'log') {
                    $files[] = array(
                        'filename' => $item,
                        'filepath' => $filepath,
                        'size' => filesize($filepath),
                        'modified_time' => filemtime($filepath),
                        'type' => $this->getLogTypeFromFilename($item)
                    );
                }
            }
        }
        
        // 按修改时间倒序排列
        usort($files, function($a, $b) {
            return $b['modified_time'] - $a['modified_time'];
        });
        
        return $files;
    }
    
    /**
     * 从文件名获取日志类型
     */
    private function getLogTypeFromFilename($filename) {
        $parts = explode('-', $filename);
        return isset($parts[0]) ? $parts[0] : 'unknown';
    }
    
    /**
     * 读取日志文件内容
     */
    public function readLogFile($filename, $lines = 100) {
        $filepath = $this->logDir . $filename;
        
        if (!file_exists($filepath)) {
            return array('success' => false, 'message' => '文件不存在');
        }
        
        try {
            $content = file_get_contents($filepath);
            $logLines = explode(PHP_EOL, trim($content));
            
            // 获取最后N行
            $logLines = array_slice($logLines, -$lines);
            
            return array(
                'success' => true,
                'content' => implode(PHP_EOL, $logLines),
                'total_lines' => count(explode(PHP_EOL, trim($content))),
                'showed_lines' => count($logLines)
            );
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
}