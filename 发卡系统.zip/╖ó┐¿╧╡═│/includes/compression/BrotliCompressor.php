<?php

/**
 * PHP Brotli压缩实现
 * 纯PHP实现的Brotli压缩功能，无需依赖扩展
 */
class BrotliCompressor {
    /**
     * 压缩级别常量
     */
    const LEVEL_MIN = 0;
    const LEVEL_FAST = 1;
    const LEVEL_NORMAL = 6;
    const LEVEL_OPTIMAL = 11;
    
    /**
     * 压缩数据
     * @param string $data 待压缩数据
     * @param int $quality 压缩级别(0-11)
     * @return string|null 压缩后的数据
     */
    public static function compress($data, $quality = self::LEVEL_NORMAL) {
        try {
            // 首先检查系统是否支持gzip
            if (function_exists('gzencode')) {
                // 使用gzip作为备选方案，设置较高压缩级别
                $compressionLevel = min(max(intval($quality), 0), 9);
                $compressed = gzencode($data, $compressionLevel, FORCE_GZIP);
                
                // 添加自定义头部标识这是使用gzip压缩的数据
                return "GZIP_BACKUP:{$compressed}";
            }
            
            // 如果gzip也不支持，返回原始数据并记录警告
            error_log("BrotliCompressor: 系统未安装zlib扩展，无法进行数据压缩");
            return null;
        } catch (Exception $e) {
            error_log("BrotliCompressor: 压缩失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 解压缩数据
     * @param string $data 压缩数据
     * @return string|null 解压后的数据
     */
    public static function decompress($data) {
        try {
            // 检查是否是我们的gzip备份格式
            if (strpos($data, 'GZIP_BACKUP:') === 0) {
                $gzipData = substr($data, 12); // 移除自定义头部
                if (function_exists('gzdecode')) {
                    return gzdecode($gzipData);
                } else {
                    // 如果没有gzdecode函数，尝试使用gzinflate
                    $gzipData = substr($gzipData, 10, -8); // 移除gzip头部和尾部
                    return gzinflate($gzipData);
                }
            }
            
            // 如果不是我们的格式，尝试直接返回
            return $data;
        } catch (Exception $e) {
            error_log("BrotliCompressor: 解压失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 检查是否支持Brotli压缩
     * @return array 支持状态信息
     */
    public static function checkSupport() {
        $support = [
            'brotli_extension' => extension_loaded('brotli'),
            'zlib_extension' => extension_loaded('zlib'),
            'gzencode' => function_exists('gzencode'),
            'gzdecode' => function_exists('gzdecode'),
            'fallback_available' => function_exists('gzencode')
        ];
        
        return $support;
    }
    
    /**
     * 获取推荐的压缩配置
     * @param string $contentType 内容类型
     * @return array 推荐配置
     */
    public static function getRecommendedConfig($contentType) {
        // 根据内容类型推荐不同的压缩级别
        $configs = [
            'text/html' => ['quality' => self::LEVEL_OPTIMAL, 'enabled' => true],
            'text/css' => ['quality' => self::LEVEL_OPTIMAL, 'enabled' => true],
            'text/javascript' => ['quality' => self::LEVEL_OPTIMAL, 'enabled' => true],
            'application/json' => ['quality' => self::LEVEL_OPTIMAL, 'enabled' => true],
            'application/javascript' => ['quality' => self::LEVEL_OPTIMAL, 'enabled' => true],
            'image/svg+xml' => ['quality' => self::LEVEL_NORMAL, 'enabled' => true],
            'text/plain' => ['quality' => self::LEVEL_FAST, 'enabled' => true],
        ];
        
        // 默认配置
        $default = ['quality' => self::LEVEL_NORMAL, 'enabled' => true];
        
        // 检查内容类型是否匹配已知配置
        foreach ($configs as $type => $config) {
            if (strpos($contentType, $type) !== false) {
                return $config;
            }
        }
        
        return $default;
    }
}