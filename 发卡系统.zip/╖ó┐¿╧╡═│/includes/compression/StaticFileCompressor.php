<?php

require_once __DIR__ . '/BrotliCompressor.php';

/**
 * 静态文件压缩管理器
 * 预压缩静态资源文件并提供缓存机制
 */
class StaticFileCompressor {
    /**
     * 配置
     */
    protected $config;
    
    /**
     * 缓存目录
     */
    protected $cacheDir;
    
    /**
     * 构造函数
     * @param array $config 配置参数
     */
    public function __construct($config = null) {
        // 加载配置
        if ($config === null) {
            $configPath = __DIR__ . '/../../config/compression.php';
            $config = file_exists($configPath) ? include($configPath) : [];
        }
        
        $this->config = $config;
        
        // 初始化缓存目录
        if (isset($config['static_cache']['cache_dir'])) {
            $this->cacheDir = $config['static_cache']['cache_dir'];
            if (!is_dir($this->cacheDir)) {
                mkdir($this->cacheDir, 0755, true);
            }
        }
    }
    
    /**
     * 处理静态文件请求
     * @param string $filePath 文件路径
     * @return string|null 压缩后的文件路径或原始路径
     */
    public function handleRequest($filePath) {
        // 检查文件是否存在
        if (!file_exists($filePath)) {
            return null;
        }
        
        // 检查是否应该压缩
        if (!$this->shouldCompressFile($filePath)) {
            return $filePath;
        }
        
        // 获取缓存文件路径
        $cacheFilePath = $this->getCacheFilePath($filePath, 'gzip');
        
        // 检查缓存是否有效
        if ($this->isCacheValid($filePath, $cacheFilePath)) {
            return $cacheFilePath;
        }
        
        // 压缩文件
        if ($this->compressFile($filePath, $cacheFilePath)) {
            return $cacheFilePath;
        }
        
        // 压缩失败，返回原始文件
        return $filePath;
    }
    
    /**
     * 判断文件是否应该被压缩
     * @param string $filePath 文件路径
     * @return bool 是否压缩
     */
    public function shouldCompressFile($filePath) {
        // 检查文件大小
        $fileSize = filesize($filePath);
        $minSize = isset($this->config['compressor']['min_size']) ? $this->config['compressor']['min_size'] : 1024;
        $maxSize = isset($this->config['compressor']['max_size']) ? $this->config['compressor']['max_size'] : 5242880;
        
        if ($fileSize < $minSize || $fileSize > $maxSize) {
            return false;
        }
        
        // 检查文件类型
        $contentType = $this->getContentType($filePath);
        $typeConfig = $this->getContentTypeConfig($contentType);
        
        return $typeConfig['enabled'] ?? false;
    }
    
    /**
     * 获取文件内容类型
     * @param string $filePath 文件路径
     * @return string 内容类型
     */
    public function getContentType($filePath) {
        $extension = pathinfo($filePath, PATHINFO_EXTENSION);
        
        $mimeTypes = [
            'html' => 'text/html',
            'css' => 'text/css',
            'js' => 'text/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'svg' => 'image/svg+xml',
            'txt' => 'text/plain',
            'csv' => 'text/csv',
        ];
        
        return $mimeTypes[$extension] ?? 'application/octet-stream';
    }
    
    /**
     * 获取内容类型配置
     * @param string $contentType 内容类型
     * @return array 配置
     */
    public function getContentTypeConfig($contentType) {
        $defaultQuality = $this->config['compressor']['default_quality'] ?? 6;
        $defaultConfig = ['enabled' => false, 'quality' => $defaultQuality];
        
        // 精确匹配
        if (isset($this->config['content_types'][$contentType])) {
            return array_merge($defaultConfig, $this->config['content_types'][$contentType]);
        }
        
        // 通配符匹配
        foreach ($this->config['content_types'] as $type => $config) {
            if (strpos($contentType, $type) === 0) {
                return array_merge($defaultConfig, $config);
            }
        }
        
        return $defaultConfig;
    }
    
    /**
     * 压缩文件
     * @param string $sourcePath 源文件路径
     * @param string $destinationPath 目标文件路径
     * @return bool 是否压缩成功
     */
    public function compressFile($sourcePath, $destinationPath) {
        try {
            // 读取源文件
            $content = file_get_contents($sourcePath);
            
            // 获取内容类型和压缩质量
            $contentType = $this->getContentType($sourcePath);
            $typeConfig = $this->getContentTypeConfig($contentType);
            $quality = $typeConfig['quality'] ?? 6;
            
            // 压缩内容
            $compressed = BrotliCompressor::compress($content, $quality);
            
            if ($compressed && strpos($compressed, 'GZIP_BACKUP:') === 0) {
                $compressed = substr($compressed, 12);
            }
            
            if ($compressed && strlen($compressed) < strlen($content)) {
                // 保存压缩文件
                file_put_contents($destinationPath, $compressed);
                
                // 设置相同的文件权限
                $permissions = fileperms($sourcePath);
                chmod($destinationPath, $permissions);
                
                return true;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("静态文件压缩失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取缓存文件路径
     * @param string $originalPath 原始文件路径
     * @param string $compressionType 压缩类型
     * @return string 缓存文件路径
     */
    public function getCacheFilePath($originalPath, $compressionType) {
        // 创建基于原始文件路径的哈希
        $hash = md5($originalPath);
        
        // 确保缓存目录存在
        $cacheSubdir = $this->cacheDir . substr($hash, 0, 2) . '/';
        if (!is_dir($cacheSubdir)) {
            mkdir($cacheSubdir, 0755, true);
        }
        
        // 返回缓存文件路径
        return $cacheSubdir . substr($hash, 2) . '.' . $compressionType;
    }
    
    /**
     * 检查缓存是否有效
     * @param string $originalPath 原始文件路径
     * @param string $cachePath 缓存文件路径
     * @return bool 缓存是否有效
     */
    public function isCacheValid($originalPath, $cachePath) {
        // 检查缓存文件是否存在
        if (!file_exists($cachePath)) {
            return false;
        }
        
        // 检查缓存是否过期
        $originalMtime = filemtime($originalPath);
        $cacheMtime = filemtime($cachePath);
        
        // 如果原始文件比缓存文件新，缓存无效
        if ($originalMtime > $cacheMtime) {
            return false;
        }
        
        // 检查缓存TTL
        $cacheTtl = $this->config['static_cache']['cache_ttl'] ?? 86400;
        if (time() - $cacheMtime > $cacheTtl) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 批量压缩目录
     * @param string $dirPath 目录路径
     * @param array $excluded 排除的文件或目录
     * @return array 压缩统计信息
     */
    public function compressDirectory($dirPath, $excluded = []) {
        $stats = [
            'total' => 0,
            'compressed' => 0,
            'skipped' => 0,
            'failed' => 0,
            'saved_bytes' => 0
        ];
        
        // 遍历目录
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dirPath, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $filePath = $file->getPathname();
                
                // 检查是否应该排除
                $shouldExclude = false;
                foreach ($excluded as $pattern) {
                    if (fnmatch($pattern, $filePath)) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                if ($shouldExclude) {
                    $stats['skipped']++;
                    continue;
                }
                
                $stats['total']++;
                
                if ($this->shouldCompressFile($filePath)) {
                    $cacheFilePath = $this->getCacheFilePath($filePath, 'gzip');
                    
                    if ($this->compressFile($filePath, $cacheFilePath)) {
                        $originalSize = filesize($filePath);
                        $compressedSize = filesize($cacheFilePath);
                        $stats['saved_bytes'] += ($originalSize - $compressedSize);
                        $stats['compressed']++;
                    } else {
                        $stats['failed']++;
                    }
                } else {
                    $stats['skipped']++;
                }
            }
        }
        
        return $stats;
    }
    
    /**
     * 清理过期缓存
     * @return int 清理的文件数量
     */
    public function cleanCache() {
        if (!is_dir($this->cacheDir)) {
            return 0;
        }
        
        $cacheTtl = $this->config['static_cache']['cache_ttl'] ?? 86400;
        $now = time();
        $cleaned = 0;
        
        // 遍历缓存目录
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->cacheDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                // 检查文件是否过期
                if ($now - $file->getMTime() > $cacheTtl) {
                    unlink($file->getPathname());
                    $cleaned++;
                }
            } elseif ($file->isDir() && iterator_count(new DirectoryIterator($file->getPathname())) == 0) {
                // 删除空目录
                rmdir($file->getPathname());
            }
        }
        
        return $cleaned;
    }
    
    /**
     * 获取缓存统计信息
     * @return array 统计信息
     */
    public function getCacheStats() {
        if (!is_dir($this->cacheDir)) {
            return ['files' => 0, 'size' => 0];
        }
        
        $stats = ['files' => 0, 'size' => 0];
        
        // 遍历缓存目录
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->cacheDir, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $stats['files']++;
                $stats['size'] += $file->getSize();
            }
        }
        
        return $stats;
    }
    
    /**
     * 静态调用方法，适用于简单场景
     * @param string $filePath 文件路径
     * @return string 处理后的文件路径
     */
    public static function getCompressedFile($filePath) {
        static $compressor = null;
        
        if ($compressor === null) {
            $compressor = new self();
        }
        
        $result = $compressor->handleRequest($filePath);
        
        // 如果有压缩版本，设置相应的头部
        if ($result !== $filePath) {
            header('Content-Encoding: gzip');
        }
        
        return $result;
    }
}