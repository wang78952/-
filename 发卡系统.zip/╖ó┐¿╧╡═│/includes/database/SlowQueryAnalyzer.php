<?php
/**
 * 慢查询日志分析器
 * 用于解析和分析MySQL慢查询日志，识别性能问题SQL并提供优化建议
 */
class SlowQueryAnalyzer {
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * @var array 配置参数
     */
    private $config = [
        'slow_query_log_file' => null,       // 慢查询日志文件路径
        'slow_query_threshold' => 1.0,       // 慢查询阈值（秒）
        'min_execution_count' => 1,          // 最小执行次数过滤
        'max_results' => 100,                // 最大返回结果数
        'analyze_sample_size' => 1000,       // 分析的样本大小
    ];
    
    /**
     * 构造函数
     * @param Logger $logger 日志记录器
     * @param array $config 配置参数
     */
    public function __construct(Logger $logger, array $config = []) {
        $this->logger = $logger;
        $this->config = array_merge($this->config, $config);
        
        // 如果没有指定日志文件路径，尝试从MySQL配置获取
        if (!$this->config['slow_query_log_file']) {
            $this->config['slow_query_log_file'] = $this->detectSlowQueryLogPath();
        }
    }
    
    /**
     * 尝试检测慢查询日志路径
     * @return string|null 日志文件路径
     */
    private function detectSlowQueryLogPath() {
        try {
            // 尝试从MySQL配置文件读取
            $myCnfPaths = [
                '/etc/mysql/my.cnf',
                '/etc/my.cnf',
                'c:/Program Files/MySQL/MySQL Server 8.0/my.ini',
                'd:/MySQL/data/my.ini',
            ];
            
            foreach ($myCnfPaths as $path) {
                if (file_exists($path)) {
                    $content = file_get_contents($path);
                    if (preg_match('/slow_query_log_file\s*=\s*(.+)/i', $content, $matches)) {
                        $logPath = trim($matches[1]);
                        $this->logger->info("从配置文件检测到慢查询日志路径: {$logPath}");
                        return $logPath;
                    }
                }
            }
            
            // 默认路径
            $defaultPaths = [
                '/var/lib/mysql/mysql-slow.log',
                '/var/log/mysql/mysql-slow.log',
                'c:/ProgramData/MySQL/MySQL Server 8.0/Data/mysql-slow.log',
            ];
            
            foreach ($defaultPaths as $path) {
                if (file_exists($path)) {
                    $this->logger->info("使用默认路径找到慢查询日志: {$path}");
                    return $path;
                }
            }
            
            return null;
        } catch (Exception $e) {
            $this->logger->error("检测慢查询日志路径失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 解析慢查询日志文件
     * @param string $logFile 可选的日志文件路径
     * @return array 解析后的慢查询记录
     */
    public function parseSlowQueryLog($logFile = null) {
        $logFile = $logFile ?: $this->config['slow_query_log_file'];
        
        if (!$logFile || !file_exists($logFile)) {
            $this->logger->error("慢查询日志文件不存在或未指定: {$logFile}");
            return [];
        }
        
        $this->logger->info("开始解析慢查询日志: {$logFile}");
        
        $queries = [];
        $currentQuery = null;
        $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        // 限制读取的样本大小
        if (count($lines) > $this->config['analyze_sample_size']) {
            $lines = array_slice($lines, -$this->config['analyze_sample_size']);
            $this->logger->info("日志文件过大，仅分析最后 {$this->config['analyze_sample_size']} 行");
        }
        
        foreach ($lines as $line) {
            // 解析查询开始行
            if (preg_match('/^# Time: (\d{6})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})/', $line, $matches)) {
                // 如果当前有查询，先保存
                if ($currentQuery) {
                    $queries[] = $currentQuery;
                }
                
                // 创建新的查询记录
                $currentQuery = [
                    'timestamp' => "{$matches[1]}-{$matches[2]}-{$matches[3]} {$matches[4]}:{$matches[5]}:{$matches[6]}",
                    'query_time' => 0,
                    'lock_time' => 0,
                    'rows_sent' => 0,
                    'rows_examined' => 0,
                    'db' => null,
                    'user' => null,
                    'host' => null,
                    'sql' => '',
                    'full_sql' => '',
                    'fingerprint' => null,
                ];
            }
            // 解析用户和主机信息
            else if ($currentQuery && preg_match('/^# User@Host: (.+?)\[(\w+)\] @ (.+?) \[(.+?)\]/', $line, $matches)) {
                $currentQuery['user'] = $matches[2];
                $currentQuery['host'] = $matches[3];
            }
            // 解析查询信息
            else if ($currentQuery && preg_match('/^# Query_time: ([\d\.]+)\s+Lock_time: ([\d\.]+)\s+Rows_sent: (\d+)\s+Rows_examined: (\d+)/', $line, $matches)) {
                $currentQuery['query_time'] = (float)$matches[1];
                $currentQuery['lock_time'] = (float)$matches[2];
                $currentQuery['rows_sent'] = (int)$matches[3];
                $currentQuery['rows_examined'] = (int)$matches[4];
            }
            // 解析数据库信息
            else if ($currentQuery && preg_match('/^use (.+?);/', $line, $matches)) {
                $currentQuery['db'] = trim($matches[1], '`');
            }
            // 解析SQL语句
            else if ($currentQuery && !preg_match('/^#/', $line)) {
                // 跳过空行和SET语句
                if (trim($line) && !preg_match('/^SET /i', $line)) {
                    $currentQuery['full_sql'] .= $line . "\n";
                    $currentQuery['sql'] = trim($currentQuery['full_sql']);
                }
            }
        }
        
        // 添加最后一个查询
        if ($currentQuery && $currentQuery['sql']) {
            $queries[] = $currentQuery;
        }
        
        $this->logger->info("解析完成，共找到 {$this->config['analyze_sample_size']} 行，生成 " . count($queries) . " 个查询记录");
        
        // 过滤慢查询并添加指纹
        $filteredQueries = [];
        foreach ($queries as $query) {
            if ($query['query_time'] >= $this->config['slow_query_threshold']) {
                $query['fingerprint'] = $this->generateSqlFingerprint($query['sql']);
                $filteredQueries[] = $query;
            }
        }
        
        $this->logger->info("过滤后得到 " . count($filteredQueries) . " 个慢查询");
        
        return $filteredQueries;
    }
    
    /**
     * 生成SQL语句指纹
     * @param string $sql SQL语句
     * @return string SQL指纹
     */
    private function generateSqlFingerprint($sql) {
        // 移除注释
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        $sql = preg_replace('/--.*$/m', '', $sql);
        
        // 移除空格
        $sql = preg_replace('/\s+/', ' ', $sql);
        $sql = trim($sql);
        
        // 替换值为占位符
        // 替换数字
        $sql = preg_replace('/\b\d+\b/', '?', $sql);
        // 替换字符串值
        $sql = preg_replace('/\'[^']*\'/', "'?'", $sql);
        $sql = preg_replace('/"[^"]*"/', '"?"', $sql);
        // 替换NULL值
        $sql = preg_replace('/\bNULL\b/', '?', $sql);
        // 替换时间戳
        $sql = preg_replace('/\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/', '?', $sql);
        
        return strtoupper($sql);
    }
    
    /**
     * 分析慢查询并按性能问题分组
     * @param array $queries 慢查询列表
     * @return array 分析结果
     */
    public function analyzeSlowQueries(array $queries) {
        $this->logger->info("开始分析 " . count($queries) . " 个慢查询");
        
        // 按SQL指纹分组
        $groupedQueries = [];
        foreach ($queries as $query) {
            $fingerprint = $query['fingerprint'];
            if (!isset($groupedQueries[$fingerprint])) {
                $groupedQueries[$fingerprint] = [
                    'fingerprint' => $fingerprint,
                    'sample_sql' => $query['sql'],
                    'execution_count' => 0,
                    'total_time' => 0,
                    'avg_time' => 0,
                    'max_time' => 0,
                    'min_time' => PHP_INT_MAX,
                    'total_rows_sent' => 0,
                    'total_rows_examined' => 0,
                    'users' => [],
                    'databases' => [],
                    'first_seen' => $query['timestamp'],
                    'last_seen' => $query['timestamp'],
                    'warnings' => [],
                    'suggestions' => [],
                ];
            }
            
            $group = &$groupedQueries[$fingerprint];
            $group['execution_count']++;
            $group['total_time'] += $query['query_time'];
            $group['max_time'] = max($group['max_time'], $query['query_time']);
            $group['min_time'] = min($group['min_time'], $query['query_time']);
            $group['total_rows_sent'] += $query['rows_sent'];
            $group['total_rows_examined'] += $query['rows_examined'];
            
            // 记录用户和数据库
            if (!in_array($query['user'], $group['users'])) {
                $group['users'][] = $query['user'];
            }
            if (!in_array($query['db'], $group['databases'])) {
                $group['databases'][] = $query['db'];
            }
            
            // 更新时间范围
            if ($query['timestamp'] < $group['first_seen']) {
                $group['first_seen'] = $query['timestamp'];
            }
            if ($query['timestamp'] > $group['last_seen']) {
                $group['last_seen'] = $query['timestamp'];
            }
        }
        
        // 计算平均值和应用过滤器
        $analyzedQueries = [];
        foreach ($groupedQueries as &$group) {
            $group['avg_time'] = $group['total_time'] / $group['execution_count'];
            
            // 过滤执行次数过少的查询
            if ($group['execution_count'] >= $this->config['min_execution_count']) {
                // 分析SQL并提供建议
                $this->analyzeSqlQuery($group);
                $analyzedQueries[] = $group;
            }
        }
        
        // 按平均执行时间降序排序
        usort($analyzedQueries, function($a, $b) {
            return $b['avg_time'] - $a['avg_time'];
        });
        
        // 限制结果数量
        $analyzedQueries = array_slice($analyzedQueries, 0, $this->config['max_results']);
        
        $this->logger->info("分析完成，共生成 " . count($analyzedQueries) . " 个分析结果");
        
        return $analyzedQueries;
    }
    
    /**
     * 分析单个SQL查询并提供建议
     * @param array $queryInfo 查询信息
     */
    private function analyzeSqlQuery(array &$queryInfo) {
        $sql = $queryInfo['sample_sql'];
        $warnings = [];
        $suggestions = [];
        
        // 检查是否包含全表扫描
        if (preg_match('/^SELECT .* FROM [^\s]+$/i', $sql) && !preg_match('/WHERE|JOIN|GROUP BY|HAVING/i', $sql)) {
            $warnings[] = '可能存在全表扫描';
            $suggestions[] = '添加WHERE条件或索引来限制结果集';
        }
        
        // 检查是否使用了ORDER BY但没有索引
        if (preg_match('/ORDER BY/i', $sql) && !preg_match('/LIMIT/i', $sql)) {
            $warnings[] = '使用ORDER BY但没有LIMIT可能导致大量数据排序';
            $suggestions[] = '添加LIMIT子句限制结果数量';
            $suggestions[] = '确保ORDER BY的列上有适当的索引';
        }
        
        // 检查是否使用了LIMIT但没有ORDER BY
        if (preg_match('/LIMIT/i', $sql) && !preg_match('/ORDER BY/i', $sql)) {
            $warnings[] = '使用LIMIT但没有ORDER BY可能导致返回不可预测的结果';
            $suggestions[] = '添加ORDER BY子句确保结果一致性';
        }
        
        // 检查SELECT *
        if (preg_match('/SELECT \*/i', $sql)) {
            $warnings[] = '使用SELECT *可能检索不必要的列';
            $suggestions[] = '只选择需要的列，减少数据传输和处理';
        }
        
        // 检查JOIN数量
        $joinCount = preg_match_all('/JOIN/i', $sql, $matches);
        if ($joinCount >= 5) {
            $warnings[] = "过多的JOIN操作（{$joinCount}个）可能导致性能问题";
            $suggestions[] = '考虑重构查询或添加适当的索引';
            $suggestions[] = '使用EXPLAIN分析JOIN顺序和执行计划';
        }
        
        // 检查子查询
        if (preg_match('/\(\s*SELECT/i', $sql)) {
            $warnings[] = '使用子查询可能导致性能问题';
            $suggestions[] = '考虑使用JOIN替代子查询';
            $suggestions[] = '确保子查询有适当的索引';
        }
        
        // 检查是否有临时表或文件排序
        // 这里需要EXPLAIN来确认，但我们可以添加相关建议
        $suggestions[] = '使用EXPLAIN分析查询执行计划，检查是否有临时表或文件排序';
        
        // 检查是否使用了索引提示
        if (!preg_match('/USE INDEX|FORCE INDEX|IGNORE INDEX/i', $sql)) {
            $suggestions[] = '考虑在必要时使用索引提示优化查询';
        }
        
        // 检查表扫描比例
        $rowsRatio = $queryInfo['execution_count'] > 0 ? 
            $queryInfo['total_rows_examined'] / max(1, $queryInfo['total_rows_sent']) : 0;
        
        if ($rowsRatio > 100) {
            $warnings[] = "数据扫描效率低，检查了 {$rowsRatio} 倍于返回的行数";
            $suggestions[] = '优化WHERE条件或添加适当的索引';
            $suggestions[] = '考虑重构查询以减少不必要的数据扫描';
        }
        
        $queryInfo['warnings'] = $warnings;
        $queryInfo['suggestions'] = $suggestions;
    }
    
    /**
     * 执行慢查询分析
     * @param string $logFile 可选的日志文件路径
     * @return array 分析结果
     */
    public function executeAnalysis($logFile = null) {
        try {
            $this->logger->info("开始执行慢查询分析");
            
            // 解析慢查询日志
            $queries = $this->parseSlowQueryLog($logFile);
            
            // 分析慢查询
            $analysisResults = $this->analyzeSlowQueries($queries);
            
            // 生成统计信息
            $stats = $this->calculateStatistics($analysisResults);
            
            $this->logger->info("慢查询分析完成，生成了完整的分析报告");
            
            return [
                'analysis_time' => date('Y-m-d H:i:s'),
                'total_queries' => count($queries),
                'analyzed_queries' => count($analysisResults),
                'statistics' => $stats,
                'slow_queries' => $analysisResults,
            ];
        } catch (Exception $e) {
            $this->logger->error("慢查询分析失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 计算统计信息
     * @param array $analysisResults 分析结果
     * @return array 统计信息
     */
    private function calculateStatistics(array $analysisResults) {
        $totalQueries = count($analysisResults);
        $totalExecutionCount = 0;
        $totalExecutionTime = 0;
        $maxQueryTime = 0;
        $totalRowsSent = 0;
        $totalRowsExamined = 0;
        $warningCount = 0;
        
        foreach ($analysisResults as $result) {
            $totalExecutionCount += $result['execution_count'];
            $totalExecutionTime += $result['total_time'];
            $maxQueryTime = max($maxQueryTime, $result['max_time']);
            $totalRowsSent += $result['total_rows_sent'];
            $totalRowsExamined += $result['total_rows_examined'];
            $warningCount += count($result['warnings']);
        }
        
        return [
            'total_query_patterns' => $totalQueries,
            'total_executions' => $totalExecutionCount,
            'total_execution_time' => round($totalExecutionTime, 2),
            'avg_execution_time' => $totalExecutionCount > 0 ? round($totalExecutionTime / $totalExecutionCount, 4) : 0,
            'max_execution_time' => $maxQueryTime,
            'total_rows_sent' => $totalRowsSent,
            'total_rows_examined' => $totalRowsExamined,
            'avg_rows_examined_per_execution' => $totalExecutionCount > 0 ? round($totalRowsExamined / $totalExecutionCount, 2) : 0,
            'avg_rows_sent_per_execution' => $totalExecutionCount > 0 ? round($totalRowsSent / $totalExecutionCount, 2) : 0,
            'total_warnings' => $warningCount,
            'avg_warnings_per_query' => $totalQueries > 0 ? round($warningCount / $totalQueries, 2) : 0,
        ];
    }
    
    /**
     * 生成HTML格式的慢查询报告
     * @param array $analysisResults 分析结果
     * @return string HTML报告
     */
    public function generateHtmlReport(array $analysisResults) {
        $stats = $analysisResults['statistics'];
        $slowQueries = $analysisResults['slow_queries'];
        
        $html = '<!DOCTYPE html>\n';
        $html .= '<html>\n';
        $html .= '<head>\n';
        $html .= '    <meta charset="UTF-8">\n';
        $html .= '    <title>MySQL慢查询分析报告</title>\n';
        $html .= '    <style>\n';
        $html .= '        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f4; }\n';
        $html .= '        .container { max-width: 1200px; margin: 0 auto; background-color: white; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }\n';
        $html .= '        h1, h2, h3 { color: #333; }\n';
        $html .= '        .summary { background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }\n';
        $html .= '        .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }\n';
        $html .= '        .summary-item { background-color: white; padding: 15px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }\n';
        $html .= '        .summary-item .label { font-size: 12px; color: #666; margin-bottom: 5px; }\n';
        $html .= '        .summary-item .value { font-size: 24px; font-weight: bold; color: #4285f4; }\n';
        $html .= '        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }\n';
        $html .= '        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }\n';
        $html .= '        th { background-color: #f2f2f2; font-weight: bold; }\n';
        $html .= '        tr:hover { background-color: #f5f5f5; }\n';
        $html .= '        .query-detail { margin-top: 20px; padding: 20px; background-color: #f8f9fa; border-radius: 5px; }\n';
        $html .= '        .sql-code { background-color: #f5f5f5; padding: 15px; border-radius: 5px; font-family: monospace; white-space: pre-wrap; word-break: break-all; }\n';
        $html .= '        .warning { color: #e67e22; background-color: #fff8f0; padding: 5px 10px; border-radius: 3px; }\n';
        $html .= '        .suggestion { color: #27ae60; background-color: #f0fff0; padding: 5px 10px; border-radius: 3px; }\n';
        $html .= '        .severity-high { color: #e74c3c; }\n';
        $html .= '        .severity-medium { color: #f39c12; }\n';
        $html .= '        .severity-low { color: #27ae60; }\n';
        $html .= '        .query-stats { display: flex; gap: 20px; margin-bottom: 10px; }\n';
        $html .= '        .query-stats .stat { font-size: 14px; }\n';
        $html .= '    </style>\n';
        $html .= '</head>\n';
        $html .= '<body>\n';
        $html .= '    <div class="container">\n';
        $html .= '        <h1>MySQL慢查询分析报告</h1>\n';
        $html .= '        <p>生成时间: ' . $analysisResults['analysis_time'] . '</p>\n';
        
        // 摘要统计
        $html .= '        <div class="summary">\n';
        $html .= '            <h2>性能摘要</h2>\n';
        $html .= '            <div class="summary-grid">\n';
        $html .= '                <div class="summary-item">\n';
        $html .= '                    <div class="label">慢查询模式数</div>\n';
        $html .= '                    <div class="value">' . $stats['total_query_patterns'] . '</div>\n';
        $html .= '                </div>\n';
        $html .= '                <div class="summary-item">\n';
        $html .= '                    <div class="label">总执行次数</div>\n';
        $html .= '                    <div class="value">' . number_format($stats['total_executions']) . '</div>\n';
        $html .= '                </div>\n';
        $html .= '                <div class="summary-item">\n';
        $html .= '                    <div class="label">总执行时间</div>\n';
        $html .= '                    <div class="value">' . $stats['total_execution_time'] . 's</div>\n';
        $html .= '                </div>\n';
        $html .= '                <div class="summary-item">\n';
        $html .= '                    <div class="label">平均执行时间</div>\n';
        $html .= '                    <div class="value">' . $stats['avg_execution_time'] . 's</div>\n';
        $html .= '                </div>\n';
        $html .= '                <div class="summary-item">\n';
        $html .= '                    <div class="label">最大执行时间</div>\n';
        $html .= '                    <div class="value">' . $stats['max_execution_time'] . 's</div>\n';
        $html .= '                </div>\n';
        $html .= '                <div class="summary-item">\n';
        $html .= '                    <div class="label">总警告数</div>\n';
        $html .= '                    <div class="value">' . $stats['total_warnings'] . '</div>\n';
        $html .= '                </div>\n';
        $html .= '            </div>\n';
        $html .= '        </div>\n';
        
        // 慢查询详情
        $html .= '        <h2>慢查询详情</h2>\n';
        
        if (empty($slowQueries)) {
            $html .= '        <p>未发现慢查询记录。</p>\n';
        } else {
            foreach ($slowQueries as $index => $query) {
                // 确定严重程度
                $severityClass = 'severity-low';
                if ($query['avg_time'] > 5) {
                    $severityClass = 'severity-high';
                } else if ($query['avg_time'] > 2) {
                    $severityClass = 'severity-medium';
                }
                
                $html .= '        <div class="query-detail">\n';
                $html .= '            <h3>查询 #' . ($index + 1) . ' <span class="' . $severityClass . '">平均执行时间: ' . round($query['avg_time'], 4) . 's</span></h3>\n';
                
                // 查询统计
                $html .= '            <div class="query-stats">\n';
                $html .= '                <div class="stat"><strong>执行次数:</strong> ' . $query['execution_count'] . '</div>\n';
                $html .= '                <div class="stat"><strong>总时间:</strong> ' . round($query['total_time'], 2) . 's</div>\n';
                $html .= '                <div class="stat"><strong>最大时间:</strong> ' . $query['max_time'] . 's</div>\n';
                $html .= '                <div class="stat"><strong>扫描行/返回行:</strong> ' . $query['total_rows_examined'] . '/' . $query['total_rows_sent'] . '</div>\n';
                $html .= '                <div class="stat"><strong>用户:</strong> ' . implode(', ', $query['users']) . '</div>\n';
                $html .= '                <div class="stat"><strong>数据库:</strong> ' . implode(', ', $query['databases']) . '</div>\n';
                $html .= '            </div>\n';
                
                // SQL代码
                $html .= '            <div class="sql-code">' . htmlspecialchars($query['sample_sql']) . '</div>\n';
                
                // 警告
                if (!empty($query['warnings'])) {
                    $html .= '            <h4>警告:</h4>\n';
                    $html .= '            <ul>\n';
                    foreach ($query['warnings'] as $warning) {
                        $html .= '                <li class="warning">' . $warning . '</li>\n';
                    }
                    $html .= '            </ul>\n';
                }
                
                // 建议
                if (!empty($query['suggestions'])) {
                    $html .= '            <h4>优化建议:</h4>\n';
                    $html .= '            <ul>\n';
                    foreach ($query['suggestions'] as $suggestion) {
                        $html .= '                <li class="suggestion">' . $suggestion . '</li>\n';
                    }
                    $html .= '            </ul>\n';
                }
                
                $html .= '        </div>\n';
            }
        }
        
        // 总结和建议
        $html .= '        <h2>总结和建议</h2>\n';
        $html .= '        <div class="summary">\n';
        
        if ($stats['total_query_patterns'] > 0) {
            $html .= '            <ol>\n';
            $html .= '                <li>总共有 ' . $stats['total_query_patterns'] . ' 个慢查询模式，共执行 ' . $stats['total_executions'] . ' 次，消耗了 ' . $stats['total_execution_time'] . ' 秒。</li>\n';
            
            if ($stats['avg_execution_time'] > 2) {
                $html .= '                <li>平均执行时间 ' . $stats['avg_execution_time'] . ' 秒过高，建议优化这些查询。</li>\n';
            }
            
            if ($stats['avg_rows_examined_per_execution'] > 1000) {
                $html .= '                <li>平均每次查询扫描 ' . $stats['avg_rows_examined_per_execution'] . ' 行，可能存在扫描效率问题。</li>\n';
            }
            
            $html .= '                <li>建议优先优化执行时间最长的查询，通常是最有价值的优化点。</li>\n';
            $html .= '                <li>检查所有警告，特别是全表扫描和没有索引的ORDER BY操作。</li>\n';
            $html .= '                <li>考虑增加慢查询日志的采样率以获得更全面的数据。</li>\n';
            $html .= '                <li>定期运行此分析工具以监控性能改进情况。</li>\n';
            $html .= '            </ol>\n';
        } else {
            $html .= '            <p>未发现需要优化的慢查询。请确保MySQL已启用慢查询日志并设置了适当的阈值。</p>\n';
        }
        
        $html .= '        </div>\n';
        
        $html .= '    </div>\n';
        $html .= '</body>\n';
        $html .= '</html>';
        
        return $html;
    }
    
    /**
     * 导出分析结果为JSON格式
     * @param array $analysisResults 分析结果
     * @param string $filePath 文件路径
     * @return bool 导出结果
     */
    public function exportToJson(array $analysisResults, $filePath) {
        try {
            $json = json_encode($analysisResults, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            file_put_contents($filePath, $json);
            $this->logger->info("分析结果已导出到JSON文件: {$filePath}");
            return true;
        } catch (Exception $e) {
            $this->logger->error("导出JSON失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 导出分析结果为HTML格式
     * @param array $analysisResults 分析结果
     * @param string $filePath 文件路径
     * @return bool 导出结果
     */
    public function exportToHtml(array $analysisResults, $filePath) {
        try {
            $html = $this->generateHtmlReport($analysisResults);
            file_put_contents($filePath, $html);
            $this->logger->info("分析结果已导出到HTML文件: {$filePath}");
            return true;
        } catch (Exception $e) {
            $this->logger->error("导出HTML失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查MySQL慢查询日志配置
     * @param PDO $pdo 数据库连接
     * @return array 配置信息
     */
    public function checkSlowQueryConfig(PDO $pdo) {
        try {
            $config = [];
            
            $variables = ['slow_query_log', 'slow_query_log_file', 'long_query_time', 'log_queries_not_using_indexes'];
            
            foreach ($variables as $var) {
                $stmt = $pdo->query("SHOW VARIABLES LIKE '{$var}'");
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($result) {
                    $config[$result['Variable_name']] = $result['Value'];
                }
            }
            
            return $config;
        } catch (Exception $e) {
            $this->logger->error("检查慢查询配置失败: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取索引使用统计信息
     * @param PDO $pdo 数据库连接
     * @return array 索引使用统计
     */
    public function getIndexUsageStats(PDO $pdo) {
        try {
            // 查询索引使用情况
            $stmt = $pdo->query("SELECT object_schema as db, object_name as table_name, index_name, count_star as access_count, count_fetch as fetch_count FROM performance_schema.table_io_waits_summary_by_index_usage WHERE count_star > 0 ORDER BY count_star DESC LIMIT 100");
            $stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $stats;
        } catch (Exception $e) {
            $this->logger->error("获取索引使用统计失败: " . $e->getMessage());
            return [];
        }
    }
}