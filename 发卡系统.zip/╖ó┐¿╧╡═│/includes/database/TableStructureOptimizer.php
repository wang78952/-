<?php
/**
 * 表结构优化工具类
 * 用于分析和优化表结构，减少空间占用，提高查询性能
 */
class TableStructureOptimizer {
    
    /**
     * @var PDO 数据库连接对象
     */
    private $pdo;
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * 构造函数
     * @param PDO $pdo 数据库连接对象
     * @param Logger $logger 日志记录器
     */
    public function __construct(PDO $pdo, Logger $logger) {
        $this->pdo = $pdo;
        $this->logger = $logger;
    }
    
    /**
     * 获取表结构信息
     * @param string $table 表名
     * @return array 表结构信息
     */
    public function getTableStructure($table) {
        $query = "SHOW CREATE TABLE `{$table}`";
        $stmt = $this->pdo->query($query);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return [
            'table' => $table,
            'create_statement' => $result['Create Table'],
            'columns' => $this->getTableColumns($table)
        ];
    }
    
    /**
     * 获取表列信息
     * @param string $table 表名
     * @return array 列信息列表
     */
    public function getTableColumns($table) {
        $query = "SHOW COLUMNS FROM `{$table}`";
        $stmt = $this->pdo->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * 获取表索引信息
     * @param string $table 表名
     * @return array 索引信息列表
     */
    public function getTableIndexes($table) {
        $query = "SHOW INDEX FROM `{$table}`";
        $stmt = $this->pdo->query($query);
        $indexes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 整理索引信息
        $indexGroups = [];
        foreach ($indexes as $index) {
            $indexName = $index['Key_name'];
            if (!isset($indexGroups[$indexName])) {
                $indexGroups[$indexName] = [
                    'name' => $indexName,
                    'unique' => $index['Non_unique'] == 0,
                    'primary' => $indexName === 'PRIMARY',
                    'columns' => [],
                    'seq_in_index' => []
                ];
            }
            
            $indexGroups[$indexName]['columns'][$index['Seq_in_index']] = $index['Column_name'];
            $indexGroups[$indexName]['seq_in_index'][] = $index['Seq_in_index'];
        }
        
        // 确保列按顺序排列
        foreach ($indexGroups as &$group) {
            ksort($group['columns']);
            $group['columns'] = array_values($group['columns']);
        }
        
        return array_values($indexGroups);
    }
    
    /**
     * 分析列类型优化建议
     * @param string $table 表名
     * @return array 优化建议列表
     */
    public function analyzeColumnTypes($table) {
        $columns = $this->getTableColumns($table);
        $suggestions = [];
        
        foreach ($columns as $column) {
            $colName = $column['Field'];
            $colType = $column['Type'];
            $suggestion = $this->getTypeOptimizationSuggestion($table, $colName, $colType);
            
            if ($suggestion) {
                $suggestions[] = array_merge([
                    'table' => $table,
                    'column' => $colName,
                    'current_type' => $colType
                ], $suggestion);
            }
        }
        
        return $suggestions;
    }
    
    /**
     * 获取类型优化建议
     * @param string $table 表名
     * @param string $column 列名
     * @param string $currentType 当前类型
     * @return array|null 优化建议
     */
    private function getTypeOptimizationSuggestion($table, $column, $currentType) {
        try {
            // 跳过某些特殊列
            if (in_array(strtolower($column), ['created_at', 'updated_at', 'deleted_at'])) {
                return null;
            }
            
            // 获取列数据统计信息
            $stats = $this->getColumnStatistics($table, $column);
            if (!$stats) return null;
            
            // 分析不同类型的优化建议
            if (preg_match('/^varchar\((\d+)\)/i', $currentType, $matches)) {
                $currentLength = (int)$matches[1];
                
                // 如果最大长度远小于定义长度，建议缩小
                if ($stats['max_length'] > 0 && $currentLength > $stats['max_length'] * 2) {
                    $suggestedLength = min($stats['max_length'] * 2, $currentLength);
                    return [
                        'suggestion' => '减小VARCHAR长度',
                        'suggested_type' => "VARCHAR({$suggestedLength})",
                        'rationale' => "当前长度({$currentLength})远大于实际最大长度({$stats['max_length']})",
                        'potential_savings' => '减少存储空间和内存使用'
                    ];
                }
            }
            
            // 检查是否可以从TEXT转为VARCHAR
            if (preg_match('/^text$/i', $currentType) && $stats['max_length'] > 0 && $stats['max_length'] <= 1000) {
                $suggestedLength = min($stats['max_length'] * 2, 1000);
                return [
                    'suggestion' => '将TEXT改为VARCHAR',
                    'suggested_type' => "VARCHAR({$suggestedLength})",
                    'rationale' => "TEXT类型数据实际最大长度仅为{$stats['max_length']}",
                    'potential_savings' => '提高查询性能和索引效率'
                ];
            }
            
            // 检查整数类型优化
            if (preg_match('/^int/i', $currentType) && $stats['max_value'] !== null) {
                $suggestedType = $this->suggestIntegerType($stats['min_value'], $stats['max_value']);
                if ($suggestedType && strtolower($suggestedType) !== strtolower($currentType)) {
                    return [
                        'suggestion' => '优化整数类型',
                        'suggested_type' => $suggestedType,
                        'rationale' => "当前使用{$currentType}，但数据范围适合{$suggestedType}",
                        'potential_savings' => '减少存储空间'
                    ];
                }
            }
            
            return null;
        } catch (Exception $e) {
            $this->logger->error("分析列 {$table}.{$column} 时出错: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 获取列统计信息
     * @param string $table 表名
     * @param string $column 列名
     * @return array|null 统计信息
     */
    private function getColumnStatistics($table, $column) {
        try {
            $stats = [];
            
            // 获取最大长度（用于字符串类型）
            $stmt = $this->pdo->query("SELECT MAX(CHAR_LENGTH(`{$column}`)) as max_length FROM `{$table}` WHERE `{$column}` IS NOT NULL");
            $maxLength = $stmt->fetchColumn();
            $stats['max_length'] = $maxLength !== false ? (int)$maxLength : 0;
            
            // 获取值范围（用于数值类型）
            $stmt = $this->pdo->query("SELECT MIN(`{$column}`) as min_value, MAX(`{$column}`) as max_value FROM `{$table}` WHERE `{$column}` IS NOT NULL");
            $range = $stmt->fetch(PDO::FETCH_ASSOC);
            $stats['min_value'] = $range['min_value'] !== null ? $range['min_value'] : null;
            $stats['max_value'] = $range['max_value'] !== null ? $range['max_value'] : null;
            
            // 获取非空值比例
            $stmt = $this->pdo->query("SELECT COUNT(*) as total, SUM(CASE WHEN `{$column}` IS NOT NULL THEN 1 ELSE 0 END) as non_null FROM `{$table}`");
            $nullStats = $stmt->fetch(PDO::FETCH_ASSOC);
            $stats['non_null_ratio'] = $nullStats['total'] > 0 ? ($nullStats['non_null'] / $nullStats['total']) * 100 : 0;
            
            return $stats;
        } catch (Exception $e) {
            $this->logger->warning("获取列 {$table}.{$column} 统计信息失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 根据值范围建议整数类型
     * @param mixed $min 最小值
     * @param mixed $max 最大值
     * @return string|null 建议的整数类型
     */
    private function suggestIntegerType($min, $max) {
        if ($min === null || $max === null) return null;
        
        $min = (int)$min;
        $max = (int)$max;
        
        // 根据范围选择合适的整数类型
        if ($min >= 0) {
            if ($max <= 255) return 'TINYINT UNSIGNED';
            if ($max <= 65535) return 'SMALLINT UNSIGNED';
            if ($max <= 16777215) return 'MEDIUMINT UNSIGNED';
            if ($max <= 4294967295) return 'INT UNSIGNED';
            return 'BIGINT UNSIGNED';
        } else {
            if ($min >= -128 && $max <= 127) return 'TINYINT';
            if ($min >= -32768 && $max <= 32767) return 'SMALLINT';
            if ($min >= -8388608 && $max <= 8388607) return 'MEDIUMINT';
            if ($min >= -2147483648 && $max <= 2147483647) return 'INT';
            return 'BIGINT';
        }
    }
    
    /**
     * 分析索引优化建议
     * @param string $table 表名
     * @return array 索引优化建议
     */
    public function analyzeIndexes($table) {
        $indexes = $this->getTableIndexes($table);
        $suggestions = [];
        
        // 检查重复索引
        $columnSets = [];
        foreach ($indexes as $index) {
            if ($index['primary']) continue;
            
            $columnSet = implode(',', $index['columns']);
            if (!isset($columnSets[$columnSet])) {
                $columnSets[$columnSet] = [];
            }
            $columnSets[$columnSet][] = $index['name'];
        }
        
        foreach ($columnSets as $columns => $indexNames) {
            if (count($indexNames) > 1) {
                $suggestions[] = [
                    'type' => 'remove_duplicate_index',
                    'table' => $table,
                    'columns' => explode(',', $columns),
                    'duplicate_indexes' => $indexNames,
                    'suggestion' => '移除重复索引',
                    'rationale' => '发现多个索引包含相同的列组合：' . implode(', ', $indexNames),
                    'sql' => 'DROP INDEX `' . $indexNames[1] . '` ON `' . $table . '`'
                ];
            }
        }
        
        // 检查可能的索引前缀
        foreach ($indexes as $index) {
            if ($index['primary'] || count($index['columns']) == 1) continue;
            
            // 检查前n-1个列是否已经有索引
            $prefixColumns = array_slice($index['columns'], 0, -1);
            foreach ($indexes as $otherIndex) {
                if ($otherIndex['primary'] || $otherIndex['name'] == $index['name']) continue;
                
                if ($prefixColumns == $otherIndex['columns']) {
                    $suggestions[] = [
                        'type' => 'review_index_usage',
                        'table' => $table,
                        'index' => $index['name'],
                        'prefix_index' => $otherIndex['name'],
                        'suggestion' => '检查索引使用情况',
                        'rationale' => "索引 {$index['name']} 的前缀列已经有索引 {$otherIndex['name']}，可能不需要单独创建",
                        'action' => '分析查询模式，确认是否需要这两个索引'
                    ];
                }
            }
        }
        
        return $suggestions;
    }
    
    /**
     * 执行表结构优化建议
     * @param array $suggestion 优化建议
     * @return bool 执行结果
     */
    public function applySuggestion($suggestion) {
        try {
            $this->logger->info("应用优化建议: {$suggestion['suggestion']} ({$suggestion['table']})");
            
            if (isset($suggestion['sql'])) {
                $this->pdo->exec($suggestion['sql']);
                $this->logger->info("成功执行SQL: {$suggestion['sql']}");
                return true;
            }
            
            // 处理列类型修改建议
            if (isset($suggestion['suggested_type']) && isset($suggestion['column'])) {
                $sql = "ALTER TABLE `{$suggestion['table']}` MODIFY COLUMN `{$suggestion['column']}` {$suggestion['suggested_type']}";
                $this->pdo->exec($sql);
                $this->logger->info("成功修改列类型: {$sql}");
                return true;
            }
            
            return false;
        } catch (Exception $e) {
            $this->logger->error("应用优化建议失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 生成表结构优化报告
     * @param string $table 表名
     * @return string HTML格式的优化报告
     */
    public function generateOptimizationReport($table) {
        $structure = $this->getTableStructure($table);
        $indexes = $this->getTableIndexes($table);
        $columnSuggestions = $this->analyzeColumnTypes($table);
        $indexSuggestions = $this->analyzeIndexes($table);
        
        $html = '<!DOCTYPE html>\n';
        $html .= '<html>\n';
        $html .= '<head>\n';
        $html .= '    <meta charset="UTF-8">\n';
        $html .= '    <title>表结构优化报告 - ' . $table . '</title>\n';
        $html .= '    <style>\n';
        $html .= '        body { font-family: Arial, sans-serif; margin: 20px; }\n';
        $html .= '        h1, h2 { color: #333; }\n';
        $html .= '        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }\n';
        $html .= '        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n';
        $html .= '        th { background-color: #f2f2f2; }\n';
        $html .= '        .suggestion { background-color: #e8f4f8; padding: 10px; margin: 10px 0; border-left: 4px solid #3498db; }\n';
        $html .= '        .code { font-family: monospace; background-color: #f5f5f5; padding: 10px; overflow-x: auto; }\n';
        $html .= '        .info-box { background-color: #f8f8f8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }\n';
        $html .= '        .success { color: green; }\n';
        $html .= '        .warning { color: orange; }\n';
        $html .= '        .critical { color: red; }\n';
        $html .= '    </style>\n';
        $html .= '</head>\n';
        $html .= '<body>\n';
        $html .= '    <h1>表结构优化报告: ' . $table . '</h1>\n';
        
        $html .= '    <div class="info-box">\n';
        $html .= '        <h2>基本信息</h2>\n';
        $html .= '        <p><strong>创建语句:</strong></p>\n';
        $html .= '        <div class="code">' . htmlspecialchars($structure['create_statement']) . '</div>\n';
        $html .= '    </div>\n';
        
        $html .= '    <h2>索引信息</h2>\n';
        $html .= '    <table>\n';
        $html .= '        <tr>\n';
        $html .= '            <th>索引名称</th>\n';
        $html .= '            <th>类型</th>\n';
        $html .= '            <th>列</th>\n';
        $html .= '        </tr>\n';
        
        foreach ($indexes as $index) {
            $type = $index['primary'] ? 'PRIMARY' : ($index['unique'] ? 'UNIQUE' : 'INDEX');
            $html .= "        <tr>\n";
            $html .= "            <td>{$index['name']}</td>\n";
            $html .= "            <td>{$type}</td>\n";
            $html .= "            <td>" . implode(', ', $index['columns']) . "</td>\n";
            $html .= "        </tr>\n";
        }
        $html .= '    </table>\n';
        
        $html .= '    <h2>优化建议</h2>\n';
        
        if (empty($columnSuggestions) && empty($indexSuggestions)) {
            $html .= '    <p class="success">未发现需要优化的问题，表结构看起来良好。</p>\n';
        } else {
            if (!empty($columnSuggestions)) {
                $html .= '    <h3>列类型优化</h3>\n';
                foreach ($columnSuggestions as $suggestion) {
                    $html .= '    <div class="suggestion">\n';
                    $html .= "        <strong>{$suggestion['suggestion']}</strong> ({$suggestion['table']}.{$suggestion['column']})<br>\n";
                    $html .= "        当前类型: {$suggestion['current_type']}<br>\n";
                    $html .= "        建议类型: {$suggestion['suggested_type']}<br>\n";
                    $html .= "        理由: {$suggestion['rationale']}<br>\n";
                    $html .= "        潜在收益: {$suggestion['potential_savings']}<br>\n";
                    $html .= "        SQL: ALTER TABLE `{$suggestion['table']}` MODIFY COLUMN `{$suggestion['column']}` {$suggestion['suggested_type']}<br>\n";
                    $html .= '    </div>\n';
                }
            }
            
            if (!empty($indexSuggestions)) {
                $html .= '    <h3>索引优化</h3>\n';
                foreach ($indexSuggestions as $suggestion) {
                    $html .= '    <div class="suggestion">\n';
                    $html .= "        <strong>{$suggestion['suggestion']}</strong><br>\n";
                    $html .= "        理由: {$suggestion['rationale']}<br>\n";
                    if (isset($suggestion['sql'])) {
                        $html .= "        SQL: {$suggestion['sql']}<br>\n";
                    } else if (isset($suggestion['action'])) {
                        $html .= "        操作建议: {$suggestion['action']}<br>\n";
                    }
                    $html .= '    </div>\n';
                }
            }
        }
        
        $html .= '</body>\n';
        $html .= '</html>';
        
        return $html;
    }
}