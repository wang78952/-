<?php

/**
 * 数据库批量处理器
 * 提供通用的分片执行框架，支持大规模数据操作
 */
class DatabaseBatchProcessor {
    /**
     * 默认配置
     */
    const DEFAULT_CONFIG = [
        'batch_size' => 1000,         // 每批次处理的记录数
        'use_transaction' => true,    // 是否使用事务
        'transaction_batch' => 10,    // 多少批次提交一次事务
        'sleep_ms' => 100,            // 每批次后的休眠时间(毫秒)
        'progress_callback' => null,  // 进度回调函数
        'error_callback' => null,     // 错误回调函数
        'concurrent_limit' => 1,      // 并发处理限制
        'timeout_seconds' => 3600,    // 处理超时时间
    ];
    
    /**
     * 数据库连接
     */
    protected $db;
    
    /**
     * 配置
     */
    protected $config;
    
    /**
     * 统计信息
     */
    protected $stats = [
        'total_records' => 0,
        'processed_records' => 0,
        'success_records' => 0,
        'failed_records' => 0,
        'batches_processed' => 0,
        'start_time' => 0,
        'end_time' => 0,
    ];
    
    /**
     * 构造函数
     * @param mysqli $db 数据库连接
     * @param array $config 配置参数
     */
    public function __construct($db, $config = []) {
        $this->db = $db;
        $this->config = array_merge(self::DEFAULT_CONFIG, $config);
    }
    
    /**
     * 批量查询
     * @param string $sql 查询SQL
     * @param callable $callback 每批次的回调函数
     * @param array $params SQL参数
     * @return array 处理结果
     */
    public function batchQuery($sql, callable $callback, $params = []) {
        $this->initStats();
        
        try {
            // 估算总记录数
            $totalRecords = $this->estimateTotalRecords($sql, $params);
            $this->stats['total_records'] = $totalRecords;
            
            $batchSize = $this->config['batch_size'];
            $processedCount = 0;
            $batchCount = 0;
            
            // 开始事务（如果配置了）
            if ($this->config['use_transaction']) {
                $this->db->begin_transaction();
            }
            
            try {
                // 使用LIMIT和OFFSET进行分页
                while (true) {
                    // 检查超时
                    if ($this->isTimedOut()) {
                        throw new Exception("批量查询超时");
                    }
                    
                    $offset = $processedCount;
                    $batchSql = "{$sql} LIMIT {$batchSize} OFFSET {$offset}";
                    
                    // 执行查询
                    $stmt = $this->prepareAndExecute($batchSql, $params);
                    $result = $stmt->get_result();
                    
                    $records = [];
                    while ($row = $result->fetch_assoc()) {
                        $records[] = $row;
                    }
                    
                    $result->close();
                    $stmt->close();
                    
                    // 如果没有更多记录，结束循环
                    if (empty($records)) {
                        break;
                    }
                    
                    // 调用回调函数处理当前批次
                    $batchResult = call_user_func($callback, $records, $this);
                    
                    // 更新统计信息
                    $processedCount += count($records);
                    $batchCount++;
                    $this->stats['processed_records'] = $processedCount;
                    $this->stats['batches_processed'] = $batchCount;
                    
                    // 提交事务（如果达到了事务批次）
                    if ($this->config['use_transaction'] && $batchCount % $this->config['transaction_batch'] == 0) {
                        $this->db->commit();
                        $this->db->begin_transaction();
                    }
                    
                    // 报告进度
                    $this->reportProgress($processedCount, $totalRecords);
                    
                    // 休眠以减少数据库压力
                    if ($this->config['sleep_ms'] > 0) {
                        usleep($this->config['sleep_ms'] * 1000);
                    }
                }
                
                // 提交最终事务
                if ($this->config['use_transaction']) {
                    $this->db->commit();
                }
                
                $this->stats['end_time'] = microtime(true);
                
                return [
                    'success' => true,
                    'stats' => $this->stats,
                    'message' => "成功处理 {$processedCount} 条记录"
                ];
                
            } catch (Exception $e) {
                // 回滚事务
                if ($this->config['use_transaction']) {
                    $this->db->rollback();
                }
                
                // 调用错误回调
                $this->handleError($e);
                
                return [
                    'success' => false,
                    'stats' => $this->stats,
                    'error' => $e->getMessage()
                ];
            }
            
        } finally {
            $this->cleanup();
        }
    }
    
    /**
     * 批量更新
     * @param string $table 表名
     * @param callable $data_mapper 数据映射函数
     * @param string $condition 条件
     * @param array $params 条件参数
     * @return array 处理结果
     */
    public function batchUpdate($table, callable $data_mapper, $condition = '', $params = []) {
        $conditionClause = $condition ? "WHERE {$condition}" : '';
        $sql = "SELECT * FROM {$table} {$conditionClause}";
        
        return $this->batchQuery($sql, function($records, $processor) use ($table, $data_mapper) {
            foreach ($records as $record) {
                try {
                    // 应用数据映射函数获取更新数据
                    $updateData = call_user_func($data_mapper, $record);
                    
                    if (!empty($updateData)) {
                        // 构建更新SQL
                        $setClauses = [];
                        $updateParams = [];
                        
                        foreach ($updateData as $field => $value) {
                            $setClauses[] = "{$field} = ?";
                            $updateParams[] = $value;
                        }
                        
                        $updateParams[] = $record['id'];
                        $setClause = implode(', ', $setClauses);
                        $updateSql = "UPDATE {$table} SET {$setClause} WHERE id = ?";
                        
                        // 执行更新
                        $stmt = $processor->prepareAndExecute($updateSql, $updateParams);
                        $stmt->close();
                        
                        $processor->stats['success_records']++;
                    }
                } catch (Exception $e) {
                    $processor->stats['failed_records']++;
                    $processor->handleError($e, $record);
                }
            }
        }, $params);
    }
    
    /**
     * 批量删除
     * @param string $table 表名
     * @param string $condition 条件
     * @param array $params 条件参数
     * @return array 处理结果
     */
    public function batchDelete($table, $condition = '', $params = []) {
        $conditionClause = $condition ? "WHERE {$condition}" : '';
        $sql = "SELECT id FROM {$table} {$conditionClause}";
        
        return $this->batchQuery($sql, function($records, $processor) use ($table) {
            if (empty($records)) return;
            
            // 提取ID列表
            $ids = array_column($records, 'id');
            $idList = implode(',', array_map('intval', $ids));
            
            try {
                // 批量删除
                $deleteSql = "DELETE FROM {$table} WHERE id IN ({$idList})";
                $result = $processor->db->query($deleteSql);
                
                if ($result) {
                    $processor->stats['success_records'] += $processor->db->affected_rows;
                } else {
                    $processor->stats['failed_records'] += count($records);
                    $processor->handleError(new Exception("删除失败: " . $processor->db->error), ['ids' => $ids]);
                }
            } catch (Exception $e) {
                $processor->stats['failed_records'] += count($records);
                $processor->handleError($e, ['ids' => $ids]);
            }
        }, $params);
    }
    
    /**
     * 批量插入
     * @param string $table 表名
     * @param array $dataList 数据列表
     * @param bool $ignoreDuplicates 是否忽略重复
     * @return array 处理结果
     */
    public function batchInsert($table, $dataList, $ignoreDuplicates = false) {
        $this->initStats();
        $this->stats['total_records'] = count($dataList);
        
        $batchSize = $this->config['batch_size'];
        $processedCount = 0;
        $batchCount = 0;
        
        // 开始事务
        if ($this->config['use_transaction']) {
            $this->db->begin_transaction();
        }
        
        try {
            while ($processedCount < count($dataList)) {
                // 检查超时
                if ($this->isTimedOut()) {
                    throw new Exception("批量插入超时");
                }
                
                // 获取当前批次数据
                $batchData = array_slice($dataList, $processedCount, $batchSize);
                
                if (empty($batchData)) {
                    break;
                }
                
                // 构建批量插入SQL
                $fields = array_keys($batchData[0]);
                $fieldList = implode(', ', $fields);
                
                // 构建值占位符
                $placeholders = [];
                $values = [];
                
                foreach ($batchData as $record) {
                    $rowPlaceholders = [];
                    foreach ($fields as $field) {
                        $rowPlaceholders[] = '?';
                        $values[] = isset($record[$field]) ? $record[$field] : null;
                    }
                    $placeholders[] = '(' . implode(', ', $rowPlaceholders) . ')';
                }
                
                $placeholderList = implode(', ', $placeholders);
                $ignoreClause = $ignoreDuplicates ? 'IGNORE' : '';
                $insertSql = "INSERT {$ignoreClause} INTO {$table} ({$fieldList}) VALUES {$placeholderList}";
                
                // 执行插入
                $stmt = $this->prepareAndExecute($insertSql, $values);
                $insertedCount = $stmt->affected_rows;
                $stmt->close();
                
                // 更新统计信息
                $processedCount += count($batchData);
                $batchCount++;
                $this->stats['processed_records'] = $processedCount;
                $this->stats['success_records'] += $insertedCount;
                $this->stats['batches_processed'] = $batchCount;
                
                // 提交事务
                if ($this->config['use_transaction'] && $batchCount % $this->config['transaction_batch'] == 0) {
                    $this->db->commit();
                    $this->db->begin_transaction();
                }
                
                // 报告进度
                $this->reportProgress($processedCount, $this->stats['total_records']);
                
                // 休眠
                if ($this->config['sleep_ms'] > 0) {
                    usleep($this->config['sleep_ms'] * 1000);
                }
            }
            
            // 提交最终事务
            if ($this->config['use_transaction']) {
                $this->db->commit();
            }
            
            $this->stats['end_time'] = microtime(true);
            
            return [
                'success' => true,
                'stats' => $this->stats,
                'message' => "成功插入 {$this->stats['success_records']} 条记录"
            ];
            
        } catch (Exception $e) {
            // 回滚事务
            if ($this->config['use_transaction']) {
                $this->db->rollback();
            }
            
            $this->handleError($e);
            
            return [
                'success' => false,
                'stats' => $this->stats,
                'error' => $e->getMessage()
            ];
        } finally {
            $this->cleanup();
        }
    }
    
    /**
     * 主键分片处理
     * @param string $table 表名
     * @param callable $process_func 处理函数
     * @param array $options 选项
     * @return array 处理结果
     */
    public function primaryKeyPartition($table, callable $process_func, $options = []) {
        $this->initStats();
        
        // 获取主键范围
        $result = $this->db->query("SELECT MIN(id) as min_id, MAX(id) as max_id FROM {$table}");
        $range = $result->fetch_assoc();
        $result->close();
        
        if (!$range['min_id']) {
            return ['success' => true, 'message' => '没有记录需要处理'];
        }
        
        $minId = $range['min_id'];
        $maxId = $range['max_id'];
        $batchSize = $this->config['batch_size'];
        $partitions = ceil(($maxId - $minId + 1) / $batchSize);
        
        $this->stats['total_records'] = $maxId - $minId + 1;
        
        for ($i = 0; $i < $partitions; $i++) {
            // 检查超时
            if ($this->isTimedOut()) {
                return [
                    'success' => false,
                    'stats' => $this->stats,
                    'error' => '处理超时'
                ];
            }
            
            $startId = $minId + ($i * $batchSize);
            $endId = min($startId + $batchSize - 1, $maxId);
            
            try {
                // 调用处理函数处理当前分片
                $partitionResult = call_user_func($process_func, $startId, $endId, $this);
                
                if (is_array($partitionResult) && isset($partitionResult['processed'])) {
                    $this->stats['processed_records'] += $partitionResult['processed'];
                }
                
                // 报告进度
                $progress = intval(($i + 1) / $partitions * 100);
                $this->reportProgress($progress, 100, true);
                
                // 休眠
                if ($this->config['sleep_ms'] > 0) {
                    usleep($this->config['sleep_ms'] * 1000);
                }
                
            } catch (Exception $e) {
                $this->handleError($e, ['partition' => $i, 'start_id' => $startId, 'end_id' => $endId]);
                return [
                    'success' => false,
                    'stats' => $this->stats,
                    'error' => $e->getMessage()
                ];
            }
        }
        
        $this->stats['end_time'] = microtime(true);
        
        return [
            'success' => true,
            'stats' => $this->stats,
            'message' => "成功处理所有 {$partitions} 个分片"
        ];
    }
    
    /**
     * 准备并执行SQL
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return mysqli_stmt 预处理语句对象
     */
    public function prepareAndExecute($sql, $params = []) {
        $stmt = $this->db->prepare($sql);
        
        if (!$stmt) {
            throw new Exception("SQL准备失败: " . $this->db->error . "\nSQL: {$sql}");
        }
        
        if (!empty($params)) {
            // 构建参数类型字符串
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
            
            // 绑定参数
            $bindParams = array_merge([$types], $params);
            $bindResult = call_user_func_array([$stmt, 'bind_param'], $this->refValues($bindParams));
            
            if (!$bindResult) {
                throw new Exception("参数绑定失败: " . $stmt->error);
            }
        }
        
        // 执行语句
        if (!$stmt->execute()) {
            throw new Exception("SQL执行失败: " . $stmt->error);
        }
        
        return $stmt;
    }
    
    /**
     * 估算总记录数
     * @param string $sql 查询SQL
     * @param array $params 参数
     * @return int 估算的记录数
     */
    protected function estimateTotalRecords($sql, $params = []) {
        try {
            // 尝试从SQL中提取WHERE子句
            $whereClause = '';
            $fromPos = stripos($sql, 'FROM');
            $wherePos = stripos($sql, 'WHERE');
            $limitPos = stripos($sql, 'LIMIT');
            
            if ($fromPos !== false) {
                $tablePart = substr($sql, $fromPos);
                if ($limitPos !== false) {
                    $tablePart = substr($tablePart, 0, $limitPos - $fromPos);
                }
                
                $whereClause = $wherePos !== false ? substr($sql, $wherePos) : '';
            }
            
            // 构建COUNT查询
            $countSql = "SELECT COUNT(*) as count FROM {$whereClause}";
            $stmt = $this->prepareAndExecute($countSql, $params);
            $result = $stmt->get_result();
            $count = $result->fetch_assoc()['count'];
            $result->close();
            $stmt->close();
            
            return $count;
        } catch (Exception $e) {
            // 如果估算失败，返回一个保守的估计
            return 0;
        }
    }
    
    /**
     * 处理错误
     * @param Exception $e 异常
     * @param array $context 上下文信息
     */
    protected function handleError($e, $context = []) {
        $this->stats['failed_records']++;
        
        // 记录错误日志
        $errorMsg = "数据库处理错误: " . $e->getMessage();
        if (!empty($context)) {
            $errorMsg .= "\n上下文: " . json_encode($context);
        }
        
        error_log($errorMsg);
        
        // 调用错误回调
        if (isset($this->config['error_callback']) && is_callable($this->config['error_callback'])) {
            call_user_func($this->config['error_callback'], $e, $context);
        }
    }
    
    /**
     * 报告进度
     * @param int $processed 已处理数量
     * @param int $total 总数量
     * @param bool $isPercentage 是否已百分比形式
     */
    protected function reportProgress($processed, $total, $isPercentage = false) {
        // 计算进度百分比
        $progress = $isPercentage ? $processed : ($total > 0 ? intval(($processed / $total) * 100) : 0);
        
        // 调用进度回调
        if (isset($this->config['progress_callback']) && is_callable($this->config['progress_callback'])) {
            call_user_func($this->config['progress_callback'], $progress, $processed, $total);
        }
    }
    
    /**
     * 检查是否超时
     * @return bool 是否超时
     */
    protected function isTimedOut() {
        $elapsed = time() - $this->stats['start_time'];
        return $elapsed > $this->config['timeout_seconds'];
    }
    
    /**
     * 初始化统计信息
     */
    protected function initStats() {
        $this->stats = [
            'total_records' => 0,
            'processed_records' => 0,
            'success_records' => 0,
            'failed_records' => 0,
            'batches_processed' => 0,
            'start_time' => time(),
            'end_time' => 0,
        ];
    }
    
    /**
     * 清理资源
     */
    protected function cleanup() {
        // 可以在这里释放资源
    }
    
    /**
     * 获取引用数组（用于call_user_func_array）
     * @param array $arr 原始数组
     * @return array 引用数组
     */
    protected function refValues($arr) {
        $refs = [];
        foreach ($arr as $key => $value) {
            $refs[$key] = &$arr[$key];
        }
        return $refs;
    }
    
    /**
     * 获取统计信息
     * @return array 统计信息
     */
    public function getStats() {
        return $this->stats;
    }
    
    /**
     * 获取处理持续时间
     * @return float 持续时间（秒）
     */
    public function getDuration() {
        $endTime = $this->stats['end_time'] ?: microtime(true);
        return $endTime - $this->stats['start_time'];
    }
}