<?php
/**
 * 数据库维护调度器
 * 自动化定时执行数据库维护任务
 */
class DatabaseMaintenanceScheduler {
    
    /**
     * @var DatabaseConnectionManager 数据库连接管理器
     */
    private $connectionManager;
    
    /**
     * @var DatabaseMaintenance 数据库维护工具
     */
    private $maintenanceTool;
    
    /**
     * @var DatabaseOptimizationAdvisor 性能优化建议工具
     */
    private $advisorTool;
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * @var array 配置参数
     */
    private $config = [
        'schedule_file' => 'database_maintenance_schedule.json',
        'logs_directory' => 'logs/database_maintenance/',
        'email_notifications' => false,
        'email_recipients' => [],
        'maintenance_window' => [
            'start' => '00:00', // 维护窗口开始时间
            'end' => '06:00',   // 维护窗口结束时间
        ],
        'max_execution_time' => 3600, // 最大执行时间（秒）
        'lock_file' => 'database_maintenance.lock',
        'backup_before_maintenance' => true,
        'backup_directory' => 'backups/',
    ];
    
    /**
     * @var array 任务调度配置
     */
    private $schedule = [];
    
    /**
     * @var array 正在执行的任务
     */
    private $runningTasks = [];
    
    /**
     * 构造函数
     * @param DatabaseConnectionManager $connectionManager 数据库连接管理器
     * @param Logger $logger 日志记录器
     * @param array $config 配置参数
     */
    public function __construct(DatabaseConnectionManager $connectionManager, Logger $logger = null, array $config = []) {
        $this->connectionManager = $connectionManager;
        
        // 如果没有日志记录器，创建一个简单的文件日志记录器
        if (!$logger) {
            $logger = new Logger();
        }
        
        $this->logger = $logger;
        $this->config = array_merge($this->config, $config);
        
        // 初始化工具类
        $this->maintenanceTool = new DatabaseMaintenance($connectionManager, $logger);
        $this->advisorTool = new DatabaseOptimizationAdvisor($connectionManager, $logger);
        
        // 确保日志目录存在
        $this->ensureDirectoriesExist();
        
        // 加载调度配置
        $this->loadSchedule();
        
        $this->logger->info("数据库维护调度器初始化成功");
    }
    
    /**
     * 确保必要的目录存在
     */
    private function ensureDirectoriesExist() {
        $directories = [
            $this->config['logs_directory'],
            $this->config['backup_directory'],
        ];
        
        foreach ($directories as $directory) {
            if (!file_exists($directory)) {
                if (mkdir($directory, 0755, true)) {
                    $this->logger->info("创建目录: {$directory}");
                } else {
                    $this->logger->error("无法创建目录: {$directory}");
                }
            }
        }
    }
    
    /**
     * 加载调度配置
     */
    private function loadSchedule() {
        $scheduleFile = $this->config['schedule_file'];
        
        if (file_exists($scheduleFile)) {
            try {
                $content = file_get_contents($scheduleFile);
                $this->schedule = json_decode($content, true);
                $this->logger->info("成功加载调度配置，共加载 " . count($this->schedule) . " 个任务");
            } catch (Exception $e) {
                $this->logger->error("加载调度配置失败: " . $e->getMessage());
                $this->schedule = [];
            }
        } else {
            // 如果配置文件不存在，创建默认配置
            $this->createDefaultSchedule();
        }
    }
    
    /**
     * 创建默认调度配置
     */
    private function createDefaultSchedule() {
        $this->schedule = [
            [
                'id' => 'daily_optimize',
                'name' => '每日索引优化',
                'type' => 'optimize_indexes',
                'schedule' => 'daily', // daily, weekly, monthly
                'time' => '01:00',
                'enabled' => true,
                'params' => [
                    'tables' => [], // 空数组表示所有表
                    'force' => false,
                ],
            ],
            [
                'id' => 'weekly_fragmentation',
                'name' => '每周碎片整理',
                'type' => 'optimize_tablespaces',
                'schedule' => 'weekly',
                'day' => 0, // 0 = Sunday
                'time' => '02:00',
                'enabled' => true,
                'params' => [
                    'threshold' => 10,
                    'max_tables_per_run' => 10,
                ],
            ],
            [
                'id' => 'monthly_analysis',
                'name' => '每月性能分析',
                'type' => 'generate_report',
                'schedule' => 'monthly',
                'day' => 1, // 每月1日
                'time' => '03:00',
                'enabled' => true,
                'params' => [
                    'format' => 'html',
                    'send_email' => true,
                ],
            ],
            [
                'id' => 'daily_backup',
                'name' => '每日数据库备份',
                'type' => 'backup',
                'schedule' => 'daily',
                'time' => '04:00',
                'enabled' => true,
                'params' => [
                    'compress' => true,
                    'keep_days' => 7,
                ],
            ],
        ];
        
        $this->saveSchedule();
        $this->logger->info("已创建默认调度配置");
    }
    
    /**
     * 保存调度配置
     */
    private function saveSchedule() {
        $scheduleFile = $this->config['schedule_file'];
        
        try {
            $content = json_encode($this->schedule, JSON_PRETTY_PRINT);
            file_put_contents($scheduleFile, $content);
            $this->logger->info("调度配置已保存");
        } catch (Exception $e) {
            $this->logger->error("保存调度配置失败: " . $e->getMessage());
        }
    }
    
    /**
     * 运行调度器
     */
    public function run() {
        $this->logger->info("数据库维护调度器开始运行");
        
        // 检查锁文件，避免重复执行
        if (!$this->acquireLock()) {
            $this->logger->warning("调度器已经在运行，退出本次执行");
            return false;
        }
        
        try {
            // 设置最大执行时间
            set_time_limit($this->config['max_execution_time']);
            
            // 检查是否在维护窗口内
            if (!$this->isInMaintenanceWindow()) {
                $this->logger->info("当前不在维护窗口内，跳过任务执行");
                return false;
            }
            
            // 获取需要执行的任务
            $tasksToRun = $this->getTasksToExecute();
            
            $this->logger->info("发现 " . count($tasksToRun) . " 个需要执行的任务");
            
            foreach ($tasksToRun as $task) {
                $this->executeTask($task);
            }
            
            $this->logger->info("调度器执行完成");
            return true;
        } catch (Exception $e) {
            $this->logger->error("调度器执行失败: " . $e->getMessage());
            $this->sendNotification("错误", "数据库维护调度器执行失败: " . $e->getMessage());
            return false;
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 获取需要执行的任务
     * @return array 需要执行的任务列表
     */
    private function getTasksToExecute() {
        $tasks = [];
        $now = new DateTime();
        $currentTime = $now->format('H:i');
        $currentDay = $now->format('w'); // 0-6, 0 = Sunday
        $currentDate = $now->format('d');
        
        foreach ($this->schedule as $task) {
            if (!$task['enabled']) {
                continue;
            }
            
            $shouldExecute = false;
            
            switch ($task['schedule']) {
                case 'daily':
                    // 每日任务
                    if ($task['time'] <= $currentTime && $task['time'] >= substr($currentTime, 0, 2) . ':00') {
                        $shouldExecute = true;
                    }
                    break;
                    
                case 'weekly':
                    // 每周任务
                    if ($task['day'] == $currentDay && $task['time'] <= $currentTime) {
                        $shouldExecute = true;
                    }
                    break;
                    
                case 'monthly':
                    // 每月任务
                    if ($task['day'] == $currentDate && $task['time'] <= $currentTime) {
                        $shouldExecute = true;
                    }
                    break;
            }
            
            if ($shouldExecute) {
                $tasks[] = $task;
            }
        }
        
        return $tasks;
    }
    
    /**
     * 执行单个维护任务
     * @param array $task 任务配置
     */
    private function executeTask(array $task) {
        $taskId = $task['id'];
        $this->logger->info("开始执行任务: {$task['name']} ({$taskId})");
        
        // 记录任务开始
        $this->runningTasks[$taskId] = [
            'name' => $task['name'],
            'start_time' => time(),
            'status' => 'running',
        ];
        
        $taskLogFile = $this->config['logs_directory'] . "task_{$taskId}_{$this->getLogTimestamp()}.log";
        $taskLogger = new Logger($taskLogFile);
        
        try {
            $result = [];
            
            switch ($task['type']) {
                case 'optimize_indexes':
                    $result = $this->executeIndexOptimization($task, $taskLogger);
                    break;
                    
                case 'optimize_tablespaces':
                    $result = $this->executeTablespaceOptimization($task, $taskLogger);
                    break;
                    
                case 'generate_report':
                    $result = $this->executeReportGeneration($task, $taskLogger);
                    break;
                    
                case 'backup':
                    $result = $this->executeDatabaseBackup($task, $taskLogger);
                    break;
                    
                case 'analyze_schema':
                    $result = $this->executeSchemaAnalysis($task, $taskLogger);
                    break;
                    
                default:
                    throw new Exception("未知的任务类型: {$task['type']}");
            }
            
            // 记录任务完成
            $this->runningTasks[$taskId]['end_time'] = time();
            $this->runningTasks[$taskId]['status'] = 'completed';
            $this->runningTasks[$taskId]['result'] = $result;
            
            $executionTime = $this->runningTasks[$taskId]['end_time'] - $this->runningTasks[$taskId]['start_time'];
            
            $this->logger->info("任务 {$task['name']} 执行完成，耗时 " . $this->formatTime($executionTime));
            $taskLogger->info("任务执行完成，耗时 " . $this->formatTime($executionTime));
            
            // 发送完成通知
            $this->sendNotification(
                "任务完成: {$task['name']}",
                "数据库维护任务已成功完成。\n执行时间: " . $this->formatTime($executionTime) . "\n任务类型: {$task['type']}"
            );
            
        } catch (Exception $e) {
            $this->runningTasks[$taskId]['status'] = 'failed';
            $this->runningTasks[$taskId]['error'] = $e->getMessage();
            $this->runningTasks[$taskId]['end_time'] = time();
            
            $this->logger->error("任务 {$task['name']} 执行失败: " . $e->getMessage());
            $taskLogger->error("任务执行失败: " . $e->getMessage());
            
            // 发送错误通知
            $this->sendNotification(
                "错误: 任务 {$task['name']} 执行失败",
                "数据库维护任务执行失败。\n错误信息: {$e->getMessage()}\n任务类型: {$task['type']}",
                'error'
            );
        }
    }
    
    /**
     * 执行索引优化任务
     * @param array $task 任务配置
     * @param Logger $logger 任务日志记录器
     * @return array 执行结果
     */
    private function executeIndexOptimization(array $task, Logger $logger) {
        $params = $task['params'];
        
        $logger->info("开始执行索引优化");
        
        $result = $this->maintenanceTool->optimizeIndexes(
            $params['tables'],
            $params['force'],
            $logger
        );
        
        $logger->info("索引优化完成，优化了 " . count($result['optimized']) . " 个表");
        
        return $result;
    }
    
    /**
     * 执行表空间优化任务
     * @param array $task 任务配置
     * @param Logger $logger 任务日志记录器
     * @return array 执行结果
     */
    private function executeTablespaceOptimization(array $task, Logger $logger) {
        $params = $task['params'];
        
        $logger->info("开始执行表空间优化，碎片阈值: {$params['threshold']}%");
        
        // 首先分析碎片情况
        $fragmentationResult = $this->maintenanceTool->analyzeFragmentation();
        
        // 筛选需要优化的表
        $tablesToOptimize = [];
        foreach ($fragmentationResult['tables'] as $table) {
            if ($table['fragmentation'] >= $params['threshold']) {
                $tablesToOptimize[] = $table['name'];
            }
        }
        
        $logger->info("发现 " . count($tablesToOptimize) . " 个表需要碎片整理");
        
        // 限制每次运行的表数量
        if (!empty($tablesToOptimize) && $params['max_tables_per_run'] > 0) {
            $tablesToOptimize = array_slice($tablesToOptimize, 0, $params['max_tables_per_run']);
            $logger->info("本次运行将优化 " . count($tablesToOptimize) . " 个表");
        }
        
        $result = $this->maintenanceTool->optimizeTablespaces(
            $tablesToOptimize,
            $logger
        );
        
        $logger->info("表空间优化完成，优化了 " . count($result['optimized']) . " 个表");
        
        return $result;
    }
    
    /**
     * 执行性能报告生成任务
     * @param array $task 任务配置
     * @param Logger $logger 任务日志记录器
     * @return array 执行结果
     */
    private function executeReportGeneration(array $task, Logger $logger) {
        $params = $task['params'];
        
        $logger->info("开始生成性能优化报告");
        
        // 清除缓存以获取最新数据
        $this->advisorTool->clearCache();
        
        // 生成报告
        $report = $this->advisorTool->getOptimizationReport();
        
        // 保存报告文件
        $reportFilename = $this->config['logs_directory'] . 
                         "performance_report_{$this->getLogTimestamp()}." . 
                         ($params['format'] == 'json' ? 'json' : 'html');
        
        if ($params['format'] == 'json') {
            $content = json_encode($report, JSON_PRETTY_PRINT);
            file_put_contents($reportFilename, $content);
        } else {
            $content = $this->advisorTool->generateHtmlReport();
            file_put_contents($reportFilename, $content);
        }
        
        $logger->info("性能报告已保存: {$reportFilename}");
        
        // 发送邮件（如果配置）
        if ($params['send_email'] && $this->config['email_notifications']) {
            $this->sendReportEmail($reportFilename, $report);
        }
        
        return [
            'report_file' => $reportFilename,
            'report_size' => filesize($reportFilename),
            'recommendations_count' => count($report['recommendations']),
        ];
    }
    
    /**
     * 执行数据库备份任务
     * @param array $task 任务配置
     * @param Logger $logger 任务日志记录器
     * @return array 执行结果
     */
    private function executeDatabaseBackup(array $task, Logger $logger) {
        $params = $task['params'];
        
        $logger->info("开始执行数据库备份");
        
        // 获取数据库信息
        $serverInfo = $this->connectionManager->getServerInfo();
        $dbname = $serverInfo['database'];
        
        // 生成备份文件名
        $timestamp = $this->getLogTimestamp();
        $backupFilename = $this->config['backup_directory'] . 
                         "{$dbname}_backup_{$timestamp}." . 
                         ($params['compress'] ? 'sql.gz' : 'sql');
        
        // 执行备份
        try {
            $this->createBackup($backupFilename, $params['compress'], $logger);
            
            $logger->info("数据库备份完成，文件: {$backupFilename}");
            
            // 清理旧备份
            if ($params['keep_days'] > 0) {
                $this->cleanupOldBackups($params['keep_days'], $logger);
            }
            
            return [
                'backup_file' => $backupFilename,
                'backup_size' => filesize($backupFilename),
                'timestamp' => $timestamp,
            ];
        } catch (Exception $e) {
            $logger->error("数据库备份失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 执行数据库架构分析任务
     * @param array $task 任务配置
     * @param Logger $logger 任务日志记录器
     * @return array 执行结果
     */
    private function executeSchemaAnalysis(array $task, Logger $logger) {
        $logger->info("开始执行数据库架构分析");
        
        // 使用优化建议工具进行架构分析
        $analysis = $this->advisorTool->getOptimizationReport(['indexes' => true, 'tablespaces' => true]);
        
        $logger->info("数据库架构分析完成，发现 " . 
                     count($analysis['recommendations']) . " 条建议");
        
        return [
            'analysis_result' => $analysis,
            'issues_found' => count($analysis['recommendations']),
        ];
    }
    
    /**
     * 创建数据库备份
     * @param string $filename 备份文件名
     * @param bool $compress 是否压缩
     * @param Logger $logger 日志记录器
     */
    private function createBackup($filename, $compress, Logger $logger) {
        // 获取数据库连接信息
        $config = $this->connectionManager->getConfig();
        
        // 在实际环境中，这里应该调用系统的mysqldump命令
        // 这里为了演示，我们使用PHP代码模拟备份
        
        $logger->info("模拟创建数据库备份: {$filename}");
        
        // 模拟备份内容
        $backupContent = "-- Database Backup for {$config['dbname']}\n";
        $backupContent .= "-- Generated on " . date('Y-m-d H:i:s') . "\n\n";
        
        // 获取所有表
        $tables = $this->connectionManager->executeQuery("SHOW TABLES");
        
        foreach ($tables as $tableRow) {
            $tableName = reset($tableRow);
            
            $backupContent .= "-- Table structure for table {$tableName}\n";
            $backupContent .= "DROP TABLE IF EXISTS {$tableName};\n";
            
            // 获取表结构
            $createTable = $this->connectionManager->executeQuery(
                "SHOW CREATE TABLE {$tableName}"
            );
            
            if (!empty($createTable)) {
                $createInfo = reset($createTable);
                $backupContent .= $createInfo['Create Table'] . ";\n\n";
            }
            
            // 记录数据备份开始
            $backupContent .= "-- Data for table {$tableName}\n";
            $backupContent .= "INSERT INTO {$tableName} VALUES (/* Data backup would be here */);\n\n";
        }
        
        // 保存备份文件
        if ($compress) {
            // 使用gzip压缩
            $gzFile = gzopen($filename, 'w9');
            gzwrite($gzFile, $backupContent);
            gzclose($gzFile);
        } else {
            file_put_contents($filename, $backupContent);
        }
        
        $logger->info("备份文件已创建: {$filename}");
    }
    
    /**
     * 清理旧备份文件
     * @param int $keepDays 保留天数
     * @param Logger $logger 日志记录器
     */
    private function cleanupOldBackups($keepDays, Logger $logger) {
        $backupDir = $this->config['backup_directory'];
        $thresholdTime = time() - ($keepDays * 24 * 60 * 60);
        
        $logger->info("开始清理 {$keepDays} 天前的备份文件");
        
        try {
            $files = glob($backupDir . '*.{sql,sql.gz}', GLOB_BRACE);
            $deletedCount = 0;
            
            foreach ($files as $file) {
                if (filemtime($file) < $thresholdTime) {
                    unlink($file);
                    $deletedCount++;
                    $logger->info("已删除旧备份文件: {$file}");
                }
            }
            
            $logger->info("清理完成，共删除 {$deletedCount} 个旧备份文件");
        } catch (Exception $e) {
            $logger->error("备份清理失败: " . $e->getMessage());
        }
    }
    
    /**
     * 检查是否在维护窗口内
     * @return bool 是否在维护窗口内
     */
    private function isInMaintenanceWindow() {
        $now = new DateTime();
        $currentTime = $now->format('H:i');
        
        $startTime = $this->config['maintenance_window']['start'];
        $endTime = $this->config['maintenance_window']['end'];
        
        // 如果开始时间小于结束时间，说明在同一天内
        if ($startTime < $endTime) {
            return $currentTime >= $startTime && $currentTime <= $endTime;
        } else {
            // 如果开始时间大于结束时间，说明跨天
            return $currentTime >= $startTime || $currentTime <= $endTime;
        }
    }
    
    /**
     * 获取日志时间戳
     * @return string 格式化的时间戳
     */
    private function getLogTimestamp() {
        return date('Ymd_His');
    }
    
    /**
     * 格式化时间
     * @param int $seconds 秒数
     * @return string 格式化后的时间字符串
     */
    private function formatTime($seconds) {
        if ($seconds < 60) {
            return "{$seconds}秒";
        } else if ($seconds < 3600) {
            return round($seconds / 60, 1) . "分钟";
        } else {
            return round($seconds / 3600, 2) . "小时";
        }
    }
    
    /**
     * 发送通知
     * @param string $subject 主题
     * @param string $message 消息内容
     * @param string $type 类型 (info/error/warning)
     */
    private function sendNotification($subject, $message, $type = 'info') {
        if ($this->config['email_notifications'] && !empty($this->config['email_recipients'])) {
            // 在实际环境中，这里应该发送邮件通知
            $this->logger->info("[邮件通知] 发送邮件: {$subject}\n{$message}");
        }
        
        // 记录到日志
        $logMethod = $type == 'error' ? 'error' : ($type == 'warning' ? 'warning' : 'info');
        $this->logger->{$logMethod}("[通知] {$subject}\n{$message}");
    }
    
    /**
     * 发送报告邮件
     * @param string $reportFile 报告文件路径
     * @param array $report 报告数据
     */
    private function sendReportEmail($reportFile, $report) {
        // 在实际环境中，这里应该发送带有附件的邮件
        $this->logger->info("[邮件通知] 发送性能报告邮件，包含报告文件: {$reportFile}");
    }
    
    /**
     * 获取运行中的任务状态
     * @return array 任务状态
     */
    public function getRunningTasks() {
        return $this->runningTasks;
    }
    
    /**
     * 获取调度配置
     * @return array 调度配置
     */
    public function getSchedule() {
        return $this->schedule;
    }
    
    /**
     * 添加新任务到调度配置
     * @param array $task 任务配置
     */
    public function addTask(array $task) {
        // 确保任务有ID
        if (!isset($task['id'])) {
            $task['id'] = 'task_' . uniqid();
        }
        
        // 检查任务是否已存在
        foreach ($this->schedule as &$existingTask) {
            if ($existingTask['id'] == $task['id']) {
                $existingTask = $task;
                $this->saveSchedule();
                $this->logger->info("已更新任务: {$task['id']}");
                return;
            }
        }
        
        // 添加新任务
        $this->schedule[] = $task;
        $this->saveSchedule();
        $this->logger->info("已添加新任务: {$task['id']}");
    }
    
    /**
     * 移除任务
     * @param string $taskId 任务ID
     */
    public function removeTask($taskId) {
        $newSchedule = [];
        
        foreach ($this->schedule as $task) {
            if ($task['id'] != $taskId) {
                $newSchedule[] = $task;
            }
        }
        
        if (count($newSchedule) != count($this->schedule)) {
            $this->schedule = $newSchedule;
            $this->saveSchedule();
            $this->logger->info("已移除任务: {$taskId}");
        }
    }
    
    /**
     * 手动执行任务
     * @param string $taskId 任务ID
     */
    public function runTask($taskId) {
        foreach ($this->schedule as $task) {
            if ($task['id'] == $taskId) {
                $this->logger->info("手动执行任务: {$task['name']}");
                $this->executeTask($task);
                return;
            }
        }
        
        throw new Exception("任务不存在: {$taskId}");
    }
    
    /**
     * 获取调度器状态
     * @return array 状态信息
     */
    public function getStatus() {
        $activeTasks = array_filter($this->runningTasks, function($task) {
            return $task['status'] == 'running';
        });
        
        $completedTasks = array_filter($this->runningTasks, function($task) {
            return $task['status'] == 'completed';
        });
        
        $failedTasks = array_filter($this->runningTasks, function($task) {
            return $task['status'] == 'failed';
        });
        
        return [
            'total_tasks' => count($this->schedule),
            'enabled_tasks' => count(array_filter($this->schedule, function($task) {
                return $task['enabled'];
            })),
            'active_tasks' => count($activeTasks),
            'completed_tasks' => count($completedTasks),
            'failed_tasks' => count($failedTasks),
            'in_maintenance_window' => $this->isInMaintenanceWindow(),
            'last_run' => isset($this->runningTasks) ? max(array_column($this->runningTasks, 'start_time', 0)) : 0,
        ];
    }
    
    /**
     * 设置配置参数
     * @param array $config 配置参数
     */
    public function setConfig(array $config) {
        $this->config = array_merge($this->config, $config);
        $this->logger->info("调度器配置已更新");
    }
    
    /**
     * 获取配置参数
     * @return array 配置参数
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 检查调度器是否正在运行（通过锁文件）
     * @return bool 是否正在运行
     */
    public function isRunning() {
        return file_exists($this->config['lock_file']);
    }
    
    /**
     * 获取锁
     * @return bool 是否成功获取锁
     */
    private function acquireLock() {
        $lockFile = $this->config['lock_file'];
        
        if (file_exists($lockFile)) {
            // 检查锁文件的时间戳，避免死锁
            $lockTime = filectime($lockFile);
            if (time() - $lockTime > $this->config['max_execution_time'] * 2) {
                $this->logger->warning("检测到过期的锁文件，已移除");
                unlink($lockFile);
            } else {
                return false;
            }
        }
        
        // 创建锁文件
        $fp = fopen($lockFile, 'w');
        if ($fp) {
            fwrite($fp, time());
            fclose($fp);
            return true;
        }
        
        return false;
    }
    
    /**
     * 释放锁
     */
    private function releaseLock() {
        $lockFile = $this->config['lock_file'];
        
        if (file_exists($lockFile)) {
            unlink($lockFile);
        }
    }
    
    /**
     * 生成命令行执行脚本
     * @return string 命令行脚本内容
     */
    public function generateCommandLineScript() {
        $script = '#!/usr/bin/env php
';
        $script .= '<?php
';
        $script .= '// 数据库维护调度器命令行执行脚本
';
        $script .= '\n';
        $script .= 'require_once "includes/database/DatabaseConnectionManager.php";
';
        $script .= 'require_once "includes/database/DatabaseMaintenance.php";
';
        $script .= 'require_once "includes/database/DatabaseOptimizationAdvisor.php";
';
        $script .= 'require_once "includes/database/DatabaseMaintenanceScheduler.php";
';
        $script .= 'require_once "includes/logger/Logger.php"; // 假设有一个Logger类
';
        $script .= '\n';
        $script .= '// 初始化连接管理器
';
        $script .= '$config = [
';
        $script .= '    "host" => "localhost",
';
        $script .= '    "port" => 3306,
';
        $script .= '    "dbname" => "your_database",
';
        $script .= '    "username" => "your_username",
';
        $script .= '    "password" => "your_password",
';
        $script .= '];
';
        $script .= '\n';
        $script .= '$connectionManager = DatabaseConnectionManager::getInstance($config);
';
        $script .= '$logger = new Logger("logs/maintenance_scheduler.log");
';
        $script .= '\n';
        $script .= '// 初始化调度器
';
        $script .= '$scheduler = new DatabaseMaintenanceScheduler($connectionManager, $logger, [
';
        $script .= '    "logs_directory" => "logs/database_maintenance/",
';
        $script .= '    "backup_directory" => "backups/",
';
        $script .= '    "email_notifications" => true,
';
        $script .= '    "email_recipients" => ["admin@example.com"],
';
        $script .= ']);
';
        $script .= '\n';
        $script .= '// 处理命令行参数
';
        $script .= '$options = getopt("t::l::s", ["task::", "list", "status"]);
';
        $script .= '\n';
        $script .= 'if (isset($options["list"])) {
';
        $script .= '    // 列出所有任务
';
        $script .= '    $tasks = $scheduler->getSchedule();
';
        $script .= '    echo "数据库维护任务列表:\n";
';
        $script .= '    foreach ($tasks as $task) {
';
        $script .= '        echo "- {$task["id"]}: {$task["name"]} (" . 
';
        $script .= '             ($task["enabled"] ? "Enabled" : "Disabled") . ")\n";
';
        $script .= '        echo "  Schedule: {$task["schedule"]} at {$task["time"]}\n";
';
        $script .= '    }
';
        $script .= '} elseif (isset($options["status"])) {
';
        $script .= '    // 显示状态
';
        $script .= '    $status = $scheduler->getStatus();
';
        $script .= '    echo "调度器状态:\n";
';
        $script .= '    echo "Total tasks: {$status["total_tasks"]}\n";
';
        $script .= '    echo "Enabled tasks: {$status["enabled_tasks"]}\n";
';
        $script .= '    echo "Active tasks: {$status["active_tasks"]}\n";
';
        $script .= '    echo "Completed tasks: {$status["completed_tasks"]}\n";
';
        $script .= '    echo "Failed tasks: {$status["failed_tasks"]}\n";
';
        $script .= '    echo "In maintenance window: " . ($status["in_maintenance_window"] ? "Yes" : "No") . "\n";
';
        $script .= '} elseif (isset($options["task"])) {
';
        $script .= '    // 手动执行任务
';
        $taskId = $options["task"];
        $script .= '    echo "手动执行任务: {$taskId}\n";
';
        $script .= '    try {
';
        $script .= '        $scheduler->runTask($taskId);
';
        $script .= '        echo "任务执行完成\n";
';
        $script .= '    } catch (Exception $e) {
';
        $script .= '        echo "错误: {$e->getMessage()}\n";
';
        $script .= '        exit(1);
';
        $script .= '    }
';
        $script .= '} else {
';
        $script .= '    // 运行调度器
';
        $script .= '    echo "启动数据库维护调度器...\n";
';
        $script .= '    if ($scheduler->isRunning()) {
';
        $script .= '        echo "调度器已经在运行\n";
';
        $script .= '        exit(1);
';
        $script .= '    }
';
        $script .= '    \n';
        $script .= '    $result = $scheduler->run();
';
        $script .= '    echo $result ? "调度器执行成功\n" : "调度器执行失败\n";
';
        $script .= '    exit($result ? 0 : 1);
';
        $script .= '}
';
        $script .= '\n';
        $script .= 'exit(0);
';
        $script .= '?>';
        
        return $script;
    }
}