<?php
/**
 * 数据库性能优化建议工具
 * 分析数据库性能状况，提供优化建议
 */
class DatabaseOptimizationAdvisor {
    
    /**
     * @var DatabaseConnectionManager 数据库连接管理器
     */
    private $connectionManager;
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * @var array 分析结果缓存
     */
    private $analysisCache = [];
    
    /**
     * @var array 配置参数
     */
    private $config = [
        'slow_query_threshold' => 1, // 秒
        'large_table_threshold' => 100000, // 记录数
        'index_coverage_threshold' => 0.6, // 60%
        'fragmentation_threshold' => 10, // 10%
        'cache_ttl' => 300, // 5分钟
    ];
    
    /**
     * 构造函数
     * @param DatabaseConnectionManager $connectionManager 数据库连接管理器
     * @param Logger $logger 日志记录器
     * @param array $config 配置参数
     */
    public function __construct(DatabaseConnectionManager $connectionManager, Logger $logger = null, array $config = []) {
        $this->connectionManager = $connectionManager;
        
        // 如果没有日志记录器，创建一个简单的文件日志记录器
        if (!$logger) {
            $logger = new Logger();
        }
        
        $this->logger = $logger;
        $this->config = array_merge($this->config, $config);
        
        $this->logger->info("数据库性能优化建议工具初始化成功");
    }
    
    /**
     * 获取完整的性能优化报告
     * @param array $options 分析选项
     * @return array 优化报告
     */
    public function getOptimizationReport(array $options = []) {
        $report = [
            'timestamp' => date('Y-m-d H:i:s'),
            'server_info' => $this->connectionManager->getServerInfo(),
            'recommendations' => [],
            'severity_summary' => ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0],
            'analysis_details' => [],
        ];
        
        try {
            // 表空间分析
            if (empty($options) || isset($options['tablespaces'])) {
                $tablespaceAnalysis = $this->analyzeTablespaces();
                $report['analysis_details']['tablespaces'] = $tablespaceAnalysis;
                $report['recommendations'] = array_merge($report['recommendations'], $tablespaceAnalysis['recommendations']);
            }
            
            // 索引分析
            if (empty($options) || isset($options['indexes'])) {
                $indexAnalysis = $this->analyzeIndexes();
                $report['analysis_details']['indexes'] = $indexAnalysis;
                $report['recommendations'] = array_merge($report['recommendations'], $indexAnalysis['recommendations']);
            }
            
            // 查询性能分析
            if (empty($options) || isset($options['queries'])) {
                $queryAnalysis = $this->analyzeQueryPerformance();
                $report['analysis_details']['queries'] = $queryAnalysis;
                $report['recommendations'] = array_merge($report['recommendations'], $queryAnalysis['recommendations']);
            }
            
            // 服务器配置分析
            if (empty($options) || isset($options['config'])) {
                $configAnalysis = $this->analyzeServerConfiguration();
                $report['analysis_details']['configuration'] = $configAnalysis;
                $report['recommendations'] = array_merge($report['recommendations'], $configAnalysis['recommendations']);
            }
            
            // 统计建议严重性
            foreach ($report['recommendations'] as $recommendation) {
                if (isset($report['severity_summary'][$recommendation['severity']])) {
                    $report['severity_summary'][$recommendation['severity']]++;
                }
            }
            
            // 按严重性排序建议
            usort($report['recommendations'], function($a, $b) {
                $severityOrder = ['critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1];
                return $severityOrder[$b['severity']] - $severityOrder[$a['severity']];
            });
            
            $this->logger->info("性能优化报告生成成功，共生成 " . count($report['recommendations']) . " 条建议");
            return $report;
        } catch (Exception $e) {
            $this->logger->error("生成性能优化报告失败: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 分析表空间情况
     * @return array 表空间分析结果
     */
    private function analyzeTablespaces() {
        $cacheKey = 'tablespace_analysis';
        
        // 检查缓存
        if ($this->isCacheValid($cacheKey)) {
            return $this->analysisCache[$cacheKey];
        }
        
        $result = [
            'tables' => [],
            'recommendations' => [],
        ];
        
        try {
            // 获取表信息
            $tables = $this->connectionManager->executeQuery("SHOW TABLE STATUS");
            
            foreach ($tables as $table) {
                $tableInfo = [
                    'name' => $table['Name'],
                    'engine' => $table['Engine'],
                    'rows' => $table['Rows'],
                    'data_size' => $table['Data_length'],
                    'index_size' => $table['Index_length'],
                    'fragmentation' => $this->calculateFragmentation($table),
                    'auto_increment' => $table['Auto_increment'],
                    'collation' => $table['Collation'],
                    'row_format' => $table['Row_format'],
                ];
                
                $result['tables'][] = $tableInfo;
                
                // 检查碎片
                if ($tableInfo['fragmentation'] > $this->config['fragmentation_threshold']) {
                    $result['recommendations'][] = [
                        'type' => 'fragmentation',
                        'severity' => 'medium',
                        'target' => $tableInfo['name'],
                        'description' => "表 {$tableInfo['name']} 碎片率过高 (" . round($tableInfo['fragmentation'], 2) . "%)",
                        'suggestion' => "执行 OPTIMIZE TABLE {$tableInfo['name']} 来减少碎片",
                        'current_value' => round($tableInfo['fragmentation'], 2) . '%',
                        'recommended_value' => '<' . $this->config['fragmentation_threshold'] . '%',
                    ];
                }
                
                // 检查大表
                if ($tableInfo['rows'] > $this->config['large_table_threshold']) {
                    $result['recommendations'][] = [
                        'type' => 'large_table',
                        'severity' => 'medium',
                        'target' => $tableInfo['name'],
                        'description' => "表 {$tableInfo['name']} 数据量较大 (" . $this->formatNumber($tableInfo['rows']) . " 条记录)",
                        'suggestion' => "考虑对表进行分区，或优化查询，添加适当的索引",
                        'current_value' => $this->formatNumber($tableInfo['rows']) . ' 记录',
                        'recommended_value' => "考虑表分区",
                    ];
                }
                
                // 检查存储引擎
                if ($tableInfo['engine'] == 'MyISAM') {
                    $result['recommendations'][] = [
                        'type' => 'storage_engine',
                        'severity' => 'high',
                        'target' => $tableInfo['name'],
                        'description' => "表 {$tableInfo['name']} 使用 MyISAM 存储引擎",
                        'suggestion' => "考虑迁移到 InnoDB 引擎以获得更好的事务支持和并发性能",
                        'current_value' => 'MyISAM',
                        'recommended_value' => 'InnoDB',
                    ];
                }
                
                // 检查行格式
                if ($tableInfo['row_format'] == 'Compact' && $tableInfo['rows'] > 10000) {
                    $result['recommendations'][] = [
                        'type' => 'row_format',
                        'severity' => 'low',
                        'target' => $tableInfo['name'],
                        'description' => "表 {$tableInfo['name']} 使用 Compact 行格式",
                        'suggestion' => "考虑使用 Dynamic 行格式以获得更好的存储效率",
                        'current_value' => 'Compact',
                        'recommended_value' => 'Dynamic',
                    ];
                }
            }
            
            // 缓存结果
            $this->cacheAnalysisResult($cacheKey, $result);
            return $result;
        } catch (Exception $e) {
            $this->logger->error("表空间分析失败: " . $e->getMessage());
            return $result;
        }
    }
    
    /**
     * 分析索引使用情况
     * @return array 索引分析结果
     */
    private function analyzeIndexes() {
        $cacheKey = 'index_analysis';
        
        // 检查缓存
        if ($this->isCacheValid($cacheKey)) {
            return $this->analysisCache[$cacheKey];
        }
        
        $result = [
            'indexes' => [],
            'recommendations' => [],
        ];
        
        try {
            // 获取所有表
            $tables = $this->connectionManager->executeQuery("SHOW TABLES");
            
            foreach ($tables as $tableRow) {
                $tableName = reset($tableRow);
                
                // 获取表索引
                $indexes = $this->connectionManager->executeQuery("SHOW INDEX FROM {$tableName}");
                
                $tableIndexInfo = [
                    'table' => $tableName,
                    'indexes' => [],
                    'index_count' => 0,
                    'primary_key_exists' => false,
                ];
                
                $indexDetails = [];
                foreach ($indexes as $index) {
                    $indexName = $index['Key_name'];
                    
                    if (!isset($indexDetails[$indexName])) {
                        $indexDetails[$indexName] = [
                            'name' => $indexName,
                            'columns' => [],
                            'unique' => ($index['Non_unique'] == 0),
                            'primary' => ($index['Key_name'] == 'PRIMARY'),
                        ];
                    }
                    
                    $indexDetails[$indexName]['columns'][] = [
                        'name' => $index['Column_name'],
                        'cardinality' => $index['Cardinality'],
                        'sub_part' => $index['Sub_part'],
                    ];
                    
                    if ($index['Key_name'] == 'PRIMARY') {
                        $tableIndexInfo['primary_key_exists'] = true;
                    }
                }
                
                $tableIndexInfo['indexes'] = array_values($indexDetails);
                $tableIndexInfo['index_count'] = count($indexDetails);
                
                $result['indexes'][] = $tableIndexInfo;
                
                // 检查主键
                if (!$tableIndexInfo['primary_key_exists']) {
                    $result['recommendations'][] = [
                        'type' => 'missing_primary_key',
                        'severity' => 'high',
                        'target' => $tableName,
                        'description' => "表 {$tableName} 缺少主键",
                        'suggestion' => "为表添加主键以提高查询性能和数据完整性",
                        'current_value' => '无',
                        'recommended_value' => '添加主键',
                    ];
                }
                
                // 分析索引使用情况（通过慢查询日志）
                $this->analyzeIndexUsage($tableName, $result['recommendations']);
                
                // 检查重复索引
                $this->checkDuplicateIndexes($tableIndexInfo, $result['recommendations']);
            }
            
            // 缓存结果
            $this->cacheAnalysisResult($cacheKey, $result);
            return $result;
        } catch (Exception $e) {
            $this->logger->error("索引分析失败: " . $e->getMessage());
            return $result;
        }
    }
    
    /**
     * 分析查询性能
     * @return array 查询性能分析结果
     */
    private function analyzeQueryPerformance() {
        $cacheKey = 'query_performance_analysis';
        
        // 检查缓存
        if ($this->isCacheValid($cacheKey)) {
            return $this->analysisCache[$cacheKey];
        }
        
        $result = [
            'slow_queries' => [],
            'recommendations' => [],
        ];
        
        try {
            // 获取慢查询统计
            $slowQueries = $this->connectionManager->executeQuery("SELECT * FROM mysql.slow_log ORDER BY start_time DESC LIMIT 100");
            
            foreach ($slowQueries as $query) {
                $result['slow_queries'][] = [
                    'query' => $query['sql_text'],
                    'execution_time' => $query['query_time'],
                    'rows_examined' => $query['rows_examined'],
                    'rows_sent' => $query['rows_sent'],
                    'timestamp' => $query['start_time'],
                ];
                
                // 检查是否缺少索引
                if ($query['rows_examined'] > $query['rows_sent'] * 10) {
                    $result['recommendations'][] = [
                        'type' => 'missing_index',
                        'severity' => 'high',
                        'target' => 'query',
                        'description' => "查询检查了过多的行 ({$query['rows_examined']} 检查, {$query['rows_sent']} 返回)",
                        'suggestion' => "考虑为查询添加适当的索引，或优化查询语句",
                        'current_value' => "Examined/Sent ratio: " . round($query['rows_examined'] / max(1, $query['rows_sent']), 2),
                        'recommended_value' => "< 10",
                    ];
                }
            }
            
            // 分析表扫描
            $fullTableScans = $this->connectionManager->executeQuery(
                "SHOW GLOBAL STATUS LIKE 'Handler_read%'"
            );
            
            $scanStats = [];
            foreach ($fullTableScans as $stat) {
                $scanStats[$stat['Variable_name']] = $stat['Value'];
            }
            
            // 计算表扫描比例
            if (isset($scanStats['Handler_read_rnd_next']) && isset($scanStats['Handler_read_key'])) {
                $totalReads = $scanStats['Handler_read_rnd_next'] + $scanStats['Handler_read_key'];
                $tableScanRatio = $scanStats['Handler_read_rnd_next'] / max(1, $totalReads);
                
                if ($tableScanRatio > 0.5) {
                    $result['recommendations'][] = [
                        'type' => 'table_scans',
                        'severity' => 'high',
                        'target' => 'system',
                        'description' => "系统表扫描比例过高 (" . round($tableScanRatio * 100, 2) . "%)",
                        'suggestion' => "检查并优化频繁执行全表扫描的查询，添加适当的索引",
                        'current_value' => round($tableScanRatio * 100, 2) . '%',
                        'recommended_value' => '< 50%',
                    ];
                }
            }
            
            // 缓存结果
            $this->cacheAnalysisResult($cacheKey, $result);
            return $result;
        } catch (Exception $e) {
            $this->logger->error("查询性能分析失败: " . $e->getMessage());
            return $result;
        }
    }
    
    /**
     * 分析服务器配置
     * @return array 服务器配置分析结果
     */
    private function analyzeServerConfiguration() {
        $cacheKey = 'config_analysis';
        
        // 检查缓存
        if ($this->isCacheValid($cacheKey)) {
            return $this->analysisCache[$cacheKey];
        }
        
        $result = [
            'variables' => [],
            'recommendations' => [],
        ];
        
        try {
            // 获取关键系统变量
            $variables = $this->connectionManager->executeQuery(
                "SHOW VARIABLES WHERE Variable_name IN ('innodb_buffer_pool_size', 'key_buffer_size', 'query_cache_size', 'max_connections', 'slow_query_log', 'long_query_time', 'innodb_flush_log_at_trx_commit', 'sync_binlog')"
            );
            
            $varValues = [];
            foreach ($variables as $var) {
                $varValues[$var['Variable_name']] = $var['Value'];
                $result['variables'][] = $var;
            }
            
            // 分析关键配置
            
            // 检查慢查询日志
            if (isset($varValues['slow_query_log']) && $varValues['slow_query_log'] != 'ON') {
                $result['recommendations'][] = [
                    'type' => 'slow_query_log',
                    'severity' => 'medium',
                    'target' => 'server',
                    'description' => "慢查询日志未开启",
                    'suggestion' => "设置 slow_query_log = ON 并调整 long_query_time 以捕获慢查询",
                    'current_value' => 'OFF',
                    'recommended_value' => 'ON',
                ];
            } else if (isset($varValues['long_query_time']) && $varValues['long_query_time'] > $this->config['slow_query_threshold']) {
                $result['recommendations'][] = [
                    'type' => 'slow_query_threshold',
                    'severity' => 'low',
                    'target' => 'server',
                    'description' => "慢查询阈值设置过高 ({$varValues['long_query_time']} 秒)",
                    'suggestion' => "降低 long_query_time 至少于 {$this->config['slow_query_threshold']} 秒以捕获更多潜在问题",
                    'current_value' => $varValues['long_query_time'] . '秒',
                    'recommended_value' => '<' . $this->config['slow_query_threshold'] . '秒',
                ];
            }
            
            // 检查缓冲池大小
            if (isset($varValues['innodb_buffer_pool_size'])) {
                $bufferPoolSize = $this->parseSize($varValues['innodb_buffer_pool_size']);
                $totalMemory = $this->getServerMemory();
                
                if ($totalMemory > 0) {
                    $bufferPoolRatio = $bufferPoolSize / $totalMemory;
                    
                    if ($bufferPoolRatio < 0.5) {
                        $result['recommendations'][] = [
                            'type' => 'buffer_pool_size',
                            'severity' => 'medium',
                            'target' => 'server',
                            'description' => "InnoDB 缓冲池大小过小 (" . round($bufferPoolRatio * 100, 2) . "% 的系统内存)",
                            'suggestion' => "增加 innodb_buffer_pool_size 到系统内存的 50-80% 以提高性能",
                            'current_value' => round($bufferPoolRatio * 100, 2) . '%',
                            'recommended_value' => '50-80%',
                        ];
                    } else if ($bufferPoolRatio > 0.8) {
                        $result['recommendations'][] = [
                            'type' => 'buffer_pool_size',
                            'severity' => 'low',
                            'target' => 'server',
                            'description' => "InnoDB 缓冲池大小较大 (" . round($bufferPoolRatio * 100, 2) . "% 的系统内存)",
                            'suggestion' => "考虑略微减少 innodb_buffer_pool_size 以避免系统内存压力",
                            'current_value' => round($bufferPoolRatio * 100, 2) . '%',
                            'recommended_value' => '< 80%',
                        ];
                    }
                }
            }
            
            // 检查最大连接数
            if (isset($varValues['max_connections']) && $varValues['max_connections'] < 100) {
                $result['recommendations'][] = [
                    'type' => 'max_connections',
                    'severity' => 'low',
                    'target' => 'server',
                    'description' => "最大连接数设置较低 ({$varValues['max_connections']})",
                    'suggestion' => "考虑增加 max_connections 以支持更多并发连接",
                    'current_value' => $varValues['max_connections'],
                    'recommended_value' => '> 100',
                ];
            }
            
            // 检查事务安全设置
            if (isset($varValues['innodb_flush_log_at_trx_commit']) && $varValues['innodb_flush_log_at_trx_commit'] != '1') {
                $result['recommendations'][] = [
                    'type' => 'transaction_safety',
                    'severity' => 'high',
                    'target' => 'server',
                    'description' => "事务安全级别较低 (innodb_flush_log_at_trx_commit = {$varValues['innodb_flush_log_at_trx_commit']})",
                    'suggestion' => "设置 innodb_flush_log_at_trx_commit = 1 以确保完整的事务安全",
                    'current_value' => $varValues['innodb_flush_log_at_trx_commit'],
                    'recommended_value' => '1',
                ];
            }
            
            // 缓存结果
            $this->cacheAnalysisResult($cacheKey, $result);
            return $result;
        } catch (Exception $e) {
            $this->logger->error("服务器配置分析失败: " . $e->getMessage());
            return $result;
        }
    }
    
    /**
     * 计算表碎片率
     * @param array $table 表信息
     * @return float 碎片率百分比
     */
    private function calculateFragmentation($table) {
        $dataSize = $table['Data_length'];
        $indexSize = $table['Index_length'];
        $dataFree = $table['Data_free'];
        
        $totalSize = $dataSize + $indexSize + $dataFree;
        
        if ($totalSize == 0) {
            return 0;
        }
        
        return ($dataFree / $totalSize) * 100;
    }
    
    /**
     * 分析索引使用情况
     * @param string $tableName 表名
     * @param array &$recommendations 建议数组引用
     */
    private function analyzeIndexUsage($tableName, &$recommendations) {
        // 这里可以结合慢查询日志分析索引使用情况
        // 或分析查询执行计划
        
        // 示例：检查表是否有全表扫描的查询
        try {
            $result = $this->connectionManager->executeQuery(
                "EXPLAIN SELECT COUNT(*) FROM {$tableName}"
            );
            
            if (!empty($result)) {
                $explain = reset($result);
                
                if ($explain['type'] == 'ALL') {
                    $recommendations[] = [
                        'type' => 'full_table_scan',
                        'severity' => 'medium',
                        'target' => $tableName,
                        'description' => "表 {$tableName} 可能存在全表扫描操作",
                        'suggestion' => "考虑添加适当的索引以避免全表扫描",
                        'current_value' => 'Using full table scan',
                        'recommended_value' => 'Using index',
                    ];
                }
            }
        } catch (Exception $e) {
            $this->logger->warning("索引使用分析失败: " . $e->getMessage());
        }
    }
    
    /**
     * 检查重复索引
     * @param array $tableIndexInfo 表索引信息
     * @param array &$recommendations 建议数组引用
     */
    private function checkDuplicateIndexes($tableIndexInfo, &$recommendations) {
        $indexes = $tableIndexInfo['indexes'];
        $tableName = $tableIndexInfo['table'];
        
        // 检查是否有冗余索引（前缀相同的索引）
        for ($i = 0; $i < count($indexes); $i++) {
            for ($j = 0; $j < count($indexes); $j++) {
                if ($i == $j) continue;
                
                $index1 = $indexes[$i];
                $index2 = $indexes[$j];
                
                // 跳过主键比较
                if ($index1['primary'] || $index2['primary']) continue;
                
                // 检查index1是否是index2的前缀
                $isPrefix = true;
                if (count($index1['columns']) <= count($index2['columns'])) {
                    for ($k = 0; $k < count($index1['columns']); $k++) {
                        if ($index1['columns'][$k]['name'] != $index2['columns'][$k]['name']) {
                            $isPrefix = false;
                            break;
                        }
                    }
                    
                    if ($isPrefix && !$index1['unique'] && !$index2['unique']) {
                        $recommendations[] = [
                            'type' => 'redundant_index',
                            'severity' => 'low',
                            'target' => $tableName,
                            'description' => "表 {$tableName} 可能存在冗余索引",
                            'suggestion' => "考虑删除索引 {$index1['name']}，因为它是 {$index2['name']} 的前缀",
                            'current_value' => "Indexes: {$index1['name']}, {$index2['name']}",
                            'recommended_value' => "保留 {$index2['name']}",
                        ];
                    }
                }
            }
        }
    }
    
    /**
     * 检查缓存是否有效
     * @param string $key 缓存键
     * @return bool 缓存是否有效
     */
    private function isCacheValid($key) {
        return isset($this->analysisCache[$key]['timestamp']) && 
               (time() - $this->analysisCache[$key]['timestamp']) < $this->config['cache_ttl'];
    }
    
    /**
     * 缓存分析结果
     * @param string $key 缓存键
     * @param array $result 分析结果
     */
    private function cacheAnalysisResult($key, $result) {
        $this->analysisCache[$key] = $result;
        $this->analysisCache[$key]['timestamp'] = time();
    }
    
    /**
     * 清除分析缓存
     */
    public function clearCache() {
        $this->analysisCache = [];
        $this->logger->info("优化建议工具缓存已清除");
    }
    
    /**
     * 格式化数字
     * @param int $number 数字
     * @return string 格式化后的数字
     */
    private function formatNumber($number) {
        if ($number >= 1000000) {
            return round($number / 1000000, 2) . 'M';
        } else if ($number >= 1000) {
            return round($number / 1000, 2) . 'K';
        }
        return $number;
    }
    
    /**
     * 解析大小字符串
     * @param string $sizeStr 大小字符串
     * @return int 字节数
     */
    private function parseSize($sizeStr) {
        $units = ['K' => 1024, 'M' => 1048576, 'G' => 1073741824];
        
        $unit = strtoupper(substr($sizeStr, -1));
        $size = substr($sizeStr, 0, -1);
        
        if (isset($units[$unit])) {
            return $size * $units[$unit];
        }
        
        return (int)$sizeStr;
    }
    
    /**
     * 获取服务器内存（模拟）
     * @return int 内存字节数
     */
    private function getServerMemory() {
        // 在实际环境中，可以通过系统命令或配置获取
        // 这里返回一个默认值（4GB）
        return 4 * 1024 * 1024 * 1024;
    }
    
    /**
     * 生成优化建议报告（HTML格式）
     * @return string HTML报告
     */
    public function generateHtmlReport() {
        $report = $this->getOptimizationReport();
        
        $html = '<!DOCTYPE html>';
        $html .= '<html>';
        $html .= '<head>';
        $html .= '<title>数据库性能优化建议报告</title>';
        $html .= '<style>';
        $html .= 'body { font-family: Arial, sans-serif; margin: 20px; }';
        $html .= 'h1, h2, h3 { color: #333; }';
        $html .= '.summary { background: #f8f8f8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }';
        $html .= '.severity-critical { background: #ffcccc; }';
        $html .= '.severity-high { background: #ffeeee; }';
        $html .= '.severity-medium { background: #ffffcc; }';
        $html .= '.severity-low { background: #f0f0f0; }';
        $html .= '.recommendation { padding: 10px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #333; }';
        $html .= '.details { margin-top: 20px; }';
        $html .= 'table { border-collapse: collapse; width: 100%; margin: 10px 0; }';
        $html .= 'th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }';
        $html .= 'th { background-color: #f2f2f2; }';
        $html .= '.severity-indicator { padding: 3px 8px; border-radius: 10px; font-size: 12px; font-weight: bold; }';
        $html .= '.severity-indicator.critical { background: #ff0000; color: white; }';
        $html .= '.severity-indicator.high { background: #ff6600; color: white; }';
        $html .= '.severity-indicator.medium { background: #ffcc00; color: black; }';
        $html .= '.severity-indicator.low { background: #00cc00; color: white; }';
        $html .= '</style>';
        $html .= '</head>';
        $html .= '<body>';
        
        // 报告标题
        $html .= '<h1>数据库性能优化建议报告</h1>';
        $html .= '<div class="summary">';
        $html .= '<p>生成时间: ' . $report['timestamp'] . '</p>';
        $html .= '<p>数据库服务器: ' . $report['server_info']['server'] . '</p>';
        $html .= '<p>数据库版本: ' . $report['server_info']['full_version'] . '</p>';
        $html .= '<p>发现问题: <span class="severity-indicator critical">严重: ' . $report['severity_summary']['critical'] . '</span> ';
        $html .= '<span class="severity-indicator high">高: ' . $report['severity_summary']['high'] . '</span> ';
        $html .= '<span class="severity-indicator medium">中: ' . $report['severity_summary']['medium'] . '</span> ';
        $html .= '<span class="severity-indicator low">低: ' . $report['severity_summary']['low'] . '</span></p>';
        $html .= '</div>';
        
        // 优化建议
        $html .= '<h2>优化建议</h2>';
        
        foreach ($report['recommendations'] as $recommendation) {
            $html .= '<div class="recommendation severity-' . $recommendation['severity'] . '">';
            $html .= '<h3><span class="severity-indicator ' . $recommendation['severity'] . '">' . 
                     ucfirst($recommendation['severity']) . '</span> ' . 
                     ucfirst($recommendation['type']) . '</h3>';
            $html .= '<p><strong>目标:</strong> ' . $recommendation['target'] . '</p>';
            $html .= '<p><strong>描述:</strong> ' . $recommendation['description'] . '</p>';
            $html .= '<p><strong>建议:</strong> ' . $recommendation['suggestion'] . '</p>';
            $html .= '<p><strong>当前值:</strong> ' . $recommendation['current_value'] . '</p>';
            $html .= '<p><strong>推荐值:</strong> ' . $recommendation['recommended_value'] . '</p>';
            $html .= '</div>';
        }
        
        // 详细分析
        $html .= '<div class="details">';
        $html .= '<h2>详细分析</h2>';
        
        // 表空间分析
        if (isset($report['analysis_details']['tablespaces'])) {
            $html .= '<h3>表空间分析</h3>';
            $html .= '<table>';
            $html .= '<tr><th>表名</th><th>引擎</th><th>记录数</th><th>数据大小</th><th>索引大小</th><th>碎片率</th><th>行格式</th></tr>';
            
            foreach ($report['analysis_details']['tablespaces']['tables'] as $table) {
                $html .= '<tr>';
                $html .= '<td>' . $table['name'] . '</td>';
                $html .= '<td>' . $table['engine'] . '</td>';
                $html .= '<td>' . $this->formatNumber($table['rows']) . '</td>';
                $html .= '<td>' . $this->formatBytes($table['data_size']) . '</td>';
                $html .= '<td>' . $this->formatBytes($table['index_size']) . '</td>';
                $html .= '<td>' . round($table['fragmentation'], 2) . '%</td>';
                $html .= '<td>' . $table['row_format'] . '</td>';
                $html .= '</tr>';
            }
            
            $html .= '</table>';
        }
        
        // 索引分析
        if (isset($report['analysis_details']['indexes'])) {
            $html .= '<h3>索引分析</h3>';
            $html .= '<table>';
            $html .= '<tr><th>表名</th><th>索引数量</th><th>主键存在</th><th>索引详情</th></tr>';
            
            foreach ($report['analysis_details']['indexes']['indexes'] as $table) {
                $indexDetails = [];
                foreach ($table['indexes'] as $index) {
                    $indexType = $index['primary'] ? 'PRIMARY' : ($index['unique'] ? 'UNIQUE' : 'INDEX');
                    $columns = implode(', ', array_column($index['columns'], 'name'));
                    $indexDetails[] = "{$indexType} {$index['name']} ({$columns})";
                }
                
                $html .= '<tr>';
                $html .= '<td>' . $table['table'] . '</td>';
                $html .= '<td>' . $table['index_count'] . '</td>';
                $html .= '<td>' . ($table['primary_key_exists'] ? '是' : '否') . '</td>';
                $html .= '<td>' . implode('<br>', $indexDetails) . '</td>';
                $html .= '</tr>';
            }
            
            $html .= '</table>';
        }
        
        // 服务器配置分析
        if (isset($report['analysis_details']['configuration'])) {
            $html .= '<h3>服务器配置分析</h3>';
            $html .= '<table>';
            $html .= '<tr><th>配置项</th><th>当前值</th></tr>';
            
            foreach ($report['analysis_details']['configuration']['variables'] as $var) {
                $html .= '<tr>';
                $html .= '<td>' . $var['Variable_name'] . '</td>';
                $html .= '<td>' . $var['Value'] . '</td>';
                $html .= '</tr>';
            }
            
            $html .= '</table>';
        }
        
        $html .= '</div>';
        $html .= '</body>';
        $html .= '</html>';
        
        return $html;
    }
    
    /**
     * 格式化字节数
     * @param int $bytes 字节数
     * @return string 格式化后的大小
     */
    private function formatBytes($bytes) {
        if ($bytes == 0) return '0 B';
        
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $unitIndex = floor(log($bytes, 1024));
        
        return round($bytes / pow(1024, $unitIndex), 2) . ' ' . $units[$unitIndex];
    }
    
    /**
     * 设置配置参数
     * @param array $config 配置参数
     */
    public function setConfig(array $config) {
        $this->config = array_merge($this->config, $config);
        $this->clearCache(); // 清除缓存
        $this->logger->info("优化建议工具配置已更新");
    }
    
    /**
     * 获取配置参数
     * @return array 配置参数
     */
    public function getConfig() {
        return $this->config;
    }
}