<?php
/**
 * 数据库维护工具类
 * 用于执行定期数据库维护任务，包括表优化、索引分析等
 */
class DatabaseMaintenance {
    
    /**
     * @var PDO 数据库连接对象
     */
    private $pdo;
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * @var array 维护任务配置
     */
    private $config = [
        'optimize_threshold_mb' => 50, // 表大小超过此值才进行优化（MB）
        'max_concurrent_tables' => 5,  // 最大并发优化表数量
        'exclude_tables' => [],        // 排除的表名列表
    ];
    
    /**
     * 构造函数
     * @param PDO $pdo 数据库连接对象
     * @param Logger $logger 日志记录器
     * @param array $config 可选配置参数
     */
    public function __construct(PDO $pdo, Logger $logger, array $config = []) {
        $this->pdo = $pdo;
        $this->logger = $logger;
        $this->config = array_merge($this->config, $config);
    }
    
    /**
     * 获取所有需要维护的表
     * @param string $database 数据库名
     * @return array 表名列表
     */
    public function getMaintenanceTables($database = null) {
        if (!$database) {
            $stmt = $this->pdo->query('SELECT DATABASE()');
            $database = $stmt->fetchColumn();
        }
        
        $query = "SHOW TABLES FROM `{$database}`";
        $stmt = $this->pdo->query($query);
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // 过滤掉排除的表
        return array_filter($tables, function($table) {
            return !in_array($table, $this->config['exclude_tables']);
        });
    }
    
    /**
     * 分析单个表的状态
     * @param string $table 表名
     * @return array 表状态信息
     */
    public function getTableStatus($table) {
        $stmt = $this->pdo->query("SHOW TABLE STATUS LIKE '{$table}'");
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * 优化单个表
     * @param string $table 表名
     * @return array 优化结果
     */
    public function optimizeTable($table) {
        try {
            $startTime = microtime(true);
            $this->logger->info("开始优化表 {$table}");
            
            // 执行优化表操作
            $stmt = $this->pdo->query("OPTIMIZE TABLE `{$table}`");
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $endTime = microtime(true);
            $duration = round($endTime - $startTime, 2);
            
            $this->logger->info("表 {$table} 优化完成，耗时 {$duration} 秒");
            
            return [
                'table' => $table,
                'success' => true,
                'duration' => $duration,
                'message' => '表优化成功'
            ];
        } catch (Exception $e) {
            $this->logger->error("表 {$table} 优化失败: " . $e->getMessage());
            return [
                'table' => $table,
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 分析索引使用情况
     * @param string $table 表名
     * @return array 索引使用情况
     */
    public function analyzeIndexes($table) {
        try {
            $this->logger->info("开始分析表 {$table} 的索引");
            
            // 执行索引分析
            $stmt = $this->pdo->query("ANALYZE TABLE `{$table}`");
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 获取索引信息
            $indexStmt = $this->pdo->query("SHOW INDEX FROM `{$table}`");
            $indexes = $indexStmt->fetchAll(PDO::FETCH_ASSOC);
            
            $this->logger->info("表 {$table} 索引分析完成，发现 " . count($indexes) . " 个索引");
            
            return [
                'table' => $table,
                'success' => true,
                'indexes' => $indexes
            ];
        } catch (Exception $e) {
            $this->logger->error("表 {$table} 索引分析失败: " . $e->getMessage());
            return [
                'table' => $table,
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 根据表大小筛选需要优化的表
     * @return array 需要优化的表列表
     */
    public function getTablesToOptimize() {
        $tables = $this->getMaintenanceTables();
        $tablesToOptimize = [];
        
        foreach ($tables as $table) {
            $status = $this->getTableStatus($table);
            if ($status) {
                // 计算表大小（MB）
                $tableSizeMB = ($status['Data_length'] + $status['Index_length']) / (1024 * 1024);
                
                // 检查是否需要优化
                if ($tableSizeMB >= $this->config['optimize_threshold_mb']) {
                    $tablesToOptimize[] = [
                        'name' => $table,
                        'size_mb' => round($tableSizeMB, 2),
                        'data_length' => $status['Data_length'],
                        'index_length' => $status['Index_length'],
                        'rows' => $status['Rows'],
                        'engine' => $status['Engine']
                    ];
                }
            }
        }
        
        // 按表大小降序排序
        usort($tablesToOptimize, function($a, $b) {
            return $b['size_mb'] - $a['size_mb'];
        });
        
        return $tablesToOptimize;
    }
    
    /**
     * 执行数据库全面维护
     * @return array 维护结果汇总
     */
    public function performFullMaintenance() {
        $startTime = microtime(true);
        $this->logger->info("开始执行数据库全面维护任务");
        
        // 获取需要优化的表
        $tablesToOptimize = $this->getTablesToOptimize();
        $totalTables = count($tablesToOptimize);
        $optimizeResults = [];
        $analyzeResults = [];
        
        $this->logger->info("发现 {$totalTables} 个需要优化的表");
        
        // 分批次处理表
        $batchCount = ceil($totalTables / $this->config['max_concurrent_tables']);
        
        for ($batch = 0; $batch < $batchCount; $batch++) {
            $start = $batch * $this->config['max_concurrent_tables'];
            $end = $start + $this->config['max_concurrent_tables'];
            $currentBatch = array_slice($tablesToOptimize, $start, $this->config['max_concurrent_tables']);
            
            foreach ($currentBatch as $tableInfo) {
                $table = $tableInfo['name'];
                
                // 先分析索引
                $analyzeResult = $this->analyzeIndexes($table);
                $analyzeResults[] = $analyzeResult;
                
                // 然后优化表
                $optimizeResult = $this->optimizeTable($table);
                $optimizeResults[] = $optimizeResult;
            }
        }
        
        // 统计结果
        $successCount = count(array_filter($optimizeResults, function($r) { return $r['success']; }));
        $failedCount = count(array_filter($optimizeResults, function($r) { return !$r['success']; }));
        
        $endTime = microtime(true);
        $totalDuration = round($endTime - $startTime, 2);
        
        $this->logger->info("数据库维护完成: 成功 {$successCount}, 失败 {$failedCount}, 总耗时 {$totalDuration} 秒");
        
        return [
            'total_tables' => $totalTables,
            'success_count' => $successCount,
            'failed_count' => $failedCount,
            'total_duration' => $totalDuration,
            'optimize_results' => $optimizeResults,
            'analyze_results' => $analyzeResults
        ];
    }
    
    /**
     * 获取数据库碎片信息
     * @return array 表碎片信息列表
     */
    public function getTableFragmentation() {
        $tables = $this->getMaintenanceTables();
        $fragmentationInfo = [];
        
        foreach ($tables as $table) {
            $status = $this->getTableStatus($table);
            if ($status && isset($status['Data_free']) && isset($status['Data_length'])) {
                $dataFree = $status['Data_free'];
                $dataLength = $status['Data_length'] + $dataFree;
                
                if ($dataLength > 0) {
                    $fragmentationPercent = round(($dataFree / $dataLength) * 100, 2);
                    $fragmentationInfo[] = [
                        'table' => $table,
                        'data_free_mb' => round($dataFree / (1024 * 1024), 2),
                        'total_size_mb' => round($dataLength / (1024 * 1024), 2),
                        'fragmentation_percent' => $fragmentationPercent,
                        'should_optimize' => $fragmentationPercent > 10 // 碎片率超过10%建议优化
                    ];
                }
            }
        }
        
        // 按碎片率降序排序
        usort($fragmentationInfo, function($a, $b) {
            return $b['fragmentation_percent'] - $a['fragmentation_percent'];
        });
        
        return $fragmentationInfo;
    }
    
    /**
     * 导出数据库维护报告
     * @return string HTML格式的维护报告
     */
    public function generateMaintenanceReport() {
        $fragmentation = $this->getTableFragmentation();
        $tablesToOptimize = $this->getTablesToOptimize();
        
        $html = '<!DOCTYPE html>\n';
        $html .= '<html>\n';
        $html .= '<head>\n';
        $html .= '    <meta charset="UTF-8">\n';
        $html .= '    <title>数据库维护报告</title>\n';
        $html .= '    <style>\n';
        $html .= '        body { font-family: Arial, sans-serif; margin: 20px; }\n';
        $html .= '        h1, h2 { color: #333; }\n';
        $html .= '        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }\n';
        $html .= '        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n';
        $html .= '        th { background-color: #f2f2f2; }\n';
        $html .= '        .warning { background-color: #ffffcc; }\n';
        $html .= '        .critical { background-color: #ffcccc; }\n';
        $html .= '        .success { background-color: #ccffcc; }\n';
        $html .= '        .summary { background-color: #f8f8f8; padding: 15px; border-radius: 5px; }\n';
        $html .= '    </style>\n';
        $html .= '</head>\n';
        $html .= '<body>\n';
        $html .= '    <h1>数据库维护报告</h1>\n';
        $html .= '    <div class="summary">\n';
        $html .= '        <p>生成时间: ' . date('Y-m-d H:i:s') . '</p>\n';
        $html .= '        <p>需要优化的表数量: ' . count($tablesToOptimize) . '</p>\n';
        $html .= '        <p>高碎片率表数量: ' . count(array_filter($fragmentation, function($f) { return $f['fragmentation_percent'] > 20; })) . '</p>\n';
        $html .= '    </div>\n';
        
        // 碎片信息表格
        $html .= '    <h2>表碎片分析</h2>\n';
        $html .= '    <table>\n';
        $html .= '        <tr>\n';
        $html .= '            <th>表名</th>\n';
        $html .= '            <th>碎片大小 (MB)</th>\n';
        $html .= '            <th>总大小 (MB)</th>\n';
        $html .= '            <th>碎片率 (%)</th>\n';
        $html .= '            <th>建议操作</th>\n';
        $html .= '        </tr>\n';
        
        foreach ($fragmentation as $frag) {
            $class = '';
            if ($frag['fragmentation_percent'] > 20) $class = 'class="critical"';
            else if ($frag['fragmentation_percent'] > 10) $class = 'class="warning"';
            else if ($frag['fragmentation_percent'] > 0) $class = 'class="success"';
            
            $action = $frag['should_optimize'] ? '优化表' : '-';
            
            $html .= "        <tr {$class}>\n";
            $html .= "            <td>{$frag['table']}</td>\n";
            $html .= "            <td>{$frag['data_free_mb']}</td>\n";
            $html .= "            <td>{$frag['total_size_mb']}</td>\n";
            $html .= "            <td>{$frag['fragmentation_percent']}%</td>\n";
            $html .= "            <td>{$action}</td>\n";
            $html .= "        </tr>\n";
        }
        
        $html .= '    </table>\n';
        
        // 需要优化的表表格
        $html .= '    <h2>需要优化的表</h2>\n';
        $html .= '    <table>\n';
        $html .= '        <tr>\n';
        $html .= '            <th>表名</th>\n';
        $html .= '            <th>大小 (MB)</th>\n';
        $html .= '            <th>行数</th>\n';
        $html .= '            <th>存储引擎</th>\n';
        $html .= '        </tr>\n';
        
        foreach ($tablesToOptimize as $tableInfo) {
            $html .= "        <tr>\n";
            $html .= "            <td>{$tableInfo['name']}</td>\n";
            $html .= "            <td>{$tableInfo['size_mb']}</td>\n";
            $html .= "            <td>{$tableInfo['rows']}</td>\n";
            $html .= "            <td>{$tableInfo['engine']}</td>\n";
            $html .= "        </tr>\n";
        }
        
        $html .= '    </table>\n';
        $html .= '</body>\n';
        $html .= '</html>';
        
        return $html;
    }
}