<?php
/**
 * 数据库连接管理器
 * 提供数据库连接管理、连接池、事务处理等功能
 */
class DatabaseConnectionManager {
    
    /**
     * @var array 单例实例
     */
    private static $instance = null;
    
    /**
     * @var array 连接池配置
     */
    private $config = [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => '',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'persistent' => false,
        'connection_timeout' => 10,
        'max_connections' => 10,
        'reconnect_attempts' => 3,
        'reconnect_delay' => 1000, // 毫秒
    ];
    
    /**
     * @var array 连接池
     */
    private $connectionPool = [];
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * 私有构造函数
     * @param array $config 数据库配置
     * @param Logger $logger 日志记录器
     */
    private function __construct(array $config = [], Logger $logger = null) {
        // 如果没有日志记录器，创建一个简单的文件日志记录器
        if (!$logger) {
            $logger = new Logger();
        }
        
        $this->logger = $logger;
        $this->config = array_merge($this->config, $config);
        
        $this->logger->info("数据库连接管理器初始化成功");
    }
    
    /**
     * 获取单例实例
     * @param array $config 数据库配置
     * @param Logger $logger 日志记录器
     * @return DatabaseConnectionManager 单例实例
     */
    public static function getInstance(array $config = [], Logger $logger = null) {
        if (self::$instance === null) {
            self::$instance = new DatabaseConnectionManager($config, $logger);
        }
        return self::$instance;
    }
    
    /**
     * 获取数据库DSN字符串
     * @return string DSN字符串
     */
    private function getDsn() {
        return "mysql:host={$this->config['host']};port={$this->config['port']};dbname={$this->config['dbname']};charset={$this->config['charset']}";
    }
    
    /**
     * 创建新的数据库连接
     * @return PDO 数据库连接对象
     * @throws Exception 连接失败时抛出异常
     */
    private function createConnection() {
        $dsn = $this->getDsn();
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_PERSISTENT => $this->config['persistent'],
            PDO::ATTR_TIMEOUT => $this->config['connection_timeout'],
        ];
        
        $retryCount = 0;
        $lastError = null;
        
        while ($retryCount < $this->config['reconnect_attempts']) {
            try {
                $connection = new PDO($dsn, $this->config['username'], $this->config['password'], $options);
                
                // 设置字符集和排序规则
                $connection->exec("SET NAMES '{$this->config['charset']}' COLLATE '{$this->config['collation']}'");
                
                // 启用查询缓存（如果可用）
                $connection->exec("SET SESSION query_cache_type = 1");
                
                $this->logger->info("成功创建数据库连接");
                return $connection;
            } catch (PDOException $e) {
                $lastError = $e;
                $retryCount++;
                
                if ($retryCount < $this->config['reconnect_attempts']) {
                    $this->logger->warning("数据库连接失败，{$retryCount}秒后重试: " . $e->getMessage());
                    usleep($this->config['reconnect_delay'] * 1000);
                }
            }
        }
        
        $this->logger->error("数据库连接失败，已达到最大重试次数: " . $lastError->getMessage());
        throw new Exception("无法连接到数据库: " . $lastError->getMessage());
    }
    
    /**
     * 从连接池获取连接
     * @return PDO 数据库连接对象
     */
    public function getConnection() {
        // 检查连接池是否有可用连接
        if (!empty($this->connectionPool)) {
            $connection = array_pop($this->connectionPool);
            
            // 检查连接是否有效
            if ($this->isConnectionValid($connection)) {
                $this->logger->debug("从连接池获取连接，剩余连接数: " . count($this->connectionPool));
                return $connection;
            } else {
                $this->logger->warning("连接池中的连接无效，创建新连接");
            }
        }
        
        // 如果连接池已满，等待或创建新连接
        if (count($this->connectionPool) >= $this->config['max_connections']) {
            $this->logger->warning("连接池已满，等待连接释放");
            // 简单的等待逻辑，实际应用中可能需要更复杂的机制
            usleep(100000); // 等待100毫秒
        }
        
        return $this->createConnection();
    }
    
    /**
     * 将连接归还到连接池
     * @param PDO $connection 数据库连接对象
     * @return bool 归还结果
     */
    public function releaseConnection(PDO $connection) {
        try {
            // 检查连接是否有效且连接池未满
            if ($this->isConnectionValid($connection) && count($this->connectionPool) < $this->config['max_connections']) {
                $this->connectionPool[] = $connection;
                $this->logger->debug("连接已归还到连接池，当前连接数: " . count($this->connectionPool));
                return true;
            }
            
            // 如果连接池已满或连接无效，关闭连接
            $this->closeConnection($connection);
            return false;
        } catch (Exception $e) {
            $this->logger->error("归还连接到连接池失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查连接是否有效
     * @param PDO $connection 数据库连接对象
     * @return bool 连接是否有效
     */
    private function isConnectionValid(PDO $connection) {
        try {
            // 执行简单的查询测试连接
            $connection->query("SELECT 1");
            return true;
        } catch (PDOException $e) {
            $this->logger->warning("连接测试失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 关闭数据库连接
     * @param PDO $connection 数据库连接对象
     */
    private function closeConnection(PDO $connection) {
        try {
            // PDO没有显式的close方法，但将其设置为null可以帮助垃圾回收
            unset($connection);
            $this->logger->debug("数据库连接已关闭");
        } catch (Exception $e) {
            $this->logger->error("关闭数据库连接失败: " . $e->getMessage());
        }
    }
    
    /**
     * 清空连接池
     */
    public function clearConnectionPool() {
        foreach ($this->connectionPool as &$connection) {
            $this->closeConnection($connection);
        }
        $this->connectionPool = [];
        $this->logger->info("连接池已清空");
    }
    
    /**
     * 获取连接池状态
     * @return array 连接池状态信息
     */
    public function getPoolStatus() {
        return [
            'active_connections' => count($this->connectionPool),
            'max_connections' => $this->config['max_connections'],
            'pool_usage_percent' => (count($this->connectionPool) / $this->config['max_connections']) * 100,
        ];
    }
    
    /**
     * 执行事务操作
     * @param callable $callback 事务回调函数
     * @return mixed 回调函数的返回值
     * @throws Exception 事务执行失败时抛出异常
     */
    public function transaction(callable $callback) {
        $connection = null;
        
        try {
            $connection = $this->getConnection();
            
            // 开始事务
            $connection->beginTransaction();
            $this->logger->debug("数据库事务已开始");
            
            // 执行回调函数
            $result = $callback($connection);
            
            // 提交事务
            $connection->commit();
            $this->logger->debug("数据库事务已提交");
            
            return $result;
        } catch (Exception $e) {
            // 回滚事务
            if ($connection) {
                try {
                    $connection->rollBack();
                    $this->logger->debug("数据库事务已回滚");
                } catch (Exception $rollbackException) {
                    $this->logger->error("事务回滚失败: " . $rollbackException->getMessage());
                }
            }
            
            $this->logger->error("数据库事务执行失败: " . $e->getMessage());
            throw $e;
        } finally {
            // 归还连接
            if ($connection) {
                $this->releaseConnection($connection);
            }
        }
    }
    
    /**
     * 执行预处理语句
     * @param string $sql SQL语句
     * @param array $params 绑定参数
     * @param callable $callback 结果处理回调函数
     * @return mixed 回调函数的返回值或语句执行结果
     */
    public function executeQuery($sql, array $params = [], callable $callback = null) {
        $connection = null;
        
        try {
            $connection = $this->getConnection();
            
            // 预处理语句
            $stmt = $connection->prepare($sql);
            
            // 绑定参数
            foreach ($params as $param => $value) {
                $type = PDO::PARAM_STR;
                if (is_int($value)) {
                    $type = PDO::PARAM_INT;
                } else if (is_bool($value)) {
                    $type = PDO::PARAM_BOOL;
                } else if (is_null($value)) {
                    $type = PDO::PARAM_NULL;
                }
                
                $stmt->bindValue(is_numeric($param) ? $param + 1 : ":{$param}", $value, $type);
            }
            
            // 执行语句
            $stmt->execute();
            
            // 处理结果
            if ($callback) {
                return $callback($stmt);
            } else {
                // 根据SQL类型返回适当的结果
                if (stripos($sql, 'INSERT') === 0) {
                    return $connection->lastInsertId();
                } else if (stripos($sql, 'UPDATE') === 0 || stripos($sql, 'DELETE') === 0) {
                    return $stmt->rowCount();
                } else {
                    return $stmt->fetchAll();
                }
            }
        } catch (PDOException $e) {
            $this->logger->error("SQL执行失败: " . $e->getMessage() . "\nSQL: {$sql}");
            throw $e;
        } finally {
            // 归还连接
            if ($connection) {
                $this->releaseConnection($connection);
            }
        }
    }
    
    /**
     * 获取数据库服务器信息
     * @return array 服务器信息
     */
    public function getServerInfo() {
        $connection = null;
        
        try {
            $connection = $this->getConnection();
            
            $info = [
                'version' => $connection->getAttribute(PDO::ATTR_SERVER_VERSION),
                'driver' => $connection->getAttribute(PDO::ATTR_DRIVER_NAME),
                'server' => $this->config['host'],
                'database' => $this->config['dbname'],
            ];
            
            // 获取更多服务器信息
            $stmt = $connection->query("SELECT VERSION() as version, NOW() as current_time");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result) {
                $info['full_version'] = $result['version'];
                $info['current_time'] = $result['current_time'];
            }
            
            return $info;
        } catch (Exception $e) {
            $this->logger->error("获取服务器信息失败: " . $e->getMessage());
            return [];
        } finally {
            if ($connection) {
                $this->releaseConnection($connection);
            }
        }
    }
    
    /**
     * 检查数据库连接状态
     * @return bool 连接是否正常
     */
    public function checkConnection() {
        $connection = null;
        
        try {
            $connection = $this->getConnection();
            $connection->query("SELECT 1");
            return true;
        } catch (Exception $e) {
            $this->logger->error("数据库连接检查失败: " . $e->getMessage());
            return false;
        } finally {
            if ($connection) {
                $this->releaseConnection($connection);
            }
        }
    }
    
    /**
     * 设置连接池配置
     * @param array $config 配置参数
     */
    public function setConfig(array $config) {
        $this->config = array_merge($this->config, $config);
        $this->logger->info("连接池配置已更新");
    }
    
    /**
     * 获取连接池配置
     * @return array 配置参数
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * 执行批量查询
     * @param string $sql SQL语句模板
     * @param array $batchParams 参数数组
     * @param bool $useTransaction 是否使用事务
     * @return array 执行结果
     */
    public function executeBatch($sql, array $batchParams, $useTransaction = true) {
        $results = [];
        
        $callback = function($connection) use ($sql, $batchParams, &$results) {
            foreach ($batchParams as $params) {
                $stmt = $connection->prepare($sql);
                
                // 绑定参数
                foreach ($params as $param => $value) {
                    $type = PDO::PARAM_STR;
                    if (is_int($value)) {
                        $type = PDO::PARAM_INT;
                    } else if (is_bool($value)) {
                        $type = PDO::PARAM_BOOL;
                    } else if (is_null($value)) {
                        $type = PDO::PARAM_NULL;
                    }
                    
                    $stmt->bindValue(is_numeric($param) ? $param + 1 : ":{$param}", $value, $type);
                }
                
                $stmt->execute();
                
                // 收集结果
                if (stripos($sql, 'INSERT') === 0) {
                    $results[] = $connection->lastInsertId();
                } else if (stripos($sql, 'UPDATE') === 0 || stripos($sql, 'DELETE') === 0) {
                    $results[] = $stmt->rowCount();
                } else {
                    $results[] = $stmt->fetchAll();
                }
            }
            
            return $results;
        };
        
        if ($useTransaction) {
            return $this->transaction($callback);
        } else {
            return $callback($this->getConnection());
        }
    }
}