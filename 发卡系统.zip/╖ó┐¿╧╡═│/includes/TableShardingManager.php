<?php

/**
 * 表分片管理器
 * 负责处理表的分表逻辑，支持按时间分表
 */
class TableShardingManager {
    
    /**
     * @var Database 数据库实例
     */
    private $database;
    
    /**
     * @var string 表前缀
     */
    private $tablePrefix;
    
    /**
     * @var array 分表配置
     */
    private $shardingConfig = [
        'orders' => [
            'enabled' => true,
            'type' => 'monthly', // 按月分表
            'key_field' => 'created_at', // 分片字段
            'template' => 'orders_%s', // 表名模板
            'auto_create' => true // 自动创建表
        ],
        // 可添加其他表的分表配置
    ];
    
    /**
     * 构造函数
     * @param Database $database 数据库实例
     * @param string $tablePrefix 表前缀
     */
    public function __construct($database, $tablePrefix = '') {
        $this->database = $database;
        $this->tablePrefix = $tablePrefix;
    }
    
    /**
     * 获取指定日期的分表名称
     * @param string $tableName 原始表名
     * @param string|DateTime $date 日期
     * @return string 分表名称
     */
    public function getShardedTableName($tableName, $date = null) {
        // 如果分表未启用，返回原始表名
        if (!$this->isShardingEnabled($tableName)) {
            return $this->tablePrefix . $tableName;
        }
        
        $config = $this->shardingConfig[$tableName];
        
        // 如果未提供日期，使用当前日期
        if ($date === null) {
            $date = new DateTime();
        } elseif (!($date instanceof DateTime)) {
            $date = new DateTime($date);
        }
        
        // 根据分表类型生成表名后缀
        switch ($config['type']) {
            case 'monthly':
                $suffix = $date->format('Ym');
                break;
            case 'quarterly':
                $year = $date->format('Y');
                $quarter = ceil($date->format('n') / 3);
                $suffix = $year . 'Q' . $quarter;
                break;
            case 'yearly':
                $suffix = $date->format('Y');
                break;
            default:
                $suffix = $date->format('Ym');
        }
        
        // 生成并返回分表名称
        $shardedTableName = $this->tablePrefix . sprintf($config['template'], $suffix);
        
        // 如果需要自动创建表，检查并创建
        if ($config['auto_create'] && !$this->tableExists($shardedTableName)) {
            $this->createShardedTable($tableName, $shardedTableName);
        }
        
        return $shardedTableName;
    }
    
    /**
     * 根据时间范围获取所有需要查询的分表
     * @param string $tableName 原始表名
     * @param string|DateTime $startDate 开始日期
     * @param string|DateTime $endDate 结束日期
     * @return array 表名数组
     */
    public function getShardedTableNamesByDateRange($tableName, $startDate, $endDate = null) {
        // 如果分表未启用，返回原始表名
        if (!$this->isShardingEnabled($tableName)) {
            return [$this->tablePrefix . $tableName];
        }
        
        // 转换日期格式
        if (!($startDate instanceof DateTime)) {
            $startDate = new DateTime($startDate);
        }
        
        if ($endDate === null) {
            $endDate = new DateTime();
        } elseif (!($endDate instanceof DateTime)) {
            $endDate = new DateTime($endDate);
        }
        
        $config = $this->shardingConfig[$tableName];
        $tables = [];
        
        // 根据分表类型生成日期区间内的所有表名
        switch ($config['type']) {
            case 'monthly':
                $currentDate = clone $startDate;
                $currentDate->modify('first day of this month');
                
                $endDate->modify('last day of this month');
                
                while ($currentDate <= $endDate) {
                    $tableName = $this->getShardedTableName($tableName, $currentDate);
                    $tables[] = $tableName;
                    $currentDate->modify('+1 month');
                }
                break;
                
            case 'quarterly':
                $currentDate = clone $startDate;
                $quarter = ceil($currentDate->format('n') / 3);
                $currentDate->setDate($currentDate->format('Y'), ($quarter - 1) * 3 + 1, 1);
                
                $endQuarter = ceil($endDate->format('n') / 3);
                $endDate->setDate($endDate->format('Y'), $endQuarter * 3, 1);
                $endDate->modify('last day of this month');
                
                while ($currentDate <= $endDate) {
                    $tableName = $this->getShardedTableName($tableName, $currentDate);
                    $tables[] = $tableName;
                    $currentDate->modify('+3 months');
                }
                break;
                
            case 'yearly':
                $startYear = $startDate->format('Y');
                $endYear = $endDate->format('Y');
                
                for ($year = $startYear; $year <= $endYear; $year++) {
                    $date = new DateTime($year . '-01-01');
                    $tableName = $this->getShardedTableName($tableName, $date);
                    $tables[] = $tableName;
                }
                break;
        }
        
        return array_unique($tables);
    }
    
    /**
     * 检查表是否存在
     * @param string $tableName 表名
     * @return bool 是否存在
     */
    public function tableExists($tableName) {
        $result = $this->database->fetch(
            "SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1",
            [$tableName]
        );
        return !empty($result);
    }
    
    /**
     * 创建分表
     * @param string $originalTableName 原始表名
     * @param string $shardedTableName 分表名
     * @return bool 是否成功
     */
    public function createShardedTable($originalTableName, $shardedTableName) {
        try {
            // 获取原始表的结构
            $result = $this->database->fetchAll(
                "SHOW CREATE TABLE {$this->tablePrefix}{$originalTableName}"
            );
            
            if (empty($result)) {
                throw new Exception("原始表 {$originalTableName} 不存在");
            }
            
            // 获取创建表SQL
            $createTableSQL = $result[0]['Create Table'];
            
            // 替换表名为分表名
            $createTableSQL = preg_replace(
                '/CREATE TABLE [`"]?' . preg_quote($this->tablePrefix . $originalTableName, '/') . '[/`"]?/', 
                'CREATE TABLE ' . $shardedTableName,
                $createTableSQL
            );
            
            // 移除AUTO_INCREMENT
            $createTableSQL = preg_replace('/AUTO_INCREMENT=[0-9]+\s+/i', '', $createTableSQL);
            
            // 执行创建表SQL
            $this->database->query($createTableSQL);
            
            // 复制所有索引
            $indexes = $this->database->fetchAll(
                "SHOW INDEX FROM {$this->tablePrefix}{$originalTableName}"
            );
            
            foreach ($indexes as $index) {
                if ($index['Key_name'] == 'PRIMARY') {
                    // 主键已经在CREATE TABLE时创建
                    continue;
                }
                
                $indexSQL = "ALTER TABLE {$shardedTableName} ADD ";
                
                if ($index['Non_unique'] == 0) {
                    $indexSQL .= "UNIQUE ";
                }
                
                $indexSQL .= "INDEX {$index['Key_name']} ({$index['Column_name']})";
                
                try {
                    $this->database->query($indexSQL);
                } catch (Exception $e) {
                    // 忽略重复索引错误
                    if (!strpos($e->getMessage(), 'Duplicate key')) {
                        throw $e;
                    }
                }
            }
            
            return true;
        } catch (Exception $e) {
            $this->logError("创建分表失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 生成跨表查询的UNION SQL
     * @param string $baseSQL 基础SQL
     * @param string $tableName 原始表名
     * @param array $shardedTables 分表名数组
     * @param string $originalTableRef 原始表引用
     * @return string 跨表查询SQL
     */
    public function generateUnionSQL($baseSQL, $tableName, $shardedTables, $originalTableRef = null) {
        if (count($shardedTables) == 1) {
            // 只有一个表，直接替换表名
            $singleTable = reset($shardedTables);
            if ($originalTableRef) {
                return str_replace($originalTableRef, $singleTable, $baseSQL);
            } else {
                return str_replace($tableName, $singleTable, $baseSQL);
            }
        }
        
        // 多个表，生成UNION ALL查询
        $unionSQLs = [];
        foreach ($shardedTables as $shardedTable) {
            if ($originalTableRef) {
                $unionSQL = str_replace($originalTableRef, $shardedTable, $baseSQL);
            } else {
                $unionSQL = str_replace($tableName, $shardedTable, $baseSQL);
            }
            $unionSQLs[] = $unionSQL;
        }
        
        return implode(" UNION ALL ", $unionSQLs);
    }
    
    /**
     * 判断是否启用分表
     * @param string $tableName 表名
     * @return bool 是否启用
     */
    public function isShardingEnabled($tableName) {
        return isset($this->shardingConfig[$tableName]) && 
               $this->shardingConfig[$tableName]['enabled'] === true;
    }
    
    /**
     * 获取分表配置
     * @param string $tableName 表名
     * @return array 配置
     */
    public function getShardingConfig($tableName) {
        return isset($this->shardingConfig[$tableName]) ? 
               $this->shardingConfig[$tableName] : [];
    }
    
    /**
     * 记录错误日志
     * @param string $message 错误信息
     */
    private function logError($message) {
        // 如果有Logger类，使用Logger记录
        if (class_exists('Logger')) {
            $logger = new Logger();
            $logger->error('TableShardingManager', $message);
        }
    }
}