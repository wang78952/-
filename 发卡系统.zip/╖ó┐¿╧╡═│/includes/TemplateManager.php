<?php
/**
 * 模板管理器
 * 处理邮件模板、短信模板、页面模板等模板管理功能
 */

require_once __DIR__ . '/BaseService.php';
require_once __DIR__ . '/CacheManager.php';
require_once __DIR__ . '/LogManager.php';

class TemplateManager extends BaseService {
    private $cacheManager;
    private $logManager;
    private $templateDir;
    private $cachePrefix = 'template_';
    
    public function __construct($database = null, $logger = null) {
        parent::__construct();
        $this->cacheManager = CacheManager::getInstance();
        $this->logManager = new LogManager($database, $logger);
        $this->templateDir = __DIR__ . '/../templates/';
        
        // 确保模板目录存在
        if (!is_dir($this->templateDir)) {
            mkdir($this->templateDir, 0755, true);
        }
    }
    
    /**
     * 获取模板列表
     */
    public function getTemplateList($type = null, $page = 1, $limit = 20) {
        try {
            $offset = ($page - 1) * $limit;
            $conditions = array();
            $params = array();
            
            if ($type) {
                $conditions[] = "type = ?";
                $params[] = $type;
            }
            
            $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';
            
            // 获取总数
            $countSql = "SELECT COUNT(*) as total FROM templates {$whereClause}";
            $totalResult = $this->database->fetch($countSql, $params);
            $total = $totalResult['total'];
            
            // 获取模板列表
            $sql = "SELECT * FROM templates {$whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $listParams = array_merge($params, array($limit, $offset));
            
            $templates = $this->database->fetchAll($sql, $listParams);
            
            return array(
                'success' => true,
                'templates' => $templates,
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("获取模板列表失败", array('error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 获取模板详情
     */
    public function getTemplate($id) {
        try {
            $cacheKey = $this->cachePrefix . $id;
            $template = $this->cacheManager->get($cacheKey);
            
            if ($template === false) {
                $template = $this->database->fetch(
                    "SELECT * FROM templates WHERE id = ?",
                    array($id)
                );
                
                if ($template) {
                    $this->cacheManager->set($cacheKey, $template, 3600);
                }
            }
            
            if (!$template) {
                return array('success' => false, 'message' => '模板不存在');
            }
            
            return array('success' => true, 'template' => $template);
            
        } catch (Exception $e) {
            $this->logManager->logError("获取模板详情失败", array('id' => $id, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 创建模板
     */
    public function createTemplate($data) {
        try {
            // 验证必填字段
            $required = array('name', 'type', 'subject', 'content');
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return array('success' => false, 'message' => "字段 {$field} 不能为空");
                }
            }
            
            // 检查模板名称是否已存在
            $existing = $this->database->fetch(
                "SELECT id FROM templates WHERE name = ? AND type = ?",
                array($data['name'], $data['type'])
            );
            
            if ($existing) {
                return array('success' => false, 'message' => '模板名称已存在');
            }
            
            // 验证模板内容
            $validation = $this->validateTemplate($data['content'], $data['type']);
            if (!$validation['valid']) {
                return array('success' => false, 'message' => $validation['message']);
            }
            
            // 插入模板
            $this->database->insert('templates', array(
                'name' => $data['name'],
                'type' => $data['type'],
                'subject' => $data['subject'],
                'content' => $data['content'],
                'variables' => json_encode((isset($data['variables']) ? $data['variables'] : array())),
                'description' => (isset($data['description']) ? $data['description'] : ''),
                'is_active' => (isset($data['is_active']) ? $data['is_active'] : 1),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ));
            
            $templateId = $this->database->lastInsertId();
            
            // 清除相关缓存
            $this->clearTemplateCache($data['type']);
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'create_template',
                'template',
                array('id' => $templateId, 'name' => $data['name'], 'type' => $data['type'])
            );
            
            return array('success' => true, 'template_id' => $templateId, 'message' => '模板创建成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("创建模板失败", array('data' => $data, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 更新模板
     */
    public function updateTemplate($id, $data) {
        try {
            // 检查模板是否存在
            $template = $this->database->fetch(
                "SELECT * FROM templates WHERE id = ?",
                array($id)
            );
            
            if (!$template) {
                return array('success' => false, 'message' => '模板不存在');
            }
            
            // 检查名称冲突（如果更改了名称）
            if (isset($data['name']) && $data['name'] !== $template['name']) {
                $existing = $this->database->fetch(
                    "SELECT id FROM templates WHERE name = ? AND type = ? AND id != ?",
                    array($data['name'], $template['type'], $id)
                );
                
                if ($existing) {
                    return array('success' => false, 'message' => '模板名称已存在');
                }
            }
            
            // 验证模板内容（如果更新了内容）
            if (isset($data['content'])) {
                $type = (isset($data['type']) ? $data['type'] : $template['type']);
                $validation = $this->validateTemplate($data['content'], $type);
                if (!$validation['valid']) {
                    return array('success' => false, 'message' => $validation['message']);
                }
            }
            
            // 更新数据
            $updateData = array_merge($data, array(
                'updated_at' => date('Y-m-d H:i:s')
            ));
            
            if (isset($updateData['variables'])) {
                $updateData['variables'] = json_encode($updateData['variables']);
            }
            
            $this->database->update('templates', $updateData, 'id = ?', array($id));
            
            // 清除相关缓存
            $this->cacheManager->delete($this->cachePrefix . $id);
            $this->clearTemplateCache($template['type']);
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'update_template',
                'template',
                array('id' => $id, 'data' => $data)
            );
            
            return array('success' => true, 'message' => '模板更新成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("更新模板失败", array('id' => $id, 'data' => $data, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 删除模板
     */
    public function deleteTemplate($id) {
        try {
            // 检查模板是否存在
            $template = $this->database->fetch(
                "SELECT * FROM templates WHERE id = ?",
                array($id)
            );
            
            if (!$template) {
                return array('success' => false, 'message' => '模板不存在');
            }
            
            // 检查是否正在使用
            $inUse = $this->isTemplateInUse($id);
            if ($inUse) {
                return array('success' => false, 'message' => '模板正在使用中，无法删除');
            }
            
            // 删除模板
            $this->database->delete('templates', 'id = ?', array($id));
            
            // 清除相关缓存
            $this->cacheManager->delete($this->cachePrefix . $id);
            $this->clearTemplateCache($template['type']);
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'delete_template',
                'template',
                array('id' => $id, 'name' => $template['name'])
            );
            
            return array('success' => true, 'message' => '模板删除成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("删除模板失败", array('id' => $id, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 渲染模板
     */
    public function renderTemplate($templateId, $variables = array()) {
        try {
            $template = $this->getTemplate($templateId);
            if (!$template['success']) {
                return $template;
            }
            
            $templateData = $template['template'];
            
            // 解析变量
            $subject = $this->parseVariables($templateData['subject'], $variables);
            $content = $this->parseVariables($templateData['content'], $variables);
            
            return array(
                'success' => true,
                'subject' => $subject,
                'content' => $content,
                'type' => $templateData['type']
            );
            
        } catch (Exception $e) {
            $this->logManager->logError("渲染模板失败", array('template_id' => $templateId, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 根据类型获取默认模板
     */
    public function getDefaultTemplate($type) {
        try {
            $template = $this->database->fetch(
                "SELECT * FROM templates WHERE type = ? AND is_default = 1",
                array($type)
            );
            
            if (!$template) {
                // 如果没有默认模板，获取最新的激活模板
                $template = $this->database->fetch(
                    "SELECT * FROM templates WHERE type = ? AND is_active = 1 ORDER BY created_at DESC LIMIT 1",
                    array($type)
                );
            }
            
            return $template ?: null;
            
        } catch (Exception $e) {
            $this->logManager->logError("获取默认模板失败", array('type' => $type, 'error' => $e->getMessage()));
            return null;
        }
    }
    
    /**
     * 设置默认模板
     */
    public function setDefaultTemplate($id) {
        try {
            // 获取模板信息
            $template = $this->database->fetch(
                "SELECT * FROM templates WHERE id = ?",
                array($id)
            );
            
            if (!$template) {
                return array('success' => false, 'message' => '模板不存在');
            }
            
            // 清除同类型的其他默认模板
            $this->database->update(
                'templates',
                array('is_default' => 0),
                'type = ?',
                array($template['type'])
            );
            
            // 设置新的默认模板
            $this->database->update(
                'templates',
                array('is_default' => 1, 'updated_at' => date('Y-m-d H:i:s')),
                'id = ?',
                array($id)
            );
            
            // 清除相关缓存
            $this->clearTemplateCache($template['type']);
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'set_default_template',
                'template',
                array('id' => $id, 'type' => $template['type'])
            );
            
            return array('success' => true, 'message' => '默认模板设置成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("设置默认模板失败", array('id' => $id, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 复制模板
     */
    public function copyTemplate($id, $newName) {
        try {
            $template = $this->getTemplate($id);
            if (!$template['success']) {
                return $template;
            }
            
            $original = $template['template'];
            
            // 检查新名称是否已存在
            $existing = $this->database->fetch(
                "SELECT id FROM templates WHERE name = ? AND type = ?",
                array($newName, $original['type'])
            );
            
            if ($existing) {
                return array('success' => false, 'message' => '模板名称已存在');
            }
            
            // 创建副本
            $this->database->insert('templates', array(
                'name' => $newName,
                'type' => $original['type'],
                'subject' => $original['subject'],
                'content' => $original['content'],
                'variables' => $original['variables'],
                'description' => (isset($original['description']) ? $original['description'] : '') . ' (副本)',
                'is_active' => 0, // 副本默认不激活
                'is_default' => 0,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ));
            
            $newId = $this->database->lastInsertId();
            
            $this->logManager->logOperation(
                $this->getCurrentUserId(),
                'copy_template',
                'template',
                array('original_id' => $id, 'new_id' => $newId, 'new_name' => $newName)
            );
            
            return array('success' => true, 'template_id' => $newId, 'message' => '模板复制成功');
            
        } catch (Exception $e) {
            $this->logManager->logError("复制模板失败", array('id' => $id, 'new_name' => $newName, 'error' => $e->getMessage()));
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 验证模板
     */
    private function validateTemplate($content, $type) {
        try {
            switch ($type) {
                case 'email':
                    // 验证邮件模板
                    if (!preg_match('/<html|<body/i', $content)) {
                        return array('valid' => false, 'message' => '邮件模板应包含HTML结构');
                    }
                    break;
                    
                case 'sms':
                    // 验证短信模板
                    if (strlen($content) > 500) {
                        return array('valid' => false, 'message' => '短信内容不能超过500字符');
                    }
                    break;
                    
                case 'webhook':
                    // 验证Webhook模板
                    $jsonTest = json_encode(array('test' => $content));
                    if ($jsonTest === false) {
                        return array('valid' => false, 'message' => 'Webhook模板内容格式错误');
                    }
                    break;
            }
            
            return array('valid' => true);
            
        } catch (Exception $e) {
            return array('valid' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * 解析模板变量
     */
    private function parseVariables($content, $variables) {
        foreach ($variables as $key => $value) {
            $content = str_replace('{' . $key . '}', $value, $content);
            $content = str_replace('{{' . $key . '}}', $value, $content);
            $content = str_replace('{$' . $key . '}', $value, $content);
        }
        
        return $content;
    }
    
    /**
     * 检查模板是否在使用中
     */
    private function isTemplateInUse($id) {
        try {
            // 检查配置中是否使用了该模板
            $configFiles = array(
                __DIR__ . '/../config/notification.php',
                __DIR__ . '/../config/email.php',
                __DIR__ . '/../config/sms.php'
            );
            
            foreach ($configFiles as $file) {
                if (file_exists($file)) {
                    $content = file_get_contents($file);
                    if (strpos($content, "template_id' => $id") !== false || 
                        strpos($content, "\"template_id\" => $id") !== false) {
                        return true;
                    }
                }
            }
            
            return false;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 清除模板缓存
     */
    private function clearTemplateCache($type) {
        $this->cacheManager->delete($this->cachePrefix . "default_{$type}");
        $this->cacheManager->delete($this->cachePrefix . "list_{$type}");
    }
    
    /**
     * 获取当前用户ID
     */
    private function getCurrentUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
}