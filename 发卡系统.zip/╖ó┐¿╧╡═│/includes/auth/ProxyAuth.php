<?php
/**
 * 代理认证类
 * 使用AuthManager实现代理认证功能
 */

namespace Auth;

require_once __DIR__ . '/../AuthManager.php';
require_once __DIR__ . '/../Database.php';
require_once __DIR__ . '/../Logger.php';

class ProxyAuth {
    /**
     * 认证管理器实例
     * @var \AuthManager
     */
    private $authManager;
    
    /**
     * 数据库连接
     * @var \Database
     */
    private $database;
    
    /**
     * 日志记录器
     * @var \Logger
     */
    private $logger;
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->authManager = \AuthManager::getInstance();
        $this->database = \Database::getInstance();
        $this->logger = \Logger::getInstance();
    }
    
    /**
     * 代理认证方法
     * @return array 认证结果
     */
    public function authenticate() {
        try {
            // 检查用户是否已登录
            if (!$this->authManager->isLoggedIn()) {
                return array(
                    'success' => false,
                    'message' => '请先登录'
                );
            }
            
            // 检查用户是否为代理角色
            $user = $this->authManager->getCurrentUser();
            if (!$user || $user['role'] !== \AuthManager::ROLE_AGENT) {
                return array(
                    'success' => false,
                    'message' => '需要代理权限'
                );
            }
            
            // 验证代理状态
            $sql = "SELECT status FROM agents WHERE user_id = ?";
            $agent = $this->database->queryOne($sql, array($user['id']));
            
            if (!$agent) {
                return array(
                    'success' => false,
                    'message' => '代理信息不存在'
                );
            }
            
            if ($agent['status'] !== 'active') {
                return array(
                    'success' => false,
                    'message' => '代理账户未激活或已禁用'
                );
            }
            
            return array(
                'success' => true,
                'agent_id' => $user['id'],
                'agent' => $user
            );
            
        } catch (Exception $e) {
            $this->logger->error('代理认证异常', array(
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ));
            
            return array(
                'success' => false,
                'message' => '认证过程中发生错误，请稍后重试'
            );
        }
    }
    
    /**
     * 验证代理权限
     * @param string $permission 权限标识
     * @return bool 是否有该权限
     */
    public function hasPermission($permission) {
        $authResult = $this->authenticate();
        if (!$authResult['success']) {
            return false;
        }
        
        return $this->authManager->hasPermission($permission);
    }
}