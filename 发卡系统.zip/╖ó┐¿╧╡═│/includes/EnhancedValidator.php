<?php
/**
 * 增强型输入验证辅助函数库
 * 提供全面的输入验证、类型转换、防注入攻击功能
 * 支持复杂数据结构、批量验证、自定义规则和错误处理
 */

require_once __DIR__ . '/ErrorHandler.php';
require_once __DIR__ . '/InputValidator.php';
require_once __DIR__ . '/SecurityUtils.php';

/**
 * 增强型验证器类
 * 扩展基础验证功能，提供更全面的安全保障
 */
class EnhancedValidator {
    /**
     * 验证器实例
     * @var EnhancedValidator
     */
    private static $instance = null;
    
    /**
     * 输入验证器实例
     * @var InputValidator
     */
    private $inputValidator;
    
    /**
     * 错误信息存储
     * @var array
     */
    private $errors = [];
    
    /**
     * 构造函数
     */
    private function __construct() {
        $this->inputValidator = InputValidator::getInstance();
    }
    
    /**
     * 获取单例实例
     * @return EnhancedValidator
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 获取错误信息
     * @return array
     */
    public function getErrors() {
        return $this->errors;
    }
    
    /**
     * 清空错误信息
     */
    public function clearErrors() {
        $this->errors = [];
    }
    
    /**
     * 验证$_POST数据
     * @param array $rules 验证规则数组
     * @param array $postData POST数据，默认使用$_POST
     * @return array 验证后的数据
     */
    public function validatePost($rules, $postData = null) {
        return $this->validateInputSource('post', $rules, $postData ?: $_POST);
    }
    
    /**
     * 验证$_GET数据
     * @param array $rules 验证规则数组
     * @param array $getData GET数据，默认使用$_GET
     * @return array 验证后的数据
     */
    public function validateGet($rules, $getData = null) {
        return $this->validateInputSource('get', $rules, $getData ?: $_GET);
    }
    
    /**
     * 验证JSON请求数据
     * @param array $rules 验证规则数组
     * @return array 验证后的数据
     */
    public function validateJson($rules) {
        $jsonData = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->errors['json'] = '无效的JSON格式';
            return [];
        }
        return $this->validateInputSource('json', $rules, $jsonData);
    }
    
    /**
     * 验证文件上传
     * @param array $rules 验证规则数组
     * @param array $files 文件数据，默认使用$_FILES
     * @return array 验证后的文件信息
     */
    public function validateFiles($rules, $files = null) {
        $fileData = $files ?: $_FILES;
        $validated = [];
        
        foreach ($rules as $field => $rule) {
            if (!isset($fileData[$field])) {
                if (!empty($rule['required'])) {
                    $this->errors[$field] = '文件必须上传';
                }
                continue;
            }
            
            $file = $fileData[$field];
            
            // 检查文件是否上传成功
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $this->errors[$field] = $this->getUploadErrorMessage($file['error']);
                continue;
            }
            
            // 检查文件类型
            if (isset($rule['allowed_types'])) {
                $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $mimeTypes = $this->getMimeTypes();
                
                if (!in_array($fileExt, $rule['allowed_types']) && !in_array($file['type'], $mimeTypes[$fileExt] ?? [])) {
                    $this->errors[$field] = '不允许的文件类型';
                    continue;
                }
            }
            
            // 检查文件大小
            if (isset($rule['max_size']) && $file['size'] > $rule['max_size']) {
                $this->errors[$field] = '文件大小超过限制';
                continue;
            }
            
            // 安全检查：验证文件内容类型
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $actualType = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            if (isset($rule['allowed_mime_types']) && !in_array($actualType, $rule['allowed_mime_types'])) {
                $this->errors[$field] = '文件内容类型不匹配';
                continue;
            }
            
            $validated[$field] = $file;
        }
        
        return $validated;
    }
    
    /**
     * 获取上传错误信息
     * @param int $errorCode 错误代码
     * @return string 错误信息
     */
    private function getUploadErrorMessage($errorCode) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => '文件大小超过php.ini限制',
            UPLOAD_ERR_FORM_SIZE => '文件大小超过表单限制',
            UPLOAD_ERR_PARTIAL => '文件上传不完整',
            UPLOAD_ERR_NO_FILE => '没有文件上传',
            UPLOAD_ERR_NO_TMP_DIR => '缺少临时目录',
            UPLOAD_ERR_CANT_WRITE => '无法写入临时文件',
            UPLOAD_ERR_EXTENSION => '文件上传被PHP扩展中断'
        ];
        return $messages[$errorCode] ?? '未知上传错误';
    }
    
    /**
     * 获取MIME类型映射
     * @return array MIME类型映射
     */
    private function getMimeTypes() {
        return [
            'jpg' => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'png' => ['image/png'],
            'gif' => ['image/gif'],
            'pdf' => ['application/pdf'],
            'doc' => ['application/msword'],
            'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            'xls' => ['application/vnd.ms-excel'],
            'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
            'zip' => ['application/zip', 'application/x-zip-compressed'],
            'rar' => ['application/x-rar-compressed']
        ];
    }
    
    /**
     * 验证输入源数据
     * @param string $source 输入源
     * @param array $rules 验证规则数组
     * @param array $data 输入数据
     * @return array 验证后的数据
     */
    public function validateInputSource($source, $rules, $data) {
        $validated = [];
        $this->errors = [];
        
        foreach ($rules as $field => $rule) {
            // 检查嵌套字段
            if (strpos($field, '.') !== false) {
                $result = $this->validateNestedField($field, $rule, $data);
                if (!is_null($result)) {
                    $this->setValueByPath($validated, $field, $result);
                }
                continue;
            }
            
            // 检查字段是否存在
            $value = isset($data[$field]) ? $data[$field] : null;
            
            // 验证必填字段
            if ($value === null || $value === '') {
                if (!empty($rule['required'])) {
                    $this->errors[$field] = $rule['required_message'] ?? '此字段为必填项';
                }
                continue;
            }
            
            try {
                // 基本类型验证和转换
                $validatedValue = $this->validateValue($value, $rule);
                
                // 应用额外验证规则
                $validatedValue = $this->applyExtraRules($field, $validatedValue, $rule, $data);
                
                $validated[$field] = $validatedValue;
            } catch (Exception $e) {
                $this->errors[$field] = $e->getMessage();
            }
        }
        
        return $validated;
    }
    
    /**
     * 验证嵌套字段
     * @param string $path 字段路径
     * @param array $rule 验证规则
     * @param array $data 输入数据
     * @return mixed 验证后的值
     */
    private function validateNestedField($path, $rule, $data) {
        $pathParts = explode('.', $path);
        $current = $data;
        
        foreach ($pathParts as $part) {
            if (!is_array($current) || !isset($current[$part])) {
                if (!empty($rule['required'])) {
                    $this->errors[$path] = $rule['required_message'] ?? '此字段为必填项';
                }
                return null;
            }
            $current = $current[$part];
        }
        
        try {
            return $this->validateValue($current, $rule);
        } catch (Exception $e) {
            $this->errors[$path] = $e->getMessage();
            return null;
        }
    }
    
    /**
     * 根据路径设置数组值
     * @param array $array 目标数组
     * @param string $path 字段路径
     * @param mixed $value 值
     */
    private function setValueByPath(&$array, $path, $value) {
        $keys = explode('.', $path);
        $current = &$array;
        
        foreach ($keys as $key) {
            if (!isset($current[$key]) || !is_array($current[$key])) {
                $current[$key] = [];
            }
            $current = &$current[$key];
        }
        
        $current = $value;
    }
    
    /**
     * 验证单个值
     * @param mixed $value 输入值
     * @param array $rule 验证规则
     * @return mixed 验证后的值
     * @throws Exception 验证失败时抛出异常
     */
    private function validateValue($value, $rule) {
        $type = $rule['type'] ?? 'string';
        $options = $rule['options'] ?? [];
        
        // 使用基础验证器进行类型验证和转换
        try {
            $validated = $this->inputValidator->validate($value, $type, $options);
        } catch (ValidationException $e) {
            throw new Exception($e->getMessage());
        }
        
        // 应用额外的安全处理
        if (in_array($type, ['string', 'text', 'html'])) {
            // 根据上下文进行不同级别的安全处理
            $securityLevel = $rule['security_level'] ?? 'default';
            $validated = $this->applySecurityFilter($validated, $securityLevel);
        }
        
        return $validated;
    }
    
    /**
     * 应用额外验证规则
     * @param string $field 字段名
     * @param mixed $value 验证后的值
     * @param array $rule 验证规则
     * @param array $data 所有输入数据
     * @return mixed 处理后的值
     * @throws Exception 验证失败时抛出异常
     */
    private function applyExtraRules($field, $value, $rule, $data) {
        // 验证自定义正则表达式
        if (isset($rule['pattern'])) {
            if (!preg_match($rule['pattern'], $value)) {
                throw new Exception($rule['pattern_message'] ?? '格式不正确');
            }
        }
        
        // 验证范围
        if (is_numeric($value)) {
            if (isset($rule['min']) && $value < $rule['min']) {
                throw new Exception($rule['min_message'] ?? '值不能小于' . $rule['min']);
            }
            if (isset($rule['max']) && $value > $rule['max']) {
                throw new Exception($rule['max_message'] ?? '值不能大于' . $rule['max']);
            }
        }
        
        // 验证允许的值
        if (isset($rule['allowed_values']) && !in_array($value, $rule['allowed_values'])) {
            throw new Exception($rule['allowed_values_message'] ?? '值不在允许范围内');
        }
        
        // 验证字段匹配（如密码确认）
        if (isset($rule['matches']) && isset($data[$rule['matches']])) {
            if ($value !== $data[$rule['matches']]) {
                throw new Exception($rule['matches_message'] ?? '字段不匹配');
            }
        }
        
        // 验证回调函数
        if (isset($rule['callback']) && is_callable($rule['callback'])) {
            $result = call_user_func($rule['callback'], $value, $data);
            if ($result !== true) {
                throw new Exception($rule['callback_message'] ?? '验证失败');
            }
        }
        
        // 唯一值验证
        if (isset($rule['unique']) && is_array($rule['unique'])) {
            [$table, $column] = $rule['unique'];
            $exclude = isset($rule['unique_exclude']) ? $rule['unique_exclude'] : [];
            
            if (!$this->isUnique($value, $table, $column, $exclude)) {
                throw new Exception($rule['unique_message'] ?? '此值已存在');
            }
        }
        
        return $value;
    }
    
    /**
     * 应用安全过滤器
     * @param string $value 输入值
     * @param string $level 安全级别
     * @return string 过滤后的值
     */
    private function applySecurityFilter($value, $level) {
        switch ($level) {
            case 'strict':
                // 最严格的过滤，移除所有HTML标签
                return strip_tags($value);
                
            case 'medium':
                // 中等过滤，保留基本HTML标签
                $allowedTags = '<p><br><strong><em><u><ul><ol><li><blockquote>';
                return strip_tags($value, $allowedTags);
                
            case 'html':
                // HTML内容过滤，允许安全的HTML标签
                return $this->sanitizeHTML($value);
                
            case 'none':
                // 不进行HTML过滤，但仍然进行基本的安全处理
                return SecurityUtils::sanitizeInput($value);
                
            default:
                // 默认过滤，进行HTML转义
                return htmlspecialchars($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
    }
    
    /**
     * 清理HTML内容
     * @param string $html HTML内容
     * @return string 清理后的HTML
     */
    private function sanitizeHTML($html) {
        // 移除危险的属性
        $html = preg_replace('/\s*(on\w+)\s*=\s*(["\'])(.*?)\2/i', '', $html);
        $html = preg_replace('/\s*(javascript|data):\s*(["\'])(.*?)\2/i', '', $html);
        
        // 移除危险的标签
        $dangerousTags = ['script', 'iframe', 'embed', 'object', 'form', 'input', 'button'];
        foreach ($dangerousTags as $tag) {
            $html = preg_replace('/<' . $tag . '[^>]*>(.*?)<\/' . $tag . '>/is', '', $html);
        }
        
        return $html;
    }
    
    /**
     * 检查值是否唯一
     * @param mixed $value 要检查的值
     * @param string $table 数据库表名
     * @param string $column 列名
     * @param array $exclude 排除条件
     * @return bool 是否唯一
     */
    private function isUnique($value, $table, $column, $exclude = []) {
        // 注意：实际使用时应替换为数据库连接和参数化查询
        // 这里仅作为示例框架
        return true; // 占位符
    }
    
    /**
     * 生成参数化查询数组
     * @param array $data 数据数组
     * @param array $map 字段映射
     * @return array 参数化查询数组
     */
    public function buildParams(array $data, array $map = []) {
        $params = [];
        $placeholders = [];
        
        foreach ($data as $field => $value) {
            $dbField = $map[$field] ?? $field;
            $paramName = ':' . $field;
            
            $params[$paramName] = $this->sanitizeForDatabase($value);
            $placeholders[] = $dbField . ' = ' . $paramName;
        }
        
        return [
            'params' => $params,
            'placeholders' => implode(', ', $placeholders)
        ];
    }
    
    /**
     * 数据库安全处理
     * @param mixed $value 输入值
     * @return mixed 处理后的值
     */
    private function sanitizeForDatabase($value) {
        if (is_null($value) || is_bool($value)) {
            return $value;
        }
        
        if (is_array($value)) {
            // 处理数组值，根据数据库类型可能需要特殊处理
            return json_encode($value);
        }
        
        if (is_string($value)) {
            // 基本的SQL注入防护
            // 注意：实际应用中应使用参数化查询
            $value = str_replace("'", "''", $value);
        }
        
        return $value;
    }
    
    /**
     * 创建数据库参数绑定数组
     * 用于PDO和其他数据库抽象层
     * @param array $data 输入数据
     * @return array 参数绑定数组
     */
    public function createBindParams(array $data) {
        $binds = [];
        
        foreach ($data as $key => $value) {
            $paramKey = is_numeric($key) ? $key + 1 : ':' . $key;
            $binds[$paramKey] = $this->sanitizeForDatabase($value);
        }
        
        return $binds;
    }
    
    /**
     * 验证并清理整个请求
     * @param array $rules 验证规则数组
     * @return array 验证后的请求数据
     */
    public function validateRequest(array $rules) {
        $method = strtoupper($_SERVER['REQUEST_METHOD']);
        
        switch ($method) {
            case 'GET':
                return $this->validateGet($rules['get'] ?? []);
                
            case 'POST':
                // 检查是否是JSON请求
                $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
                if (strpos($contentType, 'application/json') !== false) {
                    return $this->validateJson($rules['json'] ?? []);
                }
                return $this->validatePost($rules['post'] ?? []);
                
            default:
                // 其他请求方法处理
                $data = $this->parseRequestData($method);
                return $this->validateInputSource($method, $rules['all'] ?? [], $data);
        }
    }
    
    /**
     * 解析不同请求方法的数据
     * @param string $method 请求方法
     * @return array 解析后的数据
     */
    private function parseRequestData($method) {
        // 对于PUT、DELETE等方法，需要从请求体解析数据
        if (in_array($method, ['PUT', 'DELETE', 'PATCH'])) {
            parse_str(file_get_contents('php://input'), $data);
            return $data;
        }
        return [];
    }
    
    /**
     * 生成友好的错误消息响应
     * @param int $statusCode HTTP状态码
     * @return array 错误响应数组
     */
    public function getErrorResponse($statusCode = 400) {
        return [
            'status' => 'error',
            'status_code' => $statusCode,
            'message' => '请求数据验证失败',
            'errors' => $this->getErrors(),
            'timestamp' => time()
        ];
    }
    
    /**
     * 输出JSON错误响应
     * @param int $statusCode HTTP状态码
     */
    public function sendErrorResponse($statusCode = 400) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($this->getErrorResponse($statusCode));
        exit;
    }
    
    /**
     * 检查是否有验证错误
     * @return bool 是否有错误
     */
    public function hasErrors() {
        return !empty($this->errors);
    }
    
    /**
     * 获取特定字段的错误信息
     * @param string $field 字段名
     * @return string|null 错误信息
     */
    public function getError($field) {
        return $this->errors[$field] ?? null;
    }
}

/**
 * 全局辅助函数
 */

/**
 * 快速验证函数
 * @param string $source 输入源
 * @param array $rules 验证规则
 * @return array 验证结果
 */
function validate($source, $rules) {
    $validator = EnhancedValidator::getInstance();
    
    switch (strtolower($source)) {
        case 'post':
            return $validator->validatePost($rules);
        case 'get':
            return $validator->validateGet($rules);
        case 'json':
            return $validator->validateJson($rules);
        case 'files':
            return $validator->validateFiles($rules);
        default:
            return [];
    }
}

/**
 * 安全获取输入值
 * @param string $key 键名
 * @param mixed $default 默认值
 * @param string $source 输入源
 * @param string $type 数据类型
 * @return mixed 处理后的值
 */
function safe_input($key, $default = null, $source = 'post', $type = null) {
    $source = strtolower($source);
    $value = null;
    
    switch ($source) {
        case 'post':
            $value = isset($_POST[$key]) ? $_POST[$key] : null;
            break;
        case 'get':
            $value = isset($_GET[$key]) ? $_GET[$key] : null;
            break;
        case 'cookie':
            $value = isset($_COOKIE[$key]) ? $_COOKIE[$key] : null;
            break;
        case 'server':
            $value = isset($_SERVER[$key]) ? $_SERVER[$key] : null;
            break;
        case 'request':
            $value = isset($_REQUEST[$key]) ? $_REQUEST[$key] : null;
            break;
    }
    
    if ($value === null) {
        return $default;
    }
    
    // 安全处理
    $validator = EnhancedValidator::getInstance();
    $value = SecurityUtils::sanitizeInput($value);
    
    // 类型转换
    if ($type) {
        switch (strtolower($type)) {
            case 'int':
            case 'integer':
                $value = (int)$value;
                break;
            case 'float':
            case 'double':
                $value = (float)$value;
                break;
            case 'bool':
            case 'boolean':
                $value = (bool)$value;
                break;
            case 'array':
                $value = is_array($value) ? $value : [$value];
                break;
            case 'string':
                $value = (string)$value;
                break;
        }
    }
    
    return $value;
}

/**
 * 快速验证并获取错误
 * @param string $source 输入源
 * @param array $rules 验证规则
 * @return array [验证结果, 错误信息]
 */
function validate_with_errors($source, $rules) {
    $validator = EnhancedValidator::getInstance();
    $result = validate($source, $rules);
    
    return [$result, $validator->getErrors()];
}