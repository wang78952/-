<?php
/**
 * 文件监控钩子
 * 用于实时监控核心文件的变更
 * 注意：此文件是自动生成的，请勿手动修改
 * 
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

// 定义监控的核心文件列表
$MONITORED_FILES = [
    __DIR__ . '/../config.php',
    __DIR__ . '/Database.php',
    __DIR__ . '/ProductManager.php',
    __DIR__ . '/../index.php',
    __DIR__ . '/../admin/index.php'
];

// 核心文件的哈希值（由protect_core_files.php生成）
$FILE_HASHES = [
    __DIR__ . '/../config.php' => '',
    __DIR__ . '/Database.php' => '',
    __DIR__ . '/ProductManager.php' => '',
    __DIR__ . '/../index.php' => '',
    __DIR__ . '/../admin/index.php' => ''
];

/**
 * 计算文件的哈希值
 * @param string $file 文件路径
 * @return string 文件的哈希值
 */
function calculateFileHash($file) {
    if (file_exists($file) && is_readable($file)) {
        return sha1_file($file);
    }
    return '';
}

/**
 * 验证文件完整性
 * @param array $hashes 预计算的哈希值数组
 * @return array 验证结果
 */
function verifyFileIntegrity($hashes) {
    $results = [
        'status' => true,
        'modified_files' => []
    ];
    
    foreach ($hashes as $file => $original_hash) {
        if (file_exists($file)) {
            $current_hash = calculateFileHash($file);
            
            // 如果预计算的哈希值为空，使用当前哈希值（首次运行时）
            if (empty($original_hash)) {
                continue;
            }
            
            // 比较哈希值
            if ($current_hash !== $original_hash) {
                $results['status'] = false;
                $results['modified_files'][] = [
                    'file' => $file,
                    'original_hash' => $original_hash,
                    'current_hash' => $current_hash
                ];
            }
        }
    }
    
    return $results;
}

/**
 * 记录文件变更事件
 * @param array $modified_files 修改的文件数组
 */
function logFileChanges($modified_files) {
    $log_dir = __DIR__ . '/../logs';
    
    // 创建日志目录（如果不存在）
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    $log_file = $log_dir . '/file_changes_' . date('Y-m-d') . '.log';
    $log_content = date('Y-m-d H:i:s') . " - 检测到核心文件变更：\n";
    
    foreach ($modified_files as $file_info) {
        $log_content .= "  - 文件：" . basename($file_info['file']) . "\n";
        $log_content .= "    原始哈希：" . $file_info['original_hash'] . "\n";
        $log_content .= "    当前哈希：" . $file_info['current_hash'] . "\n";
    }
    
    // 写入日志
    file_put_contents($log_file, $log_content . "\n", FILE_APPEND);
}

/**
 * 尝试恢复被修改的文件
 * @param array $modified_files 修改的文件数组
 * @return array 恢复结果
 */
function restoreModifiedFiles($modified_files) {
    $restore_result = [
        'status' => true,
        'restored_files' => 0,
        'failed_files' => 0
    ];
    
    // 注意：在实际环境中，这里应该有一个备份机制
    // 本示例仅记录而不执行实际恢复操作
    
    foreach ($modified_files as $file_info) {
        $restore_result['failed_files']++;
    }
    
    return $restore_result;
}

// 执行文件完整性检查
function checkFileIntegrity() {
    global $FILE_HASHES;
    
    // 如果没有预计算的哈希值，计算并存储
    $needs_update = false;
    foreach ($FILE_HASHES as $file => &$hash) {
        if (empty($hash) && file_exists($file)) {
            $hash = calculateFileHash($file);
            $needs_update = true;
        }
    }
    unset($hash); // 解除引用
    
    // 如果哈希值需要更新，提示用户运行protect_core_files.php
    if ($needs_update) {
        error_log("文件监控钩子：需要更新文件哈希值，请运行 protect_core_files.php");
    }
    
    // 验证文件完整性
    $verification_result = verifyFileIntegrity($FILE_HASHES);
    
    // 如果检测到文件变更
    if (!$verification_result['status']) {
        // 记录变更
        logFileChanges($verification_result['modified_files']);
        
        // 尝试恢复文件
        $restore_result = restoreModifiedFiles($verification_result['modified_files']);
        
        // 如果恢复失败，显示警告信息
        if ($restore_result['failed_files'] > 0) {
            // 在非CLI模式下显示警告
            if (php_sapi_name() !== 'cli') {
                // 设置会话警告
                if (session_status() == PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['file_integrity_warning'] = true;
            }
        }
    }
}

// 检查是否处于代理模式
function isAgentMode() {
    $agent_info_file = __DIR__ . '/../agent_info.php';
    return file_exists($agent_info_file);
}

// 只在代理模式下执行监控（在非代理模式下管理员可以修改文件）
if (isAgentMode()) {
    // 延迟执行检查以避免影响页面加载速度
    register_shutdown_function('checkFileIntegrity');
}

/**
 * 添加文件保护措施
 * @param string $file_path 文件路径
 * @return bool 是否成功
 */
function addFileProtection($file_path) {
    // 检查文件是否存在
    if (!file_exists($file_path)) {
        return false;
    }
    
    // 在Windows系统中，我们可以尝试使用文件属性来提供额外保护
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // 尝试设置文件为只读
        return chmod($file_path, 0444);
    } else {
        // 在Linux/Unix系统中设置文件为只读
        return chmod($file_path, 0444);
    }
}

/**
 * 移除文件保护措施
 * @param string $file_path 文件路径
 * @return bool 是否成功
 */
function removeFileProtection($file_path) {
    // 检查文件是否存在
    if (!file_exists($file_path)) {
        return false;
    }
    
    // 设置文件为可写
    return chmod($file_path, 0644);
}

/**
 * 获取文件权限信息
 * @param string $file_path 文件路径
 * @return string 权限信息
 */
function getFilePermissions($file_path) {
    if (!file_exists($file_path)) {
        return '文件不存在';
    }
    
    $perms = fileperms($file_path);
    
    // 转换为八进制表示
    $octal = substr(sprintf('%o', $perms), -4);
    
    // 可读、可写、可执行检查
    $readable = is_readable($file_path) ? '可读' : '不可读';
    $writable = is_writable($file_path) ? '可写' : '不可写';
    $executable = is_executable($file_path) ? '可执行' : '不可执行';
    
    return "权限: $octal ($readable, $writable, $executable)";
}

?>