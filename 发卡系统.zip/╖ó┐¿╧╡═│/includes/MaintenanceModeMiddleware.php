<?php
/**
 * 维护模式中间件
 * 实现系统维护模式的请求拦截和管理
 * 支持IP白名单、管理员访问和API访问控制
 */

class MaintenanceModeMiddleware extends Middleware {
    /**
     * @var ConfigManager 配置管理器实例
     */
    private $configManager;
    
    /**
     * @var SecurityUtils 安全工具实例
     */
    private $securityUtils;
    
    /**
     * @var LogManager 日志管理器实例
     */
    private $logManager;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 获取依赖实例
        $this->configManager = ConfigManager::getInstance();
        $this->securityUtils = SecurityUtils::getInstance();
        $this->logManager = LogManager::getInstance();
    }
    
    /**
     * 处理请求
     * 
     * @param array $params 请求参数
     * @return bool 是否允许请求继续
     */
    public function handle($params) {
        // 获取维护模式配置
        $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
        
        // 检查维护模式是否启用
        if (empty($maintenanceConfig['enabled']) || $maintenanceConfig['enabled'] !== true) {
            return true; // 维护模式未启用，允许请求继续
        }
        
        // 获取客户端IP
        $clientIp = $this->securityUtils->getRealIpAddress();
        
        // 检查IP是否在白名单中
        if ($this->isIpWhitelisted($clientIp, $maintenanceConfig)) {
            $this->logManager->info('维护模式 - 白名单IP允许访问', [
                'ip' => $clientIp,
                'uri' => $_SERVER['REQUEST_URI'] ?? ''
            ]);
            return true;
        }
        
        // 检查是否是管理员
        if ($this->isAdminAccess()) {
            $this->logManager->info('维护模式 - 管理员允许访问', [
                'user_id' => $_SESSION['user_id'] ?? 'unknown',
                'uri' => $_SERVER['REQUEST_URI'] ?? ''
            ]);
            return true;
        }
        
        // 检查是否是API请求
        if ($this->isApiRequest()) {
            $this->handleApiRequest();
            return false;
        }
        
        // 处理普通请求
        $this->handleWebRequest($maintenanceConfig);
        return false;
    }
    
    /**
     * 检查IP是否在白名单中
     * 
     * @param string $ip IP地址
     * @param array $config 维护模式配置
     * @return bool 是否在白名单中
     */
    private function isIpWhitelisted($ip, $config) {
        $allowedIps = $config['allowed_ips'] ?? [];
        
        // 检查是否包含通配符IP
        foreach ($allowedIps as $allowedIp) {
            if ($allowedIp === '*') {
                return true;
            }
            
            // 检查精确匹配
            if ($ip === $allowedIp) {
                return true;
            }
            
            // 检查CIDR格式
            if (strpos($allowedIp, '/') !== false) {
                if ($this->isIpInCidr($ip, $allowedIp)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 检查IP是否在CIDR范围内
     * 
     * @param string $ip IP地址
     * @param string $cidr CIDR格式的IP范围
     * @return bool 是否在范围内
     */
    private function isIpInCidr($ip, $cidr) {
        list($subnet, $mask) = explode('/', $cidr);
        $ipDec = ip2long($ip);
        $subnetDec = ip2long($subnet);
        $maskDec = ~((1 << (32 - $mask)) - 1);
        
        return (($ipDec & $maskDec) === ($subnetDec & $maskDec));
    }
    
    /**
     * 检查是否是管理员访问
     * 
     * @return bool 是否是管理员
     */
    private function isAdminAccess() {
        // 检查用户是否已登录
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_roles'])) {
            return false;
        }
        
        // 检查用户角色
        $roles = $_SESSION['user_roles'];
        if (in_array('admin', $roles) || in_array('superadmin', $roles)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 检查是否是API请求
     * 
     * @return bool 是否是API请求
     */
    private function isApiRequest() {
        $requestUri = $_SERVER['REQUEST_URI'] ?? '';
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        
        // 检查URL是否包含API路径
        if (strpos($requestUri, '/api/') === 0 || strpos($requestUri, 'api.php') !== false) {
            return true;
        }
        
        // 检查Content-Type是否为JSON
        if (strpos($contentType, 'application/json') !== false) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 处理API请求
     */
    private function handleApiRequest() {
        http_response_code(503);
        header('Content-Type: application/json');
        
        $response = [
            'success' => false,
            'error' => 'SERVICE_UNAVAILABLE',
            'message' => '系统正在维护中，请稍后再试',
            'code' => 503
        ];
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * 处理Web请求
     * 
     * @param array $config 维护模式配置
     */
    private function handleWebRequest($config) {
        // 检查是否存在维护页面
        $maintenancePage = $config['maintenance_page'] ?? 'maintenance.php';
        $fullPath = APP_ROOT . '/' . $maintenancePage;
        
        if (file_exists($fullPath)) {
            // 设置503状态码
            http_response_code(503);
            header('Retry-After: 3600'); // 建议客户端1小时后重试
            
            // 包含维护页面
            include_once $fullPath;
            exit;
        } else {
            // 如果没有维护页面，显示默认的维护信息
            $this->displayDefaultMaintenancePage($config);
        }
    }
    
    /**
     * 显示默认的维护页面
     * 
     * @param array $config 维护模式配置
     */
    private function displayDefaultMaintenancePage($config) {
        http_response_code(503);
        header('Content-Type: text/html; charset=UTF-8');
        header('Retry-After: 3600');
        
        // 获取维护信息
        $message = $config['message'] ?? '系统正在进行定期维护，暂时无法访问。我们将尽快恢复服务，感谢您的理解与支持！';
        
        $html = <<<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统维护中 - 发卡系统</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 90%;
        }
        .logo {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
        }
        h1 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        p {
            font-size: 1.1rem;
            margin-bottom: 30px;
            color: #7f8c8d;
        }
        .countdown {
            font-size: 1.2rem;
            color: #e74c3c;
            margin: 20px 0;
        }
        .footer {
            margin-top: 30px;
            font-size: 0.9rem;
            color: #95a5a6;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>系统维护中</h1>
        <p>$message</p>
        <div class="countdown" id="countdown">
            <!-- 倒计时将在这里显示 -->
        </div>
        <div class="footer">
            <p>&copy; 2024 发卡系统 - 为您提供安全、稳定的发卡服务</p>
        </div>
    </div>
    
    <script>
        // 简单的倒计时功能
        function updateCountdown() {
            const now = new Date();
            const nextHour = new Date(now);
            nextHour.setHours(now.getHours() + 1, 0, 0, 0);
            
            const diff = nextHour - now;
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);
            
            document.getElementById('countdown').textContent = 
                `预计恢复时间：约 ${minutes} 分 ${seconds} 秒后`;
        }
        
        updateCountdown();
        setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
HTML;
        
        echo $html;
        exit;
    }
    
    /**
     * 紧急关闭维护模式
     * 
     * @param string $key 紧急关闭密钥
     * @return bool 是否成功
     */
    public function emergencyDisable($key) {
        $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
        
        // 验证紧急关闭密钥
        if (empty($maintenanceConfig['emergency_override']['key']) || 
            $maintenanceConfig['emergency_override']['key'] !== $key) {
            return false;
        }
        
        // 关闭维护模式
        $maintenanceConfig['enabled'] = false;
        
        // 保存配置
        $this->configManager->set('app.maintenance_mode', $maintenanceConfig);
        
        // 记录紧急关闭事件
        $this->logManager->warning('维护模式 - 紧急关闭', [
            'ip' => $this->securityUtils->getRealIpAddress()
        ]);
        
        return true;
    }
}