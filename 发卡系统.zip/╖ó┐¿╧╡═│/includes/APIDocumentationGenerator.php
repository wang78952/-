<?php
/**
 * API文档生成器
 * 自动生成API文档，支持多种格式输出
 */

require_once __DIR__ . '/APIVersionManager.php';

class APIDocumentationGenerator {
    
    private $versionManager;
    private $docs = array();
    private $config = array(
        'title' => '发卡系统 API 文档',
        'description' => '发卡系统RESTful API接口文档',
        'version' => '2.0.0',
        'base_url' => 'https://api.example.com',
        'contact' => array(
            'name' => 'API Support',
            'email' => 'support@example.com'
        ),
        'license' => array(
            'name' => 'MIT',
            'url' => 'https://opensource.org/licenses/MIT'
        )
    );
    
    public function __construct() {
        $this->versionManager = new APIVersionManager();
        $this->initializeDocumentation();
    }
    
    /**
     * 初始化文档结构
     */
    private function initializeDocumentation() {
        $this->docs = array(
            'openapi' => '3.0.0',
            'info' => array(
                'title' => $this->config['title'],
                'description' => $this->config['description'],
                'version' => $this->config['version'],
                'contact' => $this->config['contact'],
                'license' => $this->config['license']
            ),
            'servers' => array(
                array(
                    'url' => $this->config['base_url'],
                    'description' => '生产环境'
                ),
                array(
                    'url' => 'https://staging-api.example.com',
                    'description' => '测试环境'
                )
            ),
            'paths' => array(),
            'components' => array(
                'schemas' => array(),
                'securitySchemes' => array(),
                'responses' => array()
            )
        );
        
        $this->setupSecuritySchemes();
        $this->setupCommonSchemas();
        $this->setupCommonResponses();
    }
    
    /**
     * 设置安全认证方案
     */
    private function setupSecuritySchemes() {
        $this->docs['components']['securitySchemes'] = array(
            'BearerAuth' => array(
                'type' => 'http',
                'scheme' => 'bearer',
                'bearerFormat' => 'JWT'
            ),
            'ApiKeyAuth' => array(
                'type' => 'apiKey',
                'in' => 'header',
                'name' => 'X-API-Key'
            ),
            'BasicAuth' => array(
                'type' => 'http',
                'scheme' => 'basic'
            )
        );
    }
    
    /**
     * 设置通用数据模型
     */
    private function setupCommonSchemas() {
        $this->docs['components']['schemas'] = array(
            'User' => array(
                'type' => 'object',
                'properties' => array(
                    'id' => array(
                        'type' => 'integer',
                        'description' => '用户ID'
                    ),
                    'username' => array(
                        'type' => 'string',
                        'description' => '用户名'
                    ),
                    'email' => array(
                        'type' => 'string',
                        'format' => 'email',
                        'description' => '邮箱地址'
                    ),
                    'role' => array(
                        'type' => 'string',
                        'enum' => array('admin', 'user', 'moderator'),
                        'description' => '用户角色'
                    ),
                    'status' => array(
                        'type' => 'string',
                        'enum' => array('active', 'inactive', 'banned'),
                        'description' => '用户状态'
                    ),
                    'created_at' => array(
                        'type' => 'string',
                        'format' => 'date-time',
                        'description' => '创建时间'
                    ),
                    'updated_at' => array(
                        'type' => 'string',
                        'format' => 'date-time',
                        'description' => '更新时间'
                    )
                )
            ),
            'Product' => array(
                'type' => 'object',
                'properties' => array(
                    'id' => array(
                        'type' => 'integer',
                        'description' => '产品ID'
                    ),
                    'name' => array(
                        'type' => 'string',
                        'description' => '产品名称'
                    ),
                    'description' => array(
                        'type' => 'string',
                        'description' => '产品描述'
                    ),
                    'price' => array(
                        'type' => 'number',
                        'format' => 'float',
                        'description' => '产品价格'
                    ),
                    'category' => array(
                        'type' => 'string',
                        'description' => '产品分类'
                    ),
                    'stock' => array(
                        'type' => 'integer',
                        'description' => '库存数量'
                    ),
                    'status' => array(
                        'type' => 'string',
                        'enum' => array('active', 'inactive', 'out_of_stock'),
                        'description' => '产品状态'
                    ),
                    'created_at' => array(
                        'type' => 'string',
                        'format' => 'date-time',
                        'description' => '创建时间'
                    )
                )
            ),
            'Order' => array(
                'type' => 'object',
                'properties' => array(
                    'id' => array(
                        'type' => 'integer',
                        'description' => '订单ID'
                    ),
                    'user_id' => array(
                        'type' => 'integer',
                        'description' => '用户ID'
                    ),
                    'product_id' => array(
                        'type' => 'integer',
                        'description' => '产品ID'
                    ),
                    'quantity' => array(
                        'type' => 'integer',
                        'description' => '购买数量'
                    ),
                    'total_price' => array(
                        'type' => 'number',
                        'format' => 'float',
                        'description' => '订单总价'
                    ),
                    'status' => array(
                        'type' => 'string',
                        'enum' => array('pending', 'paid', 'completed', 'cancelled'),
                        'description' => '订单状态'
                    ),
                    'payment_method' => array(
                        'type' => 'string',
                        'description' => '支付方式'
                    ),
                    'created_at' => array(
                        'type' => 'string',
                        'format' => 'date-time',
                        'description' => '创建时间'
                    )
                )
            ),
            'Card' => array(
                'type' => 'object',
                'properties' => array(
                    'id' => array(
                        'type' => 'integer',
                        'description' => '卡密ID'
                    ),
                    'code' => array(
                        'type' => 'string',
                        'description' => '卡密代码'
                    ),
                    'product_id' => array(
                        'type' => 'integer',
                        'description' => '关联产品ID'
                    ),
                    'status' => array(
                        'type' => 'string',
                        'enum' => array('inactive', 'active', 'used'),
                        'description' => '卡密状态'
                    ),
                    'used_at' => array(
                        'type' => 'string',
                        'format' => 'date-time',
                        'description' => '使用时间'
                    ),
                    'expires_at' => array(
                        'type' => 'string',
                        'format' => 'date-time',
                        'description' => '过期时间'
                    )
                )
            ),
            'ErrorResponse' => array(
                'type' => 'object',
                'properties' => array(
                    'success' => array(
                        'type' => 'boolean',
                        'example' => false
                    ),
                    'error' => array(
                        'type' => 'object',
                        'properties' => array(
                            'message' => array(
                                'type' => 'string',
                                'description' => '错误信息'
                            ),
                            'code' => array(
                                'type' => 'integer',
                                'description' => '错误代码'
                            )
                        )
                    ),
                    'version' => array(
                        'type' => 'string',
                        'description' => 'API版本'
                    ),
                    'timestamp' => array(
                        'type' => 'integer',
                        'description' => '时间戳'
                    )
                )
            ),
            'SuccessResponse' => array(
                'type' => 'object',
                'properties' => array(
                    'success' => array(
                        'type' => 'boolean',
                        'example' => true
                    ),
                    'data' => array(
                        'type' => 'object',
                        'description' => '响应数据'
                    ),
                    'version' => array(
                        'type' => 'string',
                        'description' => 'API版本'
                    ),
                    'timestamp' => array(
                        'type' => 'integer',
                        'description' => '时间戳'
                    )
                )
            ),
            'PaginatedResponse' => array(
                'allOf' => array(
                    array(
                        '$ref' => '#/components/schemas/SuccessResponse'
                    ),
                    array(
                        'type' => 'object',
                        'properties' => array(
                            'data' => array(
                                'type' => 'object',
                                'properties' => array(
                                    'items' => array(
                                        'type' => 'array',
                                        'items' => array(
                                            'type' => 'object'
                                        )
                                    ),
                                    'pagination' => array(
                                        'type' => 'object',
                                        'properties' => array(
                                            'current_page' => array(
                                                'type' => 'integer'
                                            ),
                                            'total_pages' => array(
                                                'type' => 'integer'
                                            ),
                                            'total_items' => array(
                                                'type' => 'integer'
                                            ),
                                            'items_per_page' => array(
                                                'type' => 'integer'
                                            )
                                        )
                                    )
                                )
                            )
                        )
                )
                )
            ],
    }
    
    /**
     * 设置通用响应
     */
    private function setupCommonResponses() {
        $this->docs['components']['responses'] = array(
            'Unauthorized' => array(
                'description' => '未授权访问',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/ErrorResponse'
                        ),
                        'example' => array(
                            'success' => false,
                            'error' => array(
                                'message' => '未授权访问',
                                'code' => 401
                            ),
                            'version' => 'v1',
                            'timestamp' => 1640995200
                        )
                    )
                )
            ),
            'Forbidden' => array(
                'description' => '权限不足',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/ErrorResponse'
                        ),
                        'example' => array(
                            'success' => false,
                            'error' => array(
                                'message' => '权限不足',
                                'code' => 403
                            ),
                            'version' => 'v1',
                            'timestamp' => 1640995200
                        )
                    )
                )
            ),
            'NotFound' => array(
                'description' => '资源不存在',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/ErrorResponse'
                        ),
                        'example' => array(
                            'success' => false,
                            'error' => array(
                                'message' => '资源不存在',
                                'code' => 404
                            ),
                            'version' => 'v1',
                            'timestamp' => 1640995200
                        )
                    )
                )
            ),
            'ValidationError' => array(
                'description' => '请求参数验证失败',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/ErrorResponse'
                        ),
                        'example' => array(
                            'success' => false,
                            'error' => array(
                                'message' => '请求参数验证失败',
                                'code' => 422
                            ),
                            'version' => 'v1',
                            'timestamp' => 1640995200
                        )
                    )
                )
            ),
            'RateLimitExceeded' => array(
                'description' => '请求频率超限',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/ErrorResponse'
                        ),
                        'example' => array(
                            'success' => false,
                            'error' => array(
                                'message' => '请求频率超限',
                                'code' => 429
                            ),
                            'version' => 'v1',
                            'timestamp' => 1640995200
                        )
                    )
                )
            )
        );
    }
    
    /**
     * 生成API文档
     */
    public function generateDocumentation() {
        $versions = $this->versionManager->getVersionInfo();
        
        foreach ($versions as $version => $config) {
            $this->generateVersionDocumentation($version, $config);
        }
        
        return $this->docs;
    }
    
    /**
     * 生成特定版本的API文档
     */
    private function generateVersionDocumentation($version, $config) {
        $routes = $config['routes'];
        
        foreach ($routes as $method => $methodRoutes) {
            foreach ($methodRoutes as $path => $handler) {
                $this->generateEndpointDocumentation($method, $path, $handler, $version);
            }
        }
    }
    
    /**
     * 生成端点文档
     */
    private function generateEndpointDocumentation($method, $path, $handler, $version) {
        $endpointPath = "/api/{$version}{$path}";
        
        if (!isset($this->docs['paths'][$endpointPath])) {
            $this->docs['paths'][$endpointPath] = array();
        }
        
        $endpointDoc = array(
            'summary' => $this->getEndpointSummary($method, $path, $handler),
            'description' => $this->getEndpointDescription($method, $path, $handler),
            'operationId' => $this->generateOperationId($method, $path, $handler),
            'tags' => $this->getEndpointTags($handler),
            'security' => $this->getEndpointSecurity($method, $path),
            'parameters' => $this->getEndpointParameters($method, $path),
            'responses' => $this->getEndpointResponses($method, $path, $handler)
        );
        
        // 添加请求体（如果需要）
        if (in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $endpointDoc['requestBody'] = $this->getEndpointRequestBody($method, $path, $handler);
        }
        
        $this->docs['paths'][$endpointPath][strtolower($method)] = $endpointDoc;
    }
    
    /**
     * 获取端点摘要
     */
    private function getEndpointSummary($method, $path, $handler) {
        $summaries = array(
            'GET' => array(
                '/users' => '获取用户列表',
                '/users/{id}' => '获取用户详情',
                '/products' => '获取产品列表',
                '/products/{id}' => '获取产品详情',
                '/orders' => '获取订单列表',
                '/orders/{id}' => '获取订单详情'
            ),
            'POST' => array(
                '/users' => '创建新用户',
                '/products' => '创建新产品',
                '/orders' => '创建新订单',
                '/auth/login' => '用户登录',
                '/auth/logout' => '用户登出',
                '/batch' => '执行批量操作'
            ),
            'PUT' => array(
                '/users/{id}' => '更新用户信息',
                '/products/{id}' => '更新产品信息',
                '/orders/{id}' => '更新订单信息'
            ),
            'DELETE' => array(
                '/users/{id}' => '删除用户',
                '/products/{id}' => '删除产品',
                '/orders/{id}' => '删除订单'
            )
        );
        
        return isset($summaries[$method][$path]) ? $summaries[$method][$path] : "{$method} {$path}";
    }
    
    /**
     * 获取端点描述
     */
    private function getEndpointDescription($method, $path, $handler) {
        $descriptions = array(
            'GET' => array(
                '/users' => '获取系统中所有用户的列表，支持分页和筛选',
                '/products' => '获取所有产品的列表，支持分类筛选和搜索'
            ),
            'POST' => array(
                '/users' => '创建新用户账户，需要提供用户名、邮箱和密码',
                '/orders' => '创建新订单，需要指定产品和数量'
            )
        );
        
        return isset($descriptions[$method][$path]) ? $descriptions[$method][$path] : '';
    }
    
    /**
     * 生成操作ID
     */
    private function generateOperationId($method, $path, $handler) {
        list($controller, $action) = explode('@', $handler);
        $controllerName = str_replace('Controller', '', $controller);
        
        return strtolower($method) . ucfirst($controllerName) . ucfirst($action);
    }
    
    /**
     * 获取端点标签
     */
    private function getEndpointTags($handler) {
        $tags = array(
            'UserController' => array('用户管理'),
            'ProductController' => array('产品管理'),
            'OrderController' => array('订单管理'),
            'AuthController' => array('认证'),
            'BatchController' => array('批量操作')
        );
        
        list($controller, $action) = explode('@', $handler);
        return isset($tags[$controller]) ? $tags[$controller] : array('其他');
    }
    
    /**
     * 获取端点安全要求
     */
    private function getEndpointSecurity($method, $path) {
        // 公开端点（不需要认证）
        $publicEndpoints = array(
            'POST' => array('/auth/login'),
            'GET' => array('/products')
        );
        
        if (isset($publicEndpoints[$method]) && in_array($path, $publicEndpoints[$method])) {
            return array();
        }
        
        return array(
            array('BearerAuth' => array()),
            array('ApiKeyAuth' => array())
        );
    }
    
    /**
     * 获取端点参数
     */
    private function getEndpointParameters($method, $path) {
        $parameters = array();
        
        // 路径参数
        if (preg_match_all('/\{([^}]+)\}/', $path, $matches)) {
            foreach ($matches[1] as $paramName) {
                $parameters[] = array(
                    'name' => $paramName,
                    'in' => 'path',
                    'required' => true,
                    'schema' => array(
                        'type' => 'integer'
                    ),
                    'description' => ucfirst($paramName) . ' ID'
                );
            }
        }
        
        // 查询参数
        if ($method === 'GET') {
            $parameters[] = array(
                'name' => 'page',
                'in' => 'query',
                'required' => false,
                'schema' => array(
                    'type' => 'integer',
                    'default' => 1
                ),
                'description' => '页码'
            );
            
            $parameters[] = array(
                'name' => 'limit',
                'in' => 'query',
                'required' => false,
                'schema' => array(
                    'type' => 'integer',
                    'default' => 20,
                    'maximum' => 100
                ),
                'description' => '每页数量'
            );
            
            $parameters[] = array(
                'name' => 'sort',
                'in' => 'query',
                'required' => false,
                'schema' => array(
                    'type' => 'string'
                ),
                'description' => '排序字段'
            );
            
            $parameters[] = array(
                'name' => 'order',
                'in' => 'query',
                'required' => false,
                'schema' => array(
                    'type' => 'string',
                    'enum' => array('asc', 'desc'),
                    'default' => 'desc'
                ),
                'description' => '排序方向'
            );
        }
        
        return $parameters;
    }
    
    /**
     * 获取端点请求体
     */
    private function getEndpointRequestBody($method, $path, $handler) {
        $requestBodies = array(
            'POST' => array(
                '/users' => array(
                    'description' => '创建用户所需的数据',
                    'required' => true,
                    'content' => array(
                        'application/json' => array(
                            'schema' => array(
                                '$ref' => '#/components/schemas/User'
                            ),
                            'example' => array(
                                'username' => 'newuser',
                                'email' => 'user@example.com',
                                'password' => 'password123',
                                'role' => 'user'
                            )
                        )
                    )
                ),
                '/products' => array(
                    'description' => '创建产品所需的数据',
                    'required' => true,
                    'content' => array(
                        'application/json' => array(
                            'schema' => array(
                                '$ref' => '#/components/schemas/Product'
                            ),
                            'example' => array(
                                'name' => '新产品',
                                'description' => '产品描述',
                                'price' => 99.99,
                                'category' => '软件',
                                'stock' => 100
                            )
                        )
                    )
                ),
                '/auth/login' => array(
                    'description' => '登录凭据',
                    'required' => true,
                    'content' => array(
                        'application/json' => array(
                            'schema' => array(
                                'type' => 'object',
                                'properties' => array(
                                    'username' => array(
                                        'type' => 'string',
                                        'description' => '用户名'
                                    ),
                                    'password' => array(
                                        'type' => 'string',
                                        'description' => '密码'
                                    )
                                ),
                                'required' => array('username', 'password')
                            ),
                            'example' => array(
                                'username' => 'admin',
                                'password' => 'password123'
                            )
                        )
                    )
                )
            )
        );
        
        return isset($requestBodies[$method][$path]) ? $requestBodies[$method][$path] : null;
    }
    
    /**
     * 获取端点响应
     */
    private function getEndpointResponses($method, $path, $handler) {
        $responses = array(
            '200' => array(
                'description' => '操作成功',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/SuccessResponse'
                        )
                    )
                )
            ),
            '201' => array(
                'description' => '创建成功',
                'content' => array(
                    'application/json' => array(
                        'schema' => array(
                            '$ref' => '#/components/schemas/SuccessResponse'
                        )
                    )
                )
            ),
            '400' => array(
                '$ref' => '#/components/responses/ValidationError'
            ),
            '401' => array(
                '$ref' => '#/components/responses/Unauthorized'
            ),
            '403' => array(
                '$ref' => '#/components/responses/Forbidden'
            ),
            '404' => array(
                '$ref' => '#/components/responses/NotFound'
            ),
            '429' => array(
                '$ref' => '#/components/responses/RateLimitExceeded'
            )
        );
        
        // 根据HTTP方法选择默认响应
        $defaultResponse = in_array($method, array('POST', 'PUT', 'PATCH')) ? '201' : '200';
        
        return array(
            $defaultResponse => $responses[$defaultResponse],
            '400' => $responses['400'],
            '401' => $responses['401'],
            '403' => $responses['403'],
            '404' => $responses['404'],
            '429' => $responses['429']
        );
    }
    
    /**
     * 导出为JSON格式
     */
    public function exportJSON() {
        return json_encode($this->docs, 128); // JSON_PRETTY_PRINT = 128
    }
    
    /**
     * 导出为YAML格式
     */
    public function exportYAML() {
        if (!function_exists('yaml_emit')) {
            throw new Exception('YAML extension not available');
        }
        
        return yaml_emit($this->docs, YAML_UTF8_ENCODING);
    }
    
    /**
     * 生成HTML文档
     */
    public function generateHTML() {
        $html = '<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . $this->config['title'] . '</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .endpoint { border: 1px solid #dee2e6; border-radius: 8px; margin-bottom: 20px; }
        .endpoint-header { padding: 15px; border-bottom: 1px solid #dee2e6; }
        .method-get { background-color: #28a745; color: white; }
        .method-post { background-color: #007bff; color: white; }
        .method-put { background-color: #ffc107; color: black; }
        .method-delete { background-color: #dc3545; color: white; }
        .endpoint-body { padding: 15px; }
        .code-block { background-color: #f8f9fa; padding: 10px; border-radius: 4px; font-family: monospace; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <nav class="sticky-top">
                    <h4>目录</h4>
                    <ul class="nav flex-column">';
        
        // 生成侧边栏导航
        foreach ($this->docs['paths'] as $path => $methods) {
            foreach ($methods as $method => $endpoint) {
                $html .= '<li class="nav-item"><a class="nav-link" href="#' . $endpoint['operationId'] . '">' . strtoupper($method) . ' ' . $path . '</a></li>';
            }
        }
        
        $html .= '</ul>' .
                '</nav>' .
            '</div>' .
            '<div class="col-md-9">' .
                '<div class="mt-4">' .
                    '<h1>' . $this->config['title'] . '</h1>' .
                    '<p>' . $this->config['description'] . '</p>' .
                    '<p><strong>版本:</strong> ' . $this->config['version'] . '</p>' .
                    '<p><strong>基础URL:</strong> ' . $this->config['base_url'] . '</p>' .
                '</div>';
        
        // 生成端点文档
        foreach ($this->docs['paths'] as $path => $methods) {
            foreach ($methods as $method => $endpoint) {
                $html .= '<div class="endpoint" id="' . $endpoint['operationId'] . '">' .
                    '<div class="endpoint-header method-' . $method . '">' .
                        '<h4>' . strtoupper($method) . ' ' . $path . '</h4>' .
                        '<p>' . $endpoint['summary'] . '</p>' .
                    '</div>' .
                    '<div class="endpoint-body">' .
                        '<h5>描述</h5>' .
                        '<p>' . $endpoint['description'] . '</p>';
                
                // 参数
                if (!empty($endpoint['parameters'])) {
                    $html .= '<h5>参数</h5>' .
                        '<table class="table table-striped">' .
                            '<thead>' .
                                '<tr>' .
                                    '<th>名称</th>' .
                                    '<th>位置</th>' .
                                    '<th>类型</th>' .
                                    '<th>必需</th>' .
                                    '<th>描述</th>' .
                                '</tr>' .
                            '</thead>' .
                            '<tbody>';
                    
                    foreach ($endpoint['parameters'] as $param) {
                        $html .= '<tr>' .
                            '<td>' . $param['name'] . '</td>' .
                            '<td>' . $param['in'] . '</td>' .
                            '<td>' . (isset($param['schema']['type']) ? $param['schema']['type'] : '') . '</td>' .
                            '<td>' . ($param['required'] ? '是' : '否') . '</td>' .
                            '<td>' . (isset($param['description']) ? $param['description'] : '') . '</td>' .
                        '</tr>';
                    }
                    
                    $html .= '</tbody></table>';
                }
                
                // 响应
                $html .= '<h5>响应</h5>';
                foreach ($endpoint['responses'] as $code => $response) {
                    $html .= '<h6>HTTP ' . $code . ' - ' . $response['description'] . '</h6>';
                    if (isset($response['content']['application/json']['example'])) {
                        $html .= '<div class="code-block">' . 
                            json_encode($response['content']['application/json']['example'], 128) . // JSON_PRETTY_PRINT = 128
                        '</div>';
                    }
                }
                
                $html .= '</div></div>';
            }
        }
        
        $html .= '</div></div></div>' .
            '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>' .
        '</body>' .
        '</html>';
        
        return $html;
    }
    
    /**
     * 保存文档到文件
     */
    public function saveToFile($filename, $format = 'json') {
        $content = '';
        
        switch ($format) {
            case 'json':
                $content = $this->exportJSON();
                break;
            case 'yaml':
                $content = $this->exportYAML();
                break;
            case 'html':
                $content = $this->generateHTML();
                break;
            default:
                throw new Exception("Unsupported format: {$format}");
        }
        
        $result = file_put_contents($filename, $content);
        if ($result === false) {
            throw new Exception("Failed to save documentation to file: {$filename}");
        }
        
        return true;
    }
}