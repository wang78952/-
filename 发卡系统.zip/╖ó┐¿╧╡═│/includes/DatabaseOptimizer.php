<?php

/**
 * 数据库查询优化器
 * 提供查询优化、索引建议、性能监控等功能
 */
class DatabaseOptimizer 
{
    private $database;
    private $queryCache = array();
    private $slowQueryLog = array();
    private $indexRecommendations = array();
    private $performanceMetrics = array();
    
    public function __construct() 
    {
        $this->database = Database::getInstance();
    }
    
    /**
     * 优化统计查询 - 将多个COUNT查询合并为单个查询
     */
    public function optimizeStatusStats($table, $statusColumn = 'status') 
    {
        $cacheKey = "status_stats_{$table}";
        
        // 检查缓存
        if (isset($this->queryCache[$cacheKey]) && 
            (time() - $this->queryCache[$cacheKey]['timestamp']) < 300) {
            return $this->queryCache[$cacheKey]['data'];
        }
        
        $sql = "
            SELECT 
                {$statusColumn} as status,
                COUNT(*) as count
            FROM {$table}
            WHERE {$statusColumn} IS NOT NULL
            GROUP BY {$statusColumn}
        ";
        
        $results = $this->database->queryAll($sql);
        
        // 转换为键值对格式
        $stats = array();
        foreach ($results as $row) {
            $stats[$row['status']] = (int)$row['count'];
        }
        
        // 缓存结果
        $this->queryCache[$cacheKey] = array(
            'data' => $stats,
            'timestamp' => time()
        );
        
        return $stats;
    }
    
    /**
     * 优化用户统计查询
     */
    public function getUserStats() 
    {
        $cacheKey = 'user_stats_optimized';
        
        if (isset($this->queryCache[$cacheKey]) && 
            (time() - $this->queryCache[$cacheKey]['timestamp']) < 600) {
            return $this->queryCache[$cacheKey]['data'];
        }
        
        $sql = "
            SELECT 
                SUM(CASE WHEN status != 'deleted' THEN 1 ELSE 0 END) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive,
                SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended,
                SUM(CASE WHEN status = 'deleted' THEN 1 ELSE 0 END) as deleted,
                COUNT(*) as all_users
            FROM users
        ";
        
        $result = $this->database->queryOne($sql);
        
        $stats = array(
            'total' => (int)$result['total'],
            'active' => (int)$result['active'],
            'inactive' => (int)$result['inactive'],
            'suspended' => (int)$result['suspended'],
            'deleted' => (int)$result['deleted'],
            'all_users' => (int)$result['all_users']
        );
        
        $this->queryCache[$cacheKey] = array(
            'data' => $stats,
            'timestamp' => time()
        );
        
        return $stats;
    }
    
    /**
     * 优化卡片统计查询
     */
    public function getCardStats() 
    {
        $cacheKey = 'card_stats_optimized';
        
        if (isset($this->queryCache[$cacheKey]) && 
            (time() - $this->queryCache[$cacheKey]['timestamp']) < 300) {
            return $this->queryCache[$cacheKey]['data'];
        }
        
        $sql = "
            SELECT 
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive,
                SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                COUNT(*) as total
            FROM cards
        ";
        
        $result = $this->database->queryOne($sql);
        
        $stats = array(
            'active' => (int)$result['active'],
            'inactive' => (int)$result['inactive'],
            'suspended' => (int)$result['suspended'],
            'cancelled' => (int)$result['cancelled'],
            'expired' => (int)$result['expired'],
            'pending' => (int)$result['pending'],
            'total' => (int)$result['total']
        );
        
        // 获取银行统计
        $bankSql = "
            SELECT bank_name, COUNT(*) as count 
            FROM cards 
            WHERE bank_name != '' AND bank_name IS NOT NULL
            GROUP BY bank_name 
            ORDER BY count DESC 
            LIMIT 10
        ";
        $bankStats = $this->database->queryAll($bankSql);
        $stats['bank_distribution'] = $bankStats;
        
        $this->queryCache[$cacheKey] = array(
            'data' => $stats,
            'timestamp' => time()
        );
        
        return $stats;
    }
    
    /**
     * 优化身份验证统计查询
     */
    public function getVerificationStats() 
    {
        $cacheKey = 'verification_stats_optimized';
        
        if (isset($this->queryCache[$cacheKey]) && 
            (time() - $this->queryCache[$cacheKey]['timestamp']) < 300) {
            return $this->queryCache[$cacheKey]['data'];
        }
        
        $sql = "
            SELECT 
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                COUNT(*) as total
            FROM identity_verifications
        ";
        
        $result = $this->database->queryOne($sql);
        
        $stats = array(
            'pending' => (int)$result['pending'],
            'approved' => (int)$result['approved'],
            'rejected' => (int)$result['rejected'],
            'failed' => (int)$result['failed'],
            'total' => (int)$result['total']
        );
        
        $this->queryCache[$cacheKey] = array(
            'data' => $stats,
            'timestamp' => time()
        );
        
        return $stats;
    }
    
    /**
     * 优化合规统计查询
     */
    public function getComplianceStats() 
    {
        $cacheKey = 'compliance_stats_optimized';
        
        if (isset($this->queryCache[$cacheKey]) && 
            (time() - $this->queryCache[$cacheKey]['timestamp']) < 600) {
            return $this->queryCache[$cacheKey]['data'];
        }
        
        $sql = "
            SELECT 
                (SELECT COUNT(*) FROM security_logs WHERE DATE(created_at) = CURDATE()) as security_events,
                (SELECT COUNT(*) FROM compliance_alerts WHERE status = 'active') as compliance_alerts,
                (SELECT COUNT(*) FROM data_access_authorizations WHERE DATE(created_at) = CURDATE()) as data_access_requests
        ";
        
        $result = $this->database->queryOne($sql);
        
        $stats = array(
            'security_events' => (int)$result['security_events'],
            'compliance_alerts' => (int)$result['compliance_alerts'],
            'data_access_requests' => (int)$result['data_access_requests']
        );
        
        $this->queryCache[$cacheKey] = array(
            'data' => $stats,
            'timestamp' => time()
        );
        
        return $stats;
    }
    
    /**
     * 批量操作优化
     */
    public function batchUpdate($table, $data, $conditionField, $batchSize = 100) 
    {
        if (empty($data)) {
            return 0;
        }
        
        $updated = 0;
        $batches = array_chunk($data, $batchSize);
        
        foreach ($batches as $batch) {
            $this->database->beginTransaction();
            
            try {
                foreach ($batch as $item) {
                    $id = $item[$conditionField];
                    unset($item[$conditionField]);
                    
                    $setParts = array();
                    $params = array();
                    
                    foreach ($item as $field => $value) {
                        $setParts[] = "{$field} = ?";
                        $params[] = $value;
                    }
                    $params[] = $id;
                    
                    $sql = "UPDATE {$table} SET " . implode(', ', $setParts) . " WHERE {$conditionField} = ?";
                    $this->database->query($sql, $params);
                    $updated++;
                }
                
                $this->database->commit();
            } catch (Exception $e) {
                $this->database->rollback();
                throw $e;
            }
        }
        
        return $updated;
    }
    
    /**
     * 分析查询性能
     */
    public function analyzeQuery($sql, $params = array()) 
    {
        $startTime = microtime(true);
        
        try {
            $result = $this->database->queryAll($sql, $params);
            $executionTime = (microtime(true) - $startTime) * 1000; // 毫秒
            
            $this->recordQueryPerformance($sql, $params, $executionTime);
            
            return array(
                'result' => $result,
                'execution_time' => $executionTime,
                'performance_info' => $this->getQueryPerformanceInfo($sql, $executionTime)
            );
            
        } catch (Exception $e) {
            $executionTime = (microtime(true) - $startTime) * 1000;
            $this->recordQueryPerformance($sql, $params, $executionTime, false);
            
            throw $e;
        }
    }
    
    /**
     * 记录查询性能
     */
    private function recordQueryPerformance($sql, $params, $executionTime, $success = true) 
    {
        $this->performanceMetrics[] = array(
            'sql' => $sql,
            'params' => $params,
            'execution_time' => $executionTime,
            'success' => $success,
            'timestamp' => date('Y-m-d H:i:s')
        );
        
        // 慢查询记录
        if ($executionTime > 1000) { // 超过1秒
            $this->slowQueryLog[] = array(
                'sql' => $sql,
                'params' => $params,
                'execution_time' => $executionTime,
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            // 记录到系统日志
            error_log("Slow Query: {$executionTime}ms - {$sql}");
        }
        
        // 限制日志大小
        if (count($this->performanceMetrics) > 1000) {
            $this->performanceMetrics = array_slice($this->performanceMetrics, -500);
        }
        
        if (count($this->slowQueryLog) > 100) {
            $this->slowQueryLog = array_slice($this->slowQueryLog, -50);
        }
    }
    
    /**
     * 获取查询性能信息
     */
    private function getQueryPerformanceInfo($sql, $executionTime) 
    {
        $info = array(
            'category' => 'normal',
            'recommendations' => array()
        );
        
        if ($executionTime > 5000) {
            $info['category'] = 'critical';
            $info['recommendations'][] = '查询执行时间过长，需要立即优化';
        } elseif ($executionTime > 2000) {
            $info['category'] = 'slow';
            $info['recommendations'][] = '查询较慢，建议优化';
        } elseif ($executionTime > 1000) {
            $info['category'] = 'moderate';
            $info['recommendations'][] = '查询速度一般，可考虑优化';
        }
        
        // 分析SQL类型
        if (stripos($sql, 'SELECT') === 0) {
            if (stripos($sql, 'GROUP BY') !== false) {
                $info['recommendations'][] = 'GROUP BY操作，确保相关字段有索引';
            }
            if (stripos($sql, 'ORDER BY') !== false) {
                $info['recommendations'][] = 'ORDER BY操作，确保排序字段有索引';
            }
            if (stripos($sql, 'JOIN') !== false) {
                $info['recommendations'][] = 'JOIN操作，确保连接字段有索引';
            }
        }
        
        return $info;
    }
    
    /**
     * 获取索引建议
     */
    public function getIndexRecommendations() 
    {
        $recommendations = array();
        $uniqueKeys = array(); // 用于跟踪唯一推荐项的键
        
        // 分析慢查询
        foreach ($this->slowQueryLog as $query) {
            $sql = $query['sql'];
            
            // 检查WHERE条件字段
            if (preg_match('/WHERE\s+([^\\s]+)/i', $sql, $matches)) {
                $field = $matches[1];
                $key = 'where_' . $field; // 创建唯一键
                
                if (!isset($uniqueKeys[$key])) {
                    $uniqueKeys[$key] = true;
                    $recommendations[] = array(
                        'type' => 'where_index',
                        'field' => $field,
                        'reason' => 'WHERE条件字段需要索引',
                        'sql' => "CREATE INDEX idx_{$field} ON table_name ({$field})"
                    );
                }
            }
            
            // 检查JOIN字段
            if (preg_match_all('/JOIN\s+\w+\s+ON\s+([^\\s]+)\s*=\s*([^\\s]+)/i', $sql, $matches)) {
                $matchFields = is_array($matches[1]) ? $matches[1] : array();
                for ($i = 0; $i < count($matchFields); $i++) {
                    $field1 = $matchFields[$i];
                    $key = 'join_' . $field1; // 创建唯一键
                    
                    if (!isset($uniqueKeys[$key])) {
                        $uniqueKeys[$key] = true;
                        $recommendations[] = array(
                            'type' => 'join_index',
                            'field' => $field1,
                            'reason' => 'JOIN连接字段需要索引',
                            'sql' => "CREATE INDEX idx_{$field1} ON table_name ({$field1})"
                        );
                    }
                }
            }
        }
        
        return $recommendations;
    }
    
    /**
     * 清理查询缓存
     */
    public function clearCache() 
    {
        $this->queryCache = array();
    }
    
    /**
     * 获取性能报告
     */
    public function getPerformanceReport() 
    {
        $totalQueries = count($this->performanceMetrics);
        $slowQueries = count($this->slowQueryLog);
        
        if ($totalQueries === 0) {
            return array(
                'total_queries' => 0,
                'slow_queries' => 0,
                'slow_query_rate' => 0,
                'avg_execution_time' => 0,
                'recommendations' => array()
            );
        }
        
        $totalTime = array_sum(array_column($this->performanceMetrics, 'execution_time'));
        $avgTime = $totalTime / $totalQueries;
        $slowQueryRate = ($slowQueries / $totalQueries) * 100;
        
        return array(
            'total_queries' => $totalQueries,
            'slow_queries' => $slowQueries,
            'slow_query_rate' => round($slowQueryRate, 2),
            'avg_execution_time' => round($avgTime, 2),
            'recommendations' => $this->getIndexRecommendations()
        );
    }
    
    /**
     * 获取慢查询日志
     */
    public function getSlowQueries() 
    {
        return $this->slowQueryLog;
    }
    
    /**
     * 清理性能日志
     */
    public function clearPerformanceLog() 
    {
        $this->performanceMetrics = array();
        $this->slowQueryLog = array();
    }
}