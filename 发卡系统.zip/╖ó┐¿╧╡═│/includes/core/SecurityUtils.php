<?php
/**
 * 安全加密工具类
 * 提供全面的安全功能：SQL注入防护、XSS过滤、AES加密解密、数据脱敏、CSRF防护等
 * 符合商业级安全标准和PCI DSS合规要求
 */
class SecurityUtils 
{
    // AES加密配置
    private const AES_METHOD = 'AES-256-CBC';
    private const HASH_ALGO = 'sha256';
    
    /**
     * 获取加密密钥
     * 在生产环境中应从环境变量或安全配置中获取
     */
    private static function getEncryptionKey() 
    {
        // 生产环境应使用环境变量或密钥管理服务
        return hash(self::HASH_ALGO, getenv('ENCRYPTION_KEY') ? getenv('ENCRYPTION_KEY') : 'CardSystem2024SecureKey!@#$%^&*()');
    }
    
    /**
     * AES加密敏感数据
     * @param string $data 需要加密的数据
     * @return string 加密后的Base64字符串
     */
    public static function encrypt($data) 
    {
        if (empty($data)) {
            return $data;
        }
        
        $key = self::getEncryptionKey();
        $iv = random_bytes(openssl_cipher_iv_length(self::AES_METHOD));
        
        $encrypted = openssl_encrypt($data, self::AES_METHOD, $key, 0, $iv);
        
        if ($encrypted === false) {
            throw new Exception('数据加密失败');
        }
        
        // 将IV和加密数据组合后Base64编码
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * AES解密敏感数据
     * @param string $encryptedData 加密的Base64字符串
     * @return string 解密后的原始数据
     */
    public static function decrypt($encryptedData) 
    {
        if (empty($encryptedData)) {
            return $encryptedData;
        }
        
        $key = self::getEncryptionKey();
        $data = base64_decode($encryptedData);
        
        if ($data === false) {
            throw new Exception('加密数据格式错误');
        }
        
        $ivLength = openssl_cipher_iv_length(self::AES_METHOD);
        $iv = substr($data, 0, $ivLength);
        $encrypted = substr($data, $ivLength);
        
        $decrypted = openssl_decrypt($encrypted, self::AES_METHOD, $key, 0, $iv);
        
        if ($decrypted === false) {
            throw new Exception('数据解密失败');
        }
        
        return $decrypted;
    }
    
    /**
     * 卡号脱敏显示
     * @param string $cardNumber 完整卡号
     * @return string 脱敏后的卡号
     */
    public static function maskCardNumber($cardNumber) 
    {
        if (strlen($cardNumber) < 8) {
            return $cardNumber;
        }
        
        // 显示前4位和后4位，中间用*替代
        return substr($cardNumber, 0, 4) . str_repeat('*', strlen($cardNumber) - 8) . substr($cardNumber, -4);
    }
    
    /**
     * 姓名脱敏
     * @param string $name 姓名
     * @return string 脱敏后的姓名
     */
    public static function maskName($name) 
    {
        if (empty($name)) {
            return $name;
        }
        
        $length = mb_strlen($name);
        if ($length <= 2) {
            return $name[0] . '*';
        }
        
        return mb_substr($name, 0, 1) . str_repeat('*', $length - 2) . mb_substr($name, -1);
    }
    
    /**
     * 手机号脱敏
     * @param string $phone 手机号
     * @return string 脱敏后的手机号
     */
    public static function maskPhone($phone) 
    {
        if (strlen($phone) < 7) {
            return $phone;
        }
        
        return substr($phone, 0, 3) . '****' . substr($phone, -4);
    }
    
    /**
     * XSS防护 - HTML特殊字符转义
     * @param string $input 输入字符串
     * @return string 过滤后的安全字符串
     */
    public static function escapeHtml($input) 
    {
        return htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    /**
     * 输入验证和过滤
     * @param string $input 输入数据
     * @param string $type 验证类型：card_number, phone, email, name, general
     * @return string 过滤后的数据
     */
    public static function validateInput($input, $type = 'general') 
    {
        $input = trim($input);
        
        switch ($type) {
            case 'card_number':
                // 只保留数字
                return preg_replace('/\D/', '', $input);
                
            case 'phone':
                // 只保留数字
                return preg_replace('/\D/', '', $input);
                
            case 'email':
                // 邮箱格式验证
                if (!filter_var($input, FILTER_VALIDATE_EMAIL)) {
                    throw new InvalidArgumentException('邮箱格式不正确');
                }
                return strtolower($input);
                
            case 'name':
                // 姓名只允许中文、英文、空格
                if (!preg_match('/^[\p{L}\s]+$/u', $input)) {
                    throw new InvalidArgumentException('姓名格式不正确');
                }
                return $input;
                
            case 'general':
            default:
                // 移除HTML标签和特殊字符
                return strip_tags($input);
        }
    }
    
    /**
     * 输入数据清理（别名方法，为了向后兼容）
     * @param string $input 输入数据
     * @return string 清理后的数据
     */
    public static function sanitizeInput($input) 
    {
        return self::validateInput($input, 'general');
    }
    
    /**
     * 生成随机令牌
     * @param int $length 令牌长度
     * @return string 随机令牌
     */
    public static function generateToken($length = 32) 
    {
        return bin2hex(openssl_random_pseudo_bytes($length / 2));
    }
    
    /**
     * 生成安全的随机令牌
     * @param int $length 令牌长度
     * @return string 安全随机令牌
     */
    public static function generateSecureToken($length = 32) 
    {
        return bin2hex(openssl_random_pseudo_bytes($length / 2));
    }
    
    /**
     * 计算时间差并返回友好的时间描述
     * @param string $datetime 时间字符串
     * @return string 友好的时间描述
     */
    public static function timeAgo($datetime) 
    {
        $time = strtotime($datetime);
        $now = time();
        $diff = $now - $time;
        
        if ($diff < 60) {
            return '刚刚';
        } elseif ($diff < 3600) {
            return floor($diff / 60) . '分钟前';
        } elseif ($diff < 86400) {
            return floor($diff / 3600) . '小时前';
        } elseif ($diff < 2592000) {
            return floor($diff / 86400) . '天前';
        } elseif ($diff < 31536000) {
            return floor($diff / 2592000) . '个月前';
        } else {
            return floor($diff / 31536000) . '年前';
        }
    }
    
    /**
     * 获取客户端IP地址
     * @return string IP地址
     */
    public static function getClientIP() 
    {        
        // 确保IPAddressManager类已加载
        if (!class_exists('IPAddressManager')) {
            require_once __DIR__ . '/IPAddressManager.php';
        }
        
        // 使用IPAddressManager获取客户端IP
        $ipManager = getIPManager();
        return $ipManager->getClientIP();
    }
    
    /**
     * 记录安全日志
     * @param string $level 日志级别：info, warning, error
     * @param string $message 日志消息
     * @param array $context 上下文信息
     */
    public static function logSecurity($level, $message, $context = array()) 
    {
        $logEntry = array(
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => $level,
            'message' => $message,
            'ip' => self::getClientIP(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'context' => $context
        );
        
        $logFile = dirname(__DIR__) . '/logs/security.log';
        $logDir = dirname($logFile);
        
        // 创建日志目录
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // 写入日志
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
    
    /**
     * 密码哈希
     * @param string $password 明文密码
     * @return string 哈希后的密码
     */
    public static function hashPassword($password) 
    {
        return password_hash($password, PASSWORD_DEFAULT);
    }
    
    /**
     * 验证密码
     * @param string $password 明文密码
     * @param string $hash 哈希密码
     * @return bool 验证结果
     */
    public static function verifyPassword($password, $hash) 
    {
        return password_verify($password, $hash);
    }
    
    /**
     * 生成签名
     * @param array $data 待签名数据
     * @param string $secret 密钥
     * @return string 签名
     */
    public static function generateSignature($data, $secret) 
    {
        // 排序数据
        ksort($data);
        
        // 构建签名字符串
        $signString = '';
        foreach ($data as $key => $value) {
            if ($value !== '' && $value !== null) {
                $signString .= $key . '=' . $value . '&';
            }
        }
        $signString = rtrim($signString, '&');
        
        // 添加密钥
        $signString .= '&key=' . $secret;
        
        // 生成签名
        return md5($signString);
    }
    
    /**
     * 验证API签名
     * @param array $data 待验证数据
     * @param string $signature 签名值
     * @param string $secret 签名密钥
     * @return bool 验证结果
     */
    public static function verifySignature($data, $signature, $secret) 
    {
        $expectedSignature = self::generateSignature($data, $secret);
        return $expectedSignature === $signature;
    }
    
    /**
     * CSRF令牌生成
     * @return string CSRF令牌
     */
    public static function generateCSRFToken() 
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $token = self::generateToken(32);
        $_SESSION['csrf_token'] = $token;
        $_SESSION['csrf_token_time'] = time();
        
        return $token;
    }
    
    /**
     * CSRF令牌验证
     * @param string $token 提交的令牌
     * @return bool 验证结果
     */
    public static function validateCSRFToken($token) 
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * 验证CSRF令牌
     * @param string $token 提交的令牌
     * @param int $maxAge 最大有效期（秒）
     * @return bool 验证结果
     */
    public static function verifyCSRFToken($token, $maxAge = 3600) 
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }
        
        // 验证令牌
        if ($_SESSION['csrf_token'] !== $token) {
            return false;
        }
        
        // 验证时间
        if (time() - $_SESSION['csrf_token_time'] > $maxAge) {
            return false;
        }
        
        return true;
    }
    
    /**
     * SQL注入防护 - 输入参数清理
     * @param string $input 输入数据
     * @return string 清理后的数据
     */
    public static function protectSQL($input) 
    {
        if (is_array($input)) {
            // 递归处理数组
            return array_map([self::class, 'protectSQL'], $input);
        }
        
        // 移除SQL关键字和特殊字符
        $patterns = [
            // SQL注释
            '/\/\*.*?\*\//is',
            '/(--.*?)$/im',
            
            // 常见SQL注入模式
            '/\s+UNION\s+ALL?\s+/i',
            '/\s+INSERT\s+/i',
            '/\s+UPDATE\s+/i',
            '/\s+DELETE\s+/i',
            '/\s+DROP\s+/i',
            '/\s+ALTER\s+/i',
            '/\s+EXEC\s+/i',
            '/\s+EXECUTE\s+/i',
            '/\s+XP_\w+/i',
            '/\s+SELECT\s+/i',
            '/\s+FROM\s+/i',
            '/\s+WHERE\s+/i',
            '/\s+OR\s+1/i',
            '/\s+AND\s+1/i',
            
            // 危险字符
            '/\x00/',
            '/\x1a/',
            
            // 引号处理
            '/\s*;\s*/',
            '/\s*\\s*/',
        ];
        
        $cleaned = preg_replace($patterns, ' ', $input);
        
        return $cleaned;
    }
    
    /**
     * 高级XSS过滤
     * @param string $input 输入数据
     * @param array $allowedTags 允许的HTML标签
     * @return string 过滤后的数据
     */
    public static function advancedXSSFilter($input, $allowedTags = []) 
    {
        if (is_array($input)) {
            // 递归处理数组
            return array_map([self::class, 'advancedXSSFilter'], $input);
        }
        
        // 默认允许的安全标签
        $defaultAllowedTags = '<b><i><u><strong><em><br><p>';
        $allowedTags = empty($allowedTags) ? $defaultAllowedTags : implode('', array_map(function($tag) {
            return '<' . $tag . '>';
        }, $allowedTags));
        
        // 1. 移除所有脚本标签
        $input = preg_replace('/<script[^>]*>.*?<\/script>/is', '', $input);
        
        // 2. 移除所有on*事件处理器
        $input = preg_replace('/on\w+\s*=\s*["]{0,1}\s*\w+\s*\([^\)]*\)\s*["]{0,1}/i', '', $input);
        
        // 3. 移除javascript: URL
        $input = preg_replace('/\bjavascript\s*:/i', '', $input);
        
        // 4. 移除data: URL（可能包含恶意代码）
        $input = preg_replace('/\bdata:\s*image\/(?:png|jpg|jpeg|gif);\s*base64\s*,/i', '', $input);
        
        // 5. 使用HTML Purifier模式过滤
        $input = strip_tags($input, $allowedTags);
        
        // 6. 转义特殊字符
        $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        return $input;
    }
    
    /**
     * 检查文件权限
     * @param string $path 文件/目录路径
     * @param int $expectedPermissions 期望的权限
     * @return bool 权限是否正确
     */
    public static function hasProperPermissions($path, $expectedPermissions) 
    {
        if (!file_exists($path)) {
            return false;
        }
        
        $actualPermissions = fileperms($path) & 0777;
        return ($actualPermissions === $expectedPermissions);
    }
    
    /**
     * IP地址验证和地理位置检查
     * @param string $ip IP地址
     * @return array 验证结果和地理位置信息
     */
    public static function validateIP($ip) 
    {
        $result = array(
            'is_valid' => false,
            'ip' => $ip,
            'type' => null,
            'is_private' => false,
            'location' => null,
            'country' => null
        );
        
        // 基本IP格式验证
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return $result;
        }
        
        $result['is_valid'] = true;
        
        // 判断IP类型
        $ipType = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? 'IPv4' : 
                 (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? 'IPv6' : null);
        $result['type'] = $ipType;
        
        // 检查是否为私有IP
        $result['is_private'] = (
            filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE) === false &&
            filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE) === false
        );
        
        // 简单的地理位置映射（实际应用中应使用IP地理位置API）
        $privateRanges = array(
            '/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/',
            '/^172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}$/',
            '/^192\.168\.\d{1,3}\.\d{1,3}$/',
            '/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/'
        );
        
        foreach ($privateRanges as $pattern) {
            if (preg_match($pattern, $ip)) {
                $result['location'] = 'Private Network';
                $result['country'] = 'N/A';
                break;
            }
        }
        
        return $result;
    }
    
    /**
     * 速率限制检查
     * @param string $identifier 标识符（如IP或用户ID）
     * @param int $limit 时间窗口内的最大请求数
     * @param int $windowSeconds 时间窗口（秒）
     * @return array 检查结果
     */
    public static function checkRateLimit($identifier, $limit = 60, $windowSeconds = 60) {
        $cacheFile = dirname(__DIR__) . '/cache/rate_limit_' . md5($identifier) . '.json';
        $cacheDir = dirname($cacheFile);
        
        // 创建缓存目录
        if (!file_exists($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }
        
        $now = time();
        $windowStart = $now - $windowSeconds;
        
        // 读取现有记录
        $records = array();
        if (file_exists($cacheFile)) {
            $content = file_get_contents($cacheFile);
            $records = json_decode($content, true) ?: array();
        }
        
        // 清理过期记录
        $validRecords = array_filter($records, function($timestamp) use ($windowStart) {
            return $timestamp > $windowStart;
        });
        
        // 检查是否超过限制
        $isLimited = count($validRecords) >= $limit;
        
        if (!$isLimited) {
            // 添加新记录
            $validRecords[] = $now;
            
            // 保存更新后的记录
            file_put_contents($cacheFile, json_encode($validRecords), LOCK_EX);
        }
        
        return array(
            'is_limited' => $isLimited,
            'requests_count' => count($validRecords),
            'limit' => $limit,
            'window' => $windowSeconds,
            'reset_in' => $windowSeconds - ($now - $windowStart)
        );
    }
    
    /**
     * 请求内容类型验证
     * @param string $expectedType 期望的内容类型
     * @return bool 验证结果
     */
    public static function validateContentType($expectedType = 'application/json') {
        if (!isset($_SERVER['CONTENT_TYPE'])) {
            return false;
        }
        
        $contentType = $_SERVER['CONTENT_TYPE'];
        
        // 处理带编码的内容类型
        $parts = explode(';', $contentType);
        $baseType = trim($parts[0]);
        
        return strcasecmp($baseType, $expectedType) === 0;
    }
    
    /**
     * 应用内容安全策略头
     */
    public static function applyContentSecurityPolicy() {
        $policy = "default-src 'self'; " .
                  "script-src 'self'; " .
                  "style-src 'self'; " .
                  "img-src 'self'; " .
                  "font-src 'self'; " .
                  "object-src 'none'; " .
                  "frame-ancestors 'none'; " .
                  "form-action 'self'; " .
                  "base-uri 'self'; " .
                  "connect-src 'self'; " .
                  "upgrade-insecure-requests; " .
                  "block-all-mixed-content";
        
        header('Content-Security-Policy: ' . $policy);
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    }
    
    /**
     * 验证输入数据是否在允许的长度范围内
     * @param string $input 输入数据
     * @param int $min 最小长度
     * @param int $max 最大长度
     * @return bool 验证结果
     */
    public static function validateLength($input, $min, $max) {
        $length = strlen($input);
        return $length >= $min && $length <= $max;
    }
    
    /**
     * 记录详细安全日志
     * @param string $level 日志级别
     * @param string $message 日志消息
     * @param array $context 上下文信息
     */
    public static function logSecurityDetailed($level, $message, $context = array()) {
        $logEntry = array(
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => $level,
            'message' => $message,
            'ip' => self::getClientIP(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '',
            'context' => $context
        );
        
        $logFile = dirname(__DIR__) . '/logs/security_detailed.log';
        $logDir = dirname($logFile);
        
        // 创建日志目录
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // 写入日志
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
}