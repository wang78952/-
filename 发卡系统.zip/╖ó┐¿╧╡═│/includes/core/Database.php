<?php
/**
 * 数据库连接管理类
 * 提供安全的数据库连接、预处理语句支持、连接池管理、查询优化、事务管理、读写分离
 * 适用于高并发、高可用的生产环境
 */

require_once __DIR__ . '/SecurityUtils.php';
require_once __DIR__ . '/LogManager.php';
require_once __DIR__ . '/PerformanceMonitor.php';
require_once __DIR__ . '/../config.php';

// 数据库异常类
spl_autoload_register(function($class) {
    if ($class === 'DatabaseException') {
        class DatabaseException extends Exception {
            protected $errorCode;
            protected $errorContext;
            
            public function __construct($message, $code = 500, $context = array()) {
                parent::__construct($message, $code);
                $this->errorCode = $code;
                $this->errorContext = $context;
            }
            
            public function getErrorCode() {
                return $this->errorCode;
            }
            
            public function getErrorContext() {
                return $this->errorContext;
            }
        }
    }
    
    if ($class === 'TransactionException') {
        class TransactionException extends DatabaseException {
            public function __construct($message, $code = 500, $context = array()) {
                parent::__construct($message, $code, $context);
            }
        }
    }
});

class Database 
{
    private static $instance = null;
    private $masterConnection;
    private $slaveConnections = array();
    private $config;
    private $queryLog = array();
    private $slowQueryThreshold = 1000; // 慢查询阈值（毫秒）
    private $transactionDepth = 0; // 事务嵌套深度
    private $connectionPool = array();
    private $maxPoolSize = 20;
    private $poolTimeout = 30; // 连接池连接超时时间（秒）
    private $failedReconnectAttempts = 0;
    private $maxReconnectAttempts = 5;
    private $reconnectDelay = 1; // 重连延迟（秒）
    private $isConnected = false;
    private $lastHealthCheck = 0;
    private $healthCheckInterval = 60; // 健康检查间隔（秒）
    
    /**
     * 私有构造函数，实现单例模式
     */
    private function __construct() 
    {
        // 从配置文件加载数据库配置
        $dbConfig = require_once __DIR__ . '/../config/database.php';
        
        // 基础配置
        $this->config = array(
            'master' => array(
                'host' => $dbConfig['master']['host'],
                'port' => isset($dbConfig['master']['port']) ? $dbConfig['master']['port'] : 3306,
                'database' => $dbConfig['master']['database'],
                'username' => $dbConfig['master']['username'],
                'password' => $dbConfig['master']['password'],
                'charset' => $dbConfig['master']['charset'],
                'options' => isset($dbConfig['options']) ? $dbConfig['options'] : array()
            ),
            'slaves' => isset($dbConfig['slaves']) ? $dbConfig['slaves'] : array(),
            'connectionPool' => array(
                'enabled' => true,
                'maxSize' => 20,
                'timeout' => 30
            ),
            'readWriteSplitting' => isset($dbConfig['readWriteSplitting']) ? $dbConfig['readWriteSplitting'] : array(
                'enabled' => true,
                'useMasterForReads' => false,
                'loadBalanceStrategy' => 'random'
            ),
            'failover' => isset($dbConfig['failover']) ? $dbConfig['failover'] : array(
                'enabled' => true,
                'masterToSlaveOnFailure' => true,
                'slaveHealthCheckInterval' => 60
            ),
            'monitoring' => array(
                'slowQueryThreshold' => 1000,
                'healthCheckInterval' => 60
            )
        );
        
        // 添加默认PDO选项
        $defaultOptions = array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_PERSISTENT => true,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
            PDO::ATTR_TIMEOUT => 30,
            PDO::MYSQL_ATTR_MULTI_STATEMENTS => false
        );
        
        $this->config['master']['options'] = array_merge($defaultOptions, $this->config['master']['options']);
        
        // 初始化连接池
        $this->initConnectionPool();
        
        // 连接主数据库
        $this->connectMaster();
        
        // 连接从数据库（如果启用了读写分离）
        if ($this->config['readWriteSplitting']['enabled'] && !empty($this->config['slaves'])) {
            $this->connectSlaves();
        }
        
        // 记录数据库连接日志
        LogManager::log('INFO', '数据库连接初始化成功', array(
            'host' => $this->config['master']['host'],
            'database' => $this->config['master']['database'],
            'readWriteSplitting' => $this->config['readWriteSplitting']['enabled'],
            'slaveCount' => count($this->slaveConnections)
        ));
    }
    
    /**
     * 初始化连接池
     */
    private function initConnectionPool()
    {
        if ($this->config['connectionPool']['enabled']) {
            $this->maxPoolSize = $this->config['connectionPool']['maxSize'];
            $this->poolTimeout = $this->config['connectionPool']['timeout'];
            $this->connectionPool = array();
        }
    }
    
    /**
     * 从连接池获取连接
     * @return PDO|null
     */
    private function getConnectionFromPool()
    {
        if (!$this->config['connectionPool']['enabled'] || empty($this->connectionPool)) {
            return null;
        }
        
        $now = time();
        foreach ($this->connectionPool as $key => $connectionInfo) {
            // 检查连接是否过期
            if ($now - $connectionInfo['created_at'] > $this->poolTimeout) {
                try {
                    $connectionInfo['connection'] = null;
                } catch (Exception $e) {
                    // 忽略关闭连接时的错误
                }
                unset($this->connectionPool[$key]);
                continue;
            }
            
            // 检查连接是否有效
            try {
                $connectionInfo['connection']->query('SELECT 1');
                unset($this->connectionPool[$key]);
                return $connectionInfo['connection'];
            } catch (PDOException $e) {
                try {
                    $connectionInfo['connection'] = null;
                } catch (Exception $ex) {
                    // 忽略关闭连接时的错误
                }
                unset($this->connectionPool[$key]);
            }
        }
        
        return null;
    }
    
    /**
     * 将连接放回连接池
     * @param PDO $connection
     */
    private function returnConnectionToPool($connection)
    {
        if (!$this->config['connectionPool']['enabled'] || count($this->connectionPool) >= $this->maxPoolSize) {
            try {
                $connection = null;
            } catch (Exception $e) {
                // 忽略关闭连接时的错误
            }
            return;
        }
        
        try {
            // 验证连接仍然有效
            $connection->query('SELECT 1');
            $this->connectionPool[] = array(
                'connection' => $connection,
                'created_at' => time()
            );
        } catch (PDOException $e) {
            try {
                $connection = null;
            } catch (Exception $ex) {
                // 忽略关闭连接时的错误
            }
        }
    }
    
    /**
     * 获取数据库实例
     * @return Database
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        
        // 检查连接是否健康
        self::$instance->checkHealth();
        
        return self::$instance;
    }
    
    /**
     * 检查数据库连接健康状态
     */
    private function checkHealth()
    {
        $now = time();
        
        // 定期进行健康检查
        if ($now - $this->lastHealthCheck > $this->config['monitoring']['healthCheckInterval']) {
            try {
                $this->masterConnection->query('SELECT 1');
                $this->isConnected = true;
                $this->lastHealthCheck = $now;
            } catch (PDOException $e) {
                $this->isConnected = false;
                LogManager::log('ERROR', '数据库连接健康检查失败', array(
                    'error' => $e->getMessage()
                ));
                // 尝试重连
                $this->reconnectMaster();
            }
        }
    }
    
    /**
     * 连接主数据库
     */
    private function connectMaster()
    {
        try {
            // 尝试从连接池获取连接
            $poolConnection = $this->getConnectionFromPool();
            if ($poolConnection !== null) {
                $this->masterConnection = $poolConnection;
                $this->isConnected = true;
                return;
            }
            
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                $this->config['master']['host'],
                $this->config['master']['port'],
                $this->config['master']['database'],
                $this->config['master']['charset']
            );
            
            $this->masterConnection = new PDO($dsn, $this->config['master']['username'], $this->config['master']['password'], $this->config['master']['options']);
            $this->isConnected = true;
            $this->failedReconnectAttempts = 0;
            
        } catch (PDOException $e) {
            $this->isConnected = false;
            $errorInfo = array(
                'error' => $e->getMessage(),
                'config' => array(
                    'host' => $this->config['master']['host'],
                    'database' => $this->config['master']['database']
                ),
                'attempts' => $this->failedReconnectAttempts
            );
            
            LogManager::log('CRITICAL', '数据库连接失败', $errorInfo);
            SecurityUtils::logSecurity('CRITICAL', '数据库连接失败', $errorInfo);
            
            // 尝试重连
            if ($this->config['failover']['enabled'] && $this->failedReconnectAttempts < $this->config['failover']['maxReconnectAttempts']) {
                $this->reconnectMaster();
            }
            
            throw new DatabaseException('数据库连接失败: ' . $e->getMessage(), 503, $errorInfo);
        }
    }
    
    /**
     * 重连主数据库
     */
    private function reconnectMaster()
    {
        $this->failedReconnectAttempts++;
        $delay = $this->config['failover']['reconnectDelay'] * $this->failedReconnectAttempts;
        
        LogManager::log('WARNING', '尝试重连数据库', array(
            'attempt' => $this->failedReconnectAttempts,
            'delay' => $delay
        ));
        
        // 延迟重连，避免立即失败
        sleep($delay);
        
        try {
            $this->connectMaster();
            LogManager::log('INFO', '数据库重连成功', array(
                'attempt' => $this->failedReconnectAttempts
            ));
        } catch (Exception $e) {
            // 如果达到最大重试次数，抛出异常
            if ($this->failedReconnectAttempts >= $this->config['failover']['maxReconnectAttempts']) {
                throw new DatabaseException('数据库重连失败，已达到最大重试次数', 503, array(
                    'attempts' => $this->failedReconnectAttempts,
                    'error' => $e->getMessage()
                ));
            }
        }
    }
    
    /**
     * 连接从数据库
     */
    private function connectSlaves()
    {
        $this->slaveConnections = array();
        
        foreach ($this->config['slaves'] as $slaveConfig) {
            try {
                $dsn = sprintf(
                    'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                    $slaveConfig['host'],
                    isset($slaveConfig['port']) ? $slaveConfig['port'] : 3306,
                    $slaveConfig['database'],
                    $slaveConfig['charset']
                );
                
                $slaveConnection = new PDO(
                    $dsn, 
                    $slaveConfig['username'], 
                    $slaveConfig['password'], 
                    $this->config['master']['options']
                );
                
                $this->slaveConnections[] = $slaveConnection;
                
                LogManager::log('INFO', '从库连接成功', array(
                    'host' => $slaveConfig['host'],
                    'database' => $slaveConfig['database']
                ));
                
            } catch (PDOException $e) {
                $errorInfo = array(
                    'error' => $e->getMessage(),
                    'config' => $slaveConfig
                );
                
                LogManager::log('WARNING', '从库连接失败，将跳过该从库', $errorInfo);
            }
        }
    }
    
    /**
     * 检查从库健康状态
     */
    private function checkSlaveHealth()
    {
        $now = time();
        
        // 定期进行健康检查
        if ($now - $this->lastHealthCheck > $this->config['failover']['slaveHealthCheckInterval']) {
            $healthySlaves = array();
            
            foreach ($this->slaveConnections as $key => $connection) {
                try {
                    $connection->query('SELECT 1');
                    $healthySlaves[] = $connection;
                } catch (PDOException $e) {
                    LogManager::log('ERROR', '从库连接健康检查失败', array(
                        'slave_index' => $key,
                        'error' => $e->getMessage()
                    ));
                }
            }
            
            $this->slaveConnections = $healthySlaves;
            
            // 如果所有从库都不健康，尝试重新连接
            if (empty($this->slaveConnections) && !empty($this->config['slaves'])) {
                LogManager::log('WARNING', '所有从库都不健康，尝试重新连接');
                $this->connectSlaves();
            }
            
            $this->lastHealthCheck = $now;
        }
    }
    
    /**
     * 根据负载均衡策略选择从库
     * @return PDO
     */
    private function selectSlave()
    {
        if (empty($this->slaveConnections)) {
            return null;
        }
        
        $strategy = $this->config['readWriteSplitting']['loadBalanceStrategy'];
        
        switch ($strategy) {
            case 'round-robin':
                // 轮询策略
                static $currentSlaveIndex = 0;
                $slave = $this->slaveConnections[$currentSlaveIndex];
                $currentSlaveIndex = ($currentSlaveIndex + 1) % count($this->slaveConnections);
                return $slave;
                
            case 'random':
            default:
                // 随机策略
                $slaveKey = array_rand($this->slaveConnections);
                return $this->slaveConnections[$slaveKey];
        }
    }
    
    /**
     * 获取合适的数据库连接（主库或从库）
     * @param string $sql SQL语句
     * @return PDO
     */
    private function getConnection($sql = null)
    {
        // 确保连接是健康的
        $this->checkHealth();
        
        // 如果是写操作，使用主库
        if ($sql === null || !$this->isReadOperation($sql)) {
            return $this->masterConnection;
        }
        
        // 对于读操作，检查从库健康状态
        if ($this->config['readWriteSplitting']['enabled'] && !empty($this->slaveConnections)) {
            $this->checkSlaveHealth();
        }
        
        // 如果启用了读写分离
        if ($this->config['readWriteSplitting']['enabled']) {
            // 尝试使用从库
            if (!$this->config['readWriteSplitting']['useMasterForReads'] && !empty($this->slaveConnections)) {
                try {
                    $slaveConnection = $this->selectSlave();
                    if ($slaveConnection !== null) {
                        return $slaveConnection;
                    }
                } catch (Exception $e) {
                    LogManager::log('WARNING', '选择从库失败，使用主库', array('error' => $e->getMessage()));
                }
            }
        }
        
        // 默认使用主库
        return $this->masterConnection;
    }
    
    /**
     * 判断SQL是否为读操作
     * @param string $sql SQL语句
     * @return bool
     */
    private function isReadOperation($sql)
    {
        $sql = trim(strtoupper($sql));
        $readKeywords = array('SELECT', 'SHOW', 'DESCRIBE', 'EXPLAIN');
        
        foreach ($readKeywords as $keyword) {
            if (strpos($sql, $keyword) === 0) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取主库PDO连接对象
     * @return PDO
     */
    public function getMasterConnection()
    {
        if ($this->masterConnection === null || !$this->isConnected) {
            $this->connectMaster();
        }
        
        return $this->masterConnection;
    }
    
    /**
     * 获取数据库连接信息
     * @return array
     */
    public function getConnectionInfo() 
    {        
        try {
            $attributes = array(
                'PDO::ATTR_SERVER_INFO',
                'PDO::ATTR_SERVER_VERSION',
                'PDO::ATTR_CLIENT_VERSION',
                'PDO::ATTR_CONNECTION_STATUS'
            );
            
            $info = array(
                'status' => $this->isConnected ? 'connected' : 'disconnected',
                'master' => array(),
                'pool' => array(
                    'size' => count($this->connectionPool),
                    'max_size' => $this->maxPoolSize
                ),
                'reconnect_attempts' => $this->failedReconnectAttempts
            );
            
            foreach ($attributes as $attr) {
                try {
                    $info['master'][$attr] = $this->masterConnection->getAttribute(constant($attr));
                } catch (Exception $e) {
                    $info['master'][$attr] = 'N/A';
                }
            }
            
            return $info;
        } catch (Exception $e) {
            return array(
                'status' => 'error',
                'error' => $e->getMessage()
            );
        }
    }
    
    /**
     * 执行预处理查询（带性能监控和故障转移）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return PDOStatement
     * @throws DatabaseException
     */
    public function prepare($sql, $params = array())
    {
        $startTime = microtime(true);
        $connection = $this->getConnection($sql);
        
        try {
            // 验证SQL语句安全性
            $this->validateSQL($sql);
            
            $stmt = $connection->prepare($sql);
            
            // 参数绑定优化
            foreach ($params as $key => $value) {
                $paramType = $this->getParamType($value);
                $paramKey = is_int($key) ? $key + 1 : $key;
                $stmt->bindValue($paramKey, $value, $paramType);
            }
            
            $endTime = microtime(true);
            $executionTime = ($endTime - $startTime) * 1000; // 转换为毫秒
            
            // 确定连接类型
            $connectionType = 'master';
            foreach ($this->slaveConnections as $slaveConnection) {
                if ($connection === $slaveConnection) {
                    $connectionType = 'slave';
                    break;
                }
            }
            
            // 记录查询性能
            $this->logQuery($sql, $params, $executionTime, $connectionType);
            
            // 性能监控
            PerformanceMonitor::recordMetric('database_query_time', $executionTime);
            
            return $stmt;
            
        } catch (PDOException $e) {
            // 确定连接类型
            $connectionType = 'master';
            foreach ($this->slaveConnections as $slaveConnection) {
                if ($connection === $slaveConnection) {
                    $connectionType = 'slave';
                    break;
                }
            }
            
            $errorInfo = array(
                'sql' => $sql,
                'params' => $this->maskSensitiveData($params),
                'error' => $e->getMessage(),
                'connection_type' => $connectionType
            );
            
            LogManager::log('ERROR', '数据库预处理失败', $errorInfo);
            SecurityUtils::logSecurity('ERROR', '数据库预处理失败', $errorInfo);
            
            // 如果是连接错误，尝试重连
            if (strpos($e->getMessage(), 'server has gone away') !== false || 
                strpos($e->getMessage(), 'no connection to the server') !== false) {
                $this->isConnected = false;
                $this->reconnectMaster();
            }
            
            throw new DatabaseException('数据库预处理失败: ' . $e->getMessage(), 500, $errorInfo);
        }
    }
    
    /**
     * 验证SQL语句安全性
     * @param string $sql SQL语句
     * @throws DatabaseException
     */
    private function validateSQL($sql)
    {
        // 防止SQL注入攻击
        $dangerousPatterns = array(
            '/DROP\s+TABLE/i',
            '/ALTER\s+TABLE/i',
            '/TRUNCATE\s+TABLE/i',
            '/DROP\s+DATABASE/i',
            '/;\s*--/',
            '/;\s*#/',
            '/UNION\s+SELECT/i'
        );
        
        foreach ($dangerousPatterns as $pattern) {
            if (preg_match($pattern, $sql)) {
                throw new DatabaseException('检测到潜在的危险SQL语句', 403, array('sql' => $sql));
            }
        }
    }
    
    /**
     * 屏蔽敏感数据
     * @param array $data 原始数据
     * @return array 屏蔽后的数据
     */
    private function maskSensitiveData($data)
    {
        $sensitiveFields = array('password', 'token', 'key', 'secret', 'credit_card', 'ssn', 'phone');
        $maskedData = $data;
        
        foreach ($maskedData as $key => $value) {
            foreach ($sensitiveFields as $sensitiveField) {
                if (is_string($key) && stripos($key, $sensitiveField) !== false) {
                    $maskedData[$key] = '***';
                }
            }
        }
        
        return $maskedData;
    }
    
    /**
     * 执行查询并返回所有结果（带缓存）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @param int $cacheTime 缓存时间（秒）
     * @return array
     */
    public function queryAll($sql, $params = array(), $cacheTime = 0)
    {
        $cacheKey = $this->getCacheKey($sql, $params);
        
        // 如果有缓存且未过期，直接返回缓存结果
        if ($cacheTime > 0) {
            $cached = $this->getCache($cacheKey);
            if ($cached !== null) {
                return $cached;
            }
        }
        
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        $result = $stmt->fetchAll();
        
        // 如果需要缓存，保存结果
        if ($cacheTime > 0) {
            $this->setCache($cacheKey, $result, $cacheTime);
        }
        
        return $result;
    }
    
    /**
     * 执行查询并返回所有结果（兼容方法）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return array
     */
    public function fetchAll($sql, $params = array())
    {
        return $this->queryAll($sql, $params);
    }
    
    /**
     * 执行查询并返回单行结果（带缓存）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @param int $cacheTime 缓存时间（秒）
     * @return array|null
     */
    public function queryOne($sql, $params = array(), $cacheTime = 0)
    {
        $cacheKey = $this->getCacheKey($sql, $params);
        
        // 如果有缓存且未过期，直接返回缓存结果
        if ($cacheTime > 0) {
            $cached = $this->getCache($cacheKey);
            if ($cached !== null) {
                return $cached;
            }
        }
        
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        $result = $stmt->fetch();
        $result = $result !== false ? $result : null;
        
        // 如果需要缓存，保存结果
        if ($cacheTime > 0 && $result !== null) {
            $this->setCache($cacheKey, $result, $cacheTime);
        }
        
        return $result;
    }
    
    /**
     * 执行插入操作
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return int 插入的ID
     */
    public function insert($sql, $params = array()) 
    {
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        return (int)$this->connection->lastInsertId();
    }
    
    /**
     * 执行更新操作
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return int 影响的行数
     */
    public function update($sql, $params = array()) 
    {
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        return $stmt->rowCount();
    }
    
    /**
     * 执行删除操作
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return int 删除的行数
     */
    public function delete($sql, $params = array()) 
    {
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        return $stmt->rowCount();
    }
    
    /**
     * 开始事务（支持嵌套事务）
     * @return bool
     */
    public function beginTransaction() 
    {
        try {
            // 确保使用主库连接
            $connection = $this->getMasterConnection();
            
            // 如果是第一层事务，开始真正的事务
            if ($this->transactionDepth === 0) {
                $connection->beginTransaction();
                LogManager::log('DEBUG', '数据库事务开始');
            } else {
                // 嵌套事务，使用保存点
                $connection->exec("SAVEPOINT sp_" . $this->transactionDepth);
                LogManager::log('DEBUG', '数据库嵌套事务开始', array('depth' => $this->transactionDepth));
            }
            
            $this->transactionDepth++;
            return true;
            
        } catch (PDOException $e) {
            $errorInfo = array(
                'error' => $e->getMessage(),
                'depth' => $this->transactionDepth
            );
            
            LogManager::log('ERROR', '事务开始失败', $errorInfo);
            throw new TransactionException('事务开始失败: ' . $e->getMessage(), 500, $errorInfo);
        }
    }
    
    /**
     * 提交事务（支持嵌套事务）
     * @return bool
     */
    public function commit() 
    {
        try {
            if ($this->transactionDepth <= 0) {
                throw new TransactionException('没有活动的事务可提交', 400);
            }
            
            $this->transactionDepth--;
            $connection = $this->getMasterConnection();
            
            // 如果是最后一层事务，提交真正的事务
            if ($this->transactionDepth === 0) {
                $connection->commit();
                LogManager::log('DEBUG', '数据库事务提交成功');
            } else {
                // 嵌套事务，释放保存点
                LogManager::log('DEBUG', '数据库嵌套事务提交', array('depth' => $this->transactionDepth));
            }
            
            return true;
            
        } catch (PDOException $e) {
            $errorInfo = array(
                'error' => $e->getMessage(),
                'depth' => $this->transactionDepth
            );
            
            LogManager::log('ERROR', '事务提交失败', $errorInfo);
            
            // 尝试回滚事务
            try {
                if ($this->transactionDepth === 0) {
                    $connection->rollBack();
                }
            } catch (Exception $ex) {
                // 忽略回滚错误
            }
            
            throw new TransactionException('事务提交失败: ' . $e->getMessage(), 500, $errorInfo);
        }
    }
    
    /**
     * 回滚事务（支持嵌套事务）
     * @return bool
     */
    public function rollback() 
    {
        try {
            if ($this->transactionDepth <= 0) {
                throw new TransactionException('没有活动的事务可回滚', 400);
            }
            
            $this->transactionDepth--;
            $connection = $this->getMasterConnection();
            
            // 如果是最后一层事务，回滚整个事务
            if ($this->transactionDepth === 0) {
                $connection->rollBack();
                LogManager::log('DEBUG', '数据库事务回滚成功');
            } else {
                // 嵌套事务，回滚到保存点
                $connection->exec("ROLLBACK TO sp_" . $this->transactionDepth);
                LogManager::log('DEBUG', '数据库嵌套事务回滚', array('depth' => $this->transactionDepth));
            }
            
            return true;
            
        } catch (PDOException $e) {
            $errorInfo = array(
                'error' => $e->getMessage(),
                'depth' => $this->transactionDepth
            );
            
            LogManager::log('ERROR', '事务回滚失败', $errorInfo);
            throw new TransactionException('事务回滚失败: ' . $e->getMessage(), 500, $errorInfo);
        }
    }
    
    /**
     * 检查是否在事务中
     * @return bool
     */
    public function inTransaction() 
    {
        try {
            return $this->transactionDepth > 0;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 执行事务操作
     * @param callable $callback 事务回调函数
     * @return mixed 回调函数的返回值
     * @throws Exception
     */
    public function transaction(callable $callback)
    {
        $this->beginTransaction();
        
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (Exception $e) {
            // 尝试回滚所有嵌套事务
            while ($this->transactionDepth > 0) {
                $this->rollback();
            }
            
            LogManager::log('ERROR', '事务执行失败，已回滚', array(
                'error' => $e->getMessage(),
                'exception_class' => get_class($e)
            ));
            
            throw $e;
        }
    }
    
    /**
     * 执行存储过程
     * @param string $procedure 存储过程名
     * @param array $params 参数数组
     * @return array
     */
    public function callProcedure($procedure, $params = array()) 
    {
        $placeholders = array();
        $values = array();
        
        foreach ($params as $key => $value) {
            $placeholders[] = ':' . $key;
            $values[':' . $key] = $value;
        }
        
        $sql = sprintf('CALL %s(%s)', $procedure, implode(', ', $placeholders));
        
        return $this->queryAll($sql, $values);
    }
    
    /**
     * 检查表是否存在
     * @param string $tableName 表名
     * @return bool
     */
    public function tableExists($tableName) 
    {
        $sql = "SHOW TABLES LIKE :table_name";
        $result = $this->queryOne($sql, array('table_name' => $tableName));
        
        return !empty($result);
    }
    
    /**
     * 获取表结构
     * @param string $tableName 表名
     * @return array
     */
    public function getTableSchema($tableName) 
    {
        $sql = "DESCRIBE `{$tableName}`";
        return $this->queryAll($sql);
    }
    
    /**
     * 执行批量插入（优化版）
     * @param string $tableName 表名
     * @param array $data 数据数组
     * @param int $batchSize 批次大小
     * @return int 插入的总行数
     */
    public function batchInsert($tableName, $data, $batchSize = 100) 
    {
        if (empty($data)) {
            return 0;
        }
        
        $totalRows = 0;
        $columns = array_keys($data[0]);
        $placeholders = array_fill(0, count($columns), '?');
        
        $sql = sprintf(
            'INSERT INTO `%s` (`%s`) VALUES (%s)',
            $tableName,
            implode('`, `', $columns),
            implode(', ', $placeholders)
        );
        
        try {
            $this->beginTransaction();
            
            $batch = array();
            foreach ($data as $row) {
                $batch[] = array_values($row);
                
                if (count($batch) >= $batchSize) {
                    $totalRows += $this->executeBatchInsert($sql, $batch);
                    $batch = array();
                }
            }
            
            // 插入剩余数据
            if (!empty($batch)) {
                $totalRows += $this->executeBatchInsert($sql, $batch);
            }
            
            $this->commit();
            
        } catch (Exception $e) {
            $this->rollback();
            
            SecurityUtils::logSecurity('ERROR', '批量插入失败', array(
                'table' => $tableName,
                'batch_count' => count($data),
                'error' => $e->getMessage()
            ));
            
            throw new Exception('批量插入失败: ' . $e->getMessage());
        }
        
        return $totalRows;
    }
    
    /**
     * 执行批量插入的内部方法
     */
    private function executeBatchInsert($sql, $batch) 
    {
        $stmt = $this->connection->prepare($sql);
        
        foreach ($batch as $params) {
            $stmt->execute($params);
        }
        
        return count($batch);
    }
    
    /**
     * 获取查询统计信息
     * @return array
     */
    public function getQueryStats() 
    {
        $totalQueries = count($this->queryLog);
        $slowQueries = array_filter($this->queryLog, array($this, 'filterSlowQuery'));
        
        return array(
            'total_queries' => $totalQueries,
            'slow_queries' => count($slowQueries),
            'average_time' => $totalQueries > 0 ? 
                array_sum(array_column($this->queryLog, 'execution_time')) / $totalQueries : 0,
            'slow_query_threshold' => $this->slowQueryThreshold,
            'recent_queries' => array_slice($this->queryLog, -10)
        );
    }
    
    /**
     * 过滤慢查询的回调方法
     * @param array $query 查询信息
     * @return bool
     */
    private function filterSlowQuery($query) 
    {
        return $query['execution_time'] > $this->slowQueryThreshold;
    }
    
    /**
     * 清空查询日志
     */
    public function clearQueryLog() 
    {
        $this->queryLog = array();
    }
    
    /**
     * 记录查询日志（增强版）
     */
    private function logQuery($sql, $params, $executionTime, $connectionType = 'master') 
    {
        // 屏蔽敏感参数
        $maskedParams = $this->maskSensitiveData($params);
        
        $queryInfo = array(
            'sql' => $sql,
            'params' => $maskedParams,
            'execution_time' => $executionTime,
            'timestamp' => date('Y-m-d H:i:s'),
            'connection_type' => $connectionType,
            'memory_usage' => memory_get_usage()
        );
        
        $this->queryLog[] = $queryInfo;
        
        // 慢查询检测和告警
        $slowThreshold = $this->config['monitoring']['slowQueryThreshold'];
        if ($executionTime > $slowThreshold) {
            $slowQueryInfo = array(
                'sql' => $sql,
                'params' => $maskedParams,
                'execution_time' => $executionTime,
                'threshold' => $slowThreshold,
                'connection_type' => $connectionType
            );
            
            LogManager::log('WARNING', '慢查询检测', $slowQueryInfo);
            SecurityUtils::logSecurity('WARNING', '慢查询检测', $slowQueryInfo);
            
            // 性能监控告警
            PerformanceMonitor::recordSlowQuery($sql, $executionTime);
        }
        
        // 限制内存使用
        if (count($this->queryLog) > 1000) {
            $this->queryLog = array_slice($this->queryLog, -500);
        }
    }
    
    /**
     * 生成缓存键
     */
    private function getCacheKey($sql, $params) 
    {
        return 'db_cache_' . md5($sql . serialize($params));
    }
    
    /**
     * 获取缓存
     */
    private function getCache($key) 
    {
        // 这里可以集成Redis或其他缓存系统
        // 暂时使用简单的文件缓存
        $cacheFile = sys_get_temp_dir() . '/' . $key . '.cache';
        
        if (!file_exists($cacheFile)) {
            return null;
        }
        
        $data = unserialize(file_get_contents($cacheFile));
        
        if ($data['expires'] < time()) {
            unlink($cacheFile);
            return null;
        }
        
        return $data['result'];
    }
    
    /**
     * 设置缓存
     */
    private function setCache($key, $result, $cacheTime) 
    {
        $cacheFile = sys_get_temp_dir() . '/' . $key . '.cache';
        $data = array(
            'result' => $result,
            'expires' => time() + $cacheTime
        );
        
        file_put_contents($cacheFile, serialize($data));
    }
    
    /**
     * 获取参数类型
     * @param mixed $value 参数值
     * @return int PDO参数类型
     */
    private function getParamType($value) 
    {
        if (is_int($value)) {
            return PDO::PARAM_INT;
        } elseif (is_bool($value)) {
            return PDO::PARAM_BOOL;
        } elseif (is_null($value)) {
            return PDO::PARAM_NULL;
        } else {
            return PDO::PARAM_STR;
        }
    }
    
    /**
     * 获取数据库连接信息（用于监控）
     * @return array
     */
    public function getConnectionInfo() 
    {
        $attributes = array(
            'PDO::ATTR_SERVER_INFO',
            'PDO::ATTR_SERVER_VERSION',
            'PDO::ATTR_CLIENT_VERSION',
            'PDO::ATTR_CONNECTION_STATUS'
        );
        
        $info = array();
        foreach ($attributes as $attr) {
            try {
                $info[$attr] = $this->connection->getAttribute(constant($attr));
            } catch (PDOException $e) {
                $info[$attr] = 'N/A';
            }
        }
        
        return $info;
    }
    
    /**
     * 优化表
     * @param string $tableName 表名
     * @return array
     */
    public function optimizeTable($tableName) 
    {
        $sql = "OPTIMIZE TABLE `{$tableName}`";
        return $this->queryAll($sql);
    }
    
    /**
     * 分析表结构
     * @param string $tableName 表名
     * @return array
     */
    public function analyzeTable($tableName) 
    {
        // 严格验证表名，防止SQL注入
        if (!$this->validateTableName($tableName)) {
            throw new DatabaseException("无效的表名: $tableName");
        }
        
        $sql = "ANALYZE TABLE `{$tableName}`";
        return $this->queryAll($sql);
    }
    
    /**
     * 检查表健康状态
     * @param string $tableName 表名
     * @return array
     */
    public function checkTableHealth($tableName) 
    {
        // 严格验证表名，防止SQL注入
        if (!$this->validateTableName($tableName)) {
            throw new DatabaseException("无效的表名: $tableName");
        }
        
        $sql = "CHECK TABLE `{$tableName}`";
        return $this->queryAll($sql);
    }
    
    /**
     * 验证表名格式，防止SQL注入
     * @param string $tableName 表名
     * @return bool
     */
    private function validateTableName($tableName) {
        // 1. 检查是否为空
        if (empty($tableName) || !is_string($tableName)) {
            return false;
        }
        
        // 2. 检查表名格式（只允许字母、数字、下划线、$和#）
        if (!preg_match('/^[a-zA-Z0-9_$#]+$/i', $tableName)) {
            return false;
        }
        
        // 3. 检查是否为系统保留表名
        $reservedTables = ['mysql', 'information_schema', 'performance_schema', 'sys'];
        if (in_array(strtolower($tableName), $reservedTables)) {
            return false;
        }
        
        // 4. 可选：检查表名是否实际存在
        if (!empty($this->allowedTables)) {
            return in_array($tableName, $this->allowedTables);
        }
        
        return true;
    }
    
    /**
     * 执行查询并返回结果集（通用查询方法）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return PDOStatement
     */
    public function query($sql, $params = array()) 
    {
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        return $stmt;
    }
    
    /**
     * 获取最后插入的ID
     * @return string
     */
    public function lastInsertId() 
    {
        return $this->connection->lastInsertId();
    }
    
    /**
     * 执行查询并返回单行结果（兼容方法）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return array|null
     */
    public function fetch($sql, $params = array()) 
    {
        return $this->queryOne($sql, $params);
    }
    
    /**
     * 执行查询并返回第一列的值（兼容方法）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return mixed
     */
    public function fetchColumn($sql, $params = array()) 
    {
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        return $stmt->fetchColumn();
    }
    
    /**
     * 执行查询并返回单个值（兼容方法）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return mixed
     */
    public function querySingle($sql, $params = array()) 
    {
        $result = $this->queryOne($sql, $params);
        
        if ($result === null) {
            return null;
        }
        
        // 返回第一列的值
        return reset($result);
    }
    
    /**
     * 执行SQL语句（兼容方法）
     * @param string $sql SQL语句
     * @param array $params 参数数组
     * @return int 影响的行数或插入的ID
     */
    public function execute($sql, $params = array()) 
    {
        $stmt = $this->prepare($sql, $params);
        $stmt->execute();
        
        // 如果是INSERT语句，返回插入的ID
        if (stripos(trim($sql), 'INSERT') === 0) {
            return (int)$this->connection->lastInsertId();
        }
        
        // 否则返回影响的行数
        return $stmt->rowCount();
    }
    
    /**
     * 关闭连接
     */
    public function close() 
    {
        try {
            // 关闭主库连接
            $this->masterConnection = null;
            
            // 关闭所有从库连接
            foreach ($this->slaveConnections as $key => $connection) {
                $this->slaveConnections[$key] = null;
            }
            $this->slaveConnections = array();
            
            // 清空连接池
            foreach ($this->connectionPool as $key => $connectionInfo) {
                $this->connectionPool[$key]['connection'] = null;
            }
            $this->connectionPool = array();
            
            $this->isConnected = false;
            $this->transactionDepth = 0;
            $this->queryLog = array();
            
            LogManager::log('INFO', '数据库连接已关闭');
            
        } catch (Exception $e) {
            LogManager::log('ERROR', '关闭数据库连接时发生错误', array('error' => $e->getMessage()));
        }
        
        self::$instance = null;
    }
    
    /**
     * 魔术方法，对象销毁时自动关闭连接
     */
    public function __destruct()
    {
        try {
            // 如果有未提交的事务，尝试回滚
            if ($this->transactionDepth > 0) {
                while ($this->transactionDepth > 0) {
                    $this->rollback();
                }
            }
            
            // 关闭连接
            $this->returnConnectionToPool($this->masterConnection);
            
        } catch (Exception $e) {
            // 忽略销毁时的错误
        }
    }
    
    /**
     * 防止克隆
     */
    private function __clone() {}
    
    /**
     * 防止反序列化
     */
    public function __wakeup() 
    {
        throw new Exception("Cannot unserialize singleton");
    }
}