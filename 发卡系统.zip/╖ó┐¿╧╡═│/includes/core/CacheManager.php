<?php
/**
 * 缓存管理类
 * 提供统一的缓存操作接口，支持多种缓存驱动
 */

require_once __DIR__ . '/ConfigManager.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/PHPExtensions.php';

class CacheManager {
    private static $instance = null;
    private $driver;
    private $config;
    private $logger;
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->config = ConfigManager::getInstance();
        $this->logger = new Logger();
        $this->initializeDriver();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化缓存驱动
     */
    private function initializeDriver() {
        $cacheConfig = $this->config->getCacheConfig();
        $driverType = isset($cacheConfig['default']) ? $cacheConfig['default'] : 'file';
        $stores = isset($cacheConfig['stores']) ? $cacheConfig['stores'] : array();
        
        switch ($driverType) {
            case 'redis':
                $this->driver = new RedisCacheDriver(isset($stores['redis']) ? $stores['redis'] : array());
                break;
            case 'memcached':
                $this->driver = new MemcachedCacheDriver(isset($stores['memcached']) ? $stores['memcached'] : array());
                break;
            case 'apcu':
                $this->driver = new ApcuCacheDriver(isset($stores['apcu']) ? $stores['apcu'] : array());
                break;
            case 'file':
            default:
                $this->driver = new FileCacheDriver(isset($stores['file']) ? $stores['file'] : array());
                break;
        }
        
        $this->logger->info("缓存驱动初始化完成: {$driverType}");
    }
    
    /**
     * 设置缓存
     */
    public function set($key, $value, $ttl = 3600) {
        try {
            $result = $this->driver->set($key, $value, $ttl);
            
            if ($result) {
                $this->logger->debug("缓存设置成功: {$key}");
            } else {
                $this->logger->warning("缓存设置失败: {$key}");
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("缓存设置异常: {$key} - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取缓存
     */
    public function get($key, $default = null) {
        try {
            $value = $this->driver->get($key);
            
            if ($value !== null) {
                $this->logger->debug("缓存命中: {$key}");
                return $value;
            } else {
                $this->logger->debug("缓存未命中: {$key}");
                return $default;
            }
            
        } catch (Exception $e) {
            $this->logger->error("缓存获取异常: {$key} - " . $e->getMessage());
            return $default;
        }
    }
    
    /**
     * 删除缓存
     */
    public function delete($key) {
        try {
            $result = $this->driver->delete($key);
            
            if ($result) {
                $this->logger->debug("缓存删除成功: {$key}");
            } else {
                $this->logger->debug("缓存删除失败: {$key}");
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("缓存删除异常: {$key} - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 检查缓存是否存在
     */
    public function has($key) {
        try {
            return $this->driver->has($key);
        } catch (Exception $e) {
            $this->logger->error("缓存检查异常: {$key} - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 批量设置缓存
     */
    public function setMultiple($values, $ttl = 3600) {
        try {
            $results = array();
            
            foreach ($values as $key => $value) {
                $results[$key] = $this->set($key, $value, $ttl);
            }
            
            return $results;
            
        } catch (Exception $e) {
            $this->logger->error("批量设置缓存异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 批量获取缓存
     */
    public function getMultiple($keys, $default = null) {
        try {
            $results = array();
            
            foreach ($keys as $key) {
                $results[$key] = $this->get($key, $default);
            }
            
            return $results;
            
        } catch (Exception $e) {
            $this->logger->error("批量获取缓存异常: " . $e->getMessage());
            return array_fill_keys($keys, $default);
        }
    }
    
    /**
     * 批量删除缓存
     */
    public function deleteMultiple($keys) {
        try {
            $results = array();
            
            foreach ($keys as $key) {
                $results[$key] = $this->delete($key);
            }
            
            return $results;
            
        } catch (Exception $e) {
            $this->logger->error("批量删除缓存异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 清空所有缓存
     */
    public function clear() {
        try {
            $result = $this->driver->clear();
            
            if ($result) {
                $this->logger->info("缓存清空成功");
            } else {
                $this->logger->warning("缓存清空失败");
            }
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("缓存清空异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 刷新缓存（clear的别名）
     */
    public function flush() {
        return $this->clear();
    }
    
    /**
     * 根据模式删除缓存
     */
    public function deletePattern($pattern) {
        try {
            if (method_exists($this->driver, 'deletePattern')) {
                $result = $this->driver->deletePattern($pattern);
                
                if ($result) {
                    $this->logger->info("模式缓存删除成功: {$pattern}");
                } else {
                    $this->logger->warning("模式缓存删除失败: {$pattern}");
                }
                
                return $result;
            } else {
                $this->logger->warning("当前驱动不支持模式删除");
                return false;
            }
            
        } catch (Exception $e) {
            $this->logger->error("模式缓存删除异常: {$pattern} - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 增加缓存值
     */
    public function increment($key, $step = 1) {
        try {
            if (method_exists($this->driver, 'increment')) {
                $result = $this->driver->increment($key, $step);
                $this->logger->debug("缓存递增成功: {$key} + {$step}");
                return $result;
            } else {
                $this->logger->warning("当前驱动不支持递增操作");
                return false;
            }
            
        } catch (Exception $e) {
            $this->logger->error("缓存递增异常: {$key} - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 减少缓存值
     */
    public function decrement($key, $step = 1) {
        try {
            if (method_exists($this->driver, 'decrement')) {
                $result = $this->driver->decrement($key, $step);
                $this->logger->debug("缓存递减成功: {$key} - {$step}");
                return $result;
            } else {
                $this->logger->warning("当前驱动不支持递减操作");
                return false;
            }
            
        } catch (Exception $e) {
            $this->logger->error("缓存递减异常: {$key} - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取缓存统计信息
     */
    public function getStats() {
        try {
            if (method_exists($this->driver, 'getStats')) {
                return $this->driver->getStats();
            } else {
                return array(
                    'driver' => get_class($this->driver),
                    'supported_features' => array(
                        'set' => true,
                        'get' => true,
                        'delete' => true,
                        'clear' => true,
                        'increment' => method_exists($this->driver, 'increment'),
                        'decrement' => method_exists($this->driver, 'decrement'),
                        'deletePattern' => method_exists($this->driver, 'deletePattern'),
                        'getStats' => method_exists($this->driver, 'getStats')
                    )
                );
            }
            
        } catch (Exception $e) {
            $this->logger->error("获取缓存统计异常: " . $e->getMessage());
            return array();
        }
    }
    
    /**
     * 获取当前驱动实例
     */
    public function getDriver() {
        return $this->driver;
    }
    
    /**
     * 防止克隆
     */
    private function __clone() {}
    
    /**
     * 防止反序列化
     */
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

/**
 * 文件缓存驱动
 */
class FileCacheDriver {
    private $cacheDir;
    private $extension = '.cache';
    
    public function __construct($config = array()) {
        $this->cacheDir = isset($config['path']) ? $config['path'] : sys_get_temp_dir() . '/cache';
        
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }
    
    public function set($key, $value, $ttl = 3600) {
        $filename = $this->getFilename($key);
        $data = array(
            'value' => $value,
            'expires' => time() + $ttl,
            'created' => time()
        );
        
        return file_put_contents($filename, serialize($data), LOCK_EX) !== false;
    }
    
    public function get($key) {
        $filename = $this->getFilename($key);
        
        if (!file_exists($filename)) {
            return null;
        }
        
        $data = unserialize(file_get_contents($filename));
        
        if ($data['expires'] < time()) {
            $this->delete($key);
            return null;
        }
        
        return $data['value'];
    }
    
    public function delete($key) {
        $filename = $this->getFilename($key);
        return file_exists($filename) && unlink($filename);
    }
    
    public function has($key) {
        return $this->get($key) !== null;
    }
    
    public function clear() {
        $files = glob($this->cacheDir . '/*' . $this->extension);
        $success = true;
        
        foreach ($files as $file) {
            if (!unlink($file)) {
                $success = false;
            }
        }
        
        return $success;
    }
    
    public function deletePattern($pattern) {
        $files = glob($this->cacheDir . '/' . $pattern . '*' . $this->extension);
        $success = true;
        
        foreach ($files as $file) {
            if (!unlink($file)) {
                $success = false;
            }
        }
        
        return $success;
    }
    
    private function getFilename($key) {
        return $this->cacheDir . '/' . md5($key) . $this->extension;
    }
}

/**
 * Memcached缓存驱动
 */
class MemcachedCacheDriver {
    /** @var \Memcached|null */
    private $memcached;
    
    public function __construct($config = array()) {
        if (!class_exists('Memcached')) {
            throw new Exception('Memcached extension not found');
        }
        
        $this->memcached = new Memcached();
        
        $servers = isset($config['servers']) ? $config['servers'] : array(array('127.0.0.1', 11211, 100));
        
        foreach ($servers as $server) {
            $host = isset($server[0]) ? $server[0] : '127.0.0.1';
            $port = isset($server[1]) ? $server[1] : 11211;
            $weight = isset($server[2]) ? $server[2] : 100;
            $this->memcached->addServer($host, $port, $weight);
        }
        
        if (!empty($config['options'])) {
            foreach ($config['options'] as $option => $value) {
                $this->memcached->setOption($option, $value);
            }
        }
    }
    
    public function set($key, $value, $ttl = 3600) {
        return $this->memcached->set($key, $value, $ttl);
    }
    
    public function get($key) {
        $value = $this->memcached->get($key);
        return $value !== false ? $value : null;
    }
    
    public function delete($key) {
        return $this->memcached->delete($key);
    }
    
    public function has($key) {
        $this->memcached->get($key);
        $resultCode = $this->memcached->getResultCode();
        // Check if RES_NOTFOUND constant is defined, otherwise use the actual value
        $notFoundCode = defined('Memcached::RES_NOTFOUND') ? Memcached::RES_NOTFOUND : 1;
        return $resultCode !== $notFoundCode;
    }
    
    public function clear() {
        return $this->memcached->flush();
    }
    
    public function deletePattern($pattern) {
        // Memcached不支持模式匹配删除，这里返回false
        return false;
    }
    
    public function increment($key, $step = 1) {
        return $this->memcached->increment($key, $step);
    }
    
    public function decrement($key, $step = 1) {
        return $this->memcached->decrement($key, $step);
    }
    
    public function getStats() {
        return $this->memcached->getStats();
    }
}

/**
 * Redis缓存驱动
 */
class RedisCacheDriver {
    /** @var \Redis|null */
    private $redis;
    
    public function __construct($config = array()) {
        if (!class_exists('Redis')) {
            throw new Exception('Redis extension not found');
        }
        
        $this->redis = new Redis();
        $this->redis->connect(
            isset($config['host']) ? $config['host'] : '127.0.0.1',
            isset($config['port']) ? $config['port'] : 6379
        );
        
        if (!empty($config['password'])) {
            $this->redis->auth($config['password']);
        }
        
        if (!empty($config['database'])) {
            $this->redis->select($config['database']);
        }
    }
    
    public function set($key, $value, $ttl = 3600) {
        return $this->redis->setex($key, $ttl, serialize($value));
    }
    
    public function get($key) {
        $value = $this->redis->get($key);
        return $value !== false ? unserialize($value) : null;
    }
    
    public function delete($key) {
        return $this->redis->del($key) > 0;
    }
    
    public function has($key) {
        return $this->redis->exists($key) > 0;
    }
    
    public function clear() {
        return $this->redis->flushDB();
    }
    
    public function deletePattern($pattern) {
        $keys = $this->redis->keys($pattern);
        return !empty($keys) ? $this->redis->del($keys) > 0 : true;
    }
    
    public function increment($key, $step = 1) {
        return $this->redis->incrBy($key, $step);
    }
    
    public function decrement($key, $step = 1) {
        return $this->redis->decrBy($key, $step);
    }
    
    public function getStats() {
        return $this->redis->info();
    }
}

/**
 * APCu缓存驱动
 */
class ApcuCacheDriver {
    public function __construct($config = array()) {
        if (!function_exists('apcu_store')) {
            throw new Exception('APCu extension not found');
        }
    }
    
    public function set($key, $value, $ttl = 3600) {
        return apcu_store($key, $value, $ttl);
    }
    
    public function get($key) {
        $success = false;
        $value = apcu_fetch($key, $success);
        return $success ? $value : null;
    }
    
    public function delete($key) {
        return apcu_delete($key);
    }
    
    public function has($key) {
        return apcu_exists($key);
    }
    
    public function clear() {
        return apcu_clear_cache();
    }
    
    public function deletePattern($pattern) {
        // 检查APCUIterator类是否存在
        if (!class_exists('APCUIterator')) {
            return false;
        }
        
        $iterator = new APCUIterator('/^' . str_replace('*', '.*', $pattern) . '$/');
        $success = true;
        
        foreach ($iterator as $item) {
            if (!apcu_delete($item['key'])) {
                $success = false;
            }
        }
        
        return $success;
    }
    
    public function increment($key, $step = 1) {
        return apcu_inc($key, $step);
    }
    
    public function decrement($key, $step = 1) {
        return apcu_dec($key, $step);
    }
    
    public function getStats() {
        return apcu_cache_info();
    }
}