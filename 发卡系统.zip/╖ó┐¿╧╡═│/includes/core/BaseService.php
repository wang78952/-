<?php
/**
 * 基础服务类
 * 提供通用的服务功能和依赖注入
 */

require_once __DIR__ . '/ConfigManager.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/CacheManager.php';
require_once __DIR__ . '/ErrorHandler.php';
require_once __DIR__ . '/PermissionManager.php';

abstract class BaseService {
    protected static $instances = array();
    protected $config;
    protected $logger;
    protected $database;
    protected $cache;
    protected $errorHandler;
    
    /**
     * 构造函数
     */
    public function __construct() {
        $this->config = ConfigManager::getInstance();
        $this->logger = new Logger();
        $this->database = Database::getInstance();
        $this->cache = CacheManager::getInstance();
        $this->errorHandler = ErrorHandler::getInstance();
    }
    
    /**
     * 获取实例（支持子类单例模式）
     */
    public static function getInstance() {
        $calledClass = get_called_class();
        
        if (!isset(self::$instances[$calledClass])) {
            self::$instances[$calledClass] = new $calledClass();
        }
        
        return self::$instances[$calledClass];
    }
    
    /**
     * 验证输入参数
     */
    protected function validateInput($data, $rules) {
        $errors = array();
        
        foreach ($rules as $field => $rule) {
            $value = isset($data[$field]) ? $data[$field] : null;
            
            // 必填验证
            if (isset($rule['required']) && $rule['required'] && empty($value)) {
                $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}是必填项";
                continue;
            }
            
            // 如果字段为空且不是必填，跳过其他验证
            if (empty($value)) {
                continue;
            }
            
            // 类型验证
            if (isset($rule['type'])) {
                switch ($rule['type']) {
                    case 'int':
                        if (!is_numeric($value)) {
                            $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}必须是数字";
                        }
                        break;
                    case 'string':
                        if (!is_string($value)) {
                            $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}必须是字符串";
                        }
                        break;
                    case 'email':
                        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}必须是有效的邮箱地址";
                        }
                        break;
                    case 'url':
                        if (!filter_var($value, FILTER_VALIDATE_URL)) {
                            $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}必须是有效的URL";
                        }
                        break;
                    case 'array':
                        if (!is_array($value)) {
                            $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}必须是数组";
                        }
                        break;
                }
            }
            
            // 长度验证
            if (isset($rule['min_length']) && strlen($value) < $rule['min_length']) {
                $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}长度不能少于{$rule['min_length']}个字符";
            }
            
            if (isset($rule['max_length']) && strlen($value) > $rule['max_length']) {
                $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}长度不能超过{$rule['max_length']}个字符";
            }
            
            // 数值范围验证
            if (isset($rule['min']) && is_numeric($value) && $value < $rule['min']) {
                $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}不能小于{$rule['min']}";
            }
            
            if (isset($rule['max']) && is_numeric($value) && $value > $rule['max']) {
                $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}不能大于{$rule['max']}";
            }
            
            // 正则表达式验证
            if (isset($rule['pattern']) && !preg_match($rule['pattern'], $value)) {
                $errors[$field] = isset($rule['message']) ? $rule['message'] : "{$field}格式不正确";
            }
            
            // 自定义验证
            if (isset($rule['custom']) && is_callable($rule['custom'])) {
                $customResult = $rule['custom']($value, $data);
                if ($customResult !== true) {
                    $errors[$field] = is_string($customResult) ? $customResult : (isset($rule['message']) ? $rule['message'] : "{$field}验证失败");
                }
            }
        }
        
        if (!empty($errors)) {
            throw new ValidationException('输入验证失败', $errors);
        }
        
        return true;
    }
    
    /**
     * 清理输入数据
     */
    protected function sanitizeInput($data) {
        if (is_array($data)) {
            return array_map([$this, 'sanitizeInput'], $data);
        } else {
            return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        }
    }
    
    /**
     * 生成唯一ID
     */
    protected function generateUniqueId($prefix = '') {
        return $prefix . uniqid() . '_' . bin2hex(random_bytes(8));
    }
    
    /**
     * 格式化日期时间
     */
    protected function formatDateTime($datetime, $format = 'Y-m-d H:i:s') {
        if ($datetime instanceof DateTime) {
            return $datetime->format($format);
        } elseif (is_string($datetime)) {
            $date = new DateTime($datetime);
            return $date->format($format);
        } elseif (is_numeric($datetime)) {
            return date($format, $datetime);
        }
        
        return $datetime;
    }
    
    /**
     * 计算分页信息
     */
    protected function calculatePagination($page, $limit, $total) {
        $page = max(1, intval($page));
        $limit = max(1, min(100, intval($limit))); // 限制每页最多100条
        
        return array(
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'offset' => ($page - 1) * $limit,
            'has_next' => $page * $limit < $total,
            'has_prev' => $page > 1
        );
    }
    
    /**
     * 构建查询条件
     */
    protected function buildWhereClause($filters, $prefix = 'WHERE') {
        $conditions = array();
        $params = array();
        
        foreach ($filters as $field => $value) {
            if ($value === null || $value === '') {
                continue;
            }
            
            if (is_array($value)) {
                // IN查询
                $placeholders = str_repeat('?,', count($value) - 1) . '?';
                $conditions[] = "{$field} IN ({$placeholders})";
                $params = array_merge($params, $value);
            } elseif (strpos($value, '%') !== false) {
                // LIKE查询
                $conditions[] = "{$field} LIKE ?";
                $params[] = $value;
            } else {
                // 等值查询
                $conditions[] = "{$field} = ?";
                $params[] = $value;
            }
        }
        
        $whereClause = '';
        if (!empty($conditions)) {
            $whereClause = $prefix . ' ' . implode(' AND ', $conditions);
        }
        
        return array($whereClause, $params);
    }
    
    /**
     * 记录操作日志
     */
    protected function logOperation($action, $resource, $details = array()) {
        $logData = array(
            'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null,
            'action' => $action,
            'resource_type' => $resource,
            'details' => json_encode($details),
            'ip_address' => $this->getClientIp(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'created_at' => date('Y-m-d H:i:s')
        );
        
        $this->database->insert('operation_logs', $logData);
    }
    
    /**
     * 获取客户端IP
     */
    protected function getClientIp() {
        $ipKeys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
    }
    
    /**
     * 检查权限
     */
    protected function checkPermission($permission) {
        $permissionManager = new PermissionManager($this->database);
        $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        
        if (!$userId) {
            throw new AuthException('用户未登录');
        }
        
        if (!$permissionManager->hasPermission($userId, $permission)) {
            throw new PermissionException('权限不足');
        }
        
        return true;
    }
    
    /**
     * 检查用户是否有指定权限（兼容方法）
     */
    protected function hasPermission($permission) {
        try {
            $this->checkPermission($permission);
            return true;
        } catch (PermissionException $e) {
            return false;
        }
    }
    
    /**
     * 获取当前用户信息
     */
    protected function getCurrentUser() {
        $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        
        if (!$userId) {
            return null;
        }
        
        try {
            $query = "SELECT id, username, email, role, status FROM users WHERE id = ? AND status = 'active'";
            return $this->database->queryOne($query, array($userId));
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * 缓存结果
     */
    protected function cacheResult($key, $callback, $ttl = 3600) {
        $result = $this->cache->get($key);
        
        if ($result === null) {
            $result = $callback();
            $this->cache->set($key, $result, $ttl);
        }
        
        return $result;
    }
    
    /**
     * 清除缓存
     */
    protected function clearCache($pattern = null) {
        if ($pattern) {
            return $this->cache->deletePattern($pattern);
        } else {
            return $this->cache->flush();
        }
    }
    
    /**
     * 刷新缓存（clearCache的别名）
     */
    protected function flush() {
        return $this->clearCache();
    }
    
    /**
     * 发送通知
     */
    protected function sendNotification($type, $message, $recipients = array()) {
        $notificationConfig = $this->config->getNotificationConfig();
        
        if (empty($notificationConfig[$type]['enabled'])) {
            return false;
        }
        
        switch ($type) {
            case 'email':
                return $this->sendEmailNotification($message, $recipients, $notificationConfig['email']);
            case 'sms':
                return $this->sendSmsNotification($message, $recipients, $notificationConfig['sms']);
            case 'push':
                return $this->sendPushNotification($message, $recipients, $notificationConfig['push']);
            default:
                return false;
        }
    }
    
    /**
     * 发送邮件通知
     */
    private function sendEmailNotification($message, $recipients, $config) {
        // 集成邮件发送逻辑
        return true;
    }
    
    /**
     * 发送短信通知
     */
    private function sendSmsNotification($message, $recipients, $config) {
        // 集成短信发送逻辑
        return true;
    }
    
    /**
     * 发送推送通知
     */
    private function sendPushNotification($message, $recipients, $config) {
        // 集成推送通知逻辑
        return true;
    }
    
    /**
     * 事务处理
     */
    protected function transaction($callback) {
        try {
            $this->database->beginTransaction();
            $result = $callback();
            $this->database->commit();
            return $result;
        } catch (Exception $e) {
            $this->database->rollback();
            throw $e;
        }
    }
    
    /**
     * 批量操作
     */
    protected function batchOperation($items, $callback, $batchSize = 100) {
        $results = array();
        $errors = array();
        
        foreach (array_chunk($items, $batchSize) as $batch) {
            foreach ($batch as $item) {
                try {
                    $result = $callback($item);
                    $results[] = $result;
                } catch (Exception $e) {
                    $errors[] = array(
                        'item' => $item,
                        'error' => $e->getMessage()
                    );
                }
            }
        }
        
        return array(
            'success_count' => count($results),
            'error_count' => count($errors),
            'results' => $results,
            'errors' => $errors
        );
    }
    
    /**
     * 导出数据
     */
    protected function exportData($data, $format, $filename = null) {
        $filename = isset($filename) ? $filename : 'export_' . date('Y-m-d_H-i-s');
        
        switch (strtolower($format)) {
            case 'csv':
                $this->exportCsv($data, $filename);
                break;
            case 'excel':
                $this->exportExcel($data, $filename);
                break;
            case 'json':
                $this->exportJson($data, $filename);
                break;
            case 'pdf':
                $this->exportPdf($data, $filename);
                break;
            default:
                throw new InvalidArgumentException("不支持的导出格式: {$format}");
        }
    }
    
    /**
     * 导出CSV
     */
    private function exportCsv($data, $filename) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        if (!empty($data)) {
            // 写入标题行
            fputcsv($output, array_keys($data[0]));
            
            // 写入数据行
            foreach ($data as $row) {
                fputcsv($output, $row);
            }
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * 导出Excel
     */
    private function exportExcel($data, $filename) {
        // 这里应该集成PHPExcel或其他Excel库
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
        
        // 简单的HTML表格格式
        echo '<table border="1">';
        
        if (!empty($data)) {
            // 标题行
            echo '<tr>';
            foreach (array_keys($data[0]) as $header) {
                echo '<th>' . htmlspecialchars($header) . '</th>';
            }
            echo '</tr>';
            
            // 数据行
            foreach ($data as $row) {
                echo '<tr>';
                foreach ($row as $cell) {
                    echo '<td>' . htmlspecialchars($cell) . '</td>';
                }
                echo '</tr>';
            }
        }
        
        echo '</table>';
        exit;
    }
    
    /**
     * 导出JSON
     */
    private function exportJson($data, $filename) {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '.json"');
        
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * 导出PDF
     */
    private function exportPdf($data, $filename) {
        // 这里应该集成TCPDF或其他PDF库
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '.pdf"');
        
        echo 'PDF导出功能开发中...';
        exit;
    }
    
    /**
     * 生成响应数据
     */
    protected function response($data = null, $message = 'success', $code = 200) {
        return array(
            'success' => $code < 400,
            'code' => $code,
            'message' => $message,
            'data' => $data,
            'timestamp' => time()
        );
    }
    
    /**
     * 生成错误响应
     */
    protected function errorResponse($message, $code = 400, $data = null) {
        return $this->response($data, $message, $code);
    }
    
    /**
     * 生成成功响应
     */
    protected function successResponse($data = null, $message = 'success') {
        return $this->response($data, $message, 200);
    }
}

/**
 * 验证异常
 */
class ValidationException extends Exception {
    private $errors;
    
    public function __construct($message, $errors = array()) {
        parent::__construct($message);
        $this->errors = $errors;
    }
    
    public function getErrors() {
        return $this->errors;
    }
}

/**
 * 认证异常
 */
class AuthException extends Exception {
    
}

/**
 * 权限异常
 */
class PermissionException extends Exception {
    
}

/**
 * 业务逻辑异常
 */
class BusinessException extends Exception {
    
}