<?php
/**
 * 日志管理类
 * 提供统一的日志记录功能，支持多种日志级别和输出方式
 */

require_once __DIR__ . '/ConfigManager.php';
require_once __DIR__ . '/ErrorLevel.php';

class Logger {
    private static $instance = null;
    private $config;
    private $logFile;
    private $logLevel;
    private $maxFileSize;
    private $maxFiles;
    
    // 日志级别映射
    private $levels = array(
        ErrorLevel::DEBUG_NUM => ErrorLevel::DEBUG,
        ErrorLevel::INFO_NUM => ErrorLevel::INFO,
        ErrorLevel::WARNING_NUM => ErrorLevel::WARNING,
        ErrorLevel::ERROR_NUM => ErrorLevel::ERROR,
        ErrorLevel::CRITICAL_NUM => ErrorLevel::CRITICAL,
        ErrorLevel::EMERGENCY_NUM => ErrorLevel::EMERGENCY
    );
    
    /**
     * 私有构造函数
     */
    private function __construct() {
        $this->config = ConfigManager::getInstance();
        $this->initializeLogger();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 初始化日志器
     */
    private function initializeLogger() {
        $logConfig = $this->config->get('logging', array());
        
        $this->logFile = isset($logConfig['file']) ? $logConfig['file'] : __DIR__ . '/../logs/app.log';
        $this->logLevel = $this->getLevelByName(isset($logConfig['level']) ? $logConfig['level'] : 'INFO');
        $this->maxFileSize = isset($logConfig['max_file_size']) ? $logConfig['max_file_size'] : 10 * 1024 * 1024; // 10MB
        $this->maxFiles = isset($logConfig['max_files']) ? $logConfig['max_files'] : 5;
        
        // 确保日志目录存在
        $logDir = dirname($this->logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
    }
    
    /**
     * 记录调试信息
     */
    public function debug($message, $context = array()) {
        $this->log(ErrorLevel::DEBUG_NUM, $message, $context);
    }
    
    /**
     * 记录一般信息
     */
    public function info($message, $context = array()) {
        $this->log(ErrorLevel::INFO_NUM, $message, $context);
    }
    
    /**
     * 记录警告信息
     */
    public function warning($message, $context = array()) {
        $this->log(ErrorLevel::WARNING_NUM, $message, $context);
    }
    
    /**
     * 记录错误信息
     */
    public function error($message, $context = array()) {
        $this->log(ErrorLevel::ERROR_NUM, $message, $context);
    }
    
    /**
     * 记录严重错误信息
     */
    public function critical($message, $context = array()) {
        $this->log(ErrorLevel::CRITICAL_NUM, $message, $context);
    }
    
    /**
     * 记录一般信息（兼容方法）
     */
    public function logInfo($message, $context = array()) {
        return $this->info($message, $context);
    }
    
    /**
     * 记录错误信息（兼容方法）
     */
    public function logError($message, $context = array()) {
        return $this->error($message, $context);
    }
    
    /**
     * 记录警告信息（兼容方法）
     */
    public function logWarning($message, $context = array()) {
        return $this->warning($message, $context);
    }
    
    /**
     * 记录调试信息（兼容方法）
     */
    public function logDebug($message, $context = array()) {
        return $this->debug($message, $context);
    }
    
    /**
     * 记录严重错误信息（兼容方法）
     */
    public function logCritical($message, $context = array()) {
        return $this->critical($message, $context);
    }
    
    /**
     * 记录日志
     */
    public function log($level, $message, $context = array()) {
        // 确保$logLevel变量已经初始化，如果没有则使用默认的INFO级别
        if (!isset($this->logLevel)) {
            $this->logLevel = ErrorLevel::INFO_NUM;
        }
        
        if ($level < $this->logLevel) {
            return;
        }
        
        try {
            $logEntry = $this->formatLogEntry($level, $message, $context);
            $this->writeLog($logEntry);
            
            // 如果是严重错误，同时发送邮件通知
            if ($level >= ErrorLevel::ERROR_NUM) {
                $this->sendErrorNotification($level, $message, $context);
            }
            
        } catch (Exception $e) {
            // 日志记录失败时的备用处理
            error_log("日志记录失败: " . $e->getMessage());
        }
    }
    
    /**
     * 格式化日志条目
     */
    private function formatLogEntry($level, $message, $context = array()) {
        $timestamp = date('Y-m-d H:i:s');
        $levelName = $this->levels[$level];
        $requestId = $this->getRequestId();
        $userId = $this->getUserId();
        $ip = $this->getClientIp();
        $url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
        
        $logEntry = array(
            'timestamp' => $timestamp,
            'level' => $levelName,
            'request_id' => $requestId,
            'user_id' => $userId,
            'ip' => $ip,
            'method' => $method,
            'url' => $url,
            'message' => $message
        );
        
        if (!empty($context)) {
            $logEntry['context'] = $context;
        }
        
        return json_encode($logEntry) . PHP_EOL;
    }
    
    /**
     * 写入日志
     */
    private function writeLog($logEntry) {
        // 检查文件大小，如果超过限制则轮转
        if (file_exists($this->logFile) && filesize($this->logFile) >= $this->maxFileSize) {
            $this->rotateLog();
        }
        
        // 写入日志
        file_put_contents($this->logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * 日志文件轮转
     */
    private function rotateLog() {
        $logDir = dirname($this->logFile);
        $logName = basename($this->logFile, '.log');
        
        // 删除最旧的日志文件
        for ($i = $this->maxFiles; $i > 1; $i--) {
            $oldFile = $logDir . '/' . $logName . '.' . ($i - 1) . '.log';
            $newFile = $logDir . '/' . $logName . '.' . $i . '.log';
            
            if (file_exists($oldFile)) {
                rename($oldFile, $newFile);
            }
        }
        
        // 将当前日志文件重命名
        $rotatedFile = $logDir . '/' . $logName . '.1.log';
        rename($this->logFile, $rotatedFile);
    }
    
    /**
     * 发送错误通知
     */
    private function sendErrorNotification($level, $message, $context = array()) {
        $notificationConfig = $this->config->get('logging.notification', array());
        
        if (empty($notificationConfig['enabled'])) {
            return;
        }
        
        $levelName = $this->levels[$level];
        $subject = "[{$levelName}] 系统错误通知";
        $body = "时间: " . date('Y-m-d H:i:s') . "\n";
        $body .= "级别: {$levelName}\n";
        $body .= "消息: {$message}\n";
        $body .= "IP: " . $this->getClientIp() . "\n";
        $body .= "URL: " . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '') . "\n";
        
        if (!empty($context)) {
            $body .= "上下文: " . json_encode($context) . "\n";
        }
        
        // 发送邮件通知
        if (!empty($notificationConfig['email'])) {
            $this->sendEmailNotification($notificationConfig['email'], $subject, $body);
        }
        
        // 发送短信通知（仅限严重错误）
        if ($level >= ErrorLevel::CRITICAL_NUM && !empty($notificationConfig['sms'])) {
            $this->sendSmsNotification($notificationConfig['sms'], $subject);
        }
    }
    
    /**
     * 发送邮件通知
     */
    private function sendEmailNotification($config, $subject, $body) {
        // 这里应该集成实际的邮件发送功能
        // 例如使用PHPMailer或其他邮件库
        error_log("邮件通知: {$subject}");
    }
    
    /**
     * 发送短信通知
     */
    private function sendSmsNotification($config, $message) {
        // 这里应该集成实际的短信发送功能
        error_log("短信通知: {$message}");
    }
    
    /**
     * 获取请求ID
     */
    private function getRequestId() {
        if (!isset($_SERVER['HTTP_X_REQUEST_ID'])) {
            $_SERVER['HTTP_X_REQUEST_ID'] = uniqid('req_');
        }
        return $_SERVER['HTTP_X_REQUEST_ID'];
    }
    
    /**
     * 获取用户ID
     */
    private function getUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIp() {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
    }
    
    /**
     * 根据名称获取日志级别
     */
    private function getLevelByName($levelName) {
        $levelMap = array(
            'DEBUG' => ErrorLevel::DEBUG_NUM,
            'INFO' => ErrorLevel::INFO_NUM,
            'WARNING' => ErrorLevel::WARNING_NUM,
            'ERROR' => ErrorLevel::ERROR_NUM,
            'CRITICAL' => ErrorLevel::CRITICAL_NUM,
            'EMERGENCY' => ErrorLevel::EMERGENCY_NUM
        );
        
        return isset($levelMap[strtoupper($levelName)]) ? $levelMap[strtoupper($levelName)] : ErrorLevel::INFO_NUM;
    }
    
    /**
     * 获取日志统计信息
     */
    public function getStats() {
        if (!file_exists($this->logFile)) {
            return array(
                'total_lines' => 0,
                'file_size' => 0,
                'level_counts' => array()
            );
        }
        
        $content = file_get_contents($this->logFile);
        $lines = explode(PHP_EOL, trim($content));
        $levelCounts = array_fill_keys(array_values($this->levels), 0);
        
        foreach ($lines as $line) {
            if (empty($line)) continue;
            
            $data = json_decode($line, true);
            if ($data && isset($data['level'])) {
                $levelCounts[$data['level']]++;
            }
        }
        
        return array(
            'total_lines' => count($lines),
            'file_size' => filesize($this->logFile),
            'level_counts' => $levelCounts,
            'last_modified' => date('Y-m-d H:i:s', filemtime($this->logFile))
        );
    }
    
    /**
     * 查询日志
     */
    public function query($filters = array(), $limit = 100, $offset = 0) {
        if (!file_exists($this->logFile)) {
                return array();
            }
        
        $content = file_get_contents($this->logFile);
        $lines = explode(PHP_EOL, trim($content));
        $results = array();
        
        // 反转数组以便从最新开始查询
        $lines = array_reverse($lines);
        
        $count = 0;
        $skipped = 0;
        
        foreach ($lines as $line) {
            if (empty($line)) continue;
            
            $data = json_decode($line, true);
            if (!$data) continue;
            
            // 应用过滤条件
            if (!$this->matchesFilters($data, $filters)) {
                continue;
            }
            
            // 跳过偏移量
            if ($skipped < $offset) {
                $skipped++;
                continue;
            }
            
            array_push($results, $data);
            $count++;
            
            if ($count >= $limit) {
                break;
            }
        }
        
        return $results;
    }
    
    /**
     * 检查日志条目是否匹配过滤条件
     */
    private function matchesFilters($data, $filters) {
        foreach ($filters as $key => $value) {
            if (!isset($data[$key])) {
                return false;
            }
            
            if (is_array($value)) {
                if (!in_array($data[$key], $value)) {
                    return false;
                }
            } elseif (is_string($value) && strpos($value, '%') !== false) {
                $pattern = str_replace('%', '.*', preg_quote($value, '/'));
                if (!preg_match('/^' . $pattern . '$/i', $data[$key])) {
                    return false;
                }
            } elseif ($data[$key] != $value) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 清理旧日志
     */
    public function cleanup($days = 30) {
        $cutoffDate = date('Y-m-d', strtotime("-{$days} days"));
        $tempFile = $this->logFile . '.tmp';
        
        if (!file_exists($this->logFile)) {
            return true;
        }
        
        $input = fopen($this->logFile, 'r');
        $output = fopen($tempFile, 'w');
        
        $deletedCount = 0;
        
        while (($line = fgets($input)) !== false) {
            $data = json_decode($line, true);
            
            if ($data && isset($data['timestamp'])) {
                if ($data['timestamp'] >= $cutoffDate) {
                    fwrite($output, $line);
                } else {
                    $deletedCount++;
                }
            } else {
                fwrite($output, $line);
            }
        }
        
        fclose($input);
        fclose($output);
        
        // 替换原文件
        rename($tempFile, $this->logFile);
        
        $this->info("日志清理完成，删除了 {$deletedCount} 条记录", array(
            'cutoff_date' => $cutoffDate,
            'deleted_count' => $deletedCount
        ));
        
        return $deletedCount;
    }
    
    /**
     * 导出日志
     */
    public function export($filters = array(), $format = 'json') {
        $logs = $this->query($filters, 10000); // 最多导出10000条
        
        switch (strtolower($format)) {
            case 'csv':
                $this->exportCsv($logs);
                break;
            case 'json':
            default:
                $this->exportJson($logs);
                break;
        }
    }
    
    /**
     * 导出为JSON格式
     */
    private function exportJson($logs) {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="logs_' . date('YmdHis') . '.json"');
        
        echo json_encode($logs, JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * 导出为CSV格式
     */
    private function exportCsv($logs) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="logs_' . date('YmdHis') . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        if (!empty($logs)) {
            // 写入标题行
            $headers = array_keys($logs[0]);
            fputcsv($output, $headers);
            
            // 写入数据行
            foreach ($logs as $log) {
                $row = array();
                foreach ($headers as $header) {
                    $value = isset($log[$header]) ? $log[$header] : '';
                    if (is_array($value)) {
                        $value = json_encode($value, JSON_PRETTY_PRINT);
                    }
                    array_push($row, $value);
                }
                fputcsv($output, $row);
            }
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * 防止克隆
     */
    private function __clone() {}
    
    /**
     * 防止反序列化
     */
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}