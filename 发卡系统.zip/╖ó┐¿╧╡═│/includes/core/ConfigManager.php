<?php
/**
 * 统一配置管理类
 * 提供配置文件的加载、缓存、验证和管理功能
 */

class ConfigManager {
    private static $instance = null;
    private $config = array();
    private $configPath;
    private $cacheEnabled;
    private $cacheFile;
    
    /**
     * 私有构造函数，实现单例模式
     */
    private function __construct() {
        $this->configPath = __DIR__ . '/../config/';
        $this->cacheEnabled = defined('CONFIG_CACHE_ENABLED') ? CONFIG_CACHE_ENABLED : true;
        $this->cacheFile = __DIR__ . '/../cache/config.cache.php';
        $this->loadConfiguration();
    }
    
    /**
     * 获取单例实例
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 加载配置文件
     */
    private function loadConfiguration() {
        // 尝试从缓存加载
        if ($this->cacheEnabled && file_exists($this->cacheFile)) {
            $cacheTime = filemtime($this->cacheFile);
            $configFiles = $this->getConfigFiles();
            $maxConfigTime = 0;
            
            foreach ($configFiles as $file) {
                if (file_exists($file)) {
                    $maxConfigTime = max($maxConfigTime, filemtime($file));
                }
            }
            
            // 如果缓存是最新的，直接使用缓存
            if ($cacheTime >= $maxConfigTime) {
                $this->config = include $this->cacheFile;
                return;
            }
        }
        
        // 重新加载配置
        $this->config = $this->loadConfigFiles();
        
        // 保存到缓存
        if ($this->cacheEnabled) {
            $this->saveToCache();
        }
    }
    
    /**
     * 获取所有配置文件列表
     */
    private function getConfigFiles() {
        return [
            $this->configPath . 'database.php',
            $this->configPath . 'app.php',
            $this->configPath . 'cache.php',
            $this->configPath . 'security.php',
            $this->configPath . 'api.php',
            $this->configPath . 'payment.php',
            $this->configPath . 'notification.php',
            $this->configPath . 'compliance.php',
            $this->configPath . 'permission.php',
            $this->configPath . 'monitoring.php'
        ];
    }
    
    /**
     * 加载所有配置文件
     */
    private function loadConfigFiles() {
        $config = array();
        $configFiles = $this->getConfigFiles();
        
        foreach ($configFiles as $file) {
            if (file_exists($file)) {
                $filename = basename($file, '.php');
                $fileConfig = include $file;
                
                // 验证配置格式
                if (is_array($fileConfig)) {
                    $config[$filename] = $fileConfig;
                } else {
                    error_log("配置文件格式错误: {$file}");
                }
            }
        }
        
        // 加载环境特定配置
        $env = $this->getEnvironment();
        $envConfigFile = $this->configPath . $env . '.php';
        if (file_exists($envConfigFile)) {
            $envConfig = include $envConfigFile;
            $config = array_merge_recursive($config, $envConfig);
        }
        
        return $config;
    }
    
    /**
     * 保存配置到缓存
     */
    private function saveToCache() {
        $cacheDir = dirname($this->cacheFile);
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }
        
        $content = "<?php\nreturn " . var_export($this->config, true) . ";\n";
        file_put_contents($this->cacheFile, $content);
    }
    
    /**
     * 获取当前环境
     */
    public function getEnvironment() {
        return defined('APP_ENV') ? APP_ENV : 'production';
    }
    
    /**
     * 获取配置值
     */
    public function get($key, $default = null) {
        $keys = explode('.', $key);
        $value = $this->config;
        
        foreach ($keys as $k) {
            if (is_array($value) && isset($value[$k])) {
                $value = $value[$k];
            } else {
                return $default;
            }
        }
        
        return $value;
    }
    
    /**
     * 设置配置值（运行时）
     */
    public function set($key, $value) {
        $keys = explode('.', $key);
        $config = &$this->config;
        
        foreach ($keys as $k) {
            if (!isset($config[$k]) || !is_array($config[$k])) {
                $config[$k] = array();
            }
            $config = &$config[$k];
        }
        
        $config = $value;
        return $this;
    }
    
    /**
     * 检查配置是否存在
     */
    public function has($key) {
        return $this->get($key) !== null;
    }
    
    /**
     * 获取数据库配置
     */
    public function getDatabaseConfig() {
        return $this->get('database', array());
    }
    
    /**
     * 获取缓存配置
     */
    public function getCacheConfig() {
        return $this->get('cache', array());
    }
    
    /**
     * 获取安全配置
     */
    public function getSecurityConfig() {
        return $this->get('security', array());
    }
    
    /**
     * 获取API配置
     */
    public function getApiConfig() {
        return $this->get('api', array());
    }
    
    /**
     * 获取支付配置
     */
    public function getPaymentConfig() {
        return $this->get('payment', array());
    }
    
    /**
     * 获取通知配置
     */
    public function getNotificationConfig() {
        return $this->get('notification', array());
    }
    
    /**
     * 获取合规配置
     */
    public function getComplianceConfig() {
        return $this->get('compliance', array());
    }
    
    /**
     * 获取权限配置
     */
    public function getPermissionConfig() {
        return $this->get('permission', array());
    }
    
    /**
     * 获取监控配置
     */
    public function getMonitoringConfig() {
        return $this->get('monitoring', array());
    }
    
    /**
     * 获取应用配置
     */
    public function getAppConfig() {
        return $this->get('app', array());
    }
    
    /**
     * 验证配置完整性
     */
    public function validateConfig() {
        $errors = array();
        
        // 验证必需的配置项
        $requiredConfigs = [
            'database.host' => '数据库主机',
            'database.database' => '数据库名称',
            'database.username' => '数据库用户名',
            'app.name' => '应用名称',
            'security.encryption_key' => '加密密钥'
        ];
        
        foreach ($requiredConfigs as $key => $description) {
            if (!$this->has($key)) {
                $errors[] = "缺少必需配置: {$description} ({$key})";
            }
        }
        
        // 验证数据库连接
        try {
            $dbConfig = $this->getDatabaseConfig();
            if (!empty($dbConfig)) {
                $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset=utf8mb4";
                new PDO($dsn, $dbConfig['username'], $dbConfig['password']);
            }
        } catch (Exception $e) {
            $errors[] = "数据库连接失败: " . $e->getMessage();
        }
        
        // 验证缓存配置
        try {
            $cacheConfig = $this->getCacheConfig();
            if (!empty($cacheConfig) && $cacheConfig['type'] === 'redis') {
                $redis = new Redis();
                $redis->connect($cacheConfig['host'], $cacheConfig['port']);
                if (!empty($cacheConfig['password'])) {
                    $redis->auth($cacheConfig['password']);
                }
            }
        } catch (Exception $e) {
            $errors[] = "Redis连接失败: " . $e->getMessage();
        }
        
        return $errors;
    }
    
    /**
     * 重新加载配置
     */
    public function reload() {
        // 清除缓存
        if (file_exists($this->cacheFile)) {
            unlink($this->cacheFile);
        }
        
        $this->loadConfiguration();
        return $this;
    }
    
    /**
     * 获取所有配置
     */
    public function all() {
        return $this->config;
    }
    
    /**
     * 获取配置文件内容
     */
    public function getConfigFile($filename) {
        $file = $this->configPath . $filename . '.php';
        if (file_exists($file)) {
            return include $file;
        }
        return null;
    }
    
    /**
     * 更新配置文件
     */
    public function updateConfigFile($filename, $config) {
        $file = $this->configPath . $filename . '.php';
        
        // 验证配置格式
        if (!is_array($config)) {
            throw new InvalidArgumentException('配置必须是数组格式');
        }
        
        // 备份原文件
        if (file_exists($file)) {
            $backupFile = $file . '.backup.' . date('YmdHis');
            copy($file, $backupFile);
        }
        
        // 写入新配置
        $content = "<?php\nreturn " . var_export($config, true) . ";\n";
        if (file_put_contents($file, $content) === false) {
            throw new RuntimeException("无法写入配置文件: {$file}");
        }
        
        // 重新加载配置
        $this->reload();
        
        return true;
    }
    
    /**
     * 获取配置模板
     */
    public function getConfigTemplate($type) {
        $templates = [
            'database' => [
                'host' => 'localhost',
                'port' => 3306,
                'database' => 'card_system',
                'username' => 'root',
                'password' => '',
                'charset' => 'utf8mb4',
                'options' => [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                ]
            ],
            'cache' => [
                'type' => 'redis',
                'host' => '127.0.0.1',
                'port' => 6379,
                'password' => '',
                'database' => 0,
                'prefix' => 'card_system:',
                'ttl' => 3600
            ],
            'security' => [
                'encryption_key' => '',
                'jwt_secret' => '',
                'password_salt' => '',
                'session_timeout' => 3600,
                'max_login_attempts' => 5,
                'lockout_duration' => 900
            ],
            'api' => [
                'version' => 'v1',
                'rate_limit' => [
                    'requests_per_minute' => 60,
                    'burst_size' => 10
                ],
                'cors' => [
                    'allowed_origins' => ['*'],
                    'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE'],
                    'allowed_headers' => ['Content-Type', 'Authorization']
                ]
            ]
        ];
        
        return isset($templates[$type]) ? $templates[$type] : null;
    }
    
    /**
     * 导出配置
     */
    public function exportConfig($format = 'php') {
        switch ($format) {
            case 'php':
                return "<?php\nreturn " . var_export($this->config, true) . ";\n";
            case 'json':
                return json_encode($this->config, JSON_PRETTY_PRINT);
            case 'yaml':
                // 优先使用自定义实现，确保兼容性
                try {
                    return $this->simpleArrayToYaml($this->config);
                } catch (Exception $e) {
                    error_log("YAML导出错误: " . $e->getMessage());
                    throw new RuntimeException("YAML导出失败: " . $e->getMessage());
                }
            default:
                throw new InvalidArgumentException("不支持的导出格式: {$format}");
        }
    }
    
    /**
     * 导入配置
     */
    public function importConfig($content, $format = 'php') {
        switch ($format) {
            case 'php':
                $config = eval('?>' . $content);
                break;
            case 'json':
                $config = json_decode($content, true);
                if ($config === null) {
                    throw new RuntimeException('JSON格式错误');
                }
                break;
            case 'yaml':
                // 优先使用自定义实现，确保兼容性
                try {
                    $config = $this->simpleYamlToArray($content);
                    // 检查解析结果
                    if ($config === null || !is_array($config)) {
                        throw new RuntimeException('YAML解析失败，未得到有效数组');
                    }
                } catch (Exception $e) {
                    error_log("YAML导入错误: " . $e->getMessage());
                    throw new RuntimeException("YAML导入失败: " . $e->getMessage());
                }
                break;
            default:
                throw new InvalidArgumentException("不支持的导入格式: {$format}");
        }
        
        if (!is_array($config)) {
            throw new RuntimeException('配置必须是数组格式');
        }
        
        $this->config = array_merge_recursive($this->config, $config);
        
        // 保存到缓存
        if ($this->cacheEnabled) {
            $this->saveToCache();
        }
        
        return true;
    }
    
    /**
     * 清除配置缓存
     */
    public function clearCache() {
        if (file_exists($this->cacheFile)) {
            return unlink($this->cacheFile);
        }
        return true;
    }
    
    /**
     * 获取配置统计信息
     */
    public function getConfigStats() {
        $stats = [
            'total_configs' => count($this->config),
            'cache_enabled' => $this->cacheEnabled,
            'cache_file_exists' => file_exists($this->cacheFile),
            'environment' => $this->getEnvironment(),
            'config_files' => []
        ];
        
        $configFiles = $this->getConfigFiles();
        foreach ($configFiles as $file) {
            $filename = basename($file, '.php');
            $stats['config_files'][$filename] = [
                'exists' => file_exists($file),
                'size' => file_exists($file) ? filesize($file) : 0,
                'modified' => file_exists($file) ? filemtime($file) : null
            ];
        }
        
        return $stats;
    }
    
    /**
     * 简单的数组转YAML实现，用于PHP 5.3兼容
     */
    private function simpleArrayToYaml($array, $indent = 0) {
        $yaml = '';
        $spaces = str_repeat('  ', $indent);
        
        foreach ($array as $key => $value) {
            if (is_numeric($key)) {
                $yaml .= "{$spaces}- ";
            } else {
                $yaml .= "{$spaces}{$key}: ";
            }
            
            if (is_array($value)) {
                if (empty($value)) {
                    $yaml .= "{}";
                } else {
                    $yaml .= "\n" . $this->simpleArrayToYaml($value, $indent + 1);
                }
            } elseif (is_bool($value)) {
                $yaml .= $value ? 'true' : 'false';
            } elseif (is_null($value)) {
                $yaml .= 'null';
            } elseif (is_numeric($value)) {
                $yaml .= $value;
            } else {
                // 简单的字符串处理，添加引号
                $yaml .= '"' . addslashes($value) . '"';
            }
            $yaml .= "\n";
        }
        
        return $yaml;
    }
    
    /**
     * 简单的YAML转数组实现，用于PHP 5.3兼容
     */
    private function simpleYamlToArray($yaml) {
        $result = array();
        $lines = explode("\n", $yaml);
        $currentIndent = 0;
        $indentStack = array();
        $pathStack = array();
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) || $line[0] === '#') {
                continue; // 跳过空行和注释
            }
            
            // 计算缩进级别
            $indent = 0;
            while (isset($line[$indent]) && $line[$indent] === ' ') {
                $indent++;
            }
            $indent = floor($indent / 2); // 假设2个空格为一个缩进级别
            
            $line = trim($line);
            
            if ($line[0] === '-') {
                // 列表项
                $value = substr($line, 1);
                $value = trim($value);
                $currentArray = &$result;
                
                // 沿着路径栈找到正确的位置
                foreach ($pathStack as $key) {
                    $currentArray = &$currentArray[$key];
                }
                
                if ($value === '') {
                    // 空列表项，将在下一行定义子内容
                    $currentArray[] = array();
                    $pathStack[] = count($currentArray) - 1;
                } elseif (strpos($value, ':') === false) {
                    // 简单值
                    $currentArray[] = $this->convertYamlValue($value);
                } else {
                    // 内联键值对
                    list($key, $value) = explode(':', $value, 2);
                    $key = trim($key);
                    $value = trim($value);
                    $currentArray[] = array($key => $this->convertYamlValue($value));
                }
            } else {
                // 键值对
                list($key, $value) = explode(':', $line, 2);
                $key = trim($key);
                $value = trim($value);
                
                // 调整路径栈以匹配缩进级别
                while (count($indentStack) > 0 && end($indentStack) >= $indent) {
                    array_pop($indentStack);
                    array_pop($pathStack);
                }
                
                $currentArray = &$result;
                foreach ($pathStack as $pathKey) {
                    $currentArray = &$currentArray[$pathKey];
                }
                
                if ($value === '') {
                    // 空值，将在下一行定义子内容
                    $currentArray[$key] = array();
                    $indentStack[] = $indent;
                    $pathStack[] = $key;
                } else {
                    $currentArray[$key] = $this->convertYamlValue($value);
                }
            }
        }
        
        return $result;
    }
    
    /**
     * 转换YAML值为PHP值
     */
    private function convertYamlValue($value) {
        if ($value === 'true') return true;
        if ($value === 'false') return false;
        if ($value === 'null') return null;
        if (is_numeric($value)) return $value + 0;
        
        // 处理带引号的字符串
        if (($value[0] === '"' && substr($value, -1) === '"') ||
            ($value[0] === '\'' && substr($value, -1) === '\'')) {
            return stripslashes(substr($value, 1, -1));
        }
        
        return $value;
    }
}