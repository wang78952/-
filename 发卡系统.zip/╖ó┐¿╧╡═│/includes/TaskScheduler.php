<?php
/**
 * 自动化任务调度器
 * 用于管理定时任务、性能监控、数据清理等自动化操作
 */

// 定义SMTP相关常量作为默认值（如果配置文件中未定义）
if (!defined('SMTP_HOST')) {
    define('SMTP_HOST', '');
}

if (!defined('SMTP_USERNAME')) {
    define('SMTP_USERNAME', '');
}

class TaskScheduler {
    private $database;
    private $logger;
    private $cache;
    
    public function __construct() {
        $this->database = Database::getInstance();
        $this->logger = new Logger();
        $this->cache = new CacheManager();
    }
    
    /**
     * 执行所有定时任务
     */
    public function runAllTasks() {
        $tasks = [
            'update_daily_stats' => '更新每日统计数据',
            'cleanup_old_data' => '清理过期数据',
            'optimize_tables' => '优化数据库表',
            'check_system_health' => '检查系统健康状态',
            'generate_reports' => '生成性能报告',
            'backup_critical_data' => '备份关键数据'
        ];
        
        $results = array();
        
        foreach ($tasks as $task => $description) {
            try {
                $startTime = microtime(true);
                $this->logger->info("开始执行任务: {$description}", array('task' => $task));
                
                $result = $this->$task();
                
                $executionTime = round((microtime(true) - $startTime) * 1000, 2);
                
                $results[$task] = array(
                    'status' => 'success',
                    'execution_time' => $executionTime,
                    'message' => $result
                );
                
                $this->logger->info("任务执行成功: {$description}", array(
                    'task' => $task,
                    'execution_time' => $executionTime
                ));
                
            } catch (Exception $e) {
                $results[$task] = array(
                    'status' => 'error',
                    'message' => $e->getMessage()
                );
                
                $this->logger->error("任务执行失败: {$description}", array(
                    'task' => $task,
                    'error' => $e->getMessage()
                ));
            }
        }
        
        return $results;
    }
    
    /**
     * 更新每日统计数据
     */
    private function update_daily_stats() {
        // 调用存储过程更新统计
        $this->database->exec("CALL UpdateDailyCardStats()");
        $this->database->exec("CALL UpdateDailyUserStats()");
        $this->database->exec("CALL UpdateDailyVerificationStats()");
        
        // 清除相关缓存
        $this->cache->deletePattern('dashboard_stats_*');
        $this->cache->deletePattern('card_stats_*');
        $this->cache->deletePattern('user_stats_*');
        
        return "每日统计数据更新完成";
    }
    
    /**
     * 清理过期数据
     */
    private function cleanup_old_data() {
        // 调用存储过程清理数据
        $this->database->exec("CALL CleanupOldData()");
        
        // 清理过期会话
        $this->database->exec("
            DELETE FROM user_sessions 
            WHERE expires_at < NOW() OR status = 'expired'
        ");
        
        // 清理过期验证码
        $this->database->exec("
            DELETE FROM verification_codes 
            WHERE expires_at < NOW()
        ");
        
        // 清理临时文件
        $tempDir = dirname(__DIR__) . '/uploads/temp/';
        if (is_dir($tempDir)) {
            $files = glob($tempDir . '*');
            foreach ($files as $file) {
                if (is_file($file) && (time() - filemtime($file)) > 86400) { // 24小时
                    unlink($file);
                }
            }
        }
        
        return "过期数据清理完成";
    }
    
    /**
     * 优化数据库表
     */
    private function optimize_tables() {
        $tables = [
            'cards', 'users', 'orders', 'system_logs', 
            'identity_verifications', 'compliance_logs',
            'user_sessions', 'verification_codes'
        ];
        
        foreach ($tables as $table) {
            try {
                $this->database->exec("OPTIMIZE TABLE `{$table}`");
                $this->logger->info("表 {$table} 优化完成");
            } catch (Exception $e) {
                $this->logger->error("表 {$table} 优化失败: " . $e->getMessage());
            }
        }
        
        return "数据库表优化完成";
    }
    
    /**
     * 检查系统健康状态
     */
    private function check_system_health() {
        $health = array();
        
        // 检查数据库连接
        try {
            $this->database->query("SELECT 1");
            $health['database'] = array('status' => 'healthy', 'message' => '数据库连接正常');
        } catch (Exception $e) {
            $health['database'] = array('status' => 'error', 'message' => $e->getMessage());
        }
        
        // 检查磁盘空间
        $freeSpace = disk_free_space(dirname(__DIR__));
        $totalSpace = disk_total_space(dirname(__DIR__));
        $usagePercent = round((1 - $freeSpace / $totalSpace) * 100, 2);
        
        if ($usagePercent > 90) {
            $health['disk_space'] = array('status' => 'critical', 'message' => "磁盘使用率 {$usagePercent}%");
        } elseif ($usagePercent > 80) {
            $health['disk_space'] = array('status' => 'warning', 'message' => "磁盘使用率 {$usagePercent}%");
        } else {
            $health['disk_space'] = array('status' => 'healthy', 'message' => "磁盘使用率 {$usagePercent}%");
        }
        
        // 检查内存使用
        if (function_exists('memory_get_usage')) {
            $memoryUsage = memory_get_usage(true);
            $memoryLimit = ini_get('memory_limit');
            $memoryPercent = round(($memoryUsage / $this->parseMemoryLimit($memoryLimit)) * 100, 2);
            
            if ($memoryPercent > 90) {
                $health['memory'] = array('status' => 'critical', 'message' => "内存使用率 {$memoryPercent}%");
            } elseif ($memoryPercent > 80) {
                $health['memory'] = array('status' => 'warning', 'message' => "内存使用率 {$memoryPercent}%");
            } else {
                $health['memory'] = array('status' => 'healthy', 'message' => "内存使用率 {$memoryPercent}%");
            }
        }
        
        // 检查错误日志
        $errorLog = dirname(__DIR__) . '/logs/error.log';
        if (file_exists($errorLog)) {
            $recentErrors = $this->countRecentErrors($errorLog, 3600); // 最近1小时
            if ($recentErrors > 100) {
                $health['error_log'] = array('status' => 'critical', 'message' => "最近1小时有 {$recentErrors} 个错误");
            } elseif ($recentErrors > 50) {
                $health['error_log'] = array('status' => 'warning', 'message' => "最近1小时有 {$recentErrors} 个错误");
            } else {
                $health['error_log'] = array('status' => 'healthy', 'message' => "最近1小时有 {$recentErrors} 个错误");
            }
        }
        
        // 记录健康状态
        $this->logger->info('系统健康检查完成', array('health' => $health));
        
        return $health;
    }
    
    /**
     * 生成性能报告
     */
    private function generate_reports() {
        $reporter = new PerformanceReporter();
        $report = $reporter->generateReport();
        
        // 保存报告到文件
        $reportFile = dirname(__DIR__) . '/reports/performance_' . date('Y-m-d_H-i-s') . '.json';
        $reportDir = dirname($reportFile);
        
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }
        
        file_put_contents($reportFile, json_encode($report, JSON_PRETTY_PRINT));
        
        // 发送邮件报告（如果配置了邮件）
        if ($this->isEmailConfigured()) {
            $this->sendEmailReport($report, $reportFile);
        }
        
        return "性能报告已生成: {$reportFile}";
    }
    
    /**
     * 备份关键数据
     */
    private function backup_critical_data() {
        $backupDir = dirname(__DIR__) . '/backups/' . date('Y-m-d');
        
        if (!is_dir($backupDir)) {
            mkdir($backupDir, 0755, true);
        }
        
        // 备份配置文件
        $configFiles = [
            'database.php',
            'config.php',
            '.env'
        ];
        
        foreach ($configFiles as $file) {
            $source = dirname(__DIR__) . '/' . $file;
            if (file_exists($source)) {
                copy($source, $backupDir . '/' . $file);
            }
        }
        
        // 备份数据库结构
        $structureFile = $backupDir . '/database_structure.sql';
        $this->backupDatabaseStructure($structureFile);
        
        // 清理30天前的备份
        $oldBackups = glob(dirname(__DIR__) . '/backups/*', GLOB_ONLYDIR);
        foreach ($oldBackups as $backup) {
            if (is_dir($backup) && (time() - filemtime($backup)) > 30 * 86400) {
                $this->deleteDirectory($backup);
            }
        }
        
        return "关键数据备份完成: {$backupDir}";
    }
    
    /**
     * 解析内存限制
     */
    private function parseMemoryLimit($limit) {
        $limit = trim($limit);
        $last = strtolower($limit[strlen($limit) - 1]);
        $value = (int) $limit;
        
        switch ($last) {
            case 'g':
                $value *= 1024;
            case 'm':
                $value *= 1024;
            case 'k':
                $value *= 1024;
        }
        
        return $value;
    }
    
    /**
     * 统计最近错误数量
     */
    private function countRecentErrors($logFile, $seconds) {
        if (!file_exists($logFile)) {
            return 0;
        }
        
        $cutoffTime = time() - $seconds;
        $count = 0;
        
        $handle = fopen($logFile, 'r');
        if ($handle) {
            while (($line = fgets($handle)) !== false) {
                if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})/', $line, $matches)) {
                    $logTime = strtotime($matches[1]);
                    if ($logTime >= $cutoffTime && strpos($line, 'ERROR') !== false) {
                        $count++;
                    }
                }
            }
            fclose($handle);
        }
        
        return $count;
    }
    
    /**
     * 检查邮件是否配置
     */
    private function isEmailConfigured() {
        // 检查邮件配置是否存在
        return defined('SMTP_HOST') && SMTP_HOST && 
               defined('SMTP_USERNAME') && SMTP_USERNAME;
    }
    
    /**
     * 发送邮件报告
     */
    private function sendEmailReport($report, $reportFile) {
        // 这里应该实现邮件发送逻辑
        // 可以使用PHPMailer或其他邮件库
        $this->logger->info('性能报告邮件已发送', array('report_file' => $reportFile));
    }
    
    /**
     * 备份数据库结构
     */
    private function backupDatabaseStructure($outputFile) {
        try {
            $tables = $this->database->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            
            $sql = "-- 数据库结构备份\n";
            $sql .= "-- 生成时间: " . date('Y-m-d H:i:s') . "\n\n";
            
            foreach ($tables as $table) {
                $createTable = $this->database->query("SHOW CREATE TABLE `{$table}`")->fetch();
                $sql .= $createTable['Create Table'] . ";\n\n";
            }
            
            file_put_contents($outputFile, $sql);
            
        } catch (Exception $e) {
            $this->logger->error('数据库结构备份失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 递归删除目录
     */
    private function deleteDirectory($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                unlink($path);
            }
        }
        rmdir($dir);
    }
    
    /**
     * 运行单个任务
     */
    public function runTask($taskName) {
        if (method_exists($this, $taskName)) {
            try {
                $startTime = microtime(true);
                $result = $this->$taskName();
                $executionTime = round((microtime(true) - $startTime) * 1000, 2);
                
                return [
                    'status' => 'success',
                    'execution_time' => $executionTime,
                    'result' => $result
                ];
            } catch (Exception $e) {
                return [
                    'status' => 'error',
                    'message' => $e->getMessage()
                ];
            }
        } else {
            return [
                'status' => 'error',
                'message' => "任务 {$taskName} 不存在"
            ];
        }
    }
    
    /**
     * 获取任务列表
     */
    public function getTaskList() {
        return [
            'update_daily_stats' => '更新每日统计数据',
            'cleanup_old_data' => '清理过期数据',
            'optimize_tables' => '优化数据库表',
            'check_system_health' => '检查系统健康状态',
            'generate_reports' => '生成性能报告',
            'backup_critical_data' => '备份关键数据'
        ];
    }
}

// CLI运行接口
if (php_sapi_name() === 'cli') {
    require_once __DIR__ . '/../config/config.php';
    require_once __DIR__ . '/../includes/Database.php';
    require_once __DIR__ . '/../includes/Logger.php';
    require_once __DIR__ . '/../includes/CacheManager.php';
    require_once __DIR__ . '/../includes/PerformanceReporter.php';
    
    $scheduler = new TaskScheduler();
    
    if ($argc > 1) {
        $task = $argv[1];
        echo "执行任务: {$task}\n";
        $result = $scheduler->runTask($task);
        echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "执行所有任务:\n";
        $results = $scheduler->runAllTasks();
        echo json_encode($results, JSON_PRETTY_PRINT) . "\n";
    }
}