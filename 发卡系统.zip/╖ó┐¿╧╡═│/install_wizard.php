<?php
/**
 * 一键安装向导
 * 提供环境检测、配置安装和使用教程功能
 */

// 防止重复安装
if (file_exists('config.php') && filesize('config.php') > 0) {
    echo '系统已安装，请先删除 config.php 后重新安装！';
    exit;
}

// 安装步骤
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$submitted = isset($_POST['submit']);

// 页面标题
$title = '智能发卡系统 - ';
switch ($step) {
    case 1: $title .= '环境检测'; break;
    case 2: $title .= '数据库配置'; break;
    case 3: $title .= '管理员设置'; break;
    case 4: $title .= '模式选择'; break;
    case 5: $title .= '安装完成'; break;
}

// 安装结果数组
$result = array();

if ($submitted && $step == 1) {
    // 执行环境检测
    $result = performEnvironmentCheck();
    
    // 如果检测通过，进入下一步
    if ($result['passed']) {
        header('Location: install_wizard.php?step=2');
        exit;
    }
} elseif ($submitted && $step == 2) {
    // 数据库配置处理
    $dbConfig = $_POST;
    $dbTestResult = testDatabaseConnection($dbConfig);
    
    if ($dbTestResult['connected']) {
        // 保存数据库配置到会话
        session_start();
        $_SESSION['db_config'] = $dbConfig;
        header('Location: install_wizard.php?step=3');
        exit;
    }
} elseif ($submitted && $step == 3) {
    // 管理员设置处理
    $adminConfig = $_POST;
    if (validateAdminConfig($adminConfig)) {
        // 保存管理员配置到会话
        session_start();
        $_SESSION['admin_config'] = $adminConfig;
        header('Location: install_wizard.php?step=4');
        exit;
    }
} elseif ($submitted && $step == 4) {
    // 模式选择处理
    $mode = $_POST['mode'];
    session_start();
    $_SESSION['mode'] = $mode;
    
    // 执行安装
    if (performInstallation($_SESSION['db_config'], $_SESSION['admin_config'], $mode)) {
        header('Location: install_wizard.php?step=5');
        exit;
    }
}

// 环境检测函数
function performEnvironmentCheck() {
    $checks = array();
    $passed = true;
    
    // PHP版本检测
    $phpVersion = phpversion();
    $phpRequired = '7.0.0';
    $phpOk = version_compare($phpVersion, $phpRequired, '>=');
    $checks['php_version'] = array(
        'name' => 'PHP版本',
        'current' => $phpVersion,
        'required' => $phpRequired,
        'status' => $phpOk ? 'pass' : 'fail',
        'message' => $phpOk ? 'PHP版本符合要求' : 'PHP版本过低，需要PHP 7.0.0或更高版本'
    );
    if (!$phpOk) $passed = false;
    
    // PHP扩展检测
    $requiredExts = array('pdo', 'pdo_mysql', 'mbstring', 'curl', 'gd');
    $extResults = array();
    foreach ($requiredExts as $ext) {
        $extLoaded = extension_loaded($ext);
        $extResults[$ext] = array(
            'name' => $ext,
            'status' => $extLoaded ? 'pass' : 'fail',
            'message' => $extLoaded ? '已安装' : '未安装'
        );
        if (!$extLoaded) $passed = false;
    }
    $checks['extensions'] = $extResults;
    
    // Redis检测
    $redisOk = extension_loaded('redis');
    $redisConnected = false;
    
    if ($redisOk) {
        try {
            $redis = new Redis();
            $redisConnected = @$redis->connect('127.0.0.1', 6379);
            if ($redisConnected) $redis->close();
        } catch (Exception $e) {
            $redisConnected = false;
        }
    }
    
    $checks['redis'] = array(
        'name' => 'Redis',
        'status' => $redisOk ? ($redisConnected ? 'pass' : 'warning') : 'fail',
        'message' => $redisOk 
            ? ($redisConnected ? 'Redis已安装并可连接' : 'Redis已安装但连接失败（将使用文件缓存）') 
            : 'Redis未安装（将使用文件缓存）'
    );
    if (!$redisOk) $passed = false;
    
    // 目录权限检测
    $requiredDirs = array(
        'uploads',
        'cache',
        'logs',
        'assets/images/qrcode',
        'config'
    );
    
    $dirResults = array();
    foreach ($requiredDirs as $dir) {
        // 创建目录（如果不存在）
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        $writable = is_writable($dir);
        $dirResults[$dir] = array(
            'name' => $dir,
            'status' => $writable ? 'pass' : 'fail',
            'message' => $writable ? '目录可写' : '目录不可写，请检查权限'
        );
        if (!$writable) $passed = false;
    }
    $checks['directories'] = $dirResults;
    
    // 函数禁用检测
    $disabledFunctions = explode(',', ini_get('disable_functions'));
    $criticalFunctions = array('exec', 'shell_exec', 'passthru', 'system');
    $functionResults = array();
    $functionWarning = false;
    
    foreach ($criticalFunctions as $func) {
        $disabled = in_array($func, $disabledFunctions);
        $functionResults[$func] = array(
            'name' => $func,
            'status' => $disabled ? 'warning' : 'pass',
            'message' => $disabled ? '函数被禁用（部分功能可能受限）' : '函数可用'
        );
        if ($disabled) $functionWarning = true;
    }
    $checks['functions'] = $functionResults;
    
    return array(
        'passed' => $passed,
        'checks' => $checks,
        'functionWarning' => $functionWarning
    );
}

// 获取修复建议
function getFixSuggestions($checks) {
    $suggestions = array();
    
    // PHP版本修复建议
    if ($checks['php_version']['status'] == 'fail') {
        $suggestions[] = '请联系服务器管理员升级PHP版本至少到7.0.0';
    }
    
    // 扩展修复建议
    foreach ($checks['extensions'] as $ext => $status) {
        if ($status['status'] == 'fail') {
            $suggestions[] = '请安装PHP扩展: ' . $ext . ' (可使用命令: apt-get install php' . substr(phpversion(), 0, 3) . '-' . $ext . ')';
        }
    }
    
    // Redis修复建议
    if ($checks['redis']['status'] == 'fail') {
        $suggestions[] = '建议安装Redis扩展: apt-get install php' . substr(phpversion(), 0, 3) . '-redis';
    } elseif ($checks['redis']['status'] == 'warning') {
        $suggestions[] = 'Redis连接失败，请检查Redis服务是否启动，默认端口: 6379';
    }
    
    // 目录权限修复建议
    foreach ($checks['directories'] as $dir => $status) {
        if ($status['status'] == 'fail') {
            $suggestions[] = '请设置目录权限: chmod -R 755 ' . $dir;
        }
    }
    
    return $suggestions;
}

// 测试数据库连接
function testDatabaseConnection($dbConfig) {
    $result = array(
        'connected' => false,
        'error' => ''
    );
    
    try {
        $dsn = "mysql:host={$dbConfig['db_host']};port={$dbConfig['db_port']};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbConfig['db_user'], $dbConfig['db_pass'], array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 10
        ));
        
        // 检查数据库是否存在，如果不存在则创建
        $dbExists = $pdo->query("SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = '{$dbConfig['db_name']}'")->fetchColumn();
        
        if (!$dbExists) {
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbConfig['db_name']}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }
        
        // 选择数据库
        $pdo->exec("USE `{$dbConfig['db_name']}`");
        $result['connected'] = true;
        
    } catch (PDOException $e) {
        $errorCode = $e->getCode();
        switch ($errorCode) {
            case 1045:
                $result['error'] = '数据库用户名或密码错误';
                break;
            case 1049:
                $result['error'] = '数据库不存在且无法创建，请先创建数据库';
                break;
            case 2002:
                $result['error'] = '无法连接到数据库服务器，请检查主机和端口';
                break;
            default:
                $result['error'] = '数据库连接失败: ' . $e->getMessage();
        }
    }
    
    return $result;
}

// 验证管理员配置
function validateAdminConfig($config) {
    // 验证用户名
    if (empty($config['admin_username']) || strlen($config['admin_username']) < 3) {
        return false;
    }
    
    // 验证密码
    if (empty($config['admin_password']) || strlen($config['admin_password']) < 6) {
        return false;
    }
    
    // 验证两次密码是否一致
    if ($config['admin_password'] != $config['admin_password_confirm']) {
        return false;
    }
    
    return true;
}

// 执行安装
function performInstallation($dbConfig, $adminConfig, $mode) {
    try {
        // 1. 创建配置文件
        $configContent = generateConfigFile($dbConfig, $adminConfig, $mode);
        file_put_contents('config.php', $configContent);
        
        // 2. 导入数据库
        if (file_exists('database.sql')) {
            importDatabase($dbConfig);
        }
        
        // 3. 创建管理员账户
        createAdminAccount($dbConfig, $adminConfig);
        
        // 4. 创建必要的目录
        createRequiredDirectories();
        
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// 生成配置文件
function generateConfigFile($dbConfig, $adminConfig, $mode) {
    $configTemplate = <<<EOT
<?php
/**
 * 智能发卡系统配置文件
 * 由安装向导自动生成
 */

// 数据库配置
defined('DB_HOST') or define('DB_HOST', '{$dbConfig['db_host']}');
defined('DB_PORT') or define('DB_PORT', '{$dbConfig['db_port']}');
defined('DB_NAME') or define('DB_NAME', '{$dbConfig['db_name']}');
defined('DB_USER') or define('DB_USER', '{$dbConfig['db_user']}');
defined('DB_PASS') or define('DB_PASS', '{$dbConfig['db_pass']}');

// 系统配置
defined('SYSTEM_MODE') or define('SYSTEM_MODE', '{$mode}');
defined('SYSTEM_NAME') or define('SYSTEM_NAME', '智能发卡系统');
defined('SYSTEM_VERSION') or define('SYSTEM_VERSION', '1.0.0');

// 缓存配置
defined('CACHE_TYPE') or define('CACHE_TYPE', 'file'); // file, redis

// URL配置
defined('SITE_URL') or define('SITE_URL', '{$dbConfig['site_url']}');
defined('ADMIN_PATH') or define('ADMIN_PATH', 'admin');

// 安全配置
defined('ENCRYPT_KEY') or define('ENCRYPT_KEY', '{$adminConfig['encrypt_key']}');

// 默认时区
date_default_timezone_set('Asia/Shanghai');

// 错误报告
ini_set('display_errors', 'Off');
error_reporting(E_ALL);
EOT;
    
    return $configTemplate;
}

// 导入数据库
function importDatabase($dbConfig) {
    try {
        $dsn = "mysql:host={$dbConfig['db_host']};port={$dbConfig['db_port']};dbname={$dbConfig['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbConfig['db_user'], $dbConfig['db_pass']);
        
        // 读取SQL文件
        $sql = file_get_contents('database.sql');
        
        // 执行SQL
        $pdo->exec($sql);
        
    } catch (Exception $e) {
        // 忽略错误，因为数据库可能已经初始化
    }
}

// 创建管理员账户
function createAdminAccount($dbConfig, $adminConfig) {
    try {
        $dsn = "mysql:host={$dbConfig['db_host']};port={$dbConfig['db_port']};dbname={$dbConfig['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbConfig['db_user'], $dbConfig['db_pass']);
        
        // 加密密码
        $passwordHash = password_hash($adminConfig['admin_password'], PASSWORD_DEFAULT);
        
        // 插入管理员账户
        $stmt = $pdo->prepare("INSERT INTO admin_users (username, password, role, created_at) VALUES (:username, :password, 'superadmin', NOW())");
        $stmt->execute(array(
            ':username' => $adminConfig['admin_username'],
            ':password' => $passwordHash
        ));
        
    } catch (Exception $e) {
        // 忽略错误
    }
}

// 创建必要的目录
function createRequiredDirectories() {
    $dirs = array(
        'uploads/products',
        'uploads/qrcodes',
        'cache/templates',
        'logs',
        'backup'
    );
    
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: #2c3e50;
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .content {
            padding: 40px;
        }
        
        .steps {
            display: flex;
            margin-bottom: 40px;
            justify-content: center;
        }
        
        .step-item {
            flex: 1;
            text-align: center;
            position: relative;
            max-width: 120px;
        }
        
        .step-item:not(:last-child):after {
            content: '';
            position: absolute;
            top: 15px;
            right: -50%;
            width: 100%;
            height: 2px;
            background: #e0e0e0;
            z-index: 1;
        }
        
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #e0e0e0;
            color: #666;
            line-height: 30px;
            margin: 0 auto 10px;
            font-weight: bold;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }
        
        .step-item.active .step-number {
            background: #3498db;
            color: white;
            box-shadow: 0 0 0 4px rgba(52, 152, 219, 0.2);
        }
        
        .step-item.completed .step-number {
            background: #2ecc71;
            color: white;
        }
        
        .step-item.completed .step-number:after {
            content: '✓';
        }
        
        .step-text {
            font-size: 14px;
            color: #666;
        }
        
        .step-item.active .step-text,
        .step-item.completed .step-text {
            color: #333;
            font-weight: 500;
        }
        
        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #2c3e50;
            text-align: center;
        }
        
        .check-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
        }
        
        .check-item:hover {
            background-color: #f8f9fa;
        }
        
        .check-name {
            font-weight: 500;
        }
        
        .check-status {
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .check-status.pass {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .check-status.warning {
            background: #fff8e1;
            color: #ff8f00;
        }
        
        .check-status.fail {
            background: #ffebee;
            color: #c62828;
        }
        
        .check-message {
            margin-top: 5px;
            font-size: 13px;
            color: #666;
            flex: 1;
            text-align: right;
            padding-left: 20px;
        }
        
        .check-group {
            margin-bottom: 25px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .check-group h3 {
            font-size: 16px;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        
        .suggestions {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .suggestions h3 {
            color: #856404;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .suggestions ul {
            list-style: none;
            padding: 0;
        }
        
        .suggestions li {
            padding: 5px 0;
            padding-left: 20px;
            position: relative;
        }
        
        .suggestions li:before {
            content: '•';
            position: absolute;
            left: 0;
            color: #f39c12;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        
        .form-group .help-text {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
        
        .btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-block;
            text-decoration: none;
        }
        
        .btn:hover {
            background: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
        }
        
        .btn:disabled {
            background: #bdc3c7;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .btn-success {
            background: #2ecc71;
        }
        
        .btn-success:hover {
            background: #27ae60;
        }
        
        .buttons {
            text-align: center;
            margin-top: 40px;
        }
        
        .success-message {
            text-align: center;
            padding: 40px;
        }
        
        .success-icon {
            width: 80px;
            height: 80px;
            background: #2ecc71;
            border-radius: 50%;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: white;
        }
        
        .success-title {
            font-size: 24px;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .success-text {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 10px;
            }
            
            .content {
                padding: 20px;
            }
            
            .step-text {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>智能发卡系统</h1>
            <p>一键安装向导</p>
        </div>
        
        <div class="content">
            <!-- 步骤指示器 -->
            <div class="steps">
                <div class="step-item <?php echo $step == 1 ? 'active' : ($step > 1 ? 'completed' : ''); ?>">
                    <div class="step-number">1</div>
                    <div class="step-text">环境检测</div>
                </div>
                <div class="step-item <?php echo $step == 2 ? 'active' : ($step > 2 ? 'completed' : ''); ?>">
                    <div class="step-number">2</div>
                    <div class="step-text">数据库配置</div>
                </div>
                <div class="step-item <?php echo $step == 3 ? 'active' : ($step > 3 ? 'completed' : ''); ?>">
                    <div class="step-number">3</div>
                    <div class="step-text">管理员设置</div>
                </div>
                <div class="step-item <?php echo $step == 4 ? 'active' : ($step > 4 ? 'completed' : ''); ?>">
                    <div class="step-number">4</div>
                    <div class="step-text">模式选择</div>
                </div>
                <div class="step-item <?php echo $step == 5 ? 'active' : ''; ?>">
                    <div class="step-number">5</div>
                    <div class="step-text">完成</div>
                </div>
            </div>
            
            <!-- 步骤内容 -->
            <?php if ($step == 1): ?>
                <h2>环境检测</h2>
                <p style="text-align: center; color: #666; margin-bottom: 30px;">系统将自动检测服务器环境，确保满足安装要求</p>
                
                <?php if (!$submitted): ?>
                    <div class="buttons">
                        <form method="post">
                            <input type="hidden" name="submit" value="1">
                            <button type="submit" class="btn">开始检测环境</button>
                        </form>
                    </div>
                <?php else: ?>
                    <!-- 环境检测结果 -->
                    <?php 
                    $suggestions = getFixSuggestions($result['checks']);
                    if (!empty($suggestions)): 
                    ?>
                        <div class="suggestions">
                            <h3>需要修复的问题：</h3>
                            <ul>
                                <?php foreach ($suggestions as $suggestion): ?>
                                    <li><?php echo $suggestion; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <!-- PHP版本检测 -->
                    <div class="check-group">
                        <h3>服务器环境</h3>
                        <div class="check-item">
                            <div class="check-name">PHP版本</div>
                            <div class="check-status <?php echo $result['checks']['php_version']['status']; ?>">
                                <?php echo $result['checks']['php_version']['status'] == 'pass' ? '通过' : '失败'; ?>
                            </div>
                            <div class="check-message">
                                当前: <?php echo $result['checks']['php_version']['current']; ?> (需要: <?php echo $result['checks']['php_version']['required']; ?>)
                            </div>
                        </div>
                    </div>
                    
                    <!-- 扩展检测 -->
                    <div class="check-group">
                        <h3>PHP扩展</h3>
                        <?php foreach ($result['checks']['extensions'] as $ext => $status): ?>
                            <div class="check-item">
                                <div class="check-name">php-<?php echo $ext; ?></div>
                                <div class="check-status <?php echo $status['status']; ?>">
                                    <?php echo $status['status'] == 'pass' ? '已安装' : '未安装'; ?>
                                </div>
                                <div class="check-message"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Redis检测 -->
                    <div class="check-group">
                        <h3>缓存服务</h3>
                        <div class="check-item">
                            <div class="check-name">Redis</div>
                            <div class="check-status <?php echo $result['checks']['redis']['status']; ?>">
                                <?php 
                                switch ($result['checks']['redis']['status']) {
                                    case 'pass': echo '可用'; break;
                                    case 'warning': echo '警告'; break;
                                    case 'fail': echo '不可用'; break;
                                }
                                ?>
                            </div>
                            <div class="check-message"><?php echo $result['checks']['redis']['message']; ?></div>
                        </div>
                    </div>
                    
                    <!-- 目录权限检测 -->
                    <div class="check-group">
                        <h3>目录权限</h3>
                        <?php foreach ($result['checks']['directories'] as $dir => $status): ?>
                            <div class="check-item">
                                <div class="check-name"><?php echo $dir; ?></div>
                                <div class="check-status <?php echo $status['status']; ?>">
                                    <?php echo $status['status'] == 'pass' ? '可写' : '不可写'; ?>
                                </div>
                                <div class="check-message"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="buttons">
                        <?php if ($result['passed']): ?>
                            <a href="install_wizard.php?step=2" class="btn btn-success">环境检测通过，进入下一步</a>
                        <?php else: ?>
                            <button type="button" onclick="location.reload();" class="btn">重新检测</button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php if ($step == 2): ?>
                <h2>数据库配置</h2>
                <p style="text-align: center; color: #666; margin-bottom: 30px;">请填写数据库连接信息，系统将自动测试连接并创建数据库</p>
                
                <?php if (isset($dbTestResult) && !$dbTestResult['connected']): ?>
                    <div class="suggestions">
                        <h3>连接失败：</h3>
                        <ul>
                            <li><?php echo $dbTestResult['error']; ?></li>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="post">
                    <input type="hidden" name="submit" value="1">
                    
                    <div class="form-group">
                        <label for="db_host">数据库主机</label>
                        <input type="text" id="db_host" name="db_host" value="<?php echo isset($_POST['db_host']) ? $_POST['db_host'] : 'localhost'; ?>" required>
                        <div class="help-text">通常为 localhost 或 127.0.0.1</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_port">数据库端口</label>
                        <input type="text" id="db_port" name="db_port" value="<?php echo isset($_POST['db_port']) ? $_POST['db_port'] : '3306'; ?>" required>
                        <div class="help-text">MySQL 默认端口为 3306</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_name">数据库名称</label>
                        <input type="text" id="db_name" name="db_name" value="<?php echo isset($_POST['db_name']) ? $_POST['db_name'] : 'smart_card'; ?>" required>
                        <div class="help-text">系统将使用或创建此数据库</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_user">数据库用户名</label>
                        <input type="text" id="db_user" name="db_user" value="<?php echo isset($_POST['db_user']) ? $_POST['db_user'] : 'root'; ?>" required>
                        <div class="help-text">需要有创建/修改数据库的权限</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_pass">数据库密码</label>
                        <input type="password" id="db_pass" name="db_pass" value="<?php echo isset($_POST['db_pass']) ? $_POST['db_pass'] : ''; ?>">
                        <div class="help-text">数据库用户的密码</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="site_url">网站URL</label>
                        <input type="text" id="site_url" name="site_url" value="<?php echo isset($_POST['site_url']) ? $_POST['site_url'] : 'http://' . $_SERVER['HTTP_HOST'] . '/'; ?>" required>
                        <div class="help-text">系统访问地址，必须以 / 结尾</div>
                    </div>
                    
                    <div class="buttons">
                        <a href="install_wizard.php?step=1" class="btn" style="background: #7f8c8d; margin-right: 10px;">上一步</a>
                        <button type="submit" class="btn btn-success">测试连接并下一步</button>
                    </div>
                </form>
            <?php elseif ($step == 3): ?>
                <h2>管理员设置</h2>
                <p style="text-align: center; color: #666; margin-bottom: 30px;">请设置系统管理员账户信息</p>
                
                <form method="post">
                    <input type="hidden" name="submit" value="1">
                    
                    <div class="form-group">
                        <label for="admin_username">管理员用户名</label>
                        <input type="text" id="admin_username" name="admin_username" value="<?php echo isset($_POST['admin_username']) ? $_POST['admin_username'] : ''; ?>" required>
                        <div class="help-text">长度至少3个字符</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_password">管理员密码</label>
                        <input type="password" id="admin_password" name="admin_password" required>
                        <div class="help-text">长度至少6个字符，建议使用复杂密码</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_password_confirm">确认密码</label>
                        <input type="password" id="admin_password_confirm" name="admin_password_confirm" required>
                        <div class="help-text">请再次输入管理员密码</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="encrypt_key">加密密钥</label>
                        <input type="text" id="encrypt_key" name="encrypt_key" value="<?php echo isset($_POST['encrypt_key']) ? $_POST['encrypt_key'] : bin2hex(random_bytes(16)); ?>" required>
                        <div class="help-text">用于数据加密的密钥，请妥善保存</div>
                    </div>
                    
                    <div class="buttons">
                        <a href="install_wizard.php?step=2" class="btn" style="background: #7f8c8d; margin-right: 10px;">上一步</a>
                        <button type="submit" class="btn btn-success">完成设置并下一步</button>
                    </div>
                </form>
            <?php elseif ($step == 4): ?>
                <h2>模式选择</h2>
                <p style="text-align: center; color: #666; margin-bottom: 30px;">请选择系统运行模式</p>
                
                <form method="post">
                    <input type="hidden" name="submit" value="1">
                    
                    <div class="form-group" style="padding: 20px; border-radius: 8px; background: #f8f9fa;">
                        <label style="display: block; margin-bottom: 20px; font-size: 18px;">选择运行模式：</label>
                        
                        <label style="display: block; padding: 15px; border: 2px solid #e0e0e0; border-radius: 8px; margin-bottom: 15px; cursor: pointer;">
                            <input type="radio" name="mode" value="light" checked style="margin-right: 10px;">
                            <span style="font-weight: 600;">轻量模式</span>
                            <p style="margin: 10px 0 0 25px; color: #666;">适合小型站点，功能精简，资源占用少</p>
                        </label>
                        
                        <label style="display: block; padding: 15px; border: 2px solid #e0e0e0; border-radius: 8px; cursor: pointer;">
                            <input type="radio" name="mode" value="advanced" style="margin-right: 10px;">
                            <span style="font-weight: 600;">高级模式</span>
                            <p style="margin: 10px 0 0 25px; color: #666;">完整功能，包含所有高级特性和报表统计</p>
                        </label>
                    </div>
                    
                    <div class="buttons">
                        <a href="install_wizard.php?step=3" class="btn" style="background: #7f8c8d; margin-right: 10px;">上一步</a>
                        <button type="submit" class="btn btn-success">开始安装</button>
                    </div>
                </form>
            <?php elseif ($step == 5): ?>
                <div class="success-message">
                    <div class="success-icon">✓</div>
                    <div class="success-title">安装成功！</div>
                    <div class="success-text">
                        系统已成功安装完成！您现在可以访问系统并开始使用了。
                        <br><br>
                        <strong>管理员登录信息：</strong><br>
                        用户名：<?php session_start(); echo isset($_SESSION['admin_config']['admin_username']) ? $_SESSION['admin_config']['admin_username'] : ''; ?><br>
                        密码：您设置的密码
                        <br><br>
                        <strong>初始设置提示：</strong><br>
                        登录后，请先完成支付配置和导入卡密，以便开始使用系统功能。
                    </div>
                    <div class="buttons">
                        <a href="admin/index.php" class="btn btn-success" style="margin-right: 10px;">进入管理后台</a>
                        <a href="user_guide.html" class="btn" style="background: #667eea; margin-right: 10px;">查看使用教程</a>
                        <a href="index.php" class="btn">访问前台首页</a>
                    </div>
                    
                    <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                        <h3 style="font-size: 18px; margin-bottom: 15px; color: #2c3e50;">新手提示</h3>
                        <ul style="list-style: none; padding-left: 0;">
                            <li style="padding: 8px 0; padding-left: 20px; position: relative;">
                                <span style="position: absolute; left: 0; color: #667eea;">✓</span>
                                首次登录管理后台会显示新手引导气泡
                            </li>
                            <li style="padding: 8px 0; padding-left: 20px; position: relative;">
                                <span style="position: absolute; left: 0; color: #667eea;">✓</span>
                                完成支付配置后，建议进行1分钱测试支付
                            </li>
                            <li style="padding: 8px 0; padding-left: 20px; position: relative;">
                                <span style="position: absolute; left: 0; color: #667eea;">✓</span>
                                使用教程包含详细的系统功能使用说明
                            </li>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>