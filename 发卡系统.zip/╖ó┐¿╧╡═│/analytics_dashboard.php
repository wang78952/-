<?php
/**
 * 数据分析仪表盘
 * 集成推广效果统计图表、用户购卡偏好分析等数据可视化功能
 */

require_once 'includes/config.php';
require_once 'includes/AuthManager.php';

// 权限检查
$authManager = new AuthManager();
if (!$authManager->hasPermission('view_analytics')) {
    header('Location: login.php?redirect=' . urlencode($_SERVER['PHP_SELF']));
    exit;
}

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();

// 页面标题
$page_title = '数据分析仪表盘';

// 引入头部
include 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - 发卡系统</title>
    <!-- 引入Chart.js用于数据可视化 -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- 引入日期选择器 -->
    <link href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/moment/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <style>
        /* 仪表盘样式 */
        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        .dashboard-filters {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        .date-range-picker {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }
        .stat-title {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .stat-value {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 5px;
            color: #333;
        }
        .stat-change {
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 3px;
        }
        .stat-change.positive {
            background-color: #e8f5e9;
            color: #4caf50;
        }
        .stat-change.negative {
            background-color: #ffebee;
            color: #f44336;
        }
        .chart-section {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .chart-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        .chart-wrapper {
            position: relative;
            height: 300px;
        }
        .chart-wrapper.small {
            height: 250px;
        }
        .chart-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .top-agents-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .top-agents-table th,
        .top-agents-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .top-agents-table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .conversion-rate {
            font-weight: 600;
            color: #2196f3;
        }
        .loading-spinner {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 200px;
            font-size: 16px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="dashboard-header">
            <h1><?php echo $page_title; ?></h1>
            <div class="dashboard-filters">
                <select id="agentFilter">
                    <option value="0">所有代理</option>
                    <!-- 代理选项将通过JavaScript动态加载 -->
                </select>
                <select id="levelFilter">
                    <option value="0">所有等级</option>
                    <option value="1">一级代理</option>
                    <option value="2">二级代理</option>
                    <option value="3">三级代理</option>
                </select>
                <input type="text" id="dateRange" class="date-range-picker" value="最近7天">
                <button id="applyFilters" class="btn btn-primary">应用筛选</button>
                <button id="exportData" class="btn btn-default">导出数据</button>
            </div>
        </div>

        <!-- 数据概览卡片 -->
        <div class="dashboard-cards">
            <div class="stat-card">
                <div class="stat-title">总点击量</div>
                <div class="stat-value" id="totalClicks">0</div>
                <div class="stat-change" id="clicksChange"></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">总订单量</div>
                <div class="stat-value" id="totalOrders">0</div>
                <div class="stat-change" id="ordersChange"></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">总销售额</div>
                <div class="stat-value" id="totalRevenue">¥0.00</div>
                <div class="stat-change" id="revenueChange"></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">平均转化率</div>
                <div class="stat-value" id="averageConversionRate">0%</div>
                <div class="stat-change" id="conversionChange"></div>
            </div>
        </div>

        <!-- 图表区域 -->
        <div class="chart-grid">
            <div class="chart-section">
                <div class="chart-header">
                    <div class="chart-title">转化率趋势</div>
                </div>
                <div id="conversionTrendLoader" class="loading-spinner">加载中...</div>
                <div class="chart-wrapper" style="display: none;">
                    <canvas id="conversionTrendChart"></canvas>
                </div>
            </div>
            <div class="chart-section">
                <div class="chart-header">
                    <div class="chart-title">用户购卡偏好（按产品）</div>
                </div>
                <div id="productPreferencesLoader" class="loading-spinner">加载中...</div>
                <div class="chart-wrapper" style="display: none;">
                    <canvas id="productPreferencesChart"></canvas>
                </div>
            </div>
        </div>

        <div class="chart-grid">
            <div class="chart-section">
                <div class="chart-header">
                    <div class="chart-title">用户购卡偏好（按价格区间）</div>
                </div>
                <div id="priceRangeLoader" class="loading-spinner">加载中...</div>
                <div class="chart-wrapper" style="display: none;">
                    <canvas id="priceRangeChart"></canvas>
                </div>
            </div>
            <div class="chart-section">
                <div class="chart-header">
                    <div class="chart-title">用户购卡偏好（按分类）</div>
                </div>
                <div id="categoryLoader" class="loading-spinner">加载中...</div>
                <div class="chart-wrapper" style="display: none;">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
        </div>

        <!-- 代理排名表格 -->
        <div class="chart-section">
            <div class="chart-header">
                <div class="chart-title">代理推广效果排名</div>
                <select id="sortBy">
                    <option value="conversion_rate">按转化率排序</option>
                    <option value="total_clicks">按点击量排序</option>
                    <option value="orders">按订单量排序</option>
                    <option value="order_amount">按销售额排序</option>
                </select>
            </div>
            <div id="agentsRankingLoader" class="loading-spinner">加载中...</div>
            <table id="agentsRanking" class="top-agents-table" style="display: none;">
                <thead>
                    <tr>
                        <th>排名</th>
                        <th>代理名称</th>
                        <th>等级</th>
                        <th>点击量</th>
                        <th>订单量</th>
                        <th>销售额</th>
                        <th>转化率</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- 代理排名数据将通过JavaScript动态加载 -->
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // 全局变量存储当前筛选条件
        let currentFilters = {
            agent_id: 0,
            level: 0,
            date_range: '7days',
            start_date: '',
            end_date: '',
            sort_by: 'conversion_rate'
        };

        // 初始化日期选择器
        $(document).ready(function() {
            // 设置默认日期范围为最近7天
            const today = moment();
            const lastWeek = moment().subtract(7, 'days');
            
            // 初始化日期范围选择器
            $('#dateRange').daterangepicker({
                startDate: lastWeek,
                endDate: today,
                ranges: {
                    '今天': [moment(), moment()],
                    '昨天': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    '最近7天': [moment().subtract(6, 'days'), moment()],
                    '最近30天': [moment().subtract(29, 'days'), moment()],
                    '本月': [moment().startOf('month'), moment().endOf('month')],
                    '上月': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                locale: {
                    applyLabel: '确定',
                    cancelLabel: '取消',
                    customRangeLabel: '自定义范围',
                    daysOfWeek: ['日', '一', '二', '三', '四', '五', '六'],
                    monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
                    firstDay: 1
                }
            }, function(start, end, label) {
                $('#dateRange').val(label);
                
                // 更新筛选条件
                if (label === '自定义范围') {
                    currentFilters.date_range = 'custom';
                    currentFilters.start_date = start.format('YYYY-MM-DD');
                    currentFilters.end_date = end.format('YYYY-MM-DD');
                } else {
                    currentFilters.date_range = label.replace('最近', '').replace('天', 'days').replace('个月', 'months');
                    currentFilters.date_range = currentFilters.date_range === '今天' ? 'today' : 
                                               currentFilters.date_range === '昨天' ? 'yesterday' : 
                                               currentFilters.date_range === '本月' ? 'thismonth' : 
                                               currentFilters.date_range === '上月' ? 'lastmonth' : currentFilters.date_range;
                    currentFilters.start_date = '';
                    currentFilters.end_date = '';
                }
            });

            // 加载初始数据
            loadDashboardData();
            loadAgentOptions();

            // 绑定事件监听器
            $('#applyFilters').on('click', function() {
                currentFilters.agent_id = $('#agentFilter').val();
                currentFilters.level = $('#levelFilter').val();
                loadDashboardData();
            });

            $('#sortBy').on('change', function() {
                currentFilters.sort_by = $(this).val();
                loadAgentsRanking();
            });

            $('#exportData').on('click', exportDashboardData);
        });

        // 加载仪表盘数据
        function loadDashboardData() {
            // 显示加载状态
            showLoadingState(true);
            
            // 获取仪表盘汇总数据
            $.ajax({
                url: 'api/analytics/agent_analytics.php?action=dashboard_summary',
                type: 'GET',
                data: currentFilters,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        updateDashboardStats(response.data.summary);
                        updateConversionTrendChart(response.data.conversion_trend);
                        updateAgentsRanking(response.data.top_agents);
                    } else {
                        console.error('加载仪表盘数据失败:', response.message);
                        showError('加载数据失败，请稍后重试');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX错误:', error);
                    showError('网络错误，请检查连接');
                },
                complete: function() {
                    showLoadingState(false);
                    // 加载用户购卡偏好数据
                    loadUserPreferences();
                }
            });
        }

        // 加载用户购卡偏好数据
        function loadUserPreferences() {
            // 产品偏好
            $.ajax({
                url: 'api/analytics/user_purchase_analytics.php?action=product_preferences',
                type: 'GET',
                data: {
                    start_date: currentFilters.start_date,
                    end_date: currentFilters.end_date
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        updateProductPreferencesChart(response.data);
                    }
                }
            });

            // 价格区间偏好
            $.ajax({
                url: 'api/analytics/user_purchase_analytics.php?action=price_preferences',
                type: 'GET',
                data: {
                    start_date: currentFilters.start_date,
                    end_date: currentFilters.end_date
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        updatePriceRangeChart(response.data);
                    }
                }
            });

            // 分类偏好
            $.ajax({
                url: 'api/analytics/user_purchase_analytics.php?action=category_preferences',
                type: 'GET',
                data: {
                    start_date: currentFilters.start_date,
                    end_date: currentFilters.end_date
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        updateCategoryChart(response.data);
                    }
                }
            });
        }

        // 更新仪表盘统计数据
        function updateDashboardStats(stats) {
            $('#totalClicks').text(formatNumber(stats.total_clicks));
            $('#totalOrders').text(formatNumber(stats.total_orders));
            $('#totalRevenue').text('¥' + formatCurrency(stats.total_revenue));
            $('#averageConversionRate').text(stats.average_conversion_rate + '%');
            
            // 计算变化率（模拟数据，实际应从API获取）
            updateChangeIndicator('clicksChange', 5.2, true);
            updateChangeIndicator('ordersChange', 8.7, true);
            updateChangeIndicator('revenueChange', 12.3, true);
            updateChangeIndicator('conversionChange', 2.1, true);
        }

        // 更新变化指标
        function updateChangeIndicator(elementId, value, isPositive) {
            const indicator = $('#' + elementId);
            indicator.text((isPositive ? '↑' : '↓') + Math.abs(value) + '%');
            indicator.removeClass('positive negative');
            indicator.addClass(isPositive ? 'positive' : 'negative');
        }

        // 更新转化率趋势图表
        function updateConversionTrendChart(data) {
            const ctx = document.getElementById('conversionTrendChart').getContext('2d');
            
            // 提取数据
            const labels = data.map(item => item.date);
            const clicksData = data.map(item => item.total_clicks);
            const ordersData = data.map(item => item.orders);
            const conversionRates = data.map(item => item.conversion_rate);
            
            // 创建图表
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: '转化率 (%)',
                            data: conversionRates,
                            borderColor: '#2196f3',
                            backgroundColor: 'rgba(33, 150, 243, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y'
                        },
                        {
                            label: '点击量',
                            data: clicksData,
                            borderColor: '#4caf50',
                            backgroundColor: 'rgba(76, 175, 80, 0.1)',
                            borderWidth: 2,
                            fill: false,
                            tension: 0.4,
                            yAxisID: 'y1',
                            hidden: true
                        },
                        {
                            label: '订单量',
                            data: ordersData,
                            borderColor: '#ff9800',
                            backgroundColor: 'rgba(255, 152, 0, 0.1)',
                            borderWidth: 2,
                            fill: false,
                            tension: 0.4,
                            yAxisID: 'y1'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: '转化率 (%)'
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: false,
                            position: 'right',
                            grid: {
                                drawOnChartArea: false
                            },
                            title: {
                                display: true,
                                text: '数量'
                            }
                        }
                    }
                }
            });
            
            // 显示图表，隐藏加载状态
            $('#conversionTrendLoader').hide();
            $('#conversionTrendChart').parent().show();
        }

        // 更新产品偏好图表
        function updateProductPreferencesChart(data) {
            const ctx = document.getElementById('productPreferencesChart').getContext('2d');
            
            // 提取前10个产品数据
            const topProducts = data.slice(0, 10);
            const labels = topProducts.map(item => item.product_name);
            const purchaseCounts = topProducts.map(item => item.purchase_count);
            
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: '购买次数',
                        data: purchaseCounts,
                        backgroundColor: 'rgba(153, 102, 255, 0.6)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: '购买次数'
                            }
                        },
                        x: {
                            ticks: {
                                maxRotation: 45,
                                minRotation: 45
                            }
                        }
                    }
                }
            });
            
            $('#productPreferencesLoader').hide();
            $('#productPreferencesChart').parent().show();
        }

        // 更新价格区间图表
        function updatePriceRangeChart(data) {
            const ctx = document.getElementById('priceRangeChart').getContext('2d');
            
            const labels = data.map(item => item.price_range);
            const percentages = data.map(item => item.percentage);
            
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: labels,
                    datasets: [{
                        data: percentages,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)',
                            'rgba(255, 159, 64, 0.6)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
            
            $('#priceRangeLoader').hide();
            $('#priceRangeChart').parent().show();
        }

        // 更新分类偏好图表
        function updateCategoryChart(data) {
            const ctx = document.getElementById('categoryChart').getContext('2d');
            
            const labels = data.map(item => item.category_name);
            const amounts = data.map(item => item.total_amount);
            
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: amounts,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)',
                            'rgba(255, 159, 64, 0.6)',
                            'rgba(99, 255, 132, 0.6)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)',
                            'rgba(99, 255, 132, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
            
            $('#categoryLoader').hide();
            $('#categoryChart').parent().show();
        }

        // 加载代理选项
        function loadAgentOptions() {
            $.ajax({
                url: 'api/analytics/agent_analytics.php?action=conversion_stats',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        const agentSelect = $('#agentFilter');
                        response.data.forEach(agent => {
                            agentSelect.append(new Option(agent.agent_name, agent.agent_id));
                        });
                    }
                }
            });
        }

        // 加载代理排名数据
        function loadAgentsRanking() {
            $.ajax({
                url: 'api/analytics/agent_analytics.php?action=agent_ranking',
                type: 'GET',
                data: currentFilters,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        updateAgentsRanking(response.data);
                    }
                }
            });
        }

        // 更新代理排名表格
        function updateAgentsRanking(data) {
            const tbody = $('#agentsRanking tbody');
            tbody.empty();
            
            data.forEach((agent, index) => {
                const row = $('<tr></tr>');
                row.append($('<td></td>').text(index + 1));
                row.append($('<td></td>').text(agent.agent_name));
                row.append($('<td></td>').text('代理' + agent.level));
                row.append($('<td></td>').text(formatNumber(agent.total_clicks)));
                row.append($('<td></td>').text(formatNumber(agent.orders)));
                row.append($('<td></td>').text('¥' + formatCurrency(agent.order_amount)));
                row.append($('<td class="conversion-rate"></td>').text(agent.conversion_rate + '%'));
                tbody.append(row);
            });
            
            $('#agentsRankingLoader').hide();
            $('#agentsRanking').show();
        }

        // 导出仪表盘数据
        function exportDashboardData() {
            // 创建导出URL
            const exportUrl = 'api/analytics/export_dashboard.php?' + $.param(currentFilters);
            
            // 下载文件
            window.location.href = exportUrl;
        }

        // 工具函数：格式化数字
        function formatNumber(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        }

        // 工具函数：格式化货币
        function formatCurrency(num) {
            return parseFloat(num).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        }

        // 显示/隐藏加载状态
        function showLoadingState(show) {
            if (show) {
                $('.stat-value').text('加载中...');
                $('.stat-change').empty();
            }
        }

        // 显示错误消息
        function showError(message) {
            alert('错误: ' + message);
        }
    </script>
</body>
</html>
<?php
// 引入页脚
include 'includes/footer.php';
?>