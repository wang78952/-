<?php
require_once __DIR__ . '/includes/SecurityUtils.php';
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/AuthManager.php';
require_once __DIR__ . '/includes/EnhancedValidator.php';
require_once __DIR__ . '/includes/InjectionProtection.php';
require_once __DIR__ . '/config.php';

// 初始化认证管理器
$authManager = new AuthManager();

// 如果用户已登录，重定向到仪表板
if ($authManager->isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

// 处理登录请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 初始化验证器
    $validator = EnhancedValidator::getInstance();
    $protection = InjectionProtection::getInstance();
    
    // 获取并清理用户输入
    $username = $protection->cleanInput($_POST['username'] ?? '');
    $password = $protection->cleanInput($_POST['password'] ?? '');
    $remember = isset($_POST['remember']) && $_POST['remember'] === '1';
    $csrfToken = $_POST['csrf_token'] ?? '';
    
    // CSRF 验证
    if (!SecurityUtils::validateCSRFToken($csrfToken)) {
        $error = '请求验证失败，请重新提交';
        SecurityUtils::logSecurity('WARNING', 'CSRF验证失败', ['ip' => $_SERVER['REMOTE_ADDR']]);
    } elseif (!$validator->validateString($username, ['min_length' => 3, 'max_length' => 50, 'pattern' => '/^[a-zA-Z0-9_\-]+$/'])) {
        $error = '用户名格式不正确，只允许字母、数字、下划线和连字符';
    } elseif (!$validator->validateString($password, ['min_length' => 6])) {
        $error = '密码长度不能少于6个字符';
    } else {
        try {
            // 尝试登录
            $result = $authManager->login($username, $password, $remember);
            
            if ($result['success']) {
                // 登录成功，重定向到仪表板
                header('Location: dashboard.php');
                exit;
            } else {
                $error = $result['message'];
            }
        } catch (Exception $e) {
            $error = '登录失败：' . $e->getMessage();
            
            // 记录安全日志
            SecurityUtils::logSecurity('ERROR', '登录异常', array(
                'username' => $username,
                'error' => $e->getMessage()
            ));
        }
    }
}

// 处理密码重置请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_password') {
    // 使用验证器
    $validator = EnhancedValidator::getInstance();
    $protection = InjectionProtection::getInstance();
    
    // 获取并清理邮箱输入
    $email = $protection->cleanInput($_POST['email'] ?? '');
    
    if (empty($email)) {
        $error = '请输入邮箱地址';
    } elseif (!$validator->validateEmail($email)) {
        $error = '请输入有效的邮箱地址';
    } else {
        try {
            // 检查邮箱是否存在
            $db = Database::getInstance();
            $user = $db->queryOne("SELECT id, username FROM users WHERE email = :email", array('email' => $email));
            
            if ($user) {
                // 生成密码重置令牌
                $resetToken = generateRandomString(64);
                $expiryTime = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                // 更新用户记录
                $db->update('users', 
                    $user['id'], 
                    array(
                        'reset_token' => $resetToken,
                        'reset_token_expiry' => $expiryTime
                    )
                );
                
                // 记录安全日志
                SecurityUtils::logSecurity('INFO', '密码重置请求', array(
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $email
                ));
                
                $success = '密码重置链接已发送到您的邮箱，请查收';
            } else {
                $success = '如果该邮箱存在，密码重置链接已发送';
            }
        } catch (Exception $e) {
            $error = '密码重置失败：' . $e->getMessage();
        }
    }
}

// 生成 CSRF 令牌
$csrfToken = SecurityUtils::generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 商业级发卡系统</title>
    <link rel="stylesheet" href="assets/css/ui-components.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 16px;
            padding: 3rem;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            width: 100%;
            max-width: 450px;
            position: relative;
            overflow: hidden;
            animation: slideInUp 0.6s ease;
        }
        
        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-header h1 {
            font-size: 2rem;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        
        .login-header p {
            color: #718096;
            font-size: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            color: #4a5568;
            font-weight: 500;
        }
        
        .form-input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-checkbox {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .form-checkbox input {
            margin-right: 0.5rem;
        }
        
        .form-checkbox label {
            color: #4a5568;
            font-size: 0.9rem;
        }
        
        .form-button {
            width: 100%;
            padding: 0.875rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .form-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .form-button:active {
            transform: translateY(0);
        }
        
        .form-button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .form-button.loading {
            color: transparent;
        }
        
        .form-button.loading::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            top: 50%;
            left: 50%;
            margin-left: -10px;
            margin-top: -10px;
            border: 2px solid #ffffff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spinner 0.6s linear infinite;
        }
        
        @keyframes spinner {
            to { transform: rotate(360deg); }
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        
        .alert-danger {
            background: #fed7d7;
            color: #742a2a;
            border: 1px solid #fc8181;
        }
        
        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        
        .form-links {
            text-align: center;
            margin-top: 1.5rem;
        }
        
        .form-links a {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
            margin: 0 0.5rem;
            transition: color 0.3s ease;
        }
        
        .form-links a:hover {
            color: #764ba2;
            text-decoration: underline;
        }
        
        .password-strength {
            margin-top: 0.5rem;
            height: 4px;
            border-radius: 2px;
            background: #e2e8f0;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }
        
        .password-strength-bar.weak {
            width: 33%;
            background: #f56565;
        }
        
        .password-strength-bar.medium {
            width: 66%;
            background: #ed8936;
        }
        
        .password-strength-bar.strong {
            width: 100%;
            background: #48bb78;
        }
        
        .password-strength-text {
            font-size: 0.8rem;
            margin-top: 0.25rem;
            color: #718096;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            width: 90%;
            max-width: 400px;
            position: relative;
        }
        
        .modal-close {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #718096;
        }
        
        .modal-close:hover {
            color: #2d3748;
        }
        
        .security-info {
            background: #f7fafc;
            border-radius: 8px;
            padding: 1rem;
            margin-top: 1rem;
            font-size: 0.85rem;
            color: #4a5568;
        }
        
        .security-info h4 {
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        
        .security-info ul {
            margin-left: 1.5rem;
            margin-top: 0.5rem;
        }
        
        @media (max-width: 480px) {
            .login-container {
                padding: 2rem 1.5rem;
            }
            
            .login-header h1 {
                font-size: 1.75rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🔐 商业级发卡系统</h1>
            <p>请登录以继续</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            
            <div class="form-group">
                <label for="username" class="form-label">用户名</label>
                <input 
                    type="text" 
                    id="username" 
                    name="username" 
                    class="form-input" 
                    placeholder="请输入用户名"
                    required
                    autocomplete="username"
                    value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                >
            </div>

            <div class="form-group">
                <label for="password" class="form-label">密码</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    class="form-input" 
                    placeholder="请输入密码"
                    required
                    autocomplete="current-password"
                >
            </div>

            <div class="form-checkbox">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">记住我（7天内保持登录）</label>
            </div>

            <button type="submit" class="form-button" id="loginButton">
                登录
            </button>
        </form>

        <div class="form-links">
            <a href="#" onclick="showResetModal()">忘记密码？</a>
            <a href="#" onclick="showSecurityInfo()">安全信息</a>
        </div>
    </div>

    <!-- 密码重置模态框 -->
    <div class="modal" id="resetModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeResetModal()">&times;</button>
            <h3>重置密码</h3>
            <p style="color: #718096; margin-bottom: 1rem;">请输入您的邮箱地址，我们将发送密码重置链接</p>
            
            <form method="POST" id="resetForm">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-group">
                    <label for="email" class="form-label">邮箱地址</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        class="form-input" 
                        placeholder="请输入邮箱地址"
                        required
                    >
                </div>

                <button type="submit" class="form-button" id="resetButton">
                    发送重置链接
                </button>
            </form>
        </div>
    </div>

    <!-- 安全信息模态框 -->
    <div class="modal" id="securityModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeSecurityModal()">&times;</button>
            <h3>🛡️ 安全信息</h3>
            
            <div class="security-info">
                <h4>系统安全特性：</h4>
                <ul>
                    <li>密码强度验证和加密存储</li>
                    <li>登录失败自动锁定机制</li>
                    <li>会话超时自动登出</li>
                    <li>CSRF 攻击防护</li>
                    <li>操作日志全程记录</li>
                    <li>敏感数据 AES 加密</li>
                </ul>
                
                <h4 style="margin-top: 1rem;">安全建议：</h4>
                <ul>
                    <li>使用强密码（8位以上，包含大小写字母、数字和特殊字符）</li>
                    <li>定期更换密码</li>
                    <li>不要在公共设备上保存登录信息</li>
                    <li>发现异常登录请及时联系管理员</li>
                </ul>
            </div>
        </div>
    </div>

    <script src="assets/js/ui-components.js"></script>
    <script src="assets/js/data-loader.js"></script>
    <script src="assets/js/data-loader-init.js"></script>
    <script>
        // 页面加载完成后初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 添加表单验证属性
            const usernameInput = document.getElementById('username');
            const passwordInput = document.getElementById('password');
            const emailInput = document.getElementById('email');
            
            // 设置验证规则
            usernameInput.setAttribute('data-rules', 'required|min:3|max:20');
            passwordInput.setAttribute('data-rules', 'required|min:6');
            emailInput.setAttribute('data-rules', 'required|email');
            
            // 添加工具提示
            usernameInput.setAttribute('data-tooltip', '用户名长度3-20个字符');
            passwordInput.setAttribute('data-tooltip', '密码至少6个字符');
            emailInput.setAttribute('data-tooltip', '请输入有效的邮箱地址');
            
            // 表单提交处理
            const loginForm = document.getElementById('loginForm');
            loginForm.addEventListener('submit', function(e) {
                if (!window.ui.validateForm(loginForm)) {
                    e.preventDefault();
                    window.ui.showNotification('请检查表单输入', 'error');
                    return;
                }
            });

            // 密码重置表单处理
            const resetForm = document.getElementById('resetForm');
            if (resetForm) {
                resetForm.addEventListener('submit', function(e) {
                    if (!window.ui.validateForm(resetForm)) {
                        e.preventDefault();
                        window.ui.showNotification('请输入有效的邮箱地址', 'error');
                        return;
                    }
                });
            }
        });

        // 模态框控制（使用新的UI组件）
        function showResetModal() {
            window.ui.showModal('resetModal');
        }

        function closeResetModal() {
            window.ui.hideModal(document.getElementById('resetModal'));
        }

        function showSecurityInfo() {
            window.ui.showModal('securityModal');
        }

        function closeSecurityModal() {
            window.ui.hideModal(document.getElementById('securityModal'));
        }

        // 显示PHP错误信息（如果有的话）
        <?php if ($error): ?>
            window.ui.showNotification(<?php echo json_encode($error); ?>, 'error');
        <?php endif; ?>

        <?php if ($success): ?>
            window.ui.showNotification(<?php echo json_encode($success); ?>, 'success');
        <?php endif; ?>
    </script>
            document.getElementById('resetModal').classList.remove('active');
        }

        function showSecurityInfo() {
            document.getElementById('securityModal').classList.add('active');
        }

        function closeSecurityModal() {
            document.getElementById('securityModal').classList.remove('active');
        }

        // 点击模态框背景关闭
        document.getElementById('resetModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeResetModal();
            }
        });

        document.getElementById('securityModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeSecurityModal();
            }
        });

        // ESC 键关闭模态框
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeResetModal();
                closeSecurityModal();
            }
        });

        // 自动聚焦到用户名输入框
        window.addEventListener('load', function() {
            document.getElementById('username').focus();
        });

        // Enter 键提交表单
        document.getElementById('password').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                document.getElementById('loginForm').submit();
            }
        });
    </script>
</body>
</html>