<?php
require_once 'includes/SecurityUtils.php';
require_once 'includes/Database.php';
require_once 'includes/AuthManager.php';
require_once 'includes/ComplianceManager.php';
require_once 'config.php';

// 启动会话
session_start();

// 初始化认证管理器
$authManager = new AuthManager();

// 检查用户登录状态
if (!$authManager->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 检查会话是否过期
if ($authManager->isSessionExpired()) {
    $authManager->logout();
    header('Location: login.php?error=session_expired');
    exit;
}

// 检查权限
if (!$authManager->hasPermission(AuthManager::PERMISSION_CARD_CREATE)) {
    http_response_code(403);
    die('访问被拒绝：您没有添加卡片的权限');
}

// 刷新会话
$authManager->refreshSession();

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();

// 初始化变量
$message = '';
$messageType = '';
$formData = [
    'card_number' => '',
    'card_holder' => '',
    'id_card' => '',
    'phone' => '',
    'card_type' => 'credit',
    'bank_name' => '',
    'credit_limit' => '',
    'issue_date' => '',
    'expire_date' => ''
];

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';
    
    if (!SecurityUtils::validateCSRFToken($csrfToken)) {
        $message = 'CSRF验证失败，请重新提交';
        $messageType = 'danger';
    } else {
        try {
            // 获取表单数据
            $formData['card_number'] = trim($_POST['card_number'] ?? '');
            $formData['card_holder'] = trim($_POST['card_holder'] ?? '');
            $formData['id_card'] = trim($_POST['id_card'] ?? '');
            $formData['phone'] = trim($_POST['phone'] ?? '');
            $formData['card_type'] = $_POST['card_type'] ?? 'credit';
            $formData['bank_name'] = trim($_POST['bank_name'] ?? '');
            $formData['credit_limit'] = floatval($_POST['credit_limit'] ?? 0);
            $formData['issue_date'] = $_POST['issue_date'] ?? '';
            $formData['expire_date'] = $_POST['expire_date'] ?? '';
            
            // 验证必填字段
            $requiredFields = ['card_number', 'card_holder', 'id_card', 'phone'];
            $errors = [];
            
            foreach ($requiredFields as $field) {
                if (empty($formData[$field])) {
                    $errors[] = "字段 {$field} 是必填的";
                }
            }
            
            // 验证卡号格式（16位数字）
            if (!empty($formData['card_number']) && !preg_match('/^\d{16}$/', $formData['card_number'])) {
                $errors[] = '卡号必须是16位数字';
            }
            
            // 验证身份证号格式
            if (!empty($formData['id_card']) && !preg_match('/^\d{17}[\dXx]$/', $formData['id_card'])) {
                $errors[] = '身份证号格式不正确';
            }
            
            // 验证手机号格式
            if (!empty($formData['phone']) && !preg_match('/^1[3-9]\d{9}$/', $formData['phone'])) {
                $errors[] = '手机号格式不正确';
            }
            
            // 验证信用额度
            if ($formData['credit_limit'] < 0) {
                $errors[] = '信用额度不能为负数';
            }
            
            if (!empty($errors)) {
                $message = '表单验证失败：' . implode(', ', $errors);
                $messageType = 'danger';
            } else {
                // 检查数据访问权限
            if (!ComplianceManager::checkDataAccessPermission($currentUser['id'], 'create', 'card_data')) {
                $message = '您没有权限创建卡片数据';
                $messageType = 'danger';
            } else {
                    $db = Database::getInstance();
                    
                    try {
                        // 开始事务
                        $db->beginTransaction();
                        
                        // 检查卡号是否已存在
                        $existingCard = $db->query(
                            "SELECT id FROM cards WHERE card_number_hash = ?",
                            [hash('sha256', $formData['card_number'])]
                        );
                        
                        if (!empty($existingCard)) {
                            throw new Exception('该卡号已存在');
                        }
                        
                        // 加密敏感数据
                        $encryptedCardNumber = SecurityUtils::encrypt($formData['card_number']);
                        $encryptedCardHolder = SecurityUtils::encrypt($formData['card_holder']);
                        $encryptedIdCard = SecurityUtils::encrypt($formData['id_card']);
                        $encryptedPhone = SecurityUtils::encrypt($formData['phone']);
                        
                        // 插入卡片信息
                        $cardData = [
                            'card_number' => $encryptedCardNumber,
                            'card_number_hash' => hash('sha256', $formData['card_number']),
                            'card_holder' => $encryptedCardHolder,
                            'id_card' => $encryptedIdCard,
                            'phone' => $encryptedPhone,
                            'card_type' => $formData['card_type'],
                            'bank_name' => $formData['bank_name'],
                            'credit_limit' => $formData['credit_limit'],
                            'issue_date' => $formData['issue_date'],
                            'expire_date' => $formData['expire_date'],
                            'status' => 'pending',
                            'created_by' => $currentUser['id'],
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        ];
                        
                        $cardId = $db->insert('cards', $cardData);
                        
                        // 记录数据访问授权
                        ComplianceManager::recordDataAccessAuthorization(
                            $currentUser['id'], 
                            'card_data', 
                            'create', 
                            '添加新卡片', 
                            ['card_id' => $cardId, 'card_type' => $formData['card_type']]
                        );
                        
                        // 记录操作日志
                        $authManager->recordUserLog(
                            $currentUser['id'],
                            'card_create',
                            "添加新卡片，卡号：" . SecurityUtils::maskCardNumber($formData['card_number']),
                            SecurityUtils::getClientIP(),
                            ['card_id' => $cardId, 'card_type' => $formData['card_type']]
                        );
                        
                        // 记录安全日志
                        SecurityUtils::logSecurity('INFO', '新卡片添加成功', [
                            'user_id' => $currentUser['id'],
                            'username' => $currentUser['username'],
                            'card_id' => $cardId,
                            'card_type' => $formData['card_type']
                        ]);
                        
                        // 提交事务
                        $db->commit();
                        
                        $message = '卡片添加成功！';
                        $messageType = 'success';
                        
                        // 清空表单
                        $formData = [
                            'card_number' => '',
                            'card_holder' => '',
                            'id_card' => '',
                            'phone' => '',
                            'card_type' => 'credit',
                            'bank_name' => '',
                            'credit_limit' => '',
                            'issue_date' => '',
                            'expire_date' => ''
                        ];
                        
                    } catch (Exception $e) {
                        // 回滚事务
                        $db->rollback();
                        throw $e;
                    }
                }
            }
        } catch (Exception $e) {
            $message = '添加失败：' . $e->getMessage();
            $messageType = 'danger';
            
            // 记录错误日志
            SecurityUtils::logSecurity('ERROR', '卡片添加失败', [
                'user_id' => $currentUser['id'],
                'username' => $currentUser['username'],
                'error' => $e->getMessage(),
                'form_data' => $formData
            ]);
        }
    }
}

// 生成CSRF令牌
$csrfToken = SecurityUtils::generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加卡片 - 商业级发卡系统</title>
    <link rel="stylesheet" href="assets/css/ui-components.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4a5568;
        }
        
        .nav-links {
            display: flex;
            gap: 2rem;
            align-items: center;
        }
        
        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: #667eea;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.5rem 1rem;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 8px;
        }
        
        .user-role {
            font-size: 0.875rem;
            color: #718096;
        }
        
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
            flex: 1;
        }
        
        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .card-header {
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .card-header h1 {
            color: #2d3748;
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .card-header p {
            color: #718096;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #4a5568;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-group input.error {
            border-color: #f56565;
        }
        
        .error-message {
            color: #f56565;
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
        
        .help-text {
            font-size: 0.875rem;
            color: #718096;
            margin-top: 0.25rem;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.75rem 2rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        
        .btn:hover {
            transform: translateY(-2px);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-secondary {
            background: #718096;
            margin-left: 1rem;
        }
        
        .success-message {
            background: #48bb78;
            color: white;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            text-align: center;
        }
        
        .error-alert {
            background: #f56565;
            color: white;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            text-align: center;
        }
        
        .form-actions {
            text-align: center;
            margin-top: 2rem;
        }
        
        .compliance-notice {
            background: #f7fafc;
            border-left: 4px solid #4299e1;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .compliance-notice h3 {
            color: #2b6cb0;
            margin-bottom: 0.5rem;
        }
        
        .compliance-notice p {
            color: #4a5568;
            font-size: 0.875rem;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .nav-links {
                flex-direction: column;
                gap: 1rem;
            }
            
            .navbar {
                flex-direction: column;
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">商业级发卡系统</div>
        <div class="nav-links">
            <a href="dashboard.php">仪表板</a>
            <a href="add_card.php">添加卡片</a>
            <a href="search_card.php">查询卡片</a>
            <a href="identity_verification.php">身份核验</a>
            <a href="update_status.php">更新状态</a>
            <a href="logs.php">操作日志</a>
            <a href="compliance.php">合规管理</a>
            <div class="user-info">
                <span><?php echo htmlspecialchars($currentUser['username']); ?></span>
                <span class="user-role"><?php echo htmlspecialchars($currentUser['role']); ?></span>
                <a href="logout.php" style="color: #f56565;">退出</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>添加卡片</h1>
                <p>请填写完整的卡片信息</p>
            </div>

            <?php if ($message): ?>
                <div class="<?php echo $messageType === 'success' ? 'success-message' : 'error-alert'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <div class="compliance-notice">
                <h3>数据安全提示</h3>
                <p>所有敏感信息将进行加密存储，并按照合规要求进行脱敏处理。您的操作将被记录用于审计。</p>
            </div>

            <form method="POST" id="addCardForm">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="card_number">卡号 *</label>
                        <input type="text" id="card_number" name="card_number" 
                               placeholder="请输入16位数字卡号" 
                               value="<?php echo htmlspecialchars($formData['card_number']); ?>"
                               maxlength="16" required>
                        <div class="help-text">16位数字，将自动加密存储</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="card_holder">持卡人姓名 *</label>
                        <input type="text" id="card_holder" name="card_holder" 
                               placeholder="请输入持卡人真实姓名" 
                               value="<?php echo htmlspecialchars($formData['card_holder']); ?>" required>
                        <div class="help-text">将进行加密存储和脱敏显示</div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="id_card">身份证号 *</label>
                        <input type="text" id="id_card" name="id_card" 
                               placeholder="请输入18位身份证号" 
                               value="<?php echo htmlspecialchars($formData['id_card']); ?>"
                               maxlength="18" required>
                        <div class="help-text">18位身份证号，将加密存储</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">手机号码 *</label>
                        <input type="tel" id="phone" name="phone" 
                               placeholder="请输入11位手机号" 
                               value="<?php echo htmlspecialchars($formData['phone']); ?>"
                               maxlength="11" required>
                        <div class="help-text">11位手机号，用于联系和验证</div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="card_type">卡片类型 *</label>
                        <select id="card_type" name="card_type" required>
                            <option value="credit" <?php echo $formData['card_type'] === 'credit' ? 'selected' : ''; ?>>信用卡</option>
                            <option value="debit" <?php echo $formData['card_type'] === 'debit' ? 'selected' : ''; ?>>借记卡</option>
                            <option value="prepaid" <?php echo $formData['card_type'] === 'prepaid' ? 'selected' : ''; ?>>预付卡</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="bank_name">发卡银行</label>
                        <input type="text" id="bank_name" name="bank_name" 
                               placeholder="请输入发卡银行名称" 
                               value="<?php echo htmlspecialchars($formData['bank_name']); ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="credit_limit">信用额度</label>
                        <input type="number" id="credit_limit" name="credit_limit" 
                               placeholder="请输入信用额度" 
                               value="<?php echo htmlspecialchars($formData['credit_limit']); ?>"
                               min="0" step="0.01">
                        <div class="help-text">单位：元，仅信用卡需要填写</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="issue_date">发卡日期</label>
                        <input type="date" id="issue_date" name="issue_date" 
                               value="<?php echo htmlspecialchars($formData['issue_date']); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="expire_date">到期日期</label>
                    <input type="date" id="expire_date" name="expire_date" 
                           value="<?php echo htmlspecialchars($formData['expire_date']); ?>">
                    <div class="help-text">卡片的有效期截止日期</div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn">添加卡片</button>
                    <button type="button" class="btn btn-secondary" onclick="resetForm()">重置</button>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/ui-components.js"></script>
    <script src="assets/js/data-loader.js"></script>
    <script src="assets/js/data-loader-init.js"></script>
    <script>
        // 设置当前用户全局变量
        window.currentUser = {
            id: <?php echo json_encode($currentUser['id']); ?>,
            username: <?php echo json_encode($currentUser['username']); ?>,
            role: <?php echo json_encode($currentUser['role']); ?>
        };
        
        // 初始化UI组件
        document.addEventListener('DOMContentLoaded', function() {
            // 初始化表单验证
            const form = document.getElementById('addCardForm');
            
            // 设置表单验证属性
            const requiredFields = ['card_number', 'card_holder', 'id_card', 'phone'];
            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                field.setAttribute('data-required', 'true');
                field.setAttribute('data-error-message', `请输入${getFieldName(fieldId)}`);
            });
            
            // 设置特定字段的验证规则
            document.getElementById('card_number').setAttribute('data-pattern', '^\\d{16}$');
            document.getElementById('card_number').setAttribute('data-error-message', '卡号必须是16位数字');
            
            document.getElementById('id_card').setAttribute('data-pattern', '^\\d{17}[\\dXx]$');
            document.getElementById('id_card').setAttribute('data-error-message', '身份证号格式不正确');
            
            document.getElementById('phone').setAttribute('data-pattern', '^1[3-9]\\d{9}$');
            document.getElementById('phone').setAttribute('data-error-message', '手机号格式不正确');
            
            // 初始化表单验证
            UIComponents.FormValidation.init(form);
            
            // 添加工具提示
            const helpTexts = document.querySelectorAll('.help-text');
            helpTexts.forEach(helpText => {
                const input = helpText.previousElementSibling;
                if (input && input.tagName === 'INPUT' || input.tagName === 'SELECT') {
                    UIComponents.Tooltip.create(input, {
                        content: helpText.textContent,
                        position: 'top'
                    });
                }
            });
            
            // 表单提交处理
            form.addEventListener('submit', function(e) {
                if (!UIComponents.FormValidation.validate(form)) {
                    e.preventDefault();
                    
                    // 显示错误通知
                    UIComponents.Notification.show({
                        type: 'error',
                        message: '请检查表单中的错误',
                        duration: 5000
                    });
                    
                    // 滚动到第一个错误字段
                    const firstError = document.querySelector('.form-input.error');
                    if (firstError) {
                        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                    return;
                }
                
                // 显示加载状态
                UIComponents.Loading.show('正在添加卡片...');
                
                // 让表单正常提交到后端PHP处理
                // 不阻止默认提交行为，让PHP处理表单数据
            });
            
            // 重置按钮处理
            const resetBtn = document.querySelector('button[onclick="resetForm()"]');
            if (resetBtn) {
                resetBtn.removeAttribute('onclick');
                resetBtn.addEventListener('click', function() {
                    form.reset();
                    UIComponents.FormValidation.clearErrors(form);
                    
                    UIComponents.Notification.show({
                        type: 'info',
                        message: '表单已重置',
                        duration: 2000
                    });
                });
            }
            
            // 输入限制和格式化
            setupInputFormatting();
            
            // 显示成功消息（如果有）
            <?php if (!empty($message)): ?>
                UIComponents.Notification.show({
                    type: '<?php echo $messageType === 'success' ? 'success' : 'error'; ?>',
                    message: '<?php echo addslashes($message); ?>',
                    duration: 5000
                });
            <?php endif; ?>
        });
        
        // 获取字段中文名称
        function getFieldName(fieldId) {
            const fieldNames = {
                'card_number': '卡号',
                'card_holder': '持卡人姓名',
                'id_card': '身份证号',
                'phone': '手机号码'
            };
            return fieldNames[fieldId] || fieldId;
        }
        
        // 设置输入格式化
        function setupInputFormatting() {
            // 限制卡号输入为数字
            document.getElementById('card_number').addEventListener('input', function(e) {
                this.value = this.value.replace(/\D/g, '').slice(0, 16);
            });
            
            // 限制身份证号输入
            document.getElementById('id_card').addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9Xx]/g, '').slice(0, 18);
            });
            
            // 限制手机号输入为数字
            document.getElementById('phone').addEventListener('input', function(e) {
                this.value = this.value.replace(/\D/g, '').slice(0, 11);
            });
            
            // 限制信用额度为正数
            document.getElementById('credit_limit').addEventListener('input', function(e) {
                if (this.value < 0) {
                    this.value = 0;
                }
            });
        }
    </script>
</body>
</html>

                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">
                            <i class="fas fa-list me-1"></i>系统日志
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="database_monitor.php">
                            <i class="fas fa-database me-1"></i>数据库监控
                        </a>
                    </li>