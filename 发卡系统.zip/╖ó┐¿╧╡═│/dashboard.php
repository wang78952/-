<?php
require_once __DIR__ . '/includes/SecurityUtils.php';
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/AuthManager.php';
require_once __DIR__ . '/includes/ComplianceManager.php';
require_once __DIR__ . '/monitoring/BusinessMetricsMonitor.php';
require_once __DIR__ . '/config.php';

// 启动会话
session_start();

// 初始化认证管理器
$authManager = new AuthManager();

// 检查用户登录状态
if (!$authManager->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 检查会话是否过期
if ($authManager->isSessionExpired()) {
    $authManager->logout();
    header('Location: login.php?error=session_expired');
    exit;
}

// 刷新会话
$authManager->refreshSession();

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();

// 初始化统计数据
$stats = array(
    'total_cards' => 0,
    'active_cards' => 0,
    'inactive_cards' => 0,
    'suspended_cards' => 0,
    'cancelled_cards' => 0,
    'expired_cards' => 0,
    'recent_cards' => array(),
    'recent_activities' => array(),
    'security_events' => array(),
    'compliance_alerts' => array(),
    'business_metrics' => array()
);

// 初始化业务指标监控器
$businessMetrics = new BusinessMetricsMonitor();

try {
    $db = Database::getInstance();
    
    // 检查数据访问权限
    if (ComplianceManager::checkDataAccessPermission($currentUser['id'], 'read', 'dashboard')) {
        
        // 获取卡片统计
        $stats['total_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards")['count'];
        $stats['active_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'active'")['count'];
        $stats['inactive_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'inactive'")['count'];
        $stats['suspended_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'suspended'")['count'];
        $stats['cancelled_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'cancelled'")['count'];
        $stats['expired_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'expired'")['count'];
        
        // 获取最近添加的卡片（管理员和业务管理员可查看详细信息）
        $recentCardsQuery = "SELECT c.*, u.username as created_by_name 
                             FROM cards c 
                             LEFT JOIN users u ON c.created_by = u.id 
                             ORDER BY c.created_at DESC 
                             LIMIT 5";
        $stats['recent_cards'] = $db->query($recentCardsQuery);
        
        // 对卡片数据进行脱敏处理
        foreach ($stats['recent_cards'] as &$card) {
            // 解密敏感数据
            $card['card_number'] = SecurityUtils::decrypt($card['card_number']);
            $card['card_holder'] = SecurityUtils::decrypt($card['card_holder']);
            $card['id_card'] = SecurityUtils::decrypt($card['id_card']);
            $card['phone'] = SecurityUtils::decrypt($card['phone']);
            
            // 应用数据脱敏
            $card['card_number'] = ComplianceManager::maskCardNumber($card['card_number'], $currentUser['role']);
            $card['card_holder'] = ComplianceManager::maskName($card['card_holder'], $currentUser['role']);
            $card['id_card'] = ComplianceManager::maskIdCard($card['id_card'], $currentUser['role']);
            $card['phone'] = ComplianceManager::maskPhone($card['phone'], $currentUser['role']);
        }
        
        // 记录数据访问授权
        ComplianceManager::recordDataAccessAuthorization(
            $currentUser['id'], 
            'dashboard', 
            'read', 
            '访问仪表板查看统计数据', 
            array('stats_type' => 'dashboard_overview')
        );
    }
    
    // 获取最近活动（所有用户都可查看自己的活动）
    $activitiesQuery = "SELECT * FROM user_logs 
                        WHERE user_id = ? 
                        ORDER BY created_at DESC 
                        LIMIT 10";
    $stats['recent_activities'] = $db->query($activitiesQuery, array($currentUser['id']));
    
    // 获取安全事件（仅管理员和业务管理员可查看）
    if (in_array($currentUser['role'], ['admin', 'business_admin'])) {
        $securityEventsQuery = "SELECT * FROM security_logs 
                               WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                               ORDER BY created_at DESC 
                               LIMIT 10";
        $stats['security_events'] = $db->query($securityEventsQuery);
        
        // 获取合规告警
        $complianceAlertsQuery = "SELECT * FROM data_access_authorizations 
                                 WHERE access_type IN ('suspicious', 'violation')
                                 ORDER BY created_at DESC 
                                 LIMIT 5";
        $stats['compliance_alerts'] = $db->query($complianceAlertsQuery);
        
        // 获取业务指标数据（管理员和业务管理员可查看）
        if (in_array($currentUser['role'], ['admin', 'business_admin'])) {
            try {
                $stats['business_metrics'] = $businessMetrics->getAllMetrics('month');
            } catch (Exception $e) {
                $stats['business_metrics'] = array();
                SecurityUtils::logSecurity('ERROR', '业务指标数据获取失败', array(
                    'user_id' => $currentUser['id'],
                    'error' => $e->getMessage()
                ));
            }
        }
    }
    
} catch (Exception $e) {
    // 记录错误日志
    SecurityUtils::logSecurity('ERROR', '仪表板数据加载失败', array(
        'user_id' => $currentUser['id'],
        'username' => $currentUser['username'],
        'error' => $e->getMessage()
    ));
}

// 生成CSRF令牌
$csrfToken = SecurityUtils::generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>仪表板 - 商业级发卡系统</title>
    <link rel="stylesheet" href="assets/css/ui-components.css">
        <script src="assets/js/chart-components.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4a5568;
        }
        
        .nav-links {
            display: flex;
            gap: 2rem;
            align-items: center;
        }
        
        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: #667eea;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.5rem 1rem;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 8px;
        }
        
        .user-role {
            font-size: 0.875rem;
            color: #718096;
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 1rem;
            flex: 1;
        }
        
        .dashboard-header {
            text-align: center;
            color: white;
            margin-bottom: 2rem;
        }
        
        .dashboard-header h1 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .dashboard-header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: #718096;
            font-size: 0.9rem;
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 2rem;
        }
        
        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d3748;
        }
        
        .card-badge {
            background: #667eea;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.875rem;
        }
        
        .list-item {
            padding: 1rem 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .list-item:last-child {
            border-bottom: none;
        }
        
        .list-item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .list-item-title {
            font-weight: 500;
            color: #2d3748;
        }
        
        .list-item-time {
            font-size: 0.875rem;
            color: #718096;
        }
        
        .list-item-content {
            color: #4a5568;
            font-size: 0.9rem;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .status-active {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .status-inactive {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .status-suspended {
            background: #feebc8;
            color: #7c2d12;
        }
        
        .status-cancelled {
            background: #e2e8f0;
            color: #4a5568;
        }
        
        .status-expired {
            background: #fbb6ce;
            color: #702459;
        }
        
        .security-level {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .security-high {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .security-medium {
            background: #feebc8;
            color: #7c2d12;
        }
        
        .security-low {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .compliance-notice {
            background: #f7fafc;
            border-left: 4px solid #4299e1;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .compliance-notice h3 {
            color: #2b6cb0;
            margin-bottom: 0.5rem;
        }
        
        .compliance-notice p {
            color: #4a5568;
            font-size: 0.875rem;
        }
        
        /* 业务指标监控样式 */
        .metrics-dashboard {
            margin-top: 2rem;
        }
        
        .metrics-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            backdrop-filter: blur(10px);
        }
        
        .metrics-title {
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .metrics-period-selector {
            display: flex;
            gap: 0.5rem;
        }
        
        .period-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.875rem;
        }
        
        .period-btn:hover, .period-btn.active {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        
        .business-metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .metric-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
        }
        
        .metric-card:hover {
            transform: translateY(-5px);
        }
        
        .metric-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .metric-title {
            font-size: 1rem;
            font-weight: 600;
            color: #2d3748;
        }
        
        .metric-icon {
            font-size: 1.5rem;
        }
        
        .metric-value {
            font-size: 2rem;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        
        .metric-change {
            font-size: 0.875rem;
            margin-bottom: 0.5rem;
        }
        
        .metric-change.positive {
            color: #22543d;
        }
        
        .metric-change.negative {
            color: #742a2a;
        }
        
        .metric-description {
            color: #718096;
            font-size: 0.875rem;
        }
        
        .health-score-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            grid-column: span 2;
        }
        
        .health-score-card .metric-title,
        .health-score-card .metric-value,
        .health-score-card .metric-description {
            color: white;
        }
        
        .health-level {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.875rem;
            font-weight: 500;
            margin-left: 0.5rem;
        }
        
        .health-level.excellent {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .health-level.good {
            background: #bee3f8;
            color: #2c5282;
        }
        
        .health-level.fair {
            background: #feebc8;
            color: #7c2d12;
        }
        
        .health-level.poor {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .health-level.critical {
            background: #e53e3e;
            color: white;
        }
        
        .chart-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 2rem;
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .chart-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d3748;
        }
        
        .chart-placeholder {
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f7fafc;
            border-radius: 8px;
            color: #718096;
            font-size: 0.875rem;
        }
        
        .recommendations-list {
            margin-top: 1rem;
        }
        
        .recommendation-item {
            background: #f7fafc;
            border-left: 4px solid #4299e1;
            padding: 0.75rem;
            margin-bottom: 0.5rem;
            border-radius: 4px;
            font-size: 0.875rem;
            color: #4a5568;
        }
        
        .refresh-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.875rem;
        }
        
        .refresh-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        
        .refresh-btn.loading {
            opacity: 0.7;
            cursor: not-allowed;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn:hover {
            transform: translateY(-2px);
        }
        
        .btn-sm {
            padding: 0.25rem 0.75rem;
            font-size: 0.8rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #718096;
        }
        
        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
            
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .nav-links {
            flex-direction: column;
            gap: 1rem;
        }
        
        .navbar {
            flex-direction: column;
            padding: 1rem;
        }
        
        .dashboard-header h1 {
            font-size: 2rem;
        }
        
        .charts-controls {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .charts-controls .btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .charts-controls .btn-primary {
            background-color: #4299e1;
            color: white;
        }
        
        .charts-controls .btn-primary:hover {
            background-color: #3182ce;
            transform: translateY(-2px);
        }
        
        .charts-controls .btn-secondary {
            background-color: #718096;
            color: white;
        }
        
        .charts-controls .btn-secondary:hover {
            background-color: #4a5568;
            transform: translateY(-2px);
        }
        
        .charts-controls .btn-info {
            background-color: #38b2ac;
            color: white;
        }
        
        .charts-controls .btn-info:hover {
            background-color: #319795;
            transform: translateY(-2px);
        }
        
        .export-icon, .link-icon, .reset-icon {
            font-size: 1.1rem;
        }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">商业级发卡系统</div>
        <div class="nav-links">
            <a href="dashboard.php">仪表板</a>
            <a href="add_card.php">添加卡片</a>
            <a href="search_card.php">查询卡片</a>
            <a href="update_status.php">更新状态</a>
            <a href="logs.php">操作日志</a>
            <a href="compliance.php">合规管理</a>
            <div class="user-info">
                <span><?php echo htmlspecialchars($currentUser['username']); ?></span>
                <span class="user-role"><?php echo htmlspecialchars($currentUser['role']); ?></span>
                <a href="logout.php" style="color: #f56565;">退出</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="dashboard-header">
            <h1>系统仪表板</h1>
            <p>实时监控发卡系统状态和数据统计</p>
        </div>

        <div class="compliance-notice">
            <h3>数据安全提示</h3>
            <p>仪表板中的敏感信息已进行脱敏处理，您的所有操作将被记录用于合规审计。</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-value"><?php echo number_format($stats['total_cards']); ?></div>
                <div class="stat-label">卡片总数</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-value"><?php echo number_format($stats['active_cards']); ?></div>
                <div class="stat-label">激活卡片</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⏸️</div>
                <div class="stat-value"><?php echo number_format($stats['inactive_cards']); ?></div>
                <div class="stat-label">未激活卡片</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⚠️</div>
                <div class="stat-value"><?php echo number_format($stats['suspended_cards']); ?></div>
                <div class="stat-label">暂停卡片</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">❌</div>
                <div class="stat-value"><?php echo number_format($stats['cancelled_cards']); ?></div>
                <div class="stat-label">注销卡片</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⏰</div>
                <div class="stat-value"><?php echo number_format($stats['expired_cards']); ?></div>
                <div class="stat-label">过期卡片</div>
            </div>
        </div>

        <?php if (in_array($currentUser['role'], ['admin', 'business_manager'])): ?>
        <!-- 业务指标监控面板 -->
        <div class="business-metrics-dashboard">
            <div class="metrics-header">
                <h2>业务指标监控</h2>
                <div class="metrics-controls">
                    <select id="metricsPeriod" class="metrics-period-select">
                        <option value="day">今日</option>
                        <option value="week">本周</option>
                        <option value="month" selected>本月</option>
                        <option value="quarter">本季度</option>
                        <option value="year">本年</option>
                    </select>
                    <button class="refresh-btn" onclick="refreshBusinessMetrics()">
                        <span class="refresh-icon">🔄</span> 刷新数据
                    </button>
                </div>
            </div>

            <div class="metrics-grid">
                <!-- 核心业务指标 -->
                <div class="metric-card">
                    <div class="metric-header">
                        <h3>卡片激活率</h3>
                        <span class="metric-icon">🎯</span>
                    </div>
                    <div class="metric-value">
                        <?php echo isset($businessMetrics['card_activation_rate']) ? number_format($businessMetrics['card_activation_rate'], 1) . '%' : 'N/A'; ?>
                    </div>
                    <div class="metric-trend <?php echo isset($businessMetrics['activation_trend']) && $businessMetrics['activation_trend'] > 0 ? 'trend-up' : 'trend-down'; ?>">
                        <?php echo isset($businessMetrics['activation_trend']) ? ($businessMetrics['activation_trend'] > 0 ? '↑' : '↓') . ' ' . abs($businessMetrics['activation_trend']) . '%' : ''; ?>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <h3>订单转化率</h3>
                        <span class="metric-icon">🛒</span>
                    </div>
                    <div class="metric-value">
                        <?php echo isset($businessMetrics['order_conversion_rate']) ? number_format($businessMetrics['order_conversion_rate'], 1) . '%' : 'N/A'; ?>
                    </div>
                    <div class="metric-trend <?php echo isset($businessMetrics['conversion_trend']) && $businessMetrics['conversion_trend'] > 0 ? 'trend-up' : 'trend-down'; ?>">
                        <?php echo isset($businessMetrics['conversion_trend']) ? ($businessMetrics['conversion_trend'] > 0 ? '↑' : '↓') . ' ' . abs($businessMetrics['conversion_trend']) . '%' : ''; ?>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <h3>用户活跃度</h3>
                        <span class="metric-icon">👥</span>
                    </div>
                    <div class="metric-value">
                        <?php echo isset($businessMetrics['user_activity_rate']) ? number_format($businessMetrics['user_activity_rate'], 1) . '%' : 'N/A'; ?>
                    </div>
                    <div class="metric-trend <?php echo isset($businessMetrics['activity_trend']) && $businessMetrics['activity_trend'] > 0 ? 'trend-up' : 'trend-down'; ?>">
                        <?php echo isset($businessMetrics['activity_trend']) ? ($businessMetrics['activity_trend'] > 0 ? '↑' : '↓') . ' ' . abs($businessMetrics['activity_trend']) . '%' : ''; ?>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <h3>总收入</h3>
                        <span class="metric-icon">💰</span>
                    </div>
                    <div class="metric-value">
                        ¥<?php echo isset($businessMetrics['total_revenue']) ? number_format($businessMetrics['total_revenue'], 2) : '0.00'; ?>
                    </div>
                    <div class="metric-trend <?php echo isset($businessMetrics['revenue_trend']) && $businessMetrics['revenue_trend'] > 0 ? 'trend-up' : 'trend-down'; ?>">
                        <?php echo isset($businessMetrics['revenue_trend']) ? ($businessMetrics['revenue_trend'] > 0 ? '↑' : '↓') . ' ' . abs($businessMetrics['revenue_trend']) . '%' : ''; ?>
                    </div>
                </div>
            </div>

            <!-- 业务健康评分 -->
            <div class="health-score-section">
                <div class="health-score-card">
                    <div class="health-score-header">
                        <h3>业务健康评分</h3>
                        <span class="health-score-icon">💚</span>
                    </div>
                    <div class="health-score-value">
                        <?php echo isset($businessMetrics['health_score']) ? number_format($businessMetrics['health_score'], 0) : '0'; ?>/100
                    </div>
                    <div class="health-score-label">
                        <?php 
                        if (isset($businessMetrics['health_score'])) {
                            if ($businessMetrics['health_score'] >= 90) echo '优秀';
                            elseif ($businessMetrics['health_score'] >= 75) echo '良好';
                            elseif ($businessMetrics['health_score'] >= 60) echo '一般';
                            else echo '需要改进';
                        } else {
                            echo '未知';
                        }
                        ?>
                    </div>
                    <div class="health-score-progress">
                        <div class="health-score-bar" style="width: <?php echo isset($businessMetrics['health_score']) ? $businessMetrics['health_score'] : 0; ?>%"></div>
                    </div>
                </div>

                <div class="recommendations-card">
                    <div class="recommendations-header">
                        <h3>优化建议</h3>
                        <span class="recommendations-icon">💡</span>
                    </div>
                    <div class="recommendations-list">
                        <?php if (isset($businessMetrics['recommendations']) && !empty($businessMetrics['recommendations'])): ?>
                            <?php foreach ($businessMetrics['recommendations'] as $recommendation): ?>
                                <div class="recommendation-item">
                                    <?php echo htmlspecialchars($recommendation); ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="recommendation-item">
                                暂无优化建议，业务运行状况良好。
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- 图表区域 -->
            <div class="charts-section">
                <div class="charts-controls">
                    <div class="chart-filter-group">
                        <label for="chartDateRange">时间范围：</label>
                        <select id="chartDateRange">
                            <option value="7d">最近7天</option>
                            <option value="30d" selected>最近30天</option>
                            <option value="90d">最近90天</option>
                            <option value="1y">最近1年</option>
                        </select>
                    </div>
                    <button class="btn btn-primary" onclick="exportAllCharts()">
                        <span class="export-icon">📊</span> 批量导出图表
                    </button>
                    <button class="btn btn-secondary" onclick="toggleChartLinkage()">
                        <span class="link-icon">🔗</span> <span id="linkageText">启用图表联动</span>
                    </button>
                    <button class="btn btn-info" onclick="resetChartFilters()">
                        <span class="reset-icon">🔄</span> 重置过滤器
                    </button>
                </div>
                
                <div class="charts-grid">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h3>卡片状态分布</h3>
                            <button class="btn btn-sm" onclick="exportChart('cardStatus')">导出</button>
                        </div>
                        <div class="chart-container">
                            <div id="cardStatusChart" style="width: 100%; height: 300px;"></div>
                        </div>
                    </div>

                    <div class="chart-card">
                        <div class="chart-header">
                            <h3>收入趋势</h3>
                            <button class="btn btn-sm" onclick="exportChart('revenue')">导出</button>
                        </div>
                        <div class="chart-container">
                            <div id="revenueChart" style="width: 100%; height: 300px;"></div>
                        </div>
                    </div>

                    <div class="chart-card">
                        <div class="chart-header">
                            <h3>销售趋势</h3>
                            <button class="btn btn-sm" onclick="exportChart('sales')">导出</button>
                        </div>
                        <div class="chart-container">
                            <div id="salesChart" style="width: 100%; height: 300px;"></div>
                        </div>
                    </div>

                    <div class="chart-card">
                        <div class="chart-header">
                            <h3>用户活跃度</h3>
                            <button class="btn btn-sm" onclick="exportChart('userActivity')">导出</button>
                        </div>
                        <div class="chart-container">
                            <div id="userActivityChart" style="width: 100%; height: 300px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="content-grid">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">最近添加的卡片</h3>
                    <span class="card-badge">最新</span>
                </div>
                <?php if (!empty($stats['recent_cards'])): ?>
                    <?php foreach ($stats['recent_cards'] as $card): ?>
                        <div class="list-item">
                            <div class="list-item-header">
                                <span class="list-item-title">
                                    <?php echo htmlspecialchars($card['card_number']); ?>
                                </span>
                                <span class="status-badge status-<?php echo htmlspecialchars($card['status']); ?>">
                                    <?php
                                    $statusMap = [
                                        'active' => '激活',
                                        'inactive' => '未激活',
                                        'suspended' => '暂停',
                                        'cancelled' => '注销',
                                        'expired' => '过期'
                                    ];
                                    echo $statusMap[$card['status']] ?? htmlspecialchars($card['status']);
                                    ?>
                                </span>
                            </div>
                            <div class="list-item-content">
                                <div>持卡人：<?php echo htmlspecialchars($card['card_holder']); ?></div>
                                <div>手机号：<?php echo htmlspecialchars($card['phone']); ?></div>
                                <div>创建时间：<?php echo htmlspecialchars($card['created_at']); ?></div>
                                <?php if ($card['created_by_name']): ?>
                                    <div>创建人：<?php echo htmlspecialchars($card['created_by_name']); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-state-icon">📭</div>
                        <p>暂无卡片数据</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">最近活动</h3>
                    <span class="card-badge">活动</span>
                </div>
                <?php if (!empty($stats['recent_activities'])): ?>
                    <?php foreach ($stats['recent_activities'] as $activity): ?>
                        <div class="list-item">
                            <div class="list-item-header">
                                <span class="list-item-title">
                                    <?php echo htmlspecialchars($activity['action']); ?>
                                </span>
                                <span class="list-item-time">
                                    <?php echo date('m-d H:i', strtotime($activity['created_at'])); ?>
                                </span>
                            </div>
                            <div class="list-item-content">
                                <?php echo htmlspecialchars($activity['description']); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-state-icon">📭</div>
                        <p>暂无活动记录</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if (in_array($currentUser['role'], ['admin', 'business_admin'])): ?>
            <div class="content-grid" style="margin-top: 2rem;">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">安全事件</h3>
                        <span class="card-badge">监控</span>
                    </div>
                    <?php if (!empty($stats['security_events'])): ?>
                        <?php foreach ($stats['security_events'] as $event): ?>
                            <div class="list-item">
                                <div class="list-item-header">
                                    <span class="list-item-title">
                                        <?php echo htmlspecialchars($event['event_type']); ?>
                                    </span>
                                    <span class="security-level security-<?php echo $event['severity']; ?>">
                                        <?php echo $event['severity']; ?>
                                    </span>
                                </div>
                                <div class="list-item-content">
                                    <div><?php echo htmlspecialchars($event['description']); ?></div>
                                    <div>时间：<?php echo htmlspecialchars($event['created_at']); ?></div>
                                    <div>IP：<?php echo htmlspecialchars($event['ip_address']); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">🔒</div>
                            <p>暂无安全事件</p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">合规告警</h3>
                        <span class="card-badge">合规</span>
                    </div>
                    <?php if (!empty($stats['compliance_alerts'])): ?>
                        <?php foreach ($stats['compliance_alerts'] as $alert): ?>
                            <div class="list-item">
                                <div class="list-item-header">
                                    <span class="list-item-title">
                                        <?php echo htmlspecialchars($alert['access_type']); ?>
                                    </span>
                                    <span class="list-item-time">
                                        <?php echo date('m-d H:i', strtotime($alert['created_at'])); ?>
                                    </span>
                                </div>
                                <div class="list-item-content">
                                    <div>用户：<?php echo htmlspecialchars($alert['user_id']); ?></div>
                                    <div>操作：<?php echo htmlspecialchars($alert['operation_type']); ?></div>
                                    <div>原因：<?php echo htmlspecialchars($alert['reason']); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">✅</div>
                            <p>暂无合规告警</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <div style="text-align: center; margin-top: 2rem;">
            <a href="compliance.php" class="btn">查看合规管理</a>
            <a href="logs.php" class="btn" style="margin-left: 1rem;">查看操作日志</a>
        </div>
    </div>

    <script src="assets/js/ui-components.js"></script>
    <script src="assets/js/data-loader.js"></script>
    <script src="assets/js/data-loader-init.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // 设置当前用户全局变量
        window.currentUser = {
            id: <?php echo json_encode($currentUser['id']); ?>,
            username: <?php echo json_encode($currentUser['username']); ?>,
            role: <?php echo json_encode($currentUser['role']); ?>
        };
        
        // 业务指标监控相关变量
        let businessMetricsChart = null;
        let revenueChart = null;
        
        // 刷新业务指标数据
        function refreshBusinessMetrics() {
            const period = document.getElementById('metricsPeriod').value;
            const refreshBtn = document.querySelector('.refresh-btn');
            
            // 显示加载状态
            refreshBtn.classList.add('loading');
            refreshBtn.innerHTML = '<span class="refresh-icon">⏳</span> 加载中...';
            
            // 发送AJAX请求获取最新数据
            fetch(`api/business_metrics.php?period=${period}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateMetricsDisplay(data.metrics);
                        updateCharts(data.charts);
                        
                        // 显示成功提示
                        showNotification('success', '业务指标数据已更新');
                    } else {
                        showNotification('error', '获取业务指标数据失败：' + data.message);
                    }
                })
                .catch(error => {
                    console.error('获取业务指标数据出错:', error);
                    showNotification('error', '网络错误，请稍后重试');
                })
                .finally(() => {
                    // 恢复按钮状态
                    refreshBtn.classList.remove('loading');
                    refreshBtn.innerHTML = '<span class="refresh-icon">🔄</span> 刷新数据';
                });
        }
        
        // 更新指标显示
        function updateMetricsDisplay(metrics) {
            // 更新卡片激活率
            const activationRate = document.querySelector('.metric-card:nth-child(1) .metric-value');
            const activationTrend = document.querySelector('.metric-card:nth-child(1) .metric-trend');
            if (activationRate) activationRate.textContent = metrics.card_activation_rate ? metrics.card_activation_rate + '%' : 'N/A';
            if (activationTrend) {
                activationTrend.textContent = metrics.activation_trend ? (metrics.activation_trend > 0 ? '↑' : '↓') + ' ' + Math.abs(metrics.activation_trend) + '%' : '';
                activationTrend.className = 'metric-trend ' + (metrics.activation_trend > 0 ? 'trend-up' : 'trend-down');
            }
            
            // 更新订单转化率
            const conversionRate = document.querySelector('.metric-card:nth-child(2) .metric-value');
            const conversionTrend = document.querySelector('.metric-card:nth-child(2) .metric-trend');
            if (conversionRate) conversionRate.textContent = metrics.order_conversion_rate ? metrics.order_conversion_rate + '%' : 'N/A';
            if (conversionTrend) {
                conversionTrend.textContent = metrics.conversion_trend ? (metrics.conversion_trend > 0 ? '↑' : '↓') + ' ' + Math.abs(metrics.conversion_trend) + '%' : '';
                conversionTrend.className = 'metric-trend ' + (metrics.conversion_trend > 0 ? 'trend-up' : 'trend-down');
            }
            
            // 更新用户活跃度
            const activityRate = document.querySelector('.metric-card:nth-child(3) .metric-value');
            const activityTrend = document.querySelector('.metric-card:nth-child(3) .metric-trend');
            if (activityRate) activityRate.textContent = metrics.user_activity_rate ? metrics.user_activity_rate + '%' : 'N/A';
            if (activityTrend) {
                activityTrend.textContent = metrics.activity_trend ? (metrics.activity_trend > 0 ? '↑' : '↓') + ' ' + Math.abs(metrics.activity_trend) + '%' : '';
                activityTrend.className = 'metric-trend ' + (metrics.activity_trend > 0 ? 'trend-up' : 'trend-down');
            }
            
            // 更新总收入
            const revenue = document.querySelector('.metric-card:nth-child(4) .metric-value');
            const revenueTrend = document.querySelector('.metric-card:nth-child(4) .metric-trend');
            if (revenue) revenue.textContent = '¥' + (metrics.total_revenue ? Number(metrics.total_revenue).toFixed(2) : '0.00');
            if (revenueTrend) {
                revenueTrend.textContent = metrics.revenue_trend ? (metrics.revenue_trend > 0 ? '↑' : '↓') + ' ' + Math.abs(metrics.revenue_trend) + '%' : '';
                revenueTrend.className = 'metric-trend ' + (metrics.revenue_trend > 0 ? 'trend-up' : 'trend-down');
            }
            
            // 更新健康评分
            const healthScore = document.querySelector('.health-score-value');
            const healthLabel = document.querySelector('.health-score-label');
            const healthBar = document.querySelector('.health-score-bar');
            if (healthScore) healthScore.textContent = (metrics.health_score || 0) + '/100';
            if (healthLabel) {
                const score = metrics.health_score || 0;
                if (score >= 90) healthLabel.textContent = '优秀';
                else if (score >= 75) healthLabel.textContent = '良好';
                else if (score >= 60) healthLabel.textContent = '一般';
                else healthLabel.textContent = '需要改进';
            }
            if (healthBar) healthBar.style.width = (metrics.health_score || 0) + '%';
            
            // 更新优化建议
            const recommendationsList = document.querySelector('.recommendations-list');
            if (recommendationsList && metrics.recommendations) {
                recommendationsList.innerHTML = '';
                if (metrics.recommendations.length > 0) {
                    metrics.recommendations.forEach(rec => {
                        const item = document.createElement('div');
                        item.className = 'recommendation-item';
                        item.textContent = rec;
                        recommendationsList.appendChild(item);
                    });
                } else {
                    const item = document.createElement('div');
                    item.className = 'recommendation-item';
                    item.textContent = '暂无优化建议，业务运行状况良好。';
                    recommendationsList.appendChild(item);
                }
            }
        }
        
        // 更新图表
        function updateCharts(chartData) {
            // 更新卡片状态分布图
            if (chartData.cardStatus) {
                const ctx = document.getElementById('cardStatusChart').getContext('2d');
                if (window.cardStatusChart) {
                    window.cardStatusChart.destroy();
                }
                window.cardStatusChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: chartData.cardStatus.labels,
                        datasets: [{
                            label: '卡片状态',
                            data: chartData.cardStatus.data,
                            backgroundColor: [
                                '#48bb78',
                                '#ed8936',
                                '#f56565',
                                '#9f7aea',
                                '#38b2ac'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.parsed || 0;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        return `${label}: ${value} (${percentage}%)`;
                                    }
                                }
                            }
                        },
                        onClick: function(event, elements) {
                            if (elements.length > 0) {
                                const element = elements[0];
                                const label = this.data.labels[element.index];
                                const value = this.data.datasets[element.datasetIndex].data[element.index];
                                
                                // 触发图表联动
                                if (window.ChartDataManager) {
                                    const clickedData = {
                                        chartId: 'cardStatusChart',
                                        datasetIndex: element.datasetIndex,
                                        index: element.index,
                                        label: label,
                                        value: value
                                    };
                                    ChartDataManager.handleChartLink(clickedData, ['cardStatusChart', 'revenueChart'], 'filter');
                                }
                            }
                        }
                    }
                });
                
                // 注册到图表数据管理器
                if (window.ChartDataManager) {
                    ChartDataManager.registerChart('cardStatusChart', window.cardStatusChart, 'api/card_status_data.php');
                }
            }
            
            // 更新收入趋势图
            if (chartData.revenue) {
                const ctx = document.getElementById('revenueChart').getContext('2d');
                if (window.revenueChart) {
                    window.revenueChart.destroy();
                }
                window.revenueChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: chartData.revenue.labels,
                        datasets: [{
                            label: '收入',
                            data: chartData.revenue.data,
                            borderColor: '#4299e1',
                            backgroundColor: 'rgba(66, 153, 225, 0.1)',
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `收入: ¥${context.parsed.y.toLocaleString()}`;
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '¥' + value.toLocaleString();
                                    }
                                }
                            }
                        },
                        onClick: function(event, elements) {
                            if (elements.length > 0) {
                                const element = elements[0];
                                const label = this.data.labels[element.index];
                                const value = this.data.datasets[element.datasetIndex].data[element.index];
                                
                                // 触发图表联动
                                if (window.ChartDataManager) {
                                    const clickedData = {
                                        chartId: 'revenueChart',
                                        datasetIndex: element.datasetIndex,
                                        index: element.index,
                                        label: label,
                                        value: value
                                    };
                                    ChartDataManager.handleChartLink(clickedData, ['cardStatusChart', 'revenueChart'], 'highlight');
                                }
                            }
                        }
                    }
                });
                
                // 注册到图表数据管理器
                if (window.ChartDataManager) {
                    ChartDataManager.registerChart('revenueChart', window.revenueChart, 'api/revenue_data.php');
                }
            }
            
            // 初始化图表联动
            if (window.ChartDataManager) {
                ChartDataManager.linkCharts(['cardStatusChart', 'revenueChart'], 'filter');
                ChartDataManager.init();
            }
        }
        
        // 导出图表
        function exportChart(chartType) {
            // 使用新的图表数据管理器
            if (window.ChartDataManager) {
                const chartId = chartType === 'cardStatus' ? 'cardStatusChart' : 'revenueChart';
                ChartDataManager.showExportOptions(chartId);
            } else {
                // 回退到原有逻辑
                let chart;
                let filename;
                
                if (chartType === 'cardStatus') {
                    chart = window.cardStatusChart;
                    filename = '卡片状态分布_' + new Date().toLocaleDateString() + '.png';
                } else if (chartType === 'revenue') {
                    chart = window.revenueChart;
                    filename = '收入趋势_' + new Date().toLocaleDateString() + '.png';
                }
                
                if (chart) {
                    const url = chart.toBase64Image();
                    const link = document.createElement('a');
                    link.download = filename;
                    link.href = url;
                    link.click();
                    
                    showNotification('success', '图表已导出');
                }
            }
        }
        
        // 显示通知
        function showNotification(type, message) {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 6px;
                color: white;
                font-weight: 500;
                z-index: 9999;
                animation: slideIn 0.3s ease;
            `;
            
            if (type === 'success') {
                notification.style.backgroundColor = '#48bb78';
            } else if (type === 'error') {
                notification.style.backgroundColor = '#f56565';
            }
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
        }
        
        // 批量导出所有图表
        function exportAllCharts() {
            if (window.ChartDataManager) {
                ChartDataManager.showExportOptions('all');
            } else {
                showNotification('error', '图表数据管理器未初始化');
            }
        }
        
        // 切换图表联动状态
        let chartLinkageEnabled = false;
        function toggleChartLinkage() {
            chartLinkageEnabled = !chartLinkageEnabled;
            const linkageText = document.getElementById('linkageText');
            
            if (chartLinkageEnabled) {
                linkageText.textContent = '禁用图表联动';
                if (window.ChartDataManager) {
                    ChartDataManager.enableLinkage(['cardStatusChart', 'revenueChart']);
                }
                showNotification('success', '图表联动已启用');
            } else {
                linkageText.textContent = '启用图表联动';
                if (window.ChartDataManager) {
                    ChartDataManager.disableLinkage();
                }
                showNotification('info', '图表联动已禁用');
            }
        }
        
        // 重置图表过滤器
        function resetChartFilters() {
            if (window.ChartDataManager) {
                ChartDataManager.resetFilters();
                showNotification('success', '图表过滤器已重置');
            } else {
                showNotification('error', '图表数据管理器未初始化');
            }
        }
        
        // 初始化UI组件
        document.addEventListener('DOMContentLoaded', function() {
            // 初始化业务指标监控
            if (window.currentUser.role === 'admin' || window.currentUser.role === 'business_manager') {
                // 监听周期选择变化
                const periodSelect = document.getElementById('metricsPeriod');
                if (periodSelect) {
                    periodSelect.addEventListener('change', refreshBusinessMetrics);
                }
                
                // 初始化图表（使用我们的图表组件库）
                initDashboardCharts();
                
                // 监听时间范围变化
                document.getElementById('chartDateRange').addEventListener('change', function() {
                    initDashboardCharts();
                });
            }
            
            // 初始化工具提示
            const tooltips = document.querySelectorAll('[data-tooltip]');
            tooltips.forEach(element => {
                UIComponents.Tooltip.create(element, {
                    content: element.getAttribute('data-tooltip'),
                    position: 'top'
                });
            });

            // 添加加载动画
            UIComponents.Loading.show();

            // 模拟数据加载
            setTimeout(() => {
                UIComponents.Loading.hide();
                
                // 显示成功提示
                UIComponents.Notification.show({
                    type: 'success',
                    message: '仪表板数据加载完成',
                    duration: 3000
                });
            }, 1000);

            // 自动刷新数据（每5分钟）
            setInterval(() => {
                UIComponents.Loading.show('正在刷新数据...');
                setTimeout(() => {
                    location.reload();
                }, 1000);
            }, 300000);

            // 添加页面可见性检测，页面可见时才刷新
            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) {
                    // 页面变为可见时检查是否需要刷新
                    const lastRefresh = localStorage.getItem('dashboardLastRefresh');
                    const now = new Date().getTime();
                    
                    if (!lastRefresh || (now - parseInt(lastRefresh)) > 300000) {
                        UIComponents.Loading.show('正在刷新数据...');
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    }
                }
            });

            // 记录页面访问时间
            localStorage.setItem('dashboardLastRefresh', new Date().getTime());

            // 为统计卡片添加悬停效果
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                });
            });

            // 为列表项添加点击效果
            const listItems = document.querySelectorAll('.list-item');
            listItems.forEach(item => {
                item.addEventListener('click', function() {
                    // 添加点击动画
                    this.style.animation = 'pulse 0.3s ease';
                    setTimeout(() => {
                        this.style.animation = '';
                    }, 300);
                });
            });
        });
        
        // 初始化仪表盘图表
        function initDashboardCharts() {
            const dateRange = document.getElementById('chartDateRange').value;
            UIComponents.Loading.show('正在加载图表数据...');
            
            // 模拟数据（实际项目中应通过API获取）
            setTimeout(() => {
                // 卡片状态分布 - 饼图
                const cardStatusData = {
                    title: '卡片状态分布',
                    type: 'pie',
                    data: [
                        {name: '激活', value: <?php echo $stats['active_cards']; ?>, itemStyle: {color: '#4CAF50'}},
                        {name: '未激活', value: <?php echo $stats['inactive_cards']; ?>, itemStyle: {color: '#2196F3'}},
                        {name: '暂停', value: <?php echo $stats['suspended_cards']; ?>, itemStyle: {color: '#FF9800'}},
                        {name: '注销', value: <?php echo $stats['cancelled_cards']; ?>, itemStyle: {color: '#9E9E9E'}},
                        {name: '过期', value: <?php echo $stats['expired_cards']; ?>, itemStyle: {color: '#F44336'}}
                    ],
                    options: {
                        tooltip: {
                            trigger: 'item',
                            formatter: '{a} <br/>{b}: {c} ({d}%)'
                        },
                        legend: {
                            orient: 'vertical',
                            left: 'left'
                        }
                    }
                };
                
                // 收入趋势 - 折线图
                const revenueData = {
                    title: '收入趋势',
                    type: 'line',
                    xAxis: {
                        type: 'category',
                        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                    },
                    yAxis: {
                        type: 'value',
                        name: '收入（元）'
                    },
                    series: [{
                        data: [12000, 19000, 16000, 21000, 18000, 25000, 28000, 26000, 30000, 32000, 35000, 38000],
                        smooth: true,
                        itemStyle: {color: '#667eea'}
                    }],
                    options: {
                        tooltip: {
                            trigger: 'axis'
                        }
                    }
                };
                
                // 销售趋势 - 柱状图
                const salesData = {
                    title: '销售趋势',
                    type: 'bar',
                    xAxis: {
                        type: 'category',
                        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                    },
                    yAxis: {
                        type: 'value',
                        name: '订单量'
                    },
                    series: [{
                        data: [120, 190, 160, 210, 180, 250, 280, 260, 300, 320, 350, 380],
                        itemStyle: {color: '#764ba2'}
                    }],
                    options: {
                        tooltip: {
                            trigger: 'axis'
                        }
                    }
                };
                
                // 用户活跃度 - 折线图
                const userActivityData = {
                    title: '用户活跃度',
                    type: 'line',
                    xAxis: {
                        type: 'category',
                        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                    },
                    yAxis: {
                        type: 'value',
                        name: '活跃用户数'
                    },
                    series: [{
                        data: [80, 120, 100, 150, 130, 180, 200, 190, 220, 240, 260, 280],
                        smooth: true,
                        itemStyle: {color: '#4CAF50'}
                    }],
                    options: {
                        tooltip: {
                            trigger: 'axis'
                        }
                    }
                };
                
                // 使用图表组件库创建图表
                ChartComponents.createChart('cardStatusChart', cardStatusData);
                ChartComponents.createChart('revenueChart', revenueData);
                ChartComponents.createChart('salesChart', salesData);
                ChartComponents.createChart('userActivityChart', userActivityData);
                
                UIComponents.Loading.hide();
            }, 500);
        }
        
        // 导出图表
        function exportChart(chartId) {
            ChartComponents.exportChart(chartId);
        }
        
        // 批量导出所有图表
        function exportAllCharts() {
            ChartComponents.exportAllCharts();
        }
        
        // 切换图表联动
        let chartLinkageEnabled = false;
        function toggleChartLinkage() {
            chartLinkageEnabled = !chartLinkageEnabled;
            document.getElementById('linkageText').textContent = 
                chartLinkageEnabled ? '禁用图表联动' : '启用图表联动';
            ChartComponents.setChartLinkage(chartLinkageEnabled);
        }
        
        // 重置图表过滤器
        function resetChartFilters() {
            document.getElementById('chartDateRange').value = '30d';
            initDashboardCharts();
        }
        
        // 添加CSS动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            .charts-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            
            .chart-card {
                background: white;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            
            .chart-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 15px;
            }
            
            .chart-container {
                width: 100%;
                height: 300px;
            }
            
            .chart-filter-group {
                display: inline-flex;
                align-items: center;
                gap: 10px;
                margin-right: 20px;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>