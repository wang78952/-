#!/bin/bash

# Docker 容器启动脚本
# 用于初始化发卡系统 Docker 环境

set -e

echo "=== 发卡系统 Docker 启动脚本 ==="
echo "启动时间: $(date)"
echo ""

# 检查 Docker 和 Docker Compose
if ! command -v docker &> /dev/null; then
    echo "错误: Docker 未安装"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "错误: Docker Compose 未安装"
    exit 1
fi

# 创建必要的目录
echo "创建必要的目录..."
mkdir -p logs
mkdir -p uploads
mkdir -p backups
mkdir -p cache
mkdir -p monitoring/logs
mkdir -p monitoring/cache
mkdir -p monitoring/reports
mkdir -p docker/mysql
mkdir -p docker/redis
mkdir -p docker/nginx
mkdir -p docker/logstash
mkdir -p docker/elasticsearch

# 设置目录权限
echo "设置目录权限..."
chmod -R 777 logs
chmod -R 777 uploads
chmod -R 777 backups
chmod -R 777 cache
chmod -R 777 monitoring/logs
chmod -R 777 monitoring/cache
chmod -R 777 monitoring/reports

# 创建配置文件
echo "创建配置文件..."

# MySQL 配置
cat > docker/mysql/my.cnf << 'EOF'
[mysqld]
default-storage-engine=INNODB
innodb_buffer_pool_size=256M
innodb_log_file_size=64M
max_connections=200
max_allowed_packet=64M
sql_mode=STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci

[mysql]
default-character-set=utf8mb4

[client]
default-character-set=utf8mb4
EOF

# Redis 配置
cat > docker/redis/redis.conf << 'EOF'
bind 0.0.0.0
port 6379
timeout 300
save 900 1
save 300 10
save 60 10000
maxmemory 256mb
maxmemory-policy allkeys-lru
appendonly yes
appendfsync everysec
EOF

# Nginx 配置
cat > docker/nginx/default.conf << 'EOF'
upstream web_backend {
    server web:80;
}

server {
    listen 80;
    server_name localhost;
    
    # 重定向到 HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name localhost;
    
    # SSL 配置
    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    
    # 安全头
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
    
    # 日志
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    # 代理到后端
    location / {
        proxy_pass http://web_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # 超时设置
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # 静态文件缓存
    location ~* \.(css|js|png|jpg|jpeg|gif|ico|svg)$ {
        proxy_pass http://web_backend;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # API 代理
    location /api/ {
        proxy_pass http://web_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Logstash 配置
cat > docker/logstash/config/logstash.yml << 'EOF'
http.host: "0.0.0.0"
xpack.monitoring.elasticsearch.hosts: [ "http://elasticsearch:9200" ]
path.config: /usr/share/logstash/pipeline
EOF

cat > docker/logstash/pipeline/logstash.conf << 'EOF'
input {
  file {
    path => "/var/log/app/*.log"
    start_position => "beginning"
  }
}

filter {
  grok {
    match => { "message" => "%{TIMESTAMP_ISO8601:timestamp} %{LOGLEVEL:level} %{GREEDYDATA:message}" }
  }
  
  date {
    match => [ "timestamp", "ISO8601" ]
  }
}

output {
  elasticsearch {
    hosts => ["elasticsearch:9200"]
    index => "card-system-logs-%{+YYYY.MM.dd}"
  }
}
EOF

# Elasticsearch 配置
cat > docker/elasticsearch/elasticsearch.yml << 'EOF'
cluster.name: "card-system-cluster"
network.host: 0.0.0.0
discovery.type: single-node
xpack.security.enabled: false
xpack.monitoring.collection.enabled: true
EOF

# 创建环境配置文件
if [ ! -f .env ]; then
    echo "创建 .env 配置文件..."
    cat > .env << 'EOF'
# 应用环境
APP_ENV=production
APP_DEBUG=false
APP_URL=http://localhost:8080

# 数据库配置
DB_HOST=mysql
DB_PORT=3306
DB_NAME=card_system
DB_USER=card_user
DB_PASSWORD=secure_password_123

# Redis 配置
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=

# 加密密钥
ENCRYPTION_KEY=your_32_character_encryption_key_here

# 邮件配置
MAIL_HOST=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=noreply@example.com
MAIL_PASSWORD=your_mail_password
MAIL_FROM=noreply@example.com

# 监控配置
MONITORING_ENABLED=true
LOG_LEVEL=info

# 安全配置
SESSION_LIFETIME=3600
MAX_LOGIN_ATTEMPTS=5
LOCKOUT_TIME=900
EOF
fi

# 检查环境变量文件
if [ ! -f .env ]; then
    echo "错误: .env 文件不存在"
    exit 1
fi

# 构建和启动服务
echo "构建 Docker 镜像..."
docker-compose build

echo "启动服务..."
docker-compose up -d

# 等待服务启动
echo "等待服务启动..."
sleep 30

# 检查服务状态
echo "检查服务状态..."
docker-compose ps

# 初始化数据库
echo "初始化数据库..."
docker-compose exec web php scripts/install.php

# 安装监控模块
echo "安装监控模块..."
docker-compose exec web php monitoring/install.php

# 创建 SSL 证书（自签名）
echo "创建 SSL 证书..."
mkdir -p docker/nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout docker/nginx/ssl/key.pem \
    -out docker/nginx/ssl/cert.pem \
    -subj "/C=CN/ST=Beijing/L=Beijing/O=Card System/CN=localhost"

# 设置定时任务
echo "设置定时任务..."
docker-compose exec cron crontab -l

echo ""
echo "=== 部署完成 ==="
echo ""
echo "访问地址:"
echo "- 主应用: http://localhost:8080"
echo "- Nginx 代理: http://localhost (HTTPS)"
echo "- Kibana: http://localhost:5601"
echo "- Elasticsearch: http://localhost:9200"
echo ""
echo "管理命令:"
echo "- 查看日志: docker-compose logs -f [service_name]"
echo "- 重启服务: docker-compose restart [service_name]"
echo "- 停止服务: docker-compose down"
echo "- 更新服务: docker-compose pull && docker-compose up -d"
echo ""
echo "数据库连接信息:"
echo "- 主机: localhost:3306"
echo "- 数据库: card_system"
echo "- 用户名: card_user"
echo "- 密码: secure_password_123"
echo ""
echo "Redis 连接信息:"
echo "- 主机: localhost:6379"
echo "- 密码: (无)"
echo ""
echo "注意事项:"
echo "1. 请修改 .env 文件中的默认密码"
echo "2. 生产环境请使用真实的 SSL 证书"
echo "3. 定期备份数据库和重要文件"
echo "4. 监控系统资源使用情况"
echo ""
echo "部署成功！系统已启动并运行。"