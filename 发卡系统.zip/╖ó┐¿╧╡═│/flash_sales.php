<?php
/**
 * 秒杀活动展示页面
 * 面向普通用户的秒杀活动浏览和参与页面
 */
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/MarketingAndMembershipSystem.php';
require_once __DIR__ . '/includes/User.php';
require_once __DIR__ . '/includes/auth.php';

$db = Database::getInstance();
$marketingSystem = new MarketingAndMembershipSystem();
$currentUser = null;

// 检查用户是否登录
if (isLoggedIn()) {
    $currentUser = new User($_SESSION['user_id']);
}

// 获取当前激活的秒杀活动
$activeFlashSales = $marketingSystem->getActiveFlashSales();

// 获取即将开始的秒杀活动
$upcomingFlashSales = $marketingSystem->getUpcomingFlashSales();

// 获取热门秒杀商品
$popularFlashProducts = $marketingSystem->getPopularFlashSaleProducts();

// 处理秒杀请求
$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'flash_sale_purchase') {
    if (!isLoggedIn()) {
        $message = '请先登录后再参与秒杀！';
        $messageType = 'error';
    } else {
        $flashSaleId = $_POST['flash_sale_id'];
        $productId = $_POST['product_id'];
        $quantity = $_POST['quantity'] ?? 1;
        
        try {
            // 调用处理秒杀订单的方法
            $orderResult = $marketingSystem->processFlashSaleOrder($flashSaleId, $productId, $currentUser->id, $quantity);
            
            if ($orderResult && is_array($orderResult) && isset($orderResult['success']) && $orderResult['success']) {
                $message = '秒杀成功！订单已创建，即将跳转到订单详情页';
                // 延迟跳转到订单详情页
                echo "<script>setTimeout(function() { window.location.href = 'order.php?id={$orderResult['order_id']}'; }, 2000);</script>";
            } else {
                $message = $orderResult['error'] ?? '秒杀失败，请稍后重试';
                $messageType = 'error';
            }
        } catch (Exception $e) {
            $message = '秒杀过程中发生错误：' . $e->getMessage();
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>限时秒杀 - 发卡系统</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/echarts.min.js"></script>
    <style>
        body {
            background-color: #f5f5f5;
        }
        .flash-sale-header {
            background: linear-gradient(135deg, #ff6600 0%, #ff9933 100%);
            color: white;
            padding: 30px 0;
            margin-bottom: 30px;
            text-align: center;
        }
        .flash-sale-header h1 {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .flash-sale-header p {
            font-size: 18px;
            opacity: 0.9;
        }
        .section-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ff6600;
            color: #333;
        }
        .flash-sale-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .flash-sale-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }
        .flash-sale-card-header {
            padding: 15px;
            background-color: #fff8f0;
            border-bottom: 1px solid #ffe7ba;
        }
        .flash-sale-card-header h3 {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
            color: #d46b08;
        }
        .flash-sale-card-body {
            padding: 15px;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }
        .product-item {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            position: relative;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .product-item:hover {
            transform: translateY(-3px);
        }
        .product-item.upcoming {
            opacity: 0.7;
            background-color: #f5f5f5;
        }
        .product-image {
            height: 150px;
            overflow: hidden;
            background-color: #f8f9fa;
        }
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        .product-item:hover .product-image img {
            transform: scale(1.05);
        }
        .product-info {
            padding: 12px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .product-name {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 8px;
            color: #333;
            line-height: 1.4;
            min-height: 40px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .product-price {
            margin-bottom: 10px;
        }
        .flash-price {
            font-size: 20px;
            font-weight: bold;
            color: #ff4d4f;
        }
        .original-price {
            font-size: 14px;
            color: #999;
            text-decoration: line-through;
            margin-left: 5px;
        }
        .discount-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #ff4d4f;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .stock-info {
            margin-bottom: 10px;
            font-size: 12px;
            color: #666;
        }
        .progress-bar-container {
            height: 6px;
            background-color: #f0f0f0;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 5px;
        }
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #ff4d4f, #ff7a45);
            border-radius: 3px;
            transition: width 0.3s ease;
        }
        .purchase-section {
            margin-top: auto;
            padding-top: 10px;
            border-top: 1px solid #f0f0f0;
        }
        .countdown {
            margin-bottom: 10px;
            font-size: 14px;
            color: #ff6600;
            font-weight: bold;
        }
        .countdown-item {
            background-color: #333;
            color: white;
            padding: 2px 6px;
            border-radius: 3px;
            display: inline-block;
            margin: 0 2px;
        }
        .flash-sale-btn {
            width: 100%;
            padding: 8px;
            font-size: 14px;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-flash-purchase {
            background-color: #ff4d4f;
            color: white;
        }
        .btn-flash-purchase:hover {
            background-color: #ff7a45;
        }
        .btn-flash-purchase:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }
        .btn-waiting {
            background-color: #1890ff;
            color: white;
        }
        .time-indicator {
            display: inline-block;
            padding: 4px 8px;
            background-color: #e6f7ff;
            color: #1890ff;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            margin-left: 10px;
        }
        .category-tab {
            margin-bottom: 20px;
        }
        .category-tab .nav-tabs {
            border-bottom: 2px solid #ff6600;
        }
        .category-tab .nav-item .nav-link {
            color: #666;
            border: none;
            border-radius: 0;
            margin-right: 20px;
            font-weight: bold;
        }
        .category-tab .nav-item .nav-link.active {
            color: #ff6600;
            border-bottom: 3px solid #ff6600;
            background-color: transparent;
        }
        .login-prompt {
            padding: 20px;
            background-color: #fff2e8;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .login-prompt h4 {
            color: #fa541c;
            margin-bottom: 10px;
        }
        .login-prompt p {
            color: #fa8c16;
            margin-bottom: 15px;
        }
        .view-all-btn {
            text-align: center;
            margin-top: 10px;
        }
        .view-all-btn a {
            color: #ff6600;
            font-weight: bold;
            text-decoration: none;
        }
        .view-all-btn a:hover {
            text-decoration: underline;
        }
        .notification-badge {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 15px 20px;
            max-width: 300px;
            z-index: 1000;
            transform: translateX(120%);
            transition: transform 0.3s ease;
        }
        .notification-badge.show {
            transform: translateX(0);
        }
        .notification-badge.success {
            border-left: 4px solid #52c41a;
        }
        .notification-badge.error {
            border-left: 4px solid #ff4d4f;
        }
        .notification-content {
            font-size: 14px;
        }
        .flash-sale-detail {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .upcoming-card {
            position: relative;
            overflow: hidden;
        }
        .upcoming-card::after {
            content: "即将开始";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-15deg);
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 10px 40px;
            font-size: 18px;
            font-weight: bold;
            z-index: 10;
        }
        .purchase-form {
            margin-top: 10px;
        }
        .quantity-selector {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .quantity-btn {
            width: 28px;
            height: 28px;
            border: 1px solid #d9d9d9;
            background-color: white;
            cursor: pointer;
            font-size: 18px;
            line-height: 1;
        }
        .quantity-input {
            width: 50px;
            height: 28px;
            text-align: center;
            border: 1px solid #d9d9d9;
            border-left: none;
            border-right: none;
        }
    </style>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>限时秒杀 - 特惠卡密抢购</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/echarts.min.js"></script>
    <link rel="stylesheet" href="assets/css/flash_sales.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <!-- 通知提示 -->
    <div id="notification" class="notification-badge">
        <div id="notification-content" class="notification-content"></div>
    </div>
    
    <!-- 页面主体内容 -->
    <div class="container">
        <!-- 秒杀活动头部横幅 -->
        <div class="flash-sale-header">
            <h1><i class="fa fa-bolt"></i> 限时秒杀</h1>
            <p>每日精选特惠卡密，限时抢购，先到先得！</p>
        </div>
        
        <!-- 登录提示（未登录时显示） -->
        <?php if (!isLoggedIn()): ?>
            <div class="login-prompt">
                <h4><i class="fa fa-info-circle"></i> 温馨提示</h4>
                <p>登录后即可参与秒杀抢购，享受会员专属优惠！</p>
                <a href="login.php" class="btn btn-primary">立即登录</a>
                <a href="register.php" class="btn btn-success ml-2">免费注册</a>
            </div>
        <?php endif; ?>
        
        <!-- 消息提示 -->
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                <?php echo $message; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <!-- 秒杀活动分类标签 -->
        <div class="category-tab">
            <ul class="nav nav-tabs" id="flashSaleTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="current-tab" data-toggle="tab" href="#current" role="tab" aria-controls="current" aria-selected="true">
                        <i class="fa fa-bullhorn"></i> 正在秒杀
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="upcoming-tab" data-toggle="tab" href="#upcoming" role="tab" aria-controls="upcoming" aria-selected="false">
                        <i class="fa fa-clock-o"></i> 即将开始
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="popular-tab" data-toggle="tab" href="#popular" role="tab" aria-controls="popular" aria-selected="false">
                        <i class="fa fa-fire"></i> 热门秒杀
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- 秒杀活动内容区域 -->
        <div class="tab-content" id="flashSaleTabContent">
            <!-- 当前正在秒杀的活动 -->
            <div class="tab-pane fade show active" id="current" role="tabpanel" aria-labelledby="current-tab">
                <?php if (!empty($activeFlashSales)): ?>
                    <?php foreach ($activeFlashSales as $flashSale): ?>
                        <div class="flash-sale-card">
                            <div class="flash-sale-card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3><?php echo $flashSale['name']; ?></h3>
                                    <div class="d-flex align-items-center">
                                        <span class="countdown" data-end-time="<?php echo $flashSale['end_time']; ?>">
                                            <i class="fa fa-clock-o"></i> 距结束:
                                            <span class="countdown-item">00</span>天
                                            <span class="countdown-item">00</span>时
                                            <span class="countdown-item">00</span>分
                                            <span class="countdown-item">00</span>秒
                                        </span>
                                        <span class="time-indicator">进行中</span>
                                    </div>
                                </div>
                                <?php if (!empty($flashSale['description'])): ?>
                                    <p class="text-muted mt-2" style="font-size: 14px;"><?php echo $flashSale['description']; ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="flash-sale-card-body">
                                <div class="product-grid">
                                    <?php foreach ($flashSale['products'] as $product): ?>
                                        <div class="product-item">
                                            <div class="discount-badge"><?php echo $product['discount']; ?>%</div>
                                            <div class="product-image">
                                                <img src="<?php echo $product['image_url'] ?: 'assets/images/default-product.jpg'; ?>" alt="<?php echo $product['name']; ?>">
                                            </div>
                                            <div class="product-info">
                                                <h4 class="product-name"><?php echo $product['name']; ?></h4>
                                                <div class="product-price">
                                                    <span class="flash-price">¥<?php echo $product['flash_price']; ?></span>
                                                    <span class="original-price">¥<?php echo $product['original_price']; ?></span>
                                                </div>
                                                <div class="stock-info">
                                                    <div class="progress-bar-container">
                                                        <div class="progress-bar" style="width: <?php echo 100 - ($product['stock'] / ($product['stock'] + $product['sales_count']) * 100); ?>%"></div>
                                                    </div>
                                                    已售<?php echo $product['sales_count']; ?>件 | 库存<?php echo $product['stock']; ?>件
                                                </div>
                                                <div class="purchase-section">
                                                    <form class="purchase-form" method="POST">
                                                        <input type="hidden" name="action" value="flash_sale_purchase">
                                                        <input type="hidden" name="flash_sale_id" value="<?php echo $flashSale['id']; ?>">
                                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                        <div class="quantity-selector">
                                                            <button type="button" class="quantity-btn" onclick="updateQuantity(this, -1)">-</button>
                                                            <input type="number" name="quantity" value="1" min="1" max="<?php echo min($product['stock'], $product['max_per_user']); ?>" class="quantity-input">
                                                            <button type="button" class="quantity-btn" onclick="updateQuantity(this, 1)">+</button>
                                                        </div>
                                                        <button type="submit" class="flash-sale-btn btn-flash-purchase" <?php echo ($product['stock'] <= 0 || !isLoggedIn()) ? 'disabled' : ''; ?>>
                                                            <?php if (!isLoggedIn()): ?>
                                                                请先登录
                                                            <?php elseif ($product['stock'] <= 0): ?>
                                                                已抢光
                                                            <?php else: ?>
                                                                立即抢购
                                                            <?php endif; ?>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-info text-center p-4">
                        <i class="fa fa-info-circle fa-2x mb-2"></i>
                        <p>当前没有进行中的秒杀活动，请稍后再来查看！</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- 即将开始的秒杀活动 -->
            <div class="tab-pane fade" id="upcoming" role="tabpanel" aria-labelledby="upcoming-tab">
                <?php if (!empty($upcomingFlashSales)): ?>
                    <?php foreach ($upcomingFlashSales as $flashSale): ?>
                        <div class="flash-sale-card upcoming-card">
                            <div class="flash-sale-card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3><?php echo $flashSale['name']; ?></h3>
                                    <div class="d-flex align-items-center">
                                        <span class="countdown" data-start-time="<?php echo $flashSale['start_time']; ?>">
                                            <i class="fa fa-clock-o"></i> 距开始:
                                            <span class="countdown-item">00</span>天
                                            <span class="countdown-item">00</span>时
                                            <span class="countdown-item">00</span>分
                                            <span class="countdown-item">00</span>秒
                                        </span>
                                        <span class="time-indicator">即将开始</span>
                                    </div>
                                </div>
                                <?php if (!empty($flashSale['description'])): ?>
                                    <p class="text-muted mt-2" style="font-size: 14px;"><?php echo $flashSale['description']; ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="flash-sale-card-body">
                                <div class="product-grid">
                                    <?php foreach ($flashSale['products'] as $product): ?>
                                        <div class="product-item upcoming">
                                            <div class="discount-badge"><?php echo $product['discount']; ?>%</div>
                                            <div class="product-image">
                                                <img src="<?php echo $product['image_url'] ?: 'assets/images/default-product.jpg'; ?>" alt="<?php echo $product['name']; ?>">
                                            </div>
                                            <div class="product-info">
                                                <h4 class="product-name"><?php echo $product['name']; ?></h4>
                                                <div class="product-price">
                                                    <span class="flash-price">¥<?php echo $product['flash_price']; ?></span>
                                                    <span class="original-price">¥<?php echo $product['original_price']; ?></span>
                                                </div>
                                                <div class="stock-info">
                                                    秒杀库存: <?php echo $product['stock']; ?>件
                                                </div>
                                                <div class="purchase-section">
                                                    <button class="flash-sale-btn btn-waiting" disabled>
                                                        敬请期待
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-info text-center p-4">
                        <i class="fa fa-info-circle fa-2x mb-2"></i>
                        <p>暂无即将开始的秒杀活动</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- 热门秒杀商品 -->
            <div class="tab-pane fade" id="popular" role="tabpanel" aria-labelledby="popular-tab">
                <div class="product-grid">
                    <?php if (!empty($popularFlashProducts)): ?>
                        <?php foreach ($popularFlashProducts as $product): ?>
                            <div class="product-item">
                                <div class="discount-badge"><?php echo $product['discount']; ?>%</div>
                                <div class="product-image">
                                    <img src="<?php echo $product['image_url'] ?: 'assets/images/default-product.jpg'; ?>" alt="<?php echo $product['name']; ?>">
                                </div>
                                <div class="product-info">
                                    <h4 class="product-name"><?php echo $product['name']; ?></h4>
                                    <div class="product-price">
                                        <span class="flash-price">¥<?php echo $product['flash_price']; ?></span>
                                        <span class="original-price">¥<?php echo $product['original_price']; ?></span>
                                    </div>
                                    <div class="stock-info">
                                        <div class="progress-bar-container">
                                            <div class="progress-bar" style="width: <?php echo 100 - ($product['stock'] / ($product['stock'] + $product['sales_count']) * 100); ?>%"></div>
                                        </div>
                                        已售<?php echo $product['sales_count']; ?>件 | 库存<?php echo $product['stock']; ?>件
                                    </div>
                                    <div class="purchase-section">
                                        <form class="purchase-form" method="POST">
                                            <input type="hidden" name="action" value="flash_sale_purchase">
                                            <input type="hidden" name="flash_sale_id" value="<?php echo $product['flash_sale_id']; ?>">
                                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                            <button type="submit" class="flash-sale-btn btn-flash-purchase" <?php echo ($product['stock'] <= 0 || !isLoggedIn()) ? 'disabled' : ''; ?>>
                                                <?php if (!isLoggedIn()): ?>
                                                    请先登录
                                                <?php elseif ($product['stock'] <= 0): ?>
                                                    已抢光
                                                <?php else: ?>
                                                    立即抢购
                                                <?php endif; ?>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="alert alert-info text-center p-4 w-100">
                            <i class="fa fa-info-circle fa-2x mb-2"></i>
                            <p>暂无热门秒杀商品</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- 秒杀活动规则说明 -->
        <div class="flash-sale-detail">
            <h3><i class="fa fa-info-circle"></i> 秒杀活动规则</h3>
            <div class="row">
                <div class="col-md-6">
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fa fa-check-circle text-success"></i> 秒杀活动期间，参与秒杀的商品价格为秒杀价，不与其他优惠叠加</li>
                        <li class="mb-2"><i class="fa fa-check-circle text-success"></i> 每个秒杀商品每位用户有限购数量，超出限购数量将无法下单</li>
                        <li class="mb-2"><i class="fa fa-check-circle text-success"></i> 秒杀商品库存有限，先到先得，抢完即止</li>
                        <li class="mb-2"><i class="fa fa-check-circle text-success"></i> 成功抢购后，请在15分钟内完成支付，否则订单将自动取消</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fa fa-exclamation-circle text-warning"></i> 秒杀商品不支持无理由退款，请谨慎下单</li>
                        <li class="mb-2"><i class="fa fa-exclamation-circle text-warning"></i> 如遇系统故障导致的秒杀异常，我们有权取消相关订单并退还支付金额</li>
                        <li class="mb-2"><i class="fa fa-exclamation-circle text-warning"></i> 为保证公平性，系统会对恶意刷单行为进行监控和处理</li>
                        <li class="mb-2"><i class="fa fa-exclamation-circle text-warning"></i> 本活动最终解释权归发卡系统所有</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <script>
        // 页面加载完成后初始化倒计时
        $(document).ready(function() {
            // 初始化所有倒计时器
            initCountdowns();
            
            // 处理数量选择器
            $('.quantity-btn').click(function() {
                const input = $(this).siblings('.quantity-input');
                const currentVal = parseInt(input.val());
                const min = parseInt(input.attr('min'));
                const max = parseInt(input.attr('max'));
                
                if ($(this).text() === '+' && currentVal < max) {
                    input.val(currentVal + 1);
                } else if ($(this).text() === '-' && currentVal > min) {
                    input.val(currentVal - 1);
                }
            });
            
            // 处理秒杀购买表单提交
            $('.purchase-form').submit(function(e) {
                if (!<?php echo isLoggedIn() ? 'true' : 'false'; ?>) {
                    e.preventDefault();
                    showNotification('请先登录后再参与秒杀！', 'error');
                    return;
                }
                
                const form = $(this);
                const submitBtn = form.find('.flash-sale-btn');
                const originalText = submitBtn.html();
                
                // 禁用提交按钮防止重复提交
                submitBtn.prop('disabled', true);
                submitBtn.html('<i class="fa fa-spinner fa-spin"></i> 处理中...');
                
                // 模拟提交延迟
                setTimeout(function() {
                    submitBtn.prop('disabled', false);
                    submitBtn.html(originalText);
                }, 2000);
            });
        });
        
        // 更新数量
        function updateQuantity(btn, change) {
            const input = btn.parentElement.querySelector('.quantity-input');
            const currentVal = parseInt(input.value);
            const min = parseInt(input.min);
            const max = parseInt(input.max);
            const newValue = currentVal + change;
            
            if (newValue >= min && newValue <= max) {
                input.value = newValue;
            }
        }
        
        // 初始化所有倒计时器
        function initCountdowns() {
            const countdownElements = document.querySelectorAll('.countdown');
            countdownElements.forEach(element => {
                const endTime = element.dataset.endTime;
                const startTime = element.dataset.startTime;
                
                if (endTime) {
                    // 倒计时到结束时间
                    startCountdown(element, endTime, 'end');
                } else if (startTime) {
                    // 倒计时到开始时间
                    startCountdown(element, startTime, 'start');
                }
            });
        }
        
        // 开始倒计时
        function startCountdown(element, targetTime, type) {
            const targetDate = new Date(targetTime);
            
            function updateCountdown() {
                const now = new Date();
                const diff = type === 'end' ? targetDate - now : targetDate - now;
                
                if (diff <= 0) {
                    if (type === 'end') {
                        element.innerHTML = '<i class="fa fa-check-circle"></i> 已结束';
                        // 可以在这里添加页面刷新逻辑
                        // location.reload();
                    } else {
                        element.innerHTML = '<i class="fa fa-bullhorn"></i> 已开始';
                        // 可以在这里添加页面刷新逻辑
                        // location.reload();
                    }
                    return;
                }
                
                const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((diff % (1000 * 60)) / 1000);
                
                const countdownItems = element.querySelectorAll('.countdown-item');
                if (countdownItems.length >= 4) {
                    countdownItems[0].textContent = String(days).padStart(2, '0');
                    countdownItems[1].textContent = String(hours).padStart(2, '0');
                    countdownItems[2].textContent = String(minutes).padStart(2, '0');
                    countdownItems[3].textContent = String(seconds).padStart(2, '0');
                }
            }
            
            // 立即更新一次
            updateCountdown();
            
            // 设置定时器每秒更新
            setInterval(updateCountdown, 1000);
        }
        
        // 显示通知
        function showNotification(message, type = 'success') {
            const notification = document.getElementById('notification');
            const notificationContent = document.getElementById('notification-content');
            
            // 设置通知内容和类型
            notificationContent.textContent = message;
            notification.className = 'notification-badge ' + type;
            
            // 显示通知
            notification.classList.add('show');
            
            // 3秒后隐藏通知
            setTimeout(function() {
                notification.classList.remove('show');
            }, 3000);
        }
        
        // 刷新库存信息（模拟实时更新）
        function refreshStockInfo() {
            // 这里可以添加AJAX请求获取最新库存信息
            // 为了演示，我们只是随机更新一些进度条
            const progressBars = document.querySelectorAll('.progress-bar');
            progressBars.forEach(bar => {
                const currentWidth = parseFloat(bar.style.width);
                const newWidth = Math.min(100, Math.max(0, currentWidth + (Math.random() - 0.5) * 2));
                bar.style.width = newWidth + '%';
            });
        }
        
        // 每10秒刷新一次库存信息
        setInterval(refreshStockInfo, 10000);
    </script>
</body>
</html>