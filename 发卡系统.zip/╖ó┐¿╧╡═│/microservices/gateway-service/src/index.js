const express = require('express');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

// 加载环境变量
const envPath = path.resolve(__dirname, '../../.env');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
  console.log(`加载环境变量文件: ${envPath}`);
} else {
  console.warn(`未找到 .env 文件: ${envPath}`);
}

// 导入配置和工具
const logger = require('./utils/logger');
const { gatewayConfig } = require('./config/gatewayConfig');

// 导入中间件
const securityMiddleware = require('./middleware/securityMiddleware');
const loggingMiddleware = require('./middleware/loggingMiddleware');
const rateLimitMiddleware = require('./middleware/rateLimitMiddleware');
const proxyMiddleware = require('./middleware/proxyMiddleware');
const authMiddleware = require('./middleware/authMiddleware');

// 导入路由
const { createGatewayRoutes } = require('./routes/gatewayRoutes');

/**
 * 服务网关主入口
 * 配置Express应用、中间件、路由和HTTP/HTTPS服务器
 */

// 初始化Express应用
const app = express();

// 设置应用本地变量
app.locals.startTime = new Date();
app.locals.requestCount = 0;
app.locals.errorCount = 0;
app.locals.requestCountLastMinute = 0;
app.locals.errorCountLastMinute = 0;

/**
 * 启动服务网关
 */
async function startGateway() {
  try {
    logger.info('正在启动服务网关...', {
      version: process.env.npm_package_version || 'unknown',
      environment: process.env.NODE_ENV || 'development',
      service: 'gateway-service'
    });

    // 配置基础中间件
    configureBaseMiddleware(app);

    // 配置安全中间件
    configureSecurityMiddleware(app);

    // 配置日志中间件
    configureLoggingMiddleware(app);

    // 配置速率限制中间件
    configureRateLimitMiddleware(app);

    // 配置代理中间件
    await configureProxyMiddleware(app);

    // 配置路由
    configureRoutes(app);

    // 配置错误处理中间件
    configureErrorHandlers(app);

    // 启动HTTP/HTTPS服务器
    const server = await startServer(app);

    // 设置服务器关闭处理
    setupServerShutdown(server);

    // 启动监控（如果有）
    startMonitoring(app);

    logger.info('服务网关启动成功！', {
      version: process.env.npm_package_version || 'unknown',
      environment: process.env.NODE_ENV || 'development',
      service: 'gateway-service'
    });

    return server;
  } catch (error) {
    logger.error('服务网关启动失败', {
      error: error.message,
      stack: error.stack,
      service: 'gateway-service'
    });
    console.error('服务网关启动失败:', error);
    process.exit(1);
  }
}

/**
 * 配置基础中间件
 */
function configureBaseMiddleware(app) {
  // 解析JSON请求体
  app.use(express.json({ 
    limit: gatewayConfig.requestLimits?.jsonLimit || '1mb',
    strict: true,
    type: ['application/json', 'application/vnd.api+json']
  }));

  // 解析URL编码的请求体
  app.use(express.urlencoded({ 
    extended: true, 
    limit: gatewayConfig.requestLimits?.urlEncodedLimit || '1mb'
  }));

  // 静态文件服务（如果需要）
  if (gatewayConfig.staticFiles?.enabled) {
    const staticPath = gatewayConfig.staticFiles.path || path.join(__dirname, '../public');
    const mountPath = gatewayConfig.staticFiles.mountPath || '/static';
    
    logger.info(`配置静态文件服务`, {
      path: staticPath,
      mount_path: mountPath,
      service: 'gateway-service'
    });
    
    app.use(mountPath, express.static(staticPath));
  }

  // 请求超时处理
  if (gatewayConfig.requestLimits?.timeout) {
    app.use((req, res, next) => {
      req.setTimeout(gatewayConfig.requestLimits.timeout, () => {
        const err = new Error('请求超时');
        err.statusCode = 408;
        next(err);
      });
      next();
    });
  }

  logger.info('基础中间件配置完成', {
    service: 'gateway-service'
  });
}

/**
 * 配置安全中间件
 */
function configureSecurityMiddleware(app) {
  // 应用安全中间件
  securityMiddleware.setupSecurity(app);
  
  logger.info('安全中间件配置完成', {
    service: 'gateway-service'
  });
}

/**
 * 配置日志中间件
 */
function configureLoggingMiddleware(app) {
  // 应用请求日志中间件
  loggingMiddleware.setupRequestLogging(app);
  
  // 配置访问日志
  if (gatewayConfig.logging?.accessLog) {
    loggingMiddleware.setupAccessLog(app);
  }
  
  logger.info('日志中间件配置完成', {
    service: 'gateway-service'
  });
}

/**
 * 配置速率限制中间件
 */
function configureRateLimitMiddleware(app) {
  // 应用全局速率限制
  rateLimitMiddleware.setupGlobalRateLimit(app);
  
  // 配置API速率限制
  if (gatewayConfig.rateLimits?.api) {
    rateLimitMiddleware.setupApiRateLimit(app);
  }
  
  // 配置认证速率限制
  if (gatewayConfig.rateLimits?.auth) {
    rateLimitMiddleware.setupAuthRateLimit(app);
  }
  
  logger.info('速率限制中间件配置完成', {
    service: 'gateway-service'
  });
}

/**
 * 配置代理中间件
 */
async function configureProxyMiddleware(app) {
  try {
    // 为每个微服务设置代理
    await proxyMiddleware.setupAllMicroserviceProxies(app);
    
    logger.info('代理中间件配置完成', {
      service_count: Object.keys(gatewayConfig.microservices).length,
      service: 'gateway-service'
    });
  } catch (error) {
    logger.error('代理中间件配置失败', {
      error: error.message,
      service: 'gateway-service'
    });
    throw error;
  }
}

/**
 * 配置路由
 */
function configureRoutes(app) {
  // 创建和配置所有网关路由
  createGatewayRoutes(app);
  
  logger.info('路由配置完成', {
    service: 'gateway-service'
  });
}

/**
 * 配置错误处理中间件
 */
function configureErrorHandlers(app) {
  // 统一错误处理中间件
  app.use((err, req, res, next) => {
    // 增加错误计数
    app.locals.errorCount++;
    app.locals.errorCountLastMinute++;

    // 记录错误
    logger.error('请求处理错误', {
      error: err.message,
      stack: err.stack,
      path: req.path,
      method: req.method,
      status: err.statusCode || 500,
      ip: req.ip,
      service: 'gateway-service'
    });

    // 检查响应是否已发送
    if (res.headersSent) {
      return next(err);
    }

    // 构建错误响应
    const errorResponse = {
      error: err.name || 'Internal Server Error',
      message: err.message || '服务器内部错误',
      code: err.code || 'INTERNAL_ERROR',
      status: err.statusCode || 500,
      timestamp: new Date().toISOString()
    };

    // 根据环境决定是否包含错误详情
    if (process.env.NODE_ENV !== 'production' && err.stack) {
      errorResponse.stack = err.stack.split('\n');
    }

    // 发送错误响应
    res.status(err.statusCode || 500).json(errorResponse);
  });

  logger.info('错误处理中间件配置完成', {
    service: 'gateway-service'
  });
}

/**
 * 启动HTTP/HTTPS服务器
 */
async function startServer(app) {
  let server;
  const port = process.env.PORT || gatewayConfig.server?.port || 3000;
  const host = process.env.HOST || gatewayConfig.server?.host || '0.0.0.0';

  // 检查是否启用HTTPS
  if (gatewayConfig.server?.https?.enabled) {
    try {
      // 加载HTTPS证书
      const sslOptions = await loadHttpsOptions(gatewayConfig.server.https);
      
      // 创建HTTPS服务器
      server = https.createServer(sslOptions, app);
      
      logger.info('配置HTTPS服务器', {
        host,
        port,
        https: true,
        service: 'gateway-service'
      });
    } catch (error) {
      logger.error('HTTPS配置失败，将使用HTTP', {
        error: error.message,
        service: 'gateway-service'
      });
      // 如果HTTPS配置失败，回退到HTTP
      server = http.createServer(app);
    }
  } else {
    // 创建HTTP服务器
    server = http.createServer(app);
    
    logger.info('配置HTTP服务器', {
      host,
      port,
      https: false,
      service: 'gateway-service'
    });
  }

  // 启动服务器
  await new Promise((resolve, reject) => {
    server.listen(port, host, (error) => {
      if (error) {
        reject(error);
      } else {
        logger.info(`服务网关正在监听 ${host}:${port}`, {
          host,
          port,
          service: 'gateway-service'
        });
        resolve(server);
      }
    });

    // 处理服务器错误
    server.on('error', (error) => {
      logger.error('服务器启动错误', {
        error: error.message,
        stack: error.stack,
        service: 'gateway-service'
      });
      reject(error);
    });
  });

  return server;
}

/**
 * 加载HTTPS选项
 */
async function loadHttpsOptions(httpsConfig) {
  const sslOptions = {};

  // 加载证书文件
  if (httpsConfig.keyPath) {
    sslOptions.key = fs.readFileSync(httpsConfig.keyPath);
  }
  
  if (httpsConfig.certPath) {
    sslOptions.cert = fs.readFileSync(httpsConfig.certPath);
  }
  
  // 加载CA证书（如果有）
  if (httpsConfig.caPath) {
    sslOptions.ca = fs.readFileSync(httpsConfig.caPath);
  }
  
  // 设置SSL协议版本（如果有）
  if (httpsConfig.protocols) {
    sslOptions.secureProtocol = httpsConfig.protocols;
  }
  
  // 设置密码套件（如果有）
  if (httpsConfig.ciphers) {
    sslOptions.ciphers = httpsConfig.ciphers;
  }
  
  return sslOptions;
}

/**
 * 设置服务器关闭处理
 */
function setupServerShutdown(server) {
  // 处理SIGTERM信号
  process.on('SIGTERM', () => {
    logger.info('收到SIGTERM信号，正在关闭服务器...', {
      service: 'gateway-service'
    });
    shutdownServer(server);
  });

  // 处理SIGINT信号（Ctrl+C）
  process.on('SIGINT', () => {
    logger.info('收到SIGINT信号，正在关闭服务器...', {
      service: 'gateway-service'
    });
    shutdownServer(server);
  });

  // 处理未捕获的异常
  process.on('uncaughtException', (error) => {
    logger.error('未捕获的异常', {
      error: error.message,
      stack: error.stack,
      service: 'gateway-service'
    });
    console.error('未捕获的异常:', error);
    // 等待一段时间后关闭服务器
    setTimeout(() => shutdownServer(server), 1000);
  });

  // 处理未处理的Promise拒绝
  process.on('unhandledRejection', (reason, promise) => {
    logger.error('未处理的Promise拒绝', {
      reason: reason?.message || reason,
      promise: promise.toString(),
      service: 'gateway-service'
    });
    console.error('未处理的Promise拒绝:', reason);
  });
}

/**
 * 关闭服务器
 */
function shutdownServer(server) {
  try {
    logger.info('开始关闭服务器...', {
      service: 'gateway-service'
    });

    // 停止接受新连接
    server.close(async () => {
      logger.info('服务器已关闭', {
        service: 'gateway-service'
      });
      
      // 关闭其他资源（如果有）
      await cleanupResources();
      
      // 退出进程
      process.exit(0);
    });

    // 设置强制关闭超时
    setTimeout(() => {
      logger.error('服务器关闭超时，强制退出', {
        service: 'gateway-service'
      });
      process.exit(1);
    }, 10000); // 10秒超时
  } catch (error) {
    logger.error('服务器关闭错误', {
      error: error.message,
      service: 'gateway-service'
    });
    process.exit(1);
  }
}

/**
 * 清理资源
 */
async function cleanupResources() {
  try {
    logger.info('正在清理资源...', {
      service: 'gateway-service'
    });

    // 这里可以添加资源清理代码
    // 例如关闭数据库连接、清理缓存等
    
    logger.info('资源清理完成', {
      service: 'gateway-service'
    });
  } catch (error) {
    logger.error('资源清理错误', {
      error: error.message,
      service: 'gateway-service'
    });
  }
}

/**
 * 启动监控
 */
function startMonitoring(app) {
  // 如果启用了请求计数器
  if (gatewayConfig.monitoring?.requestCount) {
    // 设置请求计数中间件
    app.use((req, res, next) => {
      app.locals.requestCount++;
      app.locals.requestCountLastMinute++;
      next();
    });

    // 每分钟重置计数器
    setInterval(() => {
      app.locals.requestCountLastMinute = 0;
      app.locals.errorCountLastMinute = 0;
    }, 60000);
  }

  logger.info('监控已启动', {
    service: 'gateway-service'
  });
}

/**
 * 导出主函数和应用实例
 */
module.exports = {
  startGateway,
  app
};

/**
 * 如果直接运行此文件，则启动服务网关
 */
if (require.main === module) {
  startGateway().catch(error => {
    console.error('服务网关启动失败:', error);
    process.exit(1);
  });
}