const Joi = require('joi');
const logger = require('../utils/logger');

// 确保环境变量已加载
if (!process.env.NODE_ENV) {
  require('dotenv').config();
}

/**
 * 网关配置管理
 * 包含所有微服务的路由映射、代理配置、安全配置等
 */

// 服务配置模式验证
const serviceConfigSchema = Joi.object({
  url: Joi.string().uri().required(),
  timeout: Joi.number().min(1000).max(60000).default(30000),
  retry: Joi.object({
    enabled: Joi.boolean().default(false),
    maxAttempts: Joi.number().min(1).max(10).default(3),
    delay: Joi.number().min(100).max(10000).default(1000)
  }).default({ enabled: false, maxAttempts: 3, delay: 1000 }),
  circuitBreaker: Joi.object({
    enabled: Joi.boolean().default(false),
    failureThreshold: Joi.number().min(10).max(100).default(50),
    resetTimeout: Joi.number().min(1000).max(60000).default(30000)
  }).default({ enabled: false, failureThreshold: 50, resetTimeout: 30000 })
});

// 路由配置模式验证
const routeConfigSchema = Joi.object({
  path: Joi.string().required(),
  target: Joi.string().required(),
  methods: Joi.array().items(Joi.string()).default(['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']),
  auth: Joi.boolean().default(true),
  rateLimit: Joi.boolean().default(true),
  transformRequest: Joi.boolean().default(false),
  transformResponse: Joi.boolean().default(false),
  stripPath: Joi.boolean().default(true),
  sensitiveHeaders: Joi.array().items(Joi.string()).default([]),
  errorHandler: Joi.function().optional()
});

/**
 * 微服务配置
 */
const services = {
  auth: {
    url: process.env.AUTH_SERVICE_URL || 'http://localhost:3000',
    timeout: parseInt(process.env.AUTH_SERVICE_TIMEOUT || 30000),
    retry: {
      enabled: process.env.RETRY_ENABLED === 'true',
      maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS || 3),
      delay: parseInt(process.env.RETRY_DELAY || 1000)
    }
  },
  core: {
    url: process.env.CORE_SERVICE_URL || 'http://localhost:3001',
    timeout: parseInt(process.env.CORE_SERVICE_TIMEOUT || 30000),
    retry: {
      enabled: process.env.RETRY_ENABLED === 'true',
      maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS || 3),
      delay: parseInt(process.env.RETRY_DELAY || 1000)
    }
  },
  order: {
    url: process.env.ORDER_SERVICE_URL || 'http://localhost:3002',
    timeout: parseInt(process.env.ORDER_SERVICE_TIMEOUT || 30000),
    retry: {
      enabled: process.env.RETRY_ENABLED === 'true',
      maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS || 3),
      delay: parseInt(process.env.RETRY_DELAY || 1000)
    }
  },
  payment: {
    url: process.env.PAYMENT_SERVICE_URL || 'http://localhost:3003',
    timeout: parseInt(process.env.PAYMENT_SERVICE_TIMEOUT || 30000),
    retry: {
      enabled: process.env.RETRY_ENABLED === 'true',
      maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS || 3),
      delay: parseInt(process.env.RETRY_DELAY || 1000)
    }
  }
};

/**
 * 路由配置 - 将请求映射到对应的微服务
 */
const routes = [
  // 认证服务路由
  {
    path: '/api/v1/auth/**',
    target: 'auth',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: false, // 认证服务本身不需要认证
    rateLimit: true,
    stripPath: true,
    sensitiveHeaders: ['Authorization']
  },
  
  // 核心服务路由
  {
    path: '/api/v1/products/**',
    target: 'core',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: true,
    rateLimit: true,
    stripPath: true
  },
  {
    path: '/api/v1/card-templates/**',
    target: 'core',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: true,
    rateLimit: true,
    stripPath: true
  },
  {
    path: '/api/v1/categories/**',
    target: 'core',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: true,
    rateLimit: true,
    stripPath: true
  },
  
  // 订单服务路由
  {
    path: '/api/v1/orders/**',
    target: 'order',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: true,
    rateLimit: true,
    stripPath: true
  },
  {
    path: '/api/v1/cart/**',
    target: 'order',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: true,
    rateLimit: true,
    stripPath: true
  },
  
  // 支付服务路由
  {
    path: '/api/v1/payments/**',
    target: 'payment',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: true,
    rateLimit: true,
    stripPath: true,
    sensitiveHeaders: ['Authorization', 'X-Internal-Key']
  },
  {
    path: '/api/v1/payments/callback/**',
    target: 'payment',
    methods: ['GET', 'POST', 'OPTIONS'],
    auth: false, // 支付回调不需要认证
    rateLimit: false,
    stripPath: true,
    sensitiveHeaders: []
  },
  
  // 内部服务通信路由
  {
    path: '/api/v1/internal/**',
    target: 'core',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    auth: false, // 内部通信使用特殊认证
    rateLimit: false,
    stripPath: true,
    sensitiveHeaders: ['X-Internal-Key']
  }
];

/**
 * 网关配置
 */
const gatewayConfig = {
  // 基本配置
  port: parseInt(process.env.PORT || 8000),
  env: process.env.NODE_ENV || 'development',
  apiVersion: process.env.API_VERSION || 'v1',
  
  // 安全配置
  security: {
    rateLimit: process.env.ENABLE_RATE_LIMIT === 'true',
    cors: process.env.ENABLE_CORS === 'true',
    compression: process.env.ENABLE_COMPRESSION === 'true',
    helmet: true,
    requestSizeLimit: process.env.MAX_REQUEST_BODY_SIZE || '10mb',
    
    // 速率限制配置
    rateLimitConfig: {
      windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000),
      max: parseInt(process.env.RATE_LIMIT_MAX || 100),
      message: process.env.RATE_LIMIT_MESSAGE || '操作过于频繁，请稍后再试',
      standardHeaders: true,
      legacyHeaders: false
    },
    
    // CORS配置
    corsConfig: {
      origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : '*',
      methods: process.env.CORS_METHODS ? process.env.CORS_METHODS.split(',') : ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: process.env.ALLOWED_HEADERS ? process.env.ALLOWED_HEADERS.split(',') : ['Content-Type', 'Authorization', 'X-Requested-With', 'X-API-Version'],
      credentials: process.env.ALLOW_CREDENTIALS === 'true',
      optionsSuccessStatus: 204
    }
  },
  
  // 代理配置
  proxy: {
    timeout: parseInt(process.env.PROXY_TIMEOUT || 30000),
    changeOrigin: process.env.PROXY_CHANGE_ORIGIN === 'true',
    prependPath: process.env.PROXY_PREPEND_PATH === 'true',
    followRedirects: false,
    logLevel: 'error'
  },
  
  // 缓存配置
  cache: {
    enabled: false,
    ttl: parseInt(process.env.CACHE_TTL || 300),
    maxKeys: parseInt(process.env.CACHE_MAX_KEYS || 1000)
  },
  
  // JWT配置
  jwt: {
    secret: process.env.JWT_SECRET || 'payment_system_gateway_secret_key_2024',
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
    algorithm: process.env.JWT_ALGORITHM || 'HS256',
    excludedPaths: process.env.AUTH_EXCLUDED_PATHS ? process.env.AUTH_EXCLUDED_PATHS.split(',') : ['/health', '/api/v1/public', '/api/v1/status']
  },
  
  // 监控配置
  monitoring: {
    enabled: process.env.ENABLE_METRICS === 'true',
    endpoint: process.env.METRICS_ENDPOINT || '/metrics'
  },
  
  // 重试配置
  retry: {
    enabled: process.env.RETRY_ENABLED === 'true',
    maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS || 3),
    delay: parseInt(process.env.RETRY_DELAY || 1000)
  },
  
  // 错误处理配置
  error: {
    showDetails: process.env.NODE_ENV === 'development',
    pageEnabled: process.env.ERROR_PAGE_ENABLED === 'true',
    pagePath: process.env.ERROR_PAGE_PATH || '/error'
  },
  
  // 请求/响应配置
  request: {
    timeout: parseInt(process.env.REQUEST_TIMEOUT || 30000),
    enableLogging: process.env.ENABLE_REQUEST_LOGGING === 'true',
    userAgent: 'Gateway-Service/1.0.0',
    headers: {
      'x-gateway': 'gateway-service',
      'x-api-version': process.env.API_VERSION || 'v1'
    }
  }
};

/**
 * 验证服务配置
 */
function validateServiceConfigs() {
  const invalidServices = [];
  
  Object.entries(services).forEach(([name, config]) => {
    const { error } = serviceConfigSchema.validate(config);
    if (error) {
      invalidServices.push({
        name,
        errors: error.details.map(d => d.message)
      });
    }
  });
  
  if (invalidServices.length > 0) {
    logger.error('Invalid service configurations', { invalidServices });
    throw new Error(`Invalid service configurations: ${invalidServices.map(s => s.name).join(', ')}`);
  }
  
  logger.info('All service configurations are valid');
  return true;
}

/**
 * 验证路由配置
 */
function validateRouteConfigs() {
  const invalidRoutes = [];
  
  routes.forEach((route, index) => {
    const { error } = routeConfigSchema.validate(route);
    if (error) {
      invalidRoutes.push({
        index,
        path: route.path,
        errors: error.details.map(d => d.message)
      });
    }
  });
  
  if (invalidRoutes.length > 0) {
    logger.error('Invalid route configurations', { invalidRoutes });
    throw new Error(`Invalid route configurations found in ${invalidRoutes.length} routes`);
  }
  
  logger.info('All route configurations are valid');
  return true;
}

/**
 * 获取服务URL
 */
function getServiceUrl(serviceName) {
  const service = services[serviceName];
  if (!service) {
    logger.error(`Service ${serviceName} not found in configuration`);
    throw new Error(`Service ${serviceName} not found`);
  }
  return service.url;
}

/**
 * 获取路由配置
 */
function getRouteConfig(path) {
  return routes.find(route => {
    // 简单的路径匹配逻辑，可以根据需要扩展为正则表达式匹配
    const routePath = route.path.endsWith('/**') ? 
      route.path.slice(0, -3) : route.path;
    return path.startsWith(routePath);
  });
}

/**
 * 更新服务配置
 */
function updateServiceConfig(serviceName, config) {
  if (!services[serviceName]) {
    throw new Error(`Service ${serviceName} does not exist`);
  }
  
  const { error } = serviceConfigSchema.validate({ ...services[serviceName], ...config });
  if (error) {
    throw new Error(`Invalid configuration for service ${serviceName}: ${error.details[0].message}`);
  }
  
  services[serviceName] = { ...services[serviceName], ...config };
  logger.info(`Updated configuration for service ${serviceName}`, { changes: Object.keys(config) });
  return services[serviceName];
}

/**
 * 导出配置
 */
module.exports = {
  // 配置对象
  services,
  routes,
  gatewayConfig,
  
  // 工具函数
  validateServiceConfigs,
  validateRouteConfigs,
  getServiceUrl,
  getRouteConfig,
  updateServiceConfig,
  
  // 配置验证
  validateAll: () => {
    validateServiceConfigs();
    validateRouteConfigs();
    logger.info('All gateway configurations are valid');
    return true;
  },
  
  // 获取完整配置信息
  getFullConfig: () => ({
    gateway: gatewayConfig,
    services,
    routes,
    version: '1.0.0'
  })
};