const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');
const { gatewayConfig } = require('../config/gatewayConfig');

/**
 * 认证中间件集合
 * 提供JWT验证、角色验证、内部服务认证等功能
 */

/**
 * JWT认证中间件
 * 验证请求中的JWT令牌
 */
function authenticateJWT(req, res, next) {
  try {
    // 检查是否需要认证（跳过某些路径）
    const skipAuth = gatewayConfig.jwt.excludedPaths.some(path => 
      req.path.startsWith(path)
    );
    
    if (skipAuth) {
      logger.debug('跳过认证：匹配到排除路径', { path: req.path });
      return next();
    }
    
    // 获取令牌
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return handleAuthError(res, '缺少认证令牌', 'AUTH_TOKEN_MISSING');
    }
    
    // 检查Bearer前缀
    if (!authHeader.startsWith('Bearer ')) {
      return handleAuthError(res, '令牌格式错误', 'AUTH_TOKEN_INVALID_FORMAT');
    }
    
    const token = authHeader.split(' ')[1];
    if (!token) {
      return handleAuthError(res, '令牌为空', 'AUTH_TOKEN_EMPTY');
    }
    
    // 验证令牌
    jwt.verify(token, gatewayConfig.jwt.secret, {
      algorithms: [gatewayConfig.jwt.algorithm],
      maxAge: gatewayConfig.jwt.expiresIn
    }, (error, decoded) => {
      if (error) {
        logger.error('JWT验证失败', {
          error: error.message,
          path: req.path,
          ip: req.ip
        });
        
        if (error.name === 'TokenExpiredError') {
          return handleAuthError(res, '令牌已过期', 'AUTH_TOKEN_EXPIRED');
        } else if (error.name === 'JsonWebTokenError') {
          return handleAuthError(res, '令牌无效', 'AUTH_TOKEN_INVALID');
        } else {
          return handleAuthError(res, '认证失败', 'AUTH_VERIFICATION_FAILED');
        }
      }
      
      // 将解码的用户信息存储到请求对象中
      req.user = decoded;
      req.userId = decoded.userId || decoded.sub;
      req.role = decoded.role;
      
      logger.debug('JWT认证成功', {
        userId: req.userId,
        role: req.role,
        path: req.path
      });
      
      // 记录认证日志
      logger.auth('jwt_verify', true, req.userId, {
        ip: req.ip,
        user_agent: req.headers['user-agent'],
        path: req.path
      });
      
      next();
    });
  } catch (error) {
    logger.error('认证中间件错误', {
      error: error.message,
      path: req.path,
      stack: error.stack
    });
    return handleAuthError(res, '认证过程中发生错误', 'AUTH_INTERNAL_ERROR');
  }
}

/**
 * 角色验证中间件
 * 验证用户是否有足够的权限访问资源
 */
function authorizeRole(roles) {
  return (req, res, next) => {
    try {
      // 如果请求没有用户信息，拒绝访问
      if (!req.user) {
        return handleAuthError(res, '未认证的请求', 'AUTH_NOT_AUTHENTICATED');
      }
      
      // 确保角色存在
      const userRole = req.role || 'user';
      
      // 检查用户角色是否在允许的角色列表中
      const hasPermission = Array.isArray(roles) 
        ? roles.includes(userRole)
        : roles === userRole;
      
      if (!hasPermission) {
        logger.error('角色验证失败', {
          required_roles: roles,
          user_role: userRole,
          user_id: req.userId,
          path: req.path
        });
        
        return res.status(403).json({
          success: false,
          message: '权限不足，无法访问该资源',
          code: 'AUTH_INSUFFICIENT_PERMISSIONS',
          required_roles: roles,
          user_role: userRole
        });
      }
      
      logger.debug('角色验证成功', {
        user_role: userRole,
        user_id: req.userId,
        path: req.path
      });
      
      next();
    } catch (error) {
      logger.error('角色验证中间件错误', {
        error: error.message,
        path: req.path
      });
      return handleAuthError(res, '角色验证失败', 'AUTH_ROLE_VERIFICATION_ERROR');
    }
  };
}

/**
 * 内部服务认证中间件
 * 验证内部服务之间的通信
 */
function authenticateInternalService(req, res, next) {
  try {
    const internalKey = req.headers['x-internal-key'];
    
    if (!internalKey) {
      logger.error('内部服务认证失败：缺少内部密钥', {
        path: req.path,
        ip: req.ip
      });
      return res.status(403).json({
        success: false,
        message: '内部服务认证失败：缺少内部密钥',
        code: 'INTERNAL_AUTH_MISSING_KEY'
      });
    }
    
    if (internalKey !== process.env.INTERNAL_SERVICE_KEY) {
      logger.error('内部服务认证失败：密钥不匹配', {
        path: req.path,
        ip: req.ip
      });
      return res.status(403).json({
        success: false,
        message: '内部服务认证失败：密钥不匹配',
        code: 'INTERNAL_AUTH_INVALID_KEY'
      });
    }
    
    logger.debug('内部服务认证成功', {
      path: req.path,
      service: req.headers['x-service-name'] || 'unknown'
    });
    
    // 设置内部服务标志
    req.isInternalService = true;
    req.internalServiceName = req.headers['x-service-name'] || 'unknown';
    
    next();
  } catch (error) {
    logger.error('内部服务认证中间件错误', {
      error: error.message,
      path: req.path
    });
    return res.status(500).json({
      success: false,
      message: '内部服务认证过程中发生错误',
      code: 'INTERNAL_AUTH_ERROR'
    });
  }
}

/**
 * API版本控制中间件
 * 验证和处理API版本
 */
function apiVersion(requiredVersion) {
  return (req, res, next) => {
    try {
      const versionHeader = gatewayConfig.request.headers['x-api-version'] || 
                           req.headers[gatewayConfig.apiVersionHeader.toLowerCase()];
      
      let requestedVersion = versionHeader || gatewayConfig.apiVersion;
      
      // 处理版本格式（去除v前缀）
      if (requestedVersion.startsWith('v')) {
        requestedVersion = requestedVersion.slice(1);
      }
      
      if (requiredVersion.startsWith('v')) {
        requiredVersion = requiredVersion.slice(1);
      }
      
      // 检查版本兼容性
      if (!isVersionCompatible(requestedVersion, requiredVersion)) {
        return res.status(400).json({
          success: false,
          message: `API版本不兼容，请求的版本：v${requestedVersion}，支持的版本：v${requiredVersion}`,
          code: 'API_VERSION_INCOMPATIBLE',
          requested_version: `v${requestedVersion}`,
          supported_version: `v${requiredVersion}`
        });
      }
      
      // 设置版本信息到请求对象
      req.apiVersion = `v${requestedVersion}`;
      
      logger.debug('API版本验证通过', {
        requested_version: req.apiVersion,
        path: req.path
      });
      
      next();
    } catch (error) {
      logger.error('API版本控制中间件错误', {
        error: error.message,
        path: req.path
      });
      return res.status(500).json({
        success: false,
        message: 'API版本处理错误',
        code: 'API_VERSION_ERROR'
      });
    }
  };
}

/**
 * 权限检查中间件
 * 基于资源和操作类型的细粒度权限控制
 */
function checkPermission(resource, operation) {
  return (req, res, next) => {
    try {
      if (!req.user) {
        return handleAuthError(res, '未认证的请求', 'AUTH_NOT_AUTHENTICATED');
      }
      
      // 从用户对象中获取权限列表
      const permissions = req.user.permissions || [];
      
      // 检查是否有足够的权限
      const requiredPermission = `${resource}:${operation}`;
      const hasPermission = permissions.includes(requiredPermission) || 
                           permissions.includes(`${resource}:*`) || 
                           permissions.includes('*:*');
      
      // 管理员角色拥有所有权限
      const isAdmin = req.role === 'admin';
      
      if (!hasPermission && !isAdmin) {
        logger.error('权限检查失败', {
          required_permission: requiredPermission,
          user_id: req.userId,
          user_permissions: permissions,
          path: req.path
        });
        
        return res.status(403).json({
          success: false,
          message: '操作权限不足',
          code: 'PERMISSION_DENIED',
          required_permission: requiredPermission
        });
      }
      
      logger.debug('权限检查通过', {
        permission: requiredPermission,
        user_id: req.userId,
        path: req.path
      });
      
      next();
    } catch (error) {
      logger.error('权限检查中间件错误', {
        error: error.message,
        path: req.path
      });
      return res.status(500).json({
        success: false,
        message: '权限检查失败',
        code: 'PERMISSION_CHECK_ERROR'
      });
    }
  };
}

/**
 * 处理认证错误的辅助函数
 */
function handleAuthError(res, message, code) {
  logger.error('认证失败', {
    message,
    code,
    path: res.req.path,
    ip: res.req.ip
  });
  
  return res.status(401).json({
    success: false,
    message,
    code,
    status: 401,
    timestamp: new Date().toISOString()
  });
}

/**
 * 版本兼容性检查辅助函数
 */
function isVersionCompatible(requestedVersion, requiredVersion) {
  // 简单的版本比较逻辑
  // 可以根据需要扩展为更复杂的语义化版本比较
  const requestedParts = requestedVersion.split('.').map(Number);
  const requiredParts = requiredVersion.split('.').map(Number);
  
  // 确保两个版本数组长度相同
  const maxLength = Math.max(requestedParts.length, requiredParts.length);
  while (requestedParts.length < maxLength) requestedParts.push(0);
  while (requiredParts.length < maxLength) requiredParts.push(0);
  
  // 比较主版本号
  if (requestedParts[0] !== requiredParts[0]) {
    return false;
  }
  
  // 次版本号允许向后兼容
  if (requestedParts[1] < requiredParts[1]) {
    return false;
  }
  
  return true;
}

/**
 * 令牌刷新中间件
 * 检查令牌是否接近过期，如果是则生成新令牌
 */
function refreshToken(req, res, next) {
  try {
    // 仅在认证成功后执行
    if (!req.user) {
      return next();
    }
    
    // 检查令牌是否在请求中
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }
    
    const token = authHeader.split(' ')[1];
    
    // 解码令牌以获取过期时间
    const decoded = jwt.decode(token);
    if (!decoded || !decoded.exp) {
      return next();
    }
    
    const currentTime = Math.floor(Date.now() / 1000);
    const expiresIn = decoded.exp - currentTime;
    const refreshThreshold = 60 * 30; // 30分钟
    
    // 如果令牌将在30分钟内过期，则生成新令牌
    if (expiresIn > 0 && expiresIn < refreshThreshold) {
      // 创建新令牌
      const newToken = jwt.sign(
        { ...req.user, issued_at: currentTime },
        gatewayConfig.jwt.secret,
        {
          algorithm: gatewayConfig.jwt.algorithm,
          expiresIn: gatewayConfig.jwt.expiresIn
        }
      );
      
      // 设置新令牌到响应头
      res.setHeader('X-Refreshed-Token', newToken);
      res.setHeader('X-Token-Expires-In', gatewayConfig.jwt.expiresIn);
      
      logger.debug('令牌已刷新', {
        userId: req.userId,
        originalExpiresIn: expiresIn,
        newExpiresIn: gatewayConfig.jwt.expiresIn
      });
    }
    
    next();
  } catch (error) {
    logger.error('令牌刷新中间件错误', {
      error: error.message,
      path: req.path
    });
    // 令牌刷新失败不应阻止请求继续
    next();
  }
}

/**
 * 身份验证中间件
 * 提供多种认证方式的统一入口
 */
function auth(mode = 'jwt') {
  return (req, res, next) => {
    switch (mode) {
      case 'jwt':
        return authenticateJWT(req, res, next);
      case 'internal':
        return authenticateInternalService(req, res, next);
      case 'none':
        return next();
      default:
        logger.error('未知的认证模式', { mode });
        return handleAuthError(res, '未知的认证模式', 'AUTH_INVALID_MODE');
    }
  };
}

module.exports = {
  // 主要认证中间件
  authenticateJWT,
  authorizeRole,
  authenticateInternalService,
  apiVersion,
  checkPermission,
  refreshToken,
  auth,
  
  // 工具函数（可选导出）
  handleAuthError,
  isVersionCompatible
};