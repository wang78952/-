const morgan = require('morgan');
const responseTime = require('response-time');
const logger = require('../utils/logger');
const { gatewayConfig } = require('../config/gatewayConfig');

/**
 * 请求日志中间件集合
 * 提供请求记录、响应时间跟踪、错误日志等功能
 */

/**
 * 请求日志中间件
 * 使用morgan记录HTTP请求
 */
function requestLogger() {
  // 自定义日志格式
  const logFormat = ':remote-addr - :remote-user [:date[clf]] \":method :url HTTP/:http-version\" :status :res[content-length] \"-\" \"-\" :response-time ms';
  
  // 自定义日志流
  const logStream = {
    write: (message) => {
      // 提取日志信息
      const logParts = message.trim().split(' ');
      const ip = logParts[0];
      const date = logParts[3].slice(1);
      const method = logParts[5].slice(1);
      const url = logParts[6];
      const status = parseInt(logParts[8]);
      const responseTime = parseFloat(logParts[10]);
      
      // 确定日志级别
      let level = 'info';
      if (status >= 500) {
        level = 'error';
      } else if (status >= 400) {
        level = 'warn';
      }
      
      // 记录日志
      logger[level](`HTTP ${method} ${url} ${status} ${responseTime}ms`, {
        ip,
        date,
        method,
        url,
        status,
        response_time: responseTime,
        service: 'gateway-service'
      });
    }
  };
  
  // 创建morgan中间件
  return morgan(logFormat, {
    stream: logStream,
    skip: (req, res) => {
      // 跳过健康检查路径的日志
      if (gatewayConfig.enableHealthCheck && 
          req.path === gatewayConfig.healthCheckEndpoint) {
        return true;
      }
      
      // 跳过某些不需要记录的路径
      const pathsToSkip = ['/favicon.ico', '/robots.txt'];
      return pathsToSkip.some(path => req.path === path);
    }
  });
}

/**
 * 响应时间中间件
 * 记录和返回响应时间
 */
function trackResponseTime() {
  return responseTime((req, res, time) => {
    // 设置响应时间头
    res.setHeader('X-Response-Time', `${time}ms`);
    
    // 记录详细的响应时间日志（对于慢请求）
    const slowRequestThreshold = 1000; // 1秒
    if (time > slowRequestThreshold) {
      logger.warn('慢请求警告', {
        method: req.method,
        path: req.path,
        response_time: time,
        threshold: slowRequestThreshold,
        ip: req.ip,
        user_agent: req.headers['user-agent'] || '-'
      });
    }
    
    // 使用自定义的HTTP日志方法
    logger.http(req, res, time);
  });
}

/**
 * 错误日志中间件
 * 捕获和记录请求处理过程中的错误
 */
function errorLogger(err, req, res, next) {
  try {
    // 生成错误ID
    const errorId = generateErrorId();
    
    // 准备错误日志数据
    const errorData = {
      error_id: errorId,
      message: err.message || '未知错误',
      stack: err.stack,
      status: res.statusCode || 500,
      path: req.path,
      method: req.method,
      ip: req.ip,
      headers: { ...req.headers },
      params: { ...req.params },
      query: { ...req.query },
      request_id: req.headers['x-request-id'] || '-',
      service: 'gateway-service'
    };
    
    // 过滤敏感信息
    sanitizeErrorData(errorData);
    
    // 确定日志级别
    let level = 'error';
    if (res.statusCode >= 500) {
      level = 'error';
    } else if (res.statusCode >= 400) {
      level = 'warn';
    }
    
    // 记录错误日志
    logger[level]('请求处理错误', errorData);
    
    // 将错误ID添加到响应头
    res.setHeader('X-Error-ID', errorId);
    
    // 继续错误处理链
    next(err);
  } catch (loggerError) {
    // 如果记录日志时发生错误，直接继续
    console.error('错误日志记录失败:', loggerError);
    next(err);
  }
}

/**
 * 详细请求日志中间件
 * 记录完整的请求和响应信息（用于调试）
 */
function detailedRequestLogger() {
  return (req, res, next) => {
    // 仅在开发环境启用
    if (process.env.NODE_ENV !== 'development') {
      return next();
    }
    
    // 生成请求ID
    const requestId = generateRequestId();
    req.requestId = requestId;
    res.setHeader('X-Request-ID', requestId);
    
    // 记录请求开始
    logger.debug('请求开始', {
      request_id: requestId,
      method: req.method,
      path: req.path,
      ip: req.ip,
      params: { ...req.params },
      query: { ...req.query },
      headers: { ...req.headers }
    });
    
    // 记录请求体
    if (req.body && Object.keys(req.body).length > 0) {
      const sanitizedBody = sanitizeRequestData(req.body);
      logger.debug('请求体', {
        request_id: requestId,
        body: sanitizedBody
      });
    }
    
    // 重写响应的end方法以记录响应
    const originalEnd = res.end;
    res.end = function(chunk, encoding) {
      // 记录响应
      logger.debug('请求结束', {
        request_id: requestId,
        status: res.statusCode,
        content_length: res.getHeader('content-length'),
        response_time: res.getHeader('x-response-time'),
        headers: { ...res.getHeaders() }
      });
      
      // 调用原始的end方法
      originalEnd.call(this, chunk, encoding);
    };
    
    next();
  };
}

/**
 * 访问控制日志中间件
 * 记录访问控制相关的日志
 */
function accessControlLogger() {
  return (req, res, next) => {
    // 记录请求的访问控制头
    const accessControlHeaders = {
      origin: req.headers['origin'],
      referer: req.headers['referer'],
      user_agent: req.headers['user-agent'],
      authorization: req.headers['authorization'] ? 'Bearer ***' : undefined,
      x_requested_with: req.headers['x-requested-with']
    };
    
    // 记录访问控制日志
    logger.info('访问控制检查', {
      method: req.method,
      path: req.path,
      ...accessControlHeaders
    });
    
    next();
  };
}

/**
 * 安全事件日志中间件
 * 监控和记录潜在的安全问题
 */
function securityEventLogger() {
  return (req, res, next) => {
    // 检查异常请求模式
    checkForSecurityIssues(req, (securityEvents) => {
      securityEvents.forEach(event => {
        logger.security(event.type, event.severity, {
          ip: req.ip,
          method: req.method,
          path: req.path,
          ...event.details
        });
      });
    });
    
    next();
  };
}

/**
 * 生成请求ID
 */
function generateRequestId() {
  return 'req_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         Date.now().toString(36);
}

/**
 * 生成错误ID
 */
function generateErrorId() {
  return 'err_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         Date.now().toString(36);
}

/**
 * 过滤请求数据中的敏感信息
 */
function sanitizeRequestData(data) {
  if (!data || typeof data !== 'object') {
    return data;
  }
  
  const sanitized = { ...data };
  
  // 过滤常见的敏感字段
  const sensitiveFields = [
    'password', 'password_confirmation', 'passwd',
    'token', 'access_token', 'refresh_token',
    'key', 'secret', 'api_key', 'api_secret',
    'card_number', 'credit_card', 'cc_number',
    'cvv', 'cvc', 'expiry_date',
    'social_security', 'ssn', 'tax_id',
    'birthdate', 'birthday'
  ];
  
  // 递归过滤敏感字段
  Object.keys(sanitized).forEach(key => {
    const lowercaseKey = key.toLowerCase();
    
    if (sensitiveFields.some(field => lowercaseKey.includes(field))) {
      sanitized[key] = '***';
    } else if (typeof sanitized[key] === 'object') {
      sanitized[key] = sanitizeRequestData(sanitized[key]);
    }
  });
  
  return sanitized;
}

/**
 * 清理错误日志数据中的敏感信息
 */
function sanitizeErrorData(errorData) {
  // 清理请求头
  if (errorData.headers) {
    const headersToSanitize = ['authorization', 'cookie', 'x-api-key', 'x-auth-token'];
    headersToSanitize.forEach(header => {
      if (errorData.headers[header]) {
        errorData.headers[header] = '***';
      }
    });
  }
  
  // 清理请求体（如果存在）
  if (errorData.body) {
    errorData.body = sanitizeRequestData(errorData.body);
  }
  
  // 清理参数
  if (errorData.params) {
    errorData.params = sanitizeRequestData(errorData.params);
  }
  
  // 清理查询参数
  if (errorData.query) {
    errorData.query = sanitizeRequestData(errorData.query);
  }
  
  return errorData;
}

/**
 * 检查潜在的安全问题
 */
function checkForSecurityIssues(req, callback) {
  const securityEvents = [];
  
  // 检查SQL注入尝试
  const potentialSqlInjection = /['"\;\-\s]?(SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|EXEC|UNION|CREATE|TRUNCATE|RENAME|BACKUP|RESTORE)/i;
  
  // 检查请求参数
  const paramsString = JSON.stringify({ ...req.params, ...req.query });
  if (potentialSqlInjection.test(paramsString)) {
    securityEvents.push({
      type: 'POTENTIAL_SQL_INJECTION',
      severity: 'high',
      details: {
        detected_in: 'params_or_query',
        matched_pattern: paramsString.match(potentialSqlInjection)[0]
      }
    });
  }
  
  // 检查请求体
  if (req.body) {
    const bodyString = JSON.stringify(req.body);
    if (potentialSqlInjection.test(bodyString)) {
      securityEvents.push({
        type: 'POTENTIAL_SQL_INJECTION',
        severity: 'high',
        details: {
          detected_in: 'body',
          matched_pattern: bodyString.match(potentialSqlInjection)[0]
        }
      });
    }
  }
  
  // 检查文件路径遍历攻击
  const pathTraversalPattern = /\.\.\//;
  if (pathTraversalPattern.test(req.path)) {
    securityEvents.push({
      type: 'PATH_TRAVERSAL_ATTEMPT',
      severity: 'high',
      details: {
        path: req.path
      }
    });
  }
  
  // 检查异常大的请求头
  if (req.headers && Object.keys(req.headers).length > 50) {
    securityEvents.push({
      type: 'EXCESSIVE_HEADERS',
      severity: 'medium',
      details: {
        header_count: Object.keys(req.headers).length
      }
    });
  }
  
  // 检查异常长的URL
  if (req.originalUrl && req.originalUrl.length > 2000) {
    securityEvents.push({
      type: 'EXCESSIVE_URL_LENGTH',
      severity: 'medium',
      details: {
        url_length: req.originalUrl.length
      }
    });
  }
  
  callback(securityEvents);
}

/**
 * 性能监控中间件
 * 监控请求处理性能
 */
function performanceMonitor() {
  return (req, res, next) => {
    const startTime = process.hrtime();
    const originalSend = res.send;
    
    // 重写send方法以测量性能
    res.send = function(body) {
      const diff = process.hrtime(startTime);
      const processingTime = diff[0] * 1e9 + diff[1]; // 纳秒
      const memoryUsage = process.memoryUsage();
      
      // 记录性能数据
      logger.info('请求性能指标', {
        path: req.path,
        method: req.method,
        processing_time_ns: processingTime,
        processing_time_ms: processingTime / 1e6,
        memory_usage: {
          rss: memoryUsage.rss,
          heap_used: memoryUsage.heapUsed,
          heap_total: memoryUsage.heapTotal
        }
      });
      
      // 调用原始的send方法
      return originalSend.call(this, body);
    };
    
    next();
  };
}

/**
 * 综合日志中间件
 * 组合多个日志中间件
 */
function comprehensiveLogging() {
  return [
    requestLogger(),
    trackResponseTime(),
    accessControlLogger(),
    securityEventLogger(),
    // 在开发环境中添加详细日志
    process.env.NODE_ENV === 'development' ? detailedRequestLogger() : (req, res, next) => next()
  ];
}

module.exports = {
  // 主要中间件
  requestLogger,
  trackResponseTime,
  errorLogger,
  detailedRequestLogger,
  accessControlLogger,
  securityEventLogger,
  performanceMonitor,
  comprehensiveLogging,
  
  // 工具函数
  generateRequestId,
  generateErrorId,
  sanitizeRequestData,
  sanitizeErrorData,
  checkForSecurityIssues
};