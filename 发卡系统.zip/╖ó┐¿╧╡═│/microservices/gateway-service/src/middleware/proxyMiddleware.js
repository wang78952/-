const { createProxyMiddleware } = require('http-proxy-middleware');
const logger = require('../utils/logger');
const { gatewayConfig } = require('../config/gatewayConfig');

/**
 * 代理中间件集合
 * 提供请求转发到各个微服务的功能
 */

/**
 * 创建微服务代理配置
 */
function createMicroserviceProxies() {
  const proxies = {};
  
  // 遍历微服务配置，创建代理
  Object.keys(gatewayConfig.microservices).forEach(serviceName => {
    const service = gatewayConfig.microservices[serviceName];
    const routes = gatewayConfig.routes[serviceName] || [];
    
    // 为每个服务创建代理实例
    routes.forEach(route => {
      const proxyOptions = createProxyOptions(service, route);
      const proxyMiddleware = createProxyMiddleware(proxyOptions);
      
      // 存储代理中间件
      proxies[route.path] = {
        middleware: proxyMiddleware,
        options: proxyOptions,
        serviceName,
        route
      };
    });
  });
  
  return proxies;
}

/**
 * 创建单个代理的配置选项
 */
function createProxyOptions(service, route) {
  // 构建目标URL
  const targetUrl = `${service.protocol || 'http'}://${service.host}:${service.port}`;
  
  // 基础配置
  const options = {
    target: targetUrl,
    changeOrigin: true,
    logLevel: gatewayConfig.proxy.logLevel || 'info',
    timeout: gatewayConfig.proxy.timeout || 60000,
    proxyTimeout: gatewayConfig.proxy.proxyTimeout || 60000,
    ...(route.options || {})
  };
  
  // 添加路径重写配置
  if (route.pathRewrite) {
    options.pathRewrite = route.pathRewrite;
  } else if (route.targetPath) {
    // 自动生成路径重写
    options.pathRewrite = (path, req) => {
      // 从路径中提取路由前缀后的部分
      const newPath = path.replace(new RegExp(`^${route.path}`), route.targetPath || '');
      return newPath || '/';
    };
  }
  
  // 添加请求拦截器
  options.onProxyReq = createProxyReqHandler(service, route);
  
  // 添加响应拦截器
  options.onProxyRes = createProxyResHandler(service, route);
  
  // 添加错误处理
  options.onError = createProxyErrorHandler(service, route);
  
  // 添加代理连接处理
  options.onProxyConnect = createProxyConnectHandler(service, route);
  
  // 添加WebSocket配置（如果启用）
  if (route.enableWs) {
    options.ws = true;
    options.onError = createWsErrorHandler(service, route);
  }
  
  // 添加头部配置
  options.headers = createProxyHeaders(service, route);
  
  return options;
}

/**
 * 创建代理请求处理器
 */
function createProxyReqHandler(service, route) {
  return (proxyReq, req, res) => {
    try {
      // 开始请求时间
      req.proxyStartTime = Date.now();
      
      // 生成代理请求ID
      req.proxyRequestId = generateRequestId();
      
      // 传递请求ID
      proxyReq.setHeader('X-Request-ID', req.proxyRequestId);
      proxyReq.setHeader('X-Proxy-Service', service.name || 'unknown');
      proxyReq.setHeader('X-Original-IP', req.ip);
      
      // 传递用户信息（如果有）
      if (req.user) {
        // 序列化用户信息为JSON，添加到请求头
        proxyReq.setHeader('X-User-Info', JSON.stringify(sanitizeUserInfo(req.user)));
      }
      
      // 添加认证令牌（如果有）
      if (req.headers.authorization) {
        proxyReq.setHeader('Authorization', req.headers.authorization);
      }
      
      // 自定义头部
      if (gatewayConfig.proxy.globalHeaders) {
        Object.entries(gatewayConfig.proxy.globalHeaders).forEach(([key, value]) => {
          proxyReq.setHeader(key, value);
        });
      }
      
      // 路由特定的头部
      if (route.headers) {
        Object.entries(route.headers).forEach(([key, value]) => {
          proxyReq.setHeader(key, typeof value === 'function' ? value(req) : value);
        });
      }
      
      // 日志记录
      logger.debug('代理请求开始', {
        request_id: req.proxyRequestId,
        service: service.name || 'unknown',
        original_path: req.originalUrl,
        target_url: proxyReq.path,
        method: req.method,
        ip: req.ip,
        service_url: `${service.protocol || 'http'}://${service.host}:${service.port}`
      });
      
      // 自定义请求处理（如果配置了）
      if (route.onProxyReq) {
        route.onProxyReq(proxyReq, req, res);
      }
    } catch (error) {
      logger.error('代理请求处理错误', {
        error: error.message,
        service: service.name || 'unknown',
        path: req.originalUrl,
        method: req.method
      });
    }
  };
}

/**
 * 创建代理响应处理器
 */
function createProxyResHandler(service, route) {
  return (proxyRes, req, res) => {
    try {
      // 计算响应时间
      const responseTime = Date.now() - req.proxyStartTime;
      
      // 提取微服务响应的头部信息
      const microserviceHeaders = {};
      Object.keys(proxyRes.headers).forEach(key => {
        if (key.startsWith('x-') || key.startsWith('X-')) {
          microserviceHeaders[key] = proxyRes.headers[key];
        }
      });
      
      // 检查响应状态
      const statusCode = proxyRes.statusCode;
      let logLevel = 'info';
      if (statusCode >= 500) {
        logLevel = 'error';
      } else if (statusCode >= 400) {
        logLevel = 'warn';
      }
      
      // 记录响应日志
      logger[logLevel]('代理响应完成', {
        request_id: req.proxyRequestId,
        service: service.name || 'unknown',
        path: req.originalUrl,
        target_url: req.url,
        status: statusCode,
        response_time: responseTime,
        content_type: proxyRes.headers['content-type'] || 'unknown',
        content_length: proxyRes.headers['content-length'] || 'unknown'
      });
      
      // 添加代理响应时间到头部
      res.setHeader('X-Proxy-Response-Time', `${responseTime}ms`);
      res.setHeader('X-Proxy-Service', service.name || 'unknown');
      
      // 错误状态码处理
      if (statusCode >= 500 && !res.headersSent) {
        // 记录微服务错误
        logger.error('微服务错误响应', {
          request_id: req.proxyRequestId,
          service: service.name || 'unknown',
          path: req.originalUrl,
          status: statusCode,
          microservice_headers: microserviceHeaders
        });
        
        // 如果配置了错误响应转换，使用自定义处理
        if (route.errorHandling && route.errorHandling.transform500Errors) {
          // 重新定义响应
          res.status(502);
          res.setHeader('Content-Type', 'application/json');
          res.send(JSON.stringify({
            error: '服务不可用',
            message: `${service.name || '微服务'}暂时不可用，请稍后重试`,
            code: 'SERVICE_UNAVAILABLE',
            proxy_error: true,
            original_status: statusCode
          }));
          return;
        }
      }
      
      // 自定义响应处理（如果配置了）
      if (route.onProxyRes) {
        route.onProxyRes(proxyRes, req, res);
      }
    } catch (error) {
      logger.error('代理响应处理错误', {
        error: error.message,
        service: service.name || 'unknown',
        path: req.originalUrl,
        status: proxyRes.statusCode
      });
    }
  };
}

/**
 * 创建代理错误处理器
 */
function createProxyErrorHandler(service, route) {
  return (err, req, res) => {
    try {
      // 生成错误ID
      const errorId = generateErrorId();
      
      // 准备错误数据
      const errorData = {
        error_id: errorId,
        error: err.message,
        code: getErrorCodeFromError(err),
        service: service.name || 'unknown',
        path: req.originalUrl,
        method: req.method,
        ip: req.ip,
        timeout: gatewayConfig.proxy.timeout || 60000,
        ...(req.proxyStartTime ? { response_time: Date.now() - req.proxyStartTime } : {})
      };
      
      // 记录代理错误
      logger.error('代理请求错误', errorData);
      
      // 设置响应头
      res.setHeader('X-Error-ID', errorId);
      res.setHeader('X-Proxy-Service', service.name || 'unknown');
      
      // 检查响应是否已发送
      if (res.headersSent) {
        return;
      }
      
      // 根据错误类型设置状态码
      let statusCode = 502; // 默认Bad Gateway
      if (err.code === 'ECONNREFUSED') {
        statusCode = 503; // Service Unavailable
      } else if (err.code === 'ETIMEDOUT' || err.code === 'ECONNABORTED') {
        statusCode = 504; // Gateway Timeout
      }
      
      // 构建错误响应
      const errorResponse = {
        error: getErrorMessage(err),
        message: getDetailedErrorMessage(err, service),
        code: errorData.code,
        error_id: errorId,
        timestamp: new Date().toISOString(),
        service: service.name || 'unknown',
        path: req.path
      };
      
      // 发送错误响应
      res.status(statusCode).json(errorResponse);
    } catch (error) {
      // 如果错误处理也失败，使用最基本的错误响应
      console.error('代理错误处理失败:', error);
      if (!res.headersSent) {
        try {
          res.status(502).send('代理错误');
        } catch (sendError) {
          // 最后的兜底
          console.error('发送错误响应失败:', sendError);
        }
      }
    }
  };
}

/**
 * 创建WebSocket错误处理器
 */
function createWsErrorHandler(service, route) {
  return (err, req, socket) => {
    try {
      // 生成错误ID
      const errorId = generateErrorId();
      
      // 记录WebSocket错误
      logger.error('WebSocket代理错误', {
        error_id: errorId,
        error: err.message,
        service: service.name || 'unknown',
        path: req.url,
        method: req.method,
        ip: req.ip
      });
      
      // 尝试关闭WebSocket连接
      if (socket && socket.readyState === socket.OPEN) {
        socket.close(1011, `代理错误: ${err.message}`);
      }
    } catch (error) {
      console.error('WebSocket错误处理失败:', error);
    }
  };
}

/**
 * 创建代理连接处理器
 */
function createProxyConnectHandler(service, route) {
  return (proxyRes, req, socket, options) => {
    // 记录WebSocket连接
    logger.info('WebSocket连接代理', {
      service: service.name || 'unknown',
      path: req.url,
      target: options.target
    });
  };
}

/**
 * 创建代理头部
 */
function createProxyHeaders(service, route) {
  const headers = {
    'X-Proxy-Request': 'true',
    'X-Proxy-Service': service.name || 'unknown',
    'X-Proxy-Date': new Date().toISOString()
  };
  
  // 合并全局头部
  if (gatewayConfig.proxy.globalHeaders) {
    Object.assign(headers, gatewayConfig.proxy.globalHeaders);
  }
  
  // 合并路由特定头部
  if (route.headers) {
    Object.entries(route.headers).forEach(([key, value]) => {
      if (typeof value === 'function') {
        headers[key] = value();
      } else {
        headers[key] = value;
      }
    });
  }
  
  return headers;
}

/**
 * 生成请求ID
 */
function generateRequestId() {
  return 'req_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         Date.now().toString(36);
}

/**
 * 生成错误ID
 */
function generateErrorId() {
  return 'err_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         Date.now().toString(36);
}

/**
 * 从错误中提取错误代码
 */
function getErrorCodeFromError(err) {
  if (err.code) {
    return err.code;
  } else if (err.name) {
    return err.name.toUpperCase().replace(/[^A-Z0-9]/g, '_');
  }
  return 'UNKNOWN_ERROR';
}

/**
 * 获取错误信息
 */
function getErrorMessage(err) {
  if (err.code === 'ECONNREFUSED') {
    return '服务连接被拒绝';
  } else if (err.code === 'ETIMEDOUT' || err.code === 'ECONNABORTED') {
    return '请求超时';
  }
  return err.message || '代理错误';
}

/**
 * 获取详细错误信息
 */
function getDetailedErrorMessage(err, service) {
  if (err.code === 'ECONNREFUSED') {
    return `${service.name || '微服务'}可能未运行或不可达`;
  } else if (err.code === 'ETIMEDOUT' || err.code === 'ECONNABORTED') {
    return `${service.name || '微服务'}响应超时，请稍后重试`;
  }
  return `${service.name || '微服务'}请求处理失败`;
}

/**
 * 清理用户信息
 */
function sanitizeUserInfo(user) {
  if (!user || typeof user !== 'object') {
    return user;
  }
  
  const sanitized = { ...user };
  
  // 移除敏感信息
  const sensitiveFields = ['password', 'token', 'refreshToken', 'apiKey', 'secret'];
  sensitiveFields.forEach(field => {
    if (sanitized[field]) {
      sanitized[field] = '***';
    }
  });
  
  return sanitized;
}

/**
 * 微服务健康检查
 */
async function checkMicroserviceHealth(serviceName) {
  try {
    const service = gatewayConfig.microservices[serviceName];
    if (!service) {
      throw new Error(`微服务 ${serviceName} 不存在`);
    }
    
    // 构建健康检查URL
    const healthCheckUrl = `${service.protocol || 'http'}://${service.host}:${service.port}${service.healthCheckEndpoint || '/health'}`;
    
    // 发送健康检查请求
    const response = await fetch(healthCheckUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: gatewayConfig.proxy.healthCheckTimeout || 5000
    });
    
    // 检查响应状态
    if (!response.ok) {
      throw new Error(`健康检查失败: HTTP ${response.status}`);
    }
    
    // 解析响应
    const healthData = await response.json();
    
    return {
      service: serviceName,
      status: 'healthy',
      details: healthData
    };
  } catch (error) {
    return {
      service: serviceName,
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * 检查所有微服务的健康状态
 */
async function checkAllMicroservicesHealth() {
  const services = Object.keys(gatewayConfig.microservices);
  const healthPromises = services.map(serviceName => 
    checkMicroserviceHealth(serviceName).catch(error => ({
      service: serviceName,
      status: 'error',
      error: error.message
    }))
  );
  
  const results = await Promise.allSettled(healthPromises);
  
  // 处理结果
  const healthResults = {};
  results.forEach((result, index) => {
    const serviceName = services[index];
    if (result.status === 'fulfilled') {
      healthResults[serviceName] = result.value;
    } else {
      healthResults[serviceName] = {
        service: serviceName,
        status: 'error',
        error: result.reason.message || '未知错误'
      };
    }
  });
  
  // 计算整体健康状态
  const allHealthy = Object.values(healthResults).every(h => h.status === 'healthy');
  
  return {
    status: allHealthy ? 'healthy' : 'unhealthy',
    timestamp: new Date().toISOString(),
    services: healthResults,
    healthy_count: Object.values(healthResults).filter(h => h.status === 'healthy').length,
    total_count: services.length
  };
}

/**
 * 动态路由处理中间件
 */
function createDynamicRouter(proxies) {
  return (req, res, next) => {
    try {
      // 查找匹配的代理路由
      const matchedRoute = findMatchedRoute(req.path, proxies);
      
      if (matchedRoute) {
        // 使用匹配的代理处理请求
        logger.debug('匹配到代理路由', {
          path: req.path,
          service: matchedRoute.serviceName,
          route_path: matchedRoute.route.path
        });
        
        // 执行代理中间件
        matchedRoute.middleware(req, res, next);
      } else {
        // 未找到匹配的路由，继续下一个中间件
        next();
      }
    } catch (error) {
      // 路由处理错误
      logger.error('路由处理错误', {
        path: req.path,
        error: error.message
      });
      next(error);
    }
  };
}

/**
 * 查找匹配的路由
 */
function findMatchedRoute(path, proxies) {
  // 按优先级排序路由（更具体的路由优先）
  const sortedRoutes = Object.entries(proxies)
    .sort(([, a], [, b]) => {
      // 精确匹配优先
      const aExact = a.route.path === path;
      const bExact = b.route.path === path;
      if (aExact && !bExact) return -1;
      if (!aExact && bExact) return 1;
      
      // 然后按路径长度排序（更长的路径更具体）
      return b.route.path.length - a.route.path.length;
    })
    .map(([_, proxy]) => proxy);
  
  // 找到第一个匹配的路由
  return sortedRoutes.find(proxy => {
    // 支持正则表达式路径
    if (proxy.route.path instanceof RegExp) {
      return proxy.route.path.test(path);
    }
    
    // 支持通配符路径
    if (proxy.route.path.includes('*')) {
      return matchWildcardPath(proxy.route.path, path);
    }
    
    // 普通前缀匹配
    return path.startsWith(proxy.route.path);
  });
}

/**
 * 通配符路径匹配
 */
function matchWildcardPath(pattern, path) {
  // 将通配符模式转换为正则表达式
  const regexPattern = pattern
    .replace(/\*/g, '.*')
    .replace(/\?/g, '.')
    .replace(/\//g, '\\/')
    .replace(/\./g, '\\.');
  
  const regex = new RegExp(`^${regexPattern}$`);
  return regex.test(path);
}

/**
 * 初始化代理系统
 */
function initializeProxySystem() {
  try {
    // 创建所有代理
    const proxies = createMicroserviceProxies();
    
    // 创建动态路由处理器
    const router = createDynamicRouter(proxies);
    
    // 记录初始化信息
    logger.info('代理系统初始化完成', {
      proxy_count: Object.keys(proxies).length,
      microservices: Object.keys(gatewayConfig.microservices).length
    });
    
    return {
      proxies,
      router,
      // 暴露健康检查功能
      checkMicroserviceHealth,
      checkAllMicroservicesHealth,
      // 暴露工具函数
      findMatchedRoute
    };
  } catch (error) {
    logger.error('代理系统初始化失败', { error: error.message });
    throw error;
  }
}

module.exports = {
  // 初始化函数
  initializeProxySystem,
  
  // 核心功能
  createMicroserviceProxies,
  createDynamicRouter,
  
  // 健康检查
  checkMicroserviceHealth,
  checkAllMicroservicesHealth,
  
  // 工具函数
  findMatchedRoute,
  generateRequestId,
  generateErrorId,
  sanitizeUserInfo
};