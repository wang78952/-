const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const { createClient } = require('redis');
const logger = require('../utils/logger');
const { gatewayConfig } = require('../config/gatewayConfig');

/**
 * 速率限制中间件集合
 * 提供API调用频率限制功能，防止滥用和DOS攻击
 */

/**
 * 创建Redis客户端用于速率限制存储
 */
let redisClient = null;

/**
 * 初始化Redis客户端
 */
async function initializeRedisClient() {
  if (redisClient) {
    return redisClient;
  }
  
  try {
    // 如果配置了Redis连接信息，使用Redis作为存储
    if (gatewayConfig.redis && gatewayConfig.redis.url) {
      redisClient = createClient({
        url: gatewayConfig.redis.url,
        ...(gatewayConfig.redis.options || {})
      });
      
      // 监听连接事件
      redisClient.on('connect', () => {
        logger.info('Redis客户端连接成功', { service: 'gateway-service' });
      });
      
      redisClient.on('error', (err) => {
        logger.error('Redis连接错误', { error: err.message, service: 'gateway-service' });
      });
      
      redisClient.on('end', () => {
        logger.warn('Redis连接断开', { service: 'gateway-service' });
      });
      
      // 连接Redis
      await redisClient.connect();
      logger.info('Redis客户端初始化成功', { service: 'gateway-service' });
      
      return redisClient;
    }
  } catch (error) {
    logger.error('Redis客户端初始化失败', { error: error.message, service: 'gateway-service' });
    // 初始化失败时返回null，将使用内存存储
  }
  
  return null;
}

/**
 * 创建存储实例
 */
async function createRateLimitStore(options = {}) {
  try {
    // 尝试初始化Redis客户端
    const client = await initializeRedisClient();
    
    // 如果有Redis客户端，使用Redis存储
    if (client) {
      return new RedisStore({
        sendCommand: (...args) => client.sendCommand(args),
        prefix: options.prefix || 'rate_limit:',
        expiry: options.expiry || 60 // 默认60秒
      });
    }
    
    // 否则使用内存存储（适用于开发环境或单个实例部署）
    logger.warn('未使用Redis，速率限制将使用内存存储，不适合多实例部署', { service: 'gateway-service' });
    return null;
  } catch (error) {
    logger.error('创建速率限制存储失败', { error: error.message, service: 'gateway-service' });
    return null;
  }
}

/**
 * 创建全局速率限制中间件
 */
async function createGlobalRateLimiter() {
  try {
    // 获取存储实例
    const store = await createRateLimitStore({
      prefix: 'global_limit:',
      expiry: gatewayConfig.rateLimits.global.windowMs / 1000
    });
    
    // 创建速率限制器
    const globalLimiter = rateLimit({
      windowMs: gatewayConfig.rateLimits.global.windowMs,
      max: gatewayConfig.rateLimits.global.max,
      standardHeaders: true,
      legacyHeaders: false,
      store: store,
      keyGenerator: (req) => {
        // 使用IP作为默认键
        return req.ip;
      },
      skip: (req, res) => {
        // 跳过健康检查路径
        if (gatewayConfig.enableHealthCheck && 
            req.path === gatewayConfig.healthCheckEndpoint) {
          return true;
        }
        
        // 跳过某些不需要限制的路径
        const pathsToSkip = ['/favicon.ico', '/robots.txt'];
        return pathsToSkip.some(path => req.path === path);
      },
      handler: (req, res, next) => {
        // 记录速率限制违规
        logger.warn('全局速率限制触发', {
          ip: req.ip,
          path: req.path,
          method: req.method,
          limit: gatewayConfig.rateLimits.global.max,
          window: gatewayConfig.rateLimits.global.windowMs / 1000,
          service: 'gateway-service'
        });
        
        // 发送速率限制响应
        res.status(429).json({
          error: '请求过于频繁',
          message: `已超过请求限制，请在${Math.ceil(gatewayConfig.rateLimits.global.windowMs / 1000)}秒后重试`,
          code: 'TOO_MANY_REQUESTS',
          retry_after: Math.ceil(gatewayConfig.rateLimits.global.windowMs / 1000)
        });
      }
    });
    
    return globalLimiter;
  } catch (error) {
    logger.error('创建全局速率限制器失败', { error: error.message, service: 'gateway-service' });
    // 返回一个空中间件作为后备
    return (req, res, next) => next();
  }
}

/**
 * 创建API速率限制中间件
 */
async function createApiRateLimiter() {
  try {
    // 获取存储实例
    const store = await createRateLimitStore({
      prefix: 'api_limit:',
      expiry: gatewayConfig.rateLimits.api.windowMs / 1000
    });
    
    // 创建API速率限制器
    const apiLimiter = rateLimit({
      windowMs: gatewayConfig.rateLimits.api.windowMs,
      max: gatewayConfig.rateLimits.api.max,
      standardHeaders: true,
      legacyHeaders: false,
      store: store,
      keyGenerator: (req) => {
        // 为API请求生成更细粒度的键
        const pathPrefix = req.path.split('/')[1]; // 获取API路径前缀
        return `${req.ip}:${pathPrefix}`;
      },
      skip: (req, res) => {
        // 只对API路径应用此限制
        const isApiPath = req.path.startsWith('/api/');
        return !isApiPath;
      },
      handler: (req, res, next) => {
        // 记录API速率限制违规
        logger.warn('API速率限制触发', {
          ip: req.ip,
          path: req.path,
          method: req.method,
          limit: gatewayConfig.rateLimits.api.max,
          window: gatewayConfig.rateLimits.api.windowMs / 1000,
          service: 'gateway-service'
        });
        
        // 发送API速率限制响应
        res.status(429).json({
          error: 'API请求过于频繁',
          message: `已超过API请求限制，请在${Math.ceil(gatewayConfig.rateLimits.api.windowMs / 1000)}秒后重试`,
          code: 'API_RATE_LIMIT_EXCEEDED',
          retry_after: Math.ceil(gatewayConfig.rateLimits.api.windowMs / 1000)
        });
      }
    });
    
    return apiLimiter;
  } catch (error) {
    logger.error('创建API速率限制器失败', { error: error.message, service: 'gateway-service' });
    // 返回一个空中间件作为后备
    return (req, res, next) => next();
  }
}

/**
 * 创建认证路径速率限制中间件
 */
async function createAuthRateLimiter() {
  try {
    // 获取存储实例
    const store = await createRateLimitStore({
      prefix: 'auth_limit:',
      expiry: gatewayConfig.rateLimits.auth.windowMs / 1000
    });
    
    // 创建认证速率限制器
    const authLimiter = rateLimit({
      windowMs: gatewayConfig.rateLimits.auth.windowMs,
      max: gatewayConfig.rateLimits.auth.max,
      standardHeaders: true,
      legacyHeaders: false,
      store: store,
      keyGenerator: (req) => {
        // 对认证请求使用更严格的限制
        return `auth:${req.ip}:${req.body?.username || req.query?.username || 'anonymous'}`;
      },
      skip: (req, res) => {
        // 只对认证相关路径应用此限制
        const authPaths = ['/api/auth/login', '/api/auth/register', '/api/auth/reset-password'];
        return !authPaths.some(path => req.path.startsWith(path));
      },
      handler: (req, res, next) => {
        // 记录认证速率限制违规
        logger.warn('认证请求速率限制触发', {
          ip: req.ip,
          path: req.path,
          method: req.method,
          username: req.body?.username || req.query?.username || 'anonymous',
          limit: gatewayConfig.rateLimits.auth.max,
          window: gatewayConfig.rateLimits.auth.windowMs / 1000,
          service: 'gateway-service'
        });
        
        // 发送认证速率限制响应
        res.status(429).json({
          error: '认证尝试过于频繁',
          message: `已超过认证请求限制，请在${Math.ceil(gatewayConfig.rateLimits.auth.windowMs / 1000)}秒后重试`,
          code: 'AUTH_RATE_LIMIT_EXCEEDED',
          retry_after: Math.ceil(gatewayConfig.rateLimits.auth.windowMs / 1000)
        });
      }
    });
    
    return authLimiter;
  } catch (error) {
    logger.error('创建认证速率限制器失败', { error: error.message, service: 'gateway-service' });
    // 返回一个空中间件作为后备
    return (req, res, next) => next();
  }
}

/**
 * 创建IP白名单检查
 */
function createIpWhitelistChecker() {
  return (req, res, next) => {
    // 如果配置了IP白名单
    if (gatewayConfig.ipWhitelist && gatewayConfig.ipWhitelist.enabled && gatewayConfig.ipWhitelist.ips.length > 0) {
      const clientIp = req.ip;
      
      // 检查IP是否在白名单中
      const isWhitelisted = gatewayConfig.ipWhitelist.ips.some(ip => {
        // 支持CIDR格式的IP范围
        if (ip.includes('/')) {
          return isIpInCidr(clientIp, ip);
        }
        return clientIp === ip;
      });
      
      // 如果启用了强制白名单，且IP不在白名单中
      if (gatewayConfig.ipWhitelist.enforce && !isWhitelisted) {
        logger.warn('IP未在白名单中，访问被拒绝', {
          ip: clientIp,
          path: req.path,
          method: req.method,
          service: 'gateway-service'
        });
        
        return res.status(403).json({
          error: '访问被拒绝',
          message: '您的IP地址没有访问权限',
          code: 'IP_NOT_WHITELISTED'
        });
      }
      
      // 将白名单状态添加到请求对象
      req.isWhitelisted = isWhitelisted;
    } else {
      // 如果未配置白名单，默认所有IP都通过
      req.isWhitelisted = true;
    }
    
    next();
  };
}

/**
 * 检查IP是否在CIDR范围内
 */
function isIpInCidr(ip, cidr) {
  try {
    // 解析CIDR
    const [network, prefixLength] = cidr.split('/');
    const prefix = parseInt(prefixLength, 10);
    
    // 将IP和网络转换为整数
    const ipInt = ipToInt(ip);
    const networkInt = ipToInt(network);
    
    // 计算网络掩码
    const mask = prefix === 0 ? 0 : -1 << (32 - prefix);
    
    // 检查IP是否在网络范围内
    return (ipInt & mask) === (networkInt & mask);
  } catch (error) {
    logger.error('CIDR解析错误', { error: error.message, cidr, service: 'gateway-service' });
    return false;
  }
}

/**
 * 将IP地址转换为整数
 */
function ipToInt(ip) {
  const parts = ip.split('.');
  return (
    (parseInt(parts[0], 10) << 24) +
    (parseInt(parts[1], 10) << 16) +
    (parseInt(parts[2], 10) << 8) +
    parseInt(parts[3], 10)
  ) >>> 0; // 无符号右移确保结果为正数
}

/**
 * 创建基于用户的速率限制中间件
 */
async function createUserRateLimiter() {
  try {
    // 获取存储实例
    const store = await createRateLimitStore({
      prefix: 'user_limit:',
      expiry: gatewayConfig.rateLimits.user.windowMs / 1000
    });
    
    // 创建用户速率限制器
    const userLimiter = rateLimit({
      windowMs: gatewayConfig.rateLimits.user.windowMs,
      max: gatewayConfig.rateLimits.user.max,
      standardHeaders: true,
      legacyHeaders: false,
      store: store,
      keyGenerator: (req) => {
        // 对已认证用户使用用户ID作为键
        const userId = req.user?.id || req.user?.userId || 'anonymous';
        return `user:${userId}:${req.path.split('/')[1]}`;
      },
      skip: (req, res) => {
        // 只对需要认证的路径应用此限制
        // 此函数需要在认证中间件之后使用，以便req.user可用
        const requiresAuthPaths = ['/api/users', '/api/orders', '/api/payments'];
        const isAuthPath = requiresAuthPaths.some(path => req.path.startsWith(path));
        return !isAuthPath;
      },
      handler: (req, res, next) => {
        // 记录用户速率限制违规
        const userId = req.user?.id || req.user?.userId || 'anonymous';
        logger.warn('用户请求速率限制触发', {
          user_id: userId,
          ip: req.ip,
          path: req.path,
          method: req.method,
          limit: gatewayConfig.rateLimits.user.max,
          window: gatewayConfig.rateLimits.user.windowMs / 1000,
          service: 'gateway-service'
        });
        
        // 发送用户速率限制响应
        res.status(429).json({
          error: '请求过于频繁',
          message: `已超过请求限制，请在${Math.ceil(gatewayConfig.rateLimits.user.windowMs / 1000)}秒后重试`,
          code: 'USER_RATE_LIMIT_EXCEEDED',
          retry_after: Math.ceil(gatewayConfig.rateLimits.user.windowMs / 1000)
        });
      }
    });
    
    return userLimiter;
  } catch (error) {
    logger.error('创建用户速率限制器失败', { error: error.message, service: 'gateway-service' });
    // 返回一个空中间件作为后备
    return (req, res, next) => next();
  }
}

/**
 * 创建自定义速率限制中间件
 */
async function createCustomRateLimiter(options) {
  try {
    // 获取存储实例
    const store = await createRateLimitStore({
      prefix: options.prefix || 'custom_limit:',
      expiry: options.windowMs / 1000
    });
    
    // 创建自定义速率限制器
    const customLimiter = rateLimit({
      windowMs: options.windowMs,
      max: options.max,
      standardHeaders: options.standardHeaders !== false,
      legacyHeaders: options.legacyHeaders || false,
      store: store,
      keyGenerator: options.keyGenerator || ((req) => req.ip),
      skip: options.skip || ((req, res) => false),
      handler: options.handler || ((req, res, next) => {
        res.status(429).json({
          error: '请求过于频繁',
          message: `已超过请求限制，请稍后重试`,
          code: 'RATE_LIMIT_EXCEEDED',
          retry_after: Math.ceil(options.windowMs / 1000)
        });
      }),
      message: options.message || '请求过于频繁，请稍后重试',
      statusCode: options.statusCode || 429,
      headers: options.headers !== false
    });
    
    return customLimiter;
  } catch (error) {
    logger.error('创建自定义速率限制器失败', { error: error.message, options, service: 'gateway-service' });
    // 返回一个空中间件作为后备
    return (req, res, next) => next();
  }
}

/**
 * 获取当前请求的速率限制信息
 */
function getRateLimitInfo(req) {
  // rateLimit中间件会在req对象上添加rateLimitInfo
  if (req.rateLimit) {
    return {
      limit: req.rateLimit.limit,
      remaining: req.rateLimit.remaining,
      resetTime: req.rateLimit.resetTime,
      used: req.rateLimit.used,
      resetMs: req.rateLimit.resetMs
    };
  }
  return null;
}

/**
 * 根据请求路径获取适用的速率限制配置
 */
function getRateLimitConfigForPath(path, method) {
  // 检查是否有针对特定路径的配置
  if (gatewayConfig.rateLimits.paths && gatewayConfig.rateLimits.paths.length > 0) {
    const matchingConfig = gatewayConfig.rateLimits.paths.find(config => {
      // 检查路径匹配
      const pathMatch = typeof config.path === 'string' ? 
        path.startsWith(config.path) : 
        config.path.test(path);
      
      // 检查方法匹配（如果指定了方法）
      const methodMatch = !config.method || config.method.toUpperCase() === method.toUpperCase();
      
      return pathMatch && methodMatch;
    });
    
    if (matchingConfig) {
      return matchingConfig;
    }
  }
  
  // 返回默认配置
  return gatewayConfig.rateLimits.default || gatewayConfig.rateLimits.global;
}

/**
 * 关闭Redis客户端连接
 */
async function closeRedisClient() {
  if (redisClient) {
    try {
      await redisClient.quit();
      logger.info('Redis客户端连接已关闭', { service: 'gateway-service' });
      redisClient = null;
    } catch (error) {
      logger.error('关闭Redis客户端失败', { error: error.message, service: 'gateway-service' });
    }
  }
}

/**
 * 综合速率限制中间件
 * 组合多个速率限制中间件
 */
async function createComprehensiveRateLimiters() {
  try {
    // 初始化所有速率限制器
    const [ipChecker, globalLimiter, apiLimiter, authLimiter] = await Promise.all([
      createIpWhitelistChecker(),
      createGlobalRateLimiter(),
      createApiRateLimiter(),
      createAuthRateLimiter()
    ]);
    
    // 构建中间件数组
    return [
      ipChecker,
      globalLimiter,
      apiLimiter,
      authLimiter
    ];
  } catch (error) {
    logger.error('创建综合速率限制器失败', { error: error.message, service: 'gateway-service' });
    // 返回最小的中间件集合作为后备
    return [
      createIpWhitelistChecker()
    ];
  }
}

module.exports = {
  // 主要中间件
  createGlobalRateLimiter,
  createApiRateLimiter,
  createAuthRateLimiter,
  createUserRateLimiter,
  createIpWhitelistChecker,
  createCustomRateLimiter,
  createComprehensiveRateLimiters,
  
  // 工具函数
  initializeRedisClient,
  closeRedisClient,
  getRateLimitInfo,
  getRateLimitConfigForPath,
  isIpInCidr,
  ipToInt
};