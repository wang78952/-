const helmet = require('helmet');
const cors = require('cors');
const express = require('express');
const logger = require('../utils/logger');
const { gatewayConfig } = require('../config/gatewayConfig');

/**
 * 安全中间件集合
 * 提供CORS、安全头、请求验证等安全功能
 */

/**
 * 创建CORS中间件
 * 配置跨域资源共享策略
 */
function createCorsMiddleware() {
  // 构建CORS配置
  const corsOptions = {
    origin: gatewayConfig.cors.origins || ['*'],
    methods: gatewayConfig.cors.methods || ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: gatewayConfig.cors.allowedHeaders || [
      'Origin', 'X-Requested-With', 'Content-Type', 'Accept',
      'Authorization', 'X-API-Key', 'X-User-ID', 'X-Request-ID'
    ],
    exposedHeaders: gatewayConfig.cors.exposedHeaders || [
      'X-Request-ID', 'X-Response-Time', 'X-Error-ID', 'X-Proxy-Response-Time'
    ],
    credentials: gatewayConfig.cors.credentials !== false,
    maxAge: gatewayConfig.cors.maxAge || 86400, // 24小时
    preflightContinue: gatewayConfig.cors.preflightContinue || false,
    optionsSuccessStatus: gatewayConfig.cors.optionsSuccessStatus || 204
  };
  
  // 记录CORS配置
  logger.info('CORS中间件配置完成', {
    origins: corsOptions.origins.length > 10 ? `${corsOptions.origins.length}个域名` : corsOptions.origins,
    methods: corsOptions.methods,
    credentials: corsOptions.credentials,
    service: 'gateway-service'
  });
  
  // 如果配置了动态源验证，使用自定义origin函数
  if (gatewayConfig.cors.dynamicOrigins && typeof gatewayConfig.cors.dynamicOrigins === 'function') {
    corsOptions.origin = (origin, callback) => {
      try {
        // 调用自定义验证函数
        const isAllowed = gatewayConfig.cors.dynamicOrigins(origin, gatewayConfig.cors.origins);
        callback(null, isAllowed);
      } catch (error) {
        logger.error('CORS源验证错误', { error: error.message, origin });
        callback(error);
      }
    };
  }
  
  // 创建CORS中间件
  const corsMiddleware = cors(corsOptions);
  
  return corsMiddleware;
}

/**
 * 创建Helmet安全头中间件
 * 配置各种HTTP安全头
 */
function createSecurityHeadersMiddleware() {
  // 构建Helmet配置
  const helmetOptions = {
    // 启用基本安全头
    contentSecurityPolicy: gatewayConfig.security.contentSecurityPolicy || {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'", ...(gatewayConfig.cors.origins || [])],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        frameSrc: ["'self'"]
      }
    },
    
    // XSS保护
    xssFilter: gatewayConfig.security.xssProtection !== false,
    
    // MIME类型嗅探保护
    noSniff: gatewayConfig.security.noSniff !== false,
    
    // 点击劫持保护
    frameguard: gatewayConfig.security.frameguard || {
      action: 'deny'
    },
    
    // 隐藏X-Powered-By头部
    hidePoweredBy: gatewayConfig.security.hidePoweredBy !== false,
    
    // 严格传输安全（HTTPS）
    hsts: gatewayConfig.security.hsts || {
      maxAge: 31536000, // 1年
      includeSubDomains: true,
      preload: true
    },
    
    // Referrer策略
    referrerPolicy: gatewayConfig.security.referrerPolicy || {
      policy: 'same-origin'
    }
  };
  
  // 记录安全头配置
  logger.info('安全头中间件配置完成', {
    csp: !!gatewayConfig.security.contentSecurityPolicy,
    hsts: !!gatewayConfig.security.hsts,
    xss: gatewayConfig.security.xssProtection !== false,
    frameguard: !!gatewayConfig.security.frameguard,
    service: 'gateway-service'
  });
  
  // 创建Helmet中间件
  const helmetMiddleware = helmet(helmetOptions);
  
  return helmetMiddleware;
}

/**
 * 创建请求体大小限制中间件
 * 防止过大的请求体导致服务器负载过高
 */
function createBodyParserMiddleware() {
  // 构建请求体限制配置
  const bodyParserOptions = {
    json: {
      limit: gatewayConfig.requestLimits.jsonLimit || '1mb',
      strict: gatewayConfig.requestLimits.strictJSON !== false,
      type: ['application/json', 'application/*+json']
    },
    urlencoded: {
      limit: gatewayConfig.requestLimits.urlencodedLimit || '1mb',
      extended: gatewayConfig.requestLimits.extendedUrlencoded !== false,
      parameterLimit: gatewayConfig.requestLimits.parameterLimit || 1000
    }
  };
  
  // 创建body-parser中间件
  const jsonParser = express.json(bodyParserOptions.json);
  const urlencodedParser = express.urlencoded(bodyParserOptions.urlencoded);
  
  // 记录请求体解析配置
  logger.info('请求体解析中间件配置完成', {
    json_limit: bodyParserOptions.json.limit,
    urlencoded_limit: bodyParserOptions.urlencoded.limit,
    extended: bodyParserOptions.urlencoded.extended,
    parameter_limit: bodyParserOptions.urlencoded.parameterLimit,
    service: 'gateway-service'
  });
  
  return {
    json: jsonParser,
    urlencoded: urlencodedParser
  };
}

/**
 * 创建请求清理中间件
 * 移除请求中的恶意内容
 */
function createRequestSanitizerMiddleware() {
  return (req, res, next) => {
    try {
      // 清理查询参数
      if (req.query && typeof req.query === 'object') {
        sanitizeObject(req.query);
      }
      
      // 清理请求参数
      if (req.params && typeof req.params === 'object') {
        sanitizeObject(req.params);
      }
      
      // 清理请求体
      if (req.body && typeof req.body === 'object') {
        sanitizeObject(req.body);
      }
      
      // 清理头部（创建新对象，避免直接修改请求头）
      const headersToLog = {};
      Object.keys(req.headers).forEach(key => {
        headersToLog[key] = sanitizeString(req.headers[key]);
      });
      
      // 记录清理后的请求信息（仅在调试模式）
      if (process.env.NODE_ENV === 'development' && gatewayConfig.security.logSanitizedRequests) {
        logger.debug('请求内容已清理', {
          path: req.path,
          method: req.method,
          query_params_count: Object.keys(req.query).length,
          body_params_count: req.body ? Object.keys(req.body).length : 0
        });
      }
      
      next();
    } catch (error) {
      logger.error('请求清理失败', {
        error: error.message,
        path: req.path,
        method: req.method
      });
      next(error);
    }
  };
}

/**
 * 创建敏感信息过滤中间件
 * 确保敏感信息不会泄露到日志中
 */
function createSensitiveDataFilterMiddleware() {
  return (req, res, next) => {
    // 保存原始请求体用于日志记录
    if (req.body) {
      try {
        // 深拷贝请求体用于日志记录
        req.sanitizedBody = JSON.parse(JSON.stringify(req.body));
        
        // 过滤敏感字段
        filterSensitiveFields(req.sanitizedBody);
      } catch (error) {
        // 如果解析失败，使用空对象
        req.sanitizedBody = {};
        logger.warn('请求体深拷贝失败', { error: error.message });
      }
    }
    
    // 保存原始查询参数用于日志记录
    if (req.query) {
      try {
        req.sanitizedQuery = JSON.parse(JSON.stringify(req.query));
        filterSensitiveFields(req.sanitizedQuery);
      } catch (error) {
        req.sanitizedQuery = {};
        logger.warn('查询参数深拷贝失败', { error: error.message });
      }
    }
    
    // 保存原始头部用于日志记录
    if (req.headers) {
      req.sanitizedHeaders = {};
      Object.keys(req.headers).forEach(key => {
        if (isSensitiveHeader(key)) {
          req.sanitizedHeaders[key] = '***';
        } else {
          req.sanitizedHeaders[key] = req.headers[key];
        }
      });
    }
    
    next();
  };
}

/**
 * 创建API版本控制中间件
 * 根据URL路径或头部信息确定API版本
 */
function createApiVersioningMiddleware() {
  return (req, res, next) => {
    // 从URL路径中提取版本
    const urlParts = req.path.split('/');
    let version = gatewayConfig.api.defaultVersion || 'v1';
    
    // 检查URL路径中的版本号（如 /api/v1/users）
    for (let i = 0; i < urlParts.length; i++) {
      if (urlParts[i].startsWith('v') && /^v\d+$/.test(urlParts[i])) {
        version = urlParts[i];
        break;
      }
    }
    
    // 从头部检查版本（如果URL中没有）
    if (req.headers['x-api-version']) {
      version = req.headers['x-api-version'];
    }
    
    // 检查版本是否受支持
    if (gatewayConfig.api.supportedVersions && 
        !gatewayConfig.api.supportedVersions.includes(version)) {
      logger.warn('不支持的API版本请求', {
        requested_version: version,
        path: req.path,
        supported_versions: gatewayConfig.api.supportedVersions,
        service: 'gateway-service'
      });
      
      return res.status(400).json({
        error: '不支持的API版本',
        message: `请求的API版本 ${version} 不受支持，请使用以下版本之一: ${gatewayConfig.api.supportedVersions.join(', ')}`,
        code: 'UNSUPPORTED_API_VERSION',
        supported_versions: gatewayConfig.api.supportedVersions
      });
    }
    
    // 将版本信息添加到请求对象
    req.apiVersion = version;
    
    // 设置版本响应头
    res.setHeader('X-API-Version', version);
    
    next();
  };
}

/**
 * 创建请求ID中间件
 * 为每个请求生成唯一ID
 */
function createRequestIdMiddleware() {
  return (req, res, next) => {
    // 检查请求是否已有ID
    let requestId = req.headers['x-request-id'] || req.headers['X-Request-ID'];
    
    // 如果没有，生成新的ID
    if (!requestId) {
      requestId = generateRequestId();
    }
    
    // 将ID添加到请求和响应
    req.requestId = requestId;
    res.setHeader('X-Request-ID', requestId);
    
    next();
  };
}

/**
 * 创建基础安全检查中间件
 * 检查请求中的常见安全问题
 */
function createBasicSecurityCheckMiddleware() {
  return (req, res, next) => {
    try {
      // 检查路径遍历攻击
      if (pathTraversalCheck(req.path)) {
        logger.warn('潜在的路径遍历攻击检测', {
          path: req.path,
          ip: req.ip,
          method: req.method,
          service: 'gateway-service'
        });
        
        return res.status(403).json({
          error: '安全检查失败',
          message: '检测到潜在的安全威胁',
          code: 'SECURITY_VIOLATION',
          reason: 'path_traversal'
        });
      }
      
      // 检查SQL注入尝试
      const sqlInjectionCheck = performSqlInjectionCheck(req);
      if (sqlInjectionCheck.found) {
        logger.warn('潜在的SQL注入攻击检测', {
          path: req.path,
          ip: req.ip,
          method: req.method,
          matched_pattern: sqlInjectionCheck.pattern,
          detected_in: sqlInjectionCheck.location,
          service: 'gateway-service'
        });
        
        return res.status(403).json({
          error: '安全检查失败',
          message: '检测到潜在的安全威胁',
          code: 'SECURITY_VIOLATION',
          reason: 'sql_injection'
        });
      }
      
      // 检查异常请求头
      const headerCheck = checkAbnormalHeaders(req.headers);
      if (headerCheck.issues.length > 0) {
        logger.warn('异常请求头检测', {
          path: req.path,
          ip: req.ip,
          method: req.method,
          issues: headerCheck.issues,
          service: 'gateway-service'
        });
        
        // 可以选择警告而不是拒绝请求
        if (gatewayConfig.security.blockAbnormalHeaders) {
          return res.status(403).json({
            error: '安全检查失败',
            message: '检测到异常请求头',
            code: 'SECURITY_VIOLATION',
            reason: 'abnormal_headers',
            issues: headerCheck.issues
          });
        }
      }
      
      next();
    } catch (error) {
      logger.error('安全检查失败', {
        error: error.message,
        path: req.path,
        method: req.method
      });
      next(); // 继续处理，不阻止请求
    }
  };
}

/**
 * 创建HTTPS重定向中间件
 * 在生产环境中将HTTP请求重定向到HTTPS
 */
function createHttpsRedirectMiddleware() {
  return (req, res, next) => {
    // 仅在生产环境中启用
    if (process.env.NODE_ENV !== 'production') {
      return next();
    }
    
    // 检查是否已通过HTTPS访问
    const isSecure = req.secure || 
                    req.headers['x-forwarded-proto'] === 'https' ||
                    req.headers['x-forwarded-scheme'] === 'https';
    
    if (!isSecure && gatewayConfig.security.forceHttps) {
      // 构建重定向URL
      const httpsUrl = `https://${req.headers.host}${req.originalUrl}`;
      
      logger.info('HTTP请求重定向到HTTPS', {
        path: req.path,
        ip: req.ip,
        service: 'gateway-service'
      });
      
      // 执行重定向
      return res.redirect(301, httpsUrl);
    }
    
    next();
  };
}

/**
 * 综合安全中间件
 * 组合多个安全中间件
 */
function createComprehensiveSecurityMiddleware() {
  return [
    // HTTPS重定向
    createHttpsRedirectMiddleware(),
    
    // 安全头
    createSecurityHeadersMiddleware(),
    
    // CORS
    createCorsMiddleware(),
    
    // 请求ID
    createRequestIdMiddleware(),
    
    // 基础安全检查
    createBasicSecurityCheckMiddleware(),
    
    // API版本控制
    createApiVersioningMiddleware(),
    
    // 请求体解析
    createBodyParserMiddleware().json,
    createBodyParserMiddleware().urlencoded,
    
    // 请求清理和敏感数据过滤
    createRequestSanitizerMiddleware(),
    createSensitiveDataFilterMiddleware()
  ];
}

/**
 * 工具函数：清理对象
 */
function sanitizeObject(obj) {
  if (!obj || typeof obj !== 'object') {
    return obj;
  }
  
  Object.keys(obj).forEach(key => {
    if (typeof obj[key] === 'string') {
      obj[key] = sanitizeString(obj[key]);
    } else if (typeof obj[key] === 'object') {
      sanitizeObject(obj[key]);
    }
  });
  
  return obj;
}

/**
 * 工具函数：清理字符串
 */
function sanitizeString(str) {
  if (!str || typeof str !== 'string') {
    return str;
  }
  
  // 移除控制字符（除了换行符和制表符）
  str = str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  
  // 移除连续的空白字符
  str = str.replace(/\s+/g, ' ');
  
  return str.trim();
}

/**
 * 工具函数：过滤敏感字段
 */
function filterSensitiveFields(obj) {
  if (!obj || typeof obj !== 'object') {
    return obj;
  }
  
  const sensitiveFields = [
    'password', 'password_confirmation', 'passwd',
    'token', 'access_token', 'refresh_token', 'auth_token',
    'key', 'secret', 'api_key', 'api_secret',
    'card_number', 'credit_card', 'cc_number', 'cardNumber',
    'cvv', 'cvc', 'expiry_date', 'exp_date',
    'social_security', 'ssn', 'tax_id', 'vat_id',
    'birthdate', 'birthday',
    'pii', 'personal_identifiable_info'
  ];
  
  Object.keys(obj).forEach(key => {
    const lowercaseKey = key.toLowerCase();
    
    if (sensitiveFields.some(field => lowercaseKey.includes(field))) {
      obj[key] = '***';
    } else if (typeof obj[key] === 'object') {
      filterSensitiveFields(obj[key]);
    }
  });
  
  return obj;
}

/**
 * 工具函数：检查是否为敏感头部
 */
function isSensitiveHeader(header) {
  const sensitiveHeaders = [
    'authorization', 'cookie', 'x-api-key', 'x-auth-token',
    'proxy-authorization', 'x-csrf-token', 'x-xsrf-token'
  ];
  
  return sensitiveHeaders.some(sensitiveHeader => 
    header.toLowerCase() === sensitiveHeader.toLowerCase()
  );
}

/**
 * 工具函数：生成请求ID
 */
function generateRequestId() {
  return 'req_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         Date.now().toString(36);
}

/**
 * 工具函数：检查路径遍历攻击
 */
function pathTraversalCheck(path) {
  // 常见的路径遍历模式
  const traversalPatterns = [
    '../', '..\\', './../', './..\\',
    '\.\./', '\.\.\\', '\.\.\',
    '%2e%2e%2f', '%2e%2e%5c', '%252e%252e%252f',
    '..%2f', '..%5c', '..%252f', '..%255c'
  ];
  
  // 检查路径中是否包含路径遍历模式
  return traversalPatterns.some(pattern => 
    path.includes(pattern)
  );
}

/**
 * 工具函数：执行SQL注入检查
 */
function performSqlInjectionCheck(req) {
  // SQL注入模式
  const sqlPatterns = [
    /\bunion\b.*\bselect\b/i,
    /\bselect\b.*\bfrom\b/i,
    /\binsert\b.*\binto\b/i,
    /\bupdate\b.*\bset\b/i,
    /\bdelete\b.*\bfrom\b/i,
    /\bdrop\b.*\btable\b/i,
    /\balter\b.*\btable\b/i,
    /\bexec\b/i,
    /\bexecute\b/i,
    /\bsp_/i,
    /'\s*--/, /'\s*#/, /;--/, /;#/, /';/, /;\s*drop/i,
    /\bor\s+\d+=\d+/i,
    /\band\s+\d+=\d+/i,
    /\bxp_/i,
    /\bcmd\b/i,
    /\bwaitfor\b\s+\bdelay\b/i
  ];
  
  // 检查查询参数
  const queryString = JSON.stringify(req.query);
  for (const pattern of sqlPatterns) {
    if (pattern.test(queryString)) {
      return {
        found: true,
        pattern: pattern.toString(),
        location: 'query'
      };
    }
  }
  
  // 检查请求体
  if (req.body) {
    const bodyString = JSON.stringify(req.body);
    for (const pattern of sqlPatterns) {
      if (pattern.test(bodyString)) {
        return {
          found: true,
          pattern: pattern.toString(),
          location: 'body'
        };
      }
    }
  }
  
  // 检查路径参数
  const paramsString = JSON.stringify(req.params);
  for (const pattern of sqlPatterns) {
    if (pattern.test(paramsString)) {
      return {
        found: true,
        pattern: pattern.toString(),
        location: 'params'
      };
    }
  }
  
  return { found: false };
}

/**
 * 工具函数：检查异常请求头
 */
function checkAbnormalHeaders(headers) {
  const issues = [];
  
  // 检查异常大的头部数量
  if (Object.keys(headers).length > 100) {
    issues.push('异常大量的请求头');
  }
  
  // 检查异常的Content-Length
  const contentLength = headers['content-length'];
  if (contentLength && parseInt(contentLength) > (10 * 1024 * 1024)) { // 10MB
    issues.push('异常大的Content-Length');
  }
  
  // 检查异常的Host头
  const host = headers['host'];
  if (host && (host.includes('://') || host.includes('@'))) {
    issues.push('可疑的Host头');
  }
  
  // 检查XSS相关头部
  if (headers['xss-test'] || headers['xss']) {
    issues.push('XSS测试头部');
  }
  
  return {
    issues,
    abnormal: issues.length > 0
  };
}

module.exports = {
  // 主要中间件
  createCorsMiddleware,
  createSecurityHeadersMiddleware,
  createBodyParserMiddleware,
  createRequestSanitizerMiddleware,
  createSensitiveDataFilterMiddleware,
  createApiVersioningMiddleware,
  createRequestIdMiddleware,
  createBasicSecurityCheckMiddleware,
  createHttpsRedirectMiddleware,
  createComprehensiveSecurityMiddleware,
  
  // 工具函数
  sanitizeObject,
  sanitizeString,
  filterSensitiveFields,
  isSensitiveHeader,
  generateRequestId,
  pathTraversalCheck,
  performSqlInjectionCheck,
  checkAbnormalHeaders
};