const express = require('express');
const logger = require('../utils/logger');
const { gatewayConfig } = require('../config/gatewayConfig');
const authMiddleware = require('../middleware/authMiddleware');
const { checkAllMicroservicesHealth } = require('../middleware/proxyMiddleware');

/**
 * 网关路由配置
 * 定义网关服务的各种路由和端点
 */

/**
 * 创建网关路由
 */
function createGatewayRoutes(app) {
  // 创建路由器实例
  const router = express.Router();
  
  // 注册健康检查路由
  registerHealthCheckRoutes(router);
  
  // 注册API路由
  registerApiRoutes(router);
  
  // 注册管理路由
  registerAdminRoutes(router);
  
  // 注册状态路由
  registerStatusRoutes(router);
  
  // 注册错误处理路由
  registerErrorHandlingRoutes(router);
  
  // 将路由挂载到应用
  app.use('/', router);
  
  logger.info('网关路由配置完成', {
    health_check_routes: 1,
    api_routes: Object.keys(gatewayConfig.microservices).length,
    admin_routes: 1,
    service: 'gateway-service'
  });
  
  return router;
}

/**
 * 注册健康检查路由
 */
function registerHealthCheckRoutes(router) {
  // 基本健康检查端点
  router.get(gatewayConfig.healthCheckEndpoint || '/health', (req, res) => {
    const healthStatus = getGatewayHealthStatus();
    
    logger.info('健康检查请求', {
      status: healthStatus.status,
      uptime: healthStatus.uptime,
      memory_usage: healthStatus.memory_usage,
      service: 'gateway-service'
    });
    
    // 根据状态决定HTTP状态码
    const statusCode = healthStatus.status === 'ok' ? 200 : 503;
    
    res.status(statusCode).json(healthStatus);
  });
  
  // 详细健康检查端点
  router.get('/health/details', async (req, res) => {
    try {
      // 获取网关健康状态
      const gatewayStatus = getGatewayHealthStatus();
      
      // 获取所有微服务的健康状态
      const microservicesHealth = await checkAllMicroservicesHealth();
      
      // 构建详细健康状态
      const detailedStatus = {
        gateway: gatewayStatus,
        microservices: microservicesHealth,
        system: getSystemInfo(),
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || 'unknown'
      };
      
      // 确定整体健康状态
      const allHealthy = gatewayStatus.status === 'ok' && 
                       microservicesHealth.status === 'healthy';
      const statusCode = allHealthy ? 200 : 503;
      
      res.status(statusCode).json(detailedStatus);
    } catch (error) {
      logger.error('详细健康检查失败', { error: error.message, service: 'gateway-service' });
      
      res.status(500).json({
        status: 'error',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  });
  
  // 就绪检查端点（Kubernetes就绪探针）
  router.get('/ready', (req, res) => {
    const readyStatus = getGatewayReadyStatus();
    const statusCode = readyStatus.ready ? 200 : 503;
    
    res.status(statusCode).json(readyStatus);
  });
  
  // 活跃度检查端点（Kubernetes活跃度探针）
  router.get('/live', (req, res) => {
    res.status(200).json({
      status: 'alive',
      timestamp: new Date().toISOString()
    });
  });
}

/**
 * 注册API路由
 */
function registerApiRoutes(router) {
  // API版本前缀路由组
  const apiRouter = express.Router();
  
  // 认证中间件组（可选）
  const authGroup = apiRouter.use(authMiddleware.authenticate());
  
  // 为每个微服务注册路由
  Object.keys(gatewayConfig.microservices).forEach(serviceName => {
    const service = gatewayConfig.microservices[serviceName];
    const routes = gatewayConfig.routes[serviceName] || [];
    
    routes.forEach(route => {
      // 检查是否需要认证
      const routeMiddleware = [];
      
      // 如果路由配置了认证
      if (route.auth) {
        // 添加认证中间件
        routeMiddleware.push(authMiddleware.authenticate());
        
        // 如果配置了角色要求
        if (route.roles && route.roles.length > 0) {
          routeMiddleware.push(authMiddleware.authorize(route.roles));
        }
        
        // 如果配置了权限要求
        if (route.permissions && route.permissions.length > 0) {
          routeMiddleware.push(authMiddleware.checkPermissions(route.permissions));
        }
      }
      
      // 添加自定义中间件（如果有）
      if (route.middleware && Array.isArray(route.middleware)) {
        routeMiddleware.push(...route.middleware);
      }
      
      // 注册路由（使用所有HTTP方法）
      if (route.methods && route.methods.length > 0) {
        // 指定了方法的路由
        route.methods.forEach(method => {
          const httpMethod = method.toLowerCase();
          if (router[httpMethod]) {
            router[httpMethod](route.path, ...routeMiddleware);
            logger.debug('注册带方法的API路由', {
              path: route.path,
              method: method,
              service: serviceName,
              requires_auth: !!route.auth
            });
          }
        });
      } else {
        // 所有方法的路由
        router.use(route.path, ...routeMiddleware);
        logger.debug('注册所有方法的API路由', {
          path: route.path,
          service: serviceName,
          requires_auth: !!route.auth
        });
      }
    });
  });
  
  // 挂载API路由
  if (gatewayConfig.api.basePath) {
    router.use(gatewayConfig.api.basePath, apiRouter);
  }
}

/**
 * 注册管理路由
 */
function registerAdminRoutes(router) {
  // 创建管理路由器
  const adminRouter = express.Router();
  
  // 添加管理认证中间件
  adminRouter.use(authMiddleware.authenticate());
  adminRouter.use(authMiddleware.authorize(['admin', 'superadmin']));
  
  // 网关配置端点
  adminRouter.get('/config', (req, res) => {
    // 返回安全的配置信息（过滤敏感信息）
    const safeConfig = getSafeGatewayConfig();
    
    res.json({
      config: safeConfig,
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || 'development'
    });
  });
  
  // 网关状态端点
  adminRouter.get('/status', (req, res) => {
    res.json({
      status: getGatewayHealthStatus(),
      system: getSystemInfo(),
      microservices: Object.keys(gatewayConfig.microservices),
      timestamp: new Date().toISOString()
    });
  });
  
  // 网关统计端点
  adminRouter.get('/stats', (req, res) => {
    res.json({
      requests: {
        total: req.app.locals.requestCount || 0,
        last_minute: req.app.locals.requestCountLastMinute || 0,
        per_second: (req.app.locals.requestCountLastMinute || 0) / 60
      },
      errors: {
        total: req.app.locals.errorCount || 0,
        last_minute: req.app.locals.errorCountLastMinute || 0
      },
      timestamp: new Date().toISOString()
    });
  });
  
  // 缓存清理端点
  adminRouter.post('/cache/clear', (req, res) => {
    try {
      // 清理网关缓存（如果有）
      if (req.app.locals.cache) {
        req.app.locals.cache.clear();
      }
      
      logger.info('网关缓存已清理', {
        admin_user: req.user?.username || 'unknown',
        service: 'gateway-service'
      });
      
      res.json({
        success: true,
        message: '网关缓存已清理',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      logger.error('缓存清理失败', {
        error: error.message,
        admin_user: req.user?.username || 'unknown',
        service: 'gateway-service'
      });
      
      res.status(500).json({
        success: false,
        error: '缓存清理失败',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }
  });
  
  // 微服务健康检查端点
  adminRouter.get('/health/microservices', async (req, res) => {
    try {
      const healthStatus = await checkAllMicroservicesHealth();
      
      res.json({
        status: healthStatus,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      logger.error('微服务健康检查失败', {
        error: error.message,
        admin_user: req.user?.username || 'unknown',
        service: 'gateway-service'
      });
      
      res.status(500).json({
        success: false,
        error: '健康检查失败',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }
  });
  
  // 挂载管理路由
  router.use('/admin', adminRouter);
  
  logger.info('管理路由配置完成', {
    routes: 5,
    service: 'gateway-service'
  });
}

/**
 * 注册状态路由
 */
function registerStatusRoutes(router) {
  // 基本状态端点
  router.get('/status', (req, res) => {
    res.json({
      status: 'running',
      version: process.env.npm_package_version || 'unknown',
      uptime: process.uptime().toFixed(2) + 's',
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString()
    });
  });
  
  // 版本信息端点
  router.get('/version', (req, res) => {
    res.json({
      version: process.env.npm_package_version || 'unknown',
      node_version: process.version,
      environment: process.env.NODE_ENV || 'development',
      build_date: process.env.BUILD_DATE || 'unknown',
      timestamp: new Date().toISOString()
    });
  });
}

/**
 * 注册错误处理路由
 */
function registerErrorHandlingRoutes(router) {
  // 404处理
  router.use((req, res, next) => {
    logger.warn('未找到的路由', {
      path: req.path,
      method: req.method,
      ip: req.ip,
      service: 'gateway-service'
    });
    
    res.status(404).json({
      error: '资源未找到',
      message: `请求的路径 ${req.path} 不存在`,
      code: 'NOT_FOUND',
      path: req.path,
      method: req.method,
      timestamp: new Date().toISOString()
    });
  });
  
  // 405处理（方法不允许）
  router.use((err, req, res, next) => {
    if (err && err.code === 'METHOD_NOT_ALLOWED') {
      logger.warn('不允许的HTTP方法', {
        path: req.path,
        method: req.method,
        allowed_methods: err.allowedMethods,
        ip: req.ip,
        service: 'gateway-service'
      });
      
      res.status(405).json({
        error: '方法不允许',
        message: `不允许使用 ${req.method} 方法访问此资源`,
        code: 'METHOD_NOT_ALLOWED',
        path: req.path,
        method: req.method,
        allowed_methods: err.allowedMethods,
        timestamp: new Date().toISOString()
      });
    } else {
      next(err);
    }
  });
  
  // 415处理（不支持的媒体类型）
  router.use((err, req, res, next) => {
    if (err && (err.type === 'entity.parse.failed' || err instanceof SyntaxError)) {
      logger.warn('不支持的媒体类型或无效的请求体', {
        path: req.path,
        method: req.method,
        content_type: req.headers['content-type'],
        ip: req.ip,
        service: 'gateway-service'
      });
      
      res.status(415).json({
        error: '不支持的媒体类型',
        message: '请求体格式无效或不支持的媒体类型',
        code: 'UNSUPPORTED_MEDIA_TYPE',
        content_type: req.headers['content-type'],
        timestamp: new Date().toISOString()
      });
    } else {
      next(err);
    }
  });
  
  // 全局错误处理
  router.use((err, req, res, next) => {
    // 记录错误
    logger.error('全局错误处理', {
      error: err.message,
      stack: err.stack,
      path: req.path,
      method: req.method,
      ip: req.ip,
      service: 'gateway-service'
    });
    
    // 检查响应是否已发送
    if (res.headersSent) {
      return next(err);
    }
    
    // 构建错误响应
    const errorResponse = {
      error: err.message || '服务器内部错误',
      code: err.code || 'INTERNAL_ERROR',
      timestamp: new Date().toISOString(),
      path: req.path,
      service: 'gateway-service'
    };
    
    // 发送错误响应
    res.status(err.statusCode || 500).json(errorResponse);
  });
}

/**
 * 获取网关健康状态
 */
function getGatewayHealthStatus() {
  // 基本健康检查
  const isHealthy = true; // 可以添加更复杂的健康检查逻辑
  
  return {
    status: isHealthy ? 'ok' : 'error',
    uptime: process.uptime().toFixed(2) + 's',
    version: process.env.npm_package_version || 'unknown',
    environment: process.env.NODE_ENV || 'development',
    memory_usage: {
      rss: process.memoryUsage().rss,
      heap_used: process.memoryUsage().heapUsed,
      heap_total: process.memoryUsage().heapTotal
    },
    timestamp: new Date().toISOString()
  };
}

/**
 * 获取网关就绪状态
 */
function getGatewayReadyStatus() {
  // 检查必要的服务是否就绪
  const requiredServices = Object.keys(gatewayConfig.microservices);
  
  return {
    ready: true,
    required_services: requiredServices,
    service_count: requiredServices.length,
    uptime: process.uptime().toFixed(2) + 's',
    timestamp: new Date().toISOString()
  };
}

/**
 * 获取系统信息
 */
function getSystemInfo() {
  return {
    node_version: process.version,
    platform: process.platform,
    arch: process.arch,
    cpus: require('os').cpus().length,
    free_memory: require('os').freemem(),
    total_memory: require('os').totalmem(),
    load_avg: require('os').loadavg(),
    uptime: process.uptime().toFixed(2) + 's'
  };
}

/**
 * 获取安全的网关配置（过滤敏感信息）
 */
function getSafeGatewayConfig() {
  const safeConfig = {
    healthCheckEndpoint: gatewayConfig.healthCheckEndpoint,
    api: { ...gatewayConfig.api },
    cors: { ...gatewayConfig.cors },
    proxy: { ...gatewayConfig.proxy },
    security: { ...gatewayConfig.security },
    requestLimits: { ...gatewayConfig.requestLimits },
    rateLimits: { ...gatewayConfig.rateLimits },
    microservices: {}
  };
  
  // 过滤微服务配置中的敏感信息
  Object.keys(gatewayConfig.microservices).forEach(serviceName => {
    const service = gatewayConfig.microservices[serviceName];
    safeConfig.microservices[serviceName] = {
      name: service.name,
      protocol: service.protocol,
      host: service.host,
      port: service.port,
      healthCheckEndpoint: service.healthCheckEndpoint
      // 不包含auth, key, secret等敏感字段
    };
  });
  
  // 移除其他敏感配置
  if (safeConfig.security) {
    delete safeConfig.security.secrets;
    delete safeConfig.security.apiKeys;
  }
  
  if (safeConfig.rateLimits) {
    delete safeConfig.rateLimits.redis;
  }
  
  return safeConfig;
}

module.exports = {
  // 主要函数
  createGatewayRoutes,
  
  // 路由注册函数
  registerHealthCheckRoutes,
  registerApiRoutes,
  registerAdminRoutes,
  registerStatusRoutes,
  registerErrorHandlingRoutes,
  
  // 工具函数
  getGatewayHealthStatus,
  getGatewayReadyStatus,
  getSystemInfo,
  getSafeGatewayConfig
};