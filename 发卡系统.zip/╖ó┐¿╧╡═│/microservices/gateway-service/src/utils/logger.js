const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const path = require('path');

// 确保环境变量已加载
if (!process.env.NODE_ENV) {
  require('dotenv').config();
}

// 日志目录
const logDir = process.env.LOG_DIR || './src/logs';

// 日志级别
const logLevel = process.env.LOG_LEVEL || 'info';
const consoleLevel = process.env.LOG_CONSOLE_LEVEL || 'debug';
const fileLevel = process.env.LOG_FILE_LEVEL || 'info';

// 创建自定义格式器
const customFormat = winston.format.combine(
  winston.format.timestamp({
    format: 'YYYY-MM-DD HH:mm:ss.SSS'
  }),
  winston.format.printf((info) => {
    const { timestamp, level, message, ...meta } = info;
    
    // 格式化元数据
    let metaString = '';
    if (Object.keys(meta).length > 0) {
      // 过滤敏感信息
      const sanitizedMeta = { ...meta };
      if (sanitizedMeta.password) delete sanitizedMeta.password;
      if (sanitizedMeta.token) delete sanitizedMeta.token;
      if (sanitizedMeta.key) delete sanitizedMeta.key;
      if (sanitizedMeta.secret) delete sanitizedMeta.secret;
      if (sanitizedMeta.headers) {
        sanitizedMeta.headers = { ...sanitizedMeta.headers };
        if (sanitizedMeta.headers.authorization) {
          sanitizedMeta.headers.authorization = 'Bearer ***';
        }
      }
      
      try {
        metaString = JSON.stringify(sanitizedMeta, null, 2);
      } catch (error) {
        metaString = String(sanitizedMeta);
      }
    }
    
    return `${timestamp} [${level.toUpperCase()}] ${message} ${metaString}`;
  })
);

// 创建自定义控制台格式器
const consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({
    format: 'HH:mm:ss'
  }),
  winston.format.printf((info) => {
    const { timestamp, level, message, ...meta } = info;
    return `${timestamp} ${level} ${message}`;
  })
);

// 配置日志传输
const transports = [
  // 控制台输出
  new winston.transports.Console({
    level: consoleLevel,
    format: consoleFormat,
    handleExceptions: true
  }),
  
  // 所有日志文件 (按日期轮转)
  new DailyRotateFile({
    filename: path.join(logDir, 'gateway-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: process.env.LOG_FILE_SIZE || '50m',
    maxFiles: process.env.LOG_FILE_RETENTION || '30d',
    level: fileLevel,
    format: customFormat,
    zippedArchive: true
  }),
  
  // 错误日志文件 (按日期轮转)
  new DailyRotateFile({
    filename: path.join(logDir, 'gateway-error-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: process.env.LOG_FILE_SIZE || '50m',
    maxFiles: process.env.LOG_FILE_RETENTION || '30d',
    level: 'error',
    format: customFormat,
    zippedArchive: true
  }),
  
  // HTTP请求日志文件 (按日期轮转)
  new DailyRotateFile({
    filename: path.join(logDir, 'gateway-http-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: process.env.LOG_FILE_SIZE || '50m',
    maxFiles: process.env.LOG_FILE_RETENTION || '30d',
    level: 'info',
    format: customFormat,
    zippedArchive: true
  })
];

// 创建Logger实例
const logger = winston.createLogger({
  level: logLevel,
  format: customFormat,
  transports: transports,
  exceptionHandlers: [
    new DailyRotateFile({
      filename: path.join(logDir, 'gateway-exception-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '50m',
      maxFiles: '30d',
      zippedArchive: true
    })
  ],
  rejectionHandlers: [
    new DailyRotateFile({
      filename: path.join(logDir, 'gateway-rejection-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '50m',
      maxFiles: '30d',
      zippedArchive: true
    })
  ],
  exitOnError: false
});

// 日志方法封装
const gatewayLogger = {
  // 基础日志方法
  debug: (message, meta) => logger.debug(message, meta),
  info: (message, meta) => logger.info(message, meta),
  warn: (message, meta) => logger.warn(message, meta),
  error: (message, meta) => logger.error(message, meta),
  fatal: (message, meta) => logger.error(message, { ...meta, fatal: true }),
  
  // HTTP请求日志
  http: (req, res, responseTime) => {
    const statusCode = res.statusCode;
    const level = statusCode >= 500 ? 'error' : 
                 statusCode >= 400 ? 'warn' : 'info';
    
    const logData = {
      method: req.method,
      path: req.originalUrl,
      status: statusCode,
      ip: req.ip,
      user_agent: req.headers['user-agent'],
      response_time: responseTime,
      content_length: res.getHeader('content-length') || 0,
      referer: req.headers.referer || '-',
      request_id: req.headers['x-request-id'] || req.id || '-',
      service: 'gateway-service'
    };
    
    logger[level](`HTTP ${req.method} ${req.originalUrl} ${statusCode} ${responseTime}ms`, logData);
  },
  
  // 代理请求日志
  proxy: (target, req, res) => {
    logger.info(`Proxy request to ${target}`, {
      method: req.method,
      path: req.originalUrl,
      target_service: target,
      request_id: req.headers['x-request-id'] || '-',
      status: res.statusCode
    });
  },
  
  // 认证日志
  auth: (action, success, userId, meta) => {
    const level = success ? 'info' : 'error';
    logger[level](`Authentication ${action} ${success ? 'successful' : 'failed'}`, {
      action,
      success,
      user_id: userId,
      ip: meta?.ip || '-',
      ...meta
    });
  },
  
  // 错误处理日志
  errorHandler: (error, req, res) => {
    logger.error('Error handling request', {
      error: error.message,
      stack: error.stack,
      path: req.originalUrl,
      method: req.method,
      ip: req.ip,
      request_id: req.headers['x-request-id'] || '-',
      status: res.statusCode
    });
  },
  
  // 安全相关日志
  security: (event, severity, data) => {
    const level = severity === 'high' ? 'error' : 
                 severity === 'medium' ? 'warn' : 'info';
    logger[level](`Security event: ${event}`, {
      event,
      severity,
      ...data
    });
  },
  
  // 服务启动日志
  startup: (config) => {
    logger.info('Gateway service starting', {
      port: config.port,
      env: config.env,
      version: config.version,
      services: config.services
    });
  },
  
  // 服务健康检查日志
  health: (status, details) => {
    const level = status === 'healthy' ? 'info' : 'error';
    logger[level](`Service health check: ${status}`, details);
  },
  
  // 配置变更日志
  configChange: (configName, oldValue, newValue) => {
    logger.info(`Configuration changed: ${configName}`, {
      old_value: oldValue,
      new_value: typeof newValue === 'object' ? 'object' : newValue
    });
  },
  
  // 敏感操作日志 (自动脱敏)
  sensitive: (operation, userId, data) => {
    // 脱敏处理
    const sanitizedData = { ...data };
    Object.keys(sanitizedData).forEach(key => {
      if (['password', 'token', 'key', 'secret', 'credit_card'].some(sensitive => 
          key.toLowerCase().includes(sensitive))
      ) {
        sanitizedData[key] = '***';
      }
    });
    
    logger.info(`Sensitive operation: ${operation}`, {
      operation,
      user_id: userId,
      data: sanitizedData
    });
  }
};

// 导出Logger实例
module.exports = gatewayLogger;

// 全局错误处理
process.on('uncaughtException', (error) => {
  gatewayLogger.error('Uncaught Exception', {
    error: error.message,
    stack: error.stack
  });
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  gatewayLogger.error('Unhandled Rejection', {
    reason: reason instanceof Error ? reason.message : String(reason),
    stack: reason instanceof Error ? reason.stack : undefined
  });
  console.error('Unhandled Rejection:', reason);
});