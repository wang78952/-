const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');

// 配置文件
const { getConfig } = require('./config/inventoryConfig');
const dbConfig = require('./config/dbConfig');
const swaggerConfig = require('./config/swagger');

// 中间件
const { 
  errorHandler, 
  notFoundHandler, 
  timeoutMiddleware,
  securityHeadersMiddleware 
} = require('./middleware/errorMiddleware');
const authMiddleware = require('./middleware/authMiddleware');

// 路由
const inventoryRoutes = require('./routes/inventoryRoutes');

// 工具
const logger = require('./utils/logger');

/**
 * 库存管理微服务应用
 */
class InventoryServiceApp {
  constructor() {
    this.app = express();
    this.config = getConfig();
    this.port = this.config.server?.port || 3000;
    this.setup();
  }

  /**
   * 设置应用程序
   */
  setup() {
    // 初始化数据库连接
    this.initializeDatabase();
    
    // 配置中间件
    this.configureMiddleware();
    
    // 配置路由
    this.configureRoutes();
    
    // 配置错误处理
    this.configureErrorHandling();
  }

  /**
   * 初始化数据库连接
   */
  async initializeDatabase() {
    try {
      logger.info('正在连接数据库...');
      await dbConfig.authenticate();
      logger.info('数据库连接成功');
      
      // 同步数据库模型
      if (this.config.database?.sync === true) {
        logger.info('正在同步数据库模型...');
        await dbConfig.sync({
          alter: this.config.database?.alter === true,
          force: this.config.database?.force === true
        });
        logger.info('数据库模型同步完成');
      }
    } catch (error) {
      logger.error('数据库连接失败:', error);
      throw new Error('无法连接到数据库');
    }
  }

  /**
   * 配置中间件
   */
  configureMiddleware() {
    // 启用安全头部
    this.app.use(helmet());
    this.app.use(securityHeadersMiddleware);
    
    // 配置CORS
    const corsOptions = {
      origin: this.config.cors?.origins || '*',
      methods: this.config.cors?.methods || ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: this.config.cors?.allowedHeaders || ['Origin', 'Content-Type', 'Accept', 'Authorization', 'x-api-key'],
      credentials: this.config.cors?.credentials === true,
      preflightContinue: false,
      optionsSuccessStatus: 204
    };
    this.app.use(cors(corsOptions));
    
    // 配置请求体解析
    this.app.use(express.json({ limit: this.config.request?.bodyLimit || '1mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: this.config.request?.bodyLimit || '1mb' }));
    
    // 配置请求超时
    this.app.use(timeoutMiddleware(this.config.request?.timeout || 30000));
    
    // 配置速率限制
    const limiter = rateLimit({
      windowMs: this.config.rateLimit?.windowMs || 15 * 60 * 1000, // 15分钟
      max: this.config.rateLimit?.max || 100, // 每个IP限制请求数
      standardHeaders: true,
      legacyHeaders: false,
      message: {
        success: false,
        message: '请求过于频繁，请稍后再试',
        code: 'RATE_LIMIT_EXCEEDED'
      },
      skipSuccessfulRequests: this.config.rateLimit?.skipSuccessfulRequests || false
    });
    this.app.use(limiter);
    
    // 配置日志中间件
    if (process.env.NODE_ENV !== 'production') {
      this.app.use(morgan('dev'));
    } else {
      this.app.use(morgan('combined', {
        stream: {
          write: (message) => logger.info(message.trim())
        }
      }));
    }
    
    // 配置Swagger文档
    if (this.config.swagger?.enabled === true) {
      swaggerConfig.configureRoutes(this.app);
    }
  }

  /**
   * 配置路由
   */
  configureRoutes() {
    // 健康检查路由
    this.app.get('/health', this.healthCheck.bind(this));
    
    // 版本信息路由
    this.app.get('/version', this.versionInfo.bind(this));
    
    // API路由组
    const apiRouter = express.Router();
    
    // 库存管理路由
    const inventoryRouter = express.Router();
    
    // 公开路由（不需要认证）
    inventoryRouter.get('/health', this.healthCheck.bind(this));
    
    // 服务间通信路由（使用API密钥认证）
    inventoryRouter.post('/check-stock', 
      authMiddleware.verifyApiKey,
      inventoryRoutes.checkStock
    );
    
    // 需要认证的路由
    inventoryRouter.use(authMiddleware.authenticate);
    
    // 库存管理API路由
    inventoryRouter.get('/', inventoryRoutes.getInventoryList);
    inventoryRouter.get('/:id', inventoryRoutes.getInventoryById);
    inventoryRouter.get('/product/:productId', inventoryRoutes.getInventoryByProductId);
    inventoryRouter.post('/', inventoryRoutes.createInventory);
    inventoryRouter.put('/:id', inventoryRoutes.updateInventory);
    inventoryRouter.post('/:id/increase', inventoryRoutes.increaseStock);
    inventoryRouter.post('/:id/decrease', inventoryRoutes.decreaseStock);
    inventoryRouter.post('/:id/lock', inventoryRoutes.lockStock);
    inventoryRouter.post('/:id/unlock', inventoryRoutes.unlockStock);
    inventoryRouter.post('/batch', inventoryRoutes.batchStockOperation);
    inventoryRouter.get('/:id/history', inventoryRoutes.getInventoryHistory);
    
    // 注册子路由
    apiRouter.use('/inventory', inventoryRouter);
    
    // 注册API路由组
    this.app.use('/api/v1', apiRouter);
  }

  /**
   * 配置错误处理
   */
  configureErrorHandling() {
    // 处理404错误
    this.app.use(notFoundHandler);
    
    // 全局错误处理
    this.app.use(errorHandler);
  }

  /**
   * 健康检查处理程序
   */
  healthCheck(req, res) {
    res.status(200).json({
      success: true,
      message: 'Inventory Service is healthy',
      timestamp: new Date().toISOString(),
      service: 'inventory-service',
      version: '1.0.0'
    });
  }

  /**
   * 版本信息处理程序
   */
  versionInfo(req, res) {
    res.status(200).json({
      success: true,
      service: 'inventory-service',
      version: '1.0.0',
      environment: process.env.NODE_ENV || 'development'
    });
  }

  /**
   * 启动应用程序
   */
  start() {
    this.server = this.app.listen(this.port, () => {
      logger.info(`库存管理微服务已启动，监听端口: ${this.port}`);
      logger.info(`环境: ${process.env.NODE_ENV || 'development'}`);
      
      if (this.config.swagger?.enabled === true) {
        logger.info(`Swagger文档地址: http://localhost:${this.port}/api-docs`);
      }
    });
    
    // 处理服务器关闭
    this.handleServerShutdown();
  }

  /**
   * 处理服务器关闭
   */
  handleServerShutdown() {
    // 优雅关闭处理
    const handleShutdown = async () => {
      logger.info('正在关闭服务器...');
      
      try {
        // 关闭数据库连接
        await dbConfig.close();
        logger.info('数据库连接已关闭');
        
        // 关闭HTTP服务器
        this.server.close(() => {
          logger.info('服务器已关闭');
          process.exit(0);
        });
        
        // 设置超时强制退出
        setTimeout(() => {
          logger.error('服务器关闭超时，强制退出');
          process.exit(1);
        }, 10000);
        
      } catch (error) {
        logger.error('关闭服务器时发生错误:', error);
        process.exit(1);
      }
    };
    
    // 监听终止信号
    process.on('SIGTERM', handleShutdown);
    process.on('SIGINT', handleShutdown);
    
    // 未处理的Promise拒绝
    process.on('unhandledRejection', (reason, promise) => {
      logger.error('未处理的Promise拒绝:', { reason, promise });
    });
    
    // 未捕获的异常
    process.on('uncaughtException', (error) => {
      logger.error('未捕获的异常:', error);
      handleShutdown();
    });
  }

  /**
   * 停止应用程序
   */
  stop() {
    if (this.server) {
      this.server.close();
    }
  }
}

// 创建应用实例
const app = new InventoryServiceApp();

// 导出应用
module.exports = app;

// 如果直接运行此文件，则启动服务器
if (require.main === module) {
  app.start();
}