const swaggerJsDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const { getConfig } = require('./inventoryConfig');

/**
 * Swagger文档配置
 * 为API提供交互式文档
 */
class SwaggerConfig {
  constructor() {
    this.config = getConfig();
    this.options = this.getSwaggerOptions();
  }

  /**
   * 获取Swagger选项配置
   * @returns {Object} Swagger配置选项
   */
  getSwaggerOptions() {
    return {
      definition: {
        openapi: '3.0.0',
        info: {
          title: '库存管理微服务 API',
          version: '1.0.0',
          description: '库存管理微服务的API文档，提供库存查询、增减、锁定等功能',
          contact: {
            name: '开发团队',
            email: 'dev@example.com'
          },
          license: {
            name: 'MIT',
            url: 'https://opensource.org/licenses/MIT'
          }
        },
        servers: [
          {
            url: `http://localhost:${this.config.server?.port || 3000}/api/v1`,
            description: '本地开发环境'
          },
          {
            url: `${this.config.server?.baseUrl || ''}/api/v1`,
            description: '生产环境'
          }
        ],
        components: {
          securitySchemes: {
            bearerAuth: {
              type: 'http',
              scheme: 'bearer',
              bearerFormat: 'JWT',
              description: 'JWT认证令牌'
            },
            apiKey: {
              type: 'apiKey',
              name: 'x-api-key',
              in: 'header',
              description: 'API密钥认证'
            }
          },
          schemas: {
            Inventory: {
              type: 'object',
              properties: {
                id: {
                  type: 'string',
                  description: '库存记录ID'
                },
                product_id: {
                  type: 'string',
                  description: '商品ID'
                },
                available_quantity: {
                  type: 'integer',
                  description: '可用数量'
                },
                total_quantity: {
                  type: 'integer',
                  description: '总数量'
                },
                reserved_quantity: {
                  type: 'integer',
                  description: '预留数量'
                },
                reorder_level: {
                  type: 'integer',
                  description: '重新订购级别'
                },
                reorder_quantity: {
                  type: 'integer',
                  description: '重新订购数量'
                },
                unit_cost: {
                  type: 'number',
                  format: 'double',
                  description: '单位成本'
                },
                last_restocked_date: {
                  type: 'string',
                  format: 'date-time',
                  description: '最后进货日期'
                },
                location: {
                  type: 'string',
                  description: '库存位置'
                },
                status: {
                  type: 'string',
                  enum: ['in_stock', 'low_stock', 'out_of_stock', 'discontinued'],
                  description: '库存状态'
                },
                created_at: {
                  type: 'string',
                  format: 'date-time',
                  description: '创建时间'
                },
                updated_at: {
                  type: 'string',
                  format: 'date-time',
                  description: '更新时间'
                }
              },
              example: {
                id: 'inv-123',
                product_id: 'prod-001',
                available_quantity: 100,
                total_quantity: 150,
                reserved_quantity: 50,
                reorder_level: 10,
                reorder_quantity: 50,
                unit_cost: 99.99,
                last_restocked_date: '2023-05-15T08:30:00Z',
                location: 'Main Warehouse',
                status: 'in_stock',
                created_at: '2023-01-01T00:00:00Z',
                updated_at: '2023-05-15T08:30:00Z'
              }
            },
            InventoryHistory: {
              type: 'object',
              properties: {
                id: {
                  type: 'string',
                  description: '历史记录ID'
                },
                inventory_id: {
                  type: 'string',
                  description: '库存记录ID'
                },
                product_id: {
                  type: 'string',
                  description: '商品ID'
                },
                change_type: {
                  type: 'string',
                  enum: ['increase', 'decrease', 'adjustment', 'lock', 'unlock'],
                  description: '变更类型'
                },
                quantity_changed: {
                  type: 'integer',
                  description: '变更数量'
                },
                previous_quantity: {
                  type: 'integer',
                  description: '变更前数量'
                },
                new_quantity: {
                  type: 'integer',
                  description: '变更后数量'
                },
                reason: {
                  type: 'string',
                  description: '变更原因'
                },
                reference: {
                  type: 'string',
                  description: '参考号（如订单号）'
                },
                created_by: {
                  type: 'string',
                  description: '操作人'
                },
                created_at: {
                  type: 'string',
                  format: 'date-time',
                  description: '操作时间'
                }
              },
              example: {
                id: 'hist-123',
                inventory_id: 'inv-123',
                product_id: 'prod-001',
                change_type: 'increase',
                quantity_changed: 50,
                previous_quantity: 100,
                new_quantity: 150,
                reason: 'Stock replenishment',
                reference: 'PO-2023-05-15-001',
                created_by: 'system',
                created_at: '2023-05-15T08:30:00Z'
              }
            },
            StockCheckRequest: {
              type: 'object',
              required: ['items'],
              properties: {
                items: {
                  type: 'array',
                  items: {
                    type: 'object',
                    required: ['product_id', 'quantity'],
                    properties: {
                      product_id: {
                        type: 'string',
                        description: '商品ID'
                      },
                      quantity: {
                        type: 'integer',
                        description: '需要的数量'
                      }
                    }
                  }
                }
              },
              example: {
                items: [
                  { product_id: 'prod-001', quantity: 5 },
                  { product_id: 'prod-002', quantity: 10 }
                ]
              }
            },
            StockCheckResponse: {
              type: 'object',
              properties: {
                success: {
                  type: 'boolean',
                  description: '所有商品库存是否充足'
                },
                items: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      product_id: {
                        type: 'string',
                        description: '商品ID'
                      },
                      requested_quantity: {
                        type: 'integer',
                        description: '请求的数量'
                      },
                      available_quantity: {
                        type: 'integer',
                        description: '可用数量'
                      },
                      is_available: {
                        type: 'boolean',
                        description: '库存是否充足'
                      }
                    }
                  }
                }
              },
              example: {
                success: true,
                items: [
                  {
                    product_id: 'prod-001',
                    requested_quantity: 5,
                    available_quantity: 100,
                    is_available: true
                  },
                  {
                    product_id: 'prod-002',
                    requested_quantity: 10,
                    available_quantity: 15,
                    is_available: true
                  }
                ]
              }
            },
            ErrorResponse: {
              type: 'object',
              properties: {
                success: {
                  type: 'boolean',
                  description: '请求是否成功'
                },
                message: {
                  type: 'string',
                  description: '错误消息'
                },
                error: {
                  type: 'object',
                  description: '详细错误信息'
                },
                code: {
                  type: 'string',
                  description: '错误代码'
                }
              },
              example: {
                success: false,
                message: '请求参数错误',
                error: { field: 'quantity', message: '数量必须大于0' },
                code: 'VALIDATION_ERROR'
              }
            }
          },
          responses: {
            400: {
              description: '请求参数错误',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                  }
                }
              }
            },
            401: {
              description: '未授权访问',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                  }
                }
              }
            },
            403: {
              description: '禁止访问',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                  }
                }
              }
            },
            404: {
              description: '资源不存在',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                  }
                }
              }
            },
            500: {
              description: '服务器内部错误',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                  }
                }
              }
            }
          }
        },
        security: [
          {
            bearerAuth: []
          }
        ]
      },
      apis: [
        './src/routes/*.js',
        './src/controllers/*.js',
        './src/schemas/*.js'
      ]
    };
  }

  /**
   * 初始化Swagger
   * @returns {Object} 包含swaggerSpec和swaggerUi的对象
   */
  initialize() {
    const swaggerSpec = swaggerJsDoc(this.options);
    return {
      swaggerSpec,
      swaggerUi,
      serve: swaggerUi.serve,
      setup: swaggerUi.setup(swaggerSpec, {
        explorer: true,
        customCss: `.swagger-ui .topbar { background-color: #2c3e50; }`,
        customSiteTitle: '库存管理微服务 API 文档',
        customfavIcon: 'https://cdn.example.com/favicon.ico'
      })
    };
  }

  /**
   * 配置Swagger路由
   * @param {Object} app - Express应用实例
   */
  configureRoutes(app) {
    const { serve, setup } = this.initialize();
    
    // 设置Swagger UI路由
    app.use('/api-docs', serve, setup);
    
    // 设置Swagger JSON路由
    app.get('/api-docs.json', (req, res) => {
      res.setHeader('Content-Type', 'application/json');
      res.send(this.initialize().swaggerSpec);
    });
    
    // 日志记录
    console.log('Swagger文档已配置');
    console.log(`访问地址: http://localhost:${this.config.server?.port || 3000}/api-docs`);
  }
}

module.exports = new SwaggerConfig();