const dotenv = require('dotenv');
const path = require('path');

// 加载环境变量
if (process.env.NODE_ENV !== 'production') {
  dotenv.config({ path: path.resolve(__dirname, '../../.env') });
}

/**
 * 库存管理微服务的核心配置
 * 包含服务配置、API配置、业务规则配置等
 */

const inventoryConfig = {
  // 服务基础配置
  service: {
    name: process.env.SERVICE_NAME || 'inventory-service',
    version: process.env.API_VERSION || 'v1',
    port: process.env.PORT || 3003,
    env: process.env.NODE_ENV || 'development',
    basePath: process.env.API_BASE_PATH || '/api/inventory'
  },
  
  // API配置
  api: {
    requestTimeout: parseInt(process.env.REQUEST_TIMEOUT || 30000),
    maxPageSize: parseInt(process.env.MAX_PAGE_SIZE || 100),
    defaultPageSize: parseInt(process.env.DEFAULT_PAGE_SIZE || 20),
    paginationOffset: 0
  },
  
  // 库存业务规则配置
  inventory: {
    // 库存警报阈值
    alertThreshold: parseInt(process.env.STOCK_ALERT_THRESHOLD || 10),
    // 库存调整批处理大小
    adjustmentBatchSize: parseInt(process.env.STOCK_ADJUSTMENT_BATCH_SIZE || 100),
    // 库存快照间隔（毫秒）
    snapshotInterval: parseInt(process.env.INVENTORY_SNAPSHOT_INTERVAL || 3600000),
    // 库存锁定超时（毫秒）
    lockTimeout: parseInt(process.env.STOCK_LOCK_TIMEOUT || 5000),
    // 事务隔离级别
    isolationLevel: process.env.TRANSACTION_ISOLATION_LEVEL || 'REPEATABLE_READ'
  },
  
  // 安全配置
  security: {
    jwtSecret: process.env.JWT_SECRET || 'your_jwt_secret_key_here',
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '1h',
    httpsEnabled: process.env.HTTPS_ENABLED === 'true',
    sslKeyPath: process.env.SSL_KEY_PATH || '',
    sslCertPath: process.env.SSL_CERT_PATH || '',
    rateLimitWindowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000),
    rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX || 100)
  },
  
  // CORS配置
  cors: {
    enabled: process.env.CORS_ENABLED === 'true',
    allowedOrigins: process.env.ALLOWED_ORIGINS ? 
      process.env.ALLOWED_ORIGINS.split(',') : 
      ['http://localhost:3000', 'http://localhost:8080']
  },
  
  // 日志配置
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: process.env.LOG_FILE || path.join(__dirname, '../../logs/inventory-service.log'),
    fileMaxSize: process.env.LOG_FILE_MAX_SIZE || '5mb',
    fileMaxBackups: parseInt(process.env.LOG_FILE_MAX_BACKUPS || 7)
  },
  
  // 缓存配置
  cache: {
    enabled: process.env.CACHE_ENABLED === 'true',
    ttl: parseInt(process.env.CACHE_TTL || 3600000),
    redisHost: process.env.REDIS_HOST || 'localhost',
    redisPort: process.env.REDIS_PORT || 6379,
    redisPassword: process.env.REDIS_PASSWORD || ''
  },
  
  // 外部服务配置
  externalServices: {
    authService: process.env.AUTH_SERVICE_URL || 'http://localhost:3001/api/auth',
    userService: process.env.USER_SERVICE_URL || 'http://localhost:3001/api/users',
    productService: process.env.PRODUCT_SERVICE_URL || 'http://localhost:3002/api/products',
    orderService: process.env.ORDER_SERVICE_URL || 'http://localhost:3002/api/orders',
    paymentService: process.env.PAYMENT_SERVICE_URL || 'http://localhost:3004/api/payments',
    notificationService: process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:3005/api/notifications'
  },
  
  // 重试配置
  retry: {
    attempts: parseInt(process.env.API_RETRY_ATTEMPTS || 3),
    delay: parseInt(process.env.API_RETRY_DELAY || 1000)
  },
  
  // 健康检查配置
  healthCheck: {
    interval: parseInt(process.env.HEALTH_CHECK_INTERVAL || 60000),
    timeout: parseInt(process.env.HEALTH_CHECK_TIMEOUT || 5000)
  },
  
  // 特性开关配置
  features: {
    batchProcessing: process.env.FEATURE_BATCH_PROCESSING === 'true',
    realTimeUpdates: process.env.FEATURE_REAL_TIME_UPDATES === 'true',
    inventoryForecast: process.env.FEATURE_INVENTORY_FORECAST === 'true',
    stockAlertNotification: process.env.STOCK_ALERT_NOTIFICATION_ENABLED === 'true'
  },
  
  // 分表配置
  sharding: {
    enabled: process.env.SHARDING_TYPE !== 'none',
    type: process.env.SHARDING_TYPE || 'none',
    key: process.env.SHARDING_KEY || 'created_at'
  }
};

/**
 * 验证配置有效性
 * @returns {boolean} 配置是否有效
 */
function validateConfig() {
  let isValid = true;
  const errors = [];
  
  // 验证必填配置
  if (!inventoryConfig.service.port) {
    errors.push('服务端口不能为空');
    isValid = false;
  }
  
  if (!inventoryConfig.security.jwtSecret) {
    errors.push('JWT密钥不能为空');
    isValid = false;
  }
  
  if (inventoryConfig.security.httpsEnabled && (!inventoryConfig.security.sslKeyPath || !inventoryConfig.security.sslCertPath)) {
    errors.push('启用HTTPS时，必须提供SSL密钥和证书路径');
    isValid = false;
  }
  
  if (inventoryConfig.inventory.alertThreshold < 0) {
    errors.push('库存警报阈值不能为负数');
    isValid = false;
  }
  
  if (errors.length > 0) {
    console.error('配置验证失败:', errors);
  }
  
  return { isValid, errors };
}

/**
 * 获取配置信息
 * @param {string} key - 配置键路径，支持点号分隔
 * @returns {*} 配置值
 */
function getConfig(key) {
  if (!key) return inventoryConfig;
  
  const keys = key.split('.');
  let result = inventoryConfig;
  
  for (const k of keys) {
    if (result[k] === undefined) {
      return undefined;
    }
    result = result[k];
  }
  
  return result;
}

/**
 * 更新配置（运行时）
 * @param {string} key - 配置键路径
 * @param {*} value - 新的配置值
 * @returns {boolean} 更新是否成功
 */
function updateConfig(key, value) {
  if (!key) return false;
  
  const keys = key.split('.');
  let obj = inventoryConfig;
  
  for (let i = 0; i < keys.length - 1; i++) {
    if (obj[keys[i]] === undefined) {
      return false;
    }
    obj = obj[keys[i]];
  }
  
  const lastKey = keys[keys.length - 1];
  obj[lastKey] = value;
  
  return true;
}

/**
 * 导出配置信息（不包含敏感信息）
 * @returns {Object} 安全的配置信息
 */
function exportSafeConfig() {
  const safeConfig = JSON.parse(JSON.stringify(inventoryConfig));
  
  // 移除敏感信息
  safeConfig.security.jwtSecret = '******';
  
  if (safeConfig.cache) {
    safeConfig.cache.redisPassword = '******';
  }
  
  return safeConfig;
}

module.exports = {
  ...inventoryConfig,
  validateConfig,
  getConfig,
  updateConfig,
  exportSafeConfig
};