const Sequelize = require('sequelize');
const dotenv = require('dotenv');
const path = require('path');

// 加载环境变量
if (process.env.NODE_ENV !== 'production') {
  dotenv.config({ path: path.resolve(__dirname, '../../.env') });
}

/**
 * 库存管理微服务的数据库配置
 * 支持MySQL、PostgreSQL等多种数据库
 */

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  username: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '123456',
  database: process.env.DB_NAME || 'card_inventory',
  dialect: process.env.DB_DIALECT || 'mysql',
  pool: {
    max: parseInt(process.env.DB_POOL_MAX || 10),
    min: parseInt(process.env.DB_POOL_MIN || 0),
    idle: parseInt(process.env.DB_POOL_IDLE || 10000),
    acquire: parseInt(process.env.DB_POOL_ACQUIRE || 60000)
  },
  define: {
    timestamps: true,
    paranoid: true,
    underscored: true,
    freezeTableName: true
  },
  // 连接池配置
  retry: {
    match: [
      /ETIMEDOUT/,
      /EHOSTUNREACH/,
      /ECONNRESET/,
      /ECONNREFUSED/,
      /ESOCKETTIMEDOUT/,
      /EAI_AGAIN/
    ],
    max: parseInt(process.env.DB_RETRY_MAX || 5)
  },
  // 连接选项
  dialectOptions: {
    connectTimeout: 10000,
    ...(process.env.DB_DIALECT === 'mysql' ? {
      dateStrings: true,
      typeCast: true
    } : {})
  }
};

/**
 * 创建数据库连接实例
 */
const sequelize = new Sequelize(
  dbConfig.database,
  dbConfig.username,
  dbConfig.password,
  dbConfig
);

/**
 * 测试数据库连接
 * @returns {Promise<boolean>} 连接是否成功
 */
async function testDatabaseConnection() {
  try {
    await sequelize.authenticate();
    console.log('数据库连接成功');
    return true;
  } catch (error) {
    console.error('数据库连接失败:', error.message);
    return false;
  }
}

/**
 * 同步数据库模型
 * @param {boolean} force - 是否强制同步（删除并重新创建表）
 * @returns {Promise<void>}
 */
async function syncDatabaseModels(force = false) {
  try {
    await sequelize.sync({ force });
    console.log(`数据库模型${force ? '强制' : ''}同步成功`);
  } catch (error) {
    console.error('数据库模型同步失败:', error.message);
    throw error;
  }
}

/**
 * 关闭数据库连接
 * @returns {Promise<void>}
 */
async function closeDatabaseConnection() {
  try {
    await sequelize.close();
    console.log('数据库连接已关闭');
  } catch (error) {
    console.error('关闭数据库连接失败:', error.message);
    throw error;
  }
}

/**
 * 获取数据库连接状态
 * @returns {Object} 连接状态信息
 */
function getConnectionStatus() {
  return {
    isConnected: sequelize.connectionManager.state === 'authenticated',
    database: dbConfig.database,
    dialect: dbConfig.dialect,
    host: dbConfig.host,
    port: dbConfig.port,
    pool: {
      max: dbConfig.pool.max,
      min: dbConfig.pool.min,
      idle: dbConfig.pool.idle
    }
  };
}

/**
 * 执行原始SQL查询
 * @param {string} sql - SQL查询语句
 * @param {Array} parameters - 查询参数
 * @returns {Promise<Array>} 查询结果
 */
async function executeRawQuery(sql, parameters = []) {
  try {
    const [results] = await sequelize.query(sql, {
      replacements: parameters,
      type: Sequelize.QueryTypes.SELECT
    });
    return results;
  } catch (error) {
    console.error('执行SQL查询失败:', error.message);
    throw error;
  }
}

/**
 * 开始事务
 * @returns {Promise<Sequelize.Transaction>} 事务对象
 */
async function startTransaction() {
  return await sequelize.transaction();
}

module.exports = {
  sequelize,
  Sequelize,
  dbConfig,
  testDatabaseConnection,
  syncDatabaseModels,
  closeDatabaseConnection,
  getConnectionStatus,
  executeRawQuery,
  startTransaction
};