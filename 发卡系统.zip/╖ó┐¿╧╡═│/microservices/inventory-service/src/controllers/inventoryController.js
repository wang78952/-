const inventoryService = require('../services/InventoryService');
const { 
  successResponse, 
  errorResponse, 
  paginationResponse,
  notFoundResponse,
  validationErrorResponse,
  buildPagination 
} = require('../utils/responseFormatter');
const logger = require('../utils/logger');

/**
 * 库存控制器
 * 处理与库存相关的HTTP请求
 */
class InventoryController {
  /**
   * 获取库存列表
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async getInventoryList(req, res) {
    try {
      const { 
        product_id, 
        isLowStock, 
        page = 1, 
        pageSize = 20 
      } = req.query;

      // 构建查询参数
      const queryParams = {
        product_id,
        isLowStock: isLowStock === 'true',
        limit: pageSize,
        offset: (page - 1) * pageSize
      };

      // 获取库存数据
      const inventories = await inventoryService.getAllInventory(queryParams);
      
      // 计算总数（实际项目中应该单独调用一个获取总数的方法）
      const totalItems = inventories.length;
      const pagination = buildPagination(totalItems, page, pageSize);

      return paginationResponse(res, inventories, pagination, '获取库存列表成功');
    } catch (error) {
      logger.error('获取库存列表失败:', error);
      return errorResponse(res, error.message || '获取库存列表失败', 500);
    }
  }

  /**
   * 获取单个库存信息
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async getInventoryById(req, res) {
    try {
      const { id } = req.params;

      if (!id || isNaN(parseInt(id))) {
        return validationErrorResponse(res, [{ field: 'id', message: '无效的库存ID' }]);
      }

      const inventory = await inventoryService.getInventoryById(parseInt(id));
      
      if (!inventory) {
        return notFoundResponse(res, '库存记录不存在');
      }

      return successResponse(res, inventory, '获取库存信息成功');
    } catch (error) {
      logger.error(`获取库存信息失败，ID: ${req.params.id}`, error);
      
      if (error.message && error.message.includes('不存在')) {
        return notFoundResponse(res, error.message);
      }
      
      return errorResponse(res, error.message || '获取库存信息失败', 500);
    }
  }

  /**
   * 根据商品ID获取库存信息
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async getInventoryByProductId(req, res) {
    try {
      const { product_id } = req.params;

      if (!product_id || isNaN(parseInt(product_id))) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '无效的商品ID' }]);
      }

      const inventory = await inventoryService.getInventoryByProductId(parseInt(product_id));
      
      if (!inventory) {
        return notFoundResponse(res, '该商品的库存记录不存在');
      }

      return successResponse(res, inventory, '获取商品库存信息成功');
    } catch (error) {
      logger.error(`获取商品库存信息失败，商品ID: ${req.params.product_id}`, error);
      
      if (error.message && error.message.includes('不存在')) {
        return notFoundResponse(res, error.message);
      }
      
      return errorResponse(res, error.message || '获取商品库存信息失败', 500);
    }
  }

  /**
   * 创建库存记录
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async createInventory(req, res) {
    try {
      const inventoryData = req.body;

      // 验证必要字段
      if (!inventoryData.product_id) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '商品ID不能为空' }]);
      }

      if (!inventoryData.available_quantity && inventoryData.available_quantity !== 0) {
        return validationErrorResponse(res, [{ field: 'available_quantity', message: '可用数量不能为空' }]);
      }

      // 设置操作者ID（从认证中间件获取）
      inventoryData.operator_id = req.user?.id || null;

      const inventory = await inventoryService.createInventory(inventoryData);
      
      return successResponse(res, inventory, '创建库存记录成功', 201);
    } catch (error) {
      logger.error('创建库存记录失败:', error);
      
      if (error.message && error.message.includes('已存在')) {
        return errorResponse(res, error.message, 400);
      }
      
      return errorResponse(res, error.message || '创建库存记录失败', 500);
    }
  }

  /**
   * 更新库存信息
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async updateInventory(req, res) {
    try {
      const { id } = req.params;
      const inventoryData = req.body;

      if (!id || isNaN(parseInt(id))) {
        return validationErrorResponse(res, [{ field: 'id', message: '无效的库存ID' }]);
      }

      // 设置操作者ID
      inventoryData.operator_id = req.user?.id || null;

      const inventory = await inventoryService.updateInventory(parseInt(id), inventoryData);
      
      return successResponse(res, inventory, '更新库存信息成功');
    } catch (error) {
      logger.error(`更新库存信息失败，ID: ${req.params.id}`, error);
      
      if (error.message && error.message.includes('不存在')) {
        return notFoundResponse(res, error.message);
      }
      
      return errorResponse(res, error.message || '更新库存信息失败', 500);
    }
  }

  /**
   * 增加库存
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async increaseStock(req, res) {
    try {
      const { product_id } = req.params;
      const { quantity, reason, order_id, source_location } = req.body;

      // 验证参数
      if (!product_id || isNaN(parseInt(product_id))) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '无效的商品ID' }]);
      }

      if (!quantity || quantity <= 0 || isNaN(parseInt(quantity))) {
        return validationErrorResponse(res, [{ field: 'quantity', message: '数量必须为正整数' }]);
      }

      const options = {
        reason,
        order_id,
        source_location,
        operator_id: req.user?.id || null
      };

      const inventory = await inventoryService.increaseStock(parseInt(product_id), parseInt(quantity), options);
      
      return successResponse(res, inventory, '增加库存成功');
    } catch (error) {
      logger.error(`增加库存失败，商品ID: ${req.params.product_id}`, error);
      return errorResponse(res, error.message || '增加库存失败', 500);
    }
  }

  /**
   * 减少库存
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async decreaseStock(req, res) {
    try {
      const { product_id } = req.params;
      const { quantity, reason, order_id, target_location } = req.body;

      // 验证参数
      if (!product_id || isNaN(parseInt(product_id))) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '无效的商品ID' }]);
      }

      if (!quantity || quantity <= 0 || isNaN(parseInt(quantity))) {
        return validationErrorResponse(res, [{ field: 'quantity', message: '数量必须为正整数' }]);
      }

      const options = {
        reason,
        order_id,
        target_location,
        operator_id: req.user?.id || null
      };

      const inventory = await inventoryService.decreaseStock(parseInt(product_id), parseInt(quantity), options);
      
      return successResponse(res, inventory, '减少库存成功');
    } catch (error) {
      logger.error(`减少库存失败，商品ID: ${req.params.product_id}`, error);
      
      if (error.message && error.message.includes('库存不足')) {
        return errorResponse(res, error.message, 400);
      }
      
      return errorResponse(res, error.message || '减少库存失败', 500);
    }
  }

  /**
   * 锁定库存
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async lockInventory(req, res) {
    try {
      const { product_id } = req.params;
      const { quantity, reason, order_id } = req.body;

      // 验证参数
      if (!product_id || isNaN(parseInt(product_id))) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '无效的商品ID' }]);
      }

      if (!quantity || quantity <= 0 || isNaN(parseInt(quantity))) {
        return validationErrorResponse(res, [{ field: 'quantity', message: '数量必须为正整数' }]);
      }

      const options = {
        reason: reason || '锁定库存用于订单',
        order_id,
        operator_id: req.user?.id || null
      };

      const inventory = await inventoryService.lockInventory(parseInt(product_id), parseInt(quantity), options);
      
      return successResponse(res, inventory, '锁定库存成功');
    } catch (error) {
      logger.error(`锁定库存失败，商品ID: ${req.params.product_id}`, error);
      
      if (error.message && error.message.includes('库存不足')) {
        return errorResponse(res, error.message, 400);
      }
      
      return errorResponse(res, error.message || '锁定库存失败', 500);
    }
  }

  /**
   * 解锁库存
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async unlockInventory(req, res) {
    try {
      const { product_id } = req.params;
      const { quantity, reason, order_id } = req.body;

      // 验证参数
      if (!product_id || isNaN(parseInt(product_id))) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '无效的商品ID' }]);
      }

      if (!quantity || quantity <= 0 || isNaN(parseInt(quantity))) {
        return validationErrorResponse(res, [{ field: 'quantity', message: '数量必须为正整数' }]);
      }

      const options = {
        reason: reason || '解锁库存',
        order_id,
        operator_id: req.user?.id || null
      };

      const inventory = await inventoryService.unlockInventory(parseInt(product_id), parseInt(quantity), options);
      
      return successResponse(res, inventory, '解锁库存成功');
    } catch (error) {
      logger.error(`解锁库存失败，商品ID: ${req.params.product_id}`, error);
      
      if (error.message && error.message.includes('锁定库存不足')) {
        return errorResponse(res, error.message, 400);
      }
      
      return errorResponse(res, error.message || '解锁库存失败', 500);
    }
  }

  /**
   * 批量处理库存操作
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async batchProcessInventory(req, res) {
    try {
      const operations = req.body;

      // 验证操作列表
      if (!Array.isArray(operations) || operations.length === 0) {
        return validationErrorResponse(res, [{ field: 'operations', message: '操作列表不能为空' }]);
      }

      // 验证每个操作
      for (let i = 0; i < operations.length; i++) {
        const op = operations[i];
        
        if (!op.product_id || isNaN(parseInt(op.product_id))) {
          return validationErrorResponse(res, [{ field: `operations[${i}].product_id`, message: '无效的商品ID' }]);
        }

        if (!op.quantity || op.quantity <= 0 || isNaN(parseInt(op.quantity))) {
          return validationErrorResponse(res, [{ field: `operations[${i}].quantity`, message: '数量必须为正整数' }]);
        }

        if (!['increase', 'decrease', 'lock', 'unlock'].includes(op.operation_type)) {
          return validationErrorResponse(res, [{ field: `operations[${i}].operation_type`, message: '无效的操作类型' }]);
        }

        // 添加操作者ID
        op.operator_id = req.user?.id || null;
      }

      const result = await inventoryService.batchProcessInventory(operations);
      
      return successResponse(res, result, '批量处理库存操作成功');
    } catch (error) {
      logger.error('批量处理库存操作失败:', error);
      return errorResponse(res, error.message || '批量处理库存操作失败', 500);
    }
  }

  /**
   * 获取库存变动历史
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async getInventoryHistory(req, res) {
    try {
      const { 
        inventory_id, 
        product_id, 
        change_type, 
        start_date, 
        end_date,
        page = 1, 
        pageSize = 20 
      } = req.query;

      const queryParams = {
        inventory_id: inventory_id ? parseInt(inventory_id) : undefined,
        product_id: product_id ? parseInt(product_id) : undefined,
        change_type,
        start_date,
        end_date,
        limit: pageSize,
        offset: (page - 1) * pageSize
      };

      const histories = await inventoryService.getInventoryHistory(queryParams);
      
      // 构建分页信息
      const totalItems = histories.length;
      const pagination = buildPagination(totalItems, page, pageSize);

      return paginationResponse(res, histories, pagination, '获取库存变动历史成功');
    } catch (error) {
      logger.error('获取库存变动历史失败:', error);
      return errorResponse(res, error.message || '获取库存变动历史失败', 500);
    }
  }

  /**
   * 检查库存充足性
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async checkStockAvailability(req, res) {
    try {
      const { product_id } = req.params;
      const { quantity } = req.query;

      // 验证参数
      if (!product_id || isNaN(parseInt(product_id))) {
        return validationErrorResponse(res, [{ field: 'product_id', message: '无效的商品ID' }]);
      }

      if (!quantity || quantity <= 0 || isNaN(parseInt(quantity))) {
        return validationErrorResponse(res, [{ field: 'quantity', message: '数量必须为正整数' }]);
      }

      const result = await inventoryService.checkStockAvailability(parseInt(product_id), parseInt(quantity));
      
      return successResponse(res, result, '检查库存充足性成功');
    } catch (error) {
      logger.error(`检查库存充足性失败，商品ID: ${req.params.product_id}`, error);
      return errorResponse(res, error.message || '检查库存充足性失败', 500);
    }
  }
}

module.exports = new InventoryController();