# 创建src目录
mkdir -p src

# 创建src下的子目录
mkdir -p src/config
mkdir -p src/controllers
mkdir -p src/models
mkdir -p src/services
mkdir -p src/middleware
mkdir -p src/routes
mkdir -p src/utils
mkdir -p src/schemas
mkdir -p src/logs

# 创建services下的external目录
mkdir -p src/services/external

# 输出创建结果
Get-ChildItem -Recurse src | Select-Object FullName