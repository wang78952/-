# 库存管理微服务

一个独立的库存管理微服务，提供库存查询、增减、锁定等功能。

## 功能特性

- 库存记录管理：创建、更新、查询库存信息
- 库存操作：增加、减少、锁定、解锁库存
- 批量操作：支持批量库存操作
- 库存历史记录：跟踪所有库存变动
- 库存检查：支持多商品库存充足性检查
- 安全认证：JWT认证和API密钥认证
- 完整的错误处理和日志记录
- API文档：Swagger UI文档

## 技术栈

- Node.js
- Express.js
- Sequelize ORM
- MySQL/MariaDB
- JWT认证
- Swagger API文档
- Winston日志

## 目录结构

```
./inventory-service/
├── src/
│   ├── config/          # 配置文件
│   ├── controllers/     # 控制器
│   ├── middleware/      # 中间件
│   ├── models/          # 数据模型
│   ├── routes/          # 路由
│   ├── schemas/         # 数据验证模式
│   ├── services/        # 业务逻辑层
│   ├── utils/           # 工具函数
│   ├── app.js           # 应用程序文件
│   └── index.js         # 入口文件
├── .env                 # 环境变量
├── .env.example         # 环境变量示例
├── package.json         # 项目配置和依赖
└── README.md            # 项目文档
```

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境变量

复制环境变量示例文件并配置必要的变量：

```bash
cp .env.example .env
```

编辑 `.env` 文件，设置数据库连接信息和其他配置。

### 3. 启动服务

开发环境：
```bash
npm run dev
```

生产环境：
```bash
npm start
```

### 4. 访问API文档

启动服务后，可以通过以下地址访问Swagger API文档：

```
http://localhost:3000/api-docs
```

## API端点

### 库存管理

- `GET /api/v1/inventory` - 获取库存列表
- `GET /api/v1/inventory/:id` - 根据ID获取库存
- `GET /api/v1/inventory/product/:productId` - 根据商品ID获取库存
- `POST /api/v1/inventory` - 创建库存记录
- `PUT /api/v1/inventory/:id` - 更新库存记录
- `POST /api/v1/inventory/:id/increase` - 增加库存
- `POST /api/v1/inventory/:id/decrease` - 减少库存
- `POST /api/v1/inventory/:id/lock` - 锁定库存
- `POST /api/v1/inventory/:id/unlock` - 解锁库存
- `POST /api/v1/inventory/batch` - 批量库存操作
- `GET /api/v1/inventory/:id/history` - 获取库存变动历史
- `POST /api/v1/inventory/check-stock` - 检查库存充足性（服务间通信）

### 健康检查

- `GET /health` - 服务健康状态检查
- `GET /version` - 服务版本信息

## 环境变量

| 环境变量 | 说明 | 默认值 | 必须 |
|---------|------|--------|------|
| NODE_ENV | 运行环境 | development | 否 |
| PORT | 服务端口 | 3000 | 否 |
| DB_HOST | 数据库主机 | localhost | 是 |
| DB_PORT | 数据库端口 | 3306 | 否 |
| DB_USER | 数据库用户 | root | 是 |
| DB_PASSWORD | 数据库密码 | - | 否 |
| DB_NAME | 数据库名称 | inventory | 是 |
| JWT_SECRET | JWT密钥 | - | 是 |
| JWT_EXPIRY | JWT过期时间 | 1h | 否 |
| API_KEY | API密钥 | - | 是 |
| LOG_LEVEL | 日志级别 | info | 否 |
| SWAGGER_ENABLED | 启用Swagger | true | 否 |

## 数据库模型

### Inventory（库存）
- id: 库存ID
- product_id: 商品ID
- available_quantity: 可用数量
- total_quantity: 总数量
- reserved_quantity: 预留数量
- reorder_level: 重新订购级别
- reorder_quantity: 重新订购数量
- unit_cost: 单位成本
- last_restocked_date: 最后进货日期
- location: 库存位置
- status: 库存状态

### InventoryHistory（库存历史）
- id: 历史记录ID
- inventory_id: 库存ID
- product_id: 商品ID
- change_type: 变更类型
- quantity_changed: 变更数量
- previous_quantity: 变更前数量
- new_quantity: 变更后数量
- reason: 变更原因
- reference: 参考号
- created_by: 操作人

## 安全措施

- JWT认证保护API
- API密钥用于服务间通信
- 输入验证和清理
- 速率限制防止暴力攻击
- 安全HTTP头部
- 详细的访问日志记录

## 错误处理

服务提供全面的错误处理机制，包括：
- 验证错误（400 Bad Request）
- 认证错误（401 Unauthorized）
- 授权错误（403 Forbidden）
- 资源不存在（404 Not Found）
- 服务器错误（500 Internal Server Error）

所有错误都以统一的JSON格式返回，并包含适当的错误消息和代码。

## 日志记录

服务使用Winston进行日志记录，记录以下信息：
- API请求和响应
- 数据库操作
- 错误和异常
- 认证尝试

日志文件默认保存在`src/logs/`目录下。

## 部署

### Docker部署

可以使用以下Dockerfile进行容器化部署：

```dockerfile
FROM node:14-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

ENV NODE_ENV production
EXPOSE 3000

CMD ["npm", "start"]
```

### Kubernetes部署

可以使用Kubernetes进行服务编排和管理，包括部署、服务和配置映射。

## 监控

服务提供健康检查端点，可以与Prometheus、Grafana等监控工具集成，实现服务监控和告警。

## 测试

### 单元测试

```bash
npm test
```

### 集成测试

```bash
npm run test:integration
```

## 贡献

欢迎提交问题和拉取请求。请确保代码遵循项目的编码规范，并通过所有测试。

## 许可证

[MIT](LICENSE)

## 联系方式

如有问题或建议，请联系开发团队。