const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const appConfig = require('./config/app');
const logger = require('./utils/logger');
const apiRoutes = require('./routes');
const rateLimitMiddleware = require('./middleware/rateLimitMiddleware');
const authMiddleware = require('./middleware/authMiddleware');

/**
 * API网关应用类
 */
class ApiGatewayApp {
  constructor() {
    this.app = express();
    this.initializeApp();
  }

  /**
   * 初始化应用
   */
  initializeApp() {
    // 验证配置
    if (!appConfig.validate()) {
      throw new Error('Invalid configuration');
    }
    
    // 设置基础中间件
    this.setupBaseMiddlewares();
    
    // 设置安全中间件
    this.setupSecurityMiddlewares();
    
    // 设置限流中间件
    this.setupRateLimitMiddlewares();
    
    // 设置路由
    this.setupRoutes();
    
    // 设置错误处理中间件
    this.setupErrorHandlers();
  }

  /**
   * 设置基础中间件
   */
  setupBaseMiddlewares() {
    // 请求ID中间件
    this.app.use(logger.getRequestIdMiddleware());
    
    // 请求体解析中间件
    this.app.use(express.json({ limit: '1mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '1mb' }));
    
    // 压缩中间件
    this.app.use(compression());
    
    // 日志中间件
    if (appConfig.nodeEnv !== 'production') {
      this.app.use(morgan('dev'));
    }
    
    // 自定义日志中间件
    this.app.use(logger.getExpressMiddleware());
  }

  /**
   * 设置安全中间件
   */
  setupSecurityMiddlewares() {
    // Helmet安全头中间件
    this.app.use(helmet());
    
    // CORS配置
    const corsOptions = {
      origin: this.getCorsOrigins(),
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Origin', 'X-Requested-With', 'Content-Type', 'Accept', 'Authorization', appConfig.apiKeyHeader],
      exposedHeaders: ['X-Request-Id', 'X-RateLimit-Limit', 'X-RateLimit-Remaining'],
      credentials: true,
      maxAge: 86400
    };
    
    this.app.use(cors(corsOptions));
    
    // 预飞请求处理
    this.app.options('*', cors(corsOptions));
    
    // 安全相关的自定义中间件
    this.app.use(this.securityHeadersMiddleware());
  }

  /**
   * 设置限流中间件
   */
  setupRateLimitMiddlewares() {
    // 全局限流
    this.app.use(rateLimitMiddleware.getLimiter('global'));
    
    // API密钥限流
    this.app.use(rateLimitMiddleware.createApiKeyLimiter());
    
    // 基于路径的动态限流（可选）
    const pathLimits = {
      '/api/intensive/*': { windowMs: 60000, max: 50 },
      '/api/search/*': { windowMs: 60000, max: 200 }
    };
    
    this.app.use(rateLimitMiddleware.createPathBasedLimiter(pathLimits));
  }

  /**
   * 设置路由
   */
  setupRoutes() {
    // API版本前缀
    this.app.use('/v1', apiRoutes);
    
    // 根路径重定向到健康检查
    this.app.get('/', (req, res) => {
      res.redirect('/health');
    });
    
    // 404处理
    this.app.use((req, res, next) => {
      const error = new Error('Not Found');
      error.status = 404;
      next(error);
    });
  }

  /**
   * 设置错误处理中间件
   */
  setupErrorHandlers() {
    // 统一错误处理
    this.app.use((error, req, res, next) => {
      // 记录错误
      logger.logError(error, {
        path: req.path,
        method: req.method,
        userId: req.user?.userId,
        requestId: req.id
      });
      
      // 设置默认错误状态和消息
      const status = error.status || 500;
      const message = error.message || 'Internal Server Error';
      
      // 构建错误响应
      const errorResponse = {
        error: status === 500 ? 'Internal Server Error' : message,
        message: appConfig.nodeEnv === 'development' ? message : (status === 500 ? 'Something went wrong' : message),
        code: error.code || 'INTERNAL_ERROR',
        timestamp: new Date().toISOString(),
        requestId: req.id
      };
      
      // 在开发环境中添加详细错误信息
      if (appConfig.nodeEnv === 'development' && status === 500) {
        errorResponse.stack = error.stack;
      }
      
      // 发送错误响应
      res.status(status).json(errorResponse);
    });
  }

  /**
   * 获取CORS配置的来源
   * @returns {Array|string} CORS来源
   */
  getCorsOrigins() {
    if (appConfig.corsOrigins === '*') {
      return '*';
    }
    
    return appConfig.corsOrigins.split(',').map(origin => origin.trim());
  }

  /**
   * 安全头中间件
   * @returns {function} Express中间件函数
   */
  securityHeadersMiddleware() {
    return (req, res, next) => {
      // 添加服务器标识头
      res.setHeader('X-Powered-By', 'API Gateway');
      
      // 添加API网关版本头
      res.setHeader('X-API-Version', 'v1');
      
      // 添加响应时间头
      const startTime = Date.now();
      const send = res.send;
      
      res.send = function(body) {
        res.setHeader('X-Response-Time', `${Date.now() - startTime}ms`);
        return send.call(this, body);
      };
      
      next();
    };
  }

  /**
   * 获取Express应用实例
   * @returns {object} Express应用实例
   */
  getApp() {
    return this.app;
  }

  /**
   * 启动服务器
   * @param {number} port - 端口号
   * @returns {Promise} 服务器启动Promise
   */
  startServer(port) {
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(port || appConfig.port, () => {
        logger.info('API Gateway started', {
          port: port || appConfig.port,
          environment: appConfig.nodeEnv,
          ...appConfig.getSummary()
        });
        
        resolve(this.server);
      }).on('error', (error) => {
        logger.error('Failed to start API Gateway', { error: error.message });
        reject(error);
      });
    });
  }

  /**
   * 关闭服务器
   * @returns {Promise} 服务器关闭Promise
   */
  closeServer() {
    return new Promise((resolve, reject) => {
      if (!this.server) {
        resolve();
        return;
      }
      
      logger.logShutdown();
      
      this.server.close((error) => {
        if (error) {
          logger.error('Error closing server', { error: error.message });
          reject(error);
          return;
        }
        
        logger.info('Server closed successfully');
        resolve();
      });
    });
  }

  /**
   * 处理优雅关闭
   */
  setupGracefulShutdown() {
    process.on('SIGTERM', () => {
      logger.info('Received SIGTERM signal');
      this.closeServer().then(() => {
        process.exit(0);
      }).catch(() => {
        process.exit(1);
      });
    });
    
    process.on('SIGINT', () => {
      logger.info('Received SIGINT signal');
      this.closeServer().then(() => {
        process.exit(0);
      }).catch(() => {
        process.exit(1);
      });
    });
  }
}

// 导出应用实例
module.exports = ApiGatewayApp;