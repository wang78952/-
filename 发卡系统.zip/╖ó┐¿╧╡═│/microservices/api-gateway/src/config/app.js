const dotenv = require('dotenv');
const path = require('path');

// 加载环境变量
if (process.env.NODE_ENV !== 'production') {
  dotenv.config({ path: path.join(__dirname, '..', '..', '.env') });
}

/**
 * API网关配置管理类
 */
class AppConfig {
  constructor() {
    // 基础服务配置
    this.port = this.getEnv('PORT', 8000);
    this.nodeEnv = this.getEnv('NODE_ENV', 'development');
    this.logLevel = this.getEnv('LOG_LEVEL', 'info');
    
    // 安全配置
    this.jwtSecret = this.getEnv('JWT_SECRET', 'default_jwt_secret');
    this.jwtExpiration = this.getEnv('JWT_EXPIRATION', '24h');
    this.apiKeyHeader = this.getEnv('API_KEY_HEADER', 'X-API-Key');
    
    // 限流配置
    this.rateLimitWindowMs = this.getEnv('RATE_LIMIT_WINDOW_MS', 60000, 'number');
    this.rateLimitMax = this.getEnv('RATE_LIMIT_MAX', 100, 'number');
    
    // CORS配置
    this.corsOrigins = this.getEnv('CORS_ORIGINS', '*');
    
    // 微服务路由配置
    this.microservices = {
      auth: this.getEnv('AUTH_SERVICE_URL', 'http://localhost:8001'),
      user: this.getEnv('USER_SERVICE_URL', 'http://localhost:8002'),
      product: this.getEnv('PRODUCT_SERVICE_URL', 'http://localhost:8003'),
      order: this.getEnv('ORDER_SERVICE_URL', 'http://localhost:8004'),
      payment: this.getEnv('PAYMENT_SERVICE_URL', 'http://localhost:8005'),
      analytics: this.getEnv('ANALYTICS_SERVICE_URL', 'http://localhost:8006'),
      notification: this.getEnv('NOTIFICATION_SERVICE_URL', 'http://localhost:8007'),
      logging: this.getEnv('LOGGING_SERVICE_URL', 'http://localhost:8008')
    };
    
    // 缓存配置
    this.cacheTTL = this.getEnv('CACHE_TTL', 3600000, 'number');
    
    // 健康检查配置
    this.healthCheckInterval = this.getEnv('HEALTH_CHECK_INTERVAL', 30000, 'number');
    
    // 超时配置
    this.proxyTimeout = this.getEnv('PROXY_TIMEOUT', 30000, 'number');
    this.requestTimeout = this.getEnv('REQUEST_TIMEOUT', 5000, 'number');
    
    // 熔断器配置
    this.circuitBreakerEnabled = this.getEnv('CIRCUIT_BREAKER_ENABLED', true, 'boolean');
    this.circuitBreakerFailureThreshold = this.getEnv('CIRCUIT_BREAKER_FAILURE_THRESHOLD', 5, 'number');
    this.circuitBreakerResetTimeout = this.getEnv('CIRCUIT_BREAKER_RESET_TIMEOUT', 30000, 'number');
    
    // 监控配置
    this.monitoringEnabled = this.getEnv('MONITORING_ENABLED', true, 'boolean');
    this.metricsPort = this.getEnv('METRICS_PORT', 9090, 'number');
    
    // 负载均衡配置
    this.loadBalancingStrategy = this.getEnv('LOAD_BALANCING_STRATEGY', 'round-robin');
    
    // 服务发现配置
    this.serviceDiscoveryEnabled = this.getEnv('SERVICE_DISCOVERY_ENABLED', false, 'boolean');
    this.serviceRegistryUrl = this.getEnv('SERVICE_REGISTRY_URL', 'http://localhost:8761/eureka');
  }

  /**
   * 获取环境变量，如果不存在则返回默认值
   * @param {string} key - 环境变量键名
   * @param {*} defaultValue - 默认值
   * @param {string} type - 值类型
   * @returns {*} 解析后的环境变量值
   */
  getEnv(key, defaultValue, type = 'string') {
    const value = process.env[key];
    
    if (value === undefined) {
      return defaultValue;
    }
    
    switch (type) {
      case 'number':
        return parseInt(value, 10);
      case 'boolean':
        return value.toLowerCase() === 'true';
      case 'array':
        return value.split(',').map(item => item.trim());
      default:
        return value;
    }
  }

  /**
   * 验证配置的完整性
   * @returns {boolean} 配置是否有效
   */
  validate() {
    // 在生产环境中验证必要的配置
    if (this.nodeEnv === 'production' && this.jwtSecret === 'default_jwt_secret') {
      console.error('ERROR: JWT_SECRET must be set in production');
      return false;
    }
    
    return true;
  }

  /**
   * 获取配置的摘要信息
   * @returns {object} 配置摘要
   */
  getSummary() {
    return {
      port: this.port,
      nodeEnv: this.nodeEnv,
      microservices: Object.keys(this.microservices),
      rateLimit: `${this.rateLimitMax} requests per ${this.rateLimitWindowMs}ms`,
      proxyTimeout: `${this.proxyTimeout}ms`
    };
  }
}

// 导出配置单例
module.exports = new AppConfig();