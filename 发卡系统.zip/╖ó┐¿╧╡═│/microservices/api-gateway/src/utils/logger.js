const winston = require('winston');
const path = require('path');
const appConfig = require('../config/app');

/**
 * API网关日志工具类
 */
class ApiLogger {
  constructor() {
    this.logger = winston.createLogger({
      level: appConfig.logLevel,
      format: winston.format.combine(
        winston.format.timestamp({
          format: 'YYYY-MM-DD HH:mm:ss.SSS'
        }),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          const metaString = Object.keys(meta).length > 0 ? ` ${JSON.stringify(meta)}` : '';
          return `[${timestamp}] [${level.toUpperCase()}] ${message}${metaString}`;
        })
      ),
      defaultMeta: { service: 'api-gateway' },
      transports: [
        // 控制台日志
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.timestamp(),
            winston.format.printf(({ timestamp, level, message }) => {
              return `[${timestamp}] [${level}] ${message}`;
            })
          )
        }),
        // 错误日志文件
        new winston.transports.File({
          filename: path.join(__dirname, '..', '..', 'logs', 'error.log'),
          level: 'error',
          maxsize: 5242880, // 5MB
          maxFiles: 5,
          tailable: true
        }),
        // 所有日志文件
        new winston.transports.File({
          filename: path.join(__dirname, '..', '..', 'logs', 'combined.log'),
          maxsize: 5242880, // 5MB
          maxFiles: 5,
          tailable: true
        })
      ]
    });
    
    // 为不同的日志级别创建便捷方法
    this.info = this.logger.info.bind(this.logger);
    this.warn = this.logger.warn.bind(this.logger);
    this.error = this.logger.error.bind(this.logger);
    this.debug = this.logger.debug.bind(this.logger);
    this.verbose = this.logger.verbose.bind(this.logger);
  }

  /**
   * 记录API请求日志
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   */
  logRequest(req, res) {
    const startTime = Date.now();
    const originalSend = res.send;
    
    // 重写send方法以捕获响应数据
    res.send = function(body) {
      const endTime = Date.now();
      const responseTime = endTime - startTime;
      
      const logData = {
        method: req.method,
        url: req.originalUrl,
        status: res.statusCode,
        responseTime: responseTime,
        ip: req.ip,
        userAgent: req.headers['user-agent'],
        requestId: req.headers['x-request-id'] || req.id,
        microservice: req.headers['x-microservice'] || 'unknown'
      };
      
      // 根据状态码决定日志级别
      if (res.statusCode >= 500) {
        this.error('Request failed', { ...logData, body: body.length > 1000 ? 'Truncated body' : body });
      } else if (res.statusCode >= 400) {
        this.warn('Client error', logData);
      } else {
        this.info('Request completed', logData);
      }
      
      return originalSend.call(this, body);
    }.bind(this);
  }

  /**
   * 记录代理请求日志
   * @param {object} proxyReq - 代理请求对象
   * @param {object} req - Express请求对象
   */
  logProxyRequest(proxyReq, req) {
    this.debug('Proxying request', {
      method: req.method,
      originalUrl: req.originalUrl,
      targetUrl: proxyReq.path,
      microservice: req.headers['x-microservice']
    });
  }

  /**
   * 记录错误日志
   * @param {Error} error - 错误对象
   * @param {object} context - 错误上下文
   */
  logError(error, context = {}) {
    this.error(error.message, {
      stack: error.stack,
      errorName: error.name,
      ...context
    });
  }

  /**
   * 记录安全相关日志
   * @param {string} message - 日志消息
   * @param {object} details - 安全事件详情
   */
  logSecurity(message, details = {}) {
    this.info(`SECURITY: ${message}`, details);
  }

  /**
   * 获取Express中间件用于日志记录
   * @returns {function} Express中间件函数
   */
  getExpressMiddleware() {
    return (req, res, next) => {
      this.logRequest(req, res);
      next();
    }.bind(this);
  }

  /**
   * 获取请求ID生成器中间件
   * @returns {function} Express中间件函数
   */
  getRequestIdMiddleware() {
    return (req, res, next) => {
      req.id = req.headers['x-request-id'] || this.generateRequestId();
      res.setHeader('x-request-id', req.id);
      next();
    }.bind(this);
  }

  /**
   * 生成唯一的请求ID
   * @returns {string} 请求ID
   */
  generateRequestId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  /**
   * 记录系统启动日志
   */
  logStartup() {
    this.info('API Gateway starting...');
    this.info('Configuration summary', appConfig.getSummary());
  }

  /**
   * 记录系统关闭日志
   */
  logShutdown() {
    this.info('API Gateway shutting down...');
  }
}

// 导出日志工具单例
module.exports = new ApiLogger();