const ApiGatewayApp = require('./app');
const logger = require('./utils/logger');
const appConfig = require('./config/app');

/**
 * API网关主入口文件
 */
async function main() {
  try {
    // 记录启动日志
    logger.logStartup();
    logger.info('Starting API Gateway...', appConfig.getSummary());
    
    // 创建应用实例
    const gatewayApp = new ApiGatewayApp();
    
    // 启动服务器
    await gatewayApp.startServer();
    
    // 设置优雅关闭
    gatewayApp.setupGracefulShutdown();
    
    // 记录启动成功日志
    logger.info('API Gateway startup completed successfully');
    
  } catch (error) {
    // 记录启动失败日志
    logger.error('API Gateway startup failed', {
      error: error.message,
      stack: error.stack
    });
    
    // 退出进程
    process.exit(1);
  }
}

// 捕获未处理的异常
process.on('uncaughtException', (error) =
  {
    logger.error('Uncaught Exception', {
      error: error.message,
      stack: error.stack
    });
    
    // 延迟退出，确保日志被写入
    setTimeout(() =
      {
        process.exit(1);
      }, 1000);
  });

// 捕获未处理的Promise拒绝
process.on('unhandledRejection', (reason, promise) =
  {
    logger.error('Unhandled Promise Rejection', {
      reason: reason?.message || String(reason),
      stack: reason?.stack
    });
    
    // 可以在这里决定是否退出进程
    // 在某些情况下，未处理的Promise拒绝可能不会导致应用崩溃
  });

// 捕获SIGUSR2信号（用于nodemon重启）
process.on('SIGUSR2', () =
  {
    logger.info('Received SIGUSR2 signal (nodemon restart)');
  });

// 启动应用
if (require.main === module) {
  main();
}

// 导出应用（用于测试）
module.exports = {
  main
};