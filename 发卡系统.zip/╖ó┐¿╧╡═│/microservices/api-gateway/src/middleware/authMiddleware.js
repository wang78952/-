const jwt = require('jsonwebtoken');
const appConfig = require('../config/app');
const logger = require('../utils/logger');

/**
 * API网关认证中间件类
 */
class AuthMiddleware {
  constructor() {
    // 公开路由配置
    this.publicRoutes = [
      { path: '/api/auth/login', method: 'POST' },
      { path: '/api/auth/register', method: 'POST' },
      { path: '/api/auth/forgot-password', method: 'POST' },
      { path: '/api/health', method: 'GET' },
      { path: '/api/analytics/public/**', method: 'GET' },
      { path: '/api/products/public/**', method: 'GET' }
    ];
    
    // API密钥配置（实际应用中应从数据库或密钥管理服务获取）
    this.apiKeys = {
      'test-api-key': {
        permissions: ['read'],
        rateLimit: 1000
      },
      'admin-api-key': {
        permissions: ['read', 'write', 'admin'],
        rateLimit: 5000
      }
    };
  }

  /**
   * JWT认证中间件
   * @returns {function} Express中间件函数
   */
  jwtAuth() {
    return (req, res, next) => {
      // 检查是否为公开路由
      if (this.isPublicRoute(req)) {
        return next();
      }
      
      // 从请求头获取令牌
      const authHeader = req.headers.authorization;
      
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return this.unauthorizedResponse(res, 'No token provided');
      }
      
      const token = authHeader.split(' ')[1];
      
      try {
        // 验证令牌
        const decoded = jwt.verify(token, appConfig.jwtSecret);
        
        // 将用户信息附加到请求对象
        req.user = decoded;
        req.isAuthenticated = true;
        
        logger.info('JWT authentication successful', {
          userId: decoded.userId,
          username: decoded.username,
          path: req.path
        });
        
        next();
      } catch (error) {
        logger.warn('JWT authentication failed', {
          error: error.message,
          path: req.path
        });
        
        if (error.name === 'TokenExpiredError') {
          return this.unauthorizedResponse(res, 'Token expired');
        }
        
        return this.unauthorizedResponse(res, 'Invalid token');
      }
    }.bind(this);
  }

  /**
   * API密钥认证中间件
   * @returns {function} Express中间件函数
   */
  apiKeyAuth() {
    return (req, res, next) => {
      // 检查是否为公开路由或已通过JWT认证
      if (this.isPublicRoute(req) || req.isAuthenticated) {
        return next();
      }
      
      // 从请求头获取API密钥
      const apiKey = req.headers[appConfig.apiKeyHeader.toLowerCase()];
      
      if (!apiKey) {
        return this.unauthorizedResponse(res, 'No API key provided');
      }
      
      // 验证API密钥
      const keyData = this.apiKeys[apiKey];
      
      if (!keyData) {
        logger.warn('Invalid API key attempt', {
          path: req.path,
          ip: req.ip
        });
        return this.unauthorizedResponse(res, 'Invalid API key');
      }
      
      // 检查权限
      if (!this.checkPermission(req, keyData.permissions)) {
        return this.forbiddenResponse(res, 'Insufficient permissions');
      }
      
      logger.info('API key authentication successful', {
        apiKey: '******', // 不记录完整的API密钥
        permissions: keyData.permissions.join(','),
        path: req.path
      });
      
      // 设置API密钥信息
      req.apiKey = true;
      req.permissions = keyData.permissions;
      
      next();
    }.bind(this);
  }

  /**
   * 权限检查中间件
   * @param {Array} requiredPermissions - 必需的权限列表
   * @returns {function} Express中间件函数
   */
  checkPermissions(requiredPermissions) {
    return (req, res, next) => {
      // 检查是否为公开路由
      if (this.isPublicRoute(req)) {
        return next();
      }
      
      // 检查是否已认证
      if (!req.isAuthenticated && !req.apiKey) {
        return this.unauthorizedResponse(res, 'Authentication required');
      }
      
      // 获取用户权限
      const userPermissions = req.permissions || req.user?.permissions || [];
      
      // 检查是否有所需的权限
      const hasPermission = requiredPermissions.some(permission => 
        userPermissions.includes(permission) || userPermissions.includes('admin')
      );
      
      if (!hasPermission) {
        logger.warn('Permission denied', {
          userId: req.user?.userId || 'api_key',
          path: req.path,
          requiredPermissions: requiredPermissions.join(','),
          userPermissions: userPermissions.join(',')
        });
        
        return this.forbiddenResponse(res, 'Insufficient permissions');
      }
      
      next();
    };
  }

  /**
   * 检查是否为公开路由
   * @param {object} req - Express请求对象
   * @returns {boolean} 是否为公开路由
   */
  isPublicRoute(req) {
    return this.publicRoutes.some(route => {
      // 支持路径模式匹配
      if (route.path.includes('*')) {
        const pattern = new RegExp(`^${route.path.replace(/\*/g, '.*')}$`);
        return pattern.test(req.path) && route.method === req.method;
      }
      return route.path === req.path && route.method === req.method;
    });
  }

  /**
   * 检查权限
   * @param {object} req - Express请求对象
   * @param {Array} userPermissions - 用户权限列表
   * @returns {boolean} 是否有权限
   */
  checkPermission(req, userPermissions) {
    // 根据请求方法确定所需的权限
    const requiredPermission = req.method === 'GET' ? 'read' : 'write';
    
    return userPermissions.includes(requiredPermission) || userPermissions.includes('admin');
  }

  /**
   * 生成未授权响应
   * @param {object} res - Express响应对象
   * @param {string} message - 错误消息
   * @returns {object} Express响应
   */
  unauthorizedResponse(res, message) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: message,
      code: 'AUTH_REQUIRED',
      timestamp: new Date().toISOString()
    });
  }

  /**
   * 生成禁止访问响应
   * @param {object} res - Express响应对象
   * @param {string} message - 错误消息
   * @returns {object} Express响应
   */
  forbiddenResponse(res, message) {
    return res.status(403).json({
      error: 'Forbidden',
      message: message,
      code: 'ACCESS_DENIED',
      timestamp: new Date().toISOString()
    });
  }

  /**
   * 获取所有认证中间件的组合
   * @returns {Array} 中间件数组
   */
  getAllAuthMiddlewares() {
    return [
      this.jwtAuth(),
      this.apiKeyAuth()
    ];
  }

  /**
   * 刷新令牌中间件
   * @returns {function} Express中间件函数
   */
  refreshToken() {
    return (req, res, next) => {
      // 检查是否有刷新令牌请求
      if (req.path !== '/api/auth/refresh' && req.method !== 'POST') {
        return next();
      }
      
      const refreshToken = req.body.refreshToken;
      
      if (!refreshToken) {
        return this.unauthorizedResponse(res, 'No refresh token provided');
      }
      
      // 这里应该验证刷新令牌
      // 简化示例，实际应用中应该从数据库或Redis验证
      try {
        // 验证刷新令牌
        const decoded = jwt.verify(refreshToken, appConfig.jwtSecret);
        
        // 生成新的访问令牌
        const newAccessToken = jwt.sign(
          { userId: decoded.userId, username: decoded.username },
          appConfig.jwtSecret,
          { expiresIn: '1h' }
        );
        
        // 将新令牌附加到请求对象
        req.newAccessToken = newAccessToken;
        
        logger.info('Token refreshed', {
          userId: decoded.userId
        });
        
        next();
      } catch (error) {
        logger.warn('Token refresh failed', {
          error: error.message
        });
        
        return this.unauthorizedResponse(res, 'Invalid refresh token');
      }
    };
  }
}

// 导出认证中间件单例
module.exports = new AuthMiddleware();