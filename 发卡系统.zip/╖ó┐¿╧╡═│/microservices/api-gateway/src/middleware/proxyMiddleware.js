const { createProxyMiddleware } = require('http-proxy-middleware');
const appConfig = require('../config/app');
const logger = require('../utils/logger');

/**
 * API网关代理中间件管理类
 */
class ProxyMiddleware {
  constructor() {
    this.proxies = {};
    this.circuitBreakers = {};
    this.initProxies();
    
    // 如果启用了熔断器，初始化熔断器
    if (appConfig.circuitBreakerEnabled) {
      this.initCircuitBreakers();
    }
  }

  /**
   * 初始化所有微服务代理
   */
  initProxies() {
    // 定义各个微服务的代理配置
    const proxyConfigs = {
      auth: {
        path: '/api/auth/**',
        target: appConfig.microservices.auth,
        rewritePath: (path) => path.replace(/^\/api\/auth/, '')
      },
      user: {
        path: '/api/users/**',
        target: appConfig.microservices.user,
        rewritePath: (path) => path.replace(/^\/api\/users/, '')
      },
      product: {
        path: '/api/products/**',
        target: appConfig.microservices.product,
        rewritePath: (path) => path.replace(/^\/api\/products/, '')
      },
      order: {
        path: '/api/orders/**',
        target: appConfig.microservices.order,
        rewritePath: (path) => path.replace(/^\/api\/orders/, '')
      },
      payment: {
        path: '/api/payments/**',
        target: appConfig.microservices.payment,
        rewritePath: (path) => path.replace(/^\/api\/payments/, '')
      },
      analytics: {
        path: '/api/analytics/**',
        target: appConfig.microservices.analytics,
        rewritePath: (path) => path.replace(/^\/api\/analytics/, '')
      },
      notification: {
        path: '/api/notifications/**',
        target: appConfig.microservices.notification,
        rewritePath: (path) => path.replace(/^\/api\/notifications/, '')
      },
      logging: {
        path: '/api/logs/**',
        target: appConfig.microservices.logging,
        rewritePath: (path) => path.replace(/^\/api\/logs/, '')
      }
    };

    // 创建代理实例
    Object.keys(proxyConfigs).forEach((serviceName) => {
      const config = proxyConfigs[serviceName];
      
      this.proxies[serviceName] = createProxyMiddleware(config.path, {
        target: config.target,
        changeOrigin: true,
        pathRewrite: config.rewritePath,
        timeout: appConfig.proxyTimeout,
        onProxyReq: this.onProxyReq.bind(this, serviceName),
        onProxyRes: this.onProxyRes.bind(this, serviceName),
        onError: this.onProxyError.bind(this, serviceName)
      });
    });
  }

  /**
   * 初始化熔断器
   */
  initCircuitBreakers() {
    Object.keys(appConfig.microservices).forEach((serviceName) => {
      this.circuitBreakers[serviceName] = {
        state: 'CLOSED', // CLOSED, OPEN, HALF_OPEN
        failureCount: 0,
        resetTimeout: null,
        lastFailureTime: null
      };
    });
  }

  /**
   * 代理请求处理函数
   * @param {string} serviceName - 微服务名称
   * @param {object} proxyReq - 代理请求对象
   * @param {object} req - Express请求对象
   */
  onProxyReq(serviceName, proxyReq, req) {
    // 设置微服务标识头
    proxyReq.setHeader('x-microservice', serviceName);
    
    // 传递请求ID
    if (req.headers['x-request-id']) {
      proxyReq.setHeader('x-request-id', req.headers['x-request-id']);
    }
    
    // 记录代理请求
    logger.logProxyRequest(proxyReq, req);
    
    // 检查熔断器状态
    if (appConfig.circuitBreakerEnabled) {
      const circuitBreaker = this.circuitBreakers[serviceName];
      if (circuitBreaker.state === 'OPEN') {
        // 如果熔断器打开，取消请求
        proxyReq.abort();
        throw new Error(`Circuit breaker for ${serviceName} is open`);
      }
    }
  }

  /**
   * 代理响应处理函数
   * @param {string} serviceName - 微服务名称
   * @param {object} proxyRes - 代理响应对象
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   */
  onProxyRes(serviceName, proxyRes, req, res) {
    // 添加响应头，标识响应来自哪个微服务
    res.setHeader('x-proxied-by', serviceName);
    
    // 如果启用了熔断器，处理成功响应
    if (appConfig.circuitBreakerEnabled && proxyRes.statusCode < 500) {
      const circuitBreaker = this.circuitBreakers[serviceName];
      // 重置失败计数
      circuitBreaker.failureCount = 0;
      // 如果是半开状态，切换到关闭状态
      if (circuitBreaker.state === 'HALF_OPEN') {
        circuitBreaker.state = 'CLOSED';
        logger.info(`Circuit breaker for ${serviceName} closed`);
      }
    }
  }

  /**
   * 代理错误处理函数
   * @param {string} serviceName - 微服务名称
   * @param {Error} err - 错误对象
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   */
  onProxyError(serviceName, err, req, res) {
    logger.error(`Proxy error for ${serviceName}`, {
      error: err.message,
      path: req.path,
      method: req.method
    });
    
    // 如果启用了熔断器，处理失败
    if (appConfig.circuitBreakerEnabled) {
      this.handleCircuitBreakerFailure(serviceName);
    }
    
    // 返回适当的错误响应
    res.status(503).json({
      error: 'Service Unavailable',
      message: `The ${serviceName} service is currently unavailable`,
      code: 'SERVICE_UNAVAILABLE',
      timestamp: new Date().toISOString()
    });
  }

  /**
   * 处理熔断器失败
   * @param {string} serviceName - 微服务名称
   */
  handleCircuitBreakerFailure(serviceName) {
    const circuitBreaker = this.circuitBreakers[serviceName];
    circuitBreaker.failureCount++;
    circuitBreaker.lastFailureTime = Date.now();
    
    // 如果失败次数达到阈值，打开熔断器
    if (circuitBreaker.failureCount >= appConfig.circuitBreakerFailureThreshold && circuitBreaker.state === 'CLOSED') {
      circuitBreaker.state = 'OPEN';
      logger.warn(`Circuit breaker for ${serviceName} opened`, { failureCount: circuitBreaker.failureCount });
      
      // 设置重置超时
      circuitBreaker.resetTimeout = setTimeout(() => {
        circuitBreaker.state = 'HALF_OPEN';
        logger.info(`Circuit breaker for ${serviceName} half-open`);
      }, appConfig.circuitBreakerResetTimeout);
    }
  }

  /**
   * 获取指定微服务的代理中间件
   * @param {string} serviceName - 微服务名称
   * @returns {function} 代理中间件函数
   */
  getProxyMiddleware(serviceName) {
    if (!this.proxies[serviceName]) {
      throw new Error(`Proxy middleware for ${serviceName} not found`);
    }
    
    return this.proxies[serviceName];
  }

  /**
   * 获取所有代理中间件的映射
   * @returns {object} 代理中间件映射
   */
  getAllProxies() {
    return this.proxies;
  }

  /**
   * 获取熔断器状态
   * @returns {object} 熔断器状态
   */
  getCircuitBreakerStatus() {
    return Object.keys(this.circuitBreakers).reduce((status, serviceName) => {
      const breaker = this.circuitBreakers[serviceName];
      status[serviceName] = {
        state: breaker.state,
        failureCount: breaker.failureCount,
        lastFailureTime: breaker.lastFailureTime
      };
      return status;
    }, {});
  }
}

// 导出代理中间件单例
module.exports = new ProxyMiddleware();