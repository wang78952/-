const rateLimit = require('express-rate-limit');
const NodeCache = require('node-cache');
const appConfig = require('../config/app');
const logger = require('../utils/logger');

/**
 * API网关限流中间件类
 */
class RateLimitMiddleware {
  constructor() {
    // 创建缓存实例用于分布式限流（在单实例情况下）
    this.cache = new NodeCache({ stdTTL: 60 });
    
    // 创建不同级别的限流配置
    this.limiters = {
      // 全局限流
      global: this.createGlobalLimiter(),
      // 认证接口限流（更严格）
      auth: this.createAuthLimiter(),
      // 管理员接口限流（较宽松）
      admin: this.createAdminLimiter(),
      // API密钥限流（基于API密钥）
      apiKey: this.createApiKeyLimiter()
    };
  }

  /**
   * 创建全局限流中间件
   * @returns {function} 限流中间件函数
   */
  createGlobalLimiter() {
    return rateLimit({
      windowMs: appConfig.rateLimitWindowMs,
      max: appConfig.rateLimitMax,
      standardHeaders: true,
      legacyHeaders: false,
      keyGenerator: this.ipKeyGenerator,
      handler: this.rateLimitHandler.bind(this, 'global'),
      skipSuccessfulRequests: false
    });
  }

  /**
   * 创建认证接口限流中间件
   * @returns {function} 限流中间件函数
   */
  createAuthLimiter() {
    return rateLimit({
      windowMs: appConfig.rateLimitWindowMs,
      max: Math.floor(appConfig.rateLimitMax * 0.5), // 认证接口限制更严格
      standardHeaders: true,
      legacyHeaders: false,
      keyGenerator: this.ipKeyGenerator,
      handler: this.rateLimitHandler.bind(this, 'auth'),
      skipSuccessfulRequests: false
    });
  }

  /**
   * 创建管理员接口限流中间件
   * @returns {function} 限流中间件函数
   */
  createAdminLimiter() {
    return rateLimit({
      windowMs: appConfig.rateLimitWindowMs,
      max: appConfig.rateLimitMax * 2, // 管理员接口允许更多请求
      standardHeaders: true,
      legacyHeaders: false,
      keyGenerator: this.userKeyGenerator,
      handler: this.rateLimitHandler.bind(this, 'admin'),
      skipSuccessfulRequests: false
    });
  }

  /**
   * 创建基于API密钥的限流中间件
   * @returns {function} 限流中间件函数
   */
  createApiKeyLimiter() {
    return (req, res, next) => {
      // 仅对使用API密钥的请求应用
      const apiKey = req.headers[appConfig.apiKeyHeader.toLowerCase()];
      
      if (!apiKey) {
        return next();
      }
      
      // 从缓存获取API密钥的配置（实际应用中应从数据库获取）
      const apiKeyConfig = this.getApiKeyConfig(apiKey);
      
      if (!apiKeyConfig) {
        return next(); // 如果找不到API密钥配置，跳过限流
      }
      
      const key = `apiKey:${apiKey}:${Math.floor(Date.now() / appConfig.rateLimitWindowMs)}`;
      
      // 获取当前计数
      const currentCount = this.cache.get(key) || 0;
      
      if (currentCount >= apiKeyConfig.rateLimit) {
        // 超出限制
        this.rateLimitHandler('apiKey', req, res);
        return;
      }
      
      // 增加计数
      this.cache.set(key, currentCount + 1);
      
      // 设置响应头
      res.setHeader('X-RateLimit-Limit', apiKeyConfig.rateLimit);
      res.setHeader('X-RateLimit-Remaining', apiKeyConfig.rateLimit - currentCount - 1);
      
      next();
    };
  }

  /**
   * IP地址作为限流键生成器
   * @param {object} req - Express请求对象
   * @returns {string} 限流键
   */
  ipKeyGenerator(req) {
    // 获取真实IP（考虑代理）
    return req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  }

  /**
   * 用户ID作为限流键生成器
   * @param {object} req - Express请求对象
   * @returns {string} 限流键
   */
  userKeyGenerator(req) {
    if (req.user) {
      return `user:${req.user.userId}`;
    }
    // 如果用户未认证，回退到IP限流
    return this.ipKeyGenerator(req);
  }

  /**
   * 限流处理器
   * @param {string} limitType - 限流类型
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   */
  rateLimitHandler(limitType, req, res) {
    const ip = this.ipKeyGenerator(req);
    const path = req.path;
    const userId = req.user?.userId || 'unauthenticated';
    
    // 记录限流事件
    logger.warn('Rate limit exceeded', {
      limitType,
      ip,
      path,
      userId,
      method: req.method
    });
    
    // 返回429响应
    res.status(429).json({
      error: 'Too Many Requests',
      message: 'Rate limit exceeded. Please try again later.',
      code: 'RATE_LIMIT_EXCEEDED',
      timestamp: new Date().toISOString(),
      retryAfter: Math.ceil(appConfig.rateLimitWindowMs / 1000)
    });
  }

  /**
   * 获取API密钥配置
   * @param {string} apiKey - API密钥
   * @returns {object|null} API密钥配置
   */
  getApiKeyConfig(apiKey) {
    // 简化示例，实际应用中应该从数据库获取
    const apiKeys = {
      'test-api-key': { rateLimit: 1000 },
      'admin-api-key': { rateLimit: 5000 }
    };
    
    return apiKeys[apiKey] || null;
  }

  /**
   * 获取指定限流类型的中间件
   * @param {string} type - 限流类型
   * @returns {function} 限流中间件函数
   */
  getLimiter(type) {
    if (!this.limiters[type]) {
      throw new Error(`Rate limiter for ${type} not found`);
    }
    
    return this.limiters[type];
  }

  /**
   * 创建基于路径的动态限流中间件
   * @param {object} pathLimits - 路径限流配置
   * @returns {function} 限流中间件函数
   */
  createPathBasedLimiter(pathLimits) {
    return (req, res, next) => {
      // 查找匹配的路径配置
      const matchingLimit = Object.keys(pathLimits).find(pattern => {
        const regexPattern = new RegExp(`^${pattern.replace(/\*/g, '.*')}$`);
        return regexPattern.test(req.path);
      });
      
      if (matchingLimit) {
        const limit = pathLimits[matchingLimit];
        
        const key = `path:${matchingLimit}:${this.ipKeyGenerator(req)}:${Math.floor(Date.now() / limit.windowMs)}`;
        
        // 获取当前计数
        const currentCount = this.cache.get(key) || 0;
        
        if (currentCount >= limit.max) {
          // 超出限制
          this.rateLimitHandler('path', req, res);
          return;
        }
        
        // 增加计数
        this.cache.set(key, currentCount + 1, limit.windowMs / 1000);
        
        // 设置响应头
        res.setHeader('X-RateLimit-Limit', limit.max);
        res.setHeader('X-RateLimit-Remaining', limit.max - currentCount - 1);
      }
      
      next();
    };
  }

  /**
   * 清除特定IP的限流计数
   * @param {string} ip - IP地址
   */
  clearIpLimit(ip) {
    // 清除该IP的所有限流计数
    const allKeys = this.cache.keys();
    allKeys.forEach(key => {
      if (key.includes(ip)) {
        this.cache.del(key);
      }
    });
    
    logger.info('Cleared rate limits for IP', { ip });
  }

  /**
   * 获取限流统计信息
   * @returns {object} 限流统计
   */
  getStats() {
    const totalKeys = this.cache.keys().length;
    
    return {
      totalLimits: totalKeys,
      cacheSize: this.cache.getStats(),
      globalLimit: {
        windowMs: appConfig.rateLimitWindowMs,
        maxRequests: appConfig.rateLimitMax
      }
    };
  }
}

// 导出限流中间件单例
module.exports = new RateLimitMiddleware();