const express = require('express');
const router = express.Router();
const proxyMiddleware = require('../middleware/proxyMiddleware');
const authMiddleware = require('../middleware/authMiddleware');
const rateLimitMiddleware = require('../middleware/rateLimitMiddleware');
const healthController = require('../controllers/healthController');

/**
 * API网关主路由配置
 */
class ApiRoutes {
  constructor() {
    this.setupRoutes();
  }

  /**
   * 设置所有路由
   */
  setupRoutes() {
    // 健康检查路由
    this.setupHealthRoutes();
    
    // 认证路由
    this.setupAuthRoutes();
    
    // 用户服务路由
    this.setupUserRoutes();
    
    // 产品服务路由
    this.setupProductRoutes();
    
    // 订单服务路由
    this.setupOrderRoutes();
    
    // 支付服务路由
    this.setupPaymentRoutes();
    
    // 分析服务路由
    this.setupAnalyticsRoutes();
    
    // 通知服务路由
    this.setupNotificationRoutes();
    
    // 日志服务路由
    this.setupLoggingRoutes();
    
    // 管理员路由（需要额外权限）
    this.setupAdminRoutes();
  }

  /**
   * 设置健康检查路由
   */
  setupHealthRoutes() {
    // 健康检查路由不需要认证
    router.get('/health', healthController.checkHealth);
    router.get('/health/detailed', healthController.getDetailedHealth);
  }

  /**
   * 设置认证路由
   */
  setupAuthRoutes() {
    // 认证路由应用更严格的限流
    router.use('/api/auth', 
      rateLimitMiddleware.getLimiter('auth'),
      authMiddleware.refreshToken(),
      proxyMiddleware.getProxyMiddleware('auth')
    );
  }

  /**
   * 设置用户服务路由
   */
  setupUserRoutes() {
    router.use('/api/users', 
      authMiddleware.getAllAuthMiddlewares(),
      proxyMiddleware.getProxyMiddleware('user')
    );
  }

  /**
   * 设置产品服务路由
   */
  setupProductRoutes() {
    // 公开产品路由不需要认证
    router.use('/api/products/public', 
      rateLimitMiddleware.getLimiter('global'),
      proxyMiddleware.getProxyMiddleware('product')
    );
    
    // 受保护的产品路由需要认证
    router.use('/api/products', 
      authMiddleware.getAllAuthMiddlewares(),
      proxyMiddleware.getProxyMiddleware('product')
    );
  }

  /**
   * 设置订单服务路由
   */
  setupOrderRoutes() {
    router.use('/api/orders', 
      authMiddleware.getAllAuthMiddlewares(),
      proxyMiddleware.getProxyMiddleware('order')
    );
  }

  /**
   * 设置支付服务路由
   */
  setupPaymentRoutes() {
    router.use('/api/payments', 
      authMiddleware.getAllAuthMiddlewares(),
      proxyMiddleware.getProxyMiddleware('payment')
    );
  }

  /**
   * 设置分析服务路由
   */
  setupAnalyticsRoutes() {
    // 公开分析路由不需要认证
    router.use('/api/analytics/public', 
      rateLimitMiddleware.getLimiter('global'),
      proxyMiddleware.getProxyMiddleware('analytics')
    );
    
    // 受保护的分析路由需要认证
    router.use('/api/analytics', 
      authMiddleware.getAllAuthMiddlewares(),
      proxyMiddleware.getProxyMiddleware('analytics')
    );
  }

  /**
   * 设置通知服务路由
   */
  setupNotificationRoutes() {
    router.use('/api/notifications', 
      authMiddleware.getAllAuthMiddlewares(),
      proxyMiddleware.getProxyMiddleware('notification')
    );
  }

  /**
   * 设置日志服务路由
   */
  setupLoggingRoutes() {
    // 日志服务需要管理员权限
    router.use('/api/logs', 
      authMiddleware.getAllAuthMiddlewares(),
      authMiddleware.checkPermissions(['admin']),
      proxyMiddleware.getProxyMiddleware('logging')
    );
  }

  /**
   * 设置管理员路由
   */
  setupAdminRoutes() {
    // 管理员路由应用特殊限流规则
    router.use('/api/admin', 
      authMiddleware.getAllAuthMiddlewares(),
      authMiddleware.checkPermissions(['admin']),
      rateLimitMiddleware.getLimiter('admin'),
      // 这里可以添加更多管理员特定的中间件
      (req, res, next) => {
        // 所有管理员请求都需要代理到相应的微服务
        // 这里简化处理，实际应用中可能需要更复杂的路由映射
        const targetService = req.headers['x-target-service'] || 'user';
        
        if (proxyMiddleware.getAllProxies()[targetService]) {
          return proxyMiddleware.getProxyMiddleware(targetService)(req, res, next);
        }
        
        res.status(400).json({
          error: 'Bad Request',
          message: 'Invalid target service'
        });
      }
    );
  }

  /**
   * 获取路由实例
   * @returns {object} Express路由实例
   */
  getRouter() {
    return router;
  }
}

// 创建路由实例
const apiRoutes = new ApiRoutes();

// 导出路由
module.exports = apiRoutes.getRouter();