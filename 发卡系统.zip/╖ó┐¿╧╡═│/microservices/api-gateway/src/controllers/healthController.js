const axios = require('axios');
const appConfig = require('../config/app');
const proxyMiddleware = require('../middleware/proxyMiddleware');
const logger = require('../utils/logger');

/**
 * API网关健康检查控制器
 */
class HealthController {
  constructor() {
    // 服务健康状态缓存
    this.healthCache = {};
    this.lastHealthCheck = null;
    this.healthCheckInterval = appConfig.healthCheckInterval || 30000;
  }

  /**
   * 基本健康检查
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   */
  async checkHealth(req, res) {
    try {
      // 返回基本健康状态
      res.status(200).json({
        status: 'UP',
        timestamp: new Date().toISOString(),
        service: 'api-gateway',
        version: '1.0.0'
      });
    } catch (error) {
      logger.error('Health check failed', { error: error.message });
      res.status(500).json({
        status: 'DOWN',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * 获取详细健康状态
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   */
  async getDetailedHealth(req, res) {
    try {
      // 检查是否需要更新健康状态
      const shouldUpdate = !this.lastHealthCheck || 
        Date.now() - this.lastHealthCheck >= this.healthCheckInterval;
      
      if (shouldUpdate) {
        await this.updateAllServicesHealth();
      }
      
      // 计算整体健康状态
      const allServicesUp = Object.values(this.healthCache).every(service => service.status === 'UP');
      
      res.status(allServicesUp ? 200 : 503).json({
        status: allServicesUp ? 'UP' : 'DEGRADED',
        timestamp: new Date().toISOString(),
        gateway: {
          status: 'UP',
          uptime: process.uptime() + ' seconds',
          memoryUsage: process.memoryUsage(),
          nodeVersion: process.version
        },
        services: this.healthCache,
        circuitBreakers: proxyMiddleware.getCircuitBreakerStatus()
      });
    } catch (error) {
      logger.error('Detailed health check failed', { error: error.message });
      res.status(500).json({
        status: 'DOWN',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * 更新所有服务的健康状态
   */
  async updateAllServicesHealth() {
    const healthPromises = [];
    
    // 为每个微服务创建健康检查请求
    Object.entries(appConfig.microservices).forEach(([serviceName, serviceUrl]) =
      {
        const healthUrl = `${serviceUrl}/health`;
        
        const healthPromise = axios.get(healthUrl, {
          timeout: 5000,
          headers: {
            'x-request-id': `health-${Date.now()}-${serviceName}`,
            'x-microservice': 'api-gateway'
          }
        })
        .then(response =
          {
            return {
              service: serviceName,
              status: 'UP',
              details: response.data,
              responseTime: response.headers['x-response-time'] || 'N/A'
            };
          })
        .catch(error =
          {
            logger.warn(`Health check failed for ${serviceName}`, {
              error: error.message,
              url: healthUrl
            });
            
            return {
              service: serviceName,
              status: 'DOWN',
              error: error.message,
              url: healthUrl
            };
          });
        
        healthPromises.push(healthPromise);
      });
    
    // 等待所有健康检查完成
    const results = await Promise.allSettled(healthPromises);
    
    // 更新健康缓存
    results.forEach(result =
      {
        if (result.status === 'fulfilled') {
          this.healthCache[result.value.service] = result.value;
        }
      });
    
    this.lastHealthCheck = Date.now();
  }

  /**
   * 获取特定服务的健康状态
   * @param {string} serviceName - 服务名称
   * @returns {object} 服务健康状态
   */
  async getServiceHealth(serviceName) {
    if (!appConfig.microservices[serviceName]) {
      return {
        service: serviceName,
        status: 'UNKNOWN',
        error: 'Service not configured'
      };
    }
    
    try {
      const healthUrl = `${appConfig.microservices[serviceName]}/health`;
      const response = await axios.get(healthUrl, {
        timeout: 5000
      });
      
      return {
        service: serviceName,
        status: 'UP',
        details: response.data
      };
    } catch (error) {
      return {
        service: serviceName,
        status: 'DOWN',
        error: error.message
      };
    }
  }

  /**
   * 获取系统资源使用情况
   * @returns {object} 资源使用情况
   */
  getResourceUsage() {
    return {
      memory: process.memoryUsage(),
      uptime: process.uptime(),
      cpuUsage: process.cpuUsage(),
      loadavg: process.loadavg ? process.loadavg() : 'Not available',
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch
    };
  }
}

// 导出控制器实例
const healthController = new HealthController();

module.exports = {
  checkHealth: healthController.checkHealth.bind(healthController),
  getDetailedHealth: healthController.getDetailedHealth.bind(healthController)
};