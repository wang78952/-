const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');

// 加载环境变量
dotenv.config();

// 导入配置和工具
const { pool, testConnection } = require('./config/database');
const logger = require('./utils/logger');
const { errorHandler, requestLogger } = require('./middleware/authMiddleware');

// 导入路由
const authRoutes = require('./routes/authRoutes');

// 创建Express应用
const app = express();

// 配置端口
const PORT = process.env.PORT || 3001;

// 配置中间件

// CORS配置
const corsOptions = {
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ['*'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true
};
app.use(cors(corsOptions));

// 请求日志中间件
app.use(requestLogger);

// 解析请求体
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 安全头设置
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});

// 根路径健康检查
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Auth Service API',
    version: process.env.API_VERSION || 'v1',
    timestamp: new Date().toISOString()
  });
});

// 注册路由
app.use('/', authRoutes);

// 404处理
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'API端点不存在'
  });
});

// 错误处理中间件
app.use(errorHandler);

// 启动服务器
async function startServer() {
  try {
    // 测试数据库连接
    await testConnection();
    
    // 启动HTTP服务器
    const server = app.listen(PORT, () => {
      logger.info(`Auth Service启动成功，监听端口: ${PORT}`);
      logger.info(`环境: ${process.env.NODE_ENV}`);
      logger.info(`API版本: ${process.env.API_VERSION || 'v1'}`);
    });

    // 处理服务器关闭信号
    process.on('SIGTERM', () => {
      logger.info('收到关闭信号，正在关闭服务器...');
      server.close(() => {
        logger.info('服务器已关闭');
        process.exit(0);
      });
    });

  } catch (error) {
    logger.error(`服务器启动失败: ${error.message}`);
    process.exit(1);
  }
}

// 启动服务器
startServer();