const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const passport = require('passport');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const compression = require('compression');

// 导入配置和工具
const AppConfig = require('./config/app');
const logger = require('./utils/logger');
const Database = require('./utils/database');

// 导入中间件
const authMiddleware = require('./middleware/auth');

// 导入路由
const apiRoutes = require('./routes/api');

class AuthServer {
  constructor() {
    this.app = express();
    this.config = AppConfig.getInstance();
    this.logger = logger.getInstance();
    this.database = Database.getInstance();
    this.server = null;
    this.setupServer();
  }

  /**
   * 设置服务器配置
   */
  setupServer() {
    // 初始化Passport
    this.app.use(passport.initialize());
    
    // 配置安全中间件
    this.app.use(helmet());
    
    // 配置CORS
    const corsOptions = {
      origin: this.config.get('CORS_ALLOWED_ORIGINS') || '*',
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
      credentials: true,
      maxAge: 86400
    };
    this.app.use(cors(corsOptions));
    
    // 配置请求体解析
    this.app.use(bodyParser.json({ limit: '10mb' }));
    this.app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
    
    // 配置Cookie解析
    this.app.use(cookieParser(this.config.get('COOKIE_SECRET')));
    
    // 配置压缩
    this.app.use(compression());
    
    // 配置请求日志
    if (this.config.get('NODE_ENV') !== 'production') {
      this.app.use(morgan('dev'));
    } else {
      this.app.use(morgan('combined'));
    }
    
    // 配置速率限制
    const limiter = rateLimit({
      windowMs: this.config.get('RATE_LIMIT_WINDOW_MS') || 15 * 60 * 1000, // 15分钟
      max: this.config.get('RATE_LIMIT_MAX') || 100, // 每个IP限制的请求数
      standardHeaders: true,
      legacyHeaders: false,
      message: {
        success: false,
        message: 'Too many requests, please try again later',
        code: 'RATE_LIMIT_EXCEEDED'
      },
      keyGenerator: (req) => req.ip,
      handler: (req, res) => {
        this.logger.warn('Rate limit exceeded', {
          ip: req.ip,
          url: req.originalUrl,
          method: req.method
        });
        res.status(429).json({
          success: false,
          message: 'Too many requests, please try again later',
          code: 'RATE_LIMIT_EXCEEDED'
        });
      }
    });
    
    // 应用速率限制
    this.app.use(limiter);
    
    // 配置路由
    this.setupRoutes();
    
    // 配置错误处理
    this.setupErrorHandlers();
  }

  /**
   * 设置路由
   */
  setupRoutes() {
    // 根路由
    this.app.get('/', (req, res) => {
      res.status(200).json({
        success: true,
        message: '统一认证服务',
        version: this.config.get('APP_VERSION') || '1.0.0',
        timestamp: new Date().toISOString()
      });
    });
    
    // API路由
    this.app.use('/api/v1', apiRoutes);
    
    // 404处理
    this.app.use((req, res) => {
      res.status(404).json({
        success: false,
        message: 'API endpoint not found',
        code: 'NOT_FOUND'
      });
    });
  }

  /**
   * 设置错误处理
   */
  setupErrorHandlers() {
    // 使用自定义错误处理中间件
    this.app.use(authMiddleware.errorHandler());
    
    // 全局错误处理
    this.app.use((err, req, res, next) => {
      if (res.headersSent) {
        return next(err);
      }
      
      this.logger.error('Unhandled error', {
        error: err.message,
        stack: err.stack,
        url: req.originalUrl,
        method: req.method
      });
      
      res.status(500).json({
        success: false,
        message: 'Internal server error',
        code: 'SERVER_ERROR'
      });
    });
  }

  /**
   * 启动服务器
   */
  async start() {
    try {
      // 连接数据库
      await this.database.connect();
      
      // 获取服务器配置
      const port = this.config.get('PORT') || 3000;
      const host = this.config.get('HOST') || '0.0.0.0';
      
      // 启动服务器
      this.server = this.app.listen(port, host, () => {
        this.logger.info('Server started', {
          host,
          port,
          environment: this.config.get('NODE_ENV') || 'development'
        });
      });
      
      // 处理服务器关闭
      this.setupShutdownHandlers();
      
      return this.server;
    } catch (error) {
      this.logger.error('Failed to start server', { error: error.message });
      throw error;
    }
  }

  /**
   * 停止服务器
   */
  async stop() {
    try {
      this.logger.info('Stopping server...');
      
      // 关闭数据库连接
      await this.database.disconnect();
      
      // 关闭服务器
      if (this.server) {
        await new Promise((resolve, reject) => {
          this.server.close((err) => {
            if (err) {
              reject(err);
            } else {
              resolve();
            }
          });
        });
      }
      
      this.logger.info('Server stopped gracefully');
    } catch (error) {
      this.logger.error('Error stopping server', { error: error.message });
      throw error;
    }
  }

  /**
   * 设置关闭处理器
   */
  setupShutdownHandlers() {
    // 处理SIGINT信号 (Ctrl+C)
    process.on('SIGINT', async () => {
      this.logger.info('Received SIGINT signal');
      await this.stop();
      process.exit(0);
    });
    
    // 处理SIGTERM信号
    process.on('SIGTERM', async () => {
      this.logger.info('Received SIGTERM signal');
      await this.stop();
      process.exit(0);
    });
    
    // 处理未捕获的异常
    process.on('uncaughtException', (error) => {
      this.logger.error('Uncaught exception', {
        error: error.message,
        stack: error.stack
      });
    });
    
    // 处理未处理的Promise拒绝
    process.on('unhandledRejection', (reason, promise) => {
      this.logger.error('Unhandled promise rejection', {
        reason: reason?.message || String(reason),
        promise
      });
    });
  }

  /**
   * 获取服务器实例
   */
  getServer() {
    return this.server;
  }

  /**
   * 获取Express应用实例
   */
  getApp() {
    return this.app;
  }

  /**
   * 检查服务器健康状态
   */
  async healthCheck() {
    try {
      const dbStatus = await this.database.checkConnection();
      
      return {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        components: {
          database: dbStatus ? 'connected' : 'disconnected',
          server: this.server ? 'running' : 'stopped'
        },
        uptime: process.uptime(),
        memory: process.memoryUsage()
      };
    } catch (error) {
      this.logger.error('Health check failed', { error: error.message });
      return {
        status: 'unhealthy',
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }
}

// 导出服务器实例
module.exports = new AuthServer();

// 如果直接运行此文件，则启动服务器
if (require.main === module) {
  const server = module.exports;
  server.start().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}