const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const Schema = mongoose.Schema;
const AppConfig = require('../config/app');
const logger = require('../utils/logger');

/**
 * 令牌模型
 */
class TokenModel {
  constructor() {
    // 创建令牌架构
    this.tokenSchema = this.createTokenSchema();
    
    // 创建模型
    this.Token = mongoose.model('Token', this.tokenSchema);
  }

  /**
   * 创建令牌架构
   */
  createTokenSchema() {
    const TokenSchema = new Schema({
      // 令牌类型
      tokenType: {
        type: String,
        enum: ['access', 'refresh', 'resetPassword', 'verification', 'apiKey'],
        required: true
      },
      
      // 用户ID
      userId: {
        type: Schema.Types.ObjectId,
        ref: 'User',
        required: function() { return this.tokenType !== 'apiKey'; }
      },
      
      // 令牌值
      token: {
        type: String,
        required: true,
        unique: true,
        trim: true
      },
      
      // 令牌哈希
      tokenHash: {
        type: String,
        required: true,
        index: true
      },
      
      // 过期时间
      expiresAt: {
        type: Date,
        required: true,
        index: true
      },
      
      // 刷新令牌ID (用于access token关联refresh token)
      refreshTokenId: {
        type: Schema.Types.ObjectId,
        ref: 'Token',
        default: null
      },
      
      // API密钥信息
      apiKeyInfo: {
        name: {
          type: String,
          trim: true,
          default: ''
        },
        description: {
          type: String,
          trim: true,
          default: ''
        },
        permissions: [{
          type: String,
          trim: true
        }],
        createdBy: {
          type: Schema.Types.ObjectId,
          ref: 'User'
        }
      },
      
      // 令牌元数据
      metadata: {
        deviceInfo: {
          type: String,
          trim: true,
          default: ''
        },
        ipAddress: {
          type: String,
          trim: true,
          default: ''
        },
        userAgent: {
          type: String,
          trim: true,
          default: ''
        },
        clientId: {
          type: String,
          trim: true,
          default: ''
        },
        scope: [{
          type: String,
          trim: true
        }],
        audience: {
          type: String,
          trim: true,
          default: ''
        }
      },
      
      // 令牌状态
      isActive: {
        type: Boolean,
        default: true
      },
      
      // 吊销信息
      revokedAt: {
        type: Date,
        default: null,
        index: true
      },
      revokedReason: {
        type: String,
        trim: true,
        default: ''
      },
      
      // 使用信息
      lastUsedAt: {
        type: Date,
        default: null
      },
      usageCount: {
        type: Number,
        default: 0
      },
      
      // 时间戳
      createdAt: {
        type: Date,
        default: Date.now
      },
      updatedAt: {
        type: Date,
        default: Date.now
      }
    }, {
      timestamps: true,
      toJSON: {
        transform: function(doc, ret) {
          delete ret.__v;
          delete ret.tokenHash;
          return ret;
        }
      },
      toObject: {
        transform: function(doc, ret) {
          delete ret.__v;
          delete ret.tokenHash;
          return ret;
        }
      }
    });

    // 设置索引
    TokenSchema.index({ userId: 1, tokenType: 1 });
    TokenSchema.index({ userId: 1, tokenType: 1, isActive: 1 });
    TokenSchema.index({ expiresAt: 1 });
    TokenSchema.index({ tokenHash: 1 });
    TokenSchema.index({ tokenType: 1, isActive: 1 });

    // 虚拟字段
    TokenSchema.virtual('isExpired').get(function() {
      return this.expiresAt < Date.now();
    });

    TokenSchema.virtual('isValid').get(function() {
      return this.isActive && !this.revokedAt && !this.isExpired;
    });

    // 中间件
    TokenSchema.pre('save', async function(next) {
      try {
        // 只有在令牌被修改时才重新哈希
        if (this.isModified('token')) {
          this.tokenHash = this.hashToken(this.token);
        }
        next();
      } catch (error) {
        next(error);
      }
    });

    // 实例方法
    TokenSchema.methods.hashToken = function(token) {
      return crypto.createHash('sha256').update(token).digest('hex');
    };

    TokenSchema.methods.revoke = async function(reason = 'Token revoked') {
      this.revokedAt = Date.now();
      this.revokedReason = reason;
      this.isActive = false;
      await this.save();
      return this;
    };

    TokenSchema.methods.updateUsage = async function() {
      this.lastUsedAt = Date.now();
      this.usageCount += 1;
      await this.save();
      return this;
    };

    TokenSchema.methods.getRemainingLife = function() {
      if (this.isExpired || this.revokedAt) {
        return 0;
      }
      return Math.max(0, this.expiresAt - Date.now());
    };

    TokenSchema.methods.toPublic = function() {
      const publicInfo = {
        token: this.token,
        tokenType: this.tokenType,
        expiresAt: this.expiresAt,
        createdAt: this.createdAt,
        metadata: this.metadata
      };

      if (this.tokenType === 'apiKey') {
        publicInfo.apiKeyInfo = {
          name: this.apiKeyInfo.name,
          permissions: this.apiKeyInfo.permissions
        };
      }

      return publicInfo;
    };

    // 静态方法
    TokenSchema.statics.hashToken = function(token) {
      return crypto.createHash('sha256').update(token).digest('hex');
    };

    TokenSchema.statics.findByToken = async function(token) {
      const tokenHash = this.hashToken(token);
      return await this.findOne({ tokenHash });
    };

    TokenSchema.statics.findActiveTokensByUserId = async function(userId, tokenType) {
      const query = {
        userId,
        isActive: true,
        revokedAt: null,
        expiresAt: { $gt: Date.now() }
      };

      if (tokenType) {
        query.tokenType = tokenType;
      }

      return await this.find(query);
    };

    TokenSchema.statics.revokeAllTokensForUser = async function(userId, reason = 'User logged out everywhere') {
      return await this.updateMany(
        {
          userId,
          isActive: true,
          revokedAt: null,
          expiresAt: { $gt: Date.now() }
        },
        {
          $set: {
            revokedAt: Date.now(),
            revokedReason: reason,
            isActive: false
          }
        }
      );
    };

    TokenSchema.statics.cleanupExpiredTokens = async function() {
      const result = await this.deleteMany({
        expiresAt: { $lt: Date.now() }
      });
      return result.deletedCount;
    };

    return TokenSchema;
  }

  /**
   * 生成随机令牌
   */
  generateRandomToken(length = 32) {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * 创建JWT令牌
   */
  async createJwtToken(userId, tokenType, options = {}) {
    const config = AppConfig.jwtConfig;
    let expiresIn;
    
    // 根据令牌类型设置过期时间
    switch (tokenType) {
      case 'access':
        expiresIn = options.expiresIn || config.accessTokenExpiry;
        break;
      case 'refresh':
        expiresIn = options.expiresIn || config.refreshTokenExpiry;
        break;
      case 'resetPassword':
        expiresIn = options.expiresIn || '1h';
        break;
      case 'verification':
        expiresIn = options.expiresIn || '24h';
        break;
      default:
        expiresIn = options.expiresIn || '1h';
    }

    // 令牌载荷
    const payload = {
      sub: userId.toString(),
      type: tokenType,
      jti: crypto.randomUUID(),
      iat: Date.now(),
      iss: config.issuer,
      aud: options.audience || config.audience,
      scope: options.scope || []
    };

    // 生成JWT令牌
    const token = jwt.sign(
      payload,
      config.secretKey,
      {
        expiresIn,
        algorithm: config.algorithm || 'HS256'
      }
    );

    // 计算过期时间
    const expiresAt = new Date(Date.now() + this.calculateExpiryTime(expiresIn));

    // 创建令牌记录
    const tokenRecord = {
      userId,
      token,
      tokenType,
      expiresAt,
      metadata: {
        deviceInfo: options.deviceInfo || '',
        ipAddress: options.ipAddress || '',
        userAgent: options.userAgent || '',
        clientId: options.clientId || '',
        scope: options.scope || [],
        audience: options.audience || ''
      }
    };

    // 如果是access token且提供了refresh token ID，关联refresh token
    if (tokenType === 'access' && options.refreshTokenId) {
      tokenRecord.refreshTokenId = options.refreshTokenId;
    }

    // 保存令牌记录
    const savedToken = await this.createToken(tokenRecord);
    
    return {
      token,
      tokenId: savedToken._id,
      expiresAt,
      payload
    };
  }

  /**
   * 验证JWT令牌
   */
  async verifyJwtToken(token) {
    const config = AppConfig.jwtConfig;
    
    try {
      // 验证JWT令牌
      const decoded = jwt.verify(token, config.secretKey, {
        algorithms: [config.algorithm || 'HS256'],
        issuer: config.issuer,
        audience: config.audience
      });

      // 检查令牌是否在数据库中存在且有效
      const tokenHash = this.Token.hashToken(token);
      const tokenRecord = await this.Token.findOne({
        tokenHash,
        tokenType: decoded.type,
        isActive: true,
        revokedAt: null,
        expiresAt: { $gt: Date.now() }
      });

      if (!tokenRecord) {
        throw new Error('Token not found or invalid');
      }

      // 更新使用信息
      await tokenRecord.updateUsage();

      return {
        valid: true,
        decoded,
        tokenRecord
      };
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        return { valid: false, error: 'Token expired' };
      }
      if (error.name === 'JsonWebTokenError') {
        return { valid: false, error: 'Invalid token' };
      }
      return { valid: false, error: error.message };
    }
  }

  /**
   * 创建访问令牌和刷新令牌对
   */
  async createTokenPair(userId, options = {}) {
    try {
      // 创建刷新令牌
      const refreshTokenData = await this.createJwtToken(userId, 'refresh', options);
      
      // 创建访问令牌，并关联刷新令牌
      const accessTokenData = await this.createJwtToken(userId, 'access', {
        ...options,
        refreshTokenId: refreshTokenData.tokenId
      });

      logger.info('Token pair created successfully', { userId, accessTokenId: accessTokenData.tokenId, refreshTokenId: refreshTokenData.tokenId });

      return {
        accessToken: accessTokenData.token,
        refreshToken: refreshTokenData.token,
        accessTokenExpiresAt: accessTokenData.expiresAt,
        refreshTokenExpiresAt: refreshTokenData.expiresAt,
        tokenType: 'Bearer'
      };
    } catch (error) {
      logger.error('Failed to create token pair', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 刷新令牌
   */
  async refreshToken(refreshToken) {
    try {
      // 验证刷新令牌
      const verification = await this.verifyJwtToken(refreshToken);
      
      if (!verification.valid) {
        throw new Error(verification.error || 'Invalid refresh token');
      }

      const { decoded, tokenRecord } = verification;
      
      // 检查令牌类型是否为刷新令牌
      if (decoded.type !== 'refresh') {
        throw new Error('Invalid token type');
      }

      // 创建新的访问令牌
      const options = {
        scope: decoded.scope || [],
        audience: decoded.aud,
        deviceInfo: tokenRecord.metadata.deviceInfo,
        ipAddress: tokenRecord.metadata.ipAddress,
        userAgent: tokenRecord.metadata.userAgent,
        clientId: tokenRecord.metadata.clientId,
        refreshTokenId: tokenRecord._id
      };

      const accessTokenData = await this.createJwtToken(decoded.sub, 'access', options);
      
      // 可选：如果配置了刷新令牌轮换，则吊销旧的刷新令牌并创建新的
      if (AppConfig.jwtConfig.rotateRefreshToken) {
        // 吊销旧的刷新令牌
        await tokenRecord.revoke('Token rotated');
        
        // 创建新的刷新令牌
        const newRefreshTokenData = await this.createJwtToken(decoded.sub, 'refresh', options);
        
        return {
          accessToken: accessTokenData.token,
          refreshToken: newRefreshTokenData.token,
          accessTokenExpiresAt: accessTokenData.expiresAt,
          refreshTokenExpiresAt: newRefreshTokenData.expiresAt,
          tokenType: 'Bearer'
        };
      }

      logger.info('Token refreshed successfully', { userId: decoded.sub, newAccessTokenId: accessTokenData.tokenId });

      return {
        accessToken: accessTokenData.token,
        refreshToken,
        accessTokenExpiresAt: accessTokenData.expiresAt,
        refreshTokenExpiresAt: tokenRecord.expiresAt,
        tokenType: 'Bearer'
      };
    } catch (error) {
      logger.error('Failed to refresh token', { error: error.message });
      throw error;
    }
  }

  /**
   * 创建API密钥
   */
  async createApiKey(options = {}) {
    const { name, description, permissions = [], createdBy } = options;
    
    // 生成API密钥
    const apiKey = this.generateRandomToken(48);
    
    // 计算过期时间（默认365天）
    const expiresAt = options.expiresAt || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);

    const apiKeyRecord = {
      token: apiKey,
      tokenType: 'apiKey',
      expiresAt,
      apiKeyInfo: {
        name,
        description,
        permissions,
        createdBy
      },
      metadata: {
        clientId: options.clientId || '',
        ipAddress: options.ipAddress || ''
      }
    };

    const savedToken = await this.createToken(apiKeyRecord);
    
    logger.info('API key created successfully', { apiKeyId: savedToken._id, name });

    return {
      apiKey,
      apiKeyId: savedToken._id,
      expiresAt,
      name,
      description,
      permissions
    };
  }

  /**
   * 创建令牌记录
   */
  async createToken(tokenData) {
    try {
      const token = new this.Token(tokenData);
      const savedToken = await token.save();
      
      logger.info('Token created', { tokenType: tokenData.tokenType, tokenId: savedToken._id, userId: tokenData.userId });
      
      return savedToken;
    } catch (error) {
      logger.error('Failed to create token', { error: error.message, tokenType: tokenData.tokenType });
      throw error;
    }
  }

  /**
   * 通过令牌查找
   */
  async findByToken(token) {
    try {
      const tokenHash = this.Token.hashToken(token);
      return await this.Token.findOne({ tokenHash });
    } catch (error) {
      logger.error('Failed to find token', { error: error.message });
      throw error;
    }
  }

  /**
   * 吊销令牌
   */
  async revokeToken(token, reason = 'Token revoked') {
    try {
      const tokenRecord = await this.findByToken(token);
      
      if (!tokenRecord) {
        throw new Error('Token not found');
      }

      await tokenRecord.revoke(reason);
      
      // 如果是刷新令牌，吊销关联的访问令牌
      if (tokenRecord.tokenType === 'refresh') {
        await this.Token.updateMany(
          { refreshTokenId: tokenRecord._id, isActive: true },
          {
            $set: {
              revokedAt: Date.now(),
              revokedReason: 'Refresh token revoked',
              isActive: false
            }
          }
        );
      }

      logger.info('Token revoked', { tokenId: tokenRecord._id, tokenType: tokenRecord.tokenType, userId: tokenRecord.userId });
      
      return tokenRecord;
    } catch (error) {
      logger.error('Failed to revoke token', { error: error.message });
      throw error;
    }
  }

  /**
   * 吊销用户的所有令牌
   */
  async revokeAllUserTokens(userId, reason = 'User logged out everywhere') {
    try {
      const result = await this.Token.revokeAllTokensForUser(userId, reason);
      
      logger.info('All user tokens revoked', { userId, count: result.nModified });
      
      return result;
    } catch (error) {
      logger.error('Failed to revoke all user tokens', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 清理过期令牌
   */
  async cleanupExpiredTokens() {
    try {
      const deletedCount = await this.Token.cleanupExpiredTokens();
      
      if (deletedCount > 0) {
        logger.info('Expired tokens cleaned up', { count: deletedCount });
      }
      
      return deletedCount;
    } catch (error) {
      logger.error('Failed to cleanup expired tokens', { error: error.message });
      throw error;
    }
  }

  /**
   * 获取令牌统计信息
   */
  async getStats() {
    try {
      const stats = {
        total: await this.Token.countDocuments(),
        active: await this.Token.countDocuments({ isActive: true, revokedAt: null, expiresAt: { $gt: Date.now() } }),
        expired: await this.Token.countDocuments({ expiresAt: { $lt: Date.now() } }),
        revoked: await this.Token.countDocuments({ revokedAt: { $ne: null } }),
        byType: {
          access: await this.Token.countDocuments({ tokenType: 'access' }),
          refresh: await this.Token.countDocuments({ tokenType: 'refresh' }),
          resetPassword: await this.Token.countDocuments({ tokenType: 'resetPassword' }),
          verification: await this.Token.countDocuments({ tokenType: 'verification' }),
          apiKey: await this.Token.countDocuments({ tokenType: 'apiKey' })
        }
      };
      
      return stats;
    } catch (error) {
      logger.error('Failed to get token stats', { error: error.message });
      throw error;
    }
  }

  /**
   * 计算过期时间
   */
  calculateExpiryTime(expiresIn) {
    // 解析过期时间字符串 (如 '1h', '2d', '30m')
    if (typeof expiresIn === 'string') {
      const match = expiresIn.match(/^(\d+)([hdm])$/);
      if (match) {
        const value = parseInt(match[1], 10);
        const unit = match[2];
        
        switch (unit) {
          case 'h': return value * 60 * 60 * 1000; // 小时
          case 'd': return value * 24 * 60 * 60 * 1000; // 天
          case 'm': return value * 60 * 1000; // 分钟
        }
      }
    }
    
    // 如果是数字，假设是毫秒
    if (typeof expiresIn === 'number') {
      return expiresIn;
    }
    
    // 默认1小时
    return 60 * 60 * 1000;
  }

  /**
   * 获取模型实例
   */
  getModel() {
    return this.Token;
  }
}

/**
 * 导出单例实例
 */
const tokenModel = new TokenModel();

module.exports = tokenModel;
module.exports.Token = tokenModel.getModel();