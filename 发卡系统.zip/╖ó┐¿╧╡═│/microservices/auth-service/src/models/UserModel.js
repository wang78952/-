const { pool } = require('../config/database');

class UserModel {
  // 根据用户名或邮箱查找用户
  static async findByUsernameOrEmail(username, email) {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM users WHERE username = ? OR email = ?',
        [username, email]
      );
      return rows[0] || null;
    } catch (error) {
      console.error('查找用户失败:', error);
      throw error;
    }
  }

  // 根据ID查找用户
  static async findById(id) {
    try {
      const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [id]);
      return rows[0] || null;
    } catch (error) {
      console.error('根据ID查找用户失败:', error);
      throw error;
    }
  }

  // 更新用户登录失败次数
  static async updateLoginAttempts(userId, attempts, lastAttemptTime) {
    try {
      await pool.query(
        'UPDATE users SET login_attempts = ?, last_login_attempt = ? WHERE id = ?',
        [attempts, lastAttemptTime, userId]
      );
    } catch (error) {
      console.error('更新登录失败次数失败:', error);
      throw error;
    }
  }

  // 重置登录失败次数
  static async resetLoginAttempts(userId) {
    try {
      await pool.query(
        'UPDATE users SET login_attempts = 0 WHERE id = ?',
        [userId]
      );
    } catch (error) {
      console.error('重置登录失败次数失败:', error);
      throw error;
    }
  }

  // 更新用户最后登录时间
  static async updateLastLogin(userId, lastLoginTime) {
    try {
      await pool.query(
        'UPDATE users SET last_login = ? WHERE id = ?',
        [lastLoginTime, userId]
      );
    } catch (error) {
      console.error('更新最后登录时间失败:', error);
      throw error;
    }
  }

  // 验证用户密码
  static async verifyPassword(userId, password) {
    try {
      const [rows] = await pool.query(
        'SELECT password FROM users WHERE id = ?',
        [userId]
      );
      if (rows.length === 0) return false;
      return rows[0].password; // 返回哈希密码，由服务层进行验证
    } catch (error) {
      console.error('验证密码失败:', error);
      throw error;
    }
  }

  // 更新用户密码
  static async updatePassword(userId, newPasswordHash) {
    try {
      await pool.query(
        'UPDATE users SET password = ? WHERE id = ?',
        [newPasswordHash, userId]
      );
    } catch (error) {
      console.error('更新密码失败:', error);
      throw error;
    }
  }

  // 获取用户角色
  static async getUserRole(userId) {
    try {
      const [rows] = await pool.query(
        'SELECT role FROM users WHERE id = ?',
        [userId]
      );
      return rows[0]?.role || null;
    } catch (error) {
      console.error('获取用户角色失败:', error);
      throw error;
    }
  }
}

module.exports = UserModel;