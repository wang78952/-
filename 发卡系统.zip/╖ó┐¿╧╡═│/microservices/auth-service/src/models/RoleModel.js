const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const logger = require('../utils/logger');

/**
 * 角色模型
 */
class RoleModel {
  constructor() {
    // 创建角色架构
    this.roleSchema = this.createRoleSchema();
    
    // 创建模型
    this.Role = mongoose.model('Role', this.roleSchema);
  }

  /**
   * 创建角色架构
   */
  createRoleSchema() {
    const RoleSchema = new Schema({
      // 角色基本信息
      name: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        minlength: 2,
        maxlength: 50
      },
      
      // 角色描述
      description: {
        type: String,
        trim: true,
        maxlength: 255,
        default: ''
      },
      
      // 角色权限
      permissions: [{
        type: String,
        trim: true
      }],
      
      // 角色状态
      isActive: {
        type: Boolean,
        default: true
      },
      
      // 角色类型
      type: {
        type: String,
        enum: ['system', 'custom', 'default'],
        default: 'custom'
      },
      
      // 优先级（用于解决权限冲突）
      priority: {
        type: Number,
        default: 0
      },
      
      // 父角色
      parentRole: {
        type: Schema.Types.ObjectId,
        ref: 'Role',
        default: null
      },
      
      // 继承自父角色的权限
      inheritedPermissions: [{
        type: String,
        trim: true
      }],
      
      // 租户信息
      tenantId: {
        type: String,
        default: 'default'
      },
      
      // 是否系统内置（无法删除）
      isSystem: {
        type: Boolean,
        default: false
      },
      
      // 是否为默认角色
      isDefault: {
        type: Boolean,
        default: false
      },
      
      // 额外信息
      metadata: {
        type: Object,
        default: {}
      },
      
      // 时间戳
      createdAt: {
        type: Date,
        default: Date.now
      },
      updatedAt: {
        type: Date,
        default: Date.now
      },
      deletedAt: {
        type: Date,
        default: null
      }
    }, {
      timestamps: true,
      toJSON: {
        virtuals: true,
        transform: function(doc, ret) {
          delete ret.__v;
          return ret;
        }
      },
      toObject: {
        virtuals: true,
        transform: function(doc, ret) {
          delete ret.__v;
          return ret;
        }
      }
    });

    // 设置索引
    RoleSchema.index({ name: 1 }, { unique: true });
    RoleSchema.index({ tenantId: 1, isActive: 1 });
    RoleSchema.index({ parentRole: 1 });
    RoleSchema.index({ priority: -1 });

    // 虚拟字段
    RoleSchema.virtual('isDeleted').get(function() {
      return !!this.deletedAt;
    });

    RoleSchema.virtual('fullPermissions').get(function() {
      // 合并自身权限和继承权限，去重
      return [...new Set([...(this.permissions || []), ...(this.inheritedPermissions || [])])];
    });

    // 中间件
    RoleSchema.pre('save', async function(next) {
      try {
        // 如果有父角色，继承父角色的权限
        if (this.parentRole) {
          await this.updateInheritedPermissions();
        }
        next();
      } catch (error) {
        next(error);
      }
    });

    RoleSchema.pre('findOneAndUpdate', async function(next) {
      try {
        this._update.updatedAt = Date.now();
        next();
      } catch (error) {
        next(error);
      }
    });

    RoleSchema.post('findOneAndUpdate', async function(doc) {
      try {
        if (doc && doc.parentRole) {
          // 更新继承的权限
          await doc.updateInheritedPermissions();
          
          // 查找所有子角色并更新它们的继承权限
          await this.model.find({ parentRole: doc._id }, async (err, children) => {
            if (!err) {
              for (const child of children) {
                await child.updateInheritedPermissions();
              }
            }
          });
        }
      } catch (error) {
        logger.error('Error updating inherited permissions after role update', { error: error.message, roleId: doc._id });
      }
    });

    // 实例方法
    RoleSchema.methods.addPermission = function(permission) {
      if (!this.permissions.includes(permission)) {
        this.permissions.push(permission);
      }
      return this;
    };

    RoleSchema.methods.removePermission = function(permission) {
      this.permissions = this.permissions.filter(p => p !== permission);
      return this;
    };

    RoleSchema.methods.hasPermission = function(permission) {
      return this.fullPermissions.includes(permission);
    };

    RoleSchema.methods.hasAnyPermission = function(permissions) {
      const fullPerms = this.fullPermissions;
      return permissions.some(perm => fullPerms.includes(perm));
    };

    RoleSchema.methods.hasAllPermissions = function(permissions) {
      const fullPerms = this.fullPermissions;
      return permissions.every(perm => fullPerms.includes(perm));
    };

    RoleSchema.methods.updateInheritedPermissions = async function() {
      if (this.parentRole) {
        try {
          const parentRole = await this.model.findById(this.parentRole);
          if (parentRole) {
            this.inheritedPermissions = parentRole.fullPermissions;
          }
        } catch (error) {
          logger.error('Error updating inherited permissions', { error: error.message, roleId: this._id });
        }
      }
      return this;
    };

    RoleSchema.methods.addChildRole = async function(childRoleId) {
      try {
        const childRole = await this.model.findById(childRoleId);
        if (childRole) {
          childRole.parentRole = this._id;
          await childRole.save();
          // 更新子角色的继承权限
          await childRole.updateInheritedPermissions();
          return childRole;
        }
        return null;
      } catch (error) {
        logger.error('Error adding child role', { error: error.message, parentRoleId: this._id, childRoleId });
        throw error;
      }
    };

    RoleSchema.methods.removeParentRole = async function() {
      this.parentRole = null;
      this.inheritedPermissions = [];
      await this.save();
      return this;
    };

    RoleSchema.methods.softDelete = async function() {
      // 系统内置角色不能删除
      if (this.isSystem) {
        throw new Error('Cannot delete system role');
      }
      
      this.deletedAt = Date.now();
      this.isActive = false;
      await this.save();
      
      // 将所有子角色的父角色设为null
      await this.model.updateMany(
        { parentRole: this._id },
        { $set: { parentRole: null, inheritedPermissions: [] } }
      );
      
      return this;
    };

    RoleSchema.methods.restore = async function() {
      this.deletedAt = null;
      this.isActive = true;
      await this.save();
      
      // 恢复后重新获取继承权限
      if (this.parentRole) {
        await this.updateInheritedPermissions();
      }
      
      return this;
    };

    // 静态方法
    RoleSchema.statics.getSystemRoles = async function() {
      return await this.find({ type: 'system', isActive: true });
    };

    RoleSchema.statics.getDefaultRole = async function() {
      return await this.findOne({ isDefault: true, isActive: true });
    };

    RoleSchema.statics.getAllActiveRoles = async function(tenantId = 'default') {
      return await this.find({ tenantId, isActive: true, deletedAt: null });
    };

    RoleSchema.statics.validatePermissionList = function(permissions) {
      if (!Array.isArray(permissions)) {
        return { valid: false, message: 'Permissions must be an array' };
      }
      
      // 检查每个权限的格式
      for (const perm of permissions) {
        if (typeof perm !== 'string' || perm.trim() === '') {
          return { valid: false, message: 'Each permission must be a non-empty string' };
        }
        
        // 检查权限格式是否符合规范 (resource:action)
        if (!/^[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+$/.test(perm)) {
          return { valid: false, message: `Invalid permission format: ${perm}. Format should be 'resource:action'` };
        }
      }
      
      return { valid: true };
    };

    RoleSchema.statics.getPermissionTree = async function() {
      const roles = await this.find({ isActive: true, deletedAt: null });
      const roleMap = new Map();
      const rootRoles = [];
      
      // 首先创建所有角色的映射
      roles.forEach(role => {
        roleMap.set(role._id.toString(), {
          ...role.toObject(),
          children: []
        });
      });
      
      // 构建树结构
      roleMap.forEach(role => {
        if (!role.parentRole) {
          rootRoles.push(role);
        } else {
          const parentId = role.parentRole.toString();
          if (roleMap.has(parentId)) {
            roleMap.get(parentId).children.push(role);
          }
        }
      });
      
      return rootRoles;
    };

    return RoleSchema;
  }

  /**
   * 创建角色
   */
  async createRole(roleData) {
    try {
      // 验证权限列表
      if (roleData.permissions) {
        const validation = this.Role.validatePermissionList(roleData.permissions);
        if (!validation.valid) {
          throw new Error(validation.message);
        }
      }
      
      // 检查是否已有默认角色
      if (roleData.isDefault) {
        const existingDefault = await this.Role.findOne({ isDefault: true });
        if (existingDefault) {
          throw new Error('Only one default role is allowed');
        }
      }
      
      const role = new this.Role(roleData);
      const savedRole = await role.save();
      
      logger.info('Role created successfully', { roleId: savedRole._id, roleName: savedRole.name });
      return savedRole;
    } catch (error) {
      logger.error('Failed to create role', { error: error.message, roleData });
      throw error;
    }
  }

  /**
   * 通过ID查找角色
   */
  async findById(roleId) {
    try {
      const role = await this.Role.findById(roleId).lean();
      return role;
    } catch (error) {
      logger.error('Failed to find role by ID', { error: error.message, roleId });
      throw error;
    }
  }

  /**
   * 通过名称查找角色
   */
  async findByName(roleName) {
    try {
      const role = await this.Role.findOne({ name: roleName }).lean();
      return role;
    } catch (error) {
      logger.error('Failed to find role by name', { error: error.message, roleName });
      throw error;
    }
  }

  /**
   * 查找所有角色
   */
  async findAll(query = {}, options = {}) {
    try {
      const { page = 1, limit = 10, sort = { priority: -1, createdAt: -1 } } = options;
      
      // 默认不包含已删除角色
      if (!query.deletedAt) {
        query.deletedAt = null;
      }
      
      const skip = (page - 1) * limit;
      
      const roles = await this.Role.find(query)
        .skip(skip)
        .limit(limit)
        .sort(sort)
        .lean();
      
      const total = await this.Role.countDocuments(query);
      
      return {
        roles,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit)
        }
      };
    } catch (error) {
      logger.error('Failed to find all roles', { error: error.message, query });
      throw error;
    }
  }

  /**
   * 更新角色
   */
  async updateRole(roleId, updateData) {
    try {
      const role = await this.Role.findById(roleId);
      if (!role) {
        throw new Error('Role not found');
      }
      
      // 系统角色不能修改名称
      if (role.isSystem && updateData.name && updateData.name !== role.name) {
        throw new Error('Cannot modify system role name');
      }
      
      // 检查是否已有默认角色
      if (updateData.isDefault && !role.isDefault) {
        const existingDefault = await this.Role.findOne({ isDefault: true, _id: { $ne: roleId } });
        if (existingDefault) {
          throw new Error('Only one default role is allowed');
        }
      }
      
      // 验证权限列表
      if (updateData.permissions) {
        const validation = this.Role.validatePermissionList(updateData.permissions);
        if (!validation.valid) {
          throw new Error(validation.message);
        }
      }
      
      // 更新角色
      Object.assign(role, updateData);
      await role.save();
      
      // 如果更新了父角色或权限，更新继承权限
      if (updateData.parentRole || updateData.permissions) {
        await role.updateInheritedPermissions();
      }
      
      logger.info('Role updated successfully', { roleId, updateFields: Object.keys(updateData) });
      return role;
    } catch (error) {
      logger.error('Failed to update role', { error: error.message, roleId, updateFields: Object.keys(updateData) });
      throw error;
    }
  }

  /**
   * 删除角色
   */
  async deleteRole(roleId) {
    try {
      const role = await this.Role.findById(roleId);
      if (!role) {
        throw new Error('Role not found');
      }
      
      await role.softDelete();
      logger.info('Role deleted successfully', { roleId, roleName: role.name });
      return { message: 'Role deleted successfully' };
    } catch (error) {
      logger.error('Failed to delete role', { error: error.message, roleId });
      throw error;
    }
  }

  /**
   * 添加权限到角色
   */
  async addPermission(roleId, permission) {
    try {
      const role = await this.Role.findById(roleId);
      if (!role) {
        throw new Error('Role not found');
      }
      
      role.addPermission(permission);
      await role.save();
      
      logger.info('Permission added to role', { roleId, permission });
      return role;
    } catch (error) {
      logger.error('Failed to add permission to role', { error: error.message, roleId, permission });
      throw error;
    }
  }

  /**
   * 从角色移除权限
   */
  async removePermission(roleId, permission) {
    try {
      const role = await this.Role.findById(roleId);
      if (!role) {
        throw new Error('Role not found');
      }
      
      role.removePermission(permission);
      await role.save();
      
      logger.info('Permission removed from role', { roleId, permission });
      return role;
    } catch (error) {
      logger.error('Failed to remove permission from role', { error: error.message, roleId, permission });
      throw error;
    }
  }

  /**
   * 批量创建角色
   */
  async bulkCreate(rolesData) {
    try {
      const roles = await this.Role.insertMany(rolesData, { ordered: false });
      logger.info('Bulk roles created successfully', { count: roles.length });
      return roles;
    } catch (error) {
      logger.error('Failed to bulk create roles', { error: error.message, count: rolesData.length });
      throw error;
    }
  }

  /**
   * 获取角色统计信息
   */
  async getStats() {
    try {
      const stats = {
        total: await this.Role.countDocuments(),
        active: await this.Role.countDocuments({ isActive: true, deletedAt: null }),
        inactive: await this.Role.countDocuments({ isActive: false, deletedAt: null }),
        system: await this.Role.countDocuments({ type: 'system' }),
        custom: await this.Role.countDocuments({ type: 'custom' }),
        deleted: await this.Role.countDocuments({ deletedAt: { $ne: null } })
      };
      
      return stats;
    } catch (error) {
      logger.error('Failed to get role stats', { error: error.message });
      throw error;
    }
  }

  /**
   * 初始化系统角色
   */
  async initializeSystemRoles() {
    try {
      const systemRoles = [
        {
          name: 'Admin',
          description: 'System administrator with all permissions',
          permissions: [
            'user:create', 'user:read', 'user:update', 'user:delete',
            'role:create', 'role:read', 'role:update', 'role:delete',
            'permission:grant', 'permission:revoke',
            'system:config', 'system:logs', 'system:stats',
            'auth:manage', 'auth:token', 'auth:refresh'
          ],
          isSystem: true,
          type: 'system',
          priority: 100,
          isActive: true
        },
        {
          name: 'User',
          description: 'Default user role',
          permissions: [
            'user:read:own', 'user:update:own',
            'auth:login', 'auth:logout'
          ],
          type: 'default',
          isDefault: true,
          priority: 0,
          isActive: true
        },
        {
          name: 'Manager',
          description: 'Manager role with limited admin permissions',
          permissions: [
            'user:read', 'user:update',
            'role:read', 'system:stats'
          ],
          type: 'custom',
          priority: 50,
          isActive: true
        }
      ];

      const createdRoles = [];
      
      for (const roleData of systemRoles) {
        // 检查角色是否已存在
        const existingRole = await this.Role.findOne({ name: roleData.name });
        if (!existingRole) {
          const role = await this.createRole(roleData);
          createdRoles.push(role);
        }
      }
      
      logger.info('System roles initialized', { created: createdRoles.length });
      return createdRoles;
    } catch (error) {
      logger.error('Failed to initialize system roles', { error: error.message });
      throw error;
    }
  }

  /**
   * 获取模型实例
   */
  getModel() {
    return this.Role;
  }
}

/**
 * 导出单例实例
 */
const roleModel = new RoleModel();

module.exports = roleModel;
module.exports.Role = roleModel.getModel();