const { verifyAccessToken } = require('../utils/jwtUtils');
const logger = require('../utils/logger');

// JWT认证中间件
exports.authenticateJWT = (req, res, next) => {
  // 从请求头获取令牌
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    logger.warn('认证失败：缺少或无效的授权头');
    return res.status(401).json({
      success: false,
      message: '未授权访问，请提供有效的令牌'
    });
  }

  // 提取令牌
  const token = authHeader.split(' ')[1];
  
  // 验证令牌
  const decoded = verifyAccessToken(token);
  
  if (!decoded || decoded.type !== 'access') {
    logger.warn('认证失败：无效的令牌');
    return res.status(401).json({
      success: false,
      message: '无效的令牌'
    });
  }

  // 将用户信息存储在请求对象中
  req.user = {
    id: decoded.id,
    role: decoded.role,
    username: decoded.username
  };

  logger.info(`认证成功 - user_id: ${decoded.id}, username: ${decoded.username}`);
  next();
};

// 角色验证中间件
exports.authorizeRole = (roles) => {
  return (req, res, next) => {
    // 首先检查用户是否已认证
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: '未授权访问，请先登录'
      });
    }

    // 检查用户角色是否在允许的角色列表中
    const userRole = req.user.role;
    
    // 如果roles参数是字符串，转换为数组
    const allowedRoles = typeof roles === 'string' ? [roles] : roles;
    
    if (!allowedRoles.includes(userRole)) {
      logger.warn(`授权失败：角色不允许 - user_id: ${req.user.id}, role: ${userRole}, required: ${allowedRoles.join(', ')}`);
      return res.status(403).json({
        success: false,
        message: '权限不足，无法访问此资源'
      });
    }

    logger.info(`授权成功 - user_id: ${req.user.id}, role: ${userRole}`);
    next();
  };
};

// 错误处理中间件
exports.errorHandler = (err, req, res, next) => {
  logger.error(`请求处理错误: ${err.message} - path: ${req.path}, method: ${req.method}`);
  
  // 设置默认错误状态码
  const statusCode = err.statusCode || 500;
  
  // 构造错误响应
  const errorResponse = {
    success: false,
    message: process.env.NODE_ENV === 'development' ? err.message : '服务器内部错误'
  };

  // 在开发环境中包含错误堆栈
  if (process.env.NODE_ENV === 'development') {
    errorResponse.stack = err.stack;
  }

  res.status(statusCode).json(errorResponse);
};

// 请求日志中间件
exports.requestLogger = (req, res, next) => {
  // 记录请求开始
  const startTime = Date.now();
  const { method, url, headers } = req;
  
  logger.info(`请求开始 - ${method} ${url} - IP: ${headers['x-forwarded-for'] || req.ip}`);
  
  // 捕获响应结束
  const originalSend = res.send;
  res.send = function(body) {
    // 计算响应时间
    const endTime = Date.now();
    const responseTime = endTime - startTime;
    
    // 记录响应信息
    logger.info(`请求结束 - ${method} ${url} - 状态: ${res.statusCode} - 耗时: ${responseTime}ms`);
    
    // 调用原始的send方法
    return originalSend.call(this, body);
  };
  
  next();
};