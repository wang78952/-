const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const AppConfig = require('../config/app');
const logger = require('../utils/logger');
const TokenModel = require('../models/TokenModel');
const UserModel = require('../models/UserModel');

class AuthMiddleware {
  constructor() {
    this.config = AppConfig.getInstance();
    this.logger = logger.getInstance();
    this.setupJwtStrategy();
  }

  setupJwtStrategy() {
    const jwtOptions = {
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: this.config.get('JWT_SECRET'),
      issuer: this.config.get('JWT_ISSUER'),
      audience: this.config.get('JWT_AUDIENCE'),
      ignoreExpiration: false,
      maxAge: this.config.get('JWT_EXPIRATION')
    };

    passport.use(new JwtStrategy(jwtOptions, async (jwtPayload, done) => {
      try {
        // 验证令牌是否被撤销
        const tokenExists = await TokenModel.findOne({
          token: jwtPayload.tokenId,
          userId: jwtPayload.sub,
          revoked: false
        });

        if (!tokenExists) {
          return done(null, false, { message: 'Token has been revoked' });
        }

        // 获取用户信息
        const user = await UserModel.findById(jwtPayload.sub);
        if (!user) {
          return done(null, false, { message: 'User not found' });
        }

        // 检查用户是否被禁用或锁定
        if (user.status === 'disabled') {
          return done(null, false, { message: 'User account is disabled' });
        }

        if (user.locked) {
          return done(null, false, { message: 'User account is locked' });
        }

        // 验证用户权限
        if (!user.verified && !this.config.get('ALLOW_UNVERIFIED_USERS')) {
          return done(null, false, { message: 'User email not verified' });
        }

        return done(null, user);
      } catch (error) {
        this.logger.error('Error in JWT strategy', { error: error.message, userId: jwtPayload?.sub });
        return done(error, false);
      }
    }));
  }

  /**
   * 验证用户身份的中间件
   */
  authenticate() {
    return (req, res, next) => {
      passport.authenticate('jwt', { session: false }, (err, user, info) => {
        if (err) {
          this.logger.error('Authentication error', { error: err.message, url: req.originalUrl });
          return res.status(500).json({
            success: false,
            message: 'Authentication failed',
            error: 'Internal server error'
          });
        }

        if (!user) {
          this.logger.warn('Authentication failed', { info: info?.message, url: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: info?.message || 'Authentication required',
            code: 'UNAUTHORIZED'
          });
        }

        // 将用户信息添加到请求对象
        req.user = user;
        
        // 记录访问日志
        this.logger.info('User authenticated', {
          userId: user._id,
          username: user.username,
          ip: req.ip,
          url: req.originalUrl,
          method: req.method
        });

        next();
      })(req, res, next);
    };
  }

  /**
   * 验证用户权限的中间件
   * @param {string|Array<string>} requiredPermissions - 需要的权限
   */
  authorize(requiredPermissions) {
    return (req, res, next) => {
      // 确保用户已通过身份验证
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Authentication required',
          code: 'UNAUTHORIZED'
        });
      }

      const permissions = Array.isArray(requiredPermissions) ? requiredPermissions : [requiredPermissions];
      const userPermissions = req.user.permissions || [];
      const hasAdminRole = req.user.roles?.some(role => role.name === 'admin') || false;

      // 管理员拥有所有权限
      if (hasAdminRole) {
        return next();
      }

      // 检查用户是否拥有所需的所有权限
      const hasPermission = permissions.every(permission => 
        userPermissions.includes(permission)
      );

      if (!hasPermission) {
        this.logger.warn('Permission denied', {
          userId: req.user._id,
          username: req.user.username,
          requiredPermissions,
          url: req.originalUrl
        });
        return res.status(403).json({
          success: false,
          message: 'Insufficient permissions',
          code: 'FORBIDDEN'
        });
      }

      next();
    };
  }

  /**
   * 错误处理中间件
   */
  errorHandler() {
    return (err, req, res, next) => {
      this.logger.error('API Error', {
        error: err.message,
        stack: err.stack,
        url: req.originalUrl,
        method: req.method,
        userId: req.user?.id || 'anonymous'
      });

      // 根据错误类型返回不同的响应
      if (err.name === 'ValidationError') {
        return res.status(400).json({
          success: false,
          message: 'Validation error',
          errors: Object.values(err.errors).map(e => e.message)
        });
      }

      if (err.name === 'UnauthorizedError') {
        return res.status(401).json({
          success: false,
          message: 'Invalid token',
          code: 'INVALID_TOKEN'
        });
      }

      // 默认错误响应
      return res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: this.config.get('NODE_ENV') === 'production' ? undefined : err.message
      });
    };
  }

  /**
   * CORS中间件
   */
  cors() {
    return (req, res, next) => {
      const allowedOrigins = this.config.get('CORS_ALLOWED_ORIGINS') || ['*'];
      const origin = req.headers.origin;

      if (allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin || '*');
      }

      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Access-Control-Max-Age', '86400'); // 24小时

      // 处理预检请求
      if (req.method === 'OPTIONS') {
        return res.status(200).end();
      }

      next();
    };
  }

  /**
   * 请求日志记录中间件
   */
  requestLogger() {
    return (req, res, next) => {
      const start = Date.now();
      const originalSend = res.send;

      // 覆盖res.send方法以捕获响应数据
      res.send = function(body) {
        const duration = Date.now() - start;
        
        // 记录请求信息
        this.logger.info('HTTP Request', {
          method: req.method,
          url: req.originalUrl,
          statusCode: res.statusCode,
          duration: duration,
          userId: req.user?.id || 'anonymous',
          ip: req.ip,
          userAgent: req.headers['user-agent']
        });

        return originalSend.call(this, body);
      };

      next();
    };
  }

  /**
   * 速率限制中间件
   */
  rateLimiter() {
    return (req, res, next) => {
      // 这里可以集成express-rate-limit等速率限制库
      // 简化版本，实际项目中应使用专门的速率限制库
      next();
    };
  }

  /**
   * CSRF保护中间件
   */
  csrfProtection() {
    return (req, res, next) => {
      // 对于API服务，通常使用JWT就已经提供了CSRF保护
      // 这里可以添加额外的CSRF保护逻辑
      next();
    };
  }

  /**
   * 输入验证中间件生成器
   * @param {Object} schema - Joi验证模式
   */
  validateInput(schema) {
    return async (req, res, next) => {
      try {
        const validatedData = await schema.validateAsync(req.body, {
          abortEarly: false
        });
        req.body = validatedData;
        next();
      } catch (error) {
        this.logger.warn('Input validation failed', {
          userId: req.user?.id || 'anonymous',
          url: req.originalUrl,
          errors: error.details.map(detail => detail.message)
        });
        return res.status(400).json({
          success: false,
          message: 'Validation error',
          errors: error.details.map(detail => detail.message)
        });
      }
    };
  }
}

// 导出单例实例
const authMiddleware = new AuthMiddleware();
module.exports = authMiddleware;