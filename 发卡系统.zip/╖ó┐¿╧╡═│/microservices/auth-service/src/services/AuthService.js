const UserModel = require('../models/UserModel');
const { generateAccessToken, generateRefreshToken } = require('../utils/jwtUtils');
const { verifyPassword } = require('../utils/passwordUtils');
const logger = require('../utils/logger');

class AuthService {
  // 用户登录
  static async login(username, email, password) {
    try {
      // 查找用户
      const user = await UserModel.findByUsernameOrEmail(username, email);
      if (!user) {
        logger.warn(`登录失败：用户不存在 - username: ${username}, email: ${email}`);
        return { success: false, message: '用户名或密码错误' };
      }

      // 检查账户是否被锁定
      if (user.login_attempts >= 5) {
        logger.warn(`登录失败：账户已被锁定 - user_id: ${user.id}`);
        return { success: false, message: '账户已被锁定，请稍后再试' };
      }

      // 验证密码
      const isPasswordValid = await verifyPassword(password, user.password);
      if (!isPasswordValid) {
        // 更新登录失败次数
        const attempts = (user.login_attempts || 0) + 1;
        await UserModel.updateLoginAttempts(user.id, attempts, new Date());
        logger.warn(`登录失败：密码错误 - user_id: ${user.id}, attempts: ${attempts}`);
        return { success: false, message: '用户名或密码错误' };
      }

      // 重置登录失败次数
      await UserModel.resetLoginAttempts(user.id);
      
      // 更新最后登录时间
      await UserModel.updateLastLogin(user.id, new Date());

      // 生成令牌
      const accessToken = generateAccessToken(user.id, user.role, user.username);
      const refreshToken = generateRefreshToken(user.id);

      logger.info(`登录成功 - user_id: ${user.id}, username: ${user.username}`);
      
      return {
        success: true,
        data: {
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            created_at: user.created_at
          },
          tokens: {
            access_token: accessToken,
            refresh_token: refreshToken,
            expires_in: 86400 // 24小时（秒）
          }
        }
      };
    } catch (error) {
      logger.error(`登录过程发生错误: ${error.message}`);
      return { success: false, message: '登录过程中发生错误，请稍后再试' };
    }
  }

  // 用户登出
  static async logout(userId) {
    try {
      // 这里可以实现令牌黑名单功能
      // 暂时只记录日志
      logger.info(`用户登出 - user_id: ${userId}`);
      return { success: true, message: '登出成功' };
    } catch (error) {
      logger.error(`登出过程发生错误: ${error.message}`);
      return { success: false, message: '登出过程中发生错误，请稍后再试' };
    }
  }

  // 刷新令牌
  static async refreshToken(refreshTokenPayload) {
    try {
      const { id: userId } = refreshTokenPayload;
      
      // 验证用户是否存在
      const user = await UserModel.findById(userId);
      if (!user) {
        logger.warn(`刷新令牌失败：用户不存在 - user_id: ${userId}`);
        return { success: false, message: '无效的令牌' };
      }

      // 生成新的访问令牌
      const newAccessToken = generateAccessToken(user.id, user.role, user.username);
      
      logger.info(`令牌刷新成功 - user_id: ${userId}`);
      
      return {
        success: true,
        data: {
          access_token: newAccessToken,
          expires_in: 86400 // 24小时（秒）
        }
      };
    } catch (error) {
      logger.error(`刷新令牌过程发生错误: ${error.message}`);
      return { success: false, message: '刷新令牌过程中发生错误，请稍后再试' };
    }
  }

  // 验证用户权限
  static async checkPermission(userId, requiredRole) {
    try {
      const user = await UserModel.findById(userId);
      if (!user) {
        return { success: false, message: '用户不存在' };
      }

      // 定义角色权限层级
      const roleHierarchy = {
        'admin': ['admin', 'superadmin'],
        'agent': ['admin', 'agent', 'superadmin'],
        'user': ['admin', 'agent', 'user', 'superadmin'],
        'superadmin': ['superadmin']
      };

      // 检查用户角色是否在允许的角色列表中
      const allowedRoles = roleHierarchy[requiredRole] || [];
      const hasPermission = allowedRoles.includes(user.role);
      
      return {
        success: hasPermission,
        message: hasPermission ? '权限验证通过' : '权限不足'
      };
    } catch (error) {
      logger.error(`权限验证过程发生错误: ${error.message}`);
      return { success: false, message: '权限验证过程中发生错误' };
    }
  }
}

module.exports = AuthService;