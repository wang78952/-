const UserModel = require('../models/UserModel');
const RoleModel = require('../models/RoleModel');
const TokenModel = require('../models/TokenModel');
const logger = require('../utils/logger');
const crypto = require('crypto');
const AppConfig = require('../config/app');

/**
 * 用户服务
 */
class UserService {
  constructor() {
    this.userModel = UserModel;
    this.roleModel = RoleModel;
    this.tokenModel = TokenModel;
  }

  /**
   * 创建用户
   */
  async createUser(userData) {
    try {
      // 验证密码策略
      const passwordValidation = this.userModel.validatePasswordPolicy(userData.password);
      if (!passwordValidation.valid) {
        throw new Error(passwordValidation.message);
      }

      // 检查用户名是否已存在
      const existingUser = await this.userModel.findByUsername(userData.username);
      if (existingUser) {
        throw new Error('Username is already taken');
      }

      // 检查邮箱是否已存在
      const existingEmail = await this.userModel.findByEmail(userData.email);
      if (existingEmail) {
        throw new Error('Email is already registered');
      }

      // 如果没有指定角色，分配默认角色
      if (!userData.roles || userData.roles.length === 0) {
        const defaultRole = await this.roleModel.Role.getDefaultRole();
        if (defaultRole) {
          userData.roles = [defaultRole._id];
        }
      }

      // 创建用户
      const user = await this.userModel.createUser(userData);

      return user;
    } catch (error) {
      logger.error('Failed to create user', { error: error.message, userData: { ...userData, password: '***' } });
      throw error;
    }
  }

  /**
   * 获取用户信息
   */
  async getUserById(userId, options = {}) {
    try {
      const user = await this.userModel.findById(userId);
      
      if (!user) {
        throw new Error('User not found');
      }

      // 检查是否需要包含额外信息
      if (options.includeRoles) {
        // 已经在UserModel.findById中populate了roles
      }

      if (options.includeTokens) {
        const activeTokens = await this.tokenModel.getModel().find({
          userId: userId,
          isActive: true,
          revokedAt: null,
          expiresAt: { $gt: Date.now() }
        }).select('tokenType expiresAt lastUsedAt usageCount');
        
        user.activeTokens = activeTokens;
      }

      return user;
    } catch (error) {
      logger.error('Failed to get user by ID', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 更新用户信息
   */
  async updateUser(userId, updateData) {
    try {
      // 检查用户是否存在
      const user = await this.userModel.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // 检查更新的用户名是否已被其他用户使用
      if (updateData.username && updateData.username !== user.username) {
        const existingUser = await this.userModel.findByUsername(updateData.username);
        if (existingUser && existingUser._id.toString() !== userId) {
          throw new Error('Username is already taken');
        }
      }

      // 检查更新的邮箱是否已被其他用户使用
      if (updateData.email && updateData.email !== user.email) {
        const existingEmail = await this.userModel.findByEmail(updateData.email);
        if (existingEmail && existingEmail._id.toString() !== userId) {
          throw new Error('Email is already registered');
        }
      }

      // 验证密码策略（如果更新密码）
      if (updateData.password) {
        const passwordValidation = this.userModel.validatePasswordPolicy(updateData.password);
        if (!passwordValidation.valid) {
          throw new Error(passwordValidation.message);
        }
      }

      // 验证角色ID（如果更新角色）
      if (updateData.roles) {
        for (const roleId of updateData.roles) {
          const role = await this.roleModel.findById(roleId);
          if (!role || !role.isActive) {
            throw new Error(`Invalid role ID: ${roleId}`);
          }
        }
      }

      // 更新用户
      const updatedUser = await this.userModel.updateUser(userId, updateData);

      return updatedUser;
    } catch (error) {
      logger.error('Failed to update user', { error: error.message, userId, updateData });
      throw error;
    }
  }

  /**
   * 删除用户（软删除）
   */
  async deleteUser(userId) {
    try {
      // 检查用户是否存在
      const user = await this.userModel.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // 删除用户（软删除）
      const result = await this.userModel.deleteUser(userId);

      // 吊销用户的所有令牌
      await this.tokenModel.revokeAllUserTokens(userId, 'User deleted');

      return result;
    } catch (error) {
      logger.error('Failed to delete user', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 批量创建用户
   */
  async batchCreateUsers(usersData) {
    try {
      const createdUsers = [];
      const errors = [];

      for (const userData of usersData) {
        try {
          const user = await this.createUser(userData);
          createdUsers.push(user);
        } catch (error) {
          errors.push({
            data: { ...userData, password: '***' },
            error: error.message
          });
        }
      }

      return {
        success: createdUsers.length,
        failed: errors.length,
        users: createdUsers,
        errors: errors
      };
    } catch (error) {
      logger.error('Failed to batch create users', { error: error.message, count: usersData.length });
      throw error;
    }
  }

  /**
   * 搜索用户
   */
  async searchUsers(query, options = {}) {
    try {
      // 构建搜索条件
      const searchQuery = {};

      // 按用户名搜索
      if (query.username) {
        searchQuery.username = { $regex: query.username, $options: 'i' };
      }

      // 按邮箱搜索
      if (query.email) {
        searchQuery.email = { $regex: query.email, $options: 'i' };
      }

      // 按全名搜索
      if (query.fullName) {
        searchQuery.fullName = { $regex: query.fullName, $options: 'i' };
      }

      // 按角色搜索
      if (query.roleId) {
        searchQuery.roles = query.roleId;
      }

      // 按状态搜索
      if (query.isActive !== undefined) {
        searchQuery.isActive = query.isActive;
      }

      // 按验证状态搜索
      if (query.isVerified !== undefined) {
        searchQuery.isVerified = query.isVerified;
      }

      // 按租户ID搜索
      if (query.tenantId) {
        searchQuery.tenantId = query.tenantId;
      }

      // 按创建时间范围搜索
      if (query.createdAtStart || query.createdAtEnd) {
        searchQuery.createdAt = {};
        if (query.createdAtStart) {
          searchQuery.createdAt.$gte = new Date(query.createdAtStart);
        }
        if (query.createdAtEnd) {
          searchQuery.createdAt.$lte = new Date(query.createdAtEnd);
        }
      }

      // 执行搜索
      const result = await this.userModel.findAll(searchQuery, options);

      return result;
    } catch (error) {
      logger.error('Failed to search users', { error: error.message, query });
      throw error;
    }
  }

  /**
   * 激活用户账户
   */
  async activateUser(userId) {
    try {
      const updatedUser = await this.userModel.updateUser(userId, {
        isActive: true,
        deletedAt: null
      });

      logger.info('User account activated', { userId, username: updatedUser.username });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to activate user account', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 停用用户账户
   */
  async deactivateUser(userId) {
    try {
      const updatedUser = await this.userModel.updateUser(userId, {
        isActive: false
      });

      // 吊销用户的所有令牌
      await this.tokenModel.revokeAllUserTokens(userId, 'User account deactivated');

      logger.info('User account deactivated', { userId, username: updatedUser.username });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to deactivate user account', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 解锁用户账户
   */
  async unlockUser(userId) {
    try {
      const updatedUser = await this.userModel.updateUser(userId, {
        loginAttempts: 0,
        lockUntil: null
      });

      logger.info('User account unlocked', { userId, username: updatedUser.username });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to unlock user account', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 重置用户密码
   */
  async resetUserPassword(userId, newPassword) {
    try {
      // 验证密码策略
      const passwordValidation = this.userModel.validatePasswordPolicy(newPassword);
      if (!passwordValidation.valid) {
        throw new Error(passwordValidation.message);
      }

      // 更新密码
      const updatedUser = await this.userModel.updateUser(userId, { password: newPassword });

      // 吊销用户的所有令牌，强制重新登录
      await this.tokenModel.revokeAllUserTokens(userId, 'Password reset by admin');

      logger.info('User password reset', { userId, username: updatedUser.username });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to reset user password', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 更新用户角色
   */
  async updateUserRoles(userId, roleIds) {
    try {
      // 验证所有角色ID
      for (const roleId of roleIds) {
        const role = await this.roleModel.findById(roleId);
        if (!role || !role.isActive) {
          throw new Error(`Invalid role ID: ${roleId}`);
        }
      }

      // 更新用户角色
      const updatedUser = await this.userModel.updateUser(userId, { roles: roleIds });

      // 吊销用户的所有令牌，确保权限立即生效
      await this.tokenModel.revokeAllUserTokens(userId, 'User roles updated');

      logger.info('User roles updated', { userId, roleCount: roleIds.length });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to update user roles', { error: error.message, userId, roleIds });
      throw error;
    }
  }

  /**
   * 添加用户角色
   */
  async addUserRole(userId, roleId) {
    try {
      // 验证角色ID
      const role = await this.roleModel.findById(roleId);
      if (!role || !role.isActive) {
        throw new Error(`Invalid role ID: ${roleId}`);
      }

      // 获取用户
      const user = await this.userModel.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // 检查角色是否已存在
      if (user.roles && user.roles.includes(roleId)) {
        throw new Error('User already has this role');
      }

      // 添加角色
      const currentRoles = user.roles || [];
      const updatedUser = await this.userModel.updateUser(userId, {
        roles: [...currentRoles, roleId]
      });

      // 吊销用户的所有令牌
      await this.tokenModel.revokeAllUserTokens(userId, 'User role added');

      logger.info('Role added to user', { userId, roleId, roleName: role.name });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to add role to user', { error: error.message, userId, roleId });
      throw error;
    }
  }

  /**
   * 移除用户角色
   */
  async removeUserRole(userId, roleId) {
    try {
      // 获取用户
      const user = await this.userModel.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // 检查角色是否存在
      if (!user.roles || !user.roles.includes(roleId)) {
        throw new Error('User does not have this role');
      }

      // 移除角色
      const updatedRoles = user.roles.filter(id => id.toString() !== roleId.toString());
      const updatedUser = await this.userModel.updateUser(userId, { roles: updatedRoles });

      // 吊销用户的所有令牌
      await this.tokenModel.revokeAllUserTokens(userId, 'User role removed');

      logger.info('Role removed from user', { userId, roleId });
      return updatedUser;
    } catch (error) {
      logger.error('Failed to remove role from user', { error: error.message, userId, roleId });
      throw error;
    }
  }

  /**
   * 生成用户访问令牌（用于管理员操作）
   */
  async generateUserAccessToken(userId, options = {}) {
    try {
      // 验证用户是否存在且有效
      const user = await this.userModel.findById(userId);
      if (!user || !user.isActive) {
        throw new Error('User not found or account inactive');
      }

      // 生成访问令牌
      const token = await this.tokenModel.createJwtToken(userId, 'access', options);

      logger.info('Access token generated for user', { userId, generatedBy: options.adminId || 'system' });
      return token;
    } catch (error) {
      logger.error('Failed to generate user access token', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 获取用户登录历史
   */
  async getUserLoginHistory(userId, options = {}) {
    try {
      const { limit = 50, offset = 0 } = options;
      
      const user = await this.userModel.getModel().findById(userId)
        .select('loginHistory');

      if (!user) {
        throw new Error('User not found');
      }

      // 获取分页数据
      const history = user.loginHistory || [];
      const total = history.length;
      const paginatedHistory = history.slice(offset, offset + limit);

      return {
        history: paginatedHistory,
        pagination: {
          total,
          limit,
          offset,
          pages: Math.ceil(total / limit)
        }
      };
    } catch (error) {
      logger.error('Failed to get user login history', { error: error.message, userId });
      throw error;
    }
  }

  /**
   * 获取用户统计信息
   */
  async getUserStats() {
    try {
      const stats = await this.userModel.getStats();
      
      // 获取最近24小时的新用户数
      const newUsersToday = await this.userModel.getModel().countDocuments({
        createdAt: { $gte: Date.now() - 24 * 60 * 60 * 1000 }
      });

      // 获取最近24小时的活跃用户数
      const activeUsersToday = await this.userModel.getModel().countDocuments({
        lastLogin: { $gte: Date.now() - 24 * 60 * 60 * 1000 }
      });

      stats.today = {
        new: newUsersToday,
        active: activeUsersToday
      };

      // 获取用户角色分布
      const users = await this.userModel.getModel().find({})
        .select('roles');

      const roleDistribution = {};
      users.forEach(user => {
        if (user.roles && user.roles.length) {
          user.roles.forEach(roleId => {
            const idStr = roleId.toString();
            roleDistribution[idStr] = (roleDistribution[idStr] || 0) + 1;
          });
        } else {
          roleDistribution['no-role'] = (roleDistribution['no-role'] || 0) + 1;
        }
      });

      stats.roleDistribution = roleDistribution;

      return stats;
    } catch (error) {
      logger.error('Failed to get user stats', { error: error.message });
      throw error;
    }
  }

  /**
   * 批量操作用户
   */
  async batchOperateUsers(userIds, operation, params = {}) {
    try {
      const results = {
        success: [],
        failed: []
      };

      for (const userId of userIds) {
        try {
          let result;
          
          switch (operation) {
            case 'activate':
              result = await this.activateUser(userId);
              break;
            case 'deactivate':
              result = await this.deactivateUser(userId);
              break;
            case 'delete':
              result = await this.deleteUser(userId);
              break;
            case 'resetPassword':
              result = await this.resetUserPassword(userId, params.newPassword);
              break;
            case 'unlock':
              result = await this.unlockUser(userId);
              break;
            case 'addRole':
              result = await this.addUserRole(userId, params.roleId);
              break;
            case 'removeRole':
              result = await this.removeUserRole(userId, params.roleId);
              break;
            default:
              throw new Error(`Invalid operation: ${operation}`);
          }

          results.success.push({
            userId,
            result
          });
        } catch (error) {
          results.failed.push({
            userId,
            error: error.message
          });
        }
      }

      logger.info('Batch user operation completed', {
        operation,
        total: userIds.length,
        success: results.success.length,
        failed: results.failed.length
      });

      return results;
    } catch (error) {
      logger.error('Failed to perform batch user operation', { error: error.message, operation, userIds });
      throw error;
    }
  }

  /**
   * 生成随机密码
   */
  generateRandomPassword(options = {}) {
    const { length = 12, includeUppercase = true, includeLowercase = true, includeNumbers = true, includeSymbols = true } = options;
    
    let chars = '';
    let password = '';
    
    if (includeUppercase) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeLowercase) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (includeNumbers) chars += '0123456789';
    if (includeSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    // 确保至少包含每种选中的字符类型
    if (includeUppercase) password += chars.charAt(Math.floor(Math.random() * 26));
    if (includeLowercase) password += chars.charAt(26 + Math.floor(Math.random() * 26));
    if (includeNumbers) password += chars.charAt(52 + Math.floor(Math.random() * 10));
    if (includeSymbols) password += chars.charAt(62 + Math.floor(Math.random() * 22));
    
    // 生成剩余的字符
    for (let i = password.length; i < length; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    // 打乱密码顺序
    return password.split('').sort(() => Math.random() - 0.5).join('');
  }
}

/**
 * 导出单例实例
 */
const userService = new UserService();

module.exports = userService;
module.exports.UserService = UserService;