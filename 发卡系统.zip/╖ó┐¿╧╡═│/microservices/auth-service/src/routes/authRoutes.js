const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/AuthController');
const { authenticateJWT, authorizeRole } = require('../middleware/authMiddleware');

// 认证路由
const authRoutes = express.Router();

// 公开路由（无需认证）
authRoutes.post('/login', AuthController.loginValidationRules(), AuthController.login);
authRoutes.post('/refresh-token', AuthController.refreshToken);
authRoutes.get('/health', AuthController.healthCheck);

// 需要认证的路由
authRoutes.post('/logout', authenticateJWT, AuthController.logout);
authRoutes.get('/me', authenticateJWT, AuthController.getCurrentUser);
authRoutes.post('/check-permission', authenticateJWT, AuthController.checkPermission);

// 管理员路由
authRoutes.get('/admin/dashboard', authenticateJWT, authorizeRole(['admin', 'superadmin']), (req, res) => {
  res.json({
    success: true,
    message: '管理员仪表盘',
    user: req.user
  });
});

// API版本控制
router.use('/api/v1/auth', authRoutes);

module.exports = router;