const express = require('express');
const router = express.Router();
const authController = require('../controllers/AuthController');
const userController = require('../controllers/UserController');
const roleController = require('../controllers/RoleController');
const authMiddleware = require('../middleware/auth');
const logger = require('../utils/logger');

class ApiRoutes {
  constructor() {
    this.logger = logger.getInstance();
    this.setupRoutes();
  }

  setupRoutes() {
    // 健康检查端点
    router.get('/health', this.healthCheck.bind(this));
    
    // 认证相关路由（无需认证）
    const authRoutes = express.Router();
    authRoutes.post('/login', authController.login.bind(authController));
    authRoutes.post('/logout', authController.logout.bind(authController));
    authRoutes.post('/refresh', authController.refreshToken.bind(authController));
    authRoutes.post('/register', authController.register.bind(authController));
    authRoutes.post('/verify-email', authController.verifyEmail.bind(authController));
    authRoutes.post('/resend-verification', authController.resendVerification.bind(authController));
    authRoutes.post('/forgot-password', authController.forgotPassword.bind(authController));
    authRoutes.post('/reset-password', authController.resetPassword.bind(authController));
    authRoutes.post('/verify-2fa', authController.verifyTwoFactor.bind(authController));
    authRoutes.post('/generate-api-key', authController.generateApiKey.bind(authController));
    authRoutes.post('/validate-api-key', authController.validateApiKey.bind(authController));
    router.use('/auth', authRoutes);

    // 需要认证的路由
    const protectedRoutes = express.Router();
    protectedRoutes.use(authMiddleware.authenticate());
    
    // 用户管理路由
    const userRoutes = express.Router();
    userRoutes.get('/', authMiddleware.authorize('user:read'), userController.getUserList.bind(userController));
    userRoutes.get('/:id', authMiddleware.authorize('user:read'), userController.getUserDetail.bind(userController));
    userRoutes.post('/', authMiddleware.authorize('user:create'), userController.createUser.bind(userController));
    userRoutes.put('/:id', authMiddleware.authorize('user:update'), userController.updateUser.bind(userController));
    userRoutes.delete('/:id', authMiddleware.authorize('user:delete'), userController.deleteUser.bind(userController));
    userRoutes.post('/batch-create', authMiddleware.authorize('user:create'), userController.batchCreateUsers.bind(userController));
    userRoutes.put('/:id/activate', authMiddleware.authorize('user:update'), userController.activateUser.bind(userController));
    userRoutes.put('/:id/deactivate', authMiddleware.authorize('user:update'), userController.deactivateUser.bind(userController));
    userRoutes.put('/:id/unlock', authMiddleware.authorize('user:update'), userController.unlockUser.bind(userController));
    userRoutes.post('/:id/reset-password', authMiddleware.authorize('user:update'), userController.resetPassword.bind(userController));
    userRoutes.put('/:id/roles', authMiddleware.authorize('user:update'), userController.updateUserRoles.bind(userController));
    userRoutes.get('/:id/login-history', authMiddleware.authorize('user:read'), userController.getLoginHistory.bind(userController));
    userRoutes.get('/stats/summary', authMiddleware.authorize('user:read'), userController.getUserStats.bind(userController));
    userRoutes.post('/batch-action', authMiddleware.authorize('user:update'), userController.batchAction.bind(userController));
    userRoutes.get('/generate/random-password', authMiddleware.authorize('user:read'), userController.generateRandomPassword.bind(userController));
    protectedRoutes.use('/users', userRoutes);

    // 角色管理路由
    const roleRoutes = express.Router();
    roleRoutes.get('/', authMiddleware.authorize('role:read'), roleController.getRoleList.bind(roleController));
    roleRoutes.get('/:id', authMiddleware.authorize('role:read'), roleController.getRoleDetail.bind(roleController));
    roleRoutes.post('/', authMiddleware.authorize('role:create'), roleController.createRole.bind(roleController));
    roleRoutes.put('/:id', authMiddleware.authorize('role:update'), roleController.updateRole.bind(roleController));
    roleRoutes.delete('/:id', authMiddleware.authorize('role:delete'), roleController.deleteRole.bind(roleController));
    roleRoutes.get('/:id/inherited-permissions', authMiddleware.authorize('role:read'), roleController.getInheritedPermissions.bind(roleController));
    roleRoutes.get('/:id/users', authMiddleware.authorize('role:read'), roleController.getRoleUsers.bind(roleController));
    roleRoutes.get('/:id/children', authMiddleware.authorize('role:read'), roleController.getChildRoles.bind(roleController));
    roleRoutes.get('/default/get', authMiddleware.authorize('role:read'), roleController.getDefaultRole.bind(roleController));
    roleRoutes.put('/default/set/:id', authMiddleware.authorize('role:update'), roleController.setDefaultRole.bind(roleController));
    roleRoutes.get('/permissions/tree', authMiddleware.authorize('role:read'), roleController.getPermissionTree.bind(roleController));
    protectedRoutes.use('/roles', roleRoutes);

    // 个人资料路由
    const profileRoutes = express.Router();
    profileRoutes.get('/me', authController.getCurrentUser.bind(authController));
    profileRoutes.put('/me', authController.updateProfile.bind(authController));
    profileRoutes.put('/me/password', authController.changePassword.bind(authController));
    profileRoutes.post('/me/2fa/enable', authController.enableTwoFactor.bind(authController));
    profileRoutes.post('/me/2fa/disable', authController.disableTwoFactor.bind(authController));
    protectedRoutes.use('/profile', profileRoutes);

    // 令牌管理路由
    const tokenRoutes = express.Router();
    tokenRoutes.get('/', authController.getActiveTokens.bind(authController));
    tokenRoutes.delete('/:id', authController.revokeToken.bind(authController));
    tokenRoutes.delete('/all/revoke', authController.revokeAllTokens.bind(authController));
    protectedRoutes.use('/tokens', tokenRoutes);

    // API密钥管理路由
    const apiKeyRoutes = express.Router();
    apiKeyRoutes.get('/', authController.getApiKeys.bind(authController));
    apiKeyRoutes.post('/', authController.generateNewApiKey.bind(authController));
    apiKeyRoutes.delete('/:id', authController.revokeApiKey.bind(authController));
    apiKeyRoutes.put('/:id/activate', authController.activateApiKey.bind(authController));
    apiKeyRoutes.put('/:id/deactivate', authController.deactivateApiKey.bind(authController));
    protectedRoutes.use('/api-keys', apiKeyRoutes);

    // 审计日志路由
    const auditRoutes = express.Router();
    auditRoutes.get('/', authMiddleware.authorize('audit:read'), authController.getAuditLogs.bind(authController));
    auditRoutes.get('/user/:userId', authMiddleware.authorize('audit:read'), authController.getUserAuditLogs.bind(authController));
    auditRoutes.get('/action/:action', authMiddleware.authorize('audit:read'), authController.getAuditLogsByAction.bind(authController));
    protectedRoutes.use('/audit-logs', auditRoutes);

    // 系统统计路由
    const statsRoutes = express.Router();
    statsRoutes.get('/login', authMiddleware.authorize('stats:read'), authController.getLoginStats.bind(authController));
    statsRoutes.get('/usage', authMiddleware.authorize('stats:read'), authController.getUsageStats.bind(authController));
    statsRoutes.get('/security', authMiddleware.authorize('stats:read'), authController.getSecurityStats.bind(authController));
    protectedRoutes.use('/stats', statsRoutes);

    // 安全设置路由
    const securityRoutes = express.Router();
    securityRoutes.put('/settings', authMiddleware.authorize('security:update'), authController.updateSecuritySettings.bind(authController));
    securityRoutes.get('/settings', authMiddleware.authorize('security:read'), authController.getSecuritySettings.bind(authController));
    securityRoutes.post('/check-password-strength', authController.checkPasswordStrength.bind(authController));
    protectedRoutes.use('/security', securityRoutes);

    // 黑名单管理路由
    const blacklistRoutes = express.Router();
    blacklistRoutes.get('/ips', authMiddleware.authorize('blacklist:read'), authController.getBlacklistedIps.bind(authController));
    blacklistRoutes.post('/ips', authMiddleware.authorize('blacklist:create'), authController.blacklistIp.bind(authController));
    blacklistRoutes.delete('/ips/:ip', authMiddleware.authorize('blacklist:delete'), authController.unblacklistIp.bind(authController));
    blacklistRoutes.get('/users', authMiddleware.authorize('blacklist:read'), authController.getBlacklistedUsers.bind(authController));
    blacklistRoutes.post('/users', authMiddleware.authorize('blacklist:create'), authController.blacklistUser.bind(authController));
    blacklistRoutes.delete('/users/:userId', authMiddleware.authorize('blacklist:delete'), authController.unblacklistUser.bind(authController));
    protectedRoutes.use('/blacklist', blacklistRoutes);

    // 访问控制路由
    const accessRoutes = express.Router();
    accessRoutes.get('/permissions', authMiddleware.authorize('permission:read'), authController.getPermissions.bind(authController));
    accessRoutes.post('/check-access', authMiddleware.authorize('permission:read'), authController.checkAccess.bind(authController));
    protectedRoutes.use('/access', accessRoutes);

    router.use('/', protectedRoutes);
  }

  /**
   * 健康检查处理函数
   */
  healthCheck(req, res) {
    try {
      this.logger.info('Health check requested');
      
      const healthStatus = {
        status: 'healthy',
        service: 'auth-service',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        nodeVersion: process.version
      };

      res.status(200).json({
        success: true,
        data: healthStatus
      });
    } catch (error) {
      this.logger.error('Health check failed', { error: error.message });
      res.status(500).json({
        success: false,
        message: 'Health check failed',
        error: error.message
      });
    }
  }

  /**
   * 获取路由实例
   */
  getRouter() {
    return router;
  }
}

// 导出路由实例
module.exports = new ApiRoutes().getRouter();