require('dotenv').config();

/**
 * 应用配置类
 * 管理所有环境变量和应用配置
 */
class AppConfig {
  constructor() {
    this.serverConfig = {
      port: process.env.SERVER_PORT || 3001,
      timeout: process.env.SERVER_TIMEOUT || 30000,
      environment: process.env.NODE_ENV || 'development'
    };
    
    this.databaseConfig = {
      uri: process.env.MONGO_URI || 'mongodb://localhost:27017/auth_service',
      user: process.env.MONGO_USER,
      password: process.env.MONGO_PASSWORD,
      dbName: process.env.MONGO_DB_NAME || 'auth_service',
      connectionTimeout: process.env.MONGO_CONNECTION_TIMEOUT || 30000,
      maxPoolSize: process.env.MONGO_MAX_POOL_SIZE || 10
    };
    
    this.redisConfig = {
      host: process.env.REDIS_HOST || 'localhost',
      port: process.env.REDIS_PORT || 6379,
      password: process.env.REDIS_PASSWORD,
      db: process.env.REDIS_DB || 0,
      connectionTimeout: process.env.REDIS_CONNECTION_TIMEOUT || 5000
    };
    
    this.jwtConfig = {
      secret: process.env.JWT_SECRET || 'your_jwt_secret_key_here',
      expiration: process.env.JWT_EXPIRATION || '24h',
      refreshExpiration: process.env.JWT_REFRESH_EXPIRATION || '7d',
      algorithm: process.env.JWT_ALGORITHM || 'HS256'
    };
    
    this.securityConfig = {
      corsOrigins: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : ['http://localhost:3000'],
      apiKeys: process.env.API_KEYS ? process.env.API_KEYS.split(',') : []
    };
    
    this.passwordConfig = {
      minLength: process.env.PASSWORD_MIN_LENGTH || 8,
      requireUppercase: process.env.PASSWORD_REQUIRE_UPPERCASE === 'true',
      requireLowercase: process.env.PASSWORD_REQUIRE_LOWERCASE === 'true',
      requireNumber: process.env.PASSWORD_REQUIRE_NUMBER === 'true',
      requireSpecial: process.env.PASSWORD_REQUIRE_SPECIAL === 'true'
    };
    
    this.loginConfig = {
      maxAttempts: process.env.MAX_LOGIN_ATTEMPTS || 5,
      lockoutDuration: process.env.LOCKOUT_DURATION || '30m'
    };
    
    this.captchaConfig = {
      enabled: process.env.CAPTCHA_ENABLED === 'true',
      expiration: process.env.CAPTCHA_EXPIRATION || '5m'
    };
    
    this.emailConfig = {
      service: process.env.EMAIL_SERVICE || 'smtp',
      host: process.env.EMAIL_HOST || 'smtp.example.com',
      port: process.env.EMAIL_PORT || 587,
      username: process.env.EMAIL_USERNAME || 'admin@example.com',
      password: process.env.EMAIL_PASSWORD,
      from: process.env.EMAIL_FROM || 'admin@example.com'
    };
    
    this.logConfig = {
      level: process.env.LOG_LEVEL || 'info',
      format: process.env.LOG_FORMAT || 'json',
      dir: process.env.LOG_DIR || './logs'
    };
    
    this.serviceDiscoveryConfig = {
      url: process.env.SERVICE_DISCOVERY_URL || 'http://localhost:3000',
      registrationEnabled: process.env.SERVICE_REGISTRATION_ENABLED === 'true'
    };
    
    this.cacheConfig = {
      ttl: process.env.CACHE_TTL || 300,
      maxItems: process.env.CACHE_MAX_ITEMS || 1000
    };
    
    this.rateLimitConfig = {
      windowMs: process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000,
      maxRequests: process.env.RATE_LIMIT_MAX_REQUESTS || 100,
      message: process.env.RATE_LIMIT_MESSAGE || 'Too many requests, please try again later.'
    };
    
    this.metricsConfig = {
      enabled: process.env.METRICS_ENABLED === 'true',
      port: process.env.METRICS_PORT || 9090
    };
    
    this.auditConfig = {
      enabled: process.env.AUDIT_LOG_ENABLED === 'true',
      retentionDays: process.env.AUDIT_LOG_RETENTION_DAYS || 30
    };
  }

  /**
   * 获取服务器端口
   */
  get SERVER_PORT() {
    return this.serverConfig.port;
  }

  /**
   * 获取服务器超时时间
   */
  get SERVER_TIMEOUT() {
    return this.serverConfig.timeout;
  }

  /**
   * 获取环境
   */
  get NODE_ENV() {
    return this.serverConfig.environment;
  }

  /**
   * 获取MongoDB URI
   */
  get MONGO_URI() {
    return this.databaseConfig.uri;
  }

  /**
   * 获取JWT密钥
   */
  get JWT_SECRET() {
    return this.jwtConfig.secret;
  }

  /**
   * 获取JWT过期时间
   */
  get JWT_EXPIRATION() {
    return this.jwtConfig.expiration;
  }

  /**
   * 获取JWT刷新过期时间
   */
  get JWT_REFRESH_EXPIRATION() {
    return this.jwtConfig.refreshExpiration;
  }

  /**
   * 获取CORS来源
   */
  get CORS_ORIGINS() {
    return this.securityConfig.corsOrigins.join(',');
  }

  /**
   * 获取API密钥列表
   */
  get API_KEYS() {
    return this.securityConfig.apiKeys;
  }

  /**
   * 获取最大登录尝试次数
   */
  get MAX_LOGIN_ATTEMPTS() {
    return this.loginConfig.maxAttempts;
  }

  /**
   * 获取锁定持续时间
   */
  get LOCKOUT_DURATION() {
    return this.loginConfig.lockoutDuration;
  }

  /**
   * 获取日志级别
   */
  get LOG_LEVEL() {
    return this.logConfig.level;
  }

  /**
   * 获取日志目录
   */
  get LOG_DIR() {
    return this.logConfig.dir;
  }

  /**
   * 获取服务发现URL
   */
  get SERVICE_DISCOVERY_URL() {
    return this.serviceDiscoveryConfig.url;
  }

  /**
   * 获取缓存TTL
   */
  get CACHE_TTL() {
    return this.cacheConfig.ttl;
  }

  /**
   * 检查是否为生产环境
   */
  get isProduction() {
    return this.serverConfig.environment === 'production';
  }

  /**
   * 检查是否为开发环境
   */
  get isDevelopment() {
    return this.serverConfig.environment === 'development';
  }

  /**
   * 验证必需的配置项
   */
  validateRequiredConfigs() {
    const missingConfigs = [];
    
    if (!this.jwtConfig.secret || this.jwtConfig.secret === 'your_jwt_secret_key_here') {
      missingConfigs.push('JWT_SECRET');
    }
    
    if (!this.databaseConfig.uri) {
      missingConfigs.push('MONGO_URI');
    }
    
    if (!this.serverConfig.port) {
      missingConfigs.push('SERVER_PORT');
    }
    
    if (missingConfigs.length > 0) {
      throw new Error(`Missing required configurations: ${missingConfigs.join(', ')}`);
    }
    
    return true;
  }

  /**
   * 获取配置摘要（用于日志记录，不包含敏感信息）
   */
  getConfigSummary() {
    return {
      serverPort: this.serverConfig.port,
      environment: this.serverConfig.environment,
      databaseHost: this.extractHostFromUri(this.databaseConfig.uri),
      redisHost: this.redisConfig.host,
      corsEnabled: this.securityConfig.corsOrigins.length > 0,
      captchaEnabled: this.captchaConfig.enabled,
      serviceDiscoveryEnabled: this.serviceDiscoveryConfig.registrationEnabled,
      metricsEnabled: this.metricsConfig.enabled,
      auditEnabled: this.auditConfig.enabled
    };
  }

  /**
   * 从URI中提取主机名
   */
  extractHostFromUri(uri) {
    try {
      if (uri.includes('mongodb://')) {
        // MongoDB URI格式: mongodb://user:pass@host:port/db
        const parts = uri.split('@');
        if (parts.length > 1) {
          const hostPart = parts[1].split('/')[0];
          return hostPart.split(':')[0];
        }
        return uri.split('mongodb://')[1].split('/')[0].split(':')[0];
      }
      return uri;
    } catch (error) {
      return 'unknown';
    }
  }
}

/**
 * 导出单例实例
 */
const config = new AppConfig();

// 验证必需的配置项
config.validateRequiredConfigs();

module.exports = config;
module.exports.AppConfig = AppConfig;