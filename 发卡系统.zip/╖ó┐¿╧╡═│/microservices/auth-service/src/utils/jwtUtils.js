const jwt = require('jsonwebtoken');
require('dotenv').config();

// 生成访问令牌
exports.generateAccessToken = (userId, role, username) => {
  const payload = {
    id: userId,
    role: role,
    username: username,
    type: 'access'
  };
  
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  });
};

// 生成刷新令牌
exports.generateRefreshToken = (userId) => {
  const payload = {
    id: userId,
    type: 'refresh'
  };
  
  return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET, {
    expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN
  });
};

// 验证访问令牌
exports.verifyAccessToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
};

// 验证刷新令牌
exports.verifyRefreshToken = (token) => {
  try {
    return jwt.verify(token, process.env.REFRESH_TOKEN_SECRET);
  } catch (error) {
    return null;
  }
};

// 从令牌中提取用户信息
exports.extractUserFromToken = (token, isRefresh = false) => {
  const payload = isRefresh 
    ? exports.verifyRefreshToken(token)
    : exports.verifyAccessToken(token);
    
  if (!payload) return null;
  
  return {
    id: payload.id,
    role: payload.role,
    username: payload.username
  };
};