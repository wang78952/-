const mongoose = require('mongoose');
const AppConfig = require('../config/app');
const logger = require('./logger');

/**
 * 数据库连接工具类
 */
class DatabaseConnector {
  constructor() {
    this.connection = null;
    this.isConnected = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.reconnectDelay = 2000;
  }

  /**
   * 连接到MongoDB数据库
   */
  async connect() {
    try {
      // 确保只连接一次
      if (this.isConnected) {
        logger.debug('Database already connected');
        return this.connection;
      }

      logger.info('Connecting to MongoDB...', {
        host: AppConfig.extractHostFromUri(AppConfig.MONGO_URI),
        dbName: AppConfig.databaseConfig.dbName
      });

      // MongoDB连接选项
      const options = {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        serverSelectionTimeoutMS: AppConfig.databaseConfig.connectionTimeout,
        socketTimeoutMS: 45000,
        maxPoolSize: AppConfig.databaseConfig.maxPoolSize,
        family: 4 // IPv4优先
      };

      // 创建连接
      this.connection = await mongoose.connect(AppConfig.MONGO_URI, options);
      this.isConnected = true;
      this.reconnectAttempts = 0;

      logger.info('MongoDB connected successfully');
      logger.debug('MongoDB connection details', {
        host: this.connection.connection.host,
        port: this.connection.connection.port,
        dbName: this.connection.connection.name,
        readyState: this.connection.connection.readyState
      });

      // 设置连接事件监听器
      this.setupEventListeners();

      return this.connection;
    } catch (error) {
      this.reconnectAttempts++;
      logger.error('Failed to connect to MongoDB', {
        error: error.message,
        attempt: this.reconnectAttempts,
        maxAttempts: this.maxReconnectAttempts
      });

      // 自动重连
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        logger.info(`Attempting to reconnect in ${this.reconnectDelay}ms...`);
        await new Promise(resolve => setTimeout(resolve, this.reconnectDelay));
        return this.connect();
      }

      throw new Error(`Failed to connect to MongoDB after ${this.maxReconnectAttempts} attempts: ${error.message}`);
    }
  }

  /**
   * 设置连接事件监听器
   */
  setupEventListeners() {
    if (!this.connection) {
      return;
    }

    const db = this.connection.connection;

    // 连接成功
    db.on('connected', () =
      {
        this.isConnected = true;
        logger.info('MongoDB connection established');
      });

    // 连接断开
    db.on('disconnected', () =
      {
        this.isConnected = false;
        logger.warn('MongoDB connection disconnected');
        this.attemptReconnect();
      });

    // 连接错误
    db.on('error', (error) =
      {
        this.isConnected = false;
        logger.error('MongoDB connection error', { error: error.message });
        this.attemptReconnect();
      });

    // 重新连接
    db.on('reconnected', () =
      {
        this.isConnected = true;
        this.reconnectAttempts = 0;
        logger.info('MongoDB reconnected successfully');
      });

    // 关闭
    db.on('close', () =
      {
        this.isConnected = false;
        logger.info('MongoDB connection closed');
      });
  }

  /**
   * 尝试重新连接
   */
  async attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      logger.info(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);
      
      try {
        await new Promise(resolve => setTimeout(resolve, this.reconnectDelay));
        await this.connect();
      } catch (error) {
        logger.error('Reconnection failed', { error: error.message });
      }
    } else {
      logger.error(`Maximum reconnection attempts (${this.maxReconnectAttempts}) reached`);
    }
  }

  /**
   * 断开数据库连接
   */
  async disconnect() {
    try {
      if (this.connection) {
        await this.connection.disconnect();
        this.isConnected = false;
        logger.info('MongoDB disconnected successfully');
      }
    } catch (error) {
      logger.error('Error disconnecting from MongoDB', { error: error.message });
      throw error;
    }
  }

  /**
   * 获取连接状态
   */
  getConnectionStatus() {
    if (!this.connection || !this.connection.connection) {
      return 'disconnected';
    }

    const readyState = this.connection.connection.readyState;
    
    switch (readyState) {
      case 0: return 'disconnected';
      case 1: return 'connected';
      case 2: return 'connecting';
      case 3: return 'disconnecting';
      default: return 'unknown';
    }
  }

  /**
   * 检查连接是否活跃
   */
  isConnectionActive() {
    return this.isConnected;
  }

  /**
   * 获取数据库连接实例
   */
  getConnection() {
    return this.connection;
  }

  /**
   * 获取数据库实例
   */
  getDb() {
    if (!this.connection) {
      throw new Error('Database not connected');
    }
    return this.connection.connection.db;
  }

  /**
   * 获取集合
   */
  getCollection(collectionName) {
    const db = this.getDb();
    return db.collection(collectionName);
  }

  /**
   * 执行数据库命令
   */
  async executeCommand(command) {
    const db = this.getDb();
    return await db.command(command);
  }

  /**
   * 获取数据库统计信息
   */
  async getStats() {
    const db = this.getDb();
    const stats = await db.stats();
    return stats;
  }

  /**
   * 列出所有集合
   */
  async listCollections() {
    const db = this.getDb();
    const collections = await db.listCollections().toArray();
    return collections.map(col =
 col.name);
  }

  /**
   * 获取集合统计信息
   */
  async getCollectionStats(collectionName) {
    const db = this.getDb();
    const stats = await db.collection(collectionName).stats();
    return stats;
  }

  /**
   * 检查数据库是否可用
   */
  async ping() {
    try {
      await this.executeCommand({ ping: 1 });
      return true;
    } catch (error) {
      logger.error('Database ping failed', { error: error.message });
      return false;
    }
  }

  /**
   * 获取MongoDB版本
   */
  async getMongoVersion() {
    const db = this.getDb();
    const adminDb = db.admin();
    const info = await adminDb.buildInfo();
    return info.version;
  }

  /**
   * 获取连接池信息
   */
  getConnectionPoolInfo() {
    if (!this.connection || !this.connection.connection) {
      return null;
    }

    const pool = this.connection.connection.client.s.options.poolSize;
    return {
      poolSize: pool,
      activeConnections: this.connection.connection.client.s.activeConnections,
      isConnected: this.isConnected
    };
  }
}

/**
 * 导出单例实例
 */
const database = new DatabaseConnector();

module.exports = database;
module.exports.DatabaseConnector = DatabaseConnector;