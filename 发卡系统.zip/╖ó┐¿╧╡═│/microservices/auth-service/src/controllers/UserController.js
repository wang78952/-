const userService = require('../services/UserService');
const logger = require('../utils/logger');
const AppConfig = require('../config/app');

/**
 * 用户控制器
 */
class UserController {
  /**
   * 获取用户列表
   */
  async getUsers(req, res) {
    try {
      // 解析查询参数
      const query = {
        username: req.query.username,
        email: req.query.email,
        fullName: req.query.fullName,
        roleId: req.query.roleId,
        isActive: req.query.isActive === 'true' ? true : (req.query.isActive === 'false' ? false : undefined),
        isVerified: req.query.isVerified === 'true' ? true : (req.query.isVerified === 'false' ? false : undefined),
        tenantId: req.query.tenantId,
        createdAtStart: req.query.createdAtStart,
        createdAtEnd: req.query.createdAtEnd
      };

      // 解析分页参数
      const options = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 20,
        sort: req.query.sort || 'createdAt',
        order: req.query.order === 'asc' ? 'asc' : 'desc',
        includeRoles: req.query.includeRoles === 'true',
        includeTokens: req.query.includeTokens === 'true'
      };

      // 调用服务获取用户列表
      const result = await userService.searchUsers(query, options);

      return res.json({
        success: true,
        data: {
          users: result.data,
          pagination: {
            current: options.page,
            limit: options.limit,
            total: result.total,
            pages: Math.ceil(result.total / options.limit)
          }
        }
      });
    } catch (error) {
      logger.error('Failed to get users list', {
        error: error.message,
        query: req.query,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'USER_GET_LIST_FAILED',
        details: 'Failed to retrieve users list'
      });
    }
  }

  /**
   * 获取用户详情
   */
  async getUserById(req, res) {
    try {
      const { userId } = req.params;
      
      const options = {
        includeRoles: req.query.includeRoles === 'true',
        includeTokens: req.query.includeTokens === 'true'
      };

      // 调用服务获取用户详情
      const user = await userService.getUserById(userId, options);

      return res.json({
        success: true,
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to get user by ID', {
        error: error.message,
        userId: req.params.userId,
        requestingUserId: req.user?.id
      });

      let statusCode = 500;
      let errorCode = 'USER_GET_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to retrieve user details'
      });
    }
  }

  /**
   * 创建用户
   */
  async createUser(req, res) {
    try {
      const userData = req.body;

      // 调用服务创建用户
      const user = await userService.createUser(userData);

      // 记录审计日志
      logger.audit('User created by admin', {
        userId: user.id,
        username: user.username,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.status(201).json({
        success: true,
        message: 'User created successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to create user', {
        error: error.message,
        userData: { ...req.body, password: '***' },
        adminId: req.user?.id
      });

      let statusCode = 400;
      let errorCode = 'USER_CREATE_FAILED';

      if (error.message === 'Username is already taken') {
        statusCode = 409;
        errorCode = 'USERNAME_TAKEN';
      } else if (error.message === 'Email is already registered') {
        statusCode = 409;
        errorCode = 'EMAIL_TAKEN';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to create user'
      });
    }
  }

  /**
   * 更新用户
   */
  async updateUser(req, res) {
    try {
      const { userId } = req.params;
      const updateData = req.body;

      // 调用服务更新用户
      const user = await userService.updateUser(userId, updateData);

      // 记录审计日志
      logger.audit('User updated by admin', {
        userId: userId,
        updatedFields: Object.keys(updateData),
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'User updated successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to update user', {
        error: error.message,
        userId: req.params.userId,
        updateData: updateData,
        adminId: req.user?.id
      });

      let statusCode = 400;
      let errorCode = 'USER_UPDATE_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      } else if (error.message === 'Username is already taken') {
        statusCode = 409;
        errorCode = 'USERNAME_TAKEN';
      } else if (error.message === 'Email is already registered') {
        statusCode = 409;
        errorCode = 'EMAIL_TAKEN';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to update user'
      });
    }
  }

  /**
   * 删除用户
   */
  async deleteUser(req, res) {
    try {
      const { userId } = req.params;

      // 不允许删除自己
      if (userId === req.user.id) {
        return res.status(400).json({
          error: 'Cannot delete your own account',
          code: 'USER_CANNOT_DELETE_SELF',
          details: 'You cannot delete your own account'
        });
      }

      // 调用服务删除用户
      const result = await userService.deleteUser(userId);

      // 记录审计日志
      logger.audit('User deleted by admin', {
        userId: userId,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'User deleted successfully',
        data: result
      });
    } catch (error) {
      logger.error('Failed to delete user', {
        error: error.message,
        userId: req.params.userId,
        adminId: req.user?.id
      });

      let statusCode = 500;
      let errorCode = 'USER_DELETE_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to delete user'
      });
    }
  }

  /**
   * 批量创建用户
   */
  async batchCreateUsers(req, res) {
    try {
      const usersData = req.body.users || [];

      if (!Array.isArray(usersData) || usersData.length === 0) {
        return res.status(400).json({
          error: 'Invalid users data',
          code: 'USER_BATCH_INVALID_DATA',
          details: 'Please provide a non-empty array of users'
        });
      }

      // 调用服务批量创建用户
      const result = await userService.batchCreateUsers(usersData);

      // 记录审计日志
      logger.audit('Batch user creation completed', {
        totalUsers: usersData.length,
        successCount: result.success,
        failedCount: result.failed,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.status(201).json({
        success: true,
        message: 'Batch user creation completed',
        data: {
          success: result.success,
          failed: result.failed,
          users: result.users,
          errors: result.errors
        }
      });
    } catch (error) {
      logger.error('Failed to batch create users', {
        error: error.message,
        userCount: req.body.users?.length,
        adminId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'USER_BATCH_CREATE_FAILED',
        details: 'Failed to create users in batch'
      });
    }
  }

  /**
   * 激活用户
   */
  async activateUser(req, res) {
    try {
      const { userId } = req.params;

      // 调用服务激活用户
      const user = await userService.activateUser(userId);

      // 记录审计日志
      logger.audit('User activated by admin', {
        userId: userId,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'User activated successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to activate user', {
        error: error.message,
        userId: req.params.userId,
        adminId: req.user?.id
      });

      let statusCode = 500;
      let errorCode = 'USER_ACTIVATE_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to activate user'
      });
    }
  }

  /**
   * 停用用户
   */
  async deactivateUser(req, res) {
    try {
      const { userId } = req.params;

      // 不允许停用自己
      if (userId === req.user.id) {
        return res.status(400).json({
          error: 'Cannot deactivate your own account',
          code: 'USER_CANNOT_DEACTIVATE_SELF',
          details: 'You cannot deactivate your own account'
        });
      }

      // 调用服务停用用户
      const user = await userService.deactivateUser(userId);

      // 记录审计日志
      logger.audit('User deactivated by admin', {
        userId: userId,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'User deactivated successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to deactivate user', {
        error: error.message,
        userId: req.params.userId,
        adminId: req.user?.id
      });

      let statusCode = 500;
      let errorCode = 'USER_DEACTIVATE_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to deactivate user'
      });
    }
  }

  /**
   * 解锁用户
   */
  async unlockUser(req, res) {
    try {
      const { userId } = req.params;

      // 调用服务解锁用户
      const user = await userService.unlockUser(userId);

      // 记录审计日志
      logger.audit('User unlocked by admin', {
        userId: userId,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'User unlocked successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to unlock user', {
        error: error.message,
        userId: req.params.userId,
        adminId: req.user?.id
      });

      let statusCode = 500;
      let errorCode = 'USER_UNLOCK_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to unlock user'
      });
    }
  }

  /**
   * 重置用户密码
   */
  async resetUserPassword(req, res) {
    try {
      const { userId } = req.params;
      const { newPassword } = req.body;

      if (!newPassword) {
        return res.status(400).json({
          error: 'New password is required',
          code: 'USER_MISSING_PASSWORD',
          details: 'Please provide a new password'
        });
      }

      // 调用服务重置密码
      const user = await userService.resetUserPassword(userId, newPassword);

      // 记录审计日志
      logger.audit('User password reset by admin', {
        userId: userId,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'Password reset successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to reset user password', {
        error: error.message,
        userId: req.params.userId,
        adminId: req.user?.id
      });

      let statusCode = 400;
      let errorCode = 'USER_RESET_PASSWORD_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to reset user password'
      });
    }
  }

  /**
   * 更新用户角色
   */
  async updateUserRoles(req, res) {
    try {
      const { userId } = req.params;
      const { roleIds } = req.body;

      if (!Array.isArray(roleIds)) {
        return res.status(400).json({
          error: 'Invalid role IDs',
          code: 'USER_INVALID_ROLES',
          details: 'Please provide an array of role IDs'
        });
      }

      // 调用服务更新用户角色
      const user = await userService.updateUserRoles(userId, roleIds);

      // 记录审计日志
      logger.audit('User roles updated by admin', {
        userId: userId,
        roleCount: roleIds.length,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'User roles updated successfully',
        data: {
          user: user
        }
      });
    } catch (error) {
      logger.error('Failed to update user roles', {
        error: error.message,
        userId: req.params.userId,
        roleIds: req.body.roleIds,
        adminId: req.user?.id
      });

      let statusCode = 400;
      let errorCode = 'USER_UPDATE_ROLES_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to update user roles'
      });
    }
  }

  /**
   * 获取用户登录历史
   */
  async getUserLoginHistory(req, res) {
    try {
      const { userId } = req.params;

      const options = {
        limit: parseInt(req.query.limit) || 50,
        offset: parseInt(req.query.offset) || 0
      };

      // 调用服务获取用户登录历史
      const result = await userService.getUserLoginHistory(userId, options);

      return res.json({
        success: true,
        data: {
          history: result.history,
          pagination: result.pagination
        }
      });
    } catch (error) {
      logger.error('Failed to get user login history', {
        error: error.message,
        userId: req.params.userId,
        adminId: req.user?.id
      });

      let statusCode = 500;
      let errorCode = 'USER_GET_LOGIN_HISTORY_FAILED';

      if (error.message === 'User not found') {
        statusCode = 404;
        errorCode = 'USER_NOT_FOUND';
      }

      return res.status(statusCode).json({
        error: error.message,
        code: errorCode,
        details: 'Failed to retrieve user login history'
      });
    }
  }

  /**
   * 获取用户统计信息
   */
  async getUserStats(req, res) {
    try {
      // 调用服务获取用户统计信息
      const stats = await userService.getUserStats();

      return res.json({
        success: true,
        data: {
          stats: stats
        }
      });
    } catch (error) {
      logger.error('Failed to get user stats', {
        error: error.message,
        adminId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'USER_GET_STATS_FAILED',
        details: 'Failed to retrieve user statistics'
      });
    }
  }

  /**
   * 批量操作用户
   */
  async batchOperateUsers(req, res) {
    try {
      const { operation, userIds, params = {} } = req.body;

      if (!operation) {
        return res.status(400).json({
          error: 'Operation is required',
          code: 'USER_BATCH_OP_INVALID',
          details: 'Please provide an operation type'
        });
      }

      if (!Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({
          error: 'Invalid user IDs',
          code: 'USER_BATCH_OP_INVALID_USERS',
          details: 'Please provide a non-empty array of user IDs'
        });
      }

      // 验证操作类型
      const validOperations = ['activate', 'deactivate', 'delete', 'resetPassword', 'unlock', 'addRole', 'removeRole'];
      if (!validOperations.includes(operation)) {
        return res.status(400).json({
          error: 'Invalid operation',
          code: 'USER_BATCH_OP_INVALID_TYPE',
          details: `Operation must be one of: ${validOperations.join(', ')}`
        });
      }

      // 调用服务批量操作用户
      const result = await userService.batchOperateUsers(userIds, operation, params);

      // 记录审计日志
      logger.audit('Batch user operation completed', {
        operation: operation,
        userCount: userIds.length,
        successCount: result.success.length,
        failedCount: result.failed.length,
        adminId: req.user.id,
        adminUsername: req.user.username
      });

      return res.json({
        success: true,
        message: 'Batch operation completed',
        data: {
          operation: operation,
          success: result.success,
          failed: result.failed
        }
      });
    } catch (error) {
      logger.error('Failed to perform batch user operation', {
        error: error.message,
        operation: req.body.operation,
        userCount: req.body.userIds?.length,
        adminId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'USER_BATCH_OP_FAILED',
        details: 'Failed to perform operation on users in batch'
      });
    }
  }

  /**
   * 生成随机密码
   */
  async generateRandomPassword(req, res) {
    try {
      const options = {
        length: parseInt(req.query.length) || 12,
        includeUppercase: req.query.includeUppercase !== 'false',
        includeLowercase: req.query.includeLowercase !== 'false',
        includeNumbers: req.query.includeNumbers !== 'false',
        includeSymbols: req.query.includeSymbols !== 'false'
      };

      // 调用服务生成随机密码
      const password = userService.generateRandomPassword(options);

      return res.json({
        success: true,
        data: {
          password: password,
          options: options
        }
      });
    } catch (error) {
      logger.error('Failed to generate random password', {
        error: error.message,
        adminId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'USER_GENERATE_PASSWORD_FAILED',
        details: 'Failed to generate random password'
      });
    }
  }
}

/**
 * 导出控制器实例
 */
module.exports = new UserController();