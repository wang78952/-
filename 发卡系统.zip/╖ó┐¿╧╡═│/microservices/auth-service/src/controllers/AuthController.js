const { body, validationResult } = require('express-validator');
const AuthService = require('../services/AuthService');
const { verifyRefreshToken } = require('../utils/jwtUtils');
const logger = require('../utils/logger');

class AuthController {
  // 登录验证规则
  static loginValidationRules() {
    return [
      body('username').trim().optional(),
      body('email').trim().isEmail().optional(),
      body('password').trim().isLength({ min: 6 }).withMessage('密码长度不能少于6位')
    ];
  }

  // 用户登录
  static async login(req, res) {
    try {
      // 验证输入
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: '输入验证失败',
          errors: errors.array()
        });
      }

      const { username, email, password } = req.body;

      // 检查必须提供用户名或邮箱
      if (!username && !email) {
        return res.status(400).json({
          success: false,
          message: '必须提供用户名或邮箱'
        });
      }

      // 调用服务层进行登录
      const result = await AuthService.login(username, email, password);
      
      if (!result.success) {
        return res.status(401).json(result);
      }

      return res.status(200).json(result);
    } catch (error) {
      logger.error(`登录控制器错误: ${error.message}`);
      return res.status(500).json({
        success: false,
        message: '登录过程中发生错误'
      });
    }
  }

  // 用户登出
  static async logout(req, res) {
    try {
      // 检查用户是否已认证
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: '未授权访问'
        });
      }

      const result = await AuthService.logout(req.user.id);
      
      if (!result.success) {
        return res.status(500).json(result);
      }

      return res.status(200).json(result);
    } catch (error) {
      logger.error(`登出控制器错误: ${error.message}`);
      return res.status(500).json({
        success: false,
        message: '登出过程中发生错误'
      });
    }
  }

  // 刷新令牌
  static async refreshToken(req, res) {
    try {
      const { refresh_token } = req.body;
      
      if (!refresh_token) {
        return res.status(400).json({
          success: false,
          message: '必须提供刷新令牌'
        });
      }

      // 验证刷新令牌
      const decoded = verifyRefreshToken(refresh_token);
      if (!decoded || decoded.type !== 'refresh') {
        return res.status(401).json({
          success: false,
          message: '无效的刷新令牌'
        });
      }

      // 调用服务层刷新令牌
      const result = await AuthService.refreshToken(decoded);
      
      if (!result.success) {
        return res.status(401).json(result);
      }

      return res.status(200).json(result);
    } catch (error) {
      logger.error(`刷新令牌控制器错误: ${error.message}`);
      return res.status(500).json({
        success: false,
        message: '刷新令牌过程中发生错误'
      });
    }
  }

  // 获取当前用户信息
  static async getCurrentUser(req, res) {
    try {
      // 从请求对象中获取用户信息（由中间件设置）
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: '未授权访问'
        });
      }

      return res.status(200).json({
        success: true,
        data: {
          user: req.user
        }
      });
    } catch (error) {
      logger.error(`获取当前用户控制器错误: ${error.message}`);
      return res.status(500).json({
        success: false,
        message: '获取用户信息过程中发生错误'
      });
    }
  }

  // 验证用户权限
  static async checkPermission(req, res) {
    try {
      const { required_role } = req.body;
      
      if (!required_role) {
        return res.status(400).json({
          success: false,
          message: '必须提供所需角色'
        });
      }

      const result = await AuthService.checkPermission(req.user.id, required_role);
      
      return res.status(200).json(result);
    } catch (error) {
      logger.error(`检查权限控制器错误: ${error.message}`);
      return res.status(500).json({
        success: false,
        message: '检查权限过程中发生错误'
      });
    }
  }

  // 健康检查
  static async healthCheck(req, res) {
    try {
      return res.status(200).json({
        success: true,
        message: 'Auth Service is running',
        timestamp: new Date().toISOString(),
        service: process.env.SERVICE_NAME || 'auth-service'
      });
    } catch (error) {
      logger.error(`健康检查错误: ${error.message}`);
      return res.status(500).json({
        success: false,
        message: '服务不可用'
      });
    }
  }
}

module.exports = AuthController;