const RoleModel = require('../models/RoleModel');
const logger = require('../utils/logger');
const AppConfig = require('../config/app');

/**
 * 角色控制器
 */
class RoleController {
  /**
   * 获取角色列表
   */
  async getRoles(req, res) {
    try {
      // 解析查询参数
      const query = {};
      
      if (req.query.name) {
        query.name = { $regex: req.query.name, $options: 'i' };
      }
      
      if (req.query.isActive !== undefined) {
        query.isActive = req.query.isActive === 'true';
      }
      
      if (req.query.isSystemRole !== undefined) {
        query.isSystemRole = req.query.isSystemRole === 'true';
      }
      
      if (req.query.parentRoleId) {
        query.parentRoleId = req.query.parentRoleId;
      }

      // 解析分页参数
      const options = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 20,
        sort: req.query.sort || 'name',
        order: req.query.order === 'desc' ? 'desc' : 'asc',
        populatePermissions: req.query.populatePermissions === 'true'
      };

      // 调用模型获取角色列表
      const result = await RoleModel.findAll(query, options);

      return res.json({
        success: true,
        data: {
          roles: result.data,
          pagination: {
            current: options.page,
            limit: options.limit,
            total: result.total,
            pages: Math.ceil(result.total / options.limit)
          }
        }
      });
    } catch (error) {
      logger.error('Failed to get roles list', {
        error: error.message,
        query: req.query,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_LIST_FAILED',
        details: 'Failed to retrieve roles list'
      });
    }
  }

  /**
   * 获取角色详情
   */
  async getRoleById(req, res) {
    try {
      const { roleId } = req.params;
      
      const role = await RoleModel.findById(roleId, {
        populatePermissions: req.query.populatePermissions === 'true',
        populateParentRole: req.query.populateParentRole === 'true',
        populateChildRoles: req.query.populateChildRoles === 'true'
      });

      if (!role) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      return res.json({
        success: true,
        data: {
          role: role
        }
      });
    } catch (error) {
      logger.error('Failed to get role by ID', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_FAILED',
        details: 'Failed to retrieve role details'
      });
    }
  }

  /**
   * 创建角色
   */
  async createRole(req, res) {
    try {
      const { name, description, permissions = [], parentRoleId, isSystemRole = false } = req.body;

      // 基本验证
      if (!name) {
        return res.status(400).json({
          error: 'Role name is required',
          code: 'ROLE_MISSING_NAME',
          details: 'Please provide a name for the role'
        });
      }

      // 检查名称是否已存在
      const existingRole = await RoleModel.findByName(name);
      if (existingRole) {
        return res.status(409).json({
          error: 'Role name already exists',
          code: 'ROLE_NAME_TAKEN',
          details: 'A role with this name already exists'
        });
      }

      // 如果指定了父角色，验证父角色是否存在
      if (parentRoleId) {
        const parentRole = await RoleModel.findById(parentRoleId);
        if (!parentRole || !parentRole.isActive) {
          return res.status(400).json({
            error: 'Invalid parent role',
            code: 'ROLE_INVALID_PARENT',
            details: 'Parent role does not exist or is inactive'
          });
        }
      }

      // 创建角色
      const role = await RoleModel.createRole({
        name,
        description,
        permissions,
        parentRoleId,
        isSystemRole,
        createdBy: req.user?.id
      });

      // 记录审计日志
      logger.audit('Role created', {
        roleId: role.id,
        roleName: role.name,
        createdBy: req.user?.id,
        createdByUsername: req.user?.username
      });

      return res.status(201).json({
        success: true,
        message: 'Role created successfully',
        data: {
          role: role
        }
      });
    } catch (error) {
      logger.error('Failed to create role', {
        error: error.message,
        roleData: req.body,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_CREATE_FAILED',
        details: 'Failed to create role'
      });
    }
  }

  /**
   * 更新角色
   */
  async updateRole(req, res) {
    try {
      const { roleId } = req.params;
      const { name, description, permissions, isActive, parentRoleId } = req.body;

      // 获取现有角色
      const existingRole = await RoleModel.findById(roleId);
      if (!existingRole) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      // 不允许修改系统角色的名称和活动状态
      if (existingRole.isSystemRole) {
        if (name && name !== existingRole.name) {
          return res.status(403).json({
            error: 'Cannot modify system role name',
            code: 'ROLE_CANNOT_MODIFY_SYSTEM',
            details: 'System role names cannot be modified'
          });
        }
        
        if (isActive !== undefined && isActive !== existingRole.isActive) {
          return res.status(403).json({
            error: 'Cannot modify system role active status',
            code: 'ROLE_CANNOT_MODIFY_SYSTEM',
            details: 'System role active status cannot be modified'
          });
        }
      }

      // 如果要更新名称，检查新名称是否已被其他角色使用
      if (name && name !== existingRole.name) {
        const nameExists = await RoleModel.findByName(name);
        if (nameExists && nameExists._id.toString() !== roleId) {
          return res.status(409).json({
            error: 'Role name already exists',
            code: 'ROLE_NAME_TAKEN',
            details: 'A role with this name already exists'
          });
        }
      }

      // 如果要更新父角色，验证新父角色
      if (parentRoleId !== undefined) {
        // 不允许循环引用
        if (parentRoleId === roleId) {
          return res.status(400).json({
            error: 'Invalid parent role',
            code: 'ROLE_INVALID_PARENT',
            details: 'A role cannot be its own parent'
          });
        }
        
        // 检查是否会形成循环依赖
        if (parentRoleId) {
          const hasCircularDependency = await RoleModel.checkCircularDependency(roleId, parentRoleId);
          if (hasCircularDependency) {
            return res.status(400).json({
              error: 'Circular dependency detected',
              code: 'ROLE_CIRCULAR_DEPENDENCY',
              details: 'The proposed parent role would create a circular dependency'
            });
          }
          
          // 验证父角色存在且有效
          const parentRole = await RoleModel.findById(parentRoleId);
          if (!parentRole || !parentRole.isActive) {
            return res.status(400).json({
              error: 'Invalid parent role',
              code: 'ROLE_INVALID_PARENT',
              details: 'Parent role does not exist or is inactive'
            });
          }
        }
      }

      // 准备更新数据
      const updateData = {};
      if (name !== undefined) updateData.name = name;
      if (description !== undefined) updateData.description = description;
      if (permissions !== undefined) updateData.permissions = permissions;
      if (isActive !== undefined && !existingRole.isSystemRole) updateData.isActive = isActive;
      if (parentRoleId !== undefined) updateData.parentRoleId = parentRoleId;
      updateData.updatedBy = req.user?.id;

      // 更新角色
      const updatedRole = await RoleModel.updateRole(roleId, updateData);

      // 记录审计日志
      logger.audit('Role updated', {
        roleId: roleId,
        roleName: updatedRole.name,
        updatedBy: req.user?.id,
        updatedByUsername: req.user?.username
      });

      return res.json({
        success: true,
        message: 'Role updated successfully',
        data: {
          role: updatedRole
        }
      });
    } catch (error) {
      logger.error('Failed to update role', {
        error: error.message,
        roleId: req.params.roleId,
        updateData: req.body,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_UPDATE_FAILED',
        details: 'Failed to update role'
      });
    }
  }

  /**
   * 删除角色
   */
  async deleteRole(req, res) {
    try {
      const { roleId } = req.params;

      // 获取现有角色
      const role = await RoleModel.findById(roleId);
      if (!role) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      // 不允许删除系统角色
      if (role.isSystemRole) {
        return res.status(403).json({
          error: 'Cannot delete system role',
          code: 'ROLE_CANNOT_DELETE_SYSTEM',
          details: 'System roles cannot be deleted'
        });
      }

      // 检查是否有子角色
      const childRolesCount = await RoleModel.countDocuments({ parentRoleId: roleId, isActive: true });
      if (childRolesCount > 0) {
        return res.status(400).json({
          error: 'Cannot delete role with child roles',
          code: 'ROLE_HAS_CHILDREN',
          details: 'This role has child roles and cannot be deleted. Please delete or reassign the child roles first.'
        });
      }

      // 检查是否有用户分配了此角色
      const usersWithRole = await RoleModel.findUsersWithRole(roleId);
      if (usersWithRole.length > 0) {
        return res.status(400).json({
          error: 'Cannot delete role with assigned users',
          code: 'ROLE_HAS_USERS',
          details: 'This role is assigned to users and cannot be deleted. Please remove the role from all users first.',
          assignedUsersCount: usersWithRole.length
        });
      }

      // 软删除角色
      await RoleModel.deleteRole(roleId);

      // 记录审计日志
      logger.audit('Role deleted', {
        roleId: roleId,
        roleName: role.name,
        deletedBy: req.user?.id,
        deletedByUsername: req.user?.username
      });

      return res.json({
        success: true,
        message: 'Role deleted successfully'
      });
    } catch (error) {
      logger.error('Failed to delete role', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_DELETE_FAILED',
        details: 'Failed to delete role'
      });
    }
  }

  /**
   * 获取角色的继承权限
   */
  async getRoleInheritedPermissions(req, res) {
    try {
      const { roleId } = req.params;

      // 验证角色存在
      const role = await RoleModel.findById(roleId);
      if (!role) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      // 获取继承的权限
      const inheritedPermissions = await RoleModel.getInheritedPermissions(roleId);

      return res.json({
        success: true,
        data: {
          roleId: roleId,
          roleName: role.name,
          inheritedPermissions: inheritedPermissions
        }
      });
    } catch (error) {
      logger.error('Failed to get inherited permissions', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_INHERITED_PERMISSIONS_FAILED',
        details: 'Failed to retrieve inherited permissions'
      });
    }
  }

  /**
   * 获取分配了指定角色的用户列表
   */
  async getRoleUsers(req, res) {
    try {
      const { roleId } = req.params;
      
      // 验证角色存在
      const role = await RoleModel.findById(roleId);
      if (!role) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      // 解析分页参数
      const options = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 20
      };

      // 获取用户列表
      const result = await RoleModel.findUsersWithRole(roleId, options);

      return res.json({
        success: true,
        data: {
          roleId: roleId,
          roleName: role.name,
          users: result.data,
          pagination: {
            current: options.page,
            limit: options.limit,
            total: result.total,
            pages: Math.ceil(result.total / options.limit)
          }
        }
      });
    } catch (error) {
      logger.error('Failed to get role users', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_USERS_FAILED',
        details: 'Failed to retrieve users with this role'
      });
    }
  }

  /**
   * 获取角色的子角色列表
   */
  async getRoleChildRoles(req, res) {
    try {
      const { roleId } = req.params;
      
      // 验证角色存在
      const role = await RoleModel.findById(roleId);
      if (!role) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      // 解析分页参数
      const options = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 20
      };

      // 获取子角色列表
      const result = await RoleModel.findChildRoles(roleId, options);

      return res.json({
        success: true,
        data: {
          parentRoleId: roleId,
          parentRoleName: role.name,
          childRoles: result.data,
          pagination: {
            current: options.page,
            limit: options.limit,
            total: result.total,
            pages: Math.ceil(result.total / options.limit)
          }
        }
      });
    } catch (error) {
      logger.error('Failed to get role child roles', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_CHILD_ROLES_FAILED',
        details: 'Failed to retrieve child roles'
      });
    }
  }

  /**
   * 获取默认角色
   */
  async getDefaultRole(req, res) {
    try {
      // 获取默认角色
      const defaultRole = await RoleModel.getDefaultRole();
      
      if (!defaultRole) {
        return res.status(404).json({
          error: 'Default role not found',
          code: 'ROLE_DEFAULT_NOT_FOUND',
          details: 'No default role has been set up'
        });
      }

      return res.json({
        success: true,
        data: {
          defaultRole: defaultRole
        }
      });
    } catch (error) {
      logger.error('Failed to get default role', {
        error: error.message,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_DEFAULT_FAILED',
        details: 'Failed to retrieve default role'
      });
    }
  }

  /**
   * 设置默认角色
   */
  async setDefaultRole(req, res) {
    try {
      const { roleId } = req.params;
      
      // 验证角色存在
      const role = await RoleModel.findById(roleId);
      if (!role || !role.isActive) {
        return res.status(404).json({
          error: 'Role not found or inactive',
          code: 'ROLE_NOT_FOUND',
          details: 'The specified role does not exist or is inactive'
        });
      }

      // 设置默认角色
      await RoleModel.setDefaultRole(roleId);

      // 记录审计日志
      logger.audit('Default role set', {
        roleId: roleId,
        roleName: role.name,
        setBy: req.user?.id,
        setByUsername: req.user?.username
      });

      return res.json({
        success: true,
        message: 'Default role set successfully',
        data: {
          defaultRole: role
        }
      });
    } catch (error) {
      logger.error('Failed to set default role', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_SET_DEFAULT_FAILED',
        details: 'Failed to set default role'
      });
    }
  }

  /**
   * 获取角色权限树
   */
  async getRolePermissionTree(req, res) {
    try {
      const { roleId } = req.params;
      
      // 验证角色存在
      const role = await RoleModel.findById(roleId);
      if (!role) {
        return res.status(404).json({
          error: 'Role not found',
          code: 'ROLE_NOT_FOUND',
          details: 'Role with the specified ID does not exist'
        });
      }

      // 获取权限树
      const permissionTree = await RoleModel.getPermissionTree(roleId);

      return res.json({
        success: true,
        data: {
          roleId: roleId,
          roleName: role.name,
          permissionTree: permissionTree
        }
      });
    } catch (error) {
      logger.error('Failed to get role permission tree', {
        error: error.message,
        roleId: req.params.roleId,
        userId: req.user?.id
      });

      return res.status(500).json({
        error: error.message,
        code: 'ROLE_GET_PERMISSION_TREE_FAILED',
        details: 'Failed to retrieve role permission tree'
      });
    }
  }
}

/**
 * 导出控制器实例
 */
module.exports = new RoleController();