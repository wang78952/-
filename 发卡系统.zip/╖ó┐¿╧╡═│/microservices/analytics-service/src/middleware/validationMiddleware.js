/**
 * 数据分析模块 - 验证中间件
 * 提供请求参数验证功能
 */

const Joi = require('joi');
const logger = require('../utils/logger');

class ValidationMiddleware {
  /**
   * 通用验证方法
   * @param {Object} schema - Joi验证模式
   * @param {String} source - 验证源（'body', 'params', 'query'）
   * @returns {Function} Express中间件函数
   */
  validate(schema, source = 'body') {
    return (req, res, next) => {
      try {
        const { error, value } = schema.validate(req[source], {
          abortEarly: false,
          allowUnknown: true,
          stripUnknown: true
        });

        if (error) {
          const errors = error.details.map(detail => ({
            field: detail.path.join('.'),
            message: detail.message,
            type: detail.type
          }));

          logger.warn('请求参数验证失败', { 
            endpoint: req.originalUrl, 
            method: req.method,
            errors 
          });

          return res.status(400).json({
            success: false,
            message: '请求参数验证失败',
            errors
          });
        }

        // 替换原始请求数据为验证后的数据
        req[source] = value;
        next();
      } catch (err) {
        logger.error('验证中间件异常', { 
          error: err.message, 
          endpoint: req.originalUrl 
        });
        next(err);
      }
    };
  }

  /**
   * 验证路径参数
   * @param {Object} schema - Joi验证模式
   * @returns {Function} Express中间件函数
   */
  validateParams(schema) {
    return this.validate(schema, 'params');
  }

  /**
   * 验证查询参数
   * @param {Object} schema - Joi验证模式
   * @returns {Function} Express中间件函数
   */
  validateQuery(schema) {
    return this.validate(schema, 'query');
  }

  /**
   * 验证请求体
   * @param {Object} schema - Joi验证模式
   * @returns {Function} Express中间件函数
   */
  validateBody(schema) {
    return this.validate(schema, 'body');
  }

  /**
   * 复合验证 - 同时验证多个部分
   * @param {Object} schemas - 包含不同部分验证模式的对象
   * @returns {Function} Express中间件函数
   */
  validateAll(schemas) {
    return (req, res, next) => {
      const allErrors = [];
      
      try {
        // 验证每个部分
        Object.entries(schemas).forEach(([source, schema]) => {
          if (req[source]) {
            const { error, value } = schema.validate(req[source], {
              abortEarly: false,
              allowUnknown: true,
              stripUnknown: true
            });

            if (error) {
              const errors = error.details.map(detail => ({
                source,
                field: detail.path.join('.'),
                message: detail.message,
                type: detail.type
              }));
              allErrors.push(...errors);
            } else {
              // 替换原始请求数据为验证后的数据
              req[source] = value;
            }
          }
        });

        if (allErrors.length > 0) {
          logger.warn('请求参数多部分验证失败', { 
            endpoint: req.originalUrl, 
            method: req.method,
            errors: allErrors 
          });

          return res.status(400).json({
            success: false,
            message: '请求参数验证失败',
            errors: allErrors
          });
        }

        next();
      } catch (err) {
        logger.error('复合验证中间件异常', { 
          error: err.message, 
          endpoint: req.originalUrl 
        });
        next(err);
      }
    };
  }

  /**
   * 可选验证 - 如果数据存在则验证
   * @param {Object} schema - Joi验证模式
   * @param {String} source - 验证源
   * @returns {Function} Express中间件函数
   */
  validateIfExists(schema, source = 'body') {
    return (req, res, next) => {
      // 检查源数据是否存在且不为空对象
      const hasData = req[source] && Object.keys(req[source]).length > 0;
      
      if (!hasData) {
        return next();
      }
      
      // 存在数据则进行验证
      return this.validate(schema, source)(req, res, next);
    };
  }

  /**
   * 验证数组项
   * @param {Object} itemSchema - 数组项的验证模式
   * @param {String} fieldName - 数组字段名
   * @param {String} source - 验证源
   * @returns {Function} Express中间件函数
   */
  validateArrayItems(itemSchema, fieldName, source = 'body') {
    const arraySchema = Joi.object({
      [fieldName]: Joi.array().items(itemSchema).required()
    });
    
    return this.validate(arraySchema, source);
  }

  /**
   * 验证日期范围
   * @param {String} startField - 开始日期字段名
   * @param {String} endField - 结束日期字段名
   * @param {String} source - 验证源
   * @returns {Function} Express中间件函数
   */
  validateDateRange(startField, endField, source = 'query') {
    const dateRangeSchema = Joi.object({
      [startField]: Joi.date().iso().required(),
      [endField]: Joi.date().iso().min(Joi.ref(startField)).required()
    });
    
    return this.validate(dateRangeSchema, source);
  }

  /**
   * 验证分页参数
   * @returns {Function} Express中间件函数
   */
  validatePagination() {
    const paginationSchema = Joi.object({
      page: Joi.number().integer().min(1).default(1),
      limit: Joi.number().integer().min(1).max(100).default(20),
      sortBy: Joi.string().default('createdAt'),
      sortOrder: Joi.string().valid('asc', 'desc').default('desc')
    });
    
    return this.validateQuery(paginationSchema);
  }
}

module.exports = new ValidationMiddleware();