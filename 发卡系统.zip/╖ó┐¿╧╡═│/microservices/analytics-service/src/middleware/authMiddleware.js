/**
 * 数据分析模块 - 认证中间件
 * 提供用户认证和授权功能
 */

const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

class AuthMiddleware {
  /**
   * JWT认证中间件
   * @returns {Function} Express中间件函数
   */
  authenticate() {
    return async (req, res, next) => {
      try {
        // 从请求头获取Authorization
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
          logger.warn('缺少有效的认证令牌', { endpoint: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: '缺少有效的认证令牌'
          });
        }

        const token = authHeader.split(' ')[1];
        
        // 检查令牌是否在黑名单中
        if (await this.isTokenBlacklisted(token)) {
          logger.warn('认证令牌已被吊销', { endpoint: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: '认证令牌已被吊销'
          });
        }

        // 验证JWT令牌
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          
          // 将用户信息附加到请求对象
          req.user = {
            id: decoded.userId,
            username: decoded.username,
            role: decoded.role,
            permissions: decoded.permissions || []
          };
          
          // 设置令牌过期时间检查
          const now = Math.floor(Date.now() / 1000);
          if (decoded.exp && decoded.exp < now + 3600) { // 1小时内过期
            res.setHeader('X-Token-Expiry-Warning', 'Token will expire soon');
          }
          
          logger.info('用户认证成功', { userId: decoded.userId, endpoint: req.originalUrl });
          next();
        } catch (tokenError) {
          logger.warn('认证令牌无效', { 
            endpoint: req.originalUrl, 
            error: tokenError.message 
          });
          
          if (tokenError.name === 'TokenExpiredError') {
            return res.status(401).json({
              success: false,
              message: '认证令牌已过期'
            });
          }
          
          return res.status(401).json({
            success: false,
            message: '无效的认证令牌'
          });
        }
      } catch (error) {
        logger.error('认证中间件异常', { 
          error: error.message, 
          endpoint: req.originalUrl 
        });
        next(error);
      }
    };
  }

  /**
   * 角色授权中间件
   * @param {Array<String>} allowedRoles - 允许的角色列表
   * @returns {Function} Express中间件函数
   */
  authorize(allowedRoles) {
    return (req, res, next) => {
      try {
        if (!req.user) {
          logger.warn('授权失败：用户未认证', { endpoint: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: '用户未认证'
          });
        }

        // 检查用户角色是否在允许列表中
        if (!allowedRoles.includes(req.user.role)) {
          logger.warn('授权失败：权限不足', { 
            userId: req.user.id, 
            role: req.user.role, 
            requiredRoles: allowedRoles,
            endpoint: req.originalUrl 
          });
          return res.status(403).json({
            success: false,
            message: '权限不足，无法访问此资源'
          });
        }

        logger.info('用户授权成功', { 
          userId: req.user.id, 
          role: req.user.role,
          endpoint: req.originalUrl 
        });
        next();
      } catch (error) {
        logger.error('授权中间件异常', { 
          error: error.message, 
          endpoint: req.originalUrl 
        });
        next(error);
      }
    };
  }

  /**
   * 权限检查中间件
   * @param {Array<String>} requiredPermissions - 所需权限列表
   * @returns {Function} Express中间件函数
   */
  checkPermission(requiredPermissions) {
    return (req, res, next) => {
      try {
        if (!req.user || !req.user.permissions) {
          logger.warn('权限检查失败：用户未认证或没有权限信息', { endpoint: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: '用户未认证'
          });
        }

        // 检查用户是否拥有所有所需权限
        const hasPermission = requiredPermissions.every(permission => 
          req.user.permissions.includes(permission)
        );

        if (!hasPermission) {
          logger.warn('权限检查失败：缺少必要权限', { 
            userId: req.user.id, 
            permissions: req.user.permissions, 
            requiredPermissions,
            endpoint: req.originalUrl 
          });
          return res.status(403).json({
            success: false,
            message: '缺少必要的操作权限'
          });
        }

        logger.info('权限检查通过', { 
          userId: req.user.id,
          endpoint: req.originalUrl 
        });
        next();
      } catch (error) {
        logger.error('权限检查中间件异常', { 
          error: error.message, 
          endpoint: req.originalUrl 
        });
        next(error);
      }
    };
  }

  /**
   * 检查令牌是否在黑名单中
   * @param {String} token - JWT令牌
   * @returns {Promise<Boolean>} 是否在黑名单中
   */
  async isTokenBlacklisted(token) {
    try {
      // 这里可以实现令牌黑名单检查逻辑
      // 例如：从Redis或数据库中检查令牌是否被吊销
      // 目前返回false表示简单实现，所有令牌都不在黑名单中
      return false;
    } catch (error) {
      logger.error('令牌黑名单检查失败', { error: error.message });
      return false; // 默认安全策略：检查失败时不阻止访问
    }
  }

  /**
   * 创建JWT令牌
   * @param {Object} userData - 用户数据
   * @returns {String} JWT令牌
   */
  createToken(userData) {
    const payload = {
      userId: userData.id,
      username: userData.username,
      role: userData.role,
      permissions: userData.permissions || [],
      issuedAt: Math.floor(Date.now() / 1000)
    };

    return jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '24h'
    });
  }

  /**
   * 可选认证中间件 - 不强制要求认证，但如果提供了令牌则进行验证
   * @returns {Function} Express中间件函数
   */
  authenticateOptional() {
    return async (req, res, next) => {
      try {
        const authHeader = req.headers.authorization;
        
        if (authHeader && authHeader.startsWith('Bearer ')) {
          const token = authHeader.split(' ')[1];
          
          try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            
            req.user = {
              id: decoded.userId,
              username: decoded.username,
              role: decoded.role,
              permissions: decoded.permissions || []
            };
          } catch (tokenError) {
            // 可选认证模式下，令牌验证失败不会阻止请求
            logger.debug('可选认证令牌验证失败', { error: tokenError.message });
          }
        }
        
        next();
      } catch (error) {
        logger.error('可选认证中间件异常', { error: error.message });
        next(); // 即使出错也继续处理请求
      }
    };
  }

  /**
   * API密钥认证中间件
   * @returns {Function} Express中间件函数
   */
  authenticateApiKey() {
    return (req, res, next) => {
      try {
        // 从请求头或查询参数获取API密钥
        const apiKey = req.headers['x-api-key'] || req.query.apiKey;
        
        if (!apiKey) {
          logger.warn('缺少API密钥', { endpoint: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: '缺少API密钥'
          });
        }

        // 验证API密钥（这里应该与存储的有效密钥进行比较）
        // 简单实现：从环境变量中获取允许的API密钥
        const validApiKeys = (process.env.VALID_API_KEYS || '').split(',');
        
        if (!validApiKeys.includes(apiKey)) {
          logger.warn('无效的API密钥', { endpoint: req.originalUrl });
          return res.status(401).json({
            success: false,
            message: '无效的API密钥'
          });
        }

        logger.info('API密钥认证成功', { endpoint: req.originalUrl });
        next();
      } catch (error) {
        logger.error('API密钥认证中间件异常', { error: error.message });
        next(error);
      }
    };
  }

  /**
   * 管理员角色检查中间件
   * @returns {Function} Express中间件函数
   */
  isAdmin() {
    return this.authorize(['admin', 'superadmin']);
  }

  /**
   * 审计员角色检查中间件
   * @returns {Function} Express中间件函数
   */
  isAuditor() {
    return this.authorize(['admin', 'superadmin', 'auditor']);
  }

  /**
   * 用户身份验证 - 确保请求的用户是资源所有者或管理员
   * @param {String} userIdParam - URL参数中的用户ID字段名
   * @returns {Function} Express中间件函数
   */
  authorizeResourceOwner(userIdParam = 'userId') {
    return (req, res, next) => {
      try {
        if (!req.user) {
          return res.status(401).json({
            success: false,
            message: '用户未认证'
          });
        }

        const requestedUserId = req.params[userIdParam] || req.body[userIdParam];
        
        // 检查是否是管理员或者资源所有者
        if (req.user.role === 'admin' || req.user.role === 'superadmin' || 
            req.user.id === requestedUserId) {
          return next();
        }

        logger.warn('资源所有者验证失败', { 
          userId: req.user.id, 
          requestedUserId,
          endpoint: req.originalUrl 
        });
        
        return res.status(403).json({
          success: false,
          message: '无权访问其他用户的资源'
        });
      } catch (error) {
        logger.error('资源所有者验证中间件异常', { error: error.message });
        next(error);
      }
    };
  }
}

module.exports = new AuthMiddleware();