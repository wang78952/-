/**
 * 数据分析模块 - 错误处理中间件
 * 处理API错误和异常情况
 */

const logger = require('../utils/logger');

class ErrorMiddleware {
  /**
   * 全局错误处理中间件
   * @param {Error} err - 错误对象
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  globalErrorHandler(err, req, res, next) {
    // 设置默认错误状态和消息
    let statusCode = 500;
    let errorMessage = '服务器内部错误';
    let errorDetails = null;
    
    // 根据错误类型设置不同的响应
    if (err.name === 'ValidationError') {
      statusCode = 400;
      errorMessage = '数据验证失败';
      errorDetails = this.formatValidationErrors(err);
    } else if (err.name === 'CastError') {
      statusCode = 400;
      errorMessage = '无效的资源ID格式';
      errorDetails = { field: err.path, value: err.value };
    } else if (err.name === 'MongoError' && err.code === 11000) {
      statusCode = 409;
      errorMessage = '资源已存在';
      errorDetails = this.formatMongoDuplicateError(err);
    } else if (err.statusCode) {
      // 自定义错误对象
      statusCode = err.statusCode;
      errorMessage = err.message || errorMessage;
      errorDetails = err.details || null;
    }

    // 记录错误日志
    logger.error('请求处理错误', {
      endpoint: req.originalUrl,
      method: req.method,
      statusCode,
      error: errorMessage,
      errorDetails,
      stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
      userId: req.user?.id
    });

    // 构建响应对象
    const response = {
      success: false,
      message: errorMessage,
      errorCode: statusCode
    };

    // 在开发环境中包含详细错误信息
    if (process.env.NODE_ENV === 'development') {
      response.details = errorDetails || {
        errorName: err.name,
        originalMessage: err.message
      };
    }

    // 发送错误响应
    res.status(statusCode).json(response);
  }

  /**
   * 404错误处理中间件
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  notFoundHandler(req, res, next) {
    const error = new Error(`未找到路径: ${req.originalUrl}`);
    error.statusCode = 404;
    
    logger.warn('请求了不存在的资源', {
      endpoint: req.originalUrl,
      method: req.method,
      ip: req.ip
    });
    
    next(error);
  }

  /**
   * 请求超时中间件
   * @param {Number} timeoutMs - 超时时间（毫秒）
   * @returns {Function} Express中间件函数
   */
  timeoutHandler(timeoutMs = 30000) {
    return (req, res, next) => {
      const timeoutId = setTimeout(() => {
        const error = new Error('请求处理超时');
        error.statusCode = 504;
        error.details = { endpoint: req.originalUrl, timeoutMs };
        
        logger.error('请求处理超时', {
          endpoint: req.originalUrl,
          method: req.method,
          timeoutMs
        });
        
        next(error);
      }, timeoutMs);

      // 清除超时定时器
      const clearTimeoutOnFinish = () => {
        clearTimeout(timeoutId);
        res.removeListener('finish', clearTimeoutOnFinish);
        res.removeListener('error', clearTimeoutOnFinish);
        res.removeListener('close', clearTimeoutOnFinish);
      };

      res.on('finish', clearTimeoutOnFinish);
      res.on('error', clearTimeoutOnFinish);
      res.on('close', clearTimeoutOnFinish);

      next();
    };
  }

  /**
   * 安全头部中间件
   * @returns {Function} Express中间件函数
   */
  securityHeaders() {
    return (req, res, next) => {
      // 设置安全相关的HTTP头部
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('X-XSS-Protection', '1; mode=block');
      res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
      res.setHeader('Permissions-Policy', 'geolocation=(), camera=(), microphone=()');
      
      // 为JSON响应设置内容类型
      if (req.accepts('application/json')) {
        res.setHeader('Content-Type', 'application/json');
      }
      
      next();
    };
  }

  /**
   * API速率限制错误处理中间件
   * @param {Error} err - 错误对象
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  rateLimitErrorHandler(err, req, res, next) {
    if (err.statusCode === 429) {
      logger.warn('API速率限制触发', {
        endpoint: req.originalUrl,
        method: req.method,
        ip: req.ip
      });
      
      return res.status(429).json({
        success: false,
        message: '请求频率过高，请稍后再试',
        errorCode: 429,
        retryAfter: err.retryAfter || 60
      });
    }
    
    next(err);
  }

  /**
   * 数据库连接错误处理
   * @returns {Function} Express中间件函数
   */
  databaseErrorHandler() {
    return (err, req, res, next) => {
      if (err.name === 'MongoNetworkError' || 
          err.message.includes('database connection') ||
          err.message.includes('MongoDB')) {
        
        logger.error('数据库连接错误', {
          error: err.message,
          endpoint: req.originalUrl
        });
        
        return res.status(503).json({
          success: false,
          message: '数据库服务暂时不可用',
          errorCode: 503
        });
      }
      
      next(err);
    };
  }

  /**
   * 身份验证错误处理
   * @returns {Function} Express中间件函数
   */
  authErrorHandler() {
    return (err, req, res, next) => {
      if (err.name === 'JsonWebTokenError' || 
          err.name === 'TokenExpiredError' ||
          err.name === 'AuthenticationError') {
        
        logger.warn('身份验证错误', {
          error: err.name,
          endpoint: req.originalUrl,
          ip: req.ip
        });
        
        return res.status(401).json({
          success: false,
          message: '身份验证失败，请重新登录',
          errorCode: 401
        });
      }
      
      next(err);
    };
  }

  /**
   * 授权错误处理
   * @returns {Function} Express中间件函数
   */
  authorizationErrorHandler() {
    return (err, req, res, next) => {
      if (err.name === 'AuthorizationError' || 
          err.message.includes('权限') ||
          err.message.includes('Authorization')) {
        
        logger.warn('授权错误', {
          error: err.message,
          endpoint: req.originalUrl,
          userId: req.user?.id
        });
        
        return res.status(403).json({
          success: false,
          message: '权限不足，无法执行此操作',
          errorCode: 403
        });
      }
      
      next(err);
    };
  }

  /**
   * 格式化验证错误
   * @param {Error} err - 验证错误对象
   * @returns {Array} 格式化后的错误数组
   */
  formatValidationErrors(err) {
    if (err.details) {
      return err.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message,
        type: detail.type
      }));
    }
    
    const errors = [];
    for (const field in err.errors) {
      if (err.errors.hasOwnProperty(field)) {
        errors.push({
          field,
          message: err.errors[field].message,
          value: err.errors[field].value
        });
      }
    }
    return errors;
  }

  /**
   * 格式化MongoDB重复键错误
   * @param {Error} err - MongoDB错误对象
   * @returns {Object} 格式化后的错误信息
   */
  formatMongoDuplicateError(err) {
    // 提取重复字段信息
    const duplicateField = Object.keys(err.keyValue)[0];
    return {
      field: duplicateField,
      value: err.keyValue[duplicateField],
      message: `字段 '${duplicateField}' 的值 '${err.keyValue[duplicateField]}' 已存在`
    };
  }

  /**
   * 处理未捕获的异常
   */
  handleUncaughtExceptions() {
    process.on('uncaughtException', (error) => {
      logger.error('未捕获的异常', {
        error: error.message,
        stack: error.stack
      });
      
      // 在生产环境中，记录错误后退出进程
      if (process.env.NODE_ENV === 'production') {
        // 给日志系统一些时间写入日志
        setTimeout(() => {
          process.exit(1);
        }, 1000);
      }
    });
  }

  /**
   * 处理未处理的Promise拒绝
   */
  handleUnhandledRejections() {
    process.on('unhandledRejection', (reason, promise) => {
      logger.error('未处理的Promise拒绝', {
        reason: reason ? (reason.message || String(reason)) : 'Unknown',
        stack: reason ? (reason.stack || 'No stack trace') : 'No stack trace'
      });
    });
  }

  /**
   * 资源限制错误处理
   * @returns {Function} Express中间件函数
   */
  resourceLimitErrorHandler() {
    return (err, req, res, next) => {
      if (err.code === 'ERR_HTTP_HEADERS_SENT' ||
          err.code === 'ECONNRESET' ||
          err.code === 'EPIPE') {
        
        logger.warn('资源限制错误', {
          error: err.code,
          endpoint: req.originalUrl
        });
        
        // 这些错误通常不需要响应，因为连接已经关闭
        return;
      }
      
      next(err);
    };
  }

  /**
   * 配置所有错误处理中间件
   * @param {Object} app - Express应用实例
   */
  configureErrorHandlers(app) {
    // 注册错误处理中间件（顺序很重要）
    app.use(this.databaseErrorHandler());
    app.use(this.authErrorHandler());
    app.use(this.authorizationErrorHandler());
    app.use(this.rateLimitErrorHandler());
    app.use(this.resourceLimitErrorHandler());
    
    // 404错误处理
    app.use(this.notFoundHandler());
    
    // 全局错误处理
    app.use(this.globalErrorHandler());
    
    // 注册进程级错误处理
    this.handleUncaughtExceptions();
    this.handleUnhandledRejections();
    
    logger.info('错误处理中间件已配置');
  }
}

module.exports = new ErrorMiddleware();