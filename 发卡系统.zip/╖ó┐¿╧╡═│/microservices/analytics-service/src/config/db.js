/**
 * 数据分析模块 - 数据库配置
 * 负责MongoDB数据库连接和管理
 */

const mongoose = require('mongoose');
const logger = require('../utils/logger');

class DatabaseConfig {
  constructor() {
    this.connection = null;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = parseInt(process.env.DB_MAX_RECONNECT_ATTEMPTS) || 5;
    this.reconnectInterval = parseInt(process.env.DB_RECONNECT_INTERVAL) || 2000;
    this.connected = false;
  }

  /**
   * 获取数据库连接字符串
   * @returns {string} MongoDB连接字符串
   */
  getConnectionString() {
    const { 
      DB_HOST = 'localhost', 
      DB_PORT = 27017, 
      DB_NAME = 'analytics_db', 
      DB_USER, 
      DB_PASSWORD,
      DB_AUTH_SOURCE = 'admin',
      DB_REPLICA_SET
    } = process.env;

    let connectionString = `mongodb://`;
    
    // 如果提供了用户名和密码，添加认证信息
    if (DB_USER && DB_PASSWORD) {
      connectionString += `${encodeURIComponent(DB_USER)}:${encodeURIComponent(DB_PASSWORD)}@`;
    }
    
    // 添加主机和端口
    connectionString += `${DB_HOST}:${DB_PORT}/${DB_NAME}`;
    
    // 添加查询参数
    const params = [];
    
    if (DB_USER && DB_PASSWORD) {
      params.push(`authSource=${DB_AUTH_SOURCE}`);
    }
    
    if (DB_REPLICA_SET) {
      params.push(`replicaSet=${DB_REPLICA_SET}`);
    }
    
    // 添加连接选项
    params.push('connectTimeoutMS=10000');
    params.push('socketTimeoutMS=45000');
    params.push('serverSelectionTimeoutMS=5000');
    params.push('useNewUrlParser=true');
    params.push('useUnifiedTopology=true');
    
    if (params.length > 0) {
      connectionString += `?${params.join('&')}`;
    }
    
    return connectionString;
  }

  /**
   * 获取Mongoose连接选项
   * @returns {Object} Mongoose连接选项
   */
  getConnectionOptions() {
    return {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      autoIndex: process.env.DB_AUTO_INDEX !== 'false',
      maxPoolSize: parseInt(process.env.DB_MAX_POOL_SIZE) || 10,
      minPoolSize: parseInt(process.env.DB_MIN_POOL_SIZE) || 1,
      serverSelectionTimeoutMS: parseInt(process.env.DB_SERVER_SELECTION_TIMEOUT) || 5000,
      socketTimeoutMS: parseInt(process.env.DB_SOCKET_TIMEOUT) || 45000,
      family: 4, // 使用IPv4
      // 为高可用性配置
      keepAlive: true,
      keepAliveInitialDelay: 300000,
    };
  }

  /**
   * 初始化数据库连接
   * @returns {Promise<void>}
   */
  async initialize() {
    try {
      const connectionString = this.getConnectionString();
      const options = this.getConnectionOptions();

      logger.info('正在连接到MongoDB数据库', {
        host: process.env.DB_HOST,
        database: process.env.DB_NAME
      });

      // 设置连接事件监听器
      this.setupConnectionListeners();

      // 建立连接
      this.connection = await mongoose.connect(connectionString, options);
      
      this.connected = true;
      this.reconnectAttempts = 0;
      
      logger.info('成功连接到MongoDB数据库', {
        host: process.env.DB_HOST,
        database: process.env.DB_NAME,
        connectionId: this.connection.connection.id
      });
      
      // 启用索引构建完成事件监听
      this.setupIndexListeners();
      
    } catch (error) {
      logger.error('数据库连接失败', {
        error: error.message,
        attempt: this.reconnectAttempts + 1
      });
      
      this.handleConnectionError(error);
    }
  }

  /**
   * 设置连接事件监听器
   */
  setupConnectionListeners() {
    const connection = mongoose.connection;
    
    // 连接成功
    connection.on('connected', () => {
      logger.info('MongoDB连接已建立');
      this.connected = true;
      this.reconnectAttempts = 0;
    });

    // 连接断开
    connection.on('disconnected', () => {
      logger.warn('MongoDB连接已断开');
      this.connected = false;
      this.attemptReconnect();
    });

    // 连接错误
    connection.on('error', (error) => {
      logger.error('MongoDB连接错误', {
        error: error.message
      });
      this.handleConnectionError(error);
    });

    // 重新连接
    connection.on('reconnected', () => {
      logger.info('MongoDB重新连接成功');
      this.connected = true;
      this.reconnectAttempts = 0;
    });

    // 正在连接
    connection.on('connecting', () => {
      logger.info('MongoDB正在连接...');
    });

    // 连接已关闭
    connection.on('close', () => {
      logger.info('MongoDB连接已关闭');
      this.connected = false;
    });
  }

  /**
   * 设置索引构建事件监听器
   */
  setupIndexListeners() {
    // 索引构建开始
    mongoose.connection.on('index', (data) => {
      logger.debug('MongoDB索引构建开始', {
        collection: data.collection,
        indexName: data.name
      });
    });
  }

  /**
   * 处理连接错误
   * @param {Error} error - 连接错误对象
   */
  handleConnectionError(error) {
    // 根据错误类型处理
    if (error.name === 'MongoNetworkError') {
      logger.warn('网络连接错误，尝试重新连接');
      this.attemptReconnect();
    } else if (error.name === 'MongoError' && error.code === 18) {
      logger.error('数据库认证失败', {
        error: error.message
      });
      // 认证错误通常不会通过重新连接解决
      process.exit(1);
    } else {
      logger.error('未知的数据库错误', {
        error: error.message,
        name: error.name
      });
      this.attemptReconnect();
    }
  }

  /**
   * 尝试重新连接
   */
  async attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      logger.error(`达到最大重连尝试次数 (${this.maxReconnectAttempts})`);
      process.exit(1);
      return;
    }

    this.reconnectAttempts++;
    const delay = this.reconnectInterval * Math.pow(1.5, this.reconnectAttempts - 1); // 指数退避
    
    logger.info(`计划在 ${delay}ms 后进行第 ${this.reconnectAttempts} 次重连`);
    
    setTimeout(async () => {
      try {
        logger.info(`正在进行第 ${this.reconnectAttempts} 次重连尝试`);
        await this.initialize();
      } catch (error) {
        logger.error(`重连尝试 ${this.reconnectAttempts} 失败`);
      }
    }, delay);
  }

  /**
   * 关闭数据库连接
   * @returns {Promise<void>}
   */
  async close() {
    try {
      if (this.connection) {
        logger.info('正在关闭MongoDB连接...');
        await this.connection.disconnect();
        logger.info('MongoDB连接已关闭');
        this.connection = null;
        this.connected = false;
      }
    } catch (error) {
      logger.error('关闭数据库连接失败', {
        error: error.message
      });
    }
  }

  /**
   * 检查数据库连接状态
   * @returns {boolean} 连接状态
   */
  isConnected() {
    return this.connected;
  }

  /**
   * 执行数据库健康检查
   * @returns {Promise<Object>} 健康检查结果
   */
  async healthCheck() {
    try {
      // 执行简单命令检查连接
      const result = await this.connection.db.admin().ping();
      
      return {
        status: 'healthy',
        connected: true,
        responseTime: this.getResponseTime(),
        serverInfo: await this.getServerInfo()
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        connected: false,
        error: error.message
      };
    }
  }

  /**
   * 获取数据库响应时间
   * @returns {number} 响应时间（毫秒）
   */
  getResponseTime() {
    const startTime = Date.now();
    return Date.now() - startTime; // 简单实现，实际项目中可以使用更精确的方法
  }

  /**
   * 获取服务器信息
   * @returns {Promise<Object>} 服务器信息
   */
  async getServerInfo() {
    try {
      return await this.connection.db.admin().serverStatus();
    } catch (error) {
      logger.error('获取服务器信息失败', {
        error: error.message
      });
      return null;
    }
  }

  /**
   * 获取集合统计信息
   * @param {string} collectionName - 集合名称
   * @returns {Promise<Object>} 集合统计信息
   */
  async getCollectionStats(collectionName) {
    try {
      return await this.connection.db.command({
        collStats: collectionName
      });
    } catch (error) {
      logger.error('获取集合统计信息失败', {
        collection: collectionName,
        error: error.message
      });
      return null;
    }
  }

  /**
   * 启用数据库查询调试
   */
  enableQueryDebugging() {
    mongoose.set('debug', (collectionName, method, query, doc) => {
      logger.debug('MongoDB查询', {
        collection: collectionName,
        method: method,
        query: query,
        document: doc
      });
    });
  }

  /**
   * 禁用数据库查询调试
   */
  disableQueryDebugging() {
    mongoose.set('debug', false);
  }

  /**
   * 设置查询超时
   * @param {number} timeout - 超时时间（毫秒）
   */
  setQueryTimeout(timeout) {
    mongoose.set('queryTimeout', timeout);
  }

  /**
   * 处理应用程序关闭信号
   */
  handleAppShutdown() {
    process.on('SIGINT', async () => {
      logger.info('接收到终止信号，正在关闭数据库连接...');
      await this.close();
      process.exit(0);
    });

    process.on('SIGTERM', async () => {
      logger.info('接收到终止信号，正在关闭数据库连接...');
      await this.close();
      process.exit(0);
    });
  }

  /**
   * 获取数据库连接实例
   * @returns {Object} Mongoose连接实例
   */
  getConnection() {
    return this.connection;
  }

  /**
   * 监控慢查询
   * @param {number} threshold - 慢查询阈值（毫秒）
   */
  monitorSlowQueries(threshold = 100) {
    const startTime = Date.now();
    
    // 这里可以添加更复杂的慢查询监控逻辑
    // 例如使用MongoDB的profiler或自定义查询包装器
    logger.info('慢查询监控已启用', {
      threshold: threshold
    });
  }

  /**
   * 创建数据库索引（如果不存在）
   * @returns {Promise<void>}
   */
  async ensureIndexes() {
    try {
      logger.info('正在检查和创建索引...');
      
      // 让Mongoose自动为模型创建索引
      // 注意：在生产环境中，可能需要更细粒度的索引控制
      
      logger.info('索引检查和创建完成');
    } catch (error) {
      logger.error('索引创建失败', {
        error: error.message
      });
    }
  }
}

// 创建单例实例
const dbConfig = new DatabaseConfig();

// 导出数据库配置实例和初始化函数
module.exports = {
  dbConfig,
  initializeDB: () => dbConfig.initialize(),
  closeDB: () => dbConfig.close(),
  isDBConnected: () => dbConfig.isConnected()
};