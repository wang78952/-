/**
 * 数据分析模块 - 应用程序配置
 * 负责管理服务的一般配置和环境变量
 */

const dotenv = require('dotenv');
const logger = require('../utils/logger');
const path = require('path');

class AppConfig {
  constructor() {
    // 加载环境变量
    this.loadEnvVariables();
    
    // 初始化配置
    this.config = this.initializeConfig();
  }

  /**
   * 加载环境变量
   */
  loadEnvVariables() {
    // 首先尝试加载.env文件
    const envPath = path.resolve(process.cwd(), '.env');
    const envResult = dotenv.config({ path: envPath });
    
    if (envResult.error) {
      logger.warn('未找到.env文件，将使用环境变量或默认值', {
        error: envResult.error.message
      });
      
      // 尝试加载.env.example作为备选
      const exampleEnvPath = path.resolve(process.cwd(), '.env.example');
      const exampleEnvResult = dotenv.config({ path: exampleEnvPath, override: false });
      
      if (exampleEnvResult.error) {
        logger.debug('未找到.env.example文件');
      }
    } else {
      logger.info('成功加载.env文件');
    }
  }

  /**
   * 初始化配置
   * @returns {Object} 应用程序配置对象
   */
  initializeConfig() {
    return {
      // 服务器配置
      server: {
        port: this.getEnvNumber('PORT', 3002),
        host: this.getEnvString('HOST', '0.0.0.0'),
        gracefulShutdownTimeout: this.getEnvNumber('GRACEFUL_SHUTDOWN_TIMEOUT', 10000),
        enableCompression: this.getEnvBoolean('ENABLE_COMPRESSION', true),
        enableCors: this.getEnvBoolean('ENABLE_CORS', true),
        maxRequestSize: this.getEnvString('MAX_REQUEST_SIZE', '10mb')
      },
      
      // 应用程序配置
      app: {
        name: this.getEnvString('APP_NAME', 'analytics-service'),
        version: this.getEnvString('APP_VERSION', '1.0.0'),
        environment: this.getEnvString('NODE_ENV', 'development'),
        debug: this.getEnvBoolean('DEBUG', false),
        logLevel: this.getEnvString('LOG_LEVEL', 'info')
      },
      
      // 数据库配置
      database: {
        host: this.getEnvString('DB_HOST', 'localhost'),
        port: this.getEnvNumber('DB_PORT', 27017),
        name: this.getEnvString('DB_NAME', 'analytics_db'),
        user: this.getEnvString('DB_USER', ''),
        password: this.getEnvString('DB_PASSWORD', ''),
        authSource: this.getEnvString('DB_AUTH_SOURCE', 'admin'),
        replicaSet: this.getEnvString('DB_REPLICA_SET', ''),
        autoIndex: this.getEnvBoolean('DB_AUTO_INDEX', true),
        maxPoolSize: this.getEnvNumber('DB_MAX_POOL_SIZE', 10),
        minPoolSize: this.getEnvNumber('DB_MIN_POOL_SIZE', 1),
        enableQueryDebugging: this.getEnvBoolean('ENABLE_QUERY_DEBUGGING', false)
      },
      
      // Redis配置
      redis: {
        host: this.getEnvString('REDIS_HOST', 'localhost'),
        port: this.getEnvNumber('REDIS_PORT', 6379),
        password: this.getEnvString('REDIS_PASSWORD', ''),
        db: this.getEnvNumber('REDIS_DB', 0),
        enable: this.getEnvBoolean('ENABLE_REDIS', true),
        ttl: this.getEnvNumber('REDIS_TTL', 3600)
      },
      
      // JWT配置
      jwt: {
        secret: this.getEnvString('JWT_SECRET', 'your-secret-key'),
        expiresIn: this.getEnvString('JWT_EXPIRES_IN', '24h'),
        algorithm: this.getEnvString('JWT_ALGORITHM', 'HS256'),
        issuer: this.getEnvString('JWT_ISSUER', 'analytics-service'),
        audience: this.getEnvString('JWT_AUDIENCE', 'analytics-service')
      },
      
      // API配置
      api: {
        prefix: this.getEnvString('API_PREFIX', '/api/v1'),
        rateLimitWindowMs: this.getEnvNumber('RATE_LIMIT_WINDOW_MS', 60000),
        rateLimitMax: this.getEnvNumber('RATE_LIMIT_MAX', 100),
        enableRequestLogging: this.getEnvBoolean('ENABLE_REQUEST_LOGGING', true),
        enableResponseTimeLogging: this.getEnvBoolean('ENABLE_RESPONSE_TIME_LOGGING', true)
      },
      
      // 分析配置
      analytics: {
        logRetentionDays: this.getEnvNumber('LOG_RETENTION_DAYS', 90),
        statisticUpdateInterval: this.getEnvNumber('STATISTIC_UPDATE_INTERVAL', 3600000), // 1小时
        trendDataResolution: this.getEnvString('TREND_DATA_RESOLUTION', 'hourly'), // hourly, daily, weekly
        alertThresholdHigh: this.getEnvNumber('ALERT_THRESHOLD_HIGH', 90),
        alertThresholdMedium: this.getEnvNumber('ALERT_THRESHOLD_MEDIUM', 75),
        enableAnomalyDetection: this.getEnvBoolean('ENABLE_ANOMALY_DETECTION', true),
        batchProcessingSize: this.getEnvNumber('BATCH_PROCESSING_SIZE', 1000)
      },
      
      // 安全配置
      security: {
        enableHelmet: this.getEnvBoolean('ENABLE_HELMET', true),
        enableRateLimiting: this.getEnvBoolean('ENABLE_RATE_LIMITING', true),
        allowedOrigins: this.parseEnvArray('ALLOWED_ORIGINS', ['*']),
        csrfProtection: this.getEnvBoolean('CSRF_PROTECTION', true),
        sessionSecret: this.getEnvString('SESSION_SECRET', 'session-secret-key'),
        cookieSecure: this.getEnvBoolean('COOKIE_SECURE', false), // 在生产环境中应该为true
        cookieHttpOnly: this.getEnvBoolean('COOKIE_HTTP_ONLY', true)
      },
      
      // 监控配置
      monitoring: {
        enablePrometheus: this.getEnvBoolean('ENABLE_PROMETHEUS', true),
        metricsPath: this.getEnvString('METRICS_PATH', '/metrics'),
        enableHealthCheck: this.getEnvBoolean('ENABLE_HEALTH_CHECK', true),
        healthCheckPath: this.getEnvString('HEALTH_CHECK_PATH', '/health'),
        checkDependencies: this.getEnvBoolean('CHECK_DEPENDENCIES', true)
      },
      
      // 外部服务配置
      externalServices: {
        cardServiceUrl: this.getEnvString('CARD_SERVICE_URL', 'http://localhost:3000/api/v1'),
        userServiceUrl: this.getEnvString('USER_SERVICE_URL', 'http://localhost:3001/api/v1'),
        notificationServiceUrl: this.getEnvString('NOTIFICATION_SERVICE_URL', 'http://localhost:3003/api/v1'),
        httpClientTimeout: this.getEnvNumber('HTTP_CLIENT_TIMEOUT', 5000),
        retryAttempts: this.getEnvNumber('HTTP_RETRY_ATTEMPTS', 3),
        retryDelay: this.getEnvNumber('HTTP_RETRY_DELAY', 1000)
      },
      
      // 文件配置
      files: {
        uploadDir: this.getEnvString('UPLOAD_DIR', './uploads'),
        allowedExtensions: this.parseEnvArray('ALLOWED_EXTENSIONS', ['.jpg', '.jpeg', '.png', '.pdf', '.csv']),
        maxFileSize: this.getEnvNumber('MAX_FILE_SIZE', 5242880), // 5MB
        enableFileCleanup: this.getEnvBoolean('ENABLE_FILE_CLEANUP', true),
        fileCleanupInterval: this.getEnvNumber('FILE_CLEANUP_INTERVAL', 86400000) // 24小时
      }
    };
  }

  /**
   * 获取环境变量字符串值
   * @param {string} key - 环境变量键
   * @param {string} defaultValue - 默认值
   * @returns {string} 环境变量值或默认值
   */
  getEnvString(key, defaultValue = '') {
    const value = process.env[key];
    return value !== undefined ? String(value) : defaultValue;
  }

  /**
   * 获取环境变量数字值
   * @param {string} key - 环境变量键
   * @param {number} defaultValue - 默认值
   * @returns {number} 环境变量值或默认值
   */
  getEnvNumber(key, defaultValue = 0) {
    const value = process.env[key];
    if (value === undefined) {
      return defaultValue;
    }
    
    const numValue = Number(value);
    return isNaN(numValue) ? defaultValue : numValue;
  }

  /**
   * 获取环境变量布尔值
   * @param {string} key - 环境变量键
   * @param {boolean} defaultValue - 默认值
   * @returns {boolean} 环境变量值或默认值
   */
  getEnvBoolean(key, defaultValue = false) {
    const value = process.env[key];
    if (value === undefined) {
      return defaultValue;
    }
    
    // 处理常见的布尔值表示
    const lowerValue = String(value).toLowerCase();
    if (['true', '1', 'yes', 'y', 'on'].includes(lowerValue)) {
      return true;
    }
    if (['false', '0', 'no', 'n', 'off'].includes(lowerValue)) {
      return false;
    }
    
    return defaultValue;
  }

  /**
   * 解析环境变量数组
   * @param {string} key - 环境变量键
   * @param {Array} defaultValue - 默认值
   * @returns {Array} 环境变量数组或默认值
   */
  parseEnvArray(key, defaultValue = []) {
    const value = process.env[key];
    if (value === undefined) {
      return defaultValue;
    }
    
    // 尝试解析JSON数组
    try {
      return JSON.parse(value);
    } catch (e) {
      // 如果不是有效的JSON，则尝试逗号分隔的格式
      return value.split(',').map(item => item.trim());
    }
  }

  /**
   * 获取配置对象
   * @returns {Object} 应用程序配置
   */
  getConfig() {
    return this.config;
  }

  /**
   * 获取特定配置部分
   * @param {string} section - 配置部分
   * @returns {Object} 配置部分对象
   */
  getSection(section) {
    return this.config[section] || {};
  }

  /**
   * 获取服务器配置
   * @returns {Object} 服务器配置
   */
  getServerConfig() {
    return this.getSection('server');
  }

  /**
   * 获取数据库配置
   * @returns {Object} 数据库配置
   */
  getDatabaseConfig() {
    return this.getSection('database');
  }

  /**
   * 获取Redis配置
   * @returns {Object} Redis配置
   */
  getRedisConfig() {
    return this.getSection('redis');
  }

  /**
   * 获取JWT配置
   * @returns {Object} JWT配置
   */
  getJwtConfig() {
    return this.getSection('jwt');
  }

  /**
   * 获取安全配置
   * @returns {Object} 安全配置
   */
  getSecurityConfig() {
    return this.getSection('security');
  }

  /**
   * 获取分析配置
   * @returns {Object} 分析配置
   */
  getAnalyticsConfig() {
    return this.getSection('analytics');
  }

  /**
   * 获取监控配置
   * @returns {Object} 监控配置
   */
  getMonitoringConfig() {
    return this.getSection('monitoring');
  }

  /**
   * 获取外部服务配置
   * @returns {Object} 外部服务配置
   */
  getExternalServicesConfig() {
    return this.getSection('externalServices');
  }

  /**
   * 获取文件配置
   * @returns {Object} 文件配置
   */
  getFilesConfig() {
    return this.getSection('files');
  }

  /**
   * 验证必要的配置
   * @returns {Object} 验证结果
   */
  validateConfig() {
    const missingRequired = [];
    const validationErrors = [];
    const warnings = [];
    
    // 检查必要的配置
    if (!this.config.jwt.secret || this.config.jwt.secret === 'your-secret-key') {
      warnings.push('JWT密钥使用默认值，建议在生产环境中更改');
    }
    
    if (!this.config.security.sessionSecret || this.config.security.sessionSecret === 'session-secret-key') {
      warnings.push('会话密钥使用默认值，建议在生产环境中更改');
    }
    
    // 检查环境特定的配置
    if (this.config.app.environment === 'production' && !this.config.security.cookieSecure) {
      validationErrors.push('在生产环境中，Cookie应该设置为secure=true');
    }
    
    // 检查必要的外部服务URL
    if (!this.config.externalServices.cardServiceUrl) {
      missingRequired.push('CARD_SERVICE_URL');
    }
    
    if (!this.config.externalServices.userServiceUrl) {
      missingRequired.push('USER_SERVICE_URL');
    }
    
    return {
      isValid: missingRequired.length === 0 && validationErrors.length === 0,
      missingRequired,
      validationErrors,
      warnings
    };
  }

  /**
   * 输出配置报告
   */
  logConfigReport() {
    const validation = this.validateConfig();
    
    logger.info('应用程序配置已加载', {
      environment: this.config.app.environment,
      version: this.config.app.version,
      port: this.config.server.port
    });
    
    // 记录验证结果
    if (validation.warnings.length > 0) {
      validation.warnings.forEach(warning => {
        logger.warn('配置警告', { warning });
      });
    }
    
    if (validation.validationErrors.length > 0) {
      validation.validationErrors.forEach(error => {
        logger.error('配置错误', { error });
      });
    }
    
    if (validation.missingRequired.length > 0) {
      logger.error('缺少必要的配置', { missing: validation.missingRequired });
    }
    
    // 记录非敏感配置摘要（避免记录密码等敏感信息）
    logger.debug('配置摘要', {
      server: {
        host: this.config.server.host,
        port: this.config.server.port,
        environment: this.config.app.environment
      },
      database: {
        host: this.config.database.host,
        name: this.config.database.name
      },
      externalServices: {
        cardServiceAvailable: !!this.config.externalServices.cardServiceUrl,
        userServiceAvailable: !!this.config.externalServices.userServiceUrl,
        notificationServiceAvailable: !!this.config.externalServices.notificationServiceUrl
      }
    });
  }

  /**
   * 动态更新配置
   * @param {string} section - 配置部分
   * @param {string} key - 配置键
   * @param {*} value - 新值
   * @returns {boolean} 更新是否成功
   */
  updateConfig(section, key, value) {
    if (!this.config[section]) {
      logger.error('配置部分不存在', { section });
      return false;
    }
    
    logger.info('更新配置', {
      section,
      key,
      newValue: typeof value === 'string' && value.length > 20 ? `${value.substring(0, 20)}...` : value
    });
    
    this.config[section][key] = value;
    return true;
  }
}

// 创建单例实例
const appConfig = new AppConfig();

// 记录配置报告
appConfig.logConfigReport();

module.exports = appConfig;