/**
 * 数据分析模块 - 数据模型
 * 定义分析数据相关的数据结构和MongoDB模型
 */

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

/**
 * 操作日志模型 - 记录系统中所有操作的详细信息
 */
const OperationLogSchema = new Schema({
  // 操作ID
  operationId: {
    type: String,
    required: true,
    index: true,
    unique: true
  },
  // 用户ID
  userId: {
    type: String,
    required: true,
    index: true
  },
  // 用户名
  username: {
    type: String,
    required: true
  },
  // 操作类型
  operationType: {
    type: String,
    required: true,
    enum: [
      'LOGIN', 'LOGOUT', 'CREATE_CARD', 'UPDATE_CARD', 'DELETE_CARD', 
      'ACTIVATE_CARD', 'DEACTIVATE_CARD', 'BLOCK_CARD', 'UNBLOCK_CARD',
      'TRANSFER_CARD', 'RECHARGE_CARD', 'VIEW_CARD', 'SEARCH_CARD',
      'EXPORT_CARD', 'IMPORT_CARD', 'SETTING_CHANGE', 'USER_CREATE',
      'USER_UPDATE', 'USER_DELETE', 'USER_PERMISSION_CHANGE',
      'INVENTORY_CHECK', 'INVENTORY_UPDATE', 'NOTIFICATION_SEND'
    ],
    index: true
  },
  // 操作详情
  details: {
    type: Object,
    default: {}
  },
  // 操作时间
  operationTime: {
    type: Date,
    required: true,
    default: Date.now,
    index: true
  },
  // 操作IP
  ipAddress: {
    type: String,
    required: true
  },
  // 操作设备信息
  deviceInfo: {
    type: String,
    required: true
  },
  // 操作结果
  result: {
    type: String,
    required: true,
    enum: ['SUCCESS', 'FAILURE', 'PENDING'],
    index: true
  },
  // 错误信息（如果有）
  errorMessage: {
    type: String
  },
  // 关联的卡ID（如果有）
  cardId: {
    type: String,
    index: true
  },
  // 数据版本号
  version: {
    type: Number,
    default: 1
  }
}, {
  timestamps: true,
  collection: 'operation_logs'
});

/**
 * 统计数据模型 - 存储各类统计信息
 */
const StatisticSchema = new Schema({
  // 统计类型
  statisticType: {
    type: String,
    required: true,
    enum: [
      'DAILY_ACTIVITY', 'WEEKLY_ACTIVITY', 'MONTHLY_ACTIVITY',
      'USER_ACTIVITY', 'CARD_CREATION', 'CARD_ACTIVATION',
      'ERROR_RATE', 'TRAFFIC', 'REVENUE', 'INVENTORY_LEVEL'
    ],
    index: true
  },
  // 统计周期
  period: {
    type: String,
    required: true,
    index: true
  },
  // 统计数据
  data: {
    type: Object,
    required: true,
    default: {}
  },
  // 统计时间
  timestamp: {
    type: Date,
    required: true,
    default: Date.now,
    index: true
  },
  // 数据来源
  source: {
    type: String,
    required: true
  },
  // 数据汇总级别
  aggregationLevel: {
    type: String,
    enum: ['MINUTE', 'HOUR', 'DAY', 'WEEK', 'MONTH', 'YEAR'],
    required: true
  },
  // 数据版本号
  version: {
    type: Number,
    default: 1
  }
}, {
  timestamps: true,
  collection: 'statistics'
});

/**
 * 数据趋势模型 - 存储长期趋势数据
 */
const TrendDataSchema = new Schema({
  // 趋势类型
  trendType: {
    type: String,
    required: true,
    enum: [
      'CARD_CREATION_TREND', 'USER_ACTIVITY_TREND', 'ERROR_RATE_TREND',
      'TRAFFIC_TREND', 'REVENUE_TREND', 'INVENTORY_TREND',
      'AVG_PROCESSING_TIME', 'SYSTEM_PERFORMANCE_TREND'
    ],
    index: true
  },
  // 趋势数据点
  dataPoints: [{
    timestamp: {
      type: Date,
      required: true
    },
    value: {
      type: Number,
      required: true
    },
    metadata: {
      type: Object,
      default: {}
    }
  }],
  // 时间范围
  timeRange: {
    start: {
      type: Date,
      required: true
    },
    end: {
      type: Date,
      required: true
    }
  },
  // 数据粒度
  granularity: {
    type: String,
    required: true,
    enum: ['MINUTE', 'HOUR', 'DAY', 'WEEK', 'MONTH']
  },
  // 更新时间
  lastUpdated: {
    type: Date,
    required: true,
    default: Date.now
  },
  // 数据版本号
  version: {
    type: Number,
    default: 1
  }
}, {
  timestamps: true,
  collection: 'trend_data'
});

/**
 * 告警记录模型 - 存储系统告警信息
 */
const AlertSchema = new Schema({
  // 告警ID
  alertId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  // 告警级别
  severity: {
    type: String,
    required: true,
    enum: ['INFO', 'WARNING', 'ERROR', 'CRITICAL'],
    index: true
  },
  // 告警类型
  alertType: {
    type: String,
    required: true,
    enum: [
      'HIGH_ERROR_RATE', 'HIGH_TRAFFIC', 'LOW_INVENTORY',
      'AUTH_FAILURE', 'SYSTEM_PERFORMANCE', 'DATA_ANOMALY',
      'SECURITY_THREAT', 'CONFIGURATION_ERROR', 'DEPENDENCY_FAILURE'
    ],
    index: true
  },
  // 告警标题
  title: {
    type: String,
    required: true
  },
  // 告警描述
  description: {
    type: String,
    required: true
  },
  // 告警源
  source: {
    type: String,
    required: true
  },
  // 相关数据
  relatedData: {
    type: Object,
    default: {}
  },
  // 告警状态
  status: {
    type: String,
    required: true,
    enum: ['ACTIVE', 'ACKNOWLEDGED', 'RESOLVED'],
    default: 'ACTIVE',
    index: true
  },
  // 创建时间
  createdAt: {
    type: Date,
    required: true,
    default: Date.now,
    index: true
  },
  // 解决时间
  resolvedAt: {
    type: Date
  },
  // 确认人
  acknowledgedBy: {
    type: String
  },
  // 解决人
  resolvedBy: {
    type: String
  },
  // 备注
  notes: [{
    text: {
      type: String,
      required: true
    },
    user: {
      type: String,
      required: true
    },
    timestamp: {
      type: Date,
      required: true,
      default: Date.now
    }
  }],
  // 数据版本号
  version: {
    type: Number,
    default: 1
  }
}, {
  timestamps: true,
  collection: 'alerts'
});

/**
 * 用户行为模型 - 存储用户行为模式数据
 */
const UserBehaviorSchema = new Schema({
  // 用户ID
  userId: {
    type: String,
    required: true,
    index: true
  },
  // 用户名
  username: {
    type: String,
    required: true
  },
  // 行为类型
  behaviorType: {
    type: String,
    required: true,
    enum: [
      'LOGIN', 'LOGOUT', 'CARD_SEARCH', 'CARD_EXPORT', 'SETTING_CHANGE',
      'REPORT_GENERATION', 'BULK_OPERATION', 'ADMIN_ACTION'
    ],
    index: true
  },
  // 行为详情
  behaviorDetails: {
    type: Object,
    default: {}
  },
  // 行为时间
  timestamp: {
    type: Date,
    required: true,
    default: Date.now,
    index: true
  },
  // 会话信息
  sessionInfo: {
    type: Object,
    required: true
  },
  // IP地址
  ipAddress: {
    type: String,
    required: true
  },
  // 设备信息
  deviceInfo: {
    type: String,
    required: true
  },
  // 数据版本号
  version: {
    type: Number,
    default: 1
  }
}, {
  timestamps: true,
  collection: 'user_behaviors'
});

// 索引优化
OperationLogSchema.index({ userId: 1, operationTime: -1 });
OperationLogSchema.index({ operationType: 1, operationTime: -1 });
StatisticSchema.index({ statisticType: 1, period: 1 });
TrendDataSchema.index({ trendType: 1, 'timeRange.start': 1, 'timeRange.end': 1 });
AlertSchema.index({ severity: 1, status: 1, createdAt: -1 });
UserBehaviorSchema.index({ userId: 1, timestamp: -1 });
UserBehaviorSchema.index({ behaviorType: 1, timestamp: -1 });

// 模型导出
const OperationLog = mongoose.model('OperationLog', OperationLogSchema);
const Statistic = mongoose.model('Statistic', StatisticSchema);
const TrendData = mongoose.model('TrendData', TrendDataSchema);
const Alert = mongoose.model('Alert', AlertSchema);
const UserBehavior = mongoose.model('UserBehavior', UserBehaviorSchema);

module.exports = {
  OperationLog,
  Statistic,
  TrendData,
  Alert,
  UserBehavior
};