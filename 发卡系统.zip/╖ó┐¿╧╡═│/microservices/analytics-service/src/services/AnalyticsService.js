/**
 * 数据分析模块 - 服务层
 * 实现数据分析的核心业务逻辑
 */

const { v4: uuidv4 } = require('uuid');
const { OperationLog, Statistic, TrendData, Alert, UserBehavior } = require('../models/AnalyticsModel');
const logger = require('../utils/logger');

class AnalyticsService {
  /**
   * 记录操作日志
   * @param {Object} logData - 操作日志数据
   * @returns {Promise<Object>} 创建的操作日志对象
   */
  async logOperation(logData) {
    try {
      const operationLog = new OperationLog({
        operationId: uuidv4(),
        ...logData
      });
      
      await operationLog.save();
      logger.info(`操作日志已记录: ${operationLog.operationId}`, { userId: logData.userId });
      
      // 异步更新统计数据
      this.updateStatistics(logData.operationType).catch(err => {
        logger.error('更新统计数据失败', { error: err.message });
      });
      
      return operationLog;
    } catch (error) {
      logger.error('记录操作日志失败', { error: error.message, data: logData });
      throw new Error(`记录操作日志失败: ${error.message}`);
    }
  }

  /**
   * 获取操作日志列表
   * @param {Object} filters - 过滤条件
   * @param {Object} pagination - 分页参数
   * @returns {Promise<Object>} 操作日志列表和总数
   */
  async getOperationLogs(filters = {}, pagination = {}) {
    try {
      const { page = 1, limit = 20, sortBy = 'operationTime', sortOrder = 'desc' } = pagination;
      const skip = (page - 1) * limit;
      
      // 构建查询条件
      const query = {};
      
      if (filters.userId) query.userId = filters.userId;
      if (filters.operationType) query.operationType = filters.operationType;
      if (filters.result) query.result = filters.result;
      if (filters.cardId) query.cardId = filters.cardId;
      if (filters.startDate) query.operationTime = { $gte: new Date(filters.startDate) };
      if (filters.endDate) query.operationTime = { 
        ...query.operationTime, 
        $lte: new Date(filters.endDate)
      };
      
      // 构建排序对象
      const sortObject = {};
      sortObject[sortBy] = sortOrder === 'desc' ? -1 : 1;
      
      const [logs, total] = await Promise.all([
        OperationLog.find(query)
          .sort(sortObject)
          .skip(skip)
          .limit(limit)
          .lean(),
        OperationLog.countDocuments(query)
      ]);
      
      return {
        logs,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      };
    } catch (error) {
      logger.error('获取操作日志失败', { error: error.message, filters, pagination });
      throw new Error(`获取操作日志失败: ${error.message}`);
    }
  }

  /**
   * 更新统计数据
   * @param {String} operationType - 操作类型
   * @returns {Promise<void>}
   */
  async updateStatistics(operationType) {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const period = today.toISOString().split('T')[0];
      
      // 查找或创建今日统计记录
      let statistic = await Statistic.findOneAndUpdate(
        { 
          statisticType: 'DAILY_ACTIVITY',
          period: period
        },
        { 
          $inc: { 
            [`data.${operationType}`]: 1,
            'data.totalOperations': 1
          },
          $set: {
            source: 'system',
            aggregationLevel: 'DAY',
            timestamp: new Date()
          }
        },
        { 
          upsert: true,
          new: true,
          setDefaultsOnInsert: true
        }
      );
      
      logger.debug('统计数据已更新', { period, operationType });
    } catch (error) {
      logger.error('更新统计数据失败', { error: error.message, operationType });
      throw new Error(`更新统计数据失败: ${error.message}`);
    }
  }

  /**
   * 获取统计数据
   * @param {String} type - 统计类型
   * @param {String} period - 统计周期
   * @returns {Promise<Object>} 统计数据
   */
  async getStatistics(type, period) {
    try {
      const statistic = await Statistic.findOne({
        statisticType: type,
        period: period
      }).lean();
      
      if (!statistic) {
        return { data: {}, period, type };
      }
      
      return statistic;
    } catch (error) {
      logger.error('获取统计数据失败', { error: error.message, type, period });
      throw new Error(`获取统计数据失败: ${error.message}`);
    }
  }

  /**
   * 更新趋势数据
   * @param {String} trendType - 趋势类型
   * @param {Number} value - 值
   * @param {Object} metadata - 元数据
   * @returns {Promise<void>}
   */
  async updateTrendData(trendType, value, metadata = {}) {
    try {
      const now = new Date();
      const hourStart = new Date(now);
      hourStart.setMinutes(0, 0, 0);
      
      const hourEnd = new Date(hourStart);
      hourEnd.setHours(hourEnd.getHours() + 1);
      
      // 查找或创建趋势数据记录
      let trendData = await TrendData.findOneAndUpdate(
        { 
          trendType,
          'timeRange.start': hourStart,
          'timeRange.end': hourEnd
        },
        { 
          $push: {
            dataPoints: {
              timestamp: now,
              value,
              metadata
            }
          },
          $set: {
            granularity: 'HOUR',
            lastUpdated: now
          }
        },
        { 
          upsert: true,
          new: true,
          setDefaultsOnInsert: {
            trendType,
            dataPoints: [],
            timeRange: { start: hourStart, end: hourEnd },
            granularity: 'HOUR',
            version: 1
          }
        }
      );
      
      logger.debug('趋势数据已更新', { trendType, value });
    } catch (error) {
      logger.error('更新趋势数据失败', { error: error.message, trendType, value });
      throw new Error(`更新趋势数据失败: ${error.message}`);
    }
  }

  /**
   * 获取趋势数据
   * @param {String} trendType - 趋势类型
   * @param {Date} startTime - 开始时间
   * @param {Date} endTime - 结束时间
   * @returns {Promise<Array>} 趋势数据点数组
   */
  async getTrendData(trendType, startTime, endTime) {
    try {
      const trends = await TrendData.find({
        trendType,
        'timeRange.start': { $gte: startTime },
        'timeRange.end': { $lte: endTime }
      }).lean();
      
      // 合并所有数据点并按时间排序
      let allDataPoints = [];
      trends.forEach(trend => {
        allDataPoints = [...allDataPoints, ...trend.dataPoints];
      });
      
      allDataPoints.sort((a, b) => a.timestamp - b.timestamp);
      
      return allDataPoints;
    } catch (error) {
      logger.error('获取趋势数据失败', { error: error.message, trendType });
      throw new Error(`获取趋势数据失败: ${error.message}`);
    }
  }

  /**
   * 创建告警
   * @param {Object} alertData - 告警数据
   * @returns {Promise<Object>} 创建的告警对象
   */
  async createAlert(alertData) {
    try {
      const alert = new Alert({
        alertId: uuidv4(),
        ...alertData,
        createdAt: new Date()
      });
      
      await alert.save();
      logger.warn(`告警已创建: ${alert.alertId}`, { severity: alert.severity });
      
      // 高优先级告警可以在这里添加通知逻辑
      if (['ERROR', 'CRITICAL'].includes(alert.severity)) {
        // 这里可以添加通知服务的调用
        logger.warn(`高优先级告警需要通知处理: ${alert.alertId}`);
      }
      
      return alert;
    } catch (error) {
      logger.error('创建告警失败', { error: error.message, data: alertData });
      throw new Error(`创建告警失败: ${error.message}`);
    }
  }

  /**
   * 更新告警状态
   * @param {String} alertId - 告警ID
   * @param {String} status - 新状态
   * @param {String} userId - 操作用户ID
   * @param {String} note - 备注
   * @returns {Promise<Object>} 更新后的告警对象
   */
  async updateAlertStatus(alertId, status, userId, note = '') {
    try {
      const updateData = {
        status,
        $push: {
          notes: {
            text: note,
            user: userId,
            timestamp: new Date()
          }
        }
      };
      
      if (status === 'ACKNOWLEDGED') {
        updateData.acknowledgedBy = userId;
      } else if (status === 'RESOLVED') {
        updateData.resolvedBy = userId;
        updateData.resolvedAt = new Date();
      }
      
      const alert = await Alert.findOneAndUpdate(
        { alertId },
        updateData,
        { new: true }
      );
      
      if (!alert) {
        throw new Error('告警不存在');
      }
      
      logger.info(`告警状态已更新: ${alertId} -> ${status}`, { userId });
      return alert;
    } catch (error) {
      logger.error('更新告警状态失败', { error: error.message, alertId, status });
      throw new Error(`更新告警状态失败: ${error.message}`);
    }
  }

  /**
   * 获取告警列表
   * @param {Object} filters - 过滤条件
   * @param {Object} pagination - 分页参数
   * @returns {Promise<Object>} 告警列表和总数
   */
  async getAlerts(filters = {}, pagination = {}) {
    try {
      const { page = 1, limit = 20, sortBy = 'createdAt', sortOrder = 'desc' } = pagination;
      const skip = (page - 1) * limit;
      
      // 构建查询条件
      const query = {};
      
      if (filters.severity) query.severity = filters.severity;
      if (filters.alertType) query.alertType = filters.alertType;
      if (filters.status) query.status = filters.status;
      if (filters.startDate) query.createdAt = { $gte: new Date(filters.startDate) };
      if (filters.endDate) query.createdAt = { 
        ...query.createdAt, 
        $lte: new Date(filters.endDate)
      };
      
      // 构建排序对象
      const sortObject = {};
      sortObject[sortBy] = sortOrder === 'desc' ? -1 : 1;
      
      const [alerts, total] = await Promise.all([
        Alert.find(query)
          .sort(sortObject)
          .skip(skip)
          .limit(limit)
          .lean(),
        Alert.countDocuments(query)
      ]);
      
      return {
        alerts,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      };
    } catch (error) {
      logger.error('获取告警列表失败', { error: error.message, filters });
      throw new Error(`获取告警列表失败: ${error.message}`);
    }
  }

  /**
   * 记录用户行为
   * @param {Object} behaviorData - 用户行为数据
   * @returns {Promise<Object>} 创建的用户行为对象
   */
  async logUserBehavior(behaviorData) {
    try {
      const userBehavior = new UserBehavior(behaviorData);
      await userBehavior.save();
      
      logger.info(`用户行为已记录: ${behaviorData.userId} - ${behaviorData.behaviorType}`);
      
      // 异步检测异常行为
      this.detectAnomalousBehavior(behaviorData).catch(err => {
        logger.error('检测异常行为失败', { error: err.message });
      });
      
      return userBehavior;
    } catch (error) {
      logger.error('记录用户行为失败', { error: error.message, data: behaviorData });
      throw new Error(`记录用户行为失败: ${error.message}`);
    }
  }

  /**
   * 检测异常行为
   * @param {Object} behaviorData - 用户行为数据
   * @returns {Promise<void>}
   */
  async detectAnomalousBehavior(behaviorData) {
    try {
      // 这里实现异常行为检测逻辑
      // 例如：检测短时间内的大量登录尝试、异常的访问模式等
      const recentLogins = await UserBehavior.countDocuments({
        userId: behaviorData.userId,
        behaviorType: 'LOGIN',
        timestamp: { $gte: new Date(Date.now() - 5 * 60 * 1000) } // 5分钟内
      });
      
      if (recentLogins > 5) {
        await this.createAlert({
          severity: 'WARNING',
          alertType: 'AUTH_FAILURE',
          title: '用户登录尝试频率过高',
          description: `用户 ${behaviorData.username} 在短时间内有多次登录尝试`,
          source: 'analytics-service',
          relatedData: {
            userId: behaviorData.userId,
            username: behaviorData.username,
            ipAddress: behaviorData.ipAddress,
            loginCount: recentLogins
          }
        });
      }
    } catch (error) {
      logger.error('异常行为检测失败', { error: error.message });
    }
  }

  /**
   * 生成分析报告
   * @param {String} reportType - 报告类型
   * @param {Date} startDate - 开始日期
   * @param {Date} endDate - 结束日期
   * @returns {Promise<Object>} 分析报告数据
   */
  async generateReport(reportType, startDate, endDate) {
    try {
      switch (reportType) {
        case 'daily_activity':
          return await this.generateDailyActivityReport(startDate, endDate);
        case 'user_activity':
          return await this.generateUserActivityReport(startDate, endDate);
        case 'error_summary':
          return await this.generateErrorSummaryReport(startDate, endDate);
        default:
          throw new Error(`不支持的报告类型: ${reportType}`);
      }
    } catch (error) {
      logger.error('生成分析报告失败', { error: error.message, reportType });
      throw new Error(`生成分析报告失败: ${error.message}`);
    }
  }

  /**
   * 生成日常活动报告
   * @private
   */
  async generateDailyActivityReport(startDate, endDate) {
    // 实现日常活动报告逻辑
    const operations = await OperationLog.aggregate([
      { $match: { operationTime: { $gte: startDate, $lte: endDate } } },
      { $group: { _id: '$operationType', count: { $sum: 1 } } }
    ]);
    
    const successRate = await this.calculateSuccessRate(startDate, endDate);
    
    return {
      reportType: 'daily_activity',
      period: { start: startDate, end: endDate },
      operations,
      successRate,
      generatedAt: new Date()
    };
  }

  /**
   * 生成用户活动报告
   * @private
   */
  async generateUserActivityReport(startDate, endDate) {
    // 实现用户活动报告逻辑
    const userActivities = await UserBehavior.aggregate([
      { $match: { timestamp: { $gte: startDate, $lte: endDate } } },
      { $group: { 
        _id: { userId: '$userId', username: '$username' }, 
        activityCount: { $sum: 1 },
        lastActive: { $max: '$timestamp' }
      }},
      { $sort: { activityCount: -1 } },
      { $limit: 50 }
    ]);
    
    return {
      reportType: 'user_activity',
      period: { start: startDate, end: endDate },
      topActiveUsers: userActivities,
      userCount: userActivities.length,
      generatedAt: new Date()
    };
  }

  /**
   * 生成错误摘要报告
   * @private
   */
  async generateErrorSummaryReport(startDate, endDate) {
    // 实现错误摘要报告逻辑
    const errors = await OperationLog.aggregate([
      { $match: { 
        result: 'FAILURE',
        operationTime: { $gte: startDate, $lte: endDate },
        errorMessage: { $exists: true, $ne: null, $ne: '' }
      }},
      { $group: { 
        _id: '$errorMessage', 
        count: { $sum: 1 },
        operationTypes: { $addToSet: '$operationType' },
        lastOccurred: { $max: '$operationTime' }
      }},
      { $sort: { count: -1 } },
      { $limit: 20 }
    ]);
    
    return {
      reportType: 'error_summary',
      period: { start: startDate, end: endDate },
      topErrors: errors,
      totalErrorCount: errors.reduce((sum, err) => sum + err.count, 0),
      generatedAt: new Date()
    };
  }

  /**
   * 计算操作成功率
   * @private
   */
  async calculateSuccessRate(startDate, endDate) {
    const totalOperations = await OperationLog.countDocuments({
      operationTime: { $gte: startDate, $lte: endDate }
    });
    
    const successOperations = await OperationLog.countDocuments({
      operationTime: { $gte: startDate, $lte: endDate },
      result: 'SUCCESS'
    });
    
    return totalOperations > 0 ? (successOperations / totalOperations) * 100 : 100;
  }

  /**
   * 清理过期数据
   * @param {Number} retentionDays - 数据保留天数
   * @returns {Promise<Object>} 清理结果统计
   */
  async cleanupOldData(retentionDays = 90) {
    try {
      const cutoffDate = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
      
      const deletedLogs = await OperationLog.deleteMany({ 
        operationTime: { $lt: cutoffDate } 
      });
      
      const deletedBehaviors = await UserBehavior.deleteMany({ 
        timestamp: { $lt: cutoffDate } 
      });
      
      const deletedTrends = await TrendData.deleteMany({ 
        'timeRange.end': { $lt: cutoffDate } 
      });
      
      logger.info('过期数据分析数据已清理', { 
        retentionDays,
        deletedLogs: deletedLogs.deletedCount,
        deletedBehaviors: deletedBehaviors.deletedCount,
        deletedTrends: deletedTrends.deletedCount
      });
      
      return {
        cutoffDate,
        deletedLogs: deletedLogs.deletedCount,
        deletedBehaviors: deletedBehaviors.deletedCount,
        deletedTrends: deletedTrends.deletedCount
      };
    } catch (error) {
      logger.error('清理过期数据失败', { error: error.message, retentionDays });
      throw new Error(`清理过期数据失败: ${error.message}`);
    }
  }
}

module.exports = new AnalyticsService();