/**
 * 数据分析模块 - 日志工具
 * 提供结构化日志记录功能，支持不同日志级别和格式化输出
 */

const fs = require('fs');
const path = require('path');
require('dotenv').config();

class Logger {
  constructor() {
    this.logLevel = this.parseLogLevel(process.env.LOG_LEVEL || 'info');
    this.logFilePath = path.join(__dirname, '..', 'logs', 'analytics-service.log');
    this.consoleEnabled = process.env.LOG_TO_CONSOLE !== 'false';
    this.fileEnabled = process.env.LOG_TO_FILE !== 'false';
    this.jsonFormat = process.env.LOG_FORMAT === 'json';
    this.maxLogFileSize = parseInt(process.env.MAX_LOG_FILE_SIZE) || 10485760; // 默认10MB
    
    // 确保日志目录存在
    this.ensureLogDirectory();
    
    // 检查日志文件大小
    this.checkLogFileSize();
  }

  /**
   * 日志级别枚举
   */
  LOG_LEVELS = {
    ERROR: 0,
    WARN: 1,
    INFO: 2,
    DEBUG: 3,
    TRACE: 4
  };

  /**
   * 解析日志级别字符串为数值
   * @param {string} level - 日志级别字符串
   * @returns {number} 日志级别数值
   */
  parseLogLevel(level) {
    const upperLevel = level.toUpperCase();
    return this.LOG_LEVELS[upperLevel] !== undefined 
      ? this.LOG_LEVELS[upperLevel] 
      : this.LOG_LEVELS.INFO;
  }

  /**
   * 确保日志目录存在
   */
  ensureLogDirectory() {
    const logDir = path.dirname(this.logFilePath);
    if (!fs.existsSync(logDir)) {
      try {
        fs.mkdirSync(logDir, { recursive: true });
      } catch (error) {
        console.error(`无法创建日志目录: ${error.message}`);
        this.fileEnabled = false;
      }
    }
  }

  /**
   * 检查日志文件大小并滚动
   */
  checkLogFileSize() {
    if (!this.fileEnabled || !fs.existsSync(this.logFilePath)) {
      return;
    }

    try {
      const stats = fs.statSync(this.logFilePath);
      if (stats.size >= this.maxLogFileSize) {
        this.rotateLogFile();
      }
    } catch (error) {
      console.error(`检查日志文件大小失败: ${error.message}`);
    }
  }

  /**
   * 滚动日志文件
   */
  rotateLogFile() {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const rotatedFileName = `${this.logFilePath}.${timestamp}`;
      
      fs.renameSync(this.logFilePath, rotatedFileName);
      this.info(`日志文件已滚动: ${rotatedFileName}`);
    } catch (error) {
      console.error(`日志文件滚动失败: ${error.message}`);
    }
  }

  /**
   * 创建日志消息对象
   * @param {string} level - 日志级别
   * @param {string} message - 日志消息
   * @param {Object} meta - 额外元数据
   * @returns {Object} 日志对象
   */
  createLogObject(level, message, meta = {}) {
    return {
      timestamp: new Date().toISOString(),
      level: level,
      service: 'analytics-service',
      message: message,
      ...meta
    };
  }

  /**
   * 格式化日志消息为字符串
   * @param {Object} logObject - 日志对象
   * @returns {string} 格式化的日志字符串
   */
  formatLog(logObject) {
    if (this.jsonFormat) {
      return JSON.stringify(logObject);
    }

    const { timestamp, level, message, ...meta } = logObject;
    let metaStr = '';
    
    if (Object.keys(meta).length > 0) {
      metaStr = ' ' + JSON.stringify(meta);
    }

    return `[${timestamp}] [${level}] ${message}${metaStr}`;
  }

  /**
   * 写入日志到文件
   * @param {string} formattedLog - 格式化的日志字符串
   */
  writeToFile(formattedLog) {
    if (!this.fileEnabled) return;

    try {
      fs.appendFileSync(this.logFilePath, formattedLog + '\n');
    } catch (error) {
      console.error(`写入日志文件失败: ${error.message}`);
    }
  }

  /**
   * 输出日志到控制台
   * @param {string} level - 日志级别
   * @param {string} formattedLog - 格式化的日志字符串
   */
  writeToConsole(level, formattedLog) {
    if (!this.consoleEnabled) return;

    const consoleMethod = this.getConsoleMethod(level);
    consoleMethod(formattedLog);
  }

  /**
   * 获取对应的控制台方法
   * @param {string} level - 日志级别
   * @returns {Function} 控制台方法
   */
  getConsoleMethod(level) {
    switch (level) {
      case 'ERROR':
        return console.error;
      case 'WARN':
        return console.warn;
      case 'INFO':
        return console.info;
      case 'DEBUG':
      case 'TRACE':
        return console.log;
      default:
        return console.log;
    }
  }

  /**
   * 记录日志
   * @param {string} level - 日志级别
   * @param {string} message - 日志消息
   * @param {Object} meta - 额外元数据
   */
  log(level, message, meta = {}) {
    const levelValue = this.LOG_LEVELS[level];
    
    // 检查是否应该记录此级别的日志
    if (levelValue > this.logLevel) {
      return;
    }

    const logObject = this.createLogObject(level, message, meta);
    const formattedLog = this.formatLog(logObject);

    // 写入文件和控制台
    this.writeToFile(formattedLog);
    this.writeToConsole(level, formattedLog);
  }

  /**
   * 记录错误日志
   * @param {string} message - 错误消息
   * @param {Object} meta - 额外元数据
   */
  error(message, meta = {}) {
    this.log('ERROR', message, meta);
  }

  /**
   * 记录警告日志
   * @param {string} message - 警告消息
   * @param {Object} meta - 额外元数据
   */
  warn(message, meta = {}) {
    this.log('WARN', message, meta);
  }

  /**
   * 记录信息日志
   * @param {string} message - 信息消息
   * @param {Object} meta - 额外元数据
   */
  info(message, meta = {}) {
    this.log('INFO', message, meta);
  }

  /**
   * 记录调试日志
   * @param {string} message - 调试消息
   * @param {Object} meta - 额外元数据
   */
  debug(message, meta = {}) {
    this.log('DEBUG', message, meta);
  }

  /**
   * 记录跟踪日志
   * @param {string} message - 跟踪消息
   * @param {Object} meta - 额外元数据
   */
  trace(message, meta = {}) {
    this.log('TRACE', message, meta);
  }

  /**
   * 记录API请求日志
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {number} responseTime - 响应时间（毫秒）
   */
  logApiRequest(req, res, responseTime) {
    // 过滤敏感数据
    const safeBody = this.sanitizeData(req.body);
    const safeQuery = this.sanitizeData(req.query);
    const safeParams = this.sanitizeData(req.params);

    const logData = {
      endpoint: req.originalUrl,
      method: req.method,
      statusCode: res.statusCode,
      responseTime: responseTime,
      ip: this.getClientIp(req),
      userAgent: req.headers['user-agent'],
      userId: req.user?.id || 'anonymous',
      query: safeQuery,
      params: safeParams,
      bodySize: JSON.stringify(req.body).length
    };

    // 根据响应状态码决定日志级别
    if (res.statusCode >= 500) {
      this.error('API请求失败', logData);
    } else if (res.statusCode >= 400) {
      this.warn('API请求错误', logData);
    } else {
      this.debug('API请求', logData);
    }
  }

  /**
   * 记录数据库操作日志
   * @param {string} operation - 操作类型
   * @param {string} collection - 集合名称
   * @param {Object} query - 查询条件
   * @param {Object} options - 选项
   * @param {number} executionTime - 执行时间（毫秒）
   */
  logDatabaseOperation(operation, collection, query, options = {}, executionTime) {
    const logData = {
      operation: operation,
      collection: collection,
      query: this.sanitizeData(query),
      options: this.sanitizeData(options),
      executionTime: executionTime
    };

    if (executionTime > 100) {
      this.warn('数据库操作执行缓慢', logData);
    } else {
      this.debug('数据库操作', logData);
    }
  }

  /**
   * 清理敏感数据
   * @param {any} data - 待清理的数据
   * @returns {any} 清理后的数据
   */
  sanitizeData(data) {
    if (!data || typeof data !== 'object') return data;

    const sensitiveFields = ['password', 'token', 'secret', 'key', 'auth', 'credit', 'card'];
    const sanitizedData = Array.isArray(data) ? [] : {};

    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        const lowerKey = key.toLowerCase();
        
        // 检查是否包含敏感字段
        const isSensitive = sensitiveFields.some(field => lowerKey.includes(field));
        
        if (isSensitive) {
          sanitizedData[key] = '***REDACTED***';
        } else if (typeof data[key] === 'object' && data[key] !== null) {
          sanitizedData[key] = this.sanitizeData(data[key]);
        } else {
          sanitizedData[key] = data[key];
        }
      }
    }

    return sanitizedData;
  }

  /**
   * 获取客户端IP地址
   * @param {Object} req - Express请求对象
   * @returns {string} IP地址
   */
  getClientIp(req) {
    return req.ip || 
           req.connection.remoteAddress ||
           req.socket.remoteAddress ||
           req.connection.socket.remoteAddress ||
           'unknown';
  }

  /**
   * 设置日志级别
   * @param {string} level - 新的日志级别
   */
  setLogLevel(level) {
    this.logLevel = this.parseLogLevel(level);
    this.info(`日志级别已更改为: ${level}`);
  }

  /**
   * 启用/禁用文件日志
   * @param {boolean} enabled - 是否启用
   */
  setFileLogging(enabled) {
    this.fileEnabled = enabled;
    this.info(`文件日志已${enabled ? '启用' : '禁用'}`);
    
    // 如果启用且日志目录不存在，则创建
    if (enabled) {
      this.ensureLogDirectory();
    }
  }

  /**
   * 启用/禁用控制台日志
   * @param {boolean} enabled - 是否启用
   */
  setConsoleLogging(enabled) {
    this.consoleEnabled = enabled;
    this.info(`控制台日志已${enabled ? '启用' : '禁用'}`);
  }
}

// 创建单例实例
const logger = new Logger();

module.exports = logger;