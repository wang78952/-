/**
 * 数据分析模块 - 控制器
 * 处理HTTP请求并调用服务层进行数据分析操作
 */

const analyticsService = require('../services/AnalyticsService');
const logger = require('../utils/logger');

class AnalyticsController {
  /**
   * 记录操作日志
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async logOperation(req, res, next) {
    try {
      const logData = {
        ...req.body,
        ipAddress: req.ip,
        deviceInfo: req.headers['user-agent'] || 'unknown'
      };
      
      const result = await analyticsService.logOperation(logData);
      
      res.status(201).json({
        success: true,
        message: '操作日志记录成功',
        data: result
      });
    } catch (error) {
      logger.error('记录操作日志API失败', { error: error.message, userId: req.body?.userId });
      next(error);
    }
  }

  /**
   * 获取操作日志列表
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async getOperationLogs(req, res, next) {
    try {
      const filters = {
        userId: req.query.userId,
        operationType: req.query.operationType,
        result: req.query.result,
        cardId: req.query.cardId,
        startDate: req.query.startDate,
        endDate: req.query.endDate
      };
      
      const pagination = {
        page: parseInt(req.query.page, 10) || 1,
        limit: parseInt(req.query.limit, 10) || 20,
        sortBy: req.query.sortBy || 'operationTime',
        sortOrder: req.query.sortOrder || 'desc'
      };
      
      const result = await analyticsService.getOperationLogs(filters, pagination);
      
      res.status(200).json({
        success: true,
        message: '获取操作日志列表成功',
        data: result.logs,
        pagination: {
          page: result.page,
          limit: result.limit,
          total: result.total,
          totalPages: result.totalPages
        }
      });
    } catch (error) {
      logger.error('获取操作日志列表API失败', { error: error.message, query: req.query });
      next(error);
    }
  }

  /**
   * 获取统计数据
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async getStatistics(req, res, next) {
    try {
      const { type, period } = req.params;
      
      const result = await analyticsService.getStatistics(type, period);
      
      res.status(200).json({
        success: true,
        message: '获取统计数据成功',
        data: result
      });
    } catch (error) {
      logger.error('获取统计数据API失败', { error: error.message, params: req.params });
      next(error);
    }
  }

  /**
   * 获取趋势数据
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async getTrendData(req, res, next) {
    try {
      const { trendType } = req.params;
      const { startTime, endTime } = req.query;
      
      if (!startTime || !endTime) {
        return res.status(400).json({
          success: false,
          message: '缺少必要的时间范围参数'
        });
      }
      
      const result = await analyticsService.getTrendData(
        trendType, 
        new Date(startTime), 
        new Date(endTime)
      );
      
      res.status(200).json({
        success: true,
        message: '获取趋势数据成功',
        data: result
      });
    } catch (error) {
      logger.error('获取趋势数据API失败', { error: error.message, params: req.params });
      next(error);
    }
  }

  /**
   * 创建告警
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async createAlert(req, res, next) {
    try {
      const result = await analyticsService.createAlert(req.body);
      
      res.status(201).json({
        success: true,
        message: '告警创建成功',
        data: result
      });
    } catch (error) {
      logger.error('创建告警API失败', { error: error.message, data: req.body });
      next(error);
    }
  }

  /**
   * 更新告警状态
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async updateAlertStatus(req, res, next) {
    try {
      const { alertId } = req.params;
      const { status, note } = req.body;
      const userId = req.user?.id || 'system'; // 从认证中间件获取用户ID
      
      const result = await analyticsService.updateAlertStatus(alertId, status, userId, note);
      
      res.status(200).json({
        success: true,
        message: '告警状态更新成功',
        data: result
      });
    } catch (error) {
      logger.error('更新告警状态API失败', { error: error.message, alertId: req.params.alertId });
      next(error);
    }
  }

  /**
   * 获取告警列表
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async getAlerts(req, res, next) {
    try {
      const filters = {
        severity: req.query.severity,
        alertType: req.query.alertType,
        status: req.query.status,
        startDate: req.query.startDate,
        endDate: req.query.endDate
      };
      
      const pagination = {
        page: parseInt(req.query.page, 10) || 1,
        limit: parseInt(req.query.limit, 10) || 20,
        sortBy: req.query.sortBy || 'createdAt',
        sortOrder: req.query.sortOrder || 'desc'
      };
      
      const result = await analyticsService.getAlerts(filters, pagination);
      
      res.status(200).json({
        success: true,
        message: '获取告警列表成功',
        data: result.alerts,
        pagination: {
          page: result.page,
          limit: result.limit,
          total: result.total,
          totalPages: result.totalPages
        }
      });
    } catch (error) {
      logger.error('获取告警列表API失败', { error: error.message, query: req.query });
      next(error);
    }
  }

  /**
   * 记录用户行为
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async logUserBehavior(req, res, next) {
    try {
      const behaviorData = {
        ...req.body,
        ipAddress: req.ip,
        deviceInfo: req.headers['user-agent'] || 'unknown',
        sessionInfo: {
          sessionId: req.session?.id || 'unknown',
          expires: req.session?.cookie?.expires || 'unknown'
        }
      };
      
      const result = await analyticsService.logUserBehavior(behaviorData);
      
      res.status(201).json({
        success: true,
        message: '用户行为记录成功',
        data: result
      });
    } catch (error) {
      logger.error('记录用户行为API失败', { error: error.message, userId: req.body?.userId });
      next(error);
    }
  }

  /**
   * 生成分析报告
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async generateReport(req, res, next) {
    try {
      const { reportType } = req.params;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({
          success: false,
          message: '缺少必要的时间范围参数'
        });
      }
      
      const result = await analyticsService.generateReport(
        reportType,
        new Date(startDate),
        new Date(endDate)
      );
      
      res.status(200).json({
        success: true,
        message: '生成分析报告成功',
        data: result
      });
    } catch (error) {
      logger.error('生成分析报告API失败', { error: error.message, reportType: req.params.reportType });
      next(error);
    }
  }

  /**
   * 清理过期数据
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async cleanupOldData(req, res, next) {
    try {
      const { retentionDays } = req.query;
      const days = retentionDays ? parseInt(retentionDays, 10) : 90;
      
      const result = await analyticsService.cleanupOldData(days);
      
      res.status(200).json({
        success: true,
        message: '清理过期数据成功',
        data: result
      });
    } catch (error) {
      logger.error('清理过期数据API失败', { error: error.message });
      next(error);
    }
  }

  /**
   * 获取仪表盘数据
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async getDashboardData(req, res, next) {
    try {
      const { period = 'today' } = req.query;
      let startDate, endDate;
      const now = new Date();
      
      // 根据周期设置时间范围
      switch (period) {
        case 'today':
          startDate = new Date(now.setHours(0, 0, 0, 0));
          endDate = new Date(now.setHours(23, 59, 59, 999));
          break;
        case 'yesterday':
          startDate = new Date(now.setDate(now.getDate() - 1));
          startDate.setHours(0, 0, 0, 0);
          endDate = new Date(startDate);
          endDate.setHours(23, 59, 59, 999);
          break;
        case 'week':
          startDate = new Date(now.setDate(now.getDate() - now.getDay()));
          startDate.setHours(0, 0, 0, 0);
          endDate = new Date(now.setDate(now.getDate() + 6));
          endDate.setHours(23, 59, 59, 999);
          break;
        case 'month':
          startDate = new Date(now.getFullYear(), now.getMonth(), 1);
          endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
          break;
        default:
          startDate = new Date(now.setHours(0, 0, 0, 0));
          endDate = new Date(now.setHours(23, 59, 59, 999));
      }
      
      // 并行获取各类仪表盘数据
      const [dailyActivityReport, activeAlerts] = await Promise.all([
        analyticsService.generateReport('daily_activity', startDate, endDate),
        analyticsService.getAlerts({ status: 'ACTIVE' }, { limit: 10 })
      ]);
      
      res.status(200).json({
        success: true,
        message: '获取仪表盘数据成功',
        data: {
          period,
          timeRange: { start: startDate, end: endDate },
          dailyActivity: dailyActivityReport,
          activeAlerts: activeAlerts.alerts,
          activeAlertCount: activeAlerts.total
        }
      });
    } catch (error) {
      logger.error('获取仪表盘数据API失败', { error: error.message });
      next(error);
    }
  }

  /**
   * 获取系统健康状态
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   */
  async getHealthStatus(req, res) {
    try {
      res.status(200).json({
        success: true,
        message: '数据分析服务运行正常',
        data: {
          service: 'analytics-service',
          status: 'healthy',
          timestamp: new Date().toISOString(),
          version: process.env.npm_package_version || '1.0.0'
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: '服务异常',
        error: error.message
      });
    }
  }

  /**
   * 导出数据（支持CSV、JSON格式）
   * @param {Object} req - Express请求对象
   * @param {Object} res - Express响应对象
   * @param {Function} next - 下一个中间件函数
   */
  async exportData(req, res, next) {
    try {
      const { dataType, format, startDate, endDate } = req.query;
      
      if (!dataType || !format) {
        return res.status(400).json({
          success: false,
          message: '缺少必要的导出参数'
        });
      }
      
      // 根据数据类型生成报告
      const report = await analyticsService.generateReport(
        dataType === 'operations' ? 'daily_activity' : 'error_summary',
        new Date(startDate),
        new Date(endDate)
      );
      
      // 设置响应头
      const filename = `analytics_export_${dataType}_${new Date().toISOString().split('T')[0]}.${format}`;
      
      if (format === 'json') {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
        return res.json(report);
      } else if (format === 'csv') {
        // 简单的CSV转换逻辑
        let csvContent = '';
        if (dataType === 'operations') {
          // 导出操作日志统计
          csvContent = 'OperationType,Count\n';
          report.operations.forEach(op => {
            csvContent += `${op._id},${op.count}\n`;
          });
        } else {
          // 导出错误摘要
          csvContent = 'ErrorMessage,Count,LastOccurred\n';
          report.topErrors.forEach(err => {
            csvContent += `"${err._id}",${err.count},${err.lastOccurred}\n`;
          });
        }
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
        return res.send(csvContent);
      } else {
        return res.status(400).json({
          success: false,
          message: '不支持的导出格式'
        });
      }
    } catch (error) {
      logger.error('导出数据API失败', { error: error.message, params: req.query });
      next(error);
    }
  }
}

module.exports = new AnalyticsController();