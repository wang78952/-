/**
 * 数据分析服务 - 主入口文件
 * 启动数据分析微服务
 */

const dotenv = require('dotenv');
const path = require('path');

// 加载环境变量
const envPath = path.resolve(__dirname, '../.env');
dotenv.config({ path: envPath });

// 如果.env文件不存在，尝试从示例文件创建
if (!process.env.NODE_ENV) {
  console.warn('⚠️  .env 文件未找到，请根据 .env.example 创建配置文件');
  
  // 尝试从示例文件加载
  const exampleEnvPath = path.resolve(__dirname, '../.env.example');
  try {
    dotenv.config({ path: exampleEnvPath });
    console.log('📄 已从 .env.example 加载配置');
  } catch (error) {
    console.error('❌ 无法加载环境配置文件');
  }
}

// 延迟加载日志模块，避免循环依赖
let logger;
function getLogger() {
  if (!logger) {
    logger = require('./utils/logger');
  }
  return logger;
}

/**
 * 预启动检查
 * @returns {Object} 检查结果
 */
function preStartChecks() {
  const checks = [];
  const warnings = [];
  
  // 检查必要的环境变量
  const requiredEnvVars = [
    'NODE_ENV',
    'SERVER_PORT',
    'SERVER_HOST',
    'MONGODB_URI'
  ];
  
  requiredEnvVars.forEach(envVar => {
    if (!process.env[envVar]) {
      warnings.push(`环境变量 ${envVar} 未设置`);
    }
  });
  
  // 检查Node.js版本
  const requiredNodeVersion = '14.0.0';
  const currentVersion = process.version;
  
  if (currentVersion.localeCompare(requiredNodeVersion, undefined, { numeric: true, sensitivity: 'base' }) < 0) {
    warnings.push(`Node.js 版本 ${currentVersion} 低于推荐版本 ${requiredNodeVersion}`);
  }
  
  return { checks, warnings };
}

/**
 * 显示启动横幅
 */
function displayBanner() {
  const banner = `
    ============================================
              数据分析服务启动
    ============================================
    环境: ${process.env.NODE_ENV || 'development'}
    版本: ${require('../package.json').version || '1.0.0'}
    端口: ${process.env.SERVER_PORT || '3000'}
    主机: ${process.env.SERVER_HOST || 'localhost'}
    ============================================
  `;
  
  console.log(banner);
}

/**
 * 初始化应用程序
 * @returns {Promise<void>}
 */
async function initializeApp() {
  try {
    // 显示启动横幅
    displayBanner();
    
    // 执行预启动检查
    const { checks, warnings } = preStartChecks();
    
    // 显示检查结果
    if (warnings.length > 0) {
      console.warn('⚠️  预启动检查警告:');
      warnings.forEach(warning => console.warn(`   - ${warning}`));
    }
    
    // 动态导入应用程序模块
    const { startServer } = require('./app');
    
    // 启动服务器
    await startServer();
    
    const log = getLogger();
    log.info('数据分析服务启动成功');
    
  } catch (error) {
    console.error('❌ 数据分析服务启动失败:');
    console.error(error);
    
    // 尝试使用日志记录错误
    try {
      const log = getLogger();
      log.error('服务启动失败', {
        error: error.message,
        stack: error.stack
      });
    } catch (logError) {
      // 日志初始化失败时使用控制台
      console.error('日志系统初始化失败:', logError);
    }
    
    // 退出进程
    process.exit(1);
  }
}

/**
 * 主函数
 */
function main() {
  // 设置未捕获异常处理
  process.on('uncaughtException', (error) => {
    console.error('❌ 未捕获的异常:');
    console.error(error);
    
    try {
      const log = getLogger();
      log.fatal('未捕获的异常', {
        error: error.message,
        stack: error.stack
      });
    } catch (logError) {
      console.error('日志记录失败:', logError);
    }
    
    process.exit(1);
  });
  
  // 设置未处理的Promise拒绝处理
  process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ 未处理的Promise拒绝:');
    console.error(reason);
    
    try {
      const log = getLogger();
      log.fatal('未处理的Promise拒绝', {
        reason: reason?.message || String(reason),
        stack: reason?.stack || 'No stack available'
      });
    } catch (logError) {
      console.error('日志记录失败:', logError);
    }
    
    // 非生产环境下退出
    if (process.env.NODE_ENV !== 'production') {
      process.exit(1);
    }
  });
  
  // 设置内存使用监控
  if (process.env.ENABLE_MEMORY_MONITOR === 'true') {
    setInterval(() => {
      const memoryUsage = process.memoryUsage();
      const log = getLogger();
      
      log.debug('内存使用情况', {
        rss: `${Math.round(memoryUsage.rss / 1024 / 1024)} MB`,
        heapUsed: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)} MB`,
        heapTotal: `${Math.round(memoryUsage.heapTotal / 1024 / 1024)} MB`
      });
    }, 60000); // 每分钟检查一次
  }
  
  // 启动应用
  initializeApp();
}

// 执行主函数
if (require.main === module) {
  main();
}

// 导出主要功能，用于测试和集成
module.exports = {
  initializeApp,
  preStartChecks,
  displayBanner
};