/**
 * 数据分析模块 - 路由配置
 * 定义数据分析服务的API路由
 */

const express = require('express');
const router = express.Router();

// 导入控制器
const AnalyticsController = require('../controllers/AnalyticsController');

// 导入中间件
const authMiddleware = require('../middleware/authMiddleware');
const validationMiddleware = require('../middleware/validationMiddleware');

/**
 * 操作日志记录相关路由
 */
router.post('/logs/operation', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateBody({
    operation: validationMiddleware.Joi.string().required().description('操作类型'),
    resourceType: validationMiddleware.Joi.string().required().description('资源类型'),
    resourceId: validationMiddleware.Joi.string().required().description('资源ID'),
    userId: validationMiddleware.Joi.string().required().description('操作用户ID'),
    ipAddress: validationMiddleware.Joi.string().description('IP地址'),
    details: validationMiddleware.Joi.object().description('详细信息'),
    status: validationMiddleware.Joi.string().valid('success', 'error', 'warning').default('success').description('操作状态')
  }),
  AnalyticsController.logOperation
);

router.get('/logs/operation', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateQuery({
    startDate: validationMiddleware.Joi.date().iso().description('开始日期'),
    endDate: validationMiddleware.Joi.date().iso().description('结束日期'),
    operation: validationMiddleware.Joi.string().description('操作类型'),
    userId: validationMiddleware.Joi.string().description('用户ID'),
    status: validationMiddleware.Joi.string().valid('success', 'error', 'warning').description('操作状态'),
    page: validationMiddleware.Joi.number().integer().min(1).default(1).description('页码'),
    limit: validationMiddleware.Joi.number().integer().min(1).max(100).default(10).description('每页记录数')
  }),
  AnalyticsController.getOperationLogs
);

router.get('/logs/operation/:logId', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateParams({ logId: validationMiddleware.Joi.string().required().description('日志ID') }),
  AnalyticsController.getOperationLogById
);

/**
 * 统计数据相关路由
 */
router.get('/statistics', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateQuery({
    metric: validationMiddleware.Joi.string().valid('cards', 'users', 'transactions', 'logins').required().description('统计指标'),
    period: validationMiddleware.Joi.string().valid('daily', 'weekly', 'monthly', 'yearly').default('daily').description('统计周期'),
    startDate: validationMiddleware.Joi.date().iso().description('开始日期'),
    endDate: validationMiddleware.Joi.date().iso().description('结束日期'),
    groupBy: validationMiddleware.Joi.string().description('分组字段')
  }),
  AnalyticsController.getStatistics
);

router.post('/statistics/aggregate', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateBody({
    pipeline: validationMiddleware.Joi.array().required().description('聚合管道'),
    collection: validationMiddleware.Joi.string().required().description('集合名称')
  }),
  AnalyticsController.aggregateData
);

router.post('/statistics/update', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin']),
  validationMiddleware.validateBody({
    metric: validationMiddleware.Joi.string().required().description('统计指标'),
    value: validationMiddleware.Joi.number().required().description('统计值'),
    period: validationMiddleware.Joi.string().valid('daily', 'weekly', 'monthly', 'yearly').required().description('统计周期'),
    timestamp: validationMiddleware.Joi.date().iso().default(Date.now()).description('时间戳')
  }),
  AnalyticsController.updateStatistic
);

/**
 * 趋势数据相关路由
 */
router.get('/trends', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateQuery({
    metric: validationMiddleware.Joi.string().required().description('指标名称'),
    resolution: validationMiddleware.Joi.string().valid('hourly', 'daily', 'weekly').default('daily').description('时间分辨率'),
    startDate: validationMiddleware.Joi.date().iso().description('开始日期'),
    endDate: validationMiddleware.Joi.date().iso().description('结束日期'),
    filters: validationMiddleware.Joi.object().description('过滤条件')
  }),
  AnalyticsController.getTrends
);

router.post('/trends/analyze', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateBody({
    metric: validationMiddleware.Joi.string().required().description('指标名称'),
    timeRange: validationMiddleware.Joi.object({
      start: validationMiddleware.Joi.date().iso().required(),
      end: validationMiddleware.Joi.date().iso().required()
    }).required(),
    compareWith: validationMiddleware.Joi.string().valid('previousPeriod', 'samePeriodLastWeek', 'samePeriodLastMonth').description('比较基准'),
    anomalyDetection: validationMiddleware.Joi.boolean().default(false).description('是否启用异常检测')
  }),
  AnalyticsController.analyzeTrends
);

/**
 * 告警管理相关路由
 */
router.get('/alerts', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateQuery({
    severity: validationMiddleware.Joi.string().valid('high', 'medium', 'low').description('告警级别'),
    status: validationMiddleware.Joi.string().valid('active', 'resolved', 'acknowledged').description('告警状态'),
    startDate: validationMiddleware.Joi.date().iso().description('开始日期'),
    endDate: validationMiddleware.Joi.date().iso().description('结束日期'),
    page: validationMiddleware.Joi.number().integer().min(1).default(1).description('页码'),
    limit: validationMiddleware.Joi.number().integer().min(1).max(100).default(10).description('每页记录数')
  }),
  AnalyticsController.getAlerts
);

router.post('/alerts', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateBody({
    title: validationMiddleware.Joi.string().required().description('告警标题'),
    description: validationMiddleware.Joi.string().required().description('告警描述'),
    severity: validationMiddleware.Joi.string().valid('high', 'medium', 'low').required().description('告警级别'),
    source: validationMiddleware.Joi.string().required().description('告警源'),
    details: validationMiddleware.Joi.object().description('详细信息')
  }),
  AnalyticsController.createAlert
);

router.put('/alerts/:alertId/status', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateParams({ alertId: validationMiddleware.Joi.string().required().description('告警ID') }),
  validationMiddleware.validateBody({
    status: validationMiddleware.Joi.string().valid('active', 'resolved', 'acknowledged').required().description('新状态'),
    resolutionNotes: validationMiddleware.Joi.string().description('解决说明')
  }),
  AnalyticsController.updateAlertStatus
);

router.get('/alerts/:alertId', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateParams({ alertId: validationMiddleware.Joi.string().required().description('告警ID') }),
  AnalyticsController.getAlertById
);

/**
 * 用户行为相关路由
 */
router.post('/user-behavior', 
  authMiddleware.authenticateJWT,
  validationMiddleware.validateBody({
    userId: validationMiddleware.Joi.string().required().description('用户ID'),
    action: validationMiddleware.Joi.string().required().description('行为动作'),
    resourceType: validationMiddleware.Joi.string().description('资源类型'),
    resourceId: validationMiddleware.Joi.string().description('资源ID'),
    details: validationMiddleware.Joi.object().description('详细信息')
  }),
  AnalyticsController.logUserBehavior
);

router.get('/user-behavior/:userId', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateParams({ userId: validationMiddleware.Joi.string().required().description('用户ID') }),
  validationMiddleware.validateQuery({
    startDate: validationMiddleware.Joi.date().iso().description('开始日期'),
    endDate: validationMiddleware.Joi.date().iso().description('结束日期'),
    actions: validationMiddleware.Joi.array().items(validationMiddleware.Joi.string()).description('行为类型过滤'),
    page: validationMiddleware.Joi.number().integer().min(1).default(1).description('页码'),
    limit: validationMiddleware.Joi.number().integer().min(1).max(100).default(10).description('每页记录数')
  }),
  AnalyticsController.getUserBehavior
);

router.post('/user-behavior/anomalies', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateBody({
    detectionRules: validationMiddleware.Joi.array().items(validationMiddleware.Joi.object()).description('检测规则'),
    timeRange: validationMiddleware.Joi.object({
      start: validationMiddleware.Joi.date().iso().required(),
      end: validationMiddleware.Joi.date().iso().required()
    }).required(),
    userId: validationMiddleware.Joi.string().description('特定用户ID')
  }),
  AnalyticsController.detectAnomalies
);

/**
 * 报告生成相关路由
 */
router.post('/reports/generate', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateBody({
    reportType: validationMiddleware.Joi.string().required().description('报告类型'),
    parameters: validationMiddleware.Joi.object().required().description('报告参数'),
    format: validationMiddleware.Joi.string().valid('json', 'csv', 'pdf').default('json').description('输出格式'),
    scheduled: validationMiddleware.Joi.boolean().default(false).description('是否为计划报告'),
    schedule: validationMiddleware.Joi.object().description('调度信息')
  }),
  AnalyticsController.generateReport
);

router.get('/reports/:reportId', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateParams({ reportId: validationMiddleware.Joi.string().required().description('报告ID') }),
  AnalyticsController.getReport
);

router.get('/reports', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin', 'analyst']),
  validationMiddleware.validateQuery({
    reportType: validationMiddleware.Joi.string().description('报告类型'),
    status: validationMiddleware.Joi.string().valid('pending', 'completed', 'failed').description('报告状态'),
    startDate: validationMiddleware.Joi.date().iso().description('开始日期'),
    endDate: validationMiddleware.Joi.date().iso().description('结束日期'),
    page: validationMiddleware.Joi.number().integer().min(1).default(1).description('页码'),
    limit: validationMiddleware.Joi.number().integer().min(1).max(100).default(10).description('每页记录数')
  }),
  AnalyticsController.listReports
);

/**
 * 配置管理相关路由
 */
router.get('/config', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin']),
  AnalyticsController.getAnalyticsConfig
);

router.put('/config', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin']),
  validationMiddleware.validateBody({
    thresholds: validationMiddleware.Joi.object().description('告警阈值'),
    retention: validationMiddleware.Joi.object().description('数据保留策略'),
    detection: validationMiddleware.Joi.object().description('异常检测配置')
  }),
  AnalyticsController.updateAnalyticsConfig
);

/**
 * 健康检查路由
 */
router.get('/health', 
  AnalyticsController.healthCheck
);

/**
 * 批量操作路由
 */
router.post('/batch/logs', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin']),
  validationMiddleware.validateBody({
    logs: validationMiddleware.Joi.array().min(1).required().description('批量日志数据')
  }),
  AnalyticsController.batchLogOperations
);

router.post('/batch/statistics', 
  authMiddleware.authenticateJWT,
  authMiddleware.authorizeRoles(['admin']),
  validationMiddleware.validateBody({
    statistics: validationMiddleware.Joi.array().min(1).required().description('批量统计数据')
  }),
  AnalyticsController.batchUpdateStatistics
);

module.exports = router;