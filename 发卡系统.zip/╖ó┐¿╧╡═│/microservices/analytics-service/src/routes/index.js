/**
 * 数据分析模块 - 主路由配置
 * 整合所有API路由并设置全局中间件
 */

const express = require('express');
const router = express.Router();
const logger = require('../utils/logger');
const appConfig = require('../config/app');
const securityConfig = appConfig.getSecurityConfig();

// 导入子路由
const analyticsRoutes = require('./analyticsRoutes');

/**
 * 请求日志中间件
 */
const requestLoggerMiddleware = (req, res, next) => {
  const startTime = Date.now();
  const { method, originalUrl, headers, body } = req;
  
  // 创建请求日志对象，过滤敏感信息
  const logData = {
    method,
    url: originalUrl,
    ip: req.ip,
    userAgent: headers['user-agent'],
    userId: req.user?.id || 'unauthenticated'
  };
  
  // 只有在调试模式下才记录请求体
  if (appConfig.getConfig().app.debug) {
    // 过滤请求体中的敏感信息
    const sanitizedBody = { ...body };
    const sensitiveFields = ['password', 'token', 'secret', 'key'];
    
    sensitiveFields.forEach(field => {
      if (sanitizedBody[field]) {
        sanitizedBody[field] = '***REDACTED***';
      }
    });
    
    logData.bodyPreview = Object.keys(sanitizedBody).length > 0 ? sanitizedBody : undefined;
  }
  
  logger.info('接收到API请求', logData);
  
  // 保存原始的res.json方法
  const originalJson = res.json;
  
  // 重写res.json方法以记录响应
  res.json = function(data) {
    const responseTime = Date.now() - startTime;
    const responseLog = {
      statusCode: res.statusCode,
      responseTime,
      url: originalUrl,
      method,
      userId: req.user?.id || 'unauthenticated'
    };
    
    // 根据状态码选择日志级别
    if (res.statusCode >= 500) {
      logger.error('API请求失败', responseLog);
    } else if (res.statusCode >= 400) {
      logger.warn('API请求错误', responseLog);
    } else {
      logger.debug('API请求成功', responseLog);
    }
    
    // 调用原始的res.json方法
    return originalJson.call(this, data);
  };
  
  next();
};

/**
 * CORS配置中间件
 */
const corsMiddleware = (req, res, next) => {
  const allowedOrigins = securityConfig.allowedOrigins || ['*'];
  const origin = req.headers.origin;
  
  // 检查请求源是否在允许列表中
  if (allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', allowedOrigins.includes('*') ? '*' : origin);
    
    // 设置CORS相关头部
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Expose-Headers', 'Content-Length, X-Total-Count, X-Pagination');
    res.header('Access-Control-Allow-Credentials', 'true');
    
    // 处理预检请求
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
  }
  
  next();
};

/**
 * 请求ID中间件
 */
const requestIdMiddleware = (req, res, next) => {
  // 生成请求ID或使用现有ID
  const requestId = req.headers['x-request-id'] || generateRequestId();
  
  // 设置请求ID到请求和响应
  req.requestId = requestId;
  res.header('X-Request-ID', requestId);
  
  next();
};

/**
 * 生成唯一的请求ID
 * @returns {string} 请求ID
 */
function generateRequestId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * 响应时间中间件
 */
const responseTimeMiddleware = (req, res, next) => {
  const start = Date.now();
  
  // 在响应完成时设置响应时间头部
  res.on('finish', () => {
    const duration = Date.now() - start;
    res.setHeader('X-Response-Time', `${duration}ms`);
  });
  
  next();
};

/**
 * 限制请求大小中间件
 */
const requestSizeLimiterMiddleware = (req, res, next) => {
  const maxSize = appConfig.getServerConfig().maxRequestSize || '10mb';
  let receivedBytes = 0;
  
  // 监听data事件以跟踪接收的字节数
  req.on('data', (chunk) => {
    receivedBytes += chunk.length;
    
    // 检查是否超过最大大小
    if (receivedBytes > parseBytes(maxSize)) {
      logger.warn('请求体过大', {
        limit: maxSize,
        received: `${receivedBytes} bytes`,
        url: req.originalUrl,
        method: req.method
      });
      
      res.status(413).json({
        success: false,
        message: '请求体过大',
        errorCode: 413
      });
      
      // 终止请求
      req.destroy();
    }
  });
  
  next();
};

/**
 * 将大小字符串转换为字节数
 * @param {string} size - 大小字符串 (如 '10mb', '500kb')
 * @returns {number} 字节数
 */
function parseBytes(size) {
  const units = {
    b: 1,
    kb: 1024,
    mb: 1024 * 1024,
    gb: 1024 * 1024 * 1024
  };
  
  const match = size.toLowerCase().match(/^([0-9.]+)\s*([bkmgt]b?)$/);
  if (!match) return 10 * 1024 * 1024; // 默认10MB
  
  const [, value, unit] = match;
  return parseFloat(value) * (units[unit] || units.b);
}

/**
 * 路径规范化中间件
 */
const normalizePathMiddleware = (req, res, next) => {
  // 移除尾部斜杠（除了根路径）
  if (req.path !== '/' && req.path.slice(-1) === '/') {
    const query = req.url.slice(req.path.length);
    res.redirect(301, req.path.slice(0, -1) + query);
    return;
  }
  
  next();
};

/**
 * API版本控制中间件
 */
const versionMiddleware = (req, res, next) => {
  // 从URL路径中提取版本信息
  const versionMatch = req.originalUrl.match(/\/api\/v(\d+)/);
  const apiVersion = versionMatch ? parseInt(versionMatch[1], 10) : 1; // 默认版本1
  
  // 将版本信息存储在请求对象中
  req.apiVersion = apiVersion;
  res.setHeader('API-Version', apiVersion);
  
  logger.debug('API版本确定', {
    version: apiVersion,
    url: req.originalUrl
  });
  
  next();
};

/**
 * 设置全局中间件
 */
const setupGlobalMiddleware = () => {
  // 路径规范化
  router.use(normalizePathMiddleware);
  
  // 请求ID
  router.use(requestIdMiddleware);
  
  // 如果启用CORS
  if (appConfig.getServerConfig().enableCors) {
    router.use(corsMiddleware);
  }
  
  // 响应时间
  router.use(responseTimeMiddleware);
  
  // 请求大小限制
  router.use(requestSizeLimiterMiddleware);
  
  // API版本控制
  router.use(versionMiddleware);
  
  // 请求日志
  if (appConfig.getConfig().app.environment !== 'test') {
    router.use(requestLoggerMiddleware);
  }
};

/**
 * 注册所有路由
 */
const registerRoutes = () => {
  const apiPrefix = appConfig.getConfig().api.prefix || '/api/v1';
  
  // 注册API路由
  router.use(apiPrefix, analyticsRoutes);
  
  // 404处理
  router.use((req, res, next) => {
    logger.warn('API端点不存在', {
      url: req.originalUrl,
      method: req.method,
      ip: req.ip
    });
    
    res.status(404).json({
      success: false,
      message: `API端点不存在: ${req.originalUrl}`,
      errorCode: 404,
      timestamp: new Date().toISOString()
    });
  });
  
  logger.info('所有API路由已注册', {
    apiPrefix,
    environment: appConfig.getConfig().app.environment
  });
};

/**
 * 初始化路由
 */
const initializeRoutes = () => {
  setupGlobalMiddleware();
  registerRoutes();
  
  return router;
};

/**
 * 导出初始化的路由
 */
module.exports = initializeRoutes();