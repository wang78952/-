/**
 * 数据分析模块 - 主应用程序
 * 初始化Express应用并集成所有组件
 */

const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const bodyParser = require('body-parser');
const rateLimit = require('express-rate-limit');
const logger = require('./utils/logger');
const appConfig = require('./config/app');
const { initializeDB, isDBConnected } = require('./config/db');
const routes = require('./routes');
const errorMiddleware = require('./middleware/errorMiddleware');

class AnalyticsService {
  constructor() {
    this.app = express();
    this.server = null;
    this.config = appConfig.getConfig();
    this.isInitialized = false;
  }

  /**
   * 初始化应用程序
   * @returns {Promise<void>}
   */
  async initialize() {
    try {
      logger.info('开始初始化数据分析服务...');
      
      // 初始化数据库连接
      await this.initializeDatabase();
      
      // 配置Express应用
      this.setupExpress();
      
      // 设置安全中间件
      this.setupSecurity();
      
      // 配置请求处理中间件
      this.setupRequestProcessing();
      
      // 设置速率限制
      this.setupRateLimiting();
      
      // 注册路由
      this.registerRoutes();
      
      // 设置错误处理
      this.setupErrorHandling();
      
      // 配置优雅关闭
      this.setupGracefulShutdown();
      
      this.isInitialized = true;
      logger.info('数据分析服务初始化完成');
      
    } catch (error) {
      logger.error('数据分析服务初始化失败', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * 初始化数据库连接
   * @returns {Promise<void>}
   */
  async initializeDatabase() {
    logger.info('正在初始化数据库连接...');
    await initializeDB();
    logger.info('数据库连接初始化完成');
  }

  /**
   * 设置Express应用程序
   */
  setupExpress() {
    // 配置信任代理
    this.app.set('trust proxy', true);
    
    // 设置JSON解析限制
    const maxRequestSize = this.config.server.maxRequestSize || '10mb';
    
    // 配置body解析器
    this.app.use(bodyParser.json({ 
      limit: maxRequestSize,
      type: ['application/json', 'application/*+json']
    }));
    
    this.app.use(bodyParser.urlencoded({ 
      extended: true,
      limit: maxRequestSize
    }));
    
    // 配置静态文件服务（如果需要）
    if (this.config.files.enableStaticServe) {
      const staticPath = this.config.files.uploadDir || './uploads';
      this.app.use('/static', express.static(staticPath));
      logger.info('静态文件服务已启用', { path: staticPath });
    }
    
    // 设置应用程序名称
    this.app.set('name', this.config.app.name);
    
    // 设置X-Powered-By头部
    this.app.set('x-powered-by', false);
    
    logger.info('Express应用程序配置完成', {
      maxRequestSize
    });
  }

  /**
   * 设置安全中间件
   */
  setupSecurity() {
    if (this.config.security.enableHelmet) {
      // 配置Helmet安全头部
      this.app.use(helmet({
        contentSecurityPolicy: {
          directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'"],
            styleSrc: ["'self'"],
            imgSrc: ["'self'"],
            connectSrc: ["'self'", this.config.externalServices.cardServiceUrl, 
                        this.config.externalServices.userServiceUrl, 
                        this.config.externalServices.notificationServiceUrl]
          }
        },
        xFrameOptions: {
          action: 'deny'
        },
        xXssProtection: {
          setOnOldIE: true,
          value: 1
        }
      }));
      
      logger.info('安全中间件已配置');
    }
    
    // 设置其他安全头部
    this.app.use((req, res, next) => {
      // 设置内容类型选项
      res.setHeader('X-Content-Type-Options', 'nosniff');
      
      // 设置Referrer策略
      res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
      
      // 设置Permissions策略
      res.setHeader('Permissions-Policy', 'geolocation=(), camera=(), microphone=()');
      
      next();
    });
  }

  /**
   * 设置请求处理中间件
   */
  setupRequestProcessing() {
    // 如果启用了压缩
    if (this.config.server.enableCompression) {
      this.app.use(compression({
        level: 6,
        threshold: 1024, // 1KB以上才压缩
        filter: (req, res) => {
          // 不压缩某些类型的响应
          if (req.headers['content-type'] && 
              req.headers['content-type'].includes('image/')) {
            return false;
          }
          return compression.filter(req, res);
        }
      }));
      
      logger.info('响应压缩已启用');
    }
    
    // 自定义请求处理中间件
    this.app.use((req, res, next) => {
      // 设置默认内容类型
      if (!req.headers.accept) {
        req.headers.accept = 'application/json';
      }
      
      // 确保响应为JSON
      res.setHeader('Content-Type', 'application/json');
      
      next();
    });
  }

  /**
   * 设置速率限制
   */
  setupRateLimiting() {
    if (this.config.security.enableRateLimiting) {
      const limiter = rateLimit({
        windowMs: this.config.api.rateLimitWindowMs || 60 * 1000, // 默认1分钟
        max: this.config.api.rateLimitMax || 100, // 默认每分钟100个请求
        standardHeaders: true,
        legacyHeaders: false,
        message: {
          success: false,
          message: '请求频率过高，请稍后再试',
          errorCode: 429
        },
        keyGenerator: (req) => {
          // 使用用户ID或IP作为限流键
          return req.user?.id || req.ip;
        },
        skipSuccessfulRequests: false,
        handler: (req, res, options) => {
          logger.warn('速率限制触发', {
            ip: req.ip,
            userId: req.user?.id,
            path: req.path,
            limit: options.max,
            window: options.windowMs
          });
          
          res.status(options.statusCode).json(options.message);
        }
      });
      
      // 应用全局速率限制
      this.app.use(limiter);
      
      logger.info('速率限制已配置', {
        maxRequests: this.config.api.rateLimitMax,
        windowMs: this.config.api.rateLimitWindowMs
      });
    }
  }

  /**
   * 注册路由
   */
  registerRoutes() {
    // 注册主路由
    this.app.use(routes);
    
    logger.info('API路由注册完成');
  }

  /**
   * 设置错误处理
   */
  setupErrorHandling() {
    // 配置全局错误处理
    errorMiddleware.configureErrorHandlers(this.app);
    
    // 注册进程级错误处理
    errorMiddleware.handleUncaughtExceptions();
    errorMiddleware.handleUnhandledRejections();
    
    logger.info('错误处理配置完成');
  }

  /**
   * 设置优雅关闭
   */
  setupGracefulShutdown() {
    const shutdownTimeout = this.config.server.gracefulShutdownTimeout || 10000;
    
    // 处理终止信号
    const handleShutdown = async (signal) => {
      logger.info(`接收到${signal}信号，正在优雅关闭服务...`);
      
      try {
        // 设置超时，确保服务能够终止
        const timeoutId = setTimeout(() => {
          logger.error('优雅关闭超时，强制退出');
          process.exit(1);
        }, shutdownTimeout);
        
        // 关闭HTTP服务器
        if (this.server) {
          await new Promise((resolve, reject) => {
            this.server.close((error) => {
              if (error) {
                reject(error);
              } else {
                resolve();
              }
            });
          });
        }
        
        // 清理超时
        clearTimeout(timeoutId);
        
        logger.info('数据分析服务已优雅关闭');
        process.exit(0);
        
      } catch (error) {
        logger.error('关闭服务时出错', {
          error: error.message
        });
        process.exit(1);
      }
    };
    
    // 监听终止信号
    process.on('SIGINT', () => handleShutdown('SIGINT'));
    process.on('SIGTERM', () => handleShutdown('SIGTERM'));
    
    logger.info('优雅关闭配置完成', {
      timeout: shutdownTimeout
    });
  }

  /**
   * 启动服务器
   * @returns {Promise<void>}
   */
  async start() {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    const { port, host } = this.config.server;
    
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(port, host, () => {
        logger.info('数据分析服务已启动', {
          port,
          host,
          environment: this.config.app.environment
        });
        
        // 健康状态检查
        this.checkHealth();
        
        resolve();
      });
      
      // 监听服务器错误
      this.server.on('error', (error) => {
        logger.error('服务器启动失败', {
          error: error.message,
          code: error.code
        });
        reject(error);
      });
      
      // 监听连接错误
      this.server.on('connection', (socket) => {
        // 设置连接超时
        socket.setTimeout(30000);
      });
    });
  }

  /**
   * 检查服务健康状态
   */
  async checkHealth() {
    try {
      const healthStatus = {
        databaseConnected: isDBConnected(),
        environment: this.config.app.environment,
        version: this.config.app.version
      };
      
      logger.info('服务健康检查', healthStatus);
      
    } catch (error) {
      logger.error('健康检查失败', {
        error: error.message
      });
    }
  }

  /**
   * 获取Express应用实例
   * @returns {Object} Express应用实例
   */
  getApp() {
    return this.app;
  }

  /**
   * 获取服务器实例
   * @returns {Object} HTTP服务器实例
   */
  getServer() {
    return this.server;
  }

  /**
   * 获取服务配置
   * @returns {Object} 服务配置
   */
  getConfig() {
    return this.config;
  }

  /**
   * 停止服务
   * @returns {Promise<void>}
   */
  async stop() {
    try {
      logger.info('正在停止数据分析服务...');
      
      if (this.server) {
        await new Promise((resolve) => {
          this.server.close(() => {
            logger.info('HTTP服务器已关闭');
            resolve();
          });
        });
      }
      
      this.isInitialized = false;
      logger.info('数据分析服务已停止');
      
    } catch (error) {
      logger.error('停止服务时出错', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 注册自定义中间件
   * @param {Function} middleware - 中间件函数
   * @param {string} [name] - 中间件名称
   */
  registerMiddleware(middleware, name) {
    if (name) {
      logger.info(`注册自定义中间件: ${name}`);
    }
    
    this.app.use(middleware);
  }

  /**
   * 注册自定义路由
   * @param {string} path - 路由路径
   * @param {Object} router - Express路由对象
   */
  registerCustomRoute(path, router) {
    logger.info(`注册自定义路由: ${path}`);
    this.app.use(path, router);
  }
}

// 创建单例实例
const analyticsService = new AnalyticsService();

// 导出应用实例和启动函数
module.exports = {
  analyticsService,
  app: analyticsService.getApp(),
  startServer: () => analyticsService.start(),
  stopServer: () => analyticsService.stop()
};