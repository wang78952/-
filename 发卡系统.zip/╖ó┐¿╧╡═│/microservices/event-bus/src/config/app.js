const dotenv = require('dotenv');
const Joi = require('joi');
const path = require('path');

/**
 * 应用配置管理类
 * 负责加载、验证和提供配置项
 */
class ConfigManager {
  constructor() {
    this.config = {};
    this.schema = this.createValidationSchema();
    this.loadConfig();
  }

  /**
   * 加载配置
   */
  loadConfig() {
    // 加载.env文件
    const envPath = path.resolve(process.cwd(), '.env');
    const result = dotenv.config({ path: envPath });
    
    if (result.error) {
      console.warn(`No .env file found at ${envPath}, using environment variables`);
    }

    // 合并环境变量
    this.config = {
      // 服务器配置
      PORT: process.env.PORT || 3002,
      HOST: process.env.HOST || '0.0.0.0',
      NODE_ENV: process.env.NODE_ENV || 'development',
      API_PREFIX: process.env.API_PREFIX || '/api/v1',
      
      // 数据库配置
      MONGO_URI: process.env.MONGO_URI || 'mongodb://localhost:27017/event_bus',
      MONGO_OPTIONS: process.env.MONGO_OPTIONS || 'retryWrites=true&w=majority',
      
      // Redis配置
      REDIS_URI: process.env.REDIS_URI || 'redis://localhost:6379/0',
      REDIS_PASSWORD: process.env.REDIS_PASSWORD || '',
      REDIS_PREFIX: process.env.REDIS_PREFIX || 'event_bus:',
      
      // RabbitMQ配置
      RABBITMQ_URI: process.env.RABBITMQ_URI || 'amqp://guest:guest@localhost:5672/',
      RABBITMQ_EXCHANGE: process.env.RABBITMQ_EXCHANGE || 'event_bus_exchange',
      RABBITMQ_EXCHANGE_TYPE: process.env.RABBITMQ_EXCHANGE_TYPE || 'topic',
      RABBITMQ_QUEUE_PREFIX: process.env.RABBITMQ_QUEUE_PREFIX || 'event_bus_',
      RABBITMQ_RECONNECT_INTERVAL: parseInt(process.env.RABBITMQ_RECONNECT_INTERVAL) || 5000,
      RABBITMQ_CONNECTION_TIMEOUT: parseInt(process.env.RABBITMQ_CONNECTION_TIMEOUT) || 30000,
      
      // 认证配置
      AUTH_SERVICE_URL: process.env.AUTH_SERVICE_URL || 'http://localhost:3000/api/v1',
      AUTH_ENABLED: process.env.AUTH_ENABLED === 'true',
      JWT_SECRET: process.env.JWT_SECRET || 'your_jwt_secret_key_here',
      JWT_EXPIRY: parseInt(process.env.JWT_EXPIRY) || 3600,
      
      // 监控配置
      MONITORING_ENABLED: process.env.MONITORING_ENABLED === 'true',
      METRICS_COLLECTION_INTERVAL: parseInt(process.env.METRICS_COLLECTION_INTERVAL) || 60000,
      HEALTH_CHECK_INTERVAL: parseInt(process.env.HEALTH_CHECK_INTERVAL) || 30000,
      
      // 告警配置
      ALERTING_ENABLED: process.env.ALERTING_ENABLED === 'true',
      ALERT_SERVICE_URL: process.env.ALERT_SERVICE_URL || 'http://localhost:3001/api/v1',
      MAX_RETRY_ATTEMPTS: parseInt(process.env.MAX_RETRY_ATTEMPTS) || 3,
      RETRY_DELAY: parseInt(process.env.RETRY_DELAY) || 2000,
      
      // 日志配置
      LOG_LEVEL: process.env.LOG_LEVEL || 'info',
      LOG_DIR: process.env.LOG_DIR || './logs',
      LOG_ROTATION: process.env.LOG_ROTATION === 'true',
      LOG_MAX_SIZE: process.env.LOG_MAX_SIZE || '20m',
      LOG_MAX_FILES: process.env.LOG_MAX_FILES || '14d',
      
      // CORS配置
      CORS_ORIGIN: process.env.CORS_ORIGIN || '*',
      CORS_METHODS: process.env.CORS_METHODS || 'GET,POST,PUT,DELETE,PATCH,OPTIONS',
      CORS_ALLOWED_HEADERS: process.env.CORS_ALLOWED_HEADERS || 'Origin,X-Requested-With,Content-Type,Accept,Authorization',
      CORS_CREDENTIALS: process.env.CORS_CREDENTIALS === 'true',
      
      // 请求配置
      JSON_BODY_LIMIT: process.env.JSON_BODY_LIMIT || '1mb',
      URL_ENCODED_LIMIT: process.env.URL_ENCODED_LIMIT || '1mb',
      REQUEST_TIMEOUT: parseInt(process.env.REQUEST_TIMEOUT) || 30000,
      
      // 服务配置
      SERVICE_NAME: process.env.SERVICE_NAME || 'event-bus-service',
      SERVICE_ID: process.env.SERVICE_ID || 'event-bus-service-1',
      SERVICE_VERSION: process.env.SERVICE_VERSION || '1.0.0',
      
      // 性能配置
      CACHE_TTL: parseInt(process.env.CACHE_TTL) || 3600000,
      EVENT_PROCESSING_TIMEOUT: parseInt(process.env.EVENT_PROCESSING_TIMEOUT) || 10000,
      MAX_CONCURRENT_PROCESSING: parseInt(process.env.MAX_CONCURRENT_PROCESSING) || 10,
      MAX_QUEUE_SIZE: parseInt(process.env.MAX_QUEUE_SIZE) || 1000,
      
      // 限流配置
      RATE_LIMIT_ENABLED: process.env.RATE_LIMIT_ENABLED === 'true',
      RATE_LIMIT_WINDOW_MS: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 60000,
      RATE_LIMIT_MAX: parseInt(process.env.RATE_LIMIT_MAX) || 100,
      
      // 队列配置
      QUEUE_TYPE: process.env.QUEUE_TYPE || 'rabbitmq',
      QUEUE_PREFETCH_COUNT: parseInt(process.env.QUEUE_PREFETCH_COUNT) || 5,
      QUEUE_PERSISTENT: process.env.QUEUE_PERSISTENT === 'true',
      
      // 事件配置
      EVENT_VALIDATION_ENABLED: process.env.EVENT_VALIDATION_ENABLED === 'true',
      EVENT_SCHEMA_CACHE_TTL: parseInt(process.env.EVENT_SCHEMA_CACHE_TTL) || 3600000,
    };

    // 根据环境加载特定配置
    this.loadEnvironmentSpecificConfig();

    // 验证配置
    this.validateConfig();
  }

  /**
   * 加载环境特定配置
   */
  loadEnvironmentSpecificConfig() {
    const env = this.config.NODE_ENV;
    
    switch (env) {
      case 'development':
        this.config.LOG_LEVEL = process.env.DEV_LOG_LEVEL || 'debug';
        this.config.RABBITMQ_URI = process.env.DEV_RABBITMQ_URI || this.config.RABBITMQ_URI;
        break;
      case 'test':
        this.config.MONGO_URI = process.env.TEST_MONGO_URI || 'mongodb://localhost:27017/event_bus_test';
        this.config.RABBITMQ_URI = process.env.TEST_RABBITMQ_URI || this.config.RABBITMQ_URI;
        this.config.LOG_LEVEL = 'error';
        break;
      case 'production':
        this.config.RABBITMQ_URI = process.env.PROD_RABBITMQ_URI || this.config.RABBITMQ_URI;
        this.config.MONGO_URI = process.env.PROD_MONGO_URI || this.config.MONGO_URI;
        this.config.LOG_LEVEL = process.env.PROD_LOG_LEVEL || 'error';
        this.config.METRICS_COLLECTION_INTERVAL = parseInt(process.env.PROD_METRICS_COLLECTION_INTERVAL) || 300000;
        break;
      default:
        break;
    }
  }

  /**
   * 创建配置验证模式
   */
  createValidationSchema() {
    return Joi.object({
      PORT: Joi.number().integer().min(1024).max(65535).required(),
      HOST: Joi.string().required(),
      NODE_ENV: Joi.string().valid('development', 'test', 'production').required(),
      API_PREFIX: Joi.string().pattern(/^\/[^\s]+$/).required(),
      MONGO_URI: Joi.string().uri().required(),
      REDIS_URI: Joi.string().uri().required(),
      RABBITMQ_URI: Joi.string().uri().required(),
      RABBITMQ_EXCHANGE: Joi.string().required(),
      RABBITMQ_EXCHANGE_TYPE: Joi.string().valid('direct', 'topic', 'fanout', 'headers').required(),
      JWT_SECRET: Joi.string().when('AUTH_ENABLED', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional()
      }),
      LOG_LEVEL: Joi.string().valid('debug', 'info', 'warn', 'error', 'fatal').required(),
      SERVICE_NAME: Joi.string().required(),
      SERVICE_VERSION: Joi.string().required()
    });
  }

  /**
   * 验证配置
   */
  validateConfig() {
    const { error } = this.schema.validate(this.config, { abortEarly: false });
    
    if (error) {
      console.error('Configuration validation failed:');
      error.details.forEach(detail => {
        console.error(`  - ${detail.path.join('.')}: ${detail.message}`);
      });
      throw new Error('Invalid configuration');
    }
  }

  /**
   * 获取配置项
   * @param {string} key - 配置键名
   * @param {any} defaultValue - 默认值
   * @returns {any} 配置值
   */
  get(key, defaultValue = null) {
    if (key in this.config) {
      return this.config[key];
    }
    return defaultValue;
  }

  /**
   * 设置配置项（运行时）
   * @param {string} key - 配置键名
   * @param {any} value - 配置值
   */
  set(key, value) {
    this.config[key] = value;
  }

  /**
   * 获取所有配置
   * @returns {object} 所有配置
   */
  getAll() {
    return { ...this.config };
  }

  /**
   * 重新加载配置
   */
  reload() {
    this.loadConfig();
    return this.config;
  }

  /**
   * 检查配置是否存在
   * @param {string} key - 配置键名
   * @returns {boolean} 是否存在
   */
  has(key) {
    return key in this.config;
  }

  /**
   * 获取RabbitMQ完整配置
   * @returns {object} RabbitMQ配置
   */
  getRabbitMQConfig() {
    return {
      uri: this.config.RABBITMQ_URI,
      exchange: this.config.RABBITMQ_EXCHANGE,
      exchangeType: this.config.RABBITMQ_EXCHANGE_TYPE,
      queuePrefix: this.config.RABBITMQ_QUEUE_PREFIX,
      reconnectInterval: this.config.RABBITMQ_RECONNECT_INTERVAL,
      connectionTimeout: this.config.RABBITMQ_CONNECTION_TIMEOUT,
      prefetchCount: this.config.QUEUE_PREFETCH_COUNT,
      persistent: this.config.QUEUE_PERSISTENT
    };
  }

  /**
   * 获取MongoDB完整配置
   * @returns {object} MongoDB配置
   */
  getMongoDBConfig() {
    return {
      uri: this.config.MONGO_URI,
      options: {
        retryWrites: true,
        w: 'majority'
      }
    };
  }

  /**
   * 获取Redis完整配置
   * @returns {object} Redis配置
   */
  getRedisConfig() {
    return {
      uri: this.config.REDIS_URI,
      password: this.config.REDIS_PASSWORD,
      prefix: this.config.REDIS_PREFIX
    };
  }

  /**
   * 获取服务器配置
   * @returns {object} 服务器配置
   */
  getServerConfig() {
    return {
      port: this.config.PORT,
      host: this.config.HOST,
      apiPrefix: this.config.API_PREFIX,
      environment: this.config.NODE_ENV
    };
  }

  /**
   * 获取日志配置
   * @returns {object} 日志配置
   */
  getLoggerConfig() {
    return {
      level: this.config.LOG_LEVEL,
      dir: this.config.LOG_DIR,
      rotation: this.config.LOG_ROTATION,
      maxSize: this.config.LOG_MAX_SIZE,
      maxFiles: this.config.LOG_MAX_FILES,
      environment: this.config.NODE_ENV
    };
  }

  /**
   * 获取CORS配置
   * @returns {object} CORS配置
   */
  getCorsConfig() {
    return {
      origin: this.config.CORS_ORIGIN,
      methods: this.config.CORS_METHODS,
      allowedHeaders: this.config.CORS_ALLOWED_HEADERS,
      credentials: this.config.CORS_CREDENTIALS
    };
  }

  /**
   * 获取速率限制配置
   * @returns {object} 速率限制配置
   */
  getRateLimitConfig() {
    return {
      enabled: this.config.RATE_LIMIT_ENABLED,
      windowMs: this.config.RATE_LIMIT_WINDOW_MS,
      max: this.config.RATE_LIMIT_MAX
    };
  }

  /**
   * 获取事件处理配置
   * @returns {object} 事件处理配置
   */
  getEventProcessingConfig() {
    return {
      timeout: this.config.EVENT_PROCESSING_TIMEOUT,
      maxConcurrent: this.config.MAX_CONCURRENT_PROCESSING,
      maxQueueSize: this.config.MAX_QUEUE_SIZE,
      validationEnabled: this.config.EVENT_VALIDATION_ENABLED,
      schemaCacheTtl: this.config.EVENT_SCHEMA_CACHE_TTL
    };
  }

  /**
   * 获取重试策略配置
   * @returns {object} 重试策略配置
   */
  getRetryConfig() {
    return {
      maxAttempts: this.config.MAX_RETRY_ATTEMPTS,
      delay: this.config.RETRY_DELAY
    };
  }
}

// 导出单例实例
let configInstance = null;

function getInstance() {
  if (!configInstance) {
    configInstance = new ConfigManager();
  }
  return configInstance;
}

module.exports = {
  ConfigManager,
  getInstance
};