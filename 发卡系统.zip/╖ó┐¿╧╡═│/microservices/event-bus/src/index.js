#!/usr/bin/env node

const EventBusServer = require('./server');
const { getInstance: getLoggerInstance } = require('./utils/logger');
const { getInstance: getConfigInstance } = require('./config/app');

// 确保进程异常处理
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  console.error(error.stack);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
  process.exit(1);
});

/**
 * 事件总线微服务主入口函数
 */
async function startEventBusService() {
  let logger;
  let config;
  let server;
  
  try {
    // 初始化配置
    config = getConfigInstance();
    
    // 初始化日志器
    logger = getLoggerInstance();
    logger.info('Starting Event Bus Service...');
    
    // 打印启动信息
    logger.info('Service configuration loaded', {
      environment: config.get('NODE_ENV', 'development'),
      version: config.get('VERSION', '1.0.0'),
      port: config.get('PORT', 8080)
    });
    
    // 验证环境变量
    validateEnvironment();
    
    // 创建服务器实例
    server = new EventBusServer();
    
    // 启动服务器
    await server.start();
    
    logger.info('Event Bus Service started successfully!');
    
    // 记录启动成功
    recordStartupSuccess(server);
    
    return server;
    
  } catch (error) {
    // 如果日志器已初始化，使用日志器记录错误
    if (logger) {
      logger.error('Failed to start Event Bus Service', {
        error: error.message,
        stack: error.stack
      });
    } else {
      // 否则使用console记录错误
      console.error('Failed to start Event Bus Service:', error);
      console.error(error.stack);
    }
    
    // 退出进程
    process.exit(1);
  }
}

/**
 * 验证必需的环境变量
 */
function validateEnvironment() {
  const requiredEnvVars = [];
  
  // 检查必需的环境变量
  const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
  
  if (missingVars.length > 0) {
    throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
  }
}

/**
 * 记录启动成功
 */
function recordStartupSuccess(server) {
  const logger = getLoggerInstance();
  const status = server.getStatus();
  
  logger.info('Service startup complete', {
    port: status.port,
    host: status.host,
    environment: process.env.NODE_ENV || 'development',
    uptime: process.uptime()
  });
  
  // 打印启动信息到控制台
  console.log('========================================');
  console.log('  Event Bus Service - Started');
  console.log('========================================');
  console.log(`  Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`  Port: ${status.port}`);
  console.log(`  Host: ${status.host}`);
  console.log(`  Version: ${process.env.VERSION || '1.0.0'}`);
  console.log('========================================');
  console.log(`  API Documentation: http://${status.host}:${status.port}/api/docs`);
  console.log(`  Health Check: http://${status.host}:${status.port}/api/health`);
  console.log('========================================');
}

/**
 * 导出启动函数和相关组件
 */
module.exports = {
  startEventBusService,
  EventBusServer
};

// 如果直接运行此文件，则启动服务
if (require.main === module) {
  startEventBusService();
}