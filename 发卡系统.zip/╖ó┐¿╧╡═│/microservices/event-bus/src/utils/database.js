const mongoose = require('mongoose');
const { getInstance: getConfigInstance } = require('../config/app');
const { getInstance: getLoggerInstance } = require('./logger');

/**
 * 数据库连接管理类
 * 处理MongoDB连接、模型管理和事务处理
 */
class DatabaseManager {
  constructor() {
    this.config = getConfigInstance().getDatabaseConfig();
    this.logger = getLoggerInstance();
    this.connection = null;
    this.models = {};
    this.connectionStatus = 'disconnected';
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = this.config.maxReconnectAttempts || 5;
    this.reconnectInterval = this.config.reconnectInterval || 5000;
  }

  /**
   * 初始化数据库连接
   */
  async initialize() {
    try {
      this.logger.info('Initializing database connection...', {
        database: this.config.name,
        host: this.config.host
      });

      // 设置Mongoose选项
      const mongooseOptions = {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        autoIndex: this.config.autoIndex,
        serverSelectionTimeoutMS: this.config.connectionTimeout,
        socketTimeoutMS: this.config.socketTimeout,
        keepAlive: true,
        keepAliveInitialDelay: 300000,
        family: 4,
        ...this.config.options
      };

      // 构建连接字符串
      const connectionString = this.buildConnectionString();

      // 连接到数据库
      this.connection = await mongoose.connect(connectionString, mongooseOptions);
      
      // 设置事件监听器
      this.setupEventListeners();
      
      // 注册连接成功回调
      this.onConnect();
      
      return this.connection;
    } catch (error) {
      this.logger.error('Database initialization failed', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * 构建数据库连接字符串
   */
  buildConnectionString() {
    let connectionString = '';
    
    if (this.config.useReplicaSet) {
      // 副本集连接
      connectionString = `mongodb://`;
      
      if (this.config.username && this.config.password) {
        connectionString += `${encodeURIComponent(this.config.username)}:${encodeURIComponent(this.config.password)}@`;
      }
      
      connectionString += `${this.config.hosts.join(',')}/${this.config.name}?replicaSet=${this.config.replicaSetName}`;
      
      if (this.config.authSource) {
        connectionString += `&authSource=${this.config.authSource}`;
      }
    } else {
      // 单节点连接
      connectionString = `mongodb://`;
      
      if (this.config.username && this.config.password) {
        connectionString += `${encodeURIComponent(this.config.username)}:${encodeURIComponent(this.config.password)}@`;
      }
      
      connectionString += `${this.config.host}:${this.config.port}/${this.config.name}`;
      
      if (this.config.authSource) {
        connectionString += `?authSource=${this.config.authSource}`;
      }
    }
    
    // 添加其他查询参数
    const additionalParams = [];
    if (this.config.ssl) {
      additionalParams.push('ssl=true');
    }
    if (this.config.sslValidate !== undefined) {
      additionalParams.push(`sslValidate=${this.config.sslValidate}`);
    }
    
    if (additionalParams.length > 0) {
      if (!connectionString.includes('?')) {
        connectionString += '?';
      } else {
        connectionString += '&';
      }
      connectionString += additionalParams.join('&');
    }
    
    return connectionString;
  }

  /**
   * 设置连接事件监听器
   */
  setupEventListeners() {
    // 连接成功
    this.connection.connection.on('connected', () => {
      this.logger.logDatabaseConnection('connected');
      this.connectionStatus = 'connected';
      this.reconnectAttempts = 0;
    });

    // 连接断开
    this.connection.connection.on('disconnected', () => {
      this.logger.warn('Database connection disconnected');
      this.connectionStatus = 'disconnected';
      this.attemptReconnect();
    });

    // 连接错误
    this.connection.connection.on('error', (error) => {
      this.logger.error('Database connection error', {
        error: error.message
      });
      this.connectionStatus = 'error';
    });

    // 重新连接
    this.connection.connection.on('reconnected', () => {
      this.logger.logDatabaseConnection('reconnected', {
        attempts: this.reconnectAttempts
      });
      this.connectionStatus = 'connected';
      this.reconnectAttempts = 0;
    });

    // 关闭
    this.connection.connection.on('close', () => {
      this.logger.logDatabaseConnection('closed');
      this.connectionStatus = 'closed';
    });
  }

  /**
   * 尝试重新连接
   */
  attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      this.logger.info(`Attempting to reconnect to database... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
      
      setTimeout(() => {
        this.initialize().catch((error) => {
          this.logger.error('Reconnection attempt failed', {
            attempt: this.reconnectAttempts,
            error: error.message
          });
        });
      }, this.reconnectInterval * this.reconnectAttempts); // 指数退避
    } else {
      this.logger.fatal(`Maximum reconnection attempts (${this.maxReconnectAttempts}) reached`);
    }
  }

  /**
   * 连接成功回调
   */
  onConnect() {
    this.logger.logDatabaseConnection('connected', {
      host: this.config.host,
      port: this.config.port,
      database: this.config.name
    });
    
    // 设置连接池参数
    this.setConnectionPoolOptions();
    
    // 加载模型
    this.loadModels();
  }

  /**
   * 设置连接池选项
   */
  setConnectionPoolOptions() {
    if (this.connection && this.connection.connection) {
      const options = this.config.connectionPool || {};
      
      if (options.maxPoolSize) {
        this.connection.connection.setMaxPoolSize(options.maxPoolSize);
      }
      if (options.minPoolSize) {
        // MongoDB 4.2+支持minPoolSize
        if (typeof this.connection.connection.setMinPoolSize === 'function') {
          this.connection.connection.setMinPoolSize(options.minPoolSize);
        }
      }
    }
  }

  /**
   * 加载数据库模型
   */
  async loadModels() {
    try {
      // 这里会动态加载models目录下的所有模型
      // 目前先注册基础模型
      this.registerModels();
      
      this.logger.info('Database models loaded successfully');
    } catch (error) {
      this.logger.error('Failed to load database models', {
        error: error.message
      });
    }
  }

  /**
   * 注册数据库模型
   */
  registerModels() {
    // 事件日志模型
    const EventLogSchema = new mongoose.Schema({
      eventName: {
        type: String,
        required: true,
        index: true
      },
      eventData: {
        type: mongoose.Schema.Types.Mixed,
        required: true
      },
      publishedAt: {
        type: Date,
        default: Date.now,
        index: true
      },
      source: {
        type: String,
        default: 'unknown',
        index: true
      },
      correlationId: {
        type: String,
        index: true
      },
      traceId: {
        type: String,
        index: true
      },
      status: {
        type: String,
        enum: ['published', 'processed', 'failed'],
        default: 'published',
        index: true
      },
      processingTime: {
        type: Number
      }
    }, {
      timestamps: true,
      collection: 'event_logs'
    });

    // 消费者记录模型
    const ConsumerSchema = new mongoose.Schema({
      consumerId: {
        type: String,
        required: true,
        unique: true
      },
      name: {
        type: String,
        required: true
      },
      events: [{
        type: String,
        index: true
      }],
      active: {
        type: Boolean,
        default: true,
        index: true
      },
      lastSeen: {
        type: Date,
        index: true
      },
      metadata: {
        type: mongoose.Schema.Types.Mixed
      }
    }, {
      timestamps: true,
      collection: 'consumers'
    });

    // 事件处理状态模型
    const EventProcessingSchema = new mongoose.Schema({
      eventId: {
        type: String,
        required: true,
        index: true
      },
      eventName: {
        type: String,
        required: true,
        index: true
      },
      consumerId: {
        type: String,
        required: true,
        index: true
      },
      status: {
        type: String,
        enum: ['pending', 'processing', 'completed', 'failed', 'retried'],
        default: 'pending',
        index: true
      },
      attempts: {
        type: Number,
        default: 0
      },
      error: {
        type: String
      },
      nextAttemptAt: {
        type: Date
      },
      completedAt: {
        type: Date
      },
      processingStartAt: {
        type: Date
      },
      processingEndAt: {
        type: Date
      }
    }, {
      timestamps: true,
      collection: 'event_processing'
    });

    // 订阅配置模型
    const SubscriptionSchema = new mongoose.Schema({
      name: {
        type: String,
        required: true
      },
      eventPattern: {
        type: String,
        required: true,
        index: true
      },
      targetUrl: {
        type: String,
        required: true
      },
      headers: {
        type: mongoose.Schema.Types.Mixed
      },
      retryPolicy: {
        maxAttempts: {
          type: Number,
          default: 3
        },
        delay: {
          type: Number,
          default: 1000
        },
        backoff: {
          type: String,
          enum: ['fixed', 'exponential'],
          default: 'exponential'
        }
      },
      enabled: {
        type: Boolean,
        default: true,
        index: true
      },
      createdAt: {
        type: Date,
        default: Date.now
      },
      updatedAt: {
        type: Date,
        default: Date.now
      }
    }, {
      collection: 'subscriptions'
    });

    // 注册模型
    this.models.EventLog = mongoose.model('EventLog', EventLogSchema);
    this.models.Consumer = mongoose.model('Consumer', ConsumerSchema);
    this.models.EventProcessing = mongoose.model('EventProcessing', EventProcessingSchema);
    this.models.Subscription = mongoose.model('Subscription', SubscriptionSchema);

    // 创建索引
    this.createIndexes();
  }

  /**
   * 创建数据库索引
   */
  async createIndexes() {
    try {
      // EventLog索引
      await this.models.EventLog.createIndexes([
        { eventName: 1, publishedAt: 1 },
        { status: 1, publishedAt: -1 },
        { source: 1 },
        { correlationId: 1 }
      ]);

      // Consumer索引
      await this.models.Consumer.createIndexes([
        { events: 1 },
        { active: 1, lastSeen: -1 }
      ]);

      // EventProcessing索引
      await this.models.EventProcessing.createIndexes([
        { consumerId: 1, status: 1, nextAttemptAt: 1 },
        { eventId: 1, consumerId: 1 },
        { status: 1, nextAttemptAt: 1 }
      ]);

      // Subscription索引
      await this.models.Subscription.createIndexes([
        { enabled: 1, eventPattern: 1 }
      ]);

      this.logger.info('Database indexes created successfully');
    } catch (error) {
      this.logger.warn('Failed to create some indexes', {
        error: error.message
      });
    }
  }

  /**
   * 获取数据库连接状态
   */
  getStatus() {
    return this.connectionStatus;
  }

  /**
   * 检查数据库连接是否健康
   */
  isHealthy() {
    return this.connectionStatus === 'connected';
  }

  /**
   * 获取连接对象
   */
  getConnection() {
    return this.connection;
  }

  /**
   * 获取Mongoose实例
   */
  getMongoose() {
    return mongoose;
  }

  /**
   * 获取模型
   */
  getModel(name) {
    return this.models[name] || null;
  }

  /**
   * 获取所有模型
   */
  getAllModels() {
    return this.models;
  }

  /**
   * 执行数据库事务
   */
  async withTransaction(callback) {
    if (!this.connection || !this.isHealthy()) {
      throw new Error('Database is not connected');
    }

    const session = await this.connection.startSession();
    let result = null;

    try {
      session.startTransaction();
      result = await callback(session);
      await session.commitTransaction();
      return result;
    } catch (error) {
      await session.abortTransaction();
      this.logger.error('Database transaction failed', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    } finally {
      session.endSession();
    }
  }

  /**
   * 执行数据库查询
   */
  async executeQuery(modelName, operation, ...args) {
    const model = this.getModel(modelName);
    if (!model) {
      throw new Error(`Model '${modelName}' not found`);
    }

    try {
      const startTime = Date.now();
      const result = await model[operation](...args);
      const duration = Date.now() - startTime;

      this.logQuery(modelName, operation, duration, args);
      
      return result;
    } catch (error) {
      this.logger.error('Database query failed', {
        model: modelName,
        operation: operation,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 记录查询性能
   */
  logQuery(modelName, operation, duration, args) {
    if (duration > this.config.slowQueryThreshold) {
      this.logger.warn('Slow database query detected', {
        model: modelName,
        operation: operation,
        duration: duration,
        args: JSON.stringify(args).substring(0, 100) // 限制参数长度
      });
    }
  }

  /**
   * 关闭数据库连接
   */
  async close() {
    if (this.connection) {
      try {
        await this.connection.close(true);
        this.logger.info('Database connection closed');
        this.connectionStatus = 'closed';
      } catch (error) {
        this.logger.error('Error closing database connection', {
          error: error.message
        });
        throw error;
      }
    }
  }

  /**
   * 获取数据库连接统计信息
   */
  async getStats() {
    try {
      if (!this.connection || !this.isHealthy()) {
        return { status: 'disconnected' };
      }

      const stats = {
        status: this.connectionStatus,
        models: Object.keys(this.models),
        host: this.config.host,
        port: this.config.port,
        database: this.config.name,
        connectedAt: this.connection.connection._eventsCount ? new Date() : null,
        uptime: this.connection.connection.uptime || 0
      };

      return stats;
    } catch (error) {
      this.logger.error('Failed to get database stats', {
        error: error.message
      });
      return { status: 'error', error: error.message };
    }
  }
}

// 导出单例实例
let dbInstance = null;

function getInstance() {
  if (!dbInstance) {
    dbInstance = new DatabaseManager();
  }
  return dbInstance;
}

module.exports = {
  DatabaseManager,
  getInstance
};