const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const path = require('path');
const { getInstance: getConfigInstance } = require('../config/app');

/**
 * 日志工具类
 * 提供结构化日志记录功能
 */
class Logger {
  constructor() {
    this.config = getConfigInstance().getLoggerConfig();
    this.loggers = {};
    this.createLogDirectory();
    this.initializeLoggers();
  }

  /**
   * 创建日志目录
   */
  createLogDirectory() {
    try {
      const fs = require('fs');
      const logDir = path.resolve(process.cwd(), this.config.dir);
      
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }
    } catch (error) {
      console.error('Failed to create log directory:', error.message);
    }
  }

  /**
   * 初始化日志记录器
   */
  initializeLoggers() {
    // 主日志记录器
    this.loggers.main = this.createMainLogger();
    
    // 错误日志记录器
    this.loggers.error = this.createErrorLogger();
    
    // 事件日志记录器
    this.loggers.event = this.createEventLogger();
    
    // 性能日志记录器
    this.loggers.performance = this.createPerformanceLogger();
    
    // 审计日志记录器
    this.loggers.audit = this.createAuditLogger();
  }

  /**
   * 创建主日志记录器
   */
  createMainLogger() {
    const logDir = path.resolve(process.cwd(), this.config.dir);
    const transports = [];

    // 控制台传输器
    transports.push(new winston.transports.Console({
      level: this.config.level,
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.colorize(),
        winston.format.printf(info => {
          return `${info.timestamp} [${info.level}] ${info.message}${info.meta ? ' ' + JSON.stringify(info.meta) : ''}`;
        })
      )
    }));

    // 文件传输器（如果启用了日志轮转）
    if (this.config.rotation) {
      transports.push(new DailyRotateFile({
        filename: path.join(logDir, 'app-%DATE%.log'),
        datePattern: 'YYYY-MM-DD',
        zippedArchive: true,
        maxSize: this.config.maxSize,
        maxFiles: this.config.maxFiles,
        level: this.config.level,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    } else {
      // 简单文件传输器
      transports.push(new winston.transports.File({
        filename: path.join(logDir, 'app.log'),
        level: this.config.level,
        maxsize: 10485760, // 10MB
        maxFiles: 10,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    }

    return winston.createLogger({
      level: this.config.level,
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      defaultMeta: { service: 'event-bus-service' },
      transports
    });
  }

  /**
   * 创建错误日志记录器
   */
  createErrorLogger() {
    const logDir = path.resolve(process.cwd(), this.config.dir);
    const transports = [];

    // 错误文件传输器
    if (this.config.rotation) {
      transports.push(new DailyRotateFile({
        filename: path.join(logDir, 'error-%DATE%.log'),
        datePattern: 'YYYY-MM-DD',
        zippedArchive: true,
        maxSize: this.config.maxSize,
        maxFiles: this.config.maxFiles,
        level: 'error',
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    } else {
      transports.push(new winston.transports.File({
        filename: path.join(logDir, 'error.log'),
        level: 'error',
        maxsize: 10485760,
        maxFiles: 10,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    }

    return winston.createLogger({
      level: 'error',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      defaultMeta: { service: 'event-bus-service' },
      transports
    });
  }

  /**
   * 创建事件日志记录器
   */
  createEventLogger() {
    const logDir = path.resolve(process.cwd(), this.config.dir);
    const transports = [];

    // 事件文件传输器
    if (this.config.rotation) {
      transports.push(new DailyRotateFile({
        filename: path.join(logDir, 'events-%DATE%.log'),
        datePattern: 'YYYY-MM-DD',
        zippedArchive: true,
        maxSize: this.config.maxSize,
        maxFiles: this.config.maxFiles,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    } else {
      transports.push(new winston.transports.File({
        filename: path.join(logDir, 'events.log'),
        maxsize: 10485760,
        maxFiles: 10,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    }

    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      defaultMeta: { service: 'event-bus-service', type: 'event' },
      transports
    });
  }

  /**
   * 创建性能日志记录器
   */
  createPerformanceLogger() {
    const logDir = path.resolve(process.cwd(), this.config.dir);
    const transports = [];

    // 性能文件传输器
    if (this.config.rotation) {
      transports.push(new DailyRotateFile({
        filename: path.join(logDir, 'performance-%DATE%.log'),
        datePattern: 'YYYY-MM-DD',
        zippedArchive: true,
        maxSize: this.config.maxSize,
        maxFiles: this.config.maxFiles,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    } else {
      transports.push(new winston.transports.File({
        filename: path.join(logDir, 'performance.log'),
        maxsize: 10485760,
        maxFiles: 10,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    }

    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      defaultMeta: { service: 'event-bus-service', type: 'performance' },
      transports
    });
  }

  /**
   * 创建审计日志记录器
   */
  createAuditLogger() {
    const logDir = path.resolve(process.cwd(), this.config.dir);
    const transports = [];

    // 审计文件传输器
    if (this.config.rotation) {
      transports.push(new DailyRotateFile({
        filename: path.join(logDir, 'audit-%DATE%.log'),
        datePattern: 'YYYY-MM-DD',
        zippedArchive: true,
        maxSize: this.config.maxSize,
        maxFiles: '30d', // 审计日志保留30天
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    } else {
      transports.push(new winston.transports.File({
        filename: path.join(logDir, 'audit.log'),
        maxsize: 10485760,
        maxFiles: 30,
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.json()
        )
      }));
    }

    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      defaultMeta: { service: 'event-bus-service', type: 'audit' },
      transports
    });
  }

  /**
   * 调试日志
   * @param {string} message - 日志消息
   * @param {object} meta - 元数据
   */
  debug(message, meta = {}) {
    this.loggers.main.debug(message, meta);
  }

  /**
   * 信息日志
   * @param {string} message - 日志消息
   * @param {object} meta - 元数据
   */
  info(message, meta = {}) {
    this.loggers.main.info(message, meta);
  }

  /**
   * 警告日志
   * @param {string} message - 日志消息
   * @param {object} meta - 元数据
   */
  warn(message, meta = {}) {
    this.loggers.main.warn(message, meta);
  }

  /**
   * 错误日志
   * @param {string} message - 日志消息
   * @param {object} meta - 元数据
   */
  error(message, meta = {}) {
    this.loggers.main.error(message, meta);
    this.loggers.error.error(message, meta);
  }

  /**
   * 致命错误日志
   * @param {string} message - 日志消息
   * @param {object} meta - 元数据
   */
  fatal(message, meta = {}) {
    this.loggers.main.error(`[FATAL] ${message}`, meta);
    this.loggers.error.error(`[FATAL] ${message}`, meta);
  }

  /**
   * 记录事件日志
   * @param {string} eventName - 事件名称
   * @param {object} eventData - 事件数据
   */
  logEvent(eventName, eventData = {}) {
    this.loggers.event.info(eventName, {
      eventName,
      ...eventData
    });
  }

  /**
   * 记录事件发布日志
   * @param {string} eventName - 事件名称
   * @param {object} eventData - 事件数据
   */
  logEventPublished(eventName, eventData = {}) {
    this.logEvent('event.published', {
      eventName,
      eventData,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * 记录事件消费日志
   * @param {string} eventName - 事件名称
   * @param {string} consumerId - 消费者ID
   * @param {object} eventData - 事件数据
   */
  logEventConsumed(eventName, consumerId, eventData = {}) {
    this.logEvent('event.consumed', {
      eventName,
      consumerId,
      eventData,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * 记录事件处理错误日志
   * @param {string} eventName - 事件名称
   * @param {Error} error - 错误对象
   * @param {object} eventData - 事件数据
   */
  logEventError(eventName, error, eventData = {}) {
    this.logEvent('event.error', {
      eventName,
      error: {
        message: error.message,
        stack: error.stack
      },
      eventData,
      timestamp: new Date().toISOString()
    });
    this.error(`Error processing event: ${eventName}`, {
      error: error.message,
      eventData
    });
  }

  /**
   * 记录性能指标
   * @param {string} operation - 操作名称
   * @param {number} duration - 持续时间（毫秒）
   * @param {object} meta - 元数据
   */
  logPerformance(operation, duration, meta = {}) {
    this.loggers.performance.info(operation, {
      operation,
      duration,
      ...meta
    });

    // 如果性能超过阈值，记录警告
    if (duration > 1000) { // 超过1秒
      this.warn(`Slow operation detected: ${operation}`, {
        duration,
        ...meta
      });
    }
  }

  /**
   * 记录审计日志
   * @param {string} action - 操作动作
   * @param {string} userId - 用户ID
   * @param {object} details - 详细信息
   */
  logAudit(action, userId, details = {}) {
    this.loggers.audit.info(action, {
      action,
      userId,
      timestamp: new Date().toISOString(),
      ...details
    });
  }

  /**
   * 设置日志级别
   * @param {string} level - 日志级别
   */
  setLevel(level) {
    this.loggers.main.level = level;
    this.info(`Logger level set to: ${level}`);
  }

  /**
   * 获取当前日志级别
   * @returns {string} 日志级别
   */
  getLevel() {
    return this.loggers.main.level;
  }

  /**
   * 验证日志配置
   * @returns {boolean} 配置是否有效
   */
  validateConfig() {
    try {
      const validLevels = ['debug', 'info', 'warn', 'error', 'fatal'];
      const level = this.getLevel();
      
      if (!validLevels.includes(level)) {
        return false;
      }
      
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * 记录请求日志
   * @param {object} req - Express请求对象
   * @param {object} res - Express响应对象
   * @param {number} responseTime - 响应时间
   */
  logRequest(req, res, responseTime) {
    const logData = {
      method: req.method,
      url: req.originalUrl,
      ip: req.ip || req.connection.remoteAddress,
      statusCode: res.statusCode,
      responseTime: `${responseTime}ms`,
      userAgent: req.headers['user-agent'],
      contentLength: res.get('content-length')
    };

    if (res.statusCode >= 400) {
      this.warn(`Request failed`, logData);
    } else if (res.statusCode >= 500) {
      this.error(`Request error`, logData);
    } else {
      this.info(`Request completed`, logData);
    }
  }

  /**
   * 记录连接日志
   * @param {string} connectionType - 连接类型
   * @param {string} status - 状态
   * @param {object} meta - 元数据
   */
  logConnection(connectionType, status, meta = {}) {
    this.info(`Connection ${status}: ${connectionType}`, meta);
  }

  /**
   * 记录RabbitMQ连接日志
   * @param {string} status - 状态
   * @param {object} meta - 元数据
   */
  logRabbitMQConnection(status, meta = {}) {
    this.logConnection('RabbitMQ', status, {
      type: 'rabbitmq',
      ...meta
    });
  }

  /**
   * 记录数据库连接日志
   * @param {string} status - 状态
   * @param {object} meta - 元数据
   */
  logDatabaseConnection(status, meta = {}) {
    this.logConnection('MongoDB', status, {
      type: 'database',
      ...meta
    });
  }

  /**
   * 记录Redis连接日志
   * @param {string} status - 状态
   * @param {object} meta - 元数据
   */
  logRedisConnection(status, meta = {}) {
    this.logConnection('Redis', status, {
      type: 'redis',
      ...meta
    });
  }
}

// 导出单例实例
let loggerInstance = null;

function getInstance() {
  if (!loggerInstance) {
    loggerInstance = new Logger();
  }
  return loggerInstance;
}

module.exports = {
  Logger,
  getInstance
};