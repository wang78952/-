const { getInstance: getLoggerInstance } = require('../utils/logger');
const { getInstance: getConfigInstance } = require('../config/app');

/**
 * 认证中间件类
 * 处理API认证和授权
 */
class AuthMiddleware {
  constructor() {
    this.logger = getLoggerInstance();
    this.config = getConfigInstance();
    this.apiKeys = new Map();
    this.initializeApiKeys();
  }

  /**
   * 初始化API密钥列表
   */
  initializeApiKeys() {
    // 从配置中加载API密钥
    const apiKeysConfig = this.config.get('API_KEYS', '[]');
    
    try {
      const keys = typeof apiKeysConfig === 'string' ? JSON.parse(apiKeysConfig) : apiKeysConfig;
      
      if (Array.isArray(keys)) {
        keys.forEach(key => {
          this.apiKeys.set(key.apiKey, {
            service: key.service,
            permissions: key.permissions || ['read', 'write'],
            createdAt: key.createdAt || new Date().toISOString()
          });
        });
      }
      
      // 添加默认的服务密钥
      const defaultKey = this.config.get('DEFAULT_API_KEY');
      if (defaultKey) {
        this.apiKeys.set(defaultKey, {
          service: 'default',
          permissions: ['read', 'write'],
          createdAt: new Date().toISOString()
        });
      }
      
      this.logger.info('API keys initialized', { count: this.apiKeys.size });
    } catch (error) {
      this.logger.error('Failed to initialize API keys', {
        error: error.message
      });
    }
  }

  /**
   * API密钥认证中间件
   */
  authenticateApiKey() {
    return (req, res, next) => {
      // 从请求头获取API密钥
      const apiKey = req.headers['x-api-key'] || req.query.api_key;
      
      // 如果没有提供API密钥，返回错误
      if (!apiKey) {
        this.logger.warn('API key missing', {
          path: req.path,
          method: req.method,
          clientIp: req.ip
        });
        
        return res.status(401).json({
          success: false,
          error: 'API key is required',
          requestId: req.requestId
        });
      }
      
      // 验证API密钥
      const keyInfo = this.apiKeys.get(apiKey);
      
      if (!keyInfo) {
        this.logger.warn('Invalid API key', {
          path: req.path,
          clientIp: req.ip,
          apiKey: this.maskApiKey(apiKey)
        });
        
        return res.status(401).json({
          success: false,
          error: 'Invalid API key',
          requestId: req.requestId
        });
      }
      
      // 将密钥信息添加到请求对象
      req.apiKey = apiKey;
      req.service = keyInfo.service;
      req.permissions = keyInfo.permissions;
      
      // 记录认证成功
      this.logger.info('API authentication successful', {
        service: keyInfo.service,
        path: req.path,
        apiKey: this.maskApiKey(apiKey)
      });
      
      next();
    };
  }

  /**
   * 权限验证中间件
   */
  requirePermission(requiredPermission) {
    return (req, res, next) => {
      // 检查用户是否已经通过认证
      if (!req.permissions || !Array.isArray(req.permissions)) {
        return res.status(403).json({
          success: false,
          error: 'Permission denied: Authentication required',
          requestId: req.requestId
        });
      }
      
      // 检查是否有所需权限
      if (!req.permissions.includes(requiredPermission) && !req.permissions.includes('admin')) {
        this.logger.warn('Permission denied', {
          requiredPermission,
          userPermissions: req.permissions,
          service: req.service
        });
        
        return res.status(403).json({
          success: false,
          error: `Permission denied: requires ${requiredPermission} permission`,
          requestId: req.requestId
        });
      }
      
      next();
    };
  }

  /**
   * 可选认证中间件（不强制要求API密钥，但如果提供了则进行验证）
   */
  optionalAuthentication() {
    return (req, res, next) => {
      // 从请求头获取API密钥
      const apiKey = req.headers['x-api-key'] || req.query.api_key;
      
      // 如果提供了API密钥，进行验证
      if (apiKey) {
        const keyInfo = this.apiKeys.get(apiKey);
        
        if (keyInfo) {
          // 将密钥信息添加到请求对象
          req.apiKey = apiKey;
          req.service = keyInfo.service;
          req.permissions = keyInfo.permissions;
        }
      }
      
      // 继续处理请求，无论认证如何
      next();
    };
  }

  /**
   * 认证中间件工厂方法
   * 根据配置决定是否启用认证
   */
  getAuthMiddleware() {
    // 检查是否启用认证
    const authEnabled = this.config.get('AUTH_ENABLED', 'true').toLowerCase() === 'true';
    
    if (authEnabled) {
      // 如果启用了认证，返回认证中间件
      return this.authenticateApiKey();
    } else {
      // 否则返回可选认证中间件
      return this.optionalAuthentication();
    }
  }

  /**
   * 掩码API密钥，用于日志记录
   */
  maskApiKey(apiKey) {
    if (!apiKey || apiKey.length <= 8) {
      return apiKey;
    }
    
    const start = apiKey.substring(0, 4);
    const end = apiKey.substring(apiKey.length - 4);
    const masked = '*'.repeat(apiKey.length - 8);
    
    return `${start}${masked}${end}`;
  }

  /**
   * 请求验证中间件
   */
  validateRequest(schema) {
    return (req, res, next) => {
      try {
        // 执行验证
        const validationResult = this.validateSchema(req.body, schema);
        
        if (!validationResult.valid) {
          this.logger.warn('Request validation failed', {
            path: req.path,
            errors: validationResult.errors
          });
          
          return res.status(400).json({
            success: false,
            error: 'Validation failed',
            details: validationResult.errors,
            requestId: req.requestId
          });
        }
        
        // 验证成功，继续处理
        next();
      } catch (error) {
        this.logger.error('Validation middleware error', {
          error: error.message,
          schema: schema.name
        });
        
        return res.status(500).json({
          success: false,
          error: 'Validation middleware error',
          requestId: req.requestId
        });
      }
    };
  }

  /**
   * 简单的模式验证（轻量级实现）
   */
  validateSchema(data, schema) {
    const errors = [];
    
    // 检查必填字段
    if (schema.required) {
      schema.required.forEach(field => {
        if (data[field] === undefined || data[field] === null) {
          errors.push(`Field '${field}' is required`);
        }
      });
    }
    
    // 检查字段类型
    if (schema.properties) {
      Object.entries(schema.properties).forEach(([field, rules]) => {
        const value = data[field];
        
        // 如果字段存在，验证类型
        if (value !== undefined && value !== null) {
          // 类型验证
          if (rules.type && typeof value !== rules.type) {
            errors.push(`Field '${field}' must be of type ${rules.type}`);
          }
          
          // 字符串长度验证
          if (rules.type === 'string') {
            if (rules.minLength && value.length < rules.minLength) {
              errors.push(`Field '${field}' must be at least ${rules.minLength} characters long`);
            }
            if (rules.maxLength && value.length > rules.maxLength) {
              errors.push(`Field '${field}' must not exceed ${rules.maxLength} characters`);
            }
          }
          
          // 数字范围验证
          if (rules.type === 'number') {
            if (rules.min !== undefined && value < rules.min) {
              errors.push(`Field '${field}' must be at least ${rules.min}`);
            }
            if (rules.max !== undefined && value > rules.max) {
              errors.push(`Field '${field}' must not exceed ${rules.max}`);
            }
          }
        }
      });
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * CORS中间件配置
   */
  corsMiddleware() {
    const corsOrigins = this.config.get('CORS_ORIGINS', '*');
    
    return (req, res, next) => {
      // 设置CORS头
      res.setHeader('Access-Control-Allow-Origin', corsOrigins);
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key, X-Request-ID, X-Service-Name');
      res.setHeader('Access-Control-Expose-Headers', 'X-Request-ID, X-Response-Time');
      res.setHeader('Access-Control-Max-Age', '86400'); // 24小时
      
      // 处理预检请求
      if (req.method === 'OPTIONS') {
        return res.status(204).end();
      }
      
      next();
    };
  }
}

// 导出单例实例
let authMiddlewareInstance = null;

function getInstance() {
  if (!authMiddlewareInstance) {
    authMiddlewareInstance = new AuthMiddleware();
  }
  return authMiddlewareInstance;
}

module.exports = {
  AuthMiddleware,
  getInstance
};