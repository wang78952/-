const { getInstance: getEventModelInstance } = require('../models/EventModel');
const { getInstance: getRabbitMQInstance } = require('./RabbitMQService');
const { getInstance: getLoggerInstance } = require('../utils/logger');
const { getInstance: getConfigInstance } = require('../config/app');

/**
 * 事件处理服务类
 * 负责管理事件处理逻辑和消费者
 */
class EventProcessingService {
  constructor() {
    this.eventModel = getEventModelInstance();
    this.rabbitMQService = getRabbitMQInstance();
    this.logger = getLoggerInstance();
    this.config = getConfigInstance();
    
    this.processors = new Map();
    this.eventSubscriptions = new Map();
    this.consumerGroups = new Map();
    this.retryQueue = 'events.retry';
    this.deadLetterQueue = 'events.dlq';
    this.retryPolicy = {
      maxAttempts: 3,
      initialDelay: 1000,
      backoffMultiplier: 2
    };
    this.healthCheckInterval = null;
    this.idempotencyStore = new Map(); // 简单的内存存储，生产环境应使用Redis
    this.idempotencyTTL = 24 * 60 * 60 * 1000; // 24小时
  }

  /**
   * 初始化事件处理服务
   */
  async initialize() {
    try {
      this.logger.info('Initializing event processing service...');
      
      // 设置重试和死信队列
      await this.setupRetryAndDeadLetterQueues();
      
      // 启动健康检查
      this.startHealthCheck();
      
      // 清理过期的幂等性记录
      this.startIdempotencyCleanup();
      
      this.logger.info('Event processing service initialized');
      return true;
    } catch (error) {
      this.logger.error('Failed to initialize event processing service', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 设置重试和死信队列
   */
  async setupRetryAndDeadLetterQueues() {
    try {
      // 创建死信交换机
      await this.rabbitMQService.createExchange('events.dlx', 'direct', {
        durable: true
      });

      // 创建重试队列
      await this.rabbitMQService.createQueue(this.retryQueue, {
        durable: true,
        arguments: {
          'x-dead-letter-exchange': 'events.dlx',
          'x-dead-letter-routing-key': this.deadLetterQueue,
          'x-message-ttl': 60000 // 1分钟后重试
        }
      });

      // 创建死信队列
      await this.rabbitMQService.createQueue(this.deadLetterQueue, {
        durable: true
      });

      // 绑定死信队列到死信交换机
      await this.rabbitMQService.bindQueue(
        this.deadLetterQueue,
        'events.dlx',
        this.deadLetterQueue
      );

      this.logger.info('Retry and dead letter queues configured');
    } catch (error) {
      this.logger.error('Failed to setup retry and dead letter queues', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 注册事件处理器
   */
  registerEventHandler(eventName, handler, options = {}) {
    try {
      if (!eventName || typeof handler !== 'function') {
        throw new Error('Event name and handler function are required');
      }

      // 确保事件处理器集合存在
      if (!this.processors.has(eventName)) {
        this.processors.set(eventName, []);
      }

      // 添加处理器
      this.processors.get(eventName).push({
        handler,
        options,
        id: `${eventName}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });

      this.logger.info('Event handler registered', {
        eventName,
        handlerId: this.processors.get(eventName).slice(-1)[0].id
      });

      return this.processors.get(eventName).slice(-1)[0].id;
    } catch (error) {
      this.logger.error('Failed to register event handler', {
        eventName,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 注销事件处理器
   */
  unregisterEventHandler(eventName, handlerId) {
    try {
      if (!this.processors.has(eventName)) {
        throw new Error(`No handlers registered for event: ${eventName}`);
      }

      const handlers = this.processors.get(eventName);
      const initialSize = handlers.length;
      
      // 过滤掉指定的处理器
      const filteredHandlers = handlers.filter(handler => handler.id !== handlerId);
      
      if (filteredHandlers.length === initialSize) {
        throw new Error(`Handler with id ${handlerId} not found for event: ${eventName}`);
      }

      // 更新处理器列表
      this.processors.set(eventName, filteredHandlers);

      this.logger.info('Event handler unregistered', {
        eventName,
        handlerId
      });

      return true;
    } catch (error) {
      this.logger.error('Failed to unregister event handler', {
        eventName,
        handlerId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 处理事件
   */
  async processEvent(event) {
    try {
      // 验证事件
      this.eventModel.validateEvent(event);

      // 检查幂等性
      if (!this.isIdempotentEvent(event)) {
        this.logger.warn('Event already processed (idempotency check failed)', {
          eventName: event.name,
          eventId: event.eventId
        });
        return { processed: false, reason: 'duplicate' };
      }

      // 标记事件已处理（幂等性）
      this.markEventAsProcessed(event);

      // 检查是否有处理器注册
      if (!this.processors.has(event.name) || this.processors.get(event.name).length === 0) {
        this.logger.warn('No handlers registered for event', {
          eventName: event.name
        });
        return { processed: false, reason: 'no_handlers' };
      }

      const handlerResults = [];
      let hasErrors = false;

      // 执行所有注册的处理器
      for (const { handler, options } of this.processors.get(event.name)) {
        try {
          const startTime = Date.now();
          
          // 执行处理器
          const result = await this.executeHandler(handler, event, options);
          
          const duration = Date.now() - startTime;
          handlerResults.push({
            success: true,
            duration,
            handlerId: options.id,
            result
          });

          // 记录性能日志
          this.logger.logPerformance(`event.handler.${event.name}`, duration, {
            eventName: event.name,
            handlerId: options.id
          });

        } catch (error) {
          hasErrors = true;
          handlerResults.push({
            success: false,
            error: error.message,
            handlerId: options.id
          });

          this.logger.error('Error processing event handler', {
            eventName: event.name,
            handlerId: options.id,
            error: error.message,
            stack: error.stack
          });

          // 处理错误策略
          await this.handleProcessingError(event, error, options);
        }
      }

      // 如果所有处理器都失败，记录为失败
      if (hasErrors && handlerResults.every(result => !result.success)) {
        await this.eventModel.updateEventStatus(event.eventId, 'failed', {
          error: handlerResults.map(r => r.error).filter(Boolean).join(', ')
        });
      } else if (handlerResults.some(result => result.success)) {
        // 至少有一个处理器成功
        await this.eventModel.updateEventStatus(event.eventId, 'processed');
      }

      return {
        processed: true,
        results: handlerResults,
        hasErrors
      };
    } catch (error) {
      this.logger.error('Failed to process event', {
        eventName: event?.name,
        eventId: event?.eventId,
        error: error.message
      });
      
      // 将事件发送到重试队列
      await this.sendToRetryQueue(event, error);
      
      throw error;
    }
  }

  /**
   * 执行处理器函数
   */
  async executeHandler(handler, event, options) {
    // 记录开始处理
    this.logger.info('Executing event handler', {
      eventName: event.name,
      handlerId: options.id
    });

    // 支持同步和异步处理器
    const result = await handler(event);
    
    this.logger.info('Event handler executed successfully', {
      eventName: event.name,
      handlerId: options.id
    });

    return result;
  }

  /**
   * 处理处理错误
   */
  async handleProcessingError(event, error, options) {
    try {
      // 获取当前尝试次数
      const attempt = event.headers?.attempt || 1;
      
      // 如果达到最大重试次数，发送到死信队列
      if (attempt >= this.retryPolicy.maxAttempts) {
        await this.sendToDeadLetterQueue(event, error);
        this.logger.error('Event reached maximum retry attempts', {
          eventName: event.name,
          eventId: event.eventId,
          attempts: attempt
        });
      } else {
        // 计算下一次尝试的延迟
        const delay = this.retryPolicy.initialDelay * Math.pow(this.retryPolicy.backoffMultiplier, attempt - 1);
        
        // 发送到重试队列
        await this.sendToRetryQueue(event, error, attempt + 1, delay);
        
        this.logger.warn('Event sent to retry queue', {
          eventName: event.name,
          eventId: event.eventId,
          currentAttempt: attempt,
          nextAttempt: attempt + 1,
          delay
        });
      }
    } catch (err) {
      this.logger.error('Failed to handle processing error', {
        eventName: event.name,
        error: err.message
      });
    }
  }

  /**
   * 发送到重试队列
   */
  async sendToRetryQueue(event, error, attempt = 1, delay = this.retryPolicy.initialDelay) {
    try {
      // 准备重试消息
      const retryEvent = {
        ...event,
        headers: {
          ...event.headers,
          attempt,
          retryError: error.message,
          retryTimestamp: new Date().toISOString()
        }
      };

      // 发送到重试队列
      await this.rabbitMQService.publish(
        'events.topic',
        this.retryQueue,
        retryEvent,
        {
          persistent: true,
          expiration: delay,
          headers: {
            'x-retry-attempt': attempt,
            'x-error-message': error.message
          }
        }
      );

      this.logger.info('Event sent to retry queue', {
        eventName: event.name,
        eventId: event.eventId,
        attempt,
        delay
      });
    } catch (err) {
      this.logger.error('Failed to send event to retry queue', {
        eventName: event.name,
        error: err.message
      });
      throw err;
    }
  }

  /**
   * 发送到死信队列
   */
  async sendToDeadLetterQueue(event, error) {
    try {
      // 准备死信消息
      const dlqEvent = {
        ...event,
        headers: {
          ...event.headers,
          failureReason: error.message,
          failedAt: new Date().toISOString()
        }
      };

      // 发送到死信队列
      await this.rabbitMQService.publish(
        'events.dlx',
        this.deadLetterQueue,
        dlqEvent,
        {
          persistent: true,
          headers: {
            'x-failure-reason': error.message
          }
        }
      );

      // 更新数据库中的状态
      await this.eventModel.updateEventStatus(event.eventId, 'failed', {
        error: error.message,
        failedAt: new Date().toISOString()
      });

      this.logger.info('Event sent to dead letter queue', {
        eventName: event.name,
        eventId: event.eventId
      });
    } catch (err) {
      this.logger.error('Failed to send event to dead letter queue', {
        eventName: event.name,
        error: err.message
      });
      throw err;
    }
  }

  /**
   * 幂等性检查
   */
  isIdempotentEvent(event) {
    const key = this.getIdempotencyKey(event);
    
    // 检查是否已经处理过这个事件
    if (this.idempotencyStore.has(key)) {
      return false;
    }

    return true;
  }

  /**
   * 标记事件为已处理（幂等性）
   */
  markEventAsProcessed(event) {
    const key = this.getIdempotencyKey(event);
    const timestamp = Date.now();
    
    // 存储幂等性记录
    this.idempotencyStore.set(key, {
      eventId: event.eventId,
      eventName: event.name,
      processedAt: timestamp
    });
  }

  /**
   * 获取幂等性键
   */
  getIdempotencyKey(event) {
    if (event.idempotencyKey) {
      return event.idempotencyKey;
    }
    
    // 使用事件ID和名称作为键
    return `${event.eventId}:${event.name}`;
  }

  /**
   * 启动幂等性记录清理
   */
  startIdempotencyCleanup() {
    setInterval(() => {
      try {
        const now = Date.now();
        const keysToRemove = [];
        
        // 查找过期的记录
        for (const [key, record] of this.idempotencyStore.entries()) {
          if (now - record.processedAt > this.idempotencyTTL) {
            keysToRemove.push(key);
          }
        }
        
        // 删除过期记录
        for (const key of keysToRemove) {
          this.idempotencyStore.delete(key);
        }
        
        if (keysToRemove.length > 0) {
          this.logger.info('Cleaned up expired idempotency records', {
            count: keysToRemove.length
          });
        }
      } catch (error) {
        this.logger.error('Failed to cleanup idempotency records', {
          error: error.message
        });
      }
    }, 3600000); // 每小时清理一次
  }

  /**
   * 启动健康检查
   */
  startHealthCheck() {
    this.healthCheckInterval = setInterval(async () => {
      try {
        const stats = await this.rabbitMQService.getAllQueueStatus();
        const processingStats = await this.eventModel.getProcessingStats();
        
        // 检查队列健康状态
        for (const queue of stats) {
          // 如果重试队列或死信队列消息过多，发出警告
          if ((queue.queue === this.retryQueue && queue.messages > 100) ||
              (queue.queue === this.deadLetterQueue && queue.messages > 50)) {
            this.logger.warn('Queue积压警告', {
              queue: queue.queue,
              messages: queue.messages
            });
          }
        }

        // 检查失败事件
        if (processingStats.recentFailures.length > 10) {
          this.logger.warn('High number of failed events detected', {
            count: processingStats.recentFailures.length
          });
        }
      } catch (error) {
        this.logger.error('Health check failed', {
          error: error.message
        });
      }
    }, 60000); // 每分钟检查一次
  }

  /**
   * 获取处理服务健康状态
   */
  async getHealthStatus() {
    try {
      const stats = {
        processors: this.processors.size,
        subscriptions: this.eventSubscriptions.size,
        idempotencyRecords: this.idempotencyStore.size,
        queueStatus: await this.rabbitMQService.getAllQueueStatus(),
        processingStats: await this.eventModel.getProcessingStats()
      };

      // 检查是否健康
      const isHealthy = stats.queueStatus.every(q => q.consumers > 0) &&
                       stats.processingStats.statusCounts.failed < 100;

      return {
        status: isHealthy ? 'healthy' : 'degraded',
        ...stats
      };
    } catch (error) {
      this.logger.error('Failed to get health status', {
        error: error.message
      });
      return {
        status: 'error',
        error: error.message
      };
    }
  }

  /**
   * 订阅事件到处理器
   */
  async subscribeToEvent(eventName, handler, options = {}) {
    try {
      // 注册处理器
      const handlerId = this.registerEventHandler(eventName, handler, options);

      // 创建队列名
      const queueName = options.queueName || `event.${eventName}.${handlerId}`;
      
      // 创建队列
      await this.rabbitMQService.createQueue(queueName, {
        durable: true,
        exclusive: options.exclusive || false
      });

      // 绑定到交换机
      await this.rabbitMQService.bindQueue(queueName, 'events.topic', eventName);

      // 订阅队列
      const consumerTag = await this.rabbitMQService.subscribe(
        queueName,
        async (msg) => {
          await this.processEvent(msg);
        },
        {
          consumerId: handlerId,
          ...options
        }
      );

      // 记录订阅信息
      if (!this.eventSubscriptions.has(eventName)) {
        this.eventSubscriptions.set(eventName, []);
      }
      
      this.eventSubscriptions.get(eventName).push({
        handlerId,
        queueName,
        consumerTag,
        options
      });

      this.logger.info('Subscribed to event', {
        eventName,
        handlerId,
        queueName
      });

      return {
        eventName,
        handlerId,
        queueName,
        consumerTag
      };
    } catch (error) {
      this.logger.error('Failed to subscribe to event', {
        eventName,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 取消订阅事件
   */
  async unsubscribeFromEvent(eventName, handlerId) {
    try {
      if (!this.eventSubscriptions.has(eventName)) {
        throw new Error(`No subscriptions for event: ${eventName}`);
      }

      const subscriptions = this.eventSubscriptions.get(eventName);
      const subscriptionIndex = subscriptions.findIndex(s => s.handlerId === handlerId);
      
      if (subscriptionIndex === -1) {
        throw new Error(`Subscription not found for event: ${eventName}, handler: ${handlerId}`);
      }

      const subscription = subscriptions[subscriptionIndex];
      
      // 取消RabbitMQ订阅
      await this.rabbitMQService.unsubscribe(subscription.queueName);
      
      // 注销处理器
      await this.unregisterEventHandler(eventName, handlerId);
      
      // 移除订阅记录
      subscriptions.splice(subscriptionIndex, 1);
      
      if (subscriptions.length === 0) {
        this.eventSubscriptions.delete(eventName);
      }

      this.logger.info('Unsubscribed from event', {
        eventName,
        handlerId
      });

      return true;
    } catch (error) {
      this.logger.error('Failed to unsubscribe from event', {
        eventName,
        handlerId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 关闭事件处理服务
   */
  async shutdown() {
    try {
      this.logger.info('Shutting down event processing service...');
      
      // 清理定时器
      if (this.healthCheckInterval) {
        clearInterval(this.healthCheckInterval);
      }

      // 取消所有订阅
      for (const [eventName, subscriptions] of this.eventSubscriptions.entries()) {
        for (const subscription of subscriptions) {
          try {
            await this.unsubscribeFromEvent(eventName, subscription.handlerId);
          } catch (error) {
            this.logger.warn('Error unsubscribing from event', {
              eventName,
              handlerId: subscription.handlerId,
              error: error.message
            });
          }
        }
      }

      this.logger.info('Event processing service shutdown completed');
      return true;
    } catch (error) {
      this.logger.error('Error during shutdown of event processing service', {
        error: error.message
      });
      throw error;
    }
  }
}

// 导出单例实例
let eventProcessingInstance = null;

function getInstance() {
  if (!eventProcessingInstance) {
    eventProcessingInstance = new EventProcessingService();
  }
  return eventProcessingInstance;
}

module.exports = {
  EventProcessingService,
  getInstance
};