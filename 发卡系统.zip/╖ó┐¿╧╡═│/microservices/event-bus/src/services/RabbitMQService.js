const amqp = require('amqplib');
const { getInstance: getConfigInstance } = require('../config/app');
const { getInstance: getLoggerInstance } = require('../utils/logger');
const { getInstance: getEventModelInstance } = require('../models/EventModel');

/**
 * RabbitMQ服务类
 * 负责管理RabbitMQ连接和消息队列操作
 */
class RabbitMQService {
  constructor() {
    this.config = getConfigInstance().getRabbitMQConfig();
    this.logger = getLoggerInstance();
    this.eventModel = getEventModelInstance();
    
    this.connection = null;
    this.channel = null;
    this.consumerChannels = new Map();
    this.exchanges = new Set();
    this.queues = new Map();
    this.bindingKeys = new Map();
    
    this.connectionStatus = 'disconnected';
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = this.config.maxReconnectAttempts || 10;
    this.reconnectInterval = this.config.reconnectInterval || 5000;
    this.consumers = new Map();
  }

  /**
   * 初始化RabbitMQ连接
   */
  async initialize() {
    try {
      this.logger.info('Initializing RabbitMQ connection...', {
        host: this.config.host,
        port: this.config.port
      });

      // 连接到RabbitMQ
      this.connection = await this.connect();
      
      // 创建通道
      this.channel = await this.connection.createChannel();
      
      // 设置事件监听器
      this.setupEventListeners();
      
      // 创建默认交换机
      await this.setupDefaultExchanges();
      
      // 设置QoS
      await this.setChannelOptions();
      
      this.logger.logRabbitMQConnection('connected', {
        host: this.config.host,
        port: this.config.port
      });
      
      return this.connection;
    } catch (error) {
      this.logger.error('RabbitMQ initialization failed', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * 连接到RabbitMQ服务器
   */
  async connect() {
    try {
      const connectionString = this.buildConnectionString();
      
      this.logger.info('Connecting to RabbitMQ...', {
        url: connectionString
      });
      
      const connection = await amqp.connect(connectionString, {
        timeout: this.config.connectionTimeout,
        frameMax: this.config.frameMax,
        heartbeat: this.config.heartbeat,
        noDelay: true,
        reestablish: true,
        ...this.config.options
      });
      
      this.connectionStatus = 'connected';
      this.reconnectAttempts = 0;
      
      return connection;
    } catch (error) {
      this.logger.error('Failed to connect to RabbitMQ', {
        error: error.message
      });
      this.connectionStatus = 'error';
      throw error;
    }
  }

  /**
   * 构建连接字符串
   */
  buildConnectionString() {
    let url = 'amqp://';
    
    if (this.config.username && this.config.password) {
      url += `${encodeURIComponent(this.config.username)}:${encodeURIComponent(this.config.password)}@`;
    }
    
    if (this.config.useCluster) {
      // 集群模式
      url += this.config.clusterNodes.join(',') + '/';
    } else {
      // 单节点模式
      url += `${this.config.host}:${this.config.port}/`;
    }
    
    if (this.config.vhost) {
      url += encodeURIComponent(this.config.vhost);
    }
    
    // 添加查询参数
    const params = [];
    if (this.config.ssl) {
      params.push('ssl=true');
    }
    if (this.config.authMechanism) {
      params.push(`authMechanism=${this.config.authMechanism}`);
    }
    
    if (params.length > 0) {
      url += `?${params.join('&')}`;
    }
    
    return url;
  }

  /**
   * 设置事件监听器
   */
  setupEventListeners() {
    if (!this.connection) return;

    // 连接关闭事件
    this.connection.on('close', (err) => {
      this.logger.warn('RabbitMQ connection closed', {
        error: err?.message
      });
      this.connectionStatus = 'closed';
      this.attemptReconnect();
    });

    // 连接错误事件
    this.connection.on('error', (error) => {
      this.logger.error('RabbitMQ connection error', {
        error: error.message
      });
      this.connectionStatus = 'error';
    });

    // 连接阻塞事件
    this.connection.on('blocked', (reason) => {
      this.logger.warn('RabbitMQ connection blocked', {
        reason
      });
    });

    // 连接解除阻塞事件
    this.connection.on('unblocked', () => {
      this.logger.info('RabbitMQ connection unblocked');
    });

    // 重连成功事件
    this.connection.on('reconnect', () => {
      this.logger.info('RabbitMQ reconnected successfully');
    });
  }

  /**
   * 尝试重新连接
   */
  async attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      this.logger.info(`Attempting to reconnect to RabbitMQ... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
      
      setTimeout(async () => {
        try {
          await this.initialize();
          // 重新创建队列和绑定
          await this.recreateBindings();
          // 重新启动消费者
          await this.restartConsumers();
        } catch (error) {
          this.logger.error('Reconnection attempt failed', {
            attempt: this.reconnectAttempts,
            error: error.message
          });
        }
      }, this.reconnectInterval * this.reconnectAttempts); // 指数退避
    } else {
      this.logger.fatal(`Maximum reconnection attempts (${this.maxReconnectAttempts}) reached`);
    }
  }

  /**
   * 设置通道选项
   */
  async setChannelOptions() {
    if (this.channel) {
      // 设置QoS (Quality of Service)
      await this.channel.prefetch(
        this.config.prefetchCount || 10,
        this.config.prefetchGlobal || false
      );
    }
  }

  /**
   * 设置默认交换机
   */
  async setupDefaultExchanges() {
    try {
      // 创建默认的topic交换机
      await this.createExchange('events.topic', 'topic', {
        durable: true,
        autoDelete: false
      });

      // 创建默认的direct交换机
      await this.createExchange('events.direct', 'direct', {
        durable: true,
        autoDelete: false
      });

      // 创建默认的fanout交换机
      await this.createExchange('events.fanout', 'fanout', {
        durable: true,
        autoDelete: false
      });

      // 创建默认的headers交换机
      await this.createExchange('events.headers', 'headers', {
        durable: true,
        autoDelete: false
      });

      this.logger.info('Default exchanges created successfully');
    } catch (error) {
      this.logger.error('Failed to create default exchanges', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 创建交换机
   */
  async createExchange(exchangeName, exchangeType, options = {}) {
    try {
      if (!this.channel) {
        throw new Error('RabbitMQ channel not initialized');
      }

      await this.channel.assertExchange(exchangeName, exchangeType, {
        durable: true,
        autoDelete: false,
        internal: false,
        ...options
      });

      this.exchanges.add(exchangeName);
      this.logger.info('Exchange created', {
        exchangeName,
        exchangeType
      });
    } catch (error) {
      this.logger.error('Failed to create exchange', {
        exchangeName,
        exchangeType,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 创建队列
   */
  async createQueue(queueName, options = {}) {
    try {
      if (!this.channel) {
        throw new Error('RabbitMQ channel not initialized');
      }

      const queueOptions = {
        durable: true,
        exclusive: false,
        autoDelete: false,
        ...options
      };

      const queue = await this.channel.assertQueue(queueName, queueOptions);
      
      this.queues.set(queueName, {
        name: queueName,
        ...queue,
        options: queueOptions
      });

      this.logger.info('Queue created', {
        queueName
      });

      return queue;
    } catch (error) {
      this.logger.error('Failed to create queue', {
        queueName,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 绑定队列到交换机
   */
  async bindQueue(queueName, exchangeName, routingKey = '#') {
    try {
      if (!this.channel) {
        throw new Error('RabbitMQ channel not initialized');
      }

      // 确保队列存在
      if (!this.queues.has(queueName)) {
        await this.createQueue(queueName);
      }

      // 确保交换机存在
      if (!this.exchanges.has(exchangeName)) {
        await this.createExchange(exchangeName, 'topic');
      }

      // 绑定队列
      await this.channel.bindQueue(queueName, exchangeName, routingKey);

      // 记录绑定关系
      if (!this.bindingKeys.has(queueName)) {
        this.bindingKeys.set(queueName, new Set());
      }
      this.bindingKeys.get(queueName).add({ exchangeName, routingKey });

      this.logger.info('Queue bound to exchange', {
        queueName,
        exchangeName,
        routingKey
      });
    } catch (error) {
      this.logger.error('Failed to bind queue to exchange', {
        queueName,
        exchangeName,
        routingKey,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 发布消息
   */
  async publish(exchangeName, routingKey, message, options = {}) {
    try {
      if (!this.channel) {
        throw new Error('RabbitMQ channel not initialized');
      }

      // 确保交换机存在
      if (!this.exchanges.has(exchangeName)) {
        await this.createExchange(exchangeName, 'topic');
      }

      // 序列化消息
      const messageBuffer = Buffer.isBuffer(message) 
        ? message 
        : Buffer.from(this.eventModel.serializeEvent(message));

      // 发布选项
      const publishOptions = {
        persistent: true,
        contentType: 'application/json',
        contentEncoding: 'utf-8',
        timestamp: Date.now(),
        ...options
      };

      // 发布消息
      const result = await this.channel.publish(
        exchangeName,
        routingKey,
        messageBuffer,
        publishOptions
      );

      if (!result) {
        throw new Error('Message publishing rejected by RabbitMQ');
      }

      this.logger.logEventPublished(routingKey, message);
      this.logger.info('Message published successfully', {
        exchangeName,
        routingKey,
        messageSize: messageBuffer.length
      });

      return {
        success: true,
        messageId: options.messageId || message.eventId,
        exchange: exchangeName,
        routingKey
      };
    } catch (error) {
      this.logger.error('Failed to publish message', {
        exchangeName,
        routingKey,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 发布事件
   */
  async publishEvent(event) {
    try {
      // 验证事件格式
      this.eventModel.validateEvent(event);

      // 发布到默认的topic交换机
      const result = await this.publish(
        'events.topic',
        event.name,
        event,
        {
          messageId: event.eventId,
          headers: {
            'x-correlation-id': event.correlationId,
            'x-source': event.source,
            'x-event-type': event.name
          }
        }
      );

      // 记录事件日志到数据库
      await this.eventModel.logEvent(event);

      return result;
    } catch (error) {
      this.logger.error('Failed to publish event', {
        eventName: event?.name,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 订阅队列
   */
  async subscribe(queueName, callback, options = {}) {
    try {
      if (!this.channel) {
        throw new Error('RabbitMQ channel not initialized');
      }

      // 获取或创建专用的消费者通道
      let consumerChannel = this.consumerChannels.get(queueName);
      if (!consumerChannel) {
        consumerChannel = await this.connection.createChannel();
        await consumerChannel.prefetch(
          options.prefetch || this.config.prefetchCount || 10
        );
        this.consumerChannels.set(queueName, consumerChannel);
      }

      // 消费选项
      const consumeOptions = {
        noAck: options.noAck || false,
        exclusive: options.exclusive || false,
        ...options
      };

      // 确保队列存在
      if (!this.queues.has(queueName)) {
        await this.createQueue(queueName);
      }

      // 包装回调函数，添加错误处理和确认
      const wrappedCallback = async (msg) => {
        const consumerId = options.consumerId || queueName;
        let event;

        try {
          // 解析消息
          if (msg.content) {
            event = this.eventModel.deserializeEvent(msg.content.toString());
          } else {
            throw new Error('Empty message content');
          }

          this.logger.logEventConsumed(event.name, consumerId, event);

          // 记录事件处理开始
          await this.eventModel.recordEventProcessing(event.eventId, consumerId, 'processing');

          // 执行回调
          await callback(event, msg);

          // 确认消息
          if (!consumeOptions.noAck) {
            consumerChannel.ack(msg);
          }

          // 更新事件处理状态
          await this.eventModel.updateEventProcessing(event.eventId, consumerId, 'completed');

        } catch (error) {
          this.logger.logEventError(event?.name, error, event);

          // 更新事件处理状态为失败
          if (event) {
            await this.eventModel.updateEventProcessing(
              event.eventId,
              consumerId,
              'failed',
              { error: error.message }
            );
          }

          // 处理失败策略
          if (!consumeOptions.noAck) {
            if (options.retryable !== false && msg.fields.deliveryTag < (options.maxRetries || 3)) {
              // 重新排队
              consumerChannel.nack(msg, false, true);
            } else {
              // 拒绝并丢弃或发送到死信队列
              consumerChannel.nack(msg, false, false);
            }
          }
        }
      };

      // 开始消费
      const consumerTag = await consumerChannel.consume(queueName, wrappedCallback, consumeOptions);

      // 记录消费者信息
      this.consumers.set(queueName, {
        queueName,
        consumerTag,
        channel: consumerChannel,
        options
      });

      this.logger.info('Started consuming from queue', {
        queueName,
        consumerTag
      });

      return consumerTag;
    } catch (error) {
      this.logger.error('Failed to subscribe to queue', {
        queueName,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 取消订阅
   */
  async unsubscribe(queueName) {
    try {
      const consumer = this.consumers.get(queueName);
      if (!consumer) {
        throw new Error(`No consumer found for queue: ${queueName}`);
      }

      await consumer.channel.cancel(consumer.consumerTag);
      
      // 移除消费者记录
      this.consumers.delete(queueName);
      
      // 如果没有其他消费者使用此通道，关闭它
      if (consumer.channel) {
        await consumer.channel.close();
        this.consumerChannels.delete(queueName);
      }

      this.logger.info('Unsubscribed from queue', {
        queueName,
        consumerTag: consumer.consumerTag
      });
    } catch (error) {
      this.logger.error('Failed to unsubscribe from queue', {
        queueName,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取队列状态
   */
  async getQueueStatus(queueName) {
    try {
      if (!this.channel) {
        throw new Error('RabbitMQ channel not initialized');
      }

      const status = await this.channel.checkQueue(queueName);
      
      return {
        queue: queueName,
        messages: status.messageCount,
        consumers: status.consumerCount,
        ...status
      };
    } catch (error) {
      this.logger.error('Failed to get queue status', {
        queueName,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取所有队列状态
   */
  async getAllQueueStatus() {
    const statusList = [];
    
    for (const queueName of this.queues.keys()) {
      try {
        const status = await this.getQueueStatus(queueName);
        statusList.push(status);
      } catch (error) {
        this.logger.warn('Failed to get status for queue', {
          queueName,
          error: error.message
        });
      }
    }

    return statusList;
  }

  /**
   * 重新创建绑定
   */
  async recreateBindings() {
    try {
      for (const [queueName, bindings] of this.bindingKeys.entries()) {
        for (const { exchangeName, routingKey } of bindings) {
          await this.bindQueue(queueName, exchangeName, routingKey);
        }
      }
    } catch (error) {
      this.logger.error('Failed to recreate bindings', {
        error: error.message
      });
    }
  }

  /**
   * 重启消费者
   */
  async restartConsumers() {
    try {
      const consumerKeys = Array.from(this.consumers.keys());
      
      // 先取消所有订阅
      for (const queueName of consumerKeys) {
        await this.unsubscribe(queueName);
      }

      // TODO: 重新创建订阅（这里需要一个方法来存储订阅的回调函数）
    } catch (error) {
      this.logger.error('Failed to restart consumers', {
        error: error.message
      });
    }
  }

  /**
   * 关闭连接
   */
  async close() {
    try {
      // 取消所有订阅
      for (const queueName of this.consumers.keys()) {
        await this.unsubscribe(queueName);
      }

      // 关闭所有消费者通道
      for (const channel of this.consumerChannels.values()) {
        if (channel && channel.close) {
          await channel.close();
        }
      }

      // 关闭主通道
      if (this.channel && this.channel.close) {
        await this.channel.close();
      }

      // 关闭连接
      if (this.connection && this.connection.close) {
        await this.connection.close();
      }

      this.logger.logRabbitMQConnection('closed');
      this.connectionStatus = 'closed';

    } catch (error) {
      this.logger.error('Failed to close RabbitMQ connection', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取连接状态
   */
  getStatus() {
    return this.connectionStatus;
  }

  /**
   * 检查连接是否健康
   */
  isHealthy() {
    return this.connectionStatus === 'connected' && this.connection?.isConnected();
  }

  /**
   * 获取统计信息
   */
  getStats() {
    return {
      status: this.connectionStatus,
      exchanges: Array.from(this.exchanges),
      queues: Array.from(this.queues.keys()),
      consumers: this.consumers.size,
      reconnectAttempts: this.reconnectAttempts,
      host: this.config.host,
      port: this.config.port
    };
  }
}

// 导出单例实例
let rabbitMQInstance = null;

function getInstance() {
  if (!rabbitMQInstance) {
    rabbitMQInstance = new RabbitMQService();
  }
  return rabbitMQInstance;
}

module.exports = {
  RabbitMQService,
  getInstance
};