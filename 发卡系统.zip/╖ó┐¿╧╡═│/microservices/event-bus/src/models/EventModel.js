const { getInstance: getDatabaseInstance } = require('../utils/database');
const { getInstance: getLoggerInstance } = require('../utils/logger');
const crypto = require('crypto');

/**
 * 事件模型类
 * 定义事件的数据结构和操作方法
 */
class EventModel {
  constructor() {
    this.db = getDatabaseInstance();
    this.logger = getLoggerInstance();
    this.eventLogModel = null;
    this.consumerModel = null;
    this.eventProcessingModel = null;
    this.subscriptionModel = null;
    
    // 初始化数据库模型
    this.initializeModels();
  }

  /**
   * 初始化数据库模型
   */
  initializeModels() {
    this.eventLogModel = this.db.getModel('EventLog');
    this.consumerModel = this.db.getModel('Consumer');
    this.eventProcessingModel = this.db.getModel('EventProcessing');
    this.subscriptionModel = this.db.getModel('Subscription');
  }

  /**
   * 生成事件ID
   */
  generateEventId() {
    return crypto.randomUUID();
  }

  /**
   * 验证事件格式
   */
  validateEvent(event) {
    if (!event) {
      throw new Error('Event cannot be null or undefined');
    }

    if (!event.name || typeof event.name !== 'string') {
      throw new Error('Event name is required and must be a string');
    }

    if (event.data === undefined || event.data === null) {
      throw new Error('Event data cannot be null or undefined');
    }

    if (!event.timestamp) {
      event.timestamp = new Date().toISOString();
    }

    if (!event.eventId) {
      event.eventId = this.generateEventId();
    }

    // 验证事件名称格式
    if (!/^[a-zA-Z0-9_\-\.]+$/.test(event.name)) {
      throw new Error('Event name can only contain letters, numbers, underscores, hyphens, and dots');
    }

    return true;
  }

  /**
   * 创建标准事件对象
   */
  createEvent(eventName, eventData, options = {}) {
    const event = {
      eventId: this.generateEventId(),
      name: eventName,
      data: eventData,
      timestamp: new Date().toISOString(),
      source: options.source || 'unknown',
      correlationId: options.correlationId || this.generateEventId(),
      traceId: options.traceId || this.generateEventId(),
      ...options
    };

    // 验证事件
    this.validateEvent(event);

    return event;
  }

  /**
   * 记录事件日志
   */
  async logEvent(event) {
    try {
      // 验证事件
      this.validateEvent(event);

      // 准备事件日志数据
      const eventLogData = {
        eventName: event.name,
        eventData: event.data,
        publishedAt: new Date(event.timestamp),
        source: event.source || 'unknown',
        correlationId: event.correlationId,
        traceId: event.traceId,
        status: 'published'
      };

      // 保存到数据库
      const eventLog = new this.eventLogModel(eventLogData);
      await eventLog.save();

      this.logger.info('Event logged to database', {
        eventName: event.name,
        eventId: event.eventId
      });

      return eventLog;
    } catch (error) {
      this.logger.error('Failed to log event', {
        eventName: event?.name,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 更新事件状态
   */
  async updateEventStatus(eventId, status, metadata = {}) {
    try {
      const eventLog = await this.eventLogModel.findOneAndUpdate(
        { correlationId: eventId },
        { 
          status,
          updatedAt: new Date(),
          ...metadata
        },
        { new: true }
      );

      if (!eventLog) {
        this.logger.warn('Event log not found for update', {
          eventId
        });
        return null;
      }

      return eventLog;
    } catch (error) {
      this.logger.error('Failed to update event status', {
        eventId,
        status,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 记录事件处理状态
   */
  async recordEventProcessing(eventId, eventName, consumerId, status = 'pending', metadata = {}) {
    try {
      const processingRecord = new this.eventProcessingModel({
        eventId,
        eventName,
        consumerId,
        status,
        attempts: 0,
        ...metadata
      });

      await processingRecord.save();
      
      return processingRecord;
    } catch (error) {
      this.logger.error('Failed to record event processing', {
        eventId,
        eventName,
        consumerId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 更新事件处理状态
   */
  async updateEventProcessing(eventId, consumerId, status, metadata = {}) {
    try {
      const updateData = {
        status,
        updatedAt: new Date(),
        ...metadata
      };

      // 更新特定字段
      if (status === 'processing') {
        updateData.processingStartAt = new Date();
        updateData.attempts = { $inc: 1 };
      } else if (status === 'completed' || status === 'failed') {
        updateData.processingEndAt = new Date();
        updateData.completedAt = status === 'completed' ? new Date() : undefined;
      }

      const record = await this.eventProcessingModel.findOneAndUpdate(
        { eventId, consumerId },
        updateData,
        { new: true, upsert: true }
      );

      return record;
    } catch (error) {
      this.logger.error('Failed to update event processing status', {
        eventId,
        consumerId,
        status,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 注册消费者
   */
  async registerConsumer(consumerData) {
    try {
      const { consumerId, name, events = [], metadata = {} } = consumerData;

      if (!consumerId || !name) {
        throw new Error('Consumer ID and name are required');
      }

      // 查找或创建消费者
      const consumer = await this.consumerModel.findOneAndUpdate(
        { consumerId },
        {
          name,
          events,
          lastSeen: new Date(),
          active: true,
          metadata
        },
        { new: true, upsert: true }
      );

      this.logger.info('Consumer registered/updated', {
        consumerId,
        name,
        events: events.length
      });

      return consumer;
    } catch (error) {
      this.logger.error('Failed to register consumer', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 更新消费者心跳
   */
  async updateConsumerHeartbeat(consumerId) {
    try {
      const consumer = await this.consumerModel.findOneAndUpdate(
        { consumerId },
        { lastSeen: new Date() },
        { new: true }
      );

      if (!consumer) {
        this.logger.warn('Consumer not found for heartbeat update', {
          consumerId
        });
        return null;
      }

      return consumer;
    } catch (error) {
      this.logger.error('Failed to update consumer heartbeat', {
        consumerId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取活跃的消费者列表
   */
  async getActiveConsumers(eventName) {
    try {
      const query = {
        active: true,
        lastSeen: { $gte: new Date(Date.now() - 60000) } // 1分钟内活跃
      };

      // 如果指定了事件名称，只返回订阅该事件的消费者
      if (eventName) {
        query.events = { $in: [eventName] };
      }

      const consumers = await this.consumerModel.find(query);
      return consumers;
    } catch (error) {
      this.logger.error('Failed to get active consumers', {
        eventName,
        error: error.message
      });
      return [];
    }
  }

  /**
   * 创建订阅
   */
  async createSubscription(subscriptionData) {
    try {
      const { name, eventPattern, targetUrl, headers = {}, retryPolicy = {} } = subscriptionData;

      if (!name || !eventPattern || !targetUrl) {
        throw new Error('Name, event pattern, and target URL are required');
      }

      const subscription = new this.subscriptionModel({
        name,
        eventPattern,
        targetUrl,
        headers,
        retryPolicy: {
          maxAttempts: retryPolicy.maxAttempts || 3,
          delay: retryPolicy.delay || 1000,
          backoff: retryPolicy.backoff || 'exponential'
        },
        enabled: true
      });

      await subscription.save();

      this.logger.info('Subscription created', {
        name,
        eventPattern
      });

      return subscription;
    } catch (error) {
      this.logger.error('Failed to create subscription', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取匹配事件的订阅列表
   */
  async getMatchingSubscriptions(eventName) {
    try {
      // 查找启用且匹配事件模式的订阅
      const subscriptions = await this.subscriptionModel.find({
        enabled: true,
        // 使用正则表达式匹配事件模式
        eventPattern: { $regex: new RegExp(`^${eventName.replace(/\./g, '\\.').replace(/\*/g, '[^\\.]+').replace(/\*\*/g, '.*')}$`) }
      });

      return subscriptions;
    } catch (error) {
      this.logger.error('Failed to get matching subscriptions', {
        eventName,
        error: error.message
      });
      return [];
    }
  }

  /**
   * 查询事件日志
   */
  async queryEventLogs(queryParams = {}) {
    try {
      const { eventName, source, startTime, endTime, status, limit = 100, offset = 0 } = queryParams;
      
      const query = {};
      
      if (eventName) {
        query.eventName = eventName;
      }
      
      if (source) {
        query.source = source;
      }
      
      if (status) {
        query.status = status;
      }
      
      if (startTime) {
        query.publishedAt = { ...query.publishedAt, $gte: new Date(startTime) };
      }
      
      if (endTime) {
        query.publishedAt = { ...query.publishedAt, $lte: new Date(endTime) };
      }

      const eventLogs = await this.eventLogModel.find(query)
        .sort({ publishedAt: -1 })
        .limit(parseInt(limit, 10))
        .skip(parseInt(offset, 10));
      
      const total = await this.eventLogModel.countDocuments(query);

      return {
        items: eventLogs,
        total,
        limit: parseInt(limit, 10),
        offset: parseInt(offset, 10)
      };
    } catch (error) {
      this.logger.error('Failed to query event logs', {
        queryParams,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 获取事件处理统计信息
   */
  async getProcessingStats() {
    try {
      // 获取各状态的事件处理记录数量
      const stats = await this.eventProcessingModel.aggregate([
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 }
          }
        }
      ]);

      // 获取最近失败的事件
      const recentFailures = await this.eventProcessingModel.find(
        { status: 'failed' },
        { eventName: 1, consumerId: 1, error: 1, updatedAt: 1 }
      )
        .sort({ updatedAt: -1 })
        .limit(10);

      return {
        statusCounts: stats.reduce((acc, stat) => {
          acc[stat._id] = stat.count;
          return acc;
        }, {}),
        recentFailures
      };
    } catch (error) {
      this.logger.error('Failed to get processing stats', {
        error: error.message
      });
      return {
        statusCounts: {},
        recentFailures: []
      };
    }
  }

  /**
   * 清理过期的事件日志
   */
  async cleanupOldEventLogs(retentionDays = 7) {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

      const result = await this.eventLogModel.deleteMany({
        publishedAt: { $lte: cutoffDate }
      });

      this.logger.info('Cleaned up old event logs', {
        deletedCount: result.deletedCount,
        retentionDays
      });

      return result.deletedCount;
    } catch (error) {
      this.logger.error('Failed to cleanup old event logs', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 序列化事件数据
   */
  serializeEvent(event) {
    try {
      return JSON.stringify(event);
    } catch (error) {
      this.logger.error('Failed to serialize event', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 反序列化事件数据
   */
  deserializeEvent(eventString) {
    try {
      return JSON.parse(eventString);
    } catch (error) {
      this.logger.error('Failed to deserialize event', {
        error: error.message
      });
      throw error;
    }
  }
}

// 导出单例实例
let eventModelInstance = null;

function getInstance() {
  if (!eventModelInstance) {
    eventModelInstance = new EventModel();
  }
  return eventModelInstance;
}

module.exports = {
  EventModel,
  getInstance
};