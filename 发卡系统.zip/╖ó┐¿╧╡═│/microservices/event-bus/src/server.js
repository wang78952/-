const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
const { getInstance: getConfigInstance } = require('./config/app');
const { getInstance: getLoggerInstance } = require('./utils/logger');
const { getInstance: getDatabaseInstance } = require('./utils/database');
const { getInstance: getRabbitMQInstance } = require('./services/RabbitMQService');
const { getInstance: getEventProcessingInstance } = require('./services/EventProcessingService');
const ApiRouter = require('./routes/api');

/**
 * 事件总线服务主类
 */
class EventBusServer {
  constructor() {
    this.app = express();
    this.config = getConfigInstance();
    this.logger = getLoggerInstance();
    this.db = getDatabaseInstance();
    this.rabbitMQ = getRabbitMQInstance();
    this.eventProcessor = getEventProcessingInstance();
    this.server = null;
    this.isShuttingDown = false;
    this.port = this.config.get('PORT', 8080);
    this.host = this.config.get('HOST', '0.0.0.0');
  }

  /**
   * 初始化服务
   */
  async initialize() {
    try {
      this.logger.info('Initializing Event Bus Server...');
      
      // 1. 设置中间件
      this.setupMiddleware();
      
      // 2. 设置路由
      this.setupRoutes();
      
      // 3. 初始化数据库连接
      await this.initializeDatabase();
      
      // 4. 初始化RabbitMQ连接
      await this.initializeRabbitMQ();
      
      // 5. 初始化事件处理器
      await this.initializeEventProcessor();
      
      // 6. 设置安全策略
      this.setupSecurity();
      
      // 7. 设置错误处理
      this.setupErrorHandling();
      
      // 8. 设置信号处理
      this.setupSignalHandlers();
      
      this.logger.info('Event Bus Server initialized successfully');
      return true;
    } catch (error) {
      this.logger.error('Failed to initialize Event Bus Server', {
        error: error.message,
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * 设置Express中间件
   */
  setupMiddleware() {
    // 请求解析中间件
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));
    
    // 安全头中间件
    this.app.use(helmet());
    
    // CORS中间件
    this.app.use(cors({
      origin: this.config.get('CORS_ORIGINS', '*'),
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID', 'X-Service-Name'],
      exposedHeaders: ['X-Request-ID', 'X-Response-Time'],
      credentials: true
    }));
    
    // 压缩中间件
    this.app.use(compression());
    
    // 请求ID和响应时间中间件
    this.app.use((req, res, next) => {
      // 生成或使用现有的请求ID
      const requestId = req.headers['x-request-id'] || this.generateRequestId();
      req.requestId = requestId;
      
      // 设置响应头
      res.setHeader('X-Request-ID', requestId);
      res.setHeader('X-Service-Name', 'event-bus');
      
      // 记录请求开始时间
      const startTime = Date.now();
      
      // 响应完成时记录时间
      res.on('finish', () => {
        const duration = Date.now() - startTime;
        res.setHeader('X-Response-Time', duration.toString());
        
        // 记录请求日志
        this.logger.logRequest(req.method, req.path, {
          requestId,
          status: res.statusCode,
          duration,
          clientIp: req.ip,
          userAgent: req.headers['user-agent']
        });
      });
      
      next();
    });
    
    // 速率限制中间件
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000, // 15分钟
      max: this.config.get('RATE_LIMIT', 1000), // 每IP限制请求数
      standardHeaders: true,
      legacyHeaders: false,
      message: {
        success: false,
        error: 'Too many requests, please try again later'
      },
      keyGenerator: (req) => {
        // 使用IP或服务名称作为限流键
        return req.headers['x-service-name'] || req.ip;
      },
      onLimitReached: (req) => {
        this.logger.warn('Rate limit exceeded', {
          clientIp: req.ip,
          serviceName: req.headers['x-service-name'],
          path: req.path
        });
      }
    });
    
    // 应用速率限制
    this.app.use('/api', limiter);
  }

  /**
   * 设置路由
   */
  setupRoutes() {
    // API路由前缀
    const apiPrefix = this.config.get('API_PREFIX', '/api');
    
    // 创建API路由实例
    const apiRouter = new ApiRouter();
    
    // 挂载API路由
    this.app.use(apiPrefix, apiRouter.getRouter());
    
    // 根路径
    this.app.get('/', (req, res) => {
      res.status(200).json({
        message: 'Event Bus Service',
        version: this.config.get('VERSION', '1.0.0'),
        docs: `${apiPrefix}/docs`,
        health: `${apiPrefix}/health`
      });
    });
    
    // 健康检查根路径
    this.app.get('/health', (req, res) => {
      res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        service: 'event-bus'
      });
    });
  }

  /**
   * 初始化数据库连接
   */
  async initializeDatabase() {
    try {
      this.logger.info('Initializing database connection...');
      await this.db.connect();
      this.logger.info('Database connected successfully');
    } catch (error) {
      this.logger.error('Failed to connect to database', {
        error: error.message
      });
      throw new Error('Database connection failed');
    }
  }

  /**
   * 初始化RabbitMQ连接
   */
  async initializeRabbitMQ() {
    try {
      this.logger.info('Initializing RabbitMQ connection...');
      
      // 连接到RabbitMQ
      await this.rabbitMQ.connect();
      
      // 创建默认交换机
      await this.rabbitMQ.createExchange('events.topic', 'topic', { durable: true });
      
      // 创建默认队列
      await this.rabbitMQ.createQueue('events.all', { durable: true });
      await this.rabbitMQ.bindQueue('events.all', 'events.topic', '#'); // 绑定所有事件
      
      this.logger.info('RabbitMQ initialized successfully');
    } catch (error) {
      this.logger.error('Failed to initialize RabbitMQ', {
        error: error.message
      });
      throw new Error('RabbitMQ initialization failed');
    }
  }

  /**
   * 初始化事件处理器
   */
  async initializeEventProcessor() {
    try {
      this.logger.info('Initializing event processor...');
      await this.eventProcessor.initialize();
      this.logger.info('Event processor initialized successfully');
    } catch (error) {
      this.logger.error('Failed to initialize event processor', {
        error: error.message
      });
      throw new Error('Event processor initialization failed');
    }
  }

  /**
   * 设置安全策略
   */
  setupSecurity() {
    // 禁用X-Powered-By头
    this.app.disable('x-powered-by');
    
    // 内容安全策略
    this.app.use(helmet.contentSecurityPolicy({
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: [],
      },
    }));
    
    // 严格传输安全
    this.app.use(helmet.hsts({
      maxAge: 31536000,
      includeSubDomains: true
    }));
  }

  /**
   * 设置错误处理
   */
  setupErrorHandling() {
    // 全局错误处理中间件
    this.app.use((err, req, res, next) => {
      // 如果响应已发送，交给Express默认处理
      if (res.headersSent) {
        return next(err);
      }
      
      // 记录错误
      this.logger.error('Unhandled error', {
        error: err.message,
        stack: err.stack,
        path: req.path,
        method: req.method
      });
      
      // 确定错误状态码
      const statusCode = err.statusCode || err.status || 500;
      
      // 返回错误响应
      res.status(statusCode).json({
        success: false,
        error: err.message || 'Internal Server Error',
        requestId: req.requestId || this.generateRequestId(),
        timestamp: new Date().toISOString()
      });
    });
  }

  /**
   * 设置信号处理器
   */
  setupSignalHandlers() {
    // 处理SIGINT信号 (Ctrl+C)
    process.on('SIGINT', async () => {
      this.logger.info('Received SIGINT signal, shutting down gracefully...');
      await this.shutdown('SIGINT');
    });
    
    // 处理SIGTERM信号 (kill命令)
    process.on('SIGTERM', async () => {
      this.logger.info('Received SIGTERM signal, shutting down gracefully...');
      await this.shutdown('SIGTERM');
    });
    
    // 处理未捕获的异常
    process.on('uncaughtException', (error) => {
      this.logger.error('Uncaught Exception', {
        error: error.message,
        stack: error.stack
      });
      this.shutdown('uncaughtException').then(() => {
        process.exit(1);
      });
    });
    
    // 处理未处理的Promise拒绝
    process.on('unhandledRejection', (reason, promise) => {
      this.logger.error('Unhandled Promise Rejection', {
        reason: reason?.message || reason,
        stack: reason?.stack
      });
      // 不立即关闭，只记录日志
    });
  }

  /**
   * 启动服务器
   */
  async start() {
    try {
      // 确保服务未在关闭中
      if (this.isShuttingDown) {
        throw new Error('Server is shutting down, cannot start');
      }
      
      // 初始化所有组件
      await this.initialize();
      
      // 启动HTTP服务器
      this.server = this.app.listen(this.port, this.host, () => {
        this.logger.info(`Event Bus Server is running on ${this.host}:${this.port}`, {
          host: this.host,
          port: this.port,
          environment: this.config.get('NODE_ENV', 'development')
        });
        
        // 设置服务器超时
        this.server.timeout = 60000; // 60秒
        
        // 处理连接错误
        this.server.on('error', (error) => {
          if (error.code === 'EADDRINUSE') {
            this.logger.error(`Port ${this.port} is already in use`, {
              port: this.port
            });
            process.exit(1);
          }
          
          this.logger.error('Server error', {
            error: error.message
          });
        });
      });
      
      return this.server;
    } catch (error) {
      this.logger.error('Failed to start server', {
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 优雅关闭服务器
   */
  async shutdown(signal) {
    try {
      if (this.isShuttingDown) {
        this.logger.warn('Shutdown already in progress');
        return;
      }
      
      this.isShuttingDown = true;
      this.logger.info(`Starting graceful shutdown (signal: ${signal})...`);
      
      const shutdownSteps = [];
      
      // 1. 关闭HTTP服务器
      if (this.server) {
        shutdownSteps.push(new Promise((resolve) => {
          this.logger.info('Closing HTTP server...');
          this.server.close(() => {
            this.logger.info('HTTP server closed');
            resolve();
          });
          
          // 设置超时
          setTimeout(() => {
            this.logger.warn('HTTP server close timeout, forcing shutdown');
            resolve();
          }, 10000); // 10秒超时
        }));
      }
      
      // 2. 关闭事件处理器
      shutdownSteps.push(this.eventProcessor.shutdown().catch((error) => {
        this.logger.error('Error shutting down event processor', {
          error: error.message
        });
      }));
      
      // 3. 关闭RabbitMQ连接
      shutdownSteps.push(this.rabbitMQ.disconnect().catch((error) => {
        this.logger.error('Error disconnecting from RabbitMQ', {
          error: error.message
        });
      }));
      
      // 4. 关闭数据库连接
      shutdownSteps.push(this.db.disconnect().catch((error) => {
        this.logger.error('Error disconnecting from database', {
          error: error.message
        });
      }));
      
      // 等待所有步骤完成
      await Promise.all(shutdownSteps);
      
      this.logger.info('Graceful shutdown completed');
      
      // 退出进程
      process.exit(0);
    } catch (error) {
      this.logger.error('Error during shutdown', {
        error: error.message
      });
      process.exit(1);
    }
  }

  /**
   * 生成请求ID
   */
  generateRequestId() {
    const crypto = require('crypto');
    return crypto.randomUUID();
  }

  /**
   * 获取应用实例（用于测试）
   */
  getApp() {
    return this.app;
  }

  /**
   * 获取服务器状态
   */
  getStatus() {
    return {
      running: !!this.server,
      shuttingDown: this.isShuttingDown,
      port: this.port,
      host: this.host,
      uptime: process.uptime(),
      connections: this.server ? this.getConnections() : 0
    };
  }

  /**
   * 获取当前连接数（近似值）
   */
  getConnections() {
    try {
      if (this.server) {
        // Express服务器不直接暴露连接数，返回近似值
        return 'N/A';
      }
      return 0;
    } catch (error) {
      return 0;
    }
  }
}

module.exports = EventBusServer;