const { getInstance: getEventModelInstance } = require('../models/EventModel');
const { getInstance: getRabbitMQInstance } = require('../services/RabbitMQService');
const { getInstance: getEventProcessingInstance } = require('../services/EventProcessingService');
const { getInstance: getLoggerInstance } = require('../utils/logger');
const { getInstance: getConfigInstance } = require('../config/app');

/**
 * 事件控制器类
 * 处理事件相关的HTTP请求
 */
class EventController {
  constructor() {
    this.eventModel = getEventModelInstance();
    this.rabbitMQService = getRabbitMQInstance();
    this.eventProcessingService = getEventProcessingInstance();
    this.logger = getLoggerInstance();
    this.config = getConfigInstance();
  }

  /**
   * 发布事件
   */
  async publishEvent(req, res) {
    try {
      const { name, data, headers, idempotencyKey } = req.body;

      // 验证请求参数
      if (!name) {
        this.logger.warn('Event name is required', {
          clientIp: req.ip
        });
        return res.status(400).json({
          success: false,
          error: 'Event name is required'
        });
      }

      // 验证事件名称
      if (!this.isValidEventName(name)) {
        this.logger.warn('Invalid event name format', {
          eventName: name,
          clientIp: req.ip
        });
        return res.status(400).json({
          success: false,
          error: 'Invalid event name format'
        });
      }

      // 生成事件ID
      const eventId = this.generateEventId();
      const timestamp = new Date().toISOString();

      // 创建事件对象
      const event = {
        eventId,
        name,
        data: data || {},
        headers: headers || {},
        idempotencyKey,
        timestamp,
        source: 'api',
        sourceService: req.headers['x-service-name'] || 'unknown',
        status: 'pending'
      };

      // 记录审计日志
      this.logger.logAudit('event.publish_request', {
        eventName: name,
        clientIp: req.ip,
        sourceService: event.sourceService,
        eventId
      });

      const startTime = Date.now();

      // 保存事件到数据库
      await this.eventModel.createEvent(event);

      // 发布事件到RabbitMQ
      await this.rabbitMQService.publish('events.topic', name, event, {
        persistent: true,
        messageId: eventId,
        timestamp: new Date(timestamp).getTime(),
        headers: {
          'x-event-source': event.source,
          'x-service-name': event.sourceService,
          'x-idempotency-key': idempotencyKey
        }
      });

      const publishTime = Date.now() - startTime;

      // 记录性能日志
      this.logger.logPerformance('event.publish', publishTime, {
        eventName: name,
        eventId
      });

      // 记录发布日志
      this.logger.logEvent('event.published', {
        eventName: name,
        eventId,
        source: event.source,
        sourceService: event.sourceService
      });

      // 返回成功响应
      return res.status(202).json({
        success: true,
        message: 'Event published successfully',
        data: {
          eventId,
          name,
          timestamp,
          status: 'published'
        },
        meta: {
          processingTime: publishTime
        }
      });

    } catch (error) {
      this.logger.error('Error publishing event', {
        error: error.message,
        stack: error.stack,
        requestBody: req.body
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to publish event',
        errorDetails: error.message
      });
    }
  }

  /**
   * 获取事件详情
   */
  async getEventDetails(req, res) {
    try {
      const { eventId } = req.params;

      // 验证事件ID
      if (!eventId) {
        return res.status(400).json({
          success: false,
          error: 'Event ID is required'
        });
      }

      // 从数据库获取事件详情
      const event = await this.eventModel.getEventById(eventId);
      
      if (!event) {
        return res.status(404).json({
          success: false,
          error: 'Event not found'
        });
      }

      // 记录请求日志
      this.logger.logRequest('event.get_details', {
        eventId,
        eventName: event.name,
        clientIp: req.ip
      });

      return res.status(200).json({
        success: true,
        data: event
      });

    } catch (error) {
      this.logger.error('Error getting event details', {
        eventId: req.params.eventId,
        error: error.message
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to get event details'
      });
    }
  }

  /**
   * 搜索事件列表
   */
  async searchEvents(req, res) {
    try {
      const { name, status, source, startTime, endTime, page = 1, limit = 20 } = req.query;

      // 构建查询条件
      const query = {};
      
      if (name) {
        query.name = new RegExp(name, 'i');
      }
      
      if (status) {
        query.status = status;
      }
      
      if (source) {
        query.source = source;
      }
      
      if (startTime || endTime) {
        query.timestamp = {};
        if (startTime) {
          query.timestamp.$gte = new Date(startTime);
        }
        if (endTime) {
          query.timestamp.$lte = new Date(endTime);
        }
      }

      // 验证分页参数
      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      
      if (isNaN(pageNum) || pageNum < 1) {
        return res.status(400).json({
          success: false,
          error: 'Invalid page number'
        });
      }
      
      if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
        return res.status(400).json({
          success: false,
          error: 'Invalid limit (must be between 1 and 100)'
        });
      }

      const startTimeMs = Date.now();
      
      // 执行搜索
      const result = await this.eventModel.searchEvents(query, {
        page: pageNum,
        limit: limitNum,
        sortBy: 'timestamp',
        sortOrder: -1 // 降序
      });

      const searchTime = Date.now() - startTimeMs;

      // 记录性能日志
      this.logger.logPerformance('event.search', searchTime, {
        query: JSON.stringify(query),
        page: pageNum,
        limit: limitNum,
        results: result.total
      });

      return res.status(200).json({
        success: true,
        data: result.events,
        meta: {
          total: result.total,
          page: pageNum,
          limit: limitNum,
          pages: Math.ceil(result.total / limitNum),
          processingTime: searchTime
        }
      });

    } catch (error) {
      this.logger.error('Error searching events', {
        error: error.message,
        query: req.query
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to search events'
      });
    }
  }

  /**
   * 获取事件统计信息
   */
  async getEventStats(req, res) {
    try {
      const { startTime, endTime } = req.query;

      // 验证时间范围
      const timeRange = {};
      if (startTime) {
        timeRange.startTime = new Date(startTime);
      }
      if (endTime) {
        timeRange.endTime = new Date(endTime);
      }

      const startTimeMs = Date.now();
      
      // 获取统计信息
      const stats = await this.eventModel.getEventStats(timeRange);

      const processingTime = Date.now() - startTimeMs;

      // 记录性能日志
      this.logger.logPerformance('event.stats', processingTime, {
        timeRange: JSON.stringify(timeRange)
      });

      return res.status(200).json({
        success: true,
        data: stats,
        meta: {
          processingTime
        }
      });

    } catch (error) {
      this.logger.error('Error getting event stats', {
        error: error.message,
        query: req.query
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to get event statistics'
      });
    }
  }

  /**
   * 重试失败的事件
   */
  async retryEvent(req, res) {
    try {
      const { eventId } = req.params;
      const { force } = req.body;

      // 验证事件ID
      if (!eventId) {
        return res.status(400).json({
          success: false,
          error: 'Event ID is required'
        });
      }

      // 获取事件详情
      const event = await this.eventModel.getEventById(eventId);
      
      if (!event) {
        return res.status(404).json({
          success: false,
          error: 'Event not found'
        });
      }

      // 检查事件状态
      if (event.status !== 'failed' && !force) {
        return res.status(400).json({
          success: false,
          error: `Cannot retry event with status: ${event.status}. Use force=true to retry anyway.`
        });
      }

      // 更新事件状态为重试中
      await this.eventModel.updateEventStatus(eventId, 'retrying', {
        retryCount: (event.metadata?.retryCount || 0) + 1,
        retriedAt: new Date().toISOString()
      });

      // 重新发布事件
      await this.rabbitMQService.publish('events.topic', event.name, {
        ...event,
        headers: {
          ...event.headers,
          retryCount: (event.metadata?.retryCount || 0) + 1,
          retriedAt: new Date().toISOString()
        }
      }, {
        persistent: true,
        messageId: eventId,
        headers: {
          'x-retry-count': (event.metadata?.retryCount || 0) + 1
        }
      });

      // 记录日志
      this.logger.logEvent('event.retried', {
        eventId,
        eventName: event.name,
        retryCount: (event.metadata?.retryCount || 0) + 1
      });

      return res.status(202).json({
        success: true,
        message: 'Event scheduled for retry',
        data: {
          eventId,
          name: event.name,
          status: 'retrying',
          retryCount: (event.metadata?.retryCount || 0) + 1
        }
      });

    } catch (error) {
      this.logger.error('Error retrying event', {
        eventId: req.params.eventId,
        error: error.message
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to retry event'
      });
    }
  }

  /**
   * 取消事件处理
   */
  async cancelEvent(req, res) {
    try {
      const { eventId } = req.params;

      // 验证事件ID
      if (!eventId) {
        return res.status(400).json({
          success: false,
          error: 'Event ID is required'
        });
      }

      // 获取事件详情
      const event = await this.eventModel.getEventById(eventId);
      
      if (!event) {
        return res.status(404).json({
          success: false,
          error: 'Event not found'
        });
      }

      // 检查事件状态
      if (event.status === 'completed' || event.status === 'cancelled' || event.status === 'failed') {
        return res.status(400).json({
          success: false,
          error: `Cannot cancel event with status: ${event.status}`
        });
      }

      // 更新事件状态为已取消
      await this.eventModel.updateEventStatus(eventId, 'cancelled', {
        cancelledAt: new Date().toISOString(),
        cancelledBy: req.user?.id || 'system'
      });

      // 记录日志
      this.logger.logEvent('event.cancelled', {
        eventId,
        eventName: event.name,
        cancelledBy: req.user?.id || 'system'
      });

      return res.status(200).json({
        success: true,
        message: 'Event cancelled successfully',
        data: {
          eventId,
          name: event.name,
          status: 'cancelled'
        }
      });

    } catch (error) {
      this.logger.error('Error cancelling event', {
        eventId: req.params.eventId,
        error: error.message
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to cancel event'
      });
    }
  }

  /**
   * 订阅事件
   */
  async subscribeToEvent(req, res) {
    try {
      const { eventName, handlerUrl, queueName, options = {} } = req.body;

      // 验证必要参数
      if (!eventName || !handlerUrl) {
        return res.status(400).json({
          success: false,
          error: 'Event name and handler URL are required'
        });
      }

      // 验证事件名称格式
      if (!this.isValidEventName(eventName)) {
        return res.status(400).json({
          success: false,
          error: 'Invalid event name format'
        });
      }

      // 创建webhook处理器
      const handler = async (event) => {
        try {
          const webhookResult = await this.sendWebhook(handlerUrl, event);
          return webhookResult;
        } catch (error) {
          this.logger.error('Webhook handler failed', {
            eventName,
            handlerUrl,
            error: error.message
          });
          throw error;
        }
      };

      // 订阅事件
      const subscription = await this.eventProcessingInstance.subscribeToEvent(
        eventName,
        handler,
        {
          queueName,
          ...options,
          webhookUrl: handlerUrl
        }
      );

      // 记录订阅日志
      this.logger.logEvent('event.subscription.created', {
        eventName,
        subscriptionId: subscription.handlerId,
        webhookUrl: handlerUrl,
        queueName: subscription.queueName
      });

      return res.status(201).json({
        success: true,
        message: 'Successfully subscribed to event',
        data: {
          subscriptionId: subscription.handlerId,
          eventName,
          webhookUrl: handlerUrl,
          queueName: subscription.queueName
        }
      });

    } catch (error) {
      this.logger.error('Error subscribing to event', {
        error: error.message,
        requestBody: req.body
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to subscribe to event'
      });
    }
  }

  /**
   * 取消订阅事件
   */
  async unsubscribeFromEvent(req, res) {
    try {
      const { eventName, subscriptionId } = req.params;

      // 验证参数
      if (!eventName || !subscriptionId) {
        return res.status(400).json({
          success: false,
          error: 'Event name and subscription ID are required'
        });
      }

      // 取消订阅
      await this.eventProcessingInstance.unsubscribeFromEvent(eventName, subscriptionId);

      // 记录日志
      this.logger.logEvent('event.subscription.cancelled', {
        eventName,
        subscriptionId
      });

      return res.status(200).json({
        success: true,
        message: 'Successfully unsubscribed from event',
        data: {
          eventName,
          subscriptionId
        }
      });

    } catch (error) {
      this.logger.error('Error unsubscribing from event', {
        eventName: req.params.eventName,
        subscriptionId: req.params.subscriptionId,
        error: error.message
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to unsubscribe from event'
      });
    }
  }

  /**
   * 获取服务健康状态
   */
  async getHealthStatus(req, res) {
    try {
      const startTime = Date.now();
      
      // 获取各服务的健康状态
      const [processingStatus, rabbitmqStatus] = await Promise.all([
        this.eventProcessingInstance.getHealthStatus(),
        this.rabbitMQService.getHealthStatus()
      ]);

      const overallStatus = processingStatus.status === 'healthy' && rabbitmqStatus.status === 'healthy' 
        ? 'healthy' 
        : 'degraded';

      const processingTime = Date.now() - startTime;

      return res.status(overallStatus === 'healthy' ? 200 : 503).json({
        success: true,
        status: overallStatus,
        services: {
          eventProcessing: processingStatus,
          rabbitmq: rabbitmqStatus
        },
        meta: {
          processingTime,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      this.logger.error('Error getting health status', {
        error: error.message
      });
      
      return res.status(500).json({
        success: false,
        status: 'error',
        error: 'Failed to get health status',
        errorDetails: error.message
      });
    }
  }

  /**
   * 发送webhook请求
   */
  async sendWebhook(url, data) {
    const axios = require('axios');
    
    try {
      const response = await axios.post(url, data, {
        headers: {
          'Content-Type': 'application/json',
          'X-Event-Bus-Event': data.name,
          'X-Event-Bus-Id': data.eventId,
          'X-Event-Bus-Timestamp': data.timestamp
        },
        timeout: 5000 // 5秒超时
      });

      return {
        success: true,
        status: response.status,
        data: response.data
      };
    } catch (error) {
      this.logger.error('Webhook request failed', {
        url,
        eventName: data.name,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * 验证事件名称格式
   */
  isValidEventName(name) {
    // 只允许字母、数字、点和下划线
    const eventNameRegex = /^[a-zA-Z0-9_.]+$/;
    return eventNameRegex.test(name);
  }

  /**
   * 生成事件ID
   */
  generateEventId() {
    const crypto = require('crypto');
    return crypto.randomUUID();
  }

  /**
   * 批量发布事件
   */
  async batchPublishEvents(req, res) {
    try {
      const { events } = req.body;

      // 验证请求参数
      if (!Array.isArray(events)) {
        return res.status(400).json({
          success: false,
          error: 'Events must be an array'
        });
      }

      // 限制批量大小
      if (events.length > 100) {
        return res.status(400).json({
          success: false,
          error: 'Maximum batch size is 100 events'
        });
      }

      const results = [];
      const startTime = Date.now();

      // 批量处理事件
      for (const eventData of events) {
        try {
          // 生成事件ID
          const eventId = this.generateEventId();
          const timestamp = new Date().toISOString();

          // 创建事件对象
          const event = {
            eventId,
            name: eventData.name,
            data: eventData.data || {},
            headers: eventData.headers || {},
            idempotencyKey: eventData.idempotencyKey,
            timestamp,
            source: 'api.batch',
            sourceService: req.headers['x-service-name'] || 'unknown',
            status: 'pending'
          };

          // 保存到数据库
          await this.eventModel.createEvent(event);

          // 发布到RabbitMQ
          await this.rabbitMQService.publish('events.topic', event.name, event, {
            persistent: true,
            messageId: eventId
          });

          results.push({
            success: true,
            eventId,
            name: event.name
          });

        } catch (error) {
          results.push({
            success: false,
            error: error.message,
            event: eventData
          });
        }
      }

      const processingTime = Date.now() - startTime;

      // 统计结果
      const successCount = results.filter(r => r.success).length;
      const errorCount = results.length - successCount;

      // 记录日志
      this.logger.logEvent('event.batch_published', {
        total: events.length,
        success: successCount,
        failed: errorCount
      });

      return res.status(successCount > 0 ? 207 : 500).json({
        success: errorCount === 0,
        message: `Batch publish completed: ${successCount} succeeded, ${errorCount} failed`,
        data: results,
        meta: {
          total: events.length,
          success: successCount,
          failed: errorCount,
          processingTime
        }
      });

    } catch (error) {
      this.logger.error('Error in batch publish', {
        error: error.message,
        requestBody: req.body
      });
      
      return res.status(500).json({
        success: false,
        error: 'Failed to process batch publish'
      });
    }
  }
}

// 导出单例实例
let eventControllerInstance = null;

function getInstance() {
  if (!eventControllerInstance) {
    eventControllerInstance = new EventController();
  }
  return eventControllerInstance;
}

module.exports = {
  EventController,
  getInstance
};