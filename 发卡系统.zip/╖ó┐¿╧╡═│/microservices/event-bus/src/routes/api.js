const express = require('express');
const { getInstance: getEventControllerInstance } = require('../controllers/EventController');
const { getInstance: getLoggerInstance } = require('../utils/logger');
const { getInstance: getConfigInstance } = require('../config/app');

/**
 * API路由类
 * 配置所有API端点路由
 */
class ApiRouter {
  constructor() {
    this.router = express.Router();
    this.eventController = getEventControllerInstance();
    this.logger = getLoggerInstance();
    this.config = getConfigInstance();
    this.setupRoutes();
  }

  /**
   * 设置所有API路由
   */
  setupRoutes() {
    // 健康检查路由
    this.setupHealthRoutes();
    
    // 事件管理路由
    this.setupEventRoutes();
    
    // 订阅管理路由
    this.setupSubscriptionRoutes();
    
    // 统计和监控路由
    this.setupStatsRoutes();
    
    // 批量操作路由
    this.setupBatchRoutes();
    
    // 系统管理路由
    this.setupSystemRoutes();
    
    // 错误处理中间件
    this.setupErrorHandlers();
  }

  /**
   * 设置健康检查路由
   */
  setupHealthRoutes() {
    // 基本健康检查
    this.router.get('/health', this.wrapRoute(this.eventController.getHealthStatus.bind(this.eventController)));
    
    // 详细健康检查（包含所有组件状态）
    this.router.get('/health/details', this.wrapRoute(this.eventController.getHealthStatus.bind(this.eventController)));
    
    // 就绪检查
    this.router.get('/ready', this.wrapRoute((req, res) => {
      return res.status(200).json({
        status: 'ready',
        timestamp: new Date().toISOString()
      });
    }));
  }

  /**
   * 设置事件管理路由
   */
  setupEventRoutes() {
    const eventRoutes = express.Router();
    
    // 发布事件
    eventRoutes.post('/', this.wrapRoute(this.eventController.publishEvent.bind(this.eventController)));
    
    // 获取事件详情
    eventRoutes.get('/:eventId', this.wrapRoute(this.eventController.getEventDetails.bind(this.eventController)));
    
    // 搜索事件
    eventRoutes.get('/', this.wrapRoute(this.eventController.searchEvents.bind(this.eventController)));
    
    // 重试失败事件
    eventRoutes.post('/:eventId/retry', this.wrapRoute(this.eventController.retryEvent.bind(this.eventController)));
    
    // 取消事件
    eventRoutes.post('/:eventId/cancel', this.wrapRoute(this.eventController.cancelEvent.bind(this.eventController)));
    
    // 挂载事件路由
    this.router.use('/events', eventRoutes);
  }

  /**
   * 设置订阅管理路由
   */
  setupSubscriptionRoutes() {
    const subscriptionRoutes = express.Router();
    
    // 创建订阅
    subscriptionRoutes.post('/', this.wrapRoute(this.eventController.subscribeToEvent.bind(this.eventController)));
    
    // 取消订阅
    subscriptionRoutes.delete('/:eventName/:subscriptionId', this.wrapRoute(this.eventController.unsubscribeFromEvent.bind(this.eventController)));
    
    // 挂载订阅路由
    this.router.use('/subscriptions', subscriptionRoutes);
  }

  /**
   * 设置统计和监控路由
   */
  setupStatsRoutes() {
    const statsRoutes = express.Router();
    
    // 获取事件统计
    statsRoutes.get('/events', this.wrapRoute(this.eventController.getEventStats.bind(this.eventController)));
    
    // 挂载统计路由
    this.router.use('/stats', statsRoutes);
  }

  /**
   * 设置批量操作路由
   */
  setupBatchRoutes() {
    const batchRoutes = express.Router();
    
    // 批量发布事件
    batchRoutes.post('/events', this.wrapRoute(this.eventController.batchPublishEvents.bind(this.eventController)));
    
    // 挂载批量操作路由
    this.router.use('/batch', batchRoutes);
  }

  /**
   * 设置系统管理路由
   */
  setupSystemRoutes() {
    const systemRoutes = express.Router();
    
    // 获取系统信息
    systemRoutes.get('/info', this.wrapRoute((req, res) => {
      return res.status(200).json({
        service: 'event-bus',
        version: this.config.get('VERSION', '1.0.0'),
        environment: this.config.get('NODE_ENV', 'development'),
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
      });
    }));
    
    // 挂载系统管理路由
    this.router.use('/system', systemRoutes);
  }

  /**
   * 设置错误处理中间件
   */
  setupErrorHandlers() {
    // 404处理
    this.router.use((req, res) => {
      this.logger.warn('API endpoint not found', {
        method: req.method,
        url: req.url,
        clientIp: req.ip
      });
      
      return res.status(404).json({
        success: false,
        error: 'API endpoint not found',
        path: req.path
      });
    });
    
    // 全局错误处理
    this.router.use((err, req, res, next) => {
      this.logger.error('API error handler', {
        error: err.message,
        stack: err.stack,
        method: req.method,
        url: req.url
      });
      
      // 处理特定类型的错误
      if (err.name === 'ValidationError') {
        return res.status(400).json({
          success: false,
          error: 'Validation error',
          details: err.errors
        });
      }
      
      if (err.name === 'UnauthorizedError') {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized access'
        });
      }
      
      // 默认500错误
      return res.status(500).json({
        success: false,
        error: 'Internal server error',
        errorCode: err.code || 'INTERNAL_ERROR'
      });
    });
  }

  /**
   * 路由包装器，用于错误处理和日志记录
   */
  wrapRoute(handler) {
    return async (req, res, next) => {
      const startTime = Date.now();
      const requestId = req.headers['x-request-id'] || this.generateRequestId();
      
      // 添加请求ID到响应头
      res.setHeader('X-Request-ID', requestId);
      
      try {
        // 记录请求开始
        this.logger.logRequest(req.method, req.path, {
          requestId,
          clientIp: req.ip,
          userAgent: req.headers['user-agent'],
          serviceName: req.headers['x-service-name']
        });
        
        // 执行路由处理器
        await handler(req, res, next);
        
        // 记录请求完成
        const duration = Date.now() - startTime;
        this.logger.logPerformance(`api.${req.method.toLowerCase()}.${req.path.replace(/\//g, '.')}`, duration, {
          requestId,
          path: req.path,
          method: req.method,
          status: res.statusCode
        });
        
      } catch (error) {
        // 记录错误
        this.logger.error('Route handler error', {
          requestId,
          method: req.method,
          path: req.path,
          error: error.message,
          stack: error.stack
        });
        
        // 传递给错误处理中间件
        next(error);
      }
    };
  }

  /**
   * 生成请求ID
   */
  generateRequestId() {
    const crypto = require('crypto');
    return crypto.randomUUID();
  }

  /**
   * 获取配置好的路由实例
   */
  getRouter() {
    return this.router;
  }
}

module.exports = ApiRouter;