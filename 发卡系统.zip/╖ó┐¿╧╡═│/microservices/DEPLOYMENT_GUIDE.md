# 智能搜索与推荐系统部署指南

本文档提供了发卡系统智能搜索与推荐系统的完整部署流程和配置说明。

## 目录结构

```
microservices/
├── search-service/       # 搜索服务
├── recommendation-service/ # 推荐服务
├── preprocessing-service/ # 数据预处理服务
```

## 环境要求

- Docker 20.10+
- Docker Compose 2.0+
- PHP 8.0+
- MySQL 5.7+
- Redis 6.0+
- Node.js 16.0+

## 部署步骤

### 1. 准备微服务构建环境

为每个微服务创建 Dockerfile：

#### 搜索服务 Dockerfile

在 `microservices/search-service` 目录创建 `Dockerfile`：

```dockerfile
FROM php:8.1-fpm

WORKDIR /var/www/html

# 安装依赖
RUN apt-get update && apt-get install -y \
    git \
    unzip \
    libzip-dev \
    redis-tools \
    && docker-php-ext-install zip pdo pdo_mysql

# 安装 Composer
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# 复制项目文件
COPY . .

# 安装 PHP 依赖
RUN composer install --no-dev --optimize-autoloader

# 设置权限
RUN chown -R www-data:www-data /var/www/html

# 暴露端口
EXPOSE 3000

# 启动服务
CMD ["php", "-S", "0.0.0.0:3000", "-t", "./public"]
```

#### 推荐服务 Dockerfile

在 `microservices/recommendation-service` 目录创建 `Dockerfile`：

```dockerfile
FROM php:8.1-fpm

WORKDIR /var/www/html

# 安装依赖
RUN apt-get update && apt-get install -y \
    git \
    unzip \
    libzip-dev \
    redis-tools \
    && docker-php-ext-install zip pdo pdo_mysql

# 安装 Composer
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# 复制项目文件
COPY . .

# 安装 PHP 依赖
RUN composer install --no-dev --optimize-autoloader

# 设置权限
RUN chown -R www-data:www-data /var/www/html

# 暴露端口
EXPOSE 3001

# 启动服务
CMD ["php", "-S", "0.0.0.0:3001", "-t", "./public"]
```

#### 预处理服务 Dockerfile

在 `microservices/preprocessing-service` 目录创建 `Dockerfile`：

```dockerfile
FROM php:8.1-fpm

WORKDIR /var/www/html

# 安装依赖
RUN apt-get update && apt-get install -y \
    git \
    unzip \
    libzip-dev \
    redis-tools \
    && docker-php-ext-install zip pdo pdo_mysql

# 安装 Composer
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# 复制项目文件
COPY . .

# 安装 PHP 依赖
RUN composer install --no-dev --optimize-autoloader

# 设置权限
RUN chown -R www-data:www-data /var/www/html

# 暴露端口
EXPOSE 3002

# 启动服务
CMD ["php", "-S", "0.0.0.0:3002", "-t", "./public"]
```

### 2. 数据库配置

确保 MySQL 数据库中包含必要的表结构。在 `docker/init-db` 目录中添加初始化脚本：

```sql
-- 搜索服务表结构
CREATE TABLE IF NOT EXISTS `search_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `rating` float DEFAULT NULL,
  `sales_count` int(11) DEFAULT 0,
  `search_vector` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX idx_product_id (`product_id`),
  INDEX idx_category_id (`category_id`),
  INDEX idx_price (`price`),
  INDEX idx_rating (`rating`),
  INDEX idx_sales_count (`sales_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 推荐服务表结构
CREATE TABLE IF NOT EXISTS `user_behavior` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `behavior_type` enum('view','click','search','purchase','favorite') NOT NULL,
  `behavior_value` float DEFAULT 1.0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX idx_user_product (`user_id`,`product_id`),
  INDEX idx_behavior_type (`behavior_type`),
  INDEX idx_created_at (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `recommendations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `recommendation_type` enum('personalized','popular','related','recent') NOT NULL,
  `score` float NOT NULL,
  `position` int(11) NOT NULL,
  `generated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP + INTERVAL 24 HOUR,
  PRIMARY KEY (`id`),
  INDEX idx_user_type (`user_id`,`recommendation_type`),
  INDEX idx_product_id (`product_id`),
  INDEX idx_expires_at (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 预处理服务表结构
CREATE TABLE IF NOT EXISTS `preprocessing_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_type` enum('full','incremental','optimize') NOT NULL,
  `status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `processed_count` int(11) DEFAULT 0,
  `total_count` int(11) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX idx_status (`status`),
  INDEX idx_task_type (`task_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 3. 配置环境变量

为每个微服务创建 `.env` 文件：

#### 搜索服务 .env

在 `microservices/search-service` 目录创建 `.env`：

```dotenv
APP_ENV=production
APP_DEBUG=false
APP_KEY=your_app_key

# 数据库连接
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=card_system
DB_USERNAME=card_user
DB_PASSWORD=secure_password_123

# Redis 配置
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=redis_password
REDIS_DB=0

# 搜索服务配置
SEARCH_CACHE_TTL=3600
MAX_RESULTS_PER_PAGE=100
DEFAULT_PAGE_SIZE=20
ENABLE_SEARCH_SUGGESTIONS=true
MAX_SUGGESTIONS=10

# 日志配置
LOG_CHANNEL=stack
LOG_LEVEL=info
```

#### 推荐服务 .env

在 `microservices/recommendation-service` 目录创建 `.env`：

```dotenv
APP_ENV=production
APP_DEBUG=false
APP_KEY=your_app_key

# 数据库连接
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=card_system
DB_USERNAME=card_user
DB_PASSWORD=secure_password_123

# Redis 配置
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=redis_password
REDIS_DB=1

# 推荐服务配置
RECOMMENDATION_CACHE_TTL=1800
RECOMMENDATION_LIMIT=20
POPULAR_LIMIT=10
RECENT_LIMIT=15
SIMILAR_LIMIT=8
MIN_BEHAVIOR_DATA=5
ENABLE_PERSONALIZATION=true

# 日志配置
LOG_CHANNEL=stack
LOG_LEVEL=info
```

#### 预处理服务 .env

在 `microservices/preprocessing-service` 目录创建 `.env`：

```dotenv
APP_ENV=production
APP_DEBUG=false
APP_KEY=your_app_key

# 数据库连接
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=card_system
DB_USERNAME=card_user
DB_PASSWORD=secure_password_123

# Redis 配置
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=redis_password
REDIS_DB=2

# 预处理配置
BATCH_SIZE=100
MAX_CONCURRENT_BATCHES=5
OPTIMIZE_INTERVAL=86400
ENABLE_INDEX_OPTIMIZATION=true
MAX_PROCESSING_TIME=3600

# 日志配置
LOG_CHANNEL=stack
LOG_LEVEL=info
```

### 4. 启动服务

使用 Docker Compose 启动所有服务：

```bash
docker-compose up -d
```

验证服务是否正常启动：

```bash
docker-compose ps
```

### 5. 初始化数据索引

执行数据预处理任务，构建初始搜索索引：

```bash
docker exec -it preprocessing-service php artisan preprocessing:init
```

### 6. 配置前端集成

修改前端配置，指向正确的 API 地址：

```javascript
// frontend/src/services/config.js
export default {
  searchApiBase: 'http://localhost:3000',
  recommendApiBase: 'http://localhost:3001',
  apiTimeout: 10000
}
```

## 服务验证

### 测试搜索服务

```bash
curl -X GET "http://localhost:3000/api/search?keyword=游戏点卡&page=1&page_size=10"
```

### 测试推荐服务

```bash
# 获取热门推荐
curl -X GET "http://localhost:3001/api/recommendations/popular?limit=10"

# 获取个性化推荐（需要用户ID）
curl -X GET "http://localhost:3001/api/recommendations/personalized/123?limit=10"
```

## 性能优化建议

1. **数据库索引优化**
   - 确保所有频繁查询的字段都有适当的索引
   - 定期维护 MySQL 索引

2. **缓存策略**
   - 调整 Redis 内存配置
   - 优化缓存过期时间：热门搜索结果可缓存更长时间

3. **资源分配**
   - 根据实际负载调整容器内存和 CPU 限制
   - 生产环境建议单独部署 Elasticsearch

4. **监控与告警**
   - 配置 Prometheus 和 Grafana 监控服务性能
   - 设置关键指标告警（响应时间、错误率、队列长度等）

## 故障排除

### 常见问题

1. **服务启动失败**
   - 检查 Docker Compose 日志：`docker-compose logs [service_name]`
   - 验证环境变量和配置文件

2. **搜索结果不准确**
   - 重新构建索引：`docker exec -it preprocessing-service php artisan preprocessing:rebuild`
   - 检查索引配置和分词设置

3. **推荐质量问题**
   - 增加用户行为数据收集
   - 调整推荐算法参数和权重

4. **性能下降**
   - 检查 Redis 缓存命中率
   - 监控数据库慢查询日志
   - 考虑增加服务实例数量进行负载均衡

## 安全注意事项

1. 生产环境务必修改默认密码
2. 限制 API 访问来源 IP
3. 为所有服务配置 HTTPS
4. 定期更新依赖库以修复安全漏洞
5. 实施 API 访问频率限制

## 维护计划

1. **每日任务**
   - 清理过期缓存
   - 备份行为数据
   - 优化索引

2. **每周任务**
   - 重新计算推荐模型
   - 检查并清理无用数据
   - 审查性能指标

3. **每月任务**
   - 数据库优化
   - 服务版本更新
   - 安全审计

---

如有问题，请联系技术支持团队。