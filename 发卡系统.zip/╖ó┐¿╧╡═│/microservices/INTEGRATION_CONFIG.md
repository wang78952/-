# 智能搜索与推荐系统集成配置

本文档详细说明发卡系统智能搜索与推荐系统的微服务集成配置、API接口约定和通信方式。

## 系统架构

### 微服务组件

- **搜索服务 (search-service)**：提供全文搜索、过滤、排序功能
- **推荐服务 (recommendation-service)**：提供个性化推荐、热门推荐、相关推荐功能
- **数据预处理服务 (preprocessing-service)**：负责数据清洗、特征提取和索引构建
- **前端应用**：用户界面，调用搜索和推荐服务

### 数据流向

```
前端 -> 搜索服务 -> 数据库/Redis
前端 -> 推荐服务 -> 数据库/Redis
数据预处理服务 -> 数据库/Redis -> 搜索服务/推荐服务
```

## 服务发现与配置

### 1. 环境变量配置

所有微服务通过环境变量进行配置管理：

#### 共享配置项

```dotenv
# 数据库连接（所有服务共用）
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=card_system
DB_USERNAME=card_user
DB_PASSWORD=secure_password_123

# Redis配置（所有服务共用）
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=redis_password

# 服务发现配置
SERVICE_DISCOVERY_TYPE=static
LOG_LEVEL=info
ENVIRONMENT=production
```

### 2. 服务间通信配置

#### 搜索服务配置

```dotenv
# 搜索服务特有配置
SEARCH_SERVICE_PORT=3000
SEARCH_CACHE_TTL=3600
SEARCH_MAX_RESULTS_PER_PAGE=100

# 其他服务地址
RECOMMENDATION_SERVICE_URL=http://recommendation-service:3001
PREPROCESSING_SERVICE_URL=http://preprocessing-service:3002
```

#### 推荐服务配置

```dotenv
# 推荐服务特有配置
RECOMMENDATION_SERVICE_PORT=3001
RECOMMENDATION_CACHE_TTL=1800
RECOMMENDATION_LIMIT=20

# 其他服务地址
SEARCH_SERVICE_URL=http://search-service:3000
PREPROCESSING_SERVICE_URL=http://preprocessing-service:3002
```

#### 预处理服务配置

```dotenv
# 预处理服务特有配置
PREPROCESSING_SERVICE_PORT=3002
BATCH_SIZE=100
MAX_CONCURRENT_BATCHES=5

# 其他服务地址
SEARCH_SERVICE_URL=http://search-service:3000
RECOMMENDATION_SERVICE_URL=http://recommendation-service:3001
```

## API接口约定

### 1. 搜索服务API

#### 1.1 基础搜索接口

```
URL: /api/search
方法: GET
参数:
  - keyword: string (搜索关键词)
  - page: int (页码，默认1)
  - page_size: int (每页数量，默认20)
  - sort: string (排序方式: price_asc, price_desc, sales_desc, rating_desc, latest)
  - category_id: int (分类ID，可选)
  - brand_id: int (品牌ID，可选)
  - min_price: float (最低价格，可选)
  - max_price: float (最高价格，可选)
  - tags: array (标签数组，可选)
响应:
  {
    "code": 200,
    "data": {
      "items": [
        {
          "product_id": 1,
          "title": "产品标题",
          "description": "产品描述",
          "price": 99.99,
          "discount_price": 89.99,
          "category_id": 10,
          "brand_id": 5,
          "tags": ["热门", "新品"],
          "sales_count": 1000,
          "rating": 4.8
        }
      ],
      "total": 100,
      "page": 1,
      "page_size": 20,
      "total_pages": 5
    },
    "message": "success"
  }
```

#### 1.2 搜索建议接口

```
URL: /api/search/suggestions
方法: GET
参数:
  - keyword: string (搜索关键词前缀)
  - limit: int (返回数量，默认10)
响应:
  {
    "code": 200,
    "data": {
      "suggestions": [
        {
          "keyword": "游戏点卡",
          "popularity": 98
        },
        {
          "keyword": "游戏装备",
          "popularity": 85
        }
      ]
    },
    "message": "success"
  }
```

#### 1.3 热门搜索接口

```
URL: /api/search/hot
方法: GET
参数:
  - limit: int (返回数量，默认10)
响应:
  {
    "code": 200,
    "data": {
      "hot_searches": [
        {
          "keyword": "游戏点卡",
          "count": 1250
        },
        {
          "keyword": "腾讯QQ卡",
          "count": 980
        }
      ]
    },
    "message": "success"
  }
```

### 2. 推荐服务API

#### 2.1 个性化推荐接口

```
URL: /api/recommendations/personalized/{user_id}
方法: GET
参数:
  - user_id: int (用户ID)
  - limit: int (返回数量，默认10)
  - exclude_ids: array (排除的产品ID，可选)
响应:
  {
    "code": 200,
    "data": {
      "recommendations": [
        {
          "product_id": 1,
          "title": "产品标题",
          "price": 99.99,
          "score": 0.95,
          "reason": "您可能对这类产品感兴趣"
        }
      ]
    },
    "message": "success"
  }
```

#### 2.2 热门推荐接口

```
URL: /api/recommendations/popular
方法: GET
参数:
  - limit: int (返回数量，默认10)
  - time_range: string (时间范围: day, week, month, 默认week)
响应:
  {
    "code": 200,
    "data": {
      "recommendations": [
        {
          "product_id": 1,
          "title": "产品标题",
          "price": 99.99,
          "sales_count": 1200,
          "position": 1
        }
      ]
    },
    "message": "success"
  }
```

#### 2.3 相关推荐接口

```
URL: /api/recommendations/related/{product_id}
方法: GET
参数:
  - product_id: int (当前产品ID)
  - limit: int (返回数量，默认8)
响应:
  {
    "code": 200,
    "data": {
      "recommendations": [
        {
          "product_id": 2,
          "title": "相关产品标题",
          "price": 89.99,
          "similarity": 0.87
        }
      ]
    },
    "message": "success"
  }
```

#### 2.4 记录用户行为接口

```
URL: /api/user-behavior
方法: POST
参数:
  - user_id: int (用户ID)
  - product_id: int (产品ID)
  - behavior_type: string (行为类型: view, click, search, purchase, favorite)
  - behavior_value: float (行为权重，可选)
响应:
  {
    "code": 200,
    "data": {"success": true},
    "message": "success"
  }
```

### 3. 数据预处理服务API

#### 3.1 触发预处理任务接口

```
URL: /api/preprocessing/task
方法: POST
参数:
  - task_type: string (任务类型: full, incremental, optimize)
  - scope: string (处理范围: products, categories, all)
响应:
  {
    "code": 200,
    "data": {
      "task_id": 1,
      "status": "pending",
      "estimated_completion_time": "2023-06-01T10:30:00Z"
    },
    "message": "任务创建成功"
  }
```

#### 3.2 查询任务状态接口

```
URL: /api/preprocessing/task/{task_id}
方法: GET
参数:
  - task_id: int (任务ID)
响应:
  {
    "code": 200,
    "data": {
      "task_id": 1,
      "task_type": "full",
      "status": "processing",
      "started_at": "2023-06-01T10:00:00Z",
      "processed_count": 500,
      "total_count": 1000,
      "progress": 50
    },
    "message": "success"
  }
```

#### 3.3 获取索引统计信息接口

```
URL: /api/preprocessing/stats
方法: GET
响应:
  {
    "code": 200,
    "data": {
      "total_documents": 10000,
      "last_updated": "2023-06-01T09:00:00Z",
      "index_size_mb": 50.5,
      "pending_documents": 0
    },
    "message": "success"
  }
```

## 前端服务集成配置

### 1. API代理配置

在前端应用的`vue.config.js`或`vite.config.js`中配置API代理：

```javascript
// vite.config.js示例
export default {
  server: {
    proxy: {
      '/api/search': {
        target: 'http://search-service:3000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/search/, '/api')
      },
      '/api/recommendations': {
        target: 'http://recommendation-service:3001',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/recommendations/, '/api/recommendations')
      }
    }
  }
}
```

### 2. API超时和重试配置

```javascript
// frontend/src/services/config.js
export default {
  // API基础配置
  baseURLs: {
    search: 'http://search-service:3000',
    recommendation: 'http://recommendation-service:3001'
  },
  
  // 超时配置
  timeouts: {
    search: 10000,      // 搜索请求10秒超时
    recommendation: 8000 // 推荐请求8秒超时
  },
  
  // 重试配置
  retry: {
    maxRetries: 2,
    retryDelay: 300,
    retryableStatusCodes: [408, 429, 500, 502, 503, 504]
  },
  
  // 缓存配置
  cache: {
    enabled: true,
    ttl: {
      searchResults: 300,     // 搜索结果缓存5分钟
      recommendations: 180,   // 推荐结果缓存3分钟
      suggestions: 60         // 搜索建议缓存1分钟
    }
  }
}
```

## 缓存策略配置

### 1. Redis键值命名约定

```
# 搜索服务缓存键
search:results:{hash}:{page}:{page_size}       # 搜索结果缓存
search:suggestions:{keyword_prefix}             # 搜索建议缓存
search:hot                                      # 热门搜索缓存

# 推荐服务缓存键
recommend:popular:{time_range}                  # 热门推荐缓存
recommend:personalized:{user_id}:{limit}        # 个性化推荐缓存
recommend:related:{product_id}:{limit}          # 相关推荐缓存

# 预处理服务缓存键
preprocess:task_status:{task_id}                # 预处理任务状态缓存
preprocess:stats                                # 索引统计信息缓存
```

### 2. 缓存失效策略

- **主动失效**：数据更新时主动清除相关缓存
- **定时失效**：设置合理的TTL，自动过期
- **批量失效**：使用模式匹配批量删除相关缓存

```dotenv
# 缓存TTL配置（秒）
SEARCH_RESULTS_TTL=300       # 搜索结果缓存5分钟
SEARCH_SUGGESTIONS_TTL=60    # 搜索建议缓存1分钟
SEARCH_HOT_TTL=3600          # 热门搜索缓存1小时

RECOMMEND_POPULAR_TTL=7200   # 热门推荐缓存2小时
RECOMMEND_PERSONALIZED_TTL=180 # 个性化推荐缓存3分钟
RECOMMEND_RELATED_TTL=300    # 相关推荐缓存5分钟
```

## 服务健康检查

所有微服务提供健康检查端点：

### 1. 健康检查接口

```
URL: /health
方法: GET
响应:
  {
    "status": "healthy",
    "services": {
      "database": "connected",
      "redis": "connected",
      "memory": {"usage_mb": 128, "limit_mb": 512},
      "uptime_seconds": 3600
    },
    "timestamp": "2023-06-01T12:00:00Z"
  }
```

### 2. Docker Compose健康检查配置

```yaml
# 在docker-compose.yml中的服务健康检查配置
healthcheck:
  test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
  interval: 30s
  timeout: 10s
  retries: 3
  start_period: 40s
```

## 日志配置

所有微服务使用统一的日志格式和级别：

### 1. 日志格式

```
{"timestamp":"2023-06-01T12:00:00Z","level":"INFO","service":"search-service","message":"search executed","context":{"keyword":"游戏点卡","results":25,"duration_ms":45}}
```

### 2. 日志级别配置

```dotenv
# 日志级别配置
LOG_LEVEL=info
LOG_FORMAT=json
LOG_FILE=/var/log/services/
LOG_ROTATION_SIZE=50MB
LOG_RETENTION_DAYS=7
```

## 性能监控配置

### 1. 指标收集

所有微服务通过HTTP头暴露性能指标：

```
X-Response-Time: 45ms
X-Query-Count: 2
X-Cache-Status: HIT
X-Errors: 0
```

### 2. 关键监控指标

- **响应时间**：请求处理时间
- **QPS**：每秒查询数
- **缓存命中率**：缓存命中百分比
- **错误率**：请求失败百分比
- **数据库查询时间**：数据库操作耗时

## 安全配置

### 1. CORS配置

所有微服务启用CORS支持：

```dotenv
# CORS配置
CORS_ENABLED=true
CORS_ALLOW_ORIGINS=http://localhost:8080,http://frontend:8080
CORS_ALLOW_METHODS=GET,POST,PUT,DELETE,OPTIONS
CORS_ALLOW_HEADERS=Content-Type,Authorization,X-Requested-With
CORS_MAX_AGE=86400
```

### 2. 限流配置

```dotenv
# API限流配置
RATE_LIMIT_ENABLED=true
RATE_LIMIT_PER_MINUTE=60
RATE_LIMIT_BURST=10
RATE_LIMIT_KEY_TYPE=ip
RATE_LIMIT_EXCLUDE_PATHS=/health,/metrics
```

## 部署与扩展配置

### 1. 水平扩展配置

```dotenv
# 水平扩展相关配置
ENABLE_HORIZONTAL_SCALING=true
MAX_INSTANCES=5
CONTAINER_CPU_LIMIT=1
CONTAINER_MEMORY_LIMIT=512m
```

### 2. 负载均衡配置

通过Nginx配置负载均衡：

```nginx
upstream search_servers {
    server search-service-1:3000;
    server search-service-2:3000;
    server search-service-3:3000;
    
    # 负载均衡算法
    least_conn;
    
    # 健康检查
    keepalive 64;
}

upstream recommendation_servers {
    server recommendation-service-1:3001;
    server recommendation-service-2:3001;
    server recommendation-service-3:3001;
    
    # 负载均衡算法
    least_conn;
    
    # 健康检查
    keepalive 64;
}
```

## 故障恢复配置

### 1. 断路器配置

```dotenv
# 断路器配置
CIRCUIT_BREAKER_ENABLED=true
CIRCUIT_BREAKER_FAILURE_THRESHOLD=50
CIRCUIT_BREAKER_RESET_TIMEOUT=30
CIRCUIT_BREAKER_HALF_OPEN_MAX_CALLS=10
```

### 2. 降级策略配置

```dotenv
# 降级策略配置
DEGRADATION_ENABLED=true
DEGRADATION_MODE=manual
DEGRADATION_FALLBACK_TIMEOUT=1000
```

## 集成测试配置

### 1. 测试环境配置

```dotenv
# 测试环境专用配置
TEST_ENV=true
TEST_DB_DATABASE=card_system_test
TEST_REDIS_DB=10
SKIP_AUTHENTICATION=false
```

### 2. 模拟服务配置

测试时可使用模拟服务：

```javascript
// 测试配置示例
export default {
  useMockServices: false,
  mockServicesUrl: 'http://mock-service:8081',
  testDelay: 500, // 模拟网络延迟
  failRate: 0.05  // 模拟5%的失败率
}
```

## 附录：API文档

所有API接口提供Swagger文档，访问路径：

- 搜索服务API文档：http://search-service:3000/api/documentation
- 推荐服务API文档：http://recommendation-service:3001/api/documentation
- 预处理服务API文档：http://preprocessing-service:3002/api/documentation

---

本文档定期更新，请与代码库保持同步。