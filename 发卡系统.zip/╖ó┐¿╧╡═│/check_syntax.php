<?php
/**
 * 检查文件语法错误的脚本
 */

function checkSyntax($filePath) {
    echo "正在检查: $filePath\n";
    $output = [];
    $return = null;
    
    // 使用PHP命令行工具检查语法
    exec("php -l " . escapeshellarg($filePath), $output, $return);
    
    if ($return === 0) {
        echo "✓ 语法正确\n";
        return true;
    } else {
        echo "✗ 语法错误:\n";
        foreach ($output as $line) {
            echo "  $line\n";
        }
        return false;
    }
}

// 要检查的文件列表
$filesToCheck = [
    'd:/迅雷下载/发卡系统/includes/i18n/Translator.php',
    'd:/迅雷下载/发卡系统/includes/NotificationManager.php',
    'd:/迅雷下载/发卡系统/includes/performance/CompressionManager.php'
];

// 执行检查
$allGood = true;
foreach ($filesToCheck as $file) {
    if (!file_exists($file)) {
        echo "✗ 文件不存在: $file\n";
        $allGood = false;
        continue;
    }
    
    if (!checkSyntax($file)) {
        $allGood = false;
    }
    echo "\n";
}

if ($allGood) {
    echo "所有文件语法检查通过!\n";
    exit(0);
} else {
    echo "部分文件存在语法错误!\n";
    exit(1);
}