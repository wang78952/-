<?php
/**
 * 卡密管理页面
 * 
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

require_once __DIR__ . '/includes/SecurityUtils.php';
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/AuthManager.php';
require_once __DIR__ . '/includes/ComplianceManager.php';
require_once __DIR__ . '/config.php';

// 启动会话
session_start();

// 初始化认证管理器
$authManager = new AuthManager();

// 检查用户登录状态
if (!$authManager->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 检查会话是否过期
if ($authManager->isSessionExpired()) {
    $authManager->logout();
    header('Location: login.php?error=session_expired');
    exit;
}

// 刷新会话
$authManager->refreshSession();

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡密管理 - 发卡系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .card-status-active { color: #28a745; }
        .card-status-used { color: #6c757d; }
        .card-status-expired { color: #dc3545; }
        .card-status-cancelled { color: #fd7e14; }
        .anomaly-high { color: #dc3545; font-weight: bold; }
        .anomaly-medium { color: #fd7e14; }
        .anomaly-low { color: #ffc107; }
        .stats-card {
            transition: transform 0.2s;
        }
        .stats-card:hover {
            transform: translateY(-2px);
        }
        .batch-progress {
            height: 8px;
        }
        .card-code {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-credit-card"></i> 发卡系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">仪表板</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="cards.php">卡密管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">订单管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">产品管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">用户管理</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <!-- 统计卡片 -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stats-card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">总卡密数</h6>
                                <h3 id="totalCards">0</h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-credit-card fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">活跃卡密</h6>
                                <h3 id="activeCards">0</h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-check-circle fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">已使用</h6>
                                <h3 id="usedCards">0</h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-check2 fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card bg-warning text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">异常记录</h6>
                                <h3 id="anomalyCount">0</h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-exclamation-triangle fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 功能选项卡 -->
        <ul class="nav nav-tabs mb-4" id="cardTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="batches-tab" data-bs-toggle="tab" data-bs-target="#batches" type="button">
                    <i class="bi bi-collection"></i> 批次管理
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="cards-tab" data-bs-toggle="tab" data-bs-target="#cards" type="button">
                    <i class="bi bi-credit-card"></i> 卡密列表
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="verify-tab" data-bs-toggle="tab" data-bs-target="#verify" type="button">
                    <i class="bi bi-shield-check"></i> 验证使用
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="anomalies-tab" data-bs-toggle="tab" data-bs-target="#anomalies" type="button">
                    <i class="bi bi-exclamation-triangle"></i> 异常监控
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="statistics-tab" data-bs-toggle="tab" data-bs-target="#statistics" type="button">
                    <i class="bi bi-graph-up"></i> 统计分析
                </button>
            </li>
        </ul>

        <div class="tab-content" id="cardTabsContent">
            <!-- 批次管理 -->
            <div class="tab-pane fade show active" id="batches" role="tabpanel">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">批次管理</h5>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createBatchModal">
                            <i class="bi bi-plus-circle"></i> 创建批次
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>批次号</th>
                                        <th>产品</th>
                                        <th>数量</th>
                                        <th>已生成</th>
                                        <th>进度</th>
                                        <th>状态</th>
                                        <th>创建时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody id="batchesTableBody">
                                    <!-- 动态加载 -->
                                </tbody>
                            </table>
                        </div>
                        <nav>
                            <ul class="pagination justify-content-center" id="batchesPagination">
                                <!-- 动态加载 -->
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>

            <!-- 卡密列表 -->
            <div class="tab-pane fade" id="cards" role="tabpanel">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col">
                                <h5 class="mb-0">卡密列表</h5>
                            </div>
                            <div class="col-auto">
                                <div class="btn-group" role="group">
                                    <button class="btn btn-outline-primary" id="refreshCardsBtn">
                                        <i class="bi bi-arrow-clockwise"></i> 刷新
                                    </button>
                                    <button class="btn btn-outline-success" id="exportCardsBtn">
                                        <i class="bi bi-download"></i> 导出
                                    </button>
                                    <button class="btn btn-outline-warning" id="batchOperationBtn">
                                        <i class="bi bi-gear"></i> 批量操作
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-3">
                                <select class="form-select" id="cardStatusFilter">
                                    <option value="">全部状态</option>
                                    <option value="active">活跃</option>
                                    <option value="used">已使用</option>
                                    <option value="expired">已过期</option>
                                    <option value="cancelled">已取消</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="cardProductFilter">
                                    <option value="">全部产品</option>
                                    <!-- 动态加载 -->
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="cardBatchFilter">
                                    <option value="">全部批次</option>
                                    <!-- 动态加载 -->
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="text" class="form-control" id="cardSearchInput" placeholder="搜索卡密...">
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" id="selectAllCards"></th>
                                        <th>卡密编码</th>
                                        <th>产品</th>
                                        <th>批次</th>
                                        <th>状态</th>
                                        <th>过期时间</th>
                                        <th>使用时间</th>
                                        <th>使用IP</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody id="cardsTableBody">
                                    <!-- 动态加载 -->
                                </tbody>
                            </table>
                        </div>
                        <nav>
                            <ul class="pagination justify-content-center" id="cardsPagination">
                                <!-- 动态加载 -->
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>

            <!-- 验证使用 -->
            <div class="tab-pane fade" id="verify" role="tabpanel">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">验证卡密</h5>
                            </div>
                            <div class="card-body">
                                <form id="verifyCardForm">
                                    <div class="mb-3">
                                        <label for="verifyCardCode" class="form-label">卡密编码</label>
                                        <input type="text" class="form-control card-code" id="verifyCardCode" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="verifyCardSecret" class="form-label">卡密密码</label>
                                        <input type="password" class="form-control card-code" id="verifyCardSecret" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-shield-check"></i> 验证卡密
                                    </button>
                                </form>
                                <div id="verifyResult" class="mt-3"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">使用卡密</h5>
                            </div>
                            <div class="card-body">
                                <form id="redeemCardForm">
                                    <div class="mb-3">
                                        <label for="redeemCardCode" class="form-label">卡密编码</label>
                                        <input type="text" class="form-control card-code" id="redeemCardCode" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="redeemCardSecret" class="form-label">卡密密码</label>
                                        <input type="password" class="form-control card-code" id="redeemCardSecret" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="redeemOrderId" class="form-label">订单ID（可选）</label>
                                        <input type="text" class="form-control" id="redeemOrderId">
                                    </div>
                                    <button type="submit" class="btn btn-success">
                                        <i class="bi bi-check-circle"></i> 使用卡密
                                    </button>
                                </form>
                                <div id="redeemResult" class="mt-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 异常监控 -->
            <div class="tab-pane fade" id="anomalies" role="tabpanel">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">异常监控</h5>
                        <div class="btn-group">
                            <button class="btn btn-outline-primary" id="detectAnomaliesBtn">
                                <i class="bi bi-search"></i> 检测异常
                            </button>
                            <button class="btn btn-outline-success" id="expireCardsBtn">
                                <i class="bi bi-clock-history"></i> 过期处理
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-3">
                                <select class="form-select" id="anomalyTypeFilter">
                                    <option value="">全部类型</option>
                                    <option value="duplicate">重复卡密</option>
                                    <option value="abnormal_usage">异常使用</option>
                                    <option value="expiring_soon">即将过期</option>
                                    <option value="security_risk">安全风险</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="anomalySeverityFilter">
                                    <option value="">全部级别</option>
                                    <option value="low">低</option>
                                    <option value="medium">中</option>
                                    <option value="high">高</option>
                                    <option value="critical">严重</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="anomalyStatusFilter">
                                    <option value="">全部状态</option>
                                    <option value="open">待处理</option>
                                    <option value="investigating">调查中</option>
                                    <option value="resolved">已解决</option>
                                    <option value="ignored">已忽略</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button class="btn btn-outline-secondary" id="refreshAnomaliesBtn">
                                    <i class="bi bi-arrow-clockwise"></i> 刷新
                                </button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>类型</th>
                                        <th>严重程度</th>
                                        <th>描述</th>
                                        <th>状态</th>
                                        <th>创建时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody id="anomaliesTableBody">
                                    <!-- 动态加载 -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 统计分析 -->
            <div class="tab-pane fade" id="statistics" role="tabpanel">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">卡密使用趋势</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="usageChart" width="400" height="200"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">产品分布</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="productChart" width="400" height="200"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">详细统计</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>产品</th>
                                                <th>总数</th>
                                                <th>活跃</th>
                                                <th>已使用</th>
                                                <th>已过期</th>
                                                <th>使用率</th>
                                            </tr>
                                        </thead>
                                        <tbody id="statsTableBody">
                                            <!-- 动态加载 -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 创建批次模态框 -->
    <div class="modal fade" id="createBatchModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">创建卡密批次</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="createBatchForm">
                        <div class="mb-3">
                            <label for="batchProduct" class="form-label">选择产品</label>
                            <select class="form-select" id="batchProduct" required>
                                <!-- 动态加载 -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="batchQuantity" class="form-label">生成数量</label>
                            <input type="number" class="form-control" id="batchQuantity" min="1" max="10000" required>
                        </div>
                        <div class="mb-3">
                            <label for="batchValidDays" class="form-label">有效期（天）</label>
                            <input type="number" class="form-control" id="batchValidDays" min="1" max="3650" value="365" required>
                        </div>
                        <div class="mb-3">
                            <label for="batchPrefix" class="form-label">卡密前缀（可选）</label>
                            <input type="text" class="form-control" id="batchPrefix" maxlength="10" placeholder="如：VIP">
                        </div>
                        <div class="mb-3">
                            <label for="batchDescription" class="form-label">批次描述</label>
                            <textarea class="form-control" id="batchDescription" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" id="createBatchBtn">创建批次</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 批量操作模态框 -->
    <div class="modal fade" id="batchOperationModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">批量操作</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="batchOperationForm">
                        <div class="mb-3">
                            <label for="batchOperationType" class="form-label">操作类型</label>
                            <select class="form-select" id="batchOperationType" required>
                                <option value="">请选择操作</option>
                                <option value="cancel">取消卡密</option>
                                <option value="extend">延长有效期</option>
                                <option value="reset">重置状态</option>
                            </select>
                        </div>
                        <div class="mb-3" id="extendDaysDiv" style="display:none;">
                            <label for="extendDays" class="form-label">延长天数</label>
                            <input type="number" class="form-control" id="extendDays" min="1" max="3650">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">选中卡密数量：<span id="selectedCardCount">0</span></label>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" id="executeBatchOperationBtn">执行操作</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 加载遮罩 -->
    <div class="loading-overlay">
        <div class="spinner-border text-light" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="assets/js/data-loader.js"></script>
    <script src="assets/js/data-loader-init.js"></script>
    <script>
        // 设置当前用户全局变量
        window.currentUser = {
            id: <?php echo json_encode($currentUser['id']); ?>,
            username: <?php echo json_encode($currentUser['username']); ?>,
            role: <?php echo json_encode($currentUser['role']); ?>
        };
    </script>
    <script src="assets/js/cards.js"></script>
</body>
</html>