<?php
require_once 'includes/Database.php';
require_once 'includes/AuthManager.php';
require_once 'includes/SecurityUtils.php';
require_once 'includes/ComplianceManager.php';
require_once 'includes/IdentityVerificationManager.php';
require_once 'config.php';

session_start();

// 检查用户认证
$authManager = new AuthManager();
if (!$authManager->isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$db = Database::getInstance();
$complianceManager = new ComplianceManager($db);
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'user';

if (!$complianceManager->checkDataAccessPermission($userId, $userRole, 'card_activation')) {
    $_SESSION['error'] = '您没有权限访问卡片激活管理';
    header('Location: dashboard.php');
    exit();
}

// 记录数据访问授权
$complianceManager->recordDataAccessAuthorization($userId, 'card_activation', 'view', $_SERVER['REQUEST_URI']);

$db = Database::getInstance();
$identityManager = new IdentityVerificationManager();

// 获取操作参数
$action = $_GET['action'] ?? 'list';
$verificationId = $_GET['id'] ?? 0;
$message = '';
$messageType = '';

// 处理激活操作
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'activate') {
    SecurityUtils::validateCSRFToken($_POST['csrf_token'] ?? '');
    
    $verificationId = $_POST['verification_id'] ?? 0;
    $activationCode = $_POST['activation_code'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    try {
        $result = $identityManager->activateCardInstance($verificationId, $userId, $activationCode, $notes);
        
        if ($result['success']) {
            $message = '卡片激活成功！';
            $messageType = 'success';
            
            // 记录操作日志
            $db->insert('system_logs', [
                'user_id' => $userId,
                'action' => 'card_activated',
                'description' => '激活卡片，核验ID: ' . $verificationId,
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } else {
            $message = $result['message'];
            $messageType = 'danger';
        }
    } catch (Exception $e) {
        $message = '激活失败：' . $e->getMessage();
        $messageType = 'danger';
    }
    
    $action = 'list';
}

// 获取待激活的卡片列表
$pendingActivations = [];
try {
    $pendingActivations = $identityManager->getPendingActivations($userRole);
} catch (Exception $e) {
    error_log('获取待激活列表失败: ' . $e->getMessage());
}

// 获取激活历史
$activationHistory = [];
try {
    $activationHistory = $identityManager->getActivationHistory($userRole);
} catch (Exception $e) {
    error_log('获取激活历史失败: ' . $e->getMessage());
}

// 获取激活统计
$activationStats = [];
try {
    $activationStats = $identityManager->getActivationStats($userRole);
} catch (Exception $e) {
    error_log('获取激活统计失败: ' . $e->getMessage());
}

// 获取特定核验详情
$verificationDetails = null;
if ($verificationId > 0 && $action === 'view') {
    try {
        $verificationDetails = $identityManager->getVerificationDetails($verificationId, $userId, $userRole);
    } catch (Exception $e) {
        $message = '获取核验详情失败：' . $e->getMessage();
        $messageType = 'danger';
        $action = 'list';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡片激活管理 - 发卡系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .activation-card {
            transition: all 0.3s ease;
            border-left: 4px solid #28a745;
        }
        .activation-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .status-pending {
            border-left-color: #ffc107;
        }
        .status-activated {
            border-left-color: #28a745;
        }
        .status-failed {
            border-left-color: #dc3545;
        }
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .activation-form {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
        }
        .security-notice {
            background: linear-gradient(45deg, #fff3cd, #f8d7da);
            border-left: 4px solid #856404;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-credit-card me-2"></i>发卡系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>仪表板
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add_card.php">
                            <i class="fas fa-plus me-1"></i>添加卡片
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_card.php">
                            <i class="fas fa-search me-1"></i>搜索卡片
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update_status.php">
                            <i class="fas fa-edit me-1"></i>更新状态
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="identity_verification.php">
                            <i class="fas fa-user-check me-1"></i>身份核验
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="card_activation.php">
                            <i class="fas fa-key me-1"></i>卡片激活
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">
                            <i class="fas fa-list me-1"></i>系统日志
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compliance.php">
                            <i class="fas fa-shield-alt me-1"></i>合规管理
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>退出登录</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- 数据安全提示 -->
        <div class="alert alert-info security-notice" role="alert">
            <i class="fas fa-shield-alt me-2"></i>
            <strong>数据安全提示：</strong>卡片激活涉及敏感操作，所有激活行为都将被记录并接受合规审计。请确保激活操作符合业务规范和安全要求。
        </div>

        <!-- 激活统计 -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <h5 class="card-title"><i class="fas fa-clock me-2"></i>待激活</h5>
                        <h2 class="mb-0"><?php echo $activationStats['pending'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <h5 class="card-title"><i class="fas fa-check-circle me-2"></i>已激活</h5>
                        <h2 class="mb-0"><?php echo $activationStats['activated'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <h5 class="card-title"><i class="fas fa-times-circle me-2"></i>激活失败</h5>
                        <h2 class="mb-0"><?php echo $activationStats['failed'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <h5 class="card-title"><i class="fas fa-percentage me-2"></i>成功率</h5>
                        <h2 class="mb-0"><?php echo number_format($activationStats['success_rate'] ?? 0, 1); ?>%</h2>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($action === 'list'): ?>
            <div class="row">
                <!-- 待激活列表 -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-clock me-2"></i>待激活卡片</h5>
                            <span class="badge bg-warning"><?php echo count($pendingActivations); ?></span>
                        </div>
                        <div class="card-body">
                            <?php if (empty($pendingActivations)): ?>
                                <div class="text-center text-muted py-4">
                                    <i class="fas fa-check-circle fa-3x mb-3"></i>
                                    <p>暂无待激活的卡片</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($pendingActivations as $activation): ?>
                                    <div class="card activation-card status-pending mb-3">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <h6 class="card-title">
                                                        <i class="fas fa-credit-card me-2"></i>
                                                        卡号: <?php echo htmlspecialchars($activation['masked_card_number']); ?>
                                                    </h6>
                                                    <p class="card-text">
                                                        <small class="text-muted">
                                                            <i class="fas fa-user me-1"></i>持卡人: <?php echo htmlspecialchars($activation['masked_cardholder_name']); ?><br>
                                                            <i class="fas fa-calendar me-1"></i>核验时间: <?php echo htmlspecialchars($activation['verification_date']); ?><br>
                                                            <i class="fas fa-user-shield me-1"></i>审核人: <?php echo htmlspecialchars($activation['reviewer_name']); ?>
                                                        </small>
                                                    </p>
                                                </div>
                                                <div class="col-md-4 text-end">
                                                    <button type="button" class="btn btn-success btn-sm" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#activateModal"
                                                            data-verification-id="<?php echo $activation['id']; ?>"
                                                            data-card-number="<?php echo htmlspecialchars($activation['masked_card_number']); ?>">
                                                        <i class="fas fa-key me-1"></i>激活
                                                    </button>
                                                    <button type="button" class="btn btn-info btn-sm" 
                                                            onclick="viewDetails(<?php echo $activation['id']; ?>)">
                                                        <i class="fas fa-eye me-1"></i>详情
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- 激活历史 -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-history me-2"></i>激活历史</h5>
                            <span class="badge bg-info"><?php echo count($activationHistory); ?></span>
                        </div>
                        <div class="card-body">
                            <?php if (empty($activationHistory)): ?>
                                <div class="text-center text-muted py-4">
                                    <i class="fas fa-history fa-3x mb-3"></i>
                                    <p>暂无激活历史记录</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>卡号</th>
                                                <th>状态</th>
                                                <th>激活人</th>
                                                <th>时间</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($activationHistory as $history): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($history['masked_card_number']); ?></td>
                                                    <td>
                                                        <?php if ($history['status'] === 'activated'): ?>
                                                            <span class="badge bg-success">已激活</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">失败</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($history['activator_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($history['activation_date']); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif ($action === 'view' && $verificationDetails): ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i>核验详情 - 卡片激活
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>基本信息</h6>
                            <table class="table table-sm">
                                <tr><td>核验ID:</td><td><?php echo htmlspecialchars($verificationDetails['id']); ?></td></tr>
                                <tr><td>卡号:</td><td><?php echo htmlspecialchars($verificationDetails['masked_card_number']); ?></td></tr>
                                <tr><td>持卡人:</td><td><?php echo htmlspecialchars($verificationDetails['masked_cardholder_name']); ?></td></tr>
                                <tr><td>核验状态:</td><td><span class="badge bg-success"><?php echo htmlspecialchars($verificationDetails['status_text']); ?></span></td></tr>
                                <tr><td>申请时间:</td><td><?php echo htmlspecialchars($verificationDetails['created_at']); ?></td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6>审核信息</h6>
                            <table class="table table-sm">
                                <tr><td>审核级别:</td><td><?php echo htmlspecialchars($verificationDetails['review_level_text']); ?></td></tr>
                                <tr><td>审核人:</td><td><?php echo htmlspecialchars($verificationDetails['reviewer_name']); ?></td></tr>
                                <tr><td>审核时间:</td><td><?php echo htmlspecialchars($verificationDetails['review_date']); ?></td></tr>
                                <tr><td>审核结果:</td><td><span class="badge bg-success">通过</span></td></tr>
                                <tr><td>激活状态:</td><td>
                                    <?php if ($verificationDetails['activation_status'] === 'activated'): ?>
                                        <span class="badge bg-success">已激活</span>
                                    <?php elseif ($verificationDetails['activation_status'] === 'failed'): ?>
                                        <span class="badge bg-danger">激活失败</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">待激活</span>
                                    <?php endif; ?>
                                </td></tr>
                            </table>
                        </div>
                    </div>
                    
                    <?php if (!empty($verificationDetails['notes'])): ?>
                        <div class="mt-3">
                            <h6>备注信息</h6>
                            <div class="alert alert-info">
                                <?php echo htmlspecialchars($verificationDetails['notes']); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-3">
                        <a href="card_activation.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-1"></i>返回列表
                        </a>
                        <?php if ($verificationDetails['activation_status'] === 'pending'): ?>
                            <button type="button" class="btn btn-success" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#activateModal"
                                    data-verification-id="<?php echo $verificationDetails['id']; ?>"
                                    data-card-number="<?php echo htmlspecialchars($verificationDetails['masked_card_number']); ?>">
                                <i class="fas fa-key me-1"></i>激活卡片
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- 激活模态框 -->
    <div class="modal fade" id="activateModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-key me-2"></i>激活卡片
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="card_activation.php?action=activate">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?php echo SecurityUtils::generateCSRFToken(); ?>">
                        <input type="hidden" name="verification_id" id="modal_verification_id">
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>安全提醒：</strong>激活操作不可逆，请确认激活码的正确性。
                        </div>
                        
                        <div class="mb-3">
                            <label for="modal_card_number" class="form-label">卡号</label>
                            <input type="text" class="form-control" id="modal_card_number" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="activation_code" class="form-label">激活码 <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="activation_code" name="activation_code" required
                                   pattern="[A-Za-z0-9]{8,16}" maxlength="16"
                                   placeholder="请输入8-16位激活码">
                            <div class="form-text">激活码应为8-16位字母数字组合</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">备注</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"
                                      placeholder="可选：添加激活备注信息"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-key me-1"></i>确认激活
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 激活模态框数据处理
        const activateModal = document.getElementById('activateModal');
        if (activateModal) {
            activateModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                const verificationId = button.getAttribute('data-verification-id');
                const cardNumber = button.getAttribute('data-card-number');
                
                document.getElementById('modal_verification_id').value = verificationId;
                document.getElementById('modal_card_number').value = cardNumber;
                
                // 清空之前的输入
                document.getElementById('activation_code').value = '';
                document.getElementById('notes').value = '';
            });
        }
        
        // 查看详情
        function viewDetails(verificationId) {
            window.location.href = 'card_activation.php?action=view&id=' + verificationId;
        }
        
        // 激活码验证
        document.getElementById('activation_code')?.addEventListener('input', function(e) {
            const value = e.target.value;
            const pattern = /^[A-Za-z0-9]*$/;
            
            if (!pattern.test(value)) {
                e.target.setCustomValidity('激活码只能包含字母和数字');
            } else if (value.length < 8 || value.length > 16) {
                e.target.setCustomValidity('激活码长度应为8-16位');
            } else {
                e.target.setCustomValidity('');
            }
        });
    </script>
</body>
</html>