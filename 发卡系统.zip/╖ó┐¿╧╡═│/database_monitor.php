<?php
require_once 'includes/AuthManager.php';
require_once 'includes/Database.php';
require_once 'includes/SecurityUtils.php';
require_once 'includes/QueryOptimizer.php';
require_once 'config.php';

// 检查用户权限
$auth = new AuthManager();
if (!$auth->isLoggedIn() || !$auth->hasPermission('admin')) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();
$optimizer = new QueryOptimizer();

// 获取数据库性能统计
$dbStats = $db->getQueryStats();
$connectionInfo = $db->getConnectionInfo();

// 获取表统计信息
$tableStats = [];
$tables = ['cards', 'users', 'system_logs', 'audit_logs', 'identity_verifications', 'card_activations'];
foreach ($tables as $table) {
    if ($db->tableExists($table)) {
        $tableStats[$table] = [
            'schema' => $db->getTableSchema($table),
            'health' => $db->checkTableHealth($table),
            'row_count' => $db->queryOne("SELECT COUNT(*) as count FROM `{$table}`")['count'] ?? 0
        ];
    }
}

// 处理优化请求
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'optimize_table':
                $tableName = $_POST['table_name'] ?? '';
                if (!empty($tableName) && $db->tableExists($tableName)) {
                    $result = $db->optimizeTable($tableName);
                    $message = "表 {$tableName} 优化完成";
                }
                break;
                
            case 'analyze_table':
                $tableName = $_POST['table_name'] ?? '';
                if (!empty($tableName) && $db->tableExists($tableName)) {
                    $result = $db->analyzeTable($tableName);
                    $message = "表 {$tableName} 分析完成";
                }
                break;
                
            case 'clear_query_log':
                $db->clearQueryLog();
                $message = "查询日志已清空";
                break;
                
            case 'run_health_check':
                $healthResults = $db->checkTableHealth('cards');
                $message = "数据库健康检查完成";
                break;
        }
    } catch (Exception $e) {
        $message = "操作失败: " . $e->getMessage();
    }
}

$pageTitle = '数据库性能监控';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - 发卡系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .metric-card {
            transition: transform 0.2s;
        }
        .metric-card:hover {
            transform: translateY(-2px);
        }
        .query-log {
            max-height: 400px;
            overflow-y: auto;
        }
        .health-status {
            font-weight: bold;
        }
        .health-ok { color: #28a745; }
        .health-warning { color: #ffc107; }
        .health-error { color: #dc3545; }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-credit-card me-2"></i>发卡系统
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>仪表板
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add_card.php">
                            <i class="fas fa-plus me-1"></i>添加卡片
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_card.php">
                            <i class="fas fa-search me-1"></i>搜索卡片
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update_status.php">
                            <i class="fas fa-edit me-1"></i>更新状态
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="identity_verification.php">
                            <i class="fas fa-user-check me-1"></i>身份核验
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="card_activation.php">
                            <i class="fas fa-key me-1"></i>卡片激活
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compliance.php">
                            <i class="fas fa-shield-alt me-1"></i>合规管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">
                            <i class="fas fa-list me-1"></i>系统日志
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="database_monitor.php">
                            <i class="fas fa-database me-1"></i>数据库监控
                        </a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">退出登录</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- 页面标题 -->
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-database me-2"></i><?php echo $pageTitle; ?></h2>
                <p class="text-muted">监控数据库性能、优化查询、检查表健康状态</p>
            </div>
        </div>

        <!-- 消息提示 -->
        <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- 性能指标 -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card metric-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-line fa-2x text-primary mb-2"></i>
                        <h5 class="card-title">总查询数</h5>
                        <h3 class="text-primary"><?php echo number_format($dbStats['total_queries']); ?></h3>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card metric-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-exclamation-triangle fa-2x text-warning mb-2"></i>
                        <h5 class="card-title">慢查询数</h5>
                        <h3 class="text-warning"><?php echo number_format($dbStats['slow_queries']); ?></h3>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card metric-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-2x text-info mb-2"></i>
                        <h5 class="card-title">平均执行时间</h5>
                        <h3 class="text-info"><?php echo number_format($dbStats['average_time'], 2); ?>ms</h3>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card metric-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-server fa-2x text-success mb-2"></i>
                        <h5 class="card-title">连接状态</h5>
                        <h3 class="text-success">正常</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- 数据库信息 -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-info-circle me-2"></i>数据库连接信息</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>服务器版本:</strong> <?php echo htmlspecialchars($connectionInfo['PDO::ATTR_SERVER_VERSION'] ?? 'N/A'); ?>
                            </div>
                            <div class="col-md-6">
                                <strong>客户端版本:</strong> <?php echo htmlspecialchars($connectionInfo['PDO::ATTR_CLIENT_VERSION'] ?? 'N/A'); ?>
                            </div>
                            <div class="col-md-6 mt-2">
                                <strong>连接状态:</strong> <?php echo htmlspecialchars($connectionInfo['PDO::ATTR_CONNECTION_STATUS'] ?? 'N/A'); ?>
                            </div>
                            <div class="col-md-6 mt-2">
                                <strong>服务器信息:</strong> <?php echo htmlspecialchars(substr($connectionInfo['PDO::ATTR_SERVER_INFO'] ?? 'N/A', 0, 50)) . '...'; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 表统计 -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="fas fa-table me-2"></i>表统计信息</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>表名</th>
                                        <th>行数</th>
                                        <th>健康状态</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($tableStats as $tableName => $stats): ?>
                                        <tr>
                                            <td><code><?php echo htmlspecialchars($tableName); ?></code></td>
                                            <td><?php echo number_format($stats['row_count']); ?></td>
                                            <td>
                                                <?php
                                                $health = $stats['health'][0] ?? [];
                                                $msgType = $health['Msg_type'] ?? '';
                                                $msgText = $health['Msg_text'] ?? '';
                                                
                                                $class = 'health-ok';
                                                $status = '正常';
                                                
                                                if ($msgType === 'warning') {
                                                    $class = 'health-warning';
                                                    $status = '警告';
                                                } elseif ($msgType === 'error') {
                                                    $class = 'health-error';
                                                    $status = '错误';
                                                }
                                                ?>
                                                <span class="health-status <?php echo $class; ?>">
                                                    <?php echo $status; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="optimize_table">
                                                    <input type="hidden" name="table_name" value="<?php echo $tableName; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-tools"></i> 优化
                                                    </button>
                                                </form>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="analyze_table">
                                                    <input type="hidden" name="table_name" value="<?php echo $tableName; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-info">
                                                        <i class="fas fa-chart-bar"></i> 分析
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 查询日志 -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="fas fa-history me-2"></i>最近查询记录</h5>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="clear_query_log">
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="fas fa-trash"></i> 清空日志
                            </button>
                        </form>
                    </div>
                    <div class="card-body">
                        <div class="query-log">
                            <?php if (!empty($dbStats['recent_queries'])): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>时间</th>
                                                <th>SQL</th>
                                                <th>执行时间</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach (array_reverse($dbStats['recent_queries']) as $query): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($query['timestamp']); ?></td>
                                                    <td><code><?php echo htmlspecialchars(substr($query['sql'], 0, 100)); ?>...</code></td>
                                                    <td>
                                                        <span class="badge <?php echo $query['execution_time'] > $dbStats['slow_query_threshold'] ? 'bg-danger' : 'bg-success'; ?>">
                                                            <?php echo number_format($query['execution_time'], 2); ?>ms
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">暂无查询记录</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 操作按钮 -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5><i class="fas fa-cogs me-2"></i>数据库维护操作</h5>
                        <div class="row mt-3">
                            <div class="col-md-4">
                                <form method="POST">
                                    <input type="hidden" name="action" value="run_health_check">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-heartbeat me-2"></i>运行健康检查
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <button class="btn btn-info w-100" onclick="location.reload()">
                                    <i class="fas fa-sync-alt me-2"></i>刷新数据
                                </button>
                            </div>
                            <div class="col-md-4">
                                <a href="dashboard.php" class="btn btn-secondary w-100">
                                    <i class="fas fa-arrow-left me-2"></i>返回仪表板
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 自动刷新页面（每30秒）
        setTimeout(function() {
            location.reload();
        }, 30000);
        
        // 确认操作
        document.querySelectorAll('form').forEach(function(form) {
            form.addEventListener('submit', function(e) {
                const action = this.querySelector('input[name="action"]').value;
                if (action === 'clear_query_log') {
                    if (!confirm('确定要清空查询日志吗？此操作不可恢复。')) {
                        e.preventDefault();
                    }
                }
            });
        });
    </script>
</body>
</html>