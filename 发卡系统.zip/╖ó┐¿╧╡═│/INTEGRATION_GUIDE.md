# 发卡系统多语言功能集成指南

## 概述

本指南详细说明如何在发卡系统中集成和使用多语言功能。基于 `ux-enhancer.js` 的多语言系统支持中英文切换，通过 JSON 文件管理翻译文案。

## 功能特性

- ✅ 中英文语言切换
- ✅ JSON 文件管理翻译
- ✅ 参数化文本支持
- ✅ 自动翻译应用
- ✅ 语言状态持久化
- ✅ 全局 API 访问
- ✅ 事件监听支持

## 快速开始

### 1. 引入必要的文件

```html
<!-- 引入 UX 增强器 -->
<script src="assets/js/ux-enhancer.js"></script>

<!-- 语言文件 -->
<script src="assets/lang/zh-CN.json"></script>
<script src="assets/lang/en-US.json"></script>
```

### 2. HTML 标记使用多语言

```html
<!-- 基本文本 -->
<h1 data-i18n="page.title">默认标题</h1>
<p data-i18n="welcome.description">默认描述</p>

<!-- 表单元素 -->
<input type="text" data-i18n-placeholder="form.cardNumberPlaceholder" placeholder="默认占位符">
<button data-i18n="form.submit">默认按钮文本</button>

<!-- 属性翻译 -->
<button data-i18n-title="actions.addCardTitle" title="默认提示">添加卡密</button>
```

### 3. JavaScript API 使用

```javascript
// 获取翻译文本
const title = t('page.title');
const message = t('messages.saveSuccess');

// 参数化翻译
const welcome = t('demo.params.welcome', {name: '张三', count: 100});

// 切换语言
await switchLanguage('zh-CN');
await switchLanguage('en-US');

// 获取当前语言
const currentLang = getCurrentLanguage();

// 监听语言切换事件
document.addEventListener('languageChanged', (e) => {
    console.log('语言已切换到:', e.detail.language);
});
```

## 语言文件结构

### 中文语言文件 (zh-CN.json)

```json
{
  "page": {
    "title": "发卡系统 - 集成示例"
  },
  "stats": {
    "totalCards": "总卡密数",
    "totalOrders": "总订单数",
    "totalRevenue": "总收入"
  },
  "form": {
    "title": "添加新卡密",
    "cardNumber": "卡密号码",
    "cardNumberPlaceholder": "请输入卡密号码"
  }
}
```

### 英文语言文件 (en-US.json)

```json
{
  "page": {
    "title": "Card System - Integration Example"
  },
  "stats": {
    "totalCards": "Total Cards",
    "totalOrders": "Total Orders",
    "totalRevenue": "Total Revenue"
  },
  "form": {
    "title": "Add New Card",
    "cardNumber": "Card Number",
    "cardNumberPlaceholder": "Please enter card number"
  }
}
```

## 集成步骤

### 步骤 1: 准备语言文件

在 `assets/lang/` 目录下创建语言文件：

```
assets/
├── lang/
│   ├── zh-CN.json    # 中文翻译
│   └── en-US.json    # 英文翻译
```

### 步骤 2: 初始化多语言系统

```javascript
// 页面加载完成后自动初始化
document.addEventListener('DOMContentLoaded', () => {
    // UXEnhancer 会自动初始化多语言功能
    // 默认语言为浏览器语言或中文
});
```

### 步骤 3: 标记需要翻译的元素

```html
<!-- 页面标题 -->
<title data-i18n="page.title">发卡系统</title>

<!-- 导航菜单 -->
<nav>
    <a href="#" data-i18n="navigation.dashboard">仪表盘</a>
    <a href="#" data-i18n="navigation.cards">卡密管理</a>
    <a href="#" data-i18n="navigation.orders">订单管理</a>
</nav>

<!-- 统计卡片 -->
<div class="stat-card">
    <h3 data-i18n="stats.totalCards">总卡密数</h3>
    <span class="stat-value">1,234</span>
</div>

<!-- 表单 -->
<form>
    <label data-i18n="form.cardNumber">卡密号码</label>
    <input type="text" data-i18n-placeholder="form.cardNumberPlaceholder" placeholder="请输入卡密号码">
    <button type="submit" data-i18n="form.submit">提交</button>
</form>
```

### 步骤 4: 添加语言切换器

```html
<!-- 语言切换按钮 -->
<div class="language-switcher">
    <button onclick="switchLanguage('zh-CN')" class="lang-btn active" data-lang="zh-CN">
        中文
    </button>
    <button onclick="switchLanguage('en-US')" class="lang-btn" data-lang="en-US">
        English
    </button>
</div>
```

## 高级用法

### 参数化文本

```json
{
  "messages": {
    "welcome": "欢迎 {name}，您是第 {count} 位访客",
    "progress": "进度：{current}/{total}"
  }
}
```

```javascript
// 使用参数化翻译
const welcome = t('messages.welcome', {name: '张三', count: 100});
const progress = t('messages.progress', {current: 5, total: 10});
```

### 动态内容翻译

```javascript
// 动态添加翻译内容
function addTranslatedCard(title, description) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
        <h3 data-i18n="${title}">默认标题</h3>
        <p data-i18n="${description}">默认描述</p>
    `;
    
    // 应用翻译
    uxEnhancer.applyTranslations();
    
    return card;
}
```

### 表单验证消息

```javascript
// 表单验证时使用多语言消息
function validateForm(formData) {
    const errors = [];
    
    if (!formData.cardNumber) {
        errors.push(t('validation.required'));
    }
    
    if (!formData.email) {
        errors.push(t('validation.email'));
    }
    
    return errors;
}
```

## API 参考

### 全局函数

| 函数 | 描述 | 参数 | 返回值 |
|------|------|------|--------|
| `t(key, params)` | 获取翻译文本 | `key`: 翻译键<br>`params`: 参数对象 | 翻译后的文本 |
| `switchLanguage(lang)` | 切换语言 | `lang`: 语言代码 | Promise |
| `getCurrentLanguage()` | 获取当前语言 | 无 | 当前语言代码 |
| `getSupportedLanguages()` | 获取支持的语言 | 无 | 语言数组 |

### 事件

| 事件名 | 描述 | 参数 |
|--------|------|------|
| `languageChanged` | 语言切换时触发 | `{language: 新语言代码}` |
| `translationsLoaded` | 翻译加载完成时触发 | `{language: 语言代码}` |

### 数据属性

| 属性 | 描述 | 示例 |
|------|------|------|
| `data-i18n` | 元素文本翻译 | `data-i18n="page.title"` |
| `data-i18n-placeholder` | 占位符翻译 | `data-i18n-placeholder="form.search"` |
| `data-i18n-title` | 标题属性翻译 | `data-i18n-title="button.save"` |
| `data-i18n-value` | 值属性翻译 | `data-i18n-value="option.selected"` |

## 最佳实践

### 1. 翻译键命名规范

```json
{
  "module.submodule.key": "翻译文本"
}
```

- 使用点号分隔的层级结构
- 使用有意义的模块名
- 保持键名简洁明了

### 2. 性能优化

```javascript
// 批量更新翻译
function updatePageTranslations() {
    requestAnimationFrame(() => {
        uxEnhancer.applyTranslations();
    });
}

// 延迟加载翻译
async function loadLanguageOnDemand(lang) {
    if (!uxEnhancer.translations[lang]) {
        await uxEnhancer.loadTranslations(lang);
    }
}
```

### 3. 错误处理

```javascript
// 安全的翻译获取
function safeTranslate(key, fallback = '') {
    try {
        return t(key) || fallback;
    } catch (error) {
        console.warn(`翻译键 "${key}" 不存在`, error);
        return fallback;
    }
}
```

### 4. 语言文件管理

```javascript
// 语言文件版本控制
const LANGUAGE_VERSION = '1.0.0';

// 检查语言文件更新
async function checkLanguageUpdates() {
    const currentVersion = localStorage.getItem('languageVersion');
    if (currentVersion !== LANGUAGE_VERSION) {
        // 清除缓存，重新加载
        localStorage.removeItem('selectedLanguage');
        localStorage.setItem('languageVersion', LANGUAGE_VERSION);
    }
}
```

## 示例页面

### 完整的集成示例

参考 `integration-example.html` 文件，展示了：

- 导航栏多语言
- 统计卡片多语言
- 表单多语言
- 按钮和操作多语言
- 语言切换器

### 演示页面

参考 `multilingual-demo.html` 文件，展示了：

- 基本文本翻译
- 表单元素翻译
- 参数化文本
- 消息提示翻译
- 动态内容翻译

## 故障排除

### 常见问题

1. **翻译不生效**
   - 检查语言文件路径是否正确
   - 确认 JSON 格式是否有效
   - 验证翻译键是否存在

2. **语言切换失败**
   - 检查网络连接
   - 确认语言文件是否存在
   - 查看浏览器控制台错误

3. **性能问题**
   - 减少翻译文件大小
   - 使用懒加载
   - 避免频繁切换语言

### 调试技巧

```javascript
// 启用调试模式
window.uxEnhancer.debug = true;

// 查看当前翻译
console.log(uxEnhancer.translations);

// 检查缺失的翻译
function findMissingTranslations() {
    const elements = document.querySelectorAll('[data-i18n]');
    const missing = [];
    
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (!t(key)) {
            missing.push(key);
        }
    });
    
    return missing;
}
```

## 扩展开发

### 添加新语言

1. 创建新的语言文件（如 `ja-JP.json`）
2. 在 `ux-enhancer.js` 中添加语言支持
3. 更新语言切换器

### 自定义翻译加载器

```javascript
// 自定义翻译加载逻辑
class CustomTranslationLoader {
    async load(language) {
        // 从数据库或 API 加载翻译
        const response = await fetch(`/api/translations/${language}`);
        return await response.json();
    }
}
```

### 翻译管理界面

可以开发一个管理界面来：

- 在线编辑翻译
- 批量导入/导出翻译
- 翻译进度统计
- 缺失翻译检测

## 总结

通过本指南，您应该能够：

1. ✅ 理解多语言系统的工作原理
2. ✅ 在发卡系统中集成多语言功能
3. ✅ 使用 HTML 标记和 JavaScript API
4. ✅ 管理和维护翻译文件
5. ✅ 处理常见的集成问题

多语言功能将显著提升发卡系统的用户体验，使其能够服务更广泛的用户群体。如有问题，请参考示例代码或联系技术支持。