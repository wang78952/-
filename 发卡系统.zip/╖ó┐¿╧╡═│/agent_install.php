<?php
/**
 * 发卡系统代理安装脚本
 * 提供安全的安装方式，确保核心文件不被修改
 */

// 设置错误报告
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 安装步骤
$step = isset($_GET['step']) ? $_GET['step'] : 1;

// 显示安装向导头部
function showHeader($step_title) {
    echo '<!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>发卡系统 - 代理安装向导</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                color: #333;
            }
            h1, h2 {
                color: #2c3e50;
            }
            .progress {
                width: 100%;
                height: 20px;
                background-color: #eee;
                border-radius: 10px;
                margin: 20px 0;
            }
            .progress-bar {
                height: 100%;
                background-color: #3498db;
                border-radius: 10px;
                text-align: center;
                line-height: 20px;
                color: white;
                font-size: 12px;
            }
            .step-card {
                background: #fff;
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 20px;
                margin: 20px 0;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .success {
                color: #27ae60;
            }
            .error {
                color: #e74c3c;
            }
            .warning {
                color: #f39c12;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin: 15px 0;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px 12px;
                text-align: left;
            }
            th {
                background-color: #f2f2f2;
            }
            .btn {
                display: inline-block;
                padding: 10px 20px;
                background-color: #3498db;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                cursor: pointer;
                border: none;
                font-size: 16px;
            }
            .btn:hover {
                background-color: #2980b9;
            }
            .btn-next {
                float: right;
            }
            .btn-prev {
                float: left;
            }
            .clear {
                clear: both;
            }
            .note {
                background-color: #f9f9f9;
                padding: 15px;
                border-left: 4px solid #3498db;
                margin: 15px 0;
            }
        </style>
    </head>
    <body>
        <h1>发卡系统 - 代理安装向导</h1>
        <div class="step-card">
            <h2>' . $step_title . '</h2>';
}

// 显示安装向导底部
function showFooter($current_step, $total_steps) {
    echo '<div class="clear"></div>
        </div>
        <div class="progress">
            <div class="progress-bar" style="width: ' . ($current_step / $total_steps * 100) . '%">
                步骤 ' . $current_step . '/' . $total_steps . '
            </div>
        </div>
        <div style="margin-top: 20px;">
            ';
    
    if ($current_step > 1) {
        echo '<a href="agent_install.php?step=' . ($current_step - 1) . '" class="btn btn-prev">上一步</a>';
    }
    
    if ($current_step < $total_steps) {
        echo '<a href="agent_install.php?step=' . ($current_step + 1) . '" class="btn btn-next">下一步</a>';
    } else {
        echo '<a href="index.php" class="btn btn-next">完成安装</a>';
    }
    
    echo '        <div class="clear"></div>
        </div>
        <div class="note">
            <p><strong>注意：</strong>本安装程序仅用于代理部署系统。核心文件已被保护，您无法修改这些文件，但可以正常使用系统的所有功能。</p>
        </div>
    </body>
    </html>';
}

// 检查服务器环境
function checkEnvironment() {
    $results = [
        'php_version' => [
            'name' => 'PHP 版本',
            'required' => '7.0+',
            'current' => PHP_VERSION,
            'passed' => version_compare(PHP_VERSION, '7.0', '>=')
        ],
        'mysql_extension' => [
            'name' => 'MySQL 扩展',
            'required' => '已安装',
            'current' => extension_loaded('mysqli') ? '已安装' : '未安装',
            'passed' => extension_loaded('mysqli')
        ],
        'gd_extension' => [
            'name' => 'GD 扩展',
            'required' => '已安装',
            'current' => extension_loaded('gd') ? '已安装' : '未安装',
            'passed' => extension_loaded('gd')
        ],
        'json_extension' => [
            'name' => 'JSON 扩展',
            'required' => '已安装',
            'current' => extension_loaded('json') ? '已安装' : '未安装',
            'passed' => extension_loaded('json')
        ],
    ];
    
    return $results;
}

// 步骤1：环境检查
if ($step == 1) {
    showHeader('环境检查');
    
    $env_results = checkEnvironment();
    $all_passed = true;
    
    echo '<table>
        <tr>
            <th>检查项</th>
            <th>要求</th>
            <th>当前</th>
            <th>状态</th>
        </tr>';
    
    foreach ($env_results as $key => $result) {
        $all_passed = $all_passed && $result['passed'];
        echo '<tr>
            <td>' . $result['name'] . '</td>
            <td>' . $result['required'] . '</td>
            <td>' . $result['current'] . '</td>
            <td class="' . ($result['passed'] ? 'success' : 'error') . '">
                ' . ($result['passed'] ? '✓ 通过' : '✗ 失败') . '
            </td>
        </tr>';
    }
    
    echo '</table>';
    
    if (!$all_passed) {
        echo '<div class="error">
            <p>环境检查未通过，请先修复上述问题后再继续安装。</p>
        </div>';
    }
    
    showFooter(1, 4);
}

// 步骤2：数据库配置
elseif ($step == 2) {
    showHeader('数据库配置');
    
    // 处理表单提交
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $db_config = [
            'host' => $_POST['db_host'],
            'user' => $_POST['db_user'],
            'pass' => $_POST['db_pass'],
            'name' => $_POST['db_name'],
            'prefix' => $_POST['db_prefix']
        ];
        
        // 测试数据库连接
        $conn = mysqli_connect($db_config['host'], $db_config['user'], $db_config['pass']);
        
        if (!$conn) {
            echo '<div class="error">
                <p>数据库连接失败：' . mysqli_connect_error() . '</p>
            </div>';
        } else {
            // 检查数据库是否存在
            if (!mysqli_select_db($conn, $db_config['name'])) {
                // 尝试创建数据库
                if (!mysqli_query($conn, 'CREATE DATABASE ' . $db_config['name'] . ' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci')) {
                    echo '<div class="error">
                        <p>无法创建数据库：' . mysqli_error($conn) . '</p>
                    </div>';
                } else {
                    mysqli_select_db($conn, $db_config['name']);
                    echo '<div class="success">
                        <p>数据库创建成功</p>
                    </div>';
                }
            }
            
            // 保存数据库配置到临时文件
            file_put_contents(__DIR__ . '/temp_db_config.php', '<?php return ' . var_export($db_config, true) . ';');
            
            echo '<div class="success">
                <p>数据库配置已保存，请点击下一步继续安装</p>
            </div>';
        }
    }
    
    // 显示数据库配置表单
    echo '<form method="post">
        <div style="margin-bottom: 15px;">
            <label for="db_host">数据库主机：</label>
            <input type="text" id="db_host" name="db_host" value="localhost" required style="width: 100%; padding: 8px;">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="db_user">数据库用户名：</label>
            <input type="text" id="db_user" name="db_user" value="root" required style="width: 100%; padding: 8px;">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="db_pass">数据库密码：</label>
            <input type="password" id="db_pass" name="db_pass" style="width: 100%; padding: 8px;">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="db_name">数据库名称：</label>
            <input type="text" id="db_name" name="db_name" value="card_system" required style="width: 100%; padding: 8px;">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="db_prefix">表前缀：</label>
            <input type="text" id="db_prefix" name="db_prefix" value="card_" required style="width: 100%; padding: 8px;">
        </div>
        <button type="submit" class="btn">测试连接并保存配置</button>
    </form>';
    
    showFooter(2, 4);
}

// 步骤3：安装数据库
elseif ($step == 3) {
    showHeader('数据库安装');
    
    // 检查是否有临时配置文件
    if (!file_exists(__DIR__ . '/temp_db_config.php')) {
        echo '<div class="error">
            <p>找不到数据库配置，请先完成上一步</p>
        </div>';
        showFooter(3, 4);
        exit;
    }
    
    // 加载数据库配置
    $db_config = include(__DIR__ . '/temp_db_config.php');
    
    // 连接数据库
    $conn = mysqli_connect($db_config['host'], $db_config['user'], $db_config['pass'], $db_config['name']);
    
    if (!$conn) {
        echo '<div class="error">
            <p>数据库连接失败：' . mysqli_connect_error() . '</p>
        </div>';
    } else {
        mysqli_query($conn, 'SET NAMES utf8mb4');
        
        // 读取数据库SQL文件
        $sql_file = __DIR__ . '/database.sql';
        
        if (file_exists($sql_file)) {
            $sql_content = file_get_contents($sql_file);
            
            // 替换表前缀
            if (!empty($db_config['prefix']) && $db_config['prefix'] != 'card_') {
                $sql_content = str_replace('card_', $db_config['prefix'], $sql_content);
            }
            
            // 执行SQL语句
            $sql_queries = explode(';', $sql_content);
            $success_count = 0;
            $error_count = 0;
            $errors = [];
            
            foreach ($sql_queries as $query) {
                $query = trim($query);
                if (!empty($query)) {
                    if (mysqli_query($conn, $query)) {
                        $success_count++;
                    } else {
                        $error_count++;
                        $errors[] = mysqli_error($conn);
                    }
                }
            }
            
            echo '<div class="success">
                <p>数据库安装完成</p>
                <p>成功执行：' . $success_count . ' 条语句</p>
            </div>';
            
            if ($error_count > 0) {
                echo '<div class="warning">
                    <p>警告：有 ' . $error_count . ' 条语句执行失败，这些可能是重复创建的表</p>
                </div>';
            }
            
            // 保存数据库配置到实际配置文件
            $config_content = file_get_contents(__DIR__ . '/config.php');
            
            // 替换数据库配置
            $config_content = preg_replace('/\$db_config\s*=\s*\[([^\]]*)\]/', 
                '$db_config = ' . var_export($db_config, true), 
                $config_content);
            
            // 创建一个可写的配置文件副本
            file_put_contents(__DIR__ . '/config_agent.php', $config_content);
            
            // 删除临时配置文件
            unlink(__DIR__ . '/temp_db_config.php');
            
        } else {
            echo '<div class="error">
                <p>找不到数据库SQL文件：database.sql</p>
            </div>';
        }
    }
    
    showFooter(3, 4);
}

// 步骤4：完成安装
elseif ($step == 4) {
    showHeader('安装完成');
    
    // 清理安装文件访问
    $htaccess_content = '\n# 禁止访问安装文件\n<Files "agent_install.php">\n    Order Allow,Deny\n    Deny from all\n</Files>\n';
    
    if (!file_exists(__DIR__ . '/.htaccess')) {
        file_put_contents(__DIR__ . '/.htaccess', $htaccess_content);
    } else {
        file_put_contents(__DIR__ . '/.htaccess', file_get_contents(__DIR__ . '/.htaccess') . $htaccess_content);
    }
    
    // 创建代理信息文件
    $agent_info = [
        'installed_at' => date('Y-m-d H:i:s'),
        'version' => '1.0',
        'agent_mode' => true
    ];
    
    file_put_contents(__DIR__ . '/agent_info.php', '<?php return ' . var_export($agent_info, true) . ';');
    
    echo '<div class="success">
        <h3>✅ 安装成功！</h3>
        <p>发卡系统已成功安装到您的服务器。</p>
    </div>\n    
    <div class="step-card">
        <h3>🔑 管理员账号</h3>
        <p>请使用以下默认账号登录后台：</p>
        <table>
            <tr>
                <td>用户名：</td>
                <td><strong>admin</strong></td>
            </tr>
            <tr>
                <td>密码：</td>
                <td><strong>admin123</strong></td>
            </tr>
        </table>
        <p class="warning">登录后请立即修改密码！</p>
    </div>\n    
    <div class="step-card">
        <h3>📋 系统信息</h3>
        <p>• <strong>前台地址：</strong> <a href="index.php">点击访问</a></p>
        <p>• <strong>后台地址：</strong> <a href="admin/index.php">点击访问</a></p>
        <p>• <strong>API地址：</strong> <a href="api/index.php">点击访问</a></p>
    </div>\n    
    <div class="step-card">
        <h3>⚠️ 重要提示</h3>
        <ul>
            <li>核心文件已被系统保护，您无法修改这些文件</li>
            <li>您可以正常使用系统的所有功能，包括添加产品、管理订单等</li>
            <li>如有任何问题，请联系系统管理员</li>
            <li>请勿删除或修改protect_core_files.php文件，这是系统安全的重要组成部分</li>
        </ul>
    </div>';
    
    showFooter(4, 4);
}

// 清理函数
function cleanupInstallation() {
    // 这里可以添加安装后的清理代码
}

?>