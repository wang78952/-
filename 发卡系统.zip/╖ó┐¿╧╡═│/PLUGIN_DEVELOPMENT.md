# 插件开发指南

## 概述

发卡系统支持插件化架构，允许开发者通过插件扩展系统功能。插件系统基于钩子机制，支持动态加载、配置管理和生命周期管理。

## 插件架构

### 核心组件

1. **PluginManager** - 插件管理器，负责插件的注册、加载和管理
2. **PluginInterface** - 插件接口，定义插件必须实现的方法
3. **BasePlugin** - 基础插件类，提供通用功能实现
4. **Hook System** - 钩子系统，支持事件驱动的插件扩展

### 目录结构

```
plugins/
├── payment/           # 支付插件
│   ├── alipay/        # 支付宝插件
│   │   ├── plugin.json
│   │   ├── config.json
│   │   └── AlipayPlugin.php
│   └── wechat/        # 微信支付插件
├── verification/      # 验证插件
├── notifications/     # 通知插件
├── analytics/         # 分析插件
├── security/          # 安全插件
└── third-party/       # 第三方集成插件
```

## 插件开发

### 1. 创建插件目录

每个插件都有自己的目录，位于相应的分类文件夹下：

```
plugins/your-category/your-plugin/
```

### 2. 插件配置文件 (plugin.json)

```json
{
    "name": "YourPlugin",
    "version": "1.0.0",
    "description": "插件描述",
    "author": "作者名称",
    "category": "分类",
    "dependencies": [],
    "hooks": [
        "payment.create",
        "payment.success"
    ],
    "permissions": [
        "payment.create",
        "payment.query"
    ],
    "database": {
        "tables": [
            "your_plugin_data"
        ]
    },
    "api": {
        "endpoints": [
            {
                "path": "/your-plugin/callback",
                "method": "POST",
                "handler": "handleCallback"
            }
        ]
    },
    "config_schema": {
        "app_id": {
            "type": "string",
            "required": true,
            "description": "应用ID"
        },
        "app_secret": {
            "type": "string",
            "required": true,
            "description": "应用密钥"
        }
    }
}
```

### 3. 插件配置 (config.json)

```json
{
    "app_id": "",
    "app_secret": "",
    "api_url": "https://api.example.com",
    "webhook_url": "",
    "debug": false
}
```

### 4. 插件主类

```php
<?php

namespace Plugins\Payment\YourPlugin;

use Includes\PluginInterface;
use Includes\BasePlugin;

class YourPlugin extends BasePlugin implements PluginInterface
{
    /**
     * 插件初始化
     */
    public function initialize(): bool
    {
        // 注册钩子
        $this->registerHook('payment.create', [$this, 'createPayment']);
        $this->registerHook('payment.callback', [$this, 'handleCallback']);
        
        // 注册API路由
        $this->registerApiRoute('/your-plugin/status', 'GET', [$this, 'getStatus']);
        
        return true;
    }

    /**
     * 创建支付订单
     */
    public function createPayment($data)
    {
        // 实现支付订单创建逻辑
        $orderId = $data['order_id'];
        $amount = $data['amount'];
        
        // 调用第三方支付API
        $result = $this->callPaymentAPI([
            'order_id' => $orderId,
            'amount' => $amount,
            'notify_url' => $this->getConfig('webhook_url')
        ]);
        
        if ($result['success']) {
            return [
                'success' => true,
                'payment_url' => $result['payment_url'],
                'transaction_id' => $result['transaction_id']
            ];
        }
        
        return [
            'success' => false,
            'error' => $result['error']
        ];
    }

    /**
     * 处理支付回调
     */
    public function handleCallback($data)
    {
        // 验证回调签名
        if (!$this->verifySignature($data)) {
            return ['success' => false, 'error' => 'Invalid signature'];
        }
        
        // 更新订单状态
        $this->updateOrderStatus($data['order_id'], 'paid');
        
        // 触发支付成功钩子
        $this->triggerHook('payment.success', $data);
        
        return ['success' => true];
    }

    /**
     * 获取插件状态
     */
    public function getStatus()
    {
        return [
            'status' => 'active',
            'version' => $this->getVersion(),
            'config' => $this->getConfig()
        ];
    }

    /**
     * 创建数据库表
     */
    public function createTables(): bool
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS your_plugin_data (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id VARCHAR(100) NOT NULL,
                transaction_id VARCHAR(100),
                amount DECIMAL(10,2),
                status VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_order_id (order_id),
                INDEX idx_transaction_id (transaction_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        
        return $this->executeSql($sql);
    }

    /**
     * 插件卸载时清理
     */
    public function cleanup(): bool
    {
        // 删除数据库表
        $this->executeSql("DROP TABLE IF EXISTS your_plugin_data");
        
        // 清理配置文件
        // $this->removeConfig();
        
        return true;
    }

    /**
     * 调用第三方支付API
     */
    private function callPaymentAPI($params)
    {
        // 实现API调用逻辑
        $url = $this->getConfig('api_url');
        $appId = $this->getConfig('app_id');
        $appSecret = $this->getConfig('app_secret');
        
        // 生成签名
        $params['app_id'] = $appId;
        $params['timestamp'] = time();
        $params['sign'] = $this->generateSign($params, $appSecret);
        
        // 发送HTTP请求
        $response = $this->httpRequest($url, $params);
        
        return json_decode($response, true);
    }

    /**
     * 生成签名
     */
    private function generateSign($params, $secret)
    {
        // 实现签名生成逻辑
        ksort($params);
        $string = '';
        foreach ($params as $key => $value) {
            if ($value !== '') {
                $string .= $key . '=' . $value . '&';
            }
        }
        $string .= 'key=' . $secret;
        
        return md5($string);
    }

    /**
     * 验证签名
     */
    private function verifySignature($data)
    {
        $receivedSign = $data['sign'];
        unset($data['sign']);
        
        $calculatedSign = $this->generateSign($data, $this->getConfig('app_secret'));
        
        return $receivedSign === $calculatedSign;
    }

    /**
     * 更新订单状态
     */
    private function updateOrderStatus($orderId, $status)
    {
        $db = \Includes\Database::getInstance();
        return $db->update('orders', 
            ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')], 
            'order_id = ?', 
            [$orderId]
        );
    }
}
```

## 钩子系统

### 可用钩子

#### 支付相关钩子
- `payment.create` - 创建支付订单
- `payment.success` - 支付成功
- `payment.failed` - 支付失败
- `payment.callback` - 支付回调

#### 用户相关钩子
- `user.register` - 用户注册
- `user.login` - 用户登录
- `user.logout` - 用户登出
- `user.update` - 用户信息更新

#### 订单相关钩子
- `order.create` - 创建订单
- `order.update` - 更新订单
- `order.cancel` - 取消订单
- `order.complete` - 完成订单

#### 系统相关钩子
- `system.init` - 系统初始化
- `system.shutdown` - 系统关闭
- `system.error` - 系统错误
- `system.log` - 系统日志

### 注册钩子

```php
// 在插件初始化时注册钩子
$this->registerHook('hook_name', [$this, 'methodName']);

// 或者注册静态方法
$this->registerHook('hook_name', 'YourClass::staticMethod');

// 或者注册闭包
$this->registerHook('hook_name', function($data) {
    // 处理逻辑
    return $result;
});
```

### 触发钩子

```php
// 在系统代码中触发钩子
$result = $this->triggerHook('hook_name', $data);

// 如果有多个回调，可以获取所有结果
$results = $this->triggerHook('hook_name', $data, true);
```

## API 路由

### 注册API路由

```php
// 在插件初始化时注册API路由
$this->registerApiRoute('/your-plugin/endpoint', 'POST', [$this, 'handlerMethod']);
```

### API处理方法

```php
public function handlerMethod($request)
{
    // 验证权限
    if (!$this->hasPermission('your.permission')) {
        return ['success' => false, 'error' => 'Permission denied'];
    }
    
    // 处理请求
    $data = $request['data'];
    
    // 返回响应
    return [
        'success' => true,
        'data' => $processedData
    ];
}
```

## 配置管理

### 获取配置

```php
// 获取单个配置项
$value = $this->getConfig('config_key');

// 获取默认值
$value = $this->getConfig('config_key', 'default_value');

// 获取所有配置
$config = $this->getConfig();
```

### 更新配置

```php
// 更新单个配置项
$this->updateConfig('config_key', 'new_value');

// 批量更新配置
$this->updateConfig([
    'key1' => 'value1',
    'key2' => 'value2'
]);
```

## 数据库操作

### 执行SQL

```php
// 执行查询
$result = $this->executeSql("SELECT * FROM table WHERE id = ?", [$id]);

// 执行更新
$result = $this->executeSql("UPDATE table SET field = ? WHERE id = ?", [$value, $id]);

// 执行插入
$result = $this->executeSql("INSERT INTO table (field1, field2) VALUES (?, ?)", [$value1, $value2]);
```

### 使用数据库实例

```php
$db = \Includes\Database::getInstance();

// 查询
$results = $db->select('table', '*', 'condition = ?', [$value]);

// 插入
$id = $db->insert('table', ['field1' => $value1, 'field2' => $value2]);

// 更新
$result = $db->update('table', ['field' => $value], 'id = ?', [$id]);

// 删除
$result = $db->delete('table', 'id = ?', [$id]);
```

## 日志记录

```php
// 记录信息日志
$this->logInfo('Plugin operation completed', ['data' => $data]);

// 记录错误日志
$this->logError('Plugin operation failed', ['error' => $error]);

// 记录调试日志
$this->logDebug('Debug information', ['debug' => $debug]);
```

## 权限检查

```php
// 检查权限
if ($this->hasPermission('permission.name')) {
    // 有权限
}

// 检查多个权限
if ($this->hasAnyPermission(['perm1', 'perm2'])) {
    // 有任一权限
}

// 检查所有权限
if ($this->hasAllPermissions(['perm1', 'perm2'])) {
    // 有所有权限
}
```

## 插件生命周期

### 1. 注册阶段
- 插件管理器扫描插件目录
- 读取插件配置文件
- 验证插件依赖

### 2. 加载阶段
- 加载插件类文件
- 实例化插件对象
- 调用插件初始化方法

### 3. 启用阶段
- 注册钩子
- 注册API路由
- 创建数据库表
- 加载插件配置

### 4. 运行阶段
- 响应钩子调用
- 处理API请求
- 执行插件功能

### 5. 禁用阶段
- 注销钩子
- 注销API路由
- 保存配置

### 6. 卸载阶段
- 清理数据库表
- 删除配置文件
- 移除插件文件

## 最佳实践

### 1. 命名规范
- 插件名称使用PascalCase
- 类名使用PascalCase
- 方法名使用camelCase
- 配置键使用snake_case

### 2. 错误处理
```php
try {
    $result = $this->doSomething();
    return ['success' => true, 'data' => $result];
} catch (Exception $e) {
    $this->logError('Operation failed', ['error' => $e->getMessage()]);
    return ['success' => false, 'error' => $e->getMessage()];
}
```

### 3. 输入验证
```php
public function processInput($data)
{
    // 验证必需字段
    if (empty($data['required_field'])) {
        return ['success' => false, 'error' => 'Missing required field'];
    }
    
    // 验证数据类型
    if (!is_numeric($data['amount'])) {
        return ['success' => false, 'error' => 'Invalid amount'];
    }
    
    // 清理输入数据
    $cleanData = $this->sanitizeInput($data);
    
    // 处理数据
    return $this->processData($cleanData);
}
```

### 4. 缓存使用
```php
// 获取缓存数据
$cachedData = $this->getCache('cache_key');
if ($cachedData !== null) {
    return $cachedData;
}

// 生成数据
$data = $this->generateData();

// 设置缓存
$this->setCache('cache_key', $data, 3600);

return $data;
```

### 5. 性能优化
- 避免在钩子中执行耗时操作
- 使用异步处理长时间任务
- 合理使用缓存减少数据库查询
- 优化数据库查询语句

## 测试

### 单元测试
```php
class YourPluginTest extends PHPUnit\Framework\TestCase
{
    private $plugin;
    
    protected function setUp(): void
    {
        $this->plugin = new YourPlugin();
        $this->plugin->initialize();
    }
    
    public function testCreatePayment()
    {
        $data = [
            'order_id' => 'TEST001',
            'amount' => 100.00
        ];
        
        $result = $this->plugin->createPayment($data);
        
        $this->assertTrue($result['success']);
        $this->assertNotEmpty($result['payment_url']);
    }
}
```

### 集成测试
```php
public function testPluginIntegration()
{
    // 测试插件与系统的集成
    $result = $this->triggerHook('payment.create', $testData);
    
    $this->assertNotEmpty($result);
    $this->assertTrue($result['success']);
}
```

## 部署

### 1. 打包插件
```bash
# 创建插件包
tar -czf your-plugin-1.0.0.tar.gz your-plugin/
```

### 2. 安装插件
- 通过插件管理界面上传插件包
- 或者手动解压到plugins目录
- 在插件管理界面启用插件

### 3. 配置插件
- 在插件管理界面配置插件参数
- 测试插件功能
- 监控插件运行状态

## 故障排除

### 常见问题

1. **插件无法加载**
   - 检查插件配置文件格式
   - 验证插件类是否正确实现接口
   - 检查文件权限

2. **钩子不生效**
   - 确认钩子名称正确
   - 检查钩子注册时机
   - 验证回调方法存在

3. **API路由不工作**
   - 检查路由注册是否成功
   - 验证权限设置
   - 检查URL路径正确性

4. **数据库操作失败**
   - 检查SQL语法
   - 验证数据库连接
   - 确认表结构正确

### 调试技巧

1. 启用调试模式
2. 查看插件日志
3. 使用var_dump输出变量
4. 检查系统日志

## 版本管理

### 语义化版本
- 主版本号：不兼容的API修改
- 次版本号：向下兼容的功能性新增
- 修订号：向下兼容的问题修正

### 更新日志
```markdown
## [1.1.0] - 2024-01-15
### Added
- 新增支付回调处理
- 支持批量订单处理

### Fixed
- 修复签名验证问题
- 优化数据库查询性能

### Changed
- 更新配置结构
- 改进错误处理
```

## 安全考虑

1. **输入验证** - 严格验证所有输入数据
2. **权限检查** - 实施细粒度权限控制
3. **数据加密** - 敏感数据加密存储
4. **日志审计** - 记录所有关键操作
5. **定期更新** - 及时更新依赖库

## 社区支持

- 插件开发文档
- 示例插件代码
- 开发者社区
- 技术支持论坛

---

通过遵循本指南，您可以开发出高质量、可维护的插件，为发卡系统添加丰富的功能扩展。