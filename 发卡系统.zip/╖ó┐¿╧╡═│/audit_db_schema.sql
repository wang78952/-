-- 审计系统数据库表结构

-- 1. 异常记录表
CREATE TABLE IF NOT EXISTS anomaly_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL COMMENT '用户ID',
    username VARCHAR(100) NOT NULL COMMENT '用户名',
    anomaly_type VARCHAR(50) NOT NULL COMMENT '异常类型',
    description TEXT NOT NULL COMMENT '异常描述',
    risk_level ENUM('low', 'medium', 'high') NOT NULL DEFAULT 'medium' COMMENT '风险级别',
    details JSON COMMENT '详细信息',
    status ENUM('pending', 'investigating', 'resolved') NOT NULL DEFAULT 'pending' COMMENT '处理状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 审计统计汇总表
CREATE TABLE IF NOT EXISTS audit_summaries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    audit_date DATE NOT NULL COMMENT '审计日期',
    admin_anomalies INT DEFAULT 0 COMMENT '管理员异常数量',
    price_anomalies INT DEFAULT 0 COMMENT '价格异常数量',
    withdraw_anomalies INT DEFAULT 0 COMMENT '提现异常数量',
    login_anomalies INT DEFAULT 0 COMMENT '登录异常数量',
    report_path VARCHAR(255) COMMENT '报告文件路径',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    UNIQUE KEY unique_audit_date (audit_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 行为模式表（用于存储异常行为模式）
CREATE TABLE IF NOT EXISTS behavior_patterns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pattern_name VARCHAR(100) NOT NULL COMMENT '模式名称',
    pattern_type VARCHAR(50) NOT NULL COMMENT '模式类型',
    trigger_conditions JSON NOT NULL COMMENT '触发条件',
    risk_level ENUM('low', 'medium', 'high') NOT NULL DEFAULT 'medium' COMMENT '风险级别',
    is_active BOOLEAN DEFAULT TRUE COMMENT '是否启用',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 审计日志表（记录审计操作本身）
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    operator_id INT NOT NULL COMMENT '操作人ID',
    operator_name VARCHAR(100) NOT NULL COMMENT '操作人名称',
    audit_type VARCHAR(50) NOT NULL COMMENT '审计类型',
    status ENUM('started', 'completed', 'failed') NOT NULL COMMENT '审计状态',
    duration INT COMMENT '持续时间（秒）',
    result_summary TEXT COMMENT '结果摘要',
    error_message TEXT COMMENT '错误信息',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    completed_at TIMESTAMP NULL COMMENT '完成时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 异常统计趋势表
CREATE TABLE IF NOT EXISTS anomaly_statistics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date_period DATE NOT NULL COMMENT '统计日期',
    period_type ENUM('daily', 'weekly', 'monthly') NOT NULL DEFAULT 'daily' COMMENT '周期类型',
    anomaly_count INT DEFAULT 0 COMMENT '异常总数',
    high_risk_count INT DEFAULT 0 COMMENT '高风险异常数',
    medium_risk_count INT DEFAULT 0 COMMENT '中风险异常数',
    low_risk_count INT DEFAULT 0 COMMENT '低风险异常数',
    user_distinct_count INT DEFAULT 0 COMMENT '涉及用户数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    UNIQUE KEY unique_period (date_period, period_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 添加索引
ALTER TABLE anomaly_records ADD INDEX idx_user_id (user_id);
ALTER TABLE anomaly_records ADD INDEX idx_risk_level (risk_level);
ALTER TABLE anomaly_records ADD INDEX idx_anomaly_type (anomaly_type);
ALTER TABLE anomaly_records ADD INDEX idx_created_at (created_at);
ALTER TABLE audit_summaries ADD INDEX idx_audit_date (audit_date);
ALTER TABLE behavior_patterns ADD INDEX idx_pattern_type (pattern_type);
ALTER TABLE audit_logs ADD INDEX idx_created_at (created_at);
ALTER TABLE anomaly_statistics ADD INDEX idx_date_period (date_period);

-- 插入默认行为模式
INSERT INTO behavior_patterns (pattern_name, pattern_type, trigger_conditions, risk_level, is_active)
VALUES 
('价格异常波动', 'price_change', '{"min_percentage": 20, "max_percentage": 1000}', 'high', TRUE),
('短时间频繁改价', 'price_change', '{"time_window": 3600, "max_changes": 5}', 'medium', TRUE),
('大额提现', 'withdrawal', '{"min_amount": 10000}', 'high', TRUE),
('频繁提现', 'withdrawal', '{"time_window": 86400, "max_withdrawals": 10}', 'medium', TRUE),
('异常登录地点', 'login', '{"check_location_change": true}', 'high', TRUE),
('连续登录失败', 'login', '{"max_failures": 5, "time_window": 300}', 'medium', TRUE),
('管理员敏感操作', 'admin_action', '{"sensitive_actions": ["delete_user", "reset_password", "grant_admin"]}', 'high', TRUE),
('批量数据修改', 'admin_action', '{"batch_size": 100}', 'medium', TRUE)
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;