#!/bin/bash

# 发卡系统部署脚本
# 支持 Docker 容器化部署

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 显示帮助信息
show_help() {
    cat << EOF
发卡系统部署脚本

用法:
    $0 [选项] [环境]

环境:
    dev         开发环境 (默认)
    test        测试环境
    staging     预发布环境
    production  生产环境

选项:
    -h, --help          显示帮助信息
    -v, --verbose       详细输出
    -f, --force         强制重新构建
    -b, --backup        部署前备份
    -c, --check         仅检查环境，不部署
    -r, --rollback      回滚到上一个版本
    -u, --update        更新依赖
    -m, --migrate       执行数据库迁移
    -t, --test          运行测试
    --skip-tests        跳过测试
    --skip-backup       跳过备份
    --skip-health-check 跳过健康检查

示例:
    $0 dev                    # 部署到开发环境
    $0 production --backup    # 部署到生产环境并备份
    $0 staging --test         # 部署到预发布环境并运行测试
    $0 production --rollback  # 回滚生产环境

EOF
}

# 默认参数
ENVIRONMENT="dev"
VERBOSE=false
FORCE=false
BACKUP=false
CHECK_ONLY=false
ROLLBACK=false
UPDATE=false
MIGRATE=false
TEST=false
SKIP_TESTS=false
SKIP_BACKUP=false
SKIP_HEALTH_CHECK=false

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -f|--force)
            FORCE=true
            shift
            ;;
        -b|--backup)
            BACKUP=true
            shift
            ;;
        -c|--check)
            CHECK_ONLY=true
            shift
            ;;
        -r|--rollback)
            ROLLBACK=true
            shift
            ;;
        -u|--update)
            UPDATE=true
            shift
            ;;
        -m|--migrate)
            MIGRATE=true
            shift
            ;;
        -t|--test)
            TEST=true
            shift
            ;;
        --skip-tests)
            SKIP_TESTS=true
            shift
            ;;
        --skip-backup)
            SKIP_BACKUP=true
            shift
            ;;
        --skip-health-check)
            SKIP_HEALTH_CHECK=true
            shift
            ;;
        dev|test|staging|production)
            ENVIRONMENT=$1
            shift
            ;;
        *)
            log_error "未知参数: $1"
            show_help
            exit 1
            ;;
    esac
done

# 详细输出函数
verbose_log() {
    if [[ "$VERBOSE" == "true" ]]; then
        log_info "$1"
    fi
}

# 检查系统要求
check_system_requirements() {
    log_info "检查系统要求..."
    
    # 检查操作系统
    if [[ "$OSTYPE" != "linux-gnu"* ]] && [[ "$OSTYPE" != "darwin"* ]]; then
        log_warning "此脚本主要针对 Linux 和 macOS 系统"
    fi
    
    # 检查 Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker 未安装，请先安装 Docker"
        exit 1
    fi
    
    # 检查 Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose 未安装，请先安装 Docker Compose"
        exit 1
    fi
    
    # 检查 Docker 是否运行
    if ! docker info &> /dev/null; then
        log_error "Docker 服务未运行，请启动 Docker 服务"
        exit 1
    fi
    
    # 检查可用资源
    AVAILABLE_MEMORY=$(free -m 2>/dev/null | awk 'NR==2{printf "%.0f", $7}' || echo "2048")
    if [[ $AVAILABLE_MEMORY -lt 1024 ]]; then
        log_warning "可用内存不足 1GB，可能影响部署性能"
    fi
    
    AVAILABLE_DISK=$(df . | awk 'NR==2 {print $4}')
    if [[ $AVAILABLE_DISK -lt 5242880 ]]; then  # 5GB in KB
        log_warning "可用磁盘空间不足 5GB，可能影响部署"
    fi
    
    log_success "系统要求检查通过"
}

# 检查环境配置
check_environment_config() {
    log_info "检查环境配置..."
    
    case $ENVIRONMENT in
        dev)
            COMPOSE_FILE="docker-compose.yml"
            ENV_FILE=".env"
            ;;
        test)
            COMPOSE_FILE="docker-compose.test.yml"
            ENV_FILE=".env.test"
            ;;
        staging)
            COMPOSE_FILE="docker-compose.staging.yml"
            ENV_FILE=".env.staging"
            ;;
        production)
            COMPOSE_FILE="docker-compose.production.yml"
            ENV_FILE=".env.production"
            ;;
        *)
            log_error "不支持的环境: $ENVIRONMENT"
            exit 1
            ;;
    esac
    
    if [[ ! -f "$COMPOSE_FILE" ]]; then
        log_error "Docker Compose 文件不存在: $COMPOSE_FILE"
        exit 1
    fi
    
    if [[ ! -f "$ENV_FILE" ]]; then
        log_warning "环境配置文件不存在: $ENV_FILE"
        log_info "将创建默认配置文件"
        create_default_env_file
    fi
    
    verbose_log "使用配置文件: $COMPOSE_FILE"
    verbose_log "使用环境文件: $ENV_FILE"
    
    log_success "环境配置检查通过"
}

# 创建默认环境配置文件
create_default_env_file() {
    case $ENVIRONMENT in
        dev)
            cat > "$ENV_FILE" << EOF
# 开发环境配置
APP_ENV=dev
DEBUG=true
LOG_LEVEL=debug

# 数据库配置
DB_HOST=mysql
DB_NAME=card_system_dev
DB_USER=root
DB_PASS=root123
MYSQL_ROOT_PASSWORD=root123

# Redis 配置
REDIS_HOST=redis
REDIS_PASSWORD=

# API 配置
API_SECRET_KEY=dev_secret_key
JWT_SECRET=dev_jwt_secret
ENCRYPTION_KEY=dev_encryption_key
EOF
            ;;
        test)
            cat > "$ENV_FILE" << EOF
# 测试环境配置
APP_ENV=test
DEBUG=false
LOG_LEVEL=info

# 数据库配置
DB_HOST=mysql-test
DB_NAME=card_system_test
DB_USER=test_user
DB_PASS=test_password
MYSQL_ROOT_PASSWORD=test_root_password

# Redis 配置
REDIS_HOST=redis-test
REDIS_PASSWORD=test_redis_password

# API 配置
API_SECRET_KEY=test_secret_key
JWT_SECRET=test_jwt_secret
ENCRYPTION_KEY=test_encryption_key
EOF
            ;;
        staging)
            cat > "$ENV_FILE" << EOF
# 预发布环境配置
APP_ENV=staging
DEBUG=false
LOG_LEVEL=info

# 数据库配置
DB_HOST=mysql-staging
DB_NAME=card_system_staging
DB_USER=staging_user
DB_PASS=staging_password
MYSQL_ROOT_PASSWORD=staging_root_password

# Redis 配置
REDIS_HOST=redis-staging
REDIS_PASSWORD=staging_redis_password

# API 配置
API_SECRET_KEY=staging_secret_key
JWT_SECRET=staging_jwt_secret
ENCRYPTION_KEY=staging_encryption_key
EOF
            ;;
        production)
            log_error "生产环境需要手动配置环境变量文件"
            exit 1
            ;;
    esac
}

# 创建必要目录
create_directories() {
    log_info "创建必要目录..."
    
    directories=(
        "logs/apache2"
        "logs/nginx"
        "logs/mysql"
        "logs/redis"
        "logs/elasticsearch"
        "backups/database"
        "backups/files"
        "ssl/certs"
        "ssl/private"
        "uploads/images"
        "uploads/documents"
        "cache/sessions"
        "cache/templates"
        "monitoring/logs"
        "monitoring/data"
    )
    
    for dir in "${directories[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir"
            verbose_log "创建目录: $dir"
        fi
    done
    
    # 设置权限
    chmod 755 logs backups ssl uploads cache monitoring
    chmod 700 ssl/private
    
    log_success "目录创建完成"
}

# 备份当前部署
backup_current_deployment() {
    if [[ "$SKIP_BACKUP" == "true" ]]; then
        log_info "跳过备份"
        return
    fi
    
    log_info "备份当前部署..."
    
    BACKUP_DIR="backups/deployments/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    
    # 备份配置文件
    if [[ -f "$ENV_FILE" ]]; then
        cp "$ENV_FILE" "$BACKUP_DIR/"
    fi
    
    if [[ -f "$COMPOSE_FILE" ]]; then
        cp "$COMPOSE_FILE" "$BACKUP_DIR/"
    fi
    
    # 备份数据库（如果服务正在运行）
    if docker-compose -f "$COMPOSE_FILE" ps -q mysql &> /dev/null; then
        log_info "备份数据库..."
        docker-compose -f "$COMPOSE_FILE" exec -T mysql mysqldump -u root -p${MYSQL_ROOT_PASSWORD} --all-databases > "$BACKUP_DIR/database.sql" || log_warning "数据库备份失败"
    fi
    
    # 创建备份信息文件
    cat > "$BACKUP_DIR/backup_info.txt" << EOF
备份时间: $(date)
环境: $ENVIRONMENT
版本: $(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
配置文件: $COMPOSE_FILE, $ENV_FILE
EOF
    
    log_success "备份完成: $BACKUP_DIR"
}

# 更新依赖
update_dependencies() {
    if [[ "$UPDATE" != "true" ]]; then
        return
    fi
    
    log_info "更新依赖..."
    
    # 更新 Composer 依赖
    if [[ -f "composer.json" ]]; then
        log_info "更新 PHP 依赖..."
        composer install --prefer-dist --no-dev --optimize-autoloader || log_warning "Composer 依赖更新失败"
    fi
    
    # 更新 NPM 依赖
    if [[ -f "package.json" ]]; then
        log_info "更新 Node.js 依赖..."
        npm ci --production || log_warning "NPM 依赖更新失败"
    fi
    
    log_success "依赖更新完成"
}

# 构建镜像
build_images() {
    log_info "构建 Docker 镜像..."
    
    BUILD_ARGS=""
    if [[ "$FORCE" == "true" ]]; then
        BUILD_ARGS="--no-cache"
    fi
    
    docker-compose -f "$COMPOSE_FILE" build $BUILD_ARGS
    
    log_success "镜像构建完成"
}

# 启动服务
start_services() {
    log_info "启动服务..."
    
    # 加载环境变量
    if [[ -f "$ENV_FILE" ]]; then
        export $(cat "$ENV_FILE" | grep -v '^#' | xargs)
    fi
    
    # 启动服务
    docker-compose -f "$COMPOSE_FILE" up -d
    
    log_success "服务启动完成"
}

# 等待服务就绪
wait_for_services() {
    log_info "等待服务就绪..."
    
    # 等待数据库
    log_info "等待数据库启动..."
    timeout 60 bash -c "until docker-compose -f $COMPOSE_FILE exec -T mysql mysqladmin ping -h localhost --silent; do sleep 2; done" || log_warning "数据库启动超时"
    
    # 等待 Redis
    log_info "等待 Redis 启动..."
    timeout 30 bash -c "until docker-compose -f $COMPOSE_FILE exec -T redis redis-cli ping; do sleep 2; done" || log_warning "Redis 启动超时"
    
    # 等待 Web 服务
    log_info "等待 Web 服务启动..."
    sleep 30
    
    log_success "服务就绪"
}

# 执行数据库迁移
run_migrations() {
    if [[ "$MIGRATE" != "true" ]]; then
        return
    fi
    
    log_info "执行数据库迁移..."
    
    # 检查迁移脚本是否存在
    if [[ -f "scripts/migrate.php" ]]; then
        docker-compose -f "$COMPOSE_FILE" exec -T web php scripts/migrate.php || log_warning "数据库迁移失败"
    else
        log_warning "迁移脚本不存在"
    fi
    
    log_success "数据库迁移完成"
}

# 运行测试
run_tests() {
    if [[ "$SKIP_TESTS" == "true" ]] || [[ "$TEST" != "true" ]]; then
        return
    fi
    
    log_info "运行测试..."
    
    # 运行单元测试
    if [[ -f "vendor/bin/phpunit" ]]; then
        docker-compose -f "$COMPOSE_FILE" exec -T web vendor/bin/phpunit || log_warning "单元测试失败"
    fi
    
    # 运行集成测试
    if [[ -f "scripts/integration-test.sh" ]]; then
        docker-compose -f "$COMPOSE_FILE" exec -T web bash scripts/integration-test.sh || log_warning "集成测试失败"
    fi
    
    log_success "测试完成"
}

# 健康检查
health_check() {
    if [[ "$SKIP_HEALTH_CHECK" == "true" ]]; then
        log_info "跳过健康检查"
        return
    fi
    
    log_info "执行健康检查..."
    
    # 检查 Web 服务
    for i in {1..30}; do
        if curl -f http://localhost/health.php &> /dev/null; then
            log_success "Web 服务健康检查通过"
            break
        fi
        if [[ $i -eq 30 ]]; then
            log_error "Web 服务健康检查失败"
            return 1
        fi
        sleep 2
    done
    
    # 检查 API 服务
    if [[ -f "api/index.php" ]]; then
        for i in {1..30}; do
            if curl -f http://localhost/api/health &> /dev/null; then
                log_success "API 服务健康检查通过"
                break
            fi
            if [[ $i -eq 30 ]]; then
                log_error "API 服务健康检查失败"
                return 1
            fi
            sleep 2
        done
    fi
    
    log_success "所有健康检查通过"
}

# 回滚部署
rollback_deployment() {
    log_info "回滚部署..."
    
    # 查找最新的备份
    LATEST_BACKUP=$(ls -t backups/deployments/ | head -1)
    if [[ -z "$LATEST_BACKUP" ]]; then
        log_error "没有找到备份文件"
        exit 1
    fi
    
    BACKUP_DIR="backups/deployments/$LATEST_BACKUP"
    log_info "使用备份: $BACKUP_DIR"
    
    # 停止当前服务
    docker-compose -f "$COMPOSE_FILE" down
    
    # 恢复配置文件
    if [[ -f "$BACKUP_DIR/$ENV_FILE" ]]; then
        cp "$BACKUP_DIR/$ENV_FILE" ./
    fi
    
    if [[ -f "$BACKUP_DIR/$COMPOSE_FILE" ]]; then
        cp "$BACKUP_DIR/$COMPOSE_FILE" ./
    fi
    
    # 恢复数据库
    if [[ -f "$BACKUP_DIR/database.sql" ]]; then
        log_info "恢复数据库..."
        docker-compose -f "$COMPOSE_FILE" up -d mysql
        sleep 30
        docker-compose -f "$COMPOSE_FILE" exec -T mysql mysql -u root -p${MYSQL_ROOT_PASSWORD} < "$BACKUP_DIR/database.sql" || log_warning "数据库恢复失败"
    fi
    
    # 重启服务
    docker-compose -f "$COMPOSE_FILE" up -d
    
    log_success "回滚完成"
}

# 显示部署信息
show_deployment_info() {
    log_success "部署完成！"
    echo
    echo "环境: $ENVIRONMENT"
    echo "配置文件: $COMPOSE_FILE"
    echo "环境变量: $ENV_FILE"
    echo
    echo "服务状态:"
    docker-compose -f "$COMPOSE_FILE" ps
    echo
    echo "访问地址:"
    case $ENVIRONMENT in
        dev)
            echo "Web: http://localhost"
            [[ -f "api/index.php" ]] && echo "API: http://localhost/api"
            [[ -f "monitoring.php" ]] && echo "监控: http://localhost/monitoring"
            ;;
        test)
            echo "Web: http://localhost:8080"
            echo "API: http://localhost:8080/api"
            echo "监控: http://localhost:8082"
            ;;
        staging)
            echo "Web: http://localhost:8080"
            echo "API: http://localhost:8080/api"
            echo "监控: http://localhost:8082"
            ;;
        production)
            echo "Web: http://localhost"
            echo "API: http://localhost/api"
            echo "监控: http://localhost/monitoring"
            ;;
    esac
    echo
}

# 主函数
main() {
    log_info "开始部署发卡系统到 $ENVIRONMENT 环境..."
    
    # 检查系统要求
    check_system_requirements
    
    # 检查环境配置
    check_environment_config
    
    # 仅检查环境
    if [[ "$CHECK_ONLY" == "true" ]]; then
        log_success "环境检查完成"
        exit 0
    fi
    
    # 回滚操作
    if [[ "$ROLLBACK" == "true" ]]; then
        rollback_deployment
        show_deployment_info
        exit 0
    fi
    
    # 创建目录
    create_directories
    
    # 备份
    backup_current_deployment
    
    # 更新依赖
    update_dependencies
    
    # 构建镜像
    build_images
    
    # 启动服务
    start_services
    
    # 等待服务就绪
    wait_for_services
    
    # 执行迁移
    run_migrations
    
    # 运行测试
    run_tests
    
    # 健康检查
    health_check
    
    # 显示部署信息
    show_deployment_info
}

# 错误处理
trap 'log_error "部署过程中发生错误，请检查日志"; exit 1' ERR

# 执行主函数
main "$@"