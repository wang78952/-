# PHP路径引用统一标准

## 1. 概述

本文档定义了发卡系统PHP代码中路径引用的统一标准。为确保代码在不同环境和目录结构下稳定运行，我们采用`__DIR__`常量来构建绝对路径，替代传统的相对路径引用。

## 2. 为什么使用绝对路径

### 2.1 问题背景

使用相对路径引用文件存在以下问题：

- **目录位置敏感性**：相对路径依赖于当前工作目录（PHP脚本执行的位置）
- **包含文件层级变化**：在嵌套包含的情况下，相对路径容易出错
- **环境差异**：不同服务器环境下路径解析可能不一致
- **维护困难**：代码重构时，目录结构变化会导致大量路径修改

### 2.2 绝对路径的优势

使用基于`__DIR__`常量的绝对路径可以解决这些问题：

- **一致性**：无论从哪个目录执行脚本，都能正确定位文件
- **可靠性**：不依赖于当前工作目录
- **清晰性**：路径意图更明确，提高代码可读性
- **易于维护**：目录结构变化时，修改范围更小

## 3. 统一标准规范

### 3.1 基本规则

1. **强制使用`__DIR__`常量**：所有`require_once`、`include_once`、`require`、`include`语句必须使用`__DIR__`常量构建绝对路径
2. **路径分隔符**：使用正斜杠`/`作为路径分隔符（PHP内部会自动处理不同操作系统的差异）
3. **无多余斜杠**：确保路径中没有多余的斜杠
4. **文件存在性检查**：关键文件加载前应考虑添加存在性检查（可选）

### 3.2 示例格式

```php
// 正确格式（必须遵循）
require_once __DIR__ . '/includes/SecurityUtils.php';

// 多级目录格式
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/security/TwoFactorAuthenticator.php';
```

### 3.3 禁止的格式

```php
// 禁止：直接使用相对路径
require_once 'includes/SecurityUtils.php';

// 禁止：使用__FILE__（__DIR__更简洁）
require_once dirname(__FILE__) . '/includes/SecurityUtils.php';

// 禁止：混合使用不同的路径分隔符
require_once __DIR__ . '\includes\SecurityUtils.php';

// 禁止：使用多余的斜杠
require_once __DIR__ . '//includes//SecurityUtils.php';
```

## 4. 具体应用场景

### 4.1 根目录文件

```php
// 例如：cards.php, login.php, dashboard.php
require_once __DIR__ . '/includes/SecurityUtils.php';
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/config.php';
```

### 4.2 子目录文件

```php
// 例如：admin/orders.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/AuthManager.php';
require_once __DIR__ . '/../includes/SecurityUtils.php';
```

### 4.3 深层嵌套目录

```php
// 例如：api/analytics/dashboard_api.php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/Database.php';
```

### 4.4 包含目录内部文件

```php
// 例如：includes/AuthManager.php内部引用其他文件
require_once __DIR__ . '/security/TwoFactorAuthenticator.php';
require_once __DIR__ . '/utils/Validation.php';
```

## 5. 最佳实践

### 5.1 文件组织建议

- **集中式配置**：创建一个配置文件包含所有路径定义
- **使用常量**：对于频繁访问的目录，可以定义全局常量
- **模块化结构**：按功能模块组织代码，减少深层嵌套

### 5.2 性能考虑

- `__DIR__`常量在编译时解析，性能影响极小
- 对于高并发场景，考虑使用文件缓存避免重复加载

### 5.3 错误处理

```php
// 推荐：添加错误处理
$file = __DIR__ . '/includes/CriticalUtils.php';
if (!file_exists($file)) {
    throw new Exception("关键文件不存在: $file");
}
require_once $file;
```

## 6. 代码审查检查项

在代码审查过程中，请检查以下内容：

- 所有文件引用是否使用`__DIR__`常量
- 路径格式是否符合规范（使用正斜杠，无多余斜杠）
- 没有遗漏的相对路径引用
- 嵌套包含的路径是否正确

## 7. 迁移指南

对于现有代码的迁移：

1. **识别相对路径**：搜索模式如`require_once '`、`include_once "`
2. **转换为绝对路径**：替换为`require_once __DIR__ . '/`格式
3. **验证测试**：使用`test_paths.php`脚本验证路径正确性
4. **逐步替换**：优先替换关键文件，然后处理依赖文件

## 8. 例外情况

以下情况可以考虑例外处理：

- 使用PHP的自动加载机制（如Composer的`require_once 'vendor/autoload.php'`）
- 明确指定的外部资源路径
- 配置文件中用户自定义的路径设置

## 9. 常见问题解答

### 9.1 Q: `__DIR__`和`dirname(__FILE__)`有什么区别？

A: `__DIR__`是PHP 5.3.0引入的常量，等效于`dirname(__FILE__)`，但更简洁清晰。我们推荐使用`__DIR__`。

### 9.2 Q: 如何处理Windows和Linux的路径分隔符差异？

A: PHP内部会自动处理路径分隔符的差异。使用正斜杠`/`作为路径分隔符是最安全的做法，PHP会在不同操作系统上正确解析。

### 9.3 Q: 是否需要在路径末尾添加斜杠？

A: 不需要。当连接文件路径时，应该在`__DIR__`后面手动添加分隔符，例如：`__DIR__ . '/includes/file.php'`。

### 9.4 Q: 如何处理跨多个目录级别的路径？

A: 使用`__DIR__`配合`../`来处理上层目录，例如：`__DIR__ . '/../../config.php'`。

## 10. 参考资源

- [PHP官方文档：Magic Constants](https://www.php.net/manual/en/language.constants.magic.php)
- [PHP最佳实践指南](https://phptherightway.com/)
- [PSR-4自动加载规范](https://www.php-fig.org/psr/psr-4/)

---

本文档由发卡系统开发团队维护，最后更新时间：2024年

版本：1.0