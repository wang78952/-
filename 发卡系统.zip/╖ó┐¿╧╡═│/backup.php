<?php
/**
 * 备份管理页面
 */

require_once 'config.php';
require_once 'includes/AuthManager.php';
require_once 'includes/BackupManager.php';
require_once 'includes/BackupScheduler.php';
require_once 'includes/SecurityUtils.php';

// 检查用户权限
$authManager = AuthManager::getInstance();
if (!$authManager->isLoggedIn() || !$authManager->hasPermission('backup_manage')) {
    header('Location: login.php');
    exit;
}

$backupManager = BackupManager::getInstance();
$scheduler = BackupScheduler::getInstance();

// 处理操作请求
$action = $_GET['action'] ?? '';
$message = '';
$messageType = '';

switch ($action) {
    case 'create_backup':
        $description = SecurityUtils::sanitizeInput($_POST['description'] ?? '');
        $backupType = SecurityUtils::sanitizeInput($_POST['backup_type'] ?? 'database');
        
        if ($backupType === 'incremental') {
            $result = $backupManager->createIncrementalBackup($description);
        } else if ($backupType === 'files') {
            $result = $backupManager->createFilesBackup($description);
        } else if ($backupType === 'logs') {
            $result = $backupManager->createLogsBackup($description);
        } else if ($backupType === 'full') {
            $result = $backupManager->createFullBackup($description);
        } else {
            $result = $backupManager->createDatabaseBackup($description);
        }
        
        if ($result['success']) {
            $message = "备份创建成功！文件名: {$result['filename']}";
            $messageType = 'success';
        } else {
            $message = "备份创建失败: {$result['error']}";
            $messageType = 'error';
        }
        break;
        
    case 'restore_backup':
        $filename = SecurityUtils::sanitizeInput($_POST['filename'] ?? '');
        $result = $backupManager->restoreDatabaseBackup($filename);
        
        if ($result['success']) {
            $message = "数据恢复成功！执行了 {$result['statements_executed']} 条SQL语句";
            $messageType = 'success';
        } else {
            $message = "数据恢复失败: {$result['error']}";
            $messageType = 'error';
        }
        break;
        
    case 'delete_backup':
        $filename = SecurityUtils::sanitizeInput($_POST['filename'] ?? '');
        $type = SecurityUtils::sanitizeInput($_POST['type'] ?? 'database');
        
        if ($backupManager->deleteBackup($filename, $type)) {
            $message = "备份文件删除成功";
            $messageType = 'success';
        } else {
            $message = "备份文件删除失败";
            $messageType = 'error';
        }
        break;
        
    case 'verify_backup':
        $filename = SecurityUtils::sanitizeInput($_POST['filename'] ?? '');
        $result = $backupManager->verifyBackup($filename);
        
        if ($result['success']) {
            $message = "备份验证成功！文件大小: {$result['filesize']}, 有效语句: {$result['valid_statements']}";
            $messageType = 'success';
        } else {
            $message = "备份验证失败: {$result['error']}";
            $messageType = 'error';
        }
        break;
        
    case 'run_scheduler':
        $result = $scheduler->runScheduledBackups();
        
        if ($result['success']) {
            $message = "调度备份执行完成！执行了 {$result['executed_count']} 个任务";
            $messageType = 'success';
        } else {
            $message = "调度备份执行失败: {$result['error']}";
            $messageType = 'error';
        }
        break;
}

// 获取数据
$backups = $backupManager->getBackupList('database');
$schedules = $scheduler->getSchedules();
$backupStats = $backupManager->getBackupStats();
$scheduleStats = $scheduler->getScheduleStats();

// 处理AJAX请求
if (isset($_POST['action'])) {
    // 处理不同的AJAX请求
    switch ($_POST['action']) {
        case 'backup':
            // 执行备份操作
            $backupType = isset($_POST['type']) ? $_POST['type'] : 'database';
            $syncToRemote = isset($_POST['sync_to_remote']) && $_POST['sync_to_remote'] == 1;
            $result = $backupManager->createBackup($backupType, '', $syncToRemote);
            echo json_encode($result);
            break;
            
        case 'delete_backup':
            // 删除备份文件
            $filename = isset($_POST['filename']) ? $_POST['filename'] : '';
            $type = isset($_POST['type']) ? $_POST['type'] : 'database';
            $result = $backupManager->deleteBackup($filename, $type);
            echo json_encode(['success' => $result]);
            break;
            
        case 'restore':
            // 恢复备份（支持一键恢复功能）
            $filename = isset($_POST['filename']) ? $_POST['filename'] : '';
            $fromRemote = isset($_POST['from_remote']) && $_POST['from_remote'] === 'true';
            $remoteType = isset($_POST['remote_type']) ? $_POST['remote_type'] : null;
            
            try {
                $result = $backupManager->restoreDatabaseBackup($filename, $fromRemote, $remoteType);
                echo json_encode($result);
            } catch (Exception $e) {
                echo json_encode(array(
                    'success' => false,
                    'error' => $e->getMessage(),
                    'steps' => array(array(
                        'step' => '恢复过程中断',
                        'status' => '错误',
                        'time' => date('H:i:s'),
                        'details' => $e->getMessage()
                    ))
                ));
            }
            break;
            
        case 'get_restore_history':
            // 获取恢复历史记录
            try {
                // 这里可以从日志表中获取恢复历史记录
                $history = array();
                
                // 暂时返回模拟数据
                $history = array(
                    array(
                        'id' => 1,
                        'filename' => 'backup_20240120_120000.sql.gz',
                        'from_remote' => false,
                        'remote_type' => null,
                        'success' => true,
                        'time_started' => '2024-01-20 12:00:00',
                        'time_completed' => '2024-01-20 12:02:30',
                        'statements_executed' => 150,
                        'total_statements' => 150,
                        'steps' => array()
                    ),
                    array(
                        'id' => 2,
                        'filename' => 'backup_20240119_203000.sql.gz',
                        'from_remote' => true,
                        'remote_type' => 'aws_s3',
                        'success' => true,
                        'time_started' => '2024-01-19 20:30:00',
                        'time_completed' => '2024-01-19 20:35:45',
                        'statements_executed' => 230,
                        'total_statements' => 230,
                        'steps' => array()
                    )
                );
                
                echo json_encode(array('history' => $history, 'success' => true));
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'error' => $e->getMessage()));
            }
            break;
            
        case 'load_remote_config':
            // 加载远程备份配置
            $config = method_exists($backupManager, 'getRemoteConfig') ? $backupManager->getRemoteConfig() : [];
            echo json_encode($config);
            break;
            
        case 'save_remote_config':
            // 保存远程备份配置
            $storageType = isset($_POST['storage_type']) ? $_POST['storage_type'] : '';
            $config = [];
            
            // 解析不同类型的配置
            switch($storageType) {
                case 'ftp':
                    $config = [
                        'enabled' => isset($_POST['enabled']) && $_POST['enabled'] == 1,
                        'host' => isset($_POST['host']) ? $_POST['host'] : '',
                        'port' => isset($_POST['port']) ? intval($_POST['port']) : 21,
                        'username' => isset($_POST['username']) ? $_POST['username'] : '',
                        'password' => isset($_POST['password']) ? $_POST['password'] : ''
                    ];
                    break;
                    
                case 'sftp':
                    $config = [
                        'enabled' => isset($_POST['enabled']) && $_POST['enabled'] == 1,
                        'host' => isset($_POST['host']) ? $_POST['host'] : '',
                        'port' => isset($_POST['port']) ? intval($_POST['port']) : 22,
                        'username' => isset($_POST['username']) ? $_POST['username'] : '',
                        'auth_type' => isset($_POST['auth_type']) ? $_POST['auth_type'] : 'password',
                        'password' => isset($_POST['password']) ? $_POST['password'] : '',
                        'public_key' => isset($_POST['public_key']) ? $_POST['public_key'] : '',
                        'private_key' => isset($_POST['private_key']) ? $_POST['private_key'] : '',
                        'passphrase' => isset($_POST['passphrase']) ? $_POST['passphrase'] : ''
                    ];
                    break;
                    
                case 'aws_s3':
                    $config = [
                        'enabled' => isset($_POST['enabled']) && $_POST['enabled'] == 1,
                        'region' => isset($_POST['region']) ? $_POST['region'] : '',
                        'bucket' => isset($_POST['bucket']) ? $_POST['bucket'] : '',
                        'access_key' => isset($_POST['access_key']) ? $_POST['access_key'] : '',
                        'secret_key' => isset($_POST['secret_key']) ? $_POST['secret_key'] : ''
                    ];
                    break;
                    
                case 'aliyun_oss':
                    $config = [
                        'enabled' => isset($_POST['enabled']) && $_POST['enabled'] == 1,
                        'endpoint' => isset($_POST['endpoint']) ? $_POST['endpoint'] : '',
                        'bucket' => isset($_POST['bucket']) ? $_POST['bucket'] : '',
                        'access_key' => isset($_POST['access_key']) ? $_POST['access_key'] : '',
                        'secret_key' => isset($_POST['secret_key']) ? $_POST['secret_key'] : ''
                    ];
                    break;
            }
            
            $result = method_exists($backupManager, 'saveRemoteConfig') ? $backupManager->saveRemoteConfig($storageType, $config) : false;
            echo json_encode(['success' => $result, 'message' => $result ? '配置保存成功' : '保存失败']);
            break;
            
        case 'get_remote_status':
            // 获取远程备份状态
            $status = method_exists($backupManager, 'getRemoteStatus') ? $backupManager->getRemoteStatus() : [];
            echo json_encode($status);
            break;
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>备份管理 - <?php echo APP_NAME; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            padding: 20px 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: #333;
            font-size: 28px;
        }
        
        .nav-links {
            display: flex;
            gap: 15px;
        }
        
        .nav-link {
            padding: 8px 16px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 20px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .message {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        @media (max-width: 1024px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .card h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 20px;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-success {
            background: linear-gradient(45deg, #43e97b, #38f9d7);
            color: white;
        }
        
        .btn-warning {
            background: linear-gradient(45deg, #fa709a, #fee140);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(45deg, #ff6b6b, #feca57);
            color: white;
        }
        
        .modal-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 10px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            max-width: 800px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .modal-content {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 20px;
            border-top: 1px solid #eee;
            text-align: right;
        }
        
        .close {
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }
        
        .mt-5 {
            margin-top: 15px;
        }
        
        .mt-10 {
            margin-top: 20px;
        }
        
        .mt-20 {
            margin-top: 30px;
        }
        
        .ml-10 {
            margin-left: 20px;
        }
        
        .well {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #e9ecef;
        }
        
        .step-item {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #fff;
            border-radius: 5px;
            border-left: 3px solid #667eea;
        }
        
        .step-item.success {
            border-left-color: #28a745;
            color: #28a745;
        }
        
        .step-item.error {
            border-left-color: #dc3545;
            color: #dc3545;
        }
        
        .tab-content {
            padding: 20px 0;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e1e5e9;
        }
        
        .table th {
            background: #f8f9fa;
            color: #333;
            font-weight: 600;
        }
        
        .table tr:hover {
            background: #f8f9fa;
        }
        
        .schedule-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }
        
        .schedule-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .schedule-name {
            font-weight: 600;
            color: #333;
        }
        
        .schedule-status {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .schedule-status.enabled {
            background: #d4edda;
            color: #155724;
        }
        
        .schedule-status.disabled {
            background: #f8d7da;
            color: #721c24;
        }
        
        .schedule-info {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }
        
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }
        
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 20px;
            color: #333;
        }
        
        .close {
            font-size: 28px;
            font-weight: bold;
            color: #aaa;
            cursor: pointer;
        }
        
        .close:hover {
            color: #000;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💾 备份管理</h1>
            <div class="nav-links">
                <a href="dashboard.php" class="nav-link">返回首页</a>
                <a href="logs.php" class="nav-link">系统日志</a>
                <a href="logout.php" class="nav-link">退出登录</a>
            </div>
        </div>
        
        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $backupStats['database']['count']; ?></div>
                <div class="stat-label">数据库备份数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $backupStats['database']['total_size']; ?></div>
                <div class="stat-label">备份总大小</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $scheduleStats['enabled_schedules']; ?></div>
                <div class="stat-label">活跃调度任务</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $backupStats['database']['latest']; ?></div>
                <div class="stat-label">最近备份时间</div>
            </div>
        </div>
        
        <div class="content-grid">
            <div class="card">
                <h2>📋 创建备份</h2>
                <form method="POST" action="?action=create_backup">
                    <div class="form-group">
                        <label for="description">备份描述</label>
                        <textarea id="description" name="description" rows="3" placeholder="请输入备份描述信息..."></textarea>
                    </div>
                    <div class="form-group">
                        <label for="backup_type">备份类型</label>
                        <select id="backup_type" name="backup_type" class="form-control">
                            <option value="database">数据库完整备份</option>
                            <option value="incremental">数据库增量备份</option>
                            <option value="files">文件备份</option>
                            <option value="logs">日志备份</option>
                            <option value="full">完整备份</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="sync_to_remote">同步到远程存储</label>
                        <input type="checkbox" id="sync_to_remote" name="sync_to_remote" checked>
                        <span style="margin-left: 8px;">启用远程备份</span>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        🔄 创建备份
                    </button>
                </form>
                
                <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <h3 style="margin-top: 0; font-size: 16px; color: #667eea;">🌐 远程备份配置</h3>
                    <p style="font-size: 14px; color: #666;">当前远程备份状态：<span id="remote-backup-status">未配置</span></p>
                    <button type="button" class="btn btn-primary" style="padding: 5px 15px; font-size: 12px;" onclick="configureRemoteBackup()">
                        ⚙️ 配置远程备份
                    </button>
                </div>
                
                <div style="margin-top: 20px;">
                    <button onclick="runScheduler()" class="btn btn-success">
                        ⚡ 执行调度备份
                    </button>
                    <button onclick="refreshPage()" class="btn btn-warning">
                        🔄 刷新页面
                    </button>
                    <button onclick="quickIncrementalBackup()" class="btn btn-info">
                        ⏱️ 快速增量备份
                    </button>
                </div>
            </div>
            
            <div class="card">
                <h2>📅 调度任务</h2>
                <div id="schedule-list">
                    <?php foreach ($schedules as $schedule): ?>
                        <div class="schedule-item">
                            <div class="schedule-header">
                                <div class="schedule-name"><?php echo htmlspecialchars($schedule['name']); ?></div>
                                <div class="schedule-status <?php echo $schedule['enabled'] ? 'enabled' : 'disabled'; ?>">
                                    <?php echo $schedule['enabled'] ? '启用' : '禁用'; ?>
                                </div>
                            </div>
                            <div class="schedule-info">
                                <div>频率: <?php echo $schedule['frequency']; ?> | 时间: <?php echo $schedule['time']; ?></div>
                                <div>描述: <?php echo htmlspecialchars($schedule['description']); ?></div>
                                <div>最大备份数: <?php echo $schedule['max_backups']; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>📦 备份文件列表</h2>
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <div>处理中...</div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>文件名</th>
                        <th>大小</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($backups as $backup): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($backup['filename']); ?></td>
                            <td><?php echo $backup['size']; ?></td>
                            <td><?php echo $backup['created_time']; ?></td>
                            <td>
                                <button onclick="verifyBackup('<?php echo htmlspecialchars($backup['filename']); ?>')" 
                                        class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;">
                                    🔍 验证
                                </button>
                                <button onclick="restoreBackup('<?php echo htmlspecialchars($backup['filename']); ?>')" 
                                        class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">
                                    🔄 恢复
                                </button>
                                <button onclick="deleteBackup('<?php echo htmlspecialchars($backup['filename']); ?>')" 
                                        class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;">
                                    🗑️ 删除
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 远程备份配置模态框 -->
    <div class="modal fade" id="remoteConfigModal" tabindex="-1" role="dialog" aria-labelledby="remoteConfigModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="remoteConfigModalLabel">远程备份配置</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="关闭">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs" id="remoteConfigTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="ftp-tab" data-toggle="tab" href="#ftp" role="tab" aria-controls="ftp" aria-selected="true">FTP</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="sftp-tab" data-toggle="tab" href="#sftp" role="tab" aria-controls="sftp" aria-selected="false">SFTP</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="aws-s3-tab" data-toggle="tab" href="#aws-s3" role="tab" aria-controls="aws-s3" aria-selected="false">AWS S3</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="aliyun-oss-tab" data-toggle="tab" href="#aliyun-oss" role="tab" aria-controls="aliyun-oss" aria-selected="false">阿里云OSS</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="remoteConfigTabContent">
                        <!-- FTP配置 -->
                        <div class="tab-pane fade show active" id="ftp" role="tabpanel" aria-labelledby="ftp-tab">
                            <form id="ftpConfigForm" class="mt-3">
                                <input type="hidden" name="storage_type" value="ftp">
                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="ftpEnabled" name="enabled" value="1">
                                        <label class="form-check-label" for="ftpEnabled">启用FTP备份</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="ftpHost">FTP服务器地址</label>
                                    <input type="text" class="form-control" id="ftpHost" name="host" placeholder="example.com">
                                </div>
                                <div class="form-group">
                                    <label for="ftpPort">端口</label>
                                    <input type="number" class="form-control" id="ftpPort" name="port" value="21">
                                </div>
                                <div class="form-group">
                                    <label for="ftpUsername">用户名</label>
                                    <input type="text" class="form-control" id="ftpUsername" name="username">
                                </div>
                                <div class="form-group">
                                    <label for="ftpPassword">密码</label>
                                    <input type="password" class="form-control" id="ftpPassword" name="password">
                                </div>
                            </form>
                        </div>
                        <!-- SFTP配置 -->
                        <div class="tab-pane fade" id="sftp" role="tabpanel" aria-labelledby="sftp-tab">
                            <form id="sftpConfigForm" class="mt-3">
                                <input type="hidden" name="storage_type" value="sftp">
                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="sftpEnabled" name="enabled" value="1">
                                        <label class="form-check-label" for="sftpEnabled">启用SFTP备份</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="sftpHost">SFTP服务器地址</label>
                                    <input type="text" class="form-control" id="sftpHost" name="host" placeholder="example.com">
                                </div>
                                <div class="form-group">
                                    <label for="sftpPort">端口</label>
                                    <input type="number" class="form-control" id="sftpPort" name="port" value="22">
                                </div>
                                <div class="form-group">
                                    <label for="sftpUsername">用户名</label>
                                    <input type="text" class="form-control" id="sftpUsername" name="username">
                                </div>
                                <div class="form-group">
                                    <label>认证方式</label>
                                    <div class="form-check">
                                        <input type="radio" class="form-check-input" name="auth_type" id="sftpAuthPassword" value="password" checked>
                                        <label class="form-check-label" for="sftpAuthPassword">密码认证</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="form-check-input" name="auth_type" id="sftpAuthKey" value="key">
                                        <label class="form-check-label" for="sftpAuthKey">密钥认证</label>
                                    </div>
                                </div>
                                <div id="sftpPasswordSection">
                                    <div class="form-group">
                                        <label for="sftpPassword">密码</label>
                                        <input type="password" class="form-control" id="sftpPassword" name="password">
                                    </div>
                                </div>
                                <div id="sftpKeySection" style="display: none;">
                                    <div class="form-group">
                                        <label for="sftpPublicKey">公钥文件路径</label>
                                        <input type="text" class="form-control" id="sftpPublicKey" name="public_key">
                                    </div>
                                    <div class="form-group">
                                        <label for="sftpPrivateKey">私钥文件路径</label>
                                        <input type="text" class="form-control" id="sftpPrivateKey" name="private_key">
                                    </div>
                                    <div class="form-group">
                                        <label for="sftpPassphrase">密钥密码（可选）</label>
                                        <input type="password" class="form-control" id="sftpPassphrase" name="passphrase">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- AWS S3配置 -->
                        <div class="tab-pane fade" id="aws-s3" role="tabpanel" aria-labelledby="aws-s3-tab">
                            <form id="awsS3ConfigForm" class="mt-3">
                                <input type="hidden" name="storage_type" value="aws_s3">
                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="awsS3Enabled" name="enabled" value="1">
                                        <label class="form-check-label" for="awsS3Enabled">启用AWS S3备份</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="awsS3Region">区域</label>
                                    <input type="text" class="form-control" id="awsS3Region" name="region" placeholder="us-east-1">
                                </div>
                                <div class="form-group">
                                    <label for="awsS3Bucket">存储桶名称</label>
                                    <input type="text" class="form-control" id="awsS3Bucket" name="bucket">
                                </div>
                                <div class="form-group">
                                    <label for="awsS3AccessKey">访问密钥</label>
                                    <input type="text" class="form-control" id="awsS3AccessKey" name="access_key">
                                </div>
                                <div class="form-group">
                                    <label for="awsS3SecretKey">密钥</label>
                                    <input type="password" class="form-control" id="awsS3SecretKey" name="secret_key">
                                </div>
                            </form>
                        </div>
                        <!-- 阿里云OSS配置 -->
                        <div class="tab-pane fade" id="aliyun-oss" role="tabpanel" aria-labelledby="aliyun-oss-tab">
                            <form id="aliyunOSSConfigForm" class="mt-3">
                                <input type="hidden" name="storage_type" value="aliyun_oss">
                                <div class="form-group">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="aliyunOSSEnabled" name="enabled" value="1">
                                        <label class="form-check-label" for="aliyunOSSEnabled">启用阿里云OSS备份</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="aliyunOSSEndpoint">Endpoint</label>
                                    <input type="text" class="form-control" id="aliyunOSSEndpoint" name="endpoint" placeholder="oss-cn-hangzhou.aliyuncs.com">
                                </div>
                                <div class="form-group">
                                    <label for="aliyunOSSBucket">存储桶名称</label>
                                    <input type="text" class="form-control" id="aliyunOSSBucket" name="bucket">
                                </div>
                                <div class="form-group">
                                    <label for="aliyunOSSAccessKey">AccessKey ID</label>
                                    <input type="text" class="form-control" id="aliyunOSSAccessKey" name="access_key">
                                </div>
                                <div class="form-group">
                                    <label for="aliyunOSSSecretKey">AccessKey Secret</label>
                                    <input type="password" class="form-control" id="aliyunOSSSecretKey" name="secret_key">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                    <button type="button" class="btn btn-primary" id="saveRemoteConfig">保存配置</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 一键恢复进度模态框 -->
    <div id="restoreProgressModal" class="modal">
        <div class="modal-backdrop" onclick="closeModal('restoreProgressModal')"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">⏳ 数据库恢复进行中</h3>
                <span class="close" onclick="closeModal('restoreProgressModal')">&times;</span>
            </div>
            <div class="modal-body">
                <div class="progress">
                    <div id="restoreProgressBar" style="height: 20px; background: linear-gradient(90deg, #667eea, #764ba2); border-radius: 10px; width: 0%; transition: width 0.3s ease; text-align: center; line-height: 20px; color: white; font-weight: bold;">
                        0%
                    </div>
                </div>
                <div class="mt-20">
                    <h4>恢复状态</h4>
                    <p id="restoreStatusText">准备恢复中...</p>
                </div>
                <div class="mt-20">
                    <h4>执行步骤</h4>
                    <div id="restoreSteps" class="well">
                        <!-- 恢复步骤将动态显示 -->
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('restoreProgressModal')" id="closeRestoreModalBtn" disabled>关闭</button>
            </div>
        </div>
    </div>
    
    <!-- 恢复确认模态框 -->
    <div id="restoreModal" class="modal">
        <div class="modal-backdrop" onclick="closeModal('restoreModal')"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">⚠️ 确认恢复数据</h3>
                <span class="close" onclick="closeModal('restoreModal')">&times;</span>
            </div>
            <div class="modal-body">
                <p>您确定要恢复这个备份吗？此操作将覆盖当前数据库中的所有数据！</p>
                <p><strong>备份文件:</strong> <span id="restoreFilename"></span></p>
                
                <div class="mt-10">
                    <label for="restoreFromRemote">恢复来源：</label>
                    <select id="restoreFromRemote" class="form-control">
                        <option value="local">本地存储</option>
                        <option value="ftp">FTP远程存储</option>
                        <option value="sftp">SFTP远程存储</option>
                        <option value="aws_s3">AWS S3存储</option>
                        <option value="aliyun_oss">阿里云OSS存储</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="executeRestoreBackup()">确认恢复</button>
                <button type="button" class="btn btn-primary" onclick="closeModal('restoreModal')">取消</button>
            </div>
        </div>
    </div>
    
    <!-- 删除确认模态框 -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">🗑️ 确认删除备份</h3>
                <span class="close" onclick="closeModal('deleteModal')">&times;</span>
            </div>
            <p>您确定要删除这个备份文件吗？此操作不可恢复！</p>
            <p><strong>备份文件:</strong> <span id="deleteFilename"></span></p>
            <form method="POST" action="?action=delete_backup" id="deleteForm">
                <input type="hidden" name="filename" id="deleteFilenameInput">
                <input type="hidden" name="type" value="database">
                <div style="margin-top: 20px;">
                    <button type="submit" class="btn btn-danger">确认删除</button>
                    <button type="button" class="btn btn-primary" onclick="closeModal('deleteModal')">取消</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function showLoading() {
            document.getElementById('loading').style.display = 'block';
        }
        
        function hideLoading() {
            document.getElementById('loading').style.display = 'none';
        }
        
        function runScheduler() {
            showLoading();
            window.location.href = '?action=run_scheduler';
        }
        
        function quickIncrementalBackup() {
            showLoading();
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '?action=create_backup';
            
            const descriptionInput = document.createElement('input');
            descriptionInput.type = 'hidden';
            descriptionInput.name = 'description';
            descriptionInput.value = '快速增量备份 - ' + new Date().toLocaleString();
            
            const typeInput = document.createElement('input');
            typeInput.type = 'hidden';
            typeInput.name = 'backup_type';
            typeInput.value = 'incremental';
            
            form.appendChild(descriptionInput);
            form.appendChild(typeInput);
            document.body.appendChild(form);
            form.submit();
        }
        
        function refreshPage() {
            showLoading();
            setTimeout(() => {
                window.location.reload();
            }, 500);
        }
        
        function verifyBackup(filename) {
            showLoading();
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '?action=verify_backup';
            
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'filename';
            input.value = filename;
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
        
        function restoreBackup(filename) {
            document.getElementById('restoreFilename').textContent = filename;
            // 保存文件名到全局变量，以便执行恢复时使用
            window.currentRestoreFilename = filename;
            document.getElementById('restoreModal').style.display = 'block';
        }
        
        function executeRestoreBackup() {
            const filename = window.currentRestoreFilename;
            const source = document.getElementById('restoreFromRemote').value;
            const fromRemote = source !== 'local';
            const remoteType = fromRemote ? source : null;
            
            // 关闭确认模态框
            closeModal('restoreModal');
            
            // 显示进度模态框
            document.getElementById('restoreProgressModal').style.display = 'block';
            
            // 重置进度条
            document.getElementById('restoreProgressBar').style.width = '0%';
            document.getElementById('restoreProgressBar').textContent = '0%';
            document.getElementById('restoreStatusText').textContent = '准备恢复中...';
            document.getElementById('restoreSteps').innerHTML = '';
            document.getElementById('closeRestoreModalBtn').disabled = true;
            
            // 使用AJAX执行恢复操作
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'backup.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            // 模拟进度更新（在实际操作完成前）
            let progressInterval;
            let simulatedProgress = 0;
            
            progressInterval = setInterval(() => {
                simulatedProgress += Math.random() * 5;
                if (simulatedProgress > 95) simulatedProgress = 95; // 保留5%直到实际完成
                
                document.getElementById('restoreProgressBar').style.width = simulatedProgress + '%';
                document.getElementById('restoreProgressBar').textContent = Math.round(simulatedProgress) + '%';
            }, 800);
            
            xhr.onload = function() {
                clearInterval(progressInterval);
                
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        // 更新进度为100%
                        document.getElementById('restoreProgressBar').style.width = '100%';
                        document.getElementById('restoreProgressBar').textContent = '100%';
                        
                        // 更新状态文本
                        if (response.success) {
                            document.getElementById('restoreStatusText').textContent = '✅ 恢复成功完成！';
                        } else {
                            document.getElementById('restoreStatusText').textContent = '❌ 恢复失败！';
                        }
                        
                        // 显示恢复步骤
                        let stepsHtml = '';
                        if (response.steps && response.steps.length > 0) {
                            response.steps.forEach(step => {
                                const stepClass = step.status === '成功' ? 'success' : (step.status === '错误' ? 'error' : '');
                                stepsHtml += `
                                    <div class="step-item ${stepClass}">
                                        <strong>${step.step}</strong> [${step.time}] - ${step.status}
                                        ${step.details ? `<div class="mt-5">${step.details}</div>` : ''}
                                    </div>
                                `;
                            });
                        } else if (response.error) {
                            stepsHtml = `<div class="step-item error">错误: ${response.error}</div>`;
                        }
                        
                        document.getElementById('restoreSteps').innerHTML = stepsHtml;
                        
                        // 启用关闭按钮
                        document.getElementById('closeRestoreModalBtn').disabled = false;
                        
                        // 自动刷新页面
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                        
                    } catch (e) {
                        console.error('解析响应失败:', e);
                        document.getElementById('restoreStatusText').textContent = '❌ 处理响应失败！';
                        document.getElementById('restoreSteps').innerHTML = '<div class="step-item error">服务器响应格式错误</div>';
                        document.getElementById('closeRestoreModalBtn').disabled = false;
                    }
                } else {
                    document.getElementById('restoreStatusText').textContent = '❌ 请求失败！';
                    document.getElementById('restoreSteps').innerHTML = `<div class="step-item error">HTTP错误: ${xhr.status}</div>`;
                    document.getElementById('closeRestoreModalBtn').disabled = false;
                }
            };
            
            xhr.onerror = function() {
                clearInterval(progressInterval);
                document.getElementById('restoreStatusText').textContent = '❌ 网络错误！';
                document.getElementById('restoreSteps').innerHTML = '<div class="step-item error">无法连接到服务器</div>';
                document.getElementById('closeRestoreModalBtn').disabled = false;
            };
            
            // 发送请求
            xhr.send(`action=restore&filename=${encodeURIComponent(filename)}&from_remote=${fromRemote}&remote_type=${encodeURIComponent(remoteType || '')}`);
        }
        
        function deleteBackup(filename) {
            document.getElementById('deleteFilename').textContent = filename;
            document.getElementById('deleteFilenameInput').value = filename;
            document.getElementById('deleteModal').style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // 点击模态框外部关闭
        window.onclick = function(event) {
            const restoreModal = document.getElementById('restoreModal');
            const deleteModal = document.getElementById('deleteModal');
            
            if (event.target === restoreModal) {
                restoreModal.style.display = 'none';
            }
            if (event.target === deleteModal) {
                deleteModal.style.display = 'none';
            }
        }
        
        // 自动刷新（每5分钟）
        setInterval(() => {
            console.log('自动刷新备份列表...');
            refreshPage();
        }, 300000);
        
        // 远程备份配置相关功能
        function configureRemoteBackup() {
            $('#remoteConfigModal').modal('show');
        }
        
        // 显示提示信息
        function showAlert(message, type) {
            // 创建一个提示框元素
            const alertDiv = document.createElement('div');
            alertDiv.className = 'message ' + type;
            alertDiv.textContent = message;
            alertDiv.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; width: 300px;';
            
            // 添加到页面
            document.body.appendChild(alertDiv);
            
            // 3秒后自动移除
            setTimeout(() => {
                alertDiv.style.opacity = '0';
                alertDiv.style.transition = 'opacity 0.5s';
                setTimeout(() => {
                    if (document.body.contains(alertDiv)) {
                        document.body.removeChild(alertDiv);
                    }
                }, 500);
            }, 3000);
        }
        
        $(document).ready(function() {
            // SFTP认证方式切换
            $('input[name="auth_type"]').change(function() {
                if($(this).val() === 'key') {
                    $('#sftpPasswordSection').hide();
                    $('#sftpKeySection').show();
                } else {
                    $('#sftpPasswordSection').show();
                    $('#sftpKeySection').hide();
                }
            });
            
            // 远程备份配置加载
            $('#remoteConfigModal').on('show.bs.modal', function() {
                // 加载现有配置
                $.ajax({
                    url: 'backup.php',
                    type: 'POST',
                    data: {action: 'load_remote_config'},
                    success: function(response) {
                        try {
                            const configs = JSON.parse(response);
                            // 填充FTP配置
                            if(configs.ftp) {
                                $('#ftpEnabled').prop('checked', configs.ftp.enabled || false);
                                $('#ftpHost').val(configs.ftp.host || '');
                                $('#ftpPort').val(configs.ftp.port || 21);
                                $('#ftpUsername').val(configs.ftp.username || '');
                                $('#ftpPassword').val(configs.ftp.password || '');
                            }
                            
                            // 填充SFTP配置
                            if(configs.sftp) {
                                $('#sftpEnabled').prop('checked', configs.sftp.enabled || false);
                                $('#sftpHost').val(configs.sftp.host || '');
                                $('#sftpPort').val(configs.sftp.port || 22);
                                $('#sftpUsername').val(configs.sftp.username || '');
                                
                                // 设置认证方式
                                if(configs.sftp.auth_type === 'key') {
                                    $('#sftpAuthKey').prop('checked', true);
                                    $('#sftpPasswordSection').hide();
                                    $('#sftpKeySection').show();
                                } else {
                                    $('#sftpAuthPassword').prop('checked', true);
                                    $('#sftpPasswordSection').show();
                                    $('#sftpKeySection').hide();
                                }
                                
                                // 填充认证信息
                                $('#sftpPassword').val(configs.sftp.password || '');
                                $('#sftpPublicKey').val(configs.sftp.public_key || '');
                                $('#sftpPrivateKey').val(configs.sftp.private_key || '');
                                $('#sftpPassphrase').val(configs.sftp.passphrase || '');
                            }
                            
                            // 填充AWS S3配置
                            if(configs.aws_s3) {
                                $('#awsS3Enabled').prop('checked', configs.aws_s3.enabled || false);
                                $('#awsS3Region').val(configs.aws_s3.region || '');
                                $('#awsS3Bucket').val(configs.aws_s3.bucket || '');
                                $('#awsS3AccessKey').val(configs.aws_s3.access_key || '');
                                $('#awsS3SecretKey').val(configs.aws_s3.secret_key || '');
                            }
                            
                            // 填充阿里云OSS配置
                            if(configs.aliyun_oss) {
                                $('#aliyunOSSEnabled').prop('checked', configs.aliyun_oss.enabled || false);
                                $('#aliyunOSSEndpoint').val(configs.aliyun_oss.endpoint || '');
                                $('#aliyunOSSBucket').val(configs.aliyun_oss.bucket || '');
                                $('#aliyunOSSAccessKey').val(configs.aliyun_oss.access_key || '');
                                $('#aliyunOSSSecretKey').val(configs.aliyun_oss.secret_key || '');
                            }
                        } catch (e) {
                            showAlert('加载配置失败，请刷新页面重试', 'error');
                        }
                    },
                    error: function() {
                        showAlert('加载配置失败，请检查网络连接', 'error');
                    }
                });
            });
            
            // 保存远程备份配置
            $('#saveRemoteConfig').click(function() {
                const currentTabId = $('#remoteConfigTabs .nav-link.active').attr('aria-controls');
                let formData = null;
                
                // 根据当前激活的标签获取对应的表单数据
                switch(currentTabId) {
                    case 'ftp':
                        formData = new FormData(document.getElementById('ftpConfigForm'));
                        break;
                    case 'sftp':
                        formData = new FormData(document.getElementById('sftpConfigForm'));
                        break;
                    case 'aws-s3':
                        formData = new FormData(document.getElementById('awsS3ConfigForm'));
                        break;
                    case 'aliyun-oss':
                        formData = new FormData(document.getElementById('aliyunOSSConfigForm'));
                        break;
                }
                
                if(!formData) return;
                
                formData.append('action', 'save_remote_config');
                
                // 显示加载状态
                $('#saveRemoteConfig').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> 保存中...');
                
                $.ajax({
                    url: 'backup.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        try {
                            const result = JSON.parse(response);
                            if(result.success) {
                                showAlert('配置保存成功！', 'success');
                                setTimeout(function() {
                                    $('#remoteConfigModal').modal('hide');
                                    // 刷新远程备份状态
                                    refreshRemoteBackupStatus();
                                }, 1000);
                            } else {
                                showAlert(result.message || '保存失败，请重试', 'error');
                            }
                        } catch (e) {
                            showAlert('保存失败，请检查配置并重试', 'error');
                        }
                    },
                    error: function() {
                        showAlert('保存失败，请检查网络连接', 'error');
                    },
                    complete: function() {
                        $('#saveRemoteConfig').prop('disabled', false).html('保存配置');
                    }
                });
            });
            
            // 刷新远程备份状态
            function refreshRemoteBackupStatus() {
                $.ajax({
                    url: 'backup.php',
                    type: 'POST',
                    data: {action: 'get_remote_status'},
                    success: function(response) {
                        try {
                            const status = JSON.parse(response);
                            // 更新远程备份状态显示
                            let statusText = '未配置';
                            if(status && (status.ftp || status.sftp || status.aws_s3 || status.aliyun_oss)) {
                                const activeServices = [];
                                if(status.ftp && status.ftp.enabled) activeServices.push('FTP');
                                if(status.sftp && status.sftp.enabled) activeServices.push('SFTP');
                                if(status.aws_s3 && status.aws_s3.enabled) activeServices.push('AWS S3');
                                if(status.aliyun_oss && status.aliyun_oss.enabled) activeServices.push('阿里云OSS');
                                
                                statusText = activeServices.length > 0 ? 
                                    '已配置 (' + activeServices.join(', ') + ')' : '已配置但未启用';
                            }
                            
                            $('#remote-backup-status').text(statusText);
                        } catch (e) {
                            console.error('刷新远程状态失败', e);
                        }
                    }
                });
            }
            
            // 初始加载时检查远程备份状态
            if($('#remote-backup-status').length) {
                refreshRemoteBackupStatus();
            }
        });
    </script>
</body>
</html>