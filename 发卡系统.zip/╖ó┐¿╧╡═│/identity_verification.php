<?php
require_once 'includes/core/SecurityUtils.php';
require_once 'includes/core/Database.php';
require_once 'includes/services/AuthService.php';
require_once 'includes/services/ComplianceService.php';
require_once 'includes/services/IdentityVerificationService.php';
require_once 'config.php';

// 初始化认证服务
$authService = new AuthService();

// 检查用户登录状态
if (!$authService->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 检查数据访问权限
$db = Database::getInstance();
$complianceService = new ComplianceService($db);
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];

if (!$complianceService->checkDataAccessPermission($userId, 'read', 'identity_verification')) {
    header('HTTP/1.0 403 Forbidden');
    echo '<div class="alert alert-danger">您没有权限访问身份核验功能</div>';
    exit;
}

// 记录数据访问授权
$complianceService->recordDataAccessAuthorization($userId, 'identity_verification', 'view_verification_page', '访问身份核验页面');

// 获取当前操作
$action = $_GET['action'] ?? 'list';
$verificationId = $_GET['id'] ?? '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if ($action === 'create') {
            // 创建身份核验申请
            $verificationData = [
                'verification_type' => $_POST['verification_type'] ?? 'standard',
                'id_number' => $_POST['id_number'] ?? '',
                'id_front_image' => $_POST['id_front_image'] ?? '',
                'id_back_image' => $_POST['id_back_image'] ?? '',
                'selfie_image' => $_POST['selfie_image'] ?? '',
                'phone_number' => $_POST['phone_number'] ?? '',
                'email' => $_POST['email'] ?? '',
                'address' => $_POST['address'] ?? ''
            ];
            
            $cardId = $_POST['card_id'] ?? '';
            $verificationId = IdentityVerificationService::createVerificationRequest($userId, $cardId, $verificationData);
            
            $_SESSION['success_message'] = '身份核验申请提交成功，申请ID：' . $verificationId;
            header('Location: identity_verification.php?action=list');
            exit;
            
        } elseif ($action === 'review') {
            // 提交审核
            $reviewData = [
                'result' => $_POST['review_result'] ?? 'approved',
                'comment' => $_POST['review_comment'] ?? '',
                'data' => [
                    'review_notes' => $_POST['review_notes'] ?? '',
                    'additional_requirements' => $_POST['additional_requirements'] ?? ''
                ]
            ];
            
            $reviewLevel = $_POST['review_level'] ?? 1;
            IdentityVerificationService::submitForReview($verificationId, $reviewLevel, $userId, $reviewData);
            
            $_SESSION['success_message'] = '审核提交成功';
            header('Location: identity_verification.php?action=detail&id=' . $verificationId);
            exit;
            
        } elseif ($action === 'activate') {
            // 激活卡片
            $activationData = [
                'method' => $_POST['activation_method'] ?? 'online',
                'user_id' => $userId
            ];
            
            $cardId = $_POST['card_id'] ?? '';
            $activationCode = IdentityVerificationService::activateCard($cardId, $activationData);
            
            $_SESSION['success_message'] = '卡片激活成功，激活码：' . $activationCode;
            header('Location: identity_verification.php?action=list');
            exit;
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
}

// 获取数据
$verification = null;
$reviewHistory = [];
$pendingReviews = [];

if ($action === 'detail' && $verificationId) {
    $verification = IdentityVerificationService::getVerificationById($verificationId);
    $reviewHistory = IdentityVerificationService::getReviewHistory($verificationId);
    
    // 数据脱敏处理
    if ($verification) {
        $verification['id_number'] = $complianceService->maskSensitiveData($verification['id_number'], 'id_card');
            $verification['phone_number'] = $complianceService->maskSensitiveData($verification['phone_number'], 'phone');
            $verification['email'] = $complianceService->maskSensitiveData($verification['email'], 'email');
            $verification['address'] = $complianceService->maskSensitiveData($verification['address']);
    }
    
} elseif ($action === 'list') {
    $pendingReviews = IdentityVerificationService::getPendingReviews($userId);
    
    // 数据脱敏处理
    foreach ($pendingReviews as &$review) {
        if (isset($review['id_number'])) {
            $review['id_number'] = $complianceService->maskSensitiveData($review['id_number'], 'id_card');
        }
        if (isset($review['phone_number'])) {
            $review['phone_number'] = $complianceService->maskSensitiveData($review['phone_number'], 'phone');
        }
        if (isset($review['email'])) {
            $review['email'] = $complianceService->maskSensitiveData($review['email'], 'email');
        }
        if (isset($review['address'])) {
            $review['address'] = $complianceService->maskSensitiveData($review['address']);
        }
    }
}

// 获取统计信息
$verificationStats = IdentityVerificationService::getVerificationStats();
$activationStats = IdentityVerificationService::getActivationStats();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>身份核验管理 - 发卡系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .verification-card {
            transition: all 0.3s ease;
            border: 1px solid #e0e0e0;
        }
        .verification-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.875rem;
            padding: 0.375rem 0.75rem;
        }
        .review-timeline {
            position: relative;
            padding-left: 30px;
        }
        .review-timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e0e0e0;
        }
        .review-item {
            position: relative;
            margin-bottom: 20px;
        }
        .review-item::before {
            content: '';
            position: absolute;
            left: -25px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #007bff;
            border: 2px solid #fff;
            box-shadow: 0 0 0 2px #e0e0e0;
        }
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
        }
        .form-floating label {
            color: #6c757d;
        }
        .image-preview {
            max-width: 200px;
            max-height: 150px;
            object-fit: cover;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .security-notice {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-id-card me-2"></i>发卡系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>仪表板
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add_card.php">
                            <i class="fas fa-plus me-1"></i>添加卡片
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_card.php">
                            <i class="fas fa-search me-1"></i>查询卡片
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="identity_verification.php">
                            <i class="fas fa-user-check me-1"></i>身份核验
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="card_activation.php">
                            <i class="fas fa-key me-1"></i>卡片激活
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">
                            <i class="fas fa-list me-1"></i>系统日志
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">
                            <i class="fas fa-list-alt me-1"></i>操作日志
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compliance.php">
                            <i class="fas fa-shield-alt me-1"></i>合规管理
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>退出登录</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- 消息提示 -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($_SESSION['success_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($_SESSION['error_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- 页面标题 -->
        <div class="row mb-4">
            <div class="col-12">
                <h2><i class="fas fa-user-check me-2"></i>身份核验管理</h2>
                <p class="text-muted">管理用户身份核验申请、多级审核流程和卡片激活认证</p>
            </div>
        </div>

        <!-- 统计信息 -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <h6><i class="fas fa-clock me-2"></i>待核验</h6>
                    <h3><?php echo count(array_filter($pendingReviews, fn($r) => $r['status'] === 'pending')); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6><i class="fas fa-eye me-2"></i>审核中</h6>
                    <h3><?php echo count(array_filter($pendingReviews, fn($r) => $r['status'] === 'in_review')); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6><i class="fas fa-check me-2"></i>已通过</h6>
                    <h3><?php echo count(array_filter($verificationStats ?? [], fn($s) => $s['status'] === 'approved')); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6><i class="fas fa-times me-2"></i>已拒绝</h6>
                    <h3><?php echo count(array_filter($verificationStats ?? [], fn($s) => $s['status'] === 'rejected')); ?></h3>
                </div>
            </div>
        </div>

        <?php if ($action === 'list'): ?>
            <!-- 核验申请列表 -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5><i class="fas fa-list me-2"></i>核验申请列表</h5>
                    <a href="identity_verification.php?action=create" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>新建核验申请
                    </a>
                </div>
                <div class="card-body">
                    <?php if (empty($pendingReviews)): ?>
                        <div class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <p class="text-muted">暂无待处理的核验申请</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>申请ID</th>
                                        <th>申请人</th>
                                        <th>卡片ID</th>
                                        <th>核验类型</th>
                                        <th>状态</th>
                                        <th>申请时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pendingReviews as $review): ?>
                                        <tr>
                                            <td><code><?php echo htmlspecialchars($review['verification_id']); ?></code></td>
                                            <td><?php echo htmlspecialchars($review['applicant_name'] ?? '未知'); ?></td>
                                            <td><?php echo htmlspecialchars($review['card_id']); ?></td>
                                            <td><?php echo htmlspecialchars($review['verification_type']); ?></td>
                                            <td>
                                                <?php
                                                $statusClass = [
                                                    'pending' => 'warning',
                                                    'in_review' => 'info',
                                                    'approved' => 'success',
                                                    'rejected' => 'danger',
                                                    'need_info' => 'secondary'
                                                ];
                                                $statusText = [
                                                    'pending' => '待核验',
                                                    'in_review' => '审核中',
                                                    'approved' => '已通过',
                                                    'rejected' => '已拒绝',
                                                    'need_info' => '需补充信息'
                                                ];
                                                ?>
                                                <span class="badge bg-<?php echo $statusClass[$review['status']]; ?> status-badge">
                                                    <?php echo $statusText[$review['status']]; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($review['created_at'])); ?></td>
                                            <td>
                                                <a href="identity_verification.php?action=detail&id=<?php echo $review['verification_id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye me-1"></i>查看
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($action === 'create'): ?>
            <!-- 新建核验申请 -->
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-plus me-2"></i>新建身份核验申请</h5>
                </div>
                <div class="card-body">
                    <div class="security-notice">
                        <i class="fas fa-shield-alt me-2"></i>
                        <strong>安全提示：</strong>您提交的身份信息将被加密存储，仅用于身份核验目的。请确保提供的信息真实有效。
                    </div>

                    <form method="POST" action="identity_verification.php?action=create" id="verificationForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <select class="form-select" id="card_id" name="card_id" required>
                                        <option value="">请选择卡片</option>
                                        <?php
                                        // 获取用户卡片列表
                                        $db = Database::getInstance();
                                        $cards = $db->query("SELECT id, card_number, holder_name FROM cards WHERE created_by = ? AND status = 'pending'", [$userId]);
                                        foreach ($cards as $card):
                                        ?>
                                            <option value="<?php echo $card['id']; ?>">
                                                <?php echo htmlspecialchars($card['card_number'] . ' - ' . $card['holder_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="card_id">选择卡片</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <select class="form-select" id="verification_type" name="verification_type" required>
                                        <option value="standard">标准核验</option>
                                        <option value="enhanced">增强核验</option>
                                        <option value="premium">高级核验</option>
                                    </select>
                                    <label for="verification_type">核验类型</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="id_number" name="id_number" 
                                           placeholder="身份证号码" required maxlength="18">
                                    <label for="id_number">身份证号码</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="tel" class="form-control" id="phone_number" name="phone_number" 
                                           placeholder="手机号码" required maxlength="11">
                                    <label for="phone_number">手机号码</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="email" class="form-control" id="email" name="email" 
                                           placeholder="电子邮箱" required>
                                    <label for="email">电子邮箱</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="address" name="address" 
                                           placeholder="联系地址" required>
                                    <label for="address">联系地址</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="id_front_image" class="form-label">身份证正面照片</label>
                                    <input type="file" class="form-control" id="id_front_image" name="id_front_image" 
                                           accept="image/*" required>
                                    <img id="id_front_preview" class="image-preview mt-2" style="display: none;">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="id_back_image" class="form-label">身份证背面照片</label>
                                    <input type="file" class="form-control" id="id_back_image" name="id_back_image" 
                                           accept="image/*" required>
                                    <img id="id_back_preview" class="image-preview mt-2" style="display: none;">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="selfie_image" class="form-label">本人照片</label>
                                    <input type="file" class="form-control" id="selfie_image" name="selfie_image" 
                                           accept="image/*" required>
                                    <img id="selfie_preview" class="image-preview mt-2" style="display: none;">
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="identity_verification.php?action=list" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i>返回列表
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-1"></i>提交申请
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        <?php elseif ($action === 'detail'): ?>
            <!-- 核验详情 -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-info-circle me-2"></i>核验详情</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($verification): ?>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <strong>申请ID：</strong><br>
                                        <code><?php echo htmlspecialchars($verification['verification_id']); ?></code>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>核验类型：</strong><br>
                                        <?php echo htmlspecialchars($verification['verification_type']); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <strong>身份证号码：</strong><br>
                                        <?php echo htmlspecialchars($verification['id_number'] ?? '已脱敏'); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>手机号码：</strong><br>
                                        <?php echo htmlspecialchars($verification['phone_number'] ?? '已脱敏'); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <strong>电子邮箱：</strong><br>
                                        <?php echo htmlspecialchars($verification['email'] ?? '已脱敏'); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>联系地址：</strong><br>
                                        <?php echo htmlspecialchars($verification['address'] ?? '已脱敏'); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <strong>申请时间：</strong><br>
                                        <?php echo date('Y-m-d H:i:s', strtotime($verification['created_at'])); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>当前状态：</strong><br>
                                        <?php
                                        $statusClass = [
                                            'pending' => 'warning',
                                            'in_review' => 'info',
                                            'approved' => 'success',
                                            'rejected' => 'danger',
                                            'need_info' => 'secondary'
                                        ];
                                        $statusText = [
                                            'pending' => '待核验',
                                            'in_review' => '审核中',
                                            'approved' => '已通过',
                                            'rejected' => '已拒绝',
                                            'need_info' => '需补充信息'
                                        ];
                                        ?>
                                        <span class="badge bg-<?php echo $statusClass[$verification['status']]; ?> status-badge">
                                            <?php echo $statusText[$verification['status']]; ?>
                                        </span>
                                    </div>
                                </div>

                                <!-- 图片预览 -->
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <strong>身份证正面：</strong><br>
                                        <?php if ($verification['id_front_image']): ?>
                                            <img src="<?php echo htmlspecialchars($verification['id_front_image']); ?>" 
                                                 class="img-fluid rounded" alt="身份证正面">
                                        <?php else: ?>
                                            <span class="text-muted">未上传</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>身份证背面：</strong><br>
                                        <?php if ($verification['id_back_image']): ?>
                                            <img src="<?php echo htmlspecialchars($verification['id_back_image']); ?>" 
                                                 class="img-fluid rounded" alt="身份证背面">
                                        <?php else: ?>
                                            <span class="text-muted">未上传</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>本人照片：</strong><br>
                                        <?php if ($verification['selfie_image']): ?>
                                            <img src="<?php echo htmlspecialchars($verification['selfie_image']); ?>" 
                                                 class="img-fluid rounded" alt="本人照片">
                                        <?php else: ?>
                                            <span class="text-muted">未上传</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- 审核操作 -->
                                <?php if ($verification['status'] === 'in_review' || $verification['status'] === 'pending'): ?>
                                    <div class="card bg-light">
                                        <div class="card-header">
                                            <h6><i class="fas fa-clipboard-check me-2"></i>审核操作</h6>
                                        </div>
                                        <div class="card-body">
                                            <form method="POST" action="identity_verification.php?action=review&id=<?php echo $verificationId; ?>">
                                                <input type="hidden" name="review_level" value="1">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label">审核结果</label>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="review_result" 
                                                               id="approve" value="approved" checked>
                                                        <label class="form-check-label" for="approve">
                                                            <i class="fas fa-check text-success me-1"></i>通过
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="review_result" 
                                                               id="reject" value="rejected">
                                                        <label class="form-check-label" for="reject">
                                                            <i class="fas fa-times text-danger me-1"></i>拒绝
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="review_result" 
                                                               id="need_info" value="need_info">
                                                        <label class="form-check-label" for="need_info">
                                                            <i class="fas fa-info-circle text-warning me-1"></i>需要补充信息
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="review_comment" class="form-label">审核意见</label>
                                                    <textarea class="form-control" id="review_comment" name="review_comment" 
                                                              rows="3" placeholder="请输入审核意见..."></textarea>
                                                </div>

                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-paper-plane me-1"></i>提交审核
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- 激活操作 -->
                                <?php if ($verification['status'] === 'approved'): ?>
                                    <div class="card bg-success text-white">
                                        <div class="card-header">
                                            <h6><i class="fas fa-key me-2"></i>卡片激活</h6>
                                        </div>
                                        <div class="card-body">
                                            <form method="POST" action="identity_verification.php?action=activate">
                                                <input type="hidden" name="card_id" value="<?php echo $verification['card_id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label for="activation_method" class="form-label">激活方式</label>
                                                    <select class="form-select" id="activation_method" name="activation_method">
                                                        <option value="online">在线激活</option>
                                                        <option value="offline">线下激活</option>
                                                        <option value="phone">电话激活</option>
                                                    </select>
                                                </div>

                                                <button type="submit" class="btn btn-light">
                                                    <i class="fas fa-unlock me-1"></i>激活卡片
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    未找到核验申请信息
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- 审核历史 -->
                    <div class="card">
                        <div class="card-header">
                            <h6><i class="fas fa-history me-2"></i>审核历史</h6>
                        </div>
                        <div class="card-body">
                            <?php if (empty($reviewHistory)): ?>
                                <p class="text-muted">暂无审核记录</p>
                            <?php else: ?>
                                <div class="review-timeline">
                                    <?php foreach ($reviewHistory as $review): ?>
                                        <div class="review-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <strong><?php echo htmlspecialchars($review['reviewer_name']); ?></strong>
                                                    <small class="text-muted d-block">
                                                        <?php echo date('Y-m-d H:i', strtotime($review['created_at'])); ?>
                                                    </small>
                                                </div>
                                                <span class="badge bg-<?php echo $review['review_result'] === 'approved' ? 'success' : 'danger'; ?>">
                                                    <?php echo $review['review_result'] === 'approved' ? '通过' : '拒绝'; ?>
                                                </span>
                                            </div>
                                            <?php if ($review['review_comment']): ?>
                                                <p class="mt-2 mb-0"><?php echo htmlspecialchars($review['review_comment']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 图片预览
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                const previewId = this.id.replace('_image', '_preview');
                const preview = document.getElementById(previewId);
                
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                } else {
                    preview.style.display = 'none';
                }
            });
        });

        // 表单验证
        document.getElementById('verificationForm')?.addEventListener('submit', function(e) {
            const idNumber = document.getElementById('id_number').value;
            const phoneNumber = document.getElementById('phone_number').value;
            
            // 身份证号码验证
            if (!/^\d{17}[\dXx]$/.test(idNumber)) {
                e.preventDefault();
                alert('请输入有效的身份证号码');
                return false;
            }
            
            // 手机号码验证
            if (!/^1[3-9]\d{9}$/.test(phoneNumber)) {
                e.preventDefault();
                alert('请输入有效的手机号码');
                return false;
            }
        });

        // 自动保存草稿
        let autoSaveTimer;
        document.querySelectorAll('input, textarea, select').forEach(element => {
            element.addEventListener('input', function() {
                clearTimeout(autoSaveTimer);
                autoSaveTimer = setTimeout(() => {
                    // 这里可以实现自动保存草稿功能
                    console.log('自动保存草稿...');
                }, 5000);
            });
        });
    </script>
</body>
</html>