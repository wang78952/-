<?php
/**
 * 发卡系统配置文件
 * 核心配置和常量定义
 * 
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

// 系统配置
define('APP_NAME', '发卡系统');         // 应用名称
define('APP_VERSION', '1.0.0');        // 应用版本
define('DEBUG_MODE', false);            // 调试模式（生产环境应设为false）
define('APP_ENV', 'production');        // 应用环境（development, testing, production）
define('CONFIG_CACHE_ENABLED', true);   // 配置缓存是否启用

// 数据库连接配置（为兼容性保留的常量，实际配置在config/database.php中）
define('DB_HOST', 'localhost');        // 数据库主机地址
define('DB_USER', 'root');             // 数据库用户名
define('DB_PASS', '');                 // 数据库密码
define('DB_NAME', 'card_system');      // 数据库名称
define('DB_CHARSET', 'utf8mb4');       // 字符集

// 全局数据库连接函数
function getDB() {
    // 从core目录加载Database类
    require_once __DIR__ . '/includes/core/Database.php';
    return Database::getInstance();
}

// 初始化插件管理器
function initializePluginManager() {
    static $pluginManager = null;
    
    if ($pluginManager === null) {
        try {
            // 引入插件管理器
            require_once __DIR__ . '/includes/PluginManager.php';
            
            // 创建插件管理器实例（确保传入正确的参数）
            $pluginManager = PluginManager::getInstance();
            
            // 检查initialize方法是否存在
            if (method_exists($pluginManager, 'initialize')) {
                $pluginManager->initialize();
                
                if (DEBUG_MODE) {
                    error_log("插件管理器初始化成功");
                }
            } else {
                if (DEBUG_MODE) {
                    error_log("插件管理器没有initialize方法");
                }
                // 即使没有initialize方法，仍然返回实例
            }
            
        } catch (Exception $e) {
            if (DEBUG_MODE) {
                error_log("插件管理器初始化失败：" . $e->getMessage());
            }
            // 插件管理器失败不影响系统运行
            $pluginManager = false;
        }
    }
    
    return $pluginManager;
}

// 获取插件管理器实例
function getPluginManager() {
    return initializePluginManager();
}

// 触发钩子函数
function triggerHook($hookName, $data = null, $getAllResults = false) {
    $pluginManager = getPluginManager();
    
    if ($pluginManager && $pluginManager !== false) {
        // 检查executeHook方法是否存在
        if (method_exists($pluginManager, 'executeHook')) {
            return $pluginManager->executeHook($hookName, $data);
        } else {
            if (DEBUG_MODE) {
                error_log("插件管理器没有executeHook方法");
            }
        }
    }
    
    return $getAllResults ? array() : $data;
}

// 测试数据库连接（可选）
function testConnection() {
    try {
        $db = getDB();
        $result = $db->query("SELECT 1 as test");
        $row = $result->fetch();
        
        if ($row && $row['test'] == 1) {
            return true;
        }
        return false;
    } catch (Exception $e) {
        return false;
    }
}
?>