<?php
/**
 * 系统安装向导
 */

// 检查是否已经安装
if (file_exists('config.php') && defined('APP_INSTALLED')) {
    header('Location: index.php');
    exit;
}

// 错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 安装步骤
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$step = max(1, min(5, $step));

// 保存安装进度
session_start();

// 处理表单提交
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($step) {
        case 1: // 环境检查
            if (isset($_POST['continue'])) {
                header('Location: install.php?step=2');
                exit;
            }
            break;
            
        case 2: // 数据库配置
            try {
                $db_host = trim($_POST['db_host']);
                $db_name = trim($_POST['db_name']);
                $db_user = trim($_POST['db_user']);
                $db_pass = trim($_POST['db_pass']);
                $db_port = (int)($_POST['db_port'] ?? 3306);
                
                if (empty($db_host) || empty($db_name) || empty($db_user)) {
                    throw new Exception('数据库配置不能为空');
                }
                
                // 测试数据库连接
                try {
                    $pdo = new PDO("mysql:host=$db_host;port=$db_port;charset=utf8mb4", $db_user, $db_pass);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    
                    // 检查数据库是否存在，不存在则创建
                    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                    
                    // 保存配置到会话
                    $_SESSION['install_config'] = [
                        'db_host' => $db_host,
                        'db_name' => $db_name,
                        'db_user' => $db_user,
                        'db_pass' => $db_pass,
                        'db_port' => $db_port
                    ];
                    
                    header('Location: install.php?step=3');
                    exit;
                    
                } catch (PDOException $e) {
                    throw new Exception('数据库连接失败: ' . $e->getMessage());
                }
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 3: // 管理员账户设置
            try {
                $admin_username = trim($_POST['admin_username']);
                $admin_password = trim($_POST['admin_password']);
                $admin_email = trim($_POST['admin_email']);
                
                if (empty($admin_username) || empty($admin_password) || empty($admin_email)) {
                    throw new Exception('管理员信息不能为空');
                }
                
                if (strlen($admin_password) < 6) {
                    throw new Exception('密码长度至少6位');
                }
                
                if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('邮箱格式不正确');
                }
                
                // 保存管理员信息到会话
                $_SESSION['install_config']['admin_username'] = $admin_username;
                $_SESSION['install_config']['admin_password'] = password_hash($admin_password, PASSWORD_DEFAULT);
                $_SESSION['install_config']['admin_email'] = $admin_email;
                
                header('Location: install.php?step=4');
                exit;
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 4: // 系统配置
            try {
                $app_name = trim($_POST['app_name']);
                $app_url = trim($_POST['app_url']);
                $timezone = $_POST['timezone'];
                
                if (empty($app_name) || empty($app_url)) {
                    throw new Exception('系统配置不能为空');
                }
                
                // 保存系统配置到会话
                $_SESSION['install_config']['app_name'] = $app_name;
                $_SESSION['install_config']['app_url'] = $app_url;
                $_SESSION['install_config']['timezone'] = $timezone;
                
                header('Location: install.php?step=5');
                exit;
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 5: // 执行安装
            try {
                if (!isset($_SESSION['install_config'])) {
                    throw new Exception('安装配置丢失，请重新开始安装');
                }
                
                $config = $_SESSION['install_config'];
                
                // 创建配置文件
                $configContent = "<?php\n";
                $configContent .= "// 系统配置文件\n";
                $configContent .= "define('APP_NAME', '" . addslashes($config['app_name']) . "');\n";
                $configContent .= "define('APP_URL', '" . addslashes($config['app_url']) . "');\n";
                $configContent .= "define('APP_VERSION', '1.0.0');\n";
                $configContent .= "define('DEBUG_MODE', false);\n";
                $configContent .= "define('APP_INSTALLED', true);\n";
                $configContent .= "\n";
                $configContent .= "// 数据库配置\n";
                $configContent .= "define('DB_HOST', '" . addslashes($config['db_host']) . "');\n";
                $configContent .= "define('DB_NAME', '" . addslashes($config['db_name']) . "');\n";
                $configContent .= "define('DB_USER', '" . addslashes($config['db_user']) . "');\n";
                $configContent .= "define('DB_PASS', '" . addslashes($config['db_pass']) . "');\n";
                $configContent .= "define('DB_PORT', " . $config['db_port'] . ");\n";
                $configContent .= "define('DB_CHARSET', 'utf8mb4');\n";
                $configContent .= "\n";
                $configContent .= "// 时区设置\n";
                $configContent .= "date_default_timezone_set('" . addslashes($config['timezone']) . "');\n";
                $configContent .= "\n";
                $configContent .= "// 安全配置\n";
                $configContent .= "define('ENCRYPTION_KEY', '" . bin2hex(random_bytes(32)) . "');\n";
                $configContent .= "define('JWT_SECRET', '" . bin2hex(random_bytes(32)) . "');\n";
                $configContent .= "define('SESSION_LIFETIME', 7200);\n";
                $configContent .= "\n";
                $configContent .= "// 文件上传配置\n";
                $configContent .= "define('UPLOAD_MAX_SIZE', 5242880);\n";
                $configContent .= "define('UPLOAD_ALLOWED_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);\n";
                
                if (file_put_contents('config.php', $configContent) === false) {
                    throw new Exception('无法创建配置文件，请检查目录权限');
                }
                
                // 导入数据库结构
                require_once 'config.php';
                require_once 'includes/Database.php';
                
                $db = Database::getInstance();
                
                // 读取并执行SQL文件
                $sqlFile = 'database/init.sql';
                if (file_exists($sqlFile)) {
                    $sql = file_get_contents($sqlFile);
                    $statements = array_filter(array_map('trim', explode(';', $sql)));
                    
                    foreach ($statements as $statement) {
                        if (!empty($statement)) {
                            $db->query($statement);
                        }
                    }
                }
                
                // 创建管理员账户
                $db->query("INSERT INTO users (username, password, email, role, status, created_at) VALUES (?, ?, ?, 'admin', 'active', NOW())",
                    [$config['admin_username'], $config['admin_password'], $config['admin_email']]);
                
                // 清理安装会话
                unset($_SESSION['install_config']);
                
                $message = '安装成功！系统已准备就绪。';
                
                // 重定向到登录页面
                header('refresh:3;url=login.php');
                
            } catch (Exception $e) {
                $error = '安装失败: ' . $e->getMessage();
            }
            break;
    }
}

// 环境检查函数
function checkEnvironment() {
    $checks = [];
    
    // PHP版本
    $phpVersion = PHP_VERSION;
    $checks['php_version'] = [
        'name' => 'PHP版本',
        'current' => $phpVersion,
        'required' => '>= 7.4.0',
        'status' => version_compare($phpVersion, '7.4.0', '>=')
    ];
    
    // 必需扩展
    $requiredExtensions = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'openssl', 'curl'];
    foreach ($requiredExtensions as $ext) {
        $checks['extension_' . $ext] = [
            'name' => 'PHP扩展: ' . $ext,
            'current' => extension_loaded($ext) ? '已安装' : '未安装',
            'required' => '已安装',
            'status' => extension_loaded($ext)
        ];
    }
    
    // 目录权限
    $writableDirs = ['config.php', 'uploads', 'logs'];
    foreach ($writableDirs as $dir) {
        $isWritable = is_writable($dir) || (!file_exists($dir) && is_writable(dirname($dir)));
        $checks['writable_' . $dir] = [
            'name' => '目录权限: ' . $dir,
            'current' => $isWritable ? '可写' : '不可写',
            'required' => '可写',
            'status' => $isWritable
        ];
    }
    
    return $checks;
}

// 获取时区列表
function getTimezoneList() {
    $regions = [
        'Africa' => DateTimeZone::AFRICA,
        'America' => DateTimeZone::AMERICA,
        'Antarctica' => DateTimeZone::ANTARCTICA,
        'Asia' => DateTimeZone::ASIA,
        'Atlantic' => DateTimeZone::ATLANTIC,
        'Europe' => DateTimeZone::EUROPE,
        'Indian' => DateTimeZone::INDIAN,
        'Pacific' => DateTimeZone::PACIFIC
    ];
    
    $timezones = [];
    foreach ($regions as $name => $region) {
        $timezones[$name] = DateTimeZone::listIdentifiers($region);
    }
    
    return $timezones;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装向导 - 发卡系统</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .install-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 800px;
            width: 90%;
            margin: 20px;
            overflow: hidden;
        }
        
        .install-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .install-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .install-header p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .install-steps {
            display: flex;
            background: #f8f9fa;
            padding: 0;
            list-style: none;
        }
        
        .install-step {
            flex: 1;
            text-align: center;
            padding: 20px 10px;
            position: relative;
            color: #666;
            font-size: 14px;
        }
        
        .install-step::after {
            content: '';
            position: absolute;
            top: 50%;
            right: -1px;
            width: 1px;
            height: 30px;
            background: #ddd;
            transform: translateY(-50%);
        }
        
        .install-step:last-child::after {
            display: none;
        }
        
        .install-step.active {
            background: white;
            color: #667eea;
            font-weight: 600;
        }
        
        .install-step.completed {
            color: #27ae60;
        }
        
        .install-content {
            padding: 40px;
        }
        
        .step-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }
        
        .step-description {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .environment-checks {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .check-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        
        .check-item:last-child {
            border-bottom: none;
        }
        
        .check-name {
            font-weight: 500;
            color: #333;
        }
        
        .check-status {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .status-icon {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
            color: white;
        }
        
        .status-icon.success {
            background: #27ae60;
        }
        
        .status-icon.error {
            background: #e74c3c;
        }
        
        .status-text {
            font-size: 14px;
            color: #666;
        }
        
        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d5f4e6;
            color: #27ae60;
            border: 1px solid #27ae60;
        }
        
        .alert-error {
            background: #fadbd8;
            color: #e74c3c;
            border: 1px solid #e74c3c;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 30px;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .progress-bar {
            background: #e9ecef;
            border-radius: 10px;
            height: 8px;
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .progress-fill {
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            height: 100%;
            border-radius: 10px;
            transition: width 0.3s ease;
        }
        
        .feature-list {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .feature-icon {
            color: #27ae60;
            font-size: 16px;
        }
        
        @media (max-width: 768px) {
            .install-steps {
                flex-direction: column;
            }
            
            .install-step::after {
                display: none;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .install-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="install-header">
            <h1>发卡系统安装向导</h1>
            <p>欢迎使用发卡系统，让我们开始安装吧！</p>
        </div>
        
        <ul class="install-steps">
            <li class="install-step <?php echo $step >= 1 ? ($step > 1 ? 'completed' : 'active') : ''; ?>">
                1. 环境检查
            </li>
            <li class="install-step <?php echo $step >= 2 ? ($step > 2 ? 'completed' : 'active') : ''; ?>">
                2. 数据库配置
            </li>
            <li class="install-step <?php echo $step >= 3 ? ($step > 3 ? 'completed' : 'active') : ''; ?>">
                3. 管理员账户
            </li>
            <li class="install-step <?php echo $step >= 4 ? ($step > 4 ? 'completed' : 'active') : ''; ?>">
                4. 系统配置
            </li>
            <li class="install-step <?php echo $step >= 5 ? 'active' : ''; ?>">
                5. 完成安装
            </li>
        </ul>
        
        <div class="install-content">
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo ($step / 5) * 100; ?>%;"></div>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php switch ($step): case 1: ?>
                <h2 class="step-title">环境检查</h2>
                <p class="step-description">
                    系统正在检查您的服务器环境是否满足安装要求。请确保所有检查项都通过后再继续。
                </p>
                
                <div class="environment-checks">
                    <?php $checks = checkEnvironment(); ?>
                    <?php foreach ($checks as $check): ?>
                        <div class="check-item">
                            <div class="check-name"><?php echo htmlspecialchars($check['name']); ?></div>
                            <div class="check-status">
                                <div class="status-icon <?php echo $check['status'] ? 'success' : 'error'; ?>">
                                    <?php echo $check['status'] ? '✓' : '✗'; ?>
                                </div>
                                <div class="status-text">
                                    <?php echo htmlspecialchars($check['current']); ?>
                                    <small>(<?php echo htmlspecialchars($check['required']); ?>)</small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="feature-list">
                    <h3 style="margin-bottom: 15px; color: #333;">系统特性</h3>
                    <div class="feature-item">
                        <span class="feature-icon">✓</span>
                        <span>用户管理与权限控制</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">✓</span>
                        <span>卡片管理与批量操作</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">✓</span>
                        <span>订单管理与状态跟踪</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">✓</span>
                        <span>数据加密与安全保护</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">✓</span>
                        <span>操作日志与审计追踪</span>
                    </div>
                </div>
                
                <form method="POST">
                    <div class="form-actions">
                        <button type="submit" name="continue" class="btn btn-primary">继续安装</button>
                    </div>
                </form>
                
            <?php break; case 2: ?>
                <h2 class="step-title">数据库配置</h2>
                <p class="step-description">
                    请填写数据库连接信息。系统将自动创建所需的数据库表结构。
                </p>
                
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label>数据库主机</label>
                            <input type="text" name="db_host" value="localhost" required>
                        </div>
                        <div class="form-group">
                            <label>数据库端口</label>
                            <input type="number" name="db_port" value="3306" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>数据库名称</label>
                        <input type="text" name="db_name" placeholder="card_system" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>数据库用户名</label>
                            <input type="text" name="db_user" required>
                        </div>
                        <div class="form-group">
                            <label>数据库密码</label>
                            <input type="password" name="db_pass">
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <a href="install.php?step=1" class="btn btn-secondary">上一步</a>
                        <button type="submit" class="btn btn-primary">下一步</button>
                    </div>
                </form>
                
            <?php break; case 3: ?>
                <h2 class="step-title">管理员账户设置</h2>
                <p class="step-description">
                    请创建系统管理员账户。该账户将拥有系统的所有管理权限。
                </p>
                
                <form method="POST">
                    <div class="form-group">
                        <label>管理员用户名</label>
                        <input type="text" name="admin_username" placeholder="admin" required>
                    </div>
                    
                    <div class="form-group">
                        <label>管理员密码</label>
                        <input type="password" name="admin_password" placeholder="至少6位字符" required>
                    </div>
                    
                    <div class="form-group">
                        <label>管理员邮箱</label>
                        <input type="email" name="admin_email" placeholder="admin@example.com" required>
                    </div>
                    
                    <div class="form-actions">
                        <a href="install.php?step=2" class="btn btn-secondary">上一步</a>
                        <button type="submit" class="btn btn-primary">下一步</button>
                    </div>
                </form>
                
            <?php break; case 4: ?>
                <h2 class="step-title">系统配置</h2>
                <p class="step-description">
                    请配置系统基本信息。这些配置可以在安装后通过系统设置进行修改。
                </p>
                
                <form method="POST">
                    <div class="form-group">
                        <label>系统名称</label>
                        <input type="text" name="app_name" placeholder="发卡系统" value="发卡系统" required>
                    </div>
                    
                    <div class="form-group">
                        <label>系统URL</label>
                        <input type="url" name="app_url" placeholder="http://localhost/card-system" required>
                    </div>
                    
                    <div class="form-group">
                        <label>时区设置</label>
                        <select name="timezone" required>
                            <?php $timezones = getTimezoneList(); ?>
                            <?php foreach ($timezones as $region => $zones): ?>
                                <optgroup label="<?php echo htmlspecialchars($region); ?>">
                                    <?php foreach ($zones as $timezone): ?>
                                        <option value="<?php echo htmlspecialchars($timezone); ?>" <?php echo $timezone === 'Asia/Shanghai' ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($timezone); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <a href="install.php?step=3" class="btn btn-secondary">上一步</a>
                        <button type="submit" class="btn btn-primary">开始安装</button>
                    </div>
                </form>
                
            <?php break; case 5: ?>
                <h2 class="step-title">完成安装</h2>
                <p class="step-description">
                    系统正在执行最后的安装步骤，请稍候...
                </p>
                
                <form method="POST">
                    <div class="form-actions">
                        <a href="install.php?step=4" class="btn btn-secondary">上一步</a>
                        <button type="submit" class="btn btn-primary">完成安装</button>
                    </div>
                </form>
                
            <?php endswitch; ?>
        </div>
    </div>
    
    <script>
        // 自动设置系统URL
        if (document.querySelector('input[name="app_url"]')) {
            const urlInput = document.querySelector('input[name="app_url"]');
            if (!urlInput.value) {
                urlInput.value = window.location.origin + window.location.pathname.replace('/install.php', '');
            }
        }
        
        // 表单验证
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const requiredFields = form.querySelectorAll('[required]');
                let valid = true;
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        valid = false;
                        field.style.borderColor = '#e74c3c';
                    } else {
                        field.style.borderColor = '#ddd';
                    }
                });
                
                if (!valid) {
                    e.preventDefault();
                    alert('请填写所有必填字段');
                }
            });
        });
    </script>
</body>
</html>