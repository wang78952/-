# 发卡系统多语言支持指南

## 概述

基于 `ux-enhancer.js` 添加的多语言切换功能，支持通过 JSON 文件存储中英文文案，实现动态语言切换。本指南详细介绍了如何管理和扩展系统的多语言支持。

## 功能特性

### 1. 语言文件管理
- 语言文件存储位置：`assets/lang/` 目录
- 支持的语言：
  - 中文：`zh-CN.json`
  - 英文：`en-US.json`
- 可扩展支持更多语言
- 语言文件采用标准JSON格式，支持嵌套结构

### 2. 核心功能
- **动态加载**：异步加载语言文件，无需刷新页面
- **本地存储**：自动保存用户语言偏好到 localStorage
- **参数化文本**：支持带参数的翻译文本
- **降级处理**：语言文件加载失败时自动降级到默认语言
- **事件驱动**：语言切换时触发自定义事件
- **前后端一致**：支持前后端共享语言文件结构

### 3. 使用方式

#### 3.1 HTML 标记方式

**文本翻译：**
```html
<h1 data-i18n="title">多语言演示</h1>
<p data-i18n="welcome.description">这是一个演示页面</p>
```

**表单占位符：**
```html
<input type="text" data-i18n-placeholder="form.namePlaceholder">
```

**标题属性：**
```html
<button data-i18n-title="buttons.saveTitle">保存</button>
```

#### 3.2 JavaScript API 方式

**获取翻译文本：**
```javascript
// 全局函数
const text = t('common.save'); // 返回 "保存" 或 "Save"

// 实例方法
const text = uxEnhancer.t('common.save');
```

**参数化文本：**
```javascript
const text = t('demo.params.welcome', { 
    name: '张三', 
    count: 100 
});
// 返回："欢迎 张三，您是第 100 位访客"
```

**切换语言：**
```javascript
// 全局函数
switchLanguage('en-US');

// 实例方法
uxEnhancer.switchLanguage('en-US');
```

**获取当前语言：**
```javascript
const currentLang = getCurrentLanguage(); // 返回 'zh-CN' 或 'en-US'
```

#### 3.3 语言切换控件

**下拉选择器：**
```html
<select data-language-select>
    <option value="zh-CN">中文</option>
    <option value="en-US">English</option>
</select>
```

**切换按钮：**
```html
<button data-language-toggle>
    <span>English</span>
</button>
```

### 4. 语言文件格式

JSON 文件采用嵌套结构，支持点号分隔的键名：

```json
{
  "common": {
    "save": "保存",
    "cancel": "取消"
  },
  "demo": {
    "params": {
      "welcome": "欢迎 {name}，您是第 {count} 位访客"
    }
  }
}
```

### 5. 事件监听

监听语言切换事件：
```javascript
document.addEventListener('languageChanged', function(event) {
    console.log('Language changed to:', event.detail.language);
    // 执行语言切换后的自定义逻辑
});
```

## 集成步骤

### 1. 引入文件
```html
<script src="./assets/js/ux-enhancer.js"></script>
```

### 2. 添加语言标记
在 HTML 元素上添加相应的 `data-i18n-*` 属性。

### 3. 创建语言文件
在 `assets/lang/` 目录下创建对应语言的 JSON 文件。

### 4. 初始化
UXEnhancer 会自动初始化多语言功能，无需额外配置。

## API 参考

### UXEnhancer 类方法

#### `loadTranslations(language)`
异步加载指定语言文件。

#### `t(key, params = {})`
获取翻译文本，支持参数替换。

#### `switchLanguage(language)`
切换到指定语言。

#### `applyTranslations()`
应用翻译到页面所有标记的元素。

#### `getCurrentLanguage()`
获取当前语言代码。

#### `getSupportedLanguages()`
获取支持的语言列表。

### 全局函数

#### `t(key, params = {})`
获取翻译文本的快捷函数。

#### `switchLanguage(language)`
切换语言的快捷函数。

#### `getCurrentLanguage()`
获取当前语言的快捷函数。

## 最佳实践

### 1. 键名命名规范
- 使用点号分隔的层级结构
- 采用有意义的英文键名
- 保持键名的一致性

### 2. 参数化文本
- 对于包含变量的文本使用参数化
- 参数名使用驼峰命名法
- 提供默认值处理

### 3. 性能优化
- 语言文件按需加载
- 避免频繁的语言切换
- 合理组织翻译键的结构

### 4. 错误处理
- 提供降级机制
- 记录加载失败的日志
- 友好的用户提示

## 演示页面

访问 `multilingual-demo.html` 查看完整的功能演示，包括：
- 表单翻译
- 按钮翻译
- 消息翻译
- 参数化文本
- 语言切换控件

## 扩展开发

### 添加新语言

1. 在 `assets/lang/` 目录下创建新的语言文件，如 `ja-JP.json`
2. 在 `getSupportedLanguages()` 方法中添加语言信息
3. 在 HTML 中添加对应的语言选项

### 自定义加载逻辑

可以重写 `loadTranslations()` 方法来实现自定义的加载逻辑，如：
- 从 CDN 加载
- 压缩优化
- 缓存策略

### 插件集成

多语言功能可以与现有插件系统集成，为插件提供国际化支持。