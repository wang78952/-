<?php
/**
 * 会员服务类
 * 实现会员等级管理、积分管理等功能
 */
class MemberService {
    private $db;
    private $logger;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     */
    public function __construct($db) {
        $this->db = $db;
        $this->logger = new Logger('member');
    }
    
    /**
     * 获取用户会员信息
     * @param int $userId 用户ID
     * @return array 用户会员信息
     */
    public function getUserMemberInfo($userId) {
        $sql = "SELECT * FROM user_members WHERE user_id = ?";
        $result = $this->db->query($sql, [$userId]);
        
        if (empty($result)) {
            // 如果用户没有会员信息，自动创建
            $this->createUserMember($userId);
            return $this->getUserMemberInfo($userId);
        }
        
        return $result[0];
    }
    
    /**
     * 创建用户会员信息
     * @param int $userId 用户ID
     * @return bool 是否成功
     */
    private function createUserMember($userId) {
        $sql = "INSERT INTO user_members (user_id, member_level_id, current_points, total_points, member_since) VALUES (?, 1, 0, 0, NOW())";
        return $this->db->execute($sql, [$userId]);
    }
    
    /**
     * 更新用户积分
     * @param int $userId 用户ID
     * @param int $points 积分变动数量（正数增加，负数减少）
     * @param string $type 积分类型
     * @param string $sourceId 来源ID
     * @param string $description 描述
     * @return bool 是否成功
     */
    public function updateUserPoints($userId, $points, $type = 'manual', $sourceId = null, $description = '') {
        if ($points == 0) {
            return true;
        }
        
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 获取当前会员信息
            $memberInfo = $this->getUserMemberInfo($userId);
            $currentPoints = $memberInfo['current_points'];
            $totalPoints = $memberInfo['total_points'];
            
            // 计算新积分
            $newPoints = $currentPoints + $points;
            $newTotalPoints = $totalPoints + $points;
            
            if ($newPoints < 0) {
                throw new Exception('积分不足');
            }
            
            // 更新会员信息
            $sql = "UPDATE user_members SET current_points = ?, total_points = ? WHERE user_id = ?";
            $this->db->execute($sql, [$newPoints, $newTotalPoints, $userId]);
            
            // 记录积分变动
            $sql = "INSERT INTO point_transactions (user_id, type, change_points, balance_points, source_id, description, expire_date) 
                    VALUES (?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 1 YEAR))";
            $this->db->execute($sql, [$userId, $type, $points, $newPoints, $sourceId, $description]);
            
            // 检查并更新会员等级
            $this->checkAndUpdateMemberLevel($userId, $newPoints);
            
            // 提交事务
            $this->db->commit();
            
            $this->logger->info("用户积分更新成功", [
                'user_id' => $userId,
                'points' => $points,
                'type' => $type,
                'source_id' => $sourceId
            ]);
            
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            $this->logger->error("用户积分更新失败: " . $e->getMessage(), ['user_id' => $userId]);
            return false;
        }
    }
    
    /**
     * 检查并更新会员等级
     * @param int $userId 用户ID
     * @param int $points 当前积分
     * @return bool 是否成功
     */
    private function checkAndUpdateMemberLevel($userId, $points) {
        // 获取积分对应的会员等级
        $sql = "SELECT id, level FROM member_levels WHERE min_points <= ? AND status = 'active' ORDER BY level DESC LIMIT 1";
        $levelInfo = $this->db->query($sql, [$points]);
        
        if (empty($levelInfo)) {
            return false;
        }
        
        $newLevelId = $levelInfo[0]['id'];
        
        // 获取用户当前等级
        $memberInfo = $this->getUserMemberInfo($userId);
        
        if ($newLevelId != $memberInfo['member_level_id']) {
            // 更新会员等级
            $sql = "UPDATE user_members SET member_level_id = ?, last_level_change = NOW() WHERE user_id = ?";
            $result = $this->db->execute($sql, [$newLevelId, $userId]);
            
            if ($result) {
                $this->logger->info("用户会员等级更新", [
                    'user_id' => $userId,
                    'old_level' => $memberInfo['member_level_id'],
                    'new_level' => $newLevelId
                ]);
            }
            
            return $result;
        }
        
        return true;
    }
    
    /**
     * 获取用户可用优惠券列表
     * @param int $userId 用户ID
     * @return array 优惠券列表
     */
    public function getUserAvailableCoupons($userId) {
        $sql = "SELECT uc.*, ct.name as coupon_name, ct.type as coupon_type, ct.value as coupon_value, ct.min_amount 
                FROM user_coupons uc 
                JOIN coupon_types ct ON uc.coupon_type_id = ct.id 
                WHERE uc.user_id = ? AND uc.status = 'unused' AND uc.expire_date > NOW()";
        
        return $this->db->query($sql, [$userId]);
    }
    
    /**
     * 验证优惠券是否可用
     * @param int $userId 用户ID
     * @param string $couponCode 优惠券码
     * @param decimal $orderAmount 订单金额
     * @param int $productId 产品ID
     * @return array|false 优惠券信息或false
     */
    public function validateCoupon($userId, $couponCode, $orderAmount, $productId = null) {
        $sql = "SELECT uc.*, ct.type as coupon_type, ct.value as coupon_value, ct.min_amount, ct.product_scope, ct.product_data 
                FROM user_coupons uc 
                JOIN coupon_types ct ON uc.coupon_type_id = ct.id 
                WHERE uc.user_id = ? AND uc.coupon_code = ? AND uc.status = 'unused' AND uc.expire_date > NOW()";
        
        $coupon = $this->db->query($sql, [$userId, $couponCode]);
        
        if (empty($coupon)) {
            return false;
        }
        
        $coupon = $coupon[0];
        
        // 检查最低消费金额
        if ($orderAmount < $coupon['min_amount']) {
            return false;
        }
        
        // 检查产品适用性
        if (!empty($productId) && $coupon['product_scope'] != 'all') {
            $productData = json_decode($coupon['product_data'], true);
            if ($coupon['product_scope'] == 'category' && !in_array($this->getProductCategory($productId), $productData)) {
                return false;
            } elseif ($coupon['product_scope'] == 'specific' && !in_array($productId, $productData)) {
                return false;
            }
        }
        
        return $coupon;
    }
    
    /**
     * 使用优惠券
     * @param int $couponId 优惠券ID
     * @param int $orderId 订单ID
     * @return bool 是否成功
     */
    public function useCoupon($couponId, $orderId) {
        $sql = "UPDATE user_coupons SET status = 'used', used_date = NOW(), order_id = ? WHERE id = ? AND status = 'unused'";
        return $this->db->execute($sql, [$orderId, $couponId]);
    }
    
    /**
     * 获取产品分类ID
     * @param int $productId 产品ID
     * @return int 分类ID
     */
    private function getProductCategory($productId) {
        $sql = "SELECT category_id FROM products WHERE id = ?";
        $result = $this->db->query($sql, [$productId]);
        return $result[0]['category_id'] ?? 0;
    }
    
    /**
     * 处理订单积分（下单赠送积分）
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param float $orderAmount 订单金额
     * @return bool 是否成功
     */
    public function processOrderPoints($userId, $orderId, $orderAmount) {
        // 按照1:10的比例赠送积分（1元=10积分）
        $points = (int)($orderAmount * 10);
        
        return $this->updateUserPoints(
            $userId, 
            $points, 
            'order', 
            $orderId, 
            "订单号{$orderId}赠送积分"
        );
    }
    
    /**
     * 处理订单退款积分
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param float $refundAmount 退款金额
     * @return bool 是否成功
     */
    public function processRefundPoints($userId, $orderId, $refundAmount) {
        // 扣除相应积分
        $points = -1 * (int)($refundAmount * 10);
        
        return $this->updateUserPoints(
            $userId, 
            $points, 
            'refund', 
            $orderId, 
            "订单号{$orderId}退款扣除积分"
        );
    }
    
    /**
     * 积分兑换优惠券
     * @param int $userId 用户ID
     * @param int $couponTypeId 优惠券类型ID
     * @return array 结果数组
     */
    public function exchangePointsForCoupon($userId, $couponTypeId) {
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 获取优惠券类型信息
            $sql = "SELECT * FROM coupon_types WHERE id = ? AND status = 'active'";
            $couponType = $this->db->query($sql, [$couponTypeId]);
            
            if (empty($couponType)) {
                throw new Exception('优惠券类型不存在');
            }
            
            $couponType = $couponType[0];
            
            // 计算所需积分（根据优惠券价值）
            $requiredPoints = (int)($couponType['value'] * 20); // 1元优惠券需要20积分
            
            // 检查积分是否足够
            $memberInfo = $this->getUserMemberInfo($userId);
            if ($memberInfo['current_points'] < $requiredPoints) {
                throw new Exception('积分不足');
            }
            
            // 扣除积分
            $this->updateUserPoints(
                $userId, 
                -$requiredPoints, 
                'exchange', 
                $couponTypeId, 
                "积分兑换优惠券: {$couponType['name']}"
            );
            
            // 生成优惠券
            $couponCode = $this->generateCouponCode();
            $expireDate = date('Y-m-d H:i:s', strtotime("+{$couponType['valid_days']} days"));
            
            $sql = "INSERT INTO user_coupons (user_id, coupon_type_id, coupon_code, status, issue_date, expire_date) VALUES (?, ?, ?, 'unused', NOW(), ?)";
            $couponId = $this->db->execute($sql, [$userId, $couponTypeId, $couponCode, $expireDate], true);
            
            // 提交事务
            $this->db->commit();
            
            return [
                'success' => true,
                'coupon_id' => $couponId,
                'coupon_code' => $couponCode,
                'coupon_name' => $couponType['name'],
                'expire_date' => $expireDate
            ];
            
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 生成优惠券码
     * @return string 优惠券码
     */
    private function generateCouponCode() {
        $prefix = 'COUPON';
        $timestamp = time();
        $random = substr(md5(mt_rand()), 0, 6);
        return strtoupper("{$prefix}{$timestamp}{$random}");
    }
    
    /**
     * 清理过期积分
     * @return int 清理的积分数量
     */
    public function cleanupExpiredPoints() {
        $sql = "SELECT user_id, SUM(pt.change_points) as expired_points 
                FROM point_transactions pt 
                JOIN user_members um ON pt.user_id = um.user_id 
                WHERE pt.expire_date <= DATE(NOW()) AND pt.type != 'expire' 
                GROUP BY user_id";
        
        $expiredUsers = $this->db->query($sql);
        $cleanupCount = 0;
        
        foreach ($expiredUsers as $user) {
            $this->updateUserPoints(
                $user['user_id'], 
                -$user['expired_points'], 
                'expire', 
                null, 
                '积分过期清理'
            );
            $cleanupCount++;
        }
        
        return $cleanupCount;
    }
}