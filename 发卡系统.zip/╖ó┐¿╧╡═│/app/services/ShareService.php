<?php
/**
 * 社交分享裂变服务类
 * 实现用户分享、返利计算、分享记录管理等功能
 */
class ShareService {
    private $db;
    private $logger;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     */
    public function __construct($db) {
        $this->db = $db;
        $this->logger = new Logger('share');
    }
    
    /**
     * 创建分享规则
     * @param array $data 分享规则数据
     * @return int|false 规则ID或false
     */
    public function createShareRule($data) {
        $requiredFields = ['name', 'type', 'reward_type', 'reward_value', 'target_scope'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                $this->logger->error("创建分享规则失败：缺少必要字段{$field}");
                return false;
            }
        }
        
        $sql = "INSERT INTO share_rules (name, type, reward_type, reward_value, reward_max_per_user, reward_max_total, target_scope, 
                target_data, expiration_days, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())";
        
        $params = [
            $data['name'],
            $data['type'],
            $data['reward_type'],
            $data['reward_value'],
            $data['reward_max_per_user'] ?? null,
            $data['reward_max_total'] ?? null,
            $data['target_scope'],
            json_encode($data['target_data'] ?? []),
            $data['expiration_days'] ?? 30
        ];
        
        return $this->db->execute($sql, $params, true);
    }
    
    /**
     * 生成分享链接
     * @param int $userId 用户ID
     * @param string $targetType 目标类型(product/card/activity)
     * @param int $targetId 目标ID
     * @param int $ruleId 分享规则ID
     * @return string|false 分享链接或false
     */
    public function generateShareLink($userId, $targetType, $targetId, $ruleId) {
        // 验证用户存在
        $userSql = "SELECT id FROM users WHERE id = ? AND status = 'active'";
        $user = $this->db->query($userSql, [$userId]);
        if (empty($user)) {
            $this->logger->error("生成分享链接失败：用户不存在或已禁用");
            return false;
        }
        
        // 验证规则存在且有效
        if ($ruleId) {
            $ruleSql = "SELECT id FROM share_rules WHERE id = ? AND status = 'active'";
            $rule = $this->db->query($ruleSql, [$ruleId]);
            if (empty($rule)) {
                $this->logger->error("生成分享链接失败：分享规则不存在或已禁用");
                return false;
            }
        } else {
            // 获取默认规则
            $defaultRuleSql = "SELECT id FROM share_rules WHERE type = 'default' AND status = 'active' LIMIT 1";
            $defaultRule = $this->db->query($defaultRuleSql);
            $ruleId = !empty($defaultRule) ? $defaultRule[0]['id'] : null;
        }
        
        // 生成分享码
        $shareCode = $this->generateShareCode();
        $expireTime = date('Y-m-d H:i:s', strtotime('+90 days'));
        
        // 保存分享记录
        $sql = "INSERT INTO share_records (share_user_id, share_code, target_type, target_id, rule_id, status, expire_time, created_at) 
                VALUES (?, ?, ?, ?, ?, 'active', ?, NOW())";
        
        $params = [$userId, $shareCode, $targetType, $targetId, $ruleId, $expireTime];
        $recordId = $this->db->execute($sql, $params, true);
        
        if ($recordId) {
            // 构建分享链接
            $baseUrl = $this->getBaseUrl();
            return "{$baseUrl}/share/{$shareCode}";
        }
        
        return false;
    }
    
    /**
     * 通过分享码获取分享记录
     * @param string $shareCode 分享码
     * @return array|false 分享记录或false
     */
    public function getShareByCode($shareCode) {
        $sql = "SELECT * FROM share_records WHERE share_code = ? AND status = 'active' AND expire_time > NOW()";
        $record = $this->db->query($sql, [$shareCode]);
        
        if (empty($record)) {
            $this->logger->warning("分享码无效：{$shareCode}");
            return false;
        }
        
        return $record[0];
    }
    
    /**
     * 记录分享访问
     * @param string $shareCode 分享码
     * @param string $visitorIp 访问者IP
     * @param string $userAgent 用户代理
     * @param int $visitorId 访问者用户ID(如果已登录)
     * @return int|false 访问记录ID或false
     */
    public function recordShareVisit($shareCode, $visitorIp, $userAgent, $visitorId = null) {
        $shareRecord = $this->getShareByCode($shareCode);
        
        if (!$shareRecord) {
            return false;
        }
        
        $sql = "INSERT INTO share_visits (share_record_id, share_code, visitor_ip, visitor_id, user_agent, device_type, browser, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        
        // 简单的设备类型识别
        $deviceType = 'desktop';
        if (preg_match('/(iphone|ipad|ipod|android|mobile)/i', $userAgent)) {
            $deviceType = 'mobile';
        } else if (preg_match('/(wechat|micromessenger|alipay|toutiao)/i', $userAgent)) {
            $deviceType = 'app';
        }
        
        // 简单的浏览器识别
        $browser = 'unknown';
        if (preg_match('/chrome/i', $userAgent)) $browser = 'chrome';
        else if (preg_match('/firefox/i', $userAgent)) $browser = 'firefox';
        else if (preg_match('/safari/i', $userAgent)) $browser = 'safari';
        else if (preg_match('/msie|trident/i', $userAgent)) $browser = 'ie';
        else if (preg_match('/edge/i', $userAgent)) $browser = 'edge';
        
        $params = [$shareRecord['id'], $shareCode, $visitorIp, $visitorId, $userAgent, $deviceType, $browser];
        
        return $this->db->execute($sql, $params, true);
    }
    
    /**
     * 处理新用户注册的分享奖励
     * @param int $newUserId 新用户ID
     * @param string $shareCode 分享码
     * @return array 奖励处理结果
     */
    public function processRegistrationReward($newUserId, $shareCode) {
        $shareRecord = $this->getShareByCode($shareCode);
        
        if (!$shareRecord || !$shareRecord['rule_id']) {
            return ['success' => false, 'error' => '无效的分享码'];
        }
        
        // 检查分享记录是否已生成奖励
        $checkSql = "SELECT id FROM share_rewards WHERE share_record_id = ? AND reward_type = 'registration'";
        $existing = $this->db->query($checkSql, [$shareRecord['id']]);
        
        if (!empty($existing)) {
            return ['success' => false, 'error' => '该分享已获得注册奖励'];
        }
        
        // 获取分享规则
        $ruleSql = "SELECT * FROM share_rules WHERE id = ? AND status = 'active'";
        $rule = $this->db->query($ruleSql, [$shareRecord['rule_id']]);
        
        if (empty($rule)) {
            return ['success' => false, 'error' => '分享规则不存在或已禁用'];
        }
        
        $rule = $rule[0];
        $shareUserId = $shareRecord['share_user_id'];
        
        // 检查分享者是否已经达到奖励上限
        if ($rule['reward_max_per_user']) {
            $countSql = "SELECT COUNT(*) as reward_count FROM share_rewards WHERE user_id = ? AND rule_id = ? AND reward_type = 'registration'";
            $count = $this->db->query($countSql, [$shareUserId, $rule['id']]);
            
            if ($count[0]['reward_count'] >= $rule['reward_max_per_user']) {
                return ['success' => false, 'error' => '分享者已达到奖励上限'];
            }
        }
        
        // 检查总奖励是否已经达到上限
        if ($rule['reward_max_total']) {
            $totalSql = "SELECT SUM(reward_value) as total_reward FROM share_rewards WHERE rule_id = ? AND reward_type = 'registration'";
            $total = $this->db->query($totalSql, [$rule['id']]);
            
            if (($total[0]['total_reward'] ?? 0) >= $rule['reward_max_total']) {
                return ['success' => false, 'error' => '活动总奖励已发放完毕'];
            }
        }
        
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 记录奖励
            $rewardSql = "INSERT INTO share_rewards (share_record_id, user_id, rule_id, new_user_id, reward_type, reward_value, status, created_at) 
                          VALUES (?, ?, ?, ?, 'registration', ?, 'pending', NOW())";
            
            $rewardParams = [$shareRecord['id'], $shareUserId, $rule['id'], $newUserId, $rule['reward_value']];
            $rewardId = $this->db->execute($rewardSql, $rewardParams, true);
            
            // 发放奖励
            $success = $this->issueReward($shareUserId, $rule['reward_type'], $rule['reward_value']);
            
            if ($success) {
                // 更新奖励状态
                $updateSql = "UPDATE share_rewards SET status = 'completed' WHERE id = ?";
                $this->db->execute($updateSql, [$rewardId]);
                
                // 更新分享记录
                $updateRecordSql = "UPDATE share_records SET success_count = success_count + 1 WHERE id = ?";
                $this->db->execute($updateRecordSql, [$shareRecord['id']]);
                
                // 提交事务
                $this->db->commit();
                
                return [
                    'success' => true,
                    'share_user_id' => $shareUserId,
                    'reward_type' => $rule['reward_type'],
                    'reward_value' => $rule['reward_value'],
                    'message' => '分享奖励发放成功'
                ];
            } else {
                throw new Exception('奖励发放失败');
            }
            
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            $this->logger->error("处理分享注册奖励失败: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 处理分享购买奖励
     * @param int $newUserId 新用户ID
     * @param int $orderId 订单ID
     * @param float $orderAmount 订单金额
     * @return array 奖励处理结果
     */
    public function processPurchaseReward($newUserId, $orderId, $orderAmount) {
        // 查询新用户是否通过分享码注册
        $sourceSql = "SELECT * FROM user_sources WHERE user_id = ? AND source_type = 'share'";
        $source = $this->db->query($sourceSql, [$newUserId]);
        
        if (empty($source)) {
            return ['success' => false, 'error' => '未找到分享来源记录'];
        }
        
        $source = $source[0];
        $shareCode = $source['source_code'];
        
        // 查询分享记录
        $shareRecord = $this->getShareByCode($shareCode);
        
        if (!$shareRecord || !$shareRecord['rule_id']) {
            return ['success' => false, 'error' => '分享记录不存在或已过期'];
        }
        
        // 检查是否已经发放过该订单的奖励
        $checkSql = "SELECT id FROM share_rewards WHERE new_user_id = ? AND order_id = ? AND reward_type = 'purchase'";
        $existing = $this->db->query($checkSql, [$newUserId, $orderId]);
        
        if (!empty($existing)) {
            return ['success' => false, 'error' => '该订单已发放过分享奖励'];
        }
        
        // 获取分享规则
        $ruleSql = "SELECT * FROM share_rules WHERE id = ? AND status = 'active'";
        $rule = $this->db->query($ruleSql, [$shareRecord['rule_id']]);
        
        if (empty($rule)) {
            return ['success' => false, 'error' => '分享规则不存在或已禁用'];
        }
        
        $rule = $rule[0];
        $shareUserId = $shareRecord['share_user_id'];
        
        // 计算奖励金额（可能是固定金额或订单金额的百分比）
        $rewardValue = $rule['reward_type'] === 'percentage' 
            ? $orderAmount * ($rule['reward_value'] / 100) 
            : $rule['reward_value'];
        
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            // 记录奖励
            $rewardSql = "INSERT INTO share_rewards (share_record_id, user_id, rule_id, new_user_id, order_id, reward_type, reward_value, status, created_at) 
                          VALUES (?, ?, ?, ?, ?, 'purchase', ?, 'pending', NOW())";
            
            $rewardParams = [$shareRecord['id'], $shareUserId, $rule['id'], $newUserId, $orderId, $rewardValue];
            $rewardId = $this->db->execute($rewardSql, $rewardParams, true);
            
            // 发放奖励
            $success = $this->issueReward($shareUserId, 'points', $rewardValue); // 暂时固定为积分奖励
            
            if ($success) {
                // 更新奖励状态
                $updateSql = "UPDATE share_rewards SET status = 'completed' WHERE id = ?";
                $this->db->execute($updateSql, [$rewardId]);
                
                // 更新分享记录
                $updateRecordSql = "UPDATE share_records SET success_count = success_count + 1, total_amount = total_amount + ? WHERE id = ?";
                $this->db->execute($updateRecordSql, [$orderAmount, $shareRecord['id']]);
                
                // 提交事务
                $this->db->commit();
                
                return [
                    'success' => true,
                    'share_user_id' => $shareUserId,
                    'reward_type' => 'points',
                    'reward_value' => $rewardValue,
                    'message' => '分享购买奖励发放成功'
                ];
            } else {
                throw new Exception('奖励发放失败');
            }
            
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            $this->logger->error("处理分享购买奖励失败: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 发放奖励
     * @param int $userId 用户ID
     * @param string $rewardType 奖励类型(points/coupon/cash)
     * @param float $rewardValue 奖励值
     * @return bool 是否成功
     */
    private function issueReward($userId, $rewardType, $rewardValue) {
        switch ($rewardType) {
            case 'points':
                // 增加积分
                $sql = "INSERT INTO point_transactions (user_id, type, change_value, balance_after, source_type, source_id, created_at) 
                        VALUES (?, 'reward', ?, 0, 'share', null, NOW())";
                
                if ($this->db->execute($sql, [$userId, $rewardValue])) {
                    // 更新用户积分
                    $updateSql = "UPDATE users SET points = points + ? WHERE id = ?";
                    return $this->db->execute($updateSql, [$rewardValue, $userId]);
                }
                break;
                
            case 'coupon':
                // 发放优惠券（简化版，实际应该选择合适的优惠券类型）
                $couponSql = "SELECT id FROM coupon_types WHERE type = 'fixed' AND status = 'active' ORDER BY created_at DESC LIMIT 1";
                $couponType = $this->db->query($couponSql);
                
                if (!empty($couponType)) {
                    $couponCode = $this->generateShareCode();
                    $expireDate = date('Y-m-d H:i:s', strtotime('+30 days'));
                    
                    $issueSql = "INSERT INTO user_coupons (user_id, coupon_type_id, coupon_code, status, issue_date, expire_date, source) 
                                VALUES (?, ?, ?, 'unused', NOW(), ?, 'share_reward')";
                    
                    return $this->db->execute($issueSql, [$userId, $couponType[0]['id'], $couponCode, $expireDate]);
                }
                break;
                
            case 'cash':
                // 增加现金余额（简化版）
                $cashSql = "UPDATE users SET balance = balance + ? WHERE id = ?";
                return $this->db->execute($cashSql, [$rewardValue, $userId]);
                break;
        }
        
        return false;
    }
    
    /**
     * 获取用户分享统计
     * @param int $userId 用户ID
     * @return array 统计数据
     */
    public function getUserShareStats($userId) {
        // 分享总次数
        $totalSql = "SELECT COUNT(*) as total_shares FROM share_records WHERE share_user_id = ?";
        $total = $this->db->query($totalSql, [$userId]);
        
        // 成功转化次数
        $successSql = "SELECT COUNT(DISTINCT new_user_id) as new_users FROM share_rewards WHERE user_id = ? AND reward_type = 'registration'";
        $success = $this->db->query($successSql, [$userId]);
        
        // 获得的奖励
        $rewardSql = "SELECT reward_type, SUM(reward_value) as total_value FROM share_rewards WHERE user_id = ? AND status = 'completed' GROUP BY reward_type";
        $rewards = $this->db->query($rewardSql, [$userId]);
        
        return [
            'total_shares' => $total[0]['total_shares'],
            'new_users' => $success[0]['new_users'],
            'rewards' => $rewards
        ];
    }
    
    /**
     * 生成分享码
     * @return string 分享码
     */
    private function generateShareCode() {
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $code = '';
        for ($i = 0; $i < 12; $i++) {
            $code .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $code;
    }
    
    /**
     * 获取系统基础URL
     * @return string 基础URL
     */
    private function getBaseUrl() {
        // 这里可以从配置或环境变量中获取
        return 'https://example.com';
    }
    
    /**
     * 验证分享码是否有效
     * @param string $shareCode 分享码
     * @return bool 是否有效
     */
    public function validateShareCode($shareCode) {
        $sql = "SELECT id FROM share_records WHERE share_code = ? AND status = 'active' AND expire_time > NOW()";
        $result = $this->db->query($sql, [$shareCode]);
        return !empty($result);
    }
}