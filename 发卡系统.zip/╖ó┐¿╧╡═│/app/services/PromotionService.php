<?php
/**
 * 促销活动服务类
 * 实现促销活动管理、优惠券管理等功能
 */
class PromotionService {
    private $db;
    private $logger;
    private $memberService;
    
    /**
     * 构造函数
     * @param Database $db 数据库实例
     * @param MemberService $memberService 会员服务实例
     */
    public function __construct($db, $memberService) {
        $this->db = $db;
        $this->logger = new Logger('promotion');
        $this->memberService = $memberService;
    }
    
    /**
     * 创建促销活动
     * @param array $data 活动数据
     * @return int|false 活动ID或false
     */
    public function createPromotion($data) {
        $requiredFields = ['name', 'type', 'start_time', 'end_time', 'rules', 'target_scope'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                $this->logger->error("创建活动失败：缺少必要字段{$field}");
                return false;
            }
        }
        
        $sql = "INSERT INTO promotions (name, type, sub_type, description, start_time, end_time, status, rules, target_scope, target_data, max_usage, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?)";
        
        $params = [
            $data['name'],
            $data['type'],
            $data['sub_type'] ?? null,
            $data['description'] ?? '',
            $data['start_time'],
            $data['end_time'],
            json_encode($data['rules']),
            $data['target_scope'],
            json_encode($data['target_data'] ?? []),
            $data['max_usage'] ?? null,
            $data['created_by'] ?? null
        ];
        
        return $this->db->execute($sql, $params, true);
    }
    
    /**
     * 更新促销活动
     * @param int $promotionId 活动ID
     * @param array $data 更新数据
     * @return bool 是否成功
     */
    public function updatePromotion($promotionId, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if ($key != 'id') {
                $fields[] = "{$key} = ?";
                $params[] = ($key == 'rules' || $key == 'target_data') ? json_encode($value) : $value;
            }
        }
        
        $params[] = $promotionId;
        $sql = "UPDATE promotions SET " . implode(', ', $fields) . " WHERE id = ?";
        
        return $this->db->execute($sql, $params);
    }
    
    /**
     * 获取活跃的促销活动列表
     * @param int $userId 用户ID（可选，用于检查用户是否符合活动条件）
     * @return array 活动列表
     */
    public function getActivePromotions($userId = null) {
        $sql = "SELECT * FROM promotions WHERE status = 'active' AND start_time <= NOW() AND end_time >= NOW() ORDER BY created_at DESC";
        $promotions = $this->db->query($sql);
        
        if (!empty($userId)) {
            // 筛选用户符合条件的活动
            $filteredPromotions = [];
            foreach ($promotions as $promotion) {
                if ($this->checkUserPromotionEligibility($userId, $promotion)) {
                    $filteredPromotions[] = $promotion;
                }
            }
            return $filteredPromotions;
        }
        
        return $promotions;
    }
    
    /**
     * 检查用户是否符合活动条件
     * @param int $userId 用户ID
     * @param array $promotion 活动信息
     * @return bool 是否符合条件
     */
    private function checkUserPromotionEligibility($userId, $promotion) {
        // 检查活动目标用户范围
        switch ($promotion['target_scope']) {
            case 'all':
                return true;
                
            case 'new':
                // 检查是否新用户（注册30天内）
                $sql = "SELECT created_at FROM users WHERE id = ?";
                $user = $this->db->query($sql, [$userId]);
                if (!empty($user)) {
                    $daysSinceRegistration = (time() - strtotime($user[0]['created_at'])) / 86400;
                    return $daysSinceRegistration <= 30;
                }
                return false;
                
            case 'member_level':
                // 检查会员等级
                $targetData = json_decode($promotion['target_data'], true);
                if (isset($targetData['levels'])) {
                    $memberInfo = $this->memberService->getUserMemberInfo($userId);
                    return in_array($memberInfo['member_level_id'], $targetData['levels']);
                }
                return false;
                
            case 'specific_users':
                // 检查特定用户
                $targetData = json_decode($promotion['target_data'], true);
                return in_array($userId, $targetData['user_ids'] ?? []);
                
            default:
                return false;
        }
    }
    
    /**
     * 激活促销活动
     * @param int $promotionId 活动ID
     * @return bool 是否成功
     */
    public function activatePromotion($promotionId) {
        return $this->updatePromotion($promotionId, ['status' => 'active']);
    }
    
    /**
     * 暂停促销活动
     * @param int $promotionId 活动ID
     * @return bool 是否成功
     */
    public function pausePromotion($promotionId) {
        return $this->updatePromotion($promotionId, ['status' => 'paused']);
    }
    
    /**
     * 创建优惠券类型
     * @param array $data 优惠券类型数据
     * @return int|false 优惠券类型ID或false
     */
    public function createCouponType($data) {
        $requiredFields = ['name', 'type', 'value', 'min_amount'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                $this->logger->error("创建优惠券类型失败：缺少必要字段{$field}");
                return false;
            }
        }
        
        $sql = "INSERT INTO coupon_types (name, type, value, min_amount, max_discount, valid_days, product_scope, product_data, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')";
        
        $params = [
            $data['name'],
            $data['type'],
            $data['value'],
            $data['min_amount'],
            $data['max_discount'] ?? null,
            $data['valid_days'] ?? 30,
            $data['product_scope'] ?? 'all',
            json_encode($data['product_data'] ?? [])
        ];
        
        return $this->db->execute($sql, $params, true);
    }
    
    /**
     * 批量发放优惠券
     * @param int $couponTypeId 优惠券类型ID
     * @param array $userIds 用户ID列表
     * @return array 发放结果
     */
    public function batchIssueCoupons($couponTypeId, $userIds) {
        // 获取优惠券类型信息
        $sql = "SELECT * FROM coupon_types WHERE id = ? AND status = 'active'";
        $couponType = $this->db->query($sql, [$couponTypeId]);
        
        if (empty($couponType)) {
            return ['success' => false, 'error' => '优惠券类型不存在'];
        }
        
        $couponType = $couponType[0];
        $expireDate = date('Y-m-d H:i:s', strtotime("+{$couponType['valid_days']} days"));
        
        $successCount = 0;
        $failedCount = 0;
        
        // 开始事务
        $this->db->beginTransaction();
        
        try {
            foreach ($userIds as $userId) {
                // 检查用户是否已拥有该类型优惠券
                $checkSql = "SELECT id FROM user_coupons WHERE user_id = ? AND coupon_type_id = ? AND status = 'unused'";
                $existing = $this->db->query($checkSql, [$userId, $couponTypeId]);
                
                if (empty($existing)) {
                    // 发放优惠券
                    $couponCode = $this->generateCouponCode();
                    $insertSql = "INSERT INTO user_coupons (user_id, coupon_type_id, coupon_code, status, issue_date, expire_date) VALUES (?, ?, ?, 'unused', NOW(), ?)";
                    if ($this->db->execute($insertSql, [$userId, $couponTypeId, $couponCode, $expireDate])) {
                        $successCount++;
                    } else {
                        $failedCount++;
                    }
                } else {
                    $failedCount++;
                }
            }
            
            // 提交事务
            $this->db->commit();
            
            return [
                'success' => true,
                'total' => count($userIds),
                'success_count' => $successCount,
                'failed_count' => $failedCount
            ];
            
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            $this->logger->error("批量发放优惠券失败: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 根据活动向符合条件的用户发放优惠券
     * @param int $promotionId 活动ID
     * @return array 发放结果
     */
    public function issueCouponsByPromotion($promotionId) {
        // 获取活动信息
        $sql = "SELECT * FROM promotions WHERE id = ? AND status = 'active' AND start_time <= NOW() AND end_time >= NOW()";
        $promotion = $this->db->query($sql, [$promotionId]);
        
        if (empty($promotion)) {
            return ['success' => false, 'error' => '活动不存在或已结束'];
        }
        
        $promotion = $promotion[0];
        $rules = json_decode($promotion['rules'], true);
        
        if (!isset($rules['coupon_type_id'])) {
            return ['success' => false, 'error' => '活动规则中缺少优惠券类型ID'];
        }
        
        // 获取符合条件的用户
        $userIds = $this->getEligibleUsersForPromotion($promotion);
        
        // 批量发放优惠券
        return $this->batchIssueCoupons($rules['coupon_type_id'], $userIds);
    }
    
    /**
     * 获取符合活动条件的用户ID列表
     * @param array $promotion 活动信息
     * @return array 用户ID列表
     */
    private function getEligibleUsersForPromotion($promotion) {
        $baseSql = "SELECT id FROM users WHERE status = 'active'";
        $params = [];
        
        switch ($promotion['target_scope']) {
            case 'all':
                break;
                
            case 'new':
                $baseSql .= " AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                break;
                
            case 'member_level':
                $targetData = json_decode($promotion['target_data'], true);
                if (isset($targetData['levels'])) {
                    $placeholders = implode(',', array_fill(0, count($targetData['levels']), '?'));
                    $baseSql .= " AND id IN (SELECT user_id FROM user_members WHERE member_level_id IN ({$placeholders}))";
                    $params = array_merge($params, $targetData['levels']);
                }
                break;
                
            case 'specific_users':
                $targetData = json_decode($promotion['target_data'], true);
                if (isset($targetData['user_ids']) && !empty($targetData['user_ids'])) {
                    $placeholders = implode(',', array_fill(0, count($targetData['user_ids']), '?'));
                    $baseSql .= " AND id IN ({$placeholders})";
                    $params = array_merge($params, $targetData['user_ids']);
                }
                break;
        }
        
        $result = $this->db->query($baseSql, $params);
        $userIds = [];
        foreach ($result as $row) {
            $userIds[] = $row['id'];
        }
        
        return $userIds;
    }
    
    /**
     * 处理订单促销
     * @param int $userId 用户ID
     * @param int $orderId 订单ID
     * @param decimal $orderAmount 订单金额
     * @param array $orderItems 订单商品
     * @return array 促销处理结果
     */
    public function processOrderPromotion($userId, $orderId, $orderAmount, $orderItems) {
        $promotions = $this->getActivePromotions($userId);
        $discountAmount = 0;
        $appliedPromotions = [];
        
        foreach ($promotions as $promotion) {
            $rules = json_decode($promotion['rules'], true);
            $discount = $this->calculatePromotionDiscount($promotion, $orderAmount, $orderItems);
            
            if ($discount > 0) {
                $discountAmount += $discount;
                $appliedPromotions[] = [
                    'promotion_id' => $promotion['id'],
                    'promotion_name' => $promotion['name'],
                    'discount_amount' => $discount
                ];
                
                // 更新活动使用次数
                $this->updatePromotionUsage($promotion['id']);
            }
        }
        
        return [
            'total_discount' => $discountAmount,
            'applied_promotions' => $appliedPromotions
        ];
    }
    
    /**
     * 计算活动折扣金额
     * @param array $promotion 活动信息
     * @param float $orderAmount 订单金额
     * @param array $orderItems 订单商品
     * @return float 折扣金额
     */
    private function calculatePromotionDiscount($promotion, $orderAmount, $orderItems) {
        $rules = json_decode($promotion['rules'], true);
        $discount = 0;
        
        switch ($promotion['type']) {
            case 'discount':
                // 折扣类型活动
                if (isset($rules['min_amount']) && $orderAmount >= $rules['min_amount']) {
                    if (isset($rules['discount_rate'])) {
                        // 折扣率
                        $discount = $orderAmount * (1 - $rules['discount_rate']);
                    } elseif (isset($rules['discount_amount'])) {
                        // 直接减额
                        $discount = $rules['discount_amount'];
                    }
                }
                break;
                
            case 'cashback':
                // 返现类型活动
                if (isset($rules['min_amount']) && $orderAmount >= $rules['min_amount']) {
                    $discount = $orderAmount * ($rules['cashback_rate'] ?? 0);
                }
                break;
                
            case 'points':
                // 积分活动不直接影响订单金额
                break;
                
            case 'combination':
                // 组合套餐活动
                if (isset($rules['required_products']) && $this->checkOrderItems($orderItems, $rules['required_products'])) {
                    $discount = $rules['discount_amount'] ?? 0;
                }
                break;
        }
        
        // 限制最大折扣
        if (isset($rules['max_discount']) && $discount > $rules['max_discount']) {
            $discount = $rules['max_discount'];
        }
        
        return min($discount, $orderAmount); // 折扣不超过订单金额
    }
    
    /**
     * 检查订单商品是否符合活动要求
     * @param array $orderItems 订单商品
     * @param array $requiredProducts 要求的商品列表
     * @return bool 是否符合
     */
    private function checkOrderItems($orderItems, $requiredProducts) {
        foreach ($requiredProducts as $requiredProduct) {
            $found = false;
            foreach ($orderItems as $item) {
                if ($item['product_id'] == $requiredProduct['product_id'] && $item['quantity'] >= $requiredProduct['quantity']) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * 更新活动使用次数
     * @param int $promotionId 活动ID
     */
    private function updatePromotionUsage($promotionId) {
        $sql = "UPDATE promotions SET usage_count = usage_count + 1 WHERE id = ?";
        $this->db->execute($sql, [$promotionId]);
    }
    
    /**
     * 生成优惠券码
     * @return string 优惠券码
     */
    private function generateCouponCode() {
        return 'COUPON_' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 12));
    }
    
    /**
     * 获取即将过期的促销活动
     * @param int $days 天数
     * @return array 活动列表
     */
    public function getExpiringPromotions($days = 7) {
        $sql = "SELECT * FROM promotions WHERE status = 'active' AND end_time BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL ? DAY) ORDER BY end_time ASC";
        return $this->db->query($sql, [$days]);
    }
}