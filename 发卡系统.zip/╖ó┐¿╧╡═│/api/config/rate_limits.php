<?php
/**
 * API限流配置文件
 * 
 * 支持不同类型请求的差异化限流策略
 * 包含基础限流、敏感操作限流、IP黑名单等功能
 */

return [
    // 基础限流配置
    'default' => [
        'requests_per_minute' => 60,        // 每分钟60次请求
        'requests_per_hour' => 1000,         // 每小时1000次请求
        'requests_per_day' => 10000,         // 每天10000次请求
        'burst_limit' => 10,                 // 突发请求限制
        'block_duration' => 300,             // 违规后阻止时间（秒）
    ],
    
    // 登录相关限流（更严格）
    'login' => [
        'requests_per_minute' => 5,          // 每分钟5次登录尝试
        'requests_per_hour' => 20,           // 每小时20次登录尝试
        'requests_per_day' => 100,           // 每天100次登录尝试
        'failure_threshold' => 3,            // 连续失败次数阈值
        'failure_block_duration' => 900,     // 失败后阻止时间（15分钟）
        'progressive_block' => true,         // 启用递增阻止时间
    ],
    
    // 敏感操作限流（如密码修改、支付等）
    'sensitive' => [
        'requests_per_minute' => 3,          // 每分钟3次敏感操作
        'requests_per_hour' => 10,           // 每小时10次敏感操作
        'requests_per_day' => 50,            // 每天50次敏感操作
        'require_auth' => true,              // 需要身份验证
        'log_all_requests' => true,          // 记录所有请求
    ],
    
    // 文件上传限流
    'upload' => [
        'requests_per_minute' => 10,         // 每分钟10次上传
        'requests_per_hour' => 100,          // 每小时100次上传
        'max_file_size' => 50 * 1024 * 1024, // 最大文件大小（50MB）
        'allowed_extensions' => ['jpg', 'png', 'pdf', 'doc', 'docx'],
    ],
    
    // API查询限流
    'query' => [
        'requests_per_minute' => 120,         // 每分钟120次查询
        'requests_per_hour' => 2000,         // 每小时2000次查询
        'requests_per_day' => 20000,         // 每天20000次查询
        'cache_enabled' => true,             // 启用缓存
        'cache_ttl' => 300,                  // 缓存时间（秒）
    ],
    
    // 管理员操作限流（相对宽松）
    'admin' => [
        'requests_per_minute' => 200,         // 每分钟200次请求
        'requests_per_hour' => 5000,          // 每小时5000次请求
        'requests_per_day' => 50000,         // 每天50000次请求
        'exclude_from_limit' => false,       // 是否排除在限流之外
    ],
    
    // IP白名单配置
    'whitelist' => [
        'enabled' => true,
        'ips' => [
            '127.0.0.1',                     // 本地地址
            '::1',                           // IPv6本地地址
            // 可以添加更多可信IP
        ],
        'bypass_all_limits' => false,        // 是否绕过所有限流
    ],
    
    // IP黑名单配置
    'blacklist' => [
        'enabled' => true,
        'ips' => [
            // 可以添加恶意IP
        ],
        'permanent_block' => true,           // 永久阻止
    ],
    
    // 违规处理策略
    'violation_handling' => [
        'progressive_punishment' => true,    // 渐进式惩罚
        'punishment_levels' => [
            1 => ['duration' => 300,  'type' => 'temporary'],   // 5分钟
            2 => ['duration' => 900,  'type' => 'temporary'],   // 15分钟
            3 => ['duration' => 1800, 'type' => 'temporary'],   // 30分钟
            4 => ['duration' => 3600, 'type' => 'temporary'],   // 1小时
            5 => ['duration' => 86400, 'type' => 'temporary'],  // 24小时
        ],
        'max_violations_per_day' => 10,      // 每日最大违规次数
        'auto_blacklist_threshold' => 5,     // 自动加入黑名单阈值
    ],
    
    // 监控和告警
    'monitoring' => [
        'enabled' => true,
        'alert_threshold' => [
            'violations_per_minute' => 10,   // 每分钟违规次数告警
            'blocked_ips_per_hour' => 5,     // 每小时阻止IP数告警
            'total_requests_per_minute' => 1000, // 总请求量告警
        ],
        'notification_methods' => ['email', 'log', 'webhook'],
    ],
    
    // 存储配置
    'storage' => [
        'driver' => 'database',              // 存储驱动：database, redis, file
        'database' => [
            'table_prefix' => 'api_',
            'cleanup_interval' => 3600,      // 清理间隔（秒）
            'retention_days' => 30,           // 数据保留天数
        ],
        'redis' => [
            'host' => '127.0.0.1',
            'port' => 6379,
            'prefix' => 'rate_limit:',
            'ttl' => 86400,                   // 默认过期时间
        ],
    ],
    
    // 响应配置
    'response' => [
        'include_headers' => true,           // 包含限流信息头
        'headers' => [
            'x-rate-limit-limit' => 'limit',
            'x-rate-limit-remaining' => 'remaining',
            'x-rate-limit-reset' => 'reset',
            'retry-after' => 'retry_after',
        ],
        'error_messages' => [
            'RATE_LIMIT_EXCEEDED' => '请求过于频繁，请稍后再试',
            'IP_ADDRESS_BLOCKED' => '您的IP地址已被临时阻止',
            'PERMANENTLY_BLOCKED' => '您的IP地址已被永久阻止',
        ],
    ],
    
    // 调试和日志
    'debug' => [
        'enabled' => false,                   // 调试模式
        'log_all_requests' => false,         // 记录所有请求
        'log_violations' => true,            // 记录违规
        'log_blocks' => true,                // 记录阻止
        'performance_monitoring' => true,    // 性能监控
    ],
];