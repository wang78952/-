<?php
/**
 * 分析服务配置
 * 定义小程序分析服务的相关配置参数
 */

return [
    // 分析数据接收端点
    'api_endpoints' => [
        'receive_analytics' => '/api/analytics/mini-program',
        'get_report' => '/api/analytics/mini-program/report'
    ],
    
    // 数据采集配置
    'tracking' => [
        // 是否启用分析服务
        'enabled' => true,
        
        // 数据发送间隔（秒）
        'batch_interval' => 60,
        
        // 最大批量事件数
        'max_batch_size' => 50,
        
        // 自动发送前的最小事件数
        'min_batch_size' => 5
    ],
    
    // 会话管理
    'session' => [
        // 会话超时时间（秒）
        'timeout' => 300,
        
        // 会话ID长度
        'id_length' => 32
    ],
    
    // 需要记录的事件类型
    'events' => [
        'page_view' => true,
        'user_interaction' => true,
        'app_error' => true,
        'network_request' => true,
        'page_performance' => true,
        'device_info' => true
    ],
    
    // 性能监控配置
    'performance' => [
        // 慢页面加载阈值（毫秒）
        'slow_load_threshold' => 3000,
        
        // 是否启用页面加载时间监控
        'track_page_load' => true,
        
        // 是否启用网络请求监控
        'track_network_requests' => true
    ],
    
    // 存储配置
    'storage' => [
        // 本地存储键名前缀
        'local_storage_prefix' => 'analytics_',
        
        // 本地存储最大容量（字节）
        'max_local_storage' => 5 * 1024 * 1024 // 5MB
    ],
    
    // 调试配置
    'debug' => [
        // 是否启用调试模式
        'enabled' => false,
        
        // 是否在控制台打印日志
        'console_log' => false,
        
        // 是否在控制台打印性能数据
        'performance_log' => false
    ]
];