<?php
/**
 * 售后管理API
 * 处理售后申请、审批、退款、补发等操作
 */
require_once '../../includes/common.php';
require_once '../../includes/AfterSalesManager.php';
require_once '../../includes/Auth.php';
require_once '../../includes/Permission.php';

// 初始化管理器
$afterSalesManager = new AfterSalesManager();
$auth = new Auth();
$permission = new Permission();
$response = ['success' => false, 'message' => '操作失败'];

try {
    // 验证登录
    $userInfo = $auth->getCurrentUser();
    if (!$userInfo) {
        throw new Exception('未登录');
    }
    
    // 获取操作类型
    $action = $_GET['action'] ?? '';
    
    // 根据操作类型处理请求
    switch ($action) {
        case 'create':
            // 创建售后申请
            $response = handleCreateAfterSales($userInfo);
            break;
            
        case 'list':
            // 获取售后列表
            $response = handleGetAfterSalesList($userInfo);
            break;
            
        case 'detail':
            // 获取售后详情
            $response = handleGetAfterSalesDetail($userInfo);
            break;
            
        case 'process':
            // 处理售后申请（仅商户）
            $response = handleProcessAfterSales($userInfo);
            break;
            
        case 'logs':
            // 获取售后日志
            $response = handleGetAfterSalesLogs($userInfo);
            break;
            
        default:
            $response = ['success' => false, 'message' => '未知操作类型'];
    }
    
} catch (Exception $e) {
    $response = ['success' => false, 'message' => $e->getMessage()];
}

// 返回JSON响应
echo json_encode($response, JSON_UNESCAPED_UNICODE);

/**
 * 处理创建售后申请
 * @param array $userInfo 当前用户信息
 * @return array 处理结果
 */
function handleCreateAfterSales($userInfo) {
    global $afterSalesManager;
    
    // 获取请求数据
    $data = json_decode(file_get_contents('php://input'), true);
    
    // 验证必填字段
    if (empty($data['order_id']) || empty($data['reason'])) {
        return ['success' => false, 'message' => '缺少必要参数'];
    }
    
    // 验证用户权限（只能对自己的订单申请售后）
    $orderInfo = $afterSalesManager->orderManager->getOrder($data['order_id']);
    if (!$orderInfo || $orderInfo['user_id'] !== $userInfo['id']) {
        return ['success' => false, 'message' => '无权操作此订单'];
    }
    
    // 验证订单状态
    if (!in_array($orderInfo['status'], ['completed', 'paid'])) {
        return ['success' => false, 'message' => '该订单不支持申请售后'];
    }
    
    // 准备售后申请数据
    $afterSalesData = [
        'order_id' => $data['order_id'],
        'user_id' => $userInfo['id'],
        'type' => $data['type'] ?? 'refund',
        'reason' => $data['reason'],
        'description' => $data['description'] ?? '',
        'evidence_urls' => $data['evidence_urls'] ?? [],
        'amount' => $data['amount'] ?? $orderInfo['actual_amount'],
        'card_ids' => $data['card_ids'] ?? []
    ];
    
    // 创建售后申请
    $result = $afterSalesManager->createAfterSales($data['order_id'], $afterSalesData);
    
    if ($result['success']) {
        return [
            'success' => true,
            'message' => '售后申请提交成功',
            'after_sales_id' => $result['after_sales_id']
        ];
    }
    
    return $result;
}

/**
 * 处理获取售后列表
 * @param array $userInfo 当前用户信息
 * @return array 处理结果
 */
function handleGetAfterSalesList($userInfo) {
    global $afterSalesManager, $permission;
    
    // 构建查询条件
    $filters = [];
    
    // 根据用户角色设置不同过滤条件
    if ($permission->isMerchant($userInfo['id'])) {
        // 商户可以查看所有售后申请
    } else {
        // 普通用户只能查看自己的
        $filters['user_id'] = $userInfo['id'];
    }
    
    // 添加过滤条件
    if (!empty($_GET['order_id'])) {
        $filters['order_id'] = $_GET['order_id'];
    }
    
    if (!empty($_GET['status'])) {
        $filters['status'] = $_GET['status'];
    }
    
    if (!empty($_GET['type'])) {
        $filters['type'] = $_GET['type'];
    }
    
    // 获取分页参数
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = max(1, min(100, intval($_GET['limit'] ?? 20)));
    
    // 查询售后列表
    $result = $afterSalesManager->getAfterSalesList($filters, $page, $limit);
    
    return [
        'success' => true,
        'data' => $result['list'],
        'pagination' => [
            'total' => $result['total'],
            'page' => $result['page'],
            'limit' => $result['limit'],
            'pages' => $result['pages']
        ]
    ];
}

/**
 * 处理获取售后详情
 * @param array $userInfo 当前用户信息
 * @return array 处理结果
 */
function handleGetAfterSalesDetail($userInfo) {
    global $afterSalesManager, $permission;
    
    // 获取售后ID
    $afterSalesId = intval($_GET['id']);
    if (!$afterSalesId) {
        return ['success' => false, 'message' => '缺少必要参数'];
    }
    
    // 获取售后信息
    $afterSalesInfo = $afterSalesManager->getAfterSalesDetail($afterSalesId);
    if (!$afterSalesInfo) {
        return ['success' => false, 'message' => '售后申请不存在'];
    }
    
    // 权限验证
    if (!$permission->isMerchant($userInfo['id']) && $afterSalesInfo['user_id'] !== $userInfo['id']) {
        return ['success' => false, 'message' => '无权查看此售后申请'];
    }
    
    return [
        'success' => true,
        'data' => $afterSalesInfo
    ];
}

/**
 * 处理售后申请（商户操作）
 * @param array $userInfo 当前用户信息
 * @return array 处理结果
 */
function handleProcessAfterSales($userInfo) {
    global $afterSalesManager, $permission;
    
    // 验证是否为商户
    if (!$permission->isMerchant($userInfo['id'])) {
        return ['success' => false, 'message' => '只有商户可以处理售后申请'];
    }
    
    // 获取请求数据
    $data = json_decode(file_get_contents('php://input'), true);
    
    // 验证必填字段
    if (empty($data['after_sales_id']) || empty($data['action'])) {
        return ['success' => false, 'message' => '缺少必要参数'];
    }
    
    // 验证操作类型
    if (!in_array($data['action'], ['approve', 'reject', 'cancel'])) {
        return ['success' => false, 'message' => '无效的操作类型'];
    }
    
    // 准备处理数据
    $processData = [
        'action' => $data['action'],
        'admin_id' => $userInfo['id'],
        'admin_note' => $data['note'] ?? '',
        'full_refund' => isset($data['full_refund']) ? $data['full_refund'] : true,
        'card_ids' => $data['card_ids'] ?? []
    ];
    
    // 处理售后申请
    $result = $afterSalesManager->processAfterSales($data['after_sales_id'], $processData);
    
    if ($result['success']) {
        return [
            'success' => true,
            'message' => $result['message'],
            'data' => $result
        ];
    }
    
    return $result;
}

/**
 * 处理获取售后日志
 * @param array $userInfo 当前用户信息
 * @return array 处理结果
 */
function handleGetAfterSalesLogs($userInfo) {
    global $afterSalesManager, $permission;
    
    // 获取售后ID
    $afterSalesId = intval($_GET['id']);
    if (!$afterSalesId) {
        return ['success' => false, 'message' => '缺少必要参数'];
    }
    
    // 获取售后信息以验证权限
    $afterSalesInfo = $afterSalesManager->getAfterSalesDetail($afterSalesId);
    if (!$afterSalesInfo) {
        return ['success' => false, 'message' => '售后申请不存在'];
    }
    
    // 权限验证
    if (!$permission->isMerchant($userInfo['id']) && $afterSalesInfo['user_id'] !== $userInfo['id']) {
        return ['success' => false, 'message' => '无权查看此售后日志'];
    }
    
    // 获取售后日志
    $logs = $afterSalesManager->getAfterSalesLogs($afterSalesId);
    
    return [
        'success' => true,
        'data' => $logs
    ];
}

// 错误处理
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'error' => $e->__toString()
    ];
}

// 返回JSON响应
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);

/**
 * 注意：需要在AfterSalesManager中添加getAfterSalesDetail方法
 * 以下是该方法的示例实现，可以添加到AfterSalesManager类中
 */
/*
public function getAfterSalesDetail($afterSalesId) {
    $sql = "SELECT * FROM order_after_sales WHERE id = ?";
    $afterSales = $this->database->fetch($sql, [$afterSalesId]);
    
    if ($afterSales) {
        $afterSales['evidence_urls'] = json_decode($afterSales['evidence_urls'], true) ?: [];
        $afterSales['logs'] = $this->getAfterSalesLogs($afterSalesId);
        $afterSales['order_info'] = $this->orderManager->getOrder($afterSales['order_id']);
        
        // 获取关联的卡密信息
        $cardsSql = "SELECT oc.*, c.card_no, c.card_password 
                     FROM order_cards oc 
                     LEFT JOIN cards c ON oc.card_id = c.id
                     WHERE oc.after_sales_id = ?";
        $afterSales['related_cards'] = $this->database->fetchAll($cardsSql, [$afterSalesId]);
    }
    
    return $afterSales;
}
*/
?>