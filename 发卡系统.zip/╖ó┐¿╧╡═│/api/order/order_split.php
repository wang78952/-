<?php
/**
 * 订单拆分API接口
 * 处理多卡密订单的拆分操作
 */

// 引入配置和数据库连接
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/OrderManager.php';
require_once __DIR__ . '/../../includes/Auth.php';

// 初始化API控制器
class OrderSplitController {
    private $orderManager;
    private $auth;
    
    public function __construct() {
        $this->orderManager = new OrderManager();
        $this->auth = new Auth();
    }
    
    /**
     * 处理API请求
     */
    public function handleRequest() {
        // 验证认证令牌
        $userInfo = $this->auth->checkAuth();
        if (!$userInfo) {
            $this->sendResponse(401, '未授权访问', []);
            return;
        }
        
        // 检查用户权限，只有商户和管理员可以进行拆分操作
        if (!in_array($userInfo['user_type'], ['merchant', 'admin'])) {
            $this->sendResponse(403, '权限不足，只有商户和管理员可以进行订单拆分', []);
            return;
        }
        
        // 获取请求方法
        $method = $_SERVER['REQUEST_METHOD'];
        
        // 根据请求方法分发处理
        switch ($method) {
            case 'POST':
                $this->splitOrder();
                break;
            case 'GET':
                $this->getSplitPreview();
                break;
            default:
                $this->sendResponse(405, '不支持的请求方法', []);
                break;
        }
    }
    
    /**
     * 获取订单拆分预览
     */
    private function getSplitPreview() {
        // 验证参数
        if (!isset($_GET['order_id'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        $orderId = intval($_GET['order_id']);
        
        try {
            // 获取订单信息
            $order = $this->orderManager->getOrder($orderId);
            
            if (!$order) {
                $this->sendResponse(404, '订单不存在', []);
                return;
            }
            
            // 检查订单是否可拆分
            if ($order['quantity'] <= 1) {
                $this->sendResponse(400, '订单数量为1，无需拆分', []);
                return;
            }
            
            // 检查订单状态，只有已完成或处理中的订单可以拆分
            if (!in_array($order['status'], ['completed', 'processing'])) {
                $this->sendResponse(400, '只有已完成或处理中的订单可以拆分', []);
                return;
            }
            
            // 获取订单中的卡密列表
            $cards = $this->orderManager->getOrderCards($orderId);
            
            // 发送响应
            $this->sendResponse(200, '获取拆分预览成功', [
                'order' => [
                    'id' => $order['id'],
                    'order_no' => $order['order_no'],
                    'product_name' => $order['product_name'],
                    'quantity' => $order['quantity'],
                    'status' => $order['status']
                ],
                'available_cards' => array_map(function($card) {
                    return [
                        'id' => $card['id'],
                        'card_no' => $card['card_no'],
                        'card_pwd' => $card['card_pwd'],
                        'status' => $card['status'],
                        'created_at' => $card['created_at']
                    ];
                }, $cards)
            ]);
        } catch (Exception $e) {
            $this->sendResponse(500, '获取预览失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 执行订单拆分
     */
    private function splitOrder() {
        // 获取POST数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证参数
        if (!isset($data['order_id']) || !isset($data['split_items'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        $orderId = intval($data['order_id']);
        $splitItems = $data['split_items'];
        
        // 验证拆分项目
        if (!is_array($splitItems) || empty($splitItems)) {
            $this->sendResponse(400, '拆分项目格式错误', []);
            return;
        }
        
        // 获取用户信息
        $userInfo = $this->auth->checkAuth();
        $operatorId = $userInfo['user_id'];
        $operatorName = $userInfo['username'];
        
        try {
            // 开始事务
            $this->orderManager->startTransaction();
            
            // 执行拆分操作
            $result = $this->orderManager->splitOrder($orderId, $splitItems, $operatorId, $operatorName);
            
            // 提交事务
            $this->orderManager->commitTransaction();
            
            // 发送响应
            $this->sendResponse(200, '订单拆分成功', [
                'original_order_id' => $orderId,
                'new_orders' => $result
            ]);
        } catch (Exception $e) {
            // 回滚事务
            $this->orderManager->rollbackTransaction();
            
            $this->sendResponse(500, '订单拆分失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 发送JSON响应
     */
    private function sendResponse($code, $message, $data) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => $code,
            'message' => $message,
            'data' => $data
        ]);
        exit;
    }
}

// 创建控制器实例并处理请求
$controller = new OrderSplitController();
$controller->handleRequest();