<?php
/**
 * 订单备注API接口
 * 处理订单备注的增删改查操作
 */

// 引入配置和数据库连接
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/OrderNoteManager.php';
require_once __DIR__ . '/../../includes/Auth.php';

// 初始化API控制器
class OrderNoteController {
    private $orderNoteManager;
    private $auth;
    
    public function __construct() {
        $this->orderNoteManager = new OrderNoteManager();
        $this->auth = new Auth();
    }
    
    /**
     * 处理API请求
     */
    public function handleRequest() {
        // 验证认证令牌
        $userInfo = $this->auth->checkAuth();
        if (!$userInfo) {
            $this->sendResponse(401, '未授权访问', []);
            return;
        }
        
        // 获取请求方法
        $method = $_SERVER['REQUEST_METHOD'];
        
        // 根据请求方法分发处理
        switch ($method) {
            case 'GET':
                $this->getNotes();
                break;
            case 'POST':
                $this->createNote();
                break;
            case 'DELETE':
                $this->deleteNote();
                break;
            default:
                $this->sendResponse(405, '不支持的请求方法', []);
                break;
        }
    }
    
    /**
     * 获取订单备注列表
     */
    private function getNotes() {
        // 验证参数
        if (!isset($_GET['order_id'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        $orderId = intval($_GET['order_id']);
        
        try {
            // 获取备注列表
            $notes = $this->orderNoteManager->getOrderNotes($orderId);
            
            // 发送响应
            $this->sendResponse(200, '获取成功', [
                'notes' => $notes
            ]);
        } catch (Exception $e) {
            $this->sendResponse(500, '获取失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 创建新的订单备注
     */
    private function createNote() {
        // 获取POST数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证参数
        if (!isset($data['order_id']) || !isset($data['content'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        // 获取用户信息
        $userInfo = $this->auth->checkAuth();
        $userId = $userInfo['user_id'];
        $userType = $userInfo['user_type']; // merchant, user, admin
        
        try {
            // 创建备注
            $noteId = $this->orderNoteManager->addNote(
                intval($data['order_id']),
                $userId,
                $userType,
                $data['content'],
                isset($data['images']) ? $data['images'] : []
            );
            
            // 获取完整备注信息
            $note = $this->orderNoteManager->getNoteById($noteId);
            
            // 发送响应
            $this->sendResponse(201, '创建成功', [
                'note_id' => $noteId,
                'note' => $note
            ]);
        } catch (Exception $e) {
            $this->sendResponse(500, '创建失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 删除订单备注
     */
    private function deleteNote() {
        // 获取DELETE数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证参数
        if (!isset($data['note_id'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        // 获取用户信息
        $userInfo = $this->auth->checkAuth();
        $userId = $userInfo['user_id'];
        $userType = $userInfo['user_type'];
        
        try {
            // 验证备注所有权
            $note = $this->orderNoteManager->getNoteById(intval($data['note_id']));
            if (!$note) {
                $this->sendResponse(404, '备注不存在', []);
                return;
            }
            
            // 只有创建者或管理员可以删除备注
            if ($note['user_id'] != $userId && $userType != 'admin') {
                $this->sendResponse(403, '无权删除此备注', []);
                return;
            }
            
            // 删除备注
            $result = $this->orderNoteManager->deleteNote(intval($data['note_id']));
            
            if ($result) {
                $this->sendResponse(200, '删除成功', []);
            } else {
                $this->sendResponse(400, '删除失败', []);
            }
        } catch (Exception $e) {
            $this->sendResponse(500, '删除失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 发送JSON响应
     */
    private function sendResponse($code, $message, $data) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => $code,
            'message' => $message,
            'data' => $data
        ]);
        exit;
    }
}

// 创建控制器实例并处理请求
$controller = new OrderNoteController();
$controller->handleRequest();