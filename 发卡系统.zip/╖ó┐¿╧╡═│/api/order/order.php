<?php
/**
 * 订单管理API控制器
 */

// 引入配置和数据库连接
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/OrderManager.php';
require_once __DIR__ . '/../../includes/OrderNoteManager.php';
require_once __DIR__ . '/../../includes/Auth.php';

// 初始化API控制器
class OrderController {
    private $orderManager;
    private $orderNoteManager;
    private $auth;
    
    public function __construct() {
        $this->orderManager = new OrderManager();
        $this->orderNoteManager = new OrderNoteManager();
        $this->auth = new Auth();
    }
    
    /**
     * 处理API请求
     */
    public function handleRequest() {
        // 验证认证令牌
        $userInfo = $this->auth->checkAuth();
        if (!$userInfo) {
            $this->sendResponse(401, '未授权访问', []);
            return;
        }
        
        // 获取请求路径
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $pathParts = explode('/', rtrim($path, '/'));
        
        // 获取请求方法
        $method = $_SERVER['REQUEST_METHOD'];
        
        // 路由分发
        if ($pathParts[count($pathParts) - 1] === 'list' || !isset($pathParts[count($pathParts) - 1])) {
            // 订单列表
            if ($method === 'GET') {
                $this->getOrderList();
            } else {
                $this->sendResponse(405, '不支持的请求方法', []);
            }
        } elseif ($pathParts[count($pathParts) - 1] === 'detail' && isset($_GET['order_id'])) {
            // 订单详情
            if ($method === 'GET') {
                $this->getOrderDetail();
            } else {
                $this->sendResponse(405, '不支持的请求方法', []);
            }
        } elseif (isset($_GET['action'])) {
            // 其他操作
            switch ($_GET['action']) {
                case 'create':
                    if ($method === 'POST') {
                        $this->createOrder();
                    } else {
                        $this->sendResponse(405, '不支持的请求方法', []);
                    }
                    break;
                case 'update':
                    if ($method === 'PUT') {
                        $this->updateOrder();
                    } else {
                        $this->sendResponse(405, '不支持的请求方法', []);
                    }
                    break;
                case 'delete':
                    if ($method === 'DELETE') {
                        $this->deleteOrder();
                    } else {
                        $this->sendResponse(405, '不支持的请求方法', []);
                    }
                    break;
                case 'split':
                    if ($method === 'POST') {
                        $this->splitOrder();
                    } else {
                        $this->sendResponse(405, '不支持的请求方法', []);
                    }
                    break;
                default:
                    $this->sendResponse(404, '操作不存在', []);
                    break;
            }
        } else {
            $this->sendResponse(404, 'API路径不存在', []);
        }
    }
    
    /**
     * 获取订单列表
     */
    private function getOrderList() {
        // 验证参数
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $pageSize = isset($_GET['page_size']) ? intval($_GET['page_size']) : 20;
        
        // 获取筛选条件
        $filters = [];
        if (isset($_GET['product_id'])) {
            $filters['product_id'] = intval($_GET['product_id']);
        }
        if (isset($_GET['status'])) {
            $filters['status'] = $_GET['status'];
        }
        if (isset($_GET['start_date'])) {
            $filters['start_date'] = $_GET['start_date'];
        }
        if (isset($_GET['end_date'])) {
            $filters['end_date'] = $_GET['end_date'];
        }
        if (isset($_GET['order_no'])) {
            $filters['order_no'] = $_GET['order_no'];
        }
        if (isset($_GET['user_id'])) {
            $filters['user_id'] = intval($_GET['user_id']);
        }
        if (isset($_GET['agent_id'])) {
            $filters['agent_id'] = intval($_GET['agent_id']);
        }
        
        try {
            // 获取订单列表
            $result = $this->orderManager->getOrderList($page, $pageSize, $filters);
            
            // 发送响应
            $this->sendResponse(200, '获取成功', [
                'orders' => $result['orders'],
                'total' => $result['total'],
                'page' => $page,
                'page_size' => $pageSize
            ]);
        } catch (Exception $e) {
            $this->sendResponse(500, '获取失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 获取订单详情
     */
    private function getOrderDetail() {
        // 验证参数
        if (!isset($_GET['order_id'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        $orderId = intval($_GET['order_id']);
        
        try {
            // 获取订单详情
            $order = $this->orderManager->getOrder($orderId);
            
            if (!$order) {
                $this->sendResponse(404, '订单不存在', []);
                return;
            }
            
            // 获取订单卡密
            $cards = $this->orderManager->getOrderCards($orderId);
            
            // 获取订单备注
            $notes = $this->orderNoteManager->getOrderNotes($orderId);
            
            // 获取订单售后信息
            $afterSales = [];
            if (method_exists($this->orderManager, 'getOrderAfterSalesInfo')) {
                $afterSales = $this->orderManager->getOrderAfterSalesInfo($orderId);
            }
            
            // 发送响应
            $this->sendResponse(200, '获取成功', [
                'order' => $order,
                'cards' => $cards,
                'notes' => $notes,
                'after_sales' => $afterSales
            ]);
        } catch (Exception $e) {
            $this->sendResponse(500, '获取失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 创建订单
     */
    private function createOrder() {
        // 获取POST数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证参数
        if (!isset($data['product_id']) || !isset($data['quantity'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        // 获取用户信息
        $userInfo = $this->auth->checkAuth();
        $userId = $userInfo['user_id'];
        
        try {
            // 创建订单
            $orderId = $this->orderManager->createOrder([
                'user_id' => $userId,
                'product_id' => intval($data['product_id']),
                'quantity' => intval($data['quantity']),
                'payment_method' => isset($data['payment_method']) ? $data['payment_method'] : 'alipay',
                'remark' => isset($data['remark']) ? $data['remark'] : '',
                'agent_id' => isset($data['agent_id']) ? intval($data['agent_id']) : 0
            ]);
            
            // 获取订单详情
            $order = $this->orderManager->getOrder($orderId);
            
            // 发送响应
            $this->sendResponse(201, '创建成功', [
                'order_id' => $orderId,
                'order' => $order
            ]);
        } catch (Exception $e) {
            $this->sendResponse(500, '创建失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 更新订单
     */
    private function updateOrder() {
        // 获取PUT数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证参数
        if (!isset($data['order_id'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        // 获取用户信息
        $userInfo = $this->auth->checkAuth();
        
        // 检查用户权限
        if ($userInfo['user_type'] != 'merchant' && $userInfo['user_type'] != 'admin') {
            $this->sendResponse(403, '权限不足', []);
            return;
        }
        
        try {
            // 更新订单
            $result = $this->orderManager->updateOrder($data['order_id'], $data);
            
            if ($result) {
                // 获取更新后的订单详情
                $order = $this->orderManager->getOrder($data['order_id']);
                $this->sendResponse(200, '更新成功', [
                    'order' => $order
                ]);
            } else {
                $this->sendResponse(400, '更新失败', []);
            }
        } catch (Exception $e) {
            $this->sendResponse(500, '更新失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 删除订单
     */
    private function deleteOrder() {
        // 获取DELETE数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证参数
        if (!isset($data['order_id'])) {
            $this->sendResponse(400, '缺少必要参数', []);
            return;
        }
        
        // 获取用户信息
        $userInfo = $this->auth->checkAuth();
        
        // 检查用户权限
        if ($userInfo['user_type'] != 'merchant' && $userInfo['user_type'] != 'admin') {
            $this->sendResponse(403, '权限不足', []);
            return;
        }
        
        try {
            // 删除订单
            $result = $this->orderManager->deleteOrder($data['order_id']);
            
            if ($result) {
                $this->sendResponse(200, '删除成功', []);
            } else {
                $this->sendResponse(400, '删除失败', []);
            }
        } catch (Exception $e) {
            $this->sendResponse(500, '删除失败: ' . $e->getMessage(), []);
        }
    }
    
    /**
     * 发送JSON响应
     */
    private function sendResponse($code, $message, $data) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => $code,
            'message' => $message,
            'data' => $data
        ]);
        exit;
    }
}

// 实例化控制器并处理请求
$controller = new OrderController();
$controller->handleRequest();