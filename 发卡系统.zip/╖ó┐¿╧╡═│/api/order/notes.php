<?php
/**
 * 订单备注API控制器
 */
require_once '../../includes/init.php';
require_once '../../includes/OrderNoteManager.php';
require_once '../../includes/Auth.php';

// 初始化认证
$auth = new Auth();
$user = $auth->checkAuth();

// 初始化数据库和日志
$database = new Database();
$logger = new Logger();
$noteManager = new OrderNoteManager($database, $logger);

// 获取操作类型
$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');

// 设置响应头
header('Content-Type: application/json');

// 根据操作类型处理请求
switch ($action) {
    
    case 'add':
        // 添加备注
        handleAddNote();
        break;
        
    case 'list':
        // 获取备注列表
        handleListNotes();
        break;
        
    case 'delete':
        // 删除备注
        handleDeleteNote();
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'message' => '无效的操作类型'
        ]);
        break;
}

/**
 * 处理添加备注请求
 */
function handleAddNote() {
    global $user, $noteManager;
    
    // 验证输入
    $orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $isPublic = isset($_POST['is_public']) ? intval($_POST['is_public']) : 1;
    
    if (!$orderId || !$content) {
        echo json_encode([
            'success' => false,
            'message' => '订单ID和备注内容不能为空'
        ]);
        return;
    }
    
    // 确定用户类型
    $userType = 'system';
    $userId = null;
    
    if ($user) {
        $userId = $user['id'];
        $userType = ($user['role'] === 'admin' || $user['role'] === 'merchant') ? 'merchant' : 'user';
    }
    
    // 构建备注数据
    $noteData = [
        'user_id' => $userId,
        'user_type' => $userType,
        'content' => $content,
        'is_public' => $isPublic
    ];
    
    // 添加备注
    $result = $noteManager->addNote($orderId, $noteData);
    
    echo json_encode($result);
}

/**
 * 处理获取备注列表请求
 */
function handleListNotes() {
    global $user, $noteManager;
    
    // 获取订单ID
    $orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
    
    if (!$orderId) {
        echo json_encode([
            'success' => false,
            'message' => '订单ID不能为空'
        ]);
        return;
    }
    
    // 构建查询选项
    $options = [];
    if ($user && $user['role'] === 'user') {
        $options['user_type'] = 'user';
    }
    
    // 获取备注列表
    $notes = $noteManager->getOrderNotes($orderId, $options);
    
    echo json_encode([
        'success' => true,
        'data' => $notes
    ]);
}

/**
 * 处理删除备注请求
 */
function handleDeleteNote() {
    global $user, $noteManager;
    
    // 验证权限
    if (!$user) {
        echo json_encode([
            'success' => false,
            'message' => '请先登录'
        ]);
        return;
    }
    
    // 获取备注ID
    $noteId = isset($_POST['note_id']) ? intval($_POST['note_id']) : 0;
    
    if (!$noteId) {
        echo json_encode([
            'success' => false,
            'message' => '备注ID不能为空'
        ]);
        return;
    }
    
    // 删除备注
    $result = $noteManager->deleteNote($noteId, $user['id']);
    
    echo json_encode($result);
}

/**
 * 处理批量获取订单备注请求
 */
function handleBatchListNotes() {
    global $noteManager;
    
    // 获取订单ID数组
    $orderIds = isset($_GET['order_ids']) ? json_decode($_GET['order_ids'], true) : [];
    
    if (!is_array($orderIds) || empty($orderIds)) {
        echo json_encode([
            'success' => false,
            'message' => '请提供有效的订单ID列表'
        ]);
        return;
    }
    
    // 批量获取备注
    $notes = $noteManager->getBatchOrderNotes($orderIds);
    
    echo json_encode([
        'success' => true,
        'data' => $notes
    ]);
}
?>