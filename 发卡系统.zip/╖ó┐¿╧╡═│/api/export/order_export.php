<?php
/**
 * 订单导出API接口
 * 支持多种导出选项和字段自定义
 */

// 引入必要的文件
require_once __DIR__ . '/../../includes/BaseController.php';
require_once __DIR__ . '/../../includes/ExportManager.php';
require_once __DIR__ . '/../../includes/AuthMiddleware.php';

class OrderExportController extends BaseController
{
    /**
     * ExportManager实例
     * @var ExportManager
     */
    private $exportManager;
    
    /**
     * 构造函数
     */
    public function __construct()
    {
        parent::__construct();
        $this->exportManager = new ExportManager();
    }
    
    /**
     * 处理API请求
     */
    public function handleRequest()
    {
        // 验证权限
        $authMiddleware = new AuthMiddleware();
        $authMiddleware->checkAuth();
        
        // 获取请求方法
        $method = $this->getMethod();
        
        // 根据请求方法分发处理
        switch ($method) {
            case 'GET':
                // 获取导出选项
                $action = $this->getParam('action', 'options');
                
                if ($action === 'options') {
                    $this->getExportOptions();
                } elseif ($action === 'download') {
                    $this->downloadExportFile();
                } else {
                    $this->error('未知的操作类型');
                }
                break;
                
            case 'POST':
                // 执行导出
                $this->exportOrders();
                break;
                
            default:
                $this->error('不支持的请求方法');
        }
    }
    
    /**
     * 获取导出选项
     * 返回可用的导出类型和字段选项
     */
    private function getExportOptions()
    {
        try {
            // 获取导出类型选项
            $exportTypes = $this->exportManager->getExportTypeOptions();
            
            // 获取字段选项
            $fieldOptions = $this->exportManager->getExportFieldOptions();
            
            // 返回选项数据
            $this->success([
                'export_types' => $exportTypes,
                'field_options' => $fieldOptions
            ]);
        } catch (Exception $e) {
            $this->error('获取导出选项失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 执行订单导出
     */
    private function exportOrders()
    {
        try {
            // 获取请求参数
            $params = $this->getParams();
            
            // 验证必要的参数
            $validator = $this->validateExportParams($params);
            if (!$validator['valid']) {
                $this->error($validator['message']);
                return;
            }
            
            // 执行导出
            $filename = $this->exportManager->exportOrderList($params);
            
            // 返回文件信息
            $this->success([
                'filename' => $filename,
                'download_url' => '/api/export/order_export.php?action=download&filename=' . urlencode($filename),
                'message' => '订单导出成功'
            ]);
        } catch (Exception $e) {
            $this->error('订单导出失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 下载导出文件
     */
    private function downloadExportFile()
    {
        try {
            // 获取文件名
            $filename = $this->getParam('filename');
            if (empty($filename)) {
                $this->error('缺少文件名参数');
                return;
            }
            
            // 验证文件名（防止路径遍历攻击）
            if (!preg_match('/^[a-zA-Z0-9_\-\.]+$/', $filename)) {
                $this->error('无效的文件名');
                return;
            }
            
            // 文件路径
            $filepath = __DIR__ . '/../../exports/' . $filename;
            
            // 检查文件是否存在
            if (!file_exists($filepath)) {
                $this->error('文件不存在');
                return;
            }
            
            // 设置响应头
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            
            // 输出文件内容
            ob_clean();
            flush();
            readfile($filepath);
            exit;
        } catch (Exception $e) {
            $this->error('文件下载失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 验证导出参数
     * @param array $params 导出参数
     * @return array 验证结果
     */
    private function validateExportParams($params)
    {
        // 基本验证
        if (!isset($params['export_type'])) {
            return [
                'valid' => false,
                'message' => '导出类型不能为空'
            ];
        }
        
        // 验证导出类型
        $validExportTypes = ['normal', 'promotion', 'abnormal', 'period'];
        if (!in_array($params['export_type'], $validExportTypes)) {
            return [
                'valid' => false,
                'message' => '无效的导出类型'
            ];
        }
        
        // 对于时间段导出，验证日期
        if ($params['export_type'] === 'period') {
            if (empty($params['start_date']) || empty($params['end_date'])) {
                return [
                    'valid' => false,
                    'message' => '时间段导出必须指定开始日期和结束日期'
                ];
            }
            
            // 验证日期格式
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $params['start_date']) || 
                !preg_match('/^\d{4}-\d{2}-\d{2}$/', $params['end_date'])) {
                return [
                    'valid' => false,
                    'message' => '日期格式不正确，应为YYYY-MM-DD'
                ];
            }
            
            // 验证日期范围
            $startDate = strtotime($params['start_date']);
            $endDate = strtotime($params['end_date']);
            $today = strtotime(date('Y-m-d'));
            
            if ($startDate > $endDate) {
                return [
                    'valid' => false,
                    'message' => '开始日期不能晚于结束日期'
                ];
            }
            
            if ($endDate > $today) {
                return [
                    'valid' => false,
                    'message' => '结束日期不能晚于今天'
                ];
            }
            
            // 验证时间范围不能超过90天
            if (($endDate - $startDate) > 90 * 24 * 3600) {
                return [
                    'valid' => false,
                    'message' => '导出时间范围不能超过90天'
                ];
            }
        }
        
        // 验证导出格式
        if (isset($params['format']) && !in_array($params['format'], ['csv', 'excel'])) {
            return [
                'valid' => false,
                'message' => '无效的导出格式'
            ];
        }
        
        return [
            'valid' => true,
            'message' => '验证通过'
        ];
    }
}

// 创建控制器实例并处理请求
$controller = new OrderExportController();
$controller->handleRequest();