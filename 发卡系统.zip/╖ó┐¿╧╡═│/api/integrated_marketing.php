<?php
/**
 * 整合营销系统API
 * 提供统一的数据访问接口，连接前端与后端整合营销系统
 */

// 设置响应头为JSON格式
header('Content-Type: application/json');

// 引入必要的文件
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../includes/business/IntegratedMarketingSystem.php';

// 检查并处理API请求
$action = $_GET['action'] ?? '';
$response = [];

// 检查管理员权限（针对某些操作）
function checkAdminPermission() {
    global $response;
    
    if (!isLoggedIn()) {
        $response = [
            'success' => false,
            'message' => '用户未登录',
            'error' => '未登录的用户无法访问此API'
        ];
        return false;
    }
    
    if (!isAdmin()) {
        $response = [
            'success' => false,
            'message' => '权限不足',
            'error' => '只有管理员可以访问此操作'
        ];
        return false;
    }
    
    return true;
}

// 检查用户权限（针对需要用户登录的操作）
function checkUserPermission() {
    global $response;
    
    if (!isLoggedIn()) {
        $response = [
            'success' => false,
            'message' => '用户未登录',
            'error' => '未登录的用户无法访问此API'
        ];
        return false;
    }
    
    return true;
}

// 解析请求体中的JSON数据
function getRequestBody() {
    $rawData = file_get_contents('php://input');
    $data = json_decode($rawData, true);
    return $data ?? [];
}

// 初始化整合营销系统实例
function getIntegratedSystem() {
    try {
        return new IntegratedMarketingSystem();
    } catch (Exception $e) {
        global $response;
        $response = [
            'success' => false,
            'message' => '初始化系统失败',
            'error' => $e->getMessage()
        ];
        return null;
    }
}

// 根据不同的操作执行相应的功能
switch ($action) {
    case 'get_user_marketing_info':
        // 获取用户完整营销信息
        if (!checkUserPermission()) break;
        
        $userId = getCurrentUserId();
        $requestData = getRequestBody();
        $orderData = $requestData['order_data'] ?? [];
        
        $system = getIntegratedSystem();
        if (!$system) break;
        
        $response = $system->getUserMarketingInfo($userId, $orderData);
        break;
        
    case 'calculate_order_discounts':
        // 计算订单适用的所有优惠
        if (!checkUserPermission()) break;
        
        $userId = getCurrentUserId();
        $requestData = getRequestBody();
        $orderData = $requestData['order_data'] ?? [];
        
        // 验证订单数据
        if (empty($orderData) || !isset($orderData['total_amount'])) {
            $response = [
                'success' => false,
                'message' => '订单数据不完整',
                'error' => '缺少必要的订单数据字段'
            ];
            break;
        }
        
        $system = getIntegratedSystem();
        if (!$system) break;
        
        $response = $system->calculateOrderDiscounts($userId, $orderData);
        break;
        
    case 'handle_order_completion':
        // 处理订单完成后的营销操作（由后端其他接口调用）
        // 不检查登录状态，因为这是内部API调用
        
        $requestData = getRequestBody();
        $orderId = $requestData['order_id'] ?? 0;
        $orderData = $requestData['order_data'] ?? [];
        
        // 验证必要数据
        if (empty($orderId) || empty($orderData)) {
            $response = [
                'success' => false,
                'message' => '缺少必要参数',
                'error' => '订单ID和订单数据不能为空'
            ];
            break;
        }
        
        $system = getIntegratedSystem();
        if (!$system) break;
        
        $response = $system->handleOrderCompletion($orderId, $orderData);
        break;
        
    case 'get_dashboard_data':
        // 获取营销仪表盘数据（需要管理员权限）
        if (!checkAdminPermission()) break;
        
        $requestData = getRequestBody();
        $filters = [
            'start_date' => $requestData['start_date'] ?? date('Y-m-d', strtotime('-30 days')),
            'end_date' => $requestData['end_date'] ?? date('Y-m-d'),
            'user_id' => $requestData['user_id'] ?? null,
            'agent_id' => $requestData['agent_id'] ?? null
        ];
        
        $system = getIntegratedSystem();
        if (!$system) break;
        
        $response = $system->getMarketingDashboardData($filters);
        break;
        
    case 'get_user_marketing_summary':
        // 获取用户营销摘要信息（无需登录也能使用，但仅限于当前用户）
        if (!checkUserPermission()) break;
        
        $userId = getCurrentUserId();
        $system = getIntegratedSystem();
        if (!$system) break;
        
        // 获取简化版的用户营销信息
        $response = $system->getUserMarketingInfo($userId, []);
        
        // 如果成功，只返回摘要数据
        if ($response['success']) {
            $response['data'] = [
                'member_level' => $response['data']['member_level'],
                'points' => $response['data']['points'],
                'recommended_actions' => $response['data']['recommended_actions'],
                'available_flash_sales' => $response['data']['available_flash_sales'] ?? [],
                'available_exchange_rules' => $response['data']['available_exchange_rules'] ?? []
            ];
        }
        break;
        
    default:
        // 无效的操作
        $response = [
            'success' => false,
            'message' => '无效的操作',
            'error' => '不支持的API操作: ' . $action
        ];
        break;
}

// 记录API调用日志
logApiCall($action, $response['success']);

// 返回JSON响应
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

/**
 * 记录API调用日志
 * 
 * @param string $action 调用的操作
 * @param bool $success 是否成功
 */
function logApiCall($action, $success) {
    try {
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'action' => $action,
            'success' => $success ? 'success' : 'failure',
            'user_id' => isLoggedIn() ? getCurrentUserId() : 0,
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ];
        
        // 这里可以实现日志记录逻辑
        // 例如写入数据库或日志文件
        
        // 记录到日志文件
        $logMessage = json_encode($logData, JSON_UNESCAPED_UNICODE) . "\n";
        file_put_contents('../logs/integrated_marketing_api.log', $logMessage, FILE_APPEND);
    } catch (Exception $e) {
        // 日志记录失败时不影响API响应
    }
}