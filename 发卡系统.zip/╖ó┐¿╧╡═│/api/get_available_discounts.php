<?php
/**
 * 获取可用的满减优惠
 * 用于获取基于用户订单的可用满减优惠活动
 */

// 引入必要的文件
require_once '../includes/config.php';
require_once '../includes/utils.php';
require_once '../includes/security.php';

// 如果DiscountManager类不存在，定义一个基础版本
if (!class_exists('DiscountManager')) {
    class DiscountManager {
        public function getAvailableDiscounts($orderData) {
            // 返回示例满减优惠数据
            return [
                [
                    'id' => 'discount_001',
                    'name' => '新人专享满减',
                    'description' => '新用户专享，满100减10',
                    'min_amount' => 100,
                    'discount_amount' => 10,
                    'value' => 10,
                    'type' => 'fixed',
                    'max_discount' => 10,
                    'start_time' => date('Y-m-d H:i:s', strtotime('-7 days')),
                    'end_time' => date('Y-m-d H:i:s', strtotime('+30 days')),
                    'is_active' => true,
                    'discount_type' => 'new_user'
                ],
                [
                    'id' => 'discount_002',
                    'name' => '满200减20',
                    'description' => '全场通用，满200减20',
                    'min_amount' => 200,
                    'discount_amount' => 20,
                    'value' => 20,
                    'type' => 'fixed',
                    'max_discount' => 20,
                    'start_time' => date('Y-m-d H:i:s', strtotime('-7 days')),
                    'end_time' => date('Y-m-d H:i:s', strtotime('+30 days')),
                    'is_active' => true,
                    'discount_type' => 'general'
                ],
                [
                    'id' => 'discount_003',
                    'name' => '满500减50',
                    'description' => '全场通用，满500减50',
                    'min_amount' => 500,
                    'discount_amount' => 50,
                    'value' => 50,
                    'type' => 'fixed',
                    'max_discount' => 50,
                    'start_time' => date('Y-m-d H:i:s', strtotime('-7 days')),
                    'end_time' => date('Y-m-d H:i:s', strtotime('+30 days')),
                    'is_active' => true,
                    'discount_type' => 'general'
                ]
            ];
        }
    }
}

// 设置响应头部
header('Content-Type: application/json');

// 检查用户是否已登录
if (!isUserLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => '用户未登录',
        'data' => []
    ]);
    exit;
}

// 获取用户ID
$userId = getCurrentUserId();

// 获取请求体
$requestData = getRequestData();

// 验证请求数据
if (!isset($requestData['orderAmount']) || !isset($requestData['orderItems'])) {
    echo json_encode([
        'success' => false,
        'message' => '请求参数不完整',
        'data' => []
    ]);
    exit;
}

// 准备订单数据
$orderData = [
    'userId' => $userId,
    'orderAmount' => $requestData['orderAmount'],
    'orderItems' => $requestData['orderItems']
];

// 初始化折扣管理器
$discountManager = new DiscountManager();

// 获取可用的满减优惠
$availableDiscounts = $discountManager->getAvailableDiscounts($orderData);

// 过滤出满足订单金额条件的优惠
$filteredDiscounts = array_filter($availableDiscounts, function($discount) use ($requestData) {
    return $discount['min_amount'] <= $requestData['orderAmount'] && 
           $discount['is_active'] === true && 
           strtotime($discount['end_time']) > time();
});

// 返回响应
$response = [
    'success' => true,
    'message' => '获取满减优惠成功',
    'data' => array_values($filteredDiscounts)
];

echo json_encode($response);

exit;