<?php
/**
 * API维护模式中间件
 * 为API请求提供专门的维护模式处理
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

// 添加必要的文件引用
require_once __DIR__ . '/../router.php';
require_once __DIR__ . '/../../includes/ConfigManager.php';
require_once __DIR__ . '/../../includes/Logger.php';
require_once __DIR__ . '/../../includes/SecurityUtils.php';

class MaintenanceModeApiMiddleware {
    /**
     * @var ConfigManager 配置管理器实例
     */
    private $configManager;
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * @var SecurityUtils 安全工具实例
     */
    private $securityUtils;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 安全地初始化依赖项
        // 避免使用全局变量，使用类存在性检查
        global $configManager, $logger, $securityUtils;
        
        // 配置管理器
        if (isset($configManager)) {
            $this->configManager = $configManager;
        } elseif (class_exists('ConfigManager')) {
            try {
                $this->configManager = new ConfigManager();
            } catch (Exception $e) {
                $this->configManager = null;
            }
        } else {
            $this->configManager = null;
        }
        
        // 日志记录器
        if (isset($logger)) {
            $this->logger = $logger;
        } elseif (class_exists('Logger')) {
            try {
                $this->logger = new Logger();
            } catch (Exception $e) {
                $this->logger = null;
            }
        } else {
            $this->logger = null;
        }
        
        // 安全工具
        if (isset($securityUtils)) {
            $this->securityUtils = $securityUtils;
        } elseif (class_exists('SecurityUtils')) {
            try {
                $this->securityUtils = new SecurityUtils();
            } catch (Exception $e) {
                $this->securityUtils = null;
            }
        } else {
            $this->securityUtils = null;
        }
    }
    
    /**
     * 中间件处理函数
     * 
     * @param array $data 请求数据
     * @param string $method 请求方法
     * @param string $path 请求路径
     * @param array $context 请求上下文
     * @return bool|array 是否允许请求继续
     */
    public function __invoke($data, $method, $path, $context = []) {
        // 如果配置管理器不可用，默认不启用维护模式
        if (!$this->configManager || !method_exists($this->configManager, 'get')) {
            return $data; // 配置管理器不可用，允许请求继续
        }
        
        // 获取维护模式配置
        $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
        
        // 检查维护模式是否启用
        if (empty($maintenanceConfig['enabled']) || $maintenanceConfig['enabled'] !== true) {
            return $data; // 维护模式未启用，允许请求继续
        }
        
        // 获取客户端IP - 安全地调用
        $clientIp = $context['client_ip'] ?? 
            ($this->securityUtils && method_exists($this->securityUtils, 'getRealIpAddress') 
                ? $this->securityUtils->getRealIpAddress() 
                : 'unknown');
        
        // 检查IP是否在白名单中
        if ($this->isIpWhitelisted($clientIp, $maintenanceConfig)) {
            // 安全地记录日志
            if ($this->logger && method_exists($this->logger, 'info')) {
                $this->logger->info('API维护模式 - 白名单IP允许访问', [
                    'ip' => $clientIp,
                    'path' => $path,
                    'method' => $method
                ]);
            }
            return $data;
        }
        
        // 检查API密钥是否有特殊权限
        if ($this->hasSpecialApiAccess($data, $context)) {
            // 安全地记录日志
            if ($this->logger && method_exists($this->logger, 'info')) {
                $this->logger->info('API维护模式 - 特殊API密钥允许访问', [
                    'api_key' => $context['api_key_id'] ?? 'unknown',
                    'path' => $path
                ]);
            }
            return $data;
        }
        
        // 检查是否是紧急访问端点
        if ($this->isEmergencyEndpoint($path)) {
            return $this->handleEmergencyEndpoint($path, $data);
        }
        
        // 检查是否是需要允许的关键API
        if ($this->isAllowedApi($path, $maintenanceConfig)) {
            return $data;
        }
        
        // 记录被阻止的请求 - 安全地记录
        if ($this->logger && method_exists($this->logger, 'info')) {
            $this->logger->info('API维护模式 - 阻止请求', [
                'ip' => $clientIp,
                'path' => $path,
                'method' => $method
            ]);
        }
        
        // 返回维护模式响应
        $this->returnMaintenanceResponse($maintenanceConfig);
        return false;
    }
    
    /**
     * 检查IP是否在白名单中
     * 
     * @param string $ip IP地址
     * @param array $config 维护模式配置
     * @return bool 是否在白名单中
     */
    private function isIpWhitelisted($ip, $config) {
        $allowedIps = $config['allowed_ips'] ?? [];
        
        // 检查是否包含通配符IP
        foreach ($allowedIps as $allowedIp) {
            if ($allowedIp === '*') {
                return true;
            }
            
            // 检查精确匹配
            if ($ip === $allowedIp) {
                return true;
            }
            
            // 检查CIDR格式
            if (strpos($allowedIp, '/') !== false) {
                if ($this->isIpInCidr($ip, $allowedIp)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 检查IP是否在CIDR范围内
     * 
     * @param string $ip IP地址
     * @param string $cidr CIDR格式的IP范围
     * @return bool 是否在范围内
     */
    private function isIpInCidr($ip, $cidr) {
        list($subnet, $mask) = explode('/', $cidr);
        $ipDec = ip2long($ip);
        $subnetDec = ip2long($subnet);
        $maskDec = ~((1 << (32 - $mask)) - 1);
        
        return (($ipDec & $maskDec) === ($subnetDec & $maskDec));
    }
    
    /**
     * 检查是否有特殊API访问权限
     * 
     * @param array $data 请求数据
     * @param array $context 请求上下文
     * @return bool 是否有特殊权限
     */
    private function hasSpecialApiAccess($data, $context) {
        // 检查API密钥权限
        $apiKeyLevel = $context['api_key_level'] ?? '';
        if ($apiKeyLevel === 'maintenance' || $apiKeyLevel === 'admin') {
            return true;
        }
        
        return false;
    }
    
    /**
     * 检查是否是紧急访问端点
     * 
     * @param string $path 请求路径
     * @return bool 是否是紧急端点
     */
    private function isEmergencyEndpoint($path) {
        $emergencyEndpoints = [
            '/api/maintenance/disable',
            '/api/status',
            '/api/health'
        ];
        
        return in_array($path, $emergencyEndpoints);
    }
    
    /**
     * 处理紧急端点请求
     * 
     * @param string $path 请求路径
     * @param array $data 请求数据
     * @return array|bool 处理结果
     */
    private function handleEmergencyEndpoint($path, $data) {
        if ($path === '/api/maintenance/disable') {
            return $this->handleDisableMaintenance($data);
        }
        
        // 对于状态检查端点，总是允许访问
        if ($path === '/api/status' || $path === '/api/health') {
            return $data;
        }
        
        return false;
    }
    
    /**
     * 处理禁用维护模式请求
     * 
     * @param array $data 请求数据
     * @return array 处理结果
     */
    private function handleDisableMaintenance($data) {
        // 获取紧急密钥
        $emergencyKey = $data['emergency_key'] ?? '';
        
        // 获取维护模式配置
        $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
        
        // 验证紧急密钥
        if (empty($maintenanceConfig['emergency_override']['key']) || 
            $maintenanceConfig['emergency_override']['key'] !== $emergencyKey) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'INVALID_EMERGENCY_KEY',
                'message' => '无效的紧急关闭密钥'
            ]);
            return false;
        }
        
        // 关闭维护模式
        $maintenanceConfig['enabled'] = false;
        
        // 保存配置
        $this->configManager->set('app.maintenance_mode', $maintenanceConfig);
        
        // 记录紧急关闭事件
        $this->logger->warning('API维护模式 - 紧急关闭', [
            'ip' => $this->securityUtils->getRealIpAddress()
        ]);
        
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => '维护模式已成功关闭'
        ]);
        
        return false;
    }
    
    /**
     * 检查是否是允许的API
     * 
     * @param string $path 请求路径
     * @param array $config 维护模式配置
     * @return bool 是否允许访问
     */
    private function isAllowedApi($path, $config) {
        $allowedApis = $config['allowed_apis'] ?? [];
        
        foreach ($allowedApis as $allowedApi) {
            // 支持精确匹配和前缀匹配
            if ($path === $allowedApi || strpos($path, $allowedApi . '/') === 0) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 返回维护模式响应
     * 
     * @param array $config 维护模式配置
     */
    private function returnMaintenanceResponse($config) {
        // 设置HTTP状态码
        http_response_code(503);
        header('Content-Type: application/json');
        header('Retry-After: 3600'); // 建议客户端1小时后重试
        
        // 构建响应数据
        $response = [
            'success' => false,
            'error' => 'SERVICE_UNAVAILABLE',
            'message' => $config['api_message'] ?? '系统正在维护中，请稍后再试',
            'code' => 503,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // 添加预计恢复时间（如果有）
        if (!empty($config['scheduled_end_time'])) {
            $response['scheduled_end_time'] = $config['scheduled_end_time'];
        }
        
        // 添加维护ID
        $response['maintenance_id'] = uniqid('maintenance_', true);
        
        // 输出JSON响应
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
}