<?php
/**
 * 数据脱敏中间件
 * 用于对API响应中的敏感数据进行统一脱敏处理
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

class DataMaskingMiddleware {
    
    /**
     * 敏感字段映射表
     * 字段名 -> 脱敏类型
     */
    private $sensitiveFields = [
        // 个人身份信息
        'id_card' => 'id_card',
        'identity_card' => 'id_card',
        'id_number' => 'id_card',
        'idcard' => 'id_card',
        'identity' => 'id_card',
        
        // 联系方式
        'phone' => 'phone',
        'mobile' => 'phone',
        'mobile_phone' => 'phone',
        'tel' => 'phone',
        'telephone' => 'phone',
        'email' => 'email',
        'mail' => 'email',
        'contact_email' => 'email',
        
        // 金融信息
        'card_number' => 'bank_card',
        'bank_card' => 'bank_card',
        'credit_card' => 'credit_card',
        'account_number' => 'bank_account',
        'bank_account' => 'bank_account',
        'password' => 'password',
        'pwd' => 'password',
        
        // 个人信息
        'name' => 'name',
        'full_name' => 'name',
        'real_name' => 'name',
        'card_holder' => 'name',
        'address' => 'address',
        'full_address' => 'address',
        'detailed_address' => 'address',
        
        // 其他敏感信息
        'token' => 'token',
        'api_key' => 'token',
        'secret' => 'token',
        'access_key' => 'token',
    ];
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 加载必要的类
        require_once dirname(__DIR__, 2) . '/includes/ComplianceManager.php';
        
        // 尝试加载DataEncryption类（可选）
        try {
            require_once dirname(__DIR__, 2) . '/includes/security/DataEncryption.php';
        } catch (Exception $e) {
            // DataEncryption类可能不存在，静默处理
        }
    }
    
    /**
     * 处理中间件
     * @param array $request 请求数据
     * @param callable $next 下一个处理函数
     * @return array 处理后的响应数据
     */
    public function handle($request, $next) {
        // 先执行下一个处理函数获取响应
        $response = $next($request);
        
        // 如果响应不是数组或JSON，直接返回
        if (!is_array($response)) {
            return $response;
        }
        
        // 获取用户角色（如果有）
        $user = isset($request['current_user']) ? $request['current_user'] : null;
        $userRole = isset($user['role']) ? $user['role'] : null;
        
        // 递归处理响应数据
        $maskedResponse = $this->maskRecursive($response, $userRole);
        
        return $maskedResponse;
    }
    
    /**
     * 递归脱敏数据
     * @param mixed $data 待脱敏数据
     * @param string $userRole 用户角色
     * @return mixed 脱敏后的数据
     */
    private function maskRecursive($data, $userRole) {
        if (is_array($data)) {
            $masked = [];
            foreach ($data as $key => $value) {
                // 检查键名是否为敏感字段
                $fieldKey = strtolower($key);
                $masked[$key] = $this->maskRecursive($value, $userRole);
                
                // 如果是数组中的敏感字段，进行脱敏处理
                if (isset($this->sensitiveFields[$fieldKey]) && is_string($masked[$key])) {
                    $maskType = $this->sensitiveFields[$fieldKey];
                    $masked[$key] = $this->maskField($masked[$key], $maskType, $userRole);
                }
            }
            return $masked;
        } elseif (is_object($data)) {
            // 处理对象数据
            $dataArray = (array) $data;
            $maskedArray = $this->maskRecursive($dataArray, $userRole);
            return (object) $maskedArray;
        }
        return $data;
    }
    
    /**
     * 对字段进行脱敏处理
     * @param string $value 字段值
     * @param string $maskType 脱敏类型
     * @param string $userRole 用户角色
     * @return string 脱敏后的值
     */
    private function maskField($value, $maskType, $userRole) {
        if (empty($value)) {
            return $value;
        }
        
        try {
            // 检查ComplianceManager类是否存在
            if (!class_exists('ComplianceManager')) {
                return $this->defaultMask($value);
            }
            
            // 使用ComplianceManager进行脱敏（支持基于角色的脱敏）
            if (method_exists('ComplianceManager', 'mask' . ucfirst($maskType))) {
                $method = 'mask' . ucfirst($maskType);
                return ComplianceManager::$method($value, $userRole);
            }
            
            // 回退到通用脱敏方法
            if (method_exists('ComplianceManager', 'maskSensitiveData')) {
                return ComplianceManager::maskSensitiveData($value, $maskType);
            }
            
            // 如果没有找到合适的方法，使用默认脱敏
            return $this->defaultMask($value);
        } catch (Exception $e) {
            // 如果脱敏失败，使用默认脱敏
            return $this->defaultMask($value);
        }
    }
    
    /**
     * 默认脱敏方法
     * @param string $value 字段值
     * @return string 脱敏后的值
     */
    private function defaultMask($value) {
        $length = strlen($value);
        if ($length <= 5) {
            return '***';
        }
        return substr($value, 0, 3) . str_repeat('*', $length - 5) . substr($value, -2);
    }
    
    /**
     * 获取响应头
     * @return array 中间件响应头
     */
    public function getHeaders() {
        return [
            'X-Data-Masked' => 'true',
            'X-Privacy-Protected' => 'true'
        ];
    }
}