<?php
/**
 * 安全异常检测中间件
 * 用于实时检测和预警异常访问模式
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

// 添加必要的文件引用
require_once __DIR__ . '/../router.php';

class SecurityAnomalyDetectionMiddleware {
    
    /**
     * 安全管理器实例
     * @var SecurityManager
     */
    private $securityManager;
    
    /**
     * 日志器实例
     * @var Logger
     */
    private $logger;
    
    /**
     * 异常检测配置
     * @var array
     */
    private $config;
    
    /**
     * 访问模式跟踪器
     * @var array
     */
    private $accessTracker = [];
    
    /**
     * 构造函数
     * @param SecurityManager $securityManager 安全管理器
     * @param Logger $logger 日志器
     */
    public function __construct($securityManager = null, $logger = null) {
        // 安全地初始化依赖项
        if (is_object($securityManager) && method_exists($securityManager, 'checkAnomaly')) {
            $this->securityManager = $securityManager;
        } elseif (class_exists('SecurityManager')) {
            try {
                $this->securityManager = new SecurityManager();
            } catch (Exception $e) {
                $this->securityManager = null;
            }
        } else {
            $this->securityManager = null;
        }
        
        if (is_object($logger) && method_exists($logger, 'info')) {
            $this->logger = $logger;
        } elseif (class_exists('Logger')) {
            try {
                $this->logger = new Logger();
            } catch (Exception $e) {
                $this->logger = null;
            }
        } else {
            $this->logger = null;
        }
        
        // 加载异常检测配置
        $configPath = dirname(__DIR__, 2) . '/includes/config/anomaly_detection.php';
        $this->config = file_exists($configPath) ? require $configPath : [];
        
        // 初始化访问跟踪器
        $this->initAccessTracker();
    }
    
    /**
     * 处理中间件
     * @param array $request 请求数据
     * @param callable $next 下一个处理函数
     * @return array 响应数据
     */
    public function handle($request, $next) {
        // 记录请求开始时间
        $startTime = microtime(true);
        
        // 获取客户端信息
        $clientInfo = $this->getClientInfo($request);
        
        // 如果安全管理器不可用，使用默认结果
        $anomalyResult = ['is_anomaly' => false];
        
        // 实时分析访问模式
        if (method_exists($this, 'detectAnomaly')) {
            $anomalyResult = $this->detectAnomaly($clientInfo, $request) ?? ['is_anomaly' => false];
        }
        
        // 如果检测到异常，记录并发出预警
        if (isset($anomalyResult['is_anomaly']) && $anomalyResult['is_anomaly']) {
            if (method_exists($this, 'logAnomaly')) {
                $this->logAnomaly($clientInfo, $request, $anomalyResult);
            }
            if (method_exists($this, 'triggerAlert')) {
                $this->triggerAlert($clientInfo, $request, $anomalyResult);
            }
            
            // 根据异常严重程度可能采取额外措施
            if ($anomalyResult['severity'] === 'high') {
                // 对于高危异常，可能需要额外的安全措施
                $this->applyAdditionalSecurityMeasures($clientInfo);
            }
        }
        
        // 更新访问跟踪器
        $this->updateAccessTracker($clientInfo, $request);
        
        // 处理请求
        $response = $next($request);
        
        // 记录请求结束时间并更新响应时间统计
        $endTime = microtime(true);
        $responseTime = ($endTime - $startTime) * 1000; // 毫秒
        $this->updateResponseTimeStats($clientInfo, $responseTime);
        
        return $response;
    }
    
    /**
     * 初始化访问跟踪器
     */
    private function initAccessTracker() {
        // 访问跟踪器存储结构：
        // - ip_address: IP地址的访问统计
        // - user_agent: 用户代理的访问统计
        // - path: 请求路径的访问统计
        // - time_pattern: 时间模式分析
        // - request_sequence: 请求序列模式
        $this->accessTracker = [
            'ip_address' => [],
            'user_agent' => [],
            'path' => [],
            'time_pattern' => [],
            'request_sequence' => [],
            'response_time' => [],
        ];
    }
    
    /**
     * 获取客户端信息
     * @param array $request 请求数据
     * @return array 客户端信息
     */
    private function getClientInfo($request) {
        // 获取客户端IP
        $clientIp = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $clientIp = trim(end($ips));
        }
        
        // 获取用户代理
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'unknown';
        
        // 获取请求方法
        $requestMethod = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'unknown';
        
        // 获取请求路径
        $requestPath = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : 'unknown';
        
        // 获取当前时间
        $currentTime = time();
        $hour = date('G', $currentTime); // 0-23小时
        $dayOfWeek = date('w', $currentTime); // 0-6星期几
        
        return [
            'ip' => $clientIp,
            'user_agent' => $userAgent,
            'request_method' => $requestMethod,
            'request_path' => $requestPath,
            'timestamp' => $currentTime,
            'hour' => $hour,
            'day_of_week' => $dayOfWeek,
        ];
    }
    
    /**
     * 检测异常访问模式
     * @param array $clientInfo 客户端信息
     * @param array $request 请求数据
     * @return array 异常检测结果
     */
    private function detectAnomaly($clientInfo, $request) {
        $anomalies = [];
        $severity = 'low';
        $isAnomaly = false;
        
        // 1. 检测访问频率异常
        $frequencyCheck = $this->checkAccessFrequency($clientInfo);
        if ($frequencyCheck['is_anomaly']) {
            $anomalies[] = $frequencyCheck['reason'];
            $isAnomaly = true;
            $severity = $this->updateSeverity($severity, $frequencyCheck['severity']);
        }
        
        // 2. 检测时间模式异常
        $timePatternCheck = $this->checkTimePattern($clientInfo);
        if ($timePatternCheck['is_anomaly']) {
            $anomalies[] = $timePatternCheck['reason'];
            $isAnomaly = true;
            $severity = $this->updateSeverity($severity, $timePatternCheck['severity']);
        }
        
        // 3. 检测请求路径异常
        $pathCheck = $this->checkPathPattern($clientInfo);
        if ($pathCheck['is_anomaly']) {
            $anomalies[] = $pathCheck['reason'];
            $isAnomaly = true;
            $severity = $this->updateSeverity($severity, $pathCheck['severity']);
        }
        
        // 4. 检测请求方法异常
        $methodCheck = $this->checkMethodPattern($clientInfo);
        if ($methodCheck['is_anomaly']) {
            $anomalies[] = $methodCheck['reason'];
            $isAnomaly = true;
            $severity = $this->updateSeverity($severity, $methodCheck['severity']);
        }
        
        // 5. 检测请求序列异常
        $sequenceCheck = $this->checkRequestSequence($clientInfo);
        if ($sequenceCheck['is_anomaly']) {
            $anomalies[] = $sequenceCheck['reason'];
            $isAnomaly = true;
            $severity = $this->updateSeverity($severity, $sequenceCheck['severity']);
        }
        
        return [
            'is_anomaly' => $isAnomaly,
            'severity' => $severity,
            'anomalies' => $anomalies,
            'client_info' => $clientInfo,
            'timestamp' => time(),
        ];
    }
    
    /**
     * 检查访问频率异常
     * @param array $clientInfo 客户端信息
     * @return array 频率检查结果
     */
    private function checkAccessFrequency($clientInfo) {
        $ip = $clientInfo['ip'];
        $currentTime = $clientInfo['timestamp'];
        
        // 初始化IP访问记录
        if (!isset($this->accessTracker['ip_address'][$ip])) {
            $this->accessTracker['ip_address'][$ip] = [
                'requests' => [],
                'last_request' => 0,
                'request_count_1m' => 0,
                'request_count_5m' => 0,
                'request_count_15m' => 0,
            ];
        }
        
        // 更新请求记录
        $ipTracker = &$this->accessTracker['ip_address'][$ip];
        $ipTracker['requests'][] = $currentTime;
        $ipTracker['last_request'] = $currentTime;
        
        // 清理过期记录
        $this->cleanupOldRequests($ipTracker['requests'], $currentTime, 900); // 保留15分钟内的请求
        
        // 计算不同时间窗口的请求数
        $ipTracker['request_count_1m'] = $this->countRequestsInWindow($ipTracker['requests'], $currentTime, 60);
        $ipTracker['request_count_5m'] = $this->countRequestsInWindow($ipTracker['requests'], $currentTime, 300);
        $ipTracker['request_count_15m'] = $this->countRequestsInWindow($ipTracker['requests'], $currentTime, 900);
        
        // 检查异常频率阈值
        $thresholds = [
            'high' => 60,  // 1分钟内60次请求为高危
            'medium' => 30, // 1分钟内30次请求为中危
            'low' => 15,    // 1分钟内15次请求为低危
        ];
        
        if ($ipTracker['request_count_1m'] >= $thresholds['high']) {
            return [
                'is_anomaly' => true,
                'severity' => 'high',
                'reason' => "IP访问频率过高: {$ip} 在1分钟内发送了 {$ipTracker['request_count_1m']} 次请求",
            ];
        } elseif ($ipTracker['request_count_1m'] >= $thresholds['medium']) {
            return [
                'is_anomaly' => true,
                'severity' => 'medium',
                'reason' => "IP访问频率较高: {$ip} 在1分钟内发送了 {$ipTracker['request_count_1m']} 次请求",
            ];
        } elseif ($ipTracker['request_count_1m'] >= $thresholds['low']) {
            return [
                'is_anomaly' => true,
                'severity' => 'low',
                'reason' => "IP访问频率略高: {$ip} 在1分钟内发送了 {$ipTracker['request_count_1m']} 次请求",
            ];
        }
        
        return [
            'is_anomaly' => false,
            'severity' => 'low',
            'reason' => '访问频率正常',
        ];
    }
    
    /**
     * 检查时间模式异常
     * @param array $clientInfo 客户端信息
     * @return array 时间模式检查结果
     */
    private function checkTimePattern($clientInfo) {
        $ip = $clientInfo['ip'];
        $hour = $clientInfo['hour'];
        $dayOfWeek = $clientInfo['day_of_week'];
        
        // 初始化时间模式记录
        if (!isset($this->accessTracker['time_pattern'][$ip])) {
            $this->accessTracker['time_pattern'][$ip] = [
                'hourly_distribution' => array_fill(0, 24, 0),
                'weekly_distribution' => array_fill(0, 7, 0),
                'total_requests' => 0,
            ];
        }
        
        $timeTracker = &$this->accessTracker['time_pattern'][$ip];
        $timeTracker['hourly_distribution'][$hour]++;
        $timeTracker['weekly_distribution'][$dayOfWeek]++;
        $timeTracker['total_requests']++;
        
        // 只有当收集了足够的历史数据后才进行时间模式分析
        if ($timeTracker['total_requests'] < 20) {
            return [
                'is_anomaly' => false,
                'severity' => 'low',
                'reason' => '历史数据不足',
            ];
        }
        
        // 计算小时和星期的访问比例
        $hourRatio = $timeTracker['hourly_distribution'][$hour] / $timeTracker['total_requests'];
        $dayRatio = $timeTracker['weekly_distribution'][$dayOfWeek] / $timeTracker['total_requests'];
        
        // 异常时间判断：
        // 1. 深夜访问（23:00-5:00）且历史访问较少
        if (($hour >= 23 || $hour <= 5) && $hourRatio < 0.05) {
            return [
                'is_anomaly' => true,
                'severity' => 'medium',
                'reason' => "异常时间访问: {$ip} 在历史访问较少的时间段 ({$hour}:00) 进行访问",
            ];
        }
        
        // 2. 周末访问模式异常
        if ($dayOfWeek >= 5 && $dayRatio < 0.05) {
            return [
                'is_anomaly' => true,
                'severity' => 'low',
                'reason' => "异常日期访问: {$ip} 在历史访问较少的星期几进行访问",
            ];
        }
        
        return [
            'is_anomaly' => false,
            'severity' => 'low',
            'reason' => '时间模式正常',
        ];
    }
    
    /**
     * 检查路径模式异常
     * @param array $clientInfo 客户端信息
     * @return array 路径模式检查结果
     */
    private function checkPathPattern($clientInfo) {
        $ip = $clientInfo['ip'];
        $requestPath = $clientInfo['request_path'];
        $requestMethod = $clientInfo['request_method'];
        
        // 敏感路径列表
        $sensitivePaths = [
            '/api/admin',
            '/api/user/password',
            '/api/auth/reset',
            '/api/payment',
            '/api/card/verify',
        ];
        
        // 检查是否访问敏感路径
        foreach ($sensitivePaths as $sensitivePath) {
            if (strpos($requestPath, $sensitivePath) === 0) {
                // 初始化敏感路径访问记录
                if (!isset($this->accessTracker['path'][$ip]['sensitive'])) {
                    $this->accessTracker['path'][$ip]['sensitive'] = [];
                }
                
                $this->accessTracker['path'][$ip]['sensitive'][] = [
                    'path' => $requestPath,
                    'method' => $requestMethod,
                    'timestamp' => time(),
                ];
                
                // 如果短时间内多次访问不同敏感路径，可能是探测行为
                $sensitiveCount = count($this->accessTracker['path'][$ip]['sensitive']);
                if ($sensitiveCount > 3) {
                    return [
                        'is_anomaly' => true,
                        'severity' => 'high',
                        'reason' => "敏感路径探测: {$ip} 在短时间内访问了 {$sensitiveCount} 个不同的敏感路径",
                    ];
                }
                
                return [
                    'is_anomaly' => true,
                    'severity' => 'medium',
                    'reason' => "敏感路径访问: {$ip} 访问了敏感路径 {$requestPath}",
                ];
            }
        }
        
        // 检查是否有可疑的路径模式（如SQL注入、XSS尝试的特征）
        $suspiciousPatterns = [
            '/\bunion\b/i',
            '/\bselect\b.+\bfrom\b/i',
            '/\bdrop\b.+\btable\b/i',
            '/<script[^>]*>/i',
            '/\balert\s*\(/i',
            '/\bon\w+\s*=/i',
            '/\bexec\b/i',
            '/\beval\b/i',
        ];
        
        foreach ($suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $requestPath)) {
                return [
                    'is_anomaly' => true,
                    'severity' => 'high',
                    'reason' => "可疑路径模式: {$ip} 请求了可能包含攻击特征的路径 {$requestPath}",
                ];
            }
        }
        
        return [
            'is_anomaly' => false,
            'severity' => 'low',
            'reason' => '路径模式正常',
        ];
    }
    
    /**
     * 检查请求方法异常
     * @param array $clientInfo 客户端信息
     * @return array 方法模式检查结果
     */
    private function checkMethodPattern($clientInfo) {
        $ip = $clientInfo['ip'];
        $requestMethod = $clientInfo['request_method'];
        
        // 初始化方法访问记录
        if (!isset($this->accessTracker['user_agent'][$ip]['methods'])) {
            $this->accessTracker['user_agent'][$ip]['methods'] = [];
        }
        
        // 记录请求方法
        $methodKey = strtolower($requestMethod);
        if (!isset($this->accessTracker['user_agent'][$ip]['methods'][$methodKey])) {
            $this->accessTracker['user_agent'][$ip]['methods'][$methodKey] = 0;
        }
        $this->accessTracker['user_agent'][$ip]['methods'][$methodKey]++;
        
        // 检查异常的方法组合（如短时间内使用多种方法）
        $methodCount = count($this->accessTracker['user_agent'][$ip]['methods']);
        $totalRequests = array_sum($this->accessTracker['user_agent'][$ip]['methods']);
        
        if ($methodCount > 3 && $totalRequests < 10) {
            return [
                'is_anomaly' => true,
                'severity' => 'medium',
                'reason' => "异常方法组合: {$ip} 在短时间内使用了 {$methodCount} 种不同的请求方法",
            ];
        }
        
        // 检查是否频繁使用不安全的方法
        $unsafeMethods = ['post', 'put', 'delete', 'patch'];
        $unsafeCount = 0;
        foreach ($unsafeMethods as $method) {
            if (isset($this->accessTracker['user_agent'][$ip]['methods'][$method])) {
                $unsafeCount += $this->accessTracker['user_agent'][$ip]['methods'][$method];
            }
        }
        
        if ($totalRequests > 0 && ($unsafeCount / $totalRequests) > 0.8) {
            return [
                'is_anomaly' => true,
                'severity' => 'medium',
                'reason' => "不安全方法滥用: {$ip} 的请求中 {$unsafeCount}/{$totalRequests} 是不安全的方法",
            ];
        }
        
        return [
            'is_anomaly' => false,
            'severity' => 'low',
            'reason' => '方法模式正常',
        ];
    }
    
    /**
     * 检查请求序列异常
     * @param array $clientInfo 客户端信息
     * @return array 序列检查结果
     */
    private function checkRequestSequence($clientInfo) {
        $ip = $clientInfo['ip'];
        $requestPath = $clientInfo['request_path'];
        $requestMethod = $clientInfo['request_method'];
        
        // 初始化请求序列
        if (!isset($this->accessTracker['request_sequence'][$ip])) {
            $this->accessTracker['request_sequence'][$ip] = [];
        }
        
        // 添加当前请求到序列
        $sequenceTracker = &$this->accessTracker['request_sequence'][$ip];
        $sequenceTracker[] = [
            'path' => $requestPath,
            'method' => $requestMethod,
            'timestamp' => time(),
        ];
        
        // 保留最近10个请求
        if (count($sequenceTracker) > 10) {
            array_shift($sequenceTracker);
        }
        
        // 检查重复请求序列（可能是爬虫）
        if (count($sequenceTracker) >= 5) {
            $recentPaths = array_column(array_slice($sequenceTracker, -5), 'path');
            if (count(array_unique($recentPaths)) <= 2) {
                return [
                    'is_anomaly' => true,
                    'severity' => 'medium',
                    'reason' => "重复请求序列: {$ip} 发送了高度重复的请求序列",
                ];
            }
        }
        
        // 检查是否有暴力破解的特征（如短时间内多次请求登录接口）
        $loginPaths = ['/api/auth/login', '/api/user/login', '/api/login'];
        $recentRequests = array_slice($sequenceTracker, -30); // 最近30个请求
        $loginAttempts = 0;
        
        foreach ($recentRequests as $req) {
            if (in_array($req['path'], $loginPaths) && time() - $req['timestamp'] < 300) { // 5分钟内
                $loginAttempts++;
            }
        }
        
        if ($loginAttempts >= 5) {
            return [
                'is_anomaly' => true,
                'severity' => 'high',
                'reason' => "可能的暴力破解: {$ip} 在5分钟内进行了 {$loginAttempts} 次登录尝试",
            ];
        }
        
        return [
            'is_anomaly' => false,
            'severity' => 'low',
            'reason' => '请求序列正常',
        ];
    }
    
    /**
     * 更新访问跟踪器
     * @param array $clientInfo 客户端信息
     * @param array $request 请求数据
     */
    private function updateAccessTracker($clientInfo, $request) {
        // 可以在这里添加额外的跟踪逻辑
        // 例如：跟踪用户会话、请求大小等
    }
    
    /**
     * 更新响应时间统计
     * @param array $clientInfo 客户端信息
     * @param float $responseTime 响应时间（毫秒）
     */
    private function updateResponseTimeStats($clientInfo, $responseTime) {
        $ip = $clientInfo['ip'];
        
        if (!isset($this->accessTracker['response_time'][$ip])) {
            $this->accessTracker['response_time'][$ip] = [
                'times' => [],
                'avg_time' => 0,
                'max_time' => 0,
            ];
        }
        
        $timeTracker = &$this->accessTracker['response_time'][$ip];
        $timeTracker['times'][] = $responseTime;
        $timeTracker['max_time'] = max($timeTracker['max_time'], $responseTime);
        $timeTracker['avg_time'] = array_sum($timeTracker['times']) / count($timeTracker['times']);
        
        // 保留最近100个响应时间记录
        if (count($timeTracker['times']) > 100) {
            array_shift($timeTracker['times']);
        }
        
        // 如果响应时间异常长，可能是资源耗尽攻击
        if ($responseTime > 5000) { // 5秒
            $this->logAnomaly(
                $clientInfo,
                [],
                [
                    'is_anomaly' => true,
                    'severity' => 'medium',
                    'anomalies' => ["异常响应时间: {$ip} 的请求响应时间为 {$responseTime}ms，可能存在资源耗尽攻击"],
                ]
            );
        }
    }
    
    /**
     * 清理过期的请求记录
     * @param array $requests 请求记录数组
     * @param int $currentTime 当前时间戳
     * @param int $window 时间窗口（秒）
     */
    private function cleanupOldRequests(&$requests, $currentTime, $window) {
        $cutoffTime = $currentTime - $window;
        $requests = array_filter($requests, function($timestamp) use ($cutoffTime) {
            return $timestamp >= $cutoffTime;
        });
    }
    
    /**
     * 计算时间窗口内的请求数
     * @param array $requests 请求记录数组
     * @param int $currentTime 当前时间戳
     * @param int $window 时间窗口（秒）
     * @return int 请求数
     */
    private function countRequestsInWindow($requests, $currentTime, $window) {
        $cutoffTime = $currentTime - $window;
        $count = 0;
        
        foreach ($requests as $timestamp) {
            if ($timestamp >= $cutoffTime) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * 更新严重程度
     * @param string $current 当前严重程度
     * @param string $new 新的严重程度
     * @return string 更新后的严重程度
     */
    private function updateSeverity($current, $new) {
        $severityLevels = ['low', 'medium', 'high'];
        $currentLevel = array_search($current, $severityLevels);
        $newLevel = array_search($new, $severityLevels);
        
        return ($newLevel > $currentLevel) ? $new : $current;
    }
    
    /**
     * 记录异常
     * @param array $clientInfo 客户端信息
     * @param array $request 请求数据
     * @param array $anomalyResult 异常检测结果
     */
    private function logAnomaly($clientInfo, $request, $anomalyResult) {
        $logData = [
            'timestamp' => $anomalyResult['timestamp'],
            'severity' => $anomalyResult['severity'],
            'client_info' => $clientInfo,
            'anomalies' => $anomalyResult['anomalies'],
            'request_data' => $this->sanitizeRequestData($request),
        ];
        
        // 使用安全管理器记录安全事件
        if ($this->securityManager && method_exists($this->securityManager, 'logSecurity')) {
            $this->securityManager->logSecurity(
                strtoupper($anomalyResult['severity']),
                '安全异常检测',
                $logData
            );
        }
        
        // 也可以写入专门的安全异常日志表
        if (method_exists($this->securityManager, 'logAnomaly')) {
            $this->securityManager->logAnomaly($logData);
        }
    }
    
    /**
     * 触发预警
     * @param array $clientInfo 客户端信息
     * @param array $request 请求数据
     * @param array $anomalyResult 异常检测结果
     */
    private function triggerAlert($clientInfo, $request, $anomalyResult) {
        // 只有中高风险才触发预警
        if (!in_array($anomalyResult['severity'], ['medium', 'high'])) {
            return;
        }
        
        // 根据配置确定通知渠道
        $channels = $this->getNotificationChannels($anomalyResult['severity']);
        
        // 构建预警消息
        $message = $this->buildAlertMessage($clientInfo, $anomalyResult);
        
        // 发送预警
        foreach ($channels as $channel) {
            try {
                $this->sendNotification($channel, $message, $anomalyResult);
            } catch (Exception $e) {
                // 记录通知失败
                if ($this->logger) {
                    $this->logger->error("预警发送失败 ({$channel}): " . $e->getMessage());
                }
            }
        }
    }
    
    /**
     * 获取通知渠道
     * @param string $severity 严重程度
     * @return array 通知渠道数组
     */
    private function getNotificationChannels($severity) {
        // 从配置中获取通知渠道
        if (isset($this->config['notifications']['rules']['escalation']['rules'])) {
            foreach ($this->config['notifications']['rules']['escalation']['rules'] as $rule) {
                if ($rule['severity'] === $severity) {
                    return $rule['channels'];
                }
            }
        }
        
        // 默认通知渠道
        $channels = ['email'];
        if ($severity === 'high') {
            $channels[] = 'sms';
        }
        
        return $channels;
    }
    
    /**
     * 构建预警消息
     * @param array $clientInfo 客户端信息
     * @param array $anomalyResult 异常检测结果
     * @return array 预警消息数组
     */
    private function buildAlertMessage($clientInfo, $anomalyResult) {
        $severityText = [
            'low' => '低风险',
            'medium' => '中风险',
            'high' => '高风险',
        ];
        
        $subject = "[安全预警] {$severityText[$anomalyResult['severity']]} - IP: {$clientInfo['ip']} 异常访问";
        
        $body = "安全异常检测系统预警\n" .
               "\n严重程度: {$severityText[$anomalyResult['severity']]}"
               . "\n检测时间: " . date('Y-m-d H:i:s', $anomalyResult['timestamp'])
               . "\nIP地址: {$clientInfo['ip']}"
               . "\n请求方法: {$clientInfo['request_method']}"
               . "\n请求路径: {$clientInfo['request_path']}"
               . "\n\n异常详情:\n";
        
        foreach ($anomalyResult['anomalies'] as $anomaly) {
            $body .= "- {$anomaly}\n";
        }
        
        $body .= "\n请及时处理并调查异常原因。";
        
        return [
            'subject' => $subject,
            'body' => $body,
            'severity' => $anomalyResult['severity'],
        ];
    }
    
    /**
     * 发送通知
     * @param string $channel 通知渠道
     * @param array $message 消息内容
     * @param array $anomalyResult 异常检测结果
     */
    private function sendNotification($channel, $message, $anomalyResult) {
        // 获取通知接收人
        $recipients = $this->getNotificationRecipients($channel);
        
        if (empty($recipients)) {
            return;
        }
        
        // 根据不同渠道发送通知
        switch ($channel) {
            case 'email':
                $this->sendEmailNotification($recipients, $message);
                break;
                
            case 'sms':
                $this->sendSmsNotification($recipients, $message);
                break;
                
            case 'wechat':
                $this->sendWechatNotification($recipients, $message);
                break;
        }
    }
    
    /**
     * 获取通知接收人
     * @param string $channel 通知渠道
     * @return array 接收人数组
     */
    private function getNotificationRecipients($channel) {
        if (isset($this->config['notifications']['recipients'][$channel])) {
            return $this->config['notifications']['recipients'][$channel];
        }
        
        // 默认接收人
        $defaults = [
            'email' => ['admin@example.com'],
            'sms' => ['13800138000'],
            'wechat' => ['admin_id'],
        ];
        
        return isset($defaults[$channel]) ? $defaults[$channel] : [];
    }
    
    /**
     * 发送邮件通知
     * @param array $recipients 收件人
     * @param array $message 消息内容
     */
    private function sendEmailNotification($recipients, $message) {
        // 这里可以实现邮件发送逻辑
        // 由于环境限制，这里只是记录日志
        if ($this->logger) {
            $this->logger->info("邮件通知: 发送到 " . implode(', ', $recipients) . ", 主题: " . $message['subject']);
        }
    }
    
    /**
     * 发送短信通知
     * @param array $recipients 收件人
     * @param array $message 消息内容
     */
    private function sendSmsNotification($recipients, $message) {
        // 短信内容需要简洁
        $smsBody = substr($message['subject'] . " " . $message['body'], 0, 150);
        
        // 这里可以实现短信发送逻辑
        if ($this->logger) {
            $this->logger->info("短信通知: 发送到 " . implode(', ', $recipients) . ", 内容: " . $smsBody);
        }
    }
    
    /**
     * 发送微信通知
     * @param array $recipients 收件人
     * @param array $message 消息内容
     */
    private function sendWechatNotification($recipients, $message) {
        // 这里可以实现微信消息发送逻辑
        if ($this->logger) {
            $this->logger->info("微信通知: 发送到 " . implode(', ', $recipients) . ", 主题: " . $message['subject']);
        }
    }
    
    /**
     * 应用额外的安全措施
     * @param array $clientInfo 客户端信息
     */
    private function applyAdditionalSecurityMeasures($clientInfo) {
        // 对于高危异常，可以采取一些额外的安全措施
        $ip = $clientInfo['ip'];
        
        // 1. 可以临时限制该IP的访问频率
        if (method_exists($this->securityManager, 'rateLimitIp')) {
            $this->securityManager->rateLimitIp($ip, 300); // 限制5分钟
        }
        
        // 2. 可以记录到可疑IP列表
        if (method_exists($this->securityManager, 'flagSuspiciousIp')) {
            $this->securityManager->flagSuspiciousIp($ip);
        }
    }
    
    /**
     * 清理请求数据中的敏感信息
     * @param array $requestData 请求数据
     * @return array 清理后的数据
     */
    private function sanitizeRequestData($requestData) {
        if (!is_array($requestData)) {
            return $requestData;
        }
        
        $sensitiveKeys = ['password', 'token', 'api_key', 'secret', 'credit_card', 'id_card'];
        $sanitized = [];
        
        foreach ($requestData as $key => $value) {
            $keyLower = strtolower($key);
            $isSensitive = false;
            
            foreach ($sensitiveKeys as $sensitiveKey) {
                if (strpos($keyLower, $sensitiveKey) !== false) {
                    $isSensitive = true;
                    break;
                }
            }
            
            if ($isSensitive) {
                $sanitized[$key] = '[REDACTED]';
            } elseif (is_array($value)) {
                $sanitized[$key] = $this->sanitizeRequestData($value);
            } else {
                $sanitized[$key] = $value;
            }
        }
        
        return $sanitized;
    }
    
    /**
     * 获取当前的访问跟踪统计
     * @return array 访问统计数据
     */
    public function getAccessStats() {
        return [
            'total_ips' => count($this->accessTracker['ip_address']),
            'tracker_status' => 'active',
            'memory_usage' => memory_get_usage(),
            'timestamp' => time(),
        ];
    }
}