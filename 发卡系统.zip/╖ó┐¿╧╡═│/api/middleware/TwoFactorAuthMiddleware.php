<?php
/**
 * 二次验证中间件
 * 用于拦截敏感操作请求并验证二次验证状态
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

// 添加必要的文件引用
require_once __DIR__ . '/../router.php';

class TwoFactorAuthMiddleware {
    
    /**
     * 中间件处理函数
     * @param array $request 请求数据
     * @param callable $next 下一个中间件
     * @return array 响应数据
     */
    public function handle($request, $next) {
        // 确保AuthManager类已加载
        if (!class_exists('AuthManager')) {
            $authManagerPath = dirname(__DIR__) . '/includes/AuthManager.php';
            if (file_exists($authManagerPath)) {
                require_once $authManagerPath;
            } else {
                // 如果AuthManager类不存在，记录警告并允许请求继续
                error_log('AuthManager class not found, skipping two-factor authentication');
                return $next($request);
            }
        }
        
        // 安全地获取AuthManager实例
        $auth = null;
        if (class_exists('AuthManager') && method_exists('AuthManager', 'getInstance')) {
            try {
                $auth = AuthManager::getInstance();
            } catch (Exception $e) {
                error_log('Failed to get AuthManager instance: ' . $e->getMessage());
                return $next($request);
            }
        }
        
        if (!$auth) {
            return $next($request);
        }
        
        // 安全地获取当前用户ID
        $userId = 0;
        if (method_exists($auth, 'getCurrentUser')) {
            $currentUser = $auth->getCurrentUser();
            if (is_array($currentUser) && isset($currentUser['id'])) {
                $userId = $currentUser['id'] ?? 0;
            }
        }
        
        if (!$userId) {
            return ['success' => false, 'error' => '请先登录'];
        }
        
        // 从请求中提取操作类型
        $operation = $this->extractOperation($request);
        
        if (!$operation) {
            // 无法识别操作类型，让请求通过
            return $next($request);
        }
        
        // 安全地检查是否需要二次验证
        $requiresTwoFactor = false;
        if (method_exists($auth, 'requireTwoFactor')) {
            $requiresTwoFactor = $auth->requireTwoFactor($operation);
        }
        
        if ($requiresTwoFactor) {
            // 安全地检查是否已通过二次验证
            $isVerified = true;
            if (method_exists($auth, 'isTwoFactorVerified')) {
                $isVerified = $auth->isTwoFactorVerified($userId);
            }
            
            if (!$isVerified) {
                // 检查请求中是否包含验证码
                if (isset($request['two_factor_code'])) {
                    // 安全地验证提供的验证码
                    $verified = false;
                    if (method_exists($auth, 'verifyTwoFactor')) {
                        $verified = $auth->verifyTwoFactor($userId, $request['two_factor_code']);
                    }
                    
                    if (!$verified) {
                        return [
                            'success' => false, 
                            'error' => '验证码无效或已过期',
                            'require_verification' => true,
                            'operation' => $operation
                        ];
                    }
                    
                    // 验证码验证成功，继续处理请求
                } else {
                    // 需要发送验证码并要求用户输入
                    // 发送验证码
                    $sendResult = $auth->sendTwoFactorCode($userId);
                    
                    if (!$sendResult['success']) {
                        return [
                            'success' => false, 
                            'error' => $sendResult['error'],
                            'cooldown' => $sendResult['cooldown'] ?? 0
                        ];
                    }
                    
                    // 返回需要二次验证的响应
                    return [
                        'success' => false, 
                        'require_verification' => true,
                        'operation' => $operation,
                        'message' => '请输入验证码'
                    ];
                }
            }
        }
        
        // 不需要验证或已通过验证，继续处理请求
        return $next($request);
    }
    
    /**
     * 从请求中提取操作类型
     * @param array $request 请求数据
     * @return string 操作类型
     */
    private function extractOperation($request) {
        // 从路由参数中提取操作类型
        $operation = $request['route_params']['action'] ?? '';
        
        // 从请求体中提取操作类型
        if (!$operation) {
            $operation = $request['data']['operation'] ?? $request['data']['action'] ?? '';
        }
        
        // 如果没有明确的操作类型，根据控制器和方法推断
        if (!$operation && isset($request['route_params']['controller'], $request['route_params']['method'])) {
            $controller = $request['route_params']['controller'];
            $method = $request['route_params']['method'];
            
            // 映射常见的控制器和方法到操作类型
            $operationMap = [
                'user' => [
                    'delete' => 'user_delete',
                    'update' => 'user_manage',
                    'manage' => 'user_manage'
                ],
                'system' => [
                    'config' => 'system_config',
                    'update_config' => 'system_config_core'
                ],
                'card' => [
                    'delete' => 'card_delete',
                    'batch_issue' => 'card_batch_issue'
                ],
                'export' => [
                    'data' => 'export_data',
                    'all' => 'export_all_data'
                ],
                'payment' => [
                    'process' => 'payment_process',
                    'refund' => 'refund_process'
                ],
                'security' => [
                    'blacklist' => 'blacklist_add',
                    'permission_change' => 'permission_change'
                ]
            ];
            
            if (isset($operationMap[$controller], $operationMap[$controller][$method])) {
                $operation = $operationMap[$controller][$method];
            }
        }
        
        return $operation;
    }
}