<?php
/**
 * 地理位置验证中间件
 * 实现基于IP的地理围栏功能，限制特定国家/地区的访问
 * 
 * @package api/middleware
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

require_once __DIR__ . '/../router.php';
require_once __DIR__ . '/../../includes/IPAddressManager.php';
require_once __DIR__ . '/../../includes/security/SecurityConfig.php';

/**
 * 地理位置验证中间件
 * 检查客户端IP的地理位置，限制只允许特定国家/地区访问系统
 */
class GeoLocationMiddleware {
    /**
     * IP地址管理器实例
     * @var IPAddressManager
     */
    private $ipManager;
    
    /**
     * 安全配置实例
     * @var SecurityConfig
     */
    private $securityConfig;
    
    /**
     * 允许的国家/地区列表
     * @var array
     */
    private $allowedCountries = [];
    
    /**
     * 禁止的国家/地区列表
     * @var array
     */
    private $blockedCountries = [];
    
    /**
     * 豁免的IP地址列表
     * @var array
     */
    private $exemptIps = [];
    
    /**
     * 是否启用地理位置验证
     * @var bool
     */
    private $enabled = false;
    
    /**
     * 构造函数
     * @param array $options 中间件配置选项
     */
    public function __construct(array $options = []) {
        // 初始化IP地址管理器 - 直接实例化而不是使用可能不存在的函数
        $this->ipManager = class_exists('IPAddressManager') ? new IPAddressManager() : null;
        
        // 初始化安全配置
        $this->securityConfig = class_exists('SecurityConfig') && method_exists('SecurityConfig', 'getInstance') 
            ? SecurityConfig::getInstance() 
            : null;
        
        // 从安全配置中加载地理位置相关配置
        $ipFilteringConfig = $this->securityConfig->get('ip_filtering', []);
        
        // 设置是否启用
        $this->enabled = $options['enabled'] ?? $ipFilteringConfig['enabled'] ?? false;
        
        // 设置允许的国家/地区列表
        $this->allowedCountries = $options['allowed_countries'] ?? $ipFilteringConfig['allowed_countries'] ?? [];
        
        // 设置禁止的国家/地区列表
        $this->blockedCountries = $options['blocked_countries'] ?? $ipFilteringConfig['blocked_countries'] ?? [];
        
        // 设置豁免的IP地址列表
        $this->exemptIps = $options['exempt_ips'] ?? [];
    }
    
    /**
     * 执行中间件逻辑
     * @param array $context 请求上下文
     * @param callable $next 下一个中间件或处理器
     * @return array 处理结果
     */
    public function handle(array $context, callable $next) {
        // 如果地理位置验证未启用，直接通过
        if (!$this->enabled) {
            return $next($context);
        }
        
        // 获取客户端IP地址
        $clientIp = $context['client_ip'] ?? $this->ipManager->getClientIP();
        
        // 检查IP是否在豁免列表中
        if ($this->isExemptIp($clientIp)) {
            // 安全地记录日志
            if (isset($context['logger']) && is_object($context['logger']) && method_exists($context['logger'], 'info')) {
                $context['logger']->info('IP address exempt from geolocation check', ['ip' => $clientIp]);
            }
            return $next($context);
        }
        
        try {
            // 获取IP的地理位置信息
            $geoInfo = $this->ipManager->getGeoLocation($clientIp);
            $country = $geoInfo['country'] ?? 'Unknown';
            
            // 记录地理位置信息 - 安全地访问logger
            if (isset($context['logger']) && is_object($context['logger']) && method_exists($context['logger'], 'info')) {
                $context['logger']->info('Client IP geolocation information', [
                    'ip' => $clientIp,
                    'country' => $country,
                    'region' => $geoInfo['region'] ?? 'Unknown',
                    'city' => $geoInfo['city'] ?? 'Unknown',
                    'accuracy' => $geoInfo['accuracy'] ?? 'unknown'
                ]);
            }
            
            // 检查是否允许访问
            if (!$this->isAllowedLocation($clientIp, $country)) {
                // 记录被禁止的访问 - 安全地访问logger
                if (isset($context['logger']) && is_object($context['logger']) && method_exists($context['logger'], 'warning')) {
                    $context['logger']->warning('Access denied due to geolocation restriction', [
                    'ip' => $clientIp,
                    'country' => $country,
                    'request_path' => $context['request_path'],
                    'request_method' => $context['request_method']
                ]);
                }
                
                // 返回403禁止访问响应
                return [
                    'status' => 403,
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'X-Geo-Restricted' => 'true',
                        'X-Your-Country' => $country
                    ],
                    'body' => json_encode([
                        'error' => 'GEOLOCATION_RESTRICTED',
                        'message' => 'Access from your location is not allowed',
                        'code' => 403,
                        'request_id' => $context['request_id']
                    ])
                ];
            }
            
            // 将地理位置信息添加到上下文
            $context['geo_location'] = $geoInfo;
            
            // 继续处理请求
            return $next($context);
        } catch (Exception $e) {
            // 记录地理位置验证失败的异常 - 安全地访问logger
            if (isset($context['logger']) && is_object($context['logger']) && method_exists($context['logger'], 'error')) {
                $context['logger']->error('Geolocation verification failed', [
                    'ip' => $clientIp,
                    'error' => $e->getMessage(),
                    'stack_trace' => $e->getTraceAsString()
                ]);
            }
            
            // 配置决定在地理位置验证失败时是阻止还是允许访问
            $blockOnFailure = $this->securityConfig && method_exists($this->securityConfig, 'get') 
                ? $this->securityConfig->get('ip_filtering.block_on_geo_failure', false) 
                : false;
            
            if ($blockOnFailure) {
                // 如果配置为失败时阻止访问，返回403响应
                return [
                    'status' => 403,
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'X-Geo-Verification-Failed' => 'true'
                    ],
                    'body' => json_encode([
                        'error' => 'GEO_VERIFICATION_FAILED',
                        'message' => 'Unable to verify your location',
                        'code' => 403,
                        'request_id' => $context['request_id']
                    ])
                ];
            } else {
                // 如果配置为失败时允许访问，继续处理请求
                // 但添加警告信息到上下文
                $context['geo_verification_warning'] = 'Failed to verify geolocation';
                return $next($context);
            }
        }
    }
    
    /**
     * 检查IP是否在豁免列表中
     * @param string $ip IP地址
     * @return bool 是否在豁免列表中
     */
    private function isExemptIp($ip) {
        // 检查是否为本地IP
        $isLocal = $this->isLocalIp($ip);
        if ($isLocal) {
            return true;
        }
        
        // 检查IP是否在明确的豁免列表中
        return in_array($ip, $this->exemptIps);
    }
    
    /**
     * 检查是否为本地IP
     * @param string $ip IP地址
     * @return bool 是否为本地IP
     */
    private function isLocalIp($ip) {
        // 检查IPv4本地地址
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE) === false) {
            return true;
        }
        
        // 检查IPv6本地地址
        $localIpv6Patterns = [
            '^::1$',  // IPv6环回地址
            '^fe80:', // 链路本地地址
            '^fc00:', // 唯一本地地址
            '^fd00:'  // 唯一本地地址
        ];
        
        foreach ($localIpv6Patterns as $pattern) {
            if (preg_match('/' . $pattern . '/i', $ip)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 检查地理位置是否允许访问
     * @param string $ip IP地址
     * @param string $country 国家/地区
     * @return bool 是否允许访问
     */
    private function isAllowedLocation($ip, $country) {
        // 如果允许的国家/地区列表为空，则允许所有国家/地区访问
        if (empty($this->allowedCountries)) {
            // 但检查是否在禁止列表中
            return !$this->isBlockedCountry($country);
        }
        
        // 检查国家是否在允许列表中
        return $this->ipManager->isAllowedCountry($ip, $this->allowedCountries);
    }
    
    /**
     * 检查国家是否在禁止列表中
     * @param string $country 国家/地区
     * @return bool 是否在禁止列表中
     */
    private function isBlockedCountry($country) {
        // 如果禁止的国家/地区列表为空，则没有禁止的国家/地区
        if (empty($this->blockedCountries)) {
            return false;
        }
        
        // 检查国家是否在禁止列表中
        return in_array($country, $this->blockedCountries) || 
               in_array(strtoupper($country), array_map('strtoupper', $this->blockedCountries));
    }
    
    /**
     * 创建地理位置验证中间件的工厂方法
     * @param array $options 中间件配置选项
     * @return callable 中间件处理函数
     */
    public static function create(array $options = []) {
        return function($context, $next) use ($options) {
            $middleware = new self($options);
            return $middleware->handle($context, $next);
        };
    }
    
    /**
     * 获取地理位置中间件的默认配置
     * @return array 默认配置
     */
    public static function getDefaultOptions() {
        return [
            'enabled' => true,
            'allowed_countries' => [], // 空数组表示允许所有国家/地区
            'blocked_countries' => [], // 明确禁止的国家/地区
            'exempt_ips' => [
                '127.0.0.1', // 本地回环地址
                '::1'        // IPv6本地回环地址
            ]
        ];
    }
}

/**
 * 地理位置验证中间件函数
 * 方便在路由中直接使用
 * @param array $options 中间件配置选项
 * @return callable 中间件处理函数
 */
function geoLocationMiddleware(array $options = []) {
    return GeoLocationMiddleware::create($options);
}