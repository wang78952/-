# 发卡系统 RESTful API 完整文档

## 概述

本文档描述了发卡系统的完整 RESTful API 接口，包括用户认证、卡片管理、订单管理、产品管理、身份核验、系统统计、合规检查等功能。

## 基础信息

- **Base URL**: `http://your-domain.com/api`
- **Content-Type**: `application/json`
- **认证方式**: Bearer Token
- **API版本**: v1.0
- **字符编码**: UTF-8

## 认证

### 获取API Token
所有需要认证的接口都需要在请求头中包含有效的 API Token：

```
Authorization: Bearer {your_api_token}
```

### Token有效期
- 默认有效期：2小时
- 可通过配置文件调整
- Token过期后需要重新登录

## 通用响应格式

### 成功响应
```json
{
    "success": true,
    "data": { ... },
    "message": "操作成功",
    "timestamp": "2024-01-01 12:00:00",
    "request_id": "req_123456789"
}
```

### 错误响应
```json
{
    "success": false,
    "error": "ERROR_CODE",
    "message": "错误描述",
    "timestamp": "2024-01-01 12:00:00",
    "request_id": "req_123456789",
    "details": { ... }
}
```

### 错误代码说明
- `AUTH_REQUIRED`: 需要认证
- `AUTH_INVALID`: 认证无效
- `AUTH_EXPIRED`: 认证过期
- `PERMISSION_DENIED`: 权限不足
- `VALIDATION_ERROR`: 参数验证失败
- `RESOURCE_NOT_FOUND`: 资源不存在
- `RATE_LIMIT_EXCEEDED`: 请求频率超限
- `SERVER_ERROR`: 服务器内部错误

## 1. 用户认证模块

### 1.1 用户登录
- **URL**: `POST /auth/login`
- **描述**: 用户登录获取 API Token
- **请求体**:
```json
{
    "username": "admin",
    "password": "password123",
    "remember_me": false
}
```
- **响应**:
```json
{
    "success": true,
    "data": {
        "user_id": 1,
        "username": "admin",
        "role": "admin",
        "permissions": ["user_manage", "card_read", "card_write"],
        "api_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
        "expires_at": "2024-01-02 12:00:00",
        "session_id": "sess_abc123"
    },
    "message": "登录成功"
}
```

### 1.2 用户登出
- **URL**: `POST /auth/logout`
- **描述**: 用户登出，撤销 API Token
- **认证**: 需要
- **响应**:
```json
{
    "success": true,
    "data": {
        "message": "登出成功"
    }
}
```

### 1.3 刷新Token
- **URL**: `POST /auth/refresh`
- **描述**: 刷新API Token
- **认证**: 需要
- **响应**:
```json
{
    "success": true,
    "data": {
        "api_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
        "expires_at": "2024-01-02 12:00:00"
    }
}
```

### 1.4 获取当前用户信息
- **URL**: `GET /auth/me`
- **描述**: 获取当前登录用户的信息
- **认证**: 需要
- **响应**:
```json
{
    "success": true,
    "data": {
        "id": 1,
        "username": "admin",
        "email": "admin@example.com",
        "role": "admin",
        "status": "active",
        "last_login": "2024-01-01 12:00:00",
        "permissions": ["user_manage", "card_read", "card_write"],
        "created_at": "2024-01-01 10:00:00"
    }
}
```

### 1.5 修改密码
- **URL**: `POST /auth/change-password`
- **描述**: 修改当前用户密码
- **认证**: 需要
- **请求体**:
```json
{
    "current_password": "oldpassword",
    "new_password": "newpassword123",
    "confirm_password": "newpassword123"
}
```

## 2. 用户管理模块

### 2.1 获取用户列表
- **URL**: `GET /users`
- **描述**: 获取用户列表（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **查询参数**:
  - `page`: 页码（默认1）
  - `limit`: 每页数量（默认20，最大100）
  - `status`: 用户状态过滤（active/inactive/banned）
  - `role`: 用户角色过滤（admin/operator/user）
  - `search`: 搜索用户名或邮箱
  - `sort`: 排序字段（created_at/last_login/username）
  - `order`: 排序方向（asc/desc）
- **响应**:
```json
{
    "success": true,
    "data": {
        "users": [
            {
                "id": 1,
                "username": "admin",
                "email": "admin@example.com",
                "role": "admin",
                "status": "active",
                "last_login": "2024-01-01 12:00:00",
                "login_count": 156,
                "created_at": "2024-01-01 10:00:00"
            }
        ],
        "pagination": {
            "page": 1,
            "limit": 20,
            "total": 50,
            "pages": 3
        }
    }
}
```

### 2.2 创建用户
- **URL**: `POST /users`
- **描述**: 创建新用户（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **请求体**:
```json
{
    "username": "newuser",
    "password": "password123",
    "email": "user@example.com",
    "role": "operator",
    "status": "active",
    "permissions": ["card_read", "card_create"]
}
```

### 2.3 获取用户详情
- **URL**: `GET /users/{id}`
- **描述**: 获取指定用户的详细信息
- **认证**: 需要
- **权限**: user_manage
- **响应**:
```json
{
    "success": true,
    "data": {
        "id": 1,
        "username": "admin",
        "email": "admin@example.com",
        "role": "admin",
        "status": "active",
        "permissions": ["user_manage", "card_read", "card_write"],
        "last_login": "2024-01-01 12:00:00",
        "login_count": 156,
        "created_at": "2024-01-01 10:00:00",
        "updated_at": "2024-01-01 11:00:00"
    }
}
```

### 2.4 更新用户
- **URL**: `PUT /users/{id}`
- **描述**: 更新用户信息（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **请求体**:
```json
{
    "email": "newemail@example.com",
    "role": "operator",
    "status": "active",
    "permissions": ["card_read", "card_create"]
}
```

### 2.5 删除用户
- **URL**: `DELETE /users/{id}`
- **描述**: 删除用户（仅管理员）
- **认证**: 需要
- **权限**: user_manage

### 2.6 重置用户密码
- **URL**: `POST /users/{id}/reset-password`
- **描述**: 重置用户密码（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **请求体**:
```json
{
    "new_password": "newpassword123"
}
```

## 3. 卡片管理模块

### 3.1 获取卡片列表
- **URL**: `GET /cards`
- **描述**: 获取卡片列表
- **认证**: 需要
- **权限**: card_read
- **查询参数**:
  - `page`: 页码（默认1）
  - `limit`: 每页数量（默认20，最大100）
  - `status`: 卡片状态过滤（active/used/expired/frozen）
  - `batch_id`: 批次ID过滤
  - `product_id`: 产品ID过滤
  - `search`: 搜索卡号或备注
  - `created_from`: 创建时间起始（YYYY-MM-DD）
  - `created_to`: 创建时间结束（YYYY-MM-DD）
- **响应**:
```json
{
    "success": true,
    "data": {
        "cards": [
            {
                "id": 1,
                "card_number": "CARD-2024-001",
                "card_secret": "****-****-****-1234",
                "product_id": 1,
                "product_name": "月度会员",
                "status": "active",
                "batch_id": 1,
                "batch_name": "2024年1月批次",
                "created_at": "2024-01-01 10:00:00",
                "expires_at": "2024-02-01 10:00:00",
                "used_at": null,
                "used_by": null
            }
        ],
        "pagination": {
            "page": 1,
            "limit": 20,
            "total": 1000,
            "pages": 50
        }
    }
}
```

### 3.2 创建单个卡片
- **URL**: `POST /cards`
- **描述**: 创建单个卡片
- **认证**: 需要
- **权限**: card_create
- **请求体**:
```json
{
    "product_id": 1,
    "card_number": "CARD-2024-001",
    "card_secret": "SECRET123456",
    "expires_at": "2024-12-31 23:59:59",
    "batch_id": 1,
    "notes": "备注信息"
}
```

### 3.3 批量创建卡片
- **URL**: `POST /cards/batch`
- **描述**: 批量创建卡片
- **认证**: 需要
- **权限**: card_create
- **请求体**:
```json
{
    "product_id": 1,
    "quantity": 100,
    "prefix": "CARD-2024-",
    "expires_at": "2024-12-31 23:59:59",
    "batch_name": "2024年1月批次",
    "notes": "批量生成"
}
```

### 3.4 获取卡片详情
- **URL**: `GET /cards/{id}`
- **描述**: 获取指定卡片的详细信息
- **认证**: 需要
- **权限**: card_read
- **响应**:
```json
{
    "success": true,
    "data": {
        "id": 1,
        "card_number": "CARD-2024-001",
        "card_secret": "SECRET123456",
        "product_id": 1,
        "product_name": "月度会员",
        "status": "active",
        "batch_id": 1,
        "batch_name": "2024年1月批次",
        "created_at": "2024-01-01 10:00:00",
        "expires_at": "2024-02-01 10:00:00",
        "used_at": null,
        "used_by": null,
        "notes": "备注信息",
        "usage_history": []
    }
}
```

### 3.5 更新卡片
- **URL**: `PUT /cards/{id}`
- **描述**: 更新卡片信息
- **认证**: 需要
- **权限**: card_write
- **请求体**:
```json
{
    "status": "frozen",
    "expires_at": "2024-12-31 23:59:59",
    "notes": "更新备注"
}
```

### 3.6 删除卡片
- **URL**: `DELETE /cards/{id}`
- **描述**: 删除卡片
- **认证**: 需要
- **权限**: card_delete

### 3.7 激活卡片
- **URL**: `POST /cards/{id}/activate`
- **描述**: 激活卡片
- **认证**: 需要
- **权限**: card_write

### 3.8 冻结卡片
- **URL**: `POST /cards/{id}/freeze`
- **描述**: 冻结卡片
- **认证**: 需要
- **权限**: card_write

### 3.9 解冻卡片
- **URL**: `POST /cards/{id}/unfreeze`
- **描述**: 解冻卡片
- **认证**: 需要
- **权限**: card_write

### 3.10 使用卡片
- **URL**: `POST /cards/{id}/use`
- **描述**: 使用卡片
- **认证**: 需要
- **权限**: card_use
- **请求体**:
```json
{
    "user_id": 123,
    "notes": "使用备注"
}
```

## 4. 产品管理模块

### 4.1 获取产品列表
- **URL**: `GET /products`
- **描述**: 获取产品列表
- **认证**: 需要
- **权限**: product_read
- **查询参数**:
  - `page`: 页码（默认1）
  - `limit`: 每页数量（默认20，最大100）
  - `status`: 产品状态过滤（active/inactive）
  - `category_id`: 分类ID过滤
  - `search`: 搜索产品名称或描述
- **响应**:
```json
{
    "success": true,
    "data": {
        "products": [
            {
                "id": 1,
                "name": "月度会员",
                "description": "一个月会员服务",
                "price": 29.99,
                "category_id": 1,
                "category_name": "会员服务",
                "status": "active",
                "stock_count": 1000,
                "sold_count": 500,
                "created_at": "2024-01-01 10:00:00"
            }
        ],
        "pagination": {
            "page": 1,
            "limit": 20,
            "total": 10,
            "pages": 1
        }
    }
}
```

### 4.2 创建产品
- **URL**: `POST /products`
- **描述**: 创建新产品
- **认证**: 需要
- **权限**: product_create
- **请求体**:
```json
{
    "name": "年度会员",
    "description": "一年会员服务",
    "price": 299.99,
    "category_id": 1,
    "status": "active",
    "metadata": {
        "duration": "365天",
        "features": ["全功能访问", "优先支持"]
    }
}
```

### 4.3 获取产品详情
- **URL**: `GET /products/{id}`
- **描述**: 获取产品详细信息
- **认证**: 需要
- **权限**: product_read

### 4.4 更新产品
- **URL**: `PUT /products/{id}`
- **描述**: 更新产品信息
- **认证**: 需要
- **权限**: product_write

### 4.5 删除产品
- **URL**: `DELETE /products/{id}`
- **描述**: 删除产品
- **认证**: 需要
- **权限**: product_delete

## 5. 订单管理模块

### 5.1 获取订单列表
- **URL**: `GET /orders`
- **描述**: 获取订单列表
- **认证**: 需要
- **权限**: order_read
- **查询参数**:
  - `page`: 页码（默认1）
  - `limit`: 每页数量（默认20，最大100）
  - `status`: 订单状态过滤（pending/paid/completed/cancelled/refunded）
  - `user_id`: 用户ID过滤
  - `product_id`: 产品ID过滤
  - `created_from`: 创建时间起始
  - `created_to`: 创建时间结束
- **响应**:
```json
{
    "success": true,
    "data": {
        "orders": [
            {
                "id": 1,
                "order_number": "ORD-2024-001",
                "user_id": 123,
                "username": "testuser",
                "product_id": 1,
                "product_name": "月度会员",
                "quantity": 1,
                "unit_price": 29.99,
                "total_amount": 29.99,
                "status": "paid",
                "payment_method": "alipay",
                "created_at": "2024-01-01 12:00:00",
                "paid_at": "2024-01-01 12:05:00"
            }
        ],
        "pagination": {
            "page": 1,
            "limit": 20,
            "total": 100,
            "pages": 5
        }
    }
}
```

### 5.2 创建订单
- **URL**: `POST /orders`
- **描述**: 创建新订单
- **认证**: 需要
- **权限**: order_create
- **请求体**:
```json
{
    "product_id": 1,
    "quantity": 1,
    "payment_method": "alipay",
    "notes": "订单备注"
}
```

### 5.3 获取订单详情
- **URL**: `GET /orders/{id}`
- **描述**: 获取订单详细信息
- **认证**: 需要
- **权限**: order_read

### 5.4 更新订单状态
- **URL**: `PUT /orders/{id}/status`
- **描述**: 更新订单状态
- **认证**: 需要
- **权限**: order_write
- **请求体**:
```json
{
    "status": "completed",
    "notes": "状态更新备注"
}
```

### 5.5 取消订单
- **URL**: `POST /orders/{id}/cancel`
- **描述**: 取消订单
- **认证**: 需要
- **权限**: order_write

### 5.6 退款订单
- **URL**: `POST /orders/{id}/refund`
- **描述**: 订单退款
- **认证**: 需要
- **权限**: order_write
- **请求体**:
```json
{
    "refund_amount": 29.99,
    "reason": "用户申请退款"
}
```

## 6. 分类管理模块

### 6.1 获取分类列表
- **URL**: `GET /categories`
- **描述**: 获取产品分类列表
- **认证**: 需要
- **权限**: category_read
- **响应**:
```json
{
    "success": true,
    "data": {
        "categories": [
            {
                "id": 1,
                "name": "会员服务",
                "description": "各种会员套餐",
                "parent_id": null,
                "sort_order": 1,
                "product_count": 5,
                "created_at": "2024-01-01 10:00:00"
            }
        ]
    }
}
```

### 6.2 创建分类
- **URL**: `POST /categories`
- **描述**: 创建产品分类
- **认证**: 需要
- **权限**: category_create
- **请求体**:
```json
{
    "name": "游戏道具",
    "description": "游戏内虚拟道具",
    "parent_id": null,
    "sort_order": 2
}
```

### 6.3 更新分类
- **URL**: `PUT /categories/{id}`
- **描述**: 更新分类信息
- **认证**: 需要
- **权限**: category_write

### 6.4 删除分类
- **URL**: `DELETE /categories/{id}`
- **描述**: 删除分类
- **认证**: 需要
- **权限**: category_delete

## 7. 统计分析模块

### 7.1 获取系统概览统计
- **URL**: `GET /stats/overview`
- **描述**: 获取系统概览统计数据
- **认证**: 需要
- **权限**: stats_read
- **响应**:
```json
{
    "success": true,
    "data": {
        "total_users": 1000,
        "total_cards": 50000,
        "total_orders": 10000,
        "total_revenue": 500000.00,
        "today_orders": 50,
        "today_revenue": 2500.00,
        "active_cards": 45000,
        "used_cards": 5000
    }
}
```

### 7.2 获取销售统计
- **URL**: `GET /stats/sales`
- **描述**: 获取销售统计数据
- **认证**: 需要
- **权限**: stats_read
- **查询参数**:
  - `period`: 统计周期（today/week/month/year）
  - `start_date`: 开始日期
  - `end_date`: 结束日期
- **响应**:
```json
{
    "success": true,
    "data": {
        "period": "month",
        "total_orders": 1000,
        "total_revenue": 50000.00,
        "average_order_value": 50.00,
        "top_products": [
            {
                "product_id": 1,
                "product_name": "月度会员",
                "sales_count": 500,
                "revenue": 14995.00
            }
        ],
        "daily_stats": [
            {
                "date": "2024-01-01",
                "orders": 30,
                "revenue": 1500.00
            }
        ]
    }
}
```

### 7.3 获取用户统计
- **URL**: `GET /stats/users`
- **描述**: 获取用户统计数据
- **认证**: 需要
- **权限**: stats_read

### 7.4 获取卡片统计
- **URL**: `GET /stats/cards`
- **描述**: 获取卡片统计数据
- **认证**: 需要
- **权限**: stats_read

## 8. 合规检查模块

### 8.1 获取合规报告
- **URL**: `GET /compliance/report`
- **描述**: 获取系统合规报告
- **认证**: 需要
- **权限**: compliance_read
- **响应**:
```json
{
    "success": true,
    "data": {
        "overall_score": 95,
        "checks": [
            {
                "category": "数据加密",
                "status": "pass",
                "score": 100,
                "details": "所有敏感数据已加密存储"
            },
            {
                "category": "访问控制",
                "status": "pass",
                "score": 90,
                "details": "权限控制完善，建议加强日志审计"
            }
        ],
        "recommendations": [
            "启用双因素认证",
            "定期备份数据"
        ]
    }
}
```

### 8.2 获取安全事件
- **URL**: `GET /compliance/security-events`
- **描述**: 获取安全事件记录
- **认证**: 需要
- **权限**: compliance_read

### 8.3 获取审计日志
- **URL**: `GET /compliance/audit-logs`
- **描述**: 获取操作审计日志
- **认证**: 需要
- **权限**: compliance_read

## 9. 权限管理模块

### 9.1 获取权限列表
- **URL**: `GET /permissions`
- **描述**: 获取系统权限列表
- **认证**: 需要
- **权限**: permission_read

### 9.2 获取角色列表
- **URL**: `GET /roles`
- **描述**: 获取系统角色列表
- **认证**: 需要
- **权限**: role_read

### 9.3 创建角色
- **URL**: `POST /roles`
- **描述**: 创建新角色
- **认证**: 需要
- **权限**: role_create
- **请求体**:
```json
{
    "name": "客服",
    "description": "客服人员角色",
    "permissions": ["card_read", "order_read"]
}
```

## 10. 系统配置模块

### 10.1 获取系统配置
- **URL**: `GET /config`
- **描述**: 获取系统配置信息
- **认证**: 需要
- **权限**: config_read

### 10.2 更新系统配置
- **URL**: `PUT /config`
- **描述**: 更新系统配置
- **认证**: 需要
- **权限**: config_write
- **请求体**:
```json
{
    "site_name": "发卡系统",
    "site_description": "专业的发卡服务平台",
    "allow_registration": true,
    "email_verification": false
}
```

## 11. 批量操作模块

### 11.1 批量导入卡片
- **URL**: `POST /batch/import-cards`
- **描述**: 批量导入卡片
- **认证**: 需要
- **权限**: card_create
- **请求体**:
```json
{
    "batch_name": "批量导入",
    "cards": [
        {
            "card_number": "CARD-001",
            "card_secret": "SECRET-001",
            "product_id": 1,
            "expires_at": "2024-12-31"
        }
    ]
}
```

### 11.2 批量导出卡片
- **URL**: `GET /batch/export-cards`
- **描述**: 批量导出卡片
- **认证**: 需要
- **权限**: card_read
- **查询参数**:
  - `format`: 导出格式（csv/xlsx）
  - `filters`: 过滤条件

## 12. 通知模块

### 12.1 获取通知列表
- **URL**: `GET /notifications`
- **描述**: 获取用户通知列表
- **认证**: 需要

### 12.2 标记通知已读
- **URL**: `PUT /notifications/{id}/read`
- **描述**: 标记通知为已读
- **认证**: 需要

### 12.3 发送通知
- **URL**: `POST /notifications/send`
- **描述**: 发送系统通知
- **认证**: 需要
- **权限**: notification_send
- **请求体**:
```json
{
    "user_id": 123,
    "title": "系统通知",
    "content": "您的订单已完成",
    "type": "order_completed"
}
```

## 限制说明

### 请求频率限制
- 普通用户：100次/分钟
- 管理员：500次/分钟
- 批量操作：10次/分钟

### 数据限制
- 单次查询最大记录数：100条
- 批量操作最大数量：1000条
- 文件上传最大大小：5MB

## 错误处理

### HTTP状态码
- `200`: 成功
- `201`: 创建成功
- `400`: 请求参数错误
- `401`: 未认证
- `403`: 权限不足
- `404`: 资源不存在
- `429`: 请求频率超限
- `500`: 服务器内部错误

### 重试机制
对于网络超时或服务器错误，建议采用指数退避重试策略：
- 第1次重试：等待1秒
- 第2次重试：等待2秒
- 第3次重试：等待4秒
- 最多重试3次

## SDK和示例代码

### JavaScript/Node.js示例
```javascript
// 登录获取token
const loginResponse = await fetch('/api/auth/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        username: 'admin',
        password: 'password123'
    })
});

const { data } = await loginResponse.json();
const token = data.api_token;

// 使用token调用API
const cardsResponse = await fetch('/api/cards', {
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    }
});
```

### PHP示例
```php
// 登录获取token
$ch = curl_init('/api/auth/login');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'username' => 'admin',
    'password' => 'password123'
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$data = json_decode($response, true);
$token = $data['data']['api_token'];

// 使用token调用API
$ch = curl_init('/api/cards');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $token,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
```

## 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 实现基础CRUD功能
- 支持用户认证和权限管理
- 提供完整的RESTful API

## 联系支持

如有问题或建议，请联系：
- 邮箱：support@example.com
- 文档：https://docs.example.com
- GitHub：https://github.com/example/card-system