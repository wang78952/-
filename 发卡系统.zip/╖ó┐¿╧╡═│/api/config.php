<?php
/**
 * API配置文件
 * 包含API相关的配置信息
 */

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'card_system');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// API配置
define('API_VERSION', '1.0.0');
define('API_PREFIX', '/api');
define('API_DEBUG', true);
define('API_TIMEZONE', 'Asia/Shanghai');

// 缓存配置
define('CACHE_ENABLED', true);
define('CACHE_TTL', 3600); // 1小时
define('CACHE_PREFIX', 'card_api_');

// 安全配置
define('JWT_SECRET', 'your-secret-key-here');
define('JWT_EXPIRE', 86400); // 24小时
define('RATE_LIMIT_ENABLED', true);
define('RATE_LIMIT_REQUESTS', 100);
define('RATE_LIMIT_WINDOW', 3600); // 1小时

// 文件上传配置
define('UPLOAD_MAX_SIZE', 10485760); // 10MB
define('UPLOAD_ALLOWED_TYPES', array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'));
define('UPLOAD_PATH', __DIR__ . '/../uploads/');

// 日志配置
define('LOG_ENABLED', true);
define('LOG_LEVEL', 'INFO');
define('LOG_PATH', __DIR__ . '/../logs/');
define('LOG_MAX_FILES', 30);

// 邮件配置
define('MAIL_ENABLED', false);
define('MAIL_HOST', 'smtp.example.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'noreply@example.com');
define('MAIL_PASSWORD', 'password');
define('MAIL_FROM', 'noreply@example.com');
define('MAIL_FROM_NAME', 'Card System');

// 短信配置
define('SMS_ENABLED', false);
define('SMS_PROVIDER', 'aliyun');
define('SMS_ACCESS_KEY', 'your-access-key');
define('SMS_SECRET_KEY', 'your-secret-key');

// 支付配置
define('ALIPAY_ENABLED', true);
define('ALIPAY_APP_ID', 'your-alipay-app-id');
define('ALIPAY_PRIVATE_KEY', 'your-alipay-private-key');
define('ALIPAY_PUBLIC_KEY', 'your-alipay-public-key');
define('ALIPAY_GATEWAY', 'https://openapi.alipay.com/gateway.do');

define('WECHAT_PAY_ENABLED', true);
define('WECHAT_APP_ID', 'your-wechat-app-id');
define('WECHAT_MCH_ID', 'your-wechat-mch-id');
define('WECHAT_KEY', 'your-wechat-key');
define('WECHAT_CERT_PATH', __DIR__ . '/../certs/wechat/');

// 系统配置
define('SYSTEM_NAME', '发卡系统');
define('SYSTEM_VERSION', '1.0.0');
define('SYSTEM_ADMIN_EMAIL', 'admin@example.com');
define('SYSTEM_TIMEZONE', 'Asia/Shanghai');

// 错误报告
if (API_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
    ini_set('display_errors', 0);
}

// 时区设置
date_default_timezone_set(API_TIMEZONE);

// 会话配置
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Lax');

// CORS配置
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token');
header('Access-Control-Expose-Headers: X-Total-Count, X-Page-Count');

// 设置字符编码
mb_internal_encoding('UTF-8');

// 自动加载器
spl_autoload_register(function ($class) {
    $paths = array(
        __DIR__ . '/../includes/',
        __DIR__ . '/../controllers/',
        __DIR__ . '/../models/',
        __DIR__ . '/../helpers/'
    );
    
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// 全局异常处理器
set_exception_handler(function ($exception) {
    error_log("Uncaught exception: " . $exception->getMessage());
    
    if (API_DEBUG) {
        $response = array(
            'success' => false,
            'error' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString(),
            'timestamp' => date('Y-m-d H:i:s')
        );
    } else {
        $response = array(
            'success' => false,
            'error' => 'Internal Server Error',
            'timestamp' => date('Y-m-d H:i:s')
        );
    }
    
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
    exit;
});

// 全局错误处理器
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) {
        return false;
    }
    
    $errorTypes = array(
        E_ERROR => 'Error',
        E_WARNING => 'Warning',
        E_PARSE => 'Parse Error',
        E_NOTICE => 'Notice',
        E_CORE_ERROR => 'Core Error',
        E_CORE_WARNING => 'Core Warning',
        E_COMPILE_ERROR => 'Compile Error',
        E_COMPILE_WARNING => 'Compile Warning',
        E_USER_ERROR => 'User Error',
        E_USER_WARNING => 'User Warning',
        E_USER_NOTICE => 'User Notice',
        E_STRICT => 'Strict Notice',
        E_RECOVERABLE_ERROR => 'Recoverable Error',
        E_DEPRECATED => 'Deprecated',
        E_USER_DEPRECATED => 'User Deprecated'
    );
    
    $errorType = isset($errorTypes[$errno]) ? $errorTypes[$errno] : 'Unknown Error';
    
    error_log("$errorType: $errstr in $errfile on line $errline");
    
    if (API_DEBUG) {
        $response = array(
            'success' => false,
            'error' => "$errorType: $errstr",
            'file' => $errfile,
            'line' => $errline,
            'timestamp' => date('Y-m-d H:i:s')
        );
    } else {
        $response = array(
            'success' => false,
            'error' => 'Internal Server Error',
            'timestamp' => date('Y-m-d H:i:s')
        );
    }
    
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
    exit;
});

// 注意：魔术引号功能已在PHP 5.4.0中弃用，在PHP 7.0.0中移除
// 此代码仅为向后兼容性保留，在现代PHP版本中不会执行
// 由于get_magic_quotes_gpc()函数已在现代PHP版本中移除，我们直接跳过此处理
// 现代PHP应用不需要魔术引号处理，因为输入数据默认不会自动转义
?>