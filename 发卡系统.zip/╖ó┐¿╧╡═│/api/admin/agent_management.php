<?php
/**
 * 代理管理API接口
 * 用于管理后台的代理管理功能
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../includes/Database.php';
require_once '../includes/BaseService.php';
require_once '../includes/AgentManager.php';
require_once '../includes/CommissionManager.php';
require_once '../includes/AuthManager.php';

// 检查管理员权限
$authManager = AuthManager::getInstance();
if (!$authManager->isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => '权限不足']);
    exit;
}

// 创建管理器实例
$agentManager = new AgentManager();
$commissionManager = new CommissionManager();

// 获取请求方法和操作
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    switch ($method) {
        case 'GET':
            handleGetRequest($agentManager, $commissionManager, $action);
            break;
            
        case 'POST':
            handlePostRequest($agentManager, $commissionManager, $action);
            break;
            
        case 'PUT':
            handlePutRequest($agentManager, $action);
            break;
            
        case 'DELETE':
            handleDeleteRequest($agentManager, $action);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '不支持的请求方法']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '服务器错误：' . $e->getMessage()]);
}

/**
 * 处理GET请求
 */
function handleGetRequest($agentManager, $commissionManager, $action) {
    switch ($action) {
        case 'list':
            // 获取代理列表
            $page = intval(isset($_GET['page']) ? $_GET['page'] : 1);
            $limit = intval(isset($_GET['limit']) ? $_GET['limit'] : 20);
            $status = isset($_GET['status']) ? $_GET['status'] : '';
            $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
            
            $filters = array();
            if ($status) $filters['status'] = $status;
            if ($keyword) $filters['keyword'] = $keyword;
            
            $result = $agentManager->getAgentsList($filters, $page, $limit);
            echo json_encode($result);
            break;
            
        case 'detail':
            // 获取代理详情
            $agentId = intval(isset($_GET['id']) ? $_GET['id'] : 0);
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            $result = $agentManager->getAgentById($agentId);
            echo json_encode($result);
            break;
            
        case 'commissions':
            // 获取代理佣金列表
            $agentId = intval(isset($_GET['agent_id']) ? $_GET['agent_id'] : 0);
            $page = intval(isset($_GET['page']) ? $_GET['page'] : 1);
            $limit = intval(isset($_GET['limit']) ? $_GET['limit'] : 20);
            $type = isset($_GET['type']) ? $_GET['type'] : '';
            $status = isset($_GET['status']) ? $_GET['status'] : '';
            $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
            $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
            
            $filters = array();
            if ($type) $filters['type'] = $type;
            if ($status) $filters['status'] = $status;
            if ($startDate) $filters['start_date'] = $startDate;
            if ($endDate) $filters['end_date'] = $endDate;
            
            $result = $commissionManager->getAgentCommissions($agentId, $filters, $page, $limit);
            echo json_encode($result);
            break;
            
        case 'commission_stats':
            // 获取代理佣金统计
            $agentId = intval(isset($_GET['agent_id']) ? $_GET['agent_id'] : 0);
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            $result = $commissionManager->getAgentCommissionStats($agentId);
            echo json_encode($result);
            break;
            
        case 'withdrawals':
            // 获取提现记录
            $agentId = intval(isset($_GET['agent_id']) ? $_GET['agent_id'] : 0);
            $page = intval(isset($_GET['page']) ? $_GET['page'] : 1);
            $limit = intval(isset($_GET['limit']) ? $_GET['limit'] : 20);
            $status = isset($_GET['status']) ? $_GET['status'] : '';
            $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
            $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
            
            $filters = array();
            if ($status) $filters['status'] = $status;
            if ($startDate) $filters['start_date'] = $startDate;
            if ($endDate) $filters['end_date'] = $endDate;
            
            $result = $commissionManager->getWithdrawals($agentId, $filters, $page, $limit);
            echo json_encode($result);
            break;
            
        case 'stats':
            // 获取代理统计数据
            $result = getAgentStats($agentManager);
            echo json_encode($result);
            break;
            
        case 'sub_agents':
            // 获取下级代理列表
            $agentId = intval(isset($_GET['agent_id']) ? $_GET['agent_id'] : 0);
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            $result = $agentManager->getSubAgents($agentId);
            echo json_encode($result);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => '不支持的操作']);
            break;
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($agentManager, $commissionManager, $action) {
    switch ($action) {
        case 'add':
            // 手动添加代理
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '请求数据格式错误']);
                return;
            }
            
            // 验证必填字段
            $requiredFields = ['contact_name', 'phone', 'email', 'id_card', 'bank_name', 'bank_account', 'bank_account_name'];
            
            foreach ($requiredFields as $field) {
                if (empty($input[$field])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => "字段 {$field} 不能为空"]);
                    return;
                }
            }
            
            $agentData = [
                'contact_name' => trim($input['contact_name']),
                'phone' => trim($input['phone']),
                'email' => trim($input['email']),
                'id_card' => trim($input['id_card']),
                'bank_name' => trim($input['bank_name']),
                'bank_account' => trim($input['bank_account']),
                'bank_account_name' => trim($input['bank_account_name']),
                'commission_rate' => floatval($input['commission_rate'] ?? 10),
                'sub_commission_rate' => floatval($input['sub_commission_rate'] ?? 3),
                'parent_agent_id' => !empty($input['parent_agent_id']) ? intval($input['parent_agent_id']) : null,
                'remark' => !empty($input['remark']) ? trim($input['remark']) : '',
                'source' => 'admin'
            ];
            
            $result = $agentManager->addAgent($agentData);
            echo json_encode($result);
            break;
            
        case 'approve':
            // 审核通过代理申请
            $input = json_decode(file_get_contents('php://input'), true);
            $agentId = intval($input['agent_id'] ?? 0);
            $commissionRate = floatval($input['commission_rate'] ?? 10);
            $subCommissionRate = floatval($input['sub_commission_rate'] ?? 3);
            $parentAgentId = !empty($input['parent_agent_id']) ? intval($input['parent_agent_id']) : null;
            $adminNotes = $input['admin_notes'] ?? '';
            
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            $result = $agentManager->approveAgent($agentId, $commissionRate, $subCommissionRate, $parentAgentId, $adminNotes);
            echo json_encode($result);
            break;
            
        case 'reject':
            // 拒绝代理申请
            $input = json_decode(file_get_contents('php://input'), true);
            $agentId = intval($input['agent_id'] ?? 0);
            $reason = $input['reason'] ?? '';
            
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            if (empty($reason)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '拒绝原因不能为空']);
                return;
            }
            
            $result = $agentManager->rejectAgent($agentId, $reason);
            echo json_encode($result);
            break;
            
        case 'process_withdrawal':
            // 处理提现申请
            $input = json_decode(file_get_contents('php://input'), true);
            $withdrawalId = intval($input['withdrawal_id'] ?? 0);
            $status = $input['status'] ?? '';
            $adminNotes = $input['admin_notes'] ?? '';
            
            if (!$withdrawalId || !in_array($status, ['completed', 'rejected'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '参数错误']);
                return;
            }
            
            $result = $commissionManager->processWithdrawal($withdrawalId, $status, $adminNotes, $_SESSION['user_id'] ?? null);
            echo json_encode($result);
            break;
            
        case 'update_commissions':
            // 更新可用佣金状态
            $result = $commissionManager->updateAvailableCommissions();
            echo json_encode($result);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => '不支持的操作']);
            break;
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($agentManager, $action) {
    switch ($action) {
        case 'update':
            // 更新代理信息
            $input = json_decode(file_get_contents('php://input'), true);
            $agentId = intval($input['agent_id'] ?? 0);
            
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            $updateData = [];
            
            // 允许更新的字段
            $allowedFields = ['contact_name', 'phone', 'email', 'bank_name', 'bank_account', 'bank_account_name', 'commission_rate', 'sub_commission_rate', 'remark'];
            
            foreach ($allowedFields as $field) {
                if (isset($input[$field])) {
                    $updateData[$field] = trim($input[$field]);
                }
            }
            
            if (empty($updateData)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '没有要更新的数据']);
                return;
            }
            
            $result = $agentManager->updateAgent($agentId, $updateData);
            echo json_encode($result);
            break;
            
        case 'update_status':
            // 更新代理状态
            $input = json_decode(file_get_contents('php://input'), true);
            $agentId = intval($input['agent_id'] ?? 0);
            $status = $input['status'] ?? '';
            
            if (!$agentId || !in_array($status, ['active', 'inactive', 'suspended'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '参数错误']);
                return;
            }
            
            $result = $agentManager->updateAgentStatus($agentId, $status);
            echo json_encode($result);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => '不支持的操作']);
            break;
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($agentManager, $action) {
    switch ($action) {
        case 'delete':
            // 删除代理
            $agentId = intval($_GET['id'] ?? 0);
            
            if (!$agentId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '代理ID不能为空']);
                return;
            }
            
            $result = $agentManager->deleteAgent($agentId);
            echo json_encode($result);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => '不支持的操作']);
            break;
    }
}

/**
 * 获取代理统计数据
 */
function getAgentStats($agentManager) {
    try {
        $db = Database::getInstance();
        
        // 总代理数
        $totalAgents = $db->fetch("SELECT COUNT(*) as count FROM agents")['count'];
        
        // 各状态代理数
        $statusStats = $db->fetchAll("
            SELECT status, COUNT(*) as count 
            FROM agents 
            GROUP BY status
        ");
        
        $statusCounts = [];
        foreach ($statusStats as $stat) {
            $statusCounts[$stat['status']] = $stat['count'];
        }
        
        // 今日新增代理
        $todayAgents = $db->fetch("
            SELECT COUNT(*) as count 
            FROM agents 
            WHERE DATE(created_at) = CURDATE()
        ")['count'];
        
        // 本月新增代理
        $monthAgents = $db->fetch("
            SELECT COUNT(*) as count 
            FROM agents 
            WHERE YEAR(created_at) = YEAR(CURDATE()) 
            AND MONTH(created_at) = MONTH(CURDATE())
        ")['count'];
        
        // 总佣金统计
        $commissionStats = $db->fetch("
            SELECT 
                COALESCE(SUM(total_commission), 0) as total_commission,
                COALESCE(SUM(available_commission), 0) as available_commission,
                COALESCE(SUM(total_sales), 0) as total_sales
            FROM agents
        ");
        
        return [
            'success' => true,
            'data' => [
                'total_agents' => $totalAgents,
                'status_counts' => $statusCounts,
                'today_agents' => $todayAgents,
                'month_agents' => $monthAgents,
                'commission_stats' => $commissionStats
            ]
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => '获取统计数据失败：' . $e->getMessage()];
    }
}
?>