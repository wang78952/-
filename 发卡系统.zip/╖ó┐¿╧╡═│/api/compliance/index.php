<?php
/**
 * 合规性管理API接口
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/ComplianceManager.php';
require_once __DIR__ . '/../../includes/SecurityManager.php';

try {
    $db = Database::getInstance()->getConnection();
    $complianceManager = new ComplianceManager($db);
    $securityManager = new SecurityManager($db);
    
    $method = $_SERVER['REQUEST_METHOD'];
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $pathParts = explode('/', trim($path, '/'));
    
    // 获取操作类型
    $action = $pathParts[3] ?? '';
    
    switch ($method) {
        case 'GET':
            handleGetRequest($action, $complianceManager, $securityManager);
            break;
        case 'POST':
            handlePostRequest($action, $complianceManager, $securityManager);
            break;
        case 'PUT':
            handlePutRequest($action, $complianceManager, $securityManager);
            break;
        case 'DELETE':
            handleDeleteRequest($action, $complianceManager, $securityManager);
            break;
        case 'OPTIONS':
            http_response_code(200);
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => '不支持的请求方法']);
            break;
    }
    
} catch (Exception $e) {
    error_log("合规API错误: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => '服务器内部错误', 'message' => $e->getMessage()]);
}

/**
 * 处理GET请求
 */
function handleGetRequest($action, $complianceManager, $securityManager) {
    switch ($action) {
        case 'aml-statistics':
            getAmlStatistics($complianceManager);
            break;
        case 'kyc-statistics':
            getKycStatistics($complianceManager);
            break;
        case 'kyc-list':
            getKycList($complianceManager);
            break;
        case 'aml-alerts':
            getAmlAlerts($complianceManager);
            break;
        case 'compliance-events':
            getComplianceEvents($complianceManager);
            break;
        case 'retention-policies':
            getRetentionPolicies($complianceManager);
            break;
        case 'reports':
            getComplianceReports($complianceManager);
            break;
        case 'risk-assessment':
            getRiskAssessment($complianceManager);
            break;
        case 'sanctions-list':
            getSanctionsList($complianceManager);
            break;
        case 'config':
            getComplianceConfig($complianceManager);
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($action, $complianceManager, $securityManager) {
    switch ($action) {
        case 'aml-screening':
            performAmlScreening($complianceManager, $securityManager);
            break;
        case 'kyc-verification':
            performKycVerification($complianceManager, $securityManager);
            break;
        case 'kyc-document':
            uploadKycDocument($complianceManager, $securityManager);
            break;
        case 'retention-policy':
            createRetentionPolicy($complianceManager, $securityManager);
            break;
        case 'execute-retention':
            executeDataRetentionPolicy($complianceManager, $securityManager);
            break;
        case 'generate-report':
            generateComplianceReport($complianceManager, $securityManager);
            break;
        case 'risk-rule':
            createRiskAssessmentRule($complianceManager, $securityManager);
            break;
        case 'sanctions-entry':
            addSanctionsListEntry($complianceManager, $securityManager);
            break;
        case 'config':
            updateComplianceConfig($complianceManager, $securityManager);
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($action, $complianceManager, $securityManager) {
    switch ($action) {
        case 'kyc-verification':
            updateKycVerification($complianceManager, $securityManager);
            break;
        case 'aml-alert':
            updateAmlAlert($complianceManager, $securityManager);
            break;
        case 'retention-policy':
            updateRetentionPolicy($complianceManager, $securityManager);
            break;
        case 'risk-rule':
            updateRiskAssessmentRule($complianceManager, $securityManager);
            break;
        case 'sanctions-entry':
            updateSanctionsListEntry($complianceManager, $securityManager);
            break;
        case 'compliance-event':
            acknowledgeComplianceEvent($complianceManager, $securityManager);
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($action, $complianceManager, $securityManager) {
    switch ($action) {
        case 'retention-policy':
            deleteRetentionPolicy($complianceManager, $securityManager);
            break;
        case 'risk-rule':
            deleteRiskAssessmentRule($complianceManager, $securityManager);
            break;
        case 'sanctions-entry':
            deleteSanctionsListEntry($complianceManager, $securityManager);
            break;
        case 'compliance-report':
            deleteComplianceReport($complianceManager, $securityManager);
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 获取AML统计信息
 */
function getAmlStatistics($complianceManager) {
    $startDate = $_GET['start_date'] ?? date('Y-m-01');
    $endDate = $_GET['end_date'] ?? date('Y-m-t');
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_screenings,
            SUM(CASE WHEN overall_risk = 'HIGH' THEN 1 ELSE 0 END) as high_risk_count,
            SUM(CASE WHEN overall_risk = 'MEDIUM' THEN 1 ELSE 0 END) as medium_risk_count,
            SUM(CASE WHEN overall_risk = 'LOW' THEN 1 ELSE 0 END) as low_risk_count,
            AVG(risk_score) as avg_risk_score,
            MAX(risk_score) as max_risk_score,
            MIN(risk_score) as min_risk_score
        FROM aml_screening_results 
        WHERE screening_time BETWEEN ? AND ?
    ");
    $stmt->execute([$startDate, $endDate]);
    $statistics = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $statistics,
        'period' => ['start_date' => $startDate, 'end_date' => $endDate]
    ]);
}

/**
 * 获取KYC统计信息
 */
function getKycStatistics($complianceManager) {
    $startDate = $_GET['start_date'] ?? date('Y-m-01');
    $endDate = $_GET['end_date'] ?? date('Y-m-t');
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_verifications,
            SUM(CASE WHEN status = 'VERIFIED' THEN 1 ELSE 0 END) as verified_count,
            SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pending_count,
            SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as rejected_count,
            SUM(CASE WHEN status = 'EXPIRED' THEN 1 ELSE 0 END) as expired_count,
            AVG(verification_score) as avg_verification_score,
            MAX(verification_score) as max_verification_score,
            MIN(verification_score) as min_verification_score
        FROM kyc_verifications 
        WHERE verification_time BETWEEN ? AND ?
    ");
    $stmt->execute([$startDate, $endDate]);
    $statistics = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $statistics,
        'period' => ['start_date' => $startDate, 'end_date' => $endDate]
    ]);
}

/**
 * 获取KYC列表
 */
function getKycList($complianceManager) {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(10, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    $status = $_GET['status'] ?? '';
    $search = $_GET['search'] ?? '';
    
    $db = Database::getInstance()->getConnection();
    
    $whereConditions = [];
    $params = [];
    
    if ($status) {
        $whereConditions[] = "kv.status = ?";
        $params[] = $status;
    }
    
    if ($search) {
        $whereConditions[] = "(kv.real_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    $whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // 获取总数
    $countSql = "
        SELECT COUNT(*) as total
        FROM kyc_verifications kv
        LEFT JOIN users u ON kv.user_id = u.id
        {$whereClause}
    ";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取数据
    $dataSql = "
        SELECT 
            kv.*,
            u.username,
            u.email as user_email,
            u.created_at as user_created_at
        FROM kyc_verifications kv
        LEFT JOIN users u ON kv.user_id = u.id
        {$whereClause}
        ORDER BY kv.verification_time DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $db->prepare($dataSql);
    $stmt->execute(array_merge($params, [$limit, $offset]));
    $kycList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 脱敏处理
    foreach ($kycList as &$kyc) {
        if (!empty($kyc['id_number'])) {
            $kyc['id_number'] = substr($kyc['id_number'], 0, 6) . '****' . substr($kyc['id_number'], -4);
        }
        if (!empty($kyc['phone'])) {
            $kyc['phone'] = substr($kyc['phone'], 0, 3) . '****' . substr($kyc['phone'], -4);
        }
    }
    
    echo json_encode([
        'success' => true,
        'data' => $kycList,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
}

/**
 * 获取AML警报
 */
function getAmlAlerts($complianceManager) {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(10, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    $status = $_GET['status'] ?? '';
    $alertType = $_GET['alert_type'] ?? '';
    
    $db = Database::getInstance()->getConnection();
    
    $whereConditions = [];
    $params = [];
    
    if ($status) {
        $whereConditions[] = "aa.status = ?";
        $params[] = $status;
    }
    
    if ($alertType) {
        $whereConditions[] = "aa.alert_type = ?";
        $params[] = $alertType;
    }
    
    $whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // 获取总数
    $countSql = "SELECT COUNT(*) as total FROM aml_alerts aa {$whereClause}";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取数据
    $dataSql = "
        SELECT 
            aa.*,
            u.username,
            u.email as user_email
        FROM aml_alerts aa
        LEFT JOIN users u ON aa.user_id = u.id
        {$whereClause}
        ORDER BY aa.created_at DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $db->prepare($dataSql);
    $stmt->execute(array_merge($params, [$limit, $offset]));
    $alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $alerts,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
}

/**
 * 获取合规事件
 */
function getComplianceEvents($complianceManager) {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(10, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    $eventType = $_GET['event_type'] ?? '';
    $severity = $_GET['severity'] ?? '';
    
    $db = Database::getInstance()->getConnection();
    
    $whereConditions = [];
    $params = [];
    
    if ($eventType) {
        $whereConditions[] = "event_type = ?";
        $params[] = $eventType;
    }
    
    if ($severity) {
        $whereConditions[] = "severity = ?";
        $params[] = $severity;
    }
    
    $whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // 获取总数
    $countSql = "SELECT COUNT(*) as total FROM compliance_events {$whereClause}";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取数据
    $dataSql = "
        SELECT * FROM compliance_events 
        {$whereClause}
        ORDER BY event_time DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $db->prepare($dataSql);
    $stmt->execute(array_merge($params, [$limit, $offset]));
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $events,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
}

/**
 * 执行AML筛查
 */
function performAmlScreening($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['user_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少用户ID']);
        return;
    }
    
    try {
        $transactionData = $input['transaction_data'] ?? [];
        $result = $complianceManager->amlScreening($input['user_id'], $transactionData);
        
        echo json_encode([
            'success' => true,
            'data' => $result,
            'message' => 'AML筛查完成'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'AML筛查失败', 'message' => $e->getMessage()]);
    }
}

/**
 * 执行KYC验证
 */
function performKycVerification($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['user_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少用户ID']);
        return;
    }
    
    try {
        $result = $complianceManager->kycVerification($input['user_id'], $input);
        
        echo json_encode([
            'success' => true,
            'data' => $result,
            'message' => 'KYC验证提交成功'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'KYC验证失败', 'message' => $e->getMessage()]);
    }
}

/**
 * 生成合规报告
 */
function generateComplianceReport($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $reportType = $input['report_type'] ?? 'monthly';
    $startDate = $input['start_date'] ?? null;
    $endDate = $input['end_date'] ?? null;
    
    try {
        $result = $complianceManager->generateComplianceReport($reportType, $startDate, $endDate);
        
        echo json_encode([
            'success' => true,
            'data' => $result,
            'message' => '合规报告生成成功'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => '报告生成失败', 'message' => $e->getMessage()]);
    }
}

/**
 * 执行数据留存策略
 */
function executeDataRetentionPolicy($complianceManager, $securityManager) {
    try {
        $results = $complianceManager->executeDataRetentionPolicy();
        
        echo json_encode([
            'success' => true,
            'data' => $results,
            'message' => '数据留存策略执行完成'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => '留存策略执行失败', 'message' => $e->getMessage()]);
    }
}

/**
 * 获取留存策略
 */
function getRetentionPolicies($complianceManager) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("SELECT * FROM data_retention_policies ORDER BY created_at DESC");
    $stmt->execute();
    $policies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $policies
    ]);
}

/**
 * 获取合规报告
 */
function getComplianceReports($complianceManager) {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(10, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    $reportType = $_GET['report_type'] ?? '';
    
    $db = Database::getInstance()->getConnection();
    
    $whereConditions = [];
    $params = [];
    
    if ($reportType) {
        $whereConditions[] = "report_type = ?";
        $params[] = $reportType;
    }
    
    $whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // 获取总数
    $countSql = "SELECT COUNT(*) as total FROM compliance_reports {$whereClause}";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取数据
    $dataSql = "
        SELECT * FROM compliance_reports 
        {$whereClause}
        ORDER BY generated_time DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $db->prepare($dataSql);
    $stmt->execute(array_merge($params, [$limit, $offset]));
    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $reports,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
}

/**
 * 获取风险评估
 */
function getRiskAssessment($complianceManager) {
    $db = Database::getInstance()->getConnection();
    
    // 获取最近的风险统计
    $stmt = $db->prepare("
        SELECT 
            'AML风险' as risk_type,
            SUM(CASE WHEN overall_risk = 'HIGH' THEN 1 ELSE 0 END) as high_count,
            SUM(CASE WHEN overall_risk = 'MEDIUM' THEN 1 ELSE 0 END) as medium_count,
            SUM(CASE WHEN overall_risk = 'LOW' THEN 1 ELSE 0 END) as low_count,
            COUNT(*) as total_count
        FROM aml_screening_results 
        WHERE screening_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        
        UNION ALL
        
        SELECT 
            'KYC风险' as risk_type,
            SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as high_count,
            SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as medium_count,
            SUM(CASE WHEN status = 'VERIFIED' THEN 1 ELSE 0 END) as low_count,
            COUNT(*) as total_count
        FROM kyc_verifications 
        WHERE verification_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $riskData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $riskData
    ]);
}

/**
 * 获取制裁名单
 */
function getSanctionsList($complianceManager) {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(10, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    $listType = $_GET['list_type'] ?? '';
    $search = $_GET['search'] ?? '';
    
    $db = Database::getInstance()->getConnection();
    
    $whereConditions = ["active = 1"];
    $params = [];
    
    if ($listType) {
        $whereConditions[] = "list_type = ?";
        $params[] = $listType;
    }
    
    if ($search) {
        $whereConditions[] = "name LIKE ?";
        $params[] = "%{$search}%";
    }
    
    $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
    
    // 获取总数
    $countSql = "SELECT COUNT(*) as total FROM sanctions_list {$whereClause}";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取数据
    $dataSql = "
        SELECT * FROM sanctions_list 
        {$whereClause}
        ORDER BY last_updated DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $db->prepare($dataSql);
    $stmt->execute(array_merge($params, [$limit, $offset]));
    $sanctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $sanctions,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
}

/**
 * 获取合规配置
 */
function getComplianceConfig($complianceManager) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("SELECT * FROM compliance_config ORDER BY category, config_key");
    $stmt->execute();
    $config = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 按分类组织配置
    $groupedConfig = [];
    foreach ($config as $item) {
        $groupedConfig[$item['category']][] = $item;
    }
    
    echo json_encode([
        'success' => true,
        'data' => $groupedConfig
    ]);
}

/**
 * 更新KYC验证状态
 */
function updateKycVerification($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['user_id']) || !isset($input['status'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少必需参数']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE kyc_verifications 
        SET status = ?, verified_by = ?, verified_at = NOW(), rejection_reason = ?
        WHERE user_id = ?
    ");
    $stmt->execute([
        $input['status'],
        $input['verified_by'] ?? null,
        $input['rejection_reason'] ?? null,
        $input['user_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'KYC验证状态更新成功'
    ]);
}

/**
 * 更新AML警报
 */
function updateAmlAlert($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['alert_id']) || !isset($input['status'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少必需参数']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE aml_alerts 
        SET status = ?, assigned_to = ?, resolution_notes = ?, resolved_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([
        $input['status'],
        $input['assigned_to'] ?? null,
        $input['resolution_notes'] ?? null,
        $input['alert_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'AML警报更新成功'
    ]);
}

/**
 * 确认合规事件
 */
function acknowledgeComplianceEvent($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['event_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少事件ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE compliance_events 
        SET acknowledged = TRUE, acknowledged_by = ?, acknowledged_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$input['acknowledged_by'] ?? null, $input['event_id']]);
    
    echo json_encode([
        'success' => true,
        'message' => '合规事件确认成功'
    ]);
}

/**
 * 更新合规配置
 */
function updateComplianceConfig($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['config_key']) || !isset($input['config_value'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少配置键或值']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE compliance_config 
        SET config_value = ?, updated_at = NOW()
        WHERE config_key = ?
    ");
    $stmt->execute([$input['config_value'], $input['config_key']]);
    
    echo json_encode([
        'success' => true,
        'message' => '合规配置更新成功'
    ]);
}



/**
 * 上传KYC文档
 */
function uploadKycDocument($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['user_id']) || !isset($input['document_type']) || !isset($input['document_data'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少必需参数']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        INSERT INTO kyc_documents (user_id, document_type, document_data, uploaded_at)
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([
        $input['user_id'],
        $input['document_type'],
        $input['document_data']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'KYC文档上传成功',
        'document_id' => $db->lastInsertId()
    ]);
}

/**
 * 创建留存策略
 */
function createRetentionPolicy($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $result = $complianceManager->createRetentionPolicy($input);
    echo json_encode($result);
}



/**
 * 创建风险评估规则
 */
function createRiskAssessmentRule($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['rule_name']) || !isset($input['risk_factors'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少必需参数']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        INSERT INTO risk_assessment_rules (rule_name, risk_factors, risk_threshold, is_active, created_at)
        VALUES (?, ?, ?, 1, NOW())
    ");
    $stmt->execute([
        $input['rule_name'],
        json_encode($input['risk_factors']),
        $input['risk_threshold'] ?? 50
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '风险评估规则创建成功',
        'rule_id' => $db->lastInsertId()
    ]);
}

/**
 * 添加制裁名单条目
 */
function addSanctionsListEntry($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['name']) || !isset($input['list_type'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少必需参数']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        INSERT INTO sanctions_list (name, list_type, identification_info, reason, added_by, added_at)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $input['name'],
        $input['list_type'],
        $input['identification_info'] ?? '',
        $input['reason'] ?? '',
        $input['added_by'] ?? 'system'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '制裁名单条目添加成功',
        'entry_id' => $db->lastInsertId()
    ]);
}

/**
 * 更新留存策略
 */
function updateRetentionPolicy($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['policy_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少策略ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE data_retention_policies 
        SET policy_name = ?, retention_days = ?, action_type = ?, execution_frequency = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([
        $input['policy_name'],
        $input['retention_days'],
        $input['action_type'],
        $input['execution_frequency'],
        $input['policy_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '留存策略更新成功'
    ]);
}

/**
 * 更新风险评估规则
 */
function updateRiskAssessmentRule($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['rule_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少规则ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE risk_assessment_rules 
        SET rule_name = ?, risk_factors = ?, risk_threshold = ?, is_active = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([
        $input['rule_name'],
        json_encode($input['risk_factors'] ?? []),
        $input['risk_threshold'] ?? 50,
        $input['is_active'] ?? 1,
        $input['rule_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '风险评估规则更新成功'
    ]);
}

/**
 * 更新制裁名单条目
 */
function updateSanctionsListEntry($complianceManager, $securityManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['entry_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少条目ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        UPDATE sanctions_list 
        SET name = ?, identification_info = ?, reason = ?, active = ?, last_updated = NOW()
        WHERE id = ?
    ");
    $stmt->execute([
        $input['name'],
        $input['identification_info'] ?? '',
        $input['reason'] ?? '',
        $input['active'] ?? 1,
        $input['entry_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '制裁名单条目更新成功'
    ]);
}

/**
 * 删除留存策略
 */
function deleteRetentionPolicy($complianceManager, $securityManager) {
    $policyId = $_GET['policy_id'] ?? '';
    
    if (!$policyId) {
        http_response_code(400);
        echo json_encode(['error' => '缺少策略ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("DELETE FROM data_retention_policies WHERE id = ?");
    $stmt->execute([$policyId]);
    
    echo json_encode([
        'success' => true,
        'message' => '留存策略删除成功'
    ]);
}

/**
 * 删除风险评估规则
 */
function deleteRiskAssessmentRule($complianceManager, $securityManager) {
    $ruleId = $_GET['rule_id'] ?? '';
    
    if (!$ruleId) {
        http_response_code(400);
        echo json_encode(['error' => '缺少规则ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("DELETE FROM risk_assessment_rules WHERE id = ?");
    $stmt->execute([$ruleId]);
    
    echo json_encode([
        'success' => true,
        'message' => '风险评估规则删除成功'
    ]);
}

/**
 * 删除制裁名单条目
 */
function deleteSanctionsListEntry($complianceManager, $securityManager) {
    $entryId = $_GET['entry_id'] ?? '';
    
    if (!$entryId) {
        http_response_code(400);
        echo json_encode(['error' => '缺少条目ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("DELETE FROM sanctions_list WHERE id = ?");
    $stmt->execute([$entryId]);
    
    echo json_encode([
        'success' => true,
        'message' => '制裁名单条目删除成功'
    ]);
}

/**
 * 删除合规报告
 */
function deleteComplianceReport($complianceManager, $securityManager) {
    $reportId = $_GET['report_id'] ?? '';
    
    if (!$reportId) {
        http_response_code(400);
        echo json_encode(['error' => '缺少报告ID']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("DELETE FROM compliance_reports WHERE id = ?");
    $stmt->execute([$reportId]);
    
    echo json_encode([
        'success' => true,
        'message' => '合规报告删除成功'
    ]);
}