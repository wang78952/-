<?php
/**
 * 批量操作API接口
 * 提供批量创建、更新、删除等操作功能
 */

require_once __DIR__ . '/../includes/BaseService.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Logger.php';

class BatchAPI extends BaseService {
    
    private $maxBatchSize = 100;
    private $timeout = 300; // 5分钟超时
    
    public function __construct() {
        $this->logger = new Logger();
    }
    
    /**
     * 处理批量操作请求
     */
    public function processBatchRequest($operation, $data) {
        try {
            // 验证批量操作权限
            $this->validateBatchPermission($operation);
            
            // 验证请求数据
            $this->validateBatchData($data);
            
            // 获取操作处理器
            $handler = $this->getBatchHandler($operation);
            
            // 执行批量操作
            $result = $handler->process($data);
            
            // 记录操作日志
            $this->logBatchOperation($operation, $data, $result);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("Batch operation failed: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 验证批量操作权限
     */
    private function validateBatchPermission($operation) {
        $currentUser = $this->getCurrentUser();
        
        if (!$currentUser) {
            throw new Exception("Authentication required");
        }
        
        // 检查用户是否有批量操作权限
        $requiredPermission = "batch.{$operation}";
        if (!$this->hasPermission($requiredPermission)) {
            throw new Exception("Insufficient permissions for batch operation: {$operation}");
        }
        
        // 检查批量操作限制
        if (!$this->checkBatchLimits($currentUser['id'])) {
            throw new Exception("Batch operation limit exceeded");
        }
    }
    
    /**
     * 验证批量数据
     */
    private function validateBatchData($data) {
        if (!is_array($data)) {
            throw new Exception("Batch data must be an array");
        }
        
        if (empty($data)) {
            throw new Exception("Batch data cannot be empty");
        }
        
        if (count($data) > $this->maxBatchSize) {
            throw new Exception("Batch size exceeds maximum limit of {$this->maxBatchSize}");
        }
        
        // 验证每个数据项
        foreach ($data as $index => $item) {
            if (!is_array($item)) {
                throw new Exception("Batch item at index {$index} must be an object");
            }
        }
    }
    
    /**
     * 获取批量操作处理器
     */
    private function getBatchHandler($operation) {
        switch ($operation) {
            case 'create_users':
                return new BatchCreateUsersHandler();
            case 'update_users':
                return new BatchUpdateUsersHandler();
            case 'delete_users':
                return new BatchDeleteUsersHandler();
            case 'create_products':
                return new BatchCreateProductsHandler();
            case 'update_products':
                return new BatchUpdateProductsHandler();
            case 'delete_products':
                return new BatchDeleteProductsHandler();
            case 'create_orders':
                return new BatchCreateOrdersHandler();
            case 'update_orders':
                return new BatchUpdateOrdersHandler();
            case 'delete_orders':
                return new BatchDeleteOrdersHandler();
            case 'activate_cards':
                return new BatchActivateCardsHandler();
            case 'deactivate_cards':
                return new BatchDeactivateCardsHandler();
            case 'send_notifications':
                return new BatchSendNotificationsHandler();
            default:
                throw new Exception("Unsupported batch operation: {$operation}");
        }
    }
    
    /**
     * 检查批量操作限制
     */
    private function checkBatchLimits($userId) {
        $db = Database::getInstance();
        
        // 检查用户在过去一小时内的批量操作次数
        $oneHourAgo = date('Y-m-d H:i:s', time() - 3600);
        $query = "SELECT COUNT(*) as count FROM batch_operations 
                  WHERE user_id = ? AND created_at > ?";
        $result = $db->fetch($query, [$userId, $oneHourAgo]);
        
        $hourlyLimit = 10; // 每小时最多10次批量操作
        if ($result['count'] >= $hourlyLimit) {
            return false;
        }
        
        // 检查用户在过去24小时内的批量操作总数
        $oneDayAgo = date('Y-m-d H:i:s', time() - 86400);
        $query = "SELECT SUM(item_count) as total_items FROM batch_operations 
                  WHERE user_id = ? AND created_at > ?";
        $result = $db->fetch($query, [$userId, $oneDayAgo]);
        
        $dailyItemLimit = 1000; // 每天最多处理1000个项目
        if ($result['total_items'] >= $dailyItemLimit) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 记录批量操作日志
     */
    private function logBatchOperation($operation, $data, $result) {
        $currentUser = $this->getCurrentUser();
        
        $logData = [
            'operation' => $operation,
            'user_id' => $currentUser['id'],
            'item_count' => count($data),
            'success_count' => $result['success_count'] ?? 0,
            'error_count' => $result['error_count'] ?? 0,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ];
        
        $this->logger->info("Batch operation completed", $logData);
        
        // 保存到数据库
        $db = Database::getInstance();
        $query = "INSERT INTO batch_operations (operation, user_id, item_count, success_count, error_count, ip_address, user_agent, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $db->execute($query, [
            $operation,
            $currentUser['id'],
            count($data),
            $result['success_count'] ?? 0,
            $result['error_count'] ?? 0,
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    }
}

/**
 * 批量操作处理器基类
 */
abstract class BatchHandler {
    
    protected $logger;
    
    public function __construct() {
        $this->logger = new Logger();
    }
    
    /**
     * 处理批量操作
     */
    public function process($data) {
        $startTime = time();
        $results = [
            'success_count' => 0,
            'error_count' => 0,
            'success_items' => [],
            'error_items' => [],
            'processing_time' => 0
        ];
        
        foreach ($data as $index => $item) {
            try {
                $result = $this->processItem($item, $index);
                $results['success_items'][] = $result;
                $results['success_count']++;
                
                // 检查超时
                if (time() - $startTime > 300) { // 5分钟超时
                    throw new Exception("Batch operation timeout");
                }
                
            } catch (Exception $e) {
                $results['error_items'][] = [
                    'index' => $index,
                    'item' => $item,
                    'error' => $e->getMessage()
                ];
                $results['error_count']++;
            }
        }
        
        $results['processing_time'] = time() - $startTime;
        
        return $results;
    }
    
    /**
     * 处理单个项目（子类实现）
     */
    abstract protected function processItem($item, $index);
}

/**
 * 批量创建用户处理器
 */
class BatchCreateUsersHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        // 验证用户数据
        $this->validateUserData($item);
        
        // 检查用户名是否已存在
        if ($this->userExists($item['username'])) {
            throw new Exception("Username already exists: {$item['username']}");
        }
        
        // 创建用户
        $db = Database::getInstance();
        $query = "INSERT INTO users (username, email, password, role, status, created_at) 
                  VALUES (?, ?, ?, ?, 'active', NOW())";
        
        $hashedPassword = password_hash($item['password'], PASSWORD_DEFAULT);
        $userId = $db->execute($query, [
            $item['username'],
            $item['email'],
            $hashedPassword,
            $item['role'] ?? 'user'
        ]);
        
        return [
            'index' => $index,
            'user_id' => $userId,
            'username' => $item['username'],
            'email' => $item['email']
        ];
    }
    
    private function validateUserData($item) {
        $required = ['username', 'email', 'password'];
        foreach ($required as $field) {
            if (empty($item[$field])) {
                throw new Exception("Missing required field: {$field}");
            }
        }
        
        if (!filter_var($item['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }
        
        if (strlen($item['password']) < 6) {
            throw new Exception("Password must be at least 6 characters");
        }
    }
    
    private function userExists($username) {
        $db = Database::getInstance();
        $query = "SELECT id FROM users WHERE username = ?";
        $result = $db->fetch($query, [$username]);
        return !empty($result);
    }
}

/**
 * 批量更新用户处理器
 */
class BatchUpdateUsersHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['id'])) {
            throw new Exception("Missing user ID");
        }
        
        // 构建更新字段
        $updateFields = [];
        $updateValues = [];
        
        $allowedFields = ['username', 'email', 'role', 'status'];
        foreach ($allowedFields as $field) {
            if (isset($item[$field])) {
                $updateFields[] = "{$field} = ?";
                $updateValues[] = $item[$field];
            }
        }
        
        if (empty($updateFields)) {
            throw new Exception("No valid fields to update");
        }
        
        // 执行更新
        $db = Database::getInstance();
        $query = "UPDATE users SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = ?";
        $updateValues[] = $item['id'];
        
        $db->execute($query, $updateValues);
        
        return [
            'index' => $index,
            'user_id' => $item['id'],
            'updated_fields' => array_keys($updateFields)
        ];
    }
}

/**
 * 批量删除用户处理器
 */
class BatchDeleteUsersHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['id'])) {
            throw new Exception("Missing user ID");
        }
        
        // 检查用户是否存在
        $db = Database::getInstance();
        $query = "SELECT id, username FROM users WHERE id = ?";
        $user = $db->fetch($query, [$item['id']]);
        
        if (empty($user)) {
            throw new Exception("User not found: {$item['id']}");
        }
        
        // 软删除用户（标记为已删除）
        $query = "UPDATE users SET status = 'deleted', deleted_at = NOW() WHERE id = ?";
        $db->execute($query, [$item['id']]);
        
        return [
            'index' => $index,
            'user_id' => $item['id'],
            'username' => $user['username']
        ];
    }
}

/**
 * 批量创建产品处理器
 */
class BatchCreateProductsHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        // 验证产品数据
        $this->validateProductData($item);
        
        // 创建产品
        $db = Database::getInstance();
        $query = "INSERT INTO products (name, description, price, category, stock, status, created_at) 
                  VALUES (?, ?, ?, ?, ?, 'active', NOW())";
        
        $productId = $db->execute($query, [
            $item['name'],
            $item['description'] ?? '',
            $item['price'],
            $item['category'] ?? 'default',
            $item['stock'] ?? 0
        ]);
        
        return [
            'index' => $index,
            'product_id' => $productId,
            'name' => $item['name'],
            'price' => $item['price']
        ];
    }
    
    private function validateProductData($item) {
        $required = ['name', 'price'];
        foreach ($required as $field) {
            if (empty($item[$field])) {
                throw new Exception("Missing required field: {$field}");
            }
        }
        
        if (!is_numeric($item['price']) || $item['price'] < 0) {
            throw new Exception("Invalid price value");
        }
    }
}

/**
 * 批量激活卡密处理器
 */
class BatchActivateCardsHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['card_code'])) {
            throw new Exception("Missing card code");
        }
        
        $db = Database::getInstance();
        
        // 查找卡密
        $query = "SELECT id, status FROM cards WHERE code = ?";
        $card = $db->fetch($query, [$item['card_code']]);
        
        if (empty($card)) {
            throw new Exception("Card not found: {$item['card_code']}");
        }
        
        if ($card['status'] === 'active') {
            throw new Exception("Card already active: {$item['card_code']}");
        }
        
        if ($card['status'] === 'used') {
            throw new Exception("Card already used: {$item['card_code']}");
        }
        
        // 激活卡密
        $query = "UPDATE cards SET status = 'active', activated_at = NOW() WHERE id = ?";
        $db->execute($query, [$card['id']]);
        
        return [
            'index' => $index,
            'card_id' => $card['id'],
            'card_code' => $item['card_code']
        ];
    }
}

/**
 * 批量发送通知处理器
 */
class BatchSendNotificationsHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['user_id']) && empty($item['email'])) {
            throw new Exception("Missing user_id or email");
        }
        
        if (empty($item['subject']) || empty($item['message'])) {
            throw new Exception("Missing subject or message");
        }
        
        // 发送通知（这里简化实现）
        $notification = [
            'user_id' => $item['user_id'] ?? null,
            'email' => $item['email'] ?? null,
            'subject' => $item['subject'],
            'message' => $item['message'],
            'type' => $item['type'] ?? 'email',
            'sent_at' => date('Y-m-d H:i:s')
        ];
        
        // 保存通知记录
        $db = Database::getInstance();
        $query = "INSERT INTO notifications (user_id, email, subject, message, type, status, created_at) 
                  VALUES (?, ?, ?, ?, ?, 'sent', NOW())";
        $notificationId = $db->execute($query, [
            $notification['user_id'],
            $notification['email'],
            $notification['subject'],
            $notification['message'],
            $notification['type']
        ]);
        
        return [
            'index' => $index,
            'notification_id' => $notificationId,
            'recipient' => $item['user_id'] ?? $item['email'],
            'subject' => $item['subject']
        ];
    }
}

/**
 * 批量更新产品处理器
 */
class BatchUpdateProductsHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['id'])) {
            throw new Exception("Missing product ID");
        }
        
        // 构建更新字段
        $updateFields = [];
        $updateValues = [];
        
        $allowedFields = ['name', 'description', 'price', 'category', 'stock', 'status'];
        foreach ($allowedFields as $field) {
            if (isset($item[$field])) {
                $updateFields[] = "{$field} = ?";
                $updateValues[] = $item[$field];
            }
        }
        
        if (empty($updateFields)) {
            throw new Exception("No valid fields to update");
        }
        
        // 执行更新
        $db = Database::getInstance();
        $query = "UPDATE products SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = ?";
        $updateValues[] = $item['id'];
        
        $db->execute($query, $updateValues);
        
        return [
            'index' => $index,
            'product_id' => $item['id'],
            'updated_fields' => array_keys($updateFields)
        ];
    }
}

/**
 * 批量删除产品处理器
 */
class BatchDeleteProductsHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['id'])) {
            throw new Exception("Missing product ID");
        }
        
        // 检查产品是否存在
        $db = Database::getInstance();
        $query = "SELECT id, name FROM products WHERE id = ?";
        $product = $db->fetch($query, [$item['id']]);
        
        if (empty($product)) {
            throw new Exception("Product not found: {$item['id']}");
        }
        
        // 软删除产品（标记为已删除）
        $query = "UPDATE products SET status = 'deleted', deleted_at = NOW() WHERE id = ?";
        $db->execute($query, [$item['id']]);
        
        return [
            'index' => $index,
            'product_id' => $item['id'],
            'product_name' => $product['name']
        ];
    }
}

/**
 * 批量创建订单处理器
 */
class BatchCreateOrdersHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        // 验证订单数据
        $this->validateOrderData($item);
        
        // 创建订单
        $db = Database::getInstance();
        $query = "INSERT INTO orders (user_id, product_id, quantity, total_price, status, created_at) 
                  VALUES (?, ?, ?, ?, 'pending', NOW())";
        
        $orderId = $db->execute($query, [
            $item['user_id'],
            $item['product_id'],
            $item['quantity'] ?? 1,
            $item['total_price']
        ]);
        
        return [
            'index' => $index,
            'order_id' => $orderId,
            'user_id' => $item['user_id'],
            'product_id' => $item['product_id']
        ];
    }
    
    private function validateOrderData($item) {
        $required = ['user_id', 'product_id', 'total_price'];
        foreach ($required as $field) {
            if (empty($item[$field])) {
                throw new Exception("Missing required field: {$field}");
            }
        }
        
        if (!is_numeric($item['total_price']) || $item['total_price'] < 0) {
            throw new Exception("Invalid total price value");
        }
    }
}

/**
 * 批量更新订单处理器
 */
class BatchUpdateOrdersHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['id'])) {
            throw new Exception("Missing order ID");
        }
        
        // 构建更新字段
        $updateFields = [];
        $updateValues = [];
        
        $allowedFields = ['status', 'quantity', 'total_price', 'shipping_address'];
        foreach ($allowedFields as $field) {
            if (isset($item[$field])) {
                $updateFields[] = "{$field} = ?";
                $updateValues[] = $item[$field];
            }
        }
        
        if (empty($updateFields)) {
            throw new Exception("No valid fields to update");
        }
        
        // 执行更新
        $db = Database::getInstance();
        $query = "UPDATE orders SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = ?";
        $updateValues[] = $item['id'];
        
        $db->execute($query, $updateValues);
        
        return [
            'index' => $index,
            'order_id' => $item['id'],
            'updated_fields' => array_keys($updateFields)
        ];
    }
}

/**
 * 批量删除订单处理器
 */
class BatchDeleteOrdersHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['id'])) {
            throw new Exception("Missing order ID");
        }
        
        // 检查订单是否存在
        $db = Database::getInstance();
        $query = "SELECT id, order_number FROM orders WHERE id = ?";
        $order = $db->fetch($query, [$item['id']]);
        
        if (empty($order)) {
            throw new Exception("Order not found: {$item['id']}");
        }
        
        // 软删除订单（标记为已删除）
        $query = "UPDATE orders SET status = 'cancelled', cancelled_at = NOW() WHERE id = ?";
        $db->execute($query, [$item['id']]);
        
        return [
            'index' => $index,
            'order_id' => $item['id'],
            'order_number' => $order['order_number']
        ];
    }
}

/**
 * 批量停用卡密处理器
 */
class BatchDeactivateCardsHandler extends BatchHandler {
    
    protected function processItem($item, $index) {
        if (empty($item['card_code'])) {
            throw new Exception("Missing card code");
        }
        
        $db = Database::getInstance();
        
        // 查找卡密
        $query = "SELECT id, status FROM cards WHERE code = ?";
        $card = $db->fetch($query, [$item['card_code']]);
        
        if (empty($card)) {
            throw new Exception("Card not found: {$item['card_code']}");
        }
        
        if ($card['status'] === 'inactive') {
            throw new Exception("Card already inactive: {$item['card_code']}");
        }
        
        if ($card['status'] === 'used') {
            throw new Exception("Cannot deactivate used card: {$item['card_code']}");
        }
        
        // 停用卡密
        $query = "UPDATE cards SET status = 'inactive', deactivated_at = NOW() WHERE id = ?";
        $db->execute($query, [$card['id']]);
        
        return [
            'index' => $index,
            'card_id' => $card['id'],
            'card_code' => $item['card_code']
        ];
    }
}

// API路由处理
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        $operation = $input['operation'] ?? '';
        $data = $input['data'] ?? [];
        
        $batchAPI = new BatchAPI();
        $result = $batchAPI->processBatchRequest($operation, $data);
        
        echo json_encode([
            'success' => true,
            'data' => $result,
            'message' => 'Batch operation completed successfully'
        ]);
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
}