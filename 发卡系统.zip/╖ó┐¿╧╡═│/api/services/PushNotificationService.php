<?php
/**
 * 消息推送服务
 * 用于处理小程序订阅消息和APP推送
 */

class PushNotificationService {
    
    private $db;
    private $config;
    
    private $logger;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->config = require __DIR__ . '/../../config/api.php';
        $this->logger = Logger::getInstance();
    }
    
    /**
     * 发送微信订阅消息
     * @param string $openId - 用户openId
     * @param string $templateId - 模板ID
     * @param array $data - 消息数据
     * @return bool - 发送结果
     */
    public function sendWechatSubscriptionMessage($openId, $templateId, $data) {
        try {
            // 获取access_token
            $accessToken = $this->getWechatAccessToken();
            if (!$accessToken) {
                $this->logger->error('获取微信access_token失败');
                return false;
            }
            
            // 构建请求数据
            $requestData = [
                'touser' => $openId,
                'template_id' => $templateId,
                'data' => $this->formatWechatTemplateData($data)
            ];
            
            // 发送请求
            $url = "https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token={$accessToken}";
            $response = $this->curlPost($url, json_encode($requestData));
            $result = json_decode($response, true);
            
            if ($result && $result['errcode'] == 0) {
                $this->logger->info("微信订阅消息发送成功，用户: {$openId}, 模板: {$templateId}");
                return true;
            } else {
                $this->logger->error("微信订阅消息发送失败: " . ($result['errmsg'] ?? '未知错误'));
                return false;
            }
        } catch (Exception $e) {
            $this->logger->error("发送微信订阅消息异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 发送APP推送消息（极光推送示例）
     * @param string $deviceToken - 设备token
     * @param string $title - 标题
     * @param string $content - 内容
     * @param array $extras - 额外数据
     * @return bool - 发送结果
     */
    public function sendAppPushNotification($deviceToken, $title, $content, $extras = []) {
        try {
            // 极光推送API调用
            $url = 'https://api.jpush.cn/v3/push';
            $appKey = $this->config['jpush']['app_key'] ?? '';
            $masterSecret = $this->config['jpush']['master_secret'] ?? '';
            
            $auth = base64_encode("{$appKey}:{$masterSecret}");
            
            $requestData = [
                'platform' => 'all',
                'audience' => ['registration_id' => [$deviceToken]],
                'notification' => [
                    'alert' => $content,
                    'android' => [
                        'title' => $title,
                        'extras' => $extras
                    ],
                    'ios' => [
                        'alert' => $content,
                        'title' => $title,
                        'badge' => '+1',
                        'extras' => $extras
                    ]
                ],
                'options' => [
                    'apns_production' => $this->config['jpush']['production'] ?? false
                ]
            ];
            
            $response = $this->curlPost($url, json_encode($requestData), [
                'Authorization: Basic ' . $auth,
                'Content-Type: application/json'
            ]);
            
            $result = json_decode($response, true);
            
            if ($result && isset($result['msg_id'])) {
                $this->logger->info("APP推送消息发送成功，设备: {$deviceToken}");
                return true;
            } else {
                $this->logger->error("APP推送消息发送失败: " . ($result['error']['message'] ?? '未知错误'));
                return false;
            }
        } catch (Exception $e) {
            $this->logger->error("发送APP推送消息异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 发送卡密到期提醒
     * @param int $userId - 用户ID
     * @param array $cardInfo - 卡密信息
     * @return bool - 发送结果
     */
    public function sendCardExpiryReminder($userId, $cardInfo) {
        try {
            // 获取用户订阅信息
            $userSubscriptions = $this->getUserSubscriptions($userId);
            if (empty($userSubscriptions)) {
                $this->logger->info("用户 {$userId} 未订阅任何消息模板");
                return false;
            }
            
            $successCount = 0;
            
            // 发送小程序订阅消息
            if (isset($userSubscriptions['wechat']) && $userSubscriptions['wechat']['openid']) {
                $templateId = $userSubscriptions['wechat']['templates']['CARD_EXPIRY_REMINDER'] ?? null;
                if ($templateId) {
                    $data = [
                        'thing1' => ['value' => '卡密到期提醒'],
                        'time2' => ['value' => date('Y-m-d H:i:s')],
                        'thing3' => ['value' => "您的卡密 ({$cardInfo['code']}) 将在 {$cardInfo['days_left']} 天后到期，请及时续期"]
                    ];
                    
                    $result = $this->sendWechatSubscriptionMessage(
                        $userSubscriptions['wechat']['openid'],
                        $templateId,
                        $data
                    );
                    
                    if ($result) {
                        $successCount++;
                    }
                }
            }
            
            // 发送APP推送
            if (isset($userSubscriptions['app']) && $userSubscriptions['app']['device_token']) {
                $title = '卡密到期提醒';
                $content = "您的卡密 ({$cardInfo['code']}) 将在 {$cardInfo['days_left']} 天后到期，请及时续期";
                $extras = [
                    'type' => 'card_expiry',
                    'card_id' => $cardInfo['id'],
                    'expiry_date' => $cardInfo['expiry_date']
                ];
                
                $result = $this->sendAppPushNotification(
                    $userSubscriptions['app']['device_token'],
                    $title,
                    $content,
                    $extras
                );
                
                if ($result) {
                    $successCount++;
                }
            }
            
            // 记录发送历史
            $this->recordPushHistory($userId, 'card_expiry', $cardInfo['id'], $successCount > 0);
            
            return $successCount > 0;
        } catch (Exception $e) {
            $this->logger->error("发送卡密到期提醒异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 发送卡密续期成功通知
     * @param int $userId - 用户ID
     * @param array $cardInfo - 卡密信息
     * @return bool - 发送结果
     */
    public function sendCardRenewSuccessNotification($userId, $cardInfo) {
        try {
            // 获取用户订阅信息
            $userSubscriptions = $this->getUserSubscriptions($userId);
            if (empty($userSubscriptions)) {
                return false;
            }
            
            $successCount = 0;
            
            // 发送小程序订阅消息
            if (isset($userSubscriptions['wechat']) && $userSubscriptions['wechat']['openid']) {
                $templateId = $userSubscriptions['wechat']['templates']['CARD_RENEW_SUCCESS'] ?? null;
                if ($templateId) {
                    $data = [
                        'thing1' => ['value' => '卡密续期成功'],
                        'time2' => ['value' => date('Y-m-d H:i:s')],
                        'thing3' => ['value' => "您的卡密 ({$cardInfo['code']}) 已成功续期至 {$cardInfo['new_expiry_date']}"],
                        'amount4' => ['value' => $cardInfo['renew_amount'] . ' 元']
                    ];
                    
                    $result = $this->sendWechatSubscriptionMessage(
                        $userSubscriptions['wechat']['openid'],
                        $templateId,
                        $data
                    );
                    
                    if ($result) {
                        $successCount++;
                    }
                }
            }
            
            // 发送APP推送
            if (isset($userSubscriptions['app']) && $userSubscriptions['app']['device_token']) {
                $title = '卡密续期成功';
                $content = "您的卡密已成功续期至 {$cardInfo['new_expiry_date']}";
                $extras = [
                    'type' => 'card_renew_success',
                    'card_id' => $cardInfo['id']
                ];
                
                $result = $this->sendAppPushNotification(
                    $userSubscriptions['app']['device_token'],
                    $title,
                    $content,
                    $extras
                );
                
                if ($result) {
                    $successCount++;
                }
            }
            
            // 记录发送历史
            $this->recordPushHistory($userId, 'card_renew_success', $cardInfo['id'], $successCount > 0);
            
            return $successCount > 0;
        } catch (Exception $e) {
            $this->logger->error("发送卡密续期成功通知异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 保存用户订阅状态
     * @param int $userId - 用户ID
     * @param string $templateId - 模板ID
     * @param bool $status - 订阅状态
     */
    public function saveUserSubscriptionStatus($userId, $templateId, $status) {
        try {
            // 检查是否已存在
            $stmt = $this->db->prepare("SELECT id FROM user_subscriptions WHERE user_id = ? AND template_id = ?");
            $stmt->execute([$userId, $templateId]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing) {
                // 更新
                $updateStmt = $this->db->prepare("UPDATE user_subscriptions SET status = ?, updated_at = NOW() WHERE id = ?");
                $updateStmt->execute([$status ? 1 : 0, $existing['id']]);
            } else {
                // 新增
                $insertStmt = $this->db->prepare(
                    "INSERT INTO user_subscriptions (user_id, template_id, status, created_at, updated_at) 
                     VALUES (?, ?, ?, NOW(), NOW())"
                );
                $insertStmt->execute([$userId, $templateId, $status ? 1 : 0]);
            }
            
            return true;
        } catch (Exception $e) {
            $this->logger->error("保存用户订阅状态异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 保存设备推送Token
     * @param int $userId - 用户ID
     * @param string $deviceType - 设备类型
     * @param string $deviceToken - 设备Token
     */
    public function saveDeviceToken($userId, $deviceType, $deviceToken) {
        try {
            // 检查是否已存在
            $stmt = $this->db->prepare("SELECT id FROM user_device_tokens WHERE user_id = ? AND device_type = ?");
            $stmt->execute([$userId, $deviceType]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing) {
                // 更新
                $updateStmt = $this->db->prepare(
                    "UPDATE user_device_tokens SET device_token = ?, updated_at = NOW() WHERE id = ?"
                );
                $updateStmt->execute([$deviceToken, $existing['id']]);
            } else {
                // 新增
                $insertStmt = $this->db->prepare(
                    "INSERT INTO user_device_tokens (user_id, device_type, device_token, created_at, updated_at) 
                     VALUES (?, ?, ?, NOW(), NOW())"
                );
                $insertStmt->execute([$userId, $deviceType, $deviceToken]);
            }
            
            return true;
        } catch (Exception $e) {
            $this->logger->error("保存设备Token异常: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取用户订阅信息
     * @param int $userId - 用户ID
     * @return array - 订阅信息
     */
    private function getUserSubscriptions($userId) {
        $result = [];
        
        try {
            // 获取微信订阅信息
            $wechatStmt = $this->db->prepare(
                "SELECT u.openid, us.template_id, us.status 
                 FROM users u 
                 LEFT JOIN user_subscriptions us ON u.id = us.user_id 
                 WHERE u.id = ? AND us.status = 1"
            );
            $wechatStmt->execute([$userId]);
            $wechatSubs = $wechatStmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($wechatSubs)) {
                $templates = [];
                foreach ($wechatSubs as $sub) {
                    $templates[$sub['template_id']] = $sub['template_id'];
                }
                
                $result['wechat'] = [
                    'openid' => $wechatSubs[0]['openid'],
                    'templates' => $templates
                ];
            }
            
            // 获取APP设备信息
            $appStmt = $this->db->prepare(
                "SELECT device_type, device_token 
                 FROM user_device_tokens 
                 WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1"
            );
            $appStmt->execute([$userId]);
            $appDevice = $appStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($appDevice) {
                $result['app'] = $appDevice;
            }
            
        } catch (Exception $e) {
            $this->logger->error("获取用户订阅信息异常: " . $e->getMessage());
        }
        
        return $result;
    }
    
    /**
     * 获取微信access_token
     * @return string - access_token
     */
    private function getWechatAccessToken() {
        // 先尝试从缓存获取
        $cacheKey = 'wechat_access_token';
        $cached = Cache::get($cacheKey);
        if ($cached) {
            return $cached;
        }
        
        // 从数据库获取最新的token
        $stmt = $this->db->query("SELECT access_token, expires_at FROM wechat_access_tokens ORDER BY created_at DESC LIMIT 1");
        $tokenData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($tokenData && strtotime($tokenData['expires_at']) > time()) {
            // 缓存token
            Cache::set($cacheKey, $tokenData['access_token'], 3600);
            return $tokenData['access_token'];
        }
        
        // 需要重新获取
        $appId = $this->config['wechat']['app_id'] ?? '';
        $appSecret = $this->config['wechat']['app_secret'] ?? '';
        
        $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$appId}&secret={$appSecret}";
        $response = $this->curlGet($url);
        $result = json_decode($response, true);
        
        if ($result && isset($result['access_token'])) {
            $expiresIn = $result['expires_in'] ?? 7200;
            $expiresAt = date('Y-m-d H:i:s', time() + $expiresIn - 300); // 提前5分钟过期
            
            // 保存到数据库
            $insertStmt = $this->db->prepare(
                "INSERT INTO wechat_access_tokens (access_token, expires_at, created_at) VALUES (?, ?, NOW())"
            );
            $insertStmt->execute([$result['access_token'], $expiresAt]);
            
            // 缓存
            Cache::set($cacheKey, $result['access_token'], $expiresIn - 300);
            
            return $result['access_token'];
        }
        
        return null;
    }
    
    /**
     * 格式化微信模板数据
     * @param array $data - 原始数据
     * @return array - 格式化后的数据
     */
    private function formatWechatTemplateData($data) {
        $formatted = [];
        
        foreach ($data as $key => $value) {
            $formatted[$key] = [
                'value' => is_array($value) ? $value['value'] : $value
            ];
        }
        
        return $formatted;
    }
    
    /**
     * 记录推送历史
     */
    private function recordPushHistory($userId, $type, $relatedId, $success) {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO push_histories (user_id, push_type, related_id, success, created_at) 
                 VALUES (?, ?, ?, ?, NOW())"
            );
            $stmt->execute([$userId, $type, $relatedId, $success ? 1 : 0]);
        } catch (Exception $e) {
            $this->logger->error("记录推送历史异常: " . $e->getMessage());
        }
    }
    
    /**
     * curl POST请求
     */
    private function curlPost($url, $data, $headers = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        } else {
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);
        }
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;
    }
    
    /**
     * curl GET请求
     */
    private function curlGet($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;
    }
}
?>