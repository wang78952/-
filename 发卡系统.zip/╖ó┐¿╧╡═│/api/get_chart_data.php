<?php
/**
 * 图表数据API接口
 * 提供各种图表所需的数据
 */

// 引入配置和必要的类文件
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/utils/ResponseHandler.php';
require_once __DIR__ . '/../includes/utils/AuthUtils.php';

// 初始化响应处理器
$responseHandler = new ResponseHandler();

// 检查用户是否登录
if (!AuthUtils::isLoggedIn()) {
    $responseHandler->error('请先登录', 401);
}

// 获取请求参数
$chartType = isset($_GET['type']) ? $_GET['type'] : '';
$period = isset($_GET['period']) ? $_GET['period'] : '30d'; // 默认30天
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// 验证必要参数
if (empty($chartType)) {
    $responseHandler->error('图表类型不能为空', 400);
}

// 设置日期范围
if (empty($startDate) || empty($endDate)) {
    $endDate = date('Y-m-d');
    switch ($period) {
        case '7d':
            $startDate = date('Y-m-d', strtotime('-7 days'));
            break;
        case '30d':
            $startDate = date('Y-m-d', strtotime('-30 days'));
            break;
        case '90d':
            $startDate = date('Y-m-d', strtotime('-90 days'));
            break;
        case '1y':
            $startDate = date('Y-m-d', strtotime('-1 year'));
            break;
        default:
            $startDate = date('Y-m-d', strtotime('-30 days'));
    }
}

// 根据图表类型获取数据
try {
    switch ($chartType) {
        case 'sales_trend':
            $data = getSalesTrendData($startDate, $endDate);
            break;
        case 'order_count':
            $data = getOrderCountData($startDate, $endDate);
            break;
        case 'user_activity':
            $data = getUserActivityData($startDate, $endDate);
            break;
        case 'card_status':
            $data = getCardStatusData();
            break;
        case 'points_usage':
            $data = getPointsUsageData($startDate, $endDate);
            break;
        case 'product_category':
            $data = getProductCategoryData($startDate, $endDate);
            break;
        case 'hourly_orders':
            $data = getHourlyOrdersData();
            break;
        default:
            $responseHandler->error('不支持的图表类型', 400);
    }
    
    $responseHandler->success($data);
} catch (Exception $e) {
    $responseHandler->error('获取图表数据失败: ' . $e->getMessage(), 500);
}

/**
 * 获取销售趋势数据
 */
function getSalesTrendData($startDate, $endDate) {
    global $db;
    
    try {
        // 根据日期范围生成日期数组
        $dates = generateDateRange($startDate, $endDate);
        $labels = $dates;
        
        // 初始化数据数组
        $data = array_fill(0, count($dates), 0);
        
        // 查询实际销售数据
        $sql = "SELECT DATE(created_at) as date, SUM(total_amount) as sales 
                FROM orders 
                WHERE status != 'cancelled' 
                AND created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY) 
                GROUP BY DATE(created_at)";
        
        $stmt = $db->prepare($sql);
        $stmt->bind_param('ss', $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();
        
        // 将查询结果填充到数据数组
        while ($row = $result->fetch_assoc()) {
            $index = array_search($row['date'], $dates);
            if ($index !== false) {
                $data[$index] = (float)$row['sales'];
            }
        }
        
        return [
            'labels' => $labels,
            'series' => [
                [
                    'name' => '销售额',
                    'data' => $data,
                    'color' => '#667eea'
                ]
            ]
        ];
    } catch (Exception $e) {
        // 发生错误时返回模拟数据
        return generateMockSalesTrendData($startDate, $endDate);
    }
}

/**
 * 获取订单数量数据
 */
function getOrderCountData($startDate, $endDate) {
    global $db;
    
    try {
        $dates = generateDateRange($startDate, $endDate);
        $labels = $dates;
        $data = array_fill(0, count($dates), 0);
        
        $sql = "SELECT DATE(created_at) as date, COUNT(*) as order_count 
                FROM orders 
                WHERE status != 'cancelled' 
                AND created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY) 
                GROUP BY DATE(created_at)";
        
        $stmt = $db->prepare($sql);
        $stmt->bind_param('ss', $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $index = array_search($row['date'], $dates);
            if ($index !== false) {
                $data[$index] = (int)$row['order_count'];
            }
        }
        
        return [
            'labels' => $labels,
            'series' => [
                [
                    'name' => '订单数量',
                    'data' => $data,
                    'color' => '#43e97b'
                ]
            ]
        ];
    } catch (Exception $e) {
        return generateMockOrderCountData($startDate, $endDate);
    }
}

/**
 * 获取用户活跃度数据
 */
function getUserActivityData($startDate, $endDate) {
    global $db;
    
    try {
        $dates = generateDateRange($startDate, $endDate);
        $labels = $dates;
        $newUsers = array_fill(0, count($dates), 0);
        $activeUsers = array_fill(0, count($dates), 0);
        
        // 查询新增用户
        $sql1 = "SELECT DATE(created_at) as date, COUNT(*) as count 
                FROM users 
                WHERE created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY) 
                GROUP BY DATE(created_at)";
        
        $stmt1 = $db->prepare($sql1);
        $stmt1->bind_param('ss', $startDate, $endDate);
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        
        while ($row = $result1->fetch_assoc()) {
            $index = array_search($row['date'], $dates);
            if ($index !== false) {
                $newUsers[$index] = (int)$row['count'];
            }
        }
        
        // 查询活跃用户（有登录记录的用户）
        $sql2 = "SELECT DATE(login_time) as date, COUNT(DISTINCT user_id) as count 
                FROM user_login_history 
                WHERE login_time BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY) 
                GROUP BY DATE(login_time)";
        
        $stmt2 = $db->prepare($sql2);
        $stmt2->bind_param('ss', $startDate, $endDate);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        
        while ($row = $result2->fetch_assoc()) {
            $index = array_search($row['date'], $dates);
            if ($index !== false) {
                $activeUsers[$index] = (int)$row['count'];
            }
        }
        
        return [
            'labels' => $labels,
            'series' => [
                [
                    'name' => '新增用户',
                    'data' => $newUsers,
                    'color' => '#667eea'
                ],
                [
                    'name' => '活跃用户',
                    'data' => $activeUsers,
                    'color' => '#f5576c'
                ]
            ]
        ];
    } catch (Exception $e) {
        return generateMockUserActivityData($startDate, $endDate);
    }
}

/**
 * 获取卡片状态分布数据
 */
function getCardStatusData() {
    global $db;
    
    try {
        $sql = "SELECT status, COUNT(*) as count FROM cards GROUP BY status";
        $result = $db->query($sql);
        
        $data = [];
        $statusMap = [
            'active' => '已激活',
            'inactive' => '未激活',
            'suspended' => '已暂停',
            'cancelled' => '已注销',
            'expired' => '已过期'
        ];
        
        while ($row = $result->fetch_assoc()) {
            $status = $row['status'];
            $data[] = [
                'name' => isset($statusMap[$status]) ? $statusMap[$status] : $status,
                'value' => (int)$row['count']
            ];
        }
        
        return $data;
    } catch (Exception $e) {
        // 返回模拟数据
        return [
            ['name' => '已激活', 'value' => 1250],
            ['name' => '未激活', 'value' => 380],
            ['name' => '已暂停', 'value' => 120],
            ['name' => '已注销', 'value' => 80],
            ['name' => '已过期', 'value' => 150]
        ];
    }
}

/**
 * 获取积分使用数据
 */
function getPointsUsageData($startDate, $endDate) {
    global $db;
    
    try {
        $dates = generateDateRange($startDate, $endDate);
        $labels = $dates;
        $earnedPoints = array_fill(0, count($dates), 0);
        $spentPoints = array_fill(0, count($dates), 0);
        
        // 查询积分获取记录
        $sql1 = "SELECT DATE(created_at) as date, SUM(points_change) as points 
                FROM user_points_log 
                WHERE points_change > 0 
                AND created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY) 
                GROUP BY DATE(created_at)";
        
        $stmt1 = $db->prepare($sql1);
        $stmt1->bind_param('ss', $startDate, $endDate);
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        
        while ($row = $result1->fetch_assoc()) {
            $index = array_search($row['date'], $dates);
            if ($index !== false) {
                $earnedPoints[$index] = (int)$row['points'];
            }
        }
        
        // 查询积分使用记录
        $sql2 = "SELECT DATE(created_at) as date, SUM(ABS(points_change)) as points 
                FROM user_points_log 
                WHERE points_change < 0 
                AND created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY) 
                GROUP BY DATE(created_at)";
        
        $stmt2 = $db->prepare($sql2);
        $stmt2->bind_param('ss', $startDate, $endDate);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        
        while ($row = $result2->fetch_assoc()) {
            $index = array_search($row['date'], $dates);
            if ($index !== false) {
                $spentPoints[$index] = (int)$row['points'];
            }
        }
        
        return [
            'labels' => $labels,
            'series' => [
                [
                    'name' => '获取积分',
                    'data' => $earnedPoints,
                    'color' => '#43e97b'
                ],
                [
                    'name' => '使用积分',
                    'data' => $spentPoints,
                    'color' => '#f5576c'
                ]
            ]
        ];
    } catch (Exception $e) {
        return generateMockPointsUsageData($startDate, $endDate);
    }
}

/**
 * 获取商品分类分布数据
 */
function getProductCategoryData($startDate, $endDate) {
    global $db;
    
    try {
        $sql = "SELECT c.name as category_name, SUM(oi.quantity) as purchase_count 
                FROM order_items oi
                JOIN orders o ON oi.order_id = o.id
                JOIN products p ON oi.product_id = p.id
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE o.status != 'cancelled'
                AND o.created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)
                GROUP BY c.name
                ORDER BY purchase_count DESC
                LIMIT 10";
        
        $stmt = $db->prepare($sql);
        $stmt->bind_param('ss', $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'name' => $row['category_name'] ?: '未分类',
                'value' => (int)$row['purchase_count']
            ];
        }
        
        return $data;
    } catch (Exception $e) {
        // 返回模拟数据
        return [
            ['name' => '软件激活码', 'value' => 850],
            ['name' => '游戏点数卡', 'value' => 620],
            ['name' => '会员套餐', 'value' => 540],
            ['name' => '网络流量', 'value' => 480],
            ['name' => '云服务', 'value' => 320],
            ['name' => '其他', 'value' => 150]
        ];
    }
}

/**
 * 获取每小时订单分布数据
 */
function getHourlyOrdersData() {
    global $db;
    
    try {
        // 初始化小时数组
        $hours = [];
        $orderCounts = array_fill(0, 24, 0);
        
        for ($i = 0; $i < 24; $i++) {
            $hours[] = sprintf('%02d:00', $i);
        }
        
        // 查询每小时订单数
        $sql = "SELECT HOUR(created_at) as hour, COUNT(*) as count 
                FROM orders 
                WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY HOUR(created_at)";
        
        $result = $db->query($sql);
        
        while ($row = $result->fetch_assoc()) {
            $hour = (int)$row['hour'];
            $orderCounts[$hour] = (int)$row['count'];
        }
        
        return [
            'labels' => $hours,
            'series' => [
                [
                    'name' => '订单数量',
                    'data' => $orderCounts,
                    'color' => '#faad14'
                ]
            ]
        ];
    } catch (Exception $e) {
        // 返回模拟数据
        return [
            'labels' => array_map(function($h) { return sprintf('%02d:00', $h); }, range(0, 23)),
            'series' => [
                [
                    'name' => '订单数量',
                    'data' => [25, 18, 15, 10, 8, 12, 35, 85, 120, 150, 165, 170, 190, 185, 210, 240, 280, 320, 290, 240, 180, 120, 80, 40],
                    'color' => '#faad14'
                ]
            ]
        ];
    }
}

/**
 * 生成日期范围数组
 */
function generateDateRange($startDate, $endDate) {
    $dates = [];
    $current = strtotime($startDate);
    $end = strtotime($endDate);
    
    while ($current <= $end) {
        $dates[] = date('Y-m-d', $current);
        $current = strtotime('+1 day', $current);
    }
    
    return $dates;
}

/**
 * 生成模拟销售趋势数据
 */
function generateMockSalesTrendData($startDate, $endDate) {
    $dates = generateDateRange($startDate, $endDate);
    $data = [];
    
    foreach ($dates as $date) {
        // 生成有波动的模拟数据
        $baseValue = 5000 + rand(-2000, 3000);
        $data[] = max(1000, $baseValue);
    }
    
    return [
        'labels' => $dates,
        'series' => [
            [
                'name' => '销售额',
                'data' => $data,
                'color' => '#667eea'
            ]
        ]
    ];
}

/**
 * 生成模拟订单数量数据
 */
function generateMockOrderCountData($startDate, $endDate) {
    $dates = generateDateRange($startDate, $endDate);
    $data = [];
    
    foreach ($dates as $date) {
        $data[] = rand(50, 200);
    }
    
    return [
        'labels' => $dates,
        'series' => [
            [
                'name' => '订单数量',
                'data' => $data,
                'color' => '#43e97b'
            ]
        ]
    ];
}

/**
 * 生成模拟用户活跃度数据
 */
function generateMockUserActivityData($startDate, $endDate) {
    $dates = generateDateRange($startDate, $endDate);
    $newUsers = [];
    $activeUsers = [];
    
    foreach ($dates as $date) {
        $newUserCount = rand(10, 40);
        $newUsers[] = $newUserCount;
        // 活跃用户通常是新增用户的3-5倍
        $activeUsers[] = $newUserCount * (3 + rand(0, 2));
    }
    
    return [
        'labels' => $dates,
        'series' => [
            [
                'name' => '新增用户',
                'data' => $newUsers,
                'color' => '#667eea'
            ],
            [
                'name' => '活跃用户',
                'data' => $activeUsers,
                'color' => '#f5576c'
            ]
        ]
    ];
}

/**
 * 生成模拟积分使用数据
 */
function generateMockPointsUsageData($startDate, $endDate) {
    $dates = generateDateRange($startDate, $endDate);
    $earnedPoints = [];
    $spentPoints = [];
    
    foreach ($dates as $date) {
        $earned = rand(5000, 20000);
        $earnedPoints[] = $earned;
        // 消费的积分通常是获得积分的40%-60%
        $spentPoints[] = round($earned * (0.4 + rand(0, 20) / 100));
    }
    
    return [
        'labels' => $dates,
        'series' => [
            [
                'name' => '获取积分',
                'data' => $earnedPoints,
                'color' => '#43e97b'
            ],
            [
                'name' => '使用积分',
                'data' => $spentPoints,
                'color' => '#f5576c'
            ]
        ]
    ];
}