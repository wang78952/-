-- API系统相关表结构

-- API会话表
CREATE TABLE IF NOT EXISTS `api_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `api_token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `last_access` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_token` (`api_token`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `api_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 用户权限表
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission` (`user_id`, `permission`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- API访问日志表
CREATE TABLE IF NOT EXISTS `api_access_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text,
  `endpoint` varchar(255) NOT NULL,
  `method` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ip_address` (`ip_address`),
  KEY `created_at` (`created_at`),
  KEY `endpoint` (`endpoint`),
  CONSTRAINT `api_access_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- API请求日志表
CREATE TABLE IF NOT EXISTS `api_request_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(10) NOT NULL,
  `uri` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text,
  `user_id` int(11) DEFAULT NULL,
  `status_code` int(11) NOT NULL,
  `duration_ms` decimal(10,2) DEFAULT NULL,
  `request_size` int(11) DEFAULT NULL,
  `response_size` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `method` (`method`),
  KEY `ip_address` (`ip_address`),
  KEY `user_id` (`user_id`),
  KEY `status_code` (`status_code`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `api_request_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- API限流表
CREATE TABLE IF NOT EXISTS `api_rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 插入默认权限数据
INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`) VALUES
(1, 'dashboard_view'),
(1, 'card_read'),
(1, 'card_create'),
(1, 'card_update'),
(1, 'card_delete'),
(1, 'identity_verify'),
(1, 'log_view'),
(1, 'user_manage'),
(1, 'system_config');

-- 为现有用户添加默认权限（如果不存在）
INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'dashboard_view' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'dashboard_view');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'card_read' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'card_read');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'card_create' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'card_create');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'card_update' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'card_update');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'card_delete' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'card_delete');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'identity_verify' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'identity_verify');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'log_view' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'log_view');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'user_manage' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'user_manage');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'system_config' FROM `users` WHERE role = 'admin' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'system_config');

-- 为操作员用户添加基本权限
INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'dashboard_view' FROM `users` WHERE role = 'operator' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'dashboard_view');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'card_read' FROM `users` WHERE role = 'operator' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'card_read');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'card_create' FROM `users` WHERE role = 'operator' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'card_create');

INSERT IGNORE INTO `user_permissions` (`user_id`, `permission`)
SELECT id, 'identity_verify' FROM `users` WHERE role = 'operator' AND id NOT IN (SELECT user_id FROM `user_permissions` WHERE permission = 'identity_verify');