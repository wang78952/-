# 发卡系统 RESTful API 文档

## 概述

本文档描述了发卡系统的 RESTful API 接口，包括用户认证、卡片管理、身份核验和系统统计等功能。

## 基础信息

- **Base URL**: `http://your-domain.com/api`
- **Content-Type**: `application/json`
- **认证方式**: Bearer Token

## 认证

所有需要认证的接口都需要在请求头中包含有效的 API Token：

```
Authorization: Bearer {your_api_token}
```

## 通用响应格式

### 成功响应
```json
{
    "success": true,
    "data": { ... },
    "message": "操作成功",
    "timestamp": "2024-01-01 12:00:00"
}
```

### 错误响应
```json
{
    "success": false,
    "error": "ERROR_CODE",
    "message": "错误描述",
    "timestamp": "2024-01-01 12:00:00"
}
```

## 接口列表

### 1. 用户认证

#### 1.1 用户登录
- **URL**: `POST /auth/login`
- **描述**: 用户登录获取 API Token
- **请求体**:
```json
{
    "username": "admin",
    "password": "password123"
}
```
- **响应**:
```json
{
    "success": true,
    "data": {
        "user_id": 1,
        "username": "admin",
        "role": "admin",
        "api_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
        "expires_at": "2024-01-02 12:00:00"
    },
    "message": "登录成功"
}
```

#### 1.2 用户登出
- **URL**: `POST /auth/logout`
- **描述**: 用户登出，撤销 API Token
- **认证**: 需要
- **响应**:
```json
{
    "success": true,
    "data": {
        "message": "登出成功"
    }
}
```

#### 1.3 获取当前用户信息
- **URL**: `GET /auth/me`
- **描述**: 获取当前登录用户的信息
- **认证**: 需要
- **响应**:
```json
{
    "success": true,
    "data": {
        "id": 1,
        "username": "admin",
        "role": "admin",
        "status": "active",
        "last_login": "2024-01-01 12:00:00",
        "permissions": ["card_read", "card_create", ...]
    }
}
```

#### 1.4 修改密码
- **URL**: `POST /auth/change-password`
- **描述**: 修改当前用户密码
- **认证**: 需要
- **请求体**:
```json
{
    "current_password": "oldpassword",
    "new_password": "newpassword123"
}
```

### 2. 用户管理

#### 2.1 获取用户列表
- **URL**: `GET /users`
- **描述**: 获取用户列表（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **查询参数**:
  - `page`: 页码（默认1）
  - `limit`: 每页数量（默认20，最大100）
  - `status`: 用户状态过滤
  - `role`: 用户角色过滤
  - `search`: 搜索用户名或邮箱
- **响应**:
```json
{
    "success": true,
    "data": {
        "users": [
            {
                "id": 1,
                "username": "admin",
                "email": "admin@example.com",
                "role": "admin",
                "status": "active",
                "last_login": "2024-01-01 12:00:00",
                "created_at": "2024-01-01 10:00:00"
            }
        ],
        "pagination": {
            "page": 1,
            "limit": 20,
            "total": 50,
            "pages": 3
        }
    }
}
```

#### 2.2 创建用户
- **URL**: `POST /users`
- **描述**: 创建新用户（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **请求体**:
```json
{
    "username": "newuser",
    "password": "password123",
    "email": "user@example.com",
    "role": "operator",
    "status": "active"
}
```

#### 2.3 获取用户详情
- **URL**: `GET /users/{id}`
- **描述**: 获取指定用户的详细信息
- **认证**: 需要
- **权限**: user_manage

#### 2.4 更新用户
- **URL**: `PUT /users/{id}`
- **描述**: 更新用户信息（仅管理员）
- **认证**: 需要
- **权限**: user_manage
- **请求体**:
```json
{
    "email": "newemail@example.com",
    "role": "operator",
    "status": "active"
}
```

#### 2.5 删除用户
- **URL**: `DELETE /users/{id}`
- **描述**: 删除用户（仅管理员）
- **认证**: 需要
- **权限**: user_manage

### 3. 卡片管理

#### 3.1 获取卡片列表
- **URL**: `GET /cards`
- **描述**: 获取卡片列表
- **认证**: 需要
- **权限**: card_read
- **查询参数**:
  - `page`: 页码
  - `limit`: 每页数量
  - `status`: 卡片状态过滤
  - `card_type`: 卡片类型过滤
  - `search`: 搜索卡号或银行名称
- **响应**:
```json
{
    "success": true,
    "data": {
        "cards": [
            {
                "id": 1,
                "card_number": "**** **** **** 1234",
                "card_type": "credit",
                "bank_name": "中国银行",
                "credit_limit": 50000.00,
                "status": "active",
                "created_at": "2024-01-01 12:00:00"
            }
        ],
        "pagination": {
            "page": 1,
            "limit": 20,
            "total": 100,
            "pages": 5
        }
    }
}
```

#### 3.2 创建卡片
- **URL**: `POST /cards`
- **描述**: 创建新卡片
- **认证**: 需要
- **权限**: card_create
- **请求体**:
```json
{
    "card_number": "1234567890123456",
    "card_holder": "张三",
    "id_card": "110101199001011234",
    "phone": "13800138000",
    "card_type": "credit",
    "bank_name": "中国银行",
    "credit_limit": 50000.00,
    "issue_date": "2024-01-01",
    "expire_date": "2029-01-01"
}
```

#### 3.3 获取卡片详情
- **URL**: `GET /cards/{id}`
- **描述**: 获取指定卡片的详细信息
- **认证**: 需要
- **权限**: card_read

#### 3.4 更新卡片
- **URL**: `PUT /cards/{id}`
- **描述**: 更新卡片信息
- **认证**: 需要
- **权限**: card_update
- **请求体**:
```json
{
    "status": "active",
    "credit_limit": 60000.00
}
```

#### 3.5 删除卡片
- **URL**: `DELETE /cards/{id}`
- **描述**: 删除卡片（软删除）
- **认证**: 需要
- **权限**: card_delete

#### 3.6 获取卡片统计
- **URL**: `GET /cards/stats`
- **描述**: 获取卡片统计信息
- **认证**: 需要
- **权限**: card_read
- **响应**:
```json
{
    "success": true,
    "data": {
        "total_cards": 100,
        "active_cards": 80,
        "inactive_cards": 10,
        "suspended_cards": 5,
        "cancelled_cards": 3,
        "expired_cards": 2,
        "by_type": {
            "credit": 60,
            "debit": 40
        },
        "by_bank": [
            {
                "bank_name": "中国银行",
                "count": 30
            }
        ]
    }
}
```

### 4. 身份核验

#### 4.1 获取核验列表
- **URL**: `GET /verifications`
- **描述**: 获取身份核验列表
- **认证**: 需要
- **权限**: identity_verify
- **查询参数**:
  - `page`: 页码
  - `limit`: 每页数量
  - `status`: 核验状态过滤
  - `verification_type`: 核验类型过滤
  - `search`: 搜索任务ID

#### 4.2 创建核验任务
- **URL**: `POST /verifications`
- **描述**: 创建身份核验任务
- **认证**: 需要
- **权限**: identity_verify
- **请求体**:
```json
{
    "id_card": "110101199001011234",
    "name": "张三",
    "phone": "13800138000",
    "verification_type": "basic"
}
```

#### 4.3 获取核验详情
- **URL**: `GET /verifications/{id}`
- **描述**: 获取指定核验的详细信息
- **认证**: 需要
- **权限**: identity_verify

#### 4.4 执行核验
- **URL**: `POST /verifications/{id}/execute`
- **描述**: 执行身份核验
- **认证**: 需要
- **权限**: identity_verify

#### 4.5 获取核验统计
- **URL**: `GET /verifications/stats`
- **描述**: 获取身份核验统计信息
- **认证**: 需要
- **权限**: identity_verify

### 5. 统计信息

#### 5.1 获取仪表板统计
- **URL**: `GET /stats/dashboard`
- **描述**: 获取仪表板统计信息
- **认证**: 需要
- **权限**: dashboard_view
- **响应**:
```json
{
    "success": true,
    "data": {
        "card_stats": {
            "total": 100,
            "active": 80,
            "inactive": 10
        },
        "verification_stats": {
            "total": 50,
            "pending": 5,
            "approved": 40,
            "rejected": 5
        },
        "recent_activities": [
            {
                "type": "card_added",
                "description": "添加新卡片",
                "details": "中国银行",
                "timestamp": "2024-01-01 12:00:00"
            }
        ],
        "trends": {
            "cards": [
                {"date": "2024-01-01", "count": 10}
            ],
            "verifications": [
                {"date": "2024-01-01", "count": 5}
            ]
        }
    }
}
```

#### 5.2 获取详细卡片统计
- **URL**: `GET /stats/cards`
- **描述**: 获取详细的卡片统计信息
- **认证**: 需要
- **权限**: card_read

#### 5.3 获取详细核验统计
- **URL**: `GET /stats/verifications`
- **描述**: 获取详细的身份核验统计信息
- **认证**: 需要
- **权限**: identity_verify

#### 5.4 获取系统健康状态
- **URL**: `GET /stats/system-health`
- **描述**: 获取系统健康状态监控
- **认证**: 需要
- **权限**: log_view
- **响应**:
```json
{
    "success": true,
    "data": {
        "overall": {
            "score": 95.5,
            "status": "healthy"
        },
        "database": {
            "score": 100,
            "status": "healthy",
            "details": {
                "tables_exist": "5/5",
                "recent_errors": 0,
                "connection": "ok"
            }
        },
        "security": {
            "score": 90,
            "status": "healthy",
            "details": {
                "security_events_24h": 2,
                "failed_logins_24h": 1
            }
        },
        "performance": {
            "score": 95,
            "status": "healthy",
            "details": {
                "query_time_ms": 45.2,
                "response_time": "good"
            }
        },
        "compliance": {
            "score": 98,
            "status": "healthy",
            "details": {
                "active_alerts": 0,
                "pending_authorizations": 1
            }
        }
    }
}
```

## 错误代码

| 错误代码 | HTTP状态码 | 描述 |
|---------|-----------|------|
| UNAUTHORIZED | 401 | 未认证或认证失败 |
| FORBIDDEN | 403 | 权限不足 |
| NOT_FOUND | 404 | 资源不存在 |
| VALIDATION_ERROR | 400 | 请求参数验证失败 |
| INTERNAL_ERROR | 500 | 服务器内部错误 |

## 限流规则

- 每个用户每分钟最多 100 次请求
- 登录接口每分钟最多 10 次尝试
- 超出限制将返回 429 状态码

## 安全说明

1. 所有敏感数据在传输和存储时都会加密
2. API Token 有效期为 24 小时
3. 系统会记录所有 API 访问日志
4. 支持数据脱敏，根据用户角色显示不同级别的信息

## 示例代码

### JavaScript (fetch)
```javascript
// 登录
const loginResponse = await fetch('/api/auth/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
            username: 'your_username',
            password: 'your_secure_password'
        })
});

const loginData = await loginResponse.json();
const token = loginData.data.api_token;

// 获取卡片列表
const cardsResponse = await fetch('/api/cards', {
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    }
});

const cardsData = await cardsResponse.json();
```

### Python (requests)
```python
import requests

# 登录
login_response = requests.post('http://your-domain.com/api/auth/login', json={
    'username': 'your_username',
    'password': 'your_secure_password'
})

login_data = login_response.json()
token = login_data['data']['api_token']

# 获取卡片列表
cards_response = requests.get('http://your-domain.com/api/cards', headers={
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
})

cards_data = cards_response.json()
```

## 版本信息

- **当前版本**: v1.0
- **更新日期**: 2024-01-01
- **兼容性**: 支持所有现代浏览器和 HTTP 客户端