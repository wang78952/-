<?php
require_once '../includes/Database.php';
require_once '../includes/AgentManager.php';
require_once '../includes/CommissionManager.php';

// 启用会话
session_start();

// 设置响应头
header('Content-Type: application/json');

// 获取请求方法和操作
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

// 创建数据库连接和管理器
$database = new Database();
$db = $database->getConnection();
$agentManager = new AgentManager($db);
$commissionManager = new CommissionManager($db);

try {
    switch ($action) {
        case 'calculate_commission':
            // 计算订单佣金
            if ($method === 'POST') {
                $input = json_decode(file_get_contents('php://input'), true);
                
                $orderId = isset($input['order_id']) ? intval($input['order_id']) : 0;
                $orderAmount = isset($input['order_amount']) ? floatval($input['order_amount']) : 0;
                $agentId = !empty($input['agent_id']) ? intval($input['agent_id']) : null;
                $referralCode = isset($input['referral_code']) ? $input['referral_code'] : '';
                
                if ($orderId <= 0 || $orderAmount <= 0) {
                    throw new Exception('订单ID和订单金额必须大于0');
                }
                
                // 如果没有提供代理ID，尝试通过推荐码查找代理
                if (!$agentId && !empty($referralCode)) {
                    $agent = $agentManager->getAgentByReferralCode($referralCode);
                    if ($agent && $agent['status'] === 'active') {
                        $agentId = $agent['id'];
                    }
                }
                
                if (!$agentId) {
                    // 没有代理，不计算佣金
                    echo json_encode(array('success' => true, 'data' => array('commission_calculated' => false, 'message' => '无代理信息')));
                    exit;
                }
                
                // 验证代理是否存在且激活
                $agent = $agentManager->getAgent($agentId);
                if (!$agent['success'] || $agent['data']['status'] !== 'active') {
                    throw new Exception('代理不存在或未激活');
                }
                
                // 使用 CommissionManager 计算佣金
                $result = $commissionManager->calculateOrderCommission($orderId);
                
                if ($result['success']) {
                    echo json_encode(array('success' => true, 'data' => $result));
                } else {
                    echo json_encode(array('success' => false, 'message' => $result['message']));
                }
            }
            break;
            
        case 'get_agent_tree':
            // 获取代理关系树
            if ($method === 'GET') {
                $agentId = isset($_GET['agent_id']) ? intval($_GET['agent_id']) : 0;
                if ($agentId <= 0) {
                    throw new Exception('无效的代理ID');
                }
                
                $result = $agentManager->getAgentTree($agentId);
                echo json_encode(array('success' => true, 'data' => $result));
            }
            break;
            
        case 'get_level_stats':
            // 获取层级统计
            if ($method === 'GET') {
                $agentId = isset($_GET['agent_id']) ? intval($_GET['agent_id']) : 0;
                if ($agentId <= 0) {
                    throw new Exception('无效的代理ID');
                }
                
                $result = $agentManager->getLevelStats($agentId);
                echo json_encode(array('success' => true, 'data' => $result));
            }
            break;
            
        case 'update_agent_hierarchy':
            // 更新代理层级关系
            if ($method === 'POST') {
                $input = json_decode(file_get_contents('php://input'), true);
                
                $agentId = isset($input['agent_id']) ? intval($input['agent_id']) : 0;
                $newParentId = !empty($input['parent_agent_id']) ? intval($input['parent_agent_id']) : null;
                
                if ($agentId <= 0) {
                    throw new Exception('无效的代理ID');
                }
                
                // 检查是否会形成循环代理关系
                if ($newParentId && $agentManager->wouldCreateCircularReference($agentId, $newParentId)) {
                    throw new Exception('不能设置此上级代理，会形成循环代理关系');
                }
                
                // 验证新上级代理
                if ($newParentId) {
                    $newParent = $agentManager->getAgent($newParentId);
                    if (!$newParent['success'] || $newParent['data']['status'] !== 'active') {
                        throw new Exception('上级代理不存在或未激活');
                    }
                }
                
                $result = $agentManager->updateAgentHierarchy($agentId, $newParentId);
                echo json_encode(array('success' => true, 'data' => $result));
            }
            break;
            
        case 'generate_referral_link':
            // 生成推广链接
            if ($method === 'GET') {
                $agentId = isset($_GET['agent_id']) ? intval($_GET['agent_id']) : 0;
                if ($agentId <= 0) {
                    throw new Exception('无效的代理ID');
                }
                
                $agent = $agentManager->getAgent($agentId);
                if (!$agent['success']) {
                    throw new Exception('代理不存在');
                }
                
                $referralLink = $agentManager->generateReferralLink($agentId);
                echo json_encode(array('success' => true, 'data' => array('referral_link' => $referralLink)));
            }
            break;
            
        case 'track_referral':
            // 跟踪推广链接点击
            if ($method === 'POST') {
                $input = json_decode(file_get_contents('php://input'), true);
                
                $referralCode = isset($input['referral_code']) ? $input['referral_code'] : '';
                $ipAddress = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
                $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
                
                if (empty($referralCode)) {
                    throw new Exception('推荐码不能为空');
                }
                
                $result = $agentManager->trackReferralClick($referralCode, $ipAddress, $userAgent);
                echo json_encode(array('success' => true, 'data' => $result));
            }
            break;
            
        case 'get_referral_stats':
            // 获取推广统计
            if ($method === 'GET') {
                $agentId = isset($_GET['agent_id']) ? intval($_GET['agent_id']) : 0;
                $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
                $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
                
                if ($agentId <= 0) {
                    throw new Exception('无效的代理ID');
                }
                
                $result = $agentManager->getReferralStats($agentId, $startDate, $endDate);
                echo json_encode(array('success' => true, 'data' => $result));
            }
            break;
            
        default:
            throw new Exception('无效的操作');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>