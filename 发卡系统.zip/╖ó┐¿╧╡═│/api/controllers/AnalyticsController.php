<?php
/**
 * 分析控制器
 * 提供用户购买行为分析、销售趋势分析、小程序使用情况和性能监控等功能
 */

// 确保PDO扩展已加载
if (!extension_loaded('pdo')) {
    throw new Exception('PDO extension is required for AnalyticsController');
}

// 检查getDB函数是否存在
if (!function_exists('getDB')) {
    /**
     * 备用数据库连接函数
     * @return PDO
     * @throws Exception
     */
    function getDB() {
        try {
            // 使用默认连接参数（实际使用时应该从配置中读取）
            $db = new PDO(
                'mysql:host=localhost;dbname=card_system;charset=utf8mb4',
                'root',
                '',
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
            return $db;
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            throw new Exception('Database connection error');
        }
    }
}

class AnalyticsController {
    /**
     * 接收小程序分析数据
     * @param array $request 请求数据
     * @return array 处理结果
     */
    public function receiveMiniProgramAnalytics($request) {
        try {
            // 确保请求是数组
            if (!is_array($request)) {
                return [
                    'success' => false,
                    'error' => 'Invalid request format',
                    'message' => '请求数据格式无效'
                ];
            }
            
            // 验证必要字段
            if (!isset($request['session_id']) || !isset($request['events'])) {
                return [
                    'success' => false,
                    'error' => 'Missing required fields',
                    'message' => '缺少必要字段: session_id 和 events'
                ];
            }
            
            // 初始化数据库连接
            $db = getDB();
            
            // 获取用户ID（如果有token）
            $userId = null;
            if (isset($request['user_token'])) {
                $userToken = $request['user_token'];
                // 从token中解析用户信息或直接查询
                $userQuery = "SELECT id FROM users WHERE remember_token = ?";
                $userStmt = $db->prepare($userQuery);
                $userStmt->execute([$userToken]);
                $user = $userStmt->fetch(PDO::FETCH_ASSOC);
                if ($user) {
                    $userId = $user['id'];
                }
            }
            
            // 处理接收到的事件
            $events = $request['events'];
            $receivedCount = 0;
            $storedCount = 0;
            
            foreach ($events as $event) {
                if (!is_array($event) || !isset($event['event_name'])) {
                    continue;
                }
                
                $receivedCount++;
                
                try {
                    // 保存事件数据到数据库
                    $eventData = json_encode($event['event_data'] ?? [], JSON_UNESCAPED_UNICODE);
                    $deviceInfo = json_encode($event['device_info'] ?? [], JSON_UNESCAPED_UNICODE);
                    $timestamp = isset($event['timestamp']) ? $event['timestamp'] : time();
                    
                    // 准备SQL语句
                    $sql = "INSERT INTO analytics_events 
                            (session_id, user_id, event_name, event_data, device_info, timestamp, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, NOW())";
                    
                    $stmt = $db->prepare($sql);
                    $stmt->execute([
                        $request['session_id'],
                        $userId,
                        $event['event_name'],
                        $eventData,
                        $deviceInfo,
                        $timestamp
                    ]);
                    
                    $storedCount++;
                    
                    // 对于关键事件，可以进行特殊处理
                    $this->processSpecialEvents($db, $event, $userId, $request['session_id']);
                    
                } catch (Exception $e) {
                    // 记录单个事件处理错误但继续处理其他事件
                    error_log('Error storing analytics event: ' . $e->getMessage());
                }
            }
            
            return [
                'success' => true,
                'message' => '数据接收成功',
                'received_count' => $receivedCount,
                'stored_count' => $storedCount
            ];
            
        } catch (Exception $e) {
            error_log('Analytics processing error: ' . $e->getMessage());
            return [
                'success' => true, // 即使处理失败也返回成功，不影响小程序
                'message' => '数据接收成功',
                'received_count' => 0,
                'stored_count' => 0
            ];
        }
    }
    
    /**
     * 处理特殊事件（如错误、性能等）
     * @param PDO $db 数据库连接
     * @param array $event 事件数据
     * @param int|null $userId 用户ID
     * @param string $sessionId 会话ID
     */
    private function processSpecialEvents($db, $event, $userId, $sessionId) {
        $eventName = $event['event_name'];
        
        // 处理错误事件
        if ($eventName === 'app_error' || $eventName === 'network_request' && isset($event['event_data']['success']) && !$event['event_data']['success']) {
            try {
                $errorData = $event['event_data'] ?? [];
                $errorMessage = $errorData['error'] ?? json_encode($errorData);
                $pagePath = $errorData['page'] ?? 'unknown';
                
                $sql = "INSERT INTO analytics_errors 
                        (session_id, user_id, error_type, error_message, page_path, timestamp, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, NOW())";
                
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    $sessionId,
                    $userId,
                    $eventName,
                    $errorMessage,
                    $pagePath,
                    $event['timestamp'] ?? time()
                ]);
            } catch (Exception $e) {
                error_log('Error storing error event: ' . $e->getMessage());
            }
        }
        
        // 处理性能事件
        if ($eventName === 'page_performance' && isset($event['event_data']['is_slow']) && $event['event_data']['is_slow']) {
            try {
                $perfData = $event['event_data'] ?? [];
                
                $sql = "INSERT INTO analytics_performance 
                        (session_id, user_id, page_path, load_time, timestamp, created_at)
                        VALUES (?, ?, ?, ?, ?, NOW())";
                
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    $sessionId,
                    $userId,
                    $perfData['page_path'] ?? 'unknown',
                    $perfData['load_time'] ?? 0,
                    $event['timestamp'] ?? time()
                ]);
            } catch (Exception $e) {
                error_log('Error storing performance event: ' . $e->getMessage());
            }
        }
    }
    
    /**
     * 获取小程序使用统计报告
     * @param array $request 请求参数
     * @return array 统计报告
     */
    public function getMiniProgramReport($request) {
        try {
            // 确保请求是数组
            if (!is_array($request)) {
                $request = [];
            }
            
            // 初始化数据库连接
            $db = getDB();
            
            // 获取并验证查询参数
            $startDate = $this->validateDateParam($request, 'start_date', date('Y-m-d', strtotime('-7 days')));
            $endDate = $this->validateDateParam($request, 'end_date', date('Y-m-d'));
            
            // 1. 会话统计
            $sessionQuery = "SELECT 
                            COUNT(DISTINCT session_id) as total_sessions,
                            COUNT(DISTINCT user_id) as active_users,
                            AVG(TIMESTAMPDIFF(SECOND, MIN(created_at), MAX(created_at))) as avg_session_duration
                        FROM analytics_events
                        WHERE created_at BETWEEN ? AND ?
                        GROUP BY session_id";
            
            $sessionStmt = $db->prepare($sessionQuery);
            $sessionStmt->execute([$startDate, $endDate]);
            $sessionResults = $sessionStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 计算平均会话时长
            $totalSessions = count($sessionResults);
            $activeUsers = count(array_unique(array_column($sessionResults, 'active_users')));
            $avgSessionDuration = 0;
            if ($totalSessions > 0) {
                $sumDuration = array_sum(array_column($sessionResults, 'avg_session_duration'));
                $avgSessionDuration = $sumDuration / $totalSessions;
            }
            
            // 2. 页面访问统计
            $pageQuery = "SELECT 
                            JSON_UNQUOTE(JSON_EXTRACT(event_data, '$.page_path')) as page_path,
                            COUNT(*) as view_count,
                            COUNT(DISTINCT session_id) as unique_views
                        FROM analytics_events
                        WHERE created_at BETWEEN ? AND ?
                        AND event_name = 'page_view'
                        GROUP BY page_path
                        ORDER BY view_count DESC";
            
            $pageStmt = $db->prepare($pageQuery);
            $pageStmt->execute([$startDate, $endDate]);
            $pageResults = $pageStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 3. 错误统计
            $errorQuery = "SELECT 
                            error_type,
                            COUNT(*) as error_count,
                            COUNT(DISTINCT session_id) as affected_sessions
                        FROM analytics_errors
                        WHERE created_at BETWEEN ? AND ?
                        GROUP BY error_type
                        ORDER BY error_count DESC";
            
            $errorStmt = $db->prepare($errorQuery);
            $errorStmt->execute([$startDate, $endDate]);
            $errorResults = $errorStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 4. 性能统计
            $performanceQuery = "SELECT 
                            page_path,
                            COUNT(*) as record_count,
                            AVG(load_time) as avg_load_time,
                            MAX(load_time) as max_load_time,
                            MIN(load_time) as min_load_time
                        FROM analytics_performance
                        WHERE created_at BETWEEN ? AND ?
                        GROUP BY page_path
                        ORDER BY avg_load_time DESC";
            
            $performanceStmt = $db->prepare($performanceQuery);
            $performanceStmt->execute([$startDate, $endDate]);
            $performanceResults = $performanceStmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'summary' => [
                    'total_sessions' => $totalSessions,
                    'active_users' => $activeUsers,
                    'avg_session_duration' => round($avgSessionDuration, 2),
                    'date_range' => [
                        'start_date' => $startDate,
                        'end_date' => $endDate
                    ]
                ],
                'page_views' => $pageResults,
                'errors' => $errorResults,
                'performance' => $performanceResults
            ];
        } catch (Exception $e) {
            error_log('Mini program report error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Report generation failed',
                'message' => '报表生成失败'
            ];
        }
    }
    
    /**
     * 获取用户购买分析数据
     */
    public function getUserPurchaseAnalytics($request) {
        try {
            // 确保请求是数组
            if (!is_array($request)) {
                $request = [];
            }
            
            // 初始化数据库连接
            $db = getDB();
            
            // 获取并验证查询参数
            $startDate = $this->validateDateParam($request, 'start_date', date('Y-m-d', strtotime('-30 days')));
            $endDate = $this->validateDateParam($request, 'end_date', date('Y-m-d'));
            $page = $this->validateIntParam($request, 'page', 1, 1, 100);
            $limit = $this->validateIntParam($request, 'limit', 20, 1, 100);
            $offset = ($page - 1) * $limit;
            
            // 构建查询
            $query = "SELECT 
                        u.id as user_id,
                        u.username,
                        u.role,
                        COUNT(o.id) as order_count,
                        SUM(o.total_amount) as total_spent,
                        AVG(o.total_amount) as avg_order_value,
                        MIN(o.created_at) as first_purchase,
                        MAX(o.created_at) as last_purchase
                      FROM users u
                      LEFT JOIN orders o ON u.id = o.user_id AND o.created_at BETWEEN ? AND ?
                      GROUP BY u.id, u.username, u.role
                      ORDER BY total_spent DESC
                      LIMIT ? OFFSET ?";
            
            $stmt = $db->prepare($query);
            $stmt->execute([$startDate, $endDate, $limit, $offset]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 获取总数
            $countQuery = "SELECT COUNT(DISTINCT u.id) as count 
                          FROM users u
                          LEFT JOIN orders o ON u.id = o.user_id AND o.created_at BETWEEN ? AND ?";
            $countStmt = $db->prepare($countQuery);
            $countStmt->execute([$startDate, $endDate]);
            $totalCount = $countStmt->fetchColumn();
            
            return [
                'success' => true,
                'data' => $results,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $totalCount,
                    'pages' => ceil($totalCount / $limit)
                ],
                'filters' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => '获取用户购买分析数据失败',
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 获取销售趋势数据
     */
    public function getSalesTrends($request) {
        try {
            // 确保请求是数组
            if (!is_array($request)) {
                $request = [];
            }
            
            $db = getDB();
            
            // 获取并验证查询参数
            $startDate = $this->validateDateParam($request, 'start_date', date('Y-m-d', strtotime('-90 days')));
            $endDate = $this->validateDateParam($request, 'end_date', date('Y-m-d'));
            // 验证间隔类型
            $validIntervals = ['day', 'week', 'month'];
            $interval = isset($request['interval']) && in_array($request['interval'], $validIntervals) 
                ? $request['interval'] : 'day';
            
            // 根据间隔类型设置日期格式
            $dateFormat = 'date';
            $groupByFormat = '%Y-%m-%d';
            
            if ($interval === 'week') {
                $dateFormat = 'WEEK';
                $groupByFormat = '%Y-%u';
            } elseif ($interval === 'month') {
                $dateFormat = 'MONTH';
                $groupByFormat = '%Y-%m';
            }
            
            // 构建查询
            $query = "SELECT 
                        DATE_FORMAT(created_at, ?) as date,
                        COUNT(id) as order_count,
                        SUM(total_amount) as revenue,
                        AVG(total_amount) as avg_order_value
                      FROM orders
                      WHERE created_at BETWEEN ? AND ?
                      GROUP BY date
                      ORDER BY date ASC";
            
            $stmt = $db->prepare($query);
            $stmt->execute([$groupByFormat, $startDate, $endDate]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $results,
                'interval' => $interval,
                'filters' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => '获取销售趋势数据失败',
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 获取热门产品数据
     */
    public function getTopProducts($request) {
        try {
            // 确保请求是数组
            if (!is_array($request)) {
                $request = [];
            }
            
            $db = getDB();
            
            // 获取并验证查询参数
            $startDate = $this->validateDateParam($request, 'start_date', date('Y-m-d', strtotime('-30 days')));
            $endDate = $this->validateDateParam($request, 'end_date', date('Y-m-d'));
            $limit = $this->validateIntParam($request, 'limit', 10, 1, 50);
            
            // 构建查询
            $query = "SELECT 
                        p.id as product_id,
                        p.name as product_name,
                        p.category,
                        COUNT(oi.id) as quantity_sold,
                        SUM(oi.price * oi.quantity) as revenue,
                        AVG(oi.price) as avg_price
                      FROM products p
                      JOIN order_items oi ON p.id = oi.product_id
                      JOIN orders o ON oi.order_id = o.id
                      WHERE o.created_at BETWEEN ? AND ? AND o.status = 'completed'
                      GROUP BY p.id, p.name, p.category
                      ORDER BY quantity_sold DESC
                      LIMIT ?";
            
            $stmt = $db->prepare($query);
            $stmt->execute([$startDate, $endDate, $limit]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $results,
                'filters' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                    'limit' => $limit
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => '获取热门产品数据失败',
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 获取收入统计数据
     */
    public function getRevenueStats($request) {
        try {
            // 确保请求是数组
            if (!is_array($request)) {
                $request = [];
            }
            
            $db = getDB();
            
            // 获取并验证查询参数
            $startDate = $this->validateDateParam($request, 'start_date', date('Y-m-d', strtotime('-30 days')));
            $endDate = $this->validateDateParam($request, 'end_date', date('Y-m-d'));
            
            // 1. 总体收入统计
            $summaryQuery = "SELECT 
                              SUM(total_amount) as total_revenue,
                              COUNT(id) as order_count,
                              AVG(total_amount) as avg_order_value,
                              COUNT(DISTINCT user_id) as unique_customers
                            FROM orders
                            WHERE created_at BETWEEN ? AND ? AND status = 'completed'";
            
            $summaryStmt = $db->prepare($summaryQuery);
            $summaryStmt->execute([$startDate, $endDate]);
            $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);
            
            // 2. 按支付方式统计
            $paymentQuery = "SELECT 
                              payment_method,
                              COUNT(*) as order_count,
                              SUM(total_amount) as revenue,
                              AVG(total_amount) as avg_order_value
                            FROM orders
                            WHERE created_at BETWEEN ? AND ? AND status = 'completed'
                            GROUP BY payment_method
                            ORDER BY revenue DESC";
            
            $paymentStmt = $db->prepare($paymentQuery);
            $paymentStmt->execute([$startDate, $endDate]);
            $paymentStats = $paymentStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 3. 按产品类别统计
            $categoryQuery = "SELECT 
                              p.category,
                              COUNT(oi.id) as item_count,
                              SUM(oi.price * oi.quantity) as revenue,
                              AVG(oi.price) as avg_price
                            FROM products p
                            JOIN order_items oi ON p.id = oi.product_id
                            JOIN orders o ON oi.order_id = o.id
                            WHERE o.created_at BETWEEN ? AND ? AND o.status = 'completed'
                            GROUP BY p.category
                            ORDER BY revenue DESC";
            
            $categoryStmt = $db->prepare($categoryQuery);
            $categoryStmt->execute([$startDate, $endDate]);
            $categoryStats = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'summary' => $summary,
                'by_payment_method' => $paymentStats,
                'by_category' => $categoryStats,
                'filters' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ]
            ];
        } catch (Exception $e) {
            error_log('Revenue stats error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => '获取收入统计数据失败',
                'message' => '服务器内部错误'
            ];
        }
    }
    
    /**
     * 验证日期参数
     */
    private function validateDateParam($request, $paramName, $default) {
        if (!isset($request[$paramName])) {
            return $default;
        }
        
        $date = $request[$paramName];
        // 验证日期格式
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return $default;
        }
        
        // 验证日期有效性
        $dateTime = DateTime::createFromFormat('Y-m-d', $date);
        if (!$dateTime || $dateTime->format('Y-m-d') !== $date) {
            return $default;
        }
        
        return $date;
    }
    
    /**
     * 验证整数参数
     */
    private function validateIntParam($request, $paramName, $default, $min = 1, $max = 100) {
        if (!isset($request[$paramName]) || !is_numeric($request[$paramName])) {
            return $default;
        }
        
        $value = (int)$request[$paramName];
        // 确保在允许的范围内
        return max($min, min($max, $value));
    }
}