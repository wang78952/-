<?php
/**
 * 系统统计API控制器
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

require_once __DIR__ . '/../../includes/AuthManager.php';
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/ComplianceManager.php';
require_once __DIR__ . '/../../includes/SecurityUtils.php';
require_once __DIR__ . '/../router.php';

// 引入异常类
require_once __DIR__ . '/../../includes/exceptions/AuthenticationException.php';
require_once __DIR__ . '/../../includes/exceptions/AuthorizationException.php';
require_once __DIR__ . '/../../includes/exceptions/BusinessLogicException.php';

// 确保ApiRouter和DatabaseOptimizer类可用
if (class_exists('DatabaseOptimizer')) {
    require_once __DIR__ . '/../../includes/DatabaseOptimizer.php';
}

/**
 * 系统统计API控制器
 */
class StatsController {
    private $db;
    private $authManager;
    private $currentUser;
    private $optimizer;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->authManager = new AuthManager();
        // 安全地初始化optimizer
        $this->optimizer = class_exists('DatabaseOptimizer') ? new DatabaseOptimizer() : null;
        $this->currentUser = $this->getCurrentUser();
    }
    
    /**
     * 获取当前用户
     */
    private function getCurrentUser() {
        $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            $token = $matches[1];
            return $this->authManager->getUserByApiToken($token);
        }
        return null;
    }
    
    /**
     * 回退方法：当optimizer不可用时获取卡片统计
     */
    private function getCardStatsFallback() {
        $sql = "SELECT COUNT(*) as total, SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active FROM cards";
        $result = $this->db->query($sql);
        return $result->fetch_assoc() ?? ['total' => 0, 'active' => 0];
    }
    
    /**
     * 回退方法：当optimizer不可用时获取验证统计
     */
    private function getVerificationStatsFallback() {
        $sql = "SELECT COUNT(*) as total, SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) as verified FROM verifications";
        $result = $this->db->query($sql);
        return $result->fetch_assoc() ?? ['total' => 0, 'verified' => 0];
    }
    
    /**
     * 获取仪表板统计信息
     */
    public function getDashboardStats($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_DASHBOARD_VIEW)) {
            ApiRouter::errorResponse('没有查看仪表板权限', 403);
            return;
        }
        
        try {
            // 安全地获取统计信息
            $cardStats = ($this->optimizer && method_exists($this->optimizer, 'getCardStats')) 
                ? $this->optimizer->getCardStats() 
                : $this->getCardStatsFallback();
            
            $verificationStats = ($this->optimizer && method_exists($this->optimizer, 'getVerificationStats')) 
                ? $this->optimizer->getVerificationStats() 
                : $this->getVerificationStatsFallback();
            
            // 获取用户统计（仅管理员）
            $userStats = null;
            if ($this->authManager->hasPermission(AuthManager::PERMISSION_USER_MANAGE)) {
                $userStats = $this->optimizer->getUserStats();
            }
            
            // 获取系统统计（仅管理员）
            $systemStats = null;
            if ($this->authManager->hasPermission(AuthManager::PERMISSION_LOG_VIEW)) {
                $systemStats = $this->optimizer->getComplianceStats();
                $systemStats['total_logs'] = $this->db->queryOne("SELECT COUNT(*) as count FROM user_logs")['count'];
            }
            
            // 获取最近活动
            $recentActivities = $this->getRecentActivities();
            
            // 获取趋势数据
            $trends = $this->getTrends();
            
            return array(
                'card_stats' => $cardStats,
                'verification_stats' => $verificationStats,
                'user_stats' => $userStats,
                'system_stats' => $systemStats,
                'recent_activities' => $recentActivities,
                'trends' => $trends,
                'last_updated' => date('Y-m-d H:i:s')
            );
            
        } catch (Exception $e) {
            ApiRouter::errorResponse('获取统计信息失败：' . $e->getMessage(), 500);
            return;
        }
    }
    
    /**
     * 获取最近活动
     */
    private function getRecentActivities() {
        $activities = array();
        
        // 获取最近添加的卡片
        $recentCards = $this->db->query("
            SELECT id, 'card_added' as type, card_number_hash, bank_name, created_at
            FROM cards 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        
        foreach ($recentCards as $card) {
            $activities[] = array(
                'id' => $card['id'],
                'type' => 'card_added',
                'description' => '添加新卡片',
                'details' => $card['bank_name'] ?: '未知银行',
                'timestamp' => date('Y-m-d H:i:s', strtotime($card['created_at']))
            );
        }
        
        // 获取最近身份核验
        $recentVerifications = $this->db->query("
            SELECT id, 'verification_completed' as type, task_id, status, updated_at
            FROM identity_verifications 
            WHERE updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) 
            AND status IN ('approved', 'rejected')
            ORDER BY updated_at DESC 
            LIMIT 5
        ");
        
        foreach ($recentVerifications as $verification) {
            $activities[] = array(
                'id' => $verification['id'],
                'type' => 'verification_completed',
                'description' => '身份核验' . ($verification['status'] === 'approved' ? '通过' : '拒绝'),
                'details' => $verification['task_id'],
                'timestamp' => date('Y-m-d H:i:s', strtotime($verification['updated_at']))
            );
        }
        
        // 按时间排序
        usort($activities, function($a, $b) {
            return strtotime($b['timestamp']) - strtotime($a['timestamp']);
        });
        
        return array_slice($activities, 0, 10);
    }
    
    /**
     * 获取趋势数据
     */
    private function getTrends() {
        $trends = array();
        
        // 最近7天的卡片创建趋势
        $cardTrend = $this->db->query("
            SELECT DATE(created_at) as date, COUNT(*) as count 
            FROM cards 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
            GROUP BY DATE(created_at) 
            ORDER BY date ASC
        ");
        
        $trends['cards'] = $cardTrend;
        
        // 最近7天的身份核验趋势
        $verificationTrend = $this->db->query("
            SELECT DATE(created_at) as date, COUNT(*) as count 
            FROM identity_verifications 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
            GROUP BY DATE(created_at) 
            ORDER BY date ASC
        ");
        
        $trends['verifications'] = $verificationTrend;
        
        // 最近7天的登录趋势（仅管理员）
        if ($this->authManager->hasPermission(AuthManager::PERMISSION_LOG_VIEW)) {
            $loginTrend = $this->db->query("
                SELECT DATE(created_at) as date, COUNT(*) as count 
                FROM user_logs 
                WHERE action LIKE '%login%' 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
                GROUP BY DATE(created_at) 
                ORDER BY date ASC
            ");
            
            $trends['logins'] = $loginTrend;
        }
        
        return $trends;
    }
    
    /**
     * 获取详细卡片统计
     */
    public function getDetailedCardStats($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_READ)) {
            ApiRouter::errorResponse('没有查看卡片统计权限', 403);
            return;
        }
        
        try {
            // 按卡片类型统计
            $typeStats = $this->db->query("
                SELECT card_type, COUNT(*) as count, 
                       SUM(credit_limit) as total_credit_limit
                FROM cards 
                WHERE status != 'deleted'
                GROUP BY card_type
            ");
            
            // 按银行统计
            $bankStats = $this->db->query("
                SELECT bank_name, COUNT(*) as count,
                       SUM(credit_limit) as total_credit_limit
                FROM cards 
                WHERE bank_name != '' AND status != 'deleted'
                GROUP BY bank_name 
                ORDER BY count DESC 
                LIMIT 20
            ");
            
            // 按状态统计
            $statusStats = $this->db->query("
                SELECT status, COUNT(*) as count,
                       AVG(credit_limit) as avg_credit_limit
                FROM cards 
                GROUP BY status
            ");
            
            // 按月份统计（最近12个月）
            $monthlyStats = $this->db->query("
                SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count
                FROM cards 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month ASC
            ");
            
            // 即将到期的卡片（30天内）
            $expiringSoon = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM cards 
                WHERE expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                AND status = 'active'
            ")['count'];
            
            // 已过期的卡片
            $expired = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM cards 
                WHERE expire_date < CURDATE()
                AND status != 'expired' AND status != 'cancelled'
            ")['count'];
            
            return array(
                'by_type' => $typeStats,
                'by_bank' => $bankStats,
                'by_status' => $statusStats,
                'monthly_trend' => $monthlyStats,
                'expiring_soon' => $expiringSoon,
                'expired_not_updated' => $expired
            );
            
        } catch (Exception $e) {
            ApiRouter::errorResponse('获取卡片统计失败：' . $e->getMessage(), 500);
            return;
        }
    }
    
    /**
     * 获取详细身份核验统计
     */
    public function getDetailedVerificationStats($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_IDENTITY_VERIFY)) {
            ApiRouter::errorResponse('没有查看核验统计权限', 403);
            return;
        }
        
        try {
            // 按核验类型统计
            $typeStats = $this->db->query("
                SELECT verification_type, COUNT(*) as count,
                       SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count,
                       SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
                       SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count
                FROM identity_verifications 
                GROUP BY verification_type
            ");
            
            // 按状态统计
            $statusStats = $this->db->query("
                SELECT status, COUNT(*) as count,
                       AVG(TIMESTAMPDIFF(SECOND, created_at, updated_at)) as avg_processing_time
                FROM identity_verifications 
                GROUP BY status
            ");
            
            // 按月份统计（最近12个月）
            $monthlyStats = $this->db->query("
                SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
                       COUNT(*) as count,
                       SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count
                FROM identity_verifications 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month ASC
            ");
            
            // 平均处理时间
            $avgProcessingTime = $this->db->queryOne("
                SELECT AVG(TIMESTAMPDIFF(SECOND, created_at, updated_at)) as avg_time
                FROM identity_verifications 
                WHERE status IN ('approved', 'rejected')
                AND updated_at IS NOT NULL
            ")['avg_time'];
            
            // 成功率
            $totalCompleted = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM identity_verifications 
                WHERE status IN ('approved', 'rejected')
            ")['count'];
            
            $approvedCount = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM identity_verifications 
                WHERE status = 'approved'
            ")['count'];
            
            $successRate = $totalCompleted > 0 ? round(($approvedCount / $totalCompleted) * 100, 2) : 0;
            
            return array(
                'by_type' => $typeStats,
                'by_status' => $statusStats,
                'monthly_trend' => $monthlyStats,
                'avg_processing_time' => round(isset($avgProcessingTime) ? $avgProcessingTime : 0, 2),
                'success_rate' => $successRate
            );
            
        } catch (Exception $e) {
            ApiRouter::errorResponse('获取核验统计失败：' . $e->getMessage(), 500);
            return;
        }
    }
    
    /**
     * 获取系统健康状态
     */
    public function getSystemHealth($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_LOG_VIEW)) {
            ApiRouter::errorResponse('没有查看系统状态权限', 403);
            return;
        }
        
        try {
            $health = array(
                'database' => $this->checkDatabaseHealth(),
                'security' => $this->checkSecurityHealth(),
                'performance' => $this->checkPerformanceHealth(),
                'compliance' => $this->checkComplianceHealth()
            );
            
            // 计算总体健康分数
            $totalScore = 0;
            $maxScore = 0;
            
            foreach ($health as $component) {
                $totalScore += $component['score'];
                $maxScore += 100;
            }
            
            $health['overall'] = array(
                'score' => round(($totalScore / $maxScore) * 100, 2),
                'status' => $totalScore / $maxScore >= 0.8 ? 'healthy' : 
                           ($totalScore / $maxScore >= 0.6 ? 'warning' : 'critical')
            );
            
            $health['last_check'] = date('Y-m-d H:i:s');
            
            return $health;
            
        } catch (Exception $e) {
            ApiRouter::errorResponse('获取系统健康状态失败：' . $e->getMessage(), 500);
            return;
        }
    }
    
    /**
     * 检查数据库健康状态
     */
    private function checkDatabaseHealth() {
        try {
            // 测试数据库连接
            $this->db->query("SELECT 1");
            
            // 检查表是否存在
            $tables = ['users', 'cards', 'identity_verifications', 'user_logs', 'security_logs'];
            $existingTables = 0;
            
            foreach ($tables as $table) {
                $result = $this->db->queryOne("SHOW TABLES LIKE '{$table}'");
                if ($result) {
                    $existingTables++;
                }
            }
            
            $tableScore = ($existingTables / count($tables)) * 100;
            
            // 检查最近的错误日志
            $recentErrors = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM security_logs 
                WHERE level = 'ERROR' 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            ")['count'];
            
            $errorScore = max(0, 100 - ($recentErrors * 10));
            
            return array(
                'score' => round(($tableScore + $errorScore) / 2, 2),
                'status' => ($tableScore + $errorScore) / 2 >= 80 ? 'healthy' : 
                           (($tableScore + $errorScore) / 2 >= 60 ? 'warning' : 'critical'),
                'details' => array(
                    'tables_exist' => $existingTables . '/' . count($tables),
                    'recent_errors' => $recentErrors,
                    'connection' => 'ok'
                )
            );
            
        } catch (Exception $e) {
            return array(
                'score' => 0,
                'status' => 'critical',
                'details' => array(
                    'error' => $e->getMessage(),
                    'connection' => 'failed'
                )
            );
        }
    }
    
    /**
     * 检查安全健康状态
     */
    private function checkSecurityHealth() {
        try {
            // 检查最近的安全事件
            $recentSecurityEvents = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM security_logs 
                WHERE level IN ('WARNING', 'ERROR', 'CRITICAL')
                AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ")['count'];
            
            $securityScore = max(0, 100 - ($recentSecurityEvents * 5));
            
            // 检查失败的登录尝试
            $failedLogins = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM user_logs 
                WHERE action LIKE '%login%' 
                AND details LIKE '%失败%'
                AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ")['count'];
            
            $loginScore = max(0, 100 - ($failedLogins * 2));
            
            return array(
                'score' => round(($securityScore + $loginScore) / 2, 2),
                'status' => ($securityScore + $loginScore) / 2 >= 80 ? 'healthy' : 
                           (($securityScore + $loginScore) / 2 >= 60 ? 'warning' : 'critical'),
                'details' => array(
                    'security_events_24h' => $recentSecurityEvents,
                    'failed_logins_24h' => $failedLogins
                )
            );
            
        } catch (Exception $e) {
            return array(
                'score' => 0,
                'status' => 'critical',
                'details' => array(
                    'error' => $e->getMessage()
                )
            );
        }
    }
    
    /**
     * 检查性能健康状态
     */
    private function checkPerformanceHealth() {
        try {
            // 检查数据库查询性能（简单测试）
            $startTime = microtime(true);
            $this->db->query("SELECT COUNT(*) as count FROM cards");
            $queryTime = (microtime(true) - $startTime) * 1000; // 转换为毫秒
            
            $performanceScore = max(0, 100 - ($queryTime / 10)); // 超过1秒开始扣分
            
            return array(
                'score' => round($performanceScore, 2),
                'status' => $performanceScore >= 80 ? 'healthy' : 
                           ($performanceScore >= 60 ? 'warning' : 'critical'),
                'details' => array(
                    'query_time_ms' => round($queryTime, 2),
                    'response_time' => $queryTime < 100 ? 'good' : ($queryTime < 500 ? 'acceptable' : 'slow')
                )
            );
            
        } catch (Exception $e) {
            return array(
                'score' => 0,
                'status' => 'critical',
                'details' => array(
                    'error' => $e->getMessage()
                )
            );
        }
    }
    
    /**
     * 检查合规健康状态
     */
    private function checkComplianceHealth() {
        try {
            // 检查活跃的合规告警
            $activeAlerts = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM compliance_alerts 
                WHERE status = 'active'
            ")['count'];
            
            $alertScore = max(0, 100 - ($activeAlerts * 10));
            
            // 检查数据访问授权
            $pendingAuthorizations = $this->db->queryOne("
                SELECT COUNT(*) as count 
                FROM data_access_authorizations 
                WHERE status = 'pending'
            ")['count'];
            
            $authScore = max(0, 100 - ($pendingAuthorizations * 5));
            
            return array(
                'score' => round(($alertScore + $authScore) / 2, 2),
                'status' => ($alertScore + $authScore) / 2 >= 80 ? 'healthy' : 
                           (($alertScore + $authScore) / 2 >= 60 ? 'warning' : 'critical'),
                'details' => array(
                    'active_alerts' => $activeAlerts,
                    'pending_authorizations' => $pendingAuthorizations
                )
            );
            
        } catch (Exception $e) {
            return array(
                'score' => 0,
                'status' => 'critical',
                'details' => array(
                    'error' => $e->getMessage()
                )
            );
        }
    }
}