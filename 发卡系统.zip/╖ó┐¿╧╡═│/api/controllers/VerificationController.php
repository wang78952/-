<?php
/**
 * 身份核验API控制器
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

require_once __DIR__ . '/../../includes/AuthManager.php';
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/ComplianceManager.php';
require_once __DIR__ . '/../../includes/SecurityUtils.php';
require_once __DIR__ . '/../../includes/VerificationService.php';
require_once __DIR__ . '/../router.php';

// 引入异常类
require_once __DIR__ . '/../../includes/exceptions/AuthenticationException.php';
require_once __DIR__ . '/../../includes/exceptions/AuthorizationException.php';
require_once __DIR__ . '/../../includes/exceptions/BusinessLogicException.php';
require_once __DIR__ . '/../../includes/exceptions/RequestValidationException.php';

/**
 * 身份核验API控制器
 */
class VerificationController {
    private $db;
    private $authManager;
    private $currentUser;
    private $optimizer;
    private $verificationService;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->authManager = new AuthManager();
        $this->currentUser = $this->getCurrentUser();
        // 安全地初始化optimizer
        $this->optimizer = class_exists('DatabaseOptimizer') ? new DatabaseOptimizer() : null;
        $this->verificationService = class_exists('VerificationService') ? new VerificationService() : null;
    }
    
    /**
     * 获取当前用户
     */
    private function getCurrentUser() {
        $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            $token = $matches[1];
            return $this->authManager->getUserByApiToken($token);
        }
        return null;
    }
    
    /**
     * 创建身份核验任务
     */
    public function createVerification($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_IDENTITY_VERIFY)) {
            ApiRouter::errorResponse('没有身份核验权限', 403);
            return;
        }
        
        // 验证必填字段
        $requiredFields = ['id_card', 'name', 'phone'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                ApiRouter::errorResponse("字段 {$field} 是必填的", 400);
                return;
            }
        }
        
        // 验证身份证号格式
        if (!preg_match('/^\d{17}[\dXx]$/', $data['id_card'])) {
            ApiRouter::errorResponse('身份证号格式不正确', 400);
            return;
        }
        
        // 验证手机号格式
        if (!preg_match('/^1[3-9]\d{9}$/', $data['phone'])) {
            ApiRouter::errorResponse('手机号格式不正确', 400);
            return;
        }
        
        try {
            // 检查verificationService是否可用
            if (!$this->verificationService) {
                ApiRouter::errorResponse('验证服务暂不可用', 503);
                return;
            }
            
            // 开始事务
            $this->db->beginTransaction();
            
            // 检查数据访问权限
            if (!ComplianceManager::checkDataAccessPermission($this->currentUser['id'], 'create', 'identity_data')) {
                throw new Exception('没有权限创建身份核验任务');
            }
            
            // 加密敏感数据
            $encryptedIdCard = SecurityUtils::encrypt($data['id_card']);
            $encryptedName = SecurityUtils::encrypt($data['name']);
            $encryptedPhone = SecurityUtils::encrypt($data['phone']);
            
            // 生成任务ID
            $taskId = 'VER_' . date('YmdHis') . '_' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            
            // 插入核验任务
            $verificationData = array(
                'task_id' => $taskId,
                'id_card' => $encryptedIdCard,
                'name' => $encryptedName,
                'phone' => $encryptedPhone,
                'verification_type' => isset($data['verification_type']) ? $data['verification_type'] : 'basic',
                'status' => 'pending',
                'created_by' => $this->currentUser['id'],
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            );
            
            $verificationId = $this->db->insert('identity_verifications', $verificationData);
            
            // 记录数据访问授权
            ComplianceManager::recordDataAccessAuthorization(
                $this->currentUser['id'], 
                'identity_data', 
                'create', 
                'API创建身份核验任务', 
                array('task_id' => $taskId, 'verification_type' => $verificationData['verification_type'])
            );
            
            // 记录操作日志
            $this->authManager->recordUserLog(
                $this->currentUser['id'],
                'identity_verification_create_api',
                "API创建身份核验任务，任务ID：{$taskId}",
                SecurityUtils::getClientIP(),
                array('task_id' => $taskId, 'verification_type' => $verificationData['verification_type'])
            );
            
            // 记录安全日志
            SecurityUtils::logSecurity('INFO', 'API身份核验任务创建', array(
                'user_id' => $this->currentUser['id'],
                'username' => $this->currentUser['username'],
                'task_id' => $taskId,
                'verification_type' => $verificationData['verification_type']
            ));
            
            // 提交事务
            $this->db->commit();
            
            return array(
                'verification_id' => $verificationId,
                'task_id' => $taskId,
                'message' => '身份核验任务创建成功'
            );
            
        } catch (Exception $e) {
            $this->db->rollback();
            ApiRouter::errorResponse($e->getMessage(), 400);
            return;
        }
    }
    
    /**
     * 获取身份核验列表
     */
    public function getVerifications($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_IDENTITY_VERIFY)) {
            ApiRouter::errorResponse('没有查看身份核验权限', 403);
            return;
        }
        
        // 解析查询参数
        $page = max(1, intval(isset($data['page']) ? $data['page'] : 1));
        $limit = min(100, max(1, intval(isset($data['limit']) ? $data['limit'] : 20)));
        $offset = ($page - 1) * $limit;
        
        $status = isset($data['status']) ? $data['status'] : '';
        $verificationType = isset($data['verification_type']) ? $data['verification_type'] : '';
        $search = isset($data['search']) ? $data['search'] : '';
        
        // 构建查询条件
        $whereConditions = array();
        $queryParams = array();
        
        if (!empty($status)) {
            $whereConditions[] = "v.status = ?";
            $queryParams[] = $status;
        }
        
        if (!empty($verificationType)) {
            $whereConditions[] = "v.verification_type = ?";
            $queryParams[] = $verificationType;
        }
        
        if (!empty($search)) {
            $whereConditions[] = "v.task_id LIKE ?";
            $searchPattern = "%{$search}%";
            $queryParams[] = $searchPattern;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        // 获取总数
        $countQuery = "SELECT COUNT(*) as total FROM identity_verifications v {$whereClause}";
        $totalResult = $this->db->queryOne($countQuery, $queryParams);
        $total = $totalResult['total'];
        
        // 获取核验列表
        $verificationsQuery = "SELECT v.id, v.task_id, v.verification_type, v.status, 
                                      v.result_data, v.error_message, v.created_at, v.updated_at,
                                      u.username as created_by_name
                               FROM identity_verifications v
                               LEFT JOIN users u ON v.created_by = u.id
                               {$whereClause}
                               ORDER BY v.created_at DESC
                               LIMIT ? OFFSET ?";
        
        $listParams = array_merge($queryParams, array($limit, $offset));
        $verifications = $this->db->query($verificationsQuery, $listParams);
        
        // 处理核验数据
        foreach ($verifications as &$verification) {
            // 脱敏处理
            $verification['id_card'] = ComplianceManager::maskIdCard(
                SecurityUtils::decrypt($verification['id_card']), 
                $this->currentUser['role']
            );
            $verification['name'] = ComplianceManager::maskName(
                SecurityUtils::decrypt($verification['name']), 
                $this->currentUser['role']
            );
            $verification['phone'] = ComplianceManager::maskPhone(
                SecurityUtils::decrypt($verification['phone']), 
                $this->currentUser['role']
            );
            
            // 解析结果数据
            if (!empty($verification['result_data'])) {
                $verification['result_data'] = json_decode($verification['result_data'], true);
            }
            
            // 格式化日期
            $verification['created_at'] = date('Y-m-d H:i:s', strtotime($verification['created_at']));
            $verification['updated_at'] = date('Y-m-d H:i:s', strtotime($verification['updated_at']));
        }
        
        return array(
            'verifications' => $verifications,
            'pagination' => array(
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => ceil($total / $limit)
            )
        );
    }
    
    /**
     * 获取单个身份核验详情
     */
    public function getVerification($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_IDENTITY_VERIFY)) {
            ApiRouter::errorResponse('没有查看身份核验权限', 403);
            return;
        }
        
        $verificationId = isset($params['id']) ? $params['id'] : 0;
        if (!$verificationId) {
            ApiRouter::errorResponse('缺少核验ID', 400);
            return;
        }
        
        // 获取核验信息
        $query = "SELECT v.*, u.username as created_by_name
                 FROM identity_verifications v
                 LEFT JOIN users u ON v.created_by = u.id
                 WHERE v.id = ?";
        
        $verification = $this->db->queryOne($query, [$verificationId]);
        
        if (!$verification) {
            ApiRouter::errorResponse('核验记录不存在', 404);
            return;
        }
        
        // 检查数据访问权限
        if (!ComplianceManager::checkDataAccessPermission($this->currentUser['id'], 'read', 'identity_data')) {
            ApiRouter::errorResponse('没有权限访问该核验数据', 403);
            return;
        }
        
        // 解密和脱敏处理
        $verification['id_card'] = ComplianceManager::maskIdCard(
            SecurityUtils::decrypt($verification['id_card']), 
            $this->currentUser['role']
        );
        $verification['name'] = ComplianceManager::maskName(
            SecurityUtils::decrypt($verification['name']), 
            $this->currentUser['role']
        );
        $verification['phone'] = ComplianceManager::maskPhone(
            SecurityUtils::decrypt($verification['phone']), 
            $this->currentUser['role']
        );
        
        // 解析结果数据
        if (!empty($verification['result_data'])) {
            $verification['result_data'] = json_decode($verification['result_data'], true);
        }
        
        // 格式化日期
        $verification['created_at'] = date('Y-m-d H:i:s', strtotime($verification['created_at']));
        $verification['updated_at'] = date('Y-m-d H:i:s', strtotime($verification['updated_at']));
        
        // 记录访问日志
        ComplianceManager::recordDataAccessAuthorization(
            $this->currentUser['id'],
            'identity_data',
            'read',
            "API访问身份核验详情，ID: {$verificationId}",
            ['verification_id' => $verificationId]
        );
        
        return $verification;
    }
    
    /**
     * 执行身份核验
     */
    public function executeVerification($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_IDENTITY_VERIFY)) {
            ApiRouter::errorResponse('没有执行身份核验权限', 403);
            return;
        }
        
        $verificationId = isset($params['id']) ? $params['id'] : 0;
        if (!$verificationId) {
            ApiRouter::errorResponse('缺少核验ID', 400);
            return;
        }
        
        // 检查核验记录是否存在
        $verification = $this->db->queryOne(
            "SELECT * FROM identity_verifications WHERE id = ?",
            [$verificationId]
        );
        
        if (!$verification) {
            ApiRouter::errorResponse('核验记录不存在', 404);
            return;
        }
        
        // 检查状态
        if ($verification['status'] !== 'pending') {
            ApiRouter::errorResponse('只能执行待处理状态的核验', 400);
            return;
        }
        
        try {
            // 开始事务
            $this->db->beginTransaction();
            
            // 检查数据访问权限
            if (!ComplianceManager::checkDataAccessPermission($this->currentUser['id'], 'update', 'identity_data')) {
                throw new Exception('没有权限执行身份核验');
            }
            
            // 调用真实的身份核验服务
            $verificationData = [
                'id_number' => SecurityUtils::decrypt($verification['id_card']),
                'name' => SecurityUtils::decrypt($verification['name']),
                'phone_number' => SecurityUtils::decrypt($verification['phone']),
                'verification_type' => $verification['verification_type']
            ];
            
            $result = $this->verificationService->verifyIdentity($verificationData);
            
            // 更新核验状态
            $updateData = array(
                'status' => $result['status'],
                'result_data' => json_encode($result['data']),
                'error_message' => isset($result['error']) ? $result['error'] : null,
                'updated_at' => date('Y-m-d H:i:s')
            );
            
            $this->db->update('identity_verifications', $updateData, 'id = ?', [$verificationId]);
            
            // 记录数据访问授权
            ComplianceManager::recordDataAccessAuthorization(
                $this->currentUser['id'], 
                'identity_data', 
                'update', 
                "API执行身份核验，ID: {$verificationId}", 
                ['verification_id' => $verificationId, 'status' => $result['status']]
            );
            
            // 记录操作日志
            $this->authManager->recordUserLog(
                $this->currentUser['id'],
                'identity_verification_execute_api',
                "API执行身份核验，任务ID：{$verification['task_id']}，结果：{$result['status']}",
                SecurityUtils::getClientIP(),
                ['verification_id' => $verificationId, 'status' => $result['status']]
            );
            
            // 提交事务
            $this->db->commit();
            
            return array(
                'verification_id' => $verificationId,
                'task_id' => $verification['task_id'],
                'status' => $result['status'],
                'message' => '身份核验执行完成'
            );
            
        } catch (Exception $e) {
            $this->db->rollback();
            ApiRouter::errorResponse($e->getMessage(), 400);
            return;
        }
    }
    
    // 模拟核验方法已替换为真实的VerificationService调用
    
    /**
     * 获取身份核验统计信息
     */
    public function getVerificationStats($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_IDENTITY_VERIFY)) {
            ApiRouter::errorResponse('没有查看核验统计权限', 403);
            return;
        }
        
        try {
            // 使用优化器获取统计信息
            if (!$this->optimizer || !method_exists($this->optimizer, 'getVerificationStats')) {
                // 如果优化器不可用，使用默认查询获取基本统计信息
                $stats = $this->db->queryOne("SELECT 
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_verifications,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_verifications,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_verifications,
                    COUNT(*) as total_verifications
                    FROM identity_verifications");
                $stats['approved_verifications'] = intval($stats['approved_verifications']);
                $stats['rejected_verifications'] = intval($stats['rejected_verifications']);
                $stats['failed_verifications'] = intval($stats['failed_verifications']);
                $stats['total_verifications'] = intval($stats['total_verifications']);
            } else {
                $stats = $this->optimizer->getVerificationStats();
            }
            
            // 获取最近7天的核验趋势
            $trendStats = $this->db->query("
                SELECT DATE(created_at) as date, COUNT(*) as count 
                FROM identity_verifications 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
                GROUP BY DATE(created_at) 
                ORDER BY date ASC
            ");
            $stats['verification_trend'] = $trendStats;
            
            // 核验成功率
            $totalCompleted = $stats['approved_verifications'] + $stats['rejected_verifications'] + $stats['failed_verifications'];
            if ($totalCompleted > 0) {
                $stats['success_rate'] = round(($stats['approved_verifications'] / $totalCompleted) * 100, 2);
            } else {
                $stats['success_rate'] = 0;
            }
            
            return $stats;
            
        } catch (Exception $e) {
            ApiRouter::errorResponse('获取统计信息失败', 500);
            return;
        }
    }
}