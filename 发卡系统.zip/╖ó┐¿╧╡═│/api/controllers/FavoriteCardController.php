<?php
/**
 * 卡密收藏夹控制器
 * 处理用户卡密收藏的增删改查操作
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Logger.php';
require_once __DIR__ . '/../../includes/Response.php';
require_once __DIR__ . '/../../includes/exceptions/ResourceNotFoundException.php';
require_once __DIR__ . '/../../includes/exceptions/UnauthorizedException.php';
require_once __DIR__ . '/../../includes/exceptions/BadRequestException.php';

class FavoriteCardController {
    private $db;
    private $logger;
    private $response;
    
    public function __construct() {
        // 确保正确实例化数据库类
        $this->db = new Database();
        $this->logger = new Logger('favorite_card');
        // 确保 Response 类存在且可用
        $this->response = new Response();
    }
    
    /**
     * 添加卡密到收藏夹
     */
    public function addFavorite($user_id, $data) {
        try {
            // 验证请求数据
            if (!isset($data['card_id'], $data['card_code'], $data['product_id'], $data['product_name'])) {
                throw new BadRequestException('缺少必要的卡密信息');
            }
            
            // 检查是否已收藏
            $check_query = "SELECT id FROM card_favorites WHERE user_id = ? AND card_id = ? AND card_code = ?";
            // 安全调用数据库查询方法
            $check_result = $this->db->query($check_query, [
                $user_id,
                $data['card_id'],
                $data['card_code']
            ]);
            
            if ($check_result && $check_result->num_rows > 0) {
                // 使用正确的响应方法
                return $this->response->json([
                    'status' => 'success',
                    'message' => '卡密已在收藏夹中',
                    'data' => ['already_favorited' => true]
                ]);
            }
            
            // 添加到收藏夹
            $insert_query = "INSERT INTO card_favorites 
                            (user_id, card_id, card_code, product_id, product_name) 
                            VALUES (?, ?, ?, ?, ?)";
            
            $this->db->query($insert_query, [
                $user_id,
                $data['card_id'],
                $data['card_code'],
                $data['product_id'],
                $data['product_name']
            ]);
            
            // 安全记录日志
            if ($this->logger && method_exists($this->logger, 'info')) {
                $this->logger->info("用户 {$user_id} 添加卡密 {$data['card_code']} 到收藏夹");
            }
            
            // 获取插入ID
            $insert_id = property_exists($this->db, 'insert_id') ? $this->db->insert_id : null;
            
            return $this->response->json([
                'status' => 'success',
                'message' => '添加到收藏夹成功',
                'data' => ['favorite_id' => $insert_id]
            ]);
            
        } catch (BadRequestException $e) {
            return $this->response->json(['status' => 'error', 'message' => $e->getMessage()], 400);
        } catch (Exception $e) {
            // 安全记录错误日志
            if ($this->logger && method_exists($this->logger, 'error')) {
                $this->logger->error("添加收藏失败: " . $e->getMessage());
            }
            return $this->response->json(['status' => 'error', 'message' => '服务器内部错误'], 500);
        }
    }
    
    /**
     * 获取用户的收藏夹列表
     */
    public function getFavorites($user_id, $params = []) {
        try {
            $page = isset($params['page']) ? (int)$params['page'] : 1;
            $limit = isset($params['limit']) ? (int)$params['limit'] : 20;
            $offset = ($page - 1) * $limit;
            
            // 获取收藏列表
            $query = "SELECT * FROM card_favorites 
                    WHERE user_id = ? 
                    ORDER BY added_at DESC 
                    LIMIT ? OFFSET ?";
            
            $result = $this->db->query($query, [$user_id, $limit, $offset]);
            $favorites = [];
            
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $favorites[] = $row;
                }
            }
            
            // 获取总数
            $count_query = "SELECT COUNT(*) as total FROM card_favorites WHERE user_id = ?";
            $count_result = $this->db->query($count_query, [$user_id]);
            $total = 0;
            if ($count_result && $row = $count_result->fetch_assoc()) {
                $total = $row['total'] ?? 0;
            }
            
            return $this->response->json([
                'status' => 'success',
                'data' => [
                    'favorites' => $favorites,
                    'pagination' => [
                        'total' => $total,
                        'page' => $page,
                        'limit' => $limit,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
            
        } catch (Exception $e) {
            if ($this->logger && method_exists($this->logger, 'error')) {
                $this->logger->error("获取收藏列表失败: " . $e->getMessage());
            }
            return $this->response->json(['status' => 'error', 'message' => '服务器内部错误'], 500);
        }
    }
    
    /**
     * 从收藏夹移除卡密
     */
    public function removeFavorite($user_id, $favorite_id) {
        try {
            $query = "DELETE FROM card_favorites WHERE id = ? AND user_id = ?";
            $result = $this->db->query($query, [$favorite_id, $user_id]);
            
            // 安全检查影响的行数
            $affected_rows = property_exists($this->db, 'affected_rows') ? $this->db->affected_rows : 0;
            if ($affected_rows === 0) {
                throw new ResourceNotFoundException('收藏记录不存在');
            }
            
            if ($this->logger && method_exists($this->logger, 'info')) {
                $this->logger->info("用户 {$user_id} 移除收藏 ID: {$favorite_id}");
            }
            
            return $this->response->json([
                'status' => 'success',
                'message' => '从收藏夹移除成功'
            ]);
            
        } catch (ResourceNotFoundException $e) {
            return $this->response->json(['status' => 'error', 'message' => $e->getMessage()], 404);
        } catch (Exception $e) {
            if ($this->logger && method_exists($this->logger, 'error')) {
                $this->logger->error("移除收藏失败: " . $e->getMessage());
            }
            return $this->response->json(['status' => 'error', 'message' => '服务器内部错误'], 500);
        }
    }
    
    /**
     * 检查卡密是否已收藏
     */
    public function checkFavorite($user_id, $card_id, $card_code) {
        try {
            $query = "SELECT id FROM card_favorites WHERE user_id = ? AND card_id = ? AND card_code = ?";
            $result = $this->db->query($query, [$user_id, $card_id, $card_code]);
            
            $is_favorited = false;
            $favorite_id = null;
            
            if ($result && $result->num_rows > 0) {
                $is_favorited = true;
                $row = $result->fetch_assoc();
                $favorite_id = $row['id'] ?? null;
            }
            
            return $this->response->json([
                'status' => 'success',
                'data' => [
                    'is_favorited' => $is_favorited,
                    'favorite_id' => $favorite_id
                ]
            ]);
            
        } catch (Exception $e) {
            if ($this->logger && method_exists($this->logger, 'error')) {
                $this->logger->error("检查收藏状态失败: " . $e->getMessage());
            }
            return $this->response->json(['status' => 'error', 'message' => '服务器内部错误'], 500);
        }
    }
}