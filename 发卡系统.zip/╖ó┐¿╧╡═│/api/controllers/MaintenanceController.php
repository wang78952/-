<?php
/**
 * 维护模式控制器
 * 提供维护模式的启用、禁用和状态查询功能
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

// 引入必要的类
require_once __DIR__ . '/../../includes/AuthManager.php';
require_once __DIR__ . '/../../includes/ConfigManager.php';
require_once __DIR__ . '/../../includes/Logger.php';
require_once __DIR__ . '/../../includes/SecurityUtils.php';
require_once __DIR__ . '/../router.php';

// 引入异常类
require_once __DIR__ . '/../../includes/exceptions/AuthenticationException.php';
require_once __DIR__ . '/../../includes/exceptions/AuthorizationException.php';
require_once __DIR__ . '/../../includes/exceptions/BusinessLogicException.php';

class MaintenanceController {
    /**
     * @var ConfigManager 配置管理器
     */
    private $configManager;
    
    /**
     * @var Logger 日志记录器
     */
    private $logger;
    
    /**
     * @var SecurityUtils 安全工具
     */
    private $securityUtils;
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 获取依赖实例
        global $configManager, $logger, $securityUtils;
        
        $this->configManager = $configManager ?? new ConfigManager();
        $this->logger = $logger ?? new Logger();
        $this->securityUtils = $securityUtils ?? new SecurityUtils();
    }
    
    /**
     * 获取维护模式状态
     * 
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 响应数据
     */
    public function getStatus($data, $params = []) {
        try {
            // 获取维护模式配置
            $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
            
            // 记录访问日志
            $this->logger->info('获取维护模式状态', [
                'user_id' => $_SESSION['user_id'] ?? 'unknown',
                'ip' => $this->securityUtils->getRealIpAddress()
            ]);
            
            // 返回状态信息（不包含敏感信息如密钥）
            $response = [
                'enabled' => $maintenanceConfig['enabled'] ?? false,
                'message' => $maintenanceConfig['message'] ?? '',
                'scheduled_maintenance' => $maintenanceConfig['scheduled_maintenance'] ?? [],
                'allowed_ips_count' => count($maintenanceConfig['allowed_ips'] ?? []),
                'admin_notification' => $maintenanceConfig['admin_notification'] ?? false
            ];
            
            return [
                'success' => true,
                'data' => $response
            ];
        } catch (Exception $e) {
            $this->logger->error('获取维护模式状态失败', [
                'error' => $e->getMessage(),
                'user_id' => $_SESSION['user_id'] ?? 'unknown'
            ]);
            
            return [
                'success' => false,
                'error' => 'INTERNAL_ERROR',
                'message' => '获取维护模式状态失败: ' . $e->getMessage(),
                'code' => 500
            ];
        }
    }
    
    /**
     * 启用维护模式
     * 
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 响应数据
     */
    public function enableMaintenance($data, $params = []) {
        try {
            // 验证参数
            if (empty($data['message'])) {
                return [
                    'success' => false,
                    'error' => 'MISSING_PARAMETERS',
                    'message' => '缺少必需的维护信息参数',
                    'code' => 400
                ];
            }
            
            // 获取现有配置
            $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
            
            // 更新配置
            $maintenanceConfig['enabled'] = true;
            $maintenanceConfig['message'] = $data['message'];
            $maintenanceConfig['api_message'] = $data['api_message'] ?? $data['message'];
            $maintenanceConfig['started_at'] = date('Y-m-d H:i:s');
            
            // 更新可选参数
            if (!empty($data['allowed_ips'])) {
                $maintenanceConfig['allowed_ips'] = $data['allowed_ips'];
            }
            
            if (isset($data['admin_notification'])) {
                $maintenanceConfig['admin_notification'] = $data['admin_notification'] === true;
            }
            
            if (!empty($data['scheduled_end_time'])) {
                $maintenanceConfig['scheduled_end_time'] = $data['scheduled_end_time'];
            }
            
            // 保存配置
            $this->configManager->set('app.maintenance_mode', $maintenanceConfig);
            
            // 记录启用事件
            $this->logger->warning('维护模式已启用', [
                'user_id' => $_SESSION['user_id'] ?? 'unknown',
                'ip' => $this->securityUtils->getRealIpAddress(),
                'message' => $data['message']
            ]);
            
            // 发送管理员通知（如果配置了）
            if ($maintenanceConfig['admin_notification'] ?? false) {
                $this->sendAdminNotification('维护模式已启用', $data['message']);
            }
            
            return [
                'success' => true,
                'message' => '维护模式已成功启用',
                'data' => [
                    'enabled' => true,
                    'message' => $data['message'],
                    'started_at' => $maintenanceConfig['started_at']
                ]
            ];
        } catch (Exception $e) {
            $this->logger->error('启用维护模式失败', [
                'error' => $e->getMessage(),
                'user_id' => $_SESSION['user_id'] ?? 'unknown'
            ]);
            
            return [
                'success' => false,
                'error' => 'INTERNAL_ERROR',
                'message' => '启用维护模式失败: ' . $e->getMessage(),
                'code' => 500
            ];
        }
    }
    
    /**
     * 禁用维护模式
     * 
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 响应数据
     */
    public function disableMaintenance($data, $params = []) {
        try {
            // 获取现有配置
            $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
            
            // 检查是否需要验证
            if (!empty($maintenanceConfig['emergency_override']['require_verification']) && 
                $maintenanceConfig['emergency_override']['require_verification'] === true) {
                
                // 验证管理员身份
                if (empty($data['verification_code'])) {
                    return [
                        'success' => false,
                        'error' => 'VERIFICATION_REQUIRED',
                        'message' => '需要验证管理员身份',
                        'code' => 403
                    ];
                }
                
                // 这里可以添加更复杂的验证逻辑，如短信验证、邮件验证等
                // 目前简单验证
                if ($data['verification_code'] !== '123456') { // 实际应用中应该使用更安全的验证方式
                    return [
                        'success' => false,
                        'error' => 'INVALID_VERIFICATION',
                        'message' => '验证失败，请输入正确的验证码',
                        'code' => 403
                    ];
                }
            }
            
            // 禁用维护模式
            $maintenanceConfig['enabled'] = false;
            $maintenanceConfig['ended_at'] = date('Y-m-d H:i:s');
            
            // 保存配置
            $this->configManager->set('app.maintenance_mode', $maintenanceConfig);
            
            // 记录禁用事件
            $this->logger->info('维护模式已禁用', [
                'user_id' => $_SESSION['user_id'] ?? 'unknown',
                'ip' => $this->securityUtils->getRealIpAddress()
            ]);
            
            // 发送管理员通知
            $this->sendAdminNotification('维护模式已禁用', '系统维护已完成，服务恢复正常');
            
            return [
                'success' => true,
                'message' => '维护模式已成功禁用',
                'data' => [
                    'enabled' => false,
                    'ended_at' => $maintenanceConfig['ended_at']
                ]
            ];
        } catch (Exception $e) {
            $this->logger->error('禁用维护模式失败', [
                'error' => $e->getMessage(),
                'user_id' => $_SESSION['user_id'] ?? 'unknown'
            ]);
            
            return [
                'success' => false,
                'error' => 'INTERNAL_ERROR',
                'message' => '禁用维护模式失败: ' . $e->getMessage(),
                'code' => 500
            ];
        }
    }
    
    /**
     * 更新维护模式配置
     * 
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 响应数据
     */
    public function updateMaintenanceConfig($data, $params = []) {
        try {
            // 获取现有配置
            $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
            
            // 更新配置项
            if (isset($data['allowed_ips'])) {
                $maintenanceConfig['allowed_ips'] = $data['allowed_ips'];
            }
            
            if (isset($data['admin_notification'])) {
                $maintenanceConfig['admin_notification'] = $data['admin_notification'] === true;
            }
            
            if (!empty($data['notification_email'])) {
                $maintenanceConfig['notification_email'] = $data['notification_email'];
            }
            
            if (isset($data['emergency_override'])) {
                $maintenanceConfig['emergency_override'] = array_merge(
                    $maintenanceConfig['emergency_override'] ?? [],
                    $data['emergency_override']
                );
            }
            
            // 保存配置
            $this->configManager->set('app.maintenance_mode', $maintenanceConfig);
            
            // 记录更新事件
            $this->logger->info('维护模式配置已更新', [
                'user_id' => $_SESSION['user_id'] ?? 'unknown',
                'ip' => $this->securityUtils->getRealIpAddress()
            ]);
            
            return [
                'success' => true,
                'message' => '维护模式配置已成功更新',
                'data' => [
                    'allowed_ips_count' => count($maintenanceConfig['allowed_ips'] ?? []),
                    'admin_notification' => $maintenanceConfig['admin_notification'] ?? false
                ]
            ];
        } catch (Exception $e) {
            $this->logger->error('更新维护模式配置失败', [
                'error' => $e->getMessage(),
                'user_id' => $_SESSION['user_id'] ?? 'unknown'
            ]);
            
            return [
                'success' => false,
                'error' => 'INTERNAL_ERROR',
                'message' => '更新维护模式配置失败: ' . $e->getMessage(),
                'code' => 500
            ];
        }
    }
    
    /**
     * 紧急禁用维护模式（不需要认证，通过密钥验证）
     * 
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 响应数据
     */
    public function emergencyDisable($data, $params = []) {
        try {
            // 获取紧急密钥
            $emergencyKey = $data['emergency_key'] ?? '';
            
            if (empty($emergencyKey)) {
                return [
                    'success' => false,
                    'error' => 'MISSING_KEY',
                    'message' => '缺少紧急关闭密钥',
                    'code' => 400
                ];
            }
            
            // 获取维护模式配置
            $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
            
            // 验证密钥
            if (empty($maintenanceConfig['emergency_override']['key']) || 
                $emergencyKey !== $maintenanceConfig['emergency_override']['key']) {
                
                // 记录失败尝试
                $this->logger->warning('维护模式紧急关闭尝试失败 - 密钥错误', [
                    'ip' => $this->securityUtils->getRealIpAddress()
                ]);
                
                return [
                    'success' => false,
                    'error' => 'INVALID_KEY',
                    'message' => '无效的紧急关闭密钥',
                    'code' => 403
                ];
            }
            
            // 禁用维护模式
            $maintenanceConfig['enabled'] = false;
            $maintenanceConfig['ended_at'] = date('Y-m-d H:i:s');
            $maintenanceConfig['emergency_disabled'] = true;
            
            // 保存配置
            $this->configManager->set('app.maintenance_mode', $maintenanceConfig);
            
            // 记录紧急关闭事件
            $this->logger->critical('维护模式已紧急关闭', [
                'ip' => $this->securityUtils->getRealIpAddress()
            ]);
            
            // 发送管理员通知
            $this->sendAdminNotification(
                '维护模式已紧急关闭',
                '系统维护模式被紧急关闭，请确认是否为授权操作'
            );
            
            return [
                'success' => true,
                'message' => '维护模式已紧急关闭',
                'data' => [
                    'enabled' => false,
                    'ended_at' => $maintenanceConfig['ended_at']
                ]
            ];
        } catch (Exception $e) {
            $this->logger->error('紧急关闭维护模式失败', [
                'error' => $e->getMessage(),
                'ip' => $this->securityUtils->getRealIpAddress()
            ]);
            
            return [
                'success' => false,
                'error' => 'INTERNAL_ERROR',
                'message' => '紧急关闭维护模式失败: ' . $e->getMessage(),
                'code' => 500
            ];
        }
    }
    
    /**
     * 发送管理员通知
     * 
     * @param string $subject 邮件主题
     * @param string $message 邮件内容
     */
    private function sendAdminNotification($subject, $message) {
        try {
            // 获取维护模式配置
            $maintenanceConfig = $this->configManager->get('app.maintenance_mode', []);
            
            // 检查是否配置了通知邮箱
            $notificationEmail = $maintenanceConfig['notification_email'] ?? '';
            if (empty($notificationEmail)) {
                return;
            }
            
            // 这里应该使用实际的邮件发送函数
            // 暂时记录日志代替
            $this->logger->info('发送维护模式通知', [
                'to' => $notificationEmail,
                'subject' => $subject,
                'message' => $message
            ]);
            
            // TODO: 实现实际的邮件发送功能
            // mail($notificationEmail, $subject, $message);
        } catch (Exception $e) {
            $this->logger->error('发送维护模式通知失败', [
                'error' => $e->getMessage()
            ]);
        }
    }
}