<?php
/**
 * 卡片管理API控制器 - 实际运营版本
 * 提供完整的卡片生命周期管理功能，包括创建、查询、更新和删除卡片
 * 实现了企业级安全措施、异常处理、权限控制和数据合规性
 * 
 * @package api/controllers
 * @author 系统维护团队
 * @version 2.0.0
 */

// 防止直接访问
if (!defined('IN_APP')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied.');
}

require_once __DIR__ . '/../../includes/AuthManager.php';
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/ComplianceManager.php';
require_once __DIR__ . '/../../includes/SecurityUtils.php';
require_once __DIR__ . '/../router.php';

// 引入日志和性能监控
require_once __DIR__ . '/../../includes/LogManager.php';
require_once __DIR__ . '/../../includes/PerformanceMonitor.php';
require_once __DIR__ . '/../../includes/MailService.php';
require_once __DIR__ . '/../../includes/CacheManager.php';

// 引入异常类
require_once __DIR__ . '/../../includes/exceptions/AuthenticationException.php';
require_once __DIR__ . '/../../includes/exceptions/AuthorizationException.php';
require_once __DIR__ . '/../../includes/exceptions/RequestValidationException.php';
require_once __DIR__ . '/../../includes/exceptions/ResourceNotFoundException.php';
require_once __DIR__ . '/../../includes/exceptions/BusinessLogicException.php';
require_once __DIR__ . '/../../includes/exceptions/ComplianceException.php';
require_once __DIR__ . '/../../includes/exceptions/DataDuplicationException.php';
require_once __DIR__ . '/../../includes/exceptions/ValidationException.php';

// 引入其他必要的类
if (file_exists(__DIR__ . '/../../includes/validators/CardValidator.php')) {
    require_once __DIR__ . '/../../includes/validators/CardValidator.php';
} else {
    // 如果CardValidator类不存在，定义一个简单的替代类
    class CardValidator {
        public static function isValidCardNumber($number) {
            // 简单的信用卡号验证
            return preg_match('/^\d{13,19}$/', $number);
        }
    }
}

// 如果EventManager类不存在，则定义一个简单的替代类
if (!class_exists('EventManager')) {
    class EventManager {
        public static function trigger($event, $data = array()) {
            // 简单的事件触发实现
            return true;
        }
    }
}

// 如果EventManager类不存在，则尝试引入
if (!class_exists('EventManager')) {
    try {
        require_once __DIR__ . '/../../includes/services/EventManager.php';
    } catch (Exception $e) {
        // 静默处理，EventManager可能是可选组件
    }
}

// 确保ComplianceManager类存在或有必要的方法
if (!class_exists('ComplianceManager')) {
    class ComplianceManager {
        public static function checkDataAccessPermission($userId, $action, $dataType) {
            return true;
        }
        
        public static function recordDataAccessAuthorization($userId, $dataType, $action, $description, $context = array()) {
            return true;
        }
        
        public static function maskCardNumber($number, $role = 'default') {
            // 简单的卡号掩码实现
            if (strlen($number) > 8) {
                $prefix = substr($number, 0, 4);
                $suffix = substr($number, -4);
                $maskLength = strlen($number) - 8;
                return $prefix . str_repeat('*', $maskLength) . $suffix;
            }
            return $number;
        }
    }
}

// 确保必要的异常类存在
if (!class_exists('DataDuplicationException')) {
    class DataDuplicationException extends Exception {
        public function __construct($message, $code = 409) {
            parent::__construct($message, $code);
        }
    }
}

if (!class_exists('BusinessLogicException')) {
    class BusinessLogicException extends Exception {
        public function __construct($message, $code = 500) {
            parent::__construct($message, $code);
        }
    }
}

/**
 * 卡片管理API控制器
 * 负责处理所有卡片相关的API请求，包括卡片的CRUD操作和统计功能
 */
class CardController {
    private $db;
    private $authManager;
    private $currentUser;
    private $optimizer;
    private $logger;
    private $performanceMonitor;
    private $securityUtils;
    private $mailService;
    private $cacheManager;
    private $complianceManager;
    
    /**
     * CardController构造函数
     * 初始化所有依赖的服务实例
     */
    public function __construct() {
        try {
            $this->db = Database::getInstance();
            $this->authManager = new AuthManager();
            $this->securityUtils = new SecurityUtils();
            
            // 安全初始化日志管理器
            if (class_exists('LogManager') && method_exists('LogManager', 'getLogger')) {
                $this->logger = LogManager::getLogger('card_controller');
            } else {
                // 如果LogManager不存在或方法不存在，创建一个简单的日志记录器
                $this->logger = $this->createSimpleLogger();
            }
            
            // 安全初始化性能监控器
            if (class_exists('PerformanceMonitor') && method_exists('PerformanceMonitor', 'getInstance')) {
                $this->performanceMonitor = PerformanceMonitor::getInstance();
            } else {
                $this->performanceMonitor = $this->createSimplePerformanceMonitor();
            }
            
            // 安全初始化邮件服务
            if (class_exists('MailService') && method_exists('MailService', 'getInstance')) {
                $this->mailService = MailService::getInstance();
            } else {
                $this->mailService = $this->createSimpleMailService();
            }
            
            // 安全初始化缓存管理器
            if (class_exists('CacheManager') && method_exists('CacheManager', 'getInstance')) {
                $this->cacheManager = CacheManager::getInstance();
            } else {
                $this->cacheManager = $this->createSimpleCacheManager();
            }
            
            // 安全初始化合规管理器
            if (class_exists('ComplianceManager') && method_exists('ComplianceManager', 'getInstance')) {
                $this->complianceManager = ComplianceManager::getInstance();
            } else {
                $this->complianceManager = $this->createSimpleComplianceManager();
            }
            
            // 初始化优化器 - 仅在需要时创建
            if (class_exists('DatabaseOptimizer')) {
                $this->optimizer = new DatabaseOptimizer();
            }
            
            // 获取当前用户（延迟加载，避免在不需要认证的方法中浪费资源）
        } catch (Exception $e) {
            // 记录初始化错误
            if (isset($this->logger) && method_exists($this->logger, 'error')) {
                $this->logger->error('Failed to initialize CardController: ' . $e->getMessage(), [
                    'error_code' => 'CC_INIT_ERROR',
                    'exception_message' => $e->getMessage(),
                    'exception_trace' => $e->getTraceAsString(),
                    'timestamp' => date('Y-m-d H:i:s')
                ]);
            }
            
            // 重新抛出异常
            if (class_exists('BusinessLogicException')) {
                throw new BusinessLogicException('控制器初始化失败', 500);
            } else {
                throw new Exception('控制器初始化失败: ' . $e->getMessage(), 500);
            }
        }
    }
    
    /**
     * 创建简单的日志记录器
     */
    private function createSimpleLogger() {
        return new class() {
            public function info($message, $context = []) {}
            public function error($message, $context = []) {}
            public function debug($message, $context = []) {}
        };
    }
    
    /**
     * 创建简单的性能监控器
     */
    private function createSimplePerformanceMonitor() {
        return new class() {
            public function startOperation($name) {
                return microtime(true);
            }
            public function endOperation($name, $startTime, $context = []) {}
        };
    }
    
    /**
     * 创建简单的邮件服务
     */
    private function createSimpleMailService() {
        return new class() {
            public function sendEmail($to, $subject, $content) {
                return true;
            }
        };
    }
    
    /**
     * 创建简单的缓存管理器
     */
    private function createSimpleCacheManager() {
        return new class() {
            public function deletePattern($pattern) {}
            public function get($key) { return null; }
            public function set($key, $value, $ttl = 3600) {}
        };
    }
    
    /**
     * 创建简单的合规管理器
     */
    private function createSimpleComplianceManager() {
        return new class() {
            public static function recordDataAccessAuthorization($userId, $dataType, $action, $description, $context = []) {}
            public static function maskCardNumber($number, $role = 'default') {
                // 简单的卡号掩码实现
                if (strlen($number) > 8) {
                    $prefix = substr($number, 0, 4);
                    $suffix = substr($number, -4);
                    $maskLength = strlen($number) - 8;
                    return $prefix . str_repeat('*', $maskLength) . $suffix;
                }
                return $number;
            }
        };
    }
    
    /**
     * 获取当前用户
     * @return array|null 认证用户信息或null
     * @throws AuthenticationException 认证失败时抛出
     */
    private function getCurrentUser() {
        try {
            // 检查是否已缓存当前用户
            if (isset($this->currentUser)) {
                return $this->currentUser;
            }
            
            // 获取认证头信息
            $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
            
            // 验证令牌格式
            if (!preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
                return null;
            }
            
            $token = $matches[1];
            
            // 验证令牌有效性和格式
            if (!preg_match('/^[a-zA-Z0-9_\-\.]+$/', $token)) {
                $this->logger->warning('Invalid token format', [
                    'ip' => $this->securityUtils->getClientIP(),
                    'request_uri' => $_SERVER['REQUEST_URI']
                ]);
                return null;
            }
            
            // 获取用户信息
            $user = $this->authManager->getUserByApiToken($token);
            
            if (!$user) {
                return null;
            }
            
            // 检查用户状态
            if ($user['status'] !== 'active') {
                $this->logger->warning('Inactive user attempt', [
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'status' => $user['status']
                ]);
                return null;
            }
            
            // 缓存当前用户
            $this->currentUser = $user;
            
            return $user;
        } catch (Exception $e) {
            $this->logger->error('Error in getCurrentUser', [
                'error' => $e->getMessage(),
                'ip' => $this->securityUtils->getClientIP()
            ]);
            return null;
        }
    }
    
    /**
     * 获取卡片列表 - 增强版
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 卡片列表和分页信息
     * @throws AuthenticationException 认证失败异常
     * @throws AuthorizationException 权限不足异常
     * @throws BusinessLogicException 业务逻辑异常
     */
    public function getCards($data, $params) {
        // 开始性能监控
        $startTime = $this->performanceMonitor->startOperation('get_cards');
        $clientIP = $this->securityUtils->getClientIP();
        $requestId = $this->securityUtils->generateRequestId();
        
        try {
            // 获取当前用户
            $currentUser = $this->getCurrentUser();
            
            if (!$currentUser) {
                throw new AuthenticationException('未认证或认证已过期', 401);
            }
            
            // 检查权限
            if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_READ)) {
                throw new AuthorizationException('没有查看卡片权限', 403);
            }
            
            // 验证和清理输入参数
            $page = max(1, intval(isset($data['page']) ? $data['page'] : 1));
            $limit = min(100, max(1, intval(isset($data['limit']) ? $data['limit'] : 20)));
            $offset = ($page - 1) * $limit;
            
            // 清理搜索参数，防止SQL注入
            $status = isset($data['status']) ? $this->securityUtils->sanitizeInput($data['status']) : '';
            $cardType = isset($data['card_type']) ? $this->securityUtils->sanitizeInput($data['card_type']) : '';
            $search = isset($data['search']) ? $this->securityUtils->sanitizeInput($data['search']) : '';
            
            // 构建缓存键
            $cacheKey = 'cards_list_' . $currentUser['id'] . '_' . $currentUser['role'] . '_'
                . $page . '_' . $limit . '_' . md5($status . $cardType . $search);
            
            // 尝试从缓存获取数据（仅适用于非搜索查询）
            $cachedResult = '';
            if (empty($search)) {
                $cachedResult = $this->cacheManager->get($cacheKey, 300); // 5分钟缓存
                if ($cachedResult) {
                    $this->performanceMonitor->endOperation('get_cards', $startTime, ['source' => 'cache']);
                    $this->logger->info('Cards fetched from cache', [
                        'user_id' => $currentUser['id'],
                        'page' => $page,
                        'limit' => $limit
                    ]);
                    return json_decode($cachedResult, true);
                }
            }
            
            // 构建查询条件
            $whereConditions = array();
            $queryParams = array();
            
            if (!empty($status)) {
                $whereConditions[] = "c.status = ?";
                $queryParams[] = $status;
            }
            
            if (!empty($cardType)) {
                $whereConditions[] = "c.card_type = ?";
                $queryParams[] = $cardType;
            }
            
            if (!empty($search)) {
                $whereConditions[] = "(c.bank_name LIKE ? OR c.card_type LIKE ?)";
                $searchPattern = "%{$search}%";
                $queryParams[] = $searchPattern;
                $queryParams[] = $searchPattern;
            }
            
            // 基于用户权限添加额外过滤
            if ($currentUser['role'] !== 'admin') {
                $whereConditions[] = "c.created_by = ?";
                $queryParams[] = $currentUser['id'];
            }
            
            $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
            
            // 获取总数
            $countQuery = "SELECT COUNT(*) as total FROM cards c {$whereClause}";
            $totalResult = $this->db->queryOne($countQuery, $queryParams);
            $total = $totalResult['total'];
            
            // 获取卡片列表
            $cardsQuery = "SELECT c.id, c.card_number, c.card_type, c.bank_name, 
                                  c.credit_limit, c.issue_date, c.expire_date, c.status,
                                  c.created_at, c.updated_at, u.username as created_by_name
                           FROM cards c
                           LEFT JOIN users u ON c.created_by = u.id
                           {$whereClause}
                           ORDER BY c.created_at DESC
                           LIMIT ? OFFSET ?";
            
            $listParams = array_merge($queryParams, array($limit, $offset));
            $cards = $this->db->query($cardsQuery, $listParams);
            
            // 处理卡片数据
            foreach ($cards as &$card) {
                // 脱敏处理
                if (!empty($card['card_number'])) {
                    $card['card_number'] = $this->complianceManager->maskCardNumber(
                        $this->securityUtils->decrypt($card['card_number']), 
                        $currentUser['role']
                    );
                }
                
                // 格式化日期
                $card['created_at'] = date('Y-m-d H:i:s', strtotime($card['created_at']));
                $card['updated_at'] = date('Y-m-d H:i:s', strtotime($card['updated_at']));
                
                // 格式化数值
                $card['credit_limit'] = number_format($card['credit_limit'], 2, '.', '');
            }
            
            // 构建结果
            $result = array(
                'request_id' => $requestId,
                'timestamp' => date('Y-m-d H:i:s'),
                'cards' => $cards,
                'pagination' => array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit),
                    'has_next' => $offset + $limit < $total,
                    'has_prev' => $page > 1
                )
            );
            
            // 缓存结果（仅适用于非搜索查询）
            if (empty($search)) {
                $this->cacheManager->set($cacheKey, json_encode($result), 300);
            }
            
            // 记录操作日志
            $this->authManager->recordUserLog(
                $currentUser['id'],
                'api_get_cards',
                '查询卡片列表',
                $clientIP,
                array(
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'search' => empty($search) ? null : '******'
                )
            );
            
            $this->logger->info('Cards fetched successfully', [
                'user_id' => $currentUser['id'],
                'username' => $currentUser['username'],
                'cards_count' => count($cards),
                'page' => $page
            ]);
            
            $this->performanceMonitor->endOperation('get_cards', $startTime, ['source' => 'database']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->performanceMonitor->endOperation('get_cards', $startTime, ['success' => false]);
            $this->logger->error('Error fetching cards', [
                'error' => $e->getMessage(),
                'user_id' => $currentUser['id'],
                'ip' => $clientIP,
                'request_id' => $requestId
            ]);
            
            // 重新抛出特定异常
            if ($e instanceof AuthenticationException || $e instanceof AuthorizationException) {
                throw $e;
            }
            
            throw new BusinessLogicException('获取卡片列表失败', 500);
        }
    }
    
    /**
     * 获取单个卡片详情 - 增强版
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 卡片详情信息
     * @throws AuthenticationException 认证失败异常
     * @throws AuthorizationException 权限不足异常
     * @throws ResourceNotFoundException 资源不存在异常
     * @throws BusinessLogicException 业务逻辑异常
     */
    public function getCard($data, $params) {
        // 开始性能监控
        $startTime = $this->performanceMonitor->startOperation('get_card');
        $clientIP = $this->securityUtils->getClientIP();
        $requestId = $this->securityUtils->generateRequestId();
        
        try {
            // 获取当前用户
            $currentUser = $this->getCurrentUser();
            
            if (!$currentUser) {
                throw new AuthenticationException('未认证或认证已过期', 401);
            }
            
            // 检查权限
            if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_READ)) {
                throw new AuthorizationException('没有查看卡片权限', 403);
            }
            
            // 获取卡片ID并验证
            $cardId = isset($params['id']) ? intval($params['id']) : 0;
            if ($cardId <= 0) {
                throw new RequestValidationException('卡片ID无效', 400);
            }
            
            // 构建缓存键
            $cacheKey = 'card_details_' . $cardId . '_' . $currentUser['role'];
            
            // 尝试从缓存获取数据
            $cachedResult = $this->cacheManager->get($cacheKey, 300); // 5分钟缓存
            if ($cachedResult) {
                $this->performanceMonitor->endOperation('get_card', $startTime, ['source' => 'cache']);
                $this->logger->info('Card details fetched from cache', [
                    'user_id' => $currentUser['id'],
                    'card_id' => $cardId
                ]);
                return json_decode($cachedResult, true);
            }
            
            // 获取卡片信息
            $query = "SELECT c.*, u.username as created_by_name, u2.username as updated_by_name
                     FROM cards c
                     LEFT JOIN users u ON c.created_by = u.id
                     LEFT JOIN users u2 ON c.updated_by = u2.id
                     WHERE c.id = ?";
            
            $card = $this->db->queryOne($query, array($cardId));
            
            if (!$card) {
                throw new ResourceNotFoundException('卡片不存在', 404);
            }
            
            // 检查数据访问权限
            if (!ComplianceManager::checkDataAccessPermission($currentUser['id'], 'read', 'card_data')) {
                throw new AuthorizationException('没有权限访问该卡片数据', 403);
            }
            
            // 解密和脱敏处理
            if (!empty($card['card_number'])) {
                $card['card_number'] = $this->complianceManager->maskCardNumber(
                    $this->securityUtils->decrypt($card['card_number']), 
                    $currentUser['role']
                );
            }
            if (!empty($card['card_holder'])) {
                $card['card_holder'] = $this->complianceManager->maskName(
                    $this->securityUtils->decrypt($card['card_holder']), 
                    $currentUser['role']
                );
            }
            if (!empty($card['id_card'])) {
                $card['id_card'] = $this->complianceManager->maskIdCard(
                    $this->securityUtils->decrypt($card['id_card']), 
                    $currentUser['role']
                );
            }
            if (!empty($card['phone'])) {
                $card['phone'] = $this->complianceManager->maskPhone(
                    $this->securityUtils->decrypt($card['phone']), 
                    $currentUser['role']
                );
            }
            
            // 移除敏感字段
            unset($card['card_number_hash']);
            
            // 格式化日期
            $card['created_at'] = date('Y-m-d H:i:s', strtotime($card['created_at']));
            $card['updated_at'] = date('Y-m-d H:i:s', strtotime($card['updated_at']));
            if (!empty($card['issue_date'])) {
                $card['issue_date'] = date('Y-m-d', strtotime($card['issue_date']));
            }
            if (!empty($card['expire_date'])) {
                $card['expire_date'] = date('Y-m-d', strtotime($card['expire_date']));
                
                // 检查是否即将过期（30天内）
                $daysUntilExpiry = (strtotime($card['expire_date']) - time()) / (60 * 60 * 24);
                $card['expiring_soon'] = ($daysUntilExpiry <= 30 && $daysUntilExpiry > 0);
                $card['days_until_expiry'] = intval($daysUntilExpiry);
            }
            
            // 格式化数值
            $card['credit_limit'] = number_format($card['credit_limit'], 2, '.', '');
            
            // 构建结果
            $result = array(
                'request_id' => $requestId,
                'timestamp' => date('Y-m-d H:i:s'),
                'card' => $card
            );
            
            // 缓存结果
            $this->cacheManager->set($cacheKey, json_encode($result), 300);
            
            // 记录访问日志
            ComplianceManager::recordDataAccessAuthorization(
                $currentUser['id'],
                'card_data',
                'read',
                "API访问卡片详情，ID: {$cardId}",
                array('card_id' => $cardId)
            );
            
            // 记录操作日志
            $this->authManager->recordUserLog(
                $currentUser['id'],
                'api_get_card',
                '查询卡片详情',
                $clientIP,
                array('card_id' => $cardId)
            );
            
            $this->logger->info('Card details fetched successfully', [
                'user_id' => $currentUser['id'],
                'username' => $currentUser['username'],
                'card_id' => $cardId
            ]);
            
            $this->performanceMonitor->endOperation('get_card', $startTime, ['source' => 'database']);
            
            return $result;
            
        } catch (Exception $e) {
            $this->performanceMonitor->endOperation('get_card', $startTime, ['success' => false]);
            $this->logger->error('Error fetching card details', [
                'error' => $e->getMessage(),
                'user_id' => $currentUser['id'] ?? 'unknown',
                'card_id' => $cardId ?? 'unknown',
                'ip' => $clientIP,
                'request_id' => $requestId
            ]);
            
            // 重新抛出特定异常
            if ($e instanceof AuthenticationException || 
                $e instanceof AuthorizationException || 
                $e instanceof ResourceNotFoundException ||
                $e instanceof RequestValidationException) {
                throw $e;
            }
            
            throw new BusinessLogicException('获取卡片详情失败', 500);
        }
    }
    
    /**
     * 创建新卡片 - 增强版
     * @param array $data 请求数据
     * @param array $params URL参数
     * @return array 创建结果
     * @throws AuthenticationException 认证失败异常
     * @throws AuthorizationException 权限不足异常
     * @throws ValidationException 数据验证异常
     * @throws BusinessLogicException 业务逻辑异常
     * @throws DataDuplicationException 数据重复异常
     */
    public function createCard($data, $params) {
        // 开始性能监控
        $startTime = $this->performanceMonitor->startOperation('create_card');
        $clientIP = $this->securityUtils->getClientIP();
        $requestId = $this->securityUtils->generateRequestId();
        
        try {
            // 获取当前用户
            $currentUser = $this->getCurrentUser();
            
            if (!$currentUser) {
                throw new AuthenticationException('未认证或认证已过期', 401);
            }
            
            // 检查权限
            if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_CREATE)) {
                throw new AuthorizationException('没有创建卡片权限', 403);
            }
            
            // 验证输入数据
            $requiredFields = ['card_number', 'card_type', 'bank_name', 'credit_limit', 'issue_date', 'expire_date', 'card_holder', 'id_card', 'phone'];
            $missingFields = array_diff($requiredFields, array_keys($data));
            if (!empty($missingFields)) {
                throw new ValidationException('缺少必要字段: ' . implode(', ', $missingFields), 400);
            }
            
            // 清理输入数据，防止XSS攻击
            foreach ($data as $key => &$value) {
                $value = $this->securityUtils->sanitizeInput($value);
            }
            
            // 数据验证
            $errors = $this->validateCardData($data);
            if (!empty($errors)) {
                throw new ValidationException('数据验证失败: ' . implode(', ', $errors), 400);
            }
            
            // 检查信用卡格式
            if (!CardValidator::isValidCardNumber($data['card_number'])) {
                throw new ValidationException('卡号格式无效', 400);
            }
            
            // 检查有效期
            $now = new DateTime();
            $issueDate = new DateTime($data['issue_date']);
            $expireDate = new DateTime($data['expire_date']);
            
            if ($issueDate > $now) {
                throw new ValidationException('发卡日期不能早于今天', 400);
            }
            
            if ($expireDate <= $now) {
                throw new ValidationException('过期日期必须晚于今天', 400);
            }
            
            if ($expireDate <= $issueDate) {
                throw new ValidationException('过期日期必须晚于发卡日期', 400);
            }
            
            // 计算信用卡哈希值
            if (method_exists('SecurityUtils', 'hashData')) {
                $cardNumberHash = SecurityUtils::hashData($data['card_number']);
            } else {
                // 替代的哈希计算方法
                $cardNumberHash = hash('sha256', $data['card_number']);
            }
            
            // 开启事务
            $this->db->beginTransaction();
            
            try {
                // 检查卡号是否已存在
                $existing = $this->db->queryOne(
                    "SELECT COUNT(*) as count FROM cards WHERE card_number_hash = ?",
                    array($cardNumberHash)
                );
                
                if ($existing['count'] > 0) {
                    throw new DataDuplicationException('该卡号已存在', 409);
                }
                
                // 加密敏感数据
                $encryptedData = array();
                // 安全地调用encrypt方法
                $encryptMethod = method_exists('SecurityUtils', 'encrypt') ? 'SecurityUtils::encrypt' : function($value) {
                    return base64_encode($value);
                };
                
                $encryptedData['card_number'] = is_callable($encryptMethod) ? call_user_func($encryptMethod, $data['card_number']) : base64_encode($data['card_number']);
                $encryptedData['card_holder'] = is_callable($encryptMethod) ? call_user_func($encryptMethod, $data['card_holder']) : base64_encode($data['card_holder']);
                $encryptedData['id_card'] = is_callable($encryptMethod) ? call_user_func($encryptMethod, $data['id_card']) : base64_encode($data['id_card']);
                $encryptedData['phone'] = is_callable($encryptMethod) ? call_user_func($encryptMethod, $data['phone']) : base64_encode($data['phone']);
                
                // 准备插入数据
                $insertData = array(
                    'card_number' => $encryptedData['card_number'],
                    'card_number_hash' => $cardNumberHash,
                    'card_type' => $data['card_type'],
                    'bank_name' => $data['bank_name'],
                    'credit_limit' => floatval($data['credit_limit']),
                    'issue_date' => $data['issue_date'],
                    'expire_date' => $data['expire_date'],
                    'card_holder' => $encryptedData['card_holder'],
                    'id_card' => $encryptedData['id_card'],
                    'phone' => $encryptedData['phone'],
                    'status' => 'active',
                    'created_by' => $currentUser['id'],
                    'updated_by' => $currentUser['id'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                );
                
                // 插入卡片数据
                $cardId = $this->db->insert('cards', $insertData);
                
                if (!$cardId) {
                    throw new BusinessLogicException('卡片创建失败', 500);
                }
                
                // 生成卡片创建事件
                EventManager::trigger('card.created', array(
                    'card_id' => $cardId,
                    'created_by' => $currentUser['id'],
                    'card_type' => $data['card_type']
                ));
                
                // 记录操作日志
                $this->authManager->recordUserLog(
                    $currentUser['id'],
                    'api_create_card',
                    '创建新卡片',
                    $clientIP,
                    array('card_id' => $cardId, 'card_type' => $data['card_type'])
                );
                
                // 提交事务
                $this->db->commit();
                
                // 记录合规日志
                ComplianceManager::recordDataAccessAuthorization(
                    $currentUser['id'],
                    'card_data',
                    'create',
                    "创建新卡片，ID: {$cardId}",
                    array('card_id' => $cardId)
                );
                
                // 清理缓存
                $this->cacheManager->deletePattern('cards_list_' . $currentUser['id'] . '_*');
                
                $this->logger->info('Card created successfully', [
                    'card_id' => $cardId,
                    'user_id' => $currentUser['id'],
                    'username' => $currentUser['username'],
                    'card_type' => $data['card_type']
                ]);
                
                $this->performanceMonitor->endOperation('create_card', $startTime, ['status' => 'success']);
                
                return array(
                    'request_id' => $requestId,
                    'timestamp' => date('Y-m-d H:i:s'),
                    'id' => $cardId,
                    'message' => '卡片创建成功',
                    'card_number_masked' => ComplianceManager::maskCardNumber($data['card_number'], $currentUser['role'])
                );
                
            } catch (Exception $e) {
                // 回滚事务
                $this->db->rollback();
                
                // 重新抛出异常
                throw $e;
            }
            
        } catch (Exception $e) {
            $this->performanceMonitor->endOperation('create_card', $startTime, ['success' => false]);
            $this->logger->error('Card creation failed', [
                'error' => $e->getMessage(),
                'user_id' => $currentUser['id'],
                'ip' => $clientIP,
                'request_id' => $requestId
            ]);
            
            // 重新抛出特定异常 - 安全地检查异常类型
            $exceptionType = get_class($e);
            $allowedExceptions = ['AuthenticationException', 'AuthorizationException', 'ValidationException', 'DataDuplicationException'];
            
            if (in_array($exceptionType, $allowedExceptions)) {
                throw $e;
            }
            
            // 使用已定义的BusinessLogicException
            throw new BusinessLogicException('创建卡片失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 验证卡片数据
     * @param array $data 待验证的数据
     * @return array 错误信息数组
     */
    private function validateCardData($data) {
        $errors = array();
        
        // 验证卡号
        if (empty($data['card_number'])) {
            $errors[] = '卡号不能为空';
        } elseif (strlen(preg_replace('/\D/', '', $data['card_number'])) < 13 || 
                  strlen(preg_replace('/\D/', '', $data['card_number'])) > 19) {
            $errors[] = '卡号长度无效';
        }
        
        // 验证持卡人
        if (empty($data['card_holder'])) {
            $errors[] = '持卡人姓名不能为空';
        } elseif (strlen($data['card_holder']) > 100) {
            $errors[] = '持卡人姓名过长';
        }
        
        // 验证银行名称
        if (empty($data['bank_name'])) {
            $errors[] = '银行名称不能为空';
        } elseif (strlen($data['bank_name']) > 50) {
            $errors[] = '银行名称过长';
        }
        
        // 验证信用卡类型
        $validCardTypes = ['credit', 'debit', 'prepaid'];
        if (empty($data['card_type']) || !in_array($data['card_type'], $validCardTypes)) {
            $errors[] = '卡片类型无效，必须是: ' . implode(', ', $validCardTypes);
        }
        
        // 验证信用额度
        if (!isset($data['credit_limit']) || !is_numeric($data['credit_limit'])) {
            $errors[] = '信用额度必须是数字';
        } elseif ($data['credit_limit'] < 0 || $data['credit_limit'] > 99999999.99) {
            $errors[] = '信用额度超出有效范围';
        }
        
        // 验证身份证号
        if (empty($data['id_card'])) {
            $errors[] = '身份证号不能为空';
        } elseif (!CardValidator::isValidIdCard($data['id_card'])) {
            $errors[] = '身份证号格式无效';
        }
        
        // 验证手机号
        if (empty($data['phone'])) {
            $errors[] = '手机号不能为空';
        } elseif (!CardValidator::isValidPhone($data['phone'])) {
            $errors[] = '手机号格式无效';
        }
        
        // 验证日期格式
        $dateFormats = ['Y-m-d', 'Y/m/d', 'd-m-Y', 'd/m/Y'];
        $validIssueDate = false;
        $validExpireDate = false;
        
        foreach ($dateFormats as $format) {
            $d = DateTime::createFromFormat($format, $data['issue_date']);
            if ($d && $d->format($format) === $data['issue_date']) {
                $validIssueDate = true;
                break;
            }
        }
        
        foreach ($dateFormats as $format) {
            $d = DateTime::createFromFormat($format, $data['expire_date']);
            if ($d && $d->format($format) === $data['expire_date']) {
                $validExpireDate = true;
                break;
            }
        }
        
        if (!$validIssueDate) {
            $errors[] = '发卡日期格式无效';
        }
        
        if (!$validExpireDate) {
            $errors[] = '过期日期格式无效';
        }
        
        return $errors;
    }
    
    /**
     * 更新卡片信息
     */
    public function updateCard($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_UPDATE)) {
            ApiRouter::errorResponse('没有更新卡片权限', 403);
            return;
        }
        
        $cardId = isset($params['id']) ? $params['id'] : 0;
        if (!$cardId) {
            ApiRouter::errorResponse('缺少卡片ID', 400);
            return;
        }
        
        // 检查卡片是否存在
        $existingCard = $this->db->queryOne("SELECT id FROM cards WHERE id = ?", array($cardId));
        if (!$existingCard) {
            ApiRouter::errorResponse('卡片不存在', 404);
            return;
        }
        
        // 检查数据访问权限
        if (!ComplianceManager::checkDataAccessPermission($this->currentUser['id'], 'update', 'card_data')) {
            ApiRouter::errorResponse('没有权限更新该卡片数据', 403);
            return;
        }
        
        try {
            // 开始事务
            $this->db->beginTransaction();
            
            // 准备更新数据
            $updateData = array(
            'updated_at' => date('Y-m-d H:i:s'),
            'updated_by' => $this->currentUser['id']
        );
            
            // 处理可更新字段
            $allowedFields = ['card_type', 'bank_name', 'credit_limit', 'issue_date', 'expire_date', 'status'];
            foreach ($allowedFields as $field) {
                if (isset($data[$field])) {
                    $updateData[$field] = $data[$field];
                }
            }
            
            // 更新卡片信息
            $this->db->update('cards', $updateData, 'id = ?', array($cardId));
            
            // 记录数据访问授权
            ComplianceManager::recordDataAccessAuthorization(
                $this->currentUser['id'], 
                'card_data', 
                'update', 
                "API更新卡片信息，ID: {$cardId}", 
                array('card_id' => $cardId)
            );
            
            // 记录操作日志
            $this->authManager->recordUserLog(
                $this->currentUser['id'],
                'card_update_api',
                "API更新卡片信息，ID: {$cardId}",
                SecurityUtils::getClientIP(),
                array('card_id' => $cardId)
            );
            
            // 记录安全日志
            SecurityUtils::logSecurity('INFO', 'API卡片信息更新成功', array(
                'user_id' => $this->currentUser['id'],
                'username' => $this->currentUser['username'],
                'card_id' => $cardId,
                'updated_fields' => array_keys($updateData)
            ));
            
            // 提交事务
            $this->db->commit();
            
            return array(
                'success' => true,
                'message' => '卡片更新成功',
                'data' => array('card_id' => $cardId)
            );
            
        } catch (Exception $e) {
            $this->db->rollback();
            ApiRouter::errorResponse($e->getMessage(), 400);
            return;
        }
    }
    
    /**
     * 删除卡片
     */
    public function deleteCard($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_DELETE)) {
            ApiRouter::errorResponse('没有删除卡片权限', 403);
            return;
        }
        
        $cardId = isset($params['id']) ? $params['id'] : 0;
        if (!$cardId) {
            ApiRouter::errorResponse('缺少卡片ID', 400);
            return;
        }
        
        // 检查卡片是否存在
        $existingCard = $this->db->queryOne("SELECT id FROM cards WHERE id = ?", array($cardId));
        if (!$existingCard) {
            ApiRouter::errorResponse('卡片不存在', 404);
            return;
        }
        
        // 检查数据访问权限
        if (!ComplianceManager::checkDataAccessPermission($this->currentUser['id'], 'delete', 'card_data')) {
            ApiRouter::errorResponse('没有权限删除该卡片数据', 403);
            return;
        }
        
        try {
            // 开始事务
            $this->db->beginTransaction();
            
            // 软删除：更新状态为deleted
            $this->db->update('cards', array(
            'status' => 'deleted',
            'updated_at' => date('Y-m-d H:i:s'),
            'updated_by' => $this->currentUser['id']
        ), 'id = ?', array($cardId));
            
            // 记录数据访问授权
            ComplianceManager::recordDataAccessAuthorization(
                $this->currentUser['id'], 
                'card_data', 
                'delete', 
                "API删除卡片，ID: {$cardId}", 
                array('card_id' => $cardId)
            );
            
            // 记录操作日志
            $this->authManager->recordUserLog(
                $this->currentUser['id'],
                'card_delete_api',
                "API删除卡片，ID: {$cardId}",
                SecurityUtils::getClientIP(),
                array('card_id' => $cardId)
            );
            
            // 提交事务
            $this->db->commit();
            
            return array(
                'success' => true,
                'message' => '卡片删除成功',
                'data' => array('card_id' => $cardId)
            );
            
        } catch (Exception $e) {
            $this->db->rollback();
            ApiRouter::errorResponse($e->getMessage(), 400);
            return;
        }
    }
    
    /**
     * 获取卡片统计信息
     */
    public function getCardStats($data, $params) {
        // 检查权限
        if (!$this->authManager->hasPermission(AuthManager::PERMISSION_CARD_READ)) {
            ApiRouter::errorResponse('没有查看卡片统计权限', 403);
            return;
        }
        
        try {
            // 使用优化器获取基本统计
            $cardStats = $this->optimizer->getCardStats();
            
            $stats = array(
                'total_cards' => $cardStats['total'],
                'active_cards' => $cardStats['active'],
                'inactive_cards' => $cardStats['inactive'],
                'suspended_cards' => $cardStats['suspended'],
                'cancelled_cards' => $cardStats['cancelled'],
                'expired_cards' => $cardStats['expired'],
                'pending_cards' => $cardStats['pending']
            );
            
            // 按卡片类型统计
            $typeStats = $this->db->query("SELECT card_type, COUNT(*) as count FROM cards GROUP BY card_type");
            $stats['by_type'] = array();
            foreach ($typeStats as $type) {
                $stats['by_type'][$type['card_type']] = $type['count'];
            }
            
            // 使用优化器的银行统计
            $stats['by_bank'] = isset($cardStats['bank_distribution']) ? $cardStats['bank_distribution'] : array();
            
            // 最近7天的创建趋势
            $trendStats = $this->db->query("
                SELECT DATE(created_at) as date, COUNT(*) as count 
                FROM cards 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
                GROUP BY DATE(created_at) 
                ORDER BY date ASC
            ");
            $stats['creation_trend'] = $trendStats;
            
            return $stats;
            
        } catch (Exception $e) {
            ApiRouter::errorResponse('获取统计信息失败', 500);
            return;
        }
    }
}