<?php
/**
 * API响应工具类
 * 提供统一的响应格式和数据处理功能
 */

// 引入异常处理器
require_once __DIR__ . '/../includes/ExceptionHandler.php';
require_once __DIR__ . '/../includes/LogManager.php';

class ApiResponse {
    /**
     * 异常处理器实例
     */
    private static $exceptionHandler;
    
    /**
     * 初始化异常处理器
     */
    private static function initExceptionHandler() {
        if (!self::$exceptionHandler) {
            self::$exceptionHandler = new ExceptionHandler();
        }
    }
    
    /**
     * 全局异常处理入口
     * 捕获并处理API调用过程中的所有异常
     */
    public static function handleException($exception) {
        // 确保异常处理器已初始化
        self::initExceptionHandler();
        
        try {
            // 使用异常处理器处理异常
            $errorInfo = self::$exceptionHandler->handle($exception);
            
            // 根据异常类型返回对应的API错误响应
            switch ($errorInfo['type']) {
                case 'validation_error':
                    self::validationError($errorInfo['details'] ?? [], $errorInfo['message']);
                    break;
                case 'authentication_error':
                    self::unauthorized($errorInfo['message']);
                    break;
                case 'authorization_error':
                    self::forbidden($errorInfo['message']);
                    break;
                case 'not_found_error':
                    self::notFound($errorInfo['message']);
                    break;
                case 'business_error':
                    self::error(
                        $errorInfo['code'] ?? 'BUSINESS_ERROR',
                        $errorInfo['message'],
                        400,
                        $errorInfo['details']
                    );
                    break;
                case 'file_error':
                    self::error(
                        $errorInfo['code'] ?? 'FILE_ERROR',
                        $errorInfo['message'],
                        400,
                        $errorInfo['details']
                    );
                    break;
                case 'payment_error':
                    self::error(
                        $errorInfo['code'] ?? 'PAYMENT_ERROR',
                        $errorInfo['message'],
                        400,
                        $errorInfo['details']
                    );
                    break;
                case 'database_error':
                    // 数据库错误不暴露详细信息给客户端
                    self::serverError('数据库操作失败，请稍后重试');
                    break;
                default:
                    // 未分类错误作为服务器内部错误处理
                    self::serverError('服务器内部错误，请稍后重试');
            }
        } catch (Exception $e) {
            // 处理异常处理过程中发生的异常
            $logger = new LogManager('api_error');
            $logger->error('异常处理机制失败', [
                'original_error' => $exception->getMessage(),
                'handling_error' => $e->getMessage(),
                'stack_trace' => $e->getTraceAsString()
            ]);
            
            // 返回最基本的错误响应
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'SYSTEM_ERROR', 'message' => '系统错误，请稍后重试']);
            exit;
        }
    }
    
    /**
     * 注册全局异常处理器
     */
    public static function registerGlobalExceptionHandler() {
        // 设置全局异常处理器
        set_exception_handler(function($exception) {
            ApiResponse::handleException($exception);
        });
        
        // 设置全局错误处理器（将PHP错误转换为异常）
        set_error_handler(function($errno, $errstr, $errfile, $errline) {
            if (!(error_reporting() & $errno)) {
                return;
            }
            
            // 将错误转换为异常
            throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
        });
        
        // 设置全局终止函数，捕获未处理的致命错误
        register_shutdown_function(function() {
            $error = error_get_last();
            if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
                $exception = new ErrorException(
                    $error['message'],
                    0,
                    $error['type'],
                    $error['file'],
                    $error['line']
                );
                ApiResponse::handleException($exception);
            }
        });
    }
    
    /**
     * 发送成功响应
     */
    public static function success($data = null, $message = '操作成功', $http_code = 200) {
        http_response_code($http_code);
        header('Content-Type: application/json');
        
        $response = array(
            'success' => true,
            'data' => $data,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s')
        );
        
        echo json_encode($response);
        exit;
    }
    
    /**
     * 发送错误响应
     */
    public static function error($error_code, $message, $http_code = 400, $details = null) {
        http_response_code($http_code);
        header('Content-Type: application/json');
        
        $response = array(
            'success' => false,
            'error' => $error_code,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s')
        );
        
        if ($details !== null) {
            $response['details'] = $details;
        }
        
        echo json_encode($response);
        exit;
    }
    
    /**
     * 发送验证错误响应
     */
    public static function validationError($errors, $message = '请求参数验证失败') {
        self::error('VALIDATION_ERROR', $message, 400, $errors);
    }
    
    /**
     * 发送未授权响应
     */
    public static function unauthorized($message = '未授权访问') {
        self::error('UNAUTHORIZED', $message, 401);
    }
    
    /**
     * 发送禁止访问响应
     */
    public static function forbidden($message = '权限不足') {
        self::error('FORBIDDEN', $message, 403);
    }
    
    /**
     * 发送资源不存在响应
     */
    public static function notFound($message = '资源不存在') {
        self::error('NOT_FOUND', $message, 404);
    }
    
    /**
     * 发送方法不允许响应
     */
    public static function methodNotAllowed($message = '请求方法不允许') {
        self::error('METHOD_NOT_ALLOWED', $message, 405);
    }
    
    /**
     * 发送服务器错误响应
     */
    public static function serverError($message = '服务器内部错误') {
        self::error('INTERNAL_ERROR', $message, 500);
    }
}

/**
 * 数据验证工具类
 */
class ApiValidator {
    private $errors = array();
    
    /**
     * 验证必填字段
     */
    public function required($data, $fields) {
        foreach ($fields as $field) {
            if (!isset($data[$field]) || $data[$field] === '' || $data[$field] === null) {
                $this->errors[$field] = "字段 {$field} 是必填的";
            }
        }
        return $this;
    }
    
    /**
     * 验证字符串长度
     */
    public function stringLength($data, $field, $min = null, $max = null) {
        if (!isset($data[$field])) {
            return $this;
        }
        
        $value = $data[$field];
        $length = mb_strlen($value, 'UTF-8');
        
        if ($min !== null && $length < $min) {
            $this->errors[$field] = "字段 {$field} 长度不能少于 {$min} 个字符";
        }
        
        if ($max !== null && $length > $max) {
            $this->errors[$field] = "字段 {$field} 长度不能超过 {$max} 个字符";
        }
        
        return $this;
    }
    
    /**
     * 验证邮箱格式
     */
    public function email($data, $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        if (!filter_var($data[$field], FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "字段 {$field} 必须是有效的邮箱地址";
        }
        
        return $this;
    }
    
    /**
     * 验证手机号格式
     */
    public function phone($data, $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        if (!preg_match('/^1[3-9]\d{9}$/', $data[$field])) {
            $this->errors[$field] = "字段 {$field} 必须是有效的手机号码";
        }
        
        return $this;
    }
    
    /**
     * 验证身份证号格式
     */
    public function idCard($data, $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        if (!preg_match('/^\d{17}[\dXx]$/', $data[$field])) {
            $this->errors[$field] = "字段 {$field} 必须是有效的身份证号码";
        }
        
        return $this;
    }
    
    /**
     * 验证银行卡号格式
     */
    public function cardNumber($data, $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        // 移除空格和横线
        $card_number = preg_replace('/[\s-]/', '', $data[$field]);
        
        if (!preg_match('/^\d{13,19}$/', $card_number)) {
            $this->errors[$field] = "字段 {$field} 必须是有效的银行卡号";
        }
        
        return $this;
    }
    
    /**
     * 验证数字范围
     */
    public function numberRange($data, $field, $min = null, $max = null) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        $value = floatval($data[$field]);
        
        if ($min !== null && $value < $min) {
            $this->errors[$field] = "字段 {$field} 不能小于 {$min}";
        }
        
        if ($max !== null && $value > $max) {
            $this->errors[$field] = "字段 {$field} 不能大于 {$max}";
        }
        
        return $this;
    }
    
    /**
     * 验证枚举值
     */
    public function enum($data, $field, $allowed_values) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        if (!in_array($data[$field], $allowed_values)) {
            $this->errors[$field] = "字段 {$field} 必须是以下值之一: " . implode(', ', $allowed_values);
        }
        
        return $this;
    }
    
    /**
     * 验证日期格式
     */
    public function date($data, $field, $format = 'Y-m-d') {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        $date = DateTime::createFromFormat($format, $data[$field]);
        if (!$date || $date->format($format) !== $data[$field]) {
            $this->errors[$field] = "字段 {$field} 必须是有效的日期格式 ({$format})";
        }
        
        return $this;
    }
    
    /**
     * 自定义验证规则
     */
    public function custom($data, $field, $rule, $message) {
        if (!isset($data[$field]) || $data[$field] === '') {
            return $this;
        }
        
        if (!$rule($data[$field])) {
            $this->errors[$field] = $message;
        }
        
        return $this;
    }
    
    /**
     * 获取验证错误
     */
    public function getErrors() {
        return $this->errors;
    }
    
    /**
     * 检查是否有验证错误
     */
    public function hasErrors() {
        return !empty($this->errors);
    }
}

/**
 * 数据脱敏工具类
 */
class DataMasking {
    /**
     * 脱敏银行卡号
     */
    public static function maskCardNumber($card_number) {
        if (strlen($card_number) <= 8) {
            return $card_number;
        }
        
        $start = substr($card_number, 0, 4);
        $end = substr($card_number, -4);
        $middle = str_repeat('*', strlen($card_number) - 8);
        
        return $start . $middle . $end;
    }
    
    /**
     * 脱敏身份证号
     */
    public static function maskIdCard($id_card) {
        if (strlen($id_card) <= 8) {
            return $id_card;
        }
        
        $start = substr($id_card, 0, 6);
        $end = substr($id_card, -4);
        $middle = str_repeat('*', strlen($id_card) - 10);
        
        return $start . $middle . $end;
    }
    
    /**
     * 脱敏手机号
     */
    public static function maskPhone($phone) {
        if (strlen($phone) !== 11) {
            return $phone;
        }
        
        return substr($phone, 0, 3) . '****' . substr($phone, -4);
    }
    
    /**
     * 脱敏邮箱
     */
    public static function maskEmail($email) {
        $parts = explode('@', $email);
        if (count($parts) !== 2) {
            return $email;
        }
        
        $username = $parts[0];
        $domain = $parts[1];
        
        if (strlen($username) <= 2) {
            return $email;
        }
        
        $masked_username = substr($username, 0, 2) . str_repeat('*', strlen($username) - 2);
        
        return $masked_username . '@' . $domain;
    }
    
    /**
     * 脱敏姓名
     */
    public static function maskName($name) {
        if (mb_strlen($name, 'UTF-8') <= 1) {
            return $name;
        }
        
        return mb_substr($name, 0, 1, 'UTF-8') . str_repeat('*', mb_strlen($name, 'UTF-8') - 1);
    }
}

/**
 * 分页工具类
 */
class ApiPagination {
    /**
     * 生成分页数据
     */
    public static function generate($total, $page = 1, $limit = 20) {
        $page = max(1, intval($page));
        $limit = max(1, min(100, intval($limit)));
        
        $pages = ceil($total / $limit);
        $offset = ($page - 1) * $limit;
        
        return [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => $pages,
            'offset' => $offset,
            'has_prev' => $page > 1,
            'has_next' => $page < $pages,
            'prev_page' => $page > 1 ? $page - 1 : null,
            'next_page' => $page < $pages ? $page + 1 : null
        ];
    }
    
    /**
     * 生成分页SQL
     */
    public static function sql($page = 1, $limit = 20) {
        $pagination = self::generate(0, $page, $limit);
        return "LIMIT {$pagination['limit']} OFFSET {$pagination['offset']}";
    }
}

/**
 * 加密工具类
 */
class ApiCrypto {
    private static $key = null;
    
    /**
     * 设置加密密钥
     */
    public static function setKey($key) {
        self::$key = $key;
    }
    
    /**
     * 加密数据
     */
    public static function encrypt($data) {
        if (self::$key === null) {
            throw new Exception('Encryption key not set');
        }
        
        $iv = random_bytes(openssl_cipher_iv_length('AES-256-CBC'));
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', self::$key, 0, $iv);
        
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * 解密数据
     */
    public static function decrypt($encrypted_data) {
        if (self::$key === null) {
            throw new Exception('Encryption key not set');
        }
        
        $data = base64_decode($encrypted_data);
        $iv_length = openssl_cipher_iv_length('AES-256-CBC');
        $iv = substr($data, 0, $iv_length);
        $encrypted = substr($data, $iv_length);
        
        return openssl_decrypt($encrypted, 'AES-256-CBC', self::$key, 0, $iv);
    }
    
    /**
     * 生成安全哈希
     */
    public static function hash($data) {
        return password_hash($data, PASSWORD_ARGON2ID);
    }
    
    /**
     * 验证哈希
     */
    public static function verifyHash($data, $hash) {
        return password_verify($data, $hash);
    }
    
    /**
     * 生成随机Token
     */
    public static function generateToken($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
}