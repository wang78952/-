<?php

require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Logger.php';
require_once __DIR__ . '/../includes/PluginManager.php';
require_once __DIR__ . '/middleware.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // 初始化数据库和中间件
    $database = new Database();
    $logger = new Logger();
    $middleware = new ApiMiddleware($database);
    
    // 处理CORS
    $middleware->cors();
    
    // 验证管理员权限
    $user = $middleware->auth();
    $middleware->permission('admin');
    
    // 获取请求方法和路径
    $method = $_SERVER['REQUEST_METHOD'];
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $pathParts = explode('/', trim($path, '/'));
    
    // 获取插件管理器实例
    $pluginManager = PluginManager::getInstance($database, $logger);
    
    // 路由分发
    switch ($method) {
        case 'GET':
            handleGetRequest($pluginManager, $pathParts);
            break;
        case 'POST':
            handlePostRequest($pluginManager, $pathParts);
            break;
        case 'PUT':
            handlePutRequest($pluginManager, $pathParts);
            break;
        case 'DELETE':
            handleDeleteRequest($pluginManager, $pathParts);
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => '不支持的请求方法']);
            break;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => '服务器错误',
        'message' => $e->getMessage()
    ]);
}

/**
 * 处理GET请求
 */
function handleGetRequest($pluginManager, $pathParts) {
    $action = $pathParts[3] ?? 'list';
    
    switch ($action) {
        case 'list':
            // 获取插件列表
            $plugins = $pluginManager->getRegisteredPlugins();
            $loadedPlugins = $pluginManager->getLoadedPlugins();
            
            $pluginList = [];
            foreach ($plugins as $name => $info) {
                $pluginList[] = [
                    'name' => $name,
                    'status' => $info['status'],
                    'version' => $loadedPlugins[$name]->getInfo()['version'] ?? 'unknown',
                    'description' => $loadedPlugins[$name]->getInfo()['description'] ?? '',
                    'loaded' => isset($loadedPlugins[$name]),
                    'enabled' => $pluginManager->isPluginEnabled($name),
                    'registered_at' => $info['registered_at'],
                    'loaded_at' => $info['loaded_at'] ?? null,
                    'enabled_at' => $info['enabled_at'] ?? null
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $pluginList,
                'total' => count($pluginList)
            ]);
            break;
            
        case 'scan':
            // 扫描插件目录
            $discoveredPlugins = $pluginManager->scanPlugins();
            
            echo json_encode([
                'success' => true,
                'data' => $discoveredPlugins,
                'total' => count($discoveredPlugins)
            ]);
            break;
            
        case 'info':
            // 获取插件详细信息
            $pluginName = $pathParts[4] ?? '';
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            $pluginInfo = $pluginManager->getPluginInfo($pluginName);
            if (!$pluginInfo) {
                http_response_code(404);
                echo json_encode(['error' => '插件不存在']);
                return;
            }
            
            $plugin = $pluginManager->isPluginLoaded($pluginName) ? 
                     $pluginManager->getLoadedPlugins()[$pluginName] : null;
            
            $info = [
                'name' => $pluginName,
                'status' => $pluginInfo['status'],
                'loaded' => $pluginManager->isPluginLoaded($pluginName),
                'enabled' => $pluginManager->isPluginEnabled($pluginName),
                'config' => $pluginInfo['config'],
                'registered_at' => $pluginInfo['registered_at'],
                'loaded_at' => $pluginInfo['loaded_at'] ?? null,
                'enabled_at' => $pluginInfo['enabled_at'] ?? null
            ];
            
            if ($plugin) {
                $pluginInfo = $plugin->getInfo();
                $info['version'] = $pluginInfo['version'];
                $info['description'] = $pluginInfo['description'];
                $info['hooks'] = $plugin->getHooks();
            }
            
            // 读取插件清单文件
            $manifestFile = __DIR__ . "/../plugins/" . $pluginName . "/plugin.json";
            if (file_exists($manifestFile)) {
                $manifest = json_decode(file_get_contents($manifestFile), true);
                $info['manifest'] = $manifest;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $info
            ]);
            break;
            
        case 'config':
            // 获取插件配置
            $pluginName = $pathParts[4] ?? '';
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            $config = $pluginManager->getPluginConfig($pluginName);
            
            echo json_encode([
                'success' => true,
                'data' => $config
            ]);
            break;
            
        case 'hooks':
            // 获取所有钩子
            $hooks = [];
            
            // 获取系统钩子
            $systemHooks = [
                'payment.process' => '支付处理',
                'payment.callback' => '支付回调',
                'payment.success' => '支付成功',
                'payment.failed' => '支付失败',
                'order.created' => '订单创建',
                'order.updated' => '订单更新',
                'order.completed' => '订单完成',
                'user.registered' => '用户注册',
                'user.login' => '用户登录',
                'user.logout' => '用户登出',
                'card.generated' => '卡密生成',
                'card.sold' => '卡密售出',
                'system.init' => '系统初始化',
                'system.shutdown' => '系统关闭'
            ];
            
            foreach ($systemHooks as $hook => $description) {
                $hooks[$hook] = [
                    'name' => $hook,
                    'description' => $description,
                    'callbacks' => []
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $hooks
            ]);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($pluginManager, $pathParts) {
    $action = $pathParts[3] ?? '';
    
    switch ($action) {
        case 'install':
            // 安装插件
            $input = json_decode(file_get_contents('php://input'), true);
            $pluginPath = $input['plugin_path'] ?? '';
            
            if (empty($pluginPath)) {
                http_response_code(400);
                echo json_encode(['error' => '插件路径不能为空']);
                return;
            }
            
            try {
                $pluginManager->installPlugin($pluginPath);
                
                echo json_encode([
                    'success' => true,
                    'message' => '插件安装成功'
                ]);
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode([
                    'error' => '插件安装失败',
                    'message' => $e->getMessage()
                ]);
            }
            break;
            
        case 'enable':
            // 启用插件
            $input = json_decode(file_get_contents('php://input'), true);
            $pluginName = $input['plugin_name'] ?? '';
            
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            try {
                $pluginManager->enablePlugin($pluginName);
                
                echo json_encode([
                    'success' => true,
                    'message' => '插件启用成功'
                ]);
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode([
                    'error' => '插件启用失败',
                    'message' => $e->getMessage()
                ]);
            }
            break;
            
        case 'disable':
            // 禁用插件
            $input = json_decode(file_get_contents('php://input'), true);
            $pluginName = $input['plugin_name'] ?? '';
            
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            try {
                $pluginManager->disablePlugin($pluginName);
                
                echo json_encode([
                    'success' => true,
                    'message' => '插件禁用成功'
                ]);
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode([
                    'error' => '插件禁用失败',
                    'message' => $e->getMessage()
                ]);
            }
            break;
            
        case 'config':
            // 更新插件配置
            $input = json_decode(file_get_contents('php://input'), true);
            $pluginName = $input['plugin_name'] ?? '';
            $config = $input['config'] ?? [];
            
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            try {
                $pluginManager->updatePluginConfig($pluginName, $config);
                
                echo json_encode([
                    'success' => true,
                    'message' => '插件配置更新成功'
                ]);
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode([
                    'error' => '插件配置更新失败',
                    'message' => $e->getMessage()
                ]);
            }
            break;
            
        case 'discover':
            // 自动发现插件
            $discovered = $pluginManager->autoDiscoverPlugins();
            $count = count($discovered);
            
            echo json_encode([
                'success' => true,
                'message' => "发现了 {$count} 个插件",
                'count' => $count,
                'plugins' => $discovered
            ]);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($pluginManager, $pathParts) {
    $action = $pathParts[3] ?? '';
    
    switch ($action) {
        case 'config':
            // 更新插件配置
            $pluginName = $pathParts[4] ?? '';
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            $config = $input['config'] ?? [];
            
            try {
                $pluginManager->updatePluginConfig($pluginName, $config);
                
                echo json_encode([
                    'success' => true,
                    'message' => '插件配置更新成功'
                ]);
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode([
                    'error' => '插件配置更新失败',
                    'message' => $e->getMessage()
                ]);
            }
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($pluginManager, $pathParts) {
    $action = $pathParts[3] ?? '';
    
    switch ($action) {
        case 'uninstall':
            // 卸载插件
            $pluginName = $pathParts[4] ?? '';
            if (empty($pluginName)) {
                http_response_code(400);
                echo json_encode(['error' => '插件名称不能为空']);
                return;
            }
            
            try {
                $pluginManager->uninstallPlugin($pluginName);
                
                echo json_encode([
                    'success' => true,
                    'message' => '插件卸载成功'
                ]);
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode([
                    'error' => '插件卸载失败',
                    'message' => $e->getMessage()
                ]);
            }
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '未知的操作']);
            break;
    }
}
?>