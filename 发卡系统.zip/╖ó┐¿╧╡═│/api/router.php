/**
 * API认证中间件
 * @param array $data 请求数据
 * @param string $method 请求方法
 * @param string $path 请求路径
 * @param array $context 请求上下文
 * @return array|false 处理后的数据或false（阻止请求）
 */
function apiAuthMiddleware($data, $method, $path, $context = array()) {    try {        // 获取日志管理器        $logger = new LogManager('auth');        $securityUtils = new SecurityUtils();        $requestId = isset($context['request_id']) ? $context['request_id'] : '';        $clientIp = isset($context['client_ip']) ? $context['client_ip'] : '';        
        // 应用内容安全策略头        $securityUtils->applyContentSecurityPolicy();        
        // 生成请求ID        if (empty($requestId)) {            $requestId = $securityUtils->generateSecureToken(16);            $context['request_id'] = $requestId;        }        
        // 获取设备指纹        $deviceFingerprint = isset($_SERVER['HTTP_X_DEVICE_FINGERPRINT']) ? $_SERVER['HTTP_X_DEVICE_FINGERPRINT'] : '';        
        // 获取Authorization头        $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';        if (empty($authHeader)) {            $logger->warning('Missing authorization header', [                'path' => $path,                'method' => $method,                'ip' => $clientIp,                'request_id' => $requestId,                'device_fingerprint' => $deviceFingerprint ? 'exists' : 'missing'            ]);            ApiRouter::errorResponse('缺少认证信息', 401, null, 'MISSING_AUTH_HEADER');            return false;        }        
        // 清理认证头，防止注入        $authHeader = $securityUtils->sanitizeInput($authHeader);        
        // 解析Bearer Token        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {            $token = trim($matches[1]);            
            // 验证Token格式            if (!$securityUtils->validateTokenFormat($token)) {                $logger->warning('Invalid token format', [                    'path' => $path,                    'ip' => $clientIp,                    'request_id' => $requestId                ]);                ApiRouter::errorResponse('无效的认证令牌格式', 401, null, 'INVALID_TOKEN_FORMAT');                return false;            }            
            // 验证Token            try {                require_once __DIR__ . '/../includes/AuthManager.php';                require_once __DIR__ . '/../includes/PermissionManager.php';                $authManager = new AuthManager();                $permissionManager = new PermissionManager();                
                // 检查令牌是否在黑名单中                if ($authManager->isTokenBlacklisted($token)) {                    $logger->warning('Blacklisted token used', [                        'path' => $path,                        'ip' => $clientIp,                        'request_id' => $requestId                    ]);                    ApiRouter::errorResponse('认证令牌已被撤销', 401, null, 'TOKEN_REVOKED');                    return false;                }                
                // 验证令牌                if (!$authManager->validateToken($token)) {                    $logger->warning('Token validation failed', [                        'path' => $path,                        'ip' => $clientIp,                        'request_id' => $requestId                    ]);                    ApiRouter::errorResponse('认证失败', 401, null, 'AUTH_FAILED');                    return false;                }                
                // 将用户信息添加到请求数据中                $user = $authManager->getUserByApiToken($token);                if ($user) {                    // 检查用户状态                    if ($user['status'] !== 'active') {                        $logger->warning('Inactive user login attempt', [                            'user_id' => $user['id'],                            'user_status' => $user['status'],                            'path' => $path,                            'ip' => $clientIp                        ]);                        ApiRouter::errorResponse('用户账户已被禁用', 403, null, 'USER_DISABLED');                        return false;                    }                    
                    // 检查IP地址异常                    $ipInfo = $securityUtils->validateIP($clientIp);                    if (!$ipInfo['is_valid']) {                        $logger->warning('Invalid IP address', [                            'user_id' => $user['id'],                            'invalid_ip' => $clientIp,                            'path' => $path                        ]);                        ApiRouter::errorResponse('IP地址验证失败', 403, null, 'INVALID_IP_ADDRESS');                        return false;                    }                    
                    // 检查登录地点异常                    try {                        if ($authManager->checkLoginLocationSafety($user['id'], $clientIp)) {                            $logger->info('Login location verified', [                                'user_id' => $user['id'],                                'location' => $ipInfo['location'] ?? 'unknown',                                'ip' => $clientIp                            ]);                        } else {                            $logger->warning('Unusual login location detected', [                                'user_id' => $user['id'],                                'location' => $ipInfo['location'] ?? 'unknown',                                'ip' => $clientIp                            ]);                            
                            // 对于异常登录，检查是否有二次验证                            $loginAlertSent = false;                            if (!isset($user['last_login_ip']) || $user['last_login_ip'] !== $clientIp) {                                // 异步发送安全通知                                $loginAlertSent = true;                            }                            
                            // 如果是敏感操作路径，要求二次验证                            $sensitivePaths = [                                '/api/admin/',                                '/api/users/',                                '/api/cards/',                                '/api/transactions/'                            ];                            
                            foreach ($sensitivePaths as $sensitivePath) {                                if (strpos($path, $sensitivePath) === 0) {                                    // 检查是否有二次验证令牌                                    $mfaToken = isset($_SERVER['HTTP_X_MFA_TOKEN']) ? $_SERVER['HTTP_X_MFA_TOKEN'] : '';                                    if (empty($mfaToken)) {                                        $logger->warning('MFA required for unusual location', [                                            'user_id' => $user['id'],                                            'path' => $path,                                            'ip' => $clientIp                                        ]);                                        ApiRouter::errorResponse('检测到异常登录位置，请进行二次验证', 403, null, 'MFA_REQUIRED');                                        return false;                                    }                                }                            }                        }                    } catch (Exception $e) {                        $logger->error('Location verification error', [                            'error' => $e->getMessage(),                            'user_id' => $user['id'],                            'ip' => $clientIp                        ]);                    }                    
                    // 获取用户权限                    $userPermissions = $permissionManager->getUserPermissions($user['id']);                    $user['permissions'] = $userPermissions;                    
                    // 检查是否需要刷新令牌（有效期低于1小时）                    try {                        if (isset($user['expires_at'])) {                            $expiresIn = strtotime($user['expires_at']) - time();                            if ($expiresIn > 0 && $expiresIn < 3600) {                                // 自动刷新令牌                                $newToken = $authManager->generateApiToken($user['id']);                                header('X-New-Token: ' . $newToken);                                $logger->info('Token automatically refreshed', [                                    'user_id' => $user['id'],                                    'old_token' => substr($token, 0, 10) . '...',                                    'new_token' => substr($newToken, 0, 10) . '...'                                ]);                            }                        }                    } catch (Exception $e) {                        $logger->error('Token refresh error', [                            'error' => $e->getMessage(),                            'user_id' => $user['id']                        ]);                    }                    
                    // 检查权限是否允许访问该路径                    $requiredPermission = null;                    $adminPaths = ['/api/admin', '/api/users'];                    $managerPaths = ['/api/cards', '/api/transactions'];                    $userPaths = ['/api/orders', '/api/profile'];                    
                    foreach ($adminPaths as $adminPath) {                        if (strpos($path, $adminPath) === 0) {                            $requiredPermission = 'admin_access';                            break;                        }                    }                    
                    if ($requiredPermission === null) {                        foreach ($managerPaths as $managerPath) {                            if (strpos($path, $managerPath) === 0) {                                $requiredPermission = 'manager_access';                                break;                            }                        }                    }                    
                    if ($requiredPermission === null) {                        foreach ($userPaths as $userPath) {                            if (strpos($path, $userPath) === 0) {                                $requiredPermission = 'user_access';                                break;                            }                        }                    }                    
                    // 基于HTTP方法设置更细粒度的权限                    if ($requiredPermission) {                        $methodPermission = $requiredPermission . '_' . strtolower($method);                        if (!in_array($user['role'], ['admin', 'superadmin']) &&                            !in_array($methodPermission, $userPermissions) &&                            !in_array($requiredPermission, $userPermissions)) {                            $logger->warning('Permission denied', [                                'user_id' => $user['id'],                                'role' => $user['role'],                                'required_permission' => $methodPermission,                                'path' => $path,                                'method' => $method                            ]);                            ApiRouter::errorResponse('权限不足，无法访问此资源', 403, null, 'PERMISSION_DENIED');                            return false;                        }                    }                    
                    // 记录成功认证和详细访问日志                    $logger->info('Authentication successful', [                        'user_id' => $user['id'],                        'username' => $user['username'] ?? '',                        'role' => $user['role'] ?? '',                        'path' => $path,                        'method' => $method,                        'ip' => $clientIp,                        'request_id' => $requestId,                        'ip_type' => $ipInfo['type'],                        'device_fingerprint' => $deviceFingerprint ? 'exists' : 'missing'                    ]);                    
                    // 记录API访问审计日志                    $securityUtils->logSecurity('INFO', 'API访问审计', [                        'user_id' => $user['id'],                        'username' => $user['username'] ?? '',                        'path' => $path,                        'method' => $method,                        'ip' => $clientIp,                        'request_id' => $requestId,                        'permissions' => $user['role']                        // 不记录设备指纹，保护隐私                    ]);                    
                    // 更新用户会话信息                    $authManager->updateUserSession($user['id'], $clientIp, $deviceFingerprint, $requestId);                    
                    $data['current_user'] = $user;                    $data['auth_token'] = $token;                    $data['user_permissions'] = $userPermissions;                    $data['request_context'] = $context;                }                
            } catch (Exception $e) {                $logger->error('Authentication error', [                    'error' => $e->getMessage(),                    'path' => $path,                    'ip' => $clientIp,                    'request_id' => $requestId                ]);                ApiRouter::errorResponse('认证验证失败', 401, null, 'AUTH_VALIDATION_ERROR');                return false;            }        } else {            $logger->warning('Invalid authorization header format', [                'path' => $path,                'ip' => $clientIp,                'request_id' => $requestId,                'auth_header' => substr($authHeader, 0, 20) . '...' // 只记录前20个字符            ]);            ApiRouter::errorResponse('认证格式错误', 401, null, 'INVALID_AUTH_FORMAT');            return false;        }        
        return $data;    } catch (Exception $e) {        // 记录异常        $logger = new LogManager('auth');        $logger->error('Auth middleware exception', [            'error' => $e->getMessage(),            'stack_trace' => $e->getTraceAsString(),            'request_path' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',            'request_method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : ''        ]);        ApiRouter::errorResponse('认证中间件错误', 500, null, 'AUTH_MIDDLEWARE_ERROR');        return false;    }
}

/**
 * API高级认证中间件（支持多因素认证）
 * @param array $data 请求数据
 * @param string $method 请求方法
 * @param string $path 请求路径
 * @param array $context 请求上下文
 * @return array|false 处理后的数据或false（阻止请求）
 */
function apiAdvancedAuthMiddleware($data, $method, $path, $context = array()) {
    try {
        $logger = new LogManager('auth');
        $clientIp = isset($context['client_ip']) ? $context['client_ip'] : '';
        
        // 首先进行基本认证
        $result = apiAuthMiddleware($data, $method, $path, $context);
        
        if ($result === false) {
            return false;
        }
        
        $user = $result['current_user'] ?? null;
        
        if ($user && isset($user['mfa_enabled']) && $user['mfa_enabled']) {
            // 检查是否有MFA验证
            $mfaToken = isset($_SERVER['HTTP_X_MFA_TOKEN']) ? $_SERVER['HTTP_X_MFA_TOKEN'] : '';
            
            if (empty($mfaToken)) {
                $logger->warning('MFA required but not provided', [
                    'user_id' => $user['id'],
                    'path' => $path,
                    'ip' => $clientIp
                ]);
                ApiRouter::errorResponse('需要多因素认证', 403, null, 'MFA_REQUIRED');
                return false;
            }
            
            // 验证MFA令牌
            require_once __DIR__ . '/../includes/AuthManager.php';
            $authManager = new AuthManager();
            
            if (!$authManager->verifyMfaToken($user['id'], $mfaToken)) {
                $logger->warning('Invalid MFA token', [
                    'user_id' => $user['id'],
                    'path' => $path,
                    'ip' => $clientIp
                ]);
                ApiRouter::errorResponse('多因素认证失败', 403, null, 'MFA_FAILED');
                return false;
            }
            
            $logger->info('MFA verification successful', [
                'user_id' => $user['id'],
                'path' => $path,
                'ip' => $clientIp
            ]);
        }
        
        return $result;
    } catch (Exception $e) {
        error_log('Advanced auth middleware error: ' . $e->getMessage());
        ApiRouter::errorResponse('高级认证失败', 500, null, 'ADVANCED_AUTH_ERROR');
        return false;
    }
}

/**
 * API限流中间件 - 增强版
 * 支持多维度限流、渐进式惩罚、黑白名单、多级别限流控制
 * @param array $data 请求数据
 * @param string $method 请求方法
 * @param string $path 请求路径
 * @param array $context 请求上下文
 * @return array|false 处理后的数据或false（阻止请求）
 */
function apiRateLimitMiddleware($data, $method, $path, $context = array()) {
    try {
        // 加载限流配置
        $rateLimitConfig = require_once __DIR__ . '/config/rate_limits.php';
        $logger = new LogManager('rate_limit');
        $cacheManager = new CacheManager();
        $clientIp = isset($context['client_ip']) ? $context['client_ip'] : $_SERVER['REMOTE_ADDR'];
        $requestId = isset($context['request_id']) ? $context['request_id'] : '';
        $currentTime = time();
        $userId = isset($data['current_user']['id']) ? $data['current_user']['id'] : null;
        
        // 记录请求开始日志
        $logger->debug('Rate limit check started', [
            'ip' => $clientIp,
            'path' => $path,
            'method' => $method,
            'user_id' => $userId,
            'request_id' => $requestId
        ]);
        
        // 1. 检查IP黑名单
        if ($rateLimitConfig['blacklist']['enabled'] && in_array($clientIp, $rateLimitConfig['blacklist']['ips'])) {
            $blockType = $rateLimitConfig['blacklist']['permanent_block'] ? '永久' : '临时';
            $logger->warning('IP address blocked by blacklist', [
                'ip' => $clientIp,
                'path' => $path,
                'block_type' => $blockType,
                'request_id' => $requestId
            ]);
            
            ApiRouter::errorResponse(
                '您的IP地址已被' . $blockType . '阻止',
                403,
                null,
                'IP_ADDRESS_BLOCKED'
            );
            return false;
        }
        
        // 2. 检查IP白名单
        if ($rateLimitConfig['whitelist']['enabled'] && in_array($clientIp, $rateLimitConfig['whitelist']['ips'])) {
            if ($rateLimitConfig['whitelist']['bypass_all_limits']) {
                $logger->debug('IP address bypassed all limits', [
                    'ip' => $clientIp,
                    'path' => $path,
                    'request_id' => $requestId
                ]);
                // 添加白名单标记到响应头
                header('X-RateLimit-Whitelist: true');
                return $data;
            }
        }
        
        // 3. 确定限流配置类型
        $configType = determineRateLimitConfigType($path, $method, $userId, $data);
        $config = $rateLimitConfig[$configType] ?? $rateLimitConfig['default'];
        
        // 4. 检查用户是否有违规记录
        $violationCount = checkUserViolations($clientIp, $userId, $cacheManager, $logger);
        
        // 5. 如果有违规记录，应用渐进式惩罚
        if ($violationCount > 0 && $rateLimitConfig['violation_handling']['progressive_punishment']) {
            $blockResult = applyProgressivePunishment($violationCount, $clientIp, $userId, $rateLimitConfig, $cacheManager, $logger);
            if ($blockResult['blocked']) {
                $logger->warning('Request blocked due to progressive punishment', [
                    'ip' => $clientIp,
                    'user_id' => $userId,
                    'violation_count' => $violationCount,
                    'block_duration' => $blockResult['duration'],
                    'request_id' => $requestId
                ]);
                
                ApiRouter::errorResponse(
                    '您的账户因频繁违规已被临时限制访问',
                    429,
                    null,
                    'TEMPORARILY_BLOCKED',
                    ['Retry-After' => $blockResult['duration']]
                );
                return false;
            }
        }
        
        // 6. 执行多级限流检查
        $timeWindows = ['minute', 'hour', 'day'];
        $limitExceeded = false;
        $retryAfter = 0;
        $limitType = '';
        
        foreach ($timeWindows as $window) {
            $windowKey = 'requests_per_' . $window;
            if (!isset($config[$windowKey])) continue;
            
            $limit = $config[$windowKey];
            $windowSeconds = $window === 'minute' ? 60 : ($window === 'hour' ? 3600 : 86400);
            
            // 构建多维度缓存键
            $cacheKey = buildRateLimitCacheKey($clientIp, $userId, $path, $window);
            
            try {
                // 获取请求记录
                $requests = $cacheManager->get($cacheKey) ?: [];
                
                // 清理过期请求
                $requests = array_filter($requests, function($timestamp) use ($currentTime, $windowSeconds) {
                    return ($currentTime - $timestamp) < $windowSeconds;
                });
                
                // 检查是否超过限制
                if (count($requests) >= $limit) {
                    $limitExceeded = true;
                    $limitType = $window;
                    
                    // 计算重试时间
                    $oldestRequest = min($requests);
                    $retryAfter = $windowSeconds - ($currentTime - $oldestRequest);
                    
                    // 增加违规记录
                    incrementViolationCount($clientIp, $userId, $cacheManager, $logger);
                    
                    break;
                }
                
                // 记录当前请求
                $requests[] = $currentTime;
                
                // 保存到缓存
                $cacheManager->set($cacheKey, $requests, $windowSeconds);
                
                // 计算剩余请求数
                $remaining = $limit - count($requests);
                
                // 记录限流信息到响应头
                header('X-RateLimit-Limit-' . ucfirst($window) . ': ' . $limit);
                header('X-RateLimit-Remaining-' . ucfirst($window) . ': ' . $remaining);
                header('X-RateLimit-Reset-' . ucfirst($window) . ': ' . ($currentTime + $windowSeconds));
                
            } catch (CacheException $e) {
                // 缓存异常处理
                $logger->error('Cache error in rate limiter', [
                    'error' => $e->getMessage(),
                    'ip' => $clientIp,
                    'path' => $path,
                    'window' => $window
                ]);
                // 降级到文件存储或跳过检查
                continue;
            }
        }
        
        // 7. 检查突发流量限制
        if (!$limitExceeded && isset($config['burst_limit'])) {
            $burstKey = buildRateLimitCacheKey($clientIp, $userId, $path, 'burst');
            $burstWindow = 5; // 5秒内的突发请求
            
            try {
                $burstRequests = $cacheManager->get($burstKey) ?: [];
                $burstRequests = array_filter($burstRequests, function($timestamp) use ($currentTime, $burstWindow) {
                    return ($currentTime - $timestamp) < $burstWindow;
                });
                
                if (count($burstRequests) >= $config['burst_limit']) {
                    $limitExceeded = true;
                    $limitType = 'burst';
                    $retryAfter = $burstWindow;
                    incrementViolationCount($clientIp, $userId, $cacheManager, $logger);
                } else {
                    $burstRequests[] = $currentTime;
                    $cacheManager->set($burstKey, $burstRequests, $burstWindow);
                }
            } catch (CacheException $e) {
                $logger->error('Burst limit cache error', ['error' => $e->getMessage()]);
            }
        }
        
        // 8. 如果超过限制，返回错误
        if ($limitExceeded) {
            $errorMessage = $rateLimitConfig['response']['error_messages']['RATE_LIMIT_EXCEEDED'] ?? '请求过于频繁，请稍后再试';
            
            $logger->warning('Rate limit exceeded', [
                'ip' => $clientIp,
                'path' => $path,
                'limit_type' => $limitType,
                'retry_after' => $retryAfter,
                'user_id' => $userId,
                'request_id' => $requestId
            ]);
            
            // 构建响应头
            $headers = ['Retry-After' => $retryAfter];
            if ($rateLimitConfig['response']['include_headers']) {
                foreach ($rateLimitConfig['response']['headers'] as $header => $value) {
                    if ($value === 'retry_after') {
                        $headers[$header] = $retryAfter;
                    }
                }
            }
            
            ApiRouter::errorResponse(
                $errorMessage,
                429,
                null,
                'RATE_LIMIT_EXCEEDED',
                $headers
            );
            return false;
        }
        
        // 9. 敏感操作特殊处理
        if (isSensitiveOperation($path) && $rateLimitConfig['sensitive']['log_all_requests']) {
            $logger->info('Sensitive operation access', [
                'ip' => $clientIp,
                'path' => $path,
                'method' => $method,
                'user_id' => $userId,
                'request_id' => $requestId
            ]);
        }
        
        // 10. 检查监控阈值
        checkMonitoringThresholds($clientIp, $path, $rateLimitConfig, $cacheManager, $logger);
        
        $logger->debug('Rate limit check passed', [
            'ip' => $clientIp,
            'path' => $path,
            'user_id' => $userId,
            'config_type' => $configType,
            'request_id' => $requestId
        ]);
        
        return $data;
    } catch (Exception $e) {
        // 记录异常但不阻止请求，确保服务可用性
        $logger->error('Rate limit middleware error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return $data;
    }
}

/**
 * 确定限流配置类型
 * @param string $path 请求路径
 * @param string $method 请求方法
 * @param int|null $userId 用户ID
 * @param array $data 请求数据
 * @return string 配置类型
 */
function determineRateLimitConfigType($path, $method, $userId = null, $data = []) {
    // 根据路径特征确定配置类型
    if (strpos($path, '/auth/login') !== false || strpos($path, '/login') !== false) {
        return 'login';
    } elseif (strpos($path, '/auth/change-password') !== false || 
              strpos($path, '/reset-password') !== false ||
              strpos($path, '/users/') === 0 ||
              strpos($path, '/cards/delete') !== false) {
        return 'sensitive';
    } elseif (strpos($path, '/import') !== false || strpos($path, '/upload') !== false) {
        return 'upload';
    } elseif (strpos($path, '/admin') !== false || 
              (isset($data['current_user']['role']) && 
               in_array($data['current_user']['role'], ['admin', 'superadmin']))) {
        return 'admin';
    } elseif (strpos($path, '/stats') !== false || strpos($path, '/query') !== false) {
        return 'query';
    }
    
    return 'default';
}

/**
 * 判断是否为敏感操作
 * @param string $path 请求路径
 * @return bool 是否为敏感操作
 */
function isSensitiveOperation($path) {
    $sensitivePatterns = [
        '/auth/change-password',
        '/reset-password',
        '/users/',
        '/cards/delete',
        '/cards/batch',
        '/cards/import',
        '/cards/export',
        '/maintenance/',
        '/admin/'
    ];
    
    foreach ($sensitivePatterns as $pattern) {
        if (strpos($path, $pattern) !== false) {
            return true;
        }
    }
    
    return false;
}

/**
 * 构建限流缓存键
 * @param string $ip IP地址
 * @param int|null $userId 用户ID
 * @param string $path 请求路径
 * @param string $window 时间窗口
 * @return string 缓存键
 */
function buildRateLimitCacheKey($ip, $userId, $path, $window) {
    $baseKey = 'rate_limit:' . $window . ':' . md5($ip . ':' . $path);
    if ($userId) {
        $baseKey .= ':user_' . $userId;
    }
    return $baseKey;
}

/**
 * 增加违规记录
 * @param string $ip IP地址
 * @param int|null $userId 用户ID
 * @param CacheManager $cacheManager 缓存管理器
 * @param LogManager $logger 日志管理器
 */
function incrementViolationCount($ip, $userId, $cacheManager, $logger) {
    $violationKey = 'rate_limit:violations:' . md5($ip . ':' . ($userId ?: 'guest'));
    $currentCount = $cacheManager->get($violationKey) ?: 0;
    $cacheManager->set($violationKey, $currentCount + 1, 86400); // 24小时
    
    // 记录今日违规次数
    $dailyKey = 'rate_limit:daily_violations:' . md5($ip . ':' . date('Y-m-d'));
    $dailyCount = $cacheManager->get($dailyKey) ?: 0;
    $cacheManager->set($dailyKey, $dailyCount + 1, 86400);
    
    $logger->debug('Rate limit violation incremented', [
        'ip' => $ip,
        'user_id' => $userId,
        'total_violations' => $currentCount + 1,
        'daily_violations' => $dailyCount + 1
    ]);
}

/**
 * 检查违规记录
 * @param string $ip IP地址
 * @param int|null $userId 用户ID
 * @param CacheManager $cacheManager 缓存管理器
 * @param LogManager $logger 日志管理器
 * @return int 违规次数
 */
function checkUserViolations($ip, $userId, $cacheManager, $logger) {
    $violationKey = 'rate_limit:violations:' . md5($ip . ':' . ($userId ?: 'guest'));
    $violations = $cacheManager->get($violationKey) ?: 0;
    
    // 检查今日违规次数
    $dailyKey = 'rate_limit:daily_violations:' . md5($ip . ':' . date('Y-m-d'));
    $dailyViolations = $cacheManager->get($dailyKey) ?: 0;
    
    $logger->debug('User violation check', [
        'ip' => $ip,
        'user_id' => $userId,
        'total_violations' => $violations,
        'daily_violations' => $dailyViolations
    ]);
    
    return $violations;
}

/**
 * 应用渐进式惩罚
 * @param int $violationCount 违规次数
 * @param string $ip IP地址
 * @param int|null $userId 用户ID
 * @param array $config 限流配置
 * @param CacheManager $cacheManager 缓存管理器
 * @param LogManager $logger 日志管理器
 * @return array [blocked => bool, duration => int]
 */
function applyProgressivePunishment($violationCount, $ip, $userId, $config, $cacheManager, $logger) {
    $punishmentLevels = $config['violation_handling']['punishment_levels'];
    $maxViolations = $config['violation_handling']['max_violations_per_day'];
    $autoBlacklistThreshold = $config['violation_handling']['auto_blacklist_threshold'];
    
    // 检查今日违规次数
    $dailyKey = 'rate_limit:daily_violations:' . md5($ip . ':' . date('Y-m-d'));
    $dailyViolations = $cacheManager->get($dailyKey) ?: 0;
    
    // 超过每日最大违规次数
    if ($dailyViolations >= $maxViolations) {
        $blockDuration = 3600; // 1小时
        $blockKey = 'rate_limit:block:' . md5($ip . ':' . ($userId ?: 'guest'));
        
        if (!$cacheManager->get($blockKey)) {
            $cacheManager->set($blockKey, $dailyViolations, $blockDuration);
            $logger->warning('User temporarily blocked due to daily violation limit', [
                'ip' => $ip,
                'user_id' => $userId,
                'daily_violations' => $dailyViolations,
                'block_duration' => $blockDuration
            ]);
        }
        
        return ['blocked' => true, 'duration' => $blockDuration];
    }
    
    // 应用渐进式惩罚
    foreach ($punishmentLevels as $level => $punishment) {
        if ($violationCount >= $level) {
            $blockDuration = $punishment['duration'];
            $blockKey = 'rate_limit:block:' . md5($ip . ':' . ($userId ?: 'guest'));
            
            // 检查是否已经被阻止
            $blockEnd = $cacheManager->get($blockKey);
            if ($blockEnd && $blockEnd > time()) {
                return ['blocked' => true, 'duration' => $blockEnd - time()];
            }
            
            // 设置阻止
            if ($violationCount >= $autoBlacklistThreshold) {
                // 自动加入黑名单监控
                $blacklistKey = 'rate_limit:blacklist_candidate:' . $ip;
                $cacheManager->set($blacklistKey, ['added_at' => time(), 'violations' => $violationCount], 86400 * 7); // 7天
                
                $logger->warning('IP added to blacklist candidates', [
                    'ip' => $ip,
                    'violations' => $violationCount,
                    'auto_blacklist_threshold' => $autoBlacklistThreshold
                ]);
            }
            
            // 设置阻止时间
            $cacheManager->set($blockKey, time() + $blockDuration, $blockDuration);
            
            $logger->warning('Progressive punishment applied', [
                'ip' => $ip,
                'user_id' => $userId,
                'violations' => $violationCount,
                'level' => $level,
                'duration' => $blockDuration
            ]);
            
            return ['blocked' => true, 'duration' => $blockDuration];
        }
    }
    
    return ['blocked' => false, 'duration' => 0];
}

/**
 * 检查监控阈值
 * @param string $ip IP地址
 * @param string $path 请求路径
 * @param array $config 限流配置
 * @param CacheManager $cacheManager 缓存管理器
 * @param LogManager $logger 日志管理器
 */
function checkMonitoringThresholds($ip, $path, $config, $cacheManager, $logger) {
    if (!$config['monitoring']['enabled']) {
        return;
    }
    
    $thresholds = $config['monitoring']['alert_threshold'];
    $currentTime = time();
    
    // 检查每分钟违规次数
    $minuteKey = 'rate_limit:monitor:violations_per_minute:' . date('Y-m-d-H-i');
    $minuteViolations = $cacheManager->get($minuteKey) ?: 0;
    
    if ($minuteViolations >= $thresholds['violations_per_minute']) {
        sendAlert('高频率违规告警', [
            'type' => 'violations_per_minute',
            'threshold' => $thresholds['violations_per_minute'],
            'current' => $minuteViolations,
            'time' => date('Y-m-d H:i:s')
        ], $config, $logger);
    }
    
    // 检查总请求量
    $totalRequestsKey = 'rate_limit:monitor:total_requests_per_minute:' . date('Y-m-d-H-i');
    $totalRequests = $cacheManager->get($totalRequestsKey) ?: 0;
    $totalRequests++;
    $cacheManager->set($totalRequestsKey, $totalRequests, 60);
    
    if ($totalRequests >= $thresholds['total_requests_per_minute']) {
        sendAlert('请求量过高告警', [
            'type' => 'total_requests_per_minute',
            'threshold' => $thresholds['total_requests_per_minute'],
            'current' => $totalRequests,
            'time' => date('Y-m-d H:i:s')
        ], $config, $logger);
    }
}

/**
 * 发送告警
 * @param string $message 告警消息
 * @param array $data 告警数据
 * @param array $config 限流配置
 * @param LogManager $logger 日志管理器
 */
function sendAlert($message, $data, $config, $logger) {
    $logger->warning($message, $data);
    
    // 这里可以实现邮件、webhook等告警方式
    // 为简化示例，目前只记录日志
    if (in_array('log', $config['monitoring']['notification_methods'])) {
        $logger->warning('Rate limit alert', [
            'message' => $message,
            'data' => $data,
            'timestamp' => time()
        ]);
    }
}

/**
 * API权限检查中间件
 * @param array $data 请求数据
 * @param string $method 请求方法
 * @param string $path 请求路径
 * @param array $context 请求上下文
 * @return array|false 处理后的数据或false（阻止请求）
 */
function apiPermissionMiddleware($requiredPermission, $data, $method, $path, $context = array()) {
    try {
        $logger = new LogManager('permission');
        $clientIp = isset($context['client_ip']) ? $context['client_ip'] : '';
        $requestId = isset($context['request_id']) ? $context['request_id'] : '';
        
        // 检查用户是否已认证
        if (!isset($data['current_user'])) {
            $logger->warning('Permission check failed: user not authenticated', [
                'path' => $path,
                'permission' => $requiredPermission,
                'ip' => $clientIp
            ]);
            ApiRouter::errorResponse('请先登录', 401, null, 'NOT_AUTHENTICATED');
            return false;
        }
        
        $user = $data['current_user'];
        
        // 检查权限
        require_once __DIR__ . '/../includes/PermissionManager.php';
        $permissionManager = new PermissionManager();
        
        if (!$permissionManager->checkPermission($user, $requiredPermission)) {
            $logger->warning('Permission denied', [
                'user_id' => $user['id'],
                'path' => $path,
                'permission' => $requiredPermission,
                'ip' => $clientIp,
                'request_id' => $requestId
            ]);
            ApiRouter::errorResponse('没有权限执行此操作', 403, null, 'PERMISSION_DENIED');
            return false;
        }
        
        $logger->debug('Permission check passed', [
            'user_id' => $user['id'],
            'path' => $path,
            'permission' => $requiredPermission
        ]);
        
        return $data;
    } catch (Exception $e) {
        error_log('Permission middleware error: ' . $e->getMessage());
        ApiRouter::errorResponse('权限检查失败', 500, null, 'PERMISSION_CHECK_ERROR');
        return false;
    }
}

/**
 * 为特定权限创建中间件
 * @param string $permission 权限名称
 * @return callable 中间件函数
 */
function createPermissionMiddleware($permission) {
    return function($data, $method, $path, $context = array()) use ($permission) {
        return apiPermissionMiddleware($permission, $data, $method, $path, $context);
    };
}

/**
 * API日志中间件
 */
function apiLogMiddleware($data, $method, $path) {
    $logData = array(
        'method' => $method,
        'path' => $path,
        'ip' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
        'timestamp' => date('Y-m-d H:i:s'),
        'user_id' => isset($data['current_user']['id']) ? $data['current_user']['id'] : null
    );
    
    // 记录到日志文件
    $logFile = __DIR__ . '/logs/api_' . date('Y-m-d') . '.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    file_put_contents($logFile, json_encode($logData) . "\n", FILE_APPEND | LOCK_EX);
    
    return $data;
}