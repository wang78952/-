<?php
/**
 * 代理注册API接口
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../includes/Database.php';
require_once '../includes/BaseService.php';
require_once '../includes/AgentManager.php';
require_once '../includes/Logger.php';

// 创建代理管理器实例
$agentManager = new AgentManager();

// 获取请求方法
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'POST':
            // 处理代理注册请求
            handleAgentRegistration($agentManager);
            break;
            
        case 'GET':
            // 处理代理信息查询
            handleAgentQuery($agentManager);
            break;
            
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            echo json_encode(array('success' => false, 'message' => '不支持的请求方法'));
            break;
    }
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('success' => false, 'message' => '服务器错误：' . $e->getMessage()));
}

/**
 * 处理代理注册
 */
function handleAgentRegistration($agentManager) {
    // 获取POST数据
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        // 如果不是JSON，尝试获取表单数据
        $input = $_POST;
    }
    
    // 验证必填字段
    $requiredFields = ['contact_name', 'phone', 'email', 'id_card', 'bank_name', 'bank_account', 'bank_account_name'];
    
    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(array('success' => false, 'message' => "字段 {$field} 不能为空"));
            return;
        }
    }
    
    // 验证邮箱格式
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(array('success' => false, 'message' => '邮箱格式不正确'));
        return;
    }
    
    // 验证手机号格式
    if (!preg_match('/^1[3-9]\d{9}$/', $input['phone'])) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(array('success' => false, 'message' => '手机号格式不正确'));
        return;
    }
    
    // 验证身份证号格式
    if (!preg_match('/^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/', $input['id_card'])) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(array('success' => false, 'message' => '身份证号格式不正确'));
        return;
    }
    
    // 检查是否已有重复申请
    $existingAgent = $agentManager->getAgentByPhone($input['phone']);
    if ($existingAgent['success']) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(array('success' => false, 'message' => '该手机号已提交代理申请'));
        return;
    }
    
    $existingAgent = $agentManager->getAgentByEmail($input['email']);
    if ($existingAgent['success']) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(array('success' => false, 'message' => '该邮箱已提交代理申请'));
        return;
    }
    
    // 准备代理数据
    $agentData = array(
        'contact_name' => trim($input['contact_name']),
        'phone' => trim($input['phone']),
        'email' => trim($input['email']),
        'id_card' => trim($input['id_card']),
        'bank_name' => trim($input['bank_name']),
        'bank_account' => trim($input['bank_account']),
        'bank_account_name' => trim($input['bank_account_name']),
        'referral_code' => !empty($input['referral_code']) ? trim($input['referral_code']) : null,
        'remark' => !empty($input['remark']) ? trim($input['remark']) : '',
        'source' => 'web'
    );
    
    // 提交代理申请
    $result = $agentManager->submitAgentApplication($agentData);
    
    if ($result['success']) {
        header('HTTP/1.1 201 Created');
        echo json_encode(array(
            'success' => true,
            'message' => '代理申请提交成功，请等待审核',
            'data' => array(
                'application_id' => $result['data']['id'],
                'contact_name' => $agentData['contact_name'],
                'phone' => $agentData['phone'],
                'status' => 'pending'
            )
        ));
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(array('success' => false, 'message' => $result['message']));
    }
}

/**
 * 处理代理信息查询
 */
function handleAgentQuery($agentManager) {
    $action = isset($_GET['action']) ? $_GET['action'] : '';
    
    switch ($action) {
        case 'check_phone':
            // 检查手机号是否已注册
            $phone = isset($_GET['phone']) ? $_GET['phone'] : '';
            if (empty($phone)) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(array('success' => false, 'message' => '手机号不能为空'));
                return;
            }
            
            $result = $agentManager->getAgentByPhone($phone);
            echo json_encode(array(
                'success' => true,
                'exists' => $result['success'],
                'message' => $result['success'] ? '该手机号已注册' : '该手机号可用'
            ));
            break;
            
        case 'check_email':
            // 检查邮箱是否已注册
            $email = isset($_GET['email']) ? $_GET['email'] : '';
            if (empty($email)) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(array('success' => false, 'message' => '邮箱不能为空'));
                return;
            }
            
            $result = $agentManager->getAgentByEmail($email);
            echo json_encode(array(
                'success' => true,
                'exists' => $result['success'],
                'message' => $result['success'] ? '该邮箱已注册' : '该邮箱可用'
            ));
            break;
            
        case 'check_id_card':
            // 检查身份证号是否已注册
            $idCard = isset($_GET['id_card']) ? $_GET['id_card'] : '';
            if (empty($idCard)) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(array('success' => false, 'message' => '身份证号不能为空'));
                return;
            }
            
            $result = $agentManager->getAgentByIdCard($idCard);
            echo json_encode(array(
                'success' => true,
                'exists' => $result['success'],
                'message' => $result['success'] ? '该身份证号已注册' : '该身份证号可用'
            ));
            break;
            
        case 'validate_referral':
            // 验证推荐码
            $referralCode = isset($_GET['referral_code']) ? $_GET['referral_code'] : '';
            if (empty($referralCode)) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(array('success' => false, 'message' => '推荐码不能为空'));
                return;
            }
            
            $result = $agentManager->validateReferralCode($referralCode);
            echo json_encode(array(
                'success' => true,
                'valid' => $result['success'],
                'message' => $result['message']
            ));
            break;
            
        case 'get_commission_rates':
            // 获取佣金比例配置
            echo json_encode([
                'success' => true,
                'data' => [
                    'default_commission_rate' => 10, // 默认直接佣金比例
                    'default_sub_commission_rate' => 3, // 默认间接佣金比例
                    'min_withdrawal' => 100, // 最低提现金额
                    'withdrawal_fee_rate' => 0.01 // 提现手续费率
                ]
            ]);
            break;
            
        default:
              header('HTTP/1.1 400 Bad Request');
              echo json_encode(array('success' => false, 'message' => '不支持的操作'));
              break;
    }
}

/**
 * 验证CSRF令牌（如果启用）
 */
function validateCSRFToken($token) {
    // 这里可以实现CSRF验证逻辑
    // 暂时返回true
    return true;
}

/**
 * 记录API访问日志
 */
function logAPICall($endpoint, $method, $data, $result) {
    $logger = Logger::getInstance();
    $logger->info("API访问", [
        'endpoint' => $endpoint,
        'method' => $method,
        'data' => $data,
        'result' => $result,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
}
?>