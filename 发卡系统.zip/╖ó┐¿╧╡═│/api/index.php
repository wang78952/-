<?php
/**
 * 发卡系统API入口文件
 * 实际运营版本 - 处理所有API请求的路由分发
 */

// 防止直接访问核心文件
if (!defined('IN_SYSTEM')) {
    define('IN_SYSTEM', true);
}

// 设置错误报告级别
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__DIR__) . '/logs/api_errors.log');

error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);

// 记录请求开始时间（用于性能监控）
$requestStartTime = microtime(true);
$requestId = uniqid('api_req_', true);

// 获取请求信息
$requestMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$clientIp = getClientIp();

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('X-API-Version: 1.0');
header('X-Request-ID: ' . $requestId);
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-API-Key');
header('Access-Control-Max-Age: 86400');

// 增强CORS设置
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$allowedOrigins = array(
    'https://yourdomain.com',
    'https://admin.yourdomain.com',
    // 添加其他允许的域名
);

// 设置CORS
if (!empty($origin) && in_array($origin, $allowedOrigins)) {
    header('Access-Control-Allow-Origin: ' . $origin);
}

// 处理OPTIONS预检请求
if ($requestMethod === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// 引入配置文件和核心类
require_once dirname(__DIR__) . '/config.php';

// 引入API响应工具类
require_once __DIR__ . '/helpers.php';

// 注册全局异常处理器
ApiResponse::registerGlobalExceptionHandler();

/**
 * 获取HTTP状态码对应的消息
 * @param int $code 状态码
 * @return string 状态消息
 */
function getStatusCodeMessage($code) {
    $statusCodes = array(
        200 => 'OK',
        201 => 'Created',
        204 => 'No Content',
        400 => 'Bad Request',
        401 => 'Unauthorized',
        403 => 'Forbidden',
        404 => 'Not Found',
        405 => 'Method Not Allowed',
        422 => 'Unprocessable Entity',
        429 => 'Too Many Requests',
        500 => 'Internal Server Error',
        503 => 'Service Unavailable'
    );
    
    return isset($statusCodes[$code]) ? $statusCodes[$code] : 'Unknown Status';
}

// 检查配置文件是否存在
if (!file_exists(dirname(__DIR__) . '/config.php')) {
    http_response_code(500);
    echo json_encode(array(
        'success' => false,
        'error' => 'Internal Server Error',
        'message' => '配置文件不存在',
        'request_id' => $requestId
    ));
    exit;
}

// 引入配置文件和核心类
require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/middleware.php';
require_once __DIR__ . '/router.php';
// 引入维护模式中间件
require_once __DIR__ . '/middleware/MaintenanceModeApiMiddleware.php';
// 引入地理位置验证中间件
require_once __DIR__ . '/middleware/GeoLocationMiddleware.php';
// 引入安全异常检测中间件
require_once __DIR__ . '/middleware/SecurityAnomalyDetectionMiddleware.php';
require_once __DIR__ . '/middleware/DataMaskingMiddleware.php';
require_once __DIR__ . '/controllers/MaintenanceController.php';
// 引入其他控制器
require_once __DIR__ . '/controllers/UserController.php';
require_once __DIR__ . '/controllers/CardController.php';
require_once __DIR__ . '/controllers/VerificationController.php';
require_once __DIR__ . '/controllers/StatsController.php';
// 引入分析控制器
require_once __DIR__ . '/controllers/AnalyticsController.php';

// 引入日志和安全管理类
require_once dirname(__DIR__) . '/includes/LogManager.php';
require_once dirname(__DIR__) . '/includes/SecurityManager.php';
require_once dirname(__DIR__) . '/includes/PerformanceMonitor.php';
require_once dirname(__DIR__) . '/includes/CacheManager.php';
// 引入异常处理工具类
require_once dirname(__DIR__) . '/includes/ExceptionHandler.php';

// 初始化日志管理器
try {
    $logger = LogManager::getInstance();
    // 安全地设置日志级别
    if (method_exists($logger, 'setLogLevel')) {
        $logLevel = DEBUG_MODE ? (defined('LogManager::LOG_LEVEL_DEBUG') ? LogManager::LOG_LEVEL_DEBUG : 100) : (defined('LogManager::LOG_LEVEL_INFO') ? LogManager::LOG_LEVEL_INFO : 200);
        $logger->setLogLevel($logLevel);
    }
} catch (Exception $e) {
    // 创建备用日志记录
    $logger = new LogManager('api');
}

// 初始化安全管理器
$securityManager = SecurityManager::getInstance();

// 初始化缓存管理器
$cacheManager = CacheManager::getInstance();

// 初始化异常处理器
$exceptionHandler = ExceptionHandler::getInstance($logger);

// 记录请求信息
$logger->info('API请求开始', array(
    'request_id' => $requestId,
    'method' => $requestMethod,
    'uri' => $requestUri,
    'ip' => $clientIp,
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
    'timestamp' => date('Y-m-d H:i:s')
));

// 安全检查：防止恶意请求
$maliciousRequest = false;
try {
    if (method_exists($securityManager, 'isMaliciousRequest')) {
        $maliciousRequest = $securityManager->isMaliciousRequest($clientIp, $requestUri);
    }
} catch (Exception $e) {
    // 使用异常处理器记录安全检查失败
    $exceptionHandler->handleException($e, 'security_check_failed', array(
        'ip' => $clientIp,
        'uri' => $requestUri
    ));
    $maliciousRequest = false;
}

if ($maliciousRequest) {
    http_response_code(403);
    echo json_encode(array(
        'success' => false,
        'error' => 'Forbidden',
        'message' => '您的请求被安全系统拦截',
        'timestamp' => date('Y-m-d H:i:s')
    ));
    $logger->warning('恶意请求被拦截', array('ip' => $clientIp, 'uri' => $requestUri));
    exit;
}

// 限流检查
if (!checkRateLimit($clientIp)) {
    http_response_code(429);
    echo json_encode(array(
        'success' => false,
        'error' => 'Too Many Requests',
        'message' => '请求过于频繁，请稍后再试',
        'timestamp' => date('Y-m-d H:i:s')
    ));
    $logger->warning('请求限流', array('ip' => $clientIp, 'uri' => $requestUri));
    exit;
}

// 初始化中间件链
$middlewareChain = new MiddlewareChain();

// 注册中间件
$middlewareChain->addMiddleware(new RequestLoggingMiddleware($logger));
// 添加维护模式中间件（应该尽早添加，在认证之前）
$middlewareChain->addMiddleware(new MaintenanceModeApiMiddleware());
// 添加地理位置验证中间件（在认证之前添加，确保只有允许地区的请求才能继续）
$middlewareChain->addMiddleware(new GeoLocationMiddleware($securityManager, $logger));
// 添加安全异常检测中间件
$middlewareChain->addMiddleware(new SecurityAnomalyDetectionMiddleware($securityManager, $logger));
$middlewareChain->addMiddleware(new SecurityCheckMiddleware($securityManager));
// 添加数据脱敏中间件
$middlewareChain->addMiddleware(new DataMaskingMiddleware());
$middlewareChain->addMiddleware(new AuthenticationMiddleware());
$middlewareChain->addMiddleware(new AuthorizationMiddleware());
$middlewareChain->addMiddleware(new RateLimitMiddleware());
$middlewareChain->addMiddleware(new RequestValidationMiddleware());

// 初始化API路由
$router = new ApiRouter($cacheManager);

// 引入二次验证中间件
require_once __DIR__ . '/middleware/TwoFactorAuthMiddleware.php';
$twoFactorMiddleware = new TwoFactorAuthMiddleware();

// 注册路由

// 维护模式路由
// 紧急关闭路由（不需要认证，但需要密钥验证）
$router->post('/maintenance/emergency-disable', 'MaintenanceController@emergencyDisable', false);
// 维护模式状态查询（不需要认证，仅返回状态）
$router->get('/maintenance/status', 'MaintenanceController@getStatus', false);

// 购买分析相关路由（需要管理员权限）
$router->get('/analytics/user-purchases', 'AnalyticsController@getUserPurchaseAnalytics', 'admin');
$router->get('/analytics/sales-trends', 'AnalyticsController@getSalesTrends', 'admin');
$router->get('/analytics/top-products', 'AnalyticsController@getTopProducts', 'admin');
$router->get('/analytics/revenue-stats', 'AnalyticsController@getRevenueStats', 'admin');

// 用户认证路由（公开访问）
$router->post('/auth/login', 'UserController@login', false);
$router->post('/auth/logout', 'UserController@logout');
$router->get('/auth/me', 'UserController@getCurrentUser');
// 密码修改需要二次验证
$router->post('/auth/change-password', 'UserController@changePassword', ['two_factor' => $twoFactorMiddleware]);
$router->post('/auth/forgot-password', 'UserController@forgotPassword', false);
$router->post('/auth/reset-password', 'UserController@resetPassword', false);

// 维护模式管理路由（需要管理员权限和二次验证）
$router->post('/maintenance/enable', 'MaintenanceController@enableMaintenance', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
$router->post('/maintenance/disable', 'MaintenanceController@disableMaintenance', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
$router->put('/maintenance/config', 'MaintenanceController@updateMaintenanceConfig', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);

// 用户管理路由（需要管理员权限）
$router->get('/users', 'UserController@getUsers', 'admin');
// 创建用户需要二次验证
$router->post('/users', 'UserController@createUser', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
$router->get('/users/{id}', 'UserController@getUser', 'admin');
// 修改用户信息需要二次验证
$router->put('/users/{id}', 'UserController@updateUser', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
// 删除用户需要二次验证
$router->delete('/users/{id}', 'UserController@deleteUser', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
// 修改用户状态需要二次验证
$router->put('/users/{id}/status', 'UserController@updateUserStatus', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
// 修改用户角色需要二次验证
$router->put('/users/{id}/roles', 'UserController@updateUserRoles', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);

// 卡片管理路由
$router->get('/cards', 'CardController@getCards');
$router->post('/cards', 'CardController@createCard', 'manager');
$router->get('/cards/{id}', 'CardController@getCard');
$router->put('/cards/{id}', 'CardController@updateCard', 'manager');
// 删除卡片需要二次验证
$router->delete('/cards/{id}', 'CardController@deleteCard', ['permission' => 'manager', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
$router->get('/cards/stats', 'CardController@getCardStats');
$router->put('/cards/{id}/status', 'CardController@updateCardStatus', 'manager');
// 批量创建卡片需要二次验证
$router->post('/cards/batch', 'CardController@batchCreateCards', ['permission' => 'manager', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
// 导入卡片需要二次验证
$router->post('/cards/import', 'CardController@importCards', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);
// 导出卡片需要二次验证
$router->get('/cards/export', 'CardController@exportCards', ['permission' => 'admin', 'middleware' => ['two_factor' => $twoFactorMiddleware]]);

// 身份核验路由
$router->get('/verifications', 'VerificationController@getVerifications');
$router->post('/verifications', 'VerificationController@createVerification');
$router->get('/verifications/{id}', 'VerificationController@getVerification');
$router->post('/verifications/{id}/execute', 'VerificationController@executeVerification', 'verifier');
$router->put('/verifications/{id}/status', 'VerificationController@updateVerificationStatus', 'verifier');
$router->get('/verifications/stats', 'VerificationController@getVerificationStats', 'admin');

// 统计信息路由
$router->get('/stats/dashboard', 'StatsController@getDashboardStats');
$router->get('/stats/cards', 'StatsController@getDetailedCardStats');
$router->get('/stats/verifications', 'StatsController@getDetailedVerificationStats');
$router->get('/stats/system-health', 'StatsController@getSystemHealth', 'admin');
$router->get('/stats/users', 'StatsController@getUserStats', 'admin');
$router->get('/stats/performance', 'StatsController@getPerformanceStats', 'admin');

// 处理请求
try {
    // 执行中间件链
    if (!$middlewareChain->process()) {
        exit;
    }
    
    // 处理路由
    $router->run();
    
} catch (RequestValidationException $e) {
    // 使用异常处理器处理验证错误
    $response = $exceptionHandler->handleException($e, 'validation_error', array(
        'request_id' => $requestId,
        'errors' => $e->getErrors()
    ));
    
    http_response_code(400);
    echo json_encode(array(
        'success' => false,
        'error' => 'Validation Error',
        'message' => $response['message'],
        'errors' => $response['details']['errors'],
        'timestamp' => date('Y-m-d H:i:s'),
        'request_id' => $requestId
    ));
    
} catch (AuthenticationException $e) {
    // 使用异常处理器处理认证错误
    $response = $exceptionHandler->handleException($e, 'authentication_failed', array(
        'request_id' => $requestId,
        'ip' => $clientIp
    ));
    
    http_response_code(401);
    echo json_encode(array(
        'success' => false,
        'error' => 'Authentication Error',
        'message' => $response['message'],
        'timestamp' => date('Y-m-d H:i:s'),
        'request_id' => $requestId
    ));
    
} catch (AuthorizationException $e) {
    // 使用异常处理器处理授权错误
    $response = $exceptionHandler->handleException($e, 'authorization_failed', array(
        'request_id' => $requestId,
        'ip' => $clientIp
    ));
    
    http_response_code(403);
    echo json_encode(array(
        'success' => false,
        'error' => 'Authorization Error',
        'message' => $response['message'],
        'timestamp' => date('Y-m-d H:i:s'),
        'request_id' => $requestId
    ));
    
} catch (ResourceNotFoundException $e) {
    // 使用异常处理器处理资源不存在错误
    $response = $exceptionHandler->handleException($e, 'resource_not_found', array(
        'request_id' => $requestId
    ));
    
    http_response_code(404);
    echo json_encode(array(
        'success' => false,
        'error' => 'Not Found',
        'message' => $response['message'],
        'timestamp' => date('Y-m-d H:i:s'),
        'request_id' => $requestId
    ));
    
} catch (BusinessLogicException $e) {
    // 使用异常处理器处理业务逻辑错误
    $response = $exceptionHandler->handleException($e, 'business_logic_error', array(
        'request_id' => $requestId,
        'code' => $e->getCode()
    ));
    
    http_response_code(422);
    echo json_encode(array(
        'success' => false,
        'error' => 'Business Logic Error',
        'message' => $response['message'],
        'code' => $response['details']['code'],
        'timestamp' => date('Y-m-d H:i:s'),
        'request_id' => $requestId
    ));
    
} catch (Exception $e) {
    // 使用异常处理器处理所有其他异常
    $response = $exceptionHandler->handleException($e, 'api_internal_error', array(
        'request_id' => $requestId,
        'method' => $requestMethod,
        'uri' => $requestUri,
        'ip' => $clientIp
    ));
    
    // 返回错误响应
    http_response_code(500);
    echo json_encode(array(
        'success' => false,
        'error' => 'Internal Server Error',
        'message' => '服务器内部错误，请稍后再试',
        'timestamp' => date('Y-m-d H:i:s'),
        'request_id' => $requestId
    ));
}

// 记录请求完成时间和性能信息
$requestEndTime = microtime(true);
$executionTime = ($requestEndTime - $requestStartTime) * 1000; // 转换为毫秒

// 记录性能数据
if ($executionTime > 500) { // 超过500ms的请求记录为慢请求
    $logger->warning('慢API请求', array(
        'request_id' => $requestId,
        'method' => $requestMethod,
        'uri' => $requestUri,
        'execution_time' => round($executionTime, 2) . 'ms',
        'ip' => $clientIp
    ));
} else {
    $logger->info('API请求完成', array(
        'request_id' => $requestId,
        'method' => $requestMethod,
        'uri' => $requestUri,
        'execution_time' => round($executionTime, 2) . 'ms'
    ));
}

/**
 * 获取客户端真实IP地址
 */
function getClientIp() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    
    return $ip;
}

/**
 * 检查请求是否超过限流阈值
 */
function checkRateLimit($clientIp) {
    // 简单的内存限流实现
    static $rateLimits = array();
    $currentTime = time();
    $window = 60; // 60秒窗口
    $limit = 100; // 每分钟最多100次请求
    
    if (!isset($rateLimits[$clientIp])) {
        $rateLimits[$clientIp] = array(
            'count' => 1,
            'window_start' => $currentTime
        );
        return true;
    }
    
    // 重置窗口
    if ($currentTime - $rateLimits[$clientIp]['window_start'] > $window) {
        $rateLimits[$clientIp]['count'] = 1;
        $rateLimits[$clientIp]['window_start'] = $currentTime;
        return true;
    }
    
    // 增加计数并检查限制
    $rateLimits[$clientIp]['count']++;
    
    return $rateLimits[$clientIp]['count'] <= $limit;
}
?>