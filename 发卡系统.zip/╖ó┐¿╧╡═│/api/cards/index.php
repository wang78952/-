<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/CardManager.php';
require_once __DIR__ . '/../../includes/Response.php';

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $db = Database::getInstance();
    $logger = new Logger();
    $security = new SecurityUtils();
    $cardManager = new CardManager($db, $logger, $security);
    
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'create_batch':
            handleCreateBatch($cardManager);
            break;
            
        case 'generate_cards':
            handleGenerateCards($cardManager);
            break;
            
        case 'list_batches':
            handleListBatches($cardManager);
            break;
            
        case 'list_cards':
            handleListCards($cardManager);
            break;
            
        case 'verify_card':
            handleVerifyCard($cardManager);
            break;
            
        case 'redeem_card':
            handleRedeemCard($cardManager);
            break;
            
        case 'get_card_stats':
            handleGetCardStats($cardManager);
            break;
            
        case 'get_anomalies':
            handleGetAnomalies($cardManager);
            break;
            
        case 'resolve_anomaly':
            handleResolveAnomaly($cardManager);
            break;
            
        case 'expire_cards':
            handleExpireCards($cardManager);
            break;
            
        case 'detect_anomalies':
            handleDetectAnomalies($cardManager);
            break;
            
        case 'export_cards':
            handleExportCards($cardManager);
            break;
            
        case 'batch_operation':
            handleBatchOperation($cardManager);
            break;
            
        case 'get_config':
            handleGetConfig($cardManager);
            break;
            
        case 'update_config':
            handleUpdateConfig($cardManager);
            break;
            
        default:
            Response::error('Invalid action', 400);
            break;
    }
    
} catch (Exception $e) {
    error_log("Card API Error: " . $e->getMessage());
    Response::error('Internal server error: ' . $e->getMessage(), 500);
}

/**
 * 创建卡密批次
 */
function handleCreateBatch($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    $required = ['product_id', 'quantity', 'valid_days'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            Response::error("Missing required field: {$field}", 400);
        }
    }
    
    $batchData = [
        'product_id' => (int)$data['product_id'],
        'quantity' => (int)$data['quantity'],
        'valid_days' => (int)$data['valid_days'],
        'prefix' => $data['prefix'] ?? null,
        'description' => $data['description'] ?? null,
        'operator_id' => $data['operator_id'] ?? null,
        'operator_name' => $data['operator_name'] ?? 'System'
    ];
    
    $batchId = $cardManager->createBatch($batchData);
    
    Response::success([
        'batch_id' => $batchId,
        'message' => 'Batch created successfully'
    ]);
}

/**
 * 生成卡密
 */
function handleGenerateCards($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['batch_id'])) {
        Response::error('Missing batch_id', 400);
    }
    
    $count = $cardManager->generateCards($data['batch_id'], $data['count'] ?? 100);
    
    Response::success([
        'generated_count' => $count,
        'message' => 'Cards generated successfully'
    ]);
}

/**
 * 获取批次列表
 */
function handleListBatches($cardManager)
{
    $page = (int)($_GET['page'] ?? 1);
    $limit = (int)($_GET['limit'] ?? 20);
    $status = $_GET['status'] ?? null;
    $product_id = $_GET['product_id'] ?? null;
    
    $filters = [];
    if ($status) $filters['status'] = $status;
    if ($product_id) $filters['product_id'] = (int)$product_id;
    
    $result = $cardManager->getBatches($page, $limit, $filters);
    
    Response::success($result);
}

/**
 * 获取卡密列表
 */
function handleListCards($cardManager)
{
    $page = (int)($_GET['page'] ?? 1);
    $limit = (int)($_GET['limit'] ?? 20);
    $batch_id = $_GET['batch_id'] ?? null;
    $status = $_GET['status'] ?? null;
    $product_id = $_GET['product_id'] ?? null;
    
    $filters = [];
    if ($batch_id) $filters['batch_id'] = (int)$batch_id;
    if ($status) $filters['status'] = $status;
    if ($product_id) $filters['product_id'] = (int)$product_id;
    
    $result = $cardManager->getCards($page, $limit, $filters);
    
    Response::success($result);
}

/**
 * 验证卡密
 */
function handleVerifyCard($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['card_code'])) {
        Response::error('Missing card_code', 400);
    }
    
    $result = $cardManager->verifyCard($data['card_code'], $data['card_secret'] ?? null);
    
    Response::success($result);
}

/**
 * 使用卡密
 */
function handleRedeemCard($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    $required = ['card_code', 'card_secret'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            Response::error("Missing required field: {$field}", 400);
        }
    }
    
    $usageData = [
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        'session_id' => session_id() ?? null,
        'order_id' => $data['order_id'] ?? null,
        'user_id' => $data['user_id'] ?? null
    ];
    
    $result = $cardManager->redeemCardByCode($data['card_code'], $data['card_secret'], $usageData);
    
    Response::success($result);
}

/**
 * 获取卡密统计
 */
function handleGetCardStats($cardManager)
{
    $product_id = $_GET['product_id'] ?? null;
    $date_from = $_GET['date_from'] ?? null;
    $date_to = $_GET['date_to'] ?? null;
    
    $stats = $cardManager->getCardStatistics($product_id, $date_from, $date_to);
    
    Response::success($stats);
}

/**
 * 获取异常记录
 */
function handleGetAnomalies($cardManager)
{
    $page = (int)($_GET['page'] ?? 1);
    $limit = (int)($_GET['limit'] ?? 20);
    $type = $_GET['type'] ?? null;
    $severity = $_GET['severity'] ?? null;
    $status = $_GET['status'] ?? null;
    
    $filters = [];
    if ($type) $filters['anomaly_type'] = $type;
    if ($severity) $filters['severity'] = $severity;
    if ($status) $filters['status'] = $status;
    
    $result = $cardManager->getAnomalies($page, $limit, $filters);
    
    Response::success($result);
}

/**
 * 解决异常
 */
function handleResolveAnomaly($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['anomaly_id'])) {
        Response::error('Missing anomaly_id', 400);
    }
    
    $result = $cardManager->resolveAnomaly(
        $data['anomaly_id'],
        $data['resolution_note'] ?? null,
        $data['operator_id'] ?? null
    );
    
    Response::success($result);
}

/**
 * 过期卡密处理
 */
function handleExpireCards($cardManager)
{
    $batch_size = (int)($_GET['batch_size'] ?? 1000);
    
    $result = $cardManager->expireCards($batch_size);
    
    Response::success($result);
}

/**
 * 异常检测
 */
function handleDetectAnomalies($cardManager)
{
    $result = $cardManager->detectAnomalies();
    
    Response::success($result);
}

/**
 * 导出卡密
 */
function handleExportCards($cardManager)
{
    $batch_id = $_GET['batch_id'] ?? null;
    $status = $_GET['status'] ?? null;
    $format = $_GET['format'] ?? 'csv';
    
    $filters = [];
    if ($batch_id) $filters['batch_id'] = (int)$batch_id;
    if ($status) $filters['status'] = $status;
    
    $result = $cardManager->exportCards($filters, $format);
    
    if ($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="cards_export_' . date('Y-m-d') . '.csv"');
        echo $result;
        exit;
    } else {
        Response::success(['data' => $result]);
    }
}

/**
 * 批量操作
 */
function handleBatchOperation($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['operation']) || empty($data['card_ids'])) {
        Response::error('Missing operation or card_ids', 400);
    }
    
    $result = $cardManager->batchOperation(
        $data['operation'],
        $data['card_ids'],
        $data['params'] ?? []
    );
    
    Response::success($result);
}

/**
 * 获取配置
 */
function handleGetConfig($cardManager)
{
    $config = $cardManager->getConfig();
    
    Response::success($config);
}

/**
 * 更新配置
 */
function handleUpdateConfig($cardManager)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['config_key'])) {
        Response::error('Missing config_key', 400);
    }
    
    $result = $cardManager->updateConfig($data['config_key'], $data['config_value'] ?? null);
    
    Response::success($result);
}