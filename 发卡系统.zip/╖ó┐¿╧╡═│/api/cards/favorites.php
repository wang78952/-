<?php
/**
 * 卡密收藏夹API接口
 * 处理收藏夹的增删改查请求
 */
require_once __DIR__ . '/../../includes/api/middleware/AuthMiddleware.php';
require_once __DIR__ . '/../../api/controllers/FavoriteCardController.php';
// 引入 Response 类
require_once __DIR__ . '/../../includes/Response.php';

// 初始化中间件和控制器
$auth_middleware = new AuthMiddleware();
$favorite_controller = new FavoriteCardController();

// 获取当前用户ID
$user_id = $auth_middleware->getCurrentUserId();
if (!$user_id) {
    // 确保正确使用 Response 类
    $response = new Response();
    $response->json(['status' => 'error', 'message' => '用户未登录'], 401);
    exit;
}

// 获取请求方法
$method = $_SERVER['REQUEST_METHOD'];

// 路由处理
switch ($method) {
    case 'GET':
        // 获取收藏列表或检查收藏状态
        if (isset($_GET['action']) && $_GET['action'] === 'check') {
            // 检查卡密是否已收藏
            if (isset($_GET['card_id'], $_GET['card_code'])) {
                $favorite_controller->checkFavorite($user_id, $_GET['card_id'], $_GET['card_code']);
            } else {
                $response = new Response();
                $response->json(['status' => 'error', 'message' => '缺少必要参数'], 400);
                exit;
            }
        } else {
            // 获取收藏列表
            $params = [
                'page' => isset($_GET['page']) ? $_GET['page'] : 1,
                'limit' => isset($_GET['limit']) ? $_GET['limit'] : 20
            ];
            $favorite_controller->getFavorites($user_id, $params);
        }
        break;
        
    case 'POST':
        // 添加到收藏夹
        $data = json_decode(file_get_contents('php://input'), true);
        // 验证请求数据
        if (!is_array($data)) {
            $response = new Response();
            $response->json(['status' => 'error', 'message' => '无效的JSON数据'], 400);
            exit;
        }
        $favorite_controller->addFavorite($user_id, $data);
        break;
        
    case 'DELETE':
        // 从收藏夹移除
        if (isset($_GET['id'])) {
            $favorite_controller->removeFavorite($user_id, $_GET['id']);
        } else {
            $response = new Response();
            $response->json(['status' => 'error', 'message' => '缺少收藏ID参数'], 400);
            exit;
        }
        break;
        
    default:
        $response = new Response();
        $response->json(['status' => 'error', 'message' => '不支持的请求方法'], 405);
        exit;
        break;
}