<?php
/**
 * API路由配置文件
 * 统一管理所有API接口的路由、权限和处理函数
 */

// 路由配置数组
$routes = [
    // 订单管理相关API
    'GET' => [
        // 订单备注相关
        '/api/order/notes' => [
            'controller' => 'OrderNoteController',
            'file' => 'api/order/order_notes.php',
            'permission' => ['merchant', 'user', 'admin']
        ],
        // 订单拆分预览
        '/api/order/split/preview' => [
            'controller' => 'OrderSplitController',
            'file' => 'api/order/order_split.php',
            'permission' => ['merchant', 'admin']
        ],
        // 订单列表
        '/api/order/list' => [
            'controller' => 'OrderController',
            'file' => 'api/order/order.php',
            'permission' => ['merchant', 'user', 'admin']
        ],
        // 订单详情
        '/api/order/detail' => [
            'controller' => 'OrderController',
            'file' => 'api/order/order.php',
            'permission' => ['merchant', 'user', 'admin']
        ],
        // 售后列表
        '/api/order/after_sales/list' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['merchant', 'user', 'admin']
        ],
        // 售后详情
        '/api/order/after_sales/detail' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['merchant', 'user', 'admin']
        ],
        // 导出选项
        '/api/export/order/options' => [
            'controller' => 'OrderExportController',
            'file' => 'api/export/order_export.php',
            'permission' => ['merchant', 'admin']
        ],
        // 下载导出文件
        '/api/export/order/download' => [
            'controller' => 'OrderExportController',
            'file' => 'api/export/order_export.php',
            'permission' => ['merchant', 'admin']
        ]
    ],
    
    'POST' => [
        // 创建订单备注
        '/api/order/notes' => [
            'controller' => 'OrderNoteController',
            'file' => 'api/order/order_notes.php',
            'permission' => ['merchant', 'user', 'admin']
        ],
        // 执行订单拆分
        '/api/order/split' => [
            'controller' => 'OrderSplitController',
            'file' => 'api/order/order_split.php',
            'permission' => ['merchant', 'admin']
        ],
        // 创建售后申请
        '/api/order/after_sales' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['user', 'merchant', 'admin']
        ],
        // 处理售后申请
        '/api/order/after_sales/process' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['merchant', 'admin']
        ],
        // 执行订单导出
        '/api/export/order' => [
            'controller' => 'OrderExportController',
            'file' => 'api/export/order_export.php',
            'permission' => ['merchant', 'admin']
        ]
    ],
    
    'DELETE' => [
        // 删除订单备注
        '/api/order/notes' => [
            'controller' => 'OrderNoteController',
            'file' => 'api/order/order_notes.php',
            'permission' => ['merchant', 'user', 'admin']
        ]
    ],
    
    'PUT' => [
        // 审批售后申请
        '/api/order/after_sales/approve' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['merchant', 'admin']
        ],
        // 拒绝售后申请
        '/api/order/after_sales/reject' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['merchant', 'admin']
        ],
        // 取消售后申请
        '/api/order/after_sales/cancel' => [
            'controller' => 'AfterSalesController',
            'file' => 'api/order/after_sales.php',
            'permission' => ['user', 'merchant', 'admin']
        ]
    ]
];

/**
 * 获取当前请求的路由配置
 * @return array|null 路由配置或null（未找到）
 */
function getRouteConfig() {
    global $routes;
    
    // 获取请求方法和路径
    $method = $_SERVER['REQUEST_METHOD'];
    $path = $_SERVER['REQUEST_URI'];
    
    // 清理路径，去除查询字符串和尾部斜杠
    $path = parse_url($path, PHP_URL_PATH);
    $path = rtrim($path, '/');
    
    // 检查是否存在对应的路由
    if (!isset($routes[$method])) {
        return null;
    }
    
    // 遍历路由配置，查找匹配的路径
    foreach ($routes[$method] as $routePath => $config) {
        if ($path === $routePath) {
            return $config;
        }
    }
    
    return null;
}

/**
 * 处理API请求路由
 */
function handleApiRequest() {
    // 获取路由配置
    $routeConfig = getRouteConfig();
    
    if (!$routeConfig) {
        // 未找到路由
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => 404,
            'message' => 'API接口不存在',
            'data' => []
        ]);
        exit;
    }
    
    // 检查文件是否存在
    $filePath = __DIR__ . '/' . $routeConfig['file'];
    if (!file_exists($filePath)) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => 500,
            'message' => 'API控制器文件不存在',
            'data' => []
        ]);
        exit;
    }
    
    // 引入控制器文件
    require_once $filePath;
    
    // 检查控制器类是否存在
    $controllerClass = $routeConfig['controller'];
    if (!class_exists($controllerClass)) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => 500,
            'message' => 'API控制器类不存在',
            'data' => []
        ]);
        exit;
    }
    
    // 创建控制器实例并处理请求
    $controller = new $controllerClass();
    $controller->handleRequest();
}

/**
 * 验证用户权限
 * @param array $requiredPermissions 所需权限数组
 * @param array $userPermissions 用户权限数组
 * @return bool 是否有权限
 */
function checkPermissions(array $requiredPermissions, array $userPermissions) {
    // 检查是否有交集
    $intersection = array_intersect($requiredPermissions, $userPermissions);
    return !empty($intersection);
}