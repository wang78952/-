<?php
/**
 * 积分兑换API
 */

require_once '../../config.php';
require_once '../../includes/auth/Auth.php';
require_once '../../includes/business/MemberService.php';
require_once '../../utils/Response.php';
require_once '../../utils/Logger.php';

// 设置错误处理
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $logger = new Logger('api_error');
    $logger->error("API错误: $errstr", ['file' => $errfile, 'line' => $errline]);
    Response::json(500, '服务器内部错误');
    exit();
});

// 检查用户登录状态
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    Response::json(401, '用户未登录');
    exit();
}

// 获取当前用户ID
$userId = $auth->getCurrentUserId();

// 解析请求数据
$data = json_decode(file_get_contents('php://input'), true);

// 验证参数
if (!isset($data['rule_id']) || !is_numeric($data['rule_id'])) {
    Response::json(400, '请提供有效的兑换规则ID');
    exit();
}

$ruleId = intval($data['rule_id']);

// 创建会员服务实例
$memberService = new MemberService();

try {
    // 执行积分兑换
    $exchangeResult = $memberService->exchangePoints($userId, $ruleId);
    
    // 获取兑换后的会员信息
    $memberInfo = $memberService->getUserMemberInfo($userId);
    
    // 构建响应数据
    $responseData = [
        'exchange_result' => $exchangeResult,
        'member_info' => [
            'current_points' => $memberInfo['current_points'],
            'total_points' => $memberInfo['total_points'],
            'member_level' => $memberInfo['level_value'],
            'member_level_name' => $memberInfo['level_name']
        ],
        'exchange_rules' => $memberService->getAvailableExchangeRules(),
        'timestamp' => time()
    ];
    
    // 返回成功响应
    Response::json(200, '积分兑换成功', $responseData);
} catch (Exception $e) {
    $logger = new Logger('api_error');
    $logger->error("积分兑换失败: " . $e->getMessage(), ['user_id' => $userId, 'rule_id' => $ruleId]);
    Response::json(400, '兑换失败: ' . $e->getMessage());
}