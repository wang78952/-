<?php
/**
 * 获取用户会员信息API
 */

require_once '../../config.php';
require_once '../../includes/auth/Auth.php';
require_once '../../includes/business/MemberService.php';
require_once '../../utils/Response.php';
require_once '../../utils/Logger.php';

// 设置错误处理
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $logger = new Logger('api_error');
    $logger->error("API错误: $errstr", ['file' => $errfile, 'line' => $errline]);
    Response::json(500, '服务器内部错误');
    exit();
});

// 检查用户登录状态
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    Response::json(401, '用户未登录');
    exit();
}

// 获取当前用户ID
$userId = $auth->getCurrentUserId();

// 创建会员服务实例
$memberService = new MemberService();

try {
    // 获取用户会员信息
    $memberInfo = $memberService->getUserMemberInfo($userId);
    
    // 获取用户积分历史
    $historyLimit = isset($_GET['history_limit']) ? intval($_GET['history_limit']) : 10;
    $historyOffset = isset($_GET['history_offset']) ? intval($_GET['history_offset']) : 0;
    $pointsHistory = $memberService->getUserPointsHistory($userId, $historyLimit, $historyOffset);
    
    // 获取积分兑换规则
    $exchangeRules = $memberService->getAvailableExchangeRules();
    
    // 构建响应数据
    $responseData = [
        'member_info' => $memberInfo,
        'points_history' => $pointsHistory,
        'exchange_rules' => $exchangeRules,
        'member_levels' => $memberService->getMemberLevels(),
        'timestamp' => time()
    ];
    
    // 返回成功响应
    Response::json(200, '获取成功', $responseData);
} catch (Exception $e) {
    $logger = new Logger('api_error');
    $logger->error("获取会员信息失败: " . $e->getMessage(), ['user_id' => $userId]);
    Response::json(500, '获取会员信息失败: ' . $e->getMessage());
}