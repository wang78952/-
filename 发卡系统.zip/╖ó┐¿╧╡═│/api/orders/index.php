<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 引入必要的文件
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/OrderManager.php';
require_once __DIR__ . '/../../includes/functions.php';

// 初始化数据库和订单管理器
try {
    $db = Database::getInstance();
    $orderManager = new OrderManager($db);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '数据库连接失败: ' . $e->getMessage()]);
    exit;
}

// 获取请求方法和路径
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));

// 移除api/orders前缀
array_shift($pathParts); // api
array_shift($pathParts); // orders

$action = $pathParts[0] ?? '';
$param = $pathParts[1] ?? null;

try {
    switch ($method) {
        case 'GET':
            handleGetRequest($orderManager, $action, $param);
            break;
        case 'POST':
            handlePostRequest($orderManager, $action, $param);
            break;
        case 'PUT':
            handlePutRequest($orderManager, $action, $param);
            break;
        case 'DELETE':
            handleDeleteRequest($orderManager, $action, $param);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '不支持的请求方法']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/**
 * 处理GET请求
 */
function handleGetRequest($orderManager, $action, $param) {
    switch ($action) {
        case '':
        case 'list':
            // 获取订单列表
            $filters = [
                'user_id' => $_GET['user_id'] ?? null,
                'status' => $_GET['status'] ?? null,
                'payment_method' => $_GET['payment_method'] ?? null,
                'start_date' => $_GET['start_date'] ?? null,
                'end_date' => $_GET['end_date'] ?? null,
                'keyword' => $_GET['keyword'] ?? null
            ];
            
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = min(100, max(1, intval($_GET['limit'] ?? 20)));
            
            $result = $orderManager->getOrderList($filters, $page, $limit);
            echo json_encode(['success' => true, 'data' => $result]);
            break;
            
        case 'detail':
        case 'view':
            // 获取订单详情
            $orderId = $param ?? $_GET['id'] ?? null;
            if (!$orderId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单ID不能为空']);
                return;
            }
            
            $order = $orderManager->getOrder($orderId);
            if (!$order) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => '订单不存在']);
                return;
            }
            
            $order['cards'] = $orderManager->getOrderCards($orderId);
            echo json_encode(['success' => true, 'data' => $order]);
            break;
            
        case 'search':
            // 根据订单号搜索
            $orderNo = $_GET['order_no'] ?? null;
            if (!$orderNo) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单号不能为空']);
                return;
            }
            
            $order = $orderManager->getOrderByNo($orderNo);
            if (!$order) {
                echo json_encode(['success' => true, 'data' => null]);
                return;
            }
            
            $order['cards'] = $orderManager->getOrderCards($order['id']);
            echo json_encode(['success' => true, 'data' => $order]);
            break;
            
        case 'statistics':
            // 获取订单统计
            $filters = [
                'start_date' => $_GET['start_date'] ?? null,
                'end_date' => $_GET['end_date'] ?? null
            ];
            
            $statistics = $orderManager->getOrderStatistics($filters);
            echo json_encode(['success' => true, 'data' => $statistics]);
            break;
            
        case 'export':
            // 导出订单
            $filters = [
                'user_id' => $_GET['user_id'] ?? null,
                'status' => $_GET['status'] ?? null,
                'payment_method' => $_GET['payment_method'] ?? null,
                'start_date' => $_GET['start_date'] ?? null,
                'end_date' => $_GET['end_date'] ?? null,
                'keyword' => $_GET['keyword'] ?? null
            ];
            
            $format = $_GET['format'] ?? 'csv';
            $result = $orderManager->exportOrders($filters, $format);
            
            if ($result['success']) {
                // 设置下载头
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $result['filename'] . '"');
                header('Content-Length: ' . $result['size']);
                
                readfile($result['filepath']);
                
                // 删除临时文件
                unlink($result['filepath']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => '导出失败']);
            }
            break;
            
        case 'status-options':
            // 获取状态选项
            $statusOptions = [
                ['value' => 'pending', 'label' => '待支付'],
                ['value' => 'paid', 'label' => '已支付'],
                ['value' => 'processing', 'label' => '处理中'],
                ['value' => 'completed', 'label' => '已完成'],
                ['value' => 'cancelled', 'label' => '已取消'],
                ['value' => 'refunded', 'label' => '已退款'],
                ['value' => 'partial_refund', 'label' => '部分退款']
            ];
            echo json_encode(['success' => true, 'data' => $statusOptions]);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => '接口不存在']);
            break;
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($orderManager, $action, $param) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    switch ($action) {
        case '':
        case 'create':
            // 创建订单
            $userId = $input['user_id'] ?? null;
            $productId = $input['product_id'] ?? null;
            $quantity = $input['quantity'] ?? 1;
            $paymentMethod = $input['payment_method'] ?? null;
            $remark = $input['remark'] ?? '';
            
            if (!$userId || !$productId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '用户ID和产品ID不能为空']);
                return;
            }
            
            $result = $orderManager->createOrder($userId, $productId, $quantity, $paymentMethod, $remark);
            echo json_encode($result);
            break;
            
        case 'batch-create':
            // 批量创建订单
            $orders = $input['orders'] ?? [];
            $results = [];
            
            foreach ($orders as $orderData) {
                try {
                    $result = $orderManager->createOrder(
                        $orderData['user_id'],
                        $orderData['product_id'],
                        $orderData['quantity'] ?? 1,
                        $orderData['payment_method'] ?? null,
                        $orderData['remark'] ?? ''
                    );
                    $results[] = ['success' => true, 'data' => $result];
                } catch (Exception $e) {
                    $results[] = ['success' => false, 'message' => $e->getMessage()];
                }
            }
            
            echo json_encode(['success' => true, 'data' => $results]);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => '接口不存在']);
            break;
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($orderManager, $action, $param) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    switch ($action) {
        case 'status':
            // 更新订单状态
            $orderId = $param ?? $input['order_id'] ?? null;
            $newStatus = $input['status'] ?? null;
            $remark = $input['remark'] ?? '';
            
            if (!$orderId || !$newStatus) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单ID和新状态不能为空']);
                return;
            }
            
            $result = $orderManager->updateOrderStatus($orderId, $newStatus, $remark);
            echo json_encode($result);
            break;
            
        case 'batch-status':
            // 批量更新订单状态
            $orderIds = $input['order_ids'] ?? [];
            $newStatus = $input['status'] ?? null;
            $remark = $input['remark'] ?? '';
            
            if (empty($orderIds) || !$newStatus) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单ID列表和新状态不能为空']);
                return;
            }
            
            $results = [];
            foreach ($orderIds as $orderId) {
                try {
                    $result = $orderManager->updateOrderStatus($orderId, $newStatus, $remark);
                    $results[] = ['order_id' => $orderId, 'success' => true];
                } catch (Exception $e) {
                    $results[] = ['order_id' => $orderId, 'success' => false, 'message' => $e->getMessage()];
                }
            }
            
            echo json_encode(['success' => true, 'data' => $results]);
            break;
            
        case 'remark':
            // 更新订单备注
            $orderId = $param ?? $input['order_id'] ?? null;
            $remark = $input['remark'] ?? '';
            
            if (!$orderId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单ID不能为空']);
                return;
            }
            
            global $db;
            $db->update('orders', ['remark' => $remark, 'updated_at' => date('Y-m-d H:i:s')], 'id = ?', [$orderId]);
            echo json_encode(['success' => true, 'message' => '备注更新成功']);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => '接口不存在']);
            break;
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($orderManager, $action, $param) {
    switch ($action) {
        case $param:
            // 删除订单（软删除）
            $orderId = $param;
            
            if (!$orderId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单ID不能为空']);
                return;
            }
            
            // 检查订单状态，只有特定状态的订单才能删除
            $order = $orderManager->getOrder($orderId);
            if (!$order) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => '订单不存在']);
                return;
            }
            
            if (!in_array($order['status'], ['cancelled', 'refunded'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '只能删除已取消或已退款的订单']);
                return;
            }
            
            global $db;
            $db->update('orders', ['status' => 'deleted', 'updated_at' => date('Y-m-d H:i:s')], 'id = ?', [$orderId]);
            echo json_encode(['success' => true, 'message' => '订单删除成功']);
            break;
            
        case 'batch':
            // 批量删除订单
            $input = json_decode(file_get_contents('php://input'), true);
            $orderIds = $input['order_ids'] ?? [];
            
            if (empty($orderIds)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '订单ID列表不能为空']);
                return;
            }
            
            $results = [];
            foreach ($orderIds as $orderId) {
                try {
                    $order = $orderManager->getOrder($orderId);
                    if ($order && in_array($order['status'], ['cancelled', 'refunded'])) {
                        global $db;
                        $db->update('orders', ['status' => 'deleted', 'updated_at' => date('Y-m-d H:i:s')], 'id = ?', [$orderId]);
                        $results[] = ['order_id' => $orderId, 'success' => true];
                    } else {
                        $results[] = ['order_id' => $orderId, 'success' => false, 'message' => '订单状态不允许删除'];
                    }
                } catch (Exception $e) {
                    $results[] = ['order_id' => $orderId, 'success' => false, 'message' => $e->getMessage()];
                }
            }
            
            echo json_encode(['success' => true, 'data' => $results]);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => '接口不存在']);
            break;
    }
}