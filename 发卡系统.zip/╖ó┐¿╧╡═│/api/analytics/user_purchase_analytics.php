<?php
/**
 * 用户购卡偏好分析API接口
 * 提供用户购买行为分析、产品偏好统计等数据接口
 */

require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../../includes/business/UserPurchaseAnalytics.php';
require_once '../../includes/AuthManager.php';

// 使用AuthManager检查管理员权限
$authManager = new AuthManager();
if (!$authManager->hasPermission('view_analytics')) {
    $result = ['status' => 'error', 'message' => '权限不足'];
    echo json_encode($result);
    exit;
}

header('Content-Type: application/json');

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

// 获取请求参数
$action = $_GET['action'] ?? 'preferences';
$params = [];

// 从GET和POST中获取参数
$params = array_merge($_GET, $_POST);

// 过滤掉action参数
unset($params['action']);

// 验证必要参数
if (isset($params['start_date']) && !validateDate($params['start_date'])) {
    $response['message'] = '无效的开始日期格式';
    echo json_encode($response);
    exit;
}

if (isset($params['end_date']) && !validateDate($params['end_date'])) {
    $response['message'] = '无效的结束日期格式';
    echo json_encode($response);
    exit;
}

// 创建数据分析实例
$analytics = new UserPurchaseAnalytics($conn);

try {
    switch ($action) {
        case 'preferences':
            // 获取用户购卡偏好分析
            $data = $analytics->getUserPurchasePreferences($params);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取用户购卡偏好分析成功';
            break;
            
        case 'product_preferences':
            // 获取产品偏好统计
            $start_date = $params['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $params['end_date'] ?? date('Y-m-d');
            $user_id = $params['user_id'] ?? null;
            $limit = $params['limit'] ?? 20;
            
            $data = $analytics->getUserProductPreferences($start_date, $end_date, $user_id, $limit);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取产品偏好统计成功';
            break;
            
        case 'price_preferences':
            // 获取价格区间偏好
            $start_date = $params['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $params['end_date'] ?? date('Y-m-d');
            $user_id = $params['user_id'] ?? null;
            
            $data = $analytics->getPriceRangePreferences($start_date, $end_date, $user_id);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取价格区间偏好成功';
            break;
            
        case 'category_preferences':
            // 获取分类偏好
            $start_date = $params['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $params['end_date'] ?? date('Y-m-d');
            $user_id = $params['user_id'] ?? null;
            
            $data = $analytics->getCategoryPreferences($start_date, $end_date, $user_id);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取分类偏好成功';
            break;
            
        case 'time_preferences':
            // 获取购买时间偏好
            $start_date = $params['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $params['end_date'] ?? date('Y-m-d');
            $user_id = $params['user_id'] ?? null;
            
            $data = $analytics->getPurchaseTimePreferences($start_date, $end_date, $user_id);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取购买时间偏好成功';
            break;
            
        case 'frequency_analysis':
            // 获取购买频率分析
            $start_date = $params['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $params['end_date'] ?? date('Y-m-d');
            $user_id = $params['user_id'] ?? null;
            
            $data = $analytics->getPurchaseFrequencyAnalysis($start_date, $end_date, $user_id);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取购买频率分析成功';
            break;
            
        case 'recommendations':
            // 获取产品推荐
            $user_id = $params['user_id'] ?? null;
            $limit = $params['limit'] ?? 10;
            
            if (!$user_id) {
                throw new Exception('缺少用户ID参数');
            }
            
            $data = $analytics->getProductRecommendations($user_id, $limit);
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取产品推荐成功';
            break;
            
        case 'summary':
            // 获取数据分析汇总
            $filters = [];
            if (isset($params['start_date'])) $filters['start_date'] = $params['start_date'];
            if (isset($params['end_date'])) $filters['end_date'] = $params['end_date'];
            if (isset($params['user_id'])) $filters['user_id'] = $params['user_id'];
            
            $data = [
                'total_users' => $analytics->getTotalUsers($filters),
                'total_orders' => $analytics->getTotalOrders($filters),
                'total_amount' => $analytics->getTotalAmount($filters),
                'avg_order_value' => $analytics->getAvgOrderValue($filters)
            ];
            
            $response['success'] = true;
            $response['data'] = $data;
            $response['message'] = '获取数据分析汇总成功';
            break;
            
        default:
            throw new Exception('无效的操作类型');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    logError($e->getMessage(), 'user_purchase_analytics');
}

// 返回JSON响应
echo json_encode($response);

/**
 * 验证日期格式
 * @param string $date 日期字符串
 * @param string $format 日期格式
 * @return bool 是否有效
 */
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * 记录错误日志
 * @param string $message 错误信息
 * @param string $module 模块名称
 */
function logError($message, $module) {
    $log_file = '../../logs/analytics_' . date('Y-m-d') . '.log';
    $log_entry = date('Y-m-d H:i:s') . " [{$module}] ERROR: {$message}\n";
    error_log($log_entry, 3, $log_file);
}
?>