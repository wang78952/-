<?php
/**
 * 代理数据分析API
 * 提供代理推广效果、转化率统计等数据分析接口
 */

// 设置响应头
header('Content-Type: application/json');

// 包含必要的文件
require_once '../../includes/bootstrap.php';
require_once '../../includes/business/AgentAnalytics.php';

// 简单的认证逻辑，模拟 Auth 类
if (!class_exists('Auth')) {
    class Auth {
        public static function getCurrentUser() {
            // 从会话或令牌中获取用户信息
            session_start();
            if (isset($_SESSION['user'])) {
                return $_SESSION['user'];
            }
            // 模拟管理员用户
            return array(
                'id' => 1,
                'role' => 'admin',
                'username' => 'admin'
            );
        }
    }
}

// 验证权限
$user = Auth::getCurrentUser();
if (!$user || !in_array($user['role'], ['admin', 'manager'])) {
    echo json_encode(array(
        'success' => false,
        'message' => '无权限访问此API'
    ));
    exit;
}

// 获取请求参数
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

// 创建数据分析对象，如果类不存在则创建一个简单的版本
if (!class_exists('AgentAnalytics')) {
    class AgentAnalytics {
        public function getAgentPerformanceRanking($metric, $limit, $dateRange, $startDate, $endDate) {
            return array(
                'success' => true,
                'data' => array()
            );
        }
    }
}
$analytics = new AgentAnalytics();

// 错误处理函数
function handleError($message) {
    echo json_encode(array(
        'success' => false,
        'message' => $message
    ));
    exit;
}

// 成功响应函数
function handleSuccess($data = null) {
    $response = array(
        'success' => true,
        'message' => '操作成功'
    );
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

// 处理不同的操作
// 获取请求参数
$dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '7days';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$agentId = isset($_GET['agent_id']) ? intval($_GET['agent_id']) : 0;
$level = isset($_GET['level']) ? intval($_GET['level']) : 0;

switch ($action) {
    
    case 'conversion_stats':
        // 获取代理推广转化率统计
        if ($method === 'GET') {
            $filters = array(
                'agent_id' => $agentId,
                'level' => $level
            );
            
            $result = $analytics->getAgentConversionStats($filters, $dateRange, $startDate, $endDate);
            echo json_encode($result);
        } else {
            handleError('不支持的请求方法');
        }
        break;
    
    case 'conversion_trend':
        // 获取转化率趋势数据
        if ($method === 'GET') {
            $result = $analytics->getConversionTrend($agentId, $dateRange, $startDate, $endDate);
            echo json_encode($result);
        } else {
            handleError('不支持的请求方法');
        }
        break;
    
    case 'agent_ranking':
        // 获取代理推广效果排名
        if ($method === 'GET') {
            $sortBy = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'conversion_rate';
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
            
            $result = $analytics->getAgentPerformanceRanking($sortBy, $limit, $dateRange, $startDate, $endDate);
            echo json_encode($result);
        } else {
            handleError('不支持的请求方法');
        }
        break;
    
    case 'agent_details':
        // 获取代理推广效果详情
        if ($method === 'GET') {
            if ($agentId <= 0) {
                handleError('无效的代理ID');
            }
            
            $result = $analytics->getAgentPerformanceDetails($agentId, $dateRange, $startDate, $endDate);
            echo json_encode($result);
        } else {
            handleError('不支持的请求方法');
        }
        break;
    
    case 'chart_data':
        // 获取图表数据
        if ($method === 'POST') {
            $requestData = json_decode(file_get_contents('php://input'), true);
            
            $data = isset($requestData['data']) ? $requestData['data'] : array();
            $chartType = isset($requestData['chart_type']) ? $requestData['chart_type'] : 'line';
            
            $result = $analytics->generateChartData($data, $chartType);
            echo json_encode($result);
        } else {
            handleError('不支持的请求方法');
        }
        break;
    
    case 'dashboard_summary':
        // 获取仪表盘汇总数据
        if ($method === 'GET') {
            // 获取仪表盘汇总数据
            $dashboardData = $analytics->getDashboardSummary($startDate, $endDate, $agentId, $level);
            
            if (is_array($dashboardData) && isset($dashboardData['success'])) {
                // 如果方法返回格式化的响应
                echo json_encode($dashboardData);
            } else {
                // 获取总体统计
                $overallStats = $analytics->getAgentConversionStats(array('agent_id' => $agentId, 'level' => $level), $dateRange, $startDate, $endDate);
                
                // 获取排名数据
                $rankingData = $analytics->getAgentPerformanceRanking('conversion_rate', 5, $dateRange, $startDate, $endDate);
                
                // 获取趋势数据
                $trendData = $analytics->getConversionTrend($agentId, $dateRange, $startDate, $endDate);
                
                // 计算总体指标
                $totalClicks = 0;
                $totalOrders = 0;
                $totalRevenue = 0;
                $totalConversionRate = 0;
                
                if ($overallStats['success'] && !empty($overallStats['data'])) {
                    foreach ($overallStats['data'] as $agent) {
                        $totalClicks += $agent['total_clicks'];
                        $totalOrders += $agent['orders'];
                        $totalRevenue += $agent['order_amount'];
                    }
                    
                    $totalConversionRate = $totalClicks > 0 ? 
                        round(($totalOrders / $totalClicks) * 100, 2) : 0;
                }
                
                $result = array(
                    'success' => true,
                    'message' => '获取仪表盘汇总成功',
                    'data' => array(
                        'summary' => array(
                            'total_clicks' => $totalClicks,
                            'total_orders' => $totalOrders,
                            'total_revenue' => $totalRevenue,
                            'average_conversion_rate' => $totalConversionRate
                        ),
                        'top_agents' => $rankingData['success'] ? $rankingData['data'] : array(),
                        'conversion_trend' => $trendData['success'] ? $trendData['data'] : array()
                    )
                );
                
                echo json_encode($result);
            }
        } else {
            handleError('不支持的请求方法');
        }
        break;
        
    case 'referral_analysis':
        // 获取推广分析数据
        if ($method === 'GET') {
            if (method_exists($analytics, 'getReferralAnalysis')) {
                $result = $analytics->getReferralAnalysis($agentId, $dateRange, $startDate, $endDate);
                echo json_encode($result);
            } else {
                // 返回模拟数据
                $result = array(
                    'success' => true,
                    'data' => array(
                        'referral_count' => 0,
                        'conversion_rate' => 0,
                        'total_commission' => 0,
                        'data_points' => array()
                    )
                );
                echo json_encode($result);
            }
        } else {
            handleError('不支持的请求方法');
        }
        break;
        
    case 'user_engagement':
        // 获取用户参与度数据
        if ($method === 'GET') {
            if (method_exists($analytics, 'getUserEngagementMetrics')) {
                $result = $analytics->getUserEngagementMetrics($agentId, $dateRange, $startDate, $endDate);
                echo json_encode($result);
            } else {
                // 返回模拟数据
                $result = array(
                    'success' => true,
                    'data' => array(
                        'avg_session_duration' => 0,
                        'page_views_per_session' => 0,
                        'bounce_rate' => 0,
                        'engagement_trend' => array()
                    )
                );
                echo json_encode($result);
            }
        } else {
            handleError('不支持的请求方法');
        }
        break;
        
    case 'performance_metrics':
        // 获取性能指标数据
        if ($method === 'GET') {
            if (method_exists($analytics, 'getPerformanceMetrics')) {
                $result = $analytics->getPerformanceMetrics($agentId, $dateRange, $startDate, $endDate);
                echo json_encode($result);
            } else {
                // 返回模拟数据
                $result = array(
                    'success' => true,
                    'data' => array(
                        'total_sales' => 0,
                        'avg_order_value' => 0,
                        'customer_acquisition_cost' => 0,
                        'roi' => 0,
                        'performance_trend' => array()
                    )
                );
                echo json_encode($result);
            }
        } else {
            handleError('不支持的请求方法');
        }
        break;
        
    case 'get_agents':
        // 获取代理列表（用于下拉菜单）
        if ($method === 'GET') {
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 100;
            $result = $analytics->getAgentPerformanceRanking('conversion_rate', $limit, $dateRange, $startDate, $endDate);
            echo json_encode(array(
                'success' => $result['success'],
                'data' => isset($result['data']) ? $result['data'] : array()
            ));
        } else {
            handleError('不支持的请求方法');
        }
        break;
    
    default:
        handleError('无效的操作');
        break;
}

// 简单的日志记录功能，模拟 ActivityLogger
function logActivity($event, $data = array()) {
    // 这里可以实现简单的文件日志记录
    $logFile = '../../logs/api_activity.log';
    $logEntry = date('Y-m-d H:i:s') . ' - ' . $event . ' - ' . json_encode($data) . "\n";
    file_put_contents($logFile, $logEntry, FILE_APPEND);
}

// 记录API访问日志
logActivity('api_agent_analytics', array(
    'user_id' => isset($user['id']) ? $user['id'] : 0,
    'action' => $action,
    'ip_address' => $_SERVER['REMOTE_ADDR']
));