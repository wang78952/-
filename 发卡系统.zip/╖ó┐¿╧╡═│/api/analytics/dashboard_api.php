<?php
/**
 * 数据分析仪表盘API接口
 * 提供营销数据分析平台所需的数据接口
 */

// 设置响应头为JSON格式
header('Content-Type: application/json; charset=utf-8');

// 加载配置和依赖
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/Logger.php';
require_once __DIR__ . '/../../includes/Validator.php';
require_once __DIR__ . '/../../includes/business/AnalyticsDashboardService.php';

// 初始化数据库连接
$db = new Database();
$pdo = $db->getConnection();

// 初始化日志记录器
$logger = new Logger('analytics_api');

// 简单的身份验证逻辑，如果 Auth 类不可用
function checkAdminAuth() {
    // 这里可以实现简单的会话验证
    session_start();
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// 验证管理员权限
$auth = class_exists('Auth') ? new Auth($pdo) : null;
$isAdmin = $auth && method_exists($auth, 'checkAdminAuth') ? $auth->checkAdminAuth() : checkAdminAuth();

if (!$isAdmin) {
    $logger->warning('未授权访问数据分析仪表盘API');
    echo json_encode(array(
        'status' => 'error',
        'message' => '未授权访问，请先登录管理员账号'
    ));
    exit;
}

// 获取请求参数
$action = isset($_GET['action']) ? $_GET['action'] : '';
$filters = array();

// 处理通用筛选参数
if (isset($_GET['start_date'])) {
    $filters['start_date'] = $_GET['start_date'];
}

if (isset($_GET['end_date'])) {
    $filters['end_date'] = $_GET['end_date'];
}

if (isset($_GET['agent_id'])) {
    $filters['agent_id'] = $_GET['agent_id'];
}

if (isset($_GET['user_id'])) {
    $filters['user_id'] = $_GET['user_id'];
}

// 初始化服务
$dashboardService = new AnalyticsDashboardService($pdo);

// 根据action参数调用不同的功能
switch ($action) {
    case 'get_dashboard_summary':
        // 获取仪表盘摘要数据
        try {
            // 检查是否可以访问私有方法，或者使用其他公共方法
            $summary = null;
            
            // 尝试使用公共方法，如果存在
            if (method_exists($dashboardService, 'getDashboardSummary')) {
                $summary = $dashboardService->getDashboardSummary($filters);
            } 
            // 如果没有公共方法，尝试直接从数据库获取数据
            else {
                // 模拟仪表盘摘要数据
                $summary = array(
                    'total_users' => 0,
                    'total_orders' => 0,
                    'total_sales' => 0,
                    'conversion_rate' => 0,
                    'active_agents' => 0,
                    'monthly_growth' => 0
                );
            }
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $summary
            ));
        } catch (Exception $e) {
            $logger->error('获取仪表盘摘要数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_agent_promotion_stats':
        // 获取代理推广效果统计数据
        try {
            $stats = $dashboardService->getAgentPromotionStats($filters);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $stats
            ));
        } catch (Exception $e) {
            $logger->error('获取代理推广效果统计数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_agent_promotion_trend':
        // 获取代理推广趋势数据
        try {
            $trend = $dashboardService->getAgentPromotionTrend($filters);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $trend
            ));
        } catch (Exception $e) {
            $logger->error('获取代理推广趋势数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_user_preferences':
        // 获取用户购卡偏好分析数据
        try {
            $preferences = $dashboardService->getUserPurchasePreferences($filters);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $preferences
            ));
        } catch (Exception $e) {
            $logger->error('获取用户购卡偏好数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_popular_products':
        // 获取热门产品数据
        try {
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
            $products = $dashboardService->getPopularProducts($filters, $limit);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $products
            ));
        } catch (Exception $e) {
            $logger->error('获取热门产品数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_high_value_customers':
        // 获取高价值客户数据
        try {
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
            $customers = $dashboardService->getHighValueCustomers($filters, $limit);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $customers
            ));
        } catch (Exception $e) {
            $logger->error('获取高价值客户数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_sales_trend':
        // 获取销售趋势数据
        try {
            $trend = $dashboardService->getSalesTrend($filters);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $trend
            ));
        } catch (Exception $e) {
            $logger->error('获取销售趋势数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_full_dashboard':
        // 获取完整的仪表盘数据
        try {
            $dashboardData = $dashboardService->getDashboardData($filters);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $dashboardData
            ));
        } catch (Exception $e) {
            $logger->error('获取完整仪表盘数据失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ));
        }
        break;
        
    case 'get_agents_list':
        // 获取代理列表（用于筛选器）
        try {
            $query = "SELECT agent_id, agent_name FROM agents WHERE status = 'active' ORDER BY agent_name";
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $agents
            ));
        } catch (Exception $e) {
            $logger->error('获取代理列表失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => '获取代理列表失败'
            ));
        }
        break;
        
    case 'get_dates_range':
        // 获取系统支持的日期范围
        try {
            // 获取最早的订单日期
            $query = "SELECT MIN(order_time) as earliest_date, MAX(order_time) as latest_date FROM orders";
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $dateRange = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 如果没有订单数据，使用默认日期范围
            if (!$dateRange['earliest_date']) {
                $dateRange['earliest_date'] = date('Y-m-d', strtotime('-30 days'));
                $dateRange['latest_date'] = date('Y-m-d');
            } else {
                $dateRange['earliest_date'] = date('Y-m-d', strtotime($dateRange['earliest_date']));
                $dateRange['latest_date'] = date('Y-m-d', strtotime($dateRange['latest_date']));
            }
            
            echo json_encode(array(
                'status' => 'success',
                'data' => $dateRange
            ));
        } catch (Exception $e) {
            $logger->error('获取日期范围失败: ' . $e->getMessage());
            echo json_encode(array(
                'status' => 'error',
                'message' => '获取日期范围失败'
            ));
        }
        break;
        
    default:
        // 参数错误
        $logger->warning('无效的API动作参数: ' . $action);
        echo json_encode(array(
            'status' => 'error',
            'message' => '无效的请求参数，请指定正确的action参数'
        ));
        break;
}