<?php
/**
 * 仪表盘数据导出API
 * 用于导出数据分析仪表盘的统计数据为CSV或Excel格式
 */

// 确保不直接访问
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__, 3) . '/');
}

// 包含必要文件
require_once ABSPATH . 'includes/config.php';
require_once ABSPATH . 'includes/AuthManager.php';
require_once ABSPATH . 'includes/business/AgentAnalytics.php';
require_once ABSPATH . 'includes/business/UserPurchaseAnalytics.php';

// 验证权限
$authManager = new AuthManager();
if (!$authManager->isLoggedIn() || !$authManager->hasPermission('export_analytics')) {
    header('Content-Type: application/json');
    echo json_encode(array(
        'success' => false,
        'message' => '权限不足，无法导出数据'
    ));
    exit;
}

// 获取请求参数
$export_type = isset($_GET['export_type']) ? $_GET['export_type'] : 'csv'; // csv 或 excel
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$agent_id = isset($_GET['agent_id']) && $_GET['agent_id'] != 0 ? $_GET['agent_id'] : 0;
$level = isset($_GET['level']) && $_GET['level'] != 0 ? $_GET['level'] : 0;

// 初始化分析类
$agentAnalytics = new AgentAnalytics();
$userAnalytics = new UserPurchaseAnalytics();

// 设置默认日期范围（如果未提供）
if (empty($start_date) || empty($end_date)) {
    // 默认导出最近30天数据
    $end_date = date('Y-m-d');
    $start_date = date('Y-m-d', strtotime('-30 days'));
}

// 根据导出类型处理
if ($export_type === 'csv') {
    exportToCSV($agentAnalytics, $userAnalytics, $start_date, $end_date, $agent_id, $level);
} else {
    // 默认使用CSV格式
    exportToCSV($agentAnalytics, $userAnalytics, $start_date, $end_date, $agent_id, $level);
}

/**
 * 导出数据为CSV格式
 */
function exportToCSV($agentAnalytics, $userAnalytics, $start_date, $end_date, $agent_id, $level) {
    // 设置文件名
    $filename = 'dashboard_data_' . date('YmdHis') . '.csv';
    
    // 设置HTTP头以触发文件下载
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    // 打开输出缓冲流
    $output = fopen('php://output', 'w');
    
    // 添加UTF-8 BOM以支持中文
    fputs($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
    
    try {
        // 1. 导出代理排名数据
        fputcsv($output, array('代理推广效果排名'));
        fputcsv($output, array('排名', '代理名称', '等级', '点击量', '订单量', '销售额', '转化率'));
        
        $agentsRanking = $agentAnalytics->getAgentRanking($start_date, $end_date, $agent_id, $level, 'conversion_rate');
        foreach ($agentsRanking as $index => $agent) {
            fputcsv($output, array(
                $index + 1,
                $agent['agent_name'],
                '代理' . $agent['level'],
                $agent['total_clicks'],
                $agent['orders'],
                $agent['order_amount'],
                $agent['conversion_rate'] . '%'
            ));
        }
        
        // 空行分隔
        fputcsv($output, array());
        fputcsv($output, array());
        
        // 2. 导出用户购卡偏好 - 产品偏好
        fputcsv($output, array('用户购卡偏好 - 按产品'));
        fputcsv($output, array('产品名称', '购买次数', '购买金额', '占比'));
        
        $productPreferences = $userAnalytics->getProductPreferences($start_date, $end_date);
        foreach ($productPreferences as $product) {
            fputcsv($output, array(
                $product['product_name'],
                $product['purchase_count'],
                $product['total_amount'],
                $product['percentage'] . '%'
            ));
        }
        
        // 空行分隔
        fputcsv($output, array());
        fputcsv($output, array());
        
        // 3. 导出用户购卡偏好 - 价格区间
        fputcsv($output, array('用户购卡偏好 - 按价格区间'));
        fputcsv($output, array('价格区间', '购买次数', '购买金额', '占比'));
        
        $pricePreferences = $userAnalytics->getPriceRangePreferences($start_date, $end_date);
        foreach ($pricePreferences as $price) {
            fputcsv($output, array(
                $price['price_range'],
                $price['count'],
                $price['total_amount'],
                $price['percentage'] . '%'
            ));
        }
        
        // 空行分隔
        fputcsv($output, array());
        fputcsv($output, array());
        
        // 4. 导出用户购卡偏好 - 分类偏好
        fputcsv($output, array('用户购卡偏好 - 按分类'));
        fputcsv($output, array('分类名称', '购买次数', '购买金额', '占比'));
        
        $categoryPreferences = $userAnalytics->getCategoryPreferences($start_date, $end_date);
        foreach ($categoryPreferences as $category) {
            fputcsv($output, array(
                $category['category_name'],
                $category['count'],
                $category['total_amount'],
                $category['percentage'] . '%'
            ));
        }
        
        // 空行分隔
        fputcsv($output, array());
        fputcsv($output, array());
        
        // 5. 导出转化率趋势数据
        fputcsv($output, array('转化率趋势数据'));
        fputcsv($output, array('日期', '点击量', '订单量', '转化率'));
        
        $conversionTrend = $agentAnalytics->getConversionTrend($start_date, $end_date, $agent_id, $level);
        foreach ($conversionTrend as $trend) {
            fputcsv($output, array(
                $trend['date'],
                $trend['total_clicks'],
                $trend['orders'],
                $trend['conversion_rate'] . '%'
            ));
        }
        
    } catch (Exception $e) {
        fputcsv($output, array('导出数据时发生错误:', $e->getMessage()));
    }
    
    // 关闭输出流
    fclose($output);
    exit;
}

/**
 * 导出数据为Excel格式（未来扩展）
 */
function exportToExcel($agentAnalytics, $userAnalytics, $start_date, $end_date, $agent_id, $level) {
    // 这里可以扩展支持Excel格式导出
    // 可以使用PHPExcel或类似库
    // 目前先默认使用CSV格式
    exportToCSV($agentAnalytics, $userAnalytics, $start_date, $end_date, $agent_id, $level);
}