<?php
/**
 * 权限管理API
 * 处理角色分配、权限审批等操作
 */

require_once '../../includes/Database.php';
require_once '../../includes/AuthManager.php';
require_once '../../includes/PermissionManager.php';

header('Content-Type: application/json; charset=utf-8');

// 初始化
$db = new Database();
$authManager = new AuthManager($db);
$permissionManager = new PermissionManager($db);

// 获取请求方法和路径
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));

// 移除API路径前缀
array_shift($pathParts); // api
array_shift($pathParts); // permission

$endpoint = $pathParts[0] ?? '';
$param1 = $pathParts[1] ?? '';
$param2 = $pathParts[2] ?? '';

// 权限检查中间件
function requirePermission($permission) {
    global $authManager, $permissionManager;
    
    $token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    
    if (!$token || !$authManager->validateToken($token)) {
        http_response_code(401);
        echo json_encode(['error' => '未授权访问']);
        exit;
    }
    
    $payload = $authManager->getTokenPayload($token);
    $userId = $payload['user_id'];
    
    if (!$permissionManager->hasPermission($userId, $permission)) {
        http_response_code(403);
        echo json_encode(['error' => '权限不足']);
        exit;
    }
    
    return $userId;
}

// 错误处理
try {
    switch ($method) {
        case 'GET':
            handleGetRequest();
            break;
        case 'POST':
            handlePostRequest();
            break;
        case 'PUT':
            handlePutRequest();
            break;
        case 'DELETE':
            handleDeleteRequest();
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => '不支持的请求方法']);
            break;
    }
} catch (Exception $e) {
    error_log("权限管理API错误: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => '服务器内部错误']);
}

/**
 * 处理GET请求
 */
function handleGetRequest() {
    global $endpoint, $param1, $permissionManager;
    
    switch ($endpoint) {
        case 'roles':
            requirePermission('role.view');
            handleGetRoles();
            break;
            
        case 'permissions':
            requirePermission('permission.view');
            handleGetPermissions();
            break;
            
        case 'user-roles':
            $userId = requirePermission('user.view');
            handleGetUserRoles($param1);
            break;
            
        case 'user-permissions':
            $userId = requirePermission('permission.view');
            handleGetUserPermissions($param1);
            break;
            
        case 'requests':
            $userId = requirePermission('permission.view');
            handleGetPermissionRequests();
            break;
            
        case 'pending-requests':
            $userId = requirePermission('permission.approve');
            handleGetPendingRequests($userId);
            break;
            
        case 'stats':
            requirePermission('permission.view');
            handleGetPermissionStats();
            break;
            
        case 'audit-logs':
            requirePermission('permission.audit');
            handleGetAuditLogs();
            break;
            
        case 'check':
            $userId = requirePermission('user.view');
            handleCheckPermission($userId);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '接口不存在']);
            break;
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest() {
    global $endpoint, $permissionManager;
    
    switch ($endpoint) {
        case 'roles':
            requirePermission('role.create');
            handleCreateRole();
            break;
            
        case 'permissions':
            requirePermission('permission.create');
            handleCreatePermission();
            break;
            
        case 'assign-role':
            requirePermission('user.assign_role');
            handleAssignRole();
            break;
            
        case 'revoke-role':
            requirePermission('user.assign_role');
            handleRevokeRole();
            break;
            
        case 'assign-permission':
            requirePermission('role.assign_permission');
            handleAssignPermissionToRole();
            break;
            
        case 'remove-permission':
            requirePermission('role.assign_permission');
            handleRemovePermissionFromRole();
            break;
            
        case 'requests':
            $userId = requirePermission('permission.request');
            handleCreatePermissionRequest($userId);
            break;
            
        case 'approve':
            $userId = requirePermission('permission.approve');
            handleApproveRequest($userId);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '接口不存在']);
            break;
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest() {
    global $endpoint, $param1, $permissionManager;
    
    switch ($endpoint) {
        case 'roles':
            requirePermission('role.edit');
            handleUpdateRole($param1);
            break;
            
        case 'permissions':
            requirePermission('permission.edit');
            handleUpdatePermission($param1);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '接口不存在']);
            break;
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest() {
    global $endpoint, $param1, $permissionManager;
    
    switch ($endpoint) {
        case 'roles':
            requirePermission('role.delete');
            handleDeleteRole($param1);
            break;
            
        case 'permissions':
            requirePermission('permission.delete');
            handleDeletePermission($param1);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => '接口不存在']);
            break;
    }
}

/**
 * 获取角色列表
 */
function handleGetRoles() {
    global $permissionManager;
    
    $filters = [];
    
    if (!empty($_GET['is_active'])) {
        $filters['is_active'] = $_GET['is_active'] === 'true';
    }
    
    if (!empty($_GET['level_min'])) {
        $filters['level_min'] = (int)$_GET['level_min'];
    }
    
    if (!empty($_GET['level_max'])) {
        $filters['level_max'] = (int)$_GET['level_max'];
    }
    
    $roles = $permissionManager->getRoles($filters);
    
    echo json_encode([
        'success' => true,
        'data' => $roles,
        'total' => count($roles)
    ]);
}

/**
 * 获取权限列表
 */
function handleGetPermissions() {
    global $permissionManager;
    
    $filters = [];
    
    if (!empty($_GET['module'])) {
        $filters['module'] = $_GET['module'];
    }
    
    if (!empty($_GET['action'])) {
        $filters['action'] = $_GET['action'];
    }
    
    if (!empty($_GET['is_active'])) {
        $filters['is_active'] = $_GET['is_active'] === 'true';
    }
    
    $permissions = $permissionManager->getPermissions($filters);
    
    echo json_encode([
        'success' => true,
        'data' => $permissions,
        'total' => count($permissions)
    ]);
}

/**
 * 获取用户角色
 */
function handleGetUserRoles($userId) {
    global $permissionManager;
    
    if (empty($userId)) {
        http_response_code(400);
        echo json_encode(['error' => '用户ID不能为空']);
        return;
    }
    
    $roles = $permissionManager->getUserRoles($userId);
    
    echo json_encode([
        'success' => true,
        'data' => $roles,
        'total' => count($roles)
    ]);
}

/**
 * 获取用户权限
 */
function handleGetUserPermissions($userId) {
    global $permissionManager;
    
    if (empty($userId)) {
        http_response_code(400);
        echo json_encode(['error' => '用户ID不能为空']);
        return;
    }
    
    $permissions = $permissionManager->getUserPermissions($userId);
    
    echo json_encode([
        'success' => true,
        'data' => $permissions,
        'total' => count($permissions)
    ]);
}

/**
 * 获取权限申请列表
 */
function handleGetPermissionRequests() {
    global $permissionManager;
    
    $filters = [];
    
    if (!empty($_GET['user_id'])) {
        $filters['user_id'] = (int)$_GET['user_id'];
    }
    
    if (!empty($_GET['status'])) {
        $filters['status'] = $_GET['status'];
    }
    
    if (!empty($_GET['request_type'])) {
        $filters['request_type'] = $_GET['request_type'];
    }
    
    if (!empty($_GET['priority'])) {
        $filters['priority'] = $_GET['priority'];
    }
    
    if (!empty($_GET['limit'])) {
        $filters['limit'] = (int)$_GET['limit'];
    }
    
    if (!empty($_GET['offset'])) {
        $filters['offset'] = (int)$_GET['offset'];
    }
    
    $requests = $permissionManager->getPermissionRequests($filters);
    
    echo json_encode([
        'success' => true,
        'data' => $requests,
        'total' => count($requests)
    ]);
}

/**
 * 获取待审批申请
 */
function handleGetPendingRequests($approverId) {
    global $permissionManager;
    
    $requests = $permissionManager->getPendingRequests($approverId);
    
    echo json_encode([
        'success' => true,
        'data' => $requests,
        'total' => count($requests)
    ]);
}

/**
 * 获取权限统计
 */
function handleGetPermissionStats() {
    global $permissionManager;
    
    $stats = $permissionManager->getPermissionStats();
    
    echo json_encode([
        'success' => true,
        'data' => $stats
    ]);
}

/**
 * 获取审计日志
 */
function handleGetAuditLogs() {
    global $db;
    
    $filters = [];
    $params = [];
    
    $sql = "
        SELECT pal.*, u1.username as operator_username, u2.username as target_username
        FROM permission_audit_logs pal
        LEFT JOIN users u1 ON pal.user_id = u1.id
        LEFT JOIN users u2 ON pal.target_user_id = u2.id
        WHERE 1=1
    ";
    
    if (!empty($_GET['user_id'])) {
        $sql .= " AND pal.user_id = ?";
        $params[] = (int)$_GET['user_id'];
    }
    
    if (!empty($_GET['target_user_id'])) {
        $sql .= " AND pal.target_user_id = ?";
        $params[] = (int)$_GET['target_user_id'];
    }
    
    if (!empty($_GET['action'])) {
        $sql .= " AND pal.action = ?";
        $params[] = $_GET['action'];
    }
    
    if (!empty($_GET['resource_type'])) {
        $sql .= " AND pal.resource_type = ?";
        $params[] = $_GET['resource_type'];
    }
    
    if (!empty($_GET['date_from'])) {
        $sql .= " AND pal.created_at >= ?";
        $params[] = $_GET['date_from'];
    }
    
    if (!empty($_GET['date_to'])) {
        $sql .= " AND pal.created_at <= ?";
        $params[] = $_GET['date_to'];
    }
    
    $sql .= " ORDER BY pal.created_at DESC";
    
    if (!empty($_GET['limit'])) {
        $sql .= " LIMIT " . (int)$_GET['limit'];
        if (!empty($_GET['offset'])) {
            $sql .= " OFFSET " . (int)$_GET['offset'];
        }
    }
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $logs,
        'total' => count($logs)
    ]);
}

/**
 * 检查权限
 */
function handleCheckPermission($userId) {
    global $permissionManager;
    
    $permissionName = $_GET['permission'] ?? '';
    if (empty($permissionName)) {
        http_response_code(400);
        echo json_encode(['error' => '权限名称不能为空']);
        return;
    }
    
    $hasPermission = $permissionManager->hasPermission($userId, $permissionName);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'has_permission' => $hasPermission,
            'permission' => $permissionName,
            'user_id' => $userId
        ]
    ]);
}

/**
 * 创建角色
 */
function handleCreateRole() {
    global $permissionManager;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $name = $input['name'] ?? '';
    $displayName = $input['display_name'] ?? '';
    $description = $input['description'] ?? '';
    $level = $input['level'] ?? 0;
    
    if (empty($name) || empty($displayName)) {
        http_response_code(400);
        echo json_encode(['error' => '角色名称和显示名称不能为空']);
        return;
    }
    
    try {
        $roleId = $permissionManager->createRole($name, $displayName, $description, $level, $_SESSION['user_id']);
        
        if ($roleId) {
            echo json_encode([
                'success' => true,
                'message' => '角色创建成功',
                'data' => ['role_id' => $roleId]
            ]);
        } else {
            echo json_encode(['error' => '角色创建失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 创建权限
 */
function handleCreatePermission() {
    global $db;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $name = $input['name'] ?? '';
    $displayName = $input['display_name'] ?? '';
    $description = $input['description'] ?? '';
    $module = $input['module'] ?? '';
    $action = $input['action'] ?? '';
    $resource = $input['resource'] ?? '';
    
    if (empty($name) || empty($displayName) || empty($module) || empty($action)) {
        http_response_code(400);
        echo json_encode(['error' => '权限名称、显示名称、模块和操作类型不能为空']);
        return;
    }
    
    try {
        $stmt = $db->prepare("
            INSERT INTO permissions (name, display_name, description, module, action, resource)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $result = $stmt->execute([$name, $displayName, $description, $module, $action, $resource]);
        
        if ($result) {
            $permissionId = $db->lastInsertId();
            
            echo json_encode([
                'success' => true,
                'message' => '权限创建成功',
                'data' => ['permission_id' => $permissionId]
            ]);
        } else {
            echo json_encode(['error' => '权限创建失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 分配角色
 */
function handleAssignRole() {
    global $permissionManager;
    
    // 双因素认证检查
    $authManager = AuthManager::getInstance();
    if ($authManager->requireTwoFactor('assign_role')) {
        // 检查双因素认证是否已验证
        if (!$authManager->isTwoFactorVerified($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['error' => '该敏感操作需要双因素认证，请先完成验证']);
            return;
        }
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userId = $input['user_id'] ?? 0;
    $roleId = $input['role_id'] ?? 0;
    $expiresAt = $input['expires_at'] ?? null;
    
    if (empty($userId) || empty($roleId)) {
        http_response_code(400);
        echo json_encode(['error' => '用户ID和角色ID不能为空']);
        return;
    }
    
    try {
        $result = $permissionManager->assignRole($userId, $roleId, $_SESSION['user_id'], $expiresAt);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '角色分配成功'
            ]);
        } else {
            echo json_encode(['error' => '角色分配失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 撤销角色
 */
function handleRevokeRole() {
    global $permissionManager;
    
    // 双因素认证检查
    $authManager = AuthManager::getInstance();
    if ($authManager->requireTwoFactor('revoke_role')) {
        // 检查双因素认证是否已验证
        if (!$authManager->isTwoFactorVerified($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['error' => '该敏感操作需要双因素认证，请先完成验证']);
            return;
        }
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userId = $input['user_id'] ?? 0;
    $roleId = $input['role_id'] ?? 0;
    
    if (empty($userId) || empty($roleId)) {
        http_response_code(400);
        echo json_encode(['error' => '用户ID和角色ID不能为空']);
        return;
    }
    
    try {
        $result = $permissionManager->revokeRole($userId, $roleId, $_SESSION['user_id']);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '角色撤销成功'
            ]);
        } else {
            echo json_encode(['error' => '角色撤销失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 为角色分配权限
 */
function handleAssignPermissionToRole() {
    global $permissionManager;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $roleId = $input['role_id'] ?? 0;
    $permissionId = $input['permission_id'] ?? 0;
    
    if (empty($roleId) || empty($permissionId)) {
        http_response_code(400);
        echo json_encode(['error' => '角色ID和权限ID不能为空']);
        return;
    }
    
    try {
        $result = $permissionManager->assignPermissionToRole($roleId, $permissionId, $_SESSION['user_id']);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '权限分配成功'
            ]);
        } else {
            echo json_encode(['error' => '权限分配失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 移除角色权限
 */
function handleRemovePermissionFromRole() {
    global $permissionManager;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $roleId = $input['role_id'] ?? 0;
    $permissionId = $input['permission_id'] ?? 0;
    
    if (empty($roleId) || empty($permissionId)) {
        http_response_code(400);
        echo json_encode(['error' => '角色ID和权限ID不能为空']);
        return;
    }
    
    try {
        $result = $permissionManager->removePermissionFromRole($roleId, $permissionId, $_SESSION['user_id']);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '权限移除成功'
            ]);
        } else {
            echo json_encode(['error' => '权限移除失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 创建权限申请
 */
function handleCreatePermissionRequest($userId) {
    global $permissionManager;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $requestType = $input['request_type'] ?? '';
    $targetId = $input['target_id'] ?? 0;
    $reason = $input['reason'] ?? '';
    $priority = $input['priority'] ?? 'medium';
    
    if (empty($requestType) || empty($targetId) || empty($reason)) {
        http_response_code(400);
        echo json_encode(['error' => '申请类型、目标ID和申请理由不能为空']);
        return;
    }
    
    try {
        $requestId = $permissionManager->requestPermission($userId, $requestType, $targetId, $reason, $priority);
        
        if ($requestId) {
            echo json_encode([
                'success' => true,
                'message' => '申请提交成功',
                'data' => ['request_id' => $requestId]
            ]);
        } else {
            echo json_encode(['error' => '申请提交失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 审批权限申请
 */
function handleApproveRequest($approverId) {
    global $permissionManager;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $requestId = $input['request_id'] ?? 0;
    $action = $input['action'] ?? '';
    $comment = $input['comment'] ?? '';
    $nextApproverId = $input['next_approver_id'] ?? null;
    
    if (empty($requestId) || empty($action)) {
        http_response_code(400);
        echo json_encode(['error' => '申请ID和审批动作不能为空']);
        return;
    }
    
    try {
        $result = $permissionManager->approveRequest($requestId, $approverId, $action, $comment, $nextApproverId);
        
        if ($result) {
            $message = $action === 'approve' ? '审批通过' : ($action === 'reject' ? '审批拒绝' : '审批处理');
            echo json_encode([
                'success' => true,
                'message' => $message . '成功'
            ]);
        } else {
            echo json_encode(['error' => '审批处理失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 更新角色
 */
function handleUpdateRole($roleId) {
    global $db;
    
    if (empty($roleId)) {
        http_response_code(400);
        echo json_encode(['error' => '角色ID不能为空']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $displayName = $input['display_name'] ?? '';
    $description = $input['description'] ?? '';
    $level = $input['level'] ?? null;
    $isActive = $input['is_active'] ?? null;
    
    $updates = [];
    $params = [];
    
    if (!empty($displayName)) {
        $updates[] = "display_name = ?";
        $params[] = $displayName;
    }
    
    if ($description !== null) {
        $updates[] = "description = ?";
        $params[] = $description;
    }
    
    if ($level !== null) {
        $updates[] = "level = ?";
        $params[] = $level;
    }
    
    if ($isActive !== null) {
        $updates[] = "is_active = ?";
        $params[] = $isActive;
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => '没有要更新的字段']);
        return;
    }
    
    $updates[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $roleId;
    
    try {
        $sql = "UPDATE roles SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '角色更新成功'
            ]);
        } else {
            echo json_encode(['error' => '角色更新失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 更新权限
 */
function handleUpdatePermission($permissionId) {
    global $db;
    
    if (empty($permissionId)) {
        http_response_code(400);
        echo json_encode(['error' => '权限ID不能为空']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $displayName = $input['display_name'] ?? '';
    $description = $input['description'] ?? '';
    $isActive = $input['is_active'] ?? null;
    
    $updates = [];
    $params = [];
    
    if (!empty($displayName)) {
        $updates[] = "display_name = ?";
        $params[] = $displayName;
    }
    
    if ($description !== null) {
        $updates[] = "description = ?";
        $params[] = $description;
    }
    
    if ($isActive !== null) {
        $updates[] = "is_active = ?";
        $params[] = $isActive;
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => '没有要更新的字段']);
        return;
    }
    
    $updates[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $permissionId;
    
    try {
        $sql = "UPDATE permissions SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '权限更新成功'
            ]);
        } else {
            echo json_encode(['error' => '权限更新失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 删除角色
 */
function handleDeleteRole($roleId) {
    global $db;
    
    if (empty($roleId)) {
        http_response_code(400);
        echo json_encode(['error' => '角色ID不能为空']);
        return;
    }
    
    try {
        // 检查是否有用户使用该角色
        $stmt = $db->prepare("SELECT COUNT(*) FROM user_roles WHERE role_id = ? AND is_active = TRUE");
        $stmt->execute([$roleId]);
        $userCount = $stmt->fetchColumn();
        
        if ($userCount > 0) {
            http_response_code(400);
            echo json_encode(['error' => '该角色下还有用户，无法删除']);
            return;
        }
        
        $stmt = $db->prepare("DELETE FROM roles WHERE id = ?");
        $result = $stmt->execute([$roleId]);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '角色删除成功'
            ]);
        } else {
            echo json_encode(['error' => '角色删除失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}

/**
 * 删除权限
 */
function handleDeletePermission($permissionId) {
    global $db;
    
    if (empty($permissionId)) {
        http_response_code(400);
        echo json_encode(['error' => '权限ID不能为空']);
        return;
    }
    
    try {
        // 检查是否有角色使用该权限
        $stmt = $db->prepare("SELECT COUNT(*) FROM role_permissions WHERE permission_id = ?");
        $stmt->execute([$permissionId]);
        $roleCount = $stmt->fetchColumn();
        
        if ($roleCount > 0) {
            http_response_code(400);
            echo json_encode(['error' => '该权限被角色使用，无法删除']);
            return;
        }
        
        $stmt = $db->prepare("DELETE FROM permissions WHERE id = ?");
        $result = $stmt->execute([$permissionId]);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => '权限删除成功'
            ]);
        } else {
            echo json_encode(['error' => '权限删除失败']);
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
}
?>