<?php
// 支付接口文件
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 引入必要文件
require_once '../includes/Database.php';
require_once '../includes/Config.php';
require_once '../includes/Logger.php';
require_once '../includes/Security.php';
require_once '../includes/PaymentManager.php';

// 初始化数据库连接
$database = new Database();
$db = $database->getConnection();

// 初始化日志记录器
$logger = new Logger($db);

// 初始化安全管理器
$security = new SecurityManager($db);

// 初始化支付管理器
$paymentManager = new PaymentManager($db, $logger);

// 获取请求方法和路径
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// 移除项目前缀
array_shift($path_parts); // api
array_shift($path_parts); // payment

$action = $path_parts[0] ?? '';
$param = $path_parts[1] ?? '';

// 获取请求数据
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

try {
    switch ($action) {
        case 'methods':
            // 获取支付方式列表
            handlePaymentMethods();
            break;
            
        case 'create':
            // 创建支付订单
            handleCreatePayment();
            break;
            
        case 'query':
            // 查询支付状态
            handleQueryPayment($param);
            break;
            
        case 'cancel':
            // 取消支付
            handleCancelPayment($param);
            break;
            
        case 'refund':
            // 申请退款
            handleRefundPayment();
            break;
            
        case 'refund-query':
            // 查询退款状态
            handleQueryRefund($param);
            break;
            
        case 'alipay':
            // 支付宝相关接口
            handleAlipayCallback($param);
            break;
            
        case 'wechat':
            // 微信支付相关接口
            handleWechatCallback($param);
            break;
            
        case 'logs':
            // 获取支付日志
            handlePaymentLogs();
            break;
            
        default:
            sendErrorResponse('Invalid action', 400);
            break;
    }
} catch (Exception $e) {
    $logger->error("Payment API Error: " . $e->getMessage(), [
        'action' => $action,
        'param' => $param,
        'input' => $input,
        'error' => $e->getTraceAsString()
    ]);
    sendErrorResponse($e->getMessage(), 500);
}

/**
 * 获取支付方式列表
 */
function handlePaymentMethods() {
    global $db;
    
    $sql = "SELECT * FROM payment_methods WHERE is_active = 1 ORDER BY sort_order ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 过滤敏感信息
    foreach ($methods as &$method) {
        unset($method['created_at'], $method['updated_at']);
    }
    
    sendSuccessResponse([
        'methods' => $methods,
        'total' => count($methods)
    ]);
}

/**
 * 创建支付订单
 */
function handleCreatePayment() {
    global $db, $security, $paymentManager, $input;
    
    // 验证必填字段
    $required = ['order_id', 'payment_method', 'amount'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            sendErrorResponse("Missing required field: {$field}", 400);
        }
    }
    
    $orderId = $input['order_id'];
    $paymentMethod = $input['payment_method'];
    $amount = floatval($input['amount']);
    
    // 验证支付方式
    if (!in_array($paymentMethod, ['alipay', 'wechat', 'balance'])) {
        sendErrorResponse('Invalid payment method', 400);
    }
    
    // 验证订单
    $order = $db->prepare("SELECT * FROM orders WHERE id = ? AND status = 'pending'");
    $order->execute([$orderId]);
    $orderData = $order->fetch(PDO::FETCH_ASSOC);
    
    if (!$orderData) {
        sendErrorResponse('Order not found or not payable', 404);
    }
    
    // 验证金额
    if (abs($amount - $orderData['amount']) > 0.01) {
        sendErrorResponse('Payment amount does not match order amount', 400);
    }
    
    // 创建支付记录
    $paymentData = [
        'order_id' => $orderId,
        'payment_method' => $paymentMethod,
        'amount' => $amount,
        'subject' => $input['subject'] ?? '订单支付 #' . $orderId,
        'client_ip' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ];
    
    $payment = $paymentManager->createPayment($paymentData);
    
    if (!$payment) {
        sendErrorResponse('Failed to create payment', 500);
    }
    
    // 根据支付方式处理
    switch ($paymentMethod) {
        case 'alipay':
            $result = $paymentManager->processAlipayPayment($payment['id']);
            break;
        case 'wechat':
            $result = $paymentManager->processWechatPayment($payment['id']);
            break;
        case 'balance':
            $result = $paymentManager->processBalancePayment($payment['id']);
            break;
        default:
            sendErrorResponse('Unsupported payment method', 400);
    }
    
    sendSuccessResponse([
        'payment_id' => $payment['id'],
        'out_trade_no' => $payment['out_trade_no'],
        'payment_url' => isset($result['payment_url']) ? $result['payment_url'] : null,
        'qr_code' => isset($result['qr_code']) ? $result['qr_code'] : null,
        'form_data' => isset($result['form_data']) ? $result['form_data'] : null,
        'expires_in' => isset($result['expires_in']) ? $result['expires_in'] : 900
    ]);
}

/**
 * 查询支付状态
 */
function handleQueryPayment($paymentId) {
    global $paymentManager;
    
    if (empty($paymentId)) {
        sendErrorResponse('Missing payment ID', 400);
    }
    
    $result = $paymentManager->queryPayment($paymentId);
    
    if (!$result) {
        sendErrorResponse('Payment not found', 404);
    }
    
    sendSuccessResponse($result);
}

/**
 * 取消支付
 */
function handleCancelPayment($paymentId) {
    global $paymentManager;
    
    if (empty($paymentId)) {
        sendErrorResponse('Missing payment ID', 400);
    }
    
    $result = $paymentManager->cancelPayment($paymentId);
    
    if (!$result) {
        sendErrorResponse('Failed to cancel payment', 500);
    }
    
    sendSuccessResponse(['message' => 'Payment cancelled successfully']);
}

/**
 * 申请退款
 */
function handleRefundPayment() {
    global $paymentManager, $input;
    
    // 验证必填字段
    $required = ['payment_id', 'refund_amount', 'refund_reason'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            sendErrorResponse("Missing required field: {$field}", 400);
        }
    }
    
    $paymentId = $input['payment_id'];
    $refundAmount = floatval($input['refund_amount']);
    $refundReason = $input['refund_reason'];
    
    $refundData = [
        'payment_id' => $paymentId,
        'refund_amount' => $refundAmount,
        'refund_reason' => $refundReason,
        'operator_id' => $input['operator_id'] ?? null,
        'operator_name' => $input['operator_name'] ?? 'System'
    ];
    
    $result = $paymentManager->createRefund($refundData);
    
    if (!$result) {
        sendErrorResponse('Failed to create refund', 500);
    }
    
    sendSuccessResponse([
        'refund_id' => $result['id'],
        'refund_no' => $result['refund_no'],
        'status' => $result['status']
    ]);
}

/**
 * 查询退款状态
 */
function handleQueryRefund($refundId) {
    global $paymentManager;
    
    if (empty($refundId)) {
        sendErrorResponse('Missing refund ID', 400);
    }
    
    $result = $paymentManager->queryRefund($refundId);
    
    if (!$result) {
        sendErrorResponse('Refund not found', 404);
    }
    
    sendSuccessResponse($result);
}

/**
 * 处理支付宝回调
 */
function handleAlipayCallback($type) {
    global $paymentManager, $logger;
    
    $rawData = file_get_contents('php://input');
    $logger->info("Alipay callback received", [
        'type' => $type,
        'raw_data' => $rawData,
        'get' => $_GET,
        'post' => $_POST
    ]);
    
    // 记录回调
    $callbackId = $paymentManager->recordCallback('alipay', 'payment', $rawData, $_SERVER['REMOTE_ADDR']);
    
    try {
        if ($type === 'notify') {
            // 异步通知
            $result = $paymentManager->handleAlipayNotify($_POST);
            if ($result) {
                echo 'success';
            } else {
                echo 'fail';
            }
        } elseif ($type === 'return') {
            // 同步返回
            $result = $paymentManager->handleAlipayReturn($_GET);
            if ($result['success']) {
                // 跳转到成功页面
                header('Location: /payment/success?payment_id=' . $result['payment_id']);
            } else {
                // 跳转到失败页面
                header('Location: /payment/failed?error=' . urlencode($result['message']));
            }
            exit;
        }
    } catch (Exception $e) {
        $logger->error("Alipay callback error: " . $e->getMessage(), [
            'callback_id' => $callbackId,
            'error' => $e->getTraceAsString()
        ]);
        echo 'fail';
    }
}

/**
 * 处理微信支付回调
 */
function handleWechatCallback($type) {
    global $paymentManager, $logger;
    
    $rawData = file_get_contents('php://input');
    $logger->info("Wechat callback received", [
        'type' => $type,
        'raw_data' => $rawData,
        'get' => $_GET,
        'post' => $_POST
    ]);
    
    // 记录回调
    $callbackId = $paymentManager->recordCallback('wechat', 'payment', $rawData, $_SERVER['REMOTE_ADDR']);
    
    try {
        if ($type === 'notify') {
            // 支付结果通知
            $result = $paymentManager->handleWechatNotify($rawData);
            if ($result) {
                echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
            } else {
                echo '<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[处理失败]]></return_msg></xml>';
            }
        }
    } catch (Exception $e) {
        $logger->error("Wechat callback error: " . $e->getMessage(), [
            'callback_id' => $callbackId,
            'error' => $e->getTraceAsString()
        ]);
        echo '<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[系统错误]]></return_msg></xml>';
    }
}

/**
 * 获取支付日志
 */
function handlePaymentLogs() {
    global $db, $input;
    
    $page = max(1, intval($input['page'] ?? 1));
    $limit = min(100, max(10, intval($input['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    
    $filters = [];
    $params = [];
    
    // 构建查询条件
    if (!empty($input['payment_id'])) {
        $filters[] = "pl.payment_id = ?";
        $params[] = $input['payment_id'];
    }
    
    if (!empty($input['action'])) {
        $filters[] = "pl.action = ?";
        $params[] = $input['action'];
    }
    
    if (!empty($input['level'])) {
        $filters[] = "pl.level = ?";
        $params[] = $input['level'];
    }
    
    if (!empty($input['start_date'])) {
        $filters[] = "pl.created_at >= ?";
        $params[] = $input['start_date'] . ' 00:00:00';
    }
    
    if (!empty($input['end_date'])) {
        $filters[] = "pl.created_at <= ?";
        $params[] = $input['end_date'] . ' 23:59:59';
    }
    
    $whereClause = $filters ? 'WHERE ' . implode(' AND ', $filters) : '';
    
    // 查询总数
    $countSql = "SELECT COUNT(*) FROM payment_logs pl {$whereClause}";
    $countStmt = $db->prepare($countSql);
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();
    
    // 查询数据
    $sql = "SELECT pl.*, p.out_trade_no, p.payment_method 
            FROM payment_logs pl 
            LEFT JOIN payments p ON pl.payment_id = p.id 
            {$whereClause} 
            ORDER BY pl.created_at DESC 
            LIMIT {$limit} OFFSET {$offset}";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 格式化数据
    foreach ($logs as &$log) {
        if ($log['data']) {
            $log['data'] = json_decode($log['data'], true);
        }
    }
    
    sendSuccessResponse([
        'logs' => $logs,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
}

/**
 * 发送成功响应
 */
function sendSuccessResponse($data = [], $message = 'Success') {
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => $message,
        'data' => $data,
        'timestamp' => time()
    ], JSON_PRETTY_PRINT);
    exit;
}

/**
 * 发送错误响应
 */
function sendErrorResponse($message, $code = 400) {
    http_response_code($code);
    echo json_encode([
        'success' => false,
        'message' => $message,
        'code' => $code,
        'timestamp' => time()
    ], JSON_PRETTY_PRINT);
    exit;
}
?>