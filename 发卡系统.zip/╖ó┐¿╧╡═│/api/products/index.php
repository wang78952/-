<?php

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 引入必要的文件
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Config.php';
require_once __DIR__ . '/../../includes/ProductManager.php';
require_once __DIR__ . '/../../includes/Logger.php';
require_once __DIR__ . '/../../includes/CacheManager.php';
require_once __DIR__ . '/../../includes/Response.php';
require_once __DIR__ . '/../../includes/InputValidator.php';
require_once __DIR__ . '/../../helpers.php';

try {
    // 初始化服务
    $database = new Database();
    $db = $database->getConnection();
    $logger = new Logger();
    $cacheManager = new CacheManager();
    $productManager = new ProductManager($db, $logger, $cacheManager);
    $validator = new InputValidator();
    
    // 获取请求方法和路径
    $method = $_SERVER['REQUEST_METHOD'];
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $pathParts = explode('/', trim($path, '/'));
    
    // 解析输入数据
    $input = [];
    if ($method === 'POST' || $method === 'PUT') {
        $input = json_decode(file_get_contents('php://input'), true) ?: [];
    } elseif ($method === 'GET') {
        $input = $_GET;
    }
    
    // 路由分发
    switch ($method) {
        case 'GET':
            handleGetRequest($productManager, $validator, $input, $pathParts);
            break;
        case 'POST':
            handlePostRequest($productManager, $validator, $input, $pathParts);
            break;
        case 'PUT':
            handlePutRequest($productManager, $validator, $input, $pathParts);
            break;
        case 'DELETE':
            handleDeleteRequest($productManager, $validator, $input, $pathParts);
            break;
        default:
            Response::error('Method not allowed', 405);
    }
    
} catch (Exception $e) {
    $logger->error("Products API Error: " . $e->getMessage(), [
        'error' => $e->getTraceAsString()
    ]);
    Response::error('Internal server error', 500);
}

/**
 * 处理GET请求
 */
function handleGetRequest($productManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'list';
    
    switch ($action) {
        case 'list':
            handleProductList($productManager, $validator, $input);
            break;
        case 'detail':
            handleProductDetail($productManager, $validator, $input);
            break;
        case 'search':
            handleProductSearch($productManager, $validator, $input);
            break;
        case 'statistics':
            handleProductStatistics($productManager, $validator, $input);
            break;
        case 'categories':
            handleProductCategories($productManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($productManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'create';
    
    switch ($action) {
        case 'create':
            handleCreateProduct($productManager, $validator, $input);
            break;
        case 'batch-create':
            handleBatchCreateProducts($productManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($productManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'update';
    
    switch ($action) {
        case 'update':
            handleUpdateProduct($productManager, $validator, $input);
            break;
        case 'batch-update':
            handleBatchUpdateProducts($productManager, $validator, $input);
            break;
        case 'stock':
            handleUpdateProductStock($productManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($productManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'delete';
    
    switch ($action) {
        case 'delete':
            handleDeleteProduct($productManager, $validator, $input);
            break;
        case 'batch-delete':
            handleBatchDeleteProducts($productManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理产品列表
 */
function handleProductList($productManager, $validator, $input)
{
    try {
        // 验证分页参数
        $rules = [
            'page' => 'optional|integer|min:1',
            'limit' => 'optional|integer|min:1|max:100',
            'category_id' => 'optional|integer',
            'is_active' => 'optional|integer|in:0,1',
            'is_digital' => 'optional|integer|in:0,1',
            'search' => 'optional|string|max:100',
            'min_price' => 'optional|numeric|min:0',
            'max_price' => 'optional|numeric|min:0'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $page = intval($input['page'] ?? 1);
        $limit = intval($input['limit'] ?? 20);
        
        // 构建过滤条件
        $filters = [];
        foreach (['category_id', 'is_active', 'is_digital', 'search', 'min_price', 'max_price'] as $field) {
            if (isset($input[$field])) {
                $filters[$field] = $input[$field];
            }
        }
        
        $result = $productManager->getProductList($filters, $page, $limit);
        
        if ($result === false) {
            Response::error('Failed to get product list', 500);
        }
        
        Response::success($result, 'Product list retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get product list: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理产品详情
 */
function handleProductDetail($productManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $productId = intval($input['id']);
        $product = $productManager->getProduct($productId);
        
        if (!$product) {
            Response::error('Product not found', 404);
        }
        
        Response::success($product, 'Product retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get product: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理产品搜索
 */
function handleProductSearch($productManager, $validator, $input)
{
    try {
        $rules = [
            'q' => 'required|string|max:100',
            'page' => 'optional|integer|min:1',
            'limit' => 'optional|integer|min:1|max:50'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $page = intval($input['page'] ?? 1);
        $limit = intval($input['limit'] ?? 20);
        
        $filters = ['search' => $input['q']];
        $result = $productManager->getProductList($filters, $page, $limit);
        
        if ($result === false) {
            Response::error('Failed to search products', 500);
        }
        
        Response::success($result, 'Products searched successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to search products: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理产品统计
 */
function handleProductStatistics($productManager, $validator, $input)
{
    try {
        $rules = [
            'start_date' => 'optional|date',
            'end_date' => 'optional|date'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $filters = [];
        foreach (['start_date', 'end_date'] as $field) {
            if (isset($input[$field])) {
                $filters[$field] = $input[$field];
            }
        }
        
        $stats = $productManager->getProductStatistics($filters);
        
        if ($stats === false) {
            Response::error('Failed to get product statistics', 500);
        }
        
        Response::success($stats, 'Product statistics retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get product statistics: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理产品分类
 */
function handleProductCategories($productManager, $validator, $input)
{
    try {
        global $db;
        
        $sql = "SELECT c.*, COUNT(p.id) as product_count 
                FROM categories c 
                LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
                GROUP BY c.id 
                ORDER BY c.sort_order ASC, c.name ASC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        Response::success($categories, 'Product categories retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get product categories: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理创建产品
 */
function handleCreateProduct($productManager, $validator, $input)
{
    try {
        $rules = [
            'name' => 'required|string|max:100',
            'description' => 'optional|string|max:1000',
            'category_id' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'original_price' => 'optional|numeric|min:0',
            'stock' => 'optional|integer|min:0',
            'min_stock' => 'optional|integer|min:0',
            'max_stock' => 'optional|integer|min:0',
            'card_type' => 'optional|string|in:text,file,auto',
            'is_digital' => 'optional|integer|in:0,1',
            'is_active' => 'optional|integer|in:0,1',
            'sort_order' => 'optional|integer|min:0',
            'tags' => 'optional|array',
            'specifications' => 'optional|array'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $result = $productManager->createProduct($input);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Product created successfully', 201);
        
    } catch (Exception $e) {
        Response::error('Failed to create product: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理批量创建产品
 */
function handleBatchCreateProducts($productManager, $validator, $input)
{
    try {
        $rules = [
            'products' => 'required|array|max:10',
            'products.*.name' => 'required|string|max:100',
            'products.*.category_id' => 'required|integer|min:1',
            'products.*.price' => 'required|numeric|min:0'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $results = [];
        $errors = [];
        
        foreach ($input['products'] as $index => $productData) {
            $result = $productManager->createProduct($productData);
            if ($result['success']) {
                $results[] = $result;
            } else {
                $errors[] = [
                    'index' => $index,
                    'error' => $result['message']
                ];
            }
        }
        
        Response::success([
            'created' => $results,
            'errors' => $errors,
            'total' => count($input['products']),
            'success_count' => count($results),
            'error_count' => count($errors)
        ], 'Batch product creation completed');
        
    } catch (Exception $e) {
        Response::error('Failed to batch create products: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理更新产品
 */
function handleUpdateProduct($productManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1',
            'name' => 'optional|string|max:100',
            'description' => 'optional|string|max:1000',
            'category_id' => 'optional|integer|min:1',
            'price' => 'optional|numeric|min:0',
            'original_price' => 'optional|numeric|min:0',
            'stock' => 'optional|integer|min:0',
            'min_stock' => 'optional|integer|min:0',
            'max_stock' => 'optional|integer|min:0',
            'card_type' => 'optional|string|in:text,file,auto',
            'is_digital' => 'optional|integer|in:0,1',
            'is_active' => 'optional|integer|in:0,1',
            'sort_order' => 'optional|integer|min:0',
            'tags' => 'optional|array',
            'specifications' => 'optional|array'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $productId = intval($input['id']);
        unset($input['id']);
        
        $result = $productManager->updateProduct($productId, $input);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Product updated successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to update product: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理批量更新产品
 */
function handleBatchUpdateProducts($productManager, $validator, $input)
{
    try {
        $rules = [
            'products' => 'required|array|max:10',
            'products.*.id' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $results = [];
        $errors = [];
        
        foreach ($input['products'] as $index => $productData) {
            $productId = $productData['id'];
            unset($productData['id']);
            
            $result = $productManager->updateProduct($productId, $productData);
            if ($result['success']) {
                $results[] = $result;
            } else {
                $errors[] = [
                    'index' => $index,
                    'id' => $productId,
                    'error' => $result['message']
                ];
            }
        }
        
        Response::success([
            'updated' => $results,
            'errors' => $errors,
            'total' => count($input['products']),
            'success_count' => count($results),
            'error_count' => count($errors)
        ], 'Batch product update completed');
        
    } catch (Exception $e) {
        Response::error('Failed to batch update products: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理更新产品库存
 */
function handleUpdateProductStock($productManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1',
            'quantity' => 'required|integer',
            'operation' => 'optional|string|in:add,subtract,set'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $productId = intval($input['id']);
        $quantity = intval($input['quantity']);
        $operation = $input['operation'] ?? 'add';
        
        $result = $productManager->updateProductStock($productId, $quantity, $operation);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Product stock updated successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to update product stock: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理删除产品
 */
function handleDeleteProduct($productManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $productId = intval($input['id']);
        $result = $productManager->deleteProduct($productId);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Product deleted successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to delete product: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理批量删除产品
 */
function handleBatchDeleteProducts($productManager, $validator, $input)
{
    try {
        $rules = [
            'ids' => 'required|array|max:10',
            'ids.*' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $results = [];
        $errors = [];
        
        foreach ($input['ids'] as $index => $productId) {
            $result = $productManager->deleteProduct($productId);
            if ($result['success']) {
                $results[] = $result;
            } else {
                $errors[] = [
                    'index' => $index,
                    'id' => $productId,
                    'error' => $result['message']
                ];
            }
        }
        
        Response::success([
            'deleted' => $results,
            'errors' => $errors,
            'total' => count($input['ids']),
            'success_count' => count($results),
            'error_count' => count($errors)
        ], 'Batch product deletion completed');
        
    } catch (Exception $e) {
        Response::error('Failed to batch delete products: ' . $e->getMessage(), 500);
    }
}
?>