<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 引入必要的文件
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/SecurityManager.php';
require_once __DIR__ . '/../../includes/functions.php';

// 初始化数据库连接
try {
    $db = new PDO("mysql:host={$db_config['host']};dbname={$db_config['database']};charset=utf8mb4", 
                   $db_config['username'], $db_config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '数据库连接失败']);
    exit;
}

// 初始化安全管理器
$securityManager = new SecurityManager($db);

// 获取请求方法和路径
$method = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));

// 移除 'api/security' 部分
array_shift($pathParts);
array_shift($pathParts);

$action = $pathParts[0] ?? '';

try {
    switch ($action) {
        case 'csrf-token':
            handleCSRFToken($securityManager);
            break;
            
        case 'rate-limit':
            handleRateLimit($securityManager, $method);
            break;
            
        case 'login-protection':
            handleLoginProtection($securityManager, $method);
            break;
            
        case 'audit-logs':
            handleAuditLogs($db, $method);
            break;
            
        case 'security-events':
            handleSecurityEvents($db, $method);
            break;
            
        case 'sensitive-operations':
            handleSensitiveOperations($db, $method);
            break;
            
        case 'ip-lists':
            handleIPLists($db, $method);
            break;
            
        case 'security-configs':
            handleSecurityConfigs($db, $method);
            break;
            
        case 'statistics':
            handleSecurityStatistics($db);
            break;
            
        case 'validate-file':
            handleFileValidation($securityManager);
            break;
            
        case 'encrypt-data':
            handleDataEncryption($securityManager);
            break;
            
        case 'decrypt-data':
            handleDataDecryption($securityManager);
            break;
            
        case 'mask-data':
            handleDataMasking($securityManager);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => '接口不存在']);
            break;
    }
} catch (Exception $e) {
    error_log("Security API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '服务器内部错误']);
}

/**
 * 处理CSRF令牌
 */
function handleCSRFToken($securityManager) {
    $token = $securityManager->generateCSRFToken();
    echo json_encode([
        'success' => true,
        'data' => ['csrf_token' => $token]
    ]);
}

/**
 * 处理限流检查
 */
function handleRateLimit($securityManager, $method) {
    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $identifier = $input['identifier'] ?? $_SERVER['REMOTE_ADDR'];
        $limit = $input['limit'] ?? 100;
        $window = $input['window'] ?? 60;
        
        $allowed = $securityManager->checkRateLimit($identifier, $limit, $window);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'allowed' => $allowed,
                'identifier' => $identifier,
                'limit' => $limit,
                'window' => $window
            ]
        ]);
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => '方法不允许']);
    }
}

/**
 * 处理登录保护
 */
function handleLoginProtection($securityManager, $method) {
    switch ($method) {
        case 'GET':
            $identifier = $_GET['identifier'] ?? '';
            if (empty($identifier)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少标识符']);
                return;
            }
            
            $allowed = $securityManager->checkLoginProtection($identifier);
            echo json_encode([
                'success' => true,
                'data' => [
                    'allowed' => $allowed,
                    'identifier' => $identifier
                ]
            ]);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            $action = $input['action'] ?? '';
            $identifier = $input['identifier'] ?? '';
            $ip = $input['ip'] ?? $_SERVER['REMOTE_ADDR'];
            $userAgent = $input['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'];
            
            if (empty($action) || empty($identifier)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少必要参数']);
                return;
            }
            
            if ($action === 'failure') {
                $securityManager->recordLoginFailure($identifier, $ip, $userAgent);
                echo json_encode(['success' => true, 'message' => '登录失败已记录']);
            } elseif ($action === 'success') {
                $securityManager->recordLoginSuccess($identifier, $ip, $userAgent);
                echo json_encode(['success' => true, 'message' => '登录成功已记录']);
            } else {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '无效的操作类型']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '方法不允许']);
            break;
    }
}

/**
 * 处理审计日志
 */
function handleAuditLogs($db, $method) {
    switch ($method) {
        case 'GET':
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = min(100, max(1, intval($_GET['limit'] ?? 20)));
            $offset = ($page - 1) * $limit;
            
            $filters = [
                'user_id' => $_GET['user_id'] ?? null,
                'action' => $_GET['action'] ?? null,
                'resource' => $_GET['resource'] ?? null,
                'start_date' => $_GET['start_date'] ?? null,
                'end_date' => $_GET['end_date'] ?? null
            ];
            
            $whereConditions = [];
            $params = [];
            
            foreach ($filters as $key => $value) {
                if (!empty($value)) {
                    switch ($key) {
                        case 'start_date':
                            $whereConditions[] = "created_at >= ?";
                            $params[] = $value;
                            break;
                        case 'end_date':
                            $whereConditions[] = "created_at <= ?";
                            $params[] = $value;
                            break;
                        default:
                            $whereConditions[] = "$key = ?";
                            $params[] = $value;
                            break;
                    }
                }
            }
            
            $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
            
            // 获取总数
            $countSql = "SELECT COUNT(*) as total FROM audit_logs $whereClause";
            $countStmt = $db->prepare($countSql);
            $countStmt->execute($params);
            $total = $countStmt->fetch()['total'];
            
            // 获取数据
            $sql = "SELECT * FROM audit_logs $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $db->prepare($sql);
            $params[] = $limit;
            $params[] = $offset;
            $stmt->execute($params);
            $logs = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'logs' => $logs,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            $userId = $input['user_id'] ?? null;
            $action = $input['action'] ?? '';
            $resource = $input['resource'] ?? '';
            $details = $input['details'] ?? [];
            
            if (empty($action) || empty($resource)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少必要参数']);
                return;
            }
            
            $sql = "INSERT INTO audit_logs (user_id, action, resource, details, ip_address, user_agent, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, NOW())";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                $userId,
                $action,
                $resource,
                json_encode($details),
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            
            echo json_encode(['success' => true, 'message' => '审计日志记录成功']);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '方法不允许']);
            break;
    }
}

/**
 * 处理安全事件
 */
function handleSecurityEvents($db, $method) {
    switch ($method) {
        case 'GET':
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = min(100, max(1, intval($_GET['limit'] ?? 20)));
            $offset = ($page - 1) * $limit;
            
            $filters = [
                'event_type' => $_GET['event_type'] ?? null,
                'severity' => $_GET['severity'] ?? null,
                'status' => $_GET['status'] ?? null,
                'start_date' => $_GET['start_date'] ?? null,
                'end_date' => $_GET['end_date'] ?? null
            ];
            
            $whereConditions = [];
            $params = [];
            
            foreach ($filters as $key => $value) {
                if (!empty($value)) {
                    switch ($key) {
                        case 'start_date':
                            $whereConditions[] = "created_at >= ?";
                            $params[] = $value;
                            break;
                        case 'end_date':
                            $whereConditions[] = "created_at <= ?";
                            $params[] = $value;
                            break;
                        default:
                            $whereConditions[] = "$key = ?";
                            $params[] = $value;
                            break;
                    }
                }
            }
            
            $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
            
            // 获取总数
            $countSql = "SELECT COUNT(*) as total FROM security_events $whereClause";
            $countStmt = $db->prepare($countSql);
            $countStmt->execute($params);
            $total = $countStmt->fetch()['total'];
            
            // 获取数据
            $sql = "SELECT * FROM security_events $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $db->prepare($sql);
            $params[] = $limit;
            $params[] = $offset;
            $stmt->execute($params);
            $events = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'events' => $events,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            $eventType = $input['event_type'] ?? '';
            $severity = $input['severity'] ?? 'medium';
            $title = $input['title'] ?? '';
            $description = $input['description'] ?? '';
            $details = $input['details'] ?? [];
            
            if (empty($eventType) || empty($title)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少必要参数']);
                return;
            }
            
            $sql = "INSERT INTO security_events (event_type, severity, title, description, source_ip, details, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, NOW())";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                $eventType,
                $severity,
                $title,
                $description,
                $_SERVER['REMOTE_ADDR'] ?? '',
                json_encode($details)
            ]);
            
            echo json_encode(['success' => true, 'message' => '安全事件创建成功']);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '方法不允许']);
            break;
    }
}

/**
 * 处理敏感操作
 */
function handleSensitiveOperations($db, $method) {
    switch ($method) {
        case 'GET':
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = min(100, max(1, intval($_GET['limit'] ?? 20)));
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT * FROM sensitive_operations ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$limit, $offset]);
            $operations = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'data' => ['operations' => $operations]
            ]);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            $userId = $input['user_id'] ?? 0;
            $username = $input['username'] ?? '';
            $operationType = $input['operation_type'] ?? '';
            $operationName = $input['operation_name'] ?? '';
            $targetData = $input['target_data'] ?? [];
            $riskLevel = $input['risk_level'] ?? 'medium';
            
            if (empty($operationType) || empty($operationName)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少必要参数']);
                return;
            }
            
            $sql = "INSERT INTO sensitive_operations (user_id, username, operation_type, operation_name, target_data, risk_level, ip_address, user_agent, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                $userId,
                $username,
                $operationType,
                $operationName,
                json_encode($targetData),
                $riskLevel,
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            
            echo json_encode(['success' => true, 'message' => '敏感操作记录成功']);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '方法不允许']);
            break;
    }
}

/**
 * 处理IP列表
 */
function handleIPLists($db, $method) {
    switch ($method) {
        case 'GET':
            $listType = $_GET['list_type'] ?? '';
            $isActive = $_GET['is_active'] ?? '';
            
            $whereConditions = [];
            $params = [];
            
            if (!empty($listType)) {
                $whereConditions[] = "list_type = ?";
                $params[] = $listType;
            }
            
            if ($isActive !== '') {
                $whereConditions[] = "is_active = ?";
                $params[] = $isActive;
            }
            
            $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
            
            $sql = "SELECT * FROM ip_lists $whereClause ORDER BY created_at DESC";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $ipLists = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'data' => ['ip_lists' => $ipLists]
            ]);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            $ipAddress = $input['ip_address'] ?? '';
            $listType = $input['list_type'] ?? '';
            $reason = $input['reason'] ?? '';
            $expiresAt = $input['expires_at'] ?? null;
            
            if (empty($ipAddress) || empty($listType)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少必要参数']);
                return;
            }
            
            $sql = "INSERT INTO ip_lists (ip_address, list_type, reason, expires_at, created_at) 
                    VALUES (?, ?, ?, ?, NOW())";
            $stmt = $db->prepare($sql);
            $stmt->execute([$ipAddress, $listType, $reason, $expiresAt]);
            
            echo json_encode(['success' => true, 'message' => 'IP列表项添加成功']);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '方法不允许']);
            break;
    }
}

/**
 * 处理安全配置
 */
function handleSecurityConfigs($db, $method) {
    switch ($method) {
        case 'GET':
            $sql = "SELECT * FROM security_configs ORDER BY config_key";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            $configs = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'data' => ['configs' => $configs]
            ]);
            break;
            
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            $configKey = $input['config_key'] ?? '';
            $configValue = $input['config_value'] ?? '';
            
            if (empty($configKey)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => '缺少配置键']);
                return;
            }
            
            $sql = "UPDATE security_configs SET config_value = ?, updated_at = NOW() WHERE config_key = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$configValue, $configKey]);
            
            echo json_encode(['success' => true, 'message' => '配置更新成功']);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => '方法不允许']);
            break;
    }
}

/**
 * 处理安全统计
 */
function handleSecurityStatistics($db) {
    $dateRange = intval($_GET['date_range'] ?? 7); // 默认7天
    
    try {
        $sql = "CALL GetSecurityStats(?)";
        $stmt = $db->prepare($sql);
        $stmt->execute([$dateRange]);
        
        $statistics = [];
        do {
            $result = $stmt->fetchAll();
            if (!empty($result)) {
                $type = $result[0]['type'];
                $statistics[$type] = $result[0];
            }
        } while ($stmt->nextRowset());
        
        echo json_encode([
            'success' => true,
            'data' => ['statistics' => $statistics]
        ]);
    } catch (Exception $e) {
        error_log("Security Statistics Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => '获取统计信息失败']);
    }
}

/**
 * 处理文件验证
 */
function handleFileValidation($securityManager) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => '方法不允许']);
        return;
    }
    
    if (!isset($_FILES['file'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => '没有上传文件']);
        return;
    }
    
    $allowedTypes = $_POST['allowed_types'] ?? [];
    $maxSize = intval($_POST['max_size'] ?? 5242880); // 默认5MB
    
    $errors = $securityManager->validateFileUpload($_FILES['file'], $allowedTypes, $maxSize);
    
    if (empty($errors)) {
        echo json_encode(['success' => true, 'message' => '文件验证通过']);
    } else {
        echo json_encode(['success' => false, 'message' => '文件验证失败', 'errors' => $errors]);
    }
}

/**
 * 处理数据加密
 */
function handleDataEncryption($securityManager) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => '方法不允许']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $data = $input['data'] ?? '';
    $key = $input['key'] ?? null;
    
    if (empty($data)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => '缺少要加密的数据']);
        return;
    }
    
    $encrypted = $securityManager->encrypt($data, $key);
    
    echo json_encode([
        'success' => true,
        'data' => ['encrypted_data' => $encrypted]
    ]);
}

/**
 * 处理数据解密
 */
function handleDataDecryption($securityManager) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => '方法不允许']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $encryptedData = $input['encrypted_data'] ?? '';
    $key = $input['key'] ?? null;
    
    if (empty($encryptedData)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => '缺少要解密的数据']);
        return;
    }
    
    $decrypted = $securityManager->decrypt($encryptedData, $key);
    
    if ($decrypted === false) {
        echo json_encode(['success' => false, 'message' => '解密失败']);
    } else {
        echo json_encode([
            'success' => true,
            'data' => ['decrypted_data' => $decrypted]
        ]);
    }
}

/**
 * 处理数据脱敏
 */
function handleDataMasking($securityManager) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => '方法不允许']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $data = $input['data'] ?? [];
    $type = $input['type'] ?? 'default';
    
    if (empty($data)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => '缺少要脱敏的数据']);
        return;
    }
    
    $maskedData = $securityManager->maskSensitiveData($data, $type);
    
    echo json_encode([
        'success' => true,
        'data' => ['masked_data' => $maskedData]
    ]);
}