<?php
/**
 * 代理推广数据分析API接口
 * 提供代理实时推广数据看板所需的各种数据接口
 * 支持访问量、转化量、佣金明细等数据查询
 */

// 简单的 API 响应类实现
class ApiResponse {
    public static function success($data) {
        echo json_encode(array(
            'success' => true,
            'data' => $data
        ));
        exit;
    }
    
    public static function error($message, $code = 400) {
        http_response_code($code);
        echo json_encode(array(
            'success' => false,
            'error' => $message,
            'code' => $code
        ));
        exit;
    }
}

// 简单的代理认证类实现
class ProxyAuth {
    private $agentId;
    
    public function authenticate() {
        // 简单的会话验证逻辑
        session_start();
        if (isset($_SESSION['agent_id'])) {
            $this->agentId = $_SESSION['agent_id'];
            return array('success' => true);
        }
        return array('success' => false, 'error' => '代理认证失败');
    }
    
    public function getCurrentAgentId() {
        return $this->agentId ?: 1; // 默认返回ID为1
    }
}

// 验证代理身份
$proxyAuth = new ProxyAuth();

// 代理认证检查
$authResult = $proxyAuth->authenticate();

if (!$authResult['success']) {
    ApiResponse::error($authResult['error'], 401);
    exit;
}

// 获取当前登录代理ID
$currentAgentId = $proxyAuth->getCurrentAgentId();

// 检查权限（代理只能查看自己的数据）
if (!isset($_GET['action'])) {
    ApiResponse::error('缺少操作参数', 400);
    exit;
}

// 获取操作类型
$action = $_GET['action'];

// 简单的代理推广分析服务实现
class AgentPromotionAnalytics {
    public function getAgentPromotionOverview($agentId, $dateRange, $startDate, $endDate) {
        return array(
            'total_visits' => 150,
            'total_conversions' => 25,
            'conversion_rate' => '16.67%',
            'total_commission' => 500.00,
            'date_range' => $dateRange
        );
    }
    
    public function getPromotionTrend($agentId, $dateRange, $startDate, $endDate) {
        return array(
            'trend_data' => array(
                array('date' => date('Y-m-d', strtotime('-6 days')), 'visits' => 20, 'conversions' => 3),
                array('date' => date('Y-m-d', strtotime('-5 days')), 'visits' => 25, 'conversions' => 4),
                array('date' => date('Y-m-d', strtotime('-4 days')), 'visits' => 18, 'conversions' => 2),
                array('date' => date('Y-m-d', strtotime('-3 days')), 'visits' => 22, 'conversions' => 5),
                array('date' => date('Y-m-d', strtotime('-2 days')), 'visits' => 30, 'conversions' => 6),
                array('date' => date('Y-m-d', strtotime('-1 day')), 'visits' => 25, 'conversions' => 3),
                array('date' => date('Y-m-d'), 'visits' => 10, 'conversions' => 2)
            )
        );
    }
    
    public function getCommissionDetails($agentId, $filters, $page, $pageSize) {
        return array(
            'total' => 5,
            'page' => $page,
            'page_size' => $pageSize,
            'data' => array(
                array('id' => 1, 'order_id' => 'ORD123', 'amount' => 100.00, 'commission' => 20.00, 'date' => date('Y-m-d H:i:s', strtotime('-2 days')), 'status' => 'completed'),
                array('id' => 2, 'order_id' => 'ORD124', 'amount' => 150.00, 'commission' => 30.00, 'date' => date('Y-m-d H:i:s', strtotime('-3 days')), 'status' => 'completed'),
                array('id' => 3, 'order_id' => 'ORD125', 'amount' => 200.00, 'commission' => 40.00, 'date' => date('Y-m-d H:i:s', strtotime('-4 days')), 'status' => 'completed'),
                array('id' => 4, 'order_id' => 'ORD126', 'amount' => 80.00, 'commission' => 16.00, 'date' => date('Y-m-d H:i:s', strtotime('-5 days')), 'status' => 'pending'),
                array('id' => 5, 'order_id' => 'ORD127', 'amount' => 120.00, 'commission' => 24.00, 'date' => date('Y-m-d H:i:s', strtotime('-6 days')), 'status' => 'completed')
            )
        );
    }
    
    public function getPageEffectiveness($agentId, $dateRange) {
        return array(
            'page_data' => array(
                array('page_name' => '推广主页', 'visits' => 80, 'conversion_rate' => '20%', 'avg_time' => '2:30'),
                array('page_name' => '产品详情页', 'visits' => 120, 'conversion_rate' => '15%', 'avg_time' => '3:45'),
                array('page_name' => '结算页面', 'visits' => 40, 'conversion_rate' => '60%', 'avg_time' => '5:15')
            ),
            'date_range' => $dateRange
        );
    }
    
    public function getGeographicDistribution($agentId, $dateRange) {
        return array(
            'geo_data' => array(
                array('region' => '北京', 'visits' => 40, 'conversions' => 8),
                array('region' => '上海', 'visits' => 35, 'conversions' => 7),
                array('region' => '广州', 'visits' => 30, 'conversions' => 5),
                array('region' => '深圳', 'visits' => 25, 'conversions' => 4),
                array('region' => '其他', 'visits' => 20, 'conversions' => 1)
            ),
            'date_range' => $dateRange
        );
    }
}

// 创建分析服务实例
$analyticsService = new AgentPromotionAnalytics();

// 根据操作类型处理请求
try {
    switch ($action) {
        case 'overview':
            // 获取代理推广总览
            $dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '7days';
            $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
            $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
            
            $result = $analyticsService->getAgentPromotionOverview(
                $currentAgentId, 
                $dateRange,
                $startDate,
                $endDate
            );
            
            ApiResponse::success($result);
            break;
            
        case 'promotion_trend':
            // 获取推广趋势数据
            $dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '7days';
            $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
            $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
            
            $result = $analyticsService->getPromotionTrend(
                $currentAgentId, 
                $dateRange,
                $startDate,
                $endDate
            );
            
            ApiResponse::success($result);
            break;
            
        case 'commission_details':
            // 获取佣金明细
            $filters = array();
            
            if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
                $filters['start_date'] = $_GET['start_date'];
                $filters['end_date'] = $_GET['end_date'];
            }
            
            if (isset($_GET['status'])) {
                $filters['status'] = $_GET['status'];
            }
            
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $pageSize = isset($_GET['page_size']) ? (int)$_GET['page_size'] : 20;
            
            $result = $analyticsService->getCommissionDetails(
                $currentAgentId, 
                $filters,
                $page,
                $pageSize
            );
            
            ApiResponse::success($result);
            break;
            
        case 'page_effectiveness':
            // 获取页面效果分析
            $dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '30days';
            
            $result = $analyticsService->getPageEffectiveness(
                $currentAgentId, 
                $dateRange
            );
            
            ApiResponse::success($result);
            break;
            
        case 'geographic_distribution':
            // 获取地域分布数据
            $dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '30days';
            
            $result = $analyticsService->getGeographicDistribution(
                $currentAgentId, 
                $dateRange
            );
            
            ApiResponse::success($result);
            break;
            
        case 'device_statistics':
            // 获取设备统计数据
            $dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '30days';
            
            $result = $analyticsService->getDeviceStatistics(
                $currentAgentId, 
                $dateRange
            );
            
            ApiResponse::success($result);
            break;
            
        case 'export_data':
            // 导出数据功能
            if (!isset($_GET['export_type'])) {
                ApiResponse::error('缺少导出类型参数', 400);
                exit;
            }
            
            $exportType = $_GET['export_type'];
            
            // 检查是否为有效的导出类型
            $validExportTypes = array('commission_details', 'promotion_trend', 'page_effectiveness');
            
            if (!in_array($exportType, $validExportTypes)) {
                ApiResponse::error('无效的导出类型', 400);
                exit;
            }
            
            // 创建导出服务实例
            $exportService = new Business\DataExportService();
            
            // 设置导出参数
            $exportParams = array(
                'agent_id' => $currentAgentId,
                'export_type' => $exportType,
                'filters' => $_GET
            );
            
            // 执行导出
            $exportResult = $exportService->exportAgentData($exportParams);
            
            if ($exportResult['success']) {
                // 设置下载响应头
                header('Content-Type: application/vnd.ms-excel');
                header('Content-Disposition: attachment; filename="' . $exportResult['filename'] . '"');
                header('Content-Length: ' . strlen($exportResult['content']));
                header('Cache-Control: no-cache');
                
                // 输出文件内容
                echo $exportResult['content'];
                exit;
            } else {
                ApiResponse::error($exportResult['error'], 500);
            }
            break;
            
        default:
            ApiResponse::error('无效的操作类型', 400);
            break;
    }
} catch (Exception $e) {
    // 记录错误日志
    $logger->error("代理推广数据分析API错误: " . $e->getMessage() . ", 代理ID: " . $currentAgentId);
    
    // 返回错误响应
    ApiResponse::error('服务器内部错误', 500);
}