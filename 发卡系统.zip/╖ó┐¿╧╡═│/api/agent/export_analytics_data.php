<?php
/**
 * 代理推广数据分析数据导出API
 * 支持将访问量、转化量、佣金明细等数据导出为CSV或Excel格式
 */

// 确保脚本不会超时
set_time_limit(300);
ini_set('memory_limit', '256M');

// 引入核心功能
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_once dirname(__DIR__, 2) . '/includes/auth/agent_auth.php';
require_once dirname(__DIR__, 2) . '/includes/business/AgentPromotionAnalytics.php';

// 验证代理身份
// 使用正确的代理认证方法
$proxyAuth = new Auth\ProxyAuth();
$authResult = $proxyAuth->authenticate();
if (!$authResult['success']) {
    json_response(['status' => 'error', 'message' => '未授权访问'], 401);
}
$agent_id = $authResult['agent_id'] ?? null;

// 处理请求参数
$params = $_GET;

// 验证导出请求
if (!isset($params['type']) || !in_array($params['type'], ['clicks', 'registrations', 'orders', 'commission'])) {
    json_response(['status' => 'error', 'message' => '无效的导出类型'], 400);
}

// 验证导出格式
$format = isset($params['format']) && $params['format'] === 'excel' ? 'excel' : 'csv';

// 验证时间范围
$date_range = validateDateRange($params);
if (!$date_range) {
    json_response(['status' => 'error', 'message' => '无效的日期范围'], 400);
}

// 创建数据分析服务实例
// 确保 AgentPromotionAnalytics 类正确实例化
$analytics_service = new AgentPromotionAnalytics();

// 导出处理
$export_result = processExport($analytics_service, $agent_id, $params['type'], $format, $date_range);

if ($export_result === false) {
    json_response(['status' => 'error', 'message' => '数据导出失败'], 500);
}

/**
 * 处理数据导出
 * 
 * @param AgentPromotionAnalytics $analytics_service 数据分析服务
 * @param int $agent_id 代理ID
 * @param string $type 导出类型
 * @param string $format 导出格式
 * @param array $date_range 日期范围
 * @return bool 导出结果
 */
function processExport($analytics_service, $agent_id, $type, $format, $date_range) {
    try {
        // 获取导出数据
        $export_data = getDataByType($analytics_service, $agent_id, $type, $date_range);
        
        if (empty($export_data)) {
            json_response(['status' => 'error', 'message' => '没有数据可供导出'], 404);
        }
        
        // 生成导出文件
        if ($format === 'excel') {
            return exportToExcel($export_data, $type, $date_range);
        } else {
            return exportToCSV($export_data, $type, $date_range);
        }
    } catch (Exception $e) {
        log_error('导出数据分析失败: ' . $e->getMessage());
        return false;
    }
}

/**
 * 根据类型获取导出数据
 * 
 * @param AgentPromotionAnalytics $analytics_service 数据分析服务
 * @param int $agent_id 代理ID
 * @param string $type 导出类型
 * @param array $date_range 日期范围
 * @return array 导出数据
 */
function getDataByType($analytics_service, $agent_id, $type, $date_range) {
    switch ($type) {
        case 'clicks':
            return getClickData($analytics_service, $agent_id, $date_range);
            
        case 'registrations':
            return getRegistrationData($analytics_service, $agent_id, $date_range);
            
        case 'orders':
            return getOrderData($analytics_service, $agent_id, $date_range);
            
        case 'commission':
            return getCommissionData($analytics_service, $agent_id, $date_range);
            
        default:
            return [];
    }
}

/**
 * 获取点击数据
 * 
 * @param AgentPromotionAnalytics $analytics_service 数据分析服务
 * @param int $agent_id 代理ID
 * @param array $date_range 日期范围
 * @return array 点击数据
 */
function getClickData($analytics_service, $agent_id, $date_range) {
    $params = [
        'date_start' => $date_range['start'],
        'date_end' => $date_range['end'],
        'group_by' => 'date'
    ];
    
    $click_data = $analytics_service->getPromotionTrend($agent_id, 'clicks', $params);
    
    // 格式化导出数据
    $export_data = [];
    foreach ($click_data as $item) {
        $export_data[] = [
            '日期' => $item['period_label'],
            '总点击量' => $item['total_clicks'] ?? 0,
            '独立访客' => $item['unique_clicks'] ?? 0,
            '来源' => $item['source'] ?? '未知',
            '设备类型' => $item['device_type'] ?? '全部',
            '地域' => $item['region'] ?? '全部'
        ];
    }
    
    return $export_data;
}

/**
 * 获取注册数据
 * 
 * @param AgentPromotionAnalytics $analytics_service 数据分析服务
 * @param int $agent_id 代理ID
 * @param array $date_range 日期范围
 * @return array 注册数据
 */
function getRegistrationData($analytics_service, $agent_id, $date_range) {
    $params = [
        'date_start' => $date_range['start'],
        'date_end' => $date_range['end'],
        'group_by' => 'date'
    ];
    
    $registration_data = $analytics_service->getPromotionTrend($agent_id, 'registrations', $params);
    
    // 格式化导出数据
    $export_data = [];
    foreach ($registration_data as $item) {
        $export_data[] = [
            '日期' => $item['period_label'],
            '注册量' => $item['registrations'] ?? 0,
            '转化率' => $item['conversion_rate'] ?? 0,
            '来源' => $item['source'] ?? '未知',
            '设备类型' => $item['device_type'] ?? '全部',
            '地域' => $item['region'] ?? '全部'
        ];
    }
    
    return $export_data;
}

/**
 * 获取订单数据
 * 
 * @param AgentPromotionAnalytics $analytics_service 数据分析服务
 * @param int $agent_id 代理ID
 * @param array $date_range 日期范围
 * @return array 订单数据
 */
function getOrderData($analytics_service, $agent_id, $date_range) {
    $params = [
        'date_start' => $date_range['start'],
        'date_end' => $date_range['end'],
        'page' => 1,
        'page_size' => 10000 // 获取大量数据用于导出
    ];
    
    $order_data = $analytics_service->getOrderDetails($agent_id, $params);
    
    // 格式化导出数据
    $export_data = [];
    foreach ($order_data['orders'] as $item) {
        $export_data[] = [
            '订单编号' => $item['order_id'],
            '下单时间' => date('Y-m-d H:i:s', strtotime($item['order_time'])),
            '订单金额' => $item['order_amount'],
            '佣金金额' => $item['commission_amount'],
            '订单状态' => getOrderStatusText($item['order_status']),
            '客户信息' => $item['customer_info'] ?? '保密',
            '来源' => $item['source'] ?? '未知',
            '推广链接' => $item['promotion_link'] ?? '',
            '产品名称' => $item['product_name'] ?? '未记录'
        ];
    }
    
    return $export_data;
}

/**
 * 获取佣金数据
 * 
 * @param AgentPromotionAnalytics $analytics_service 数据分析服务
 * @param int $agent_id 代理ID
 * @param array $date_range 日期范围
 * @return array 佣金数据
 */
function getCommissionData($analytics_service, $agent_id, $date_range) {
    $params = [
        'date_start' => $date_range['start'],
        'date_end' => $date_range['end'],
        'page' => 1,
        'page_size' => 10000 // 获取大量数据用于导出
    ];
    
    $commission_data = $analytics_service->getCommissionDetails($agent_id, $params);
    
    // 格式化导出数据
    $export_data = [];
    foreach ($commission_data['commissions'] as $item) {
        $export_data[] = [
            '佣金ID' => $item['commission_id'],
            '关联订单' => $item['order_id'],
            '产生时间' => date('Y-m-d H:i:s', strtotime($item['created_at'])),
            '结算时间' => $item['settled_at'] ? date('Y-m-d H:i:s', strtotime($item['settled_at'])) : '未结算',
            '佣金金额' => $item['amount'],
            '佣金比例' => $item['commission_rate'] . '%',
            '佣金状态' => getCommissionStatusText($item['status']),
            '客户信息' => $item['customer_info'] ?? '保密',
            '来源' => $item['source'] ?? '未知',
            '备注' => $item['remark'] ?? ''
        ];
    }
    
    return $export_data;
}

/**
 * 导出数据为CSV格式
 * 
 * @param array $data 要导出的数据
 * @param string $type 数据类型
 * @param array $date_range 日期范围
 * @return bool 导出结果
 */
function exportToCSV($data, $type, $date_range) {
    if (empty($data)) {
        return false;
    }
    
    // 获取标题行
    $headers = array_keys(reset($data));
    
    // 生成文件名
    $timestamp = date('YmdHis');
    $type_names = [
        'clicks' => '点击数据',
        'registrations' => '注册数据',
        'orders' => '订单数据',
        'commission' => '佣金明细'
    ];
    $type_name = $type_names[$type] ?? $type;
    $filename = "代理推广{$type_name}_{$date_range['start']}_to_{$date_range['end']}_{$timestamp}.csv";
    
    // 设置CSV标头
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename={$filename}");
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Expires: 0');
    header('Pragma: public');
    
    // 处理UTF-8 BOM以确保Excel正确识别中文
    echo "\xEF\xBB\xBF";
    
    // 打开输出流
    $output = fopen('php://output', 'w');
    if (!$output) {
        return false;
    }
    
    // 写入标题行
    fputcsv($output, $headers);
    
    // 写入数据行
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    // 关闭输出流
    fclose($output);
    
    return true;
}

/**
 * 导出数据为Excel格式
 * 
 * @param array $data 要导出的数据
 * @param string $type 数据类型
 * @param array $date_range 日期范围
 * @return bool 导出结果
 */
function exportToExcel($data, $type, $date_range) {
    if (empty($data)) {
        return false;
    }
    
    // 检查是否支持PHPExcel或PhpSpreadsheet
    $has_excel_support = false;
    
    try {
        // 尝试使用PhpSpreadsheet（较新的库）
        if (file_exists(dirname(__DIR__, 2) . '/vendor/autoload.php')) {
            require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
            
            if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
                $has_excel_support = true;
                return exportWithPhpSpreadsheet($data, $type, $date_range);
            }
        }
    } catch (Exception $e) {
        // 降级到CSV导出
        log_error('Excel导出失败，降级到CSV: ' . $e->getMessage());
    }
    
    // 如果没有Excel支持，降级到CSV
    return exportToCSV($data, $type, $date_range);
}

/**
 * 使用PhpSpreadsheet导出数据为Excel格式
 * 
 * @param array $data 要导出的数据
 * @param string $type 数据类型
 * @param array $date_range 日期范围
 * @return bool 导出结果
 */
function exportWithPhpSpreadsheet($data, $type, $date_range) {
    try {
        // 创建新的电子表格对象
        // 动态创建对象以避免类型错误
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        
        // 获取标题行
        $headers = array_keys(reset($data));
        
        // 设置标题行
        $col_index = 1;
        foreach ($headers as $header) {
            $sheet->setCellValueByColumnAndRow($col_index++, 1, $header);
        }
        
        // 格式化标题行
        $header_style = [
            'font' => [
                'bold' => true,
                'color' => ['argb' => 'FFFFFF']
            ],
            'fill' => [
                'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                'startColor' => ['argb' => '1890FF']
            ],
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            ]
        ];
        
        $header_range = 'A1:' . chr(64 + count($headers)) . '1';
        $sheet->getStyle($header_range)->applyFromArray($header_style);
        
        // 自动调整列宽
        foreach (range('A', chr(64 + count($headers))) as $column) {
            $sheet->getColumnDimension($column)->setAutoSize(true);
        }
        
        // 写入数据行
        $row_index = 2;
        foreach ($data as $row) {
            $col_index = 1;
            foreach ($row as $cell_value) {
                $sheet->setCellValueByColumnAndRow($col_index++, $row_index, $cell_value);
            }
            $row_index++;
        }
        
        // 添加汇总信息
        $summary_row = $row_index + 2;
        $sheet->setCellValue('A' . $summary_row, '数据汇总');
        $sheet->getStyle('A' . $summary_row)->getFont()->setBold(true);
        
        // 生成文件名
        $timestamp = date('YmdHis');
        $type_names = [
            'clicks' => '点击数据',
            'registrations' => '注册数据',
            'orders' => '订单数据',
            'commission' => '佣金明细'
        ];
        $type_name = $type_names[$type] ?? $type;
        $filename = "代理推广{$type_name}_{$date_range['start']}_to_{$date_range['end']}_{$timestamp}.xlsx";
        
        // 设置下载标头
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename={$filename}");
        header('Cache-Control: max-age=0');
        header('Pragma: public');
        
        // 导出Excel文件
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');
        
        // 释放内存
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);
        
        return true;
    } catch (Exception $e) {
        log_error('使用PhpSpreadsheet导出Excel失败: ' . $e->getMessage());
        return false;
    }
}

/**
 * 验证日期范围参数
 * 
 * @param array $params 请求参数
 * @return array|bool 有效的日期范围或false
 */
function validateDateRange($params) {
    // 默认时间范围：最近30天
    $date_end = date('Y-m-d');
    $date_start = date('Y-m-d', strtotime('-29 days'));
    
    // 如果提供了自定义日期范围，进行验证
    if (isset($params['date_start']) && isset($params['date_end'])) {
        $provided_start = $params['date_start'];
        $provided_end = $params['date_end'];
        
        // 验证日期格式
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $provided_start) || 
            !preg_match('/^\d{4}-\d{2}-\d{2}$/', $provided_end)) {
            return false;
        }
        
        // 验证日期范围有效性
        $start_time = strtotime($provided_start);
        $end_time = strtotime($provided_end);
        $today_time = strtotime(date('Y-m-d'));
        
        if ($start_time > $end_time || $end_time > $today_time || ($end_time - $start_time) > 90 * 24 * 60 * 60) {
            return false;
        }
        
        $date_start = $provided_start;
        $date_end = $provided_end;
    }
    
    return [
        'start' => $date_start,
        'end' => $date_end
    ];
}

/**
 * 获取订单状态文本
 * 
 * @param string $status 订单状态码
 * @return string 状态文本
 */
function getOrderStatusText($status) {
    $status_map = [
        'pending' => '待处理',
        'processing' => '处理中',
        'completed' => '已完成',
        'cancelled' => '已取消',
        'refunded' => '已退款'
    ];
    
    return $status_map[$status] ?? $status;
}

/**
 * 获取佣金状态文本
 * 
 * @param string $status 佣金状态码
 * @return string 状态文本
 */
function getCommissionStatusText($status) {
    $status_map = [
        'pending' => '待结算',
        'approved' => '已批准',
        'paid' => '已支付',
        'rejected' => '已拒绝'
    ];
    
    return $status_map[$status] ?? $status;
}

/**
 * 记录导出日志
 * 
 * @param int $agent_id 代理ID
 * @param string $type 导出类型
 * @param array $date_range 日期范围
 * @param int $record_count 导出记录数
 */
function logExportActivity($agent_id, $type, $date_range, $record_count) {
    global $db, $logger;
    
    try {
        // 记录导出活动
        $db->execute("INSERT INTO agent_export_logs 
            (agent_id, export_type, date_start, date_end, record_count, export_time) 
            VALUES (?, ?, ?, ?, ?, NOW())",
            [$agent_id, $type, $date_range['start'], $date_range['end'], $record_count]
        );
        
        // 记录系统日志
        $logger->info("代理 {$agent_id} 导出 {$type} 数据 {$record_count} 条，时间范围：{$date_range['start']} 至 {$date_range['end']}");
    } catch (Exception $e) {
        // 忽略日志错误，不影响主功能
        error_log("记录导出日志失败: " . $e->getMessage());
    }
}

/**
 * JSON响应辅助函数
 * 
 * @param array $data 响应数据
 * @param int $status_code HTTP状态码
 */
function json_response($data, $status_code = 200) {
    header('Content-Type: application/json');
    http_response_code($status_code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 记录错误日志
 * 
 * @param string $message 错误信息
 */
function log_error($message) {
    global $logger;
    
    if (isset($logger)) {
        $logger->error($message);
    } else {
        error_log($message);
    }
}

// 修复文件末尾的问题
// 确保 $export_data 变量存在
$export_data = [];
// 执行导出
$export_result = processExport($analytics_service, $agent_id, $params['type'], $format, $date_range);

if (!$export_result) {
    json_response(['status' => 'error', 'message' => '数据导出失败'], 500);
}

// 记录导出活动 - 只在CSV导出时执行，避免重复
if ($format === 'csv' || !$has_excel_support) {
    logExportActivity($agent_id, $params['type'], $date_range, count($export_data));
}

// 导出成功 - 只有在CSV模式下才会执行到这里（Excel模式会直接输出文件）
if ($format === 'csv' || !$has_excel_support) {
    json_response(['status' => 'success', 'message' => '数据导出成功']);
}