<?php
/**
 * 分析数据相关路由配置
 * 提供小程序使用情况和性能监控数据的API接口
 */

// 引入控制器
require_once __DIR__ . '/../controllers/AnalyticsController.php';

$controller = new AnalyticsController();

// 定义路由处理函数
function handleAnalyticsRoutes($path, $request, $method) {
    global $controller;
    
    // 接收小程序分析数据
    if ($path === '/api/analytics/mini-program' && $method === 'POST') {
        return $controller->receiveMiniProgramAnalytics($request);
    }
    
    // 获取小程序使用统计报告
    if ($path === '/api/analytics/mini-program/report' && $method === 'GET') {
        // 这里可以添加权限验证，确保只有管理员可以访问
        return $controller->getMiniProgramReport($request);
    }
    
    // 如果没有匹配的路由，返回null
    return null;
}

// 返回路由处理函数
return 'handleAnalyticsRoutes';