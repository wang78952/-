<?php
require_once __DIR__ . '/../includes/UserCardWallet.php';
require_once __DIR__ . '/../includes/AuthManager.php';
require_once __DIR__ . '/../includes/Response.php';

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 初始化
$authManager = new AuthManager();
$userCardWallet = new UserCardWallet();

// 验证用户身份
$user = $authManager->getCurrentUser();
if (!$user) {
    Response::error('未登录或登录已过期', 401);
}

$userId = $user['id'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    switch ($action) {
        case 'list':
            handleGetWalletCards($userId, $userCardWallet);
            break;
            
        case 'stats':
            handleGetWalletStats($userId, $userCardWallet);
            break;
            
        case 'mark_used':
            handleMarkCardAsUsed($userId, $userCardWallet);
            break;
            
        case 'export':
            handleExportCards($userId, $userCardWallet);
            break;
            
        case 'card_detail':
            handleGetCardDetail($userId, $userCardWallet);
            break;
            
        case 'add_to_repurchase':
            handleAddToRepurchaseList($userId);
            break;
            
        case 'repurchase_list':
            handleGetRepurchaseList($userId);
            break;
            
        case 'activation_guide':
            handleGetActivationGuide();
            break;
            
        case 'record_activation':
            handleRecordActivation($userId);
            break;
            
        default:
            Response::error('无效的操作', 400);
    }
} catch (Exception $e) {
    error_log("User wallet API error: " . $e->getMessage());
    Response::error('服务器内部错误', 500);
}

/**
 * 获取用户卡包列表
 */
function handleGetWalletCards($userId, $userCardWallet) {
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
    $status = isset($_GET['status']) ? $_GET['status'] : '';
    $category = isset($_GET['category']) ? $_GET['category'] : '';
    $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
    
    $filters = array();
    if ($status) $filters['status'] = $status;
    if ($category) $filters['category'] = $category;
    if ($keyword) $filters['keyword'] = $keyword;
    
    $result = $userCardWallet->getUserWalletCards($userId, $filters, $page, $limit);
    
    Response::success('获取成功', $result);
}

/**
 * 获取卡包统计信息
 */
function handleGetWalletStats($userId, $userCardWallet) {
    $stats = $userCardWallet->getWalletStats($userId);
    
    Response::success('获取成功', $stats);
}

/**
 * 标记卡密为已使用
 */
function handleMarkCardAsUsed($userId, $userCardWallet) {
    $walletId = isset($_POST['wallet_id']) ? intval($_POST['wallet_id']) : 0;
    $usageInfo = array(
        'ip' => $_SERVER['REMOTE_ADDR'],
        'device' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
        'notes' => isset($_POST['notes']) ? $_POST['notes'] : ''
    );
    
    if (!$walletId) {
        Response::error('参数错误', 400);
    }
    
    $result = $userCardWallet->markCardAsUsed($userId, $walletId, $usageInfo);
    
    if ($result) {
        Response::success('标记成功');
    } else {
        Response::error('标记失败', 500);
    }
}

/**
 * 导出卡密
 */
function handleExportCards($userId, $userCardWallet) {
    $walletIds = isset($_POST['wallet_ids']) ? $_POST['wallet_ids'] : array();
    
    if (is_string($walletIds)) {
        $walletIds = json_decode($walletIds, true) ? json_decode($walletIds, true) : array();
    }
    
    $result = $userCardWallet->exportCards($userId, $walletIds);
    
    if ($result['success']) {
        // 设置下载头
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $result['filename'] . '"');
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: 0');
        
        // 输出BOM以支持中文
        echo "\xEF\xBB\xBF";
        echo $result['content'];
        exit;
    } else {
        Response::error($result['error'] ?? '导出失败', 500);
    }
}

/**
 * 获取卡密详情
 */
function handleGetCardDetail($userId, $userCardWallet) {
    $walletId = isset($_GET['wallet_id']) ? intval($_GET['wallet_id']) : 0;
    
    if (!$walletId) {
        Response::error('参数错误', 400);
    }
    
    global $database;
    
    $sql = "SELECT * FROM user_wallet_cards WHERE user_id = ? AND id = ?";
    $stmt = $database->prepare($sql);
    $stmt->execute([$userId, $walletId]);
    $card = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$card) {
        Response::error('卡密不存在', 404);
    }
    
    // 获取激活指引
    $guideSql = "SELECT * FROM card_activation_guides WHERE product_id = ? AND is_active = 1 ORDER BY sort_order";
    $guideStmt = $database->prepare($guideSql);
    $guideStmt->execute([$card['product_id']]);
    $guides = $guideStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 处理JSON字段
    foreach ($guides as &$guide) {
        $guide['steps'] = json_decode(isset($guide['steps']) ? $guide['steps'] : '[]', true);
        $guide['common_issues'] = json_decode(isset($guide['common_issues']) ? $guide['common_issues'] : '[]', true);
        $guide['images'] = json_decode(isset($guide['images']) ? $guide['images'] : '[]', true);
    }
    
    $card['activation_guides'] = $guides;
    
    Response::success('获取成功', $card);
}

/**
 * 添加到复购清单
 */
function handleAddToRepurchaseList($userId) {
    $productId = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $reminderType = isset($_POST['reminder_type']) ? $_POST['reminder_type'] : 'none';
    $reminderInterval = isset($_POST['reminder_interval']) ? intval($_POST['reminder_interval']) : 0;
    
    if (!$productId) {
        Response::error('参数错误', 400);
    }
    
    global $database;
    
    // 获取产品信息
    $productSql = "SELECT name, image FROM products WHERE id = ?";
    $productStmt = $database->prepare($productSql);
    $productStmt->execute([$productId]);
    $product = $productStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        Response::error('产品不存在', 404);
    }
    
    // 获取最后订单信息
    $orderSql = "SELECT id, quantity, price FROM orders WHERE user_id = ? AND product_id = ? ORDER BY created_at DESC LIMIT 1";
    $orderStmt = $database->prepare($orderSql);
    $orderStmt->execute([$userId, $productId]);
    $lastOrder = $orderStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$lastOrder) {
        Response::error('未找到购买记录', 400);
    }
    
    // 计算下次提醒日期
    $nextReminderDate = null;
    if ($reminderType !== 'none') {
        $interval = $reminderInterval ?: ($reminderType === 'weekly' ? 7 : 30);
        $nextReminderDate = date('Y-m-d', strtotime("+{$interval} days"));
    }
    
    // 插入或更新复购清单
    $sql = "INSERT INTO user_repurchase_list 
            (user_id, product_id, product_name, product_image, last_order_id, last_quantity, last_price, reminder_type, reminder_interval, next_reminder_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            product_name = VALUES(product_name),
            product_image = VALUES(product_image),
            last_order_id = VALUES(last_order_id),
            last_quantity = VALUES(last_quantity),
            last_price = VALUES(last_price),
            reminder_type = VALUES(reminder_type),
            reminder_interval = VALUES(reminder_interval),
            next_reminder_date = VALUES(next_reminder_date),
            updated_at = CURRENT_TIMESTAMP";
    
    $stmt = $database->prepare($sql);
    $result = $stmt->execute([
        $userId, $productId, $product['name'], $product['image'],
        $lastOrder['id'], $lastOrder['quantity'], $lastOrder['price'],
        $reminderType, $reminderInterval, $nextReminderDate
    ]);
    
    if ($result) {
        Response::success('添加成功');
    } else {
        Response::error('添加失败', 500);
    }
}

/**
 * 获取复购清单
 */
function handleGetRepurchaseList($userId) {
    global $database;
    
    $sql = "SELECT * FROM user_repurchase_list 
            WHERE user_id = ? AND is_active = 1 
            ORDER BY updated_at DESC";
    $stmt = $database->prepare($sql);
    $stmt->execute([$userId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    Response::success('获取成功', $items);
}

/**
 * 获取激活指引
 */
function handleGetActivationGuide() {
    $productId = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
    
    if (!$productId) {
        Response::error('参数错误', 400);
    }
    
    global $database;
    
    $sql = "SELECT * FROM card_activation_guides 
            WHERE product_id = ? AND is_active = 1 
            ORDER BY sort_order";
    $stmt = $database->prepare($sql);
    $stmt->execute([$productId]);
    $guides = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 处理JSON字段
    foreach ($guides as &$guide) {
        $guide['steps'] = json_decode(isset($guide['steps']) ? $guide['steps'] : '[]', true);
        $guide['common_issues'] = json_decode(isset($guide['common_issues']) ? $guide['common_issues'] : '[]', true);
        $guide['images'] = json_decode(isset($guide['images']) ? $guide['images'] : '[]', true);
    }
    
    Response::success('获取成功', $guides);
}

/**
 * 记录激活操作
 */
function handleRecordActivation($userId) {
    $walletCardId = isset($_POST['wallet_card_id']) ? intval($_POST['wallet_card_id']) : 0;
    $cardCode = isset($_POST['card_code']) ? $_POST['card_code'] : '';
    $productId = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $result = isset($_POST['result']) ? $_POST['result'] : 'success';
    $errorMessage = isset($_POST['error_message']) ? $_POST['error_message'] : '';
    
    if (!$walletCardId || !$cardCode || !$productId) {
        Response::error('参数错误', 400);
    }
    
    global $database;
    
    $sql = "INSERT INTO user_card_activations 
            (user_id, wallet_card_id, card_code, product_id, activation_time, activation_ip, activation_device, activation_result, error_message)
            VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, ?)";
    
    $stmt = $database->prepare($sql);
    $success = $stmt->execute([
        $userId, $walletCardId, $cardCode, $productId,
        $_SERVER['REMOTE_ADDR'], isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
        $result, $errorMessage
    ]);
    
    if ($success) {
        Response::success('记录成功');
    } else {
        Response::error('记录失败', 500);
    }
}
?>