<?php
/**
 * 业务指标监控API接口
 * 提供业务指标数据的获取和刷新功能
 */

require_once '../includes/Database.php';
require_once '../includes/Logger.php';
require_once '../includes/AuthManager.php';
require_once '../monitoring/BusinessMetricsMonitor.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

try {
    // 验证用户权限
    session_start();
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('用户未登录');
    }
    
    $auth = new AuthManager();
    $currentUser = $auth->getCurrentUser();
    
    if (!$currentUser || !in_array($currentUser['role'], ['admin', 'business_manager'])) {
        throw new Exception('权限不足');
    }
    
    // 获取请求参数
    $period = $_GET['period'] ?? 'month';
    $validPeriods = ['day', 'week', 'month', 'quarter', 'year'];
    
    if (!in_array($period, $validPeriods)) {
        $period = 'month';
    }
    
    // 初始化业务指标监控器
    $businessMetrics = new BusinessMetricsMonitor();
    
    // 获取指标数据
    $metrics = $businessMetrics->getAllMetrics($period);
    
    // 获取图表数据
    $charts = [
        'cardStatus' => $businessMetrics->getCardStatusChartData($period),
        'revenue' => $businessMetrics->getRevenueChartData($period)
    ];
    
    // 记录API调用日志
    $logger = Logger::getInstance();
    $logger->info('业务指标数据访问', [
        'user_id' => $currentUser['id'],
        'username' => $currentUser['username'],
        'period' => $period,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
    
    // 返回成功响应
    echo json_encode([
        'success' => true,
        'metrics' => $metrics,
        'charts' => $charts,
        'period' => $period,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    // 记录错误日志
    $logger = Logger::getInstance();
    $logger->error('业务指标API错误', [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
        'user_id' => $_SESSION['user_id'] ?? 'unknown',
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
    
    // 返回错误响应
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
}
?>