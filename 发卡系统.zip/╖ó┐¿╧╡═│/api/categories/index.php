<?php

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 引入必要的文件
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Config.php';
require_once __DIR__ . '/../../includes/CategoryManager.php';
require_once __DIR__ . '/../../includes/Logger.php';
require_once __DIR__ . '/../../includes/CacheManager.php';
require_once __DIR__ . '/../../includes/Response.php';
require_once __DIR__ . '/../../includes/InputValidator.php';
require_once __DIR__ . '/../../helpers.php';

try {
    // 初始化服务
    $database = new Database();
    $db = $database->getConnection();
    $logger = new Logger();
    $cacheManager = new CacheManager();
    $categoryManager = new CategoryManager($db, $logger, $cacheManager);
    $validator = new InputValidator();
    
    // 获取请求方法和路径
    $method = $_SERVER['REQUEST_METHOD'];
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $pathParts = explode('/', trim($path, '/'));
    
    // 解析输入数据
    $input = [];
    if ($method === 'POST' || $method === 'PUT') {
        $input = json_decode(file_get_contents('php://input'), true) ?: [];
    } elseif ($method === 'GET') {
        $input = $_GET;
    }
    
    // 路由分发
    switch ($method) {
        case 'GET':
            handleGetRequest($categoryManager, $validator, $input, $pathParts);
            break;
        case 'POST':
            handlePostRequest($categoryManager, $validator, $input, $pathParts);
            break;
        case 'PUT':
            handlePutRequest($categoryManager, $validator, $input, $pathParts);
            break;
        case 'DELETE':
            handleDeleteRequest($categoryManager, $validator, $input, $pathParts);
            break;
        default:
            Response::error('Method not allowed', 405);
    }
    
} catch (Exception $e) {
    $logger->error("Categories API Error: " . $e->getMessage(), [
        'error' => $e->getTraceAsString()
    ]);
    Response::error('Internal server error', 500);
}

/**
 * 处理GET请求
 */
function handleGetRequest($categoryManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'list';
    
    switch ($action) {
        case 'list':
            handleCategoryList($categoryManager, $validator, $input);
            break;
        case 'detail':
            handleCategoryDetail($categoryManager, $validator, $input);
            break;
        case 'tree':
            handleCategoryTree($categoryManager, $validator, $input);
            break;
        case 'search':
            handleCategorySearch($categoryManager, $validator, $input);
            break;
        case 'statistics':
            handleCategoryStatistics($categoryManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($categoryManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'create';
    
    switch ($action) {
        case 'create':
            handleCreateCategory($categoryManager, $validator, $input);
            break;
        case 'batch-create':
            handleBatchCreateCategories($categoryManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($categoryManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'update';
    
    switch ($action) {
        case 'update':
            handleUpdateCategory($categoryManager, $validator, $input);
            break;
        case 'batch-update':
            handleBatchUpdateCategories($categoryManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($categoryManager, $validator, $input, $pathParts)
{
    $action = $pathParts[2] ?? 'delete';
    
    switch ($action) {
        case 'delete':
            handleDeleteCategory($categoryManager, $validator, $input);
            break;
        case 'batch-delete':
            handleBatchDeleteCategories($categoryManager, $validator, $input);
            break;
        default:
            Response::error('Invalid action', 400);
    }
}

/**
 * 处理分类列表
 */
function handleCategoryList($categoryManager, $validator, $input)
{
    try {
        // 验证分页参数
        $rules = [
            'page' => 'optional|integer|min:1',
            'limit' => 'optional|integer|min:1|max:100',
            'is_active' => 'optional|integer|in:0,1',
            'parent_id' => 'optional|integer|min:0',
            'search' => 'optional|string|max:100'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $page = intval($input['page'] ?? 1);
        $limit = intval($input['limit'] ?? 50);
        
        // 构建过滤条件
        $filters = [];
        foreach (['is_active', 'parent_id', 'search'] as $field) {
            if (isset($input[$field])) {
                $filters[$field] = $input[$field];
            }
        }
        
        $result = $categoryManager->getCategoryList($filters, $page, $limit);
        
        if ($result === false) {
            Response::error('Failed to get category list', 500);
        }
        
        Response::success($result, 'Category list retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get category list: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理分类详情
 */
function handleCategoryDetail($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $categoryId = intval($input['id']);
        $category = $categoryManager->getCategory($categoryId);
        
        if (!$category) {
            Response::error('Category not found', 404);
        }
        
        Response::success($category, 'Category retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get category: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理分类树
 */
function handleCategoryTree($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'is_active' => 'optional|integer|in:0,1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $filters = [];
        if (isset($input['is_active'])) {
            $filters['is_active'] = $input['is_active'];
        }
        
        $tree = $categoryManager->getCategoryTree($filters);
        
        if ($tree === false) {
            Response::error('Failed to get category tree', 500);
        }
        
        Response::success($tree, 'Category tree retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get category tree: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理分类搜索
 */
function handleCategorySearch($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'q' => 'required|string|max:100',
            'page' => 'optional|integer|min:1',
            'limit' => 'optional|integer|min:1|max:50'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $page = intval($input['page'] ?? 1);
        $limit = intval($input['limit'] ?? 20);
        
        $filters = ['search' => $input['q']];
        $result = $categoryManager->getCategoryList($filters, $page, $limit);
        
        if ($result === false) {
            Response::error('Failed to search categories', 500);
        }
        
        Response::success($result, 'Categories searched successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to search categories: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理分类统计
 */
function handleCategoryStatistics($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'start_date' => 'optional|date',
            'end_date' => 'optional|date'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $filters = [];
        foreach (['start_date', 'end_date'] as $field) {
            if (isset($input[$field])) {
                $filters[$field] = $input[$field];
            }
        }
        
        $stats = $categoryManager->getCategoryStatistics($filters);
        
        if ($stats === false) {
            Response::error('Failed to get category statistics', 500);
        }
        
        Response::success($stats, 'Category statistics retrieved successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to get category statistics: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理创建分类
 */
function handleCreateCategory($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'name' => 'required|string|max:50',
            'description' => 'optional|string|max:200',
            'parent_id' => 'optional|integer|min:0',
            'icon' => 'optional|string|max:100',
            'is_active' => 'optional|integer|in:0,1',
            'sort_order' => 'optional|integer|min:0'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $result = $categoryManager->createCategory($input);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Category created successfully', 201);
        
    } catch (Exception $e) {
        Response::error('Failed to create category: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理批量创建分类
 */
function handleBatchCreateCategories($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'categories' => 'required|array|max:10',
            'categories.*.name' => 'required|string|max:50'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $results = [];
        $errors = [];
        
        foreach ($input['categories'] as $index => $categoryData) {
            $result = $categoryManager->createCategory($categoryData);
            if ($result['success']) {
                $results[] = $result;
            } else {
                $errors[] = [
                    'index' => $index,
                    'error' => $result['message']
                ];
            }
        }
        
        Response::success([
            'created' => $results,
            'errors' => $errors,
            'total' => count($input['categories']),
            'success_count' => count($results),
            'error_count' => count($errors)
        ], 'Batch category creation completed');
        
    } catch (Exception $e) {
        Response::error('Failed to batch create categories: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理更新分类
 */
function handleUpdateCategory($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1',
            'name' => 'optional|string|max:50',
            'description' => 'optional|string|max:200',
            'parent_id' => 'optional|integer|min:0',
            'icon' => 'optional|string|max:100',
            'is_active' => 'optional|integer|in:0,1',
            'sort_order' => 'optional|integer|min:0'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $categoryId = intval($input['id']);
        unset($input['id']);
        
        $result = $categoryManager->updateCategory($categoryId, $input);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Category updated successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to update category: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理批量更新分类
 */
function handleBatchUpdateCategories($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'categories' => 'required|array|max:10',
            'categories.*.id' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $results = [];
        $errors = [];
        
        foreach ($input['categories'] as $index => $categoryData) {
            $categoryId = $categoryData['id'];
            unset($categoryData['id']);
            
            $result = $categoryManager->updateCategory($categoryId, $categoryData);
            if ($result['success']) {
                $results[] = $result;
            } else {
                $errors[] = [
                    'index' => $index,
                    'id' => $categoryId,
                    'error' => $result['message']
                ];
            }
        }
        
        Response::success([
            'updated' => $results,
            'errors' => $errors,
            'total' => count($input['categories']),
            'success_count' => count($results),
            'error_count' => count($errors)
        ], 'Batch category update completed');
        
    } catch (Exception $e) {
        Response::error('Failed to batch update categories: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理删除分类
 */
function handleDeleteCategory($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'id' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $categoryId = intval($input['id']);
        $result = $categoryManager->deleteCategory($categoryId);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result, 'Category deleted successfully');
        
    } catch (Exception $e) {
        Response::error('Failed to delete category: ' . $e->getMessage(), 500);
    }
}

/**
 * 处理批量删除分类
 */
function handleBatchDeleteCategories($categoryManager, $validator, $input)
{
    try {
        $rules = [
            'ids' => 'required|array|max:10',
            'ids.*' => 'required|integer|min:1'
        ];
        
        $validation = $validator->validate($input, $rules);
        if (!$validation['valid']) {
            Response::error('Validation failed: ' . implode(', ', $validation['errors']), 400);
        }
        
        $results = [];
        $errors = [];
        
        foreach ($input['ids'] as $index => $categoryId) {
            $result = $categoryManager->deleteCategory($categoryId);
            if ($result['success']) {
                $results[] = $result;
            } else {
                $errors[] = [
                    'index' => $index,
                    'id' => $categoryId,
                    'error' => $result['message']
                ];
            }
        }
        
        Response::success([
            'deleted' => $results,
            'errors' => $errors,
            'total' => count($input['ids']),
            'success_count' => count($results),
            'error_count' => count($errors)
        ], 'Batch category deletion completed');
        
    } catch (Exception $e) {
        Response::error('Failed to batch delete categories: ' . $e->getMessage(), 500);
    }
}
?>