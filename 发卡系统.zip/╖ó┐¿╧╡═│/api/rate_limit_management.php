<?php
/**
 * 限流管理API接口
 * 
 * 提供限流状态查询、IP管理、违规记录等功能
 * 仅管理员可访问
 */

require_once '../includes/Database.php';
require_once '../includes/Logger.php';
require_once '../api/middleware.php';

// 初始化数据库和中间件
$database = new Database();
$middleware = new ApiMiddleware($database);
$logger = new Logger();

// 应用中间件
$middleware->cors();
$auth_result = $middleware->auth();
if (!$auth_result['success']) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'UNAUTHORIZED', 'message' => '需要身份验证']);
    exit;
}

// 检查管理员权限
$middleware->permission('admin');

// 获取请求方法和路径
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));
$action = $path_parts[count($path_parts) - 1] ?? 'status';

try {
    switch ($method) {
        case 'GET':
            handleGetRequest($action, $database, $logger);
            break;
        case 'POST':
            handlePostRequest($action, $database, $logger);
            break;
        case 'PUT':
            handlePutRequest($action, $database, $logger);
            break;
        case 'DELETE':
            handleDeleteRequest($action, $database, $logger);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'METHOD_NOT_ALLOWED', 'message' => '不支持的请求方法']);
            break;
    }
} catch (Exception $e) {
    $logger->error('Rate limit management API error', [
        'action' => $action,
        'method' => $method,
        'error' => $e->getMessage()
    ]);
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'INTERNAL_SERVER_ERROR',
        'message' => '服务器内部错误'
    ]);
}

/**
 * 处理GET请求
 */
function handleGetRequest($action, $database, $logger) {
    switch ($action) {
        case 'status':
            getRateLimitStatus($database);
            break;
        case 'violations':
            getRateLimitViolations($database);
            break;
        case 'blocked-ips':
            getBlockedIps($database);
            break;
        case 'ip-info':
            getIpInfo($database);
            break;
        case 'statistics':
            getRateLimitStatistics($database);
            break;
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'NOT_FOUND', 'message' => '未找到请求的资源']);
            break;
    }
}

/**
 * 处理POST请求
 */
function handlePostRequest($action, $database, $logger) {
    switch ($action) {
        case 'block-ip':
            blockIpAddress($database, $logger);
            break;
        case 'unblock-ip':
            unblockIpAddress($database, $logger);
            break;
        case 'add-whitelist':
            addToWhitelist($database, $logger);
            break;
        case 'remove-whitelist':
            removeFromWhitelist($database, $logger);
            break;
        case 'add-blacklist':
            addToBlacklist($database, $logger);
            break;
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'NOT_FOUND', 'message' => '未找到请求的资源']);
            break;
    }
}

/**
 * 处理PUT请求
 */
function handlePutRequest($action, $database, $logger) {
    switch ($action) {
        case 'config':
            updateRateLimitConfig($database, $logger);
            break;
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'NOT_FOUND', 'message' => '未找到请求的资源']);
            break;
    }
}

/**
 * 处理DELETE请求
 */
function handleDeleteRequest($action, $database, $logger) {
    switch ($action) {
        case 'cleanup':
            cleanupExpiredRecords($database, $logger);
            break;
        case 'clear-violations':
            clearViolations($database, $logger);
            break;
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'NOT_FOUND', 'message' => '未找到请求的资源']);
            break;
    }
}

/**
 * 获取限流状态
 */
function getRateLimitStatus($database) {
    $db = $database->getConnection();
    
    // 获取当前活跃的限流记录
    $sql = "SELECT 
                ip_address,
                endpoint,
                COUNT(*) as request_count,
                MAX(created_at) as last_request
            FROM api_rate_limits 
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
            GROUP BY ip_address, endpoint
            ORDER BY request_count DESC
            LIMIT 100";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $active_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 获取当前被阻止的IP数量
    $sql = "SELECT COUNT(*) as blocked_count FROM ip_blocks WHERE block_until > NOW()";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $blocked_count = $stmt->fetch()['blocked_count'];
    
    // 获取最近1小时的违规次数
    $sql = "SELECT COUNT(*) as violation_count 
            FROM rate_limit_violations 
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $violation_count = $stmt->fetch()['violation_count'];
    
    echo json_encode([
        'success' => true,
        'data' => [
            'active_requests' => $active_requests,
            'blocked_ips_count' => (int)$blocked_count,
            'recent_violations' => (int)$violation_count,
            'timestamp' => date('Y-m-d H:i:s')
        ]
    ]);
}

/**
 * 获取限流违规记录
 */
function getRateLimitViolations($database) {
    $db = $database->getConnection();
    
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(10, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    
    $sql = "SELECT 
                ip_address,
                endpoint,
                method,
                current_count,
                limit_count,
                created_at
            FROM rate_limit_violations 
            ORDER BY created_at DESC 
            LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $violations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 获取总数
    $sql = "SELECT COUNT(*) as total FROM rate_limit_violations";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $total = $stmt->fetch()['total'];
    
    echo json_encode([
        'success' => true,
        'data' => [
            'violations' => $violations,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]
    ]);
}

/**
 * 获取被阻止的IP列表
 */
function getBlockedIps($database) {
    $db = $database->getConnection();
    
    $sql = "SELECT 
                ip_address,
                block_reason,
                block_until,
                violation_count,
                created_at,
                TIMESTAMPDIFF(SECOND, NOW(), block_until) as remaining_seconds
            FROM ip_blocks 
            WHERE block_until > NOW()
            ORDER BY block_until DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $blocked_ips = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'blocked_ips' => $blocked_ips,
            'count' => count($blocked_ips)
        ]
    ]);
}

/**
 * 获取IP详细信息
 */
function getIpInfo($database) {
    $ip = $_GET['ip'] ?? '';
    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_IP', 'message' => '无效的IP地址']);
        return;
    }
    
    $db = $database->getConnection();
    
    // 获取请求历史
    $sql = "SELECT 
                endpoint,
                method,
                COUNT(*) as request_count,
                MAX(created_at) as last_request
            FROM api_rate_limits 
            WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
            GROUP BY endpoint, method
            ORDER BY request_count DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip]);
    $request_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 获取违规记录
    $sql = "SELECT 
                endpoint,
                method,
                current_count,
                limit_count,
                created_at
            FROM rate_limit_violations 
            WHERE ip_address = ?
            ORDER BY created_at DESC
            LIMIT 10";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip]);
    $violations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 检查是否被阻止
    $sql = "SELECT 
                block_reason,
                block_until,
                violation_count
            FROM ip_blocks 
            WHERE ip_address = ? AND block_until > NOW()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip]);
    $block_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'ip_address' => $ip,
            'request_history' => $request_history,
            'violations' => $violations,
            'block_info' => $block_info,
            'is_blocked' => !empty($block_info)
        ]
    ]);
}

/**
 * 获取限流统计信息
 */
function getRateLimitStatistics($database) {
    $db = $database->getConnection();
    
    // 今日统计
    $sql = "SELECT 
                COUNT(DISTINCT ip_address) as unique_ips,
                COUNT(*) as total_requests,
                COUNT(CASE WHEN created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 1 END) as last_hour_requests
            FROM api_rate_limits 
            WHERE DATE(created_at) = CURDATE()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $today_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // 违规统计
    $sql = "SELECT 
                COUNT(*) as total_violations,
                COUNT(DISTINCT ip_address) as unique_violating_ips,
                COUNT(CASE WHEN created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 1 END) as recent_violations
            FROM rate_limit_violations 
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $violation_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // 阻止统计
    $sql = "SELECT 
                COUNT(*) as currently_blocked,
                COUNT(CASE WHEN block_until > DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 1 END) as blocked_over_1h
            FROM ip_blocks 
            WHERE block_until > NOW()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $block_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'today' => [
                'unique_ips' => (int)$today_stats['unique_ips'],
                'total_requests' => (int)$today_stats['total_requests'],
                'last_hour_requests' => (int)$today_stats['last_hour_requests']
            ],
            'violations' => [
                'total_violations' => (int)$violation_stats['total_violations'],
                'unique_violating_ips' => (int)$violation_stats['unique_violating_ips'],
                'recent_violations' => (int)$violation_stats['recent_violations']
            ],
            'blocks' => [
                'currently_blocked' => (int)$block_stats['currently_blocked'],
                'blocked_over_1h' => (int)$block_stats['blocked_over_1h']
            ]
        ]
    ]);
}

/**
 * 阻止IP地址
 */
function blockIpAddress($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $ip = $input['ip'] ?? '';
    $duration = max(60, intval($input['duration'] ?? 3600)); // 最少1小时
    $reason = $input['reason'] ?? '管理员手动阻止';
    
    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_IP', 'message' => '无效的IP地址']);
        return;
    }
    
    $db = $database->getConnection();
    $block_until = date('Y-m-d H:i:s', time() + $duration);
    
    $sql = "INSERT INTO ip_blocks (ip_address, block_reason, block_until, created_at) 
            VALUES (?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE 
            block_reason = ?,
            block_until = GREATEST(block_until, ?),
            updated_at = NOW()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip, $reason, $block_until, $reason, $block_until]);
    
    $logger->warning('IP manually blocked by admin', [
        'ip' => $ip,
        'duration' => $duration,
        'reason' => $reason,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'IP地址已成功阻止',
        'data' => [
            'ip' => $ip,
            'block_until' => $block_until,
            'duration' => $duration
        ]
    ]);
}

/**
 * 解除IP阻止
 */
function unblockIpAddress($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $ip = $input['ip'] ?? '';
    
    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_IP', 'message' => '无效的IP地址']);
        return;
    }
    
    $db = $database->getConnection();
    
    $sql = "DELETE FROM ip_blocks WHERE ip_address = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip]);
    
    $logger->info('IP unblocked by admin', [
        'ip' => $ip,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'IP地址已解除阻止',
        'data' => ['ip' => $ip]
    ]);
}

/**
 * 清理过期记录
 */
function cleanupExpiredRecords($database, $logger) {
    $db = $database->getConnection();
    
    // 清理过期的限流记录
    $sql = "DELETE FROM api_rate_limits WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $rate_limit_deleted = $stmt->rowCount();
    
    // 清理过期的阻止记录
    $sql = "DELETE FROM ip_blocks WHERE block_until <= NOW()";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $block_deleted = $stmt->rowCount();
    
    $logger->info('Rate limit cleanup completed', [
        'rate_limit_records_deleted' => $rate_limit_deleted,
        'block_records_deleted' => $block_deleted,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '过期记录清理完成',
        'data' => [
            'rate_limit_records_deleted' => $rate_limit_deleted,
            'block_records_deleted' => $block_deleted
        ]
    ]);
}

/**
 * 清除违规记录
 */
function clearViolations($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    $days = max(1, intval($input['days'] ?? 30)); // 默认清除30天前的记录
    
    $db = $database->getConnection();
    
    $sql = "DELETE FROM rate_limit_violations WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
    $stmt = $db->prepare($sql);
    $stmt->execute([$days]);
    $deleted = $stmt->rowCount();
    
    $logger->info('Rate limit violations cleared', [
        'days' => $days,
        'records_deleted' => $deleted,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '违规记录清除完成',
        'data' => [
            'days' => $days,
            'records_deleted' => $deleted
        ]
    ]);
}

/**
 * 添加到白名单
 */
function addToWhitelist($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $ip = $input['ip'] ?? '';
    $reason = $input['reason'] ?? '管理员添加到白名单';
    
    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_IP', 'message' => '无效的IP地址']);
        return;
    }
    
    $db = $database->getConnection();
    
    $sql = "INSERT INTO ip_whitelist (ip_address, reason, created_at) 
            VALUES (?, ?, NOW())
            ON DUPLICATE KEY UPDATE reason = ?, updated_at = NOW()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip, $reason, $reason]);
    
    $logger->info('IP added to whitelist', [
        'ip' => $ip,
        'reason' => $reason,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'IP地址已添加到白名单',
        'data' => ['ip' => $ip, 'reason' => $reason]
    ]);
}

/**
 * 从白名单移除
 */
function removeFromWhitelist($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $ip = $input['ip'] ?? '';
    
    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_IP', 'message' => '无效的IP地址']);
        return;
    }
    
    $db = $database->getConnection();
    
    $sql = "DELETE FROM ip_whitelist WHERE ip_address = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip]);
    
    $logger->info('IP removed from whitelist', [
        'ip' => $ip,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'IP地址已从白名单移除',
        'data' => ['ip' => $ip]
    ]);
}

/**
 * 添加到黑名单
 */
function addToBlacklist($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $ip = $input['ip'] ?? '';
    $reason = $input['reason'] ?? '管理员添加到黑名单';
    
    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_IP', 'message' => '无效的IP地址']);
        return;
    }
    
    $db = $database->getConnection();
    
    $sql = "INSERT INTO ip_blacklist (ip_address, reason, created_at) 
            VALUES (?, ?, NOW())
            ON DUPLICATE KEY UPDATE reason = ?, updated_at = NOW()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$ip, $reason, $reason]);
    
    $logger->info('IP added to blacklist', [
        'ip' => $ip,
        'reason' => $reason,
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'IP地址已添加到黑名单',
        'data' => ['ip' => $ip, 'reason' => $reason]
    ]);
}

/**
 * 更新限流配置
 */
function updateRateLimitConfig($database, $logger) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $config = $input['config'] ?? [];
    
    if (empty($config)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'INVALID_CONFIG', 'message' => '配置不能为空']);
        return;
    }
    
    $db = $database->getConnection();
    
    // 更新或插入配置
    foreach ($config as $key => $value) {
        $sql = "INSERT INTO rate_limit_config (config_key, config_value, updated_at) 
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE config_value = ?, updated_at = NOW()";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$key, json_encode($value), json_encode($value)]);
    }
    
    $logger->info('Rate limit config updated', [
        'config_keys' => array_keys($config),
        'admin' => $_SERVER['API_USER']['username'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => '限流配置更新成功',
        'data' => [
            'updated_keys' => array_keys($config),
            'config' => $config
        ]
    ]);
}
?>