<?php
/**
 * 性能监控API接口
 * 提供性能指标、任务管理、日志查询等功能
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Logger.php';
require_once __DIR__ . '/../includes/CacheManager.php';
require_once __DIR__ . '/../includes/TaskScheduler.php';
require_once __DIR__ . '/../includes/PerformanceReporter.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 验证管理员权限
function validateAdmin() {
    session_start();
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(array('error' => '需要管理员权限'));
        exit;
    }
}

// 获取请求路径
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace('/api/performance/', '', $path);
$path = rtrim($path, '/');

try {
    switch ($path) {
        case 'metrics':
            handleMetrics();
            break;
        case 'tasks':
            handleTasks();
            break;
        case 'run-all-tasks':
            validateAdmin();
            handleRunAllTasks();
            break;
        case 'logs':
            handleLogs();
            break;
        default:
            if (strpos($path, 'run-task/') === 0) {
                validateAdmin();
                $taskId = substr($path, 10);
                handleRunTask($taskId);
            } else {
                http_response_code(404);
                echo json_encode(array('error' => '接口不存在'));
            }
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('error' => $e->getMessage()));
}

/**
 * 获取性能指标
 */
function handleMetrics() {
    global $pdo;
    
    $metrics = array();
    
    // 数据库查询统计
    try {
        $stmt = $pdo->query("
            SELECT 
                COUNT(*) as total_queries,
                AVG(execution_time) as avg_time,
                MAX(execution_time) as max_time,
                COUNT(CASE WHEN execution_time > 2 THEN 1 END) as slow_queries
            FROM query_performance_log 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ");
        
        $dbStats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $metrics['db_queries'] = isset($dbStats['total_queries']) ? $dbStats['total_queries'] : 0;
        $metrics['avg_response_time'] = round(isset($dbStats['avg_time']) ? $dbStats['avg_time'] : 0, 2);
        $metrics['db_queries_status'] = (isset($dbStats['slow_queries']) ? $dbStats['slow_queries'] : 0) > 10 ? 'warning' : 'healthy';
        $metrics['response_time_status'] = (isset($dbStats['avg_time']) ? $dbStats['avg_time'] : 0) > 1 ? 'warning' : 'healthy';
        $metrics['db_queries_percent'] = min((isset($dbStats['total_queries']) ? $dbStats['total_queries'] : 0) / 100 * 100, 100);
        $metrics['response_time_percent'] = min((isset($dbStats['avg_time']) ? $dbStats['avg_time'] : 0) / 5 * 100, 100);
        
    } catch (Exception $e) {
        $metrics['db_queries'] = 0;
        $metrics['avg_response_time'] = 0;
        $metrics['db_queries_status'] = 'error';
        $metrics['response_time_status'] = 'error';
    }
    
    // 内存使用情况
    if (function_exists('memory_get_usage')) {
        $memoryUsage = memory_get_usage(true);
        $memoryLimit = ini_get('memory_limit');
        $memoryLimitBytes = parseMemoryLimit($memoryLimit);
        
        $metrics['memory_usage'] = round(($memoryUsage / $memoryLimitBytes) * 100, 2);
        $metrics['memory_status'] = $metrics['memory_usage'] > 80 ? 'critical' : ($metrics['memory_usage'] > 60 ? 'warning' : 'healthy');
    } else {
        $metrics['memory_usage'] = 0;
        $metrics['memory_status'] = 'healthy';
    }
    
    // 磁盘使用情况
    $freeSpace = disk_free_space(dirname(__DIR__));
    $totalSpace = disk_total_space(dirname(__DIR__));
    
    if ($totalSpace > 0) {
        $metrics['disk_usage'] = round((1 - $freeSpace / $totalSpace) * 100, 2);
        $metrics['disk_status'] = $metrics['disk_usage'] > 90 ? 'critical' : ($metrics['disk_usage'] > 80 ? 'warning' : 'healthy');
    } else {
        $metrics['disk_usage'] = 0;
        $metrics['disk_status'] = 'healthy';
    }
    
    // 数据库连接数
    try {
        $stmt = $pdo->query("SHOW STATUS LIKE 'Threads_connected'");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $metrics['db_connections'] = isset($result['Value']) ? $result['Value'] : 0;
    } catch (Exception $e) {
        $metrics['db_connections'] = 0;
    }
    
    // 缓存命中率
    try {
        $cache = new CacheManager();
        $metrics['cache_hit_rate'] = $cache->getHitRate();
        $metrics['cache_status'] = $metrics['cache_hit_rate'] > 80 ? 'healthy' : ($metrics['cache_hit_rate'] > 60 ? 'warning' : 'critical');
    } catch (Exception $e) {
        $metrics['cache_hit_rate'] = 0;
        $metrics['cache_status'] = 'error';
    }
    
    echo json_encode($metrics);
}

/**
 * 获取任务列表
 */
function handleTasks() {
    $scheduler = new TaskScheduler();
    $tasks = $scheduler->getTaskList();
    
    $taskList = array();
    foreach ($tasks as $id => $description) {
        $taskList[] = array(
            'id' => $id,
            'name' => $description,
            'description' => $description
        );
    }
    
    echo json_encode($taskList);
}

/**
 * 执行所有任务
 */
function handleRunAllTasks() {
    $scheduler = new TaskScheduler();
    $results = $scheduler->runAllTasks();
    
    echo json_encode($results);
}

/**
 * 执行单个任务
 */
function handleRunTask($taskId) {
    $scheduler = new TaskScheduler();
    $result = $scheduler->runTask($taskId);
    
    echo json_encode($result);
}

/**
 * 获取系统日志
 */
function handleLogs() {
    $logFile = dirname(__DIR__) . '/logs/app.log';
    $logs = array();
    
    if (file_exists($logFile)) {
        $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $lines = array_slice($lines, -100); // 获取最后100行
        
        foreach ($lines as $line) {
            if (preg_match('/^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] (\w+): (.+)$/', $line, $matches)) {
                $logs[] = array(
                    'time' => $matches[1],
                    'level' => $matches[2],
                    'message' => $matches[3]
                );
            }
        }
    }
    
    // 按时间倒序排列
    $logs = array_reverse($logs);
    
    echo json_encode($logs);
}

/**
 * 解析内存限制
 */
function parseMemoryLimit($limit) {
    $limit = trim($limit);
    $last = strtolower($limit[strlen($limit) - 1]);
    $value = (int) $limit;
    
    switch ($last) {
        case 'g':
            $value *= 1024;
        case 'm':
            $value *= 1024;
        case 'k':
            $value *= 1024;
    }
    
    return $value;
}