<?php
/**
 * 获取可用的限时秒杀活动API
 */

// 包含必要的文件和初始化
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/business/FlashSaleManager.php';

// 检查用户是否登录
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => '请先登录',
        'data' => []
    ]);
    exit;
}

// 获取用户ID
$userId = $_SESSION['user_id'];

// 初始化数据库连接和日志
$database = new Database();
$logger = new Logger('flash_sale_api');

// 初始化秒杀管理器
$flashSaleManager = new FlashSaleManager($database, $logger);

// 获取订单数据
$orderData = json_decode(file_get_contents('php://input'), true);
$orderAmount = isset($orderData['orderAmount']) ? (float)$orderData['orderAmount'] : 0;
$orderItems = isset($orderData['orderItems']) ? $orderData['orderItems'] : [];

// 计算可用的限时秒杀活动
$availableFlashSales = $flashSaleManager->calculateAvailableFlashSales($userId, $orderAmount, $orderItems);

// 返回结果
echo json_encode([
    'success' => true,
    'message' => '获取限时秒杀活动成功',
    'data' => $availableFlashSales
]);

// 关闭数据库连接
$database->close();