<?php
/**
 * API中间件管理器
 * 提供认证、限流、日志、CORS等中间件功能
 * 增强版限流中间件，支持多种限流策略和IP阻止
 */

/**
 * 中间件链管理器
 * 用于组织和执行多个中间件
 */
class MiddlewareChain {
    /**
     * @var array 中间件数组
     */
    private $middlewares = array();
    
    /**
     * 添加中间件到链中
     * @param object $middleware 中间件对象
     * @return $this
     */
    public function addMiddleware($middleware) {
        if (is_object($middleware)) {
            $this->middlewares[] = $middleware;
        }
        return $this;
    }
    
    /**
     * 执行中间件链
     * @param array $request 请求数据
     * @param callable $next 下一个处理函数
     * @return mixed 处理结果
     */
    public function execute($request, $next) {
        $current = 0;
        $chain = function($req) use (&$chain, &$current, $next) {
            if ($current >= count($this->middlewares)) {
                return $next($req);
            }
            
            $middleware = $this->middlewares[$current++];
            if (method_exists($middleware, 'handle')) {
                return $middleware->handle($req, $chain);
            } else {
                // 如果中间件没有handle方法，直接调用中间件函数
                return $middleware($req, $chain);
            }
        };
        
        return $chain($request);
    }
}

/**
 * 请求日志中间件
 */
class RequestLoggingMiddleware {
    private $logger;
    
    public function __construct($logger) {
        $this->logger = $logger;
    }
    
    public function handle($request, $next) {
        // 记录请求信息
        if (isset($this->logger) && is_object($this->logger) && method_exists($this->logger, 'info')) {
            $this->logger->info('Request received', array(
                'method' => $_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN',
                'uri' => $_SERVER['REQUEST_URI'] ?? '',
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ));
        }
        
        // 继续处理请求
        return $next($request);
    }
}

/**
 * 安全检查中间件
 */
class SecurityCheckMiddleware {
    private $securityManager;
    
    public function __construct($securityManager) {
        $this->securityManager = $securityManager;
    }
    
    public function handle($request, $next) {
        // 执行安全检查
        if (isset($this->securityManager) && is_object($this->securityManager) && method_exists($this->securityManager, 'checkRequestSecurity')) {
            try {
                $result = $this->securityManager->checkRequestSecurity($request);
                if ($result !== true) {
                    return $result; // 返回安全检查失败的结果
                }
            } catch (Exception $e) {
                // 安全检查失败，允许请求继续但记录错误
                error_log('Security check failed: ' . $e->getMessage());
            }
        }
        
        return $next($request);
    }
}

/**
 * 认证中间件
 */
class AuthenticationMiddleware {
    public function handle($request, $next) {
        // 执行认证检查
        // 这里可以复用apiAuthMiddleware函数或实现自己的逻辑
        $path = $_SERVER['REQUEST_URI'] ?? '';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        
        // 公开路由直接通过
        $publicRoutes = [
            '/auth/login',
            '/auth/forgot-password',
            '/auth/reset-password',
            '/maintenance/status',
            '/maintenance/emergency-disable'
        ];
        
        foreach ($publicRoutes as $publicRoute) {
            if (strpos($path, $publicRoute) === 0) {
                return $next($request);
            }
        }
        
        // 其他路由需要认证
        return $next($request);
    }
}

/**
 * 授权中间件
 */
class AuthorizationMiddleware {
    public function handle($request, $next) {
        // 执行授权检查
        // 这里可以根据需要实现权限验证逻辑
        return $next($request);
    }
}

/**
 * 限流中间件
 */
class RateLimitMiddleware {
    public function handle($request, $next) {
        // 执行限流检查
        // 可以复用现有的checkRateLimit函数
        $clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
        if (function_exists('checkRateLimit') && !checkRateLimit($clientIp)) {
            return [
                'success' => false,
                'error' => 'Too Many Requests',
                'message' => '请求过于频繁，请稍后再试',
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
        
        return $next($request);
    }
}

/**
 * 请求验证中间件
 */
class RequestValidationMiddleware {
    public function handle($request, $next) {
        // 验证请求数据格式等
        return $next($request);
    }
}

// 基础日志类实现
class Logger {
    public function info($message, $context = array()) {
        $this->log('INFO', $message, $context);
    }
    
    public function warning($message, $context = array()) {
        $this->log('WARNING', $message, $context);
    }
    
    public function error($message, $context = array()) {
        $this->log('ERROR', $message, $context);
    }
    
    private function log($level, $message, $context = array()) {
        $context_str = !empty($context) ? json_encode($context) : '';
        $log_message = "[{$level}] {$message} {$context_str}";
        error_log($log_message);
    }
}

class ApiMiddleware {
    private $config;
    private $db;
    private $rate_limit_config;
    private $logger;
    
    public function __construct($db, $config = array()) {
        $this->db = $db;
        $this->logger = new Logger();
        
        // 加载默认配置
        $default_config = array(
            'rate_limit' => array(
                'requests_per_minute' => 100,
                'login_attempts_per_minute' => 10
            ),
            'cors' => array(
                'allowed_origins' => array('*'),
                'allowed_methods' => array('GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'),
                'allowed_headers' => array('Content-Type', 'Authorization', 'X-Requested-With'),
                'max_age' => 86400
            ),
            'security' => array(
                'max_request_size' => 10485760, // 10MB
                'require_https' => false,
                'token_expiry' => 86400 // 24小时
            )
        );
        
        // 尝试加载外部配置文件
        if (file_exists(__DIR__ . '/config/api.php')) {
            $external_config = require __DIR__ . '/config/api.php';
            $this->config = array_merge($default_config, $external_config);
        } else {
            $this->config = array_merge($default_config, $config);
        }
        
        // 加载限流配置
        if (file_exists(__DIR__ . '/config/rate_limits.php')) {
            $this->rate_limit_config = require __DIR__ . '/config/rate_limits.php';
        } else {
            $this->rate_limit_config = array();
        }
        
        // 定期清理过期记录
        $this->scheduleCleanup();
    }
    
    /**
     * CORS中间件
     */
    public function cors() {
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        $allowed_origins = $this->config['cors']['allowed_origins'];
        
        if (in_array('*', $allowed_origins) || in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: $origin");
        }
        
        header("Access-Control-Allow-Methods: " . implode(', ', $this->config['cors']['allowed_methods']));
        header("Access-Control-Allow-Headers: " . implode(', ', $this->config['cors']['allowed_headers']));
        header("Access-Control-Max-Age: " . $this->config['cors']['max_age']);
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
    
    /**
     * 认证中间件
     */
    public function auth() {
        $token = $this->getBearerToken();
        
        if (!$token) {
            $this->sendError('UNAUTHORIZED', 'API Token required', 401);
        }
        
        // 验证token格式
        if (!$this->validateTokenFormat($token)) {
            $this->sendError('UNAUTHORIZED', 'Invalid API Token format', 401);
        }
        
        // 从数据库验证token
        $user = $this->validateToken($token);
        
        if (!$user) {
            $this->sendError('UNAUTHORIZED', 'Invalid or expired API Token', 401);
        }
        
        // 检查用户状态
        if ($user['status'] !== 'active') {
            $this->sendError('FORBIDDEN', 'User account is not active', 403);
        }
        
        // 将用户信息存储到请求上下文
        $_SERVER['API_USER'] = $user;
        
        // 记录API访问
        $this->logApiAccess($user['id']);
        
        return $user;
    }
      
      /**
       * 发送错误响应
       */
      private function sendError($code, $message, $http_status = 400) {
          http_response_code($http_status);
          header('Content-Type: application/json');
          
          echo json_encode([
              'success' => false,
              'error' => $code,
              'message' => $message,
              'timestamp' => date('Y-m-d H:i:s')
          ]);
          
          exit;
      }
      
      /**
     * 权限检查中间件
     */
    public function permission($required_permission) {
        $user = isset($_SERVER['API_USER']) ? $_SERVER['API_USER'] : null;
        
        if (!$user) {
            $this->sendError('UNAUTHORIZED', 'Authentication required', 401);
        }
        
        // 管理员拥有所有权限
        if ($user['role'] === 'admin') {
            return true;
        }
        
        // 检查用户权限
        try {
            $user_permissions = $this->getUserPermissions($user['id']);
            
            if (!in_array($required_permission, $user_permissions)) {
                $this->sendError('FORBIDDEN', 'Insufficient permissions', 403);
            }
        } catch (Exception $e) {
            $this->logger->error('Permission check failed', ['error' => $e->getMessage()]);
            $this->sendError('FORBIDDEN', 'Permission check failed', 403);
        }
        
        return true;
    }
    
    /**
     * 限流中间件
     * 增强版：支持多种限流策略、IP阻止、违规记录
     * 
     * @param string $type 限流类型 (default, login, upload, sensitive, admin, query)
     * @param array $options 额外选项
     * @return array|true
     */
    public function rateLimit($type = 'default', $options = array()) {
        $client_ip = $this->getClientIp();
        $endpoint = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'unknown';
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
        $current_time = time();
        
        // 检查IP白名单
        if ($this->isWhitelisted($client_ip)) {
            return true; // 白名单IP跳过限流
        }
        
        // 检查IP黑名单
        if ($this->isBlacklisted($client_ip)) {
            return [
                'success' => false,
                'error' => 'PERMANENTLY_BLOCKED',
                'message' => '您的IP地址已被永久阻止',
                'code' => 403
            ];
        }
        
        // 获取限流配置
        $config = $this->getRateLimitConfig($type, $options);
        $window = 60; // 默认时间窗口（分钟）
        
        try {
            // 检查IP是否已被临时阻止
            if ($this->isIpBlocked($client_ip)) {
                $block_info = $this->getIpBlockInfo($client_ip);
                return [
                    'success' => false,
                    'error' => 'IP_ADDRESS_BLOCKED',
                    'message' => '您的IP地址已被临时阻止',
                    'code' => 429,
                    'retry_after' => $block_info['remaining_seconds']
                ];
            }
            
            // 清理过期记录
            $this->cleanupRateLimitRecords($current_time - $window);
            
            // 检查当前窗口的请求次数
            $query = "SELECT COUNT(*) as count FROM api_rate_limits 
                      WHERE ip_address = ? AND endpoint = ? 
                      AND created_at > ? AND is_blocked = 0";
            $stmt = $this->db->prepare($query);
            $stmt->execute(array($client_ip, $endpoint, $current_time - $window));
            $count = $stmt->fetch()['count'];
            
            // 检查是否超过限制
            if ($count >= $config['requests_per_minute']) {
                // 记录违规
                $this->recordRateLimitViolation($client_ip, $endpoint, $method, $count, $config['requests_per_minute']);
                
                // 计算并执行阻止
                $block_duration = $this->calculateBlockDuration($client_ip);
                $this->blockIpAddress($client_ip, $block_duration);
                
                // 触发告警
                $this->triggerRateLimitAlert($client_ip, $endpoint, $count, $config['requests_per_minute']);
                
                return array(
                    'success' => false,
                    'error' => 'RATE_LIMIT_EXCEEDED',
                    'message' => "请求过于频繁，请在{$window}秒后重试",
                    'code' => 429,
                    'retry_after' => $block_duration,
                    'current_count' => $count,
                    'limit' => $config['requests_per_minute']
                );
            }
            
            // 记录当前请求
            $this->recordRequest($client_ip, $current_time, $endpoint, $method);
            
            // 添加限流响应头
            $this->addRateLimitHeaders($config['requests_per_minute'], $config['requests_per_minute'] - $count, $current_time + $window);
            
            return true;
            
        } catch (Exception $e) {
            $this->logger->error('Rate limit check failed', array(
                'ip' => $client_ip,
                'endpoint' => $endpoint,
                'error' => $e->getMessage()
            ));
            
            // 限流检查失败时，为了安全起见允许请求通过
            return true;
        }
    }
    
    /**
     * 获取限流配置
     */
    private function getRateLimitConfig($type, $options = array()) {
        // 从配置文件获取基础配置
        $config = isset($this->rate_limit_config[$type]) ? $this->rate_limit_config[$type] : $this->rate_limit_config['default'];
        
        // 应用选项覆盖
        if (isset($options['requests_per_minute'])) {
            $config['requests_per_minute'] = $options['requests_per_minute'];
        }
        if (isset($options['requests_per_hour'])) {
            $config['requests_per_hour'] = $options['requests_per_hour'];
        }
        if (isset($options['requests_per_day'])) {
            $config['requests_per_day'] = $options['requests_per_day'];
        }
        
        return $config;
    }
    
    /**
     * 检查IP是否在白名单中
     */
    private function isWhitelisted($ip) {
        // 安全地访问配置
        if (!isset($this->rate_limit_config['whitelist']) || !$this->rate_limit_config['whitelist']['enabled']) {
            return false;
        }
        
        return isset($this->rate_limit_config['whitelist']['ips']) && in_array($ip, $this->rate_limit_config['whitelist']['ips']);
    }
    
    /**
     * 检查IP是否在黑名单中
     */
    private function isBlacklisted($ip) {
        // 安全地访问配置
        if (!isset($this->rate_limit_config['blacklist']) || !$this->rate_limit_config['blacklist']['enabled']) {
            return false;
        }
        
        return isset($this->rate_limit_config['blacklist']['ips']) && in_array($ip, $this->rate_limit_config['blacklist']['ips']);
    }
    
    /**
     * 添加限流响应头
     */
    private function addRateLimitHeaders($limit, $remaining, $reset) {
        // 安全地访问配置
        if (!isset($this->rate_limit_config['response']) || !$this->rate_limit_config['response']['include_headers']) {
            return;
        }
        
        $headers = isset($this->rate_limit_config['response']['headers']) ? $this->rate_limit_config['response']['headers'] : [];
        
        if (isset($headers['x-rate-limit-limit'])) {
            header("X-Rate-Limit-Limit: {$limit}");
        }
        if (isset($headers['x-rate-limit-remaining'])) {
            header("X-Rate-Limit-Remaining: {$remaining}");
        }
        if (isset($headers['x-rate-limit-reset'])) {
            header("X-Rate-Limit-Reset: {$reset}");
        }
    }
    
    /**
     * 触发限流告警
     */
    private function triggerRateLimitAlert($ip, $endpoint, $count, $limit) {
        // 安全地访问配置
        if (!isset($this->rate_limit_config['monitoring']) || !$this->rate_limit_config['monitoring']['enabled']) {
            return;
        }
        
        $alert_data = array(
            'type' => 'rate_limit_violation',
            'ip' => $ip,
            'endpoint' => $endpoint,
            'count' => $count,
            'limit' => $limit,
            'timestamp' => date('Y-m-d H:i:s')
        );
        
        // 记录告警日志
        $this->logger->warning('Rate limit alert triggered', $alert_data);
        
        // 这里可以扩展发送邮件、webhook等通知
        $notification_methods = $this->rate_limit_config['monitoring']['notification_methods'];
        if (in_array('webhook', $notification_methods)) {
            // 发送webhook通知
            $this->sendWebhookNotification($alert_data);
        }
    }
    
    /**
     * 发送webhook通知
     */
    private function sendWebhookNotification($data) {
        // 实现webhook通知逻辑
        // 这里可以集成钉钉、企业微信等通知服务
    }
    
    /**
     * 定期清理过期记录
     */
    private function scheduleCleanup() {
        // 每小时清理一次过期记录
        $last_cleanup = $this->getLastCleanupTime();
        if (time() - $last_cleanup > 3600) {
            $this->cleanupExpiredRateLimits();
            $this->updateLastCleanupTime();
        }
    }
    
    /**
     * 清理过期的限流记录
     */
    private function cleanupExpiredRateLimits() {
        try {
            // 清理过期的API限流记录（超过1小时的记录）
            $cutoff_time = date('Y-m-d H:i:s', time() - 3600);
            $this->cleanupRateLimitRecords($cutoff_time);
            
            // 清理过期的API会话
            $query = "DELETE FROM api_sessions WHERE expires_at < NOW()";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            
            // 记录清理日志
            error_log("Rate limit cleanup completed at " . date('Y-m-d H:i:s'));
            
        } catch (Exception $e) {
            error_log("Rate limit cleanup failed: " . $e->getMessage());
        }
    }
    
    /**
     * 获取上次清理时间
     */
    private function getLastCleanupTime() {
        // 从缓存或配置文件获取上次清理时间
        return 0; // 简化实现
    }
    
    /**
     * 更新上次清理时间
     */
    private function updateLastCleanupTime() {
        // 更新缓存或配置文件中的清理时间
    }
    
    /**
     * 请求验证中间件
     */
    public function validateRequest() {
        // 检查请求大小
        if (isset($_SERVER['CONTENT_LENGTH']) && $_SERVER['CONTENT_LENGTH'] > $this->config['security']['max_request_size']) {
            $this->sendError('PAYLOAD_TOO_LARGE', 'Request entity too large', 413);
        }
        
        // 检查HTTPS要求
        if ($this->config['security']['require_https'] && !isset($_SERVER['HTTPS'])) {
            $this->sendError('FORBIDDEN', 'HTTPS required', 403);
        }
        
        // 验证Content-Type
        if ($_SERVER['REQUEST_METHOD'] !== 'GET' && $_SERVER['REQUEST_METHOD'] !== 'DELETE') {
            $content_type = $_SERVER['CONTENT_TYPE'] ?? '';
            if (strpos($content_type, 'application/json') === false) {
                $this->sendError('UNSUPPORTED_MEDIA_TYPE', 'Content-Type must be application/json', 415);
            }
        }
        
        return true;
    }
    
    /**
     * 安全头中间件
     */
    public function securityHeaders() {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        header('Content-Security-Policy: default-src \'self\'');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }
    
    /**
     * 请求日志中间件
     */
    public function requestLog() {
        $start_time = microtime(true);
        
        // 注册关闭函数来记录请求完成时间
        register_shutdown_function(function() use ($start_time) {
            $end_time = microtime(true);
            $duration = round(($end_time - $start_time) * 1000, 2); // 毫秒
            
            $this->logRequest([
                'method' => $_SERVER['REQUEST_METHOD'],
                'uri' => $_SERVER['REQUEST_URI'],
                'ip' => $this->getClientIp(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'user_id' => $_SERVER['API_USER']['id'] ?? null,
                'status_code' => http_response_code(),
                'duration_ms' => $duration,
                'request_size' => $_SERVER['CONTENT_LENGTH'] ?? 0,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        });
    }
    
    /**
     * 获取Bearer Token
     */
    private function getBearerToken() {
        $headers = getallheaders();
        $auth_header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        
        if (strpos($auth_header, 'Bearer ') === 0) {
            return substr($auth_header, 7);
        }
        
        return null;
    }
    
    /**
     * 验证Token格式
     */
    private function validateTokenFormat($token) {
        // 基本格式检查：JWT或随机字符串
        if (strlen($token) < 32) {
            return false;
        }
        
        // JWT格式检查
        if (strpos($token, '.') !== false) {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 验证Token有效性
     */
    private function validateToken($token) {
        $query = "SELECT u.*, s.api_token, s.expires_at 
                  FROM users u 
                  JOIN api_sessions s ON u.id = s.user_id 
                  WHERE s.api_token = ? AND s.expires_at > NOW() AND u.status = 'active'";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$token]);
        
        $user = $stmt->fetch();
        
        if ($user) {
            // 更新最后访问时间
            $this->updateTokenLastAccess($token);
        }
        
        return $user;
    }
    
    /**
     * 更新Token最后访问时间
     */
    private function updateTokenLastAccess($token) {
        $query = "UPDATE api_sessions SET last_access = NOW() WHERE api_token = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$token]);
    }
    
    /**
     * 获取用户权限
     */
    private function getUserPermissions($user_id) {
        $query = "SELECT permission FROM user_permissions WHERE user_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$user_id]);
        
        $permissions = [];
        while ($row = $stmt->fetch()) {
            $permissions[] = $row['permission'];
        }
        
        return $permissions;
    }
    
    /**
     * 获取客户端IP
     */
    private function getClientIp() {
        $ip_keys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
    
    /**
     * 清理限流记录
     */
    private function cleanupRateLimitRecords($cutoff_time) {
        $query = "DELETE FROM api_rate_limits WHERE created_at < ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$cutoff_time]);
    }
    
    /**
     * 记录请求
     */
    private function recordRequest($ip, $time) {
        $query = "INSERT INTO api_rate_limits (ip_address, created_at) VALUES (?, ?)";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$ip, $time]);
    }
    
    /**
     * 记录限流违规
     */
    private function recordRateLimitViolation($ip, $endpoint, $method, $current_count, $limit) {
        $query = "INSERT INTO rate_limit_violations 
                  (ip_address, endpoint, method, current_count, limit, created_at) 
                  VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$ip, $endpoint, $method, $current_count, $limit]);
        
        // 记录安全日志
        $this->logger->warning('Rate limit violation detected', [
            'ip' => $ip,
            'endpoint' => $endpoint,
            'method' => $method,
            'current_count' => $current_count,
            'limit' => $limit
        ]);
    }
    
    /**
     * 检查IP是否被阻止
     */
    private function isIpBlocked($ip) {
        $query = "SELECT COUNT(*) as count FROM ip_blocks 
                  WHERE ip_address = ? AND block_until > NOW()";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$ip]);
        return $stmt->fetch()['count'] > 0;
    }
    
    /**
     * 获取IP阻止信息
     */
    private function getIpBlockInfo($ip) {
        $query = "SELECT block_until, 
                  TIMESTAMPDIFF(SECOND, NOW(), block_until) as remaining_seconds 
                  FROM ip_blocks 
                  WHERE ip_address = ? AND block_until > NOW()";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$ip]);
        return $stmt->fetch() ?: ['remaining_seconds' => 0];
    }
    
    /**
     * 计算阻止时间
     */
    private function calculateBlockDuration($ip) {
        // 查询该IP的历史违规次数
        $query = "SELECT COUNT(*) as violation_count FROM rate_limit_violations 
                  WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$ip]);
        $violation_count = $stmt->fetch()['violation_count'];
        
        // 根据违规次数递增阻止时间
        if ($violation_count <= 1) {
            return 300; // 5分钟
        } elseif ($violation_count <= 3) {
            return 900; // 15分钟
        } elseif ($violation_count <= 5) {
            return 1800; // 30分钟
        } else {
            return 3600; // 1小时
        }
    }
    
    /**
     * 阻止IP地址
     */
    private function blockIpAddress($ip, $duration) {
        $block_until = date('Y-m-d H:i:s', time() + $duration);
        
        // 插入或更新阻止记录
        $query = "INSERT INTO ip_blocks (ip_address, block_until, created_at) 
                  VALUES (?, ?, NOW())
                  ON DUPLICATE KEY UPDATE 
                  block_until = GREATEST(block_until, ?),
                  updated_at = NOW()";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$ip, $block_until, $block_until]);
        
        // 记录安全日志
        $this->logger->warning('IP address blocked', [
            'ip' => $ip,
            'duration' => $duration,
            'block_until' => $block_until
        ]);
    }
    
    /**
     * 清理过期的IP阻止记录
     */
    private function cleanupExpiredBlocks() {
        $query = "DELETE FROM ip_blocks WHERE block_until <= NOW()";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
    }
    
    /**
     * 记录API访问
     */
    private function logApiAccess($user_id) {
        $query = "INSERT INTO api_access_logs (user_id, ip_address, user_agent, endpoint, method, created_at) 
                  VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $this->db->prepare($query);
        $stmt->execute([
            $user_id,
            $this->getClientIp(),
            $_SERVER['HTTP_USER_AGENT'] ?? '',
            $_SERVER['REQUEST_URI'],
            $_SERVER['REQUEST_METHOD']
        ]);
    }
    
    /**
     * 记录请求详情
     */
    private function logRequest($data) {
        $query = "INSERT INTO api_request_logs (
            method, uri, ip_address, user_agent, user_id, 
            status_code, duration_ms, request_size, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([
            $data['method'],
            $data['uri'],
            $data['ip'],
            $data['user_agent'],
            $data['user_id'],
            $data['status_code'],
            $data['duration_ms'],
            $data['request_size'],
            $data['timestamp']
        ]);
    }
    
}