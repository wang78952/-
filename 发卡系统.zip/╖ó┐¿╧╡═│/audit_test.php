<?php
/**
 * 审计系统测试脚本
 * 用于验证日志审计功能的正确性
 */

// 加载必要的文件
require_once 'check_logs_syntax.php';

// 测试函数
function runAuditTests() {
    echo "开始审计系统功能测试...\n";
    echo "======================================\n\n";
    
    try {
        // 创建审计系统实例
        echo "1. 创建LogAuditSystem实例...";
        $auditSystem = new LogAuditSystem();
        echo " ✓ 成功\n";
        
        // 测试管理员操作审计
        echo "2. 测试管理员操作审计...";
        $adminResults = $auditSystem->auditAdminOperations();
        echo " ✓ 成功\n";
        echo "   - 审计记录数: " . count($adminResults) . "\n";
        
        // 测试价格修改审计
        echo "3. 测试价格修改审计...";
        $priceResults = $auditSystem->auditPriceChanges();
        echo " ✓ 成功\n";
        echo "   - 审计记录数: " . count($priceResults) . "\n";
        
        // 测试代理提现审计
        echo "4. 测试代理提现审计...";
        $withdrawResults = $auditSystem->auditAgentWithdrawals();
        echo " ✓ 成功\n";
        echo "   - 审计记录数: " . count($withdrawResults) . "\n";
        
        // 测试异常行为检测
        echo "5. 测试异常行为检测...";
        $anomalies = $auditSystem->detectAnomalies();
        echo " ✓ 成功\n";
        echo "   - 发现异常数: " . count($anomalies) . "\n";
        
        // 测试风险评估
        echo "6. 测试风险评估...";
        $riskLevel = $auditSystem->assessRiskLevel($anomalies);
        echo " ✓ 成功\n";
        echo "   - 当前风险等级: " . $riskLevel . "\n";
        
        // 测试报告生成
        echo "7. 测试审计报告生成...";
        $reportPath = $auditSystem->generateReport('test_report');
        echo " ✓ 成功\n";
        echo "   - 报告保存路径: " . $reportPath . "\n";
        
        echo "\n======================================\n";
        echo "所有测试通过！审计系统功能正常。\n";
        
    } catch (Exception $e) {
        echo " ✗ 失败\n";
        echo "错误信息: " . $e->getMessage() . "\n";
        echo "\n测试中断！请检查错误。\n";
    }
}

// 执行测试
if (php_sapi_name() === 'cli') {
    // 命令行模式下直接运行
    runAuditTests();
} else {
    // Web模式下显示友好界面
    echo '<html>';
    echo '<head><title>审计系统测试</title>';
    echo '<style>body { font-family: Arial, sans-serif; margin: 40px; } .success { color: green; } .error { color: red; } pre { background: #f5f5f5; padding: 15px; border-radius: 5px; }</style>';
    echo '</head>';
    echo '<body>';
    echo '<h1>审计系统功能测试</h1>';
    echo '<pre>';
    ob_start();
    runAuditTests();
    $output = ob_get_clean();
    // 简单的输出格式化
    $output = str_replace('✓', '<span class="success">✓</span>', $output);
    $output = str_replace('✗', '<span class="error">✗</span>', $output);
    echo $output;
    echo '</pre>';
    echo '</body>';
    echo '</html>';
}
?>