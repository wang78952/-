/**
 * 批量操作增强功能
 * 提供批量选择、批量处理、进度显示等功能
 */

class BatchOperations {
  constructor (options = {}) {
    this.options = {
      container: options.container || '#batchOperations',
      selectAllSelector: options.selectAllSelector || '#selectAll',
      itemSelector: options.itemSelector || '.batch-item',
      progressBarSelector: options.progressBarSelector || '#batchProgress',
      statusSelector: options.statusSelector || '#batchStatus',
      ...options,
    };

    this.selectedItems = new Set();
    this.isProcessing = false;
    this.currentBatch = null;

    this.init();
  }

  init () {
    this.bindEvents();
    this.updateUI();
  }

  /**
     * 绑定事件
     */
  bindEvents () {
    // 全选/取消全选
    document.addEventListener('change', (e) => {
      if (e.target.matches(this.options.selectAllSelector)) {
        this.toggleSelectAll(e.target.checked);
      }
    });

    // 单项选择
    document.addEventListener('change', (e) => {
      if (e.target.matches(this.options.itemSelector)) {
        this.toggleItem(e.target.value, e.target.checked);
      }
    });

    // 批量操作按钮
    document.addEventListener('click', (e) => {
      if (e.target.matches('[data-batch-action]')) {
        const action = e.target.dataset.batchAction;
        this.executeBatchAction(action);
      }
    });
  }

  /**
     * 全选/取消全选
     */
  toggleSelectAll (checked) {
    const items = document.querySelectorAll(this.options.itemSelector);
    items.forEach((item) => {
      item.checked = checked;
      if (checked) {
        this.selectedItems.add(item.value);
      } else {
        this.selectedItems.delete(item.value);
      }
    });
    this.updateUI();
  }

  /**
     * 切换单项选择
     */
  toggleItem (value, checked) {
    if (checked) {
      this.selectedItems.add(value);
    } else {
      this.selectedItems.delete(value);
    }
    this.updateUI();
  }

  /**
     * 更新UI状态
     */
  updateUI () {
    const items = document.querySelectorAll(this.options.itemSelector);
    const selectAll = document.querySelector(this.options.selectAllSelector);
    const selectedCount = this.selectedItems.size;
    const totalCount = items.length;

    // 更新全选框状态
    if (selectAll) {
      selectAll.checked = selectedCount === totalCount && totalCount > 0;
      selectAll.indeterminate = selectedCount > 0 && selectedCount < totalCount;
    }

    // 更新选中数量显示
    const countDisplay = document.querySelector('[data-selected-count]');
    if (countDisplay) {
      countDisplay.textContent = selectedCount;
    }

    // 更新批量操作按钮状态
    const batchButtons = document.querySelectorAll('[data-batch-action]');
    batchButtons.forEach((button) => {
      button.disabled = selectedCount === 0 || this.isProcessing;
    });

    // 更新操作面板显示
    const batchPanel = document.querySelector('[data-batch-panel]');
    if (batchPanel) {
      batchPanel.style.display = selectedCount > 0 ? 'block' : 'none';
    }
  }

  /**
     * 执行批量操作
     */
  async executeBatchAction (action) {
    if (this.selectedItems.size === 0) {
      showNotification('请先选择要操作的项目', 'warning');
      return;
    }

    if (this.isProcessing) {
      showNotification('正在处理其他批量操作，请稍候', 'info');
      return;
    }

    const confirmed = await confirmAction(
      `确定要对选中的 ${this.selectedItems.size} 个项目执行"${this.getActionName(action)}"操作吗？`,
      '批量操作确认',
    );

    if (!confirmed) {
      return;
    }

    this.isProcessing = true;
    this.updateUI();

    try {
      await this.processBatchAction(action);
      showNotification(`批量${this.getActionName(action)}操作完成`, 'success');
      this.clearSelection();
    } catch (error) {
      console.error('批量操作失败:', error);
      showNotification(`批量操作失败: ${error.message}`, 'error');
    } finally {
      this.isProcessing = false;
      this.updateUI();
    }
  }

  /**
     * 处理批量操作
     */
  async processBatchAction (action) {
    const items = Array.from(this.selectedItems);
    const total = items.length;
    let processed = 0;
    let success = 0;
    let failed = 0;

    this.showProgress(0, total);

    // 分批处理，避免一次性处理太多请求
    const batchSize = this.options.batchSize || 5;
    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);
      const promises = batch.map((item) => this.processItem(item, action));

      const results = await Promise.allSettled(promises);

      results.forEach((result) => {
        processed++;
        if (result.status === 'fulfilled') {
          success++;
        } else {
          failed++;
        }
      });

      this.updateProgress(processed, total, success, failed);

      // 添加延迟，避免过快请求
      if (i + batchSize < items.length) {
        await this.delay(this.options.batchDelay || 100);
      }
    }

    if (failed > 0) {
      throw new Error(`成功处理 ${success} 个项目，失败 ${failed} 个项目`);
    }

    return { total, success, failed };
  }

  /**
     * 处理单个项目
     */
  async processItem (itemId, action) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', itemId);

    const response = await fetch(this.options.apiEndpoint || '/api/batch', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`处理项目 ${itemId} 失败`);
    }

    return response.json();
  }

  /**
     * 显示进度条
     */
  showProgress (current, total) {
    const progressBar = document.querySelector(this.options.progressBarSelector);
    const statusText = document.querySelector(this.options.statusSelector);

    if (progressBar) {
      progressBar.style.display = 'block';
      const percentage = (current / total) * 100;
      progressBar.style.width = percentage + '%';
      progressBar.setAttribute('aria-valuenow', percentage);
    }

    if (statusText) {
      statusText.textContent = `正在处理: ${current}/${total}`;
    }
  }

  /**
     * 更新进度
     */
  updateProgress (current, total, success, failed) {
    const progressBar = document.querySelector(this.options.progressBarSelector);
    const statusText = document.querySelector(this.options.statusSelector);

    if (progressBar) {
      const percentage = (current / total) * 100;
      progressBar.style.width = percentage + '%';
      progressBar.setAttribute('aria-valuenow', percentage);
    }

    if (statusText) {
      statusText.textContent = `处理中: ${current}/${total} (成功: ${success}, 失败: ${failed})`;
    }
  }

  /**
     * 隐藏进度条
     */
  hideProgress () {
    const progressBar = document.querySelector(this.options.progressBarSelector);
    const statusText = document.querySelector(this.options.statusSelector);

    if (progressBar) {
      progressBar.style.display = 'none';
      progressBar.style.width = '0%';
      progressBar.setAttribute('aria-valuenow', 0);
    }

    if (statusText) {
      statusText.textContent = '';
    }
  }

  /**
     * 清空选择
     */
  clearSelection () {
    this.selectedItems.clear();

    // 清空所有复选框
    const items = document.querySelectorAll(this.options.itemSelector);
    items.forEach((item) => {
      item.checked = false;
    });

    // 清空全选框
    const selectAll = document.querySelector(this.options.selectAllSelector);
    if (selectAll) {
      selectAll.checked = false;
      selectAll.indeterminate = false;
    }

    this.hideProgress();
    this.updateUI();
  }

  /**
     * 获取操作名称
     */
  getActionName (action) {
    const actionNames = {
      delete: '删除',
      enable: '启用',
      disable: '禁用',
      approve: '审批',
      reject: '拒绝',
      export: '导出',
      archive: '归档',
      restore: '恢复',
    };
    return actionNames[action] || action;
  }

  /**
     * 延迟函数
     */
  delay (ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
     * 获取选中项
     */
  getSelectedItems () {
    return Array.from(this.selectedItems);
  }

  /**
     * 设置选中项
     */
  setSelectedItems (items) {
    this.selectedItems.clear();
    items.forEach((item) => this.selectedItems.add(item));
    this.updateUI();
  }

  /**
     * 添加选中项
     */
  addSelectedItem (item) {
    this.selectedItems.add(item);
    this.updateUI();
  }

  /**
     * 移除选中项
     */
  removeSelectedItem (item) {
    this.selectedItems.delete(item);
    this.updateUI();
  }

  /**
     * 是否正在处理
     */
  isProcessingBatch () {
    return this.isProcessing;
  }

  /**
     * 获取选中数量
     */
  getSelectedCount () {
    return this.selectedItems.size;
  }

  /**
     * 销毁实例
     */
  destroy () {
    this.clearSelection();
    this.selectedItems.clear();
    this.isProcessing = false;
    this.currentBatch = null;
  }
}

// 批量操作工具函数
window.BatchOperations = BatchOperations;

// 初始化批量操作
document.addEventListener('DOMContentLoaded', () => {
  // 自动初始化页面中的批量操作
  const batchContainers = document.querySelectorAll('[data-batch-operations]');
  batchContainers.forEach((container) => {
    const options = {
      container,
      ...container.dataset,
    };
    new BatchOperations(options);
  });
});
