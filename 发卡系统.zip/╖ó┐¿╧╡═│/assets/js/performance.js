/**
 * 性能优化和动画效果JavaScript文件
 * 包含懒加载、动画控制、性能监控等功能
 */

class PerformanceOptimizer {
  constructor () {
    this.init();
  }

  init () {
    this.setupLazyLoading();
    this.setupScrollAnimations();
    this.setupIntersectionObserver();
    this.setupPerformanceMonitoring();
    this.setupImageOptimization();
    this.setupDebouncing();
    this.setupThrottling();
    this.setupVirtualScrolling();
    this.setupCacheOptimization();
    this.setupAnimationOptimization();
    this.setupVisibilityAPI();
    // 预加载关键资源
    this.preloadCriticalResources();
  }

  // 增强的图片懒加载
  setupLazyLoading () {
    // 优化配置
    const config = {
      // 更智能的观察器配置
      rootMargin: '200px 0px', // 增加预加载区域
      threshold: 0.05, // 降低触发阈值
      // 加载优先级
      priorityClasses: ['hero', 'above-fold', 'critical'],
      // 延迟加载配置
      delayLoadThreshold: 3000, // 3秒内可见的资源优先加载
    };

    // 创建更高效的图片观察器
    const imageObserver = new IntersectionObserver((entries, observer) => {
      // 分批处理可见项，避免同时加载过多资源
      const visibleEntries = entries.filter((entry) => entry.isIntersecting);

      // 按优先级排序
      visibleEntries.sort((a, b) => {
        const aHasPriority = config.priorityClasses.some((cls) => a.target.classList.contains(cls));
        const bHasPriority = config.priorityClasses.some((cls) => b.target.classList.contains(cls));

        if (aHasPriority && !bHasPriority) return -1;
        if (!aHasPriority && bHasPriority) return 1;
        return 0;
      });

      // 分批加载，避免一次性触发过多请求
      visibleEntries.forEach((entry, index) => {
        setTimeout(() => {
          this.loadLazyImage(entry.target);
          observer.unobserve(entry.target);
        }, index * 100); // 每100ms加载一个，避免请求阻塞
      });
    }, config);

    // 观察所有懒加载图片
    document.querySelectorAll('img[data-src], img[data-original]').forEach((img) => {
      // 标记初始状态
      img.classList.add('lazy-image', 'loading');
      imageObserver.observe(img);
    });

    // 观察其他资源类型（如视频、音频）
    this.setupResourceLazyLoading();
  }

  // 加载懒加载图片
  loadLazyImage (img) {
    // 处理多种懒加载属性命名方式
    const src = img.dataset.src || img.dataset.original;
    const srcset = img.dataset.srcset;
    const sizes = img.dataset.sizes;

    if (!src) return;

    // 性能监控：记录加载开始时间
    const loadStartTime = performance.now();

    // 使用Image对象预加载
    const tempImg = new Image();

    // 设置资源加载成功回调
    tempImg.onload = () => {
      // 应用预加载的图片
      img.src = src;
      if (srcset) img.srcset = srcset;
      if (sizes) img.sizes = sizes;

      // 移除懒加载属性
      img.removeAttribute('data-src');
      img.removeAttribute('data-original');
      img.removeAttribute('data-srcset');
      img.removeAttribute('data-sizes');

      // 更新状态类
      img.classList.remove('loading');
      img.classList.add('loaded');

      // 性能监控：记录加载时间
      const loadTime = performance.now() - loadStartTime;
      if (window.performance && window.performance.mark) {
        window.performance.mark(`image-loaded-${img.src}`);
      }
    };

    // 设置错误处理
    tempImg.onerror = () => {
      img.classList.remove('loading');
      img.classList.add('failed');
      // 尝试加载备用图片
      if (img.dataset.fallback) {
        img.src = img.dataset.fallback;
      }
    };

    // 开始预加载
    tempImg.src = src;
    if (srcset) tempImg.srcset = srcset;
  }

  // 扩展资源懒加载（支持视频、音频等）
  setupResourceLazyLoading () {
    // 视频懒加载
    document.querySelectorAll('video[data-src]').forEach((video) => {
      const videoObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            video.src = video.dataset.src;
            video.removeAttribute('data-src');
            videoObserver.unobserve(video);
          }
        });
      }, { threshold: 0.1 });

      videoObserver.observe(video);
    });

    // 背景图片懒加载
    document.querySelectorAll('[data-bg-src]').forEach((element) => {
      const bgObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            element.style.backgroundImage = `url(${entry.target.dataset.bgSrc})`;
            element.removeAttribute('data-bg-src');
            bgObserver.unobserve(element);
          }
        });
      }, { threshold: 0.1 });

      bgObserver.observe(element);
    });

    // 脚本懒加载
    this.lazyLoadScripts();
  }

  // 脚本懒加载
  lazyLoadScripts () {
    const scriptObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const scriptEl = entry.target;
          const src = scriptEl.dataset.src;
          const type = scriptEl.dataset.type || 'text/javascript';
          const async = scriptEl.dataset.async !== 'false';
          const defer = scriptEl.dataset.defer === 'true';

          if (src) {
            // 创建实际脚本元素
            const newScript = document.createElement('script');
            newScript.src = src;
            newScript.type = type;
            newScript.async = async;
            newScript.defer = defer;

            // 复制其他属性
            Array.from(scriptEl.attributes).forEach((attr) => {
              if (!['data-src', 'data-type', 'data-async', 'data-defer'].includes(attr.name)) {
                newScript.setAttribute(attr.name, attr.value);
              }
            });

            // 替换占位元素
            scriptEl.parentNode.insertBefore(newScript, scriptEl);
            scriptEl.parentNode.removeChild(scriptEl);
          }

          scriptObserver.unobserve(scriptEl);
        }
      });
    }, { threshold: 0.1 });

    // 观察所有脚本占位符
    document.querySelectorAll('script[data-src]').forEach((script) => {
      scriptObserver.observe(script);
    });
  }

  // 优化的预加载关键资源方法，支持CDN
  preloadCriticalResources () {
    // 使用CDN路径的关键资源列表
    const criticalResources = [
      { url: '/assets/css/main.css', type: 'style', as: 'style' },
      { url: '/assets/js/main.js', type: 'script', as: 'script' },
      { url: '/assets/css/responsive.css', type: 'style', as: 'style' },
      { url: '/assets/js/core.js', type: 'script', as: 'script' },
      // 预加载关键图片
      { url: '/assets/images/logo.png', type: 'image', as: 'image', importance: 'high' },
      { url: '/assets/images/placeholder.png', type: 'image', as: 'image' },
    ];

    // 获取文档头部
    const head = document.head;

    // 检查是否支持fetch优先的资源提示
    const supportsFetchPreload = 'requestIdleCallback' in window;

    // 批量添加预加载标签
    criticalResources.forEach((resource) => {
      // 检查资源是否已加载
      if (this.isResourceLoaded(resource.url)) return;

      // 优先使用资源提示
      const link = document.createElement('link');
      link.rel = 'preload';
      link.href = this.getResourceUrl(resource.url);
      link.as = resource.as;

      // 添加资源优先级
      if (resource.importance) {
        link.importance = resource.importance;
      }

      // 设置类型
      if (resource.type) {
        link.type = resource.type;
      }

      // 添加到头部
      try {
        head.appendChild(link);
      } catch (e) {
        console.warn('Failed to preload resource:', resource.url);
      }
    });

    // 使用空闲时间预缓存其他资源
    if (supportsFetchPreload) {
      requestIdleCallback(() => {
        this.preloadSecondaryResources();
      });
    }
  }

  // 预加载次要资源
  preloadSecondaryResources () {
    const secondaryResources = [
      { url: '/assets/js/utils.js', as: 'script' },
      { url: '/assets/css/animations.css', as: 'style' },
    ];

    secondaryResources.forEach((resource) => {
      if (!this.isResourceLoaded(resource.url)) {
        // 使用fetch API预加载
        try {
          fetch(this.getResourceUrl(resource.url), {
            method: 'GET',
            mode: 'cors',
            credentials: 'same-origin',
            cache: 'force-cache',
          });
        } catch (e) {
          console.warn('Failed to prefetch resource:', resource.url);
        }
      }
    });
  }

  // 获取资源URL（支持CDN）
  getResourceUrl (path) {
    // 检查是否有CDN集成
    if (window.cdnEnabled && window.cdnUrl) {
      // 已经是完整URL的资源不处理
      if (path.startsWith('http://') || path.startsWith('https://')) {
        return path;
      }
      // 处理CDN路径
      return window.cdnUrl + path;
    }
    return path;
  }

  // 检查资源是否已加载
  isResourceLoaded (url) {
    // 检查已加载的脚本
    if (url.endsWith('.js')) {
      return Array.from(document.scripts).some((script) =>
        script.src && script.src.includes(url),
      );
    }
    // 检查已加载的样式
    if (url.endsWith('.css')) {
      return Array.from(document.styleSheets).some((sheet) => {
        try {
          return sheet.href && sheet.href.includes(url);
        } catch (e) {
          return false;
        }
      });
    }
    return false;
  }

  // 优化的代码分割懒加载
  async loadModule (moduleName, options = {}) {
    // 添加缓存支持
    const cacheKey = `module_${moduleName}`;
    const cachedModule = this.getCache(cacheKey);

    if (cachedModule && !options.forceReload) {
      return cachedModule;
    }

    try {
      // 显示加载指示器
      if (options.loadingIndicatorId) {
        const indicator = document.getElementById(options.loadingIndicatorId);
        if (indicator) indicator.style.display = 'block';
      }

      // 使用CDN路径加载模块
      const modulePath = this.getResourceUrl(`/assets/js/modules/${moduleName}.js`);

      // 动态加载模块
      const module = await import(modulePath);

      // 缓存模块
      this.setCache(cacheKey, module.default || module);

      // 隐藏加载指示器
      if (options.loadingIndicatorId) {
        const indicator = document.getElementById(options.loadingIndicatorId);
        if (indicator) indicator.style.display = 'none';
      }

      return module.default || module;
    } catch (error) {
      console.error('模块加载失败:', error);
      // 降级处理：尝试加载本地备用版本
      try {
        const fallbackModule = await import(`/assets/js/modules/fallback/${moduleName}.js`);
        return fallbackModule.default || fallbackModule;
      } catch (fallbackError) {
        console.error('备用模块加载失败:', fallbackError);
        return null;
      }
    }
  }

  // 性能监控增强
  setupPerformanceMonitoring () {
    // 页面加载性能监控
    window.addEventListener('load', () => {
      if ('performance' in window && 'getEntriesByType' in performance) {
        const perfData = performance.getEntriesByType('navigation')[0];

        // 记录详细性能指标
        const performanceMetrics = {
          pageLoadTime: perfData.loadEventEnd - perfData.startTime,
          domReadyTime: perfData.domContentLoadedEventEnd - perfData.startTime,
          ttfb: perfData.responseStart - perfData.requestStart,
          resourceLoadTime: perfData.loadEventEnd - perfData.responseEnd,
        };

        console.log('页面性能指标:', performanceMetrics);

        // 性能较差时自动启用性能模式
        if (performanceMetrics.pageLoadTime > 3000) {
          this.enablePerformanceMode();
        }

        // 可以将性能数据发送到服务器进行分析
        // this.sendPerformanceData(performanceMetrics);
      }
    });

    // 长任务监控
    if ('PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        list.getEntries().forEach((entry) => {
          if (entry.duration > 50) {
            console.warn('长任务检测:', entry.name, entry.duration + 'ms');
            // 记录长任务以优化
            this.recordLongTask(entry);
          }
        });
      });

      observer.observe({ entryTypes: ['longtask'] });
    }
  }

  // 记录长任务以进行优化
  recordLongTask (entry) {
    // 简单的长任务统计
    if (!window._longTasks) {
      window._longTasks = [];
    }

    // 只保留最近10个长任务
    window._longTasks.push({
      name: entry.name,
      duration: entry.duration,
      startTime: entry.startTime,
      timestamp: new Date().toISOString(),
    });

    if (window._longTasks.length > 10) {
      window._longTasks.shift();
    }
  }

  // 启用性能模式
  enablePerformanceMode () {
    console.log('启用高性能模式');

    // 添加性能模式类
    document.documentElement.classList.add('performance-mode');

    // 减少动画复杂度
    this.optimizeAnimations();

    // 延迟加载非关键资源
    this.deferNonCriticalResources();

    // 启用图片优化
    this.forceImageOptimization();
  }

  // 延迟加载非关键资源
  deferNonCriticalResources () {
    // 找到并延迟加载非关键脚本
    document.querySelectorAll('script:not([defer]):not([async]):not([critical])').forEach((script) => {
      // 只处理外部脚本
      if (script.src && !script.src.includes('critical')) {
        script.defer = true;
      }
    });
  }

  // 强制图片优化
  forceImageOptimization () {
    // 为所有图片添加延迟加载标记
    document.querySelectorAll('img:not([data-src]):not([data-original]):not(.already-optimized)').forEach((img) => {
      img.classList.add('already-optimized');
      // 可以在这里应用额外的图片优化
    });
  }

  // 利用可见性API优化资源加载
  setupVisibilityAPI () {
    // 当页面隐藏时暂停动画和资源加载
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.pauseAnimations();
        // 暂停非关键资源加载
        this.pauseResourceLoading();
      } else {
        this.resumeAnimations();
        // 恢复资源加载
        this.resumeResourceLoading();
      }
    });
  }

  // 暂停非关键资源加载
  pauseResourceLoading () {
    // 记录正在加载的资源
    this.pausedResources = [];

    // 这里可以实现暂停正在进行的网络请求
    // 注意：完全暂停网络请求需要更复杂的实现
  }

  // 恢复资源加载
  resumeResourceLoading () {
    // 恢复之前暂停的资源加载
    // 这里需要根据暂停时的状态进行恢复
  }

  // 事件处理器
  handleSearch (query) {
    // 搜索逻辑
    console.log('搜索:', query);
  }

  handleResize () {
    // 响应式处理
    console.log('窗口大小改变');
  }

  handleScroll () {
    // 滚动处理
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    // 导航栏效果
    const navbar = document.querySelector('.navbar');
    if (navbar) {
      if (scrollTop > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }
  }

  handleMouseMove () {
    // 鼠标移动处理
  }

  // 页面可见性API
  setupVisibilityAPI () {
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        // 页面隐藏时暂停动画
        this.pauseAnimations();
      } else {
        // 页面显示时恢复动画
        this.resumeAnimations();
      }
    });
  }

  pauseAnimations () {
    const animatedElements = document.querySelectorAll('.animated');
    animatedElements.forEach((element) => {
      element.style.animationPlayState = 'paused';
    });
  }

  resumeAnimations () {
    const animatedElements = document.querySelectorAll('.animated');
    animatedElements.forEach((element) => {
      element.style.animationPlayState = 'running';
    });
  }

  // 防抖函数
  debounce (func, wait) {
    let timeout;
    return function executedFunction (...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // 获取资源URL（集成CDN支持）
  getResourceUrl (path) {
    // 检查是否有全局CDN配置
    if (window.cdnEnabled && window.cdnUrl) {
      // 已经是完整URL的资源不处理
      if (path.startsWith('http://') || path.startsWith('https://')) {
        return path;
      }
      // 处理CDN路径
      return window.cdnUrl + path;
    }
    // 检查是否有服务器端渲染的CDN配置
    if (window.__cdnConfig && window.__cdnConfig.enabled && window.__cdnConfig.baseUrl) {
      return window.__cdnConfig.baseUrl + path;
    }
    return path;
  }
}

// 全局实例，方便调用
window.PerformanceOptimizer = PerformanceOptimizer;

// 初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.performanceOptimizer = new PerformanceOptimizer();
  });
} else {
  window.performanceOptimizer = new PerformanceOptimizer();
}

// 导出类（支持模块化）
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PerformanceOptimizer };
}
