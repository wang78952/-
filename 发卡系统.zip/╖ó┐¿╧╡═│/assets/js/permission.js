/**
 * 权限管理JavaScript文件
 * 处理角色管理、权限管理、权限申请审批等前端交互
 */

class PermissionManager {
  constructor () {
    this.apiBase = 'api/permission';
    this.currentTab = 'overview';
    this.init();
  }

  init () {
    this.bindEvents();
    this.loadInitialData();
  }

  bindEvents () {
    // Tab切换事件
    document.querySelectorAll('[data-bs-toggle="pill"]').forEach((tab) => {
      tab.addEventListener('shown.bs.tab', (e) => {
        this.currentTab = e.target.getAttribute('href').substring(1);
        this.loadTabData();
      });
    });

    // 表单提交事件
    document.getElementById('createRoleForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.createRole();
    });

    document.getElementById('createPermissionForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.createPermission();
    });

    document.getElementById('assignRoleForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.assignRole();
    });

    document.getElementById('requestPermissionForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.submitPermissionRequest();
    });

    document.getElementById('approvalForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.submitApproval();
    });

    // 申请类型切换
    document.querySelector('[name="request_type"]')?.addEventListener('change', (e) => {
      this.toggleRequestTarget(e.target.value);
    });

    // 审批动作切换
    document.querySelector('[name="action"]')?.addEventListener('change', (e) => {
      this.toggleNextApprover(e.target.value);
    });
  }

  async loadInitialData () {
    await this.loadRecentActivities();
    await this.loadRoles();
    await this.loadPermissions();
    await this.loadPendingApprovals();
  }

  async loadTabData () {
    switch (this.currentTab) {
    case 'roles':
      await this.loadRoles();
      break;
    case 'permissions':
      await this.loadPermissions();
      break;
    case 'requests':
      await this.loadPermissionRequests();
      break;
    case 'approvals':
      await this.loadPendingApprovals();
      break;
    case 'audit':
      await this.loadAuditLogs();
      break;
    }
  }

  // API请求封装
  async apiRequest (endpoint, options = {}) {
    const token = localStorage.getItem('auth_token');
    const defaultOptions = {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    };

    const response = await fetch(`${this.apiBase}/${endpoint}`, {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || '请求失败');
    }

    return response.json();
  }

  // 加载最近活动
  async loadRecentActivities () {
    try {
      const response = await this.apiRequest('audit-logs?limit=10');
      const activities = response.data;

      const container = document.getElementById('recent-activities');
      if (activities.length === 0) {
        container.innerHTML = '<p class="text-muted">暂无最近活动</p>';
        return;
      }

      container.innerHTML = activities.map((activity) => `
                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                    <div>
                        <strong>${this.getActionText(activity.action)}</strong>
                        <span class="text-muted">${activity.resource_type}</span>
                        ${activity.target_username ? `<span class="text-muted"> - ${activity.target_username}</span>` : ''}
                    </div>
                    <small class="text-muted">${this.formatDateTime(activity.created_at)}</small>
                </div>
            `).join('');
    } catch (error) {
      console.error('加载最近活动失败:', error);
    }
  }

  // 加载角色列表
  async loadRoles (filters = {}) {
    try {
      const queryString = new URLSearchParams(filters).toString();
      const response = await this.apiRequest(`roles${queryString ? '?' + queryString : ''}`);
      const roles = response.data;

      const container = document.getElementById('roles-list');
      if (roles.length === 0) {
        container.innerHTML = '<p class="text-muted">暂无角色数据</p>';
        return;
      }

      container.innerHTML = `
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>角色名称</th>
                                <th>显示名称</th>
                                <th>等级</th>
                                <th>状态</th>
                                <th>用户数量</th>
                                <th>创建时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${roles.map((role) => `
                                <tr>
                                    <td>
                                        <code>${role.name}</code>
                                    </td>
                                    <td>${role.display_name}</td>
                                    <td><span class="badge bg-info">${role.level}</span></td>
                                    <td>
                                        <span class="badge ${role.is_active ? 'bg-success' : 'bg-danger'}">
                                            ${role.is_active ? '启用' : '禁用'}
                                        </span>
                                    </td>
                                    <td>${role.user_count || 0}</td>
                                    <td>${this.formatDateTime(role.created_at)}</td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" onclick="permissionManager.editRole(${role.id})">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button class="btn btn-outline-info" onclick="permissionManager.viewRolePermissions(${role.id})">
                                                <i class="bi bi-key"></i>
                                            </button>
                                            <button class="btn btn-outline-danger" onclick="permissionManager.deleteRole(${role.id})">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
    } catch (error) {
      console.error('加载角色列表失败:', error);
      this.showError('加载角色列表失败');
    }
  }

  // 加载权限列表
  async loadPermissions (filters = {}) {
    try {
      const queryString = new URLSearchParams(filters).toString();
      const response = await this.apiRequest(`permissions${queryString ? '?' + queryString : ''}`);
      const permissions = response.data;

      const container = document.getElementById('permissions-list');
      if (permissions.length === 0) {
        container.innerHTML = '<p class="text-muted">暂无权限数据</p>';
        return;
      }

      // 按模块分组
      const groupedPermissions = this.groupByModule(permissions);

      container.innerHTML = Object.entries(groupedPermissions).map(([module, perms]) => `
                <div class="permission-group">
                    <div class="permission-group-title">
                        <i class="bi bi-folder"></i> ${this.getModuleText(module)}
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>权限名称</th>
                                    <th>显示名称</th>
                                    <th>操作类型</th>
                                    <th>资源</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${perms.map((permission) => `
                                    <tr>
                                        <td><code>${permission.name}</code></td>
                                        <td>${permission.display_name}</td>
                                        <td><span class="badge bg-secondary">${this.getActionText(permission.action)}</span></td>
                                        <td>${permission.resource || '-'}</td>
                                        <td>
                                            <span class="badge ${permission.is_active ? 'bg-success' : 'bg-danger'}">
                                                ${permission.is_active ? '启用' : '禁用'}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <button class="btn btn-outline-primary" onclick="permissionManager.editPermission(${permission.id})">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button class="btn btn-outline-danger" onclick="permissionManager.deletePermission(${permission.id})">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `).join('');
    } catch (error) {
      console.error('加载权限列表失败:', error);
      this.showError('加载权限列表失败');
    }
  }

  // 加载权限申请
  async loadPermissionRequests (filters = {}) {
    try {
      const queryString = new URLSearchParams(filters).toString();
      const response = await this.apiRequest(`requests${queryString ? '?' + queryString : ''}`);
      const requests = response.data;

      const container = document.getElementById('requests-list');
      if (requests.length === 0) {
        container.innerHTML = '<p class="text-muted">暂无申请数据</p>';
        return;
      }

      container.innerHTML = `
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>申请人</th>
                                <th>申请类型</th>
                                <th>申请内容</th>
                                <th>优先级</th>
                                <th>状态</th>
                                <th>申请时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${requests.map((request) => `
                                <tr class="${request.status === 'pending' ? 'approval-pending' : ''}">
                                    <td>${request.username}</td>
                                    <td>
                                        <span class="badge ${request.request_type === 'role' ? 'bg-primary' : 'bg-success'}">
                                            ${request.request_type === 'role' ? '角色' : '权限'}
                                        </span>
                                    </td>
                                    <td>${request.target_name}</td>
                                    <td>
                                        <span class="badge ${this.getPriorityBadgeClass(request.priority)}">
                                            ${this.getPriorityText(request.priority)}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge ${this.getStatusBadgeClass(request.status)}">
                                            ${this.getStatusText(request.status)}
                                        </span>
                                    </td>
                                    <td>${this.formatDateTime(request.created_at)}</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-info" onclick="permissionManager.viewRequest(${request.id})">
                                            <i class="bi bi-eye"></i> 查看
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
    } catch (error) {
      console.error('加载权限申请失败:', error);
      this.showError('加载权限申请失败');
    }
  }

  // 加载待审批申请
  async loadPendingApprovals () {
    try {
      const response = await this.apiRequest('pending-requests');
      const requests = response.data;

      const container = document.getElementById('approvals-list');
      if (requests.length === 0) {
        container.innerHTML = '<p class="text-muted">暂无待审批申请</p>';
        return;
      }

      container.innerHTML = requests.map((request) => `
                <div class="card mb-3 approval-pending">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <h6>
                                    ${request.request_type === 'role' ? '角色申请' : '权限申请'}
                                    <span class="badge ${this.getPriorityBadgeClass(request.priority)} ms-2">
                                        ${this.getPriorityText(request.priority)}
                                    </span>
                                </h6>
                                <p class="mb-1">
                                    <strong>申请人:</strong> ${request.username}
                                </p>
                                <p class="mb-1">
                                    <strong>申请内容:</strong> ${request.target_name}
                                </p>
                                <p class="mb-1">
                                    <strong>申请理由:</strong> ${request.reason}
                                </p>
                                <small class="text-muted">
                                    申请时间: ${this.formatDateTime(request.created_at)}
                                </small>
                            </div>
                            <div class="col-md-4 text-end">
                                <button class="btn btn-success mb-2" onclick="permissionManager.approveRequest(${request.id})">
                                    <i class="bi bi-check-circle"></i> 批准
                                </button>
                                <br>
                                <button class="btn btn-danger mb-2" onclick="permissionManager.rejectRequest(${request.id})">
                                    <i class="bi bi-x-circle"></i> 拒绝
                                </button>
                                <br>
                                <button class="btn btn-warning" onclick="permissionManager.forwardRequest(${request.id})">
                                    <i class="bi bi-arrow-right-circle"></i> 转发
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `).join('');
    } catch (error) {
      console.error('加载待审批申请失败:', error);
      this.showError('加载待审批申请失败');
    }
  }

  // 加载审计日志
  async loadAuditLogs (filters = {}) {
    try {
      const queryString = new URLSearchParams(filters).toString();
      const response = await this.apiRequest(`audit-logs${queryString ? '?' + queryString : ''}`);
      const logs = response.data;

      const container = document.getElementById('audit-logs-list');
      if (logs.length === 0) {
        container.innerHTML = '<p class="text-muted">暂无审计日志</p>';
        return;
      }

      container.innerHTML = `
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>操作人</th>
                                <th>操作</th>
                                <th>资源类型</th>
                                <th>目标用户</th>
                                <th>IP地址</th>
                                <th>操作时间</th>
                                <th>详情</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${logs.map((log) => `
                                <tr>
                                    <td>${log.operator_username}</td>
                                    <td>
                                        <span class="badge ${this.getActionBadgeClass(log.action)}">
                                            ${this.getActionText(log.action)}
                                        </span>
                                    </td>
                                    <td>${this.getResourceTypeText(log.resource_type)}</td>
                                    <td>${log.target_username || '-'}</td>
                                    <td><code>${log.ip_address}</code></td>
                                    <td>${this.formatDateTime(log.created_at)}</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-info" onclick="permissionManager.viewLogDetails(${log.id})">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
    } catch (error) {
      console.error('加载审计日志失败:', error);
      this.showError('加载审计日志失败');
    }
  }

  // 创建角色
  async createRole () {
    const form = document.getElementById('createRoleForm');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await this.apiRequest('roles', {
        method: 'POST',
        body: JSON.stringify(data),
      });

      this.showSuccess('角色创建成功');
      bootstrap.Modal.getInstance(document.getElementById('createRoleModal')).hide();
      form.reset();
      await this.loadRoles();
    } catch (error) {
      this.showError(error.message);
    }
  }

  // 创建权限
  async createPermission () {
    const form = document.getElementById('createPermissionForm');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await this.apiRequest('permissions', {
        method: 'POST',
        body: JSON.stringify(data),
      });

      this.showSuccess('权限创建成功');
      bootstrap.Modal.getInstance(document.getElementById('createPermissionModal')).hide();
      form.reset();
      await this.loadPermissions();
    } catch (error) {
      this.showError(error.message);
    }
  }

  // 分配角色
  async assignRole () {
    const form = document.getElementById('assignRoleForm');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await this.apiRequest('assign-role', {
        method: 'POST',
        body: JSON.stringify(data),
      });

      this.showSuccess('角色分配成功');
      bootstrap.Modal.getInstance(document.getElementById('assignRoleModal')).hide();
      form.reset();
    } catch (error) {
      this.showError(error.message);
    }
  }

  // 提交权限申请
  async submitPermissionRequest () {
    const form = document.getElementById('requestPermissionForm');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await this.apiRequest('requests', {
        method: 'POST',
        body: JSON.stringify(data),
      });

      this.showSuccess('申请提交成功');
      bootstrap.Modal.getInstance(document.getElementById('requestPermissionModal')).hide();
      form.reset();
      await this.loadPermissionRequests();
    } catch (error) {
      this.showError(error.message);
    }
  }

  // 审批申请
  async submitApproval () {
    const form = document.getElementById('approvalForm');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    const requestId = form.dataset.requestId;
    if (!requestId) {
      this.showError('申请ID缺失');
      return;
    }

    try {
      const response = await this.apiRequest('approve', {
        method: 'POST',
        body: JSON.stringify({
          request_id: parseInt(requestId),
          ...data,
        }),
      });

      this.showSuccess('审批处理成功');
      bootstrap.Modal.getInstance(document.getElementById('approvalModal')).hide();
      form.reset();
      delete form.dataset.requestId;

      await this.loadPendingApprovals();
      await this.loadPermissionRequests();
    } catch (error) {
      this.showError(error.message);
    }
  }

  // 工具函数
  groupByModule (permissions) {
    return permissions.reduce((groups, permission) => {
      const module = permission.module || 'other';
      if (!groups[module]) {
        groups[module] = [];
      }
      groups[module].push(permission);
      return groups;
    }, {});
  }

  getActionText (action) {
    const actions = {
      create: '创建',
      update: '更新',
      delete: '删除',
      view: '查看',
      assign: '分配',
      revoke: '撤销',
      approve: '审批',
      audit: '审计',
    };
    return actions[action] || action;
  }

  getModuleText (module) {
    const modules = {
      user: '用户管理',
      product: '商品管理',
      order: '订单管理',
      permission: '权限管理',
      system: '系统管理',
      other: '其他',
    };
    return modules[module] || module;
  }

  getPriorityText (priority) {
    const priorities = {
      low: '低',
      medium: '中',
      high: '高',
      urgent: '紧急',
    };
    return priorities[priority] || priority;
  }

  getPriorityBadgeClass (priority) {
    const classes = {
      low: 'bg-secondary',
      medium: 'bg-info',
      high: 'bg-warning',
      urgent: 'bg-danger',
    };
    return classes[priority] || 'bg-secondary';
  }

  getStatusText (status) {
    const statuses = {
      pending: '待审批',
      approved: '已批准',
      rejected: '已拒绝',
      cancelled: '已取消',
    };
    return statuses[status] || status;
  }

  getStatusBadgeClass (status) {
    const classes = {
      pending: 'bg-warning',
      approved: 'bg-success',
      rejected: 'bg-danger',
      cancelled: 'bg-secondary',
    };
    return classes[status] || 'bg-secondary';
  }

  getActionBadgeClass (action) {
    const classes = {
      create: 'bg-success',
      update: 'bg-primary',
      delete: 'bg-danger',
      view: 'bg-info',
      assign: 'bg-warning',
      revoke: 'bg-secondary',
      approve: 'bg-success',
      audit: 'bg-dark',
    };
    return classes[action] || 'bg-secondary';
  }

  getResourceTypeText (type) {
    const types = {
      role: '角色',
      permission: '权限',
      user_role: '用户角色',
      user_permission: '用户权限',
    };
    return types[type] || type;
  }

  formatDateTime (dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN');
  }

  // UI交互函数
  showSuccess (message) {
    // 使用Bootstrap的toast或其他通知组件
    alert('成功: ' + message);
  }

  showError (message) {
    // 使用Bootstrap的toast或其他通知组件
    alert('错误: ' + message);
  }

  toggleRequestTarget (type) {
    const targetSelect = document.querySelector('[name="target_id"]');
    if (!type) {
      targetSelect.innerHTML = '<option value="">先选择申请类型</option>';
      return;
    }

    // 根据类型加载相应的选项
    if (type === 'role') {
      this.loadRoleOptions(targetSelect);
    } else if (type === 'permission') {
      this.loadPermissionOptions(targetSelect);
    }
  }

  async loadRoleOptions (select) {
    try {
      const response = await this.apiRequest('roles');
      const roles = response.data;

      select.innerHTML = '<option value="">选择角色</option>' +
                roles.map((role) => `<option value="${role.id}">${role.display_name}</option>`).join('');
    } catch (error) {
      console.error('加载角色选项失败:', error);
    }
  }

  async loadPermissionOptions (select) {
    try {
      const response = await this.apiRequest('permissions');
      const permissions = response.data;

      select.innerHTML = '<option value="">选择权限</option>' +
                permissions.map((permission) => `<option value="${permission.id}">${permission.display_name}</option>`).join('');
    } catch (error) {
      console.error('加载权限选项失败:', error);
    }
  }

  toggleNextApprover (action) {
    const nextApproverGroup = document.getElementById('next-approver-group');
    if (action === 'forward') {
      nextApproverGroup.style.display = 'block';
      // 这里应该加载可转发的审批人列表
    } else {
      nextApproverGroup.style.display = 'none';
    }
  }

  // 筛选函数
  filterRoles () {
    const filters = {
      is_active: document.getElementById('role-status-filter').value,
      level_min: document.getElementById('role-level-min').value,
      level_max: document.getElementById('role-level-max').value,
    };

    // 移除空值
    Object.keys(filters).forEach((key) => {
      if (!filters[key]) delete filters[key];
    });

    this.loadRoles(filters);
  }

  resetRoleFilters () {
    document.getElementById('role-status-filter').value = '';
    document.getElementById('role-level-min').value = '';
    document.getElementById('role-level-max').value = '';
    this.loadRoles();
  }

  filterPermissions () {
    const filters = {
      module: document.getElementById('permission-module-filter').value,
      action: document.getElementById('permission-action-filter').value,
      is_active: document.getElementById('permission-status-filter').value,
    };

    // 移除空值
    Object.keys(filters).forEach((key) => {
      if (!filters[key]) delete filters[key];
    });

    this.loadPermissions(filters);
  }

  resetPermissionFilters () {
    document.getElementById('permission-module-filter').value = '';
    document.getElementById('permission-action-filter').value = '';
    document.getElementById('permission-status-filter').value = '';
    this.loadPermissions();
  }

  filterRequests () {
    const filters = {
      status: document.getElementById('request-status-filter').value,
      request_type: document.getElementById('request-type-filter').value,
      priority: document.getElementById('request-priority-filter').value,
    };

    // 移除空值
    Object.keys(filters).forEach((key) => {
      if (!filters[key]) delete filters[key];
    });

    this.loadPermissionRequests(filters);
  }

  resetRequestFilters () {
    document.getElementById('request-status-filter').value = '';
    document.getElementById('request-type-filter').value = '';
    document.getElementById('request-priority-filter').value = '';
    this.loadPermissionRequests();
  }

  filterAuditLogs () {
    const filters = {
      action: document.getElementById('audit-action-filter').value,
      resource_type: document.getElementById('audit-resource-filter').value,
      date_from: document.getElementById('audit-date-from').value,
      date_to: document.getElementById('audit-date-to').value,
    };

    // 移除空值
    Object.keys(filters).forEach((key) => {
      if (!filters[key]) delete filters[key];
    });

    this.loadAuditLogs(filters);
  }

  resetAuditFilters () {
    document.getElementById('audit-action-filter').value = '';
    document.getElementById('audit-resource-filter').value = '';
    document.getElementById('audit-date-from').value = '';
    document.getElementById('audit-date-to').value = '';
    this.loadAuditLogs();
  }

  // 导出函数
  exportPermissionReport () {
    // 实现权限报告导出
    this.showSuccess('权限报告导出功能开发中...');
  }

  exportAuditLogs () {
    // 实现审计日志导出
    this.showSuccess('审计日志导出功能开发中...');
  }

  // 模态框显示函数
  showCreateRoleModal () {
    const modal = new bootstrap.Modal(document.getElementById('createRoleModal'));
    modal.show();
  }

  showCreatePermissionModal () {
    const modal = new bootstrap.Modal(document.getElementById('createPermissionModal'));
    modal.show();
  }

  showAssignRoleModal () {
    const modal = new bootstrap.Modal(document.getElementById('assignRoleModal'));
    // 加载角色选项
    this.loadRoleOptions(document.querySelector('[name="role_id"]'));
    modal.show();
  }

  showRequestPermissionModal () {
    const modal = new bootstrap.Modal(document.getElementById('requestPermissionModal'));
    modal.show();
  }

  // 审批相关函数
  approveRequest (requestId) {
    const form = document.getElementById('approvalForm');
    form.dataset.requestId = requestId;
    document.querySelector('[name="action"]').value = 'approve';

    const modal = new bootstrap.Modal(document.getElementById('approvalModal'));
    modal.show();
  }

  rejectRequest (requestId) {
    const form = document.getElementById('approvalForm');
    form.dataset.requestId = requestId;
    document.querySelector('[name="action"]').value = 'reject';

    const modal = new bootstrap.Modal(document.getElementById('approvalModal'));
    modal.show();
  }

  forwardRequest (requestId) {
    const form = document.getElementById('approvalForm');
    form.dataset.requestId = requestId;
    document.querySelector('[name="action"]').value = 'forward';
    this.toggleNextApprover('forward');

    const modal = new bootstrap.Modal(document.getElementById('approvalModal'));
    modal.show();
  }

  // 其他操作函数
  editRole (roleId) {
    this.showSuccess('编辑角色功能开发中...');
  }

  viewRolePermissions (roleId) {
    this.showSuccess('查看角色权限功能开发中...');
  }

  deleteRole (roleId) {
    if (confirm('确定要删除这个角色吗？')) {
      this.showSuccess('删除角色功能开发中...');
    }
  }

  editPermission (permissionId) {
    this.showSuccess('编辑权限功能开发中...');
  }

  deletePermission (permissionId) {
    if (confirm('确定要删除这个权限吗？')) {
      this.showSuccess('删除权限功能开发中...');
    }
  }

  viewRequest (requestId) {
    this.showSuccess('查看申请详情功能开发中...');
  }

  viewLogDetails (logId) {
    this.showSuccess('查看日志详情功能开发中...');
  }

  searchUser () {
    const userId = document.getElementById('user-search').value;
    if (!userId) {
      this.showError('请输入用户ID');
      return;
    }
    this.loadUserPermissions(userId);
  }

  async loadUserPermissions (userId) {
    try {
      const [roles, permissions] = await Promise.all([
        this.apiRequest(`user-roles/${userId}`),
        this.apiRequest(`user-permissions/${userId}`),
      ]);

      const container = document.getElementById('user-permissions-content');
      container.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6>用户角色</h6>
                            </div>
                            <div class="card-body">
                                ${roles.data.length > 0
    ? roles.data.map((role) => `
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="badge bg-primary">${role.display_name}</span>
                                        <button class="btn btn-sm btn-outline-danger" onclick="permissionManager.revokeUserRole(${userId}, ${role.id})">
                                            撤销
                                        </button>
                                    </div>
                                `).join('')
    : '<p class="text-muted">暂无角色</p>'}
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6>用户权限</h6>
                            </div>
                            <div class="card-body">
                                <div class="permission-tree">
                                    ${permissions.data.length > 0 ? this.groupByModule(permissions.data) : '<p class="text-muted">暂无权限</p>'}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
    } catch (error) {
      console.error('加载用户权限失败:', error);
      this.showError('加载用户权限失败');
    }
  }

  revokeUserRole (userId, roleId) {
    if (confirm('确定要撤销这个角色吗？')) {
      this.showSuccess('撤销角色功能开发中...');
    }
  }
}

// 全局函数，供HTML调用
let permissionManager;

document.addEventListener('DOMContentLoaded', function () {
  permissionManager = new PermissionManager();
});

// 模态框相关的全局函数
function showCreateRoleModal () {
  permissionManager.showCreateRoleModal();
}

function showCreatePermissionModal () {
  permissionManager.showCreatePermissionModal();
}

function showAssignRoleModal () {
  permissionManager.showAssignRoleModal();
}

function createRole () {
  permissionManager.createRole();
}

function createPermission () {
  permissionManager.createPermission();
}

function assignRole () {
  permissionManager.assignRole();
}

function submitPermissionRequest () {
  permissionManager.submitPermissionRequest();
}

function submitApproval () {
  permissionManager.submitApproval();
}

function toggleRequestTarget () {
  const type = document.querySelector('[name="request_type"]').value;
  permissionManager.toggleRequestTarget(type);
}

function filterRoles () {
  permissionManager.filterRoles();
}

function resetRoleFilters () {
  permissionManager.resetRoleFilters();
}

function filterPermissions () {
  permissionManager.filterPermissions();
}

function resetPermissionFilters () {
  permissionManager.resetPermissionFilters();
}

function filterRequests () {
  permissionManager.filterRequests();
}

function resetRequestFilters () {
  permissionManager.resetRequestFilters();
}

function filterAuditLogs () {
  permissionManager.filterAuditLogs();
}

function resetAuditFilters () {
  permissionManager.resetAuditFilters();
}

function exportPermissionReport () {
  permissionManager.exportPermissionReport();
}

function exportAuditLogs () {
  permissionManager.exportAuditLogs();
}

function searchUser () {
  permissionManager.searchUser();
}
