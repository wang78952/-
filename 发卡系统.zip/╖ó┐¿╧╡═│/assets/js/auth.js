// 登录注册页面交互逻辑
class AuthPage {
  constructor () {
    this.currentTab = 'login';
    this.countdown = 0;
    this.countdownTimer = null;

    this.init();
  }

  init () {
    this.bindEvents();
    this.initTabSwitching();
    this.initFormValidation();
    this.initPasswordToggle();
    this.initPasswordStrength();
    this.initSocialLogin();
    this.initVerificationCode();
  }

  // 绑定事件
  bindEvents () {
    // 表单提交事件
    document.getElementById('loginForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleLogin();
    });

    document.getElementById('registerForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleRegister();
    });

    // 输入框实时验证
    const inputs = document.querySelectorAll('.form-input');
    inputs.forEach((input) => {
      input.addEventListener('blur', () => {
        this.validateField(input);
      });

      input.addEventListener('input', () => {
        if (input.classList.contains('error')) {
          this.validateField(input);
        }

        // 密码强度检测
        if (input.id === 'registerPassword') {
          this.checkPasswordStrength(input.value);
        }
      });
    });

    // 忘记密码链接
    document.querySelector('.forgot-password')?.addEventListener('click', (e) => {
      e.preventDefault();
      this.handleForgotPassword();
    });

    // 协议链接
    document.querySelector('.terms-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      this.showTerms('terms');
    });

    document.querySelector('.privacy-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      this.showTerms('privacy');
    });
  }

  // 初始化标签切换
  initTabSwitching () {
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');

    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        if (tabName === this.currentTab) return;

        // 更新标签状态
        tabs.forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');

        // 切换表单显示
        forms.forEach((form) => {
          form.classList.remove('active');
        });

        const targetForm = document.getElementById(`${tabName}Form`);
        if (targetForm) {
          targetForm.classList.add('active');
        }

        // 更新头部文案
        this.updateHeader(tabName);
        this.currentTab = tabName;
      });
    });
  }

  // 更新头部文案
  updateHeader (tabName) {
    const header = document.querySelector('.auth-header');
    if (!header) return;

    if (tabName === 'login') {
      header.innerHTML = `
                <h2>欢迎回来</h2>
                <p>登录您的账户，开始购买卡密</p>
            `;
    } else {
      header.innerHTML = `
                <h2>创建新账户</h2>
                <p>注册账户，享受更多优惠和服务</p>
            `;
    }
  }

  // 初始化表单验证
  initFormValidation () {
    // 邮箱/手机号验证
    this.validators = {
      loginEmail: (value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^1[3-9]\d{9}$/;
        return emailRegex.test(value) || phoneRegex.test(value);
      },
      registerPhone: (value) => {
        const phoneRegex = /^1[3-9]\d{9}$/;
        return phoneRegex.test(value);
      },
      loginPassword: (value) => {
        return value.length >= 6;
      },
      registerPassword: (value) => {
        return value.length >= 6 && value.length <= 20;
      },
      confirmPassword: (value) => {
        const password = document.getElementById('registerPassword').value;
        return value === password;
      },
      verifyCode: (value) => {
        return /^\d{6}$/.test(value);
      },
    };
  }

  // 验证字段
  validateField (input) {
    const validator = this.validators[input.id];
    if (!validator) return true;

    const isValid = validator(input.value);
    const errorElement = document.getElementById(`${input.id}Error`);

    if (!isValid && input.value) {
      input.classList.add('error');
      input.classList.remove('success');
      if (errorElement) {
        errorElement.classList.add('show');
      }
      return false;
    } else if (input.value) {
      input.classList.remove('error');
      input.classList.add('success');
      if (errorElement) {
        errorElement.classList.remove('show');
      }
      return true;
    } else {
      input.classList.remove('error', 'success');
      if (errorElement) {
        errorElement.classList.remove('show');
      }
      return false;
    }
  }

  // 初始化密码显示/隐藏
  initPasswordToggle () {
    const toggleButtons = document.querySelectorAll('.password-toggle');

    toggleButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const targetId = button.dataset.target;
        const input = document.getElementById(targetId);
        const icon = button.querySelector('i');

        if (input.type === 'password') {
          input.type = 'text';
          icon.classList.remove('fa-eye');
          icon.classList.add('fa-eye-slash');
        } else {
          input.type = 'password';
          icon.classList.remove('fa-eye-slash');
          icon.classList.add('fa-eye');
        }
      });
    });
  }

  // 初始化密码强度检测
  initPasswordStrength () {
    const passwordInput = document.getElementById('registerPassword');
    if (passwordInput) {
      passwordInput.addEventListener('input', () => {
        this.checkPasswordStrength(passwordInput.value);
      });
    }
  }

  // 检查密码强度
  checkPasswordStrength (password) {
    const strengthBars = document.querySelectorAll('.strength-bar');
    const strengthText = document.getElementById('strengthText');

    if (!strengthBars.length || !strengthText) return;

    let strength = 0;

    // 长度检查
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;

    // 复杂度检查
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;

    // 更新显示
    strengthBars.forEach((bar) => bar.classList.remove('active', 'weak', 'medium', 'strong'));
    strengthText.classList.remove('show', 'weak', 'medium', 'strong');

    if (password.length > 0) {
      strengthText.classList.add('show');

      if (strength <= 2) {
        strengthBars[0].classList.add('active', 'weak');
        strengthText.textContent = '密码强度：弱';
        strengthText.classList.add('weak');
      } else if (strength <= 4) {
        strengthBars[0].classList.add('active', 'medium');
        strengthBars[1].classList.add('active', 'medium');
        strengthText.textContent = '密码强度：中';
        strengthText.classList.add('medium');
      } else {
        strengthBars.forEach((bar) => bar.classList.add('active', 'strong'));
        strengthText.textContent = '密码强度：强';
        strengthText.classList.add('strong');
      }
    }
  }

  // 初始化社交登录
  initSocialLogin () {
    const socialButtons = document.querySelectorAll('.social-btn');

    socialButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const provider = button.dataset.provider;
        this.handleSocialLogin(provider);
      });
    });
  }

  // 初始化验证码
  initVerificationCode () {
    const sendCodeBtn = document.getElementById('sendCodeBtn');
    if (sendCodeBtn) {
      sendCodeBtn.addEventListener('click', () => {
        this.sendVerificationCode();
      });
    }
  }

  // 发送验证码
  async sendVerificationCode () {
    const phoneInput = document.getElementById('registerPhone');
    const phone = phoneInput.value;

    // 验证手机号
    if (!this.validators.registerPhone(phone)) {
      this.showFieldError('registerPhone', '请输入有效的手机号');
      return;
    }

    const sendCodeBtn = document.getElementById('sendCodeBtn');

    try {
      // 显示加载状态
      sendCodeBtn.classList.add('loading');
      sendCodeBtn.disabled = true;

      // 模拟API调用
      await this.mockApiCall('/api/send-code', { phone });

      // 开始倒计时
      this.startCountdown(sendCodeBtn);

      this.showSuccess('验证码已发送，请注意查收');
    } catch (error) {
      this.showError('发送验证码失败，请重试');
      sendCodeBtn.classList.remove('loading');
      sendCodeBtn.disabled = false;
    }
  }

  // 开始倒计时
  startCountdown (button) {
    this.countdown = 60;

    const updateButton = () => {
      if (this.countdown > 0) {
        button.innerHTML = `<i class="fas fa-clock"></i><span>${this.countdown}秒后重试</span>`;
        button.disabled = true;
        this.countdown--;
      } else {
        button.innerHTML = '<i class="fas fa-paper-plane"></i><span>重新发送</span>';
        button.disabled = false;
        button.classList.remove('loading');
        clearInterval(this.countdownTimer);
      }
    };

    updateButton();
    this.countdownTimer = setInterval(updateButton, 1000);
  }

  // 处理登录
  async handleLogin () {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const rememberMe = document.getElementById('rememberMe').checked;

    // 验证表单
    if (!this.validateLoginForm()) {
      return;
    }

    const submitBtn = document.querySelector('#loginForm .btn-auth');

    try {
      // 显示加载状态
      submitBtn.classList.add('loading');
      submitBtn.disabled = true;

      // 模拟API调用
      const response = await this.mockApiCall('/api/login', {
        email,
        password,
        rememberMe,
      });

      if (response.status === 'success') {
        this.showSuccess('登录成功！');

        // 保存登录状态
        if (rememberMe) {
          localStorage.setItem('userToken', response.data.token);
          localStorage.setItem('userInfo', JSON.stringify(response.data.user));
        } else {
          sessionStorage.setItem('userToken', response.data.token);
          sessionStorage.setItem('userInfo', JSON.stringify(response.data.user));
        }

        // 跳转到首页或个人中心
        setTimeout(() => {
          const returnUrl = new URLSearchParams(window.location.search).get('return');
          window.location.href = returnUrl || 'user-center.html';
        }, 1000);
      } else {
        this.showError(response.message || '登录失败，请检查用户名和密码');
      }
    } catch (error) {
      this.showError('登录失败，请重试');
    } finally {
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
    }
  }

  // 处理注册
  async handleRegister () {
    const phone = document.getElementById('registerPhone').value;
    const verifyCode = document.getElementById('verifyCode').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;

    // 验证表单
    if (!this.validateRegisterForm()) {
      return;
    }

    if (!agreeTerms) {
      this.showError('请同意用户协议和隐私政策');
      return;
    }

    const submitBtn = document.querySelector('#registerForm .btn-auth');

    try {
      // 显示加载状态
      submitBtn.classList.add('loading');
      submitBtn.disabled = true;

      // 模拟API调用
      const response = await this.mockApiCall('/api/register', {
        phone,
        verifyCode,
        password,
        confirmPassword,
      });

      if (response.status === 'success') {
        this.showSuccess('注册成功！正在自动登录...');

        // 自动登录
        setTimeout(() => {
          localStorage.setItem('userToken', response.data.token);
          localStorage.setItem('userInfo', JSON.stringify(response.data.user));
          window.location.href = 'user-center.html';
        }, 1500);
      } else {
        this.showError(response.message || '注册失败，请重试');
      }
    } catch (error) {
      this.showError('注册失败，请重试');
    } finally {
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
    }
  }

  // 验证登录表单
  validateLoginForm () {
    const email = document.getElementById('loginEmail');
    const password = document.getElementById('loginPassword');

    let isValid = true;

    if (!this.validateField(email)) {
      isValid = false;
    }

    if (!this.validateField(password)) {
      isValid = false;
    }

    return isValid;
  }

  // 验证注册表单
  validateRegisterForm () {
    const phone = document.getElementById('registerPhone');
    const verifyCode = document.getElementById('verifyCode');
    const password = document.getElementById('registerPassword');
    const confirmPassword = document.getElementById('confirmPassword');

    let isValid = true;

    if (!this.validateField(phone)) {
      isValid = false;
    }

    if (!this.validateField(verifyCode)) {
      isValid = false;
    }

    if (!this.validateField(password)) {
      isValid = false;
    }

    if (!this.validateField(confirmPassword)) {
      isValid = false;
    }

    return isValid;
  }

  // 处理社交登录
  async handleSocialLogin (provider) {
    try {
      this.showInfo(`正在使用${this.getProviderName(provider)}登录...`);

      // 模拟社交登录
      const response = await this.mockApiCall('/api/social-login', { provider });

      if (response.status === 'success') {
        this.showSuccess('登录成功！');
        localStorage.setItem('userToken', response.data.token);
        localStorage.setItem('userInfo', JSON.stringify(response.data.user));

        setTimeout(() => {
          window.location.href = 'user-center.html';
        }, 1000);
      } else {
        this.showError('登录失败，请重试');
      }
    } catch (error) {
      this.showError('登录失败，请重试');
    }
  }

  // 获取社交平台名称
  getProviderName (provider) {
    const names = {
      wechat: '微信',
      qq: 'QQ',
      alipay: '支付宝',
    };
    return names[provider] || provider;
  }

  // 处理忘记密码
  handleForgotPassword () {
    // 可以显示忘记密码模态框或跳转到忘记密码页面
    this.showInfo('忘记密码功能正在开发中，请联系客服');
  }

  // 显示用户协议
  showTerms (type) {
    const title = type === 'terms' ? '用户协议' : '隐私政策';
    const content = type === 'terms'
      ? '这里是用户协议内容...'
      : '这里是隐私政策内容...';

    // 可以显示模态框或跳转到专门页面
    this.showInfo(`${title}页面正在开发中`);
  }

  // 显示字段错误
  showFieldError (fieldId, message) {
    const input = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}Error`);

    if (input) input.classList.add('error');
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.classList.add('show');
    }
  }

  // 显示成功消息
  showSuccess (message) {
    this.showToast(message, 'success');
  }

  // 显示错误消息
  showError (message) {
    this.showToast(message, 'error');
  }

  // 显示信息消息
  showInfo (message) {
    this.showToast(message, 'info');
  }

  // 显示提示消息
  showToast (message, type = 'info', duration = 3000) {
    // 创建或获取toast容器
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      toastContainer.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
            `;
      document.body.appendChild(toastContainer);
    }

    // 创建toast元素
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.cssText = `
            background: ${type === 'success' ? '#00B42A' : type === 'error' ? '#F53F3F' : '#165DFF'};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            animation: slideInRight 0.3s ease;
            max-width: 300px;
            word-wrap: break-word;
        `;
    toast.textContent = message;

    // 添加动画样式
    const style = document.createElement('style');
    style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
    if (!document.querySelector('style[data-toast]')) {
      style.setAttribute('data-toast', 'true');
      document.head.appendChild(style);
    }

    toastContainer.appendChild(toast);

    // 自动移除
    setTimeout(() => {
      toast.style.animation = 'slideOutRight 0.3s ease';
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, duration);
  }

  // 模拟API调用
  async mockApiCall (url, data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (url === '/api/login') {
          if (data.email === 'admin@example.com' && data.password === '123456') {
            resolve({
              status: 'success',
              data: {
                token: 'mock-token-' + Date.now(),
                user: {
                  id: 1,
                  name: '张三',
                  email: data.email,
                  level: 'VIP会员',
                },
              },
            });
          } else {
            resolve({
              status: 'error',
              message: '用户名或密码错误',
            });
          }
        } else if (url === '/api/register') {
          resolve({
            status: 'success',
            data: {
              token: 'mock-token-' + Date.now(),
              user: {
                id: 2,
                name: '新用户',
                phone: data.phone,
                level: '普通会员',
              },
            },
          });
        } else if (url === '/api/send-code') {
          resolve({ status: 'success' });
        } else if (url === '/api/social-login') {
          resolve({
            status: 'success',
            data: {
              token: 'mock-social-token-' + Date.now(),
              user: {
                id: 3,
                name: '社交用户',
                level: '普通会员',
              },
            },
          });
        } else {
          resolve({ status: 'success', data: {} });
        }
      }, 1000);
    });
  }
}

// 全局实例
let authPage;

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  authPage = new AuthPage();
});
