/**
 * 用户体验优化JavaScript库
 * 提供丰富的交互效果和用户体验增强功能
 */

class UXEnhancer {
  constructor () {
    this.currentLanguage = localStorage.getItem('language') || 'zh-CN';
    this.translations = {};
    this.operationAttempts = {}; // 记录操作尝试次数
    this.lastOperationTime = {}; // 记录上次操作时间
    this.init();
  }

  async init () {
    await this.loadTranslations(this.currentLanguage);
    this.initTooltips();
    this.initPopovers();
    this.initLoadingStates();
    this.initFormValidation();
    this.initSmoothScroll();
    this.initLazyLoading();
    this.initKeyboardShortcuts();
    this.initModalManagement();
    this.initThemeToggle();
    this.initResponsiveHelpers();
    this.initAnimations();
    this.initLanguageToggle();
    this.initResponsiveLayout();
    this.applyTranslations();
  }

  /**
     * 初始化工具提示
     */
  initTooltips () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl, {
        delay: { show: 500, hide: 100 },
        placement: 'auto',
      });
    });
  }

  /**
     * 初始化弹出框
     */
  initPopovers () {
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
      return new bootstrap.Popover(popoverTriggerEl, {
        trigger: 'hover focus',
        delay: { show: 300, hide: 100 },
      });
    });
  }

  /**
     * 初始化加载状态
     */
  initLoadingStates () {
    // 为按钮添加加载状态
    document.addEventListener('click', (e) => {
      if (e.target.matches('.btn-loading')) {
        this.setButtonLoading(e.target, true);
      }
    });

    // 表单提交时显示加载状态
    document.querySelectorAll('form').forEach((form) => {
      form.addEventListener('submit', (e) => {
        const submitBtn = form.querySelector('[type="submit"]');
        if (submitBtn && !submitBtn.disabled) {
          this.setButtonLoading(submitBtn, true);
        }
      });
    });
  }

  /**
     * 设置按钮加载状态
     */
  setButtonLoading (button, loading) {
    if (loading) {
      button.dataset.originalText = button.innerHTML;
      button.disabled = true;
      button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>加载中...';
    } else {
      button.disabled = false;
      button.innerHTML = button.dataset.originalText || button.innerHTML;
    }
  }

  /**
     * 初始化表单验证
     */
  initFormValidation () {
    document.querySelectorAll('form[data-validate]').forEach((form) => {
      form.addEventListener('submit', (e) => {
        // 安全验证：检查操作频率
        if (!this.checkOperationRate(form)) {
          e.preventDefault();
          return;
        }

        // 安全验证：二次确认
        if (!this.confirmOperation(form)) {
          e.preventDefault();
          return;
        }

        if (!this.validateForm(form)) {
          e.preventDefault();
          this.showFormError(form, this.t('validation.form_error'));
        }
      });
    });

    // 实时验证 - 失焦时验证
    document.querySelectorAll('input, textarea, select').forEach((field) => {
      field.addEventListener('blur', () => {
        this.validateField(field);
      });

      // 输入过程中的实时验证（防抖处理）
      let debounceTimer;
      field.addEventListener('input', () => {
        // 清除之前的错误状态（提供更好的用户体验）
        this.clearFieldError(field);

        // 如果有验证规则，进行防抖验证
        if (field.dataset.rules) {
          clearTimeout(debounceTimer);
          debounceTimer = setTimeout(() => {
            this.validateField(field);
          }, 500); // 500ms防抖延迟
        }

        // 密码强度实时显示
        if (field.dataset.rules && field.dataset.rules.includes('password')) {
          this.showPasswordStrength(field);
        }
      });

      // 字段获得焦点时显示提示
      field.addEventListener('focus', () => {
        this.showFieldHint(field);
      });
    });
  }

  /**
     * 清除字段错误
     */
  clearFieldError (field) {
    field.classList.remove('is-invalid');
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
      feedback.remove();
    }
  }

  /**
     * 显示字段提示
     */
  showFieldHint (field) {
    const rules = field.dataset.rules ? field.dataset.rules.split('|') : [];
    let hintText = '';

    if (rules.includes('required')) {
      hintText += '必填项 ';
    }
    if (rules.includes('email')) {
      hintText += '邮箱格式 ';
    }
    if (rules.includes('phone')) {
      hintText += '手机号格式 ';
    }
    if (rules.includes('ip')) {
      hintText += 'IP地址格式 (如: 192.168.1.1) ';
    }
    if (rules.includes('password')) {
      hintText += '至少8位，包含大小写字母、数字和特殊字符 ';
    }
    if (rules.includes('url')) {
      hintText += 'URL格式 ';
    }

    const minLengthRule = rules.find((rule) => rule.startsWith('min:'));
    if (minLengthRule) {
      hintText += `最少${minLengthRule.split(':')[1]}个字符 `;
    }

    const maxLengthRule = rules.find((rule) => rule.startsWith('max:'));
    if (maxLengthRule) {
      hintText += `最多${maxLengthRule.split(':')[1]}个字符 `;
    }

    if (hintText) {
      // 移除旧的提示
      const oldHint = field.parentNode.querySelector('.field-hint');
      if (oldHint) {
        oldHint.remove();
      }

      // 添加新提示
      const hintDiv = document.createElement('div');
      hintDiv.className = 'field-hint';
      hintDiv.textContent = hintText.trim();
      field.parentNode.appendChild(hintDiv);
    }
  }

  /**
     * 显示密码强度
     */
  showPasswordStrength (field) {
    const strength = this.getPasswordStrength(field.value);
    const strengthContainer = field.parentNode.querySelector('.password-strength');

    if (!strengthContainer) {
      const container = document.createElement('div');
      container.className = 'password-strength';
      field.parentNode.appendChild(container);
    }

    const container = field.parentNode.querySelector('.password-strength');
    const strengthText = ['很弱', '弱', '一般', '强', '很强'][strength] || '';
    const strengthClass = ['strength-0', 'strength-1', 'strength-2', 'strength-3', 'strength-4'][strength] || '';

    container.innerHTML = `
            <div class="password-strength-bar">
                <div class="password-strength-fill ${strengthClass}" style="width: ${(strength / 5) * 100}%"></div>
            </div>
            <div class="password-strength-text">${strengthText}</div>
        `;
  }

  /**
     * 显示表单错误
     */
  showFormError (form, message) {
    // 移除旧的表单错误
    const oldError = form.querySelector('.form-error');
    if (oldError) {
      oldError.remove();
    }

    // 添加新的表单错误
    const errorDiv = document.createElement('div');
    errorDiv.className = 'form-error alert alert-danger';
    errorDiv.textContent = message;
    form.insertBefore(errorDiv, form.firstChild);

    // 3秒后自动移除
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.remove();
      }
    }, 3000);
  }

  /**
     * 验证表单
     */
  validateForm (form) {
    let isValid = true;
    const fields = form.querySelectorAll('input, textarea, select');

    fields.forEach((field) => {
      if (!this.validateField(field)) {
        isValid = false;
      }
    });

    return isValid;
  }

  /**
     * 验证字段
     */
  validateField (field) {
    const rules = field.dataset.rules ? field.dataset.rules.split('|') : [];
    let isValid = true;
    let errorMessage = '';

    // 清除之前的错误状态
    field.classList.remove('is-invalid');
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
      feedback.remove();
    }

    // 必填验证
    if (rules.includes('required') && !field.value.trim()) {
      isValid = false;
      errorMessage = '此字段为必填项';
    }

    // 邮箱验证
    if (rules.includes('email') && field.value && !this.isValidEmail(field.value)) {
      isValid = false;
      errorMessage = '请输入有效的邮箱地址';
    }

    // 手机号验证
    if (rules.includes('phone') && field.value && !this.isValidPhone(field.value)) {
      isValid = false;
      errorMessage = '请输入有效的手机号码';
    }

    // IP地址验证
    if (rules.includes('ip') && field.value && !this.isValidIP(field.value)) {
      isValid = false;
      errorMessage = '请输入有效的IP地址格式';
    }

    // 日期验证
    const dateRule = rules.find((rule) => rule.startsWith('date:'));
    if (dateRule && field.value) {
      const format = dateRule.split(':')[1] || 'YYYY-MM-DD';
      if (!this.isValidDate(field.value, format)) {
        isValid = false;
        errorMessage = `请输入有效的日期格式 (${format})`;
      }
    }

    // 密码强度验证
    if (rules.includes('password') && field.value && !this.isValidPassword(field.value)) {
      isValid = false;
      errorMessage = '密码必须包含大小写字母、数字和特殊字符，至少8位';
    }

    // URL验证
    if (rules.includes('url') && field.value && !this.isValidURL(field.value)) {
      isValid = false;
      errorMessage = '请输入有效的URL地址';
    }

    // 数字范围验证
    const rangeRule = rules.find((rule) => rule.startsWith('range:'));
    if (rangeRule && field.value) {
      const [min, max] = rangeRule.split(':')[1].split('-').map(Number);
      if (!this.isNumberInRange(field.value, min, max)) {
        isValid = false;
        errorMessage = `请输入${min}到${max}之间的数字`;
      }
    }

    // 正则表达式验证
    const regexRule = rules.find((rule) => rule.startsWith('pattern:'));
    if (regexRule && field.value) {
      const pattern = new RegExp(regexRule.split(':')[1]);
      if (!pattern.test(field.value)) {
        isValid = false;
        errorMessage = '输入格式不正确';
      }
    }

    // 最小长度验证
    const minLengthRule = rules.find((rule) => rule.startsWith('min:'));
    if (minLengthRule && field.value.length < parseInt(minLengthRule.split(':')[1])) {
      isValid = false;
      errorMessage = `最少需要${minLengthRule.split(':')[1]}个字符`;
    }

    // 最大长度验证
    const maxLengthRule = rules.find((rule) => rule.startsWith('max:'));
    if (maxLengthRule && field.value.length > parseInt(maxLengthRule.split(':')[1])) {
      isValid = false;
      errorMessage = `最多允许${maxLengthRule.split(':')[1]}个字符`;
    }

    // 确认密码验证
    if (rules.includes('confirm')) {
      const form = field.closest('form');
      const passwordField = form.querySelector('input[type="password"]:not([data-rules*="confirm"])');
      if (passwordField && field.value !== passwordField.value) {
        isValid = false;
        errorMessage = '两次输入的密码不一致';
      }
    }

    // 自定义验证函数
    const customRule = rules.find((rule) => rule.startsWith('custom:'));
    if (customRule && typeof window[customRule.split(':')[1]] === 'function') {
      const customResult = window[customRule.split(':')[1]](field.value, field);
      if (customResult !== true) {
        isValid = false;
        errorMessage = typeof customResult === 'string' ? customResult : '验证失败';
      }
    }

    // 显示错误信息
    if (!isValid) {
      field.classList.add('is-invalid');
      const feedbackDiv = document.createElement('div');
      feedbackDiv.className = 'invalid-feedback';
      feedbackDiv.textContent = errorMessage;
      field.parentNode.appendChild(feedbackDiv);
    }

    return isValid;
  }

  /**
     * 验证邮箱
     */
  isValidEmail (email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
     * 验证手机号
     */
  isValidPhone (phone) {
    const phoneRegex = /^1[3-9]\d{9}$/;
    return phoneRegex.test(phone);
  }

  /**
     * 验证IP地址
     */
  isValidIP (ip) {
    const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return ipRegex.test(ip);
  }

  /**
     * 验证日期格式
     */
  isValidDate (date, format = 'YYYY-MM-DD') {
    if (!date) return false;

    if (format === 'YYYY-MM-DD') {
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
      if (!dateRegex.test(date)) return false;

      const d = new Date(date);
      return d instanceof Date && !isNaN(d);
    }

    if (format === 'YYYY-MM-DD HH:mm:ss') {
      const dateTimeRegex = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
      if (!dateTimeRegex.test(date)) return false;

      const d = new Date(date);
      return d instanceof Date && !isNaN(d);
    }

    return false;
  }

  /**
     * 验证密码强度
     */
  isValidPassword (password) {
    // 至少8位，包含大小写字母、数字和特殊字符
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
  }

  /**
     * 检查密码强度等级
     */
  getPasswordStrength (password) {
    if (!password) return 0;

    let strength = 0;

    // 长度检查
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;

    // 字符类型检查
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[@$!%*?&]/.test(password)) strength++;

    return Math.min(strength, 5); // 最高5级
  }

  /**
     * 验证URL格式
     */
  isValidURL (url) {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  /**
     * 验证数字范围
     */
  isNumberInRange (value, min, max) {
    const num = parseFloat(value);
    return !isNaN(num) && num >= min && num <= max;
  }

  /**
     * 初始化平滑滚动
     */
  initSmoothScroll () {
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }
      });
    });
  }

  /**
     * 初始化懒加载
     */
  initLazyLoading () {
    if ('IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.classList.remove('lazy');
            observer.unobserve(img);
          }
        });
      });

      document.querySelectorAll('img[data-src]').forEach((img) => {
        imageObserver.observe(img);
      });
    }
  }

  /**
     * 初始化键盘快捷键
     */
  initKeyboardShortcuts () {
    document.addEventListener('keydown', (e) => {
      // Ctrl+S 保存
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        const saveBtn = document.querySelector('[data-action="save"]');
        if (saveBtn) {
          saveBtn.click();
        }
      }

      // Ctrl+N 新建
      if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        const newBtn = document.querySelector('[data-action="new"]');
        if (newBtn) {
          newBtn.click();
        }
      }

      // Esc 关闭模态框
      if (e.key === 'Escape') {
        const openModal = document.querySelector('.modal.show');
        if (openModal) {
          this.closeModalSafely(openModal);
        }
      }
    });
  }

  /**
     * 统一模态框管理
     */
  initModalManagement () {
    // 为所有模态框添加统一的事件监听
    document.addEventListener('show.bs.modal', (e) => {
      this.onModalShow(e.target);
    });

    document.addEventListener('hidden.bs.modal', (e) => {
      this.onModalHidden(e.target);
    });

    // 为自定义模态框添加事件监听
    document.addEventListener('click', (e) => {
      const trigger = e.target.closest('[data-modal]');
      if (trigger) {
        const modalId = trigger.dataset.modal;
        this.showModal(modalId);
      }

      const closeBtn = e.target.closest('[data-close-modal], .modal-close');
      if (closeBtn) {
        const modal = closeBtn.closest('.modal');
        this.closeModalSafely(modal);
      }
    });

    // 点击模态框外部关闭
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        this.closeModalSafely(e.target);
      }
    });
  }

  /**
     * 模态框显示时的处理
     */
  onModalShow (modal) {
    // 保存原始表单数据
    const form = modal.querySelector('form');
    if (form) {
      form.dataset.originalData = JSON.stringify(this.getFormData(form));
    }

    // 焦点管理
    setTimeout(() => {
      const focusableElements = modal.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusableElements.length > 0) {
        focusableElements[0].focus();
      }
    }, 100);

    // 禁用背景滚动
    document.body.style.overflow = 'hidden';

    // 触发自定义事件
    modal.dispatchEvent(new CustomEvent('modalShown', { detail: { modal } }));
  }

  /**
     * 模态框隐藏时的处理
     */
  onModalHidden (modal) {
    // 清理表单数据
    this.cleanupModalData(modal);

    // 恢复背景滚动
    document.body.style.overflow = '';

    // 清理定时器和事件监听器
    this.cleanupModalTimers(modal);

    // 触发自定义事件
    modal.dispatchEvent(new CustomEvent('modalHidden', { detail: { modal } }));
  }

  /**
     * 安全关闭模态框
     */
  closeModalSafely (modal) {
    if (!modal) return;

    // 检查是否有未保存的更改
    if (this.hasUnsavedChanges(modal)) {
      this.confirmUnsavedChanges(modal).then((confirmed) => {
        if (confirmed) {
          this.hideModal(modal);
        }
      });
    } else {
      this.hideModal(modal);
    }
  }

  /**
     * 检查模态框是否有未保存的更改
     */
  hasUnsavedChanges (modal) {
    const form = modal.querySelector('form');
    if (!form) return false;

    const originalData = form.dataset.originalData;
    if (!originalData) return false;

    const currentData = JSON.stringify(this.getFormData(form));
    return originalData !== currentData;
  }

  /**
     * 确认未保存的更改
     */
  confirmUnsavedChanges (modal) {
    return this.confirm(
      this.t('modal.unsaved_changes'),
      this.t('modal.confirm_title'),
    );
  }

  /**
     * 获取表单数据
     */
  getFormData (form) {
    const formData = new FormData(form);
    const data = {};

    for (const [key, value] of formData.entries()) {
      data[key] = value;
    }

    return data;
  }

  /**
     * 清理模态框数据
     */
  cleanupModalData (modal) {
    // 重置表单
    const forms = modal.querySelectorAll('form');
    forms.forEach((form) => {
      // 保存原始数据以便后续比较
      if (form.dataset.originalData) {
        delete form.dataset.originalData;
      }

      // 清理验证状态
      this.clearFormValidation(form);

      // 重置表单字段
      form.reset();

      // 清理自定义数据
      const inputs = form.querySelectorAll('input, select, textarea');
      inputs.forEach((input) => {
        // 移除自定义属性
        delete input.dataset.originalValue;
        delete input.dataset.modified;

        // 清理验证状态
        input.classList.remove('is-valid', 'is-invalid', 'is-secure', 'insecure');

        // 移除错误提示
        const feedback = input.parentNode.querySelector('.invalid-feedback, .valid-feedback');
        if (feedback) {
          feedback.remove();
        }

        // 移除字段提示
        const hint = input.parentNode.querySelector('.field-hint');
        if (hint) {
          hint.remove();
        }

        // 移除密码强度指示器
        const strength = input.parentNode.querySelector('.password-strength');
        if (strength) {
          strength.remove();
        }
      });
    });

    // 清理模态框级别的数据
    delete modal.dataset.originalData;
    delete modal.dataset.modified;

    // 清理自定义事件监听器
    const customEvents = modal.querySelectorAll('[data-modal-event]');
    customEvents.forEach((element) => {
      element.removeEventListener('click', element.dataset.modalHandler);
    });
  }

  /**
     * 清理表单验证状态
     */
  clearFormValidation (form) {
    // 移除所有验证类
    form.classList.remove('was-validated');

    // 清理字段验证状态
    const inputs = form.querySelectorAll('.is-valid, .is-invalid');
    inputs.forEach((input) => {
      input.classList.remove('is-valid', 'is-invalid');
    });

    // 移除验证反馈
    const feedbacks = form.querySelectorAll('.valid-feedback, .invalid-feedback');
    feedbacks.forEach((feedback) => {
      feedback.remove();
    });
  }

  /**
     * 清理模态框定时器
     */
  cleanupModalTimers (modal) {
    // 清理所有与模态框相关的定时器
    const timerIds = modal.dataset.timerIds
      ? modal.dataset.timerIds.split(',')
      : [];

    timerIds.forEach((timerId) => {
      clearTimeout(parseInt(timerId));
      clearInterval(parseInt(timerId));
    });

    delete modal.dataset.timerIds;
  }

  /**
     * 显示模态框（增强版）
     */
  showModal (modalId, options = {}) {
    const modal = typeof modalId === 'string'
      ? document.getElementById(modalId)
      : modalId;

    if (!modal) return;

    // 应用选项
    const defaultOptions = {
      backdrop: true,
      keyboard: true,
      focus: true,
      show: true,
    };

    const finalOptions = { ...defaultOptions, ...options };

    // 使用Bootstrap模态框或自定义实现
    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
      const bsModal = new bootstrap.Modal(modal, finalOptions);
      bsModal.show();
    } else {
      // 自定义模态框实现
      this.showCustomModal(modal, finalOptions);
    }
  }

  /**
     * 自定义模态框显示
     */
  showCustomModal (modal, options) {
    modal.classList.add('show');
    modal.style.display = 'block';

    // 添加背景
    if (options.backdrop) {
      this.createModalBackdrop(modal);
    }

    this.onModalShow(modal);
  }

  /**
     * 隐藏模态框（增强版）
     */
  hideModal (modal) {
    if (!modal) return;

    // 使用Bootstrap模态框或自定义实现
    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
      const bsModal = bootstrap.Modal.getInstance(modal);
      if (bsModal) {
        bsModal.hide();
      } else {
        this.hideCustomModal(modal);
      }
    } else {
      this.hideCustomModal(modal);
    }
  }

  /**
     * 自定义模态框隐藏
     */
  hideCustomModal (modal) {
    modal.classList.remove('show');
    setTimeout(() => {
      modal.style.display = 'none';
      this.removeModalBackdrop(modal);
      this.onModalHidden(modal);
    }, 300);
  }

  /**
     * 创建模态框背景
     */
  createModalBackdrop (modal) {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop fade show';
    backdrop.dataset.modalTarget = modal.id;
    document.body.appendChild(backdrop);
  }

  /**
     * 移除模态框背景
     */
  removeModalBackdrop (modal) {
    const backdrop = document.querySelector(`.modal-backdrop[data-modal-target="${modal.id}"]`);
    if (backdrop) {
      backdrop.remove();
    }
  }

  /**
     * 加载语言文件
     */
  async loadTranslations (language) {
    try {
      const response = await fetch(`./assets/lang/${language}.json`);
      if (response.ok) {
        this.translations = await response.json();
        this.currentLanguage = language;
        localStorage.setItem('language', language);
      } else {
        console.warn(`Language file ${language}.json not found, using default language`);
        // 降级到中文
        if (language !== 'zh-CN') {
          await this.loadTranslations('zh-CN');
        }
      }
    } catch (error) {
      console.error('Failed to load translations:', error);
      // 降级到中文
      if (language !== 'zh-CN') {
        await this.loadTranslations('zh-CN');
      }
    }
  }

  /**
     * 获取翻译文本
     */
  t (key, params = {}) {
    const keys = key.split('.');
    let value = this.translations;

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        console.warn(`Translation key not found: ${key}`);
        return key; // 返回原始键名作为降级
      }
    }

    // 处理参数替换
    if (typeof value === 'string' && Object.keys(params).length > 0) {
      return value.replace(/\{(\w+)\}/g, (match, param) => {
        return params[param] !== undefined ? params[param] : match;
      });
    }

    return value || key;
  }

  /**
     * 初始化语言切换
     */
  initLanguageToggle () {
    const languageToggle = document.querySelector('[data-language-toggle]');
    if (languageToggle) {
      languageToggle.addEventListener('click', () => {
        this.switchLanguage();
      });
    }

    // 为语言选择器添加事件监听
    const languageSelect = document.querySelector('[data-language-select]');
    if (languageSelect) {
      languageSelect.value = this.currentLanguage;
      languageSelect.addEventListener('change', (e) => {
        this.switchLanguage(e.target.value);
      });
    }
  }

  /**
     * 切换语言
     */
  async switchLanguage (language = null) {
    const newLanguage = language || (this.currentLanguage === 'zh-CN' ? 'en-US' : 'zh-CN');

    if (newLanguage !== this.currentLanguage) {
      await this.loadTranslations(newLanguage);
      this.applyTranslations();

      // 触发语言切换事件
      document.dispatchEvent(new CustomEvent('languageChanged', {
        detail: { language: newLanguage },
      }));
    }
  }

  /**
     * 应用翻译到页面
     */
  applyTranslations () {
    // 更新带有 data-i18n 属性的元素
    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.dataset.i18n;
      const translation = this.t(key);

      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        element.placeholder = translation;
      } else {
        element.textContent = translation;
      }
    });

    // 更新带有 data-i18n-title 属性的元素
    document.querySelectorAll('[data-i18n-title]').forEach((element) => {
      const key = element.dataset.i18nTitle;
      element.title = this.t(key);
    });

    // 更新带有 data-i18n-placeholder 属性的元素
    document.querySelectorAll('[data-i18n-placeholder]').forEach((element) => {
      const key = element.dataset.i18nPlaceholder;
      element.placeholder = this.t(key);
    });

    // 更新语言选择器
    const languageSelect = document.querySelector('[data-language-select]');
    if (languageSelect) {
      languageSelect.value = this.currentLanguage;
    }

    // 更新语言切换按钮文本
    const languageToggle = document.querySelector('[data-language-toggle]');
    if (languageToggle) {
      const buttonText = this.currentLanguage === 'zh-CN' ? 'English' : '中文';
      const button = languageToggle.querySelector('span') || languageToggle;
      if (button.tagName === 'SPAN') {
        button.textContent = buttonText;
      } else {
        languageToggle.textContent = buttonText;
      }
    }
  }

  /**
     * 获取当前语言
     */
  getCurrentLanguage () {
    return this.currentLanguage;
  }

  /**
     * 获取支持的语言列表
     */
  getSupportedLanguages () {
    return [
      { code: 'zh-CN', name: '中文', nativeName: '中文' },
      { code: 'en-US', name: 'English', nativeName: 'English' },
    ];
  }

  /**
     * 初始化主题切换
     */
  initThemeToggle () {
    const themeToggle = document.querySelector('[data-theme-toggle]');
    if (themeToggle) {
      themeToggle.addEventListener('click', () => {
        const currentTheme = document.body.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);

        // 更新图标
        const icon = themeToggle.querySelector('i');
        if (icon) {
          icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
      });

      // 恢复保存的主题
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme) {
        document.body.setAttribute('data-theme', savedTheme);
        const icon = themeToggle.querySelector('i');
        if (icon) {
          icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
      }
    }
  }

  /**
     * 初始化响应式助手
     */
  initResponsiveHelpers () {
    // 移动端菜单切换
    const mobileMenuToggle = document.querySelector('[data-mobile-menu-toggle]');
    if (mobileMenuToggle) {
      mobileMenuToggle.addEventListener('click', () => {
        const mobileMenu = document.querySelector('[data-mobile-menu]');
        if (mobileMenu) {
          mobileMenu.classList.toggle('show');
        }
      });
    }

    // 响应式表格处理
    this.makeTablesResponsive();

    // 窗口大小变化时重新处理
    window.addEventListener('resize', () => {
      this.makeTablesResponsive();
    });
  }

  /**
     * 使表格响应式
     */
  makeTablesResponsive () {
    document.querySelectorAll('table').forEach((table) => {
      if (!table.closest('.table-responsive')) {
        const wrapper = document.createElement('div');
        wrapper.className = 'table-responsive';
        table.parentNode.insertBefore(wrapper, table);
        wrapper.appendChild(table);
      }

      // 为移动端创建卡片式表格视图
      this.createCardTable(table);
    });
  }

  /**
     * 创建移动端卡片式表格
     */
  createCardTable (table) {
    const tableId = table.id || 'table-' + Math.random().toString(36).substr(2, 9);
    table.id = tableId;

    // 检查是否已经创建了卡片视图
    if (document.getElementById(tableId + '-card')) {
      return;
    }

    const headers = Array.from(table.querySelectorAll('thead th')).map((th) => th.textContent.trim());
    const rows = table.querySelectorAll('tbody tr');

    if (headers.length === 0 || rows.length === 0) {
      return;
    }

    // 创建卡片容器
    const cardContainer = document.createElement('div');
    cardContainer.id = tableId + '-card';
    cardContainer.className = 'table-card d-md-none';
    cardContainer.style.display = 'none';

    rows.forEach((row, index) => {
      const cells = row.querySelectorAll('td');
      const card = document.createElement('div');
      card.className = 'card mb-3';

      const cardBody = document.createElement('div');
      cardBody.className = 'card-body';

      headers.forEach((header, cellIndex) => {
        if (cells[cellIndex]) {
          const item = document.createElement('div');
          item.className = 'card-item';

          const label = document.createElement('div');
          label.className = 'item-label';
          label.textContent = header;

          const value = document.createElement('div');
          value.className = 'item-value';
          value.innerHTML = cells[cellIndex].innerHTML;

          item.appendChild(label);
          item.appendChild(value);
          cardBody.appendChild(item);
        }
      });

      card.appendChild(cardBody);
      cardContainer.appendChild(card);
    });

    // 插入卡片容器到表格后面
    table.parentNode.insertBefore(cardContainer, table.nextSibling);

    // 添加切换按钮
    this.addTableToggle(table, cardContainer);
  }

  /**
     * 添加表格切换按钮
     */
  addTableToggle (table, cardContainer) {
    const tableWrapper = table.closest('.table-responsive');
    if (!tableWrapper) return;

    // 检查是否已经添加了切换按钮
    if (tableWrapper.querySelector('.table-toggle-btn')) {
      return;
    }

    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'btn btn-outline-secondary btn-sm table-toggle-btn d-md-none mb-2';
    toggleBtn.innerHTML = '<i class="fas fa-th-list"></i> 切换视图';

    let isCardView = false;

    toggleBtn.addEventListener('click', () => {
      isCardView = !isCardView;

      if (isCardView) {
        table.style.display = 'none';
        cardContainer.style.display = 'block';
        toggleBtn.innerHTML = '<i class="fas fa-table"></i> 表格视图';
      } else {
        table.style.display = '';
        cardContainer.style.display = 'none';
        toggleBtn.innerHTML = '<i class="fas fa-th-list"></i> 卡片视图';
      }
    });

    tableWrapper.insertBefore(toggleBtn, table);
  }

  /**
     * 优化按钮组响应式
     */
  makeButtonGroupsResponsive () {
    document.querySelectorAll('.btn-group').forEach((group) => {
      // 检查是否需要响应式处理
      if (this.shouldMakeButtonGroupResponsive(group)) {
        this.makeButtonGroupResponsive(group);
      }
    });
  }

  /**
     * 判断按钮组是否需要响应式处理
     */
  shouldMakeButtonGroupResponsive (group) {
    const buttons = group.querySelectorAll('.btn');
    const totalWidth = Array.from(buttons).reduce((sum, btn) => sum + btn.offsetWidth, 0);
    const containerWidth = group.parentElement ? group.parentElement.offsetWidth : window.innerWidth;

    return totalWidth > containerWidth * 0.9; // 如果按钮宽度超过容器宽度的90%
  }

  /**
     * 使按钮组响应式
     */
  makeButtonGroupResponsive (group) {
    const buttons = Array.from(group.querySelectorAll('.btn'));

    // 创建下拉菜单容器
    const dropdown = document.createElement('div');
    dropdown.className = 'btn-group responsive-btn-group';

    // 保留前几个按钮，其余放入下拉菜单
    const visibleCount = this.calculateVisibleButtons(group);
    const visibleButtons = buttons.slice(0, visibleCount);
    const hiddenButtons = buttons.slice(visibleCount);

    // 添加可见按钮
    visibleButtons.forEach((btn) => {
      dropdown.appendChild(btn.cloneNode(true));
    });

    // 如果有隐藏按钮，创建下拉菜单
    if (hiddenButtons.length > 0) {
      const dropdownToggle = document.createElement('button');
      dropdownToggle.className = 'btn btn-outline-secondary dropdown-toggle';
      dropdownToggle.type = 'button';
      dropdownToggle.setAttribute('data-bs-toggle', 'dropdown');
      dropdownToggle.innerHTML = '<i class="fas fa-ellipsis-h"></i>';

      const dropdownMenu = document.createElement('div');
      dropdownMenu.className = 'dropdown-menu';

      hiddenButtons.forEach((btn) => {
        const menuItem = document.createElement('a');
        menuItem.className = 'dropdown-item';
        menuItem.href = '#';
        menuItem.innerHTML = btn.innerHTML;

        // 复制按钮的事件
        const originalEvents = this.getButtonEvents(btn);
        originalEvents.forEach((eventType) => {
          menuItem.addEventListener(eventType, (e) => {
            e.preventDefault();
            btn.click();
          });
        });

        dropdownMenu.appendChild(menuItem);
      });

      dropdown.appendChild(dropdownToggle);
      dropdown.appendChild(dropdownMenu);
    }

    // 替换原始按钮组
    group.parentNode.replaceChild(dropdown, group);
  }

  /**
     * 计算可见按钮数量
     */
  calculateVisibleButtons (group) {
    const containerWidth = group.parentElement ? group.parentElement.offsetWidth : window.innerWidth;
    const buttons = group.querySelectorAll('.btn');
    let visibleCount = 0;
    let totalWidth = 0;

    for (let i = 0; i < buttons.length; i++) {
      const btnWidth = buttons[i].offsetWidth + 4; // 加上间距
      if (totalWidth + btnWidth <= containerWidth * 0.7) {
        totalWidth += btnWidth;
        visibleCount++;
      } else {
        break;
      }
    }

    return Math.max(1, visibleCount - 1); // 至少保留1个按钮，为下拉菜单留空间
  }

  /**
     * 获取按钮的事件类型
     */
  getButtonEvents (btn) {
    const events = [];
    const eventTypes = ['click', 'focus', 'blur'];

    eventTypes.forEach((type) => {
      if (btn['on' + type]) {
        events.push(type);
      }
    });

    return events;
  }

  /**
     * 优化表单响应式
     */
  makeFormsResponsive () {
    document.querySelectorAll('form').forEach((form) => {
      this.optimizeFormLayout(form);
      this.addFormValidation(form);
    });
  }

  /**
     * 优化表单布局
     */
  optimizeFormLayout (form) {
    // 为移动端优化表单行
    const rows = form.querySelectorAll('.row');
    rows.forEach((row) => {
      if (window.innerWidth <= 768) {
        row.classList.add('g-3');
      }
    });

    // 优化输入组
    const inputGroups = form.querySelectorAll('.input-group');
    inputGroups.forEach((group) => {
      if (window.innerWidth <= 768) {
        group.classList.add('input-group-sm');
      }
    });
  }

  /**
     * 添加表单验证
     */
  addFormValidation (form) {
    const inputs = form.querySelectorAll('input, textarea, select');

    inputs.forEach((input) => {
      // 移除输入焦点时的验证
      input.addEventListener('blur', () => {
        this.validateField(input);
      });

      // 实时验证
      input.addEventListener('input', () => {
        if (input.classList.contains('is-invalid') || input.classList.contains('is-valid')) {
          this.validateField(input);
        }
      });
    });
  }

  /**
     * 验证字段
     */
  validateField (input) {
    const value = input.value.trim();
    const isRequired = input.hasAttribute('required');
    const type = input.type;
    const pattern = input.getAttribute('pattern');

    // 清除之前的验证状态
    input.classList.remove('is-invalid', 'is-valid');

    let isValid = true;
    let errorMessage = '';

    // 必填验证
    if (isRequired && !value) {
      isValid = false;
      errorMessage = '此字段为必填项';
    }

    // 类型验证
    if (isValid && value) {
      switch (type) {
      case 'email':
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(value)) {
          isValid = false;
          errorMessage = '请输入有效的邮箱地址';
        }
        break;
      case 'tel':
        const phonePattern = /^1[3-9]\d{9}$/;
        if (!phonePattern.test(value)) {
          isValid = false;
          errorMessage = '请输入有效的手机号码';
        }
        break;
      case 'url':
        try {
          new URL(value);
        } catch {
          isValid = false;
          errorMessage = '请输入有效的URL地址';
        }
        break;
      }
    }

    // 自定义模式验证
    if (isValid && value && pattern) {
      const regex = new RegExp(pattern);
      if (!regex.test(value)) {
        isValid = false;
        errorMessage = input.getAttribute('title') || '格式不正确';
      }
    }

    // 显示验证结果
    if (isValid) {
      input.classList.add('is-valid');
      this.removeFieldError(input);
    } else {
      input.classList.add('is-invalid');
      this.showFieldError(input, errorMessage);
    }

    return isValid;
  }

  /**
     * 显示字段错误
     */
  showFieldError (input, message) {
    this.removeFieldError(input);

    const errorElement = document.createElement('div');
    errorElement.className = 'invalid-feedback';
    errorElement.textContent = message;

    input.parentNode.appendChild(errorElement);
  }

  /**
     * 移除字段错误
     */
  removeFieldError (input) {
    const existingError = input.parentNode.querySelector('.invalid-feedback');
    if (existingError) {
      existingError.remove();
    }
  }

  /**
     * 初始化响应式布局
     */
  initResponsiveLayout () {
    // 监听窗口大小变化
    let resizeTimeout;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        this.handleResponsiveChange();
      }, 250);
    });

    // 初始化响应式组件
    this.handleResponsiveChange();
  }

  /**
     * 处理响应式变化
     */
  handleResponsiveChange () {
    const isMobile = window.innerWidth <= 768;

    // 处理表格
    this.makeTablesResponsive();

    // 处理按钮组
    this.makeButtonGroupsResponsive();

    // 处理表单
    this.makeFormsResponsive();

    // 处理导航
    this.handleNavigation(isMobile);

    // 处理模态框
    this.handleModals(isMobile);
  }

  /**
     * 处理导航响应式
     */
  handleNavigation (isMobile) {
    const navTabs = document.querySelectorAll('.nav-tabs');

    navTabs.forEach((tabs) => {
      if (isMobile) {
        tabs.classList.add('nav-tabs-mobile');
        this.addNavScroll(tabs);
      } else {
        tabs.classList.remove('nav-tabs-mobile');
        this.removeNavScroll(tabs);
      }
    });
  }

  /**
     * 添加导航滚动
     */
  addNavScroll (tabs) {
    if (tabs.classList.contains('has-scroll')) return;

    tabs.classList.add('has-scroll');

    // 添加滚动指示器
    const scrollIndicator = document.createElement('div');
    scrollIndicator.className = 'nav-scroll-indicator';
    tabs.appendChild(scrollIndicator);

    // 监听滚动事件
    tabs.addEventListener('scroll', () => {
      this.updateScrollIndicator(tabs, scrollIndicator);
    });
  }

  /**
     * 移除导航滚动
     */
  removeNavScroll (tabs) {
    tabs.classList.remove('has-scroll');
    const indicator = tabs.querySelector('.nav-scroll-indicator');
    if (indicator) {
      indicator.remove();
    }
  }

  /**
     * 更新滚动指示器
     */
  updateScrollIndicator (tabs, indicator) {
    const scrollLeft = tabs.scrollLeft;
    const scrollWidth = tabs.scrollWidth;
    const clientWidth = tabs.clientWidth;

    const scrollPercent = scrollLeft / (scrollWidth - clientWidth);
    const indicatorWidth = (clientWidth / scrollWidth) * 100;
    const indicatorLeft = scrollPercent * (100 - indicatorWidth);

    indicator.style.width = indicatorWidth + '%';
    indicator.style.left = indicatorLeft + '%';
  }

  /**
     * 处理模态框响应式
     */
  handleModals (isMobile) {
    const modals = document.querySelectorAll('.modal');

    modals.forEach((modal) => {
      if (isMobile) {
        modal.classList.add('modal-mobile');
        this.optimizeModalForMobile(modal);
      } else {
        modal.classList.remove('modal-mobile');
        this.restoreModalForDesktop(modal);
      }
    });
  }

  /**
     * 为移动端优化模态框
     */
  optimizeModalForMobile (modal) {
    const dialog = modal.querySelector('.modal-dialog');
    if (dialog) {
      dialog.classList.add('modal-dialog-mobile');
    }

    // 优化模态框内容
    const body = modal.querySelector('.modal-body');
    if (body) {
      body.classList.add('modal-body-mobile');
    }

    // 优化模态框底部
    const footer = modal.querySelector('.modal-footer');
    if (footer) {
      footer.classList.add('modal-footer-mobile');
    }
  }

  /**
     * 恢复桌面端模态框
     */
  restoreModalForDesktop (modal) {
    const dialog = modal.querySelector('.modal-dialog');
    if (dialog) {
      dialog.classList.remove('modal-dialog-mobile');
    }

    const body = modal.querySelector('.modal-body');
    if (body) {
      body.classList.remove('modal-body-mobile');
    }

    const footer = modal.querySelector('.modal-footer');
    if (footer) {
      footer.classList.remove('modal-footer-mobile');
    }
  }

  /**
     * 初始化动画效果
     */
  initAnimations () {
    // 滚动动画
    if ('IntersectionObserver' in window) {
      const animationObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      }, {
        threshold: 0.1,
      });

      document.querySelectorAll('[data-animate]').forEach((element) => {
        animationObserver.observe(element);
      });
    }

    // 悬停效果
    this.initHoverEffects();

    // 点击波纹效果
    this.initRippleEffect();
  }

  /**
     * 初始化悬停效果
     */
  initHoverEffects () {
    document.querySelectorAll('[data-hover]').forEach((element) => {
      element.addEventListener('mouseenter', () => {
        element.classList.add('hover-effect');
      });

      element.addEventListener('mouseleave', () => {
        element.classList.remove('hover-effect');
      });
    });
  }

  /**
     * 初始化点击波纹效果
     */
  initRippleEffect () {
    document.addEventListener('click', (e) => {
      if (e.target.matches('[data-ripple]')) {
        this.createRipple(e.target, e);
      }
    });
  }

  /**
     * 创建波纹效果
     */
  createRipple (element, event) {
    const ripple = document.createElement('span');
    ripple.className = 'ripple';

    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';

    element.appendChild(ripple);

    setTimeout(() => {
      ripple.remove();
    }, 600);
  }

  /**
     * 显示通知
     */
  showNotification (message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
            <button class="notification-close">&times;</button>
        `;

    document.body.appendChild(notification);

    // 自动关闭
    setTimeout(() => {
      this.closeNotification(notification);
    }, duration);

    // 手动关闭
    notification.querySelector('.notification-close').addEventListener('click', () => {
      this.closeNotification(notification);
    });
  }

  /**
     * 获取通知图标
     */
  getNotificationIcon (type) {
    const icons = {
      success: 'fa-check-circle',
      error: 'fa-exclamation-circle',
      warning: 'fa-exclamation-triangle',
      info: 'fa-info-circle',
    };
    return icons[type] || icons.info;
  }

  /**
     * 关闭通知
     */
  closeNotification (notification) {
    notification.classList.add('notification-out');
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }

  /**
     * 显示确认对话框
     */
  confirm (message, title = '确认操作') {
    return new Promise((resolve) => {
      const modal = document.createElement('div');
      modal.className = 'modal fade';
      modal.innerHTML = `
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>${message}</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                            <button type="button" class="btn btn-primary" id="confirmBtn">确认</button>
                        </div>
                    </div>
                </div>
            `;

      document.body.appendChild(modal);
      const bsModal = new bootstrap.Modal(modal);
      bsModal.show();

      modal.querySelector('#confirmBtn').addEventListener('click', () => {
        bsModal.hide();
        resolve(true);
      });

      modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
        resolve(false);
      });
    });
  }

  /**
     * 复制到剪贴板
     */
  async copyToClipboard (text) {
    try {
      await navigator.clipboard.writeText(text);
      this.showNotification('已复制到剪贴板', 'success');
    } catch (err) {
      // 降级方案
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      this.showNotification('已复制到剪贴板', 'success');
    }
  }

  /**
     * 格式化文件大小
     */
  formatFileSize (bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
     * 格式化日期
     */
  formatDate (date, format = 'YYYY-MM-DD HH:mm:ss') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');

    return format
      .replace('YYYY', year)
      .replace('MM', month)
      .replace('DD', day)
      .replace('HH', hours)
      .replace('mm', minutes)
      .replace('ss', seconds);
  }

  /**
     * 防抖函数 - 优化版本
     */
  debounce (func, wait, immediate = false) {
    let timeout;
    let lastCallTime = 0;
    let lastArgs;
    let lastThis;

    return function executedFunction (...args) {
      const now = Date.now();
      const timeSinceLastCall = now - lastCallTime;

      lastArgs = args;
      lastThis = this;

      // 清除之前的定时器
      if (timeout) {
        clearTimeout(timeout);
      }

      // 立即执行条件
      if (immediate && timeSinceLastCall >= wait) {
        lastCallTime = now;
        return func.apply(this, args);
      }

      // 设置新的定时器
      timeout = setTimeout(() => {
        lastCallTime = Date.now();
        timeout = null;

        if (!immediate) {
          func.apply(lastThis, lastArgs);
        }
      }, wait);
    };
  }

  /**
     * 节流函数 - 优化版本
     */
  throttle (func, limit) {
    let inThrottle;
    let lastFunc;
    let lastRan;

    return function () {
      const context = this;
      const args = arguments;

      if (!inThrottle) {
        func.apply(context, args);
        lastRan = Date.now();
        inThrottle = true;
      } else {
        clearTimeout(lastFunc);
        lastFunc = setTimeout(() => {
          if ((Date.now() - lastRan) >= limit) {
            func.apply(context, args);
            lastRan = Date.now();
          }
        }, limit - (Date.now() - lastRan));
      }
    };
  }

  /**
     * 检查操作频率限制
     */
  checkOperationRate (form) {
    const formId = form.id || form.className || 'default';
    const now = Date.now();
    const lastTime = this.lastOperationTime[formId] || 0;
    const attempts = this.operationAttempts[formId] || 0;

    // 基础限制：1分钟内最多5次操作
    const timeLimit = 60 * 1000; // 1分钟
    const maxAttempts = 5;

    // 敏感操作限制：1分钟内最多3次操作
    const isSensitive = form.dataset.sensitive === 'true';
    const sensitiveMaxAttempts = 3;

    const currentMaxAttempts = isSensitive ? sensitiveMaxAttempts : maxAttempts;

    if (now - lastTime < timeLimit && attempts >= currentMaxAttempts) {
      const remainingTime = Math.ceil((timeLimit - (now - lastTime)) / 1000);
      this.showNotification(
        this.t('validation.rate_limit_exceeded', { seconds: remainingTime }),
        'warning',
      );
      return false;
    }

    // 重置计数器（如果超过时间限制）
    if (now - lastTime >= timeLimit) {
      this.operationAttempts[formId] = 1;
    } else {
      this.operationAttempts[formId] = attempts + 1;
    }

    this.lastOperationTime[formId] = now;
    return true;
  }

  /**
     * 二次确认操作
     */
  confirmOperation (form) {
    // 检查是否需要二次确认
    const requiresConfirmation = form.dataset.confirm === 'true';
    const isSensitive = form.dataset.sensitive === 'true';

    if (!requiresConfirmation && !isSensitive) {
      return true;
    }

    // 获取确认消息
    const confirmMessage = form.dataset.confirmMessage ||
            this.t('validation.confirm_operation');
    const confirmTitle = form.dataset.confirmTitle ||
            this.t('validation.confirm_title');

    // 同步确认（简单操作）
    if (!isSensitive) {
      return window.confirm(confirmMessage);
    }

    // 异步确认（敏感操作）
    // 注意：这里需要返回Promise，但由于form submit事件是同步的，
    // 我们需要阻止默认行为并手动提交表单
    return this.confirm(confirmMessage, confirmTitle).then((confirmed) => {
      if (confirmed) {
        // 用户确认，手动提交表单
        form.submit();
      }
      return false;
    });
  }

  /**
     * 增强表单验证规则
     */
  enhancedValidateField (field) {
    const value = field.value.trim();
    const rules = field.dataset.rules ? field.dataset.rules.split('|') : [];

    // 基础验证
    if (!this.validateField(field)) {
      return false;
    }

    // 增强验证规则
    for (const rule of rules) {
      if (rule === 'strong_password') {
        if (!this.validateStrongPassword(value)) {
          this.showFieldError(field, this.t('validation.password_weak'));
          return false;
        }
      }

      if (rule === 'username') {
        if (!this.validateUsername(value)) {
          this.showFieldError(field, this.t('validation.username_invalid'));
          return false;
        }
      }

      if (rule === 'domain') {
        if (!this.validateDomain(value)) {
          this.showFieldError(field, this.t('validation.domain_invalid'));
          return false;
        }
      }

      if (rule === 'json') {
        if (!this.validateJSON(value)) {
          this.showFieldError(field, this.t('validation.json_invalid'));
          return false;
        }
      }

      if (rule.startsWith('regex:')) {
        const pattern = rule.substring(6);
        if (!this.validateRegex(value, pattern)) {
          this.showFieldError(field, this.t('validation.pattern_invalid'));
          return false;
        }
      }
    }

    return true;
  }

  /**
     * 验证强密码
     */
  validateStrongPassword (password) {
    // 至少8位，包含大小写字母、数字和特殊字符
    const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return strongPasswordRegex.test(password);
  }

  /**
     * 验证用户名
     */
  validateUsername (username) {
    // 3-20位，只能包含字母、数字、下划线和连字符
    const usernameRegex = /^[a-zA-Z0-9_-]{3,20}$/;
    return usernameRegex.test(username);
  }

  /**
     * 验证域名
     */
  validateDomain (domain) {
    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])*$/;
    return domainRegex.test(domain);
  }

  /**
     * 验证JSON格式
     */
  validateJSON (jsonString) {
    try {
      JSON.parse(jsonString);
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
     * 验证正则表达式
     */
  validateRegex (value, pattern) {
    try {
      const regex = new RegExp(pattern);
      return regex.test(value);
    } catch (e) {
      return false;
    }
  }

  /**
     * 显示字段错误（增强版）
     */
  showFieldError (field, message) {
    field.classList.add('is-invalid');

    // 移除旧的错误消息
    const oldFeedback = field.parentNode.querySelector('.invalid-feedback');
    if (oldFeedback) {
      oldFeedback.remove();
    }

    // 添加新的错误消息
    const feedback = document.createElement('div');
    feedback.className = 'invalid-feedback';
    feedback.textContent = message;
    field.parentNode.appendChild(feedback);

    // 添加震动效果
    field.classList.add('shake');
    setTimeout(() => {
      field.classList.remove('shake');
    }, 500);
  }

  /**
     * 安全表单提交
     */
  secureFormSubmit (form) {
    // 添加CSRF令牌（如果不存在）
    this.addCSRFToken(form);

    // 清理敏感数据
    this.sanitizeFormData(form);

    // 显示加载状态
    const submitBtn = form.querySelector('[type="submit"]');
    if (submitBtn) {
      this.setButtonLoading(submitBtn, true);
    }

    return true;
  }

  /**
     * 添加CSRF令牌
     */
  addCSRFToken (form) {
    if (!form.querySelector('input[name="csrf_token"]')) {
      const csrfToken = document.querySelector('meta[name="csrf-token"]');
      if (csrfToken) {
        const tokenInput = document.createElement('input');
        tokenInput.type = 'hidden';
        tokenInput.name = 'csrf_token';
        tokenInput.value = csrfToken.getAttribute('content');
        form.appendChild(tokenInput);
      }
    }
  }

  /**
     * 清理表单数据
     */
  sanitizeFormData (form) {
    const inputs = form.querySelectorAll('input, textarea');
    inputs.forEach((input) => {
      // 移除潜在的XSS代码
      if (input.type !== 'password' && input.type !== 'file') {
        input.value = this.sanitizeInput(input.value);
      }
    });
  }

  /**
     * 清理输入数据
     */
  sanitizeInput (input) {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
  }
}

// 初始化用户体验增强器
document.addEventListener('DOMContentLoaded', () => {
  window.uxEnhancer = new UXEnhancer();
});

// 全局函数
window.showNotification = function (message, type, duration) {
  if (window.uxEnhancer) {
    window.uxEnhancer.showNotification(message, type, duration);
  }
};

window.confirmAction = function (message, title) {
  if (window.uxEnhancer) {
    return window.uxEnhancer.confirm(message, title);
  }
  return Promise.resolve(false);
};

window.copyToClipboard = function (text) {
  if (window.uxEnhancer) {
    return window.uxEnhancer.copyToClipboard(text);
  }
};

// 多语言全局函数
window.t = function (key, params = {}) {
  if (window.uxEnhancer) {
    return window.uxEnhancer.t(key, params);
  }
  return key;
};

window.switchLanguage = function (language) {
  if (window.uxEnhancer) {
    return window.uxEnhancer.switchLanguage(language);
  }
};

window.getCurrentLanguage = function () {
  if (window.uxEnhancer) {
    return window.uxEnhancer.getCurrentLanguage();
  }
  return 'zh-CN';
};
