/**
 * 统一数据加载管理器
 * 提供统一的API请求、错误处理、重复请求防护等功能
 */

class DataLoader {
  constructor () {
    this.pendingRequests = new Map(); // 防止重复请求
    this.retryConfig = {
      maxRetries: 3,
      retryDelay: 1000,
      retryDelayMultiplier: 2,
    };
    this.defaultTimeout = 30000; // 30秒超时
    this.language = 'zh-CN';
  }

  /**
     * 设置语言
     * @param {string} language
     */
  setLanguage (language) {
    this.language = language;
  }

  /**
     * 生成请求唯一标识
     * @param {string} url
     * @param {Object} params
     * @returns {string}
     */
  generateRequestKey (url, params = {}) {
    const sortedParams = Object.keys(params).sort().reduce((result, key) => {
      result[key] = params[key];
      return result;
    }, {});
    return `${url}?${JSON.stringify(sortedParams)}`;
  }

  /**
     * 检查是否有重复请求
     * @param {string} requestKey
     * @returns {boolean}
     */
  hasPendingRequest (requestKey) {
    return this.pendingRequests.has(requestKey);
  }

  /**
     * 添加请求到待处理列表
     * @param {string} requestKey
     * @param {AbortController} controller
     */
  addPendingRequest (requestKey, controller) {
    this.pendingRequests.set(requestKey, controller);
  }

  /**
     * 移除待处理请求
     * @param {string} requestKey
     */
  removePendingRequest (requestKey) {
    this.pendingRequests.delete(requestKey);
  }

  /**
     * 取消重复请求
     * @param {string} requestKey
     */
  cancelPendingRequest (requestKey) {
    if (this.pendingRequests.has(requestKey)) {
      const controller = this.pendingRequests.get(requestKey);
      controller.abort();
      this.removePendingRequest(requestKey);
    }
  }

  /**
     * 获取错误消息
     * @param {Error} error
     * @param {string} defaultMessage
     * @returns {string}
     */
  getErrorMessage (error, defaultMessage = '操作失败') {
    if (error.name === 'AbortError') {
      return '请求已取消';
    }

    if (error.code === 'NETWORK_ERROR') {
      return '网络连接失败，请检查网络设置';
    }

    if (error.code === 'TIMEOUT') {
      return '请求超时，请稍后重试';
    }

    if (error.response) {
      // 服务器响应错误
      const status = error.response.status;
      const data = error.response.data;

      switch (status) {
      case 400:
        return data.message || '请求参数错误';
      case 401:
        return '登录已过期，请重新登录';
      case 403:
        return '权限不足，无法执行此操作';
      case 404:
        return '请求的资源不存在';
      case 422:
        return data.message || '数据验证失败';
      case 429:
        return '请求过于频繁，请稍后重试';
      case 500:
        return '服务器内部错误';
      case 502:
        return '服务器网关错误';
      case 503:
        return '服务暂时不可用';
      default:
        return data.message || `服务器错误 (${status})`;
      }
    }

    return error.message || defaultMessage;
  }

  /**
     * 显示错误消息
     * @param {string} message
     * @param {string} type
     */
  showError (message, type = 'error') {
    // 尝试使用全局消息显示函数
    if (typeof window.showToast === 'function') {
      window.showToast(message, type);
    } else if (typeof window.showMessage === 'function') {
      window.showMessage(message, type);
    } else if (typeof window.showAlert === 'function') {
      window.showAlert(message, type);
    } else {
      // 降级到原生alert
      console.error(message);
      alert(message);
    }
  }

  /**
     * 创建带超时的fetch请求
     * @param {string} url
     * @param {Object} options
     * @param {number} timeout
     * @returns {Promise}
     */
  createTimeoutFetch (url, options = {}, timeout = this.defaultTimeout) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
    }, timeout);

    const fetchOptions = {
      ...options,
      signal: controller.signal,
    };

    return fetch(url, fetchOptions)
      .finally(() => {
        clearTimeout(timeoutId);
      });
  }

  /**
     * 延迟函数
     * @param {number} ms
     * @returns {Promise}
     */
  delay (ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
     * 统一的API请求方法
     * @param {Object} config
     * @returns {Promise}
     */
  async request (config) {
    const {
      url,
      method = 'GET',
      data = null,
      params = {},
      headers = {},
      timeout = this.defaultTimeout,
      preventDuplicate = true,
      showLoading = false,
      showError = true,
      retryCount = 0,
      onLoadingStart = null,
      onLoadingEnd = null,
      onSuccess = null,
      onError = null,
    } = config;

    // 构建完整URL
    const fullUrl = new URL(url, window.location.origin);
    Object.keys(params).forEach((key) => {
      if (params[key] !== null && params[key] !== undefined) {
        fullUrl.searchParams.set(key, params[key]);
      }
    });

    // 生成请求唯一标识
    const requestKey = this.generateRequestKey(fullUrl.toString(), data);

    // 检查重复请求
    if (preventDuplicate && this.hasPendingRequest(requestKey)) {
      console.log(`重复请求已阻止: ${requestKey}`);
      return Promise.reject(new Error('重复请求已阻止'));
    }

    // 创建新的请求控制器
    const controller = new AbortController();
    this.addPendingRequest(requestKey, controller);

    try {
      // 显示加载状态
      if (showLoading && onLoadingStart) {
        onLoadingStart();
      }

      // 构建请求选项
      const fetchOptions = {
        method,
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Accept-Language': this.language,
          ...headers,
        },
        signal: controller.signal,
      };

      // 添加请求体
      if (data && method !== 'GET') {
        fetchOptions.body = JSON.stringify(data);
      }

      // 发送请求
      const response = await this.createTimeoutFetch(fullUrl.toString(), fetchOptions, timeout);

      // 检查响应状态
      if (!response.ok) {
        const error = new Error(`HTTP ${response.status}: ${response.statusText}`);
        error.response = {
          status: response.status,
          statusText: response.statusText,
          data: null,
        };

        try {
          const responseData = await response.json();
          error.response.data = responseData;
        } catch (e) {
          // 忽略JSON解析错误
        }

        throw error;
      }

      // 解析响应数据
      const responseData = await response.json();

      // 检查业务逻辑状态
      if (!responseData.success) {
        const error = new Error(responseData.message || '操作失败');
        error.response = {
          status: response.status,
          statusText: response.statusText,
          data: responseData,
        };
        throw error;
      }

      // 成功回调
      if (onSuccess) {
        onSuccess(responseData);
      }

      return responseData;
    } catch (error) {
      // 重试逻辑
      if (retryCount < this.retryConfig.maxRetries &&
                (error.code === 'NETWORK_ERROR' || error.code === 'TIMEOUT' || error.name === 'AbortError')) {
        const retryDelay = this.retryConfig.retryDelay * Math.pow(this.retryConfig.retryDelayMultiplier, retryCount);
        console.log(`请求失败，${retryDelay}ms后重试 (${retryCount + 1}/${this.retryConfig.maxRetries})`);

        await this.delay(retryDelay);
        return this.request({
          ...config,
          retryCount: retryCount + 1,
        });
      }

      // 错误回调
      if (onError) {
        onError(error);
      }

      // 显示错误消息
      if (showError) {
        const errorMessage = this.getErrorMessage(error, config.defaultErrorMessage || '操作失败');
        this.showError(errorMessage, 'error');
      }

      throw error;
    } finally {
      // 清理请求状态
      this.removePendingRequest(requestKey);

      // 隐藏加载状态
      if (showLoading && onLoadingEnd) {
        onLoadingEnd();
      }
    }
  }

  /**
     * GET请求
     * @param {string} url
     * @param {Object} config
     * @returns {Promise}
     */
  get (url, config = {}) {
    return this.request({
      url,
      method: 'GET',
      ...config,
    });
  }

  /**
     * POST请求
     * @param {string} url
     * @param {Object} data
     * @param {Object} config
     * @returns {Promise}
     */
  post (url, data, config = {}) {
    return this.request({
      url,
      method: 'POST',
      data,
      ...config,
    });
  }

  /**
     * PUT请求
     * @param {string} url
     * @param {Object} data
     * @param {Object} config
     * @returns {Promise}
     */
  put (url, data, config = {}) {
    return this.request({
      url,
      method: 'PUT',
      data,
      ...config,
    });
  }

  /**
     * DELETE请求
     * @param {string} url
     * @param {Object} config
     * @returns {Promise}
     */
  delete (url, config = {}) {
    return this.request({
      url,
      method: 'DELETE',
      ...config,
    });
  }

  /**
     * 批量请求
     * @param {Array} requests
     * @returns {Promise}
     */
  async batch (requests) {
    try {
      const results = await Promise.allSettled(
        requests.map((request) => this.request(request)),
      );

      const successful = results.filter((result) => result.status === 'fulfilled');
      const failed = results.filter((result) => result.status === 'rejected');

      return {
        success: true,
        data: {
          successful: successful.map((result) => result.value),
          failed: failed.map((result) => ({
            request: result.reason.config,
            error: result.reason.message,
          })),
          total: results.length,
          successCount: successful.length,
          failCount: failed.length,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
     * 取消所有待处理请求
     */
  cancelAllRequests () {
    this.pendingRequests.forEach((controller, key) => {
      controller.abort();
      console.log(`已取消请求: ${key}`);
    });
    this.pendingRequests.clear();
  }

  /**
     * 获取待处理请求数量
     * @returns {number}
     */
  getPendingRequestCount () {
    return this.pendingRequests.size;
  }

  /**
     * 检查网络状态
     * @returns {boolean}
     */
  isOnline () {
    return navigator.onLine;
  }

  /**
     * 等待网络恢复
     * @returns {Promise}
     */
  waitForOnline () {
    return new Promise((resolve) => {
      if (navigator.onLine) {
        resolve();
        return;
      }

      const handleOnline = () => {
        window.removeEventListener('online', handleOnline);
        resolve();
      };

      window.addEventListener('online', handleOnline);
    });
  }
}

// 创建全局实例
const dataLoader = new DataLoader();

// 监听网络状态变化
window.addEventListener('online', () => {
  console.log('网络已恢复');
});

window.addEventListener('offline', () => {
  console.log('网络已断开');
  dataLoader.showError('网络连接已断开，请检查网络设置', 'warning');
});

// 页面卸载时取消所有请求
window.addEventListener('beforeunload', () => {
  dataLoader.cancelAllRequests();
});

// 导出到全局
window.DataLoader = DataLoader;
window.dataLoader = dataLoader;
