// 订单管理JavaScript
class OrderManager {
  constructor () {
    this.currentPage = 1;
    this.pageSize = 20;
    this.filters = {};
    this.selectedOrders = new Set();

    this.init();
  }

  init () {
    this.bindEvents();
    this.loadStatistics();
    this.loadOrders();

    // 初始化数据加载管理器语言设置
    if (typeof dataLoader !== 'undefined') {
      dataLoader.setLanguage(this.currentLanguage || 'zh-CN');
    }

    // 初始化分页管理器
    try {
      this.paginationManager = new PaginationManager({
        containerId: 'pagination',
        currentPage: 1,
        totalPages: 1,
        onPageChange: (page) => {
          this.currentPage = page;
          this.loadOrders();
        },
        language: this.currentLanguage || 'zh-CN',
      });
    } catch (error) {
      console.error('初始化分页管理器失败:', error);
    }
  }

  bindEvents () {
    // 搜索表单提交
    document.getElementById('searchForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleSearch();
    });

    // 刷新按钮
    document.getElementById('refreshBtn').addEventListener('click', () => {
      this.loadOrders();
      this.loadStatistics();
    });

    // 导出按钮
    document.getElementById('exportBtn').addEventListener('click', () => {
      this.exportOrders();
    });

    // 全选复选框
    document.getElementById('selectAll').addEventListener('change', (e) => {
      this.handleSelectAll(e.target.checked);
    });

    // 批量更新按钮
    document.getElementById('batchUpdateBtn').addEventListener('click', () => {
      this.showBatchUpdateModal();
    });

    // 创建订单表单提交
    document.getElementById('saveOrderBtn').addEventListener('click', () => {
      this.createOrder();
    });

    // 批量更新确认
    document.getElementById('confirmBatchUpdateBtn').addEventListener('click', () => {
      this.batchUpdateOrders();
    });

    // 状态更新确认
    document.getElementById('confirmStatusUpdateBtn').addEventListener('click', () => {
      this.updateOrderStatus();
    });

    // 事件委托 - 处理订单表格中的所有交互元素
    const ordersTableBody = document.getElementById('ordersTableBody');
    if (ordersTableBody) {
      ordersTableBody.addEventListener('click', (e) => {
        // 处理订单详情链接
        const detailLink = e.target.closest('.order-detail-link');
        if (detailLink) {
          e.preventDefault();
          this.showOrderDetail(detailLink.dataset.id);
          return;
        }

        // 处理详情按钮
        const detailBtn = e.target.closest('.btn-detail');
        if (detailBtn) {
          this.showOrderDetail(detailBtn.dataset.id);
          return;
        }

        // 处理状态更新按钮
        const statusBtn = e.target.closest('.btn-status');
        if (statusBtn) {
          this.showStatusUpdateModal(statusBtn.dataset.id);
          return;
        }

        // 处理删除按钮
        const deleteBtn = e.target.closest('.btn-delete');
        if (deleteBtn) {
          this.deleteOrder(deleteBtn.dataset.id);
        }
      });

      // 处理复选框选择
      ordersTableBody.addEventListener('change', (e) => {
        if (e.target.classList.contains('order-checkbox')) {
          if (e.target.checked) {
            this.selectedOrders.add(e.target.value);
          } else {
            this.selectedOrders.delete(e.target.value);
          }
          this.updateBatchButton();
        }
      });
    }
  }

  handleSearch () {
    this.filters = {
      keyword: document.getElementById('keyword').value,
      status: document.getElementById('status').value,
      payment_method: document.getElementById('paymentMethod').value,
      start_date: document.getElementById('startDate').value,
      end_date: document.getElementById('endDate').value,
    };

    this.currentPage = 1;
    this.loadOrders();
  }

  async loadStatistics () {
    try {
      const response = await dataLoader.get('api/orders/statistics', {
        params: this.filters,
        showLoading: false,
        defaultErrorMessage: '加载统计数据失败',
      });

      const stats = response.data;
      document.getElementById('totalOrders').textContent = stats.total_orders || 0;
      document.getElementById('completedOrders').textContent = stats.status_statistics?.find((s) => s.status === 'completed')?.count || 0;
      document.getElementById('pendingOrders').textContent = stats.status_statistics?.find((s) => s.status === 'pending')?.count || 0;
      document.getElementById('todayOrders').textContent = stats.today_orders || 0;
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  }

  async loadOrders () {
    try {
      const response = await dataLoader.get('api/orders/list', {
        params: {
          ...this.filters,
          page: this.currentPage,
          limit: this.pageSize,
        },
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '加载订单列表失败',
      });

      this.renderOrdersTable(response.data.orders);
      this.renderPagination(response.data);
    } catch (error) {
      console.error('加载订单列表失败:', error);
    }
  }

  renderOrdersTable (orders) {
    const tbody = document.getElementById('ordersTableBody');

    if (orders.length === 0) {
      tbody.innerHTML = '<tr><td colspan="10" class="text-center">暂无订单数据</td></tr>';
      return;
    }

    tbody.innerHTML = orders.map((order) => `
            <tr>
                <td><input type="checkbox" class="order-checkbox" value="${order.id}"></td>
                <td>
                    <a href="#" class="order-detail-link" data-id="${order.id}">
                        ${order.order_no}
                    </a>
                </td>
                <td>${order.username || '-'}</td>
                <td>${order.product_name}</td>
                <td>${order.quantity}</td>
                <td>¥${order.actual_amount}</td>
                <td>${this.getPaymentMethodLabel(order.payment_method)}</td>
                <td>${this.getStatusBadge(order.status)}</td>
                <td>${this.formatDateTime(order.created_at)}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-primary btn-detail" data-id="${order.id}">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" class="btn btn-outline-warning btn-status" data-id="${order.id}" data-status="${order.status}">
                            <i class="fas fa-edit"></i>
                        </button>
                        ${order.status === 'cancelled' || order.status === 'refunded'
    ? `<button type="button" class="btn btn-outline-danger btn-delete" data-id="${order.id}">
                                <i class="fas fa-trash"></i>
                            </button>`
    : ''}
                    </div>
                </td>
            </tr>
        `).join('');

    // 绑定行事件
    // 事件委托已经处理了所有表格内的交互，不再需要单独绑定事件

    // 复选框的交互已经通过事件委托处理
  }

  renderPagination (data) {
    // 如果还没有分页管理器实例，创建一个
    if (!this.paginationManager) {
      this.paginationManager = new PaginationManager({
        containerId: 'pagination',
        currentPage: data.page,
        totalPages: data.pages,
        onPageChange: (newPage) => {
          if (newPage && newPage !== this.currentPage) {
            this.currentPage = newPage;
            this.loadOrders();
          }
        },
        language: this.currentLanguage || 'zh-CN',
      });
    } else {
      // 更新现有分页管理器的状态
      this.paginationManager.update({
        currentPage: data.page,
        totalPages: data.pages,
      });
    }
  }

  async showOrderDetail (orderId) {
    try {
      const response = await dataLoader.get(`api/orders/detail/${orderId}`, {
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '加载订单详情失败',
      });

      const order = response.data;
      const content = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6>基本信息</h6>
                            <table class="table table-sm">
                                <tr><td>订单号</td><td>${order.order_no}</td></tr>
                                <tr><td>用户</td><td>${order.username || '-'}</td></tr>
                                <tr><td>邮箱</td><td>${order.email || '-'}</td></tr>
                                <tr><td>状态</td><td>${this.getStatusBadge(order.status)}</td></tr>
                                <tr><td>支付方式</td><td>${this.getPaymentMethodLabel(order.payment_method)}</td></tr>
                                <tr><td>支付交易号</td><td>${order.payment_id || '-'}</td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6>金额信息</h6>
                            <table class="table table-sm">
                                <tr><td>产品名称</td><td>${order.product_name}</td></tr>
                                <tr><td>购买数量</td><td>${order.quantity}</td></tr>
                                <tr><td>单价</td><td>¥${order.unit_price}</td></tr>
                                <tr><td>总金额</td><td>¥${order.total_amount}</td></tr>
                                <tr><td>折扣金额</td><td>¥${order.discount_amount}</td></tr>
                                <tr><td>实付金额</td><td class="font-weight-bold">¥${order.actual_amount}</td></tr>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <h6>时间信息</h6>
                            <table class="table table-sm">
                                <tr><td>创建时间</td><td>${this.formatDateTime(order.created_at)}</td></tr>
                                <tr><td>支付时间</td><td>${this.formatDateTime(order.paid_at)}</td></tr>
                                <tr><td>完成时间</td><td>${this.formatDateTime(order.completed_at)}</td></tr>
                                <tr><td>取消时间</td><td>${this.formatDateTime(order.cancelled_at)}</td></tr>
                                <tr><td>退款时间</td><td>${this.formatDateTime(order.refunded_at)}</td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6>卡密信息</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>卡密代码</th>
                                            <th>面值</th>
                                            <th>状态</th>
                                            <th>激活时间</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${order.cards && order.cards.length > 0
    ? order.cards.map((card) => `
                                            <tr>
                                                <td>${card.card_code || '-'}</td>
                                                <td>¥${card.card_value || '-'}</td>
                                                <td>${this.getCardStatusBadge(card.status)}</td>
                                                <td>${this.formatDateTime(card.activated_at)}</td>
                                            </tr>
                                        `).join('')
    : '<tr><td colspan="4" class="text-center">暂无卡密</td></tr>'}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    ${order.remark
    ? `
                        <div class="row mt-3">
                            <div class="col-12">
                                <h6>备注</h6>
                                <p>${order.remark}</p>
                            </div>
                        </div>
                    `
    : ''}
                `;

      document.getElementById('orderDetailContent').innerHTML = content;
      new bootstrap.Modal(document.getElementById('orderDetailModal')).show();
    } catch (error) {
      console.error('加载订单详情失败:', error);
      this.showToast('加载订单详情失败', 'error');
    }
  }

  showStatusUpdateModal (orderId) {
    document.getElementById('updateOrderId').value = orderId;
    document.getElementById('updateStatus').value = '';
    document.getElementById('updateRemark').value = '';
    new bootstrap.Modal(document.getElementById('statusUpdateModal')).show();
  }

  async updateOrderStatus () {
    const orderId = document.getElementById('updateOrderId').value;
    const newStatus = document.getElementById('updateStatus').value;
    const remark = document.getElementById('updateRemark').value;

    if (!newStatus) {
      this.showToast('请选择新状态', 'warning');
      return;
    }

    try {
      await dataLoader.put('api/orders/status', {
        order_id: orderId,
        status: newStatus,
        remark,
      }, {
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '更新订单状态失败',
      });

      this.showToast('订单状态更新成功', 'success');
      bootstrap.Modal.getInstance(document.getElementById('statusUpdateModal')).hide();
      this.loadOrders();
      this.loadStatistics();
    } catch (error) {
      console.error('更新订单状态失败:', error);
    }
  }

  async createOrder () {
    const formData = {
      user_id: document.getElementById('createUserId').value,
      product_id: document.getElementById('createProductId').value,
      quantity: document.getElementById('createQuantity').value,
      payment_method: document.getElementById('createPaymentMethod').value,
      remark: document.getElementById('createRemark').value,
    };

    try {
      const response = await axios.post('api/orders/create', formData);

      if (response.data.success) {
        this.showToast('订单创建成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('createOrderModal')).hide();
        document.getElementById('createOrderForm').reset();
        this.loadOrders();
        this.loadStatistics();
      }
    } catch (error) {
      console.error('创建订单失败:', error);
      this.showToast('创建订单失败', 'error');
    }
  }

  handleSelectAll (checked) {
    const checkboxes = document.querySelectorAll('.order-checkbox');
    checkboxes.forEach((checkbox) => {
      checkbox.checked = checked;
      if (checked) {
        this.selectedOrders.add(checkbox.value);
      } else {
        this.selectedOrders.delete(checkbox.value);
      }
    });
    this.updateBatchButton();
  }

  updateBatchButton () {
    const batchBtn = document.getElementById('batchUpdateBtn');
    if (this.selectedOrders.size > 0) {
      batchBtn.disabled = false;
      document.getElementById('selectedCount').textContent = this.selectedOrders.size;
    } else {
      batchBtn.disabled = true;
      document.getElementById('selectedCount').textContent = '0';
    }
  }

  showBatchUpdateModal () {
    if (this.selectedOrders.size === 0) {
      this.showToast('请先选择要更新的订单', 'warning');
      return;
    }

    document.getElementById('batchStatus').value = '';
    document.getElementById('batchRemark').value = '';
    document.getElementById('selectedCount').textContent = this.selectedOrders.size;
    new bootstrap.Modal(document.getElementById('batchUpdateModal')).show();
  }

  async batchUpdateOrders () {
    const newStatus = document.getElementById('batchStatus').value;
    const remark = document.getElementById('batchRemark').value;

    if (!newStatus) {
      this.showToast('请选择新状态', 'warning');
      return;
    }

    try {
      await dataLoader.put('api/orders/batch-status', {
        order_ids: Array.from(this.selectedOrders),
        status: newStatus,
        remark,
      }, {
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '批量更新失败',
      });

      this.showToast('批量更新成功', 'success');
      bootstrap.Modal.getInstance(document.getElementById('batchUpdateModal')).hide();
      this.selectedOrders.clear();
      this.loadOrders();
      this.loadStatistics();
    } catch (error) {
      console.error('批量更新失败:', error);
    }
  }

  async deleteOrder (orderId) {
    if (!confirm('确定要删除这个订单吗？此操作不可恢复！')) {
      return;
    }

    try {
      await dataLoader.delete(`api/orders/${orderId}`, {
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '删除订单失败',
      });

      this.showToast('订单删除成功', 'success');
      this.loadOrders();
      this.loadStatistics();
    } catch (error) {
      console.error('删除订单失败:', error);
    }
  }

  async exportOrders () {
    try {
      const params = {
        ...this.filters,
        format: 'csv',
      };

      const response = await dataLoader.get('api/orders/export', {
        params,
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '导出订单失败',
      });

      // 创建下载链接
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `orders_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      this.showToast('订单导出成功', 'success');
    } catch (error) {
      console.error('导出订单失败:', error);
    }
  }

  getStatusBadge (status) {
    const statusMap = {
      pending: '<span class="badge bg-warning">待支付</span>',
      paid: '<span class="badge bg-info">已支付</span>',
      processing: '<span class="badge bg-primary">处理中</span>',
      completed: '<span class="badge bg-success">已完成</span>',
      cancelled: '<span class="badge bg-secondary">已取消</span>',
      refunded: '<span class="badge bg-danger">已退款</span>',
      partial_refund: '<span class="badge bg-warning">部分退款</span>',
    };
    return statusMap[status] || status;
  }

  getCardStatusBadge (status) {
    const statusMap = {
      reserved: '<span class="badge bg-secondary">预留</span>',
      activated: '<span class="badge bg-info">已激活</span>',
      used: '<span class="badge bg-success">已使用</span>',
      expired: '<span class="badge bg-warning">已过期</span>',
      refunded: '<span class="badge bg-danger">已退款</span>',
    };
    return statusMap[status] || status;
  }

  getPaymentMethodLabel (method) {
    const methodMap = {
      alipay: '支付宝',
      wechat: '微信支付',
      balance: '余额支付',
    };
    return methodMap[method] || method || '-';
  }

  formatDateTime (dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('zh-CN');
  }

  showToast (message, type = 'info') {
    // 创建toast元素
    const toastHtml = `
            <div class="toast align-items-center text-white bg-${type === 'error' ? 'danger' : type === 'success' ? 'success' : 'info'} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;

    const toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
    toastContainer.innerHTML = toastHtml;
    document.body.appendChild(toastContainer);

    const toast = new bootstrap.Toast(toastContainer.querySelector('.toast'));
    toast.show();

    // 自动移除
    setTimeout(() => {
      document.body.removeChild(toastContainer);
    }, 5000);
  }
}

// 初始化订单管理器
document.addEventListener('DOMContentLoaded', () => {
  new OrderManager();
});
