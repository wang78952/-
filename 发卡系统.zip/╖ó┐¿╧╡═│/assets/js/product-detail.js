/**
 * 产品详情页交互功能
 */

// 产品数据
const productData = {
  id: 'tencent-video-year',
  name: '腾讯视频VIP年卡会员',
  category: 'video-vip',
  price: 198.00,
  originalPrice: 258.00,
  discount: 0.77,
  stock: 998,
  rating: 4.8,
  reviews: 2341,
  sales: 15678,
  images: [
    'https://via.placeholder.com/600x400/165DFF/FFFFFF?text=腾讯视频年卡',
    'https://via.placeholder.com/600x400/00B42A/FFFFFF?text=详情1',
    'https://via.placeholder.com/600x400/FF7D00/FFFFFF?text=详情2',
    'https://via.placeholder.com/600x400/F53F3F/FFFFFF?text=详情3',
  ],
  specs: {
    duration: [
      { id: 'year', name: '年卡', price: 198.00, originalPrice: 258.00 },
      { id: 'quarter', name: '季卡', price: 58.00, originalPrice: 78.00 },
      { id: 'month', name: '月卡', price: 19.90, originalPrice: 25.00 },
    ],
    version: [
      { id: 'standard', name: '标准版', price: 0 },
      { id: 'premium', name: '高级版', price: 20.00 },
    ],
  },
  features: [
    '海量影视资源，涵盖电影、电视剧、综艺、动漫等',
    '独家内容抢先看，热门剧集同步更新',
    '免广告观看，享受纯净观影体验',
    '支持多设备同时观看，手机、平板、电脑通用',
    '高清画质，支持4K超清播放',
    '离线下载功能，随时随地观看',
  ],
};

// 当前选择的状态
const currentSelection = {
  duration: 'year',
  version: 'standard',
  quantity: 1,
  currentImageIndex: 0,
};

// DOM元素
let elements = {};

// 初始化函数
function initProductDetail () {
  initElements();
  initEventListeners();
  updateProductInfo();
  initAnimations();
  initLazyLoading();
  initScrollEffects();
}

// 初始化DOM元素
function initElements () {
  elements = {
    mainImage: document.getElementById('mainImage'),
    quantityInput: document.getElementById('quantityInput'),
    decreaseBtn: document.getElementById('decreaseBtn'),
    increaseBtn: document.getElementById('increaseBtn'),
    currentPrice: document.querySelector('.current-price'),
    originalPrice: document.querySelector('.original-price'),
    discountBadge: document.querySelector('.discount-badge'),
    stockInfo: document.querySelector('.stock-info'),
    purchaseTitle: document.querySelector('.purchase-title'),
    thumbnails: document.querySelectorAll('.product-thumbnail'),
    faqItems: document.querySelectorAll('.faq-item'),
  };
}

// 初始化事件监听器
function initEventListeners () {
  // 数量输入框变化
  elements.quantityInput.addEventListener('input', function () {
    const value = parseInt(this.value);
    if (isNaN(value) || value < 1) {
      this.value = 1;
    } else if (value > productData.stock) {
      this.value = productData.stock;
      Utils.showToast('库存不足', 'warning');
    }
    currentSelection.quantity = parseInt(this.value);
    updateQuantityButtons();
  });

  // FAQ折叠面板
  elements.faqItems.forEach((item) => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', function () {
      toggleFaq(this);
    });
  });

  // 图片懒加载
  const images = document.querySelectorAll('img[loading="lazy"]');
  images.forEach((img) => {
    img.addEventListener('load', function () {
      this.classList.add('loaded');
    });
  });

  // 滚动事件
  window.addEventListener('scroll', handleScroll);
}

// 更新产品信息
function updateProductInfo () {
  const durationSpec = productData.specs.duration.find((s) => s.id === currentSelection.duration);
  const versionSpec = productData.specs.version.find((s) => s.id === currentSelection.version);

  const basePrice = durationSpec.price;
  const versionPrice = versionSpec.price;
  const totalPrice = basePrice + versionPrice;
  const totalOriginalPrice = durationSpec.originalPrice + versionPrice;
  const discount = totalPrice / totalOriginalPrice;

  // 更新价格显示
  elements.currentPrice.textContent = `¥${totalPrice.toFixed(2)}`;
  elements.originalPrice.textContent = `¥${totalOriginalPrice.toFixed(2)}`;
  elements.discountBadge.textContent = `${(discount * 10).toFixed(1)}折`;

  // 更新库存信息
  const remainingStock = productData.stock - currentSelection.quantity;
  elements.stockInfo.innerHTML = `
        <i class="fas fa-check-circle"></i>
        库存${remainingStock > 50 ? '充足' : `仅剩${remainingStock}件`} (${remainingStock}件)
    `;

  // 更新购买区域标题
  elements.purchaseTitle.textContent = `${productData.name} - ${durationSpec.name}`;
}

// 切换产品图片
function changeImage (index) {
  if (index === currentSelection.currentImageIndex) return;

  // 更新缩略图状态
  elements.thumbnails.forEach((thumb, i) => {
    thumb.classList.toggle('active', i === index);
  });

  // 切换主图
  const mainImage = elements.mainImage;
  mainImage.style.opacity = '0';

  setTimeout(() => {
    mainImage.src = productData.images[index];
    mainImage.style.opacity = '1';
  }, 200);

  currentSelection.currentImageIndex = index;
}

// 选择规格
function selectSpec (button) {
  const specGroup = button.closest('.spec-group');
  const specOptions = specGroup.querySelectorAll('.spec-option');

  // 移除其他选中状态
  specOptions.forEach((btn) => btn.classList.remove('selected'));

  // 添加选中状态
  button.classList.add('selected');

  // 更新选择状态
  const specLabel = specGroup.querySelector('.spec-label').textContent;
  if (specLabel === '选择规格') {
    currentSelection.duration = button.textContent.trim().toLowerCase();
  } else if (specLabel === '选择版本') {
    currentSelection.version = button.textContent.trim().toLowerCase();
  }

  // 更新产品信息
  updateProductInfo();

  // 添加选择动画
  Animation.bounce(button);
}

// 增加数量
function increaseQuantity () {
  if (currentSelection.quantity >= productData.stock) {
    Utils.showToast('已达到最大库存数量', 'warning');
    return;
  }

  currentSelection.quantity++;
  elements.quantityInput.value = currentSelection.quantity;
  updateQuantityButtons();
  updateProductInfo();
}

// 减少数量
function decreaseQuantity () {
  if (currentSelection.quantity <= 1) return;

  currentSelection.quantity--;
  elements.quantityInput.value = currentSelection.quantity;
  updateQuantityButtons();
  updateProductInfo();
}

// 更新数量
function updateQuantity () {
  const value = parseInt(elements.quantityInput.value);
  if (isNaN(value) || value < 1) {
    elements.quantityInput.value = 1;
    currentSelection.quantity = 1;
  } else if (value > productData.stock) {
    elements.quantityInput.value = productData.stock;
    currentSelection.quantity = productData.stock;
    Utils.showToast('库存不足', 'warning');
  } else {
    currentSelection.quantity = value;
  }

  updateQuantityButtons();
  updateProductInfo();
}

// 更新数量按钮状态
function updateQuantityButtons () {
  elements.decreaseBtn.disabled = currentSelection.quantity <= 1;
  elements.increaseBtn.disabled = currentSelection.quantity >= productData.stock;

  elements.decreaseBtn.classList.toggle('disabled', currentSelection.quantity <= 1);
  elements.increaseBtn.classList.toggle('disabled', currentSelection.quantity >= productData.stock);
}

// 立即购买
function buyNow () {
  // 检查登录状态
  if (!Storage.get('userToken')) {
    Utils.showConfirm('请先登录', '立即购买需要登录账号，是否前往登录？', () => {
      window.location.href = 'login.html';
    });
    return;
  }

  // 添加到购物车并跳转到结算页
  const cartItem = createCartItem();
  Storage.set('directPurchase', cartItem);

  // 显示加载状态
  const button = event.target.closest('.btn-purchase');
  const originalText = button.innerHTML;
  button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 处理中...';
  button.disabled = true;

  setTimeout(() => {
    button.innerHTML = originalText;
    button.disabled = false;
    window.location.href = 'checkout.html';
  }, 1000);
}

// 添加到购物车
function addToCart () {
  const cartItem = createCartItem();
  const cart = Storage.get('cart') || [];

  // 检查是否已存在相同商品
  const existingIndex = cart.findIndex((item) =>
    item.id === cartItem.id &&
        item.duration === cartItem.duration &&
        item.version === cartItem.version,
  );

  if (existingIndex !== -1) {
    cart[existingIndex].quantity += cartItem.quantity;
  } else {
    cart.push(cartItem);
  }

  Storage.set('cart', cart);

  // 更新购物车数量
  updateCartCount();

  // 显示成功提示
  Utils.showToast('已添加到购物车', 'success');

  // 添加动画效果
  const button = event.target.closest('.btn-add-cart');
  Animation.bounce(button);
}

// 创建购物车项目
function createCartItem () {
  const durationSpec = productData.specs.duration.find((s) => s.id === currentSelection.duration);
  const versionSpec = productData.specs.version.find((s) => s.id === currentSelection.version);

  return {
    id: productData.id,
    name: productData.name,
    image: productData.images[0],
    duration: durationSpec.id,
    durationName: durationSpec.name,
    version: versionSpec.id,
    versionName: versionSpec.name,
    price: durationSpec.price + versionSpec.price,
    originalPrice: durationSpec.originalPrice + versionSpec.price,
    quantity: currentSelection.quantity,
    category: productData.category,
  };
}

// 切换FAQ
function toggleFaq (button) {
  const faqItem = button.closest('.faq-item');
  const answer = faqItem.querySelector('.faq-answer');
  const icon = button.querySelector('.faq-icon');
  const isOpen = faqItem.classList.contains('open');

  // 关闭其他FAQ项
  document.querySelectorAll('.faq-item').forEach((item) => {
    if (item !== faqItem) {
      item.classList.remove('open');
      item.querySelector('.faq-answer').style.maxHeight = '0';
      item.querySelector('.faq-icon').style.transform = 'rotate(0deg)';
    }
  });

  // 切换当前FAQ项
  faqItem.classList.toggle('open');

  if (isOpen) {
    answer.style.maxHeight = '0';
    icon.style.transform = 'rotate(0deg)';
  } else {
    answer.style.maxHeight = answer.scrollHeight + 'px';
    icon.style.transform = 'rotate(180deg)';
  }
}

// 跳转到产品页面
function goToProduct (productId) {
  window.location.href = `product-detail.html?id=${productId}`;
}

// 初始化动画
function initAnimations () {
  // 产品信息淡入动画
  const productInfo = document.querySelector('.product-info');
  const purchaseSection = document.querySelector('.product-purchase');

  setTimeout(() => {
    productInfo.classList.add('fade-in');
    purchaseSection.classList.add('slide-up');
  }, 100);

  // 特性列表逐个显示
  const featureItems = document.querySelectorAll('.product-features li');
  featureItems.forEach((item, index) => {
    setTimeout(() => {
      item.style.opacity = '1';
      item.style.transform = 'translateX(0)';
    }, 200 + index * 100);
  });
}

// 初始化懒加载
function initLazyLoading () {
  const lazyImages = document.querySelectorAll('img[loading="lazy"]');

  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src || img.src;
          img.classList.add('loaded');
          observer.unobserve(img);
        }
      });
    });

    lazyImages.forEach((img) => imageObserver.observe(img));
  }
}

// 初始化滚动效果
function initScrollEffects () {
  let lastScrollTop = 0;

  function handleScroll () {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const purchaseSection = document.querySelector('.product-purchase');

    // 购买区域固定效果
    if (scrollTop > 500) {
      purchaseSection.classList.add('sticky');
    } else {
      purchaseSection.classList.remove('sticky');
    }

    lastScrollTop = scrollTop;
  }

  window.addEventListener('scroll', Utils.throttle(handleScroll, 100));
}

// 处理滚动事件
function handleScroll () {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

  // 相关产品区域显示动画
  const relatedProducts = document.querySelector('.related-products');
  if (relatedProducts) {
    const rect = relatedProducts.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      relatedProducts.classList.add('visible');
    }
  }
}

// 更新购物车数量
function updateCartCount () {
  const cart = Storage.get('cart') || [];
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartCount = document.querySelector('.cart-count');
  if (cartCount) {
    cartCount.textContent = totalCount;
    cartCount.style.display = totalCount > 0 ? 'block' : 'none';
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function () {
  initProductDetail();
  updateCartCount();
});

// 监听页面卸载，保存浏览历史
window.addEventListener('beforeunload', function () {
  const viewHistory = Storage.get('viewHistory') || [];
  const newViewItem = {
    productId: productData.id,
    productName: productData.name,
    viewTime: new Date().toISOString(),
  };

  // 避免重复记录
  const existingIndex = viewHistory.findIndex((item) => item.productId === productData.id);
  if (existingIndex === -1) {
    viewHistory.unshift(newViewItem);
    // 保留最近20条记录
    Storage.set('viewHistory', viewHistory.slice(0, 20));
  }
});
