/**
 * 数据可视化图表组件库
 * 提供统一的图表接口，支持ECharts和Chart.js两种图表引擎
 * 包含性能优化：懒加载、防抖节流、数据降采样等功能
 */

class ChartComponents {
    constructor() {
        this.charts = {}; // 存储已创建的图表实例
        this.defaultEngine = 'echarts'; // 默认图表引擎
        this.defaultCacheMinutes = 30; // 默认缓存时间（分钟）
        this.throttledResize = this.throttle(this.resizeAllCharts.bind(this), 100); // 节流的窗口大小调整
        this.debouncedUpdate = {}; // 存储图表更新的防抖函数
        this.lazyLoadedCharts = {}; // 存储懒加载的图表配置
        this.setupEventListeners();
        this.setupLazyLoading();
    }
    
    /**
     * 缓存管理器
     */
    cacheManager = {
        // 设置缓存
        set: function(key, data, expirationMinutes = 30) {
            const cacheData = {
                data: data,
                timestamp: new Date().getTime(),
                expiration: expirationMinutes * 60 * 1000
            };
            localStorage.setItem('chart_cache_' + key, JSON.stringify(cacheData));
        },
        
        // 获取缓存
        get: function(key) {
            const cacheItem = localStorage.getItem('chart_cache_' + key);
            if (!cacheItem) return null;
            
            const cacheData = JSON.parse(cacheItem);
            const now = new Date().getTime();
            
            // 检查是否过期
            if (now - cacheData.timestamp > cacheData.expiration) {
                localStorage.removeItem('chart_cache_' + key);
                return null;
            }
            
            return cacheData.data;
        },
        
        // 清除特定缓存
        clear: function(key) {
            localStorage.removeItem('chart_cache_' + key);
        },
        
        // 清除所有图表缓存
        clearAll: function() {
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key.startsWith('chart_cache_')) {
                    localStorage.removeItem(key);
                }
            }
        },
        
        // 获取缓存键（基于图表配置生成唯一键）
        getCacheKey: function(chartId, chartData) {
            // 提取关键参数用于生成缓存键
            const params = {
                id: chartId,
                type: chartData.type,
                dateRange: chartData.dateRange || 'default',
                filters: chartData.filters || {}
            };
            return JSON.stringify(params);
        },
        
        // 清除过期缓存
        clearExpiredCache: function() {
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key.startsWith('chart_cache_')) {
                    try {
                        const cacheItem = localStorage.getItem(key);
                        const cacheData = JSON.parse(cacheItem);
                        const now = new Date().getTime();
                        
                        // 检查是否过期
                        if (now - cacheData.timestamp > cacheData.expiration) {
                            localStorage.removeItem(key);
                            console.log('清除过期缓存：' + key);
                        }
                    } catch (error) {
                        console.error('清理缓存时出错：' + error.message);
                    }
                }
            }
        }
    };

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        // 窗口大小改变时，自动调整图表大小（使用节流优化性能）
        window.addEventListener('resize', this.throttledResize);
        
        // 页面卸载前清理资源
        window.addEventListener('beforeunload', () => {
            this.cleanupResources();
        });
    }
    
    /**
     * 设置懒加载
     */
    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            this.observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const chartId = entry.target.id;
                        if (this.lazyLoadedCharts[chartId]) {
                            const chartConfig = this.lazyLoadedCharts[chartId];
                            this.createLazyChart(chartId, chartConfig);
                            observer.unobserve(entry.target);
                        }
                    }
                });
            }, {
                rootMargin: '100px', // 提前100px开始加载
                threshold: 0.1 // 当10%的元素可见时触发
            });
        }
    }
    
    /**
     * 创建懒加载图表
     */
    createLazyChart(chartId, config) {
        const container = document.getElementById(chartId);
        if (!container || !config) return;
        
        try {
            // 先显示骨架屏
            container.innerHTML = '<div class="chart-skeleton"></div>';
            
            // 延迟创建，让浏览器有时间处理渲染
            setTimeout(() => {
                container.innerHTML = '';
                const { type, data, options, engine, apiUrl } = config;
                
                if (apiUrl) {
                    // 从API加载数据
                    this.loadChartData(chartId, apiUrl, type, options, engine);
                } else {
                    // 使用本地数据
                    this.createChartByType(chartId, type, data, options, engine);
                }
            }, 100);
        } catch (error) {
            console.error('Error creating lazy chart:', error);
        }
    }
    
    /**
     * 清理资源
     */
    cleanupResources() {
        // 销毁所有图表实例
        Object.keys(this.charts).forEach(chartId => {
            this.destroyChart(chartId);
        });
        
        // 清理事件监听器
        window.removeEventListener('resize', this.throttledResize);
        
        // 清理观察器
        if (this.observer) {
            this.observer.disconnect();
        }
    }

    /**
     * 创建图表实例（支持懒加载）
     * @param {string} chartId - 图表容器ID
     * @param {Object} options - 图表配置
     * @param {string} engine - 图表引擎 ('echarts' 或 'chartjs')
     * @param {boolean} lazy - 是否懒加载
     * @returns {Object} - 创建的图表实例
     */
    createChart(chartId, options = {}, engine = this.defaultEngine, lazy = false) {
        const container = document.getElementById(chartId);
        if (!container) {
            console.error(`Chart container not found: ${chartId}`);
            return null;
        }
        
        // 如果启用懒加载
        if (lazy && 'IntersectionObserver' in window) {
            // 检查元素是否已经在视口中
            const rect = container.getBoundingClientRect();
            const isVisible = (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
            
            if (!isVisible) {
                // 不在视口中，进行懒加载
                this.lazyLoadedCharts[chartId] = { options, engine, type: options.type || 'line' };
                container.classList.add('chart-lazy-loading');
                this.observer.observe(container);
                return null;
            }
        }
        
        container.classList.remove('chart-lazy-loading');
        delete this.lazyLoadedCharts[chartId];
        const container = document.getElementById(chartId);
        if (!container) {
            console.error(`Chart container not found: ${chartId}`);
            return null;
        }
        
        // 生成缓存键
        const cacheKey = this.cacheManager.getCacheKey(chartId, options);
        
        // 检查缓存
        const cachedOptions = this.cacheManager.get(cacheKey);
        if (cachedOptions) {
            console.log('使用缓存配置渲染图表：' + chartId);
            options = cachedOptions;
        } else {
            // 如果没有缓存，存储当前配置
            this.cacheManager.set(cacheKey, options, this.defaultCacheMinutes);
        }

        try {
            let chart;
            
            // 先销毁已存在的图表实例
            if (this.charts[chartId]) {
                this.destroyChart(chartId);
            }

            if (engine === 'echarts') {
                chart = this.createEChartsChart(chartId, options);
            } else if (engine === 'chartjs') {
                chart = this.createChartJSChart(chartId, options);
            } else {
                console.error(`Unsupported chart engine: ${engine}`);
                return null;
            }

            this.charts[chartId] = {
                instance: chart,
                engine: engine,
                container: container
            };

            return chart;
        } catch (error) {
            console.error('Error creating chart:', error);
            return null;
        }
    }

    /**
     * 使用ECharts创建图表
     */
    createEChartsChart(chartId, options) {
        if (!window.echarts) {
            console.error('ECharts not loaded');
            return null;
        }

        const container = document.getElementById(chartId);
        const chart = echarts.init(container);
        
        // 合并默认配置
        const mergedOptions = this.mergeEChartsOptions(options);
        chart.setOption(mergedOptions);
        
        return chart;
    }

    /**
     * 使用Chart.js创建图表
     */
    createChartJSChart(chartId, options) {
        if (!window.Chart) {
            console.error('Chart.js not loaded');
            return null;
        }

        const ctx = document.getElementById(chartId).getContext('2d');
        
        // 合并默认配置
        const mergedOptions = this.mergeChartJSOptions(options);
        
        return new Chart(ctx, mergedOptions);
    }

    /**
     * 合并ECharts默认配置
     */
    mergeEChartsOptions(options) {
        const defaultOptions = {
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(50, 50, 50, 0.9)',
                borderColor: '#ddd',
                textStyle: {
                    color: '#fff'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            textStyle: {
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'
            }
        };

        return this.deepMerge(defaultOptions, options);
    }

    /**
     * 合并Chart.js默认配置
     */
    mergeChartJSOptions(options) {
        const defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    backgroundColor: 'rgba(50, 50, 50, 0.9)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: '#ddd',
                    borderWidth: 1,
                    padding: 10,
                    cornerRadius: 4
                }
            }
        };

        return this.deepMerge(defaultOptions, options);
    }

    /**
     * 更新图表数据（带防抖优化）
     * @param {string} chartId - 图表ID
     * @param {Object} data - 新数据
     * @param {number} debounceTime - 防抖时间（毫秒）
     */
    updateChart(chartId, data, debounceTime = 100) {
        const chartInfo = this.charts[chartId];
        if (!chartInfo) {
            console.error(`Chart not found: ${chartId}`);
            return;
        }

        try {
            // 检查是否启用防抖
            if (debounceTime > 0) {
                if (!this.debouncedUpdate[chartId]) {
                    this.debouncedUpdate[chartId] = this.debounce((chartId, data) => {
                        this.performChartUpdate(chartId, data);
                    }, debounceTime);
                }
                this.debouncedUpdate[chartId](chartId, data);
            } else {
                // 直接更新
                this.performChartUpdate(chartId, data);
            }
        } catch (error) {
            console.error('Error updating chart:', error);
        }
    }
    
    /**
     * 执行图表更新（实际更新操作）
     */
    performChartUpdate(chartId, data) {
        const chartInfo = this.charts[chartId];
        if (!chartInfo) return;
        
        try {
            // 对大数据集进行降采样处理
            const processedData = this.optimizeChartData(chartInfo.engine, data);
            
            if (chartInfo.engine === 'echarts') {
                chartInfo.instance.setOption(processedData);
            } else if (chartInfo.engine === 'chartjs') {
                this.updateChartJSData(chartInfo.instance, processedData);
            }
            
            // 更新缓存
            const cacheKey = this.cacheManager.getCacheKey(chartId, data);
            this.cacheManager.set(cacheKey, data, this.defaultCacheMinutes);
        } catch (error) {
            console.error('Error performing chart update:', error);
        }
    }
    
    /**
     * 强制刷新图表数据（忽略缓存）
     * @param {string} chartId - 图表ID
     * @param {string} apiUrl - API地址
     * @param {string} chartType - 图表类型
     * @param {Object} options - 图表配置
     * @param {string} engine - 图表引擎
     */
    async refreshChartData(chartId, apiUrl, chartType, options = {}, engine = this.defaultEngine) {
        const container = document.getElementById(chartId);
        if (!container) return;
        
        // 显示加载状态
        container.innerHTML = '<div class="chart-loading">加载中...</div>';
        
        // 清除相关缓存
        const cacheKey = 'api_' + apiUrl;
        const chartCacheKey = this.cacheManager.getCacheKey(chartId, { type: chartType });
        this.cacheManager.clear(cacheKey);
        this.cacheManager.clear(chartCacheKey);
        
        try {
            // 获取新数据
            const response = await dataLoader.get(apiUrl);
            
            if (response && response.data) {
                // 清除加载状态
                container.innerHTML = '';
                
                // 重新缓存数据
                this.cacheManager.set(cacheKey, response, this.defaultCacheMinutes);
                
                // 根据图表类型创建图表
                switch (chartType) {
                    case 'line':
                        this.createLineChart(chartId, response.data, options, engine);
                        break;
                    case 'bar':
                        this.createBarChart(chartId, response.data, options, engine);
                        break;
                    case 'pie':
                        this.createPieChart(chartId, response.data, options, engine);
                        break;
                    default:
                        this.createChart(chartId, response.data, engine);
                }
            }
        } catch (error) {
            console.error('Error refreshing chart data:', error);
            container.innerHTML = '<div class="chart-error">刷新失败，请重试</div>';
        }
    }
    
    /**
     * 清除指定图表的缓存
     * @param {string} chartId - 图表ID
     */
    clearChartCache(chartId) {
        // 清除与该图表相关的所有缓存
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('chart_cache_') && key.includes(chartId)) {
                localStorage.removeItem(key);
            }
        }
        console.log('已清除图表缓存：' + chartId);
    }
    
    /**
     * 清除所有图表缓存
     */
    clearAllCache() {
        this.cacheManager.clearAll();
        console.log('已清除所有图表缓存');
    }
    
    /**
     * 设置默认缓存时间
     * @param {number} minutes - 缓存时间（分钟）
     */
    setCacheTime(minutes) {
        this.defaultCacheMinutes = minutes;
        console.log('已设置默认缓存时间：' + minutes + '分钟');
    }

    /**
     * 更新Chart.js图表数据
     */
    updateChartJSData(chart, data) {
        try {
            // 使用批量更新优化性能
            chart.data = {
                labels: data.labels || chart.data.labels,
                datasets: data.datasets || chart.data.datasets
            };
            
            // 对大数据集关闭动画以提高性能
            const isLargeDataset = this.isLargeDataset(chart.data);
            chart.update(isLargeDataset ? 'none' : 'default');
        } catch (error) {
            console.error('Error updating Chart.js data:', error);
        }
    }
    
    /**
     * 检查是否为大数据集
     */
    isLargeDataset(data) {
        if (!data || !data.datasets) return false;
        
        const totalPoints = data.datasets.reduce((sum, dataset) => {
            return sum + (dataset.data ? dataset.data.length : 0);
        }, 0);
        
        return totalPoints > 1000; // 超过1000个数据点视为大数据集
    }
    
    /**
     * 优化图表数据（降采样、数据处理等）
     */
    optimizeChartData(engine, data) {
        if (!data) return data;
        
        try {
            const result = JSON.parse(JSON.stringify(data)); // 深拷贝
            
            if (engine === 'echarts') {
                // 优化ECharts数据
                if (result.series) {
                    result.series = result.series.map(series => {
                        if (series.data && series.data.length > 2000) {
                            // 对大型数据集进行降采样
                            series.data = this.downsampleData(series.data, 2000);
                        }
                        return series;
                    });
                }
            } else if (engine === 'chartjs') {
                // 优化Chart.js数据
                if (result.datasets) {
                    result.datasets = result.datasets.map(dataset => {
                        if (dataset.data && dataset.data.length > 2000) {
                            dataset.data = this.downsampleData(dataset.data, 2000);
                        }
                        return dataset;
                    });
                    
                    // 同步降采样标签
                    if (result.labels && result.datasets.length > 0 && 
                        result.labels.length !== result.datasets[0].data.length) {
                        result.labels = this.downsampleLabels(result.labels, result.datasets[0].data.length);
                    }
                }
            }
            
            return result;
        } catch (error) {
            console.error('Error optimizing chart data:', error);
            return data;
        }
    }
    
    /**
     * 降采样数据点
     */
    downsampleData(data, maxPoints) {
        if (!data || data.length <= maxPoints) return data;
        
        const step = Math.ceil(data.length / maxPoints);
        const result = [];
        
        for (let i = 0; i < data.length; i += step) {
            // 保留关键点（最大值、最小值、第一个点、最后一个点）
            const window = data.slice(i, Math.min(i + step, data.length));
            let max = -Infinity, min = Infinity, maxIndex = 0, minIndex = 0;
            
            window.forEach((value, idx) => {
                const numValue = typeof value === 'object' && value.value !== undefined ? value.value : Number(value);
                if (numValue > max) {
                    max = numValue;
                    maxIndex = idx;
                }
                if (numValue < min) {
                    min = numValue;
                    minIndex = idx;
                }
            });
            
            // 添加窗口的第一个点、最大值点、最小值点和最后一个点
            result.push(window[0]);
            if (maxIndex > 0 && maxIndex < window.length - 1) {
                result.push(window[maxIndex]);
            }
            if (minIndex > 0 && minIndex < window.length - 1 && minIndex !== maxIndex) {
                result.push(window[minIndex]);
            }
        }
        
        // 确保最后一个点被包含
        if (result[result.length - 1] !== data[data.length - 1]) {
            result.push(data[data.length - 1]);
        }
        
        return result;
    }
    
    /**
     * 降采样标签
     */
    downsampleLabels(labels, targetLength) {
        if (!labels || labels.length <= targetLength) return labels;
        
        const result = [];
        const step = Math.ceil(labels.length / targetLength);
        
        for (let i = 0; i < labels.length; i += step) {
            result.push(labels[i]);
        }
        
        // 确保数量匹配
        while (result.length > targetLength) {
            result.pop();
        }
        
        return result;
    }

    /**
     * 销毁图表实例
     * @param {string} chartId - 图表ID
     */
    destroyChart(chartId) {
        const chartInfo = this.charts[chartId];
        if (!chartInfo) {
            return;
        }

        try {
            if (chartInfo.engine === 'echarts') {
                chartInfo.instance.dispose();
            } else if (chartInfo.engine === 'chartjs') {
                chartInfo.instance.destroy();
            }
            
            delete this.charts[chartId];
        } catch (error) {
            console.error('Error destroying chart:', error);
        }
    }

    /**
     * 调整所有图表大小
     */
    resizeAllCharts() {
        Object.values(this.charts).forEach(chartInfo => {
            if (chartInfo.engine === 'echarts') {
                chartInfo.instance.resize();
            } else if (chartInfo.engine === 'chartjs') {
                // Chart.js 会自动调整大小
            }
        });
    }

    /**
     * 导出图表为图片
     * @param {string} chartId - 图表ID
     * @param {string} filename - 文件名
     */
    exportChart(chartId, filename = `chart_${Date.now()}`) {
        const chartInfo = this.charts[chartId];
        if (!chartInfo) {
            console.error(`Chart not found: ${chartId}`);
            return;
        }

        try {
            if (chartInfo.engine === 'echarts') {
                const url = chartInfo.instance.getDataURL({
                    type: 'png',
                    pixelRatio: 2,
                    backgroundColor: '#fff'
                });
                
                this.downloadImage(url, `${filename}.png`);
            } else if (chartInfo.engine === 'chartjs') {
                const url = chartInfo.instance.toBase64Image();
                this.downloadImage(url, `${filename}.png`);
            }
        } catch (error) {
            console.error('Error exporting chart:', error);
        }
    }

    /**
     * 下载图片
     */
    downloadImage(url, filename) {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    /**
     * 防抖函数 - 限制函数在指定时间内只执行一次
     * @param {Function} func - 要执行的函数
     * @param {number} wait - 等待时间（毫秒）
     * @returns {Function} - 防抖处理后的函数
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    /**
     * 节流函数 - 限制函数在一定时间内只能执行一次
     * @param {Function} func - 要执行的函数
     * @param {number} limit - 时间限制（毫秒）
     * @returns {Function} - 节流处理后的函数
     */
    throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    /**
     * 创建常见图表类型
     */
    createChartByType(chartId, chartType, data, options = {}, engine = this.defaultEngine) {
        switch (chartType) {
            case 'line':
                return this.createLineChart(chartId, data, options, engine);
            case 'bar':
                return this.createBarChart(chartId, data, options, engine);
            case 'pie':
                return this.createPieChart(chartId, data, options, engine);
            default:
                return this.createChart(chartId, data, engine);
        }
    }
    
    /**
     * 创建折线图
     */
    createLineChart(chartId, data, options = {}, engine = this.defaultEngine) {
        if (engine === 'echarts') {
            const chartOptions = {
                xAxis: {
                    type: 'category',
                    data: data.labels || [],
                    boundaryGap: false
                },
                yAxis: {
                    type: 'value'
                },
                series: data.series.map(item => ({
                    data: item.data,
                    type: 'line',
                    smooth: true,
                    name: item.name || '',
                    lineStyle: {
                        width: 2
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                }))
            };

            return this.createChart(chartId, this.deepMerge(chartOptions, options), engine);
        } else {
            const chartOptions = {
                type: 'line',
                data: {
                    labels: data.labels || [],
                    datasets: data.series.map(item => ({
                        label: item.name || '',
                        data: item.data,
                        borderColor: item.color || this.generateColor(),
                        backgroundColor: item.color ? this.rgba(item.color, 0.1) : this.generateColor(0.1),
                        tension: 0.4
                    }))
                }
            };

            return this.createChart(chartId, this.deepMerge(chartOptions, options), engine);
        }
    }

    createBarChart(chartId, data, options = {}, engine = this.defaultEngine) {
        if (engine === 'echarts') {
            const chartOptions = {
                xAxis: {
                    type: 'category',
                    data: data.labels || []
                },
                yAxis: {
                    type: 'value'
                },
                series: data.series.map(item => ({
                    data: item.data,
                    type: 'bar',
                    name: item.name || '',
                    itemStyle: {
                        color: item.color || this.generateColor()
                    }
                }))
            };

            return this.createChart(chartId, this.deepMerge(chartOptions, options), engine);
        } else {
            const chartOptions = {
                type: 'bar',
                data: {
                    labels: data.labels || [],
                    datasets: data.series.map(item => ({
                        label: item.name || '',
                        data: item.data,
                        backgroundColor: item.color || this.generateColor()
                    }))
                }
            };

            return this.createChart(chartId, this.deepMerge(chartOptions, options), engine);
        }
    }

    createPieChart(chartId, data, options = {}, engine = this.defaultEngine) {
        if (engine === 'echarts') {
            const chartOptions = {
                series: [{
                    type: 'pie',
                    radius: '60%',
                    data: data.map((item, index) => ({
                        value: item.value,
                        name: item.name,
                        itemStyle: {
                            color: item.color || this.getPresetColors()[index % 5]
                        }
                    })),
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }]
            };

            return this.createChart(chartId, this.deepMerge(chartOptions, options), engine);
        } else {
            const chartOptions = {
                type: 'pie',
                data: {
                    labels: data.map(item => item.name),
                    datasets: [{
                        data: data.map(item => item.value),
                        backgroundColor: data.map((item, index) => item.color || this.getPresetColors()[index % 5])
                    }]
                }
            };

            return this.createChart(chartId, this.deepMerge(chartOptions, options), engine);
        }
    }

    /**
     * 工具方法
     */
    deepMerge(target, source) {
        const output = { ...target };
        if (this.isObject(target) && this.isObject(source)) {
            Object.keys(source).forEach(key => {
                if (this.isObject(source[key])) {
                    if (!(key in target)) {
                        Object.assign(output, { [key]: source[key] });
                    } else {
                        output[key] = this.deepMerge(target[key], source[key]);
                    }
                } else {
                    Object.assign(output, { [key]: source[key] });
                }
            });
        }
        return output;
    }

    isObject(item) {
        return item && typeof item === 'object' && !Array.isArray(item);
    }

    generateColor(opacity = 1) {
        const colors = this.getPresetColors();
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        return opacity === 1 ? randomColor : this.rgba(randomColor, opacity);
    }

    rgba(color, opacity) {
        return color.replace('rgb', 'rgba').replace(')', `, ${opacity})`);
    }

    getPresetColors() {
        return [
            '#667eea',
            '#764ba2',
            '#f093fb',
            '#f5576c',
            '#4facfe',
            '#43e97b',
            '#fa709a',
            '#fee140',
            '#faad14',
            '#00c49f'
        ];
    }

    /**
     * 从API加载数据并渲染图表（带缓存）
     */
    async loadChartData(chartId, apiUrl, chartType, options = {}, engine = this.defaultEngine, cacheMinutes = this.defaultCacheMinutes) {
        const container = document.getElementById(chartId);
        if (!container) return;

        // 显示加载状态
        container.innerHTML = '<div class="chart-loading">加载中...</div>';
        
        // 生成API数据缓存键
        const cacheKey = 'api_' + apiUrl;
        
        // 检查API数据缓存
        const cachedData = this.cacheManager.get(cacheKey);
        
        let response;
        try {
            if (cachedData) {
                console.log('使用缓存API数据：' + apiUrl);
                response = cachedData;
            } else {
                // 使用项目中的数据加载器获取新数据
                response = await dataLoader.get(apiUrl);
                // 存储到缓存
                this.cacheManager.set(cacheKey, response, cacheMinutes);
            }
            
            if (response && response.data) {
                // 清除加载状态
                container.innerHTML = '';
                
                // 根据图表类型创建图表
                switch (chartType) {
                    case 'line':
                        this.createLineChart(chartId, response.data, options, engine);
                        break;
                    case 'bar':
                        this.createBarChart(chartId, response.data, options, engine);
                        break;
                    case 'pie':
                        this.createPieChart(chartId, response.data, options, engine);
                        break;
                    default:
                        this.createChart(chartId, response.data, engine);
                }
            }
        } catch (error) {
            console.error('Error loading chart data:', error);
            container.innerHTML = '<div class="chart-error">加载失败，请重试</div>';
        }
    }
}

// 初始化图表组件库
const chartComponents = new ChartComponents();
window.ChartComponents = ChartComponents;
window.chartComponents = chartComponents;

// 定期清理过期缓存（每小时执行一次）
setInterval(() => {
    chartComponents.cacheManager.clearExpiredCache();
}, 3600000);

// 页面加载时清理过期缓存
window.addEventListener('load', () => {
    chartComponents.cacheManager.clearExpiredCache();
});

// 图表相关的CSS样式
const styleId = 'chart-components-css';
if (!document.getElementById(styleId)) {
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
        .chart-container {
            width: 100%;
            height: 400px;
            position: relative;
        }
        
        .chart-loading,
        .chart-error {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #666;
            font-size: 14px;
        }
        
        .chart-error {
            color: #f5576c;
        }
        
        /* 懒加载骨架屏 */
        .chart-skeleton {
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
            border-radius: 4px;
        }
        
        /* 懒加载容器样式 */
        .chart-lazy-loading {
            opacity: 0.7;
            transition: opacity 0.3s ease;
        }
        
        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }
        
        .chart-controls {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .chart-card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .chart-card:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .chart-title {
            font-size: 16px;
            font-weight: 500;
            margin: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: calc(100% - 120px);
        }`;
    document.head.appendChild(style);
}