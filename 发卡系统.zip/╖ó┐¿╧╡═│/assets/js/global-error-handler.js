/**
 * 全局错误处理器
 * 统一处理JavaScript运行时错误和未捕获的Promise拒绝
 */

class GlobalErrorHandler {
  constructor () {
    this.errorQueue = [];
    this.maxErrorQueue = 50;
    this.reportingEndpoint = 'api/logs/index.php?action=js_error';
    this.isReporting = false;
    this.init();
  }

  init () {
    // 捕获JavaScript运行时错误
    window.addEventListener('error', (event) => {
      this.handleError({
        type: 'javascript',
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack,
        timestamp: new Date().toISOString(),
      });
    });

    // 捕获未处理的Promise拒绝
    window.addEventListener('unhandledrejection', (event) => {
      this.handleError({
        type: 'promise',
        message: event.reason?.message || String(event.reason),
        stack: event.reason?.stack,
        timestamp: new Date().toISOString(),
      });
    });

    // 捕获资源加载错误
    window.addEventListener('error', (event) => {
      if (event.target !== window) {
        this.handleError({
          type: 'resource',
          message: `Failed to load resource: ${event.target.src || event.target.href}`,
          element: event.target.tagName,
          source: event.target.src || event.target.href,
          timestamp: new Date().toISOString(),
        });
      }
    }, true);

    // 页面卸载时发送剩余错误
    window.addEventListener('beforeunload', () => {
      this.flushErrorQueue();
    });
  }

  /**
     * 处理错误
     */
  handleError (error) {
    // 过滤掉一些常见的无害错误
    if (this.shouldIgnoreError(error)) {
      return;
    }

    // 添加到错误队列
    this.errorQueue.push(error);

    // 限制队列大小
    if (this.errorQueue.length > this.maxErrorQueue) {
      this.errorQueue.shift();
    }

    // 显示用户友好的错误消息
    this.showUserFriendlyError(error);

    // 异步上报错误
    this.reportErrors();
  }

  /**
     * 判断是否应该忽略错误
     */
  shouldIgnoreError (error) {
    const ignorePatterns = [
      /Script error/i,
      /Non-Error promise rejection captured/i,
      /Network error/i,
      /Request timeout/i,
      /AbortError/i,
      /ResizeObserver loop limit exceeded/i,
      /Non-Error promise rejection captured with value: undefined/i,
    ];

    return ignorePatterns.some((pattern) => pattern.test(error.message));
  }

  /**
     * 显示用户友好的错误消息
     */
  showUserFriendlyError (error) {
    // 只在生产环境显示用户友好的错误
    if (window.location.hostname === 'localhost' || window.debugMode) {
      return;
    }

    let userMessage = '系统出现了一些问题，请刷新页面重试';

    // 根据错误类型显示不同的消息
    switch (error.type) {
    case 'network':
      userMessage = '网络连接异常，请检查网络后重试';
      break;
    case 'timeout':
      userMessage = '请求超时，请稍后重试';
      break;
    case 'resource':
      userMessage = '资源加载失败，请刷新页面';
      break;
    }

    // 避免频繁显示相同错误
    if (this.lastUserMessage !== userMessage) {
      this.lastUserMessage = userMessage;
      this.showNotification(userMessage, 'warning');
    }
  }

  /**
     * 显示通知消息
     */
  showNotification (message, type = 'info') {
    // 检查是否有UXEnhancer实例
    if (window.uxEnhancer) {
      window.uxEnhancer.showNotification(message, type);
      return;
    }

    // 降级方案：简单的alert
    if (type === 'error' || type === 'danger') {
      console.error(message);
    } else {
      console.warn(message);
    }
  }

  /**
     * 上报错误到服务器
     */
  async reportErrors () {
    if (this.isReporting || this.errorQueue.length === 0) {
      return;
    }

    this.isReporting = true;
    const errorsToReport = [...this.errorQueue];
    this.errorQueue = [];

    try {
      await fetch(this.reportingEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({
          errors: errorsToReport,
          user_agent: navigator.userAgent,
          url: window.location.href,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      // 上报失败，将错误重新加入队列
      this.errorQueue.unshift(...errorsToReport.slice(0, 10)); // 只保留前10个
      console.warn('Failed to report errors:', error);
    } finally {
      this.isReporting = false;
    }
  }

  /**
     * 强制发送错误队列中的所有错误
     */
  async flushErrorQueue () {
    if (this.errorQueue.length > 0) {
      await this.reportErrors();
    }
  }

  /**
     * 手动记录错误
     */
  logError (message, error = null, context = {}) {
    this.handleError({
      type: 'manual',
      message,
      stack: error?.stack,
      context,
      timestamp: new Date().toISOString(),
    });
  }

  /**
     * 获取错误统计
     */
  getErrorStats () {
    const stats = {
      total: this.errorQueue.length,
      byType: {},
      recentErrors: this.errorQueue.slice(-5),
    };

    this.errorQueue.forEach((error) => {
      stats.byType[error.type] = (stats.byType[error.type] || 0) + 1;
    });

    return stats;
  }
}

// 初始化全局错误处理器
window.globalErrorHandler = new GlobalErrorHandler();

// 提供全局错误记录函数
window.logError = function (message, error = null, context = {}) {
  window.globalErrorHandler.logError(message, error, context);
};

// 在开发模式下启用调试
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
  window.debugMode = true;
}
