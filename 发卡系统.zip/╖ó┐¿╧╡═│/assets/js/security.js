// 翻译函数fallback实现
if (typeof t !== 'function') {
  window.t = function (key, params = {}) {
    // 简单的翻译映射
    const translations = {
      'error.load_sensitive_operations_failed': '加载敏感操作失败',
      'error.load_ip_lists_failed': '加载IP列表失败',
      'error.load_security_configs_failed': '加载安全配置失败',
      'common.no_data': '暂无数据',
      'security.actions.create': '创建',
      'security.actions.update': '更新',
      'security.actions.delete': '删除',
      'security.actions.view': '查看',
      'security.event_types.login': '登录',
      'security.event_types.logout': '登出',
      'security.event_types.failed_login': '登录失败',
      'security.event_types.password_change': '密码修改',
      'security.event_types.privilege_escalation': '权限提升',
      'security.severity.low': '低',
      'security.severity.medium': '中',
      'security.severity.high': '高',
      'security.severity.critical': '严重',
      'security.status.active': '激活',
      'security.status.resolved': '已解决',
      'security.status.pending': '待处理',
    };

    let result = translations[key] || key;

    // 替换参数
    if (params && typeof params === 'object') {
      Object.keys(params).forEach((param) => {
        result = result.replace(`{${param}}`, params[param]);
      });
    }

    return result;
  };
}

class SecurityManager {
  constructor () {
    this.currentTab = 'audit';
    this.currentPage = 1;
    this.pageSize = 10;
    this.init();
  }

  async init () {
    try {
      this.currentLanguage = this.getLanguage();
      await this.loadTranslations();
      this.bindEvents();
      this.loadStatistics();
      this.loadAuditLogs();

      // 初始化数据加载管理器语言设置
      if (typeof dataLoader !== 'undefined') {
        dataLoader.setLanguage(this.currentLanguage || 'zh-CN');
      }

      // 初始化分页管理器
      this.paginationManager = new PaginationManager({
        containerId: 'pagination',
        currentPage: 1,
        totalPages: 1,
        onPageChange: (page) => this.goToPage(page),
        language: this.currentLanguage,
      });
    } catch (error) {
      console.error('初始化失败:', error);
      this.showMessage('初始化失败', 'error');
    }
  }

  bindEvents () {
    // 刷新按钮
    document.getElementById('refreshBtn').addEventListener('click', () => {
      this.loadStatistics();
      this.loadCurrentTabData();
    });

    // 选项卡切换
    document.querySelectorAll('#securityTabs button').forEach((tab) => {
      tab.addEventListener('shown.bs.tab', (e) => {
        this.currentTab = e.target.id.replace('-tab', '');
        this.loadCurrentTabData();
      });
    });

    // 审计日志搜索
    document.getElementById('auditSearchForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.currentPage = 1;
      this.loadAuditLogs();
    });

    document.getElementById('clearAuditSearch').addEventListener('click', () => {
      document.getElementById('auditSearchForm').reset();
    });

    // 其他事件绑定...
  }

  getLanguage () {
    return document.documentElement.lang || 'zh-CN';
  }

  async loadTranslations () {
    // 加载翻译文件
  }

  async loadStatistics () {
    try {
      const response = await fetch('api/security/index.php?action=get_statistics');
      const result = await response.json();

      if (result.success) {
        this.renderStatistics(result.data);
      }
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  }

  async loadCurrentTabData () {
    switch (this.currentTab) {
    case 'audit':
      this.loadAuditLogs();
      break;
    case 'events':
      this.loadSecurityEvents();
      break;
    case 'sensitive-operations':
      this.loadSensitiveOperations();
      break;
    case 'ip-lists':
      this.loadIpLists();
      break;
    case 'configs':
      this.loadSecurityConfigs();
      break;
    }
  }

  async loadAuditLogs () {
    try {
      const formData = new FormData(document.getElementById('auditSearchForm'));
      const queryParams = new URLSearchParams(formData);
      queryParams.append('page', this.currentPage);
      queryParams.append('page_size', this.pageSize);

      const response = await fetch(`api/security/index.php?action=get_audit_logs&${queryParams.toString()}`);
      const result = await response.json();

      if (result.success) {
        this.renderAuditLogs(result.data.logs);
        this.renderPagination('pagination', result.data.pagination);
      } else {
        this.showAlert(result.message || '加载审计日志失败', 'danger');
      }
    } catch (error) {
      console.error('加载审计日志失败:', error);
      this.showAlert('加载审计日志失败', 'danger');
    }
  }

  async loadSecurityEvents () {
    try {
      const response = await fetch('api/security/index.php?action=get_security_events');
      const result = await response.json();

      if (result.success) {
        this.renderSecurityEvents(result.data);
      } else {
        this.showAlert(result.message || '加载安全事件失败', 'danger');
      }
    } catch (error) {
      console.error('加载安全事件失败:', error);
      this.showAlert(t('error.load_security_events_failed'), 'danger');
    }
  }

  async loadSensitiveOperations () {
    try {
      const response = await fetch('api/security/index.php?action=get_sensitive_operations');
      const result = await response.json();

      if (result.success) {
        this.renderSensitiveOperations(result.data);
      } else {
        this.showAlert(result.message || '加载敏感操作失败', 'danger');
      }
    } catch (error) {
      console.error('加载敏感操作失败:', error);
      this.showAlert(t('error.load_sensitive_operations_failed'), 'danger');
    }
  }

  async loadIpLists () {
    try {
      const response = await fetch('api/security/index.php?action=get_ip_lists');
      const result = await response.json();

      if (result.success) {
        this.renderIpLists(result.data);
      } else {
        this.showAlert(result.message || '加载IP列表失败', 'danger');
      }
    } catch (error) {
      console.error('加载IP列表失败:', error);
      this.showAlert(t('error.load_ip_lists_failed'), 'danger');
    }
  }

  async loadSecurityConfigs () {
    try {
      const response = await fetch('api/security/index.php?action=get_security_configs');
      const result = await response.json();

      if (result.success) {
        this.renderSecurityConfigs(result.data);
      } else {
        this.showAlert(result.message || '加载安全配置失败', 'danger');
      }
    } catch (error) {
      console.error('加载安全配置失败:', error);
      this.showAlert(t('error.load_security_configs_failed'), 'danger');
    }
  }

  renderAuditLogs (logs) {
    const tbody = document.getElementById('auditTableBody');

    if (logs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center">${t('common.no_data')}</td></tr>`;
      return;
    }

    tbody.innerHTML = logs.map((log) => `
            <tr>
                <td>${log.id}</td>
                <td>${log.user_id || '-'}</td>
                <td>${log.action}</td>
                <td>${log.target}</td>
                <td>${this.formatDateTime(log.created_at)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary audit-details-btn" data-log-id="${log.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');

    // 绑定审计详情按钮事件
    this.bindAuditDetailButtons();
  }

  // 绑定审计详情按钮事件
  bindAuditDetailButtons () {
    document.querySelectorAll('.audit-details-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const logId = btn.getAttribute('data-log-id');
        this.showAuditDetails(logId);
      });
    });
  }

  renderSecurityEvents (events) {
    const tbody = document.getElementById('eventTableBody');

    if (events.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center">${t('common.no_data')}</td></tr>`;
      return;
    }

    tbody.innerHTML = events.map((event) => `
            <tr>
                <td>${event.id}</td>
                <td><span class="badge bg-info">${this.getEventTypeLabel(event.event_type)}</span></td>
                <td><span class="badge bg-${this.getSeverityColor(event.severity)}">${this.getSeverityLabel(event.severity)}</span></td>
                <td>${event.title}</td>
                <td><span class="badge bg-${this.getStatusColor(event.status)}">${this.getStatusLabel(event.status)}</span></td>
                <td>${event.source_ip}</td>
                <td>${this.formatDateTime(event.created_at)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary event-details-btn" data-event-id="${event.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-success event-resolve-btn" data-event-id="${event.id}">
                        <i class="fas fa-check"></i>
                    </button>
                </td>
            </tr>
        `).join('');

    // 绑定事件详情按钮事件
    this.bindEventDetailButtons();
    // 绑定事件解决按钮事件
    this.bindEventResolveButtons();
  }

  // 绑定事件详情按钮事件
  bindEventDetailButtons () {
    document.querySelectorAll('.event-details-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const eventId = btn.getAttribute('data-event-id');
        this.showEventDetails(eventId);
      });
    });
  }

  // 绑定事件解决按钮事件
  bindEventResolveButtons () {
    document.querySelectorAll('.event-resolve-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const eventId = btn.getAttribute('data-event-id');
        this.resolveEvent(eventId);
      });
    });
  }

  renderSensitiveOperations (operations) {
    const tbody = document.getElementById('operationTableBody');

    if (operations.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center">${t('common.no_data')}</td></tr>`;
      return;
    }

    tbody.innerHTML = operations.map((op) => `
            <tr>
                <td>${op.id}</td>
                <td>${op.user_id || '-'}</td>
                <td><span class="badge bg-info">${op.operation_type}</span></td>
                <td>${op.operation_name}</td>
                <td><span class="badge bg-${this.getRiskColor(op.risk_level)}">${op.risk_level}</span></td>
                <td>${op.ip_address}</td>
                <td>${this.formatDateTime(op.created_at)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary operation-details-btn" data-operation-id="${op.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                <td>
            </tr>
        `).join('');

    // 绑定操作详情按钮事件
    this.bindOperationDetailButtons();
  }

  // 绑定操作详情按钮事件
  bindOperationDetailButtons () {
    document.querySelectorAll('.operation-details-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const operationId = btn.getAttribute('data-operation-id');
        this.showOperationDetails(operationId);
      });
    });
  }

  renderIpLists (ipLists) {
    const tbody = document.getElementById('ipTableBody');

    if (ipLists.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center">${t('common.no_data')}</td></tr>`;
      return;
    }

    tbody.innerHTML = ipLists.map((ip) => `
            <tr>
                <td>${ip.id}</td>
                <td>${ip.ip_address}</td>
                <td><span class="badge bg-${ip.list_type === 'whitelist' ? 'success' : 'danger'}">${ip.list_type === 'whitelist' ? '白名单' : '黑名单'}</span></td>
                <td>${ip.reason || '-'}</td>
                <td>${ip.expires_at ? this.formatDateTime(ip.expires_at) : '永不过期'}</td>
                <td><span class="badge bg-${ip.active ? 'success' : 'secondary'}">${ip.active ? '激活' : '未激活'}</span></td>
                <td>${this.formatDateTime(ip.created_at)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-warning ip-toggle-btn" data-ip-id="${ip.id}">
                        <i class="fas fa-toggle-${ip.active ? 'on' : 'off'}"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger ip-delete-btn" data-ip-id="${ip.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');

    // 绑定IP状态切换按钮事件
    this.bindIpToggleButtons();
    // 绑定IP删除按钮事件
    this.bindIpDeleteButtons();
  }

  // 绑定IP状态切换按钮事件
  bindIpToggleButtons () {
    document.querySelectorAll('.ip-toggle-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const ipId = btn.getAttribute('data-ip-id');
        this.toggleIpStatus(ipId);
      });
    });
  }

  // 绑定IP删除按钮事件
  bindIpDeleteButtons () {
    document.querySelectorAll('.ip-delete-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const ipId = btn.getAttribute('data-ip-id');
        this.deleteIpList(ipId);
      });
    });
  }

  renderSecurityConfigs (configs) {
    const tbody = document.getElementById('configTableBody');

    tbody.innerHTML = configs.map((config) => `
            <tr>
                <td>${config.config_key}</td>
                <td>
                    <input type="text" class="form-control form-control-sm" id="config_${config.config_key}" value="${config.config_value}">
                <td>
                <td><span class="badge bg-info">${config.config_type}</span></td>
                <td>${config.description || '-'}</td>
                <td><span class="badge bg-${config.is_encrypted ? 'warning' : 'secondary'}">${config.is_encrypted ? '是' : '否'}</span></td>
                <td>
                    <button class="btn btn-sm btn-primary config-update-btn" data-config-key="${config.config_key}">
                        <i class="fas fa-save"></i>
                    </button>
                <td>
            </tr>
        `).join('');

    // 绑定配置更新按钮事件
    this.bindConfigUpdateButtons();
  }

  // 绑定配置更新按钮事件
  bindConfigUpdateButtons () {
    document.querySelectorAll('.config-update-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const configKey = btn.getAttribute('data-config-key');
        this.updateConfig(configKey);
      });
    });
  }

  renderPagination (containerId, pagination) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';

    if (!pagination || pagination.total_pages <= 1) {
      return;
    }

    // 渲染分页控件
    const paginationEl = document.createElement('nav');
    paginationEl.innerHTML = `
            <ul class="pagination">
                <li class="page-item ${pagination.current_page === 1 ? 'disabled' : ''}">
                    <a class="page-link" href="#" aria-label="Previous" data-page="${pagination.current_page - 1}">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                ${this.generatePageButtons(pagination)}}
                <li class="page-item ${pagination.current_page === pagination.total_pages ? 'disabled' : ''}">
                    <a class="page-link" href="#" aria-label="Next" data-page="${pagination.current_page + 1}">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        `;

    container.appendChild(paginationEl);

    // 绑定分页按钮事件
    paginationEl.querySelectorAll('.page-link').forEach((link) => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = parseInt(link.getAttribute('data-page'));
        if (page && page >= 1 && page <= pagination.total_pages) {
          this.goToPage(page);
        }
      });
    });
  }

  generatePageButtons (pagination) {
    const { current_page, total_pages } = pagination;
    const buttons = [];

    // 生成页码按钮
    const startPage = Math.max(1, current_page - 2);
    const endPage = Math.min(total_pages, startPage + 4);

    for (let i = startPage; i <= endPage; i++) {
      buttons.push(`
                <li class="page-item ${i === current_page ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `);
    }

    return buttons.join('');
  }

  goToPage (page) {
    this.currentPage = page;
    this.loadAuditLogs();
  }

  getActionLabel (action) {
    switch (action) {
    case 'create':
      return t('security.actions.create');
    case 'update':
      return t('security.actions.update');
    case 'delete':
      return t('security.actions.delete');
    case 'view':
      return t('security.actions.view');
    default:
      return action;
    }
  }

  getEventTypeLabel (type) {
    const labels = {
      login: t('security.event_types.login'),
      logout: t('security.event_types.logout'),
      failed_login: t('security.event_types.failed_login'),
      password_change: t('security.event_types.password_change'),
      privilege_escalation: t('security.event_types.privilege_escalation'),
    };
    return labels[type] || type;
  }

  getSeverityLabel (severity) {
    switch (severity) {
    case 'low':
      return t('security.severity.low');
    case 'medium':
      return t('security.severity.medium');
    case 'high':
      return t('security.severity.high');
    case 'critical':
      return t('security.severity.critical');
    default:
      return severity;
    }
  }

  getSeverityColor (severity) {
    switch (severity) {
    case 'low':
      return 'success';
    case 'medium':
      return 'warning';
    case 'high':
    case 'critical':
      return 'danger';
    default:
      return 'secondary';
    }
  }

  getStatusLabel (status) {
    switch (status) {
    case 'active':
      return t('security.status.active');
    case 'resolved':
      return t('security.status.resolved');
    case 'pending':
      return t('security.status.pending');
    default:
      return status;
    }
  }

  getStatusColor (status) {
    switch (status) {
    case 'active':
      return 'danger';
    case 'resolved':
      return 'success';
    case 'pending':
      return 'warning';
    default:
      return 'secondary';
    }
  }

  getRiskColor (risk) {
    switch (risk) {
    case 'low':
      return 'success';
    case 'medium':
      return 'warning';
    case 'high':
    case 'critical':
      return 'danger';
    default:
      return 'secondary';
    }
  }

  formatDateTime (dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
  }

  showAlert (message, type = 'info') {
    // 显示提示信息
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 right-0 m-3 z-50`;
    alertContainer.role = 'alert';
    alertContainer.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;

    document.body.appendChild(alertContainer);

    // 自动关闭
    setTimeout(() => {
      alertContainer.classList.remove('show');
      setTimeout(() => {
        document.body.removeChild(alertContainer);
      }, 300);
    }, 3000);
  }

  showMessage (message, type = 'info') {
    // 显示消息
    this.showAlert(message, type);
  }

  // 详情查看方法
  showAuditDetails (logId) {
    console.log('显示审计详情:', logId);
  }

  showEventDetails (eventId) {
    console.log('显示事件详情:', eventId);
  }

  showOperationDetails (operationId) {
    console.log('显示操作详情:', operationId);
  }

  // 业务操作方法
  async resolveEvent (eventId) {
    if (!confirm('确定要解决这个安全事件吗？')) {
      return;
    }

    try {
      const response = await fetch(`api/security/index.php?action=resolve_event&id=${eventId}`, {
        method: 'PUT',
      });

      const result = await response.json();

      if (result.success) {
        this.showAlert('安全事件已解决', 'success');
        this.loadSecurityEvents();
      } else {
        this.showAlert(result.message || '解决失败', 'danger');
      }
    } catch (error) {
      console.error('解决安全事件失败:', error);
      this.showAlert('解决安全事件失败', 'danger');
    }
  }

  async toggleIpStatus (ipId) {
    try {
      const response = await fetch(`api/security/index.php?action=toggle_ip_status&id=${ipId}`, {
        method: 'PUT',
      });

      const result = await response.json();

      if (result.success) {
        this.showAlert('IP状态已更新', 'success');
        this.loadIpLists();
      } else {
        this.showAlert(result.message || '更新失败', 'danger');
      }
    } catch (error) {
      console.error('更新IP状态失败:', error);
      this.showAlert('更新IP状态失败', 'danger');
    }
  }

  async deleteIpList (ipId) {
    if (!confirm('确定要删除这个IP记录吗？')) {
      return;
    }

    try {
      const response = await fetch(`api/security/index.php?action=delete_ip_list&id=${ipId}`, {
        method: 'DELETE',
      });

      const result = await response.json();

      if (result.success) {
        this.showAlert('IP记录已删除', 'success');
        this.loadIpLists();
      } else {
        this.showAlert(result.message || '删除失败', 'danger');
      }
    } catch (error) {
      console.error('删除IP记录失败:', error);
      this.showAlert('删除IP记录失败', 'danger');
    }
  }

  async updateConfig (configKey) {
    const value = document.getElementById(`config_${configKey}`).value;

    try {
      const response = await fetch('api/security/index.php?action=update_config', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ config_key: configKey, config_value: value }),
      });

      const result = await response.json();

      if (result.success) {
        this.showAlert('配置已更新', 'success');
      } else {
        this.showAlert(result.message || '更新失败', 'danger');
      }
    } catch (error) {
      console.error('更新配置失败:', error);
      this.showAlert('更新配置失败', 'danger');
    }
  }

  // 其他操作方法
  async saveSecurityEvent () {
    const formData = {
      event_type: document.getElementById('eventEventType').value,
      severity: document.getElementById('eventSeverity').value,
      title: document.getElementById('eventTitle').value,
      description: document.getElementById('eventDescription').value,
    };

    try {
      const response = await fetch('api/security/index.php?action=create_event', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (result.success) {
        this.showAlert('安全事件创建成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('securityEventModal')).hide();
        document.getElementById('securityEventForm').reset();
        if (this.currentTab === 'events') {
          this.loadSecurityEvents();
        }
      } else {
        this.showAlert(result.message || '创建失败', 'danger');
      }
    } catch (error) {
      console.error('创建安全事件失败:', error);
      this.showAlert('创建安全事件失败', 'danger');
    }
  }

  async saveIpList () {
    const formData = {
      ip_address: document.getElementById('ipAddress').value,
      list_type: document.getElementById('ipListType').value,
      reason: document.getElementById('ipReason').value,
      expires_at: document.getElementById('ipExpiresAt').value,
    };

    try {
      const response = await fetch('api/security/index.php?action=add_ip_list', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (result.success) {
        this.showAlert('IP列表添加成功', 'success');
        bootstrap.Modal.getInstance(document.getElementById('ipListModal')).hide();
        document.getElementById('ipListForm').reset();
        if (this.currentTab === 'ip-lists') {
          this.loadIpLists();
        }
      } else {
        this.showAlert(result.message || '添加失败', 'danger');
      }
    } catch (error) {
      console.error('添加IP列表失败:', error);
      this.showAlert('添加IP列表失败', 'danger');
    }
  }
}

// 初始化安全管理器
let securityManager;
document.addEventListener('DOMContentLoaded', () => {
  securityManager = new SecurityManager();
});
