/**
 * 数据加载管理器初始化文件
 * 在所有页面加载时自动初始化dataLoader实例
 */

// 确保dataLoader在全局可用
let dataLoader;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function () {
  try {
    // 创建数据加载管理器实例
    dataLoader = new DataLoader({
      baseURL: '',
      timeout: 30000,
      retryAttempts: 3,
      retryDelay: 1000,
      enableCache: true,
      cacheTimeout: 300000, // 5分钟缓存
      showGlobalLoading: true,
      globalLoadingElement: 'loading-overlay',
      language: 'zh-CN',
      onLoadingStart: (options) => {
        // 全局加载开始回调
        if (options.showGlobalLoading) {
          showGlobalLoading();
        }
      },
      onLoadingEnd: (options) => {
        // 全局加载结束回调
        if (options.showGlobalLoading) {
          hideGlobalLoading();
        }
      },
      onError: (error, options) => {
        // 全局错误处理回调
        console.error('数据加载错误:', error);

        // 显示错误提示
        if (options.showErrorMessage !== false && window.showToast) {
          showToast(error.message || '请求失败', 'error');
        }
      },
      onSuccess: (response, options) => {
        // 全局成功回调
        if (options.showSuccessMessage && window.showToast) {
          showToast(options.successMessage || '操作成功', 'success');
        }
      },
    });

    // 设置全局语言
    const currentLanguage = localStorage.getItem('language') || 'zh-CN';
    dataLoader.setLanguage(currentLanguage);

    // 监听语言切换事件
    window.addEventListener('languageChanged', async function (event) {
      const newLanguage = event.detail.language;

      if (dataLoader) {
        dataLoader.setLanguage(newLanguage);
      }

      // 显示加载状态
      showGlobalLoading();

      try {
        // 重新渲染所有动态内容
        await rerenderAllContent();

        // 重新初始化图表（如果存在）
        rerenderCharts();

        // 重新绑定事件处理器
        rebindEventHandlers();

        // 重新渲染表格
        rerenderTables();

        // 重新渲染模态框
        rerenderModals();

        // 更新页面标题
        updatePageTitle();

        // 显示成功消息
        if (window.showToast) {
          showToast('语言切换成功', 'success');
        }
      } catch (error) {
        console.error('Language switch error:', error);
        if (window.showToast) {
          showToast('语言切换失败', 'error');
        }
      } finally {
        hideGlobalLoading();
      }
    });

    /**
         * 重新渲染所有动态内容
         */
    async function rerenderAllContent () {
      // 应用翻译到所有标记的元素
      if (window.uxEnhancer) {
        window.uxEnhancer.applyTranslations();
      }

      // 重新渲染统计卡片
      rerenderStatCards();

      // 重新渲染导航菜单
      rerenderNavigation();

      // 重新渲染按钮和操作
      rerenderButtons();

      // 重新渲染表单标签
      rerenderForms();
    }

    /**
         * 重新渲染统计卡片
         */
    function rerenderStatCards () {
      const statCards = document.querySelectorAll('.stat-card, .metric-card');
      statCards.forEach((card) => {
        const titleElement = card.querySelector('.card-title, .metric-title, h3, h4');
        const valueElement = card.querySelector('.stat-value, .metric-value, .card-value');

        if (titleElement && titleElement.dataset.i18n) {
          const translatedTitle = getTranslation(titleElement.dataset.i18n);
          if (translatedTitle) {
            titleElement.textContent = translatedTitle;
          }
        }
      });
    }

    /**
         * 重新渲染导航菜单
         */
    function rerenderNavigation () {
      const navItems = document.querySelectorAll('nav a, .nav-link, .menu-item');
      navItems.forEach((item) => {
        if (item.dataset.i18n) {
          const translatedText = getTranslation(item.dataset.i18n);
          if (translatedText) {
            item.textContent = translatedText;
          }
        }
      });
    }

    /**
         * 重新渲染按钮
         */
    function rerenderButtons () {
      const buttons = document.querySelectorAll('button, .btn');
      buttons.forEach((button) => {
        if (button.dataset.i18n) {
          const translatedText = getTranslation(button.dataset.i18n);
          if (translatedText) {
            // 保留图标，只更新文本
            const icon = button.querySelector('i, .icon, svg');
            if (icon) {
              button.childNodes.forEach((node) => {
                if (node.nodeType === Node.TEXT_NODE) {
                  node.textContent = translatedText;
                }
              });
            } else {
              button.textContent = translatedText;
            }
          }
        }

        // 更新按钮的title属性
        if (button.dataset.i18nTitle) {
          const translatedTitle = getTranslation(button.dataset.i18nTitle);
          if (translatedTitle) {
            button.title = translatedTitle;
          }
        }
      });
    }

    /**
         * 重新渲染表单
         */
    function rerenderForms () {
      // 表单标签
      const labels = document.querySelectorAll('label');
      labels.forEach((label) => {
        if (label.dataset.i18n) {
          const translatedText = getTranslation(label.dataset.i18n);
          if (translatedText) {
            label.textContent = translatedText;
          }
        }
      });

      // 输入框占位符
      const inputs = document.querySelectorAll('input, textarea, select');
      inputs.forEach((input) => {
        if (input.dataset.i18nPlaceholder) {
          const translatedPlaceholder = getTranslation(input.dataset.i18nPlaceholder);
          if (translatedPlaceholder) {
            input.placeholder = translatedPlaceholder;
          }
        }

        // 更新select选项
        if (input.tagName === 'SELECT') {
          const options = input.querySelectorAll('option[data-i18n]');
          options.forEach((option) => {
            const translatedText = getTranslation(option.dataset.i18n);
            if (translatedText) {
              option.textContent = translatedText;
            }
          });
        }
      });
    }

    /**
         * 重新渲染表格
         */
    function rerenderTables () {
      const tables = document.querySelectorAll('table');
      tables.forEach((table) => {
        // 重新渲染表头
        const headers = table.querySelectorAll('th[data-i18n]');
        headers.forEach((header) => {
          const translatedText = getTranslation(header.dataset.i18n);
          if (translatedText) {
            header.textContent = translatedText;
          }
        });

        // 重新渲染表格中的操作按钮
        const actionButtons = table.querySelectorAll('button[data-i18n], .btn[data-i18n]');
        actionButtons.forEach((button) => {
          const translatedText = getTranslation(button.dataset.i18n);
          if (translatedText) {
            button.textContent = translatedText;
          }
        });

        // 重新渲染状态标签
        const statusBadges = table.querySelectorAll('.status-badge[data-i18n]');
        statusBadges.forEach((badge) => {
          const translatedText = getTranslation(badge.dataset.i18n);
          if (translatedText) {
            badge.textContent = translatedText;
          }
        });
      });

      // 重新渲染数据表格（如果有使用DataTables或类似插件）
      rerenderDataTables();
    }

    /**
         * 重新渲染数据表格
         */
    function rerenderDataTables () {
      // 如果使用了DataTables插件
      if (window.$ && window.$.fn && window.$.fn.DataTable) {
        const dataTables = window.$('table.dataTable');
        if (dataTables.length > 0) {
          dataTables.each(function () {
            const dataTable = window.$(this).DataTable();

            // 重新设置语言
            const currentLang = localStorage.getItem('language') || 'zh-CN';
            const languageUrl = currentLang === 'zh-CN'
              ? '//cdn.datatables.net/plug-ins/1.10.24/i18n/Chinese.json'
              : '//cdn.datatables.net/plug-ins/1.10.24/i18n/English.json';

            dataTable.settings()[0].oLanguage.sUrl = languageUrl;
            dataTable.draw();
          });
        }
      }
    }

    /**
         * 重新渲染模态框
         */
    function rerenderModals () {
      const modals = document.querySelectorAll('.modal, .modal-dialog');
      modals.forEach((modal) => {
        // 模态框标题
        const titles = modal.querySelectorAll('.modal-title[data-i18n], .modal-header h3[data-i18n], .modal-header h4[data-i18n]');
        titles.forEach((title) => {
          const translatedText = getTranslation(title.dataset.i18n);
          if (translatedText) {
            title.textContent = translatedText;
          }
        });

        // 模态框内容
        const contentElements = modal.querySelectorAll('[data-i18n]');
        contentElements.forEach((element) => {
          if (element.tagName !== 'INPUT' && element.tagName !== 'TEXTAREA' && element.tagName !== 'SELECT') {
            const translatedText = getTranslation(element.dataset.i18n);
            if (translatedText) {
              element.textContent = translatedText;
            }
          }
        });

        // 模态框按钮
        const modalButtons = modal.querySelectorAll('.modal-footer button[data-i18n]');
        modalButtons.forEach((button) => {
          const translatedText = getTranslation(button.dataset.i18n);
          if (translatedText) {
            button.textContent = translatedText;
          }
        });

        // 表单元素
        const modalInputs = modal.querySelectorAll('input[data-i18n-placeholder], textarea[data-i18n-placeholder]');
        modalInputs.forEach((input) => {
          const translatedPlaceholder = getTranslation(input.dataset.i18nPlaceholder);
          if (translatedPlaceholder) {
            input.placeholder = translatedPlaceholder;
          }
        });
      });
    }

    /**
         * 重新渲染图表
         */
    function rerenderCharts () {
      // Chart.js 图表
      if (window.Chart) {
        const charts = Chart.instances;
        Object.values(charts).forEach((chart) => {
          // 更新图表标题
          if (chart.options.plugins && chart.options.plugins.title) {
            const titleKey = chart.options.plugins.title.i18nKey;
            if (titleKey) {
              const translatedTitle = getTranslation(titleKey);
              if (translatedTitle) {
                chart.options.plugins.title.text = translatedTitle;
              }
            }
          }

          // 更新图例
          if (chart.options.plugins && chart.options.plugins.legend) {
            const legendLabels = chart.options.plugins.legend.labels;
            if (legendLabels && legendLabels.i18nKeys) {
              legendLabels.i18nKeys.forEach((key, index) => {
                const translatedLabel = getTranslation(key);
                if (translatedLabel && legendLabels.generateLabels) {
                  // 更新图例标签
                  if (chart.data.labels && chart.data.labels[index]) {
                    chart.data.labels[index] = translatedLabel;
                  }
                }
              });
            }
          }

          // 重新渲染图表
          chart.update();
        });
      }
    }

    /**
         * 重新绑定事件处理器
         */
    function rebindEventHandlers () {
      // 重新绑定工具提示
      rebindTooltips();

      // 重新绑定确认对话框
      rebindConfirmDialogs();

      // 重新绑定表单验证
      rebindFormValidation();

      // 重新绑定快捷键
      rebindKeyboardShortcuts();
    }

    /**
         * 重新绑定工具提示
         */
    function rebindTooltips () {
      // 销毁现有工具提示
      const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
      tooltips.forEach((tooltip) => {
        if (window.bootstrap && window.bootstrap.Tooltip) {
          const tooltipInstance = bootstrap.Tooltip.getInstance(tooltip);
          if (tooltipInstance) {
            tooltipInstance.dispose();
          }
        }
      });

      // 重新初始化工具提示
      tooltips.forEach((tooltip) => {
        const titleKey = tooltip.dataset.bsTitle || tooltip.title;
        if (titleKey && titleKey.startsWith('t(')) {
          const key = titleKey.replace('t(', '').replace(')', '').replace(/['"]/g, '');
          const translatedTitle = getTranslation(key);
          if (translatedTitle) {
            tooltip.setAttribute('data-bs-title', translatedTitle);
            tooltip.removeAttribute('title');
          }
        }

        if (window.bootstrap && window.bootstrap.Tooltip) {
          new bootstrap.Tooltip(tooltip);
        }
      });
    }

    /**
         * 重新绑定确认对话框
         */
    function rebindConfirmDialogs () {
      const confirmButtons = document.querySelectorAll('[data-confirm]');
      confirmButtons.forEach((button) => {
        const confirmKey = button.dataset.confirm;
        if (confirmKey && confirmKey.startsWith('t(')) {
          const key = confirmKey.replace('t(', '').replace(')', '').replace(/['"]/g, '');
          const translatedMessage = getTranslation(key);
          if (translatedMessage) {
            button.dataset.confirm = translatedMessage;
          }
        }
      });
    }

    /**
         * 重新绑定表单验证
         */
    function rebindFormValidation () {
      const forms = document.querySelectorAll('form[data-validate]');
      forms.forEach((form) => {
        // 重新设置验证消息
        const inputs = form.querySelectorAll('input[data-validation], select[data-validation], textarea[data-validation]');
        inputs.forEach((input) => {
          const validationKey = input.dataset.validation;
          if (validationKey && validationKey.startsWith('t(')) {
            const key = validationKey.replace('t(', '').replace(')', '').replace(/['"]/g, '');
            const translatedMessage = getTranslation(key);
            if (translatedMessage) {
              input.dataset.validation = translatedMessage;
            }
          }
        });
      });
    }

    /**
         * 重新绑定快捷键
         */
    function rebindKeyboardShortcuts () {
      // 重新绑定快捷键提示
      const shortcutElements = document.querySelectorAll('[data-shortcut]');
      shortcutElements.forEach((element) => {
        const shortcutKey = element.dataset.shortcut;
        if (shortcutKey && element.title) {
          const translatedTitle = getTranslation(element.title.replace(/^.*:/, '').trim());
          if (translatedTitle) {
            element.title = `${shortcutKey}: ${translatedTitle}`;
          }
        }
      });
    }

    /**
         * 更新页面标题
         */
    function updatePageTitle () {
      const titleElement = document.querySelector('title');
      if (titleElement && titleElement.dataset.i18n) {
        const translatedTitle = getTranslation(titleElement.dataset.i18n);
        if (translatedTitle) {
          titleElement.textContent = translatedTitle;
          document.title = translatedTitle;
        }
      }
    }

    /**
         * 获取翻译文本的辅助函数
         */
    function getTranslation (key) {
      // 尝试使用全局翻译函数
      if (window.t && typeof window.t === 'function') {
        return window.t(key);
      }

      // 尝试从localStorage获取翻译
      try {
        const translations = JSON.parse(localStorage.getItem('translations') || '{}');
        return translations[key] || key;
      } catch (e) {
        return key;
      }
    }

    // 初始化增强的快捷键系统
    initEnhancedKeyboardShortcuts();

    // 暴露到全局作用域
    window.dataLoader = dataLoader;

    console.log('数据加载管理器初始化成功');
  } catch (error) {
    console.error('数据加载管理器初始化失败:', error);

    // 创建备用实例
    window.dataLoader = {
      get: () => Promise.reject(new Error('数据加载管理器未正确初始化')),
      post: () => Promise.reject(new Error('数据加载管理器未正确初始化')),
      put: () => Promise.reject(new Error('数据加载管理器未正确初始化')),
      delete: () => Promise.reject(new Error('数据加载管理器未正确初始化')),
      setLanguage: () => {},
    };
  }
});

/**
 * 初始化增强的快捷键系统
 */
function initEnhancedKeyboardShortcuts () {
  // 快捷键配置
  const shortcuts = {
    // 全局快捷键
    global: {
      // 导航相关
      'Ctrl+Shift+H': { action: 'home', description: '返回首页' },
      'Ctrl+Shift+D': { action: 'dashboard', description: '打开仪表板' },
      'Ctrl+Shift+C': { action: 'cards', description: '卡片管理' },
      'Ctrl+Shift+O': { action: 'orders', description: '订单管理' },
      'Ctrl+Shift+S': { action: 'security', description: '安全中心' },
      'Ctrl+Shift+M': { action: 'monitoring', description: '监控中心' },
      'Ctrl+Shift+P': { action: 'permission', description: '权限管理' },
      'Ctrl+Shift+L': { action: 'compliance', description: '合规管理' },

      // 操作相关
      'Ctrl+Alt+R': { action: 'refresh', description: '刷新当前页面' },
      'Ctrl+Alt+F': { action: 'search', description: '全局搜索' },
      'Ctrl+Alt+N': { action: 'new', description: '新建' },
      'Ctrl+Alt+E': { action: 'edit', description: '编辑' },
      'Ctrl+Alt+D': { action: 'delete', description: '删除' },
      'Ctrl+Alt+V': { action: 'view', description: '查看详情' },

      // 工具相关
      'Ctrl+Alt+T': { action: 'theme', description: '切换主题' },
      'Ctrl+Alt+L': { action: 'language', description: '切换语言' },
      'Ctrl+Alt+H': { action: 'help', description: '显示帮助' },
      'Ctrl+Alt+K': { action: 'shortcuts', description: '显示快捷键列表' },

      // 系统相关
      F11: { action: 'fullscreen', description: '全屏切换' },
      'Ctrl+Shift+I': { action: 'export', description: '导出数据' },
      'Ctrl+Shift+P': { action: 'print', description: '打印页面' },
      'Ctrl+;': { action: 'console', description: '打开控制台' },
    },

    // 模态框快捷键
    modal: {
      Enter: { action: 'confirm', description: '确认' },
      Escape: { action: 'cancel', description: '取消' },
      'Ctrl+Enter': { action: 'save', description: '保存' },
      'Ctrl+Shift+Enter': { action: 'saveAndNew', description: '保存并新建' },
    },

    // 表格快捷键
    table: {
      ArrowUp: { action: 'selectPrevious', description: '选择上一行' },
      ArrowDown: { action: 'selectNext', description: '选择下一行' },
      Space: { action: 'toggleSelection', description: '切换选择' },
      Enter: { action: 'viewDetails', description: '查看详情' },
      Delete: { action: 'deleteSelected', description: '删除选中项' },
      'Ctrl+A': { action: 'selectAll', description: '全选' },
      'Ctrl+F': { action: 'filter', description: '过滤' },
    },

    // 表单快捷键
    form: {
      Tab: { action: 'nextField', description: '下一个字段' },
      'Shift+Tab': { action: 'previousField', description: '上一个字段' },
      'Ctrl+Enter': { action: 'submit', description: '提交表单' },
      'Ctrl+R': { action: 'reset', description: '重置表单' },
      'Ctrl+S': { action: 'save', description: '保存' },
    },
  };

  // 快捷键状态
  const shortcutState = {
    enabled: true,
    context: 'global',
    activeElement: null,
    modifiers: {},
  };

  // 绑定键盘事件
  function bindKeyboardEvents () {
    document.addEventListener('keydown', (e) => {
      if (!shortcutState.enabled) return;

      // 忽略在输入框中的某些快捷键
      if (isInputElement(e.target) && shouldIgnoreInInput(e)) {
        return;
      }

      const keyCombo = getKeyCombo(e);
      const context = getCurrentContext();
      const contextShortcuts = shortcuts[context] || {};

      if (contextShortcuts[keyCombo]) {
        e.preventDefault();
        executeShortcut(contextShortcuts[keyCombo], e);
      }
    });

    // 监听焦点变化以更新上下文
    document.addEventListener('focusin', (e) => {
      shortcutState.activeElement = e.target;
      updateContext();
    });

    document.addEventListener('focusout', (e) => {
      shortcutState.activeElement = null;
      updateContext();
    });
  }

  // 获取按键组合
  function getKeyCombo (e) {
    const parts = [];

    if (e.ctrlKey) parts.push('Ctrl');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    if (e.metaKey) parts.push('Meta');

    let key = e.key;

    // 特殊键处理
    const specialKeys = {
      ' ': 'Space',
      ArrowUp: 'ArrowUp',
      ArrowDown: 'ArrowDown',
      ArrowLeft: 'ArrowLeft',
      ArrowRight: 'ArrowRight',
      Escape: 'Escape',
      Enter: 'Enter',
      Tab: 'Tab',
      Delete: 'Delete',
    };

    if (specialKeys[key]) {
      key = specialKeys[key];
    } else if (key.length === 1) {
      key = key.toUpperCase();
    }

    parts.push(key);

    return parts.join('+');
  }

  // 获取当前上下文
  function getCurrentContext () {
    const activeElement = shortcutState.activeElement;

    if (!activeElement) {
      // 检查是否有打开的模态框
      const openModal = document.querySelector('.modal.show');
      if (openModal) return 'modal';

      // 检查是否在表格中
      const focusedTable = document.querySelector('table:focus-within');
      if (focusedTable) return 'table';

      return 'global';
    }

    // 检查是否在表单中
    const form = activeElement.closest('form');
    if (form) return 'form';

    // 检查是否在表格中
    const table = activeElement.closest('table');
    if (table) return 'table';

    // 检查是否在模态框中
    const modal = activeElement.closest('.modal');
    if (modal) return 'modal';

    return 'global';
  }

  // 更新上下文
  function updateContext () {
    shortcutState.context = getCurrentContext();
  }

  // 判断是否为输入元素
  function isInputElement (element) {
    const inputTags = ['INPUT', 'TEXTAREA', 'SELECT'];
    const contentEditable = element.contentEditable === 'true';

    return inputTags.includes(element.tagName) || contentEditable;
  }

  // 判断是否应该在输入框中忽略快捷键
  function shouldIgnoreInInput (e) {
    const key = e.key;
    const ignoreKeys = [
      'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
      'Home', 'End', 'PageUp', 'PageDown',
    ];

    // 在输入框中忽略导航键，但保留功能键
    return ignoreKeys.includes(key) && !e.ctrlKey && !e.altKey;
  }

  // 执行快捷键动作
  function executeShortcut (shortcut, event) {
    const { action, description } = shortcut;

    console.log(`Executing shortcut: ${action} - ${description}`);

    try {
      switch (action) {
      // 导航相关
      case 'home':
        navigateTo('index.php');
        break;
      case 'dashboard':
        navigateTo('dashboard.php');
        break;
      case 'cards':
        navigateTo('cards.php');
        break;
      case 'orders':
        navigateTo('orders.php');
        break;
      case 'security':
        navigateTo('security.php');
        break;
      case 'monitoring':
        navigateTo('monitoring.php');
        break;
      case 'permission':
        navigateTo('permission.php');
        break;
      case 'compliance':
        navigateTo('compliance.php');
        break;

        // 操作相关
      case 'refresh':
        refreshCurrentPage();
        break;
      case 'search':
        focusGlobalSearch();
        break;
      case 'new':
        clickNewButton();
        break;
      case 'edit':
        clickEditButton();
        break;
      case 'delete':
        clickDeleteButton();
        break;
      case 'view':
        clickViewButton();
        break;

        // 工具相关
      case 'theme':
        toggleTheme();
        break;
      case 'language':
        toggleLanguage();
        break;
      case 'help':
        showHelp();
        break;
      case 'shortcuts':
        showShortcutHelp();
        break;

        // 系统相关
      case 'fullscreen':
        toggleFullscreen();
        break;
      case 'export':
        exportData();
        break;
      case 'print':
        printPage();
        break;
      case 'console':
        toggleConsole();
        break;

        // 模态框相关
      case 'confirm':
        confirmModal();
        break;
      case 'cancel':
        cancelModal();
        break;
      case 'save':
        saveModal();
        break;
      case 'saveAndNew':
        saveAndNewModal();
        break;

        // 表格相关
      case 'selectPrevious':
        selectPreviousRow();
        break;
      case 'selectNext':
        selectNextRow();
        break;
      case 'toggleSelection':
        toggleRowSelection();
        break;
      case 'viewDetails':
        viewRowDetails();
        break;
      case 'deleteSelected':
        deleteSelectedRows();
        break;
      case 'selectAll':
        selectAllRows();
        break;
      case 'filter':
        focusTableFilter();
        break;

        // 表单相关
      case 'nextField':
        focusNextField();
        break;
      case 'previousField':
        focusPreviousField();
        break;
      case 'submit':
        submitForm();
        break;
      case 'reset':
        resetForm();
        break;

      default:
        console.warn(`Unknown shortcut action: ${action}`);
      }
    } catch (error) {
      console.error(`Error executing shortcut ${action}:`, error);
      if (window.showToast) {
        showToast(`快捷键执行失败: ${description}`, 'error');
      }
    }
  }

  // 快捷键动作实现函数
  function navigateTo (url) {
    window.location.href = url;
  }

  function refreshCurrentPage () {
    window.location.reload();
  }

  function focusGlobalSearch () {
    const searchInput = document.querySelector('#global-search, .search-input, input[type="search"]');
    if (searchInput) {
      searchInput.focus();
    }
  }

  function clickNewButton () {
    const newButton = document.querySelector('.btn-new, .btn-add, button[data-action="new"]');
    if (newButton) {
      newButton.click();
    }
  }

  function clickEditButton () {
    const editButton = document.querySelector('.btn-edit, button[data-action="edit"]');
    if (editButton) {
      editButton.click();
    }
  }

  function clickDeleteButton () {
    const deleteButton = document.querySelector('.btn-delete, button[data-action="delete"]');
    if (deleteButton) {
      deleteButton.click();
    }
  }

  function clickViewButton () {
    const viewButton = document.querySelector('.btn-view, button[data-action="view"]');
    if (viewButton) {
      viewButton.click();
    }
  }

  function toggleTheme () {
    // 实现主题切换逻辑
    document.body.classList.toggle('dark-theme');
  }

  function toggleLanguage () {
    // 实现语言切换逻辑
    const currentLang = localStorage.getItem('language') || 'zh-CN';
    const newLang = currentLang === 'zh-CN' ? 'en-US' : 'zh-CN';

    // 触发语言切换事件
    const event = new CustomEvent('languageChanged', {
      detail: { language: newLang },
    });
    window.dispatchEvent(event);
  }

  function showHelp () {
    // 实现帮助显示逻辑
    if (window.showToast) {
      showToast('帮助功能开发中...', 'info');
    }
  }

  function showShortcutHelp () {
    // 创建快捷键帮助面板
    const helpPanel = document.createElement('div');
    helpPanel.id = 'shortcut-help-panel';
    helpPanel.className = 'modal fade';
    helpPanel.setAttribute('tabindex', '-1');
    helpPanel.setAttribute('aria-hidden', 'true');

    helpPanel.innerHTML = `
             <div class="modal-dialog modal-lg modal-dialog-centered">
                 <div class="modal-content">
                     <div class="modal-header">
                         <h5 class="modal-title">
                             <i class="fas fa-keyboard me-2"></i>
                             快捷键列表
                         </h5>
                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                     </div>
                     <div class="modal-body">
                         <div class="row">
                             <div class="col-md-6">
                                 <h6 class="text-primary mb-3">
                                     <i class="fas fa-compass me-2"></i>导航快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.global)
    .filter(([key, shortcut]) => ['home', 'dashboard', 'cards', 'orders', 'security', 'monitoring', 'permission', 'compliance'].includes(shortcut.action))
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                             <div class="col-md-6">
                                 <h6 class="text-success mb-3">
                                     <i class="fas fa-tools me-2"></i>操作快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.global)
    .filter(([key, shortcut]) => ['refresh', 'search', 'new', 'edit', 'delete', 'view'].includes(shortcut.action))
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                         </div>
                         <div class="row mt-4">
                             <div class="col-md-6">
                                 <h6 class="text-warning mb-3">
                                     <i class="fas fa-cog me-2"></i>工具快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.global)
    .filter(([key, shortcut]) => ['theme', 'language', 'help', 'shortcuts'].includes(shortcut.action))
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                             <div class="col-md-6">
                                 <h6 class="text-info mb-3">
                                     <i class="fas fa-desktop me-2"></i>系统快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.global)
    .filter(([key, shortcut]) => ['fullscreen', 'export', 'print', 'console'].includes(shortcut.action))
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                         </div>
                         <div class="row mt-4">
                             <div class="col-md-4">
                                 <h6 class="text-secondary mb-3">
                                     <i class="fas fa-window-restore me-2"></i>模态框快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.modal)
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                             <div class="col-md-4">
                                 <h6 class="text-secondary mb-3">
                                     <i class="fas fa-table me-2"></i>表格快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.table)
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                             <div class="col-md-4">
                                 <h6 class="text-secondary mb-3">
                                     <i class="fas fa-edit me-2"></i>表单快捷键
                                 </h6>
                                 <div class="shortcut-list">
                                     ${Object.entries(shortcuts.form)
    .map(([key, shortcut]) => `
                                             <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                                 <span>${shortcut.description}</span>
                                                 <kbd class="bg-light px-2 py-1 rounded">${key}</kbd>
                                             </div>
                                         `).join('')}
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="modal-footer">
                         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                         <button type="button" class="btn btn-primary" onclick="window.print()">
                             <i class="fas fa-print me-2"></i>打印快捷键
                         </button>
                     </div>
                 </div>
             </div>
         `;

    // 添加到页面
    document.body.appendChild(helpPanel);

    // 显示模态框
    const modal = new bootstrap.Modal(helpPanel);
    modal.show();

    // 模态框关闭时移除元素
    helpPanel.addEventListener('hidden.bs.modal', () => {
      document.body.removeChild(helpPanel);
    });
  }

  /**
      * 初始化快捷键提示
      */
  function initShortcutTooltips () {
    // 为有快捷键的按钮添加提示
    const shortcutButtons = {
      '.btn-new, .btn-add': 'Ctrl+Alt+N',
      '.btn-edit': 'Ctrl+Alt+E',
      '.btn-delete': 'Ctrl+Alt+D',
      '.btn-view': 'Ctrl+Alt+V',
      '.btn-refresh': 'Ctrl+Alt+R',
      '.btn-search': 'Ctrl+Alt+F',
      '.btn-save': 'Ctrl+S',
      '.btn-cancel': 'Escape',
    };

    Object.entries(shortcutButtons).forEach(([selector, shortcut]) => {
      const buttons = document.querySelectorAll(selector);
      buttons.forEach((button) => {
        const existingTitle = button.getAttribute('title') || button.textContent.trim();
        button.setAttribute('title', `${existingTitle} (${shortcut})`);

        // 初始化Bootstrap工具提示
        if (window.bootstrap && window.bootstrap.Tooltip) {
          new bootstrap.Tooltip(button);
        }
      });
    });
  }

  /**
      * 创建快捷键状态指示器
      */
  function createShortcutIndicator () {
    const indicator = document.createElement('div');
    indicator.id = 'shortcut-indicator';
    indicator.className = 'position-fixed bottom-0 end-0 p-3';
    indicator.style.zIndex = '9999';
    indicator.style.display = 'none';

    indicator.innerHTML = `
             <div class="toast align-items-center text-white bg-primary border-0" role="alert">
                 <div class="d-flex">
                     <div class="toast-body">
                         <span id="shortcut-message"></span>
                     </div>
                     <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                 </div>
             </div>
         `;

    document.body.appendChild(indicator);

    // 暴露显示快捷键消息的方法
    window.showShortcutMessage = (message, type = 'primary') => {
      const toast = indicator.querySelector('.toast');
      const messageElement = document.getElementById('shortcut-message');

      // 设置样式
      toast.className = `toast align-items-center text-white bg-${type} border-0`;
      messageElement.textContent = message;

      // 显示
      indicator.style.display = 'block';
      const bsToast = new bootstrap.Toast(toast);
      bsToast.show();

      // 自动隐藏
      setTimeout(() => {
        indicator.style.display = 'none';
      }, 3000);
    };
  }

  /**
      * 显示快捷键状态
      */
  function showShortcutStatus (key, action) {
    if (window.showShortcutMessage) {
      window.showShortcutStatus(`快捷键 ${key}: ${action}`, 'info');
    }
  }

  /**
      * 创建快捷键冲突检测
      */
  function detectShortcutConflicts () {
    const browserShortcuts = [
      'Ctrl+S', 'Ctrl+N', 'Ctrl+O', 'Ctrl+P', 'Ctrl+F', 'Ctrl+H',
      'Ctrl+R', 'Ctrl+T', 'Ctrl+W', 'Ctrl+Tab', 'Ctrl+Shift+Tab',
      'F5', 'F11', 'F12',
    ];

    const conflicts = [];

    Object.keys(shortcuts.global).forEach((key) => {
      if (browserShortcuts.includes(key)) {
        conflicts.push({
          key,
          action: shortcuts.global[key].action,
          type: 'browser',
        });
      }
    });

    if (conflicts.length > 0) {
      console.warn('检测到快捷键冲突:', conflicts);
    }

    return conflicts;
  }

  function toggleFullscreen () {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  }

  function exportData () {
    // 实现数据导出逻辑
    if (window.showToast) {
      showToast('导出功能开发中...', 'info');
    }
  }

  function printPage () {
    window.print();
  }

  function toggleConsole () {
    // 切换开发者工具
    if (typeof console !== 'undefined') {
      console.clear();
      console.log('控制台已清空');
    }
  }

  function confirmModal () {
    const confirmButton = document.querySelector('.modal.show .btn-confirm, .modal.show .btn-primary');
    if (confirmButton) {
      confirmButton.click();
    }
  }

  function cancelModal () {
    const cancelButton = document.querySelector('.modal.show .btn-cancel, .modal.show .btn-secondary');
    if (cancelButton) {
      cancelButton.click();
    }
  }

  function saveModal () {
    const saveButton = document.querySelector('.modal.show .btn-save');
    if (saveButton) {
      saveButton.click();
    }
  }

  function saveAndNewModal () {
    // 实现保存并新建逻辑
    if (window.showToast) {
      showToast('保存并新建功能开发中...', 'info');
    }
  }

  function selectPreviousRow () {
    // 实现选择上一行逻辑
    if (window.showToast) {
      showToast('选择上一行功能开发中...', 'info');
    }
  }

  function selectNextRow () {
    // 实现选择下一行逻辑
    if (window.showToast) {
      showToast('选择下一行功能开发中...', 'info');
    }
  }

  function toggleRowSelection () {
    // 实现切换行选择逻辑
    if (window.showToast) {
      showToast('切换选择功能开发中...', 'info');
    }
  }

  function viewRowDetails () {
    // 实现查看行详情逻辑
    if (window.showToast) {
      showToast('查看详情功能开发中...', 'info');
    }
  }

  function deleteSelectedRows () {
    // 实现删除选中行逻辑
    if (window.showToast) {
      showToast('删除选中项功能开发中...', 'info');
    }
  }

  function selectAllRows () {
    // 实现全选逻辑
    if (window.showToast) {
      showToast('全选功能开发中...', 'info');
    }
  }

  function focusTableFilter () {
    const filterInput = document.querySelector('table input[type="search"], .dataTables_filter input');
    if (filterInput) {
      filterInput.focus();
    }
  }

  function focusNextField () {
    // 实现聚焦下一个字段逻辑
    const activeElement = document.activeElement;
    if (activeElement && activeElement.form) {
      const formElements = Array.from(activeElement.form.elements);
      const currentIndex = formElements.indexOf(activeElement);
      if (currentIndex < formElements.length - 1) {
        formElements[currentIndex + 1].focus();
      }
    }
  }

  function focusPreviousField () {
    // 实现聚焦上一个字段逻辑
    const activeElement = document.activeElement;
    if (activeElement && activeElement.form) {
      const formElements = Array.from(activeElement.form.elements);
      const currentIndex = formElements.indexOf(activeElement);
      if (currentIndex > 0) {
        formElements[currentIndex - 1].focus();
      }
    }
  }

  function submitForm () {
    const activeElement = document.activeElement;
    if (activeElement && activeElement.form) {
      activeElement.form.submit();
    }
  }

  function resetForm () {
    const activeElement = document.activeElement;
    if (activeElement && activeElement.form) {
      activeElement.form.reset();
    }
  }

  // 初始化快捷键系统
  bindKeyboardEvents();

  // 初始化快捷键提示
  initShortcutTooltips();

  // 创建快捷键状态指示器
  createShortcutIndicator();

  // 检测快捷键冲突
  detectShortcutConflicts();

  // 暴露到全局
  window.keyboardShortcuts = {
    enable: () => {
      shortcutState.enabled = true;
    },
    disable: () => {
      shortcutState.enabled = false;
    },
    toggle: () => {
      shortcutState.enabled = !shortcutState.enabled;
    },
    getShortcuts: () => shortcuts,
    getCurrentContext: () => shortcutState.context,
  };

  console.log('增强快捷键系统初始化成功');
}

/**
 * 图表数据联动和导出管理器
 */
const ChartDataManager = {
  charts: {},
  dataCache: {},
  updateCallbacks: [],

  /**
     * 注册图表
     */
  registerChart (chartId, chartInstance, dataSource) {
    this.charts[chartId] = {
      instance: chartInstance,
      dataSource,
      lastUpdate: null,
    };
  },

  /**
     * 更新所有图表数据
     */
  async updateAllCharts () {
    const updatePromises = Object.keys(this.charts).map(async (chartId) => {
      try {
        const chart = this.charts[chartId];
        const newData = await this.fetchChartData(chart.dataSource);

        if (newData) {
          this.updateChart(chartId, newData);
          chart.lastUpdate = new Date();
        }
      } catch (error) {
        console.error(`更新图表 ${chartId} 失败:`, error);
      }
    });

    await Promise.all(updatePromises);

    // 触发更新回调
    this.updateCallbacks.forEach((callback) => callback());
  },

  /**
     * 获取图表数据
     */
  async fetchChartData (dataSource) {
    try {
      const response = await dataLoader.fetchData(dataSource);
      return response.data;
    } catch (error) {
      console.error('获取图表数据失败:', error);
      return null;
    }
  },

  /**
     * 更新单个图表
     */
  updateChart (chartId, newData) {
    const chart = this.charts[chartId];
    if (!chart || !chart.instance) return;

    const instance = chart.instance;

    // 更新数据
    if (newData.labels) {
      instance.data.labels = newData.labels;
    }

    if (newData.datasets) {
      instance.data.datasets = newData.datasets;
    }

    // 重新渲染
    instance.update('active');

    // 缓存数据
    this.dataCache[chartId] = newData;
  },

  /**
     * 图表数据联动
     */
  linkCharts (chartIds, linkType = 'filter') {
    chartIds.forEach((chartId) => {
      const chart = this.charts[chartId];
      if (!chart || !chart.instance) return;

      const instance = chart.instance;

      // 添加点击事件
      instance.options.onClick = (event, elements) => {
        if (elements.length > 0) {
          const element = elements[0];
          const datasetIndex = element.datasetIndex;
          const index = element.index;

          const clickedData = {
            chartId,
            datasetIndex,
            index,
            label: instance.data.labels[index],
            value: instance.data.datasets[datasetIndex].data[index],
          };

          this.handleChartLink(clickedData, chartIds, linkType);
        }
      };
    });
  },

  /**
     * 处理图表联动
     */
  handleChartLink (clickedData, linkedCharts, linkType) {
    linkedCharts.forEach((linkedChartId) => {
      if (linkedChartId === clickedData.chartId) return;

      const linkedChart = this.charts[linkedChartId];
      if (!linkedChart || !linkedChart.instance) return;

      switch (linkType) {
      case 'filter':
        this.filterLinkedChart(linkedChartId, clickedData);
        break;
      case 'highlight':
        this.highlightLinkedChart(linkedChartId, clickedData);
        break;
      case 'drilldown':
        this.drilldownChart(linkedChartId, clickedData);
        break;
      }
    });
  },

  /**
     * 过滤关联图表
     */
  filterLinkedChart (chartId, filterData) {
    const chart = this.charts[chartId];
    if (!chart || !chart.instance) return;

    const instance = chart.instance;
    const cachedData = this.dataCache[chartId];

    if (!cachedData) return;

    // 根据过滤条件筛选数据
    const filteredData = this.filterData(cachedData, filterData);

    // 更新图表
    this.updateChart(chartId, filteredData);

    // 显示过滤提示
    this.showFilterHint(chartId, filterData);
  },

  /**
     * 高亮关联图表
     */
  highlightLinkedChart (chartId, highlightData) {
    const chart = this.charts[chartId];
    if (!chart || !chart.instance) return;

    const instance = chart.instance;

    // 重置所有透明度
    instance.data.datasets.forEach((dataset) => {
      dataset.backgroundColor = dataset.backgroundColor.map((color) =>
        typeof color === 'string' ? color : color.map((c) => c * 0.3),
      );
    });

    // 高亮相关数据
    const relatedIndex = this.findRelatedIndex(instance.data, highlightData);
    if (relatedIndex !== -1) {
      instance.data.datasets.forEach((dataset) => {
        if (Array.isArray(dataset.backgroundColor)) {
          dataset.backgroundColor[relatedIndex] =
                        typeof dataset.backgroundColor[relatedIndex] === 'string'
                          ? dataset.backgroundColor[relatedIndex]
                          : dataset.backgroundColor[relatedIndex].map((c) => Math.min(c * 2, 255));
        }
      });
    }

    instance.update('active');
  },

  /**
     * 图表下钻
     */
  drilldownChart (chartId, drilldownData) {
    const chart = this.charts[chartId];
    if (!chart || !chart.instance) return;

    // 获取下钻数据
    this.fetchDrilldownData(chartId, drilldownData).then((drilldownResponse) => {
      if (drilldownResponse) {
        this.updateChart(chartId, drilldownResponse);

        // 添加返回按钮
        this.addBackButton(chartId);
      }
    });
  },

  /**
     * 获取下钻数据
     */
  async fetchDrilldownData (chartId, drilldownData) {
    try {
      const dataSource = `${this.charts[chartId].dataSource}&drilldown=${encodeURIComponent(drilldownData.label)}`;
      return await this.fetchChartData(dataSource);
    } catch (error) {
      console.error('获取下钻数据失败:', error);
      return null;
    }
  },

  /**
     * 添加返回按钮
     */
  addBackButton (chartId) {
    const chartContainer = document.getElementById(chartId).closest('.chart-card');
    if (!chartContainer) return;

    // 检查是否已有返回按钮
    if (chartContainer.querySelector('.back-button')) return;

    const backButton = document.createElement('button');
    backButton.className = 'btn btn-sm btn-secondary back-button';
    backButton.innerHTML = '<i class="fas fa-arrow-left me-1"></i>返回';
    backButton.style.marginLeft = '10px';

    backButton.addEventListener('click', () => {
      this.restoreOriginalData(chartId);
      backButton.remove();
    });

    const header = chartContainer.querySelector('.chart-header');
    if (header) {
      header.appendChild(backButton);
    }
  },

  /**
     * 恢复原始数据
     */
  restoreOriginalData (chartId) {
    const originalData = this.dataCache[chartId + '_original'];
    if (originalData) {
      this.updateChart(chartId, originalData);
    }
  },

  /**
     * 导出图表数据
     */
  exportChart (chartId, format = 'png') {
    const chart = this.charts[chartId];
    if (!chart || !chart.instance) return;

    switch (format) {
    case 'png':
      this.exportChartAsImage(chartId);
      break;
    case 'csv':
      this.exportChartAsCSV(chartId);
      break;
    case 'json':
      this.exportChartAsJSON(chartId);
      break;
    case 'pdf':
      this.exportChartAsPDF(chartId);
      break;
    }
  },

  /**
     * 导出为图片
     */
  exportChartAsImage (chartId) {
    const chart = this.charts[chartId];
    const url = chart.instance.toBase64Image();

    const link = document.createElement('a');
    link.download = `${chartId}_${new Date().toLocaleDateString()}.png`;
    link.href = url;
    link.click();

    this.showExportNotification('图表已导出为PNG图片', 'success');
  },

  /**
     * 导出为CSV
     */
  exportChartAsCSV (chartId) {
    const chart = this.charts[chartId];
    const data = this.dataCache[chartId] || chart.instance.data;

    let csvContent = '';

    // 添加标题
    csvContent += `${chartId} 数据导出\n`;
    csvContent += `导出时间: ${new Date().toLocaleString()}\n\n`;

    // 添加数据
    if (data.labels && data.datasets) {
      csvContent += '日期,' + data.datasets.map((d) => d.label).join(',') + '\n';

      data.labels.forEach((label, index) => {
        const row = [label];
        data.datasets.forEach((dataset) => {
          row.push(dataset.data[index] || 0);
        });
        csvContent += row.join(',') + '\n';
      });
    }

    // 创建下载
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${chartId}_${new Date().toLocaleDateString()}.csv`;
    link.click();

    this.showExportNotification('图表数据已导出为CSV文件', 'success');
  },

  /**
     * 导出为JSON
     */
  exportChartAsJSON (chartId) {
    const chart = this.charts[chartId];
    const exportData = {
      chartId,
      exportTime: new Date().toISOString(),
      data: this.dataCache[chartId] || chart.instance.data,
      options: chart.instance.options,
    };

    const jsonStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${chartId}_${new Date().toLocaleDateString()}.json`;
    link.click();

    this.showExportNotification('图表数据已导出为JSON文件', 'success');
  },

  /**
     * 导出为PDF（简化版）
     */
  exportChartAsPDF (chartId) {
    // 这里可以使用jsPDF等库来实现完整的PDF导出
    // 现在先导出图片，提示用户手动转换为PDF
    this.exportChartAsImage(chartId);
    this.showExportNotification('图片已导出，可使用工具转换为PDF', 'info');
  },

  /**
     * 批量导出所有图表
     */
  exportAllCharts (format = 'png') {
    Object.keys(this.charts).forEach((chartId) => {
      setTimeout(() => {
        this.exportChart(chartId, format);
      }, 100 * Object.keys(this.charts).indexOf(chartId));
    });
  },

  /**
     * 显示导出通知
     */
  showExportNotification (message, type = 'success') {
    if (window.showToast) {
      showToast(message, type);
    } else {
      console.log(message);
    }
  },

  /**
     * 数据过滤
     */
  filterData (data, filterData) {
    // 实现数据过滤逻辑
    // 这里可以根据实际需求实现不同的过滤策略
    return data;
  },

  /**
     * 查找相关索引
     */
  findRelatedIndex (chartData, highlightData) {
    // 实现查找相关数据的逻辑
    return chartData.labels.indexOf(highlightData.label);
  },

  /**
     * 显示过滤提示
     */
  showFilterHint (chartId, filterData) {
    const chartContainer = document.getElementById(chartId).closest('.chart-card');
    if (!chartContainer) return;

    let hint = chartContainer.querySelector('.filter-hint');
    if (!hint) {
      hint = document.createElement('div');
      hint.className = 'filter-hint alert alert-info alert-sm';
      hint.style.marginTop = '10px';
      chartContainer.appendChild(hint);
    }

    hint.innerHTML = `
            <i class="fas fa-filter me-2"></i>
            当前过滤: ${filterData.label} (${filterData.value})
            <button class="btn btn-sm btn-outline-secondary ms-2" onclick="ChartDataManager.clearFilter('${chartId}')">
                清除过滤
            </button>
        `;
  },

  /**
     * 清除过滤
     */
  clearFilter (chartId) {
    const originalData = this.dataCache[chartId + '_original'] || this.dataCache[chartId];
    if (originalData) {
      this.updateChart(chartId, originalData);
    }

    const chartContainer = document.getElementById(chartId).closest('.chart-card');
    const hint = chartContainer.querySelector('.filter-hint');
    if (hint) {
      hint.remove();
    }
  },

  /**
     * 添加更新回调
     */
  onUpdate (callback) {
    this.updateCallbacks.push(callback);
  },

  /**
     * 初始化图表数据管理器
     */
  init () {
    // 保存原始数据
    Object.keys(this.charts).forEach((chartId) => {
      const chart = this.charts[chartId];
      if (chart.instance && chart.instance.data) {
        this.dataCache[chartId + '_original'] = JSON.parse(JSON.stringify(chart.instance.data));
      }
    });

    console.log('图表数据管理器初始化完成');
  },
};

// 暴露到全局
window.ChartDataManager = ChartDataManager;
function showGlobalLoading () {
  let loadingOverlay = document.getElementById('loading-overlay');

  if (!loadingOverlay) {
    loadingOverlay = document.createElement('div');
    loadingOverlay.id = 'loading-overlay';
    loadingOverlay.className = 'loading-overlay';
    loadingOverlay.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">加载中...</span>
                </div>
                <div class="loading-text mt-2">加载中...</div>
            </div>
        `;

    // 添加样式
    const style = document.createElement('style');
    style.textContent = `
            .loading-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease, visibility 0.3s ease;
            }
            
            .loading-overlay.show {
                opacity: 1;
                visibility: visible;
            }
            
            .loading-spinner {
                text-align: center;
                color: white;
            }
            
            .loading-text {
                font-size: 14px;
                color: white;
            }
        `;
    document.head.appendChild(style);
    document.body.appendChild(loadingOverlay);
  }

  loadingOverlay.classList.add('show');
}

/**
 * 隐藏全局加载状态
 */
function hideGlobalLoading () {
  const loadingOverlay = document.getElementById('loading-overlay');
  if (loadingOverlay) {
    loadingOverlay.classList.remove('show');
  }
}

/**
 * 清理所有待处理的请求
 * 页面卸载时调用
 */
window.addEventListener('beforeunload', function () {
  if (dataLoader && dataLoader.cancelAllRequests) {
    dataLoader.cancelAllRequests('页面正在卸载');
  }
});

/**
 * 网络状态监听
 */
window.addEventListener('online', function () {
  if (dataLoader && dataLoader.retryFailedRequests) {
    dataLoader.retryFailedRequests();
  }
});

window.addEventListener('offline', function () {
  console.log('网络连接已断开');
  if (window.showToast) {
    showToast('网络连接已断开，请检查网络设置', 'warning');
  }
});
