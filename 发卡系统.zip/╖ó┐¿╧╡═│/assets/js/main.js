// 发卡系统主JavaScript文件
//
// Copyright © 2025 远
// 未经授权禁止传播或用于商业用途

// 全局配置
const AppConfig = {
  apiBaseUrl: '/api',
  version: '1.0.0',
  debug: true,
  animation: {
    duration: 300,
    easing: 'ease',
  },
};

// 工具函数
const Utils = {
  // 防抖函数
  debounce (func, wait) {
    let timeout;
    return function executedFunction (...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  // 节流函数
  throttle (func, limit) {
    let inThrottle;
    return function () {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  // 格式化价格
  formatPrice (price) {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
    }).format(price);
  },

  // 格式化日期
  formatDate (date, format = 'YYYY-MM-DD HH:mm:ss') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');

    return format
      .replace('YYYY', year)
      .replace('MM', month)
      .replace('DD', day)
      .replace('HH', hours)
      .replace('mm', minutes)
      .replace('ss', seconds);
  },

  // 生成随机ID
  generateId () {
    return Math.random().toString(36).substr(2, 9);
  },

  // 深拷贝对象
  deepClone (obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj.getTime());
    if (obj instanceof Array) return obj.map((item) => this.deepClone(item));
    if (typeof obj === 'object') {
      const clonedObj = {};
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          clonedObj[key] = this.deepClone(obj[key]);
        }
      }
      return clonedObj;
    }
  },

  // 检查是否为移动设备
  isMobile () {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  },

  // 获取设备类型
  getDeviceType () {
    const width = window.innerWidth;
    if (width < 768) return 'mobile';
    if (width < 1024) return 'tablet';
    return 'desktop';
  },
};

// HTTP请求工具
const Http = {
  // 基础请求方法
  async request (url, options = {}) {
    const defaultOptions = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const config = { ...defaultOptions, ...options };

    try {
      const response = await fetch(AppConfig.apiBaseUrl + url, config);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Request failed:', error);
      throw error;
    }
  },

  // GET请求
  async get (url, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const fullUrl = queryString ? `${url}?${queryString}` : url;
    return this.request(fullUrl);
  },

  // POST请求
  async post (url, data = {}) {
    return this.request(url, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // PUT请求
  async put (url, data = {}) {
    return this.request(url, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // DELETE请求
  async delete (url) {
    return this.request(url, {
      method: 'DELETE',
    });
  },
};

// 本地存储工具
const Storage = {
  // 设置本地存储
  set (key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Storage set failed:', error);
    }
  },

  // 获取本地存储
  get (key, defaultValue = null) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error('Storage get failed:', error);
      return defaultValue;
    }
  },

  // 删除本地存储
  remove (key) {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Storage remove failed:', error);
    }
  },

  // 清空本地存储
  clear () {
    try {
      localStorage.clear();
    } catch (error) {
      console.error('Storage clear failed:', error);
    }
  },
};

// 表单验证工具
const Validator = {
  // 验证规则
  rules: {
    required: (value) => value && value.trim() !== '',
    email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
    phone: (value) => /^1[3-9]\d{9}$/.test(value),
    password: (value) => value.length >= 6,
    minLength: (value, min) => value.length >= min,
    maxLength: (value, max) => value.length <= max,
    number: (value) => !isNaN(value) && value.trim() !== '',
    positive: (value) => parseFloat(value) > 0,
  },

  // 验证单个字段
  validateField (value, rules) {
    for (const rule of rules) {
      const [ruleName, ...params] = rule.split(':');
      const ruleFunc = this.rules[ruleName];

      if (ruleFunc && !ruleFunc(value, ...params)) {
        return this.getErrorMessage(ruleName, params);
      }
    }
    return null;
  },

  // 验证整个表单
  validateForm (formData, schema) {
    const errors = {};

    for (const [field, rules] of Object.entries(schema)) {
      const error = this.validateField(formData[field], rules);
      if (error) {
        errors[field] = error;
      }
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors,
    };
  },

  // 获取错误消息
  getErrorMessage (ruleName, params) {
    const messages = {
      required: '此字段为必填项',
      email: '请输入有效的邮箱地址',
      phone: '请输入有效的手机号码',
      password: '密码长度至少6位',
      minLength: `长度至少${params[0]}位`,
      maxLength: `长度不能超过${params[0]}位`,
      number: '请输入有效数字',
      positive: '请输入大于0的数字',
    };

    return messages[ruleName] || '输入格式不正确';
  },
};

// 动画工具
const Animation = {
  // 淡入
  fadeIn (element, duration = AppConfig.animation.duration) {
    element.style.opacity = '0';
    element.style.display = 'block';

    const start = performance.now();

    function animate (currentTime) {
      const elapsed = currentTime - start;
      const progress = Math.min(elapsed / duration, 1);

      element.style.opacity = progress;

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    }

    requestAnimationFrame(animate);
  },

  // 淡出
  fadeOut (element, duration = AppConfig.animation.duration) {
    const start = performance.now();
    const initialOpacity = parseFloat(window.getComputedStyle(element).opacity);

    function animate (currentTime) {
      const elapsed = currentTime - start;
      const progress = Math.min(elapsed / duration, 1);

      element.style.opacity = initialOpacity * (1 - progress);

      if (progress >= 1) {
        element.style.display = 'none';
      } else {
        requestAnimationFrame(animate);
      }
    }

    requestAnimationFrame(animate);
  },

  // 滑动
  slide (element, direction, duration = AppConfig.animation.duration) {
    const start = performance.now();
    const isDown = direction === 'down';
    const maxHeight = element.scrollHeight;

    element.style.overflow = 'hidden';
    element.style.height = isDown ? '0px' : maxHeight + 'px';

    function animate (currentTime) {
      const elapsed = currentTime - start;
      const progress = Math.min(elapsed / duration, 1);

      if (isDown) {
        element.style.height = (maxHeight * progress) + 'px';
      } else {
        element.style.height = (maxHeight * (1 - progress)) + 'px';
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        if (!isDown) {
          element.style.display = 'none';
        }
        element.style.overflow = '';
        element.style.height = '';
      }
    }

    requestAnimationFrame(animate);
  },
};

// 全局事件总线
const EventBus = {
  events: {},

  // 订阅事件
  on (event, callback) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(callback);
  },

  // 取消订阅
  off (event, callback) {
    if (this.events[event]) {
      this.events[event] = this.events[event].filter((cb) => cb !== callback);
    }
  },

  // 发布事件
  emit (event, data) {
    if (this.events[event]) {
      this.events[event].forEach((callback) => callback(data));
    }
  },
};

// 全局初始化
function initApp () {
  // 设置全局错误处理
  window.addEventListener('error', function (e) {
    console.error('Global error:', e.error);
    if (AppConfig.debug) {
      // 在调试模式下显示错误信息
      showGlobalError('系统发生错误，请刷新页面重试');
    }
  });

  // 设置未处理的Promise拒绝
  window.addEventListener('unhandledrejection', function (e) {
    console.error('Unhandled promise rejection:', e.reason);
    if (AppConfig.debug) {
      showGlobalError('请求处理失败，请稍后重试');
    }
  });

  // 初始化主题
  initTheme();

  // 初始化响应式处理
  initResponsive();

  console.log('应用初始化完成');
}

// 显示全局错误
function showGlobalError (message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'global-error';
  errorDiv.textContent = message;
  errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--error-color);
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        z-index: 9999;
        font-size: 14px;
        box-shadow: var(--shadow-lg);
    `;

  document.body.appendChild(errorDiv);

  setTimeout(() => {
    errorDiv.remove();
  }, 5000);
}

// 初始化主题
function initTheme () {
  const savedTheme = Storage.get('theme', 'light');
  document.documentElement.setAttribute('data-theme', savedTheme);
}

// 初始化响应式处理
function initResponsive () {
  const updateDeviceType = Utils.throttle(() => {
    const deviceType = Utils.getDeviceType();
    document.documentElement.setAttribute('data-device', deviceType);
    EventBus.emit('deviceChange', deviceType);
  }, 250);

  window.addEventListener('resize', updateDeviceType);
  updateDeviceType();
}

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', initApp);

// 导出到全局作用域
window.App = {
  Config: AppConfig,
  Utils,
  Http,
  Storage,
  Validator,
  Animation,
  EventBus,
};
