/**
 * 卡密收藏夹交互功能
 * 处理收藏夹的添加、移除和状态显示
 */

class CardFavorites {
  constructor () {
    this.baseUrl = '/api/cards/favorites.php';
    this.isLoggedIn = document.body.dataset.loggedIn === 'true';
  }

  /**
     * 初始化收藏夹功能
     */
  init () {
    if (!this.isLoggedIn) {
      return;
    }

    // 初始化所有收藏按钮
    this.initFavoriteButtons();

    // 如果在收藏夹页面，初始化收藏夹列表
    if (window.location.pathname.includes('favorites')) {
      this.initFavoritesPage();
    }

    // 初始化卡密详情页的收藏功能
    if (window.location.pathname.includes('card-result.html')) {
      this.initCardDetailPage();
    }
  }

  /**
     * 初始化收藏按钮
     */
  initFavoriteButtons () {
    const favoriteButtons = document.querySelectorAll('.favorite-btn');
    favoriteButtons.forEach((button) => {
      const cardId = button.dataset.cardId;
      const cardCode = button.dataset.cardCode;

      // 检查收藏状态
      this.checkFavoriteStatus(cardId, cardCode, button);

      // 添加点击事件
      button.addEventListener('click', () => {
        if (button.classList.contains('favorited')) {
          this.removeFavorite(button.dataset.favoriteId, button);
        } else {
          this.addFavorite({
            card_id: cardId,
            card_code: cardCode,
            product_id: button.dataset.productId,
            product_name: button.dataset.productName,
          }, button);
        }
      });

      // 优化移动端触摸体验
      if (this.isMobileDevice()) {
        // 增大触摸区域
        button.style.padding = '12px';
        button.style.minWidth = '44px';
        button.style.minHeight = '44px';

        // 添加触摸反馈
        button.addEventListener('touchstart', function () {
          this.style.transform = 'scale(0.95)';
        });

        button.addEventListener('touchend', function () {
          this.style.transform = 'scale(1)';
        });
      }
    });
  }

  /**
     * 检测是否为移动设备
     */
  isMobileDevice () {
    const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    return mobileRegex.test(navigator.userAgent);
  }

  /**
     * 优化收藏夹列表的响应式显示
     */
  optimizeFavoriteListForDevice () {
    const favoriteList = document.getElementById('favorites-list');
    if (!favoriteList) return;

    if (this.isMobileDevice()) {
      // 移动设备优化
      const favoriteItems = favoriteList.querySelectorAll('.favorite-item');
      favoriteItems.forEach((item) => {
        // 确保项目是响应式的
        item.style.width = '100%';
        item.style.marginBottom = '15px';

        // 优化内部布局
        const cardInfo = item.querySelector('.card-info');
        if (cardInfo) {
          cardInfo.style.fontSize = '14px';
        }
      });
    }
  }

  /**
     * 添加响应式分页处理
     */
  handleResponsivePagination () {
    const pagination = document.getElementById('pagination');
    if (!pagination) return;

    if (this.isMobileDevice()) {
      // 移动设备上简化分页显示
      pagination.style.justifyContent = 'center';
    }
  }

  /**
     * 检查卡密的收藏状态
     */
  checkFavoriteStatus (cardId, cardCode, button) {
    fetch(`${this.baseUrl}?action=check&card_id=${cardId}&card_code=${cardCode}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 'success' && data.data.is_favorited) {
          button.classList.add('favorited');
          button.dataset.favoriteId = data.data.favorite_id;
          button.innerHTML = '<i class="icon-star filled"></i> 已收藏';
        } else {
          button.classList.remove('favorited');
          button.innerHTML = '<i class="icon-star"></i> 收藏';
        }
      })
      .catch((error) => {
        console.error('检查收藏状态失败:', error);
      });
  }

  /**
     * 添加卡密到收藏夹
     */
  addFavorite (cardData, button) {
    fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(cardData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 'success') {
          button.classList.add('favorited');
          button.dataset.favoriteId = data.data.favorite_id || '';
          button.innerHTML = '<i class="icon-star filled"></i> 已收藏';

          // 显示成功提示
          this.showNotification('添加到收藏夹成功');
        } else {
          this.showNotification(data.message || '添加失败', 'error');
        }
      })
      .catch((error) => {
        console.error('添加收藏失败:', error);
        this.showNotification('添加失败，请重试', 'error');
      });
  }

  /**
     * 从收藏夹移除卡密
     */
  removeFavorite (favoriteId, button) {
    if (!favoriteId) {
      return;
    }

    fetch(`${this.baseUrl}?id=${favoriteId}`, {
      method: 'DELETE',
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 'success') {
          button.classList.remove('favorited');
          button.removeAttribute('data-favorite-id');
          button.innerHTML = '<i class="icon-star"></i> 收藏';

          // 显示成功提示
          this.showNotification('已从收藏夹移除');

          // 如果在收藏夹列表页，移除对应的行
          if (window.location.pathname.includes('favorites')) {
            const row = button.closest('.favorite-item');
            if (row) {
              row.remove();
            }
          }
        } else {
          this.showNotification(data.message || '移除失败', 'error');
        }
      })
      .catch((error) => {
        console.error('移除收藏失败:', error);
        this.showNotification('移除失败，请重试', 'error');
      });
  }

  /**
     * 初始化收藏夹页面
     */
  initFavoritesPage () {
    // 加载收藏列表
    this.loadFavoritesList(1);

    // 初始化分页
    this.initPagination();
  }

  /**
     * 加载收藏列表
     */
  loadFavoritesList (page = 1) {
    const container = document.getElementById('favorites-list');
    const loading = document.getElementById('loading-indicator');

    if (loading) {
      loading.style.display = 'block';
    }

    fetch(`${this.baseUrl}?page=${page}&limit=20`)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 'success') {
          this.renderFavoritesList(data.data.favorites, container);
          this.updatePagination(data.data.pagination);
        } else {
          container.innerHTML = `<div class="empty-message">${data.message || '加载失败'}</div>`;
        }
      })
      .catch((error) => {
        console.error('加载收藏列表失败:', error);
        container.innerHTML = '<div class="empty-message">加载失败，请重试</div>';
      })
      .finally(() => {
        if (loading) {
          loading.style.display = 'none';
        }
      });
  }

  /**
     * 渲染收藏列表
     */
  renderFavoritesList (favorites, container) {
    if (favorites.length === 0) {
      container.innerHTML = '<div class="empty-message">暂无收藏的卡密</div>';
      return;
    }

    let html = '';
    favorites.forEach((favorite) => {
      html += `
            <div class="favorite-item card">
                <div class="card-body">
                    <h5 class="card-title">${favorite.product_name}</h5>
                    <p class="card-text">卡密: ${favorite.card_code}</p>
                    <p class="card-text text-muted">添加时间: ${this.formatDate(favorite.added_at)}</p>
                    <div class="d-flex justify-content-between">
                        <button 
                            class="btn btn-outline-info view-card-btn"
                            data-card-id="${favorite.card_id}"
                            data-card-code="${favorite.card_code}"
                        >
                            查看详情
                        </button>
                        <button 
                            class="btn btn-outline-danger remove-favorite-btn favorite-btn favorited"
                            data-card-id="${favorite.card_id}"
                            data-card-code="${favorite.card_code}"
                            data-favorite-id="${favorite.id}"
                        >
                            移除收藏
                        </button>
                    </div>
                </div>
            </div>
            `;
    });

    container.innerHTML = html;

    // 重新初始化按钮
    this.initFavoriteButtons();
  }

  /**
     * 初始化分页
     */
  initPagination () {
    const pagination = document.getElementById('pagination');
    if (pagination) {
      pagination.addEventListener('click', (e) => {
        if (e.target.tagName === 'A') {
          e.preventDefault();
          const page = e.target.dataset.page;
          if (page) {
            this.loadFavoritesList(page);
          }
        }
      });
    }
  }

  /**
     * 更新分页
     */
  updatePagination (paginationData) {
    const pagination = document.getElementById('pagination');
    if (!pagination) return;

    let html = `<nav aria-label="Page navigation">
            <ul class="pagination">`;

    // 上一页
    html += `<li class="page-item ${paginationData.page === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" data-page="${paginationData.page - 1}" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
        </li>`;

    // 页码
    for (let i = 1; i <= paginationData.pages; i++) {
      html += `<li class="page-item ${i === paginationData.page ? 'active' : ''}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>`;
    }

    // 下一页
    html += `<li class="page-item ${paginationData.page === paginationData.pages ? 'disabled' : ''}">
            <a class="page-link" href="#" data-page="${paginationData.page + 1}" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
        </li>`;

    html += '</ul></nav>';
    pagination.innerHTML = html;
  }

  /**
     * 初始化卡密详情页
     */
  initCardDetailPage () {
    const cardInfo = this.getCardInfoFromPage();
    if (cardInfo) {
      const favoriteButton = document.querySelector('.favorite-btn');
      if (favoriteButton) {
        favoriteButton.dataset.cardId = cardInfo.cardId;
        favoriteButton.dataset.cardCode = cardInfo.cardCode;
        favoriteButton.dataset.productId = cardInfo.productId;
        favoriteButton.dataset.productName = cardInfo.productName;

        this.initFavoriteButtons();
      }
    }
  }

  /**
     * 从页面获取卡密信息
     */
  getCardInfoFromPage () {
    const cardElement = document.querySelector('.card-info');
    if (!cardElement) return null;

    return {
      cardId: cardElement.dataset.cardId,
      cardCode: cardElement.dataset.cardCode,
      productId: cardElement.dataset.productId,
      productName: cardElement.dataset.productName,
    };
  }

  /**
     * 格式化日期
     */
  formatDate (dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN');
  }

  /**
     * 显示通知
     */
  showNotification (message, type = 'success') {
    // 使用现有的通知系统
    if (window.showNotification) {
      window.showNotification(message, type);
    } else {
      // 响应式通知实现
      const notification = document.createElement('div');
      notification.className = `notification notification-${type}`;

      // 设置消息内容
      notification.innerHTML = `
                <i class="icon-star ${type === 'success' ? 'filled' : ''}"></i>
                <span>${message}</span>
            `;

      // 设置样式（移动设备优化）
      const isMobile = this.isMobileDevice();
      notification.style.cssText = `
                position: fixed;
                ${isMobile ? 'bottom: 80px; left: 50%; transform: translateX(-50%);' : 'top: 20px; right: 20px;'}
                background-color: ${type === 'success' ? '#5cb85c' : '#d9534f'};
                color: white;
                padding: 12px 20px;
                border-radius: 4px;
                z-index: 9999;
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 14px;
                max-width: ${isMobile ? '90%' : '400px'};
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            `;

      document.body.appendChild(notification);

      setTimeout(() => {
        notification.remove();
      }, 3000);
    }
  }
}

// 添加响应式样式
const style = document.createElement('style');
style.textContent = `
/* 移动设备响应式调整 */
@media (max-width: 767px) {
    .favorite-item {
        width: 100% !important;
        margin-bottom: 15px !important;
    }
    
    .favorite-item .card-body {
        font-size: 14px;
    }
    
    .favorite-item .btn {
        padding: 10px 15px;
        font-size: 14px;
        min-width: 44px;
        min-height: 44px;
    }
    
    .pagination {
        flex-wrap: wrap;
        font-size: 12px;
        justify-content: center;
    }
    
    .page-item {
        margin: 2px;
    }
    
    .page-link {
        padding: 8px 12px;
    }
}
`;
document.head.appendChild(style);

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', () => {
  const cardFavorites = new CardFavorites();
  cardFavorites.init();

  // 针对收藏夹页面添加额外的响应式处理
  if (window.location.pathname.includes('favorites')) {
    cardFavorites.optimizeFavoriteListForDevice();
    cardFavorites.handleResponsivePagination();
  }

  // 暴露到全局供其他脚本调用
  window.cardFavorites = cardFavorites;
});
