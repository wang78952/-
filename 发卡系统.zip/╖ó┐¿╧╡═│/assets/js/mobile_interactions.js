// 移动端交互增强脚本
// 为发卡系统添加触摸友好的交互体验

class MobileInteractionEnhancer {
  constructor () {
    this.isMobile = this.detectMobileDevice();
    this.isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    this.init();
  }

  // 检测是否为移动设备
  detectMobileDevice () {
    const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    return mobileRegex.test(navigator.userAgent);
  }

  // 初始化所有移动增强功能
  init () {
    if (this.isMobile || this.isTouchDevice) {
      console.log('移动设备检测：启用触摸优化');

      // 等待DOM加载完成
      document.addEventListener('DOMContentLoaded', () => {
        this.setupTouchEvents();
        this.optimizeTouchTargets();
        this.preventAccidentalZoom();
        this.setupPullToRefresh();
        this.enhanceModalInteraction();
        this.optimizeFavoriteButtons();
        this.enhanceExtensionOptions();
      });
    }
  }

  // 设置触摸事件增强
  setupTouchEvents () {
    // 添加触摸友好的点击事件处理
    const clickableElements = document.querySelectorAll('a, button, .btn, .favorite-btn, .card-item');

    clickableElements.forEach((element) => {
      // 添加触摸反馈
      element.addEventListener('touchstart', () => {
        element.style.opacity = '0.8';
      });

      element.addEventListener('touchend', () => {
        setTimeout(() => {
          element.style.opacity = '';
        }, 150);
      });

      // 防止触摸时的默认行为（如长按菜单）
      element.addEventListener('contextmenu', (e) => {
        e.preventDefault();
      });
    });

    // 为卡片添加滑动检测
    const cards = document.querySelectorAll('.card-item');
    cards.forEach((card) => {
      let startX, startY;
      const threshold = 50;

      card.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
      });

      card.addEventListener('touchend', (e) => {
        if (!startX || !startY) return;

        const endX = e.changedTouches[0].clientX;
        const endY = e.changedTouches[0].clientY;

        const diffX = endX - startX;
        const diffY = endY - startY;

        // 判断是否为水平滑动
        if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > threshold) {
          if (diffX > 0) {
            // 向右滑动
            this.handleSwipeRight(card);
          } else {
            // 向左滑动
            this.handleSwipeLeft(card);
          }
        }
      });
    });
  }

  // 优化触摸目标尺寸
  optimizeTouchTargets () {
    const elements = document.querySelectorAll('button, a, .btn, .favorite-btn');

    elements.forEach((element) => {
      const rect = element.getBoundingClientRect();

      // 确保触摸目标至少有44x44像素（苹果HIG建议）
      if (rect.width < 44 || rect.height < 44) {
        element.style.minWidth = '44px';
        element.style.minHeight = '44px';
        element.style.display = 'flex';
        element.style.alignItems = 'center';
        element.style.justifyContent = 'center';
      }
    });
  }

  // 防止意外缩放
  preventAccidentalZoom () {
    // 确保输入框字体大小不小于16px
    const inputs = document.querySelectorAll('input, select, textarea');

    inputs.forEach((input) => {
      if (parseInt(getComputedStyle(input).fontSize) < 16) {
        input.style.fontSize = '16px';
      }

      // 防止双击缩放
      input.addEventListener('dblclick', (e) => {
        e.preventDefault();
      });
    });
  }

  // 设置下拉刷新功能
  setupPullToRefresh () {
    let startY;
    let pullDistance = 0;
    const threshold = 100;
    const refreshElement = document.createElement('div');

    refreshElement.className = 'pull-to-refresh';
    refreshElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 下拉刷新';
    refreshElement.style.cssText = `
            position: fixed;
            top: -60px;
            left: 0;
            width: 100%;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
            color: #666;
            z-index: 9998;
            transition: transform 0.3s ease;
        `;

    document.body.appendChild(refreshElement);

    document.addEventListener('touchstart', (e) => {
      // 只有在页面顶部才能下拉刷新
      if (window.scrollY === 0) {
        startY = e.touches[0].clientY;
      }
    });

    document.addEventListener('touchmove', (e) => {
      if (!startY) return;

      const currentY = e.touches[0].clientY;
      pullDistance = currentY - startY;

      // 只允许向下拉动
      if (pullDistance > 0 && window.scrollY === 0) {
        e.preventDefault(); // 防止页面滚动

        // 限制最大拉动距离
        const maxPullDistance = 150;
        const limitedDistance = Math.min(pullDistance, maxPullDistance);

        // 应用拉动效果
        refreshElement.style.transform = `translateY(${limitedDistance * 0.6}px)`;

        if (limitedDistance > threshold) {
          refreshElement.innerHTML = '<i class="fas fa-arrow-up"></i> 释放刷新';
        } else {
          refreshElement.innerHTML = '<i class="fas fa-spinner"></i> 下拉刷新';
        }
      }
    }, { passive: false });

    document.addEventListener('touchend', () => {
      if (!startY || pullDistance <= 0) {
        startY = null;
        pullDistance = 0;
        return;
      }

      // 检查是否达到刷新阈值
      if (pullDistance > threshold) {
        // 执行刷新
        refreshElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 刷新中...';
        refreshElement.style.transform = 'translateY(60px)';

        // 模拟刷新操作
        setTimeout(() => {
          this.triggerRefresh();
          refreshElement.style.transform = 'translateY(0)';
        }, 1500);
      } else {
        // 回弹效果
        refreshElement.style.transform = 'translateY(0)';
      }

      startY = null;
      pullDistance = 0;
    });
  }

  // 触发页面刷新
  triggerRefresh () {
    // 根据当前页面执行相应的刷新操作
    if (window.location.pathname.includes('favorites.php')) {
      if (window.loadFavoriteCards) {
        window.loadFavoriteCards();
      }
    } else if (window.location.pathname.includes('card-result.html')) {
      // 刷新卡密结果页面
      location.reload();
    }

    // 显示刷新成功提示
    this.showToast('刷新成功');
  }

  // 增强模态框交互
  enhanceModalInteraction () {
    // 为模态框添加点击外部关闭功能
    const modals = document.querySelectorAll('.modal');

    modals.forEach((modal) => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          // 找到关闭按钮并点击
          const closeBtn = modal.querySelector('.close-btn, .btn-cancel');
          if (closeBtn) {
            closeBtn.click();
          } else {
            modal.style.display = 'none';
          }
        }
      });

      // 添加滑动关闭模态框支持
      let startY, initialScroll;

      modal.addEventListener('touchstart', (e) => {
        startY = e.touches[0].clientY;
        initialScroll = modal.scrollTop;
      });

      modal.addEventListener('touchmove', (e) => {
        if (!startY) return;

        const currentY = e.touches[0].clientY;
        const diff = currentY - startY;

        // 如果在顶部且向下滑动，关闭模态框
        if (initialScroll === 0 && diff > 50) {
          modal.style.display = 'none';
          startY = null;
        }
      });
    });
  }

  // 优化收藏按钮交互
  optimizeFavoriteButtons () {
    const favoriteBtns = document.querySelectorAll('.favorite-btn');

    favoriteBtns.forEach((btn) => {
      // 增大触摸区域
      this.enlargeTouchArea(btn, 10);

      // 添加触摸反馈动画
      btn.style.transition = 'all 0.2s ease';

      btn.addEventListener('touchstart', () => {
        btn.style.transform = 'scale(0.95)';
      });

      btn.addEventListener('touchend', () => {
        btn.style.transform = 'scale(1)';
        // 添加收藏成功的视觉反馈
        if (btn.classList.contains('favorited')) {
          btn.style.animation = 'heartBeat 0.6s ease-in-out';
          setTimeout(() => {
            btn.style.animation = '';
          }, 600);
        }
      });
    });
  }

  // 增强续期选项交互
  enhanceExtensionOptions () {
    const options = document.querySelectorAll('.extension-option');

    options.forEach((option) => {
      // 添加触摸反馈
      option.style.transition = 'all 0.2s ease';

      option.addEventListener('touchstart', () => {
        option.style.transform = 'scale(0.98)';
      });

      option.addEventListener('touchend', () => {
        option.style.transform = 'scale(1)';

        // 自动选中对应的单选按钮
        const radio = option.querySelector('input[type="radio"]');
        if (radio) {
          radio.checked = true;

          // 更新选中状态
          options.forEach((opt) => opt.classList.remove('active'));
          option.classList.add('active');
        }
      });
    });
  }

  // 处理向右滑动
  handleSwipeRight (element) {
    // 显示操作按钮
    const actions = element.querySelector('.card-actions');
    if (actions) {
      actions.style.opacity = '1';
      actions.style.transform = 'translateX(0)';
    }
  }

  // 处理向左滑动
  handleSwipeLeft (element) {
    // 隐藏操作按钮
    const actions = element.querySelector('.card-actions');
    if (actions) {
      actions.style.opacity = '0';
      actions.style.transform = 'translateX(100%)';
    }
  }

  // 增大触摸区域
  enlargeTouchArea (element, padding) {
    const rect = element.getBoundingClientRect();

    const wrapper = document.createElement('div');
    wrapper.style.cssText = `
            position: relative;
            padding: ${padding}px;
            display: inline-block;
        `;

    // 保存原始样式
    const originalDisplay = element.style.display;
    const originalPosition = element.style.position;

    // 将元素移动到包装器中
    element.parentNode.insertBefore(wrapper, element);
    wrapper.appendChild(element);

    // 恢复元素样式
    element.style.display = originalDisplay || '';
    element.style.position = originalPosition || '';
  }

  // 显示消息提示
  showToast (message, duration = 2000) {
    // 检查是否已存在toast
    let toast = document.querySelector('.toast-notification');

    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast-notification';
      toast.style.cssText = `
                position: fixed;
                bottom: 80px;
                left: 50%;
                transform: translateX(-50%);
                background-color: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 12px 20px;
                border-radius: 20px;
                z-index: 9999;
                opacity: 0;
                transition: opacity 0.3s ease;
                font-size: 14px;
                max-width: 80%;
                text-align: center;
            `;
      document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.style.opacity = '1';

    setTimeout(() => {
      toast.style.opacity = '0';
    }, duration);
  }

  // 防止iOS橡皮筋效果
  preventRubberBandEffect () {
    let startY;

    document.addEventListener('touchstart', (e) => {
      startY = e.touches[0].clientY;
    });

    document.addEventListener('touchmove', (e) => {
      const currentY = e.touches[0].clientY;
      const isScrollingUp = currentY < startY;
      const isScrollingDown = currentY > startY;

      // 防止顶部下拉橡皮筋效果
      if (window.scrollY === 0 && isScrollingDown) {
        e.preventDefault();
      }

      // 防止底部上拉橡皮筋效果
      if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight && isScrollingUp) {
        e.preventDefault();
      }

      startY = currentY;
    }, { passive: false });
  }
}

// 初始化移动交互增强器
document.addEventListener('DOMContentLoaded', () => {
  window.mobileEnhancer = new MobileInteractionEnhancer();
});

// 添加必要的CSS动画
const style = document.createElement('style');
style.textContent = `
@keyframes heartBeat {
    0% { transform: scale(1); }
    14% { transform: scale(1.1); }
    28% { transform: scale(1); }
    42% { transform: scale(1.1); }
    70% { transform: scale(1); }
}

/* 触摸反馈样式 */
.btn:active, a:active, button:active {
    transform: scale(0.98);
}

/* 优化表单元素的触摸体验 */
input, select, textarea {
    -webkit-tap-highlight-color: transparent;
}

/* 移动设备隐藏不需要的元素 */
@media (max-width: 767px) {
    .non-mobile-friendly {
        display: none !important;
    }
}

/* 增强滚动条样式 */
::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
    background: #555;
}
`;
document.head.appendChild(style);
