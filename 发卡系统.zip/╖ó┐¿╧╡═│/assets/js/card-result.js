// 卡密结果页交互逻辑
class CardResultPage {
  constructor () {
    this.cardData = {
      cardNumber: 'TXSP-2024-1118-1234',
      cardPassword: 'VIP-2024-1118-5678',
      orderNumber: '#2024111800001',
      productName: '腾讯视频年卡',
      amount: 198.00,
      payTime: '2024-11-18 14:30:25',
      payMethod: '支付宝',
      validFrom: '2025-11-18',
      validTo: '2026-11-18',
    };

    this.isCardNumberVisible = false;
    this.isCardPasswordVisible = false;
    this.autoHideTimer = null;

    this.init();
  }

  init () {
    this.bindEvents();
    this.initAnimations();
    this.checkOrderStatus();
    this.setupAutoHide();

    // 初始化移动端优化
    if (this.isMobileDevice()) {
      this.initMobileOptimizations();
    }
  }

  // 检测是否为移动设备
  isMobileDevice () {
    const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    return mobileRegex.test(navigator.userAgent);
  }

  // 初始化移动端优化
  initMobileOptimizations () {
    // 增大触摸目标
    const buttons = document.querySelectorAll('button');
    buttons.forEach((button) => {
      const currentWidth = button.offsetWidth;
      const currentHeight = button.offsetHeight;

      // 确保触摸目标至少为44x44像素
      if (currentWidth < 44 || currentHeight < 44) {
        button.style.minWidth = '44px';
        button.style.minHeight = '44px';
        button.style.padding = '8px 16px';
      }

      // 添加触摸反馈
      button.addEventListener('touchstart', () => {
        button.style.transform = 'scale(0.95)';
      });

      button.addEventListener('touchend', () => {
        button.style.transform = 'scale(1)';
      });
    });

    // 优化复制按钮行为
    const copyButtons = document.querySelectorAll('.btn-copy');
    copyButtons.forEach((button) => {
      button.style.display = 'flex';
      button.style.alignItems = 'center';
      button.style.justifyContent = 'center';
      button.style.gap = '8px';
    });

    // 确保模态框在移动设备上正确显示
    const modals = document.querySelectorAll('.modal');
    modals.forEach((modal) => {
      modal.style.maxWidth = '95%';
      modal.style.width = '95%';
      modal.style.margin = '10px auto';
    });

    // 优化卡密显示区域
    const cardInfo = document.querySelector('.card-detail-card');
    if (cardInfo) {
      cardInfo.style.padding = '20px 15px';
    }
  }

  // 绑定事件
  bindEvents () {
    // 页面卸载时清理定时器
    window.addEventListener('beforeunload', () => {
      if (this.autoHideTimer) {
        clearTimeout(this.autoHideTimer);
      }
    });

    // 复制按钮点击事件
    document.addEventListener('click', (e) => {
      if (e.target.closest('.btn-copy')) {
        this.handleCopyClick(e.target.closest('.btn-copy'));
      }
    });

    // 显示/隐藏按钮点击事件
    document.addEventListener('click', (e) => {
      if (e.target.closest('.btn-show')) {
        this.handleShowClick(e.target.closest('.btn-show'));
      }
    });

    // 键盘快捷键
    document.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        this.downloadCard();
      }
      if (e.ctrlKey && e.key === 'c' && this.isCardNumberVisible) {
        e.preventDefault();
        this.copyCardNumber();
      }
    });
  }

  // 初始化动画
  initAnimations () {
    // 成功图标动画
    const successIcon = document.querySelector('.success-icon');
    if (successIcon) {
      successIcon.style.animation = 'pulse 2s infinite';
    }

    // 卡片依次显示动画
    const cards = document.querySelectorAll('.card-detail-card, .order-info, .action-section');
    cards.forEach((card, index) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';

      setTimeout(() => {
        card.style.transition = 'all 0.6s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, 200 + index * 100);
    });
  }

  // 检查订单状态
  async checkOrderStatus () {
    try {
      // 模拟API调用检查订单状态
      const response = await this.mockApiCall('/api/order/status', {
        orderNumber: this.cardData.orderNumber,
      });

      if (response.status === 'success') {
        this.updateOrderInfo(response.data);
      } else {
        this.showError('订单状态异常，请联系客服');
      }
    } catch (error) {
      console.error('检查订单状态失败:', error);
    }
  }

  // 切换卡号显示/隐藏
  toggleCardNumber () {
    const cardNumberElement = document.getElementById('cardNumber');
    const showButton = document.querySelector('.card-field:first-child .btn-show');

    if (this.isCardNumberVisible) {
      // 隐藏卡号
      cardNumberElement.textContent = this.maskCardNumber(this.cardData.cardNumber);
      cardNumberElement.classList.add('masked');
      showButton.innerHTML = '<i class="fas fa-eye"></i> 显示';
      this.isCardNumberVisible = false;
      this.clearAutoHideTimer();
    } else {
      // 显示卡号
      cardNumberElement.textContent = this.cardData.cardNumber;
      cardNumberElement.classList.remove('masked');
      showButton.innerHTML = '<i class="fas fa-eye-slash"></i> 隐藏';
      this.isCardNumberVisible = true;
      this.startAutoHideTimer('cardNumber');
    }
  }

  // 切换密码显示/隐藏
  toggleCardPassword () {
    const cardPasswordElement = document.getElementById('cardPassword');
    const showButton = document.querySelector('.card-field:nth-child(2) .btn-show');

    if (this.isCardPasswordVisible) {
      // 隐藏密码
      cardPasswordElement.textContent = this.maskCardNumber(this.cardData.cardPassword);
      cardPasswordElement.classList.add('masked');
      showButton.innerHTML = '<i class="fas fa-eye"></i> 显示';
      this.isCardPasswordVisible = false;
      this.clearAutoHideTimer();
    } else {
      // 显示密码
      cardPasswordElement.textContent = this.cardData.cardPassword;
      cardPasswordElement.classList.remove('masked');
      showButton.innerHTML = '<i class="fas fa-eye-slash"></i> 隐藏';
      this.isCardPasswordVisible = true;
      this.startAutoHideTimer('cardPassword');
    }
  }

  // 复制卡号
  async copyCardNumber () {
    try {
      await navigator.clipboard.writeText(this.cardData.cardNumber);
      this.showCopySuccess('卡号已复制到剪贴板');
      this.updateCopyButton('cardNumber', true);
    } catch (error) {
      // 降级方案
      this.fallbackCopy(this.cardData.cardNumber);
    }
  }

  // 复制密码
  async copyCardPassword () {
    try {
      await navigator.clipboard.writeText(this.cardData.cardPassword);
      this.showCopySuccess('密码已复制到剪贴板');
      this.updateCopyButton('cardPassword', true);
    } catch (error) {
      // 降级方案
      this.fallbackCopy(this.cardData.cardPassword);
    }
  }

  // 降级复制方案
  fallbackCopy (text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.opacity = '0';
    document.body.appendChild(textArea);
    textArea.select();

    try {
      document.execCommand('copy');
      this.showCopySuccess('已复制到剪贴板');
    } catch (error) {
      this.showError('复制失败，请手动复制');
    }

    document.body.removeChild(textArea);
  }

  // 下载卡密
  downloadCard () {
    const content = this.generateCardFile();
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `卡密_${this.cardData.orderNumber}_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
    this.showSuccess('卡密文件已下载');
  }

  // 生成卡密文件内容
  generateCardFile () {
    return `
===========================================
           卡密信息凭证
===========================================

订单号：${this.cardData.orderNumber}
产品名称：${this.cardData.productName}
购买时间：${this.cardData.payTime}
支付金额：¥${this.cardData.amount.toFixed(2)}
支付方式：${this.cardData.payMethod}

-------------------------------------------
卡密信息
-------------------------------------------
卡号：${this.cardData.cardNumber}
密码：${this.cardData.cardPassword}

-------------------------------------------
有效期
-------------------------------------------
生效日期：${this.cardData.validFrom}
到期日期：${this.cardData.validTo}

-------------------------------------------
使用说明
-------------------------------------------
1. 请在有效期内激活使用
2. 卡密一旦激活无法退款
3. 如有问题请联系客服

===========================================
生成时间：${new Date().toLocaleString()}
===========================================
        `.trim();
  }

  // 查看订单
  viewOrder () {
    // 跳转到订单详情页
    window.location.href = `user-center.html?order=${this.cardData.orderNumber}`;
  }

  // 显示/隐藏按钮点击处理
  handleShowClick (button) {
    const cardField = button.closest('.card-field');
    const label = cardField.querySelector('.field-label').textContent;

    if (label.includes('卡号')) {
      this.toggleCardNumber();
    } else if (label.includes('密码')) {
      this.toggleCardPassword();
    }
  }

  // 复制按钮点击处理
  handleCopyClick (button) {
    const cardField = button.closest('.card-field');
    const label = cardField.querySelector('.field-label').textContent;

    if (label.includes('卡号')) {
      this.copyCardNumber();
    } else if (label.includes('密码')) {
      this.copyCardPassword();
    }
  }

  // 更新复制按钮状态
  updateCopyButton (type, success) {
    const cardField = type === 'cardNumber'
      ? document.querySelector('.card-field:first-child')
      : document.querySelector('.card-field:nth-child(2)');

    const copyButton = cardField.querySelector('.btn-copy');

    if (success) {
      copyButton.classList.add('copied');
      copyButton.innerHTML = '<i class="fas fa-check"></i> 已复制';

      setTimeout(() => {
        copyButton.classList.remove('copied');
        copyButton.innerHTML = '<i class="fas fa-copy"></i> 复制';
      }, 2000);
    }
  }

  // 设置自动隐藏
  setupAutoHide () {
    // 页面失去焦点时隐藏敏感信息
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.hideAllSensitiveInfo();
      }
    });

    // 点击页面其他区域时隐藏敏感信息
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.card-detail-card')) {
        this.hideAllSensitiveInfo();
      }
    });

    // 为移动设备添加触摸事件支持
    if (this.isMobileDevice()) {
      this.setupTouchEvents();
    }
  }

  // 复制所有卡密信息
  copyAllCardInfo () {
    const allInfo = `卡号: ${this.cardData.cardNumber}\n密码: ${this.cardData.cardPassword}\n有效期: ${this.cardData.validFrom} 至 ${this.cardData.validTo}`;

    navigator.clipboard.writeText(allInfo).then(() => {
      this.showToast('卡密信息已复制', 'success');
    }).catch(() => {
      // 降级方案
      this.fallbackCopy(allInfo);
      this.showToast('卡密信息已复制', 'success');
    });
  }

  // 设置触摸事件支持
  setupTouchEvents () {
    // 为卡片区域添加触摸事件
    const cardArea = document.querySelector('.card-detail-card');
    if (cardArea) {
      // 长按复制功能
      let longPressTimer;
      const longPressDelay = 500; // 长按阈值

      cardArea.addEventListener('touchstart', () => {
        longPressTimer = setTimeout(() => {
          // 复制所有卡密信息
          this.copyAllCardInfo();
        }, longPressDelay);
      });

      cardArea.addEventListener('touchend', () => {
        clearTimeout(longPressTimer);
      });

      cardArea.addEventListener('touchmove', () => {
        clearTimeout(longPressTimer);
      });
    }

    // 为续期按钮添加触摸反馈
    const extendButton = document.querySelector('.btn-extend');
    if (extendButton) {
      extendButton.addEventListener('touchstart', () => {
        extendButton.style.transform = 'scale(0.95)';
      });

      extendButton.addEventListener('touchend', () => {
        extendButton.style.transform = 'scale(1)';
      });
    }
  }

  // 开始自动隐藏计时器
  startAutoHideTimer (type) {
    this.clearAutoHideTimer();

    this.autoHideTimer = setTimeout(() => {
      if (type === 'cardNumber' && this.isCardNumberVisible) {
        this.toggleCardNumber();
      } else if (type === 'cardPassword' && this.isCardPasswordVisible) {
        this.toggleCardPassword();
      }
    }, 10000); // 10秒后自动隐藏
  }

  // 清除自动隐藏计时器
  clearAutoHideTimer () {
    if (this.autoHideTimer) {
      clearTimeout(this.autoHideTimer);
      this.autoHideTimer = null;
    }
  }

  // 隐藏所有敏感信息
  hideAllSensitiveInfo () {
    if (this.isCardNumberVisible) {
      this.toggleCardNumber();
    }
    if (this.isCardPasswordVisible) {
      this.toggleCardPassword();
    }
  }

  // 掩码卡号
  maskCardNumber (cardNumber) {
    if (cardNumber.length <= 8) return '****-****';
    return cardNumber.substring(0, cardNumber.length - 4).replace(/./g, '*') +
               cardNumber.substring(cardNumber.length - 4);
  }

  // 更新订单信息
  updateOrderInfo (data) {
    // 更新页面上的订单信息
    Object.keys(data).forEach((key) => {
      const element = document.querySelector(`[data-order="${key}"]`);
      if (element) {
        element.textContent = data[key];
      }
    });
  }

  // 显示成功消息
  showSuccess (message) {
    this.showToast(message, 'success');
  }

  // 显示错误消息
  showError (message) {
    this.showToast(message, 'error');
  }

  // 显示复制成功消息
  showCopySuccess (message) {
    this.showToast(message, 'success', 2000);
  }

  // 显示提示消息
  showToast (message, type = 'info', duration = 3000) {
    const isMobile = this.isMobileDevice();

    // 创建或获取toast容器
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      toastContainer.style.cssText = `
                position: fixed;
                ${isMobile ? 'bottom: 80px; left: 50%; transform: translateX(-50%);' : 'top: 20px; right: 20px; transform: none;'}
                z-index: 10000;
            `;
      document.body.appendChild(toastContainer);
    }

    // 创建toast元素
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.cssText = `
            background: ${type === 'success' ? '#00B42A' : type === 'error' ? '#F53F3F' : '#165DFF'};
            color: white;
            padding: 12px 20px;
            border-radius: ${isMobile ? '25px' : '8px'};
            margin-bottom: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            max-width: ${isMobile ? '90%' : '300px'};
            font-size: ${isMobile ? '14px' : '16px'};
            word-wrap: break-word;
            display: flex;
            align-items: center;
            gap: 10px;
            transform: ${isMobile ? 'translateX(-50%) translateY(100px)' : 'translateX(100%)'};
            opacity: 0;
            transition: transform 0.3s ease, opacity 0.3s ease;
        `;

    // 添加图标和消息
    toast.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        `;

    // 添加动画样式（仅一次）
    const style = document.createElement('style');
    style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
    if (!document.querySelector('style[data-toast]')) {
      style.setAttribute('data-toast', 'true');
      document.head.appendChild(style);
    }

    toastContainer.appendChild(toast);

    // 触发动画
    setTimeout(() => {
      toast.style.opacity = '1';
      toast.style.transform = isMobile ? 'translateX(-50%) translateY(0)' : 'translateX(0)';
    }, 10);

    // 自动移除
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = isMobile ? 'translateX(-50%) translateY(100px)' : 'translateX(100%)';
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, duration);
  }

  // 模拟API调用
  async mockApiCall (url, data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          status: 'success',
          data: {
            orderNumber: this.cardData.orderNumber,
            status: 'completed',
            paymentTime: this.cardData.payTime,
          },
        });
      }, 500);
    });
  }

  // 添加一键续期功能
  extendCard () {
    // 显示续期选项模态框
    this.showExtensionModal();
  }

  // 显示续期选项模态框
  showExtensionModal () {
    // 检查是否存在模态框，不存在则创建
    let modal = document.getElementById('extensionModal');
    if (!modal) {
      modal = this.createExtensionModal();
      document.body.appendChild(modal);
    }

    // 显示模态框
    modal.style.display = 'block';

    // 移动设备优化
    if (this.isMobileDevice()) {
      this.optimizeExtendModalForMobile();
    }

    // 绑定关闭事件
    const closeBtn = modal.querySelector('.close-btn');
    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    // 绑定确认续期按钮事件
    const confirmBtn = modal.querySelector('.confirm-extension-btn');
    confirmBtn.addEventListener('click', () => {
      this.processExtension();
    });
  }

  // 创建续期模态框
  createExtensionModal () {
    const modal = document.createElement('div');
    modal.id = 'extensionModal';
    modal.className = 'modal';
    modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-calendar-plus"></i> 卡密续期</h3>
                    <button class="close-btn">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="extension-options">
                        <div class="extension-option active">
                            <input type="radio" id="option3months" name="extensionPeriod" value="3" checked>
                            <label for="option3months">
                                <span class="period-name">3个月</span>
                                <span class="period-price">¥68.00</span>
                            </label>
                        </div>
                        <div class="extension-option">
                            <input type="radio" id="option6months" name="extensionPeriod" value="6">
                            <label for="option6months">
                                <span class="period-name">6个月</span>
                                <span class="period-price">¥128.00</span>
                            </label>
                        </div>
                        <div class="extension-option">
                            <input type="radio" id="option12months" name="extensionPeriod" value="12">
                            <label for="option12months">
                                <span class="period-name">12个月</span>
                                <span class="period-price">¥198.00</span>
                            </label>
                        </div>
                    </div>
                    <div class="extension-info">
                        <p><i class="fas fa-info-circle"></i> 续期后，新的有效期将从当前卡密到期日开始计算</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-cancel">取消</button>
                    <button class="btn-primary confirm-extension-btn">确认续期</button>
                </div>
            </div>
        `;

    // 绑定选项点击事件
    const options = modal.querySelectorAll('.extension-option');
    options.forEach((option) => {
      option.addEventListener('click', () => {
        // 移除其他选项的active类
        options.forEach((opt) => opt.classList.remove('active'));
        // 为当前选项添加active类
        option.classList.add('active');
        // 选中对应的radio
        option.querySelector('input[type="radio"]').checked = true;
      });
    });

    // 绑定取消按钮事件
    const cancelBtn = modal.querySelector('.btn-cancel');
    cancelBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    return modal;
  }

  // 处理续期请求
  async processExtension () {
    // 获取选中的续期期限
    const selectedPeriod = document.querySelector('input[name="extensionPeriod"]:checked').value;

    // 显示加载状态
    this.showLoadingState();

    try {
      // 模拟API调用
      const result = await this.confirmExtension(selectedPeriod);

      if (result.success) {
        // 显示成功消息
        this.showToast('续期成功！卡密有效期已延长。');

        // 更新页面上的有效期显示
        this.updateValidityDate(result.newExpiryDate);

        // 关闭模态框
        const modal = document.getElementById('extensionModal');
        if (modal) {
          modal.style.display = 'none';
        }
      } else {
        // 显示错误消息
        this.showToast(result.message || '续期失败，请稍后重试。', 'error');
      }
    } catch (error) {
      // 显示错误消息
      this.showToast('网络错误，请检查网络连接后重试。', 'error');
      console.error('续期请求错误:', error);
    } finally {
      // 隐藏加载状态
      this.hideLoadingState();
    }
  }

  // 为移动设备优化续期模态框
  optimizeExtendModalForMobile () {
    const modal = document.getElementById('extensionModal');
    if (!modal) return;

    if (this.isMobileDevice()) {
      // 调整模态框尺寸和位置
      modal.style.width = '95%';
      modal.style.maxWidth = '400px';
      modal.style.margin = '10px auto';
      modal.style.padding = '15px';

      // 优化选项样式
      const options = modal.querySelectorAll('.extension-option');
      options.forEach((option) => {
        option.style.padding = '15px 10px';
        option.style.marginBottom = '10px';
        option.style.fontSize = '14px';
      });

      // 优化按钮样式
      const buttons = modal.querySelectorAll('button');
      buttons.forEach((button) => {
        button.style.minHeight = '44px';
        button.style.minWidth = '80px';
        button.style.fontSize = '16px';
        button.style.padding = '10px 20px';
      });
    }
  }

  // 模拟确认续期API调用
  confirmExtension (period) {
    return new Promise((resolve) => {
      // 模拟网络延迟
      setTimeout(() => {
        // 生成新的有效期（示例逻辑）
        const now = new Date();
        const monthsToAdd = parseInt(period);
        now.setMonth(now.getMonth() + monthsToAdd);

        const newExpiryDate = {
          start: '2026-11-18', // 原到期日作为新的开始日期
          end: now.toISOString().split('T')[0],
        };

        resolve({
          success: true,
          newExpiryDate,
        });
      }, 1500);
    });
  }

  // 更新有效期显示
  updateValidityDate (newExpiryDate) {
    const validityDateElement = document.querySelector('.validity-date');
    if (validityDateElement) {
      validityDateElement.innerHTML = `
                <i class="fas fa-calendar-alt"></i>
                ${newExpiryDate.start} 至 ${newExpiryDate.end}
            `;
    }
  }

  // 显示加载状态
  showLoadingState () {
    // 检查是否存在加载遮罩，不存在则创建
    let loadingOverlay = document.getElementById('loadingOverlay');
    if (!loadingOverlay) {
      loadingOverlay = document.createElement('div');
      loadingOverlay.id = 'loadingOverlay';
      loadingOverlay.className = 'loading-overlay';
      loadingOverlay.innerHTML = `
                <div class="loading-spinner"></div>
                <p>处理中...</p>
            `;
      document.body.appendChild(loadingOverlay);
    }

    loadingOverlay.style.display = 'flex';
  }

  // 隐藏加载状态
  hideLoadingState () {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
      loadingOverlay.style.display = 'none';
    }
  }
}

// 全局函数（供HTML调用）
function toggleCardNumber () {
  window.cardResultPage.toggleCardNumber();
}

function toggleCardPassword () {
  window.cardResultPage.toggleCardPassword();
}

function copyCardNumber () {
  window.cardResultPage.copyCardNumber();
}

function copyCardPassword () {
  window.cardResultPage.copyCardPassword();
}

function downloadCard () {
  window.cardResultPage.downloadCard();
}

function viewOrder () {
  window.cardResultPage.viewOrder();
}

// 全局函数：一键续期
function extendCard () {
  window.cardResultPage.extendCard();
}

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  window.cardResultPage = new CardResultPage();
});
