/**
 * 前端通用组件库
 * 提供加载动画、表单验证、错误提示等功能
 */

class UIComponents {
  constructor () {
    this.init();
  }

  init () {
    this.setupLoadingStates();
    this.setupFormValidation();
    this.setupTooltips();
    this.setupModals();
    this.setupAnimations();
  }

  // 加载状态管理
  setupLoadingStates () {
    // 为所有按钮添加加载状态
    document.addEventListener('click', (e) => {
      const button = e.target.closest('button[type="submit"], .btn-submit');
      if (button && !button.dataset.loading) {
        this.showButtonLoading(button);
      }
    });

    // 页面加载动画
    window.addEventListener('load', () => {
      this.hidePageLoader();
    });
  }

  showButtonLoading (button) {
    if (button.disabled) return;

    const originalText = button.innerHTML;
    button.dataset.loading = 'true';
    button.disabled = true;
    button.innerHTML = '<span class="btn-spinner"></span> 处理中...';

    // 自动恢复（防止卡死）
    setTimeout(() => {
      if (button.dataset.loading === 'true') {
        this.hideButtonLoading(button, originalText);
      }
    }, 10000);
  }

  hideButtonLoading (button, originalText = null) {
    button.disabled = false;
    button.dataset.loading = 'false';
    button.innerHTML = originalText || button.innerHTML.replace('<span class="btn-spinner"></span> 处理中...', '');
  }

  showPageLoader () {
    const loader = document.createElement('div');
    loader.id = 'page-loader';
    loader.className = 'page-loader';
    loader.innerHTML = `
            <div class="loader-content">
                <div class="loader-spinner"></div>
                <div class="loader-text">加载中...</div>
            </div>
        `;
    document.body.appendChild(loader);
  }

  hidePageLoader () {
    const loader = document.getElementById('page-loader');
    if (loader) {
      loader.style.opacity = '0';
      setTimeout(() => loader.remove(), 300);
    }
  }

  // 表单验证
  setupFormValidation () {
    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach((form) => {
      form.addEventListener('submit', (e) => {
        if (!this.validateForm(form)) {
          e.preventDefault();
        }
      });

      // 实时验证
      const inputs = form.querySelectorAll('input, textarea, select');
      inputs.forEach((input) => {
        input.addEventListener('blur', () => this.validateField(input));
        input.addEventListener('input', () => this.clearFieldError(input));
      });
    });
  }

  validateForm (form) {
    if (window.uxEnhancer && window.uxEnhancer.validateForm) {
      return window.uxEnhancer.validateForm(form);
    }

    // 备用验证逻辑
    let isValid = true;
    const inputs = form.querySelectorAll('input, textarea, select');

    inputs.forEach((input) => {
      if (!this.validateField(input)) {
        isValid = false;
      }
    });

    return isValid;
  }

  validateField (field) {
    if (window.uxEnhancer && window.uxEnhancer.validateField) {
      return window.uxEnhancer.validateField(field);
    }

    // 备用字段验证逻辑
    const rules = field.dataset.rules || '';
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';

    // 必填验证
    if (rules.includes('required') && !value) {
      isValid = false;
      errorMessage = '此字段为必填项';
    }

    // 邮箱验证
    if (rules.includes('email') && value && !this.isValidEmail(value)) {
      isValid = false;
      errorMessage = '请输入有效的邮箱地址';
    }

    // 手机号验证
    if (rules.includes('phone') && value && !this.isValidPhone(value)) {
      isValid = false;
      errorMessage = '请输入有效的手机号码';
    }

    this.showFieldError(field, errorMessage);
    return isValid;
  }

  showFieldError (field, message) {
    this.clearFieldError(field);

    if (message) {
      field.classList.add('error');

      const errorElement = document.createElement('div');
      errorElement.className = 'field-error';
      errorElement.textContent = message;

      field.parentNode.appendChild(errorElement);
    }
  }

  clearFieldError (field) {
    field.classList.remove('error');
    const errorElement = field.parentNode.querySelector('.field-error');
    if (errorElement) {
      errorElement.remove();
    }
  }

  // 工具提示
  setupTooltips () {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach((element) => {
      element.addEventListener('mouseenter', (e) => this.showTooltip(e));
      element.addEventListener('mouseleave', (e) => this.hideTooltip(e));
    });
  }

  showTooltip (e) {
    const element = e.target;
    const text = element.dataset.tooltip;

    if (!text) return;

    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = text;

    document.body.appendChild(tooltip);

    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
  }

  hideTooltip () {
    const tooltip = document.querySelector('.tooltip');
    if (tooltip) {
      tooltip.remove();
    }
  }

  // 模态框管理
  setupModals () {
    // 为所有具有 data-modal 属性的元素添加点击事件
    document.addEventListener('click', (e) => {
      const trigger = e.target.closest('[data-modal]');
      if (trigger) {
        const modalId = trigger.dataset.modal;
        this.showModal(modalId);
      }

      const closeBtn = e.target.closest('[data-close-modal]');
      if (closeBtn) {
        const modal = closeBtn.closest('.modal');
        this.hideModal(modal);
      }
    });

    // 点击模态框外部关闭
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        this.hideModal(e.target);
      }
    });

    // ESC键关闭模态框
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const openModal = document.querySelector('.modal.show');
        if (openModal) {
          this.hideModal(openModal);
        }
      }
    });
  }

  showModal (modalId) {
    const modal = typeof modalId === 'string' ? document.getElementById(modalId) : modalId;
    if (!modal) return;

    modal.classList.add('show');
    modal.style.display = 'block';

    // 焦点管理
    setTimeout(() => {
      const focusableElements = modal.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusableElements.length > 0) {
        focusableElements[0].focus();
      }
    }, 100);

    // 禁用背景滚动
    document.body.style.overflow = 'hidden';
  }

  hideModal (modal) {
    if (!modal) return;

    modal.classList.remove('show');
    setTimeout(() => {
      modal.style.display = 'none';
    }, 300);

    // 恢复背景滚动
    document.body.style.overflow = '';
  }

  // 动画效果
  setupAnimations () {
    // 滚动动画
    this.setupScrollAnimations();

    // 悬停效果
    this.setupHoverEffects();

    // 过渡动画
    this.setupTransitions();
  }

  setupScrollAnimations () {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px',
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    document.querySelectorAll('[data-animate]').forEach((element) => {
      observer.observe(element);
    });
  }

  setupHoverEffects () {
    document.querySelectorAll('[data-hover]').forEach((element) => {
      element.addEventListener('mouseenter', () => {
        element.classList.add('hover-effect');
      });

      element.addEventListener('mouseleave', () => {
        element.classList.remove('hover-effect');
      });
    });
  }

  setupTransitions () {
    // 页面切换动画
    document.querySelectorAll('a[href]').forEach((link) => {
      link.addEventListener('click', (e) => {
        const href = link.getAttribute('href');
        if (href && !href.startsWith('#') && !href.startsWith('javascript') && !href.startsWith('mailto')) {
          e.preventDefault();
          this.pageTransition(href);
        }
      });
    });
  }

  pageTransition (url) {
    document.body.classList.add('page-transition-out');
    setTimeout(() => {
      window.location.href = url;
    }, 300);
  }

  // 通知系统
  showNotification (message, type = 'info', duration = 5000) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-message">${message}</span>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
        `;

    document.body.appendChild(notification);

    // 自动消失
    setTimeout(() => {
      if (notification.parentElement) {
        notification.classList.add('notification-out');
        setTimeout(() => notification.remove(), 300);
      }
    }, duration);
  }

  // 确认对话框
  confirm (message, onConfirm, onCancel = null) {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.style.display = 'block';
    modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">确认操作</h3>
                </div>
                <div class="modal-body">
                    <p>${message}</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" data-action="cancel">取消</button>
                    <button class="btn btn-danger" data-action="confirm">确认</button>
                </div>
            </div>
        `;

    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';

    modal.addEventListener('click', (e) => {
      const action = e.target.dataset.action;

      if (action === 'confirm') {
        onConfirm();
        this.hideModal(modal);
      } else if (action === 'cancel' || e.target === modal) {
        if (onCancel) onCancel();
        this.hideModal(modal);
      }
    });
  }

  // 格式化方法
  formatFileSize (bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  formatDate (date, format = 'YYYY-MM-DD HH:mm:ss') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');

    return format
      .replace('YYYY', year)
      .replace('MM', month)
      .replace('DD', day)
      .replace('HH', hours)
      .replace('mm', minutes)
      .replace('ss', seconds);
  }

  // 防抖和节流
  debounce (func, wait) {
    let timeout;
    return function executedFunction (...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  throttle (func, limit) {
    let inThrottle;
    return function () {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }
}

// 初始化组件
document.addEventListener('DOMContentLoaded', () => {
  window.ui = new UIComponents();
});

// 全局方法
window.showNotification = function (message, type, duration) {
  if (window.ui) {
    window.ui.showNotification(message, type, duration);
  }
};

window.confirmAction = function (message, onConfirm, onCancel) {
  if (window.ui) {
    window.ui.confirm(message, onConfirm, onCancel);
  }
};
