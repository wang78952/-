// 发卡系统首页JavaScript文件

// DOM加载完成后执行
document.addEventListener('DOMContentLoaded', function () {
  initHomePage();
});

// 初始化首页功能
function initHomePage () {
  initHeroBanner();
  initCategoryCards();
  initProductCards();
  initTrustSection();
  initAnimations();
  initLazyLoading();
}

// 初始化横幅Banner
function initHeroBanner () {
  const heroButtons = document.querySelectorAll('.hero-buttons .btn');

  heroButtons.forEach((button) => {
    button.addEventListener('click', function (e) {
      const href = this.getAttribute('href');

      if (href.startsWith('#')) {
        e.preventDefault();
        const targetId = href.substring(1);
        if (window.Navigation && window.Navigation.scrollToElement) {
          window.Navigation.scrollToElement(targetId);
        }
      }
    });
  });

  // 添加视差滚动效果
  initParallaxEffect();
}

// 初始化视差滚动效果
function initParallaxEffect () {
  const heroBanner = document.querySelector('.hero-banner');
  const heroImage = document.querySelector('.hero-image img');

  if (heroBanner && heroImage) {
    window.addEventListener('scroll', function () {
      const scrolled = window.pageYOffset;
      const parallax = scrolled * 0.5;

      if (scrolled < heroBanner.offsetHeight) {
        heroImage.style.transform = `translateY(${parallax}px)`;
      }
    });
  }
}

// 初始化分类卡片
function initCategoryCards () {
  const categoryCards = document.querySelectorAll('.category-card');

  categoryCards.forEach((card) => {
    // 添加悬停效果
    card.addEventListener('mouseenter', function () {
      this.style.transform = 'translateY(-8px) scale(1.02)';
    });

    card.addEventListener('mouseleave', function () {
      this.style.transform = 'translateY(0) scale(1)';
    });

    // 点击事件
    card.addEventListener('click', function (e) {
      e.preventDefault();
      const categoryName = this.querySelector('.category-name').textContent;
      filterProductsByCategory(categoryName);
    });
  });
}

// 根据分类筛选产品
function filterProductsByCategory (categoryName) {
  const productCards = document.querySelectorAll('.product-card');
  let visibleCount = 0;

  productCards.forEach((card) => {
    const productCategory = card.querySelector('.product-category').textContent;

    if (categoryName === '全部' || productCategory === categoryName) {
      card.style.display = 'block';
      visibleCount++;

      // 添加淡入动画
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';

      setTimeout(() => {
        card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, visibleCount * 100);
    } else {
      card.style.display = 'none';
    }
  });

  // 滚动到产品区域
  if (window.Navigation && window.Navigation.scrollToElement) {
    window.Navigation.scrollToElement('products');
  }

  // 显示筛选结果提示
  showFilterResult(categoryName, visibleCount);
}

// 显示筛选结果提示
function showFilterResult (category, count) {
  const message = count > 0
    ? `找到 ${count} 个${category}产品`
    : `暂无${category}产品`;

  if (window.Navigation && window.Navigation.showNotification) {
    window.Navigation.showNotification(message, count > 0 ? 'success' : 'warning');
  }
}

// 初始化产品卡片
function initProductCards () {
  const productCards = document.querySelectorAll('.product-card');

  productCards.forEach((card) => {
    // 添加悬停效果
    card.addEventListener('mouseenter', function () {
      this.style.transform = 'translateY(-8px)';
      this.style.boxShadow = 'var(--shadow-xl)';
    });

    card.addEventListener('mouseleave', function () {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = 'var(--shadow-sm)';
    });

    // 产品图片加载错误处理
    const productImage = card.querySelector('.product-image');
    if (productImage) {
      productImage.addEventListener('error', function () {
        this.src = 'assets/images/placeholder-product.jpg';
      });
    }

    // 库存状态动态更新
    updateStockStatus(card);
  });

  // 初始化产品筛选和排序
  initProductFilters();
}

// 更新库存状态
function updateStockStatus (card) {
  const stockStatus = card.querySelector('.stock-status');
  if (stockStatus) {
    const stockText = stockStatus.querySelector('span:last-child').textContent;

    // 根据库存文本更新样式
    stockStatus.classList.remove('stock-high', 'stock-medium', 'stock-low');

    if (stockText.includes('充足')) {
      stockStatus.classList.add('stock-high');
    } else if (stockText.includes('仅剩')) {
      const number = parseInt(stockText.match(/\d+/)?.[0] || '0');
      if (number <= 5) {
        stockStatus.classList.add('stock-low');
      } else {
        stockStatus.classList.add('stock-medium');
      }
    }
  }
}

// 初始化产品筛选
function initProductFilters () {
  // 可以在这里添加产品筛选功能
  // 例如：按价格、销量、新品等筛选
}

// 初始化信任背书区
function initTrustSection () {
  const trustItems = document.querySelectorAll('.trust-item');

  trustItems.forEach((item, index) => {
    // 添加延迟动画 - 优化减少跳动
    item.style.opacity = '0';
    item.style.transform = 'translateY(10px)'; // 减少移动距离

    setTimeout(() => {
      item.style.transition = 'opacity 0.3s ease, transform 0.3s ease'; // 减少动画时间
      item.style.opacity = '1';
      item.style.transform = 'translateY(0)';
    }, index * 50); // 减少延迟时间

    // 添加悬停效果 - 优化减少跳屏
    item.addEventListener('mouseenter', function () {
      const icon = this.querySelector('.trust-icon');
      if (icon) {
        icon.style.transform = 'scale(1.05)';
      }
    });

    item.addEventListener('mouseleave', function () {
      const icon = this.querySelector('.trust-icon');
      if (icon) {
        icon.style.transform = 'scale(1)';
      }
    });
  });
}

// 初始化动画效果
function initAnimations () {
  // 滚动显示动画
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px',
  };

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // 观察需要动画的元素
  const animateElements = document.querySelectorAll('.category-card, .product-card, .trust-item');
  animateElements.forEach((element) => {
    element.classList.add('animate-on-scroll');
    observer.observe(element);
  });
}

// 初始化懒加载
function initLazyLoading () {
  const images = document.querySelectorAll('img[loading="lazy"]');

  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver(function (entries) {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;

          // 添加加载动画
          img.style.opacity = '0';
          img.style.transition = 'opacity 0.3s ease';

          img.addEventListener('load', function () {
            this.style.opacity = '1';
          });

          imageObserver.unobserve(img);
        }
      });
    });

    images.forEach((img) => {
      imageObserver.observe(img);
    });
  }
}

// 添加CSS动画类
const style = document.createElement('style');
style.textContent = `
    .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    
    .animate-on-scroll.animate-in {
        opacity: 1;
        transform: translateY(0);
    }
    
    .trust-icon {
        transition: transform 0.2s ease;
        will-change: transform;
    }
    
    .category-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .product-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .hero-image img {
        transition: transform 0.1s ease-out;
    }
    
    .navbar.scrolled {
        box-shadow: var(--shadow-md);
    }
    
    .notification {
        animation: slideInRight 0.3s ease;
    }
    
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }
    
    @keyframes slideUp {
        from {
            transform: translateY(20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);

// 页面性能监控
function trackPagePerformance () {
  if ('performance' in window) {
    window.addEventListener('load', function () {
      setTimeout(() => {
        const perfData = performance.getEntriesByType('navigation')[0];
        const loadTime = perfData.loadEventEnd - perfData.loadEventStart;

        console.log('页面加载时间:', loadTime + 'ms');

        // 如果加载时间过长，可以显示优化建议
        if (loadTime > 3000) {
          console.warn('页面加载时间较长，建议优化');
        }
      }, 0);
    });
  }
}

// 初始化性能监控
trackPagePerformance();

// 导出函数供其他模块使用
window.HomePage = {
  filterProductsByCategory,
  updateStockStatus,
  showFilterResult,
};
