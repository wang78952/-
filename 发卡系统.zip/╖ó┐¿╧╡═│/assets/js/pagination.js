/**
 * 统一分页组件
 * 提供统一的分页逻辑和UI组件
 */

class PaginationManager {
  constructor (options = {}) {
    this.defaultOptions = {
      currentPage: 1,
      totalPages: 1,
      totalItems: 0,
      itemsPerPage: 20,
      maxVisiblePages: 7,
      showFirstLast: true,
      showPrevNext: true,
      showPageInfo: true,
      showItemsPerPageSelector: true,
      itemsPerPageOptions: [10, 20, 50, 100],
      onPageChange: null,
      onItemsPerPageChange: null,
      containerId: null,
      language: 'zh-CN',
    };

    this.options = { ...this.defaultOptions, ...options };
    this.translations = this.getTranslations();
  }

  /**
     * 获取翻译文本
     */
  getTranslations () {
    return {
      'zh-CN': {
        first: '首页',
        last: '末页',
        prev: '上一页',
        next: '下一页',
        page: '页',
        of: '共',
        items: '条',
        showing: '显示',
        to: '至',
        of_total: '共',
        items_per_page: '每页显示',
        go_to_page: '跳转到',
        total_pages: '总页数',
      },
      'en-US': {
        first: 'First',
        last: 'Last',
        prev: 'Previous',
        next: 'Next',
        page: 'Page',
        of: 'of',
        items: 'items',
        showing: 'Showing',
        to: 'to',
        of_total: 'of',
        items_per_page: 'Items per page',
        go_to_page: 'Go to page',
        total_pages: 'Total pages',
      },
    };
  }

  /**
     * 获取翻译文本
     */
  t (key) {
    const lang = this.options.language || 'zh-CN';
    return this.translations[lang]?.[key] || key;
  }

  /**
     * 渲染分页组件
     */
  render () {
    if (!this.options.containerId) {
      console.error('PaginationManager: containerId is required');
      return;
    }

    const container = document.getElementById(this.options.containerId);
    if (!container) {
      console.error(`PaginationManager: container with id '${this.options.containerId}' not found`);
      return;
    }

    // 如果只有一页且不显示分页信息，则隐藏
    if (this.options.totalPages <= 1 && !this.options.showPageInfo) {
      container.innerHTML = '';
      return;
    }

    container.innerHTML = this.generatePaginationHTML();
    this.bindEvents();
  }

  /**
     * 生成分页HTML
     */
  generatePaginationHTML () {
    let html = '<div class="pagination-wrapper">';

    // 每页显示数量选择器
    if (this.options.showItemsPerPageSelector) {
      html += this.generateItemsPerPageSelector();
    }

    // 分页导航
    html += '<nav aria-label="Page navigation">';
    html += '<ul class="pagination justify-content-center">';

    // 首页按钮
    if (this.options.showFirstLast) {
      html += this.generateFirstButton();
    }

    // 上一页按钮
    if (this.options.showPrevNext) {
      html += this.generatePrevButton();
    }

    // 页码按钮
    html += this.generatePageNumbers();

    // 下一页按钮
    if (this.options.showPrevNext) {
      html += this.generateNextButton();
    }

    // 末页按钮
    if (this.options.showFirstLast) {
      html += this.generateLastButton();
    }

    html += '</ul>';
    html += '</nav>';

    // 分页信息
    if (this.options.showPageInfo) {
      html += this.generatePageInfo();
    }

    html += '</div>';

    return html;
  }

  /**
     * 生成每页显示数量选择器
     */
  generateItemsPerPageSelector () {
    let html = '<div class="items-per-page-selector mb-3">';
    html += `<label class="form-label me-2">${this.t('items_per_page')}: </label>`;
    html += '<select class="form-select form-select-sm d-inline-block w-auto" id="itemsPerPageSelect">';

    this.options.itemsPerPageOptions.forEach((option) => {
      const selected = option === this.options.itemsPerPage ? 'selected' : '';
      html += `<option value="${option}" ${selected}>${option}</option>`;
    });

    html += '</select>';
    html += '</div>';

    return html;
  }

  /**
     * 生成首页按钮
     */
  generateFirstButton () {
    const disabled = this.options.currentPage === 1 ? 'disabled' : '';
    return `
            <li class="page-item ${disabled}">
                <a class="page-link" href="#" data-page="1" aria-label="First">
                    <span aria-hidden="true">${this.t('first')}</span>
                </a>
            </li>
        `;
  }

  /**
     * 生成上一页按钮
     */
  generatePrevButton () {
    const disabled = this.options.currentPage === 1 ? 'disabled' : '';
    const prevPage = Math.max(1, this.options.currentPage - 1);
    return `
            <li class="page-item ${disabled}">
                <a class="page-link" href="#" data-page="${prevPage}" aria-label="Previous">
                    <span aria-hidden="true">${this.t('prev')}</span>
                </a>
            </li>
        `;
  }

  /**
     * 生成页码按钮
     */
  generatePageNumbers () {
    let html = '';
    const { currentPage, totalPages, maxVisiblePages } = this.options;

    // 计算显示范围
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    const endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    // 调整起始页
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    // 如果不是从第一页开始，显示第一页和省略号
    if (startPage > 1) {
      html += this.generatePageButton(1);
      if (startPage > 2) {
        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
      }
    }

    // 显示页码
    for (let i = startPage; i <= endPage; i++) {
      html += this.generatePageButton(i);
    }

    // 如果不是到最后一页结束，显示省略号和最后一页
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
      }
      html += this.generatePageButton(totalPages);
    }

    return html;
  }

  /**
     * 生成页码按钮
     */
  generatePageButton (pageNum) {
    const active = pageNum === this.options.currentPage ? 'active' : '';
    const ariaCurrent = active ? 'aria-current="page"' : '';
    return `
            <li class="page-item ${active}">
                <a class="page-link" href="#" data-page="${pageNum}" ${ariaCurrent}>${pageNum}</a>
            </li>
        `;
  }

  /**
     * 生成下一页按钮
     */
  generateNextButton () {
    const disabled = this.options.currentPage === this.options.totalPages ? 'disabled' : '';
    const nextPage = Math.min(this.options.totalPages, this.options.currentPage + 1);
    return `
            <li class="page-item ${disabled}">
                <a class="page-link" href="#" data-page="${nextPage}" aria-label="Next">
                    <span aria-hidden="true">${this.t('next')}</span>
                </a>
            </li>
        `;
  }

  /**
     * 生成末页按钮
     */
  generateLastButton () {
    const disabled = this.options.currentPage === this.options.totalPages ? 'disabled' : '';
    return `
            <li class="page-item ${disabled}">
                <a class="page-link" href="#" data-page="${this.options.totalPages}" aria-label="Last">
                    <span aria-hidden="true">${this.t('last')}</span>
                </a>
            </li>
        `;
  }

  /**
     * 生成分页信息
     */
  generatePageInfo () {
    const startItem = (this.options.currentPage - 1) * this.options.itemsPerPage + 1;
    const endItem = Math.min(this.options.totalItems, this.options.currentPage * this.options.itemsPerPage);

    return `
            <div class="page-info text-center mt-2">
                <small class="text-muted">
                    ${this.t('showing')} ${startItem} ${this.t('to')} ${endItem} ${this.t('of_total')} ${this.options.totalItems} ${this.t('items')}
                    (${this.t('page')} ${this.options.currentPage} ${this.t('of')} ${this.options.totalPages})
                </small>
            </div>
        `;
  }

  /**
     * 绑定事件
     */
  bindEvents () {
    const container = document.getElementById(this.options.containerId);
    if (!container) return;

    // 页码点击事件
    container.querySelectorAll('.page-link[data-page]').forEach((link) => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = parseInt(e.target.closest('.page-link').dataset.page);
        if (page && page !== this.options.currentPage) {
          this.goToPage(page);
        }
      });
    });

    // 每页显示数量变化事件
    const itemsPerPageSelect = container.querySelector('#itemsPerPageSelect');
    if (itemsPerPageSelect) {
      itemsPerPageSelect.addEventListener('change', (e) => {
        const newItemsPerPage = parseInt(e.target.value);
        if (newItemsPerPage !== this.options.itemsPerPage) {
          this.changeItemsPerPage(newItemsPerPage);
        }
      });
    }
  }

  /**
     * 跳转到指定页
     */
  goToPage (page) {
    if (page < 1 || page > this.options.totalPages) {
      return;
    }

    this.options.currentPage = page;

    if (typeof this.options.onPageChange === 'function') {
      this.options.onPageChange(page);
    }

    // 重新渲染分页组件
    this.render();
  }

  /**
     * 改变每页显示数量
     */
  changeItemsPerPage (itemsPerPage) {
    this.options.itemsPerPage = itemsPerPage;
    this.options.totalPages = Math.ceil(this.options.totalItems / itemsPerPage);
    this.options.currentPage = 1; // 重置到第一页

    if (typeof this.options.onItemsPerPageChange === 'function') {
      this.options.onItemsPerPageChange(itemsPerPage);
    }

    // 重新渲染分页组件
    this.render();
  }

  /**
     * 更新分页数据
     */
  update (newOptions) {
    this.options = { ...this.options, ...newOptions };
    this.render();
  }

  /**
     * 获取当前分页状态
     */
  getState () {
    return {
      currentPage: this.options.currentPage,
      totalPages: this.options.totalPages,
      totalItems: this.options.totalItems,
      itemsPerPage: this.options.itemsPerPage,
    };
  }

  /**
     * 重置分页状态
     */
  reset () {
    this.options.currentPage = 1;
    this.render();
  }

  /**
     * 设置语言
     */
  setLanguage (language) {
    this.options.language = language;
    this.render();
  }

  /**
     * 销毁分页组件
     */
  destroy () {
    const container = document.getElementById(this.options.containerId);
    if (container) {
      container.innerHTML = '';
    }
  }
}

// 全局分页管理器实例
let globalPaginationManager = null;

/**
 * 初始化全局分页管理器
 */
function initPagination (options = {}) {
  globalPaginationManager = new PaginationManager(options);
  return globalPaginationManager;
}

/**
 * 获取全局分页管理器
 */
function getPaginationManager () {
  return globalPaginationManager;
}

// 导出分页管理器类
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PaginationManager;
}

// 确保在DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', function () {
  // 初始化全局分页管理器
  window.paginationManager = PaginationManager;

  // 自动初始化页面中的分页组件
  const paginationContainers = document.querySelectorAll('[data-pagination]');
  paginationContainers.forEach((container) => {
    const options = {
      containerId: container.id,
      currentPage: parseInt(container.dataset.currentPage) || 1,
      totalPages: parseInt(container.dataset.totalPages) || 1,
      onPageChange: container.dataset.onPageChange
        ? new Function('page', container.dataset.onPageChange)
        : null,
      itemsPerPage: parseInt(container.dataset.itemsPerPage) || 10,
      showItemsPerPage: container.dataset.showItemsPerPage !== 'false',
      showPageInfo: container.dataset.showPageInfo !== 'false',
      language: container.dataset.language || 'zh-CN',
      theme: container.dataset.theme || 'default',
    };

    new PaginationManager(options);
  });
});
