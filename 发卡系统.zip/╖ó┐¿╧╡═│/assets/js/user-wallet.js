// 用户卡包功能JavaScript
class UserWallet {
  constructor () {
    this.currentPage = 1;
    this.pageSize = 10;
    this.filters = {
      status: '',
      category: '',
      search: '',
    };
    this.init();
  }

  init () {
    this.bindEvents();
    this.loadWalletStats();
    this.loadWalletCards();
  }

  bindEvents () {
    // 筛选事件
    document.getElementById('cardStatusFilter')?.addEventListener('change', (e) => {
      this.filters.status = e.target.value;
      this.currentPage = 1;
      this.loadWalletCards();
    });

    document.getElementById('cardCategoryFilter')?.addEventListener('change', (e) => {
      this.filters.category = e.target.value;
      this.currentPage = 1;
      this.loadWalletCards();
    });

    document.getElementById('cardSearchInput')?.addEventListener('input', this.debounce((e) => {
      this.filters.search = e.target.value;
      this.currentPage = 1;
      this.loadWalletCards();
    }, 500));

    // 同步卡密按钮
    document.getElementById('syncCardsBtn')?.addEventListener('click', () => {
      this.syncCards();
    });

    // 批量下载按钮
    document.getElementById('exportCardsBtn')?.addEventListener('click', () => {
      this.exportCards();
    });
  }

  // 加载卡包统计
  async loadWalletStats () {
    try {
      const timestamp = new Date().getTime();
      const response = await fetch(`api/user_wallet_stats.json?t=${timestamp}`);
      const result = await response.json();

      if (result.success) {
        this.updateWalletStats(result.data);
      } else {
        this.showError('加载统计数据失败：' + result.message);
      }
    } catch (error) {
      console.error('加载统计数据失败:', error);
      this.showError('加载统计数据失败，请稍后重试');
    }
  }

  // 更新卡包统计显示
  updateWalletStats (stats) {
    const elements = {
      total: document.querySelector('#walletStats .stat-card:nth-child(1) .stat-value'),
      unused: document.querySelector('#walletStats .stat-card:nth-child(2) .stat-value'),
      used: document.querySelector('#walletStats .stat-card:nth-child(3) .stat-value'),
      expired: document.querySelector('#walletStats .stat-card:nth-child(4) .stat-value'),
    };

    if (elements.total) elements.total.textContent = stats.total || 0;
    if (elements.unused) elements.unused.textContent = stats.unused || 0;
    if (elements.used) elements.used.textContent = stats.used || 0;
    if (elements.expired) elements.expired.textContent = stats.expired || 0;
  }

  // 加载卡密列表
  async loadWalletCards () {
    try {
      this.showLoading();

      const timestamp = new Date().getTime();
      const response = await fetch(`api/user_wallet_list.json?t=${timestamp}`);
      const result = await response.json();

      if (result.success) {
        this.renderCardList(result.data.cards);
        this.renderPagination(result.data.pagination);
      } else {
        this.showError('加载卡密列表失败：' + result.message);
      }
    } catch (error) {
      console.error('加载卡密列表失败:', error);
      this.showError('加载卡密列表失败，请稍后重试');
    } finally {
      this.hideLoading();
    }
  }

  // 渲染卡密列表
  renderCardList (cards) {
    const cardList = document.getElementById('cardList');

    if (!cards || cards.length === 0) {
      cardList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <h3 class="empty-title">暂无卡密</h3>
                    <p class="empty-text">您还没有符合条件的卡密，快去购买吧！</p>
                    <button class="btn-content primary" onclick="window.location.href='products.html'">
                        <i class="fas fa-shopping-cart"></i>
                        去购买
                    </button>
                </div>
            `;
      return;
    }

    cardList.innerHTML = cards.map((card) => this.createCardItem(card)).join('');
  }

  // 创建卡密项HTML
  createCardItem (card) {
    const categoryIcons = {
      game: 'fa-gamepad',
      video: 'fa-play-circle',
      software: 'fa-desktop',
      music: 'fa-music',
      reading: 'fa-book',
      other: 'fa-credit-card',
    };

    const statusClass = card.status;
    const statusText = {
      unused: '未使用',
      used: '已使用',
      expired: '已过期',
    }[card.status] || card.status;

    return `
            <div class="card-item ${statusClass}" data-card-id="${card.id}">
                <div class="card-icon ${card.category}">
                    <i class="fas ${categoryIcons[card.category] || 'fa-credit-card'}"></i>
                </div>
                <div class="card-info">
                    <div class="card-name">${card.product_name}</div>
                    <div class="card-code">
                        <span>${card.card_code}</span>
                        <button class="copy-btn" onclick="userWallet.copyCardCode('${card.card_code}')">
                            <i class="fas fa-copy"></i>
                            复制
                        </button>
                    </div>
                    <div class="card-meta">
                        <span class="card-status ${statusClass}">${statusText}</span>
                        <span><i class="fas fa-calendar"></i> ${this.formatDate(card.created_at)}</span>
                        ${card.expires_at ? `<span><i class="fas fa-clock"></i> ${this.formatDate(card.expires_at)}</span>` : ''}
                    </div>
                </div>
                <div class="card-actions">
                    ${card.status === 'unused'
    ? `
                        <button class="card-btn primary" onclick="userWallet.useCard(${card.id})">
                            <i class="fas fa-check"></i>
                            使用
                        </button>
                    `
    : ''}
                    <button class="card-btn secondary" onclick="userWallet.showCardDetail(${card.id})">
                        <i class="fas fa-info-circle"></i>
                        详情
                    </button>
                </div>
            </div>
        `;
  }

  // 复制卡密
  async copyCardCode (cardCode) {
    try {
      await navigator.clipboard.writeText(cardCode);
      this.showSuccess('卡密已复制到剪贴板');
    } catch (error) {
      // 降级方案
      const textArea = document.createElement('textarea');
      textArea.value = cardCode;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      this.showSuccess('卡密已复制到剪贴板');
    }
  }

  // 使用卡密
  useCard (cardId) {
    this.showSuccess('卡密使用功能演示');
  }

  // 显示卡密详情
  showCardDetail (cardId) {
    this.showSuccess('卡密详情功能演示');
  }

  // 同步卡密
  syncCards () {
    this.showSuccess('同步卡密功能演示');
  }

  // 导出卡密
  exportCards () {
    this.showSuccess('导出卡密功能演示');
  }

  // 渲染分页
  renderPagination (pagination) {
    const paginationEl = document.getElementById('cardPagination');

    if (!pagination || pagination.total_pages <= 1) {
      paginationEl.innerHTML = '';
      return;
    }

    let html = '';

    // 上一页
    if (pagination.current_page > 1) {
      html += `<button class="page-btn" onclick="userWallet.goToPage(${pagination.current_page - 1})">上一页</button>`;
    }

    // 页码
    for (let i = 1; i <= pagination.total_pages; i++) {
      if (i === pagination.current_page) {
        html += `<button class="page-btn active">${i}</button>`;
      } else {
        html += `<button class="page-btn" onclick="userWallet.goToPage(${i})">${i}</button>`;
      }
    }

    // 下一页
    if (pagination.current_page < pagination.total_pages) {
      html += `<button class="page-btn" onclick="userWallet.goToPage(${pagination.current_page + 1})">下一页</button>`;
    }

    paginationEl.innerHTML = html;
  }

  // 跳转到指定页
  goToPage (page) {
    this.currentPage = page;
    this.loadWalletCards();
  }

  // 格式化日期
  formatDate (dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  // 防抖函数
  debounce (func, wait) {
    let timeout;
    return function executedFunction (...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // 显示加载状态
  showLoading () {
    const cardList = document.getElementById('cardList');
    cardList.innerHTML = `
            <div style="text-align: center; padding: 2rem;">
                <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: #667eea;"></i>
                <p style="margin-top: 1rem; color: #718096;">加载中...</p>
            </div>
        `;
  }

  // 隐藏加载状态
  hideLoading () {
    // 加载完成后会被实际内容替换
  }

  // 显示成功消息
  showSuccess (message) {
    this.showToast(message, 'success');
  }

  // 显示错误消息
  showError (message) {
    this.showToast(message, 'error');
  }

  // 显示Toast消息
  showToast (message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        `;

    // 添加样式
    toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#48bb78' : type === 'error' ? '#f56565' : '#4299e1'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: slideInRight 0.3s ease;
            max-width: 300px;
        `;

    document.body.appendChild(toast);

    // 3秒后自动移除
    setTimeout(() => {
      toast.style.animation = 'slideOutRight 0.3s ease';
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3000);
  }
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// 初始化用户卡包
let userWallet;
document.addEventListener('DOMContentLoaded', () => {
  // 检查是否在用户中心页面
  if (document.getElementById('cards-content')) {
    userWallet = new UserWallet();
  }
});
