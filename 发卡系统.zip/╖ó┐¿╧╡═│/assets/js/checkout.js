/**
 * 结算页交互功能
 */

// 订单数据
const orderData = {
  items: [],
  subtotal: 0,
  discount: 0,
  total: 0,
  selectedPayment: 'alipay',
  selectedCoupon: null,
  selectedDiscount: null,
};

// 可用满减优惠数据
let availableDiscounts = [];

// 可用优惠券数据
const availableCoupons = [
  {
    id: 'newuser10',
    name: '新用户专享券',
    description: '满50元减10元',
    value: 10,
    minAmount: 50,
    expireDate: '2024-12-31',
    type: 'amount',
  },
  {
    id: 'vip20',
    name: 'VIP会员券',
    description: '满100元减20元',
    value: 20,
    minAmount: 100,
    expireDate: '2024-11-30',
    type: 'amount',
  },
  {
    id: 'discount85',
    name: '限时折扣券',
    description: '全场8.5折',
    value: 0.85,
    minAmount: 30,
    expireDate: '2024-11-15',
    type: 'percentage',
  },
];

// DOM元素
let elements = {};

// 初始化函数
async function initCheckout () {
  initElements();
  loadOrderData();
  renderOrderItems();
  renderCoupons();

  // 获取并渲染满减优惠
  await fetchAvailableDiscounts();

  updateOrderSummary();
  initEventListeners();
  initAnimations();
}

// 初始化DOM元素
function initElements () {
  elements = {
    orderItems: document.getElementById('orderItems'),
    subtotal: document.getElementById('subtotal'),
    discountRow: document.getElementById('discountRow'),
    couponDiscountAmount: document.getElementById('couponDiscountAmount'),
    discountActivityRow: document.getElementById('discountActivityRow'),
    discountActivityAmount: document.getElementById('discountActivityAmount'),
    totalDiscountAmount: document.getElementById('totalDiscountAmount'),
    totalAmount: document.getElementById('totalAmount'),
    couponInput: document.getElementById('couponInput'),
    couponList: document.getElementById('couponList'),
    discountList: document.getElementById('discountList'),
    confirmBtn: document.getElementById('confirmBtn'),
  };
}

// 加载订单数据
function loadOrderData () {
  // 检查是否有直接购买的商品
  const directPurchase = Storage.get('directPurchase');
  if (directPurchase) {
    orderData.items = [directPurchase];
    Storage.remove('directPurchase');
  } else {
    // 从购物车加载商品
    const cart = Storage.get('cart') || [];
    orderData.items = cart;
  }

  // 计算订单金额
  calculateOrderAmount();
}

// 计算订单金额
function calculateOrderAmount () {
  orderData.subtotal = orderData.items.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);

  // 初始化折扣金额
  let couponDiscount = 0;
  let discountActivity = 0;

  // 应用优惠券折扣
  if (orderData.selectedCoupon) {
    if (orderData.selectedCoupon.type === 'amount') {
      couponDiscount = orderData.selectedCoupon.value;
    } else if (orderData.selectedCoupon.type === 'percentage') {
      couponDiscount = orderData.subtotal * (1 - orderData.selectedCoupon.value);
    }
  }

  // 应用满减优惠折扣
  if (orderData.selectedDiscount) {
    discountActivity = orderData.selectedDiscount.value;
  }

  // 计算总折扣（优惠券和满减优惠可叠加）
  orderData.discount = couponDiscount + discountActivity;

  orderData.total = Math.max(0, orderData.subtotal - orderData.discount);
}

// 获取可用的满减优惠
async function fetchAvailableDiscounts () {
  // 检查登录状态
  if (!Storage.get('userToken')) {
    return;
  }

  try {
    // 准备订单数据
    const orderDataForAPI = {
      orderAmount: orderData.subtotal,
      orderItems: orderData.items.map((item) => ({
        id: item.id,
        quantity: item.quantity,
        price: item.price,
      })),
    };

    // 发送请求到API
    const response = await fetch('/api/get_available_discounts.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(orderDataForAPI),
    });

    const data = await response.json();

    if (data.success) {
      availableDiscounts = data.data;
      renderDiscounts();
    }
  } catch (error) {
    console.error('获取满减优惠失败:', error);
  }
}

// 渲染订单商品
function renderOrderItems () {
  if (orderData.items.length === 0) {
    elements.orderItems.innerHTML = `
            <div class="empty-cart">
                <div class="empty-cart-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h3 class="empty-cart-title">购物车为空</h3>
                <p class="empty-cart-desc">您的购物车中还没有商品，快去选购吧</p>
                <button class="btn-go-shopping" onclick="goToShopping()">
                    去购物
                </button>
            </div>
        `;
    elements.confirmBtn.disabled = true;
    return;
  }

  const itemsHTML = orderData.items.map((item) => `
        <div class="order-item">
            <img src="${item.image}" alt="${item.name}" class="order-item-image">
            <div class="order-item-details">
                <h3 class="order-item-name">${item.name}</h3>
                <div class="order-item-specs">
                    规格：${item.durationName || item.duration} ${item.versionName ? `| ${item.versionName}` : ''}
                </div>
                <div class="order-item-price">
                    <span class="order-item-current-price">¥${item.price.toFixed(2)}</span>
                    ${item.originalPrice && item.originalPrice > item.price
    ? `<span class="order-item-original-price">¥${item.originalPrice.toFixed(2)}</span>`
    : ''}
                </div>
            </div>
            <div class="order-item-quantity">
                <span>数量：${item.quantity}</span>
            </div>
        </div>
    `).join('');

  elements.orderItems.innerHTML = itemsHTML;
}

// 渲染优惠券
function renderCoupons () {
  const validCoupons = availableCoupons.filter((coupon) => {
    // 检查是否满足使用条件
    return orderData.subtotal >= coupon.minAmount;
  });

  if (validCoupons.length === 0) {
    elements.couponList.innerHTML = `
            <div style="text-align: center; padding: 1rem; color: var(--text-secondary);">
                暂无可用优惠券
            </div>
        `;
    return;
  }

  const couponsHTML = validCoupons.map((coupon) => {
    const isSelected = orderData.selectedCoupon && orderData.selectedCoupon.id === coupon.id;
    const isExpired = new Date(coupon.expireDate) < new Date();

    return `
            <div class="coupon-item ${isSelected ? 'selected' : ''} ${isExpired ? 'disabled' : ''}" 
                 onclick="selectCoupon('${coupon.id}')" data-coupon-id="${coupon.id}">
                <div class="coupon-info">
                    <div class="coupon-name">${coupon.name}</div>
                    <div class="coupon-desc">${coupon.description}</div>
                    <div class="coupon-expire">有效期至：${coupon.expireDate}</div>
                </div>
                <div class="coupon-value">
                    ${coupon.type === 'amount' ? `¥${coupon.value}` : `${(coupon.value * 10).toFixed(1)}折`}
                </div>
            </div>
        `;
  }).join('');

  elements.couponList.innerHTML = couponsHTML;
}

// 渲染满减优惠
function renderDiscounts () {
  if (!elements.discountList) return;

  // 检查是否满足使用条件
  const validDiscounts = availableDiscounts.filter((discount) => {
    return orderData.subtotal >= discount.minAmount;
  });

  if (validDiscounts.length === 0) {
    elements.discountList.innerHTML = `
            <div style="text-align: center; padding: 1rem; color: var(--text-secondary);">
                暂无可用满减优惠
            </div>
        `;
    return;
  }

  const discountsHTML = validDiscounts.map((discount) => {
    const isSelected = orderData.selectedDiscount && orderData.selectedDiscount.id === discount.id;

    return `
            <div class="discount-item ${isSelected ? 'selected' : ''}" 
                 onclick="selectDiscount('${discount.id}')" data-discount-id="${discount.id}">
                <div class="discount-info">
                    <div class="discount-name">${discount.name}</div>
                    <div class="discount-desc">${discount.description}</div>
                    <div class="discount-condition">满${discount.minAmount}元可用</div>
                </div>
                <div class="discount-value">
                    -¥${discount.value.toFixed(2)}
                </div>
            </div>
        `;
  }).join('');

  elements.discountList.innerHTML = discountsHTML;
}

// 更新订单汇总
function updateOrderSummary () {
  elements.subtotal.textContent = `¥${orderData.subtotal.toFixed(2)}`;

  // 计算优惠券和满减优惠金额
  const couponDiscount = orderData.selectedCoupon
    ? (orderData.selectedCoupon.type === 'amount'
      ? orderData.selectedCoupon.value
      : orderData.subtotal * (1 - orderData.selectedCoupon.value))
    : 0;

  const discountActivity = orderData.selectedDiscount ? orderData.selectedDiscount.value : 0;

  // 显示/隐藏优惠券折扣行
  if (couponDiscount > 0) {
    elements.discountRow.style.display = 'flex';
    elements.couponDiscountAmount.textContent = `-¥${couponDiscount.toFixed(2)}`;
  } else {
    elements.discountRow.style.display = 'none';
  }

  // 显示/隐藏满减优惠行
  if (discountActivity > 0) {
    elements.discountActivityRow.style.display = 'flex';
    elements.discountActivityAmount.textContent = `-¥${discountActivity.toFixed(2)}`;
  } else {
    elements.discountActivityRow.style.display = 'none';
  }

  // 显示总折扣金额
  if (orderData.discount > 0) {
    elements.totalDiscountAmount.textContent = `-¥${orderData.discount.toFixed(2)}`;
  }

  elements.totalAmount.textContent = `¥${orderData.total.toFixed(2)}`;
}

// 选择支付方式
function selectPayment (element, paymentMethod) {
  // 移除其他选中状态
  document.querySelectorAll('.payment-method').forEach((method) => {
    method.classList.remove('selected');
  });

  // 添加选中状态
  element.classList.add('selected');
  orderData.selectedPayment = paymentMethod;

  // 添加选择动画
  Animation.bounce(element);

  // 显示对应的二维码
  showPaymentQRCode(paymentMethod);
}

// 显示支付二维码
function showPaymentQRCode (paymentMethod) {
  const qrSection = document.getElementById('paymentQRSection');
  const qrImage = document.getElementById('paymentQRImage');
  const qrTitle = document.getElementById('qrTitle');
  const qrAppName = document.getElementById('qrAppName');
  const qrAmount = document.getElementById('qrAmount');
  const paymentStatus = document.getElementById('paymentStatus');

  // 设置支付方式信息
  const paymentInfo = {
    alipay: {
      title: '支付宝扫码支付',
      appName: '支付宝',
      qrImage: 'assets/images/qrcode/alipay-qr.png',
      color: '#1677FF',
    },
    wechat: {
      title: '微信扫码支付',
      appName: '微信',
      qrImage: 'assets/images/qrcode/wechat-qr.png',
      color: '#07C160',
    },
    bank: {
      title: '银行卡扫码支付',
      appName: '手机银行',
      qrImage: 'assets/images/qrcode/bank-qr.png',
      color: '#FF6B35',
    },
  };

  const info = paymentInfo[paymentMethod];
  if (!info) return;

  // 更新二维码信息
  qrTitle.textContent = info.title;
  qrAppName.textContent = info.appName;
  qrAmount.textContent = `¥${orderData.total.toFixed(2)}`;

  // 设置二维码图片（这里使用占位图片，实际应用中应该从后端获取）
  qrImage.src = generateQRCode(paymentMethod, orderData.total);

  // 重置支付状态
  paymentStatus.innerHTML = `
        <div class="status-waiting">
            <i class="fas fa-hourglass-half"></i>
            等待支付中...
        </div>
    `;

  // 显示二维码区域
  qrSection.style.display = 'block';

  // 滚动到二维码区域
  setTimeout(() => {
    qrSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 100);

  // 开始检查支付状态
  startPaymentStatusCheck(paymentMethod);
}

// 生成二维码图片（模拟）
function generateQRCode (paymentMethod, amount) {
  // 这里应该调用后端API生成真实的二维码
  // 现在使用在线二维码生成服务作为示例
  const paymentData = {
    type: paymentMethod,
    amount: amount.toFixed(2),
    orderNo: generateOrderNo(),
    timestamp: Date.now(),
  };

  const dataString = JSON.stringify(paymentData);
  const encodedData = encodeURIComponent(dataString);

  // 使用二维码API生成图片
  return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodedData}`;
}

// 关闭二维码
function closeQRCode () {
  const qrSection = document.getElementById('paymentQRSection');
  qrSection.style.display = 'none';

  // 停止支付状态检查
  if (window.paymentCheckInterval) {
    clearInterval(window.paymentCheckInterval);
    window.paymentCheckInterval = null;
  }
}

// 刷新二维码
function refreshQRCode () {
  const paymentMethod = orderData.selectedPayment;
  if (!paymentMethod) return;

  const qrImage = document.getElementById('paymentQRImage');
  const paymentStatus = document.getElementById('paymentStatus');

  // 显示刷新动画
  qrImage.style.opacity = '0.5';

  setTimeout(() => {
    // 重新生成二维码
    qrImage.src = generateQRCode(paymentMethod, orderData.total) + '&t=' + Date.now();
    qrImage.style.opacity = '1';

    // 重置支付状态
    paymentStatus.innerHTML = `
            <div class="status-waiting">
                <i class="fas fa-hourglass-half"></i>
                等待支付中...
            </div>
        `;

    Utils.showToast('二维码已刷新', 'success');
  }, 500);
}

// 开始检查支付状态
function startPaymentStatusCheck (paymentMethod) {
  // 清除之前的检查
  if (window.paymentCheckInterval) {
    clearInterval(window.paymentCheckInterval);
  }

  // 每3秒检查一次支付状态
  window.paymentCheckInterval = setInterval(() => {
    checkPaymentStatus(paymentMethod);
  }, 3000);
}

// 检查支付状态（模拟）
function checkPaymentStatus (paymentMethod) {
  // 这里应该调用后端API检查真实的支付状态
  // 现在随机模拟支付成功

  // 模拟10%的概率支付成功
  if (Math.random() < 0.1) {
    // 支付成功
    handlePaymentSuccess(paymentMethod);
  }
}

// 处理支付成功
function handlePaymentSuccess (paymentMethod) {
  // 停止状态检查
  if (window.paymentCheckInterval) {
    clearInterval(window.paymentCheckInterval);
    window.paymentCheckInterval = null;
  }

  const paymentStatus = document.getElementById('paymentStatus');
  paymentStatus.innerHTML = `
        <div class="status-success">
            <i class="fas fa-check-circle"></i>
            支付成功！
        </div>
    `;

  Utils.showToast('支付成功，正在跳转...', 'success');

  // 创建订单
  setTimeout(() => {
    createOrderAfterPayment(paymentMethod);
  }, 1500);
}

// 支付成功后创建订单
function createOrderAfterPayment (paymentMethod) {
  // 生成订单号
  const orderNo = generateOrderNo();

  // 创建订单数据
  const order = {
    orderNo,
    items: orderData.items,
    subtotal: orderData.subtotal,
    discount: orderData.discount,
    coupon: orderData.selectedCoupon,
    discountActivity: orderData.selectedDiscount,
    flashSale: orderData.selectedFlashSale,
    total: orderData.total,
    paymentMethod,
    status: 'paid',
    paymentTime: new Date().toISOString(),
    createTime: new Date().toISOString(),
  };

  // 保存订单
  const orders = Storage.get('orders') || [];
  orders.unshift(order);
  Storage.set('orders', orders);

  // 清空购物车
  Storage.remove('cart');

  // 跳转到结果页
  window.location.href = `card-result.html?orderNo=${orderNo}`;
}

// 选择优惠券
function selectCoupon (couponId) {
  const coupon = availableCoupons.find((c) => c.id === couponId);
  if (!coupon) return;

  // 检查是否满足使用条件
  if (orderData.subtotal < coupon.minAmount) {
    Utils.showToast(`订单金额需满${coupon.minAmount}元才能使用此优惠券`, 'warning');
    return;
  }

  // 切换选中状态
  if (orderData.selectedCoupon && orderData.selectedCoupon.id === couponId) {
    // 取消选择
    orderData.selectedCoupon = null;
  } else {
    // 选择优惠券
    orderData.selectedCoupon = coupon;
  }

  // 重新计算金额
  calculateOrderAmount();
  updateOrderSummary();
  renderCoupons();
}

// 选择满减优惠
function selectDiscount (discountId) {
  const discount = availableDiscounts.find((d) => d.id === discountId);
  if (!discount) return;

  // 检查是否满足使用条件
  if (orderData.subtotal < discount.minAmount) {
    Utils.showToast(`订单金额需满${discount.minAmount}元才能使用此满减优惠`, 'warning');
    return;
  }

  // 切换选中状态
  if (orderData.selectedDiscount && orderData.selectedDiscount.id === discountId) {
    // 取消选择
    orderData.selectedDiscount = null;
  } else {
    // 选择满减优惠
    orderData.selectedDiscount = discount;
  }

  // 重新计算金额
  calculateOrderAmount();
  updateOrderSummary();
  renderDiscounts();
}

// 应用优惠券码
function applyCoupon () {
  const couponCode = elements.couponInput.value.trim();
  if (!couponCode) {
    Utils.showToast('请输入优惠券码', 'warning');
    return;
  }

  const coupon = availableCoupons.find((c) => c.id === couponCode);
  if (!coupon) {
    Utils.showToast('优惠券码无效', 'error');
    return;
  }

  if (orderData.subtotal < coupon.minAmount) {
    Utils.showToast(`订单金额需满${coupon.minAmount}元才能使用此优惠券`, 'warning');
    return;
  }

  orderData.selectedCoupon = coupon;
  calculateOrderAmount();
  updateOrderSummary();
  renderCoupons();

  elements.couponInput.value = '';
  Utils.showToast('优惠券应用成功', 'success');
}

// 确认支付
function confirmPayment () {
  if (orderData.items.length === 0) {
    Utils.showToast('购物车为空，请先添加商品', 'warning');
    return;
  }

  // 检查登录状态
  if (!Storage.get('userToken')) {
    Utils.showConfirm('请先登录', '支付需要登录账号，是否前往登录？', () => {
      window.location.href = 'login.html';
    });
    return;
  }

  // 显示加载状态
  elements.confirmBtn.classList.add('loading');
  elements.confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 处理中...';
  elements.confirmBtn.disabled = true;

  // 模拟支付处理
  setTimeout(() => {
    processPayment();
  }, 2000);
}

// 处理支付
function processPayment () {
  // 生成订单号
  const orderNo = generateOrderNo();

  // 创建订单数据
  const order = {
    orderNo,
    items: orderData.items,
    subtotal: orderData.subtotal,
    discount: orderData.discount,
    total: orderData.total,
    paymentMethod: orderData.selectedPayment,
    coupon: orderData.selectedCoupon,
    status: 'paid',
    createTime: new Date().toISOString(),
  };

  // 保存订单
  const orders = Storage.get('orders') || [];
  orders.unshift(order);
  Storage.set('orders', orders);

  // 清空购物车
  Storage.remove('cart');

  // 恢复按钮状态
  elements.confirmBtn.classList.remove('loading');
  elements.confirmBtn.innerHTML = '<i class="fas fa-check"></i> 支付成功';

  // 跳转到结果页
  setTimeout(() => {
    window.location.href = `card-result.html?orderNo=${orderNo}`;
  }, 1000);
}

// 生成订单号
function generateOrderNo () {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `ORD${timestamp}${random}`;
}

// 返回修改
function goBack () {
  // 检查是否是直接购买
  const directPurchase = Storage.get('directPurchase');
  if (directPurchase) {
    // 返回产品详情页
    window.location.href = `product-detail.html?id=${directPurchase.id}`;
  } else {
    // 返回购物车或首页
    const referrer = document.referrer;
    if (referrer.includes('product-detail')) {
      window.history.back();
    } else {
      window.location.href = 'index.html';
    }
  }
}

// 去购物
function goToShopping () {
  window.location.href = 'index.html';
}

// 初始化事件监听器
function initEventListeners () {
  // 优惠券输入框回车事件
  elements.couponInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      applyCoupon();
    }
  });

  // 页面卸载前保存订单数据
  window.addEventListener('beforeunload', function () {
    if (orderData.items.length > 0) {
      Storage.set('pendingOrder', orderData);
    }
  });
}

// 初始化动画
function initAnimations () {
  // 订单商品淡入
  const orderItems = document.querySelectorAll('.order-item');
  orderItems.forEach((item, index) => {
    setTimeout(() => {
      item.style.opacity = '1';
      item.style.transform = 'translateY(0)';
    }, 100 + index * 100);
  });

  // 优惠券列表动画
  const couponItems = document.querySelectorAll('.coupon-item');
  couponItems.forEach((item, index) => {
    setTimeout(() => {
      item.style.opacity = '1';
      item.style.transform = 'translateX(0)';
    }, 200 + index * 50);
  });

  // 支付方式动画
  const paymentMethods = document.querySelectorAll('.payment-method');
  paymentMethods.forEach((method, index) => {
    setTimeout(() => {
      method.style.opacity = '1';
      method.style.transform = 'translateX(0)';
    }, 300 + index * 100);
  });
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function () {
  initCheckout();
  updateCartCount();
});
