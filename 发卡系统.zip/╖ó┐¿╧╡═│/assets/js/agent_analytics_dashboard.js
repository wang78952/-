/**
 * 代理推广数据看板JavaScript功能模块
 * 处理数据可视化、图表渲染和用户交互
 */

// 全局配置
const analyticsConfig = {
  chartColors: {
    primary: '#1890ff',
    success: '#52c41a',
    warning: '#fa8c16',
    danger: '#ff4d4f',
    info: '#13c2c2',
    purple: '#722ed1',
  },
  animationDuration: 1000,
  defaultPageSize: 20,
  chartHeight: 350,
};

/**
 * 初始化所有图表组件
 */
function initCharts () {
  // 等待DOM完全加载
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeChartsInternal);
  } else {
    initializeChartsInternal();
  }
}

/**
 * 内部图表初始化函数
 */
function initializeChartsInternal () {
  // 初始化所有图表容器
  const chartContainers = document.querySelectorAll('.chart-container');

  chartContainers.forEach((container) => {
    // 确保容器有正确的高度
    container.style.height = `${analyticsConfig.chartHeight}px`;
  });

  // 注册窗口大小变化事件处理器
  window.addEventListener('resize', debounce(handleWindowResize, 200));
}

/**
 * 处理窗口大小变化，重新调整所有图表大小
 */
function handleWindowResize () {
  // 重新调整所有图表大小
  const activeCharts = window.analyticsCharts || {};

  Object.values(activeCharts).forEach((chart) => {
    if (chart && typeof chart.resize === 'function') {
      chart.resize();
    }
  });
}

/**
 * 防抖函数 - 限制函数在短时间内多次触发
 */
function debounce (func, wait) {
  let timeout;

  return function executedFunction (...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };

    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * 渲染数据趋势图表
 * @param {string} containerId - 图表容器ID
 * @param {Array} data - 图表数据
 * @param {string} metric - 展示指标类型
 */
function renderTrendChart (containerId, data, metric) {
  // 验证输入参数
  const container = document.getElementById(containerId);
  if (!container || !data || !Array.isArray(data)) {
    console.error('渲染趋势图表参数错误');
    return null;
  }

  try {
    // 初始化ECharts实例
    const chart = echarts.init(container);

    // 保存图表实例到全局变量
    if (!window.analyticsCharts) {
      window.analyticsCharts = {};
    }
    window.analyticsCharts[containerId] = chart;

    // 提取时间段标签
    const periods = data.map((item) => item.period_label);

    // 根据指标类型配置图表数据
    const chartConfig = getChartConfigByMetric(metric, data, periods);

    // 设置图表选项
    chart.setOption({
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999',
          },
        },
        formatter: chartConfig.tooltipFormatter,
      },
      legend: {
        data: chartConfig.legendData,
        bottom: 0,
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '15%',
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        data: periods,
        axisPointer: {
          type: 'shadow',
        },
        axisLabel: {
          rotate: periods.length > 7 ? 45 : 0,
          interval: Math.floor(periods.length / 10) || 0,
        },
      },
      yAxis: chartConfig.yAxisConfig,
      series: chartConfig.series,
      animationDuration: analyticsConfig.animationDuration,
    });

    return chart;
  } catch (error) {
    console.error('渲染趋势图表失败:', error);
    container.innerHTML = '<div class="chart-error">图表加载失败</div>';
    return null;
  }
}

/**
 * 根据指标类型获取图表配置
 */
function getChartConfigByMetric (metric, data, periods) {
  const colors = analyticsConfig.chartColors;

  switch (metric) {
  case 'clicks':
    return {
      legendData: ['总点击量', '独立访客'],
      yAxisConfig: {
        type: 'value',
        name: '点击量',
      },
      series: [
        {
          name: '总点击量',
          type: 'line',
          smooth: true,
          data: data.map((item) => item.total_clicks || 0),
          itemStyle: { color: colors.primary },
          lineStyle: { width: 3 },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: `${colors.primary}60` },
              { offset: 1, color: `${colors.primary}10` },
            ]),
          },
        },
        {
          name: '独立访客',
          type: 'line',
          smooth: true,
          data: data.map((item) => item.unique_clicks || 0),
          itemStyle: { color: colors.info },
          lineStyle: { width: 3 },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: `${colors.info}60` },
              { offset: 1, color: `${colors.info}10` },
            ]),
          },
        },
      ],
      tooltipFormatter: function (params) {
        const dataIndex = params[0].dataIndex;
        const dataItem = data[dataIndex];
        return `
                        <div style="font-weight: bold; margin-bottom: 5px;">${dataItem.period_label}</div>
                        <div>总点击量: ${dataItem.total_clicks || 0}</div>
                        <div>独立访客: ${dataItem.unique_clicks || 0}</div>
                    `;
      },
    };

  case 'registrations':
    return {
      legendData: ['注册量'],
      yAxisConfig: {
        type: 'value',
        name: '注册量',
      },
      series: [
        {
          name: '注册量',
          type: 'line',
          smooth: true,
          data: data.map((item) => item.registrations || 0),
          itemStyle: { color: colors.success },
          lineStyle: { width: 3 },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: `${colors.success}60` },
              { offset: 1, color: `${colors.success}10` },
            ]),
          },
        },
      ],
      tooltipFormatter: function (params) {
        const dataIndex = params[0].dataIndex;
        const dataItem = data[dataIndex];
        return `
                        <div style="font-weight: bold; margin-bottom: 5px;">${dataItem.period_label}</div>
                        <div>注册量: ${dataItem.registrations || 0}</div>
                    `;
      },
    };

  case 'orders':
    return {
      legendData: ['订单量', '订单金额'],
      yAxisConfig: [
        {
          type: 'value',
          name: '订单量',
          position: 'left',
        },
        {
          type: 'value',
          name: '订单金额(¥)',
          position: 'right',
          axisLabel: {
            formatter: function (value) {
              return value.toFixed(0);
            },
          },
        },
      ],
      series: [
        {
          name: '订单量',
          type: 'line',
          yAxisIndex: 0,
          smooth: true,
          data: data.map((item) => item.orders || 0),
          itemStyle: { color: colors.warning },
          lineStyle: { width: 3 },
        },
        {
          name: '订单金额',
          type: 'bar',
          yAxisIndex: 1,
          data: data.map((item) => (item.order_amount || 0).toFixed(0)),
          itemStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: `${colors.purple}80` },
              { offset: 1, color: `${colors.purple}40` },
            ]),
          },
        },
      ],
      tooltipFormatter: function (params) {
        const dataIndex = params[0].dataIndex;
        const dataItem = data[dataIndex];
        return `
                        <div style="font-weight: bold; margin-bottom: 5px;">${dataItem.period_label}</div>
                        <div>订单量: ${dataItem.orders || 0}</div>
                        <div>订单金额: ¥${(dataItem.order_amount || 0).toFixed(2)}</div>
                    `;
      },
    };

  case 'commission':
    return {
      legendData: ['佣金收入'],
      yAxisConfig: {
        type: 'value',
        name: '佣金金额(¥)',
        axisLabel: {
          formatter: function (value) {
            return value.toFixed(2);
          },
        },
      },
      series: [
        {
          name: '佣金收入',
          type: 'line',
          smooth: true,
          data: data.map((item) => (item.commission_amount || 0).toFixed(2)),
          itemStyle: { color: colors.danger },
          lineStyle: { width: 3 },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: `${colors.danger}60` },
              { offset: 1, color: `${colors.danger}10` },
            ]),
          },
        },
      ],
      tooltipFormatter: function (params) {
        const dataIndex = params[0].dataIndex;
        const dataItem = data[dataIndex];
        return `
                        <div style="font-weight: bold; margin-bottom: 5px;">${dataItem.period_label}</div>
                        <div>佣金收入: ¥${(dataItem.commission_amount || 0).toFixed(2)}</div>
                    `;
      },
    };

  default:
    return {
      legendData: ['数据'],
      yAxisConfig: {
        type: 'value',
      },
      series: [],
      tooltipFormatter: '',
    };
  }
}

/**
 * 渲染饼图
 * @param {string} containerId - 容器ID
 * @param {Array} data - 图表数据
 * @param {Object} options - 可选配置
 */
function renderPieChart (containerId, data, options = {}) {
  const container = document.getElementById(containerId);
  if (!container || !data || !Array.isArray(data)) {
    console.error('渲染饼图参数错误');
    return null;
  }

  try {
    const chart = echarts.init(container);

    // 保存图表实例
    if (!window.analyticsCharts) {
      window.analyticsCharts = {};
    }
    window.analyticsCharts[containerId] = chart;

    // 默认配置
    const defaultOptions = {
      title: {
        text: '',
        left: 'center',
      },
      radius: ['40%', '70%'],
      center: ['50%', '55%'],
      showLabels: true,
      maxItems: 10,
    };

    // 合并配置选项
    const finalOptions = { ...defaultOptions, ...options };

    // 限制最大数据项数量
    const displayData = data.slice(0, finalOptions.maxItems);

    // 准备图表数据
    const chartData = displayData.map((item, index) => ({
      name: item.name || `数据项${index + 1}`,
      value: item.value,
    }));

    // 图表配置
    const pieChartOption = {
      title: finalOptions.title,
      tooltip: {
        trigger: 'item',
        formatter: function (params) {
          return `${params.name}<br/>${params.value} (${params.percent}%)`;
        },
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        bottom: '10%',
        formatter: function (name) {
          const dataItem = chartData.find((item) => item.name === name);
          if (dataItem) {
            const total = chartData.reduce((sum, item) => sum + item.value, 0);
            const percent = ((dataItem.value / total) * 100).toFixed(1);
            return `${name}: ${percent}%`;
          }
          return name;
        },
      },
      series: [
        {
          name: finalOptions.title.text || '数据分布',
          type: 'pie',
          radius: finalOptions.radius,
          center: finalOptions.center,
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2,
          },
          label: {
            show: finalOptions.showLabels,
            formatter: '{b}\n{d}%',
          },
          emphasis: {
            label: {
              show: true,
              fontSize: '16',
              fontWeight: 'bold',
            },
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
          },
          data: chartData,
        },
      ],
    };

    chart.setOption(pieChartOption);
    return chart;
  } catch (error) {
    console.error('渲染饼图失败:', error);
    container.innerHTML = '<div class="chart-error">图表加载失败</div>';
    return null;
  }
}

/**
 * 渲染柱状图
 * @param {string} containerId - 容器ID
 * @param {Array} categories - 分类数据
 * @param {Array} seriesData - 系列数据
 * @param {Object} options - 可选配置
 */
function renderBarChart (containerId, categories, seriesData, options = {}) {
  const container = document.getElementById(containerId);
  if (!container || !categories || !seriesData) {
    console.error('渲染柱状图参数错误');
    return null;
  }

  try {
    const chart = echarts.init(container);

    // 保存图表实例
    if (!window.analyticsCharts) {
      window.analyticsCharts = {};
    }
    window.analyticsCharts[containerId] = chart;

    // 默认配置
    const defaultOptions = {
      title: '',
      xAxisName: '',
      yAxisName: '',
      barWidth: '60%',
      isHorizontal: false,
      showGrid: true,
    };

    // 合并配置选项
    const finalOptions = { ...defaultOptions, ...options };

    // 准备系列数据
    const chartSeries = seriesData.map((series, index) => ({
      name: series.name || `系列${index + 1}`,
      type: 'bar',
      data: series.data,
      itemStyle: series.itemStyle || {
        color: analyticsConfig.chartColors[Object.keys(analyticsConfig.chartColors)[index] || 'primary'],
      },
      barWidth: finalOptions.barWidth,
    }));

    // 图表配置
    const chartOption = {
      title: {
        text: finalOptions.title,
        left: 'center',
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
      },
      legend: {
        data: seriesData.map((s) => s.name || `系列${seriesData.indexOf(s) + 1}`),
        bottom: 0,
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: finalOptions.isHorizontal ? '30%' : '15%',
        top: '15%',
        containLabel: true,
      },
    };

    if (finalOptions.isHorizontal) {
      // 水平柱状图
      chartOption.xAxis = {
        type: 'value',
        name: finalOptions.yAxisName,
        axisLabel: {
          formatter: finalOptions.xAxisFormatter || null,
        },
      };
      chartOption.yAxis = {
        type: 'category',
        data: categories,
        name: finalOptions.xAxisName,
        axisLabel: {
          rotate: categories.length > 10 ? 30 : 0,
        },
      };
    } else {
      // 垂直柱状图
      chartOption.xAxis = {
        type: 'category',
        data: categories,
        name: finalOptions.xAxisName,
        axisLabel: {
          rotate: categories.length > 8 ? 45 : 0,
        },
      };
      chartOption.yAxis = {
        type: 'value',
        name: finalOptions.yAxisName,
        axisLabel: {
          formatter: finalOptions.yAxisFormatter || null,
        },
      };
    }

    chartOption.series = chartSeries;

    // 设置网格线
    if (!finalOptions.showGrid) {
      if (chartOption.xAxis) chartOption.xAxis.splitLine = { show: false };
      if (chartOption.yAxis) chartOption.yAxis.splitLine = { show: false };
    }

    chart.setOption(chartOption);
    return chart;
  } catch (error) {
    console.error('渲染柱状图失败:', error);
    container.innerHTML = '<div class="chart-error">图表加载失败</div>';
    return null;
  }
}

/**
 * 渲染转化率漏斗图
 * @param {string} containerId - 容器ID
 * @param {Array} funnelData - 漏斗数据
 * @param {Object} options - 可选配置
 */
function renderFunnelChart (containerId, funnelData, options = {}) {
  const container = document.getElementById(containerId);
  if (!container || !funnelData || !Array.isArray(funnelData)) {
    console.error('渲染漏斗图参数错误');
    return null;
  }

  try {
    const chart = echarts.init(container);

    // 保存图表实例
    if (!window.analyticsCharts) {
      window.analyticsCharts = {};
    }
    window.analyticsCharts[containerId] = chart;

    // 默认配置
    const defaultOptions = {
      title: { text: '转化漏斗' },
      funnelSize: ['60%', '80%'],
    };

    // 合并配置选项
    const finalOptions = { ...defaultOptions, ...options };

    // 准备漏斗图数据
    const chartData = funnelData.map((stage, index) => ({
      name: stage.name,
      value: stage.value,
      itemStyle: stage.itemStyle || {
        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
          { offset: 0, color: analyticsConfig.chartColors.primary },
          { offset: 1, color: analyticsConfig.chartColors.info },
        ]),
      },
    }));

    // 图表配置
    const funnelOption = {
      title: {
        text: finalOptions.title.text,
        left: 'center',
      },
      tooltip: {
        trigger: 'item',
        formatter: function (params) {
          const index = params.dataIndex;
          let prevStageValue = chartData[0].value;

          if (index > 0) {
            prevStageValue = chartData[index - 1].value;
          }

          const conversionRate = ((params.value / prevStageValue) * 100).toFixed(1);
          return `${params.name}<br/>${params.value}<br/>转化率: ${conversionRate}%`;
        },
      },
      series: [
        {
          name: finalOptions.title.text,
          type: 'funnel',
          left: '10%',
          top: 60,
          bottom: 60,
          width: '80%',
          min: 0,
          max: 100,
          minSize: '0%',
          maxSize: '100%',
          sort: 'descending',
          gap: 2,
          label: {
            show: true,
            position: 'inside',
          },
          labelLine: {
            length: 10,
            lineStyle: {
              width: 1,
              type: 'solid',
            },
          },
          itemStyle: {
            borderColor: '#fff',
            borderWidth: 1,
          },
          emphasis: {
            label: {
              fontSize: 20,
            },
          },
          data: chartData,
        },
      ],
    };

    chart.setOption(funnelOption);
    return chart;
  } catch (error) {
    console.error('渲染漏斗图失败:', error);
    container.innerHTML = '<div class="chart-error">图表加载失败</div>';
    return null;
  }
}

/**
 * 格式化数据为图表友好格式
 * @param {Array} rawData - 原始数据
 * @param {Object} mapping - 字段映射配置
 * @returns {Array} 格式化后的数据
 */
function formatChartData (rawData, mapping) {
  if (!Array.isArray(rawData)) {
    return [];
  }

  return rawData.map((item) => {
    const formattedItem = {};

    Object.entries(mapping || {}).forEach(([targetKey, sourceKey]) => {
      formattedItem[targetKey] = item[sourceKey] !== undefined ? item[sourceKey] : '';
    });

    return formattedItem;
  });
}

/**
 * 处理数据表格渲染
 * @param {string} tableId - 表格ID
 * @param {Array} data - 表格数据
 * @param {Array} columns - 列配置
 */
function renderDataTable (tableId, data, columns) {
  const table = document.getElementById(tableId);
  const tbody = table ? table.querySelector('tbody') : null;

  if (!table || !tbody || !Array.isArray(data) || !Array.isArray(columns)) {
    console.error('渲染数据表格参数错误');
    return;
  }

  // 清空表格
  tbody.innerHTML = '';

  // 渲染数据行
  if (data.length === 0) {
    const emptyRow = document.createElement('tr');
    emptyRow.innerHTML = `<td colspan="${columns.length}" style="text-align: center; padding: 20px;">暂无数据</td>`;
    tbody.appendChild(emptyRow);
    return;
  }

  data.forEach((rowData, rowIndex) => {
    const row = document.createElement('tr');

    // 设置行样式
    row.className = rowIndex % 2 === 0 ? 'even-row' : 'odd-row';

    // 渲染单元格
    columns.forEach((column) => {
      const cell = document.createElement('td');

      // 获取单元格数据
      const cellData = rowData[column.field] !== undefined ? rowData[column.field] : '';

      // 应用格式化器
      if (column.formatter && typeof column.formatter === 'function') {
        cell.innerHTML = column.formatter(cellData, rowData, rowIndex);
      } else if (column.type === 'date' && cellData) {
        cell.textContent = formatDateTime(cellData);
      } else if (column.type === 'currency' && typeof cellData === 'number') {
        cell.textContent = `¥${cellData.toFixed(2)}`;
      } else if (column.type === 'status' && cellData) {
        // 渲染状态徽章
        cell.innerHTML = renderStatusBadge(cellData);
      } else {
        cell.textContent = cellData;
      }

      // 应用单元格样式
      if (column.style) {
        Object.entries(column.style).forEach(([key, value]) => {
          cell.style[key] = value;
        });
      }

      row.appendChild(cell);
    });

    tbody.appendChild(row);
  });
}

/**
 * 渲染状态徽章
 * @param {string} status - 状态值
 * @returns {string} HTML字符串
 */
function renderStatusBadge (status) {
  const statusConfig = {
    pending: { text: '待结算', class: 'badge-pending' },
    settled: { text: '已结算', class: 'badge-settled' },
    rejected: { text: '已拒绝', class: 'badge-rejected' },
    active: { text: '活跃', class: 'badge-active' },
    inactive: { text: '非活跃', class: 'badge-inactive' },
  };

  const config = statusConfig[status] || { text: status, class: 'badge-default' };
  return `<span class="status-badge ${config.class}">${config.text}</span>`;
}

/**
 * 格式化日期时间
 * @param {string|Date} dateTime - 日期时间值
 * @returns {string} 格式化后的日期时间字符串
 */
function formatDateTime (dateTime) {
  if (!dateTime) return '';

  try {
    const date = typeof dateTime === 'string' ? new Date(dateTime) : dateTime;

    if (isNaN(date.getTime())) return '';

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error('格式化日期时间失败:', error);
    return '';
  }
}

/**
 * 格式化日期
 * @param {string|Date} date - 日期值
 * @returns {string} 格式化后的日期字符串
 */
function formatDate (date) {
  if (!date) return '';

  try {
    const dateObj = typeof date === 'string' ? new Date(date) : date;

    if (isNaN(dateObj.getTime())) return '';

    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const day = String(dateObj.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  } catch (error) {
    console.error('格式化日期失败:', error);
    return '';
  }
}

/**
 * 显示加载状态
 * @param {string} elementId - 元素ID
 */
function showLoading (elementId) {
  const element = document.getElementById(elementId);
  if (!element) return;

  element.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%;">
            <div class="loading-spinner"></div>
            <div style="margin-top: 10px; color: #666;">加载中...</div>
        </div>
    `;
}

/**
 * 显示错误信息
 * @param {string} elementId - 元素ID
 * @param {string} message - 错误信息
 */
function showError (elementId, message = '加载失败，请稍后重试') {
  const element = document.getElementById(elementId);
  if (!element) return;

  element.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: ${analyticsConfig.chartColors.danger};">
            <i class="fa fa-exclamation-circle" style="font-size: 32px; margin-bottom: 10px;"></i>
            <div>${message}</div>
        </div>
    `;
}

/**
 * 导出表格数据为CSV格式
 * @param {Array} data - 要导出的数据
 * @param {Array} columns - 列配置
 * @param {string} filename - 文件名
 */
function exportToCSV (data, columns, filename = 'export.csv') {
  if (!Array.isArray(data) || !Array.isArray(columns) || data.length === 0) {
    alert('没有数据可导出');
    return;
  }

  // 准备CSV内容
  let csvContent = '';

  // 添加列标题
  const headers = columns.map((col) => col.title || col.field);
  csvContent += headers.map((h) => `"${h}"`).join(',') + '\n';

  // 添加数据行
  data.forEach((row) => {
    const rowValues = columns.map((col) => {
      let value = row[col.field] !== undefined ? row[col.field] : '';

      // 应用格式化
      if (col.type === 'date' && value) {
        value = formatDateTime(value);
      } else if (col.type === 'currency' && typeof value === 'number') {
        value = `¥${value.toFixed(2)}`;
      } else if (col.type === 'status' && value) {
        const statusConfig = {
          pending: '待结算',
          settled: '已结算',
          rejected: '已拒绝',
          active: '活跃',
          inactive: '非活跃',
        };
        value = statusConfig[value] || value;
      }

      // 确保CSV格式正确
      return `"${String(value).replace(/"/g, '""')}"`;
    });

    csvContent += rowValues.join(',') + '\n';
  });

  // 创建下载链接
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');

  if (link.download !== undefined) { // 支持Blob URLs的浏览器
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } else {
    // 不支持Blob URLs的浏览器
    alert('您的浏览器不支持文件下载，请手动复制表格数据');
  }
}

/**
 * 初始化分页控件
 * @param {string} containerId - 容器ID
 * @param {number} currentPage - 当前页码
 * @param {number} totalPages - 总页数
 * @param {Function} onPageChange - 页码变化回调函数
 */
function initPagination (containerId, currentPage, totalPages, onPageChange) {
  const container = document.getElementById(containerId);
  if (!container || typeof onPageChange !== 'function') return;

  // 清空容器
  container.innerHTML = '';

  // 验证页码范围
  currentPage = Math.max(1, Math.min(currentPage, totalPages));

  // 生成分页按钮
  const pageInfo = document.createElement('span');
  pageInfo.textContent = `第 ${currentPage} / ${totalPages} 页`;
  pageInfo.className = 'pagination-info';

  // 上一页按钮
  const prevButton = document.createElement('button');
  prevButton.textContent = '上一页';
  prevButton.className = 'pagination-button prev-page';
  prevButton.disabled = currentPage === 1;
  prevButton.addEventListener('click', () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  });

  // 下一页按钮
  const nextButton = document.createElement('button');
  nextButton.textContent = '下一页';
  nextButton.className = 'pagination-button next-page';
  nextButton.disabled = currentPage === totalPages;
  nextButton.addEventListener('click', () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  });

  // 添加元素到容器
  container.appendChild(prevButton);
  container.appendChild(pageInfo);
  container.appendChild(nextButton);
}

/**
 * 计算两个日期之间的天数差
 * @param {Date} date1 - 第一个日期
 * @param {Date} date2 - 第二个日期
 * @returns {number} 天数差
 */
function getDaysDifference (date1, date2) {
  const oneDay = 24 * 60 * 60 * 1000;
  const diffMs = Math.abs(date2 - date1);
  return Math.round(diffMs / oneDay);
}

/**
 * 获取指定时间范围的日期对象
 * @param {string} range - 时间范围标识符 (today, yesterday, 7days, 30days)
 * @returns {Object} 包含开始和结束日期的对象
 */
function getDateRange (range) {
  const today = new Date();
  const endDate = new Date(today);
  const startDate = new Date(today);

  // 重置时间为当天开始/结束
  endDate.setHours(23, 59, 59, 999);

  switch (range) {
  case 'today':
    startDate.setHours(0, 0, 0, 0);
    break;

  case 'yesterday':
    startDate.setDate(today.getDate() - 1);
    startDate.setHours(0, 0, 0, 0);
    endDate.setDate(today.getDate() - 1);
    endDate.setHours(23, 59, 59, 999);
    break;

  case '7days':
    startDate.setDate(today.getDate() - 6);
    startDate.setHours(0, 0, 0, 0);
    break;

  case '30days':
    startDate.setDate(today.getDate() - 29);
    startDate.setHours(0, 0, 0, 0);
    break;

  default:
    startDate.setDate(today.getDate() - 29);
    startDate.setHours(0, 0, 0, 0);
  }

  return {
    start: startDate,
    end: endDate,
    startFormatted: formatDate(startDate),
    endFormatted: formatDate(endDate),
  };
}

/**
 * 检查浏览器是否支持所需功能
 * @returns {Object} 功能支持状态对象
 */
function checkBrowserSupport () {
  return {
    canvas: typeof HTMLCanvasElement !== 'undefined',
    fetch: typeof fetch !== 'undefined',
    blob: typeof Blob !== 'undefined',
    webWorker: typeof Worker !== 'undefined',
  };
}

/**
 * 执行异步数据请求
 * @param {string} url - 请求URL
 * @param {Object} options - 请求选项
 * @returns {Promise} 包含响应数据的Promise
 */
async function fetchData (url, options = {}) {
  // 默认请求选项
  const defaultOptions = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    credentials: 'same-origin',
  };

  // 合并请求选项
  const finalOptions = { ...defaultOptions, ...options };

  try {
    const response = await fetch(url, finalOptions);

    if (!response.ok) {
      throw new Error(`HTTP错误! 状态: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('数据请求失败:', error);
    throw error;
  }
}

// 初始化模块
(function () {
  // 检查浏览器支持
  const support = checkBrowserSupport();

  if (!support.canvas) {
    console.warn('您的浏览器不支持Canvas，某些图表功能可能无法使用');
  }

  // 暴露全局API
  window.analyticsDashboard = {
    initCharts,
    renderTrendChart,
    renderPieChart,
    renderBarChart,
    renderFunnelChart,
    renderDataTable,
    exportToCSV,
    initPagination,
    getDateRange,
    fetchData,
    showLoading,
    showError,
    formatDateTime,
    formatDate,
    checkBrowserSupport,
  };

  // 自动初始化图表
  initCharts();
})();
