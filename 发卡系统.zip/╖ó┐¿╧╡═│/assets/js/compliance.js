/**
 * 合规性管理前端JavaScript
 */

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function () {
  loadComplianceStatistics();
  loadAmlScreenings();
  loadKycVerifications();
  loadAmlAlerts();
  loadComplianceEvents();
  loadRetentionPolicies();
  loadComplianceReports();
  loadComplianceConfig();

  // 绑定表单提交事件
  bindFormEvents();
});

/**
 * 加载合规性统计数据
 */
async function loadComplianceStatistics () {
  try {
    const response = await dataLoader.get('api/compliance/index.php', {
      params: { action: 'statistics' },
      showLoading: false,
      defaultErrorMessage: '加载合规统计数据失败',
    });

    document.getElementById('complianceScore').textContent = response.data.compliance_score + '%';
    document.getElementById('totalPolicies').textContent = response.data.total_policies;
    document.getElementById('activePolicies').textContent = response.data.active_policies;
    document.getElementById('violationsCount').textContent = response.data.violations_count;
  } catch (error) {
    console.error('加载合规统计数据失败:', error);
  }
}

/**
 * 刷新统计数据
 */
function refreshStatistics () {
  const button = event.target;
  const originalText = button.innerHTML;
  button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 刷新中...';
  button.disabled = true;

  loadComplianceStatistics();

  setTimeout(() => {
    button.innerHTML = originalText;
    button.disabled = false;
    showToast('统计数据已刷新', 'success');
  }, 1000);
}

/**
 * 加载AML筛查记录
 */
async function loadAmlScreenings () {
  try {
    const response = await dataLoader.get('api/compliance/aml_screenings.php', {
      showLoading: true,
      defaultErrorMessage: '加载AML筛查记录失败',
    });

    const tbody = document.getElementById('amlTableBody');
    tbody.innerHTML = '';

    response.data.forEach((screening) => {
      const row = createAmlScreeningRow(screening);
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('加载AML筛查记录失败:', error);
  }
}

/**
 * 创建AML筛查行
 */
function createAmlScreeningRow (screening) {
  const row = document.createElement('tr');
  row.innerHTML = `
        <td>${screening.user_id}</td>
        <td>
            <span class="badge bg-${getRiskLevelColor(screening.risk_score)}">
                ${screening.risk_score}
            </span>
        </td>
        <td>${screening.risk_level}</td>
        <td>${screening.screening_factors}</td>
        <td>${screening.screening_time}</td>
        <td>
            <button class="btn btn-sm btn-info" onclick="viewAmlScreening('${screening.id}')">
                <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-warning" onclick="reScreenUser('${screening.user_id}')">
                <i class="fas fa-redo"></i>
            </button>
        </td>
    `;
  return row;
}

/**
 * 加载KYC验证记录
 */
async function loadKycVerifications () {
  try {
    const response = await dataLoader.get('api/compliance/kyc_verifications.php', {
      showLoading: true,
      defaultErrorMessage: '加载KYC验证记录失败',
    });

    const tbody = document.getElementById('kycTableBody');
    tbody.innerHTML = '';

    response.data.forEach((verification) => {
      const row = createKycVerificationRow(verification);
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('加载KYC验证记录失败:', error);
  }
}

/**
 * 创建KYC验证行
 */
function createKycVerificationRow (verification) {
  const row = document.createElement('tr');
  row.innerHTML = `
        <td>${verification.user_id}</td>
        <td>${verification.real_name}</td>
        <td>${verification.id_number}</td>
        <td>${verification.phone_number}</td>
        <td>${verification.email}</td>
        <td>
            <span class="badge bg-${getVerificationScoreColor(verification.verification_score)}">
                ${verification.verification_score}
            </span>
        </td>
        <td>
            <span class="badge bg-${getStatusColor(verification.status)}">
                ${verification.status}
            </span>
        </td>
        <td>${verification.created_at}</td>
        <td>
            <button class="btn btn-sm btn-info" onclick="viewKycVerification('${verification.id}')">
                <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-warning" onclick="reVerifyUser('${verification.user_id}')">
                <i class="fas fa-redo"></i>
            </button>
        </td>
    `;
  return row;
}

/**
 * 加载AML警报
 */
async function loadAmlAlerts () {
  try {
    const response = await dataLoader.get('api/compliance/aml_alerts.php', {
      showLoading: true,
      defaultErrorMessage: '加载AML警报失败',
    });

    const tbody = document.getElementById('alertsTableBody');
    tbody.innerHTML = '';

    response.data.forEach((alert) => {
      const row = createAmlAlertRow(alert);
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('加载AML警报失败:', error);
  }
}

/**
 * 创建AML警报行
 */
function createAmlAlertRow (alert) {
  const row = document.createElement('tr');
  row.innerHTML = `
        <td>${alert.alert_id}</td>
        <td>${alert.user_id}</td>
        <td>${alert.alert_type}</td>
        <td>
            <span class="badge bg-${getRiskLevelColor(alert.risk_score)}">
                ${alert.risk_score}
            </span>
        </td>
        <td>
            <span class="badge bg-${getAlertStatusColor(alert.status)}">
                ${alert.status}
            </span>
        </td>
        <td>${alert.assigned_to || '-'}</td>
        <td>${alert.created_at}</td>
        <td>
            <button class="btn btn-sm btn-primary" onclick="processAmlAlertModal('${alert.alert_id}')">
                <i class="fas fa-cog"></i> 处理
            </button>
            <button class="btn btn-sm btn-info" onclick="viewAmlAlert('${alert.alert_id}')">
                <i class="fas fa-eye"></i>
            </button>
        </td>
    `;
  return row;
}

/**
 * 加载合规事件
 */
async function loadComplianceEvents () {
  try {
    const response = await dataLoader.get('api/compliance/compliance_events.php', {
      showLoading: true,
      defaultErrorMessage: '加载合规事件失败',
    });

    const tbody = document.getElementById('eventsTableBody');
    tbody.innerHTML = '';

    response.data.forEach((event) => {
      const row = createComplianceEventRow(event);
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('加载合规事件失败:', error);
  }
}

/**
 * 创建合规事件行
 */
function createComplianceEventRow (event) {
  const row = document.createElement('tr');
  row.innerHTML = `
        <td>${event.event_type}</td>
        <td>
            <span class="badge bg-${getSeverityColor(event.severity)}">
                ${event.severity}
            </span>
        </td>
        <td>${event.description}</td>
        <td>${event.user_id || '-'}</td>
        <td>${event.event_time}</td>
    `;
  return row;
}

/**
 * 加载数据留存策略
 */
async function loadRetentionPolicies () {
  try {
    const response = await dataLoader.get('api/compliance/retention_policies.php', {
      showLoading: true,
      defaultErrorMessage: '加载保留策略失败',
    });

    const tbody = document.getElementById('retentionTableBody');
    tbody.innerHTML = '';

    response.data.forEach((policy) => {
      const row = createRetentionPolicyRow(policy);
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('加载保留策略失败:', error);
  }
}

/**
 * 创建数据留存策略行
 */
function createRetentionPolicyRow (policy) {
  const row = document.createElement('tr');
  row.innerHTML = `
        <td>${policy.policy_name}</td>
        <td>${policy.table_name}</td>
        <td>${policy.date_column}</td>
        <td>${policy.retention_days}</td>
        <td>
            <span class="badge bg-${getActionTypeColor(policy.action_type)}">
                ${policy.action_type}
            </span>
        </td>
        <td>${policy.execution_frequency}</td>
        <td>
            <span class="badge bg-${policy.status === 'ACTIVE' ? 'success' : 'secondary'}">
                ${policy.status}
            </span>
        </td>
        <td>${policy.last_execution || '-'}</td>
        <td>
            <button class="btn btn-sm btn-primary" onclick="editRetentionPolicy('${policy.id}')">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-success" onclick="executePolicy('${policy.id}')">
                <i class="fas fa-play"></i>
            </button>
            <button class="btn btn-sm btn-danger" onclick="deleteRetentionPolicy('${policy.id}')">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
  return row;
}

/**
 * 加载合规报告
 */
async function loadComplianceReports () {
  try {
    const response = await dataLoader.get('api/compliance/compliance_reports.php', {
      showLoading: true,
      defaultErrorMessage: '加载合规报告失败',
    });

    const tbody = document.getElementById('reportsTableBody');
    tbody.innerHTML = '';

    response.data.forEach((report) => {
      const row = createComplianceReportRow(report);
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('加载合规报告失败:', error);
  }
}

/**
 * 创建合规报告行
 */
function createComplianceReportRow (report) {
  const row = document.createElement('tr');
  row.innerHTML = `
        <td>${report.report_id}</td>
        <td>${report.report_type}</td>
        <td>${report.start_date}</td>
        <td>${report.end_date}</td>
        <td>
            <span class="badge bg-${getReportStatusColor(report.status)}">
                ${report.status}
            </span>
        </td>
        <td>${report.file_size || '-'}</td>
        <td>${report.generated_at}</td>
        <td>
            <button class="btn btn-sm btn-primary" onclick="downloadReport('${report.report_id}')" ${report.status !== 'COMPLETED' ? 'disabled' : ''}>
                <i class="fas fa-download"></i> 下载
            </button>
            <button class="btn btn-sm btn-info" onclick="viewReport('${report.report_id}')">
                <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-danger" onclick="deleteReport('${report.report_id}')">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
  return row;
}

/**
 * 加载合规配置
 */
async function loadComplianceConfig () {
  try {
    const response = await dataLoader.get('api/compliance/config.php', {
      showLoading: false,
      defaultErrorMessage: '加载合规配置失败',
    });

    const config = response.data;
    const form = document.getElementById('configForm');

    // 填充表单数据
    form.aml_risk_threshold.value = config.aml_risk_threshold || 60;
    form.kyc_verification_threshold.value = config.kyc_verification_threshold || 80;
    form.default_retention_days.value = config.default_retention_days || 2555;
    form.auto_generate_reports.value = config.auto_generate_reports || 'enabled';
    form.high_risk_regions.value = config.high_risk_regions || '';
    form.monitoring_keywords.value = config.monitoring_keywords || '';
  } catch (error) {
    console.error('加载合规配置失败:', error);
  }
}

/**
 * 绑定表单事件
 */
function bindFormEvents () {
  // 合规配置表单提交
  document.getElementById('configForm').addEventListener('submit', function (e) {
    e.preventDefault();
    saveComplianceConfig();
  });
}

/**
 * 显示AML筛查模态框
 */
function showAmlScreeningModal () {
  const modal = new bootstrap.Modal(document.getElementById('amlScreeningModal'));
  document.getElementById('amlScreeningForm').reset();
  modal.show();
}

/**
 * 执行AML筛查
 */
function performAmlScreening () {
  const form = document.getElementById('amlScreeningForm');
  const formData = new FormData(form);

  fetch('api/compliance/perform_aml_screening.php', {
    method: 'POST',
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        bootstrap.Modal.getInstance(document.getElementById('amlScreeningModal')).hide();
        showToast('AML筛查执行成功', 'success');
        loadAmlScreenings();
        loadComplianceStatistics();
      } else {
        showToast('AML筛查执行失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('AML筛查请求失败:', error);
      showToast('AML筛查请求失败', 'error');
    });
}

/**
 * 显示KYC验证模态框
 */
function showKycModal () {
  const modal = new bootstrap.Modal(document.getElementById('kycModal'));
  document.getElementById('kycForm').reset();
  modal.show();
}

/**
 * 执行KYC验证
 */
function performKycVerification () {
  const form = document.getElementById('kycForm');
  const formData = new FormData(form);

  fetch('api/compliance/perform_kyc_verification.php', {
    method: 'POST',
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        bootstrap.Modal.getInstance(document.getElementById('kycModal')).hide();
        showToast('KYC验证提交成功', 'success');
        loadKycVerifications();
        loadComplianceStatistics();
      } else {
        showToast('KYC验证提交失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('KYC验证请求失败:', error);
      showToast('KYC验证请求失败', 'error');
    });
}

/**
 * 显示AML警报处理模态框
 */
function processAmlAlertModal (alertId) {
  const modal = new bootstrap.Modal(document.getElementById('alertProcessModal'));
  const form = document.getElementById('alertProcessForm');
  form.reset();
  form.alert_id.value = alertId;
  modal.show();
}

/**
 * 处理AML警报
 */
function processAmlAlert () {
  const form = document.getElementById('alertProcessForm');
  const formData = new FormData(form);

  fetch('api/compliance/process_aml_alert.php', {
    method: 'POST',
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        bootstrap.Modal.getInstance(document.getElementById('alertProcessModal')).hide();
        showToast('AML警报处理成功', 'success');
        loadAmlAlerts();
      } else {
        showToast('AML警报处理失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('AML警报处理请求失败:', error);
      showToast('AML警报处理请求失败', 'error');
    });
}

/**
 * 显示数据留存策略模态框
 */
function showRetentionModal () {
  const modal = new bootstrap.Modal(document.getElementById('retentionModal'));
  document.getElementById('retentionForm').reset();
  modal.show();
}

/**
 * 创建数据留存策略
 */
function createRetentionPolicy () {
  const form = document.getElementById('retentionForm');
  const formData = new FormData(form);

  fetch('api/compliance/create_retention_policy.php', {
    method: 'POST',
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        bootstrap.Modal.getInstance(document.getElementById('retentionModal')).hide();
        showToast('数据留存策略创建成功', 'success');
        loadRetentionPolicies();
        loadComplianceStatistics();
      } else {
        showToast('数据留存策略创建失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('数据留存策略创建请求失败:', error);
      showToast('数据留存策略创建请求失败', 'error');
    });
}

/**
 * 执行数据留存策略
 */
function executeRetentionPolicies () {
  if (!confirm('确定要执行所有数据留存策略吗？此操作不可恢复。')) {
    return;
  }

  fetch('api/compliance/execute_retention_policies.php', {
    method: 'POST',
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showToast('数据留存策略执行成功', 'success');
        loadRetentionPolicies();
      } else {
        showToast('数据留存策略执行失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('数据留存策略执行请求失败:', error);
      showToast('数据留存策略执行请求失败', 'error');
    });
}

/**
 * 显示报告生成模态框
 */
function showReportModal () {
  const modal = new bootstrap.Modal(document.getElementById('reportModal'));
  document.getElementById('reportForm').reset();
  modal.show();
}

/**
 * 生成合规报告
 */
function generateComplianceReport () {
  const form = document.getElementById('reportForm');
  const formData = new FormData(form);

  fetch('api/compliance/generate_compliance_report.php', {
    method: 'POST',
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        bootstrap.Modal.getInstance(document.getElementById('reportModal')).hide();
        showToast('合规报告生成成功', 'success');
        loadComplianceReports();
      } else {
        showToast('合规报告生成失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('合规报告生成请求失败:', error);
      showToast('合规报告生成请求失败', 'error');
    });
}

/**
 * 生成报告（快捷按钮）
 */
function generateReport () {
  showReportModal();
}

/**
 * 保存合规配置
 */
function saveComplianceConfig () {
  const form = document.getElementById('configForm');
  const formData = new FormData(form);

  fetch('api/compliance/save_config.php', {
    method: 'POST',
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showToast('合规配置保存成功', 'success');
      } else {
        showToast('合规配置保存失败: ' + data.message, 'error');
      }
    })
    .catch((error) => {
      console.error('合规配置保存请求失败:', error);
      showToast('合规配置保存请求失败', 'error');
    });
}

/**
 * 下载报告
 */
function downloadReport (reportId) {
  window.open(`api/compliance/download_report.php?report_id=${reportId}`);
}

/**
 * 辅助函数：获取风险等级颜色
 */
function getRiskLevelColor (score) {
  if (score >= 80) return 'danger';
  if (score >= 60) return 'warning';
  return 'success';
}

/**
 * 辅助函数：获取验证分数颜色
 */
function getVerificationScoreColor (score) {
  if (score >= 90) return 'success';
  if (score >= 70) return 'info';
  return 'warning';
}

/**
 * 辅助函数：获取状态颜色
 */
function getStatusColor (status) {
  switch (status) {
  case 'VERIFIED': return 'success';
  case 'PENDING': return 'warning';
  case 'FAILED': return 'danger';
  default: return 'secondary';
  }
}

/**
 * 辅助函数：获取警报状态颜色
 */
function getAlertStatusColor (status) {
  switch (status) {
  case 'OPEN': return 'danger';
  case 'IN_PROGRESS': return 'warning';
  case 'RESOLVED': return 'success';
  case 'DISMISSED': return 'secondary';
  default: return 'secondary';
  }
}

/**
 * 辅助函数：获取严重程度颜色
 */
function getSeverityColor (severity) {
  switch (severity) {
  case 'HIGH': return 'danger';
  case 'MEDIUM': return 'warning';
  case 'LOW': return 'info';
  default: return 'secondary';
  }
}

/**
 * 辅助函数：获取操作类型颜色
 */
function getActionTypeColor (actionType) {
  switch (actionType) {
  case 'DELETE': return 'danger';
  case 'ARCHIVE': return 'info';
  case 'ANONYMIZE': return 'warning';
  default: return 'secondary';
  }
}

/**
 * 辅助函数：获取报告状态颜色
 */
function getReportStatusColor (status) {
  switch (status) {
  case 'COMPLETED': return 'success';
  case 'IN_PROGRESS': return 'warning';
  case 'FAILED': return 'danger';
  default: return 'secondary';
  }
}

/**
 * 显示Toast提示
 */
function showToast (message, type = 'info') {
  // 创建toast容器（如果不存在）
  let toastContainer = document.getElementById('toastContainer');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toastContainer';
    toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
    document.body.appendChild(toastContainer);
  }

  // 创建toast元素
  const toastElement = document.createElement('div');
  toastElement.className = `toast align-items-center text-white bg-${type === 'error' ? 'danger' : type} border-0`;
  toastElement.setAttribute('role', 'alert');
  toastElement.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;

  toastContainer.appendChild(toastElement);

  const toast = new bootstrap.Toast(toastElement);
  toast.show();

  // 自动移除toast元素
  toastElement.addEventListener('hidden.bs.toast', () => {
    toastElement.remove();
  });
}
