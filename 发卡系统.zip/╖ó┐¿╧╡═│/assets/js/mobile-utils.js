/*
 * 移动端适配工具库
 * 提供移动端常见交互和优化功能
 *
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

// 移动端工具类
const MobileUtils = {
  // 检测是否为移动设备
  isMobile: function () {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  },

  // 检测是否为iOS设备
  isIOS: function () {
    return /iPhone|iPad|iPod/i.test(navigator.userAgent) && !window.MSStream;
  },

  // 检测是否为Android设备
  isAndroid: function () {
    return /Android/i.test(navigator.userAgent) && !window.MSStream;
  },

  // 获取设备类型
  getDeviceType: function () {
    if (this.isIOS()) return 'ios';
    if (this.isAndroid()) return 'android';
    if (this.isMobile()) return 'mobile';
    return 'desktop';
  },

  // 获取视口尺寸
  getViewportSize: function () {
    return {
      width: Math.max(document.documentElement.clientWidth, window.innerWidth || 0),
      height: Math.max(document.documentElement.clientHeight, window.innerHeight || 0),
    };
  },

  // 检测是否为竖屏
  isPortrait: function () {
    const size = this.getViewportSize();
    return size.height > size.width;
  },

  // 检测是否为横屏
  isLandscape: function () {
    return !this.isPortrait();
  },

  // 添加横竖屏切换监听
  onOrientationChange: function (callback) {
    window.addEventListener('orientationchange', callback, false);
    window.addEventListener('resize', callback, false);

    // 返回移除监听器的函数
    return function () {
      window.removeEventListener('orientationchange', callback);
      window.removeEventListener('resize', callback);
    };
  },

  // 阻止默认的触摸行为（如双击缩放）
  preventDefaultTouchBehavior: function () {
    document.addEventListener('touchstart', function (e) {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    }, { passive: false });

    let lastTouchEnd = 0;
    document.addEventListener('touchend', function (e) {
      const now = (new Date()).getTime();
      if (now - lastTouchEnd <= 300) {
        e.preventDefault();
      }
      lastTouchEnd = now;
    }, { passive: false });

    // 阻止双击缩放
    document.addEventListener('dblclick', function (e) {
      e.preventDefault();
    }, { passive: false });
  },

  // 初始化移动端菜单
  initMobileMenu: function (menuBtnSelector, menuSelector, closeBtnSelector) {
    const menuBtn = document.querySelector(menuBtnSelector);
    const menu = document.querySelector(menuSelector);
    const closeBtn = document.querySelector(closeBtnSelector);

    if (!menuBtn || !menu || !closeBtn) {
      console.warn('Mobile menu elements not found');
      return;
    }

    const toggleMenu = function () {
      menu.classList.toggle('active');
      document.body.classList.toggle('menu-open');
      // 禁止或恢复背景滚动
      document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
    };

    menuBtn.addEventListener('click', toggleMenu);
    closeBtn.addEventListener('click', toggleMenu);

    // 点击菜单外部关闭菜单
    document.addEventListener('click', function (e) {
      if (menu.classList.contains('active') &&
                !menu.contains(e.target) &&
                !menuBtn.contains(e.target)) {
        toggleMenu();
      }
    });
  },

  // 实现移动端触摸滑动
  enableSwipe: function (element, options) {
    const settings = {
      onSwipeLeft: function () {},
      onSwipeRight: function () {},
      onSwipeUp: function () {},
      onSwipeDown: function () {},
      threshold: 50, // 最小滑动距离
      ...options,
    };

    let touchStartX = 0;
    let touchStartY = 0;
    let touchEndX = 0;
    let touchEndY = 0;

    const handleTouchStart = function (e) {
      const touch = e.touches[0];
      touchStartX = touch.clientX;
      touchStartY = touch.clientY;
    };

    const handleTouchEnd = function () {
      const diffX = touchStartX - touchEndX;
      const diffY = touchStartY - touchEndY;

      // 判断是水平滑动还是垂直滑动
      if (Math.abs(diffX) > Math.abs(diffY)) {
        // 水平滑动
        if (Math.abs(diffX) > settings.threshold) {
          if (diffX > 0) {
            settings.onSwipeLeft();
          } else {
            settings.onSwipeRight();
          }
        }
      } else {
        // 垂直滑动
        if (Math.abs(diffY) > settings.threshold) {
          if (diffY > 0) {
            settings.onSwipeUp();
          } else {
            settings.onSwipeDown();
          }
        }
      }
    };

    const handleTouchMove = function (e) {
      const touch = e.touches[0];
      touchEndX = touch.clientX;
      touchEndY = touch.clientY;
    };

    element.addEventListener('touchstart', handleTouchStart, false);
    element.addEventListener('touchmove', handleTouchMove, false);
    element.addEventListener('touchend', handleTouchEnd, false);

    // 返回移除滑动监听的函数
    return function () {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('touchmove', handleTouchMove);
      element.removeEventListener('touchend', handleTouchEnd);
    };
  },

  // 实现移动端滚动到底部加载更多
  enableInfiniteScroll: function (callback, options) {
    const settings = {
      distance: 100, // 距离底部多少像素触发回调
      throttle: 200, // 节流时间(ms)
      ...options,
    };

    let isLoading = false;
    let lastScrollCall = 0;

    const handleScroll = function () {
      const now = Date.now();

      // 节流
      if (now - lastScrollCall < settings.throttle) {
        return;
      }

      lastScrollCall = now;

      // 判断是否滚动到底部附近
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      const documentHeight = document.documentElement.scrollHeight;

      if (scrollTop + windowHeight >= documentHeight - settings.distance && !isLoading) {
        isLoading = true;

        // 执行回调，期望返回一个Promise
        Promise.resolve(callback()).finally(function () {
          isLoading = false;
        });
      }
    };

    window.addEventListener('scroll', handleScroll, false);

    // 返回移除滚动监听的函数
    return function () {
      window.removeEventListener('scroll', handleScroll);
    };
  },

  // 处理移动端键盘弹出事件
  handleKeyboardEvents: function (onKeyboardShow, onKeyboardHide) {
    let viewportHeight = window.innerHeight;

    const handleResize = function () {
      const newViewportHeight = window.innerHeight;
      const heightDifference = viewportHeight - newViewportHeight;

      // 高度减少超过100px认为键盘弹出
      if (heightDifference > 100) {
        if (onKeyboardShow) onKeyboardShow(heightDifference);
        document.body.classList.add('keyboard-visible');
      }
      // 高度增加超过100px认为键盘收起
      else if (heightDifference < -100) {
        if (onKeyboardHide) onKeyboardHide();
        document.body.classList.remove('keyboard-visible');
      }

      viewportHeight = newViewportHeight;
    };

    window.addEventListener('resize', handleResize, false);

    // 返回移除监听的函数
    return function () {
      window.removeEventListener('resize', handleResize);
    };
  },

  // 自动调整输入框位置，避免被键盘遮挡
  autoAdjustInputPosition: function (inputSelector) {
    const inputs = document.querySelectorAll(inputSelector);

    inputs.forEach((input) => {
      input.addEventListener('focus', function () {
        setTimeout(() => {
          const rect = this.getBoundingClientRect();
          const windowHeight = window.innerHeight;
          const inputBottom = rect.bottom;

          // 如果输入框底部距离视口底部不足150px，则滚动页面
          if (windowHeight - inputBottom < 150) {
            window.scrollBy(0, inputBottom - windowHeight + 150);
          }
        }, 100);
      });
    });
  },

  // 初始化数字输入框（移动端友好）
  initNumberInput: function (inputSelector) {
    const inputs = document.querySelectorAll(inputSelector);

    inputs.forEach((input) => {
      // 设置输入类型
      if (this.isIOS() || this.isAndroid()) {
        input.type = 'tel'; // 使用电话键盘，只有数字
      } else {
        input.type = 'number';
      }

      // 只允许输入数字
      input.addEventListener('input', function () {
        this.value = this.value.replace(/[^0-9]/g, '');
      });
    });
  },

  // 添加触摸反馈效果
  addTouchFeedback: function (elementsSelector) {
    const elements = document.querySelectorAll(elementsSelector);

    elements.forEach((element) => {
      // 添加触摸反馈类
      element.classList.add('touch-feedback');

      // 触摸开始时添加按下状态
      element.addEventListener('touchstart', function () {
        this.classList.add('touching');
      }, { passive: true });

      // 触摸结束时移除按下状态
      element.addEventListener('touchend', function () {
        this.classList.remove('touching');
      }, { passive: true });

      // 触摸取消时移除按下状态
      element.addEventListener('touchcancel', function () {
        this.classList.remove('touching');
      }, { passive: true });
    });
  },

  // 修复iOS点击延迟
  fixIOSClickDelay: function () {
    if (!this.isIOS()) return;

    // 使用fastclick库的核心逻辑
    let lastTouchTimestamp = 0;

    document.addEventListener('touchstart', function (e) {
      lastTouchTimestamp = e.timeStamp;
    }, { passive: true });

    document.addEventListener('touchend', function (e) {
      // 如果触摸事件和点击事件的时间差小于300ms，则认为是快速点击
      if (e.timeStamp - lastTouchTimestamp < 300) {
        // 创建并触发点击事件
        const touch = e.changedTouches[0];
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
          detail: 1,
          screenX: touch.screenX,
          screenY: touch.screenY,
          clientX: touch.clientX,
          clientY: touch.clientY,
          ctrlKey: false,
          altKey: false,
          shiftKey: false,
          metaKey: false,
          button: 0,
          relatedTarget: null,
        });

        e.target.dispatchEvent(clickEvent);
      }
    }, { passive: true });
  },

  // 检测设备支持的功能
  detectFeatures: function () {
    return {
      touch: 'ontouchstart' in window || navigator.maxTouchPoints > 0,
      orientation: 'orientation' in window || 'screenOrientation' in window,
      deviceMotion: 'DeviceMotionEvent' in window,
      deviceOrientation: 'DeviceOrientationEvent' in window,
      serviceWorker: 'serviceWorker' in navigator,
      webp: this.supportsWebp(),
      pushNotification: 'Notification' in window,
    };
  },

  // 检测是否支持WebP格式图片
  supportsWebp: function () {
    const canvas = document.createElement('canvas');
    if (!canvas.getContext || !canvas.getContext('2d')) {
      return false;
    }
    return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
  },

  // 初始化所有移动端功能
  init: function () {
    // 阻止默认触摸行为
    this.preventDefaultTouchBehavior();

    // 修复iOS点击延迟
    this.fixIOSClickDelay();

    // 添加设备类型类到body
    document.body.classList.add('device-' + this.getDeviceType());

    // 添加初始方向类到body
    document.body.classList.add(this.isPortrait() ? 'orientation-portrait' : 'orientation-landscape');

    // 监听方向变化
    this.onOrientationChange(function () {
      document.body.classList.remove('orientation-portrait', 'orientation-landscape');
      document.body.classList.add(this.isPortrait() ? 'orientation-portrait' : 'orientation-landscape');
    }.bind(this));

    console.log('Mobile utilities initialized for device type:', this.getDeviceType());
  },
};

// 触摸反馈的基础样式
const addTouchFeedbackStyles = function () {
  if (document.getElementById('mobile-touch-styles')) return;

  const style = document.createElement('style');
  style.id = 'mobile-touch-styles';
  style.textContent = `
        .touch-feedback {
            transition: transform 0.1s ease, opacity 0.1s ease, background-color 0.1s ease;
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }
        
        .touch-feedback.touching {
            transform: scale(0.98);
            opacity: 0.8;
        }
        
        .menu-open {
            overflow: hidden;
            position: fixed;
            width: 100%;
        }
        
        /* 键盘可见时的样式 */
        .keyboard-visible .fixed-bottom {
            position: relative;
            bottom: auto !important;
        }
        
        /* 设备类型相关样式 */
        .device-ios .ios-only,
        .device-android .android-only,
        .device-mobile .mobile-only,
        .device-desktop .desktop-only {
            display: block;
        }
        
        .device-ios .android-only,
        .device-ios .desktop-only,
        .device-android .ios-only,
        .device-android .desktop-only,
        .device-mobile .desktop-only,
        .device-desktop .mobile-only,
        .device-desktop .ios-only,
        .device-desktop .android-only {
            display: none;
        }
    `;

  document.head.appendChild(style);
};

// 导出模块（支持CommonJS和ES6模块）
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
  module.exports = MobileUtils;
} else if (typeof define === 'function' && define.amd) {
  define([], function () {
    return MobileUtils;
  });
} else {
  window.MobileUtils = MobileUtils;
  window.addTouchFeedbackStyles = addTouchFeedbackStyles;
}

// 自动初始化
if (typeof window !== 'undefined') {
  // 添加触摸反馈样式
  addTouchFeedbackStyles();

  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      if (MobileUtils.isMobile()) {
        MobileUtils.init();
      }
    });
  } else {
    if (MobileUtils.isMobile()) {
      MobileUtils.init();
    }
  }
}
