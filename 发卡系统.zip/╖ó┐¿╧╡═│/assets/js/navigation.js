// 发卡系统主导航JavaScript文件

// DOM加载完成后执行
document.addEventListener('DOMContentLoaded', function () {
  initNavigation();
});

// 初始化导航功能
function initNavigation () {
  initDropdown();
  initMobileMenu();
  initSearch();
  initCart();
}

// 初始化下拉菜单
function initDropdown () {
  const dropdowns = document.querySelectorAll('.dropdown');

  dropdowns.forEach((dropdown) => {
    const toggle = dropdown.querySelector('.dropdown-toggle');
    const menu = dropdown.querySelector('.dropdown-menu');

    if (toggle && menu) {
      // 点击切换下拉菜单
      toggle.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        // 关闭其他下拉菜单
        dropdowns.forEach((otherDropdown) => {
          if (otherDropdown !== dropdown) {
            otherDropdown.classList.remove('show');
          }
        });

        // 切换当前下拉菜单
        dropdown.classList.toggle('show');
      });

      // 点击菜单项关闭下拉菜单
      const items = menu.querySelectorAll('.dropdown-item');
      items.forEach((item) => {
        item.addEventListener('click', function () {
          dropdown.classList.remove('show');
        });
      });
    }
  });

  // 点击页面其他地方关闭所有下拉菜单
  document.addEventListener('click', function () {
    dropdowns.forEach((dropdown) => {
      dropdown.classList.remove('show');
    });
  });
}

// 初始化移动端菜单
function initMobileMenu () {
  const toggle = document.querySelector('.mobile-menu-toggle');
  const menu = document.querySelector('.mobile-menu');

  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      menu.classList.toggle('show');

      // 切换图标
      const icon = toggle.querySelector('i');
      if (menu.classList.contains('show')) {
        icon.classList.remove('fa-bars');
        icon.classList.add('fa-times');
      } else {
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      }
    });

    // 点击菜单项关闭菜单
    const menuItems = menu.querySelectorAll('.mobile-menu-item');
    menuItems.forEach((item) => {
      item.addEventListener('click', function () {
        menu.classList.remove('show');
        const icon = toggle.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      });
    });

    // 点击遮罩关闭菜单
    menu.addEventListener('click', function (e) {
      if (e.target === menu) {
        menu.classList.remove('show');
        const icon = toggle.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      }
    });
  }
}

// 初始化搜索功能
function initSearch () {
  const searchInput = document.querySelector('.search-input');

  if (searchInput) {
    let searchTimeout;

    // 输入搜索关键词
    searchInput.addEventListener('input', function () {
      clearTimeout(searchTimeout);
      const query = this.value.trim();

      if (query.length >= 2) {
        searchTimeout = setTimeout(() => {
          performSearch(query);
        }, 300);
      }
    });

    // 回车搜索
    searchInput.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        const query = this.value.trim();
        if (query) {
          performSearch(query);
        }
      }
    });
  }
}

// 执行搜索
function performSearch (query) {
  // 这里可以发送AJAX请求到后端API
  console.log('搜索:', query);

  // 模拟搜索结果
  const results = [
    { name: '腾讯视频VIP会员年卡', category: '视频会员', price: 198 },
    { name: 'Steam钱包充值卡 $100', category: '游戏点卡', price: 688 },
    { name: 'QQ音乐豪华会员年卡', category: '音乐会员', price: 138 },
  ];

  // 显示搜索建议（可选）
  showSearchSuggestions(results);
}

// 显示搜索建议
function showSearchSuggestions (results) {
  // 这里可以实现搜索建议下拉框
  // 为了简化，暂时只在控制台输出
  console.log('搜索建议:', results);
}

// 初始化购物车功能
function initCart () {
  updateCartBadge();
  initCartEvents();
}

// 更新购物车数量徽章
function updateCartBadge () {
  const badge = document.querySelector('.cart-badge');
  if (badge) {
    const cartCount = getCartCount();
    badge.textContent = cartCount;
    badge.style.display = cartCount > 0 ? 'flex' : 'none';
  }
}

// 获取购物车数量
function getCartCount () {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  return cart.reduce((total, item) => total + item.quantity, 0);
}

// 初始化购物车事件
function initCartEvents () {
  // 加入购物车按钮
  const addToCartButtons = document.querySelectorAll('.btn-add-cart');
  addToCartButtons.forEach((button) => {
    button.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      const productCard = this.closest('.product-card');
      if (productCard) {
        const product = getProductFromCard(productCard);
        addToCart(product);
      }
    });
  });

  // 立即购买按钮
  const buyButtons = document.querySelectorAll('.btn-buy');
  buyButtons.forEach((button) => {
    button.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      const productCard = this.closest('.product-card');
      if (productCard) {
        const product = getProductFromCard(productCard);
        buyNow(product);
      }
    });
  });
}

// 从产品卡片获取产品信息
function getProductFromCard (card) {
  const name = card.querySelector('.product-name')?.textContent || '';
  const priceText = card.querySelector('.price-current')?.textContent || '';
  const price = parseFloat(priceText.replace('¥', ''));
  const image = card.querySelector('.product-image')?.src || '';
  const category = card.querySelector('.product-category')?.textContent || '';
  const url = card.href || '';

  return {
    id: generateProductId(name),
    name,
    price,
    image,
    category,
    url,
    quantity: 1,
  };
}

// 生成产品ID
function generateProductId (name) {
  return name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
}

// 添加到购物车
function addToCart (product) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const existingItem = cart.find((item) => item.id === product.id);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push(product);
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartBadge();

  // 显示添加成功提示
  showNotification('商品已添加到购物车');
}

// 立即购买
function buyNow (product) {
  // 清空购物车并添加当前商品
  localStorage.setItem('cart', JSON.stringify([product]));
  updateCartBadge();

  // 跳转到结算页面
  window.location.href = 'checkout.html';
}

// 显示通知
function showNotification (message, type = 'success') {
  // 创建通知元素
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;

  // 添加样式
  Object.assign(notification.style, {
    position: 'fixed',
    top: '20px',
    right: '20px',
    backgroundColor: type === 'success' ? 'var(--success-color)' : 'var(--error-color)',
    color: 'white',
    padding: '12px 20px',
    borderRadius: '8px',
    boxShadow: 'var(--shadow-lg)',
    zIndex: '9999',
    fontSize: '14px',
    fontWeight: '500',
    transform: 'translateX(100%)',
    transition: 'transform 0.3s ease',
  });

  document.body.appendChild(notification);

  // 显示动画
  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 100);

  // 自动隐藏
  setTimeout(() => {
    notification.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// 平滑滚动到指定元素
function scrollToElement (elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }
}

// 导航栏滚动效果
function initNavbarScroll () {
  const navbar = document.querySelector('.navbar');
  let lastScrollTop = 0;

  window.addEventListener('scroll', function () {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (navbar) {
      if (scrollTop > lastScrollTop && scrollTop > 100) {
        // 向下滚动 - 隐藏导航栏
        navbar.style.transform = 'translateY(-100%)';
      } else {
        // 向上滚动 - 显示导航栏
        navbar.style.transform = 'translateY(0)';
      }

      // 添加阴影效果
      if (scrollTop > 0) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }

    lastScrollTop = scrollTop;
  });
}

// 页面加载完成后初始化滚动效果
window.addEventListener('load', function () {
  initNavbarScroll();
});

// 导出函数供其他模块使用
window.Navigation = {
  scrollToElement,
  showNotification,
  updateCartBadge,
  addToCart,
  buyNow,
};
