// 个人中心页面交互逻辑
class UserCenterPage {
    constructor() {
        this.currentTab = 'orders';
        this.orders = [];
        this.filteredOrders = [];
        this.currentPage = 1;
        this.pageSize = 10;
        this.totalPages = 1;
        
        this.userData = {
            name: '张三',
            email: 'zhangsan@example.com',
            level: 'VIP会员',
            avatar: null,
            totalOrders: 12,
            completedOrders: 8,
            totalAmount: 2580
        };
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadUserData();
        this.loadOrders();
        this.initTabSwitching();
        this.initFilters();
        this.initPagination();
    }

    // 绑定事件
    bindEvents() {
        // 菜单项点击事件
        document.addEventListener('click', (e) => {
            if (e.target.closest('.menu-item')) {
                this.handleMenuClick(e.target.closest('.menu-item'));
            }
            
            // 订单项点击事件
            if (e.target.closest('.order-item')) {
                this.handleOrderClick(e.target.closest('.order-item'));
            }
            
            // 操作按钮点击事件
            if (e.target.closest('.btn-order')) {
                this.handleOrderAction(e.target.closest('.btn-order'));
            }
            
            // 筛选器变化事件
            if (e.target.closest('.order-filters')) {
                this.handleFilterChange();
            }
        });

        // 搜索框输入事件
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', this.debounce(() => {
                this.handleFilterChange();
            }, 300));
        }

        // 页面滚动事件
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
    }

    // 加载用户数据
    loadUserData() {
        // 更新用户信息显示
        const userNameElement = document.querySelector('.user-name');
        const userEmailElement = document.querySelector('.user-email');
        const userLevelElement = document.querySelector('.user-level');
        
        if (userNameElement) userNameElement.textContent = this.userData.name;
        if (userEmailElement) userEmailElement.textContent = this.userData.email;
        if (userLevelElement) userLevelElement.textContent = this.userData.level;
        
        // 更新统计数据
        const statValues = document.querySelectorAll('.stat-value');
        if (statValues.length >= 3) {
            statValues[0].textContent = this.userData.totalOrders;
            statValues[1].textContent = this.userData.completedOrders;
            statValues[2].textContent = `¥${this.userData.totalAmount.toLocaleString()}`;
        }
    }

    // 加载订单数据
    async loadOrders() {
        try {
            this.showLoading('orderList');
            
            // 模拟API调用
            const response = await this.mockApiCall('/api/orders', {
                page: this.currentPage,
                pageSize: this.pageSize
            });
            
            this.orders = response.data.orders;
            this.totalPages = response.data.totalPages;
            this.filteredOrders = [...this.orders];
            
            this.renderOrders();
            this.renderPagination();
            this.hideLoading('orderList');
        } catch (error) {
            console.error('加载订单失败:', error);
            this.showError('加载订单失败，请刷新重试');
            this.hideLoading('orderList');
        }
    }

    // 初始化标签切换
    initTabSwitching() {
        const menuItems = document.querySelectorAll('.menu-item');
        const tabContents = document.querySelectorAll('.tab-content');
        
        menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const tabName = item.dataset.tab;
                
                if (tabName === this.currentTab) return;
                
                // 更新菜单状态
                menuItems.forEach(mi => mi.classList.remove('active'));
                item.classList.add('active');
                
                // 切换内容显示
                tabContents.forEach(content => {
                    content.style.display = 'none';
                });
                
                const targetContent = document.getElementById(`${tabName}-content`);
                if (targetContent) {
                    targetContent.style.display = 'block';
                    this.animateTabContent(targetContent);
                }
                
                this.currentTab = tabName;
                
                // 根据标签加载相应数据
                this.loadTabData(tabName);
            });
        });
    }

    // 加载标签数据
    loadTabData(tabName) {
        switch (tabName) {
            case 'orders':
                this.loadOrders();
                break;
            case 'cards':
                this.loadCards();
                break;
            case 'profile':
                this.loadProfile();
                break;
            case 'address':
                this.loadAddress();
                break;
            case 'settings':
                this.loadSettings();
                break;
        }
    }

    // 加载卡密数据
    async loadCards() {
        try {
            const response = await this.mockApiCall('/api/cards', {});
            // 处理卡密数据
        } catch (error) {
            console.error('加载卡密失败:', error);
        }
    }

    // 加载账户信息
    async loadProfile() {
        try {
            const response = await this.mockApiCall('/api/profile', {});
            // 处理账户信息
        } catch (error) {
            console.error('加载账户信息失败:', error);
        }
    }

    // 加载地址信息
    async loadAddress() {
        try {
            const response = await this.mockApiCall('/api/address', {});
            // 处理地址信息
        } catch (error) {
            console.error('加载地址信息失败:', error);
        }
    }

    // 加载设置信息
    async loadSettings() {
        try {
            const response = await this.mockApiCall('/api/settings', {});
            // 处理设置信息
        } catch (error) {
            console.error('加载设置信息失败:', error);
        }
    }

    // 初始化筛选器
    initFilters() {
        const statusFilter = document.getElementById('statusFilter');
        const timeFilter = document.getElementById('timeFilter');
        
        if (statusFilter) {
            statusFilter.addEventListener('change', () => {
                this.handleFilterChange();
            });
        }
        
        if (timeFilter) {
            timeFilter.addEventListener('change', () => {
                this.handleFilterChange();
            });
        }
    }

    // 处理筛选变化
    handleFilterChange() {
        const statusFilter = document.getElementById('statusFilter');
        const timeFilter = document.getElementById('timeFilter');
        const searchInput = document.getElementById('searchInput');
        
        const status = statusFilter ? statusFilter.value : '';
        const timeRange = timeFilter ? timeFilter.value : '';
        const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
        
        this.filteredOrders = this.orders.filter(order => {
            // 状态筛选
            if (status && order.status !== status) return false;
            
            // 时间筛选
            if (timeRange && !this.isOrderInTimeRange(order, timeRange)) return false;
            
            // 搜索筛选
            if (searchTerm) {
                const searchMatch = order.orderNumber.toLowerCase().includes(searchTerm) ||
                                  order.productName.toLowerCase().includes(searchTerm);
                if (!searchMatch) return false;
            }
            
            return true;
        });
        
        this.currentPage = 1;
        this.renderOrders();
        this.renderPagination();
    }

    // 判断订单是否在时间范围内
    isOrderInTimeRange(order, timeRange) {
        const orderDate = new Date(order.createTime);
        const now = new Date();
        
        switch (timeRange) {
            case 'today':
                return orderDate.toDateString() === now.toDateString();
            case 'week':
                const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                return orderDate >= weekAgo;
            case 'month':
                const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                return orderDate >= monthAgo;
            case 'year':
                return orderDate.getFullYear() === now.getFullYear();
            default:
                return true;
        }
    }

    // 渲染订单列表
    renderOrders() {
        const orderList = document.getElementById('orderList');
        if (!orderList) return;
        
        if (this.filteredOrders.length === 0) {
            orderList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                    <h3 class="empty-title">暂无订单</h3>
                    <p class="empty-text">您还没有相关订单，快去购买吧！</p>
                    <a href="index.html" class="btn-content primary">
                        <i class="fas fa-shopping-cart"></i>
                        去购买
                    </a>
                </div>
            `;
            return;
        }
        
        const startIndex = (this.currentPage - 1) * this.pageSize;
        const endIndex = startIndex + this.pageSize;
        const pageOrders = this.filteredOrders.slice(startIndex, endIndex);
        
        orderList.innerHTML = pageOrders.map(order => this.createOrderHTML(order)).join('');
        
        // 添加动画效果
        const orderItems = orderList.querySelectorAll('.order-item');
        orderItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                item.style.transition = 'all 0.3s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, index * 50);
        });
    }

    // 创建订单HTML
    createOrderHTML(order) {
        const statusClass = this.getStatusClass(order.status);
        const statusText = this.getStatusText(order.status);
        
        return `
            <div class="order-item" data-order-id="${order.orderNumber}">
                <div class="order-header">
                    <span class="order-number">#${order.orderNumber}</span>
                    <span class="order-status ${statusClass}">${statusText}</span>
                </div>
                <div class="order-content">
                    <div class="order-product">
                        <div class="product-image">
                            <i class="fas ${order.productIcon}"></i>
                        </div>
                        <div class="product-info">
                            <h4>${order.productName}</h4>
                            <p>规格：${order.specification}</p>
                        </div>
                    </div>
                    <div class="order-details">
                        <div class="order-time">${this.formatTime(order.createTime)}</div>
                        <div class="order-amount">¥${order.amount.toFixed(2)}</div>
                    </div>
                    <div class="order-actions">
                        ${this.createOrderActions(order)}
                    </div>
                </div>
            </div>
        `;
    }

    // 创建订单操作按钮
    createOrderActions(order) {
        let actions = '';
        
        switch (order.status) {
            case 'completed':
                actions = `
                    <a href="card-result.html?order=${order.orderNumber}" class="btn-order primary">查看卡密</a>
                    <button class="btn-order" onclick="userCenterPage.reorder('${order.orderNumber}')">再次购买</button>
                `;
                break;
            case 'pending':
                actions = `
                    <a href="checkout.html?order=${order.orderNumber}" class="btn-order primary">立即支付</a>
                    <button class="btn-order" onclick="userCenterPage.cancelOrder('${order.orderNumber}')">取消订单</button>
                `;
                break;
            case 'failed':
                actions = `
                    <button class="btn-order" onclick="userCenterPage.viewOrderDetail('${order.orderNumber}')">查看详情</button>
                    <button class="btn-order" onclick="userCenterPage.reorder('${order.orderNumber}')">再次购买</button>
                `;
                break;
        }
        
        return actions;
    }

    // 获取状态样式类
    getStatusClass(status) {
        const statusMap = {
            'completed': 'status-completed',
            'pending': 'status-pending',
            'failed': 'status-failed'
        };
        return statusMap[status] || 'status-pending';
    }

    // 获取状态文本
    getStatusText(status) {
        const statusMap = {
            'completed': '已完成',
            'pending': '待支付',
            'failed': '已失效'
        };
        return statusMap[status] || '未知状态';
    }

    // 格式化时间
    formatTime(timeString) {
        const date = new Date(timeString);
        return date.toLocaleString('zh-CN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // 初始化分页
    initPagination() {
        // 分页点击事件在renderPagination中处理
    }

    // 渲染分页
    renderPagination() {
        const pagination = document.querySelector('.pagination');
        if (!pagination) return;
        
        if (this.totalPages <= 1) {
            pagination.style.display = 'none';
            return;
        }
        
        pagination.style.display = 'flex';
        
        let paginationHTML = `
            <button class="page-btn" ${this.currentPage === 1 ? 'disabled' : ''} onclick="userCenterPage.goToPage(${this.currentPage - 1})">
                <i class="fas fa-chevron-left"></i>
            </button>
        `;
        
        // 显示页码
        const maxVisiblePages = 5;
        let startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(this.totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage < maxVisiblePages - 1) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            paginationHTML += `
                <button class="page-btn ${i === this.currentPage ? 'active' : ''}" onclick="userCenterPage.goToPage(${i})">${i}</button>
            `;
        }
        
        paginationHTML += `
            <button class="page-btn" ${this.currentPage === this.totalPages ? 'disabled' : ''} onclick="userCenterPage.goToPage(${this.currentPage + 1})">
                <i class="fas fa-chevron-right"></i>
            </button>
        `;
        
        pagination.innerHTML = paginationHTML;
    }

    // 跳转到指定页
    goToPage(page) {
        if (page < 1 || page > this.totalPages || page === this.currentPage) return;
        
        this.currentPage = page;
        this.renderOrders();
        this.renderPagination();
        
        // 滚动到顶部
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // 处理菜单点击
    handleMenuClick(menuItem) {
        const tabName = menuItem.dataset.tab;
        if (tabName && tabName !== this.currentTab) {
            // 切换标签逻辑已在initTabSwitching中处理
        }
    }

    // 处理订单点击
    handleOrderClick(orderItem) {
        const orderId = orderItem.dataset.orderId;
        // 可以添加订单详情查看逻辑
    }

    // 处理订单操作
    handleOrderAction(button) {
        const action = button.textContent.trim();
        const orderItem = button.closest('.order-item');
        const orderId = orderItem.dataset.orderId;
        
        switch (action) {
            case '查看卡密':
                this.viewCard(orderId);
                break;
            case '立即支付':
                this.payOrder(orderId);
                break;
            case '取消订单':
                this.cancelOrder(orderId);
                break;
            case '再次购买':
                this.reorder(orderId);
                break;
            case '查看详情':
                this.viewOrderDetail(orderId);
                break;
        }
    }

    // 查看卡密
    viewCard(orderId) {
        window.location.href = `card-result.html?order=${orderId}`;
    }

    // 支付订单
    payOrder(orderId) {
        window.location.href = `checkout.html?order=${orderId}`;
    }

    // 取消订单
    async cancelOrder(orderId) {
        if (!confirm('确定要取消这个订单吗？')) return;
        
        try {
            await this.mockApiCall('/api/orders/cancel', { orderId });
            this.showSuccess('订单已取消');
            this.loadOrders();
        } catch (error) {
            this.showError('取消订单失败，请重试');
        }
    }

    // 再次购买
    reorder(orderId) {
        const order = this.orders.find(o => o.orderNumber === orderId);
        if (order) {
            // 跳转到产品详情页
            window.location.href = `product-detail.html?id=${order.productId}`;
        }
    }

    // 查看订单详情
    viewOrderDetail(orderId) {
        // 显示订单详情模态框或跳转到详情页
        console.log('查看订单详情:', orderId);
    }

    // 处理滚动
    handleScroll() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const navbar = document.querySelector('.navbar');
        
        if (navbar) {
            if (scrollTop > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }
    }

    // 标签内容动画
    animateTabContent(content) {
        content.style.opacity = '0';
        content.style.transform = 'translateY(20px');
        
        setTimeout(() => {
            content.style.transition = 'all 0.3s ease';
            content.style.opacity = '1';
            content.style.transform = 'translateY(0)';
        }, 100);
    }

    // 显示加载状态
    showLoading(containerId) {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = `
                <div class="loading">
                    <div class="loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            `;
        }
    }

    // 隐藏加载状态
    hideLoading(containerId) {
        // 加载完成后会被renderOrders替换内容
    }

    // 显示成功消息
    showSuccess(message) {
        this.showToast(message, 'success');
    }

    // 显示错误消息
    showError(message) {
        this.showToast(message, 'error');
    }

    // 显示提示消息
    showToast(message, type = 'info', duration = 3000) {
        // 创建或获取toast容器
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container';
            toastContainer.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
            `;
            document.body.appendChild(toastContainer);
        }

        // 创建toast元素
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.style.cssText = `
            background: ${type === 'success' ? '#00B42A' : type === 'error' ? '#F53F3F' : '#165DFF'};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            animation: slideInRight 0.3s ease;
            max-width: 300px;
            word-wrap: break-word;
        `;
        toast.textContent = message;

        // 添加动画样式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        if (!document.querySelector('style[data-toast]')) {
            style.setAttribute('data-toast', 'true');
            document.head.appendChild(style);
        }

        toastContainer.appendChild(toast);

        // 自动移除
        setTimeout(() => {
            toast.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, duration);
    }

    // 防抖函数
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // 模拟API调用
    async mockApiCall(url, data) {
        return new Promise((resolve) => {
            setTimeout(() => {
                if (url === '/api/orders') {
                    resolve({
                        status: 'success',
                        data: {
                            orders: [
                                {
                                    orderNumber: '2024111800001',
                                    productName: '腾讯视频年卡',
                                    productIcon: 'fa-play-circle',
                                    specification: '年卡会员',
                                    amount: 198.00,
                                    status: 'completed',
                                    createTime: '2024-11-18T14:30:25',
                                    productId: 'txsp-year'
                                },
                                {
                                    orderNumber: '2024111700002',
                                    productName: '网易云音乐月卡',
                                    productIcon: 'fa-music',
                                    specification: '月卡会员',
                                    amount: 15.00,
                                    status: 'pending',
                                    createTime: '2024-11-17T10:15:30',
                                    productId: 'wymusic-month'
                                },
                                {
                                    orderNumber: '2024111600003',
                                    productName: 'Steam充值卡100元',
                                    productIcon: 'fa-gamepad',
                                    specification: '100元充值卡',
                                    amount: 100.00,
                                    status: 'completed',
                                    createTime: '2024-11-16T16:45:12',
                                    productId: 'steam-100'
                                }
                            ],
                            totalPages: 3,
                            currentPage: 1,
                            total: 12
                        }
                    });
                } else {
                    resolve({ status: 'success', data: {} });
                }
            }, 500);
        });
    }
}

// 全局实例
let userCenterPage;

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    userCenterPage = new UserCenterPage();
});