// 卡密管理页面JavaScript

// 翻译函数fallback实现
if (typeof t !== 'function') {
  window.t = function (key, params = {}) {
    // 简单的翻译映射
    const translations = {
      'error.load_stats_failed': '加载统计数据失败',
      'validation.please_select': '请选择',
      'cards.all_products': '全部产品',
      'error.load_products_failed': '加载产品列表失败',
      'success.batch_created': '批次创建成功',
      'error.create_batch_failed': '创建批次失败',
      'success.cards_generated': '成功生成 {count} 个卡密',
      'error.generate_cards_failed': '生成卡密失败',
      'error.load_cards_failed': '加载卡密列表失败',
      'error.load_anomalies_failed': '加载异常记录失败',
      'error.load_statistics_failed': '加载统计数据失败',
      'error.create_verification_failed': '创建核验任务失败',
      'success.verification_created': '核验任务创建成功',
      'error.batch_operation_failed': '批量操作失败',
      'success.batch_operation_success': '批量操作成功',
    };

    let result = translations[key] || key;

    // 替换参数
    if (params && typeof params === 'object') {
      Object.keys(params).forEach((param) => {
        result = result.replace(`{${param}}`, params[param]);
      });
    }

    return result;
  };
}

class CardManager {
  constructor () {
    this.currentPage = 1;
    this.currentBatchPage = 1;
    this.currentAnomalyPage = 1;
    this.selectedCards = new Set();
    this.init();
  }

  init () {
    this.bindEvents();
    this.loadStatistics();
    this.loadBatches();

    // 初始化数据加载管理器语言设置
    if (typeof dataLoader !== 'undefined') {
      dataLoader.setLanguage(this.currentLanguage || 'zh-CN');
    }

    this.loadProducts();
    this.initCharts();

    // 初始化分页管理器
    this.paginationManager = new PaginationManager({
      containerId: 'pagination',
      currentPage: 1,
      totalPages: 1,
      onPageChange: (page) => this.loadCards(page),
      language: this.currentLanguage || 'zh-CN',
    });

    // 初始化移动端优化
    if (this.isMobileDevice()) {
      this.initMobileOptimizations();
    }
  }

  // 事件配置对象，集中管理所有事件绑定
  getEventConfig () {
    return {
      // 批次管理相关事件
      batchManagement: [
        { id: 'createBatchBtn', event: 'click', handler: () => this.createBatch() },
        { id: 'batchProduct', event: 'change', handler: () => this.loadProducts() },
      ],

      // 卡密列表相关事件
      cardList: [
        { id: 'refreshCardsBtn', event: 'click', handler: () => this.loadCards() },
        { id: 'exportCardsBtn', event: 'click', handler: () => this.exportCards() },
        { id: 'batchOperationBtn', event: 'click', handler: () => this.showBatchOperation() },
        { id: 'selectAllCards', event: 'change', handler: (e) => this.selectAllCards(e) },
      ],

      // 筛选器相关事件 - 集中管理所有筛选器
      filters: [
        // 卡密筛选器
        { id: 'cardStatusFilter', event: 'change', handler: () => this.loadCards() },
        { id: 'cardProductFilter', event: 'change', handler: () => this.loadCards() },
        { id: 'cardBatchFilter', event: 'change', handler: () => this.loadCards() },
        { id: 'cardSearchInput', event: 'input', handler: this.debounce(() => this.loadCards(), 500) },

        // 异常筛选器
        { id: 'anomalyTypeFilter', event: 'change', handler: () => this.loadAnomalies(), optional: true },
        { id: 'anomalySeverityFilter', event: 'change', handler: () => this.loadAnomalies(), optional: true },
        { id: 'anomalyStatusFilter', event: 'change', handler: () => this.loadAnomalies(), optional: true },
      ],

      // 表单相关事件
      forms: [
        { id: 'verifyCardForm', event: 'submit', handler: (e) => this.verifyCard(e) },
        { id: 'redeemCardForm', event: 'submit', handler: (e) => this.redeemCard(e) },
      ],

      // 异常监控相关事件
      anomalyMonitoring: [
        { id: 'detectAnomaliesBtn', event: 'click', handler: () => this.detectAnomalies() },
        { id: 'expireCardsBtn', event: 'click', handler: () => this.expireCards() },
        { id: 'refreshAnomaliesBtn', event: 'click', handler: () => this.loadAnomalies() },
      ],

      // 批量操作相关事件
      batchOperations: [
        { id: 'batchOperationType', event: 'change', handler: (e) => this.toggleBatchOperationOptions(e), optional: true },
        { id: 'executeBatchOperationBtn', event: 'click', handler: () => this.executeBatchOperation(), optional: true },
      ],
    };
  }

  // 批量绑定事件的辅助方法
  bindEventsByConfig (eventConfigs) {
    for (const config of eventConfigs) {
      const element = document.getElementById(config.id);

      // 处理可选元素，如果元素不存在且标记为可选，则跳过
      if (!element) {
        if (config.optional) continue;
        console.warn(`Element with id '${config.id}' not found for event binding`);
        continue;
      }

      // 绑定事件
      element.addEventListener(config.event, config.handler);
    }
  }

  bindEvents () {
    const eventConfig = this.getEventConfig();

    // 按功能模块批量绑定事件
    Object.values(eventConfig).forEach((eventGroup) => {
      this.bindEventsByConfig(eventGroup);
    });

    // 为移动设备添加触摸事件支持
    if (this.isMobileDevice()) {
      this.setupTouchEvents();
    }

    // 标签页切换 - 特殊处理，因为需要querySelectorAll
    document.querySelectorAll('#cardTabs button').forEach((tab) => {
      tab.addEventListener('shown.bs.tab', (e) => {
        const target = e.target.getAttribute('data-bs-target');
        if (target === '#cards') {
          this.loadCards();
        } else if (target === '#anomalies') {
          this.loadAnomalies();
        } else if (target === '#statistics') {
          this.loadStatistics();
          this.updateCharts();
        }
      });
    });
  }

  // 获取当前用户ID
  getCurrentUserId () {
    // 从页面全局变量获取用户信息
    if (window.currentUser && window.currentUser.id) {
      return window.currentUser.id;
    }
    return 1; // 默认值，应该从后端会话获取
  }

  // 获取当前用户名
  getCurrentUserName () {
    // 从页面全局变量获取用户信息
    if (window.currentUser && window.currentUser.username) {
      return window.currentUser.username;
    }
    return 'Admin'; // 默认值，应该从后端会话获取
  }

  // 显示加载状态
  showLoading () {
    document.querySelector('.loading-overlay').style.display = 'flex';
  }

  hideLoading () {
    document.querySelector('.loading-overlay').style.display = 'none';
  }

  // 检测是否为移动设备
  isMobileDevice () {
    const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    return mobileRegex.test(navigator.userAgent);
  }

  // 初始化移动端优化
  initMobileOptimizations () {
    // 增大触摸目标
    const buttons = document.querySelectorAll('button, .btn');
    buttons.forEach((button) => {
      const currentWidth = button.offsetWidth;
      const currentHeight = button.offsetHeight;

      // 确保触摸目标至少为44x44像素
      if (currentWidth < 44 || currentHeight < 44) {
        button.style.minWidth = '44px';
        button.style.minHeight = '44px';
        button.style.padding = '8px 16px';
      }
    });

    // 优化表单元素
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach((input) => {
      input.style.fontSize = '16px'; // 防止iOS自动缩放
    });

    // 优化表格显示
    const tables = document.querySelectorAll('.table');
    tables.forEach((table) => {
      table.classList.add('table-responsive');
    });

    // 优化模态框
    const modals = document.querySelectorAll('.modal');
    modals.forEach((modal) => {
      modal.style.maxWidth = '95%';
      modal.style.width = '95%';
      modal.style.margin = '10px auto';
    });
  }

  // 设置触摸事件支持
  setupTouchEvents () {
    // 为按钮添加触摸反馈
    const buttons = document.querySelectorAll('button, .btn');
    buttons.forEach((button) => {
      button.addEventListener('touchstart', () => {
        button.style.transform = 'scale(0.95)';
        button.style.transition = 'transform 0.1s';
      });

      button.addEventListener('touchend', () => {
        button.style.transform = 'scale(1)';
      });

      button.addEventListener('touchmove', () => {
        button.style.transform = 'scale(1)';
      });
    });

    // 优化筛选器交互
    const filters = document.querySelectorAll('.filter-group');
    filters.forEach((filter) => {
      filter.addEventListener('click', (e) => {
        if (e.target.tagName === 'SELECT') {
          e.target.style.fontSize = '16px'; // 防止iOS自动缩放
        }
      });
    });
  }

  // 显示消息
  showMessage (message, type = 'info') {
    const isMobile = this.isMobileDevice();
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;

    // 移动端消息样式
    if (isMobile) {
      alertDiv.style.cssText = 'bottom: 80px; left: 50%; transform: translateX(-50%); z-index: 9999; width: 90%; max-width: 500px; border-radius: 20px;';
    } else {
      alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    }

    alertDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                <span>${message}</span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

    document.body.appendChild(alertDiv);

    setTimeout(() => {
      alertDiv.remove();
    }, 5000);
  }

  // 防抖函数
  debounce (func, wait) {
    let timeout;
    return function executedFunction (...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // 加载统计数据
  async loadStatistics () {
    try {
      const response = await dataLoader.get('api/cards/index.php', {
        params: { action: 'get_card_stats' },
        showLoading: false,
        defaultErrorMessage: '加载统计数据失败',
      });
      const stats = response.data;

      document.getElementById('totalCards').textContent = stats.total || 0;
      document.getElementById('activeCards').textContent = stats.active || 0;
      document.getElementById('usedCards').textContent = stats.used || 0;
      document.getElementById('anomalyCount').textContent = stats.anomalies || 0;

      // 更新统计表格
      this.updateStatsTable(stats.product_stats || []);
    } catch (error) {
      console.error('加载统计数据失败:', error);
      this.showMessage(t('error.load_stats_failed'), 'danger');
    }
  }

  // 更新统计表格
  updateStatsTable (productStats) {
    const tbody = document.getElementById('statsTableBody');
    tbody.innerHTML = '';

    productStats.forEach((stat) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${stat.product_name}</td>
                <td>${stat.total_count}</td>
                <td>${stat.active_count}</td>
                <td>${stat.used_count}</td>
                <td>${stat.expired_count}</td>
                <td>
                    <div class="progress" style="height: 20px;">
                        <div class="progress-bar" style="width: ${stat.usage_rate}%">${stat.usage_rate}%</div>
                    </div>
                </td>
            `;
      tbody.appendChild(row);
    });
  }

  // 加载产品列表
  async loadProducts () {
    try {
      const response = await axios.get('api/products/index.php?action=list');
      const products = response.data.data.products || [];

      // 更新批次创建的产品选择器
      const batchProductSelect = document.getElementById('batchProduct');
      batchProductSelect.innerHTML = `<option value="">${t('validation.please_select')}</option>`;
      products.forEach((product) => {
        batchProductSelect.innerHTML += `<option value="${product.id}">${product.name}</option>`;
      });

      // 更新卡密筛选的产品选择器
      const cardProductFilter = document.getElementById('cardProductFilter');
      cardProductFilter.innerHTML = `<option value="">${t('cards.all_products')}</option>`;
      products.forEach((product) => {
        cardProductFilter.innerHTML += `<option value="${product.id}">${product.name}</option>`;
      });
    } catch (error) {
      console.error('加载产品列表失败:', error);
      this.showMessage(t('error.load_products_failed'), 'danger');
    }
  }

  // 加载批次列表
  async loadBatches (page = 1) {
    try {
      const params = {
        page,
        limit: 10,
        status: document.getElementById('batchStatus')?.value || '',
        product_id: document.getElementById('batchProduct')?.value || '',
      };

      const response = await dataLoader.get('api/cards/index.php', {
        params: { action: 'list_batches', ...params },
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '加载批次列表失败',
      });

      this.renderBatches(response.data.batches || []);
      this.renderPagination('batchesPagination', response.data.current_page, response.data.total_pages, (p) => this.loadBatches(p));
    } catch (error) {
      console.error('加载批次列表失败:', error);
    }
  }

  // 渲染批次列表
  renderBatches (batches) {
    const tbody = document.getElementById('batchesTableBody');
    tbody.innerHTML = '';

    batches.forEach((batch) => {
      const progress = batch.quantity > 0 ? (batch.generated_count / batch.quantity * 100).toFixed(1) : 0;
      const statusBadge = this.getStatusBadge(batch.status);

      const row = document.createElement('tr');
      row.innerHTML = `
                <td><code>${batch.batch_no}</code></td>
                <td>${batch.product_name || 'N/A'}</td>
                <td>${batch.quantity}</td>
                <td>${batch.generated_count}</td>
                <td>
                    <div class="progress batch-progress">
                        <div class="progress-bar" style="width: ${progress}%"></div>
                    </div>
                    <small>${progress}%</small>
                </td>
                <td>${statusBadge}</td>
                <td>${new Date(batch.created_at).toLocaleString()}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        ${batch.status === 'processing'
    ? `
                            <button class="btn btn-success" onclick="cardManager.generateCards(${batch.id})">
                                <i class="bi bi-play"></i>
                            </button>
                        `
    : ''}
                        <button class="btn btn-info" onclick="cardManager.viewBatch(${batch.id})">
                            <i class="bi bi-eye"></i>
                        </button>
                        <button class="btn btn-warning" onclick="cardManager.exportBatch(${batch.id})">
                            <i class="bi bi-download"></i>
                        </button>
                    </div>
                </td>
            `;
      tbody.appendChild(row);
    });
  }

  // 创建批次
  async createBatch () {
    const form = document.getElementById('createBatchForm');
    const formData = new FormData(form);

    const batchData = {
      product_id: formData.get('product_id'),
      quantity: parseInt(formData.get('quantity')),
      valid_days: parseInt(formData.get('valid_days')),
      prefix: formData.get('prefix'),
      description: formData.get('description'),
      operator_id: this.getCurrentUserId(),
      operator_name: this.getCurrentUserName(),
    };

    try {
      this.showLoading();

      const response = await axios.post('api/cards/index.php?action=create_batch', batchData);

      this.showMessage(t('success.batch_created'), 'success');
      bootstrap.Modal.getInstance(document.getElementById('createBatchModal')).hide();
      form.reset();
      this.loadBatches();
    } catch (error) {
      console.error('创建批次失败:', error);
      this.showMessage(error.response?.data?.message || t('error.create_batch_failed'), 'danger');
    } finally {
      this.hideLoading();
    }
  }

  // 生成卡密
  async generateCards (batchId) {
    try {
      this.showLoading();

      const response = await axios.post('api/cards/index.php?action=generate_cards', {
        batch_id: batchId,
        count: 100,
      });

      this.showMessage(t('success.cards_generated', { count: response.data.data.generated_count }), 'success');
      this.loadBatches();
    } catch (error) {
      console.error('生成卡密失败:', error);
      this.showMessage(t('error.generate_cards_failed'), 'danger');
    } finally {
      this.hideLoading();
    }
  }

  // 加载卡密列表
  async loadCards (page = 1) {
    try {
      const filters = {
        page,
        limit: 20,
        status: document.getElementById('cardStatusFilter').value,
        product_id: document.getElementById('cardProductFilter').value,
        batch_id: document.getElementById('cardBatchFilter').value,
        search: document.getElementById('cardSearchInput').value,
      };

      const response = await axios.get('api/cards/index.php?action=list_cards', { params: filters });
      const data = response.data.data;

      this.renderCards(data.cards || []);
      this.renderPagination('cardsPagination', data.current_page, data.total_pages, (p) => this.loadCards(p));
    } catch (error) {
      console.error('加载卡密列表失败:', error);
      this.showMessage(t('error.load_cards_failed'), 'danger');
    }
  }

  // 渲染卡密列表
  renderCards (cards) {
    const tbody = document.getElementById('cardsTableBody');
    tbody.innerHTML = '';

    cards.forEach((card) => {
      const statusBadge = this.getCardStatusBadge(card.status);

      const row = document.createElement('tr');
      row.innerHTML = `
                <td><input type="checkbox" class="card-checkbox" value="${card.id}"></td>
                <td><code class="card-code">${card.card_code}</code></td>
                <td>${card.product_name || 'N/A'}</td>
                <td><code>${card.batch_no || 'N/A'}</code></td>
                <td>${statusBadge}</td>
                <td>${card.expires_at ? new Date(card.expires_at).toLocaleString() : 'N/A'}</td>
                <td>${card.used_at ? new Date(card.used_at).toLocaleString() : 'N/A'}</td>
                <td>${card.used_ip || 'N/A'}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-info" onclick="cardManager.viewCard(${card.id})">
                            <i class="bi bi-eye"></i>
                        </button>
                        ${card.status === 'active'
    ? `
                            <button class="btn btn-warning" onclick="cardManager.cancelCard(${card.id})">
                                <i class="bi bi-x-circle"></i>
                            </button>
                        `
    : ''}
                    </div>
                </td>
            `;
      tbody.appendChild(row);
    });

    // 绑定复选框事件
    document.querySelectorAll('.card-checkbox').forEach((checkbox) => {
      checkbox.addEventListener('change', (e) => {
        if (e.target.checked) {
          this.selectedCards.add(parseInt(e.target.value));
        } else {
          this.selectedCards.delete(parseInt(e.target.value));
        }
        this.updateSelectedCount();
      });
    });
  }

  // 全选/取消全选
  selectAllCards (e) {
    const checkboxes = document.querySelectorAll('.card-checkbox');
    checkboxes.forEach((checkbox) => {
      checkbox.checked = e.target.checked;
      const cardId = parseInt(checkbox.value);
      if (e.target.checked) {
        this.selectedCards.add(cardId);
      } else {
        this.selectedCards.delete(cardId);
      }
    });
    this.updateSelectedCount();
  }

  // 更新选中数量
  updateSelectedCount () {
    document.getElementById('selectedCardCount').textContent = this.selectedCards.size;
  }

  // 验证卡密
  async verifyCard (e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const cardCode = formData.get('card_code');
    const cardSecret = formData.get('card_secret');

    try {
      const response = await axios.post('api/cards/index.php?action=verify_card', {
        card_code: cardCode,
        card_secret: cardSecret,
      });

      const result = response.data.data;
      const resultDiv = document.getElementById('verifyResult');

      if (result.valid) {
        resultDiv.innerHTML = `
                    <div class="alert alert-success">
                        <h6><i class="bi bi-check-circle"></i> 卡密有效</h6>
                        <p>产品：${result.product_name}</p>
                        <p>状态：${result.status}</p>
                        ${result.expires_at ? `<p>过期时间：${new Date(result.expires_at).toLocaleString()}</p>` : ''}
                    </div>
                `;
      } else {
        resultDiv.innerHTML = `
                    <div class="alert alert-danger">
                        <h6><i class="bi bi-x-circle"></i> 卡密无效</h6>
                        <p>${result.message}</p>
                    </div>
                `;
      }
    } catch (error) {
      console.error('验证卡密失败:', error);
      document.getElementById('verifyResult').innerHTML = `
                <div class="alert alert-danger">
                    验证失败：${error.response?.data?.message || '服务器错误'}
                </div>
            `;
    }
  }

  // 使用卡密
  async redeemCard (e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const cardCode = formData.get('card_code');
    const cardSecret = formData.get('card_secret');
    const orderId = formData.get('order_id');

    try {
      const response = await axios.post('api/cards/index.php?action=redeem_card', {
        card_code: cardCode,
        card_secret: cardSecret,
        order_id: orderId,
      });

      const result = response.data.data;
      const resultDiv = document.getElementById('redeemResult');

      resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <h6><i class="bi bi-check-circle"></i> 卡密使用成功</h6>
                    <p>产品：${result.product_name}</p>
                    <p>使用时间：${new Date(result.used_at).toLocaleString()}</p>
                    <p>使用IP：${result.used_ip}</p>
                </div>
            `;

      e.target.reset();
    } catch (error) {
      console.error('使用卡密失败:', error);
      document.getElementById('redeemResult').innerHTML = `
                <div class="alert alert-danger">
                    使用失败：${error.response?.data?.message || '服务器错误'}
                </div>
            `;
    }
  }

  // 加载异常记录
  async loadAnomalies (page = 1) {
    try {
      const filters = {
        page,
        limit: 20,
        type: document.getElementById('anomalyTypeFilter').value,
        severity: document.getElementById('anomalySeverityFilter').value,
        status: document.getElementById('anomalyStatusFilter').value,
      };

      const response = await dataLoader.get('api/cards/index.php', {
        params: { action: 'get_anomalies', ...filters },
        showLoading: true,
        onLoadingStart: () => this.showLoading(),
        onLoadingEnd: () => this.hideLoading(),
        defaultErrorMessage: '加载异常记录失败',
      });

      this.renderAnomalies(response.data.anomalies || []);
    } catch (error) {
      console.error('加载异常记录失败:', error);
    }
  }

  // 渲染异常记录
  renderAnomalies (anomalies) {
    const tbody = document.getElementById('anomaliesTableBody');
    tbody.innerHTML = '';

    anomalies.forEach((anomaly) => {
      const typeBadge = this.getAnomalyTypeBadge(anomaly.anomaly_type);
      const severityBadge = this.getSeverityBadge(anomaly.severity);
      const statusBadge = this.getStatusBadge(anomaly.status);

      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${typeBadge}</td>
                <td>${severityBadge}</td>
                <td>${anomaly.description}</td>
                <td>${statusBadge}</td>
                <td>${new Date(anomaly.created_at).toLocaleString()}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        ${anomaly.status === 'open'
    ? `
                            <button class="btn btn-success" onclick="cardManager.resolveAnomaly(${anomaly.id})">
                                <i class="bi bi-check"></i>
                            </button>
                        `
    : ''}
                        <button class="btn btn-info" onclick="cardManager.viewAnomaly(${anomaly.id})">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </td>
            `;
      tbody.appendChild(row);
    });
  }

  // 检测异常
  async detectAnomalies () {
    try {
      this.showLoading();

      const response = await axios.post('api/cards/index.php?action=detect_anomalies', {}, {
        timeout: 30000, // 30秒超时
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
        },
      });

      if (!response.data || !response.data.success) {
        throw new Error(response.data?.message || '检测异常失败');
      }

      const result = response.data.data;
      this.showMessage(`检测完成，发现 ${result.total_anomalies || 0} 个异常`, 'info');
      this.loadAnomalies();
    } catch (error) {
      let errorMessage = '检测异常失败';

      if (error.code === 'ECONNABORTED') {
        errorMessage = '请求超时，请稍后重试';
      } else if (error.response) {
        errorMessage = error.response.data?.message || `服务器错误 (${error.response.status})`;
      } else if (error.request) {
        errorMessage = '网络连接失败，请检查网络';
      } else {
        errorMessage = error.message || errorMessage;
      }

      this.showMessage(errorMessage, 'danger');
      // 记录详细错误信息用于调试
      if (window.debugMode) {
        console.error('检测异常失败:', error);
      }
    } finally {
      this.hideLoading();
    }
  }

  // 过期处理
  async expireCards () {
    try {
      this.showLoading();

      const response = await axios.post('api/cards/index.php?action=expire_cards');
      const result = response.data.data;

      this.showMessage(`处理完成，过期 ${result.expired_count} 个卡密`, 'success');
      this.loadCards();
    } catch (error) {
      console.error('过期处理失败:', error);
      this.showMessage('过期处理失败', 'danger');
    } finally {
      this.hideLoading();
    }
  }

  // 导出卡密
  async exportCards () {
    try {
      const filters = {
        status: document.getElementById('cardStatusFilter').value,
        product_id: document.getElementById('cardProductFilter').value,
        batch_id: document.getElementById('cardBatchFilter').value,
      };

      const response = await axios.get('api/cards/index.php?action=export_cards', {
        params: { ...filters, format: 'csv' },
        responseType: 'blob',
      });

      const blob = new Blob([response.data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cards_export_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      this.showMessage('导出成功', 'success');
    } catch (error) {
      console.error('导出失败:', error);
      this.showMessage('导出失败', 'danger');
    }
  }

  // 显示批量操作
  showBatchOperation () {
    if (this.selectedCards.size === 0) {
      this.showMessage('请先选择要操作的卡密', 'warning');
      return;
    }

    bootstrap.Modal.getOrCreateInstance(document.getElementById('batchOperationModal')).show();
  }

  // 切换批量操作选项
  toggleBatchOperationOptions (e) {
    const operationType = e.target.value;
    const extendDaysDiv = document.getElementById('extendDaysDiv');

    if (operationType === 'extend') {
      extendDaysDiv.style.display = 'block';
    } else {
      extendDaysDiv.style.display = 'none';
    }
  }

  // 执行批量操作
  async executeBatchOperation () {
    const operationType = document.getElementById('batchOperationType').value;
    if (!operationType) {
      this.showMessage('请选择操作类型', 'warning');
      return;
    }

    const params = {};
    if (operationType === 'extend') {
      const extendDays = document.getElementById('extendDays').value;
      if (!extendDays) {
        this.showMessage('请输入延长天数', 'warning');
        return;
      }
      params.days = parseInt(extendDays);
    }

    try {
      this.showLoading();

      const response = await axios.post('api/cards/index.php?action=batch_operation', {
        operation: operationType,
        card_ids: Array.from(this.selectedCards),
        params,
      });

      this.showMessage(`批量操作完成，影响 ${response.data.data.affected_count} 个卡密`, 'success');
      bootstrap.Modal.getInstance(document.getElementById('batchOperationModal')).hide();
      this.selectedCards.clear();
      this.loadCards();
    } catch (error) {
      console.error('批量操作失败:', error);
      this.showMessage('批量操作失败', 'danger');
    } finally {
      this.hideLoading();
    }
  }

  // 获取状态徽章
  getStatusBadge (status) {
    const badges = {
      active: '<span class="badge bg-success">活跃</span>',
      used: '<span class="badge bg-secondary">已使用</span>',
      expired: '<span class="badge bg-danger">已过期</span>',
      cancelled: '<span class="badge bg-warning">已取消</span>',
      processing: '<span class="badge bg-info">处理中</span>',
      completed: '<span class="badge bg-success">已完成</span>',
      failed: '<span class="badge bg-danger">失败</span>',
      open: '<span class="badge bg-warning">待处理</span>',
      investigating: '<span class="badge bg-info">调查中</span>',
      resolved: '<span class="badge bg-success">已解决</span>',
      ignored: '<span class="badge bg-secondary">已忽略</span>',
    };
    return badges[status] || status;
  }

  // 获取卡密状态徽章
  getCardStatusBadge (status) {
    return this.getStatusBadge(status);
  }

  // 获取异常类型徽章
  getAnomalyTypeBadge (type) {
    const badges = {
      duplicate: '<span class="badge bg-danger">重复卡密</span>',
      abnormal_usage: '<span class="badge bg-warning">异常使用</span>',
      expiring_soon: '<span class="badge bg-info">即将过期</span>',
      security_risk: '<span class="badge bg-dark">安全风险</span>',
    };
    return badges[type] || type;
  }

  // 获取严重程度徽章
  getSeverityBadge (severity) {
    const badges = {
      low: '<span class="badge bg-secondary">低</span>',
      medium: '<span class="badge bg-warning">中</span>',
      high: '<span class="badge bg-danger">高</span>',
      critical: '<span class="badge bg-dark">严重</span>',
    };
    return badges[severity] || severity;
  }

  // 渲染分页（使用统一分页组件）
  renderPagination (elementId, currentPage, totalPages, onPageChange) {
    // 如果还没有分页管理器实例，创建一个
    if (!this.paginationManager) {
      this.paginationManager = new PaginationManager({
        containerId: elementId,
        currentPage,
        totalPages,
        onPageChange,
        language: this.currentLanguage || 'zh-CN',
      });
    } else {
      // 更新现有分页管理器的状态
      this.paginationManager.update({
        currentPage,
        totalPages,
      });
    }
  }

  // 初始化图表
  initCharts () {
    // 使用趋势图
    const usageCtx = document.getElementById('usageChart').getContext('2d');
    this.usageChart = new Chart(usageCtx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [{
          label: '使用数量',
          data: [],
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1,
        }],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    // 产品分布图
    const productCtx = document.getElementById('productChart').getContext('2d');
    this.productChart = new Chart(productCtx, {
      type: 'doughnut',
      data: {
        labels: [],
        datasets: [{
          data: [],
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56',
            '#4BC0C0',
            '#9966FF',
          ],
        }],
      },
      options: {
        responsive: true,
      },
    });
  }

  // 更新图表
  async updateCharts () {
    try {
      const response = await axios.get('api/cards/index.php?action=get_card_stats', {
        params: { days: 30 },
      });
      const stats = response.data.data;

      // 更新使用趋势图
      if (stats.daily_stats) {
        this.usageChart.data.labels = stats.daily_stats.map((s) => s.date);
        this.usageChart.data.datasets[0].data = stats.daily_stats.map((s) => s.used_count);
        this.usageChart.update();
      }

      // 更新产品分布图
      if (stats.product_stats) {
        this.productChart.data.labels = stats.product_stats.map((s) => s.product_name);
        this.productChart.data.datasets[0].data = stats.product_stats.map((s) => s.total_count);
        this.productChart.update();
      }
    } catch (error) {
      console.error('更新图表失败:', error);
    }
  }
}

// 初始化卡密管理器
const cardManager = new CardManager();
