# 发卡系统

一个功能完整的在线发卡系统，支持多种支付方式、卡密管理、订单处理和系统监控。

## 系统要求

- PHP 7.0 或更高版本
- MySQL 5.7 或更高版本
- Web服务器（Apache/Nginx）
- phpMyAdmin（推荐，用于数据库管理）

## 文件结构

```
发卡系统/
├── database.sql          # 数据库创建脚本
├── config.php           # 数据库配置文件
├── index.php           # 系统首页
└── README.md           # 说明文档
```

## 安装步骤

### 1. 数据库设置

#### 方法一：使用phpMyAdmin（推荐）

1. 打开phpMyAdmin（通常访问 http://localhost/phpmyadmin）
2. 点击"导入"选项卡
3. 选择 `database.sql` 文件
4. 点击"执行"按钮
5. 确认数据库 `card_system` 和表 `cards` 已创建成功

#### 方法二：使用命令行

```bash
# 登录MySQL
mysql -u root -p

# 执行SQL脚本
source /path/to/database.sql;

# 或者直接执行
mysql -u root -p < database.sql
```

#### 方法三：手动创建

```sql
-- 创建数据库
CREATE DATABASE IF NOT EXISTS `card_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE `card_system`;

-- 创建卡片表
CREATE TABLE IF NOT EXISTS `cards` (
    `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '卡片ID',
    `card_number` varchar(16) NOT NULL COMMENT '卡号（16位）',
    `card_type` varchar(20) NOT NULL COMMENT '卡片类型：借记卡/信用卡/预付卡',
    `status` varchar(20) NOT NULL DEFAULT '未激活' COMMENT '状态：未激活/正常/冻结',
    `expire_date` varchar(7) DEFAULT NULL COMMENT '有效期（格式：YYYY-MM）',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_card_number` (`card_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡片信息表';
```

### 2. 配置数据库连接

编辑 `config.php` 文件，修改数据库连接信息：

```php
// 数据库连接配置
define('DB_HOST', 'localhost');        // 数据库主机地址
define('DB_USER', 'root');             // 数据库用户名
define('DB_PASS', 'your_password');    // 数据库密码（修改为你的密码）
define('DB_NAME', 'card_system');      // 数据库名称
```

### 3. 部署文件

将所有文件上传到Web服务器目录，或者放置在本地服务器的根目录中。

## 测试方法

### 1. 测试数据库连接

创建测试文件 `test.php`：

```php
<?php
require_once 'config.php';

try {
    $db = getDB();
    echo "✅ 数据库连接成功！";
    
    // 测试查询
    $result = $db->fetch("SELECT COUNT(*) as count FROM cards");
    echo "<br>当前卡片数量：" . $result['count'];
    
} catch (Exception $e) {
    echo "❌ 数据库连接失败：" . $e->getMessage();
}
?>
```

访问 `http://localhost/发卡系统/test.php` 进行测试。

### 2. 测试首页

直接访问 `http://localhost/发卡系统/` 或 `http://localhost/发卡系统/index.php`

如果看到以下内容，说明系统运行正常：
- 系统标题和导航栏
- 卡片统计信息
- 功能按钮区域

### 3. 功能测试

目前系统包含基础功能：
- **导航栏**：包含"添加卡片"、"查询卡片"、"修改状态"链接（点击会提示功能开发中）
- **统计面板**：显示总卡片数、正常卡片、未激活卡片、冻结卡片数量
- **功能区域**：三个主要功能模块的入口

## 数据库表结构

### cards 表

| 字段名 | 类型 | 说明 | 约束 |
|--------|------|------|------|
| id | int(11) | 卡片ID | 主键，自增 |
| card_number | varchar(16) | 卡号 | 唯一，16位 |
| card_type | varchar(20) | 卡片类型 | 借记卡/信用卡/预付卡 |
| status | varchar(20) | 状态 | 未激活/正常/冻结，默认未激活 |
| expire_date | varchar(7) | 有效期 | 格式：YYYY-MM |
| create_time | datetime | 创建时间 | 自动记录 |

## 示例数据

系统会自动插入5条示例数据：

| 卡号 | 类型 | 状态 | 有效期 |
|------|------|------|--------|
| 6222021234567890 | 借记卡 | 未激活 | 2028-12 |
| 6222021234567891 | 借记卡 | 正常 | 2027-06 |
| 6222021234567892 | 信用卡 | 未激活 | 2029-03 |
| 6222021234567893 | 预付卡 | 正常 | 2026-12 |
| 6222021234567894 | 信用卡 | 冻结 | 2028-09 |

## 常见问题

### 1. 数据库连接失败

**错误信息**：`数据库连接失败！`

**解决方案**：
- 检查MySQL服务是否启动
- 确认数据库用户名和密码正确
- 确认数据库 `card_system` 已创建
- 检查 `config.php` 中的连接配置

### 2. 页面显示空白

**可能原因**：
- PHP语法错误
- 文件权限问题
- Web服务器配置错误

**解决方案**：
- 检查PHP错误日志
- 确认文件权限正确
- 测试其他PHP文件是否正常

### 3. 统计数据显示为0

**可能原因**：
- 数据库表为空
- SQL查询错误

**解决方案**：
- 检查数据库中是否有数据
- 执行SQL查询测试：`SELECT COUNT(*) FROM cards;`

## 开发扩展

### 添加新功能

1. **添加卡片功能**：
   - 创建 `add_card.php`
   - 实现表单提交和数据插入

2. **查询卡片功能**：
   - 创建 `search_card.php`
   - 实现搜索和显示功能

3. **修改状态功能**：
   - 创建 `update_status.php`
   - 实现状态更新功能

### 数据库操作示例

```php
// 插入数据
$data = [
    'card_number' => '6222021234567895',
    'card_type' => '借记卡',
    'status' => '未激活',
    'expire_date' => '2028-12'
];
$id = $db->insert('cards', $data);

// 查询数据
$cards = $db->fetchAll("SELECT * FROM cards WHERE status = ?", ['正常']);

// 更新数据
$db->update('cards', 
    ['status' => '冻结'], 
    'id = ?', 
    [1]
);
```

## 安全建议

1. **数据库安全**：
   - 使用强密码
   - 限制数据库用户权限
   - 定期备份数据

2. **代码安全**：
   - 输入验证和过滤
   - SQL注入防护（已使用PDO预处理）
   - XSS攻击防护

3. **服务器安全**：
   - HTTPS加密传输
   - 定期更新PHP版本
   - 配置防火墙

## 授权验证

本系统包含授权验证机制，用于检测代码是否被非法上传到未经授权的服务器。

### 授权服务器配置

默认情况下，以下服务器被视为授权服务器：
- localhost
- 127.0.0.1

如需添加更多授权服务器，请修改 `includes/license_validator.php` 文件中的以下数组：
```php
private static $authorizedDomains = [
    'localhost',
    '127.0.0.1',
    // 添加您的授权域名
];

private static $authorizedIPs = [
    '127.0.0.1',
    '::1',
    // 添加您的授权IP地址
];
```

详细信息请参阅：
- [LICENSE.md](LICENSE.md) - 软件许可协议
- [docs/authorization.md](docs/authorization.md) - 授权验证系统使用说明

## 技术支持

如遇到问题，请检查：
1. PHP和MySQL版本兼容性
2. 服务器配置是否正确
3. 数据库连接信息是否准确
4. 文件权限是否正确

---

**版本信息**：v1.0.0  
**最后更新**：<?php echo date('Y-m-d'); ?>