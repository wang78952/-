# 发卡系统部署文档

## 概述

发卡系统支持多环境 Docker 容器化部署，包括开发、测试、预发布和生产环境。本文档详细介绍了系统的部署流程、配置管理和运维操作。

## 环境要求

### 系统要求
- **操作系统**: Linux (推荐 Ubuntu 20.04+) 或 macOS
- **内存**: 最低 2GB，推荐 4GB+
- **磁盘空间**: 最低 10GB，推荐 20GB+
- **网络**: 稳定的互联网连接

### 软件依赖
- **Docker**: 20.10+
- **Docker Compose**: 2.0+
- **Git**: 2.0+
- **OpenSSL**: 1.1+ (用于 SSL 证书)

## 快速开始

### 1. 克隆项目
```bash
git clone https://github.com/your-org/card-system.git
cd card-system
```

### 2. 部署到开发环境
```bash
./deploy.sh dev
```

### 3. 访问系统
- **Web 应用**: http://localhost
- **API 接口**: http://localhost/api
- **监控面板**: http://localhost/monitoring

## 环境配置

### 开发环境 (dev)
```bash
./deploy.sh dev
```
- **配置文件**: `docker-compose.yml`
- **环境变量**: `.env`
- **端口**: 80 (HTTP)
- **调试模式**: 开启
- **日志级别**: debug

### 测试环境 (test)
```bash
./deploy.sh test --test
```
- **配置文件**: `docker-compose.test.yml`
- **环境变量**: `.env.test`
- **端口**: 8080 (Web), 8082 (监控)
- **调试模式**: 关闭
- **日志级别**: info

### 预发布环境 (staging)
```bash
./deploy.sh staging --backup --test
```
- **配置文件**: `docker-compose.staging.yml`
- **环境变量**: `.env.staging`
- **端口**: 8080 (Web), 8082 (监控)
- **调试模式**: 关闭
- **日志级别**: info

### 生产环境 (production)
```bash
./deploy.sh production --backup --migrate
```
- **配置文件**: `docker-compose.production.yml`
- **环境变量**: `.env.production`
- **端口**: 80 (HTTP), 443 (HTTPS)
- **调试模式**: 关闭
- **日志级别**: warning

## 部署选项

### 命令行选项
```bash
./deploy.sh [选项] [环境]

选项:
  -h, --help          显示帮助信息
  -v, --verbose       详细输出
  -f, --force         强制重新构建镜像
  -b, --backup        部署前备份
  -c, --check         仅检查环境，不部署
  -r, --rollback      回滚到上一个版本
  -u, --update        更新依赖包
  -m, --migrate       执行数据库迁移
  -t, --test          运行自动化测试
  --skip-tests        跳过测试
  --skip-backup       跳过备份
  --skip-health-check 跳过健康检查
```

### 使用示例

#### 基础部署
```bash
# 部署到开发环境
./deploy.sh dev

# 部署到测试环境
./deploy.sh test

# 部署到生产环境
./deploy.sh production
```

#### 高级部署
```bash
# 部署到生产环境并备份
./deploy.sh production --backup

# 部署到预发布环境并运行测试
./deploy.sh staging --test

# 强制重新构建并部署
./deploy.sh dev --force

# 部署并执行数据库迁移
./deploy.sh production --migrate
```

#### 环境检查
```bash
# 检查开发环境配置
./deploy.sh dev --check

# 详细模式检查
./deploy.sh production --check --verbose
```

#### 回滚操作
```bash
# 回滚生产环境
./deploy.sh production --rollback

# 回滚测试环境
./deploy.sh test --rollback
```

## 配置文件

### 环境变量配置

#### 开发环境 (.env)
```bash
# 应用配置
APP_ENV=dev
DEBUG=true
LOG_LEVEL=debug

# 数据库配置
DB_HOST=mysql
DB_NAME=card_system_dev
DB_USER=root
DB_PASS=root123
MYSQL_ROOT_PASSWORD=root123

# Redis 配置
REDIS_HOST=redis
REDIS_PASSWORD=

# API 配置
API_SECRET_KEY=dev_secret_key
JWT_SECRET=dev_jwt_secret
ENCRYPTION_KEY=dev_encryption_key
```

#### 生产环境 (.env.production)
```bash
# 应用配置
APP_ENV=production
DEBUG=false
LOG_LEVEL=warning

# 数据库配置
DB_HOST=mysql-master
DB_NAME=card_system
DB_USER=app_user
DB_PASS=secure_production_password
MYSQL_ROOT_PASSWORD=secure_root_password

# Redis 配置
REDIS_HOST=redis-cluster
REDIS_PASSWORD=secure_redis_password

# API 配置
API_SECRET_KEY=your_production_secret_key
JWT_SECRET=your_production_jwt_secret
ENCRYPTION_KEY=your_32_character_encryption_key

# 邮件配置
MAIL_HOST=smtp.yourdomain.com
MAIL_PORT=587
MAIL_USERNAME=noreply@yourdomain.com
MAIL_PASSWORD=your_mail_password
MAIL_FROM=noreply@yourdomain.com

# 安全配置
SESSION_LIFETIME=7200
MAX_LOGIN_ATTEMPTS=3
LOCKOUT_TIME=1800
```

### Docker Compose 配置

每个环境都有对应的 Docker Compose 配置文件：

- **开发环境**: `docker-compose.yml`
- **测试环境**: `docker-compose.test.yml`
- **预发布环境**: `docker-compose.staging.yml`
- **生产环境**: `docker-compose.production.yml`

## 服务架构

### 核心服务
- **web**: PHP Apache 应用服务器
- **nginx**: 反向代理和负载均衡器
- **mysql**: MySQL 数据库
- **redis**: Redis 缓存服务

### 监控服务
- **elasticsearch**: 日志存储和搜索
- **kibana**: 日志可视化界面
- **logstash**: 日志收集和处理
- **monitoring**: 系统监控服务

### 辅助服务
- **cron**: 定时任务服务
- **db-backup**: 数据库备份服务
- **fail2ban**: 安全防护服务

## 数据库管理

### 初始化
```bash
# 自动初始化（部署时执行）
./deploy.sh production --migrate

# 手动初始化
docker-compose exec web php scripts/install.php
```

### 备份
```bash
# 自动备份（部署时使用 --backup 选项）
./deploy.sh production --backup

# 手动备份
docker-compose exec mysql mysqldump -u root -p card_system > backup.sql
```

### 恢复
```bash
# 恢复数据库
docker-compose exec -T mysql mysql -u root -p card_system < backup.sql
```

## SSL 证书管理

### 开发环境
使用自签名证书（自动生成）：
```bash
# 生成自签名证书
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout ssl/private/key.pem \
    -out ssl/certs/cert.pem \
    -subj "/C=CN/ST=Beijing/L=Beijing/O=Card System/CN=localhost"
```

### 生产环境
使用 Let's Encrypt 证书：
```bash
# 安装 Certbot
sudo apt-get install certbot python3-certbot-nginx

# 获取证书
sudo certbot --nginx -d yourdomain.com

# 自动续期
sudo crontab -e
# 添加: 0 12 * * * /usr/bin/certbot renew --quiet
```

## 监控和日志

### 访问监控界面
- **Kibana**: http://localhost:5601
- **监控面板**: http://localhost/monitoring

### 查看日志
```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f web
docker-compose logs -f mysql
docker-compose logs -f nginx

# 查看应用日志
tail -f logs/apache2/error.log
tail -f logs/apache2/access.log
```

### 性能监控
```bash
# 查看容器资源使用
docker stats

# 查看系统资源
htop
df -h
free -m
```

## 故障排除

### 常见问题

#### 1. 服务启动失败
```bash
# 检查服务状态
docker-compose ps

# 查看错误日志
docker-compose logs [service_name]

# 重启服务
docker-compose restart [service_name]
```

#### 2. 数据库连接失败
```bash
# 检查数据库状态
docker-compose exec mysql mysql -u root -p -e "SHOW DATABASES;"

# 检查网络连接
docker-compose exec web ping mysql
```

#### 3. 端口冲突
```bash
# 检查端口占用
netstat -tulpn | grep :80
lsof -i :80

# 修改端口配置
vim docker-compose.yml
```

#### 4. 权限问题
```bash
# 修复文件权限
sudo chown -R $USER:$USER .
chmod -R 755 logs uploads cache
```

### 性能优化

#### 1. 数据库优化
```sql
-- 优化 MySQL 配置
SET GLOBAL innodb_buffer_pool_size = 1073741824; -- 1GB
SET GLOBAL max_connections = 200;
SET GLOBAL query_cache_size = 67108864; -- 64MB
```

#### 2. Redis 优化
```bash
# 优化 Redis 配置
echo "maxmemory 512mb" >> docker/redis/redis.conf
echo "maxmemory-policy allkeys-lru" >> docker/redis/redis.conf
```

#### 3. Nginx 优化
```nginx
# 启用 gzip 压缩
gzip on;
gzip_types text/plain text/css application/json application/javascript;

# 启用缓存
location ~* \.(css|js|png|jpg|jpeg|gif|ico|svg)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

## 安全配置

### 1. 防火墙设置
```bash
# 启用 UFW
sudo ufw enable

# 允许必要端口
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
```

### 2. 定期更新
```bash
# 更新系统包
sudo apt update && sudo apt upgrade

# 更新 Docker 镜像
docker-compose pull
docker-compose up -d
```

### 3. 安全扫描
```bash
# 使用 Docker 安全扫描
docker scan card-system:latest

# 使用 fail2ban 防护
sudo apt install fail2ban
sudo systemctl enable fail2ban
```

## CI/CD 集成

### GitHub Actions
系统已配置 GitHub Actions 工作流：
- **代码质量检查**: `.github/workflows/ci-cd.yml`
- **自动测试**: 推送时触发
- **自动部署**: 合并到主分支时触发

### 部署流程
1. **开发**: 推送到 `develop` 分支
2. **测试**: 自动部署到测试环境
3. **预发布**: 手动部署到预发布环境
4. **生产**: 审批后部署到生产环境

## 维护操作

### 日常维护
```bash
# 清理 Docker 资源
docker system prune -f

# 清理日志文件
find logs/ -name "*.log" -mtime +30 -delete

# 备份数据库
./scripts/backup-database.sh
```

### 升级流程
```bash
# 1. 备份当前版本
./deploy.sh production --backup

# 2. 拉取最新代码
git pull origin main

# 3. 更新依赖
./deploy.sh production --update

# 4. 部署新版本
./deploy.sh production --migrate

# 5. 运行测试
./deploy.sh production --test
```

## 技术支持

### 日志位置
- **应用日志**: `logs/apache2/`
- **Nginx 日志**: `logs/nginx/`
- **MySQL 日志**: `logs/mysql/`
- **系统日志**: `/var/log/syslog`

### 配置文件位置
- **Docker 配置**: `docker-compose.*.yml`
- **环境变量**: `.env*`
- **Nginx 配置**: `docker/nginx/`
- **MySQL 配置**: `docker/mysql/`

### 联系方式
- **技术支持**: support@yourdomain.com
- **文档**: https://docs.yourdomain.com
- **问题反馈**: https://github.com/your-org/card-system/issues

---

*本文档最后更新时间: 2024-01-20*