# API限流中间件系统

## 概述

本系统为发卡系统提供了完整的API请求频率控制和安全防护功能，包括：

- **请求频率限制**：限制单IP在指定时间窗口内的请求次数
- **智能阻止机制**：对频繁违规的IP地址进行自动阻止
- **灵活配置**：支持不同类型请求的差异化限流策略
- **实时监控**：提供完整的限流状态监控和管理界面
- **安全防护**：防止恶意攻击和API滥用

## 功能特性

### 🛡️ 核心功能

1. **多层级限流策略**
   - 默认限制：每分钟60次请求
   - 登录接口：每分钟5次请求
   - 敏感操作：每分钟10次请求
   - 文件上传：每分钟3次请求

2. **智能IP管理**
   - 自动检测和阻止恶意IP
   - 支持IP黑白名单
   - 动态调整阻止时长
   - 手动IP管理功能

3. **实时监控面板**
   - 活跃请求监控
   - 违规记录查看
   - 阻止IP管理
   - 统计数据分析

4. **安全防护机制**
   - 请求计数和限制
   - 违规记录和告警
   - 自动IP阻止
   - 异常请求检测

## 文件结构

```
发卡系统/
├── api/
│   ├── middleware.php              # 核心限流中间件
│   ├── rate_limit_management.php   # 限流管理API
│   └── config/
│       └── rate_limits.php         # 限流配置文件
├── database/
│   └── schema.sql                  # 数据库结构（包含限流表）
├── rate_limit_management.html      # 限流管理界面
└── README_RATE_LIMIT.md            # 本文档
```

## 数据库表结构

### 1. `rate_limits` - 限流记录表
```sql
CREATE TABLE rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    request_count INT DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_rate_limit (ip_address, endpoint, method, window_start),
    INDEX idx_ip_endpoint (ip_address, endpoint),
    INDEX idx_created_at (created_at)
);
```

### 2. `api_rate_limits` - 简化版限流记录表
```sql
CREATE TABLE api_rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    endpoint VARCHAR(255) NOT NULL,
    request_count INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip_created (ip_address, created_at),
    INDEX idx_endpoint (endpoint)
);
```

### 3. `rate_limit_violations` - 限流违规记录表
```sql
CREATE TABLE rate_limit_violations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    current_count INT NOT NULL,
    limit_count INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip_created (ip_address, created_at),
    INDEX idx_created_at (created_at)
);
```

### 4. `ip_blocks` - IP阻止记录表
```sql
CREATE TABLE ip_blocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL UNIQUE,
    block_reason VARCHAR(255) NOT NULL,
    block_until TIMESTAMP NOT NULL,
    violation_count INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_block_until (block_until),
    INDEX idx_ip_address (ip_address)
);
```

## 配置说明

### 限流配置文件 (`api/config/rate_limits.php`)

```php
<?php
return [
    'default' => [
        'requests_per_minute' => 60,
        'window_size' => 60,
        'block_duration' => 3600,
        'max_violations' => 3
    ],
    'login' => [
        'requests_per_minute' => 5,
        'window_size' => 60,
        'block_duration' => 7200,
        'max_violations' => 2
    ],
    'sensitive' => [
        'requests_per_minute' => 10,
        'window_size' => 60,
        'block_duration' => 5400,
        'max_violations' => 3
    ],
    'upload' => [
        'requests_per_minute' => 3,
        'window_size' => 60,
        'block_duration' => 9000,
        'max_violations' => 2
    ],
    'whitelist' => [
        '127.0.0.1',
        '::1'
    ],
    'blacklist' => [],
    'cleanup_interval' => 300,
    'enable_logging' => true,
    'enable_alerts' => true
];
```

## 使用方法

### 1. 在API中应用限流中间件

```php
<?php
require_once '../includes/Database.php';
require_once 'api/middleware.php';

$database = new Database();
$middleware = new ApiMiddleware($database);

// 应用CORS中间件
$middleware->cors();

// 应用身份验证中间件
$auth_result = $middleware->auth();
if (!$auth_result['success']) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'UNAUTHORIZED']);
    exit;
}

// 应用限流中间件（默认配置）
$rate_limit_result = $middleware->rateLimit();
if (!$rate_limit_result['success']) {
    http_response_code(429);
    echo json_encode([
        'success' => false, 
        'error' => 'RATE_LIMIT_EXCEEDED',
        'message' => $rate_limit_result['message']
    ]);
    exit;
}

// 应用权限检查中间件
$middleware->permission('admin');

// 继续处理API逻辑...
```

### 2. 自定义限流策略

```php
// 对登录接口使用更严格的限流
$rate_limit_result = $middleware->rateLimit([
    'type' => 'login',
    'requests_per_minute' => 5,
    'block_duration' => 7200
]);

// 对敏感操作使用特殊配置
$rate_limit_result = $middleware->rateLimit([
    'type' => 'sensitive',
    'endpoint' => '/api/admin/delete'
]);
```

### 3. 管理界面访问

访问 `rate_limit_management.html` 可以打开限流管理界面，提供以下功能：

- **总览**：查看实时请求状态和统计信息
- **违规记录**：查看所有限流违规记录
- **阻止IP**：管理被阻止的IP地址
- **IP管理**：查询IP信息，手动阻止/解除阻止IP
- **统计分析**：查看详细的限流统计数据

## API接口说明

### 限流管理API (`api/rate_limit_management.php`)

#### 1. 获取限流状态
```
GET /api/rate_limit_management.php/status
```

响应示例：
```json
{
    "success": true,
    "data": {
        "active_requests": [
            {
                "ip_address": "192.168.1.100",
                "endpoint": "/api/cards",
                "request_count": 15,
                "last_request": "2024-01-15 10:30:45"
            }
        ],
        "blocked_ips_count": 3,
        "recent_violations": 12,
        "timestamp": "2024-01-15 10:30:45"
    }
}
```

#### 2. 获取违规记录
```
GET /api/rate_limit_management.php/violations?page=1&limit=20
```

#### 3. 获取被阻止的IP列表
```
GET /api/rate_limit_management.php/blocked-ips
```

#### 4. 查询IP信息
```
GET /api/rate_limit_management.php/ip-info?ip=192.168.1.100
```

#### 5. 手动阻止IP
```
POST /api/rate_limit_management.php/block-ip
Content-Type: application/json

{
    "ip": "192.168.1.100",
    "duration": 3600,
    "reason": "管理员手动阻止"
}
```

#### 6. 解除IP阻止
```
POST /api/rate_limit_management.php/unblock-ip
Content-Type: application/json

{
    "ip": "192.168.1.100"
}
```

#### 7. 获取统计数据
```
GET /api/rate_limit_management.php/statistics
```

#### 8. 清理过期记录
```
DELETE /api/rate_limit_management.php/cleanup
```

## 安全特性

### 1. 多层防护机制

- **请求频率限制**：防止API被滥用
- **IP地址阻止**：对恶意IP进行封禁
- **违规记录**：记录所有违规行为
- **自动清理**：定期清理过期数据

### 2. 智能检测算法

- **动态限流**：根据请求类型调整限制策略
- **渐进式阻止**：违规次数越多，阻止时间越长
- **异常检测**：识别异常请求模式
- **实时响应**：即时阻止恶意请求

### 3. 数据保护

- **敏感数据加密**：对关键信息进行加密存储
- **访问权限控制**：只有管理员可以访问限流管理功能
- **审计日志**：记录所有管理操作
- **数据备份**：定期备份限流数据

## 性能优化

### 1. 数据库优化

- **索引优化**：为关键字段创建索引
- **分区表**：对大表进行分区处理
- **定期清理**：自动清理过期数据
- **连接池**：使用数据库连接池

### 2. 缓存机制

- **内存缓存**：使用Redis缓存热点数据
- **本地缓存**：缓存限流配置信息
- **CDN加速**：使用CDN加速静态资源
- **压缩传输**：启用gzip压缩

### 3. 监控告警

- **性能监控**：监控系统性能指标
- **异常告警**：及时通知异常情况
- **容量规划**：预测系统容量需求
- **日志分析**：分析系统运行日志

## 故障排除

### 常见问题

1. **限流不生效**
   - 检查中间件是否正确应用
   - 确认数据库表结构是否正确
   - 验证配置文件是否加载成功

2. **IP阻止失效**
   - 检查IP地址格式是否正确
   - 确认阻止时间是否已过期
   - 验证数据库记录是否存在

3. **统计数据异常**
   - 检查数据清理任务是否正常运行
   - 确认时间范围设置是否正确
   - 验证SQL查询逻辑是否正确

### 调试方法

1. **启用调试模式**
   ```php
   // 在middleware.php中启用调试
   $middleware = new ApiMiddleware($database, ['debug' => true]);
   ```

2. **查看日志记录**
   ```php
   // 查看限流相关日志
   $logger->info('Rate limit check', $debug_info);
   ```

3. **检查数据库状态**
   ```sql
   -- 查看当前限流记录
   SELECT * FROM rate_limits WHERE created_at > NOW() - INTERVAL 1 HOUR;
   
   -- 查看被阻止的IP
   SELECT * FROM ip_blocks WHERE block_until > NOW();
   ```

## 更新日志

### v1.0.0 (2024-01-15)
- 初始版本发布
- 实现基础限流功能
- 添加IP阻止机制
- 提供管理界面

### v1.1.0 (计划中)
- 添加分布式限流支持
- 增强机器学习检测
- 优化性能和内存使用
- 添加更多统计维度

## 许可证

本系统遵循MIT许可证，详情请参阅LICENSE文件。

## 技术支持

如有问题或建议，请联系技术支持团队：

- 邮箱：support@example.com
- 电话：400-123-4567
- 在线客服：工作日 9:00-18:00

---

**注意**：本限流系统设计用于保护API接口安全，请根据实际业务需求调整配置参数。在生产环境中使用前，请充分测试以确保系统稳定性。