<?php
require_once 'includes/SecurityUtils.php';
require_once 'includes/Database.php';
require_once 'includes/AuthManager.php';
require_once 'config.php';

// 初始化认证管理器
$authManager = new AuthManager();

// 获取当前用户信息（如果已登录）
$currentUser = null;
if ($authManager->isLoggedIn()) {
    $currentUser = $authManager->getCurrentUser();
}

// 执行登出操作
$logoutResult = $authManager->logout();

// 记录登出日志
if ($currentUser) {
    SecurityUtils::logSecurity('INFO', '用户登出', [
        'user_id' => $currentUser['id'],
        'username' => $currentUser['username'],
        'logout_time' => date('Y-m-d H:i:s'),
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
}

// 重定向到登录页面并显示登出成功消息
header('Location: login.php?logout=success');
exit;
?>