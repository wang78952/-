<?php
/**
 * 积分兑换管理页面
 * 管理积分兑换商品、兑换记录等
 */

// 检查管理员权限
require_once '../includes/functions/auth.php';
require_once '../includes/AuthManager.php';

// 使用AuthManager检查权限
$authManager = new AuthManager();
if (!$authManager->hasPermission('manage_points_exchange')) {
    header('Location: login.php');
    exit;
}

// 加载必要的服务
require_once '../includes/services/PointsExchangeService.php';
require_once '../includes/services/MemberService.php';
require_once '../includes/database/Database.php';
require_once '../includes/logger/Logger.php';

// 初始化服务
$db = new Database();
$logger = new Logger();
$memberService = new MemberService($db, $logger);
$exchangeService = new PointsExchangeService($db, $logger, null, $memberService);

// 获取操作类型
$action = $_GET['action'] ?? 'list';
$productId = $_GET['product_id'] ?? 0;
$exchangeId = $_GET['exchange_id'] ?? 0;

// 消息变量
$successMessage = '';
$errorMessage = '';

// 处理操作
switch ($action) {
    case 'create_product':
        // 创建商品表单提交处理
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            try {
                $productData = [
                    'name' => $_POST['name'],
                    'description' => $_POST['description'],
                    'points' => (int)$_POST['points'],
                    'stock' => (int)$_POST['stock'],
                    'status' => $_POST['status'],
                    'limit_per_user' => (int)$_POST['limit_per_user'],
                    'image_url' => $_POST['image_url'],
                    'start_date' => $_POST['start_date'] ?: null,
                    'end_date' => $_POST['end_date'] ?: null,
                    'sort_order' => (int)$_POST['sort_order'],
                    'type' => $_POST['type']
                ];
                
                // 处理元数据
                $metadata = [];
                if ($productData['type'] == 'coupon') {
                    $metadata['coupon_type_id'] = $_POST['coupon_type_id'] ?? null;
                    $metadata['discount'] = $_POST['discount'] ?? null;
                } elseif ($productData['type'] == 'virtual') {
                    $metadata['virtual_type'] = $_POST['virtual_type'] ?? 'code';
                }
                $productData['metadata'] = $metadata;
                
                $exchangeService->createExchangeProduct($productData);
                $successMessage = '商品创建成功！';
                $action = 'list'; // 返回列表页
            } catch (Exception $e) {
                $errorMessage = '创建失败: ' . $e->getMessage();
            }
        }
        break;
        
    case 'edit_product':
        // 编辑商品表单提交处理
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $productId) {
            try {
                $productData = [
                    'name' => $_POST['name'],
                    'description' => $_POST['description'],
                    'points' => (int)$_POST['points'],
                    'stock' => (int)$_POST['stock'],
                    'status' => $_POST['status'],
                    'limit_per_user' => (int)$_POST['limit_per_user'],
                    'image_url' => $_POST['image_url'],
                    'start_date' => $_POST['start_date'] ?: null,
                    'end_date' => $_POST['end_date'] ?: null,
                    'sort_order' => (int)$_POST['sort_order'],
                    'type' => $_POST['type']
                ];
                
                // 处理元数据
                $metadata = [];
                if ($productData['type'] == 'coupon') {
                    $metadata['coupon_type_id'] = $_POST['coupon_type_id'] ?? null;
                    $metadata['discount'] = $_POST['discount'] ?? null;
                } elseif ($productData['type'] == 'virtual') {
                    $metadata['virtual_type'] = $_POST['virtual_type'] ?? 'code';
                }
                $productData['metadata'] = $metadata;
                
                $exchangeService->updateExchangeProduct($productId, $productData);
                $successMessage = '商品更新成功！';
                $action = 'list'; // 返回列表页
            } catch (Exception $e) {
                $errorMessage = '更新失败: ' . $e->getMessage();
                // 保持在编辑页
            }
        }
        break;
        
    case 'delete_product':
        // 删除商品
        if ($productId) {
            try {
                $exchangeService->deleteExchangeProduct($productId);
                $successMessage = '商品删除成功！';
            } catch (Exception $e) {
                $errorMessage = '删除失败: ' . $e->getMessage();
            }
        }
        $action = 'list';
        break;
        
    case 'update_exchange_status':
        // 更新兑换记录状态
        if ($exchangeId && $_SERVER['REQUEST_METHOD'] == 'POST') {
            try {
                $newStatus = $_POST['status'] ?? 'pending';
                $remark = $_POST['remark'] ?? '';
                $exchangeService->updateExchangeRecordStatus($exchangeId, $newStatus, $remark);
                $successMessage = '状态更新成功！';
            } catch (Exception $e) {
                $errorMessage = '更新失败: ' . $e->getMessage();
            }
        }
        $action = 'exchange_records';
        break;
        
    default:
        $action = 'list';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>积分兑换管理 - 发卡系统管理后台</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/echarts/5.4.3/echarts.min.js"></script>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        /* 自定义样式 */
        .product-card {
            transition: all 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        .product-stock-badge {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .tab-content {
            min-height: 500px;
        }
        .points-tag {
            background-color: #ff6b6b;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        .type-badge {
            font-size: 0.75rem;
        }
        .exchange-status-badge {
            font-size: 0.875rem;
        }
        .status-pending { background-color: #ffc107; }
        .status-completed { background-color: #28a745; }
        .status-cancelled { background-color: #6c757d; }
        .status-shipped { background-color: #17a2b8; }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">积分兑换管理</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="?action=list" class="btn btn-primary">
                                <i class="fas fa-list"></i> 商品列表
                            </a>
                            <a href="?action=exchange_records" class="btn btn-info">
                                <i class="fas fa-history"></i> 兑换记录
                            </a>
                            <a href="?action=statistics" class="btn btn-secondary">
                                <i class="fas fa-chart-bar"></i> 数据统计
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- 消息提示 -->
                <?php if ($successMessage): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>成功！</strong> <?php echo $successMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <?php if ($errorMessage): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>错误！</strong> <?php echo $errorMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <!-- 商品列表 -->
                <?php if ($action == 'list'): ?>
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">积分兑换商品列表</h5>
                            <a href="?action=create_product" class="btn btn-success">
                                <i class="fas fa-plus"></i> 添加商品
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4">
                            <?php 
                                $products = $exchangeService->getExchangeProducts([], 1, 50)['products'];
                                foreach ($products as $product): 
                            ?>
                            <div class="col">
                                <div class="card product-card h-100">
                                    <div class="position-relative">
                                        <img 
                                            src="<?php echo $product['image_url'] ?: 'https://via.placeholder.com/300x200?text=No+Image'; ?>" 
                                            class="card-img-top" 
                                            alt="<?php echo $product['name']; ?>"
                                            style="height: 200px; object-fit: cover;"
                                        >
                                        <span class="product-stock-badge badge rounded-pill bg-primary">
                                            库存: <?php echo $product['stock']; ?>
                                        </span>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h5 class="card-title mb-0 truncate" style="max-width: 70%;">
                                                <?php echo $product['name']; ?>
                                            </h5>
                                            <span class="points-tag">
                                                <i class="fas fa-coins"></i> <?php echo $product['points']; ?>
                                            </span>
                                        </div>
                                        <div class="d-flex flex-wrap gap-2 mb-3">
                                            <span class="badge type-badge bg-secondary">
                                                <?php 
                                                    $typeMap = ['physical' => '实物商品', 'virtual' => '虚拟商品', 'coupon' => '优惠券'];
                                                    echo $typeMap[$product['type']] ?? $product['type'];
                                                ?>
                                            </span>
                                            <span class="badge type-badge bg-<?php echo $product['status'] == 'active' ? 'success' : 'danger'; ?>">
                                                <?php echo $product['status'] == 'active' ? '激活' : '禁用'; ?>
                                            </span>
                                            <?php if ($product['limit_per_user'] > 0): ?>
                                            <span class="badge type-badge bg-info">
                                                限兑: <?php echo $product['limit_per_user']; ?>件
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="card-text text-sm text-muted mb-4 truncate-3"><?php echo $product['description']; ?></p>
                                        <div class="d-flex justify-content-between">
                                            <a href="?action=edit_product&product_id=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i> 编辑
                                            </a>
                                            <button class="btn btn-sm btn-outline-danger delete-product-btn" data-product-id="<?php echo $product['id']; ?>">
                                                <i class="fas fa-trash"></i> 删除
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <!-- 创建/编辑商品 -->
                <?php elseif ($action == 'create_product' || ($action == 'edit_product' && $productId)): 
                    $isEdit = $action == 'edit_product';
                    $product = $isEdit ? $exchangeService->getExchangeProduct($productId) : [];
                ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo $isEdit ? '编辑商品' : '添加商品'; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row">
                                <!-- 基本信息 -->
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">商品名称 *</label>
                                        <input type="text" class="form-control" id="name" name="name" 
                                            value="<?php echo $product['name'] ?? ''; ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="description" class="form-label">商品描述</label>
                                        <textarea class="form-control" id="description" name="description" rows="4">
                                            <?php echo $product['description'] ?? ''; ?>
                                        </textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="image_url" class="form-label">商品图片URL</label>
                                        <input type="text" class="form-control" id="image_url" name="image_url" 
                                            value="<?php echo $product['image_url'] ?? ''; ?>">
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="points" class="form-label">所需积分 *</label>
                                            <input type="number" class="form-control" id="points" name="points" 
                                                value="<?php echo $product['points'] ?? 100; ?>" min="1" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="stock" class="form-label">库存数量 *</label>
                                            <input type="number" class="form-control" id="stock" name="stock" 
                                                value="<?php echo $product['stock'] ?? 100; ?>" min="0" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="limit_per_user" class="form-label">每人兑换限制</label>
                                            <input type="number" class="form-control" id="limit_per_user" name="limit_per_user" 
                                                value="<?php echo $product['limit_per_user'] ?? 0; ?>" min="0" 
                                                placeholder="0表示无限制">
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- 高级设置 -->
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h6 class="card-title mb-3">高级设置</h6>
                                            
                                            <div class="mb-3">
                                                <label for="status" class="form-label">状态</label>
                                                <select class="form-select" id="status" name="status">
                                                    <option value="active" <?php echo ($product['status'] ?? 'active') == 'active' ? 'selected' : ''; ?>>激活</option>
                                                    <option value="inactive" <?php echo ($product['status'] ?? 'active') == 'inactive' ? 'selected' : ''; ?>>禁用</option>
                                                </select>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="type" class="form-label">商品类型</label>
                                                <select class="form-select product-type-select" id="type" name="type">
                                                    <option value="physical" <?php echo ($product['type'] ?? 'physical') == 'physical' ? 'selected' : ''; ?>>实物商品</option>
                                                    <option value="virtual" <?php echo ($product['type'] ?? 'physical') == 'virtual' ? 'selected' : ''; ?>>虚拟商品</option>
                                                    <option value="coupon" <?php echo ($product['type'] ?? 'physical') == 'coupon' ? 'selected' : ''; ?>>优惠券</option>
                                                </select>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="sort_order" class="form-label">排序</label>
                                                <input type="number" class="form-control" id="sort_order" name="sort_order" 
                                                    value="<?php echo $product['sort_order'] ?? 0; ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="start_date" class="form-label">开始日期</label>
                                                <input type="datetime-local" class="form-control" id="start_date" name="start_date" 
                                                    value="<?php echo $product['start_date'] ? date('Y-m-d\TH:i', strtotime($product['start_date'])) : ''; ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="end_date" class="form-label">结束日期</label>
                                                <input type="datetime-local" class="form-control" id="end_date" name="end_date" 
                                                    value="<?php echo $product['end_date'] ? date('Y-m-d\TH:i', strtotime($product['end_date'])) : ''; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 特定类型设置 -->
                            <div class="type-specific-settings mt-4">
                                <div id="coupon-settings" class="card mb-3" style="display: none;">
                                    <div class="card-body">
                                        <h6 class="card-title mb-3">优惠券设置</h6>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="coupon_type_id" class="form-label">优惠券类型ID</label>
                                                <input type="text" class="form-control" id="coupon_type_id" name="coupon_type_id" 
                                                    value="<?php echo $product['metadata']['coupon_type_id'] ?? ''; ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="discount" class="form-label">折扣信息</label>
                                                <input type="text" class="form-control" id="discount" name="discount" 
                                                    value="<?php echo $product['metadata']['discount'] ?? ''; ?>" 
                                                    placeholder="例如: 满100减20或9折">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="virtual-settings" class="card mb-3" style="display: none;">
                                    <div class="card-body">
                                        <h6 class="card-title mb-3">虚拟商品设置</h6>
                                        <div class="mb-3">
                                            <label for="virtual_type" class="form-label">虚拟类型</label>
                                            <select class="form-select" id="virtual_type" name="virtual_type">
                                                <option value="code">兑换码</option>
                                                <option value="digital">数字内容</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo $isEdit ? '更新商品' : '创建商品'; ?>
                                </button>
                                <a href="?action=list" class="btn btn-secondary">取消</a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- 兑换记录 -->
                <?php elseif ($action == 'exchange_records'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">兑换记录管理</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>兑换码</th>
                                        <th>用户信息</th>
                                        <th>商品信息</th>
                                        <th>积分数量</th>
                                        <th>状态</th>
                                        <th>创建时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $page = $_GET['page'] ?? 1;
                                        $exchangeRecords = $exchangeService->getUserExchangeRecords(null, [], $page, 20)['records'] ?? [];
                                        foreach ($exchangeRecords as $record): 
                                    ?>
                                    <tr>
                                        <td><?php echo $record['id']; ?></td>
                                        <td><code><?php echo $record['exchange_code']; ?></code></td>
                                        <td>
                                            <div>ID: <?php echo $record['user_id']; ?></div>
                                            <div class="text-sm text-muted"><?php echo $record['contact_name'] ?? '-'; ?></div>
                                            <div class="text-sm text-muted"><?php echo $record['phone'] ?? '-'; ?></div>
                                        </td>
                                        <td>
                                            <div><?php echo $record['product_name']; ?></div>
                                            <div class="text-sm text-muted">ID: <?php echo $record['product_id']; ?></div>
                                        </td>
                                        <td>
                                            <span class="points-tag">
                                                <?php echo $record['product_points']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge rounded-pill exchange-status-badge text-white status-<?php echo $record['status']; ?>">
                                                <?php 
                                                    $statusMap = [
                                                        'pending' => '待处理',
                                                        'completed' => '已完成',
                                                        'cancelled' => '已取消',
                                                        'shipped' => '已发货'
                                                    ];
                                                    echo $statusMap[$record['status']] ?? $record['status'];
                                                ?>
                                            </span>
                                        </td>
                                        <td><?php echo $record['created_at']; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary view-record-btn" 
                                                data-exchange-id="<?php echo $record['id']; ?>">
                                                查看
                                            </button>
                                            <?php if ($record['status'] == 'pending'): ?>
                                            <button class="btn btn-sm btn-outline-success update-status-btn" 
                                                data-exchange-id="<?php echo $record['id']; ?>">
                                                更新状态
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- 分页 -->
                        <div class="d-flex justify-content-center mt-4">
                            <nav aria-label="Page navigation">
                                <ul class="pagination">
                                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>>
                                        <a class="page-link" href="?action=exchange_records&page=<?php echo $page - 1; ?>">
                                            上一页
                                        </a>
                                    </li>
                                    <li class="page-item active">
                                        <span class="page-link"><?php echo $page; ?></span>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?action=exchange_records&page=<?php echo $page + 1; ?>">
                                            下一页
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                
                <!-- 数据统计 -->
                <?php elseif ($action == 'statistics'): 
                    $stats = $exchangeService->getExchangeStatistics();
                ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-4">积分兑换数据概览</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="stat-item text-center p-4 bg-light rounded">
                                            <h6 class="text-muted">总兑换次数</h6>
                                            <p class="display-4 font-weight-bold mb-0"><?php echo $stats['total_exchanges']; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="stat-item text-center p-4 bg-light rounded">
                                            <h6 class="text-muted">总消耗积分</h6>
                                            <p class="display-4 font-weight-bold mb-0">
                                                <i class="fas fa-coins text-warning"></i> 
                                                <?php echo $stats['total_points_consumed']; ?>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mt-4">
                                        <div class="stat-item text-center p-4 bg-light rounded">
                                            <h6 class="text-muted">参与用户数</h6>
                                            <p class="display-4 font-weight-bold mb-0"><?php echo $stats['unique_users']; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mt-4">
                                        <div class="stat-item text-center p-4 bg-light rounded">
                                            <h6 class="text-muted">平均每次兑换</h6>
                                            <p class="display-4 font-weight-bold mb-0">
                                                <i class="fas fa-coins text-warning"></i> 
                                                <?php echo $stats['total_exchanges'] > 0 ? round($stats['total_points_consumed'] / $stats['total_exchanges']) : 0; ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-4">状态分布</h5>
                                <div id="statusChart" style="height: 300px;"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4">商品兑换排行</h5>
                        <div id="productRankingChart" style="height: 400px;"></div>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <!-- 兑换记录详情模态框 -->
    <div class="modal fade" id="recordDetailModal" tabindex="-1" aria-labelledby="recordDetailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="recordDetailModalLabel">兑换记录详情</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="recordDetailContent">
                    <!-- 动态加载 -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 状态更新模态框 -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="statusUpdateForm">
                    <input type="hidden" id="statusUpdateExchangeId" name="exchange_id">
                    <div class="modal-header">
                        <h5 class="modal-title" id="updateStatusModalLabel">更新订单状态</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="statusSelect" class="form-label">订单状态</label>
                            <select class="form-select" id="statusSelect" name="status">
                                <option value="pending">待处理</option>
                                <option value="completed">已完成</option>
                                <option value="shipped">已发货</option>
                                <option value="cancelled">已取消</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="statusRemark" class="form-label">备注</label>
                            <textarea class="form-control" id="statusRemark" name="remark" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">更新</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // 初始化类型切换显示
        document.addEventListener('DOMContentLoaded', function() {
            // 商品类型选择切换
            const productTypeSelect = document.querySelector('.product-type-select');
            if (productTypeSelect) {
                function updateTypeSettings() {
                    const type = productTypeSelect.value;
                    document.getElementById('coupon-settings').style.display = type === 'coupon' ? 'block' : 'none';
                    document.getElementById('virtual-settings').style.display = type === 'virtual' ? 'block' : 'none';
                }
                
                updateTypeSettings();
                productTypeSelect.addEventListener('change', updateTypeSettings);
            }
            
            // 删除商品按钮
            document.querySelectorAll('.delete-product-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product-id');
                    if (confirm('确定要删除此商品吗？')) {
                        window.location.href = `?action=delete_product&product_id=${productId}`;
                    }
                });
            });
            
            // 查看记录按钮
            document.querySelectorAll('.view-record-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const exchangeId = this.getAttribute('data-exchange-id');
                    fetchRecordDetail(exchangeId);
                });
            });
            
            // 更新状态按钮
            document.querySelectorAll('.update-status-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const exchangeId = this.getAttribute('data-exchange-id');
                    document.getElementById('statusUpdateExchangeId').value = exchangeId;
                    const statusModal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
                    statusModal.show();
                });
            });
            
            // 状态更新表单提交
            document.getElementById('statusUpdateForm').addEventListener('submit', function(e) {
                e.preventDefault();
                const exchangeId = document.getElementById('statusUpdateExchangeId').value;
                const status = document.getElementById('statusSelect').value;
                const remark = document.getElementById('statusRemark').value;
                
                const form = document.createElement('form');
                form.method = 'post';
                form.action = `?action=update_exchange_status&exchange_id=${exchangeId}`;
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = status;
                form.appendChild(statusInput);
                
                const remarkInput = document.createElement('input');
                remarkInput.type = 'hidden';
                remarkInput.name = 'remark';
                remarkInput.value = remark;
                form.appendChild(remarkInput);
                
                document.body.appendChild(form);
                form.submit();
            });
            
            // 加载图表
            if (document.getElementById('statusChart')) {
                initStatusChart();
            }
            
            if (document.getElementById('productRankingChart')) {
                initProductRankingChart();
            }
        });
        
        // 获取兑换记录详情
        function fetchRecordDetail(exchangeId) {
            const modal = new bootstrap.Modal(document.getElementById('recordDetailModal'));
            const content = document.getElementById('recordDetailContent');
            
            // 加载中
            content.innerHTML = '<div class="text-center py-4"><div class="spinner-border" role="status"></div></div>';
            
            // 模拟加载（实际应通过AJAX获取）
            setTimeout(() => {
                // 这里应替换为实际的AJAX请求
                window.location.href = `?action=exchange_records&view_id=${exchangeId}`;
            }, 500);
        }
        
        // 初始化状态分布图表
        function initStatusChart() {
            const chart = echarts.init(document.getElementById('statusChart'));
            
            const statusData = <?php echo json_encode($stats['status_statistics'] ?? []); ?>;
            const labels = [];
            const values = [];
            const colors = [];
            
            const statusColorMap = {
                'pending': '#ffc107',
                'completed': '#28a745',
                'cancelled': '#6c757d',
                'shipped': '#17a2b8'
            };
            
            const statusLabelMap = {
                'pending': '待处理',
                'completed': '已完成',
                'cancelled': '已取消',
                'shipped': '已发货'
            };
            
            statusData.forEach(item => {
                labels.push(statusLabelMap[item.status] || item.status);
                values.push(item.count);
                colors.push(statusColorMap[item.status] || '#6c757d');
            });
            
            const option = {
                tooltip: {
                    trigger: 'item',
                    formatter: '{b}: {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    left: 'left'
                },
                series: [{
                    name: '订单状态',
                    type: 'pie',
                    radius: '60%',
                    data: labels.map((label, index) => ({
                        name: label,
                        value: values[index]
                    })),
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    },
                    itemStyle: {
                        color: function(params) {
                            return colors[params.dataIndex];
                        }
                    }
                }]
            };
            
            chart.setOption(option);
            window.addEventListener('resize', () => chart.resize());
        }
        
        // 初始化商品排行图表
        function initProductRankingChart() {
            const chart = echarts.init(document.getElementById('productRankingChart'));
            
            // 模拟数据（实际应通过后端API获取）
            const option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'value'
                },
                yAxis: {
                    type: 'category',
                    data: ['商品5', '商品4', '商品3', '商品2', '商品1']
                },
                series: [{
                    name: '兑换次数',
                    type: 'bar',
                    data: [10, 32, 61, 45, 88],
                    itemStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                            { offset: 0, color: '#83bff6' },
                            { offset: 0.5, color: '#188df0' },
                            { offset: 1, color: '#188df0' }
                        ])
                    },
                    emphasis: {
                        itemStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                                { offset: 0, color: '#2378f7' },
                                { offset: 0.7, color: '#2378f7' },
                                { offset: 1, color: '#83bff6' }
                            ])
                        }
                    }
                }]
            };
            
            chart.setOption(option);
            window.addEventListener('resize', () => chart.resize());
        }
    </script>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>