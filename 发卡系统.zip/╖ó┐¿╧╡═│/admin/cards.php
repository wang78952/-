<?php
/**
 * 卡片管理页面
 */

require_once '../config.php';
require_once '../includes/AuthManager.php';
require_once '../includes/Database.php';
require_once '../includes/SecurityUtils.php';

// 启动会话
session_start();

// 检查管理员权限
$authManager = new AuthManager();
if (!$authManager->isLoggedIn() || !in_array($_SESSION['user_role'], ['admin', 'business_admin'])) {
    header('Location: ../login.php');
    exit;
}

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();

// 获取数据库连接
$db = Database::getInstance();

// 处理操作
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_card':
            try {
                $cardNumber = trim($_POST['card_number']);
                $cardHolder = trim($_POST['card_holder']);
                $idCard = trim($_POST['id_card']);
                $phone = trim($_POST['phone']);
                $cardType = $_POST['card_type'];
                $amount = (float)$_POST['amount'];
                $status = $_POST['status'] ?? 'active';
                $expiryDate = $_POST['expiry_date'];
                
                // 验证输入
                if (empty($cardNumber) || empty($cardHolder) || empty($idCard) || empty($phone) || empty($cardType) || empty($amount)) {
                    throw new Exception('所有必填字段都不能为空');
                }
                
                // 检查卡号是否已存在
                if ($db->queryOne("SELECT id FROM cards WHERE card_number = ?", [$cardNumber])) {
                    throw new Exception('卡号已存在');
                }
                
                // 加密敏感数据
                $encryptedCardNumber = SecurityUtils::encrypt($cardNumber);
                $encryptedCardHolder = SecurityUtils::encrypt($cardHolder);
                $encryptedIdCard = SecurityUtils::encrypt($idCard);
                $encryptedPhone = SecurityUtils::encrypt($phone);
                
                // 插入卡片
                $db->query("INSERT INTO cards (card_number, card_holder, id_card, phone, card_type, amount, status, expiry_date, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())", 
                    [$encryptedCardNumber, $encryptedCardHolder, $encryptedIdCard, $encryptedPhone, $cardType, $amount, $status, $expiryDate, $currentUser['id']]);
                
                $message = '卡片添加成功';
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "添加卡片: $cardNumber", 'card_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'edit_card':
            try {
                $cardId = (int)$_POST['card_id'];
                $cardNumber = trim($_POST['card_number']);
                $cardHolder = trim($_POST['card_holder']);
                $idCard = trim($_POST['id_card']);
                $phone = trim($_POST['phone']);
                $cardType = $_POST['card_type'];
                $amount = (float)$_POST['amount'];
                $status = $_POST['status'] ?? 'active';
                $expiryDate = $_POST['expiry_date'];
                
                // 验证输入
                if (empty($cardNumber) || empty($cardHolder) || empty($idCard) || empty($phone) || empty($cardType) || empty($amount)) {
                    throw new Exception('所有必填字段都不能为空');
                }
                
                // 检查卡号是否已存在（排除当前卡片）
                if ($db->queryOne("SELECT id FROM cards WHERE card_number = ? AND id != ?", [$cardNumber, $cardId])) {
                    throw new Exception('卡号已存在');
                }
                
                // 加密敏感数据
                $encryptedCardNumber = SecurityUtils::encrypt($cardNumber);
                $encryptedCardHolder = SecurityUtils::encrypt($cardHolder);
                $encryptedIdCard = SecurityUtils::encrypt($idCard);
                $encryptedPhone = SecurityUtils::encrypt($phone);
                
                // 更新卡片信息
                $db->query("UPDATE cards SET card_number = ?, card_holder = ?, id_card = ?, phone = ?, card_type = ?, amount = ?, status = ?, expiry_date = ?, updated_at = NOW() WHERE id = ?", 
                    [$encryptedCardNumber, $encryptedCardHolder, $encryptedIdCard, $encryptedPhone, $cardType, $amount, $status, $expiryDate, $cardId]);
                
                $message = '卡片信息更新成功';
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "更新卡片: $cardNumber", 'card_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'delete_card':
            try {
                $cardId = (int)$_POST['card_id'];
                
                // 获取卡片信息
                $card = $db->queryOne("SELECT card_number FROM cards WHERE id = ?", [$cardId]);
                if (!$card) {
                    throw new Exception('卡片不存在');
                }
                
                // 删除卡片
                $db->query("DELETE FROM cards WHERE id = ?", [$cardId]);
                
                $message = '卡片删除成功';
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "删除卡片: {$card['card_number']}", 'card_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'batch_add':
            try {
                $batchName = trim($_POST['batch_name']);
                $cardType = $_POST['card_type'];
                $amount = (float)$_POST['amount'];
                $count = (int)$_POST['count'];
                $expiryDate = $_POST['expiry_date'];
                
                if (empty($batchName) || empty($cardType) || empty($amount) || empty($count) || empty($expiryDate)) {
                    throw new Exception('所有必填字段都不能为空');
                }
                
                // 创建批次记录
                $db->query("INSERT INTO card_batches (batch_name, card_type, amount, card_count, status, created_by, created_at) VALUES (?, ?, ?, ?, 'active', ?, NOW())",
                    [$batchName, $cardType, $amount, $count, $currentUser['id']]);
                $batchId = $db->lastInsertId();
                
                // 批量生成卡片
                $cards = [];
                for ($i = 0; $i < $count; $i++) {
                    $cardNumber = generateCardNumber();
                    $cardHolder = '批量生成用户' . ($i + 1);
                    $idCard = generateIdCard();
                    $phone = generatePhone();
                    
                    // 加密敏感数据
                    $encryptedCardNumber = SecurityUtils::encrypt($cardNumber);
                    $encryptedCardHolder = SecurityUtils::encrypt($cardHolder);
                    $encryptedIdCard = SecurityUtils::encrypt($idCard);
                    $encryptedPhone = SecurityUtils::encrypt($phone);
                    
                    $cards[] = [
                        $encryptedCardNumber, $encryptedCardHolder, $encryptedIdCard, $encryptedPhone,
                        $cardType, $amount, 'active', $expiryDate, $batchId, $currentUser['id']
                    ];
                }
                
                // 批量插入
                $placeholders = str_repeat('(?, ?, ?, ?, ?, ?, ?, ?, ?, ?),', $count);
                $placeholders = rtrim($placeholders, ',');
                $params = array_merge(...$cards);
                
                $db->query("INSERT INTO cards (card_number, card_holder, id_card, phone, card_type, amount, status, expiry_date, batch_id, created_by, created_at) VALUES $placeholders", $params);
                
                $message = "成功批量添加 {$count} 张卡片";
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "批量添加卡片: {$count}张", 'card_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'import_cards':
            try {
                $cardType = $_POST['card_type'];
                $amount = (float)$_POST['amount'];
                $expiryDate = $_POST['expiry_date'];
                $batchName = trim($_POST['batch_name']);
                $skipDuplicate = isset($_POST['skip_duplicate']) ? true : false;
                
                if (empty($cardType) || empty($amount) || empty($expiryDate) || empty($batchName)) {
                    throw new Exception('所有必填字段都不能为空');
                }
                
                // 处理导入数据
                $cardsData = [];
                if (!empty($_POST['paste_content'])) {
                    // 粘贴文本导入
                    $lines = explode("\n", $_POST['paste_content']);
                    foreach ($lines as $line) {
                        $line = trim($line);
                        if (!empty($line)) {
                            $cardsData[] = $line;
                        }
                    }
                } elseif (!empty($_FILES['upload_file']['tmp_name'])) {
                    // 文件上传导入
                    $fileContent = file_get_contents($_FILES['upload_file']['tmp_name']);
                    $lines = explode("\n", $fileContent);
                    foreach ($lines as $line) {
                        $line = trim($line);
                        if (!empty($line)) {
                            $cardsData[] = $line;
                        }
                    }
                } else {
                    throw new Exception('未提供导入数据');
                }
                
                // 去重
                $cardsData = array_unique($cardsData);
                
                if (empty($cardsData)) {
                    throw new Exception('导入数据为空或全为重复数据');
                }
                
                // 创建批次记录
                $db->query("INSERT INTO card_batches (batch_name, card_type, amount, card_count, status, created_by, created_at) VALUES (?, ?, ?, ?, 'active', ?, NOW())",
                    [$batchName, $cardType, $amount, count($cardsData), $currentUser['id']]);
                $batchId = $db->lastInsertId();
                
                // 准备插入数据
                $cards = [];
                $successCount = 0;
                $errorCount = 0;
                
                foreach ($cardsData as $cardNumber) {
                    try {
                        // 检查是否重复
                        if ($skipDuplicate && $db->queryOne("SELECT id FROM cards WHERE card_number = ?", [SecurityUtils::encrypt($cardNumber)])) {
                            $errorCount++;
                            continue;
                        }
                        
                        // 生成卡片持有者信息
                        $cardHolder = '导入用户' . ($successCount + 1);
                        $idCard = generateIdCard();
                        $phone = generatePhone();
                        
                        // 加密敏感数据
                        $encryptedCardNumber = SecurityUtils::encrypt($cardNumber);
                        $encryptedCardHolder = SecurityUtils::encrypt($cardHolder);
                        $encryptedIdCard = SecurityUtils::encrypt($idCard);
                        $encryptedPhone = SecurityUtils::encrypt($phone);
                        
                        $cards[] = [
                            $encryptedCardNumber, $encryptedCardHolder, $encryptedIdCard, $encryptedPhone,
                            $cardType, $amount, 'active', $expiryDate, $batchId, $currentUser['id']
                        ];
                        $successCount++;
                    } catch (Exception $e) {
                        $errorCount++;
                    }
                }
                
                // 批量插入
                if (!empty($cards)) {
                    $placeholders = str_repeat('(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW()),', count($cards));
                    $placeholders = rtrim($placeholders, ',');
                    $params = array_merge(...$cards);
                    
                    $db->query("INSERT INTO cards (card_number, card_holder, id_card, phone, card_type, amount, status, expiry_date, batch_id, created_by, created_at) VALUES $placeholders", $params);
                }
                
                $message = "成功导入 {$successCount} 张卡片";
                if ($errorCount > 0) {
                    $message .= "，失败 {$errorCount} 张";
                }
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "导入卡片: 成功{$successCount}张,失败{$errorCount}张", 'card_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'export_cards':
            try {
                $exportFormat = $_POST['export_format'] ?? 'txt';
                $selectedFields = isset($_POST['selected_fields']) ? $_POST['selected_fields'] : [];
                $statusFilter = $_POST['status_filter'] ?? '';
                $typeFilter = $_POST['type_filter'] ?? '';
                
                // 构建查询条件
                $whereClause = '';
                $params = [];
                
                if (!empty($statusFilter)) {
                    $whereClause .= " AND status = ?";
                    $params[] = $statusFilter;
                }
                
                if (!empty($typeFilter)) {
                    $whereClause .= " AND card_type = ?";
                    $params[] = $typeFilter;
                }
                
                // 查询卡片数据
                $query = "SELECT * FROM cards WHERE 1=1 $whereClause";
                $cards = $db->query($query, $params);
                
                if ($exportFormat === 'txt') {
                    // TXT格式导出
                    header('Content-Type: text/plain; charset=utf-8');
                    header('Content-Disposition: attachment; filename=cards_export_' . date('YmdHis') . '.txt');
                    
                    foreach ($cards as $card) {
                        // 解密卡号
                        $cardNumber = SecurityUtils::decrypt($card['card_number']);
                        echo $cardNumber . "\n";
                    }
                    exit;
                } else if ($exportFormat === 'excel') {
                    // Excel格式导出（CSV）
                    header('Content-Type: text/csv; charset=utf-8');
                    header('Content-Disposition: attachment; filename=cards_export_' . date('YmdHis') . '.csv');
                    
                    // 初始化输出缓冲区
                    $output = fopen('php://output', 'w');
                    
                    // 设置BOM以支持Excel正确识别UTF-8编码
                    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
                    
                    // 定义默认导出字段
                    $defaultFields = ['card_number', 'card_holder', 'card_type', 'amount', 'status', 'expiry_date'];
                    $fieldsToExport = !empty($selectedFields) ? $selectedFields : $defaultFields;
                    
                    // 输出表头
                    $headers = [];
                    $fieldMap = [
                        'card_number' => '卡号',
                        'card_holder' => '持卡人',
                        'id_card' => '身份证号',
                        'phone' => '手机号',
                        'card_type' => '卡片类型',
                        'amount' => '金额',
                        'status' => '状态',
                        'expiry_date' => '过期日期',
                        'created_at' => '创建时间',
                        'updated_at' => '更新时间'
                    ];
                    
                    foreach ($fieldsToExport as $field) {
                        $headers[] = isset($fieldMap[$field]) ? $fieldMap[$field] : $field;
                    }
                    fputcsv($output, $headers);
                    
                    // 输出数据行
                    foreach ($cards as $card) {
                        $row = [];
                        foreach ($fieldsToExport as $field) {
                            $value = '';
                            switch ($field) {
                                case 'card_number':
                                case 'card_holder':
                                case 'id_card':
                                case 'phone':
                                    $value = SecurityUtils::decrypt($card[$field]);
                                    break;
                                case 'card_type':
                                    $value = $card[$field] === 'debit' ? '借记卡' : ($card[$field] === 'credit' ? '信用卡' : '预付费卡');
                                    break;
                                case 'status':
                                    $value = $card[$field] === 'active' ? '活跃' : ($card[$field] === 'inactive' ? '停用' : '过期');
                                    break;
                                default:
                                    $value = $card[$field] ?? '';
                            }
                            $row[] = $value;
                        }
                        fputcsv($output, $row);
                    }
                    
                    fclose($output);
                    exit;
                }
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
    }
}

// 获取卡片列表
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// 搜索条件
$search = trim($_GET['search'] ?? '');
$card_type_filter = $_GET['card_type'] ?? '';
$status_filter = $_GET['status'] ?? '';

$whereConditions = [];
$params = [];

if (!empty($search)) {
    $whereConditions[] = "(card_number LIKE ? OR card_holder LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($card_type_filter)) {
    $whereConditions[] = "card_type = ?";
    $params[] = $card_type_filter;
}

if (!empty($status_filter)) {
    $whereConditions[] = "status = ?";
    $params[] = $status_filter;
}

$whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// 获取总数
$totalQuery = "SELECT COUNT(*) as total FROM cards $whereClause";
$totalResult = $db->queryOne($totalQuery, $params);
$totalCards = $totalResult['total'];
$totalPages = ceil($totalCards / $limit);

// 获取卡片列表
$cardsQuery = "SELECT c.*, u.username as created_by_name FROM cards c LEFT JOIN users u ON c.created_by = u.id $whereClause ORDER BY c.created_at DESC LIMIT $limit OFFSET $offset";
$cards = $db->query($cardsQuery, $params);

// 解密和脱敏处理
foreach ($cards as &$card) {
    $card['card_number'] = SecurityUtils::decrypt($card['card_number']);
    $card['card_holder'] = SecurityUtils::decrypt($card['card_holder']);
    $card['id_card'] = SecurityUtils::decrypt($card['id_card']);
    $card['phone'] = SecurityUtils::decrypt($card['phone']);
    
    // 根据用户角色进行脱敏
    $card['card_number'] = maskCardNumber($card['card_number'], $currentUser['role']);
    $card['card_holder'] = maskName($card['card_holder'], $currentUser['role']);
    $card['id_card'] = maskIdCard($card['id_card'], $currentUser['role']);
    $card['phone'] = maskPhone($card['phone'], $currentUser['role']);
}

// 辅助函数
function generateCardNumber() {
    return '6222' . str_pad(mt_rand(0, 9999999999999999), 16, '0', STR_PAD_LEFT);
}

function generateIdCard() {
    $area = mt_rand(110000, 659004);
    $birth = mt_rand(19500101, 20001231);
    $sequence = mt_rand(100, 999);
    return $area . $birth . $sequence . mt_rand(0, 9);
}

function generatePhone() {
    $prefixes = ['130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '150', '151', '152', '153', '155', '156', '157', '158', '159', '180', '181', '182', '183', '184', '185', '186', '187', '188', '189'];
    return $prefixes[array_rand($prefixes)] . str_pad(mt_rand(0, 99999999), 8, '0', STR_PAD_LEFT);
}

function maskCardNumber($cardNumber, $role) {
    if (in_array($role, ['admin', 'business_admin'])) {
        return substr($cardNumber, 0, 4) . ' **** **** ' . substr($cardNumber, -4);
    }
    return substr($cardNumber, 0, 4) . ' **** **** ****';
}

function maskName($name, $role) {
    if (in_array($role, ['admin', 'business_admin'])) {
        return substr($name, 0, 1) . '**';
    }
    return '***';
}

function maskIdCard($idCard, $role) {
    if (in_array($role, ['admin', 'business_admin'])) {
        return substr($idCard, 0, 6) . '********' . substr($idCard, -4);
    }
    return '************';
}

function maskPhone($phone, $role) {
    if (in_array($role, ['admin', 'business_admin'])) {
        return substr($phone, 0, 3) . '****' . substr($phone, -4);
    }
    return '********';
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡片管理 - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/ui-components.css">
    <style>
        .page-header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        .search-filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .filter-form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .filter-group label {
            font-size: 14px;
            color: #555;
            font-weight: 500;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .cards-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .table tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-active {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .status-inactive {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .status-expired {
            background: #fdebd0;
            color: #dc7633;
        }
        
        .card-type-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .type-debit {
            background: #d6eaf8;
            color: #2874a6;
        }
        
        .type-credit {
            background: #e8daef;
            color: #6c3483;
        }
        
        .type-prepaid {
            background: #d5f4e6;
            color: #239b56;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn-sm {
            padding: 4px 8px;
            font-size: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-edit {
            background: #3498db;
            color: white;
        }
        
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        
        .modal-content {
            background: white;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
            position: relative;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }
        
        .alert {
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d5f4e6;
            color: #27ae60;
            border: 1px solid #27ae60;
        }
        
        .alert-error {
            background: #fadbd8;
            color: #e74c3c;
            border: 1px solid #e74c3c;
        }
        
        .batch-form {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        
        .batch-form h4 {
            margin-bottom: 15px;
            color: #333;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .header-actions {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>管理控制台</h2>
                <div class="user-info">
                    <?php echo htmlspecialchars($currentUser['username']); ?>
                    <br>
                    <small><?php echo htmlspecialchars($currentUser['role']); ?></small>
                </div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i>📊</i>仪表板</a></li>
                <li><a href="users.php"><i>👥</i>用户管理</a></li>
                <li><a href="cards.php" class="active"><i>💳</i>卡片管理</a></li>
                <li><a href="orders.php"><i>📦</i>订单管理</a></li>
                <li><a href="products.php"><i>🛍️</i>产品管理</a></li>
                <li><a href="security.php"><i>🔒</i>安全管理</a></li>
                <li><a href="logs.php"><i>📝</i>日志管理</a></li>
                <li><a href="settings.php"><i>⚙️</i>系统设置</a></li>
                <li><a href="../logout.php"><i>🚪</i>退出登录</a></li>
            </ul>
        </div>

        <!-- 主要内容 -->
        <div class="main-content">
            <!-- 页面头部 -->
            <div class="page-header">
                <h1>卡片管理</h1>
                <div class="header-actions">
                    <button class="btn btn-success" onclick="showBatchAddModal()">批量添加</button>
                    <button class="btn btn-primary" onclick="showAddCardModal()">添加卡片</button>
                    <button class="btn btn-info" onclick="showImportModal()">导入卡密</button>
                    <button class="btn btn-warning" onclick="showExportModal()">导出卡密</button>
                </div>
            </div>

            <!-- 消息提示 -->
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- 搜索过滤 -->
            <div class="search-filters">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <label>搜索</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="卡号或持卡人">
                    </div>
                    <div class="filter-group">
                        <label>卡片类型</label>
                        <select name="card_type">
                            <option value="">全部</option>
                            <option value="debit" <?php echo $card_type_filter === 'debit' ? 'selected' : ''; ?>>借记卡</option>
                            <option value="credit" <?php echo $card_type_filter === 'credit' ? 'selected' : ''; ?>>信用卡</option>
                            <option value="prepaid" <?php echo $card_type_filter === 'prepaid' ? 'selected' : ''; ?>>预付卡</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>状态</label>
                        <select name="status">
                            <option value="">全部</option>
                            <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>正常</option>
                            <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>禁用</option>
                            <option value="expired" <?php echo $status_filter === 'expired' ? 'selected' : ''; ?>>过期</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">搜索</button>
                    <a href="cards.php" class="btn btn-secondary">重置</a>
                </form>
            </div>

            <!-- 卡片列表 -->
            <div class="cards-table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>卡号</th>
                            <th>持卡人</th>
                            <th>身份证</th>
                            <th>手机号</th>
                            <th>类型</th>
                            <th>金额</th>
                            <th>状态</th>
                            <th>到期日</th>
                            <th>创建人</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($cards)): ?>
                            <tr>
                                <td colspan="11" style="text-align: center; padding: 40px;">没有找到卡片</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($cards as $card): ?>
                                <tr>
                                    <td><?php echo $card['id']; ?></td>
                                    <td><?php echo htmlspecialchars($card['card_number']); ?></td>
                                    <td><?php echo htmlspecialchars($card['card_holder']); ?></td>
                                    <td><?php echo htmlspecialchars($card['id_card']); ?></td>
                                    <td><?php echo htmlspecialchars($card['phone']); ?></td>
                                    <td>
                                        <span class="card-type-badge type-<?php echo $card['card_type']; ?>">
                                            <?php 
                                            $types = [
                                                'debit' => '借记卡',
                                                'credit' => '信用卡',
                                                'prepaid' => '预付卡'
                                            ];
                                            echo $types[$card['card_type']] ?? $card['card_type'];
                                            ?>
                                        </span>
                                    </td>
                                    <td>¥<?php echo number_format($card['amount'], 2); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $card['status']; ?>">
                                            <?php 
                                            $statuses = [
                                                'active' => '正常',
                                                'inactive' => '禁用',
                                                'expired' => '过期'
                                            ];
                                            echo $statuses[$card['status']] ?? $card['status'];
                                            ?>
                                        </span>
                                    </td>
                                    <td><?php echo $card['expiry_date']; ?></td>
                                    <td><?php echo htmlspecialchars($card['created_by_name'] ?? '系统'); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn-sm btn-edit" data-action="edit-card" data-card-id="<?php echo $card['id']; ?>">编辑</button>
                                            <button class="btn-sm btn-delete" data-action="delete-card" data-card-id="<?php echo $card['id']; ?>">删除</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- 分页 -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&card_type=<?php echo urlencode($card_type_filter); ?>&status=<?php echo urlencode($status_filter); ?>">上一页</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&card_type=<?php echo urlencode($card_type_filter); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&card_type=<?php echo urlencode($card_type_filter); ?>&status=<?php echo urlencode($status_filter); ?>">下一页</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 添加卡片模态框 -->
    <div id="addCardModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                    <h3>添加卡片</h3>
                    <button class="modal-close" data-action="hide-modal" data-modal-id="addCardModal">&times;</button>
                </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_card">
                <div class="form-group">
                    <label>卡号 *</label>
                    <input type="text" name="card_number" placeholder="请输入16-19位卡号" required>
                </div>
                <div class="form-group">
                    <label>持卡人 *</label>
                    <input type="text" name="card_holder" required>
                </div>
                <div class="form-group">
                    <label>身份证号 *</label>
                    <input type="text" name="id_card" placeholder="18位身份证号" required>
                </div>
                <div class="form-group">
                    <label>手机号 *</label>
                    <input type="text" name="phone" placeholder="11位手机号" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>卡片类型 *</label>
                        <select name="card_type" required>
                            <option value="">请选择类型</option>
                            <option value="debit">借记卡</option>
                            <option value="credit">信用卡</option>
                            <option value="prepaid">预付卡</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>金额 *</label>
                        <input type="number" name="amount" step="0.01" min="0" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>状态</label>
                        <select name="status">
                            <option value="active">正常</option>
                            <option value="inactive">禁用</option>
                            <option value="expired">过期</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>到期日 *</label>
                        <input type="date" name="expiry_date" required>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" data-action="hide-modal" data-modal-id="addCardModal">取消</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 编辑卡片模态框 -->
    <div id="editCardModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>编辑卡片</h3>
                <button class="modal-close" data-action="hide-modal" data-modal-id="editCardModal">&times;</button>
            </div>
            <form method="POST" id="editCardForm">
                <input type="hidden" name="action" value="edit_card">
                <input type="hidden" name="card_id" id="edit_card_id">
                <div class="form-group">
                    <label>卡号 *</label>
                    <input type="text" name="card_number" id="edit_card_number" required>
                </div>
                <div class="form-group">
                    <label>持卡人 *</label>
                    <input type="text" name="card_holder" id="edit_card_holder" required>
                </div>
                <div class="form-group">
                    <label>身份证号 *</label>
                    <input type="text" name="id_card" id="edit_id_card" required>
                </div>
                <div class="form-group">
                    <label>手机号 *</label>
                    <input type="text" name="phone" id="edit_phone" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>卡片类型 *</label>
                        <select name="card_type" id="edit_card_type" required>
                            <option value="">请选择类型</option>
                            <option value="debit">借记卡</option>
                            <option value="credit">信用卡</option>
                            <option value="prepaid">预付卡</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>金额 *</label>
                        <input type="number" name="amount" id="edit_amount" step="0.01" min="0" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>状态</label>
                        <select name="status" id="edit_status">
                            <option value="active">正常</option>
                            <option value="inactive">禁用</option>
                            <option value="expired">过期</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>到期日 *</label>
                        <input type="date" name="expiry_date" id="edit_expiry_date" required>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" data-action="hide-modal" data-modal-id="editCardModal">取消</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 批量添加模态框 -->
    <div id="batchAddModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>批量添加卡片</h3>
                <button class="modal-close" data-action="hide-modal" data-modal-id="batchAddModal">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="batch_add">
                <div class="batch-form">
                    <h4>批次信息</h4>
                    <div class="form-group">
                        <label>批次名称 *</label>
                        <input type="text" name="batch_name" placeholder="例如：2024年第一批卡片" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>卡片类型 *</label>
                        <select name="card_type" required>
                            <option value="">请选择类型</option>
                            <option value="debit">借记卡</option>
                            <option value="credit">信用卡</option>
                            <option value="prepaid">预付卡</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>金额 *</label>
                        <input type="number" name="amount" step="0.01" min="0" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>数量 *</label>
                        <input type="number" name="count" min="1" max="1000" required>
                    </div>
                    <div class="form-group">
                        <label>到期日 *</label>
                        <input type="date" name="expiry_date" required>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" data-action="hide-modal" data-modal-id="batchAddModal">取消</button>
                    <button type="submit" class="btn btn-success">批量添加</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 导入卡密模态框 -->
    <div id="importModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>导入卡密</h3>
                <button class="modal-close" data-action="hide-modal" data-modal-id="importModal">&times;</button>
            </div>
            <form id="importForm" enctype="multipart/form-data">
                <input type="hidden" name="action" value="import_cards">
                <div class="form-group">
                    <label>导入方式</label>
                    <div class="radio-group">
                        <label><input type="radio" name="import_type" value="paste" checked> 粘贴文本（一行一个卡密）</label>
                        <label><input type="radio" name="import_type" value="upload"> 上传TXT文件</label>
                    </div>
                </div>
                
                <div id="pasteContentContainer">
                    <div class="form-group">
                        <label>卡密内容</label>
                        <textarea name="paste_content" rows="10" placeholder="请粘贴卡密内容，每行一个卡密..." class="form-control"></textarea>
                    </div>
                </div>
                
                <div id="uploadFileContainer" style="display: none;">
                    <div class="form-group">
                        <label>上传文件</label>
                        <input type="file" name="card_file" accept=".txt" class="form-control">
                        <small class="text-muted">请上传TXT文件，每行一个卡密</small>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>卡片类型</label>
                    <select name="card_type" required>
                        <option value="">请选择类型</option>
                        <option value="debit">借记卡</option>
                        <option value="credit">信用卡</option>
                        <option value="prepaid">预付卡</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>金额</label>
                    <input type="number" name="amount" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label>到期日</label>
                    <input type="date" name="expiry_date" required>
                </div>
                
                <div class="import-stats" style="margin-bottom: 20px; padding: 15px; background-color: #f8f9fa; border-radius: 4px; display: none;">
                    <h4>导入统计</h4>
                    <div class="stats-row">
                        <span>成功: <span id="success-count" class="text-success">0</span></span>
                        <span>重复: <span id="duplicate-count" class="text-warning">0</span></span>
                        <span>失败: <span id="failed-count" class="text-danger">0</span></span>
                    </div>
                    <div id="download-failed" style="margin-top: 10px; display: none;">
                        <a href="#" class="btn btn-sm btn-danger">下载失败项重试</a>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" data-action="hide-modal" data-modal-id="importModal">取消</button>
                    <button type="button" class="btn btn-info" onclick="previewImport()">预览导入</button>
                    <button type="submit" class="btn btn-primary">确认导入</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 导出卡密模态框 -->
    <div id="exportModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>导出卡密</h3>
                <button class="modal-close" data-action="hide-modal" data-modal-id="exportModal">&times;</button>
            </div>
            <form id="exportForm">
                <input type="hidden" name="action" value="export_cards">
                
                <div class="form-group">
                    <label>导出格式</label>
                    <div class="radio-group">
                        <label><input type="radio" name="export_format" value="txt" checked> TXT格式（卡密+激活状态+时间）</label>
                        <label><input type="radio" name="export_format" value="excel"> Excel自定义导出</label>
                    </div>
                </div>
                
                <div id="excelFieldsContainer" style="display: none;">
                    <div class="form-group">
                        <label>选择导出字段</label>
                        <div class="checkbox-group">
                            <label><input type="checkbox" name="export_fields[]" value="card_number" checked> 卡密</label>
                            <label><input type="checkbox" name="export_fields[]" value="status" checked> 状态</label>
                            <label><input type="checkbox" name="export_fields[]" value="created_at" checked> 创建时间</label>
                            <label><input type="checkbox" name="export_fields[]" value="activated_at"> 激活时间</label>
                            <label><input type="checkbox" name="export_fields[]" value="expiry_date"> 过期时间</label>
                            <label><input type="checkbox" name="export_fields[]" value="card_type"> 卡片类型</label>
                            <label><input type="checkbox" name="export_fields[]" value="amount"> 金额</label>
                            <label><input type="checkbox" name="export_fields[]" value="created_by"> 创建人</label>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>导出条件</label>
                    <div class="form-row">
                        <div class="form-group">
                            <label>卡片类型</label>
                            <select name="card_type_filter">
                                <option value="">全部</option>
                                <option value="debit">借记卡</option>
                                <option value="credit">信用卡</option>
                                <option value="prepaid">预付卡</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>状态</label>
                            <select name="status_filter">
                                <option value="">全部</option>
                                <option value="active">正常</option>
                                <option value="inactive">禁用</option>
                                <option value="expired">过期</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" data-action="hide-modal" data-modal-id="exportModal">取消</button>
                    <button type="submit" class="btn btn-primary">开始导出</button>
                </div>
            </form>
        </div>
    </div>

    // 显示导入模态框
    window.showImportModal = function() {
        const modal = document.getElementById('importModal');
        modal.style.display = 'block';
        // 重置表单
        document.getElementById('importForm').reset();
        document.querySelectorAll('input[name="import_type"]')[0].checked = true;
        document.getElementById('pasteContentContainer').style.display = 'block';
        document.getElementById('uploadFileContainer').style.display = 'none';
        document.querySelector('.import-stats').style.display = 'none';
        document.getElementById('download-failed').style.display = 'none';
        document.getElementById('success-count').textContent = '0';
        document.getElementById('duplicate-count').textContent = '0';
        document.getElementById('failed-count').textContent = '0';
    };

    // 显示导出模态框
    window.showExportModal = function() {
        const modal = document.getElementById('exportModal');
        modal.style.display = 'block';
        // 重置表单
        document.getElementById('exportForm').reset();
        document.querySelectorAll('input[name="export_format"]')[0].checked = true;
        document.getElementById('excelFieldsContainer').style.display = 'none';
    };

    // 预览导入
    window.previewImport = function() {
        const form = document.getElementById('importForm');
        const formData = new FormData(form);
        formData.append('preview', '1');

        fetch('', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector('.import-stats').style.display = 'block';
                document.getElementById('success-count').textContent = data.stats.success || 0;
                document.getElementById('duplicate-count').textContent = data.stats.duplicate || 0;
                document.getElementById('failed-count').textContent = data.stats.failed || 0;
                
                if (data.failed_download_url) {
                    document.getElementById('download-failed').style.display = 'block';
                    document.querySelector('#download-failed a').href = data.failed_download_url;
                } else {
                    document.getElementById('download-failed').style.display = 'none';
                }
            } else {
                alert('预览失败: ' + (data.message || '未知错误'));
            }
        })
        .catch(error => {
            console.error('预览请求错误:', error);
            alert('预览请求失败，请重试');
        });
    };

    // 导入表单提交
    document.getElementById('importForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const form = this;
        const formData = new FormData(form);
        
        // 显示加载状态
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = '导入中...';

        fetch('', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            
            if (data.success) {
                document.querySelector('.import-stats').style.display = 'block';
                document.getElementById('success-count').textContent = data.stats.success || 0;
                document.getElementById('duplicate-count').textContent = data.stats.duplicate || 0;
                document.getElementById('failed-count').textContent = data.stats.failed || 0;
                
                if (data.failed_download_url) {
                    document.getElementById('download-failed').style.display = 'block';
                    document.querySelector('#download-failed a').href = data.failed_download_url;
                } else {
                    document.getElementById('download-failed').style.display = 'none';
                }
                
                // 刷新页面或重新加载卡片列表
                alert('导入成功！');
                location.reload();
            } else {
                alert('导入失败: ' + (data.message || '未知错误'));
            }
        })
        .catch(error => {
            console.error('导入请求错误:', error);
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            alert('导入请求失败，请重试');
        });
    });

    // 导出表单提交
    document.getElementById('exportForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // 创建隐藏表单并提交
        const hiddenForm = document.createElement('form');
        hiddenForm.method = 'POST';
        hiddenForm.style.display = 'none';
        document.body.appendChild(hiddenForm);
        
        // 复制所有表单字段
        const formData = new FormData(this);
        for (const [key, value] of formData.entries()) {
            if (Array.isArray(value)) {
                value.forEach(val => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = key;
                    input.value = val;
                    hiddenForm.appendChild(input);
                });
            } else {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = value;
                hiddenForm.appendChild(input);
            }
        }
        
        hiddenForm.submit();
        // 关闭模态框
        document.getElementById('exportModal').style.display = 'none';
    });

    // 窗口点击事件
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    };
</script>
</body>
</html>