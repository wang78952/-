<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统性能监控</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .header {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            color: #2c3e50;
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .header p {
            color: #7f8c8d;
            font-size: 1.1em;
        }

        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .card-title {
            font-size: 1.3em;
            font-weight: 600;
            color: #2c3e50;
        }

        .metric-value {
            font-size: 2.5em;
            font-weight: 700;
            margin: 15px 0;
        }

        .metric-change {
            font-size: 0.9em;
            padding: 5px 10px;
            border-radius: 20px;
            display: inline-block;
        }

        .positive {
            background: #d4edda;
            color: #155724;
        }

        .negative {
            background: #f8d7da;
            color: #721c24;
        }

        .neutral {
            background: #e2e3e5;
            color: #383d41;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin: 10px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.3s ease;
        }

        .chart-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-title {
            font-size: 1.5em;
            font-weight: 600;
            color: #2c3e50;
        }

        .time-selector {
            display: flex;
            gap: 10px;
        }

        .time-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            background: #e9ecef;
            color: #495057;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .time-btn.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .chart-placeholder {
            height: 300px;
            background: #f8f9fa;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 1.1em;
        }

        .task-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .task-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .task-list {
            display: grid;
            gap: 15px;
        }

        .task-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }

        .task-info {
            flex: 1;
        }

        .task-name {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .task-description {
            color: #6c757d;
            font-size: 0.9em;
        }

        .task-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9em;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            display: inline-block;
        }

        .status-healthy {
            background: #28a745;
        }

        .status-warning {
            background: #ffc107;
        }

        .status-critical {
            background: #dc3545;
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }

        .alert-success {
            background: #d4edda;
            border-color: #28a745;
            color: #155724;
        }

        .alert-warning {
            background: #fff3cd;
            border-color: #ffc107;
            color: #856404;
        }

        .alert-danger {
            background: #f8d7da;
            border-color: #dc3545;
            color: #721c24;
        }

        .log-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .log-container {
            background: #2c3e50;
            border-radius: 10px;
            padding: 20px;
            color: #ecf0f1;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            max-height: 400px;
            overflow-y: auto;
        }

        .log-entry {
            margin-bottom: 10px;
            padding: 5px 0;
            border-bottom: 1px solid #34495e;
        }

        .log-time {
            color: #95a5a6;
        }

        .log-level {
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 0.8em;
            margin: 0 5px;
        }

        .log-info {
            background: #3498db;
        }

        .log-warning {
            background: #f39c12;
        }

        .log-error {
            background: #e74c3c;
        }

        @media (max-width: 768px) {
            .dashboard {
                grid-template-columns: 1fr;
            }
            
            .chart-header {
                flex-direction: column;
                gap: 15px;
            }
            
            .task-header {
                flex-direction: column;
                gap: 15px;
            }
            
            .task-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>系统性能监控</h1>
            <p>实时监控系统性能、数据库状态和任务执行情况</p>
        </div>

        <div id="alerts"></div>

        <div class="dashboard">
            <div class="card">
                <div class="card-header">
                    <div class="card-icon" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                        📊
                    </div>
                    <div class="card-title">数据库查询</div>
                </div>
                <div class="metric-value" id="dbQueries">0</div>
                <div class="metric-change positive" id="dbQueriesChange">
                    <span class="status-indicator status-healthy"></span>
                    正常
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="dbQueriesProgress" style="width: 30%"></div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="card-icon" style="background: linear-gradient(135deg, #28a745, #20c997);">
                        ⚡
                    </div>
                    <div class="card-title">响应时间</div>
                </div>
                <div class="metric-value" id="responseTime">0ms</div>
                <div class="metric-change positive" id="responseTimeChange">
                    <span class="status-indicator status-healthy"></span>
                    快速
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="responseTimeProgress" style="width: 20%"></div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="card-icon" style="background: linear-gradient(135deg, #ffc107, #ff9800);">
                        💾
                    </div>
                    <div class="card-title">内存使用</div>
                </div>
                <div class="metric-value" id="memoryUsage">0%</div>
                <div class="metric-change neutral" id="memoryUsageChange">
                    <span class="status-indicator status-healthy"></span>
                    正常
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="memoryUsageProgress" style="width: 45%"></div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="card-icon" style="background: linear-gradient(135deg, #dc3545, #e91e63);">
                        🖥️
                    </div>
                    <div class="card-title">磁盘空间</div>
                </div>
                <div class="metric-value" id="diskUsage">0%</div>
                <div class="metric-change neutral" id="diskUsageChange">
                    <span class="status-indicator status-healthy"></span>
                    充足
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="diskUsageProgress" style="width: 60%"></div>
                </div>
            </div>
        </div>

        <div class="chart-container">
            <div class="chart-header">
                <div class="chart-title">性能趋势</div>
                <div class="time-selector">
                    <button class="time-btn active" data-period="1h">1小时</button>
                    <button class="time-btn" data-period="24h">24小时</button>
                    <button class="time-btn" data-period="7d">7天</button>
                    <button class="time-btn" data-period="30d">30天</button>
                </div>
            </div>
            <div class="chart-placeholder">
                图表加载中...
            </div>
        </div>

        <div class="task-section">
            <div class="task-header">
                <div class="chart-title">自动化任务</div>
                <button class="btn btn-primary" onclick="runAllTasks()">
                    <span id="runAllText">执行所有任务</span>
                </button>
            </div>
            <div class="task-list" id="taskList">
                <!-- 任务列表将通过JavaScript动态加载 -->
            </div>
        </div>

        <div class="log-section">
            <div class="chart-header">
                <div class="chart-title">系统日志</div>
                <button class="btn btn-secondary" onclick="refreshLogs()">刷新日志</button>
            </div>
            <div class="log-container" id="logContainer">
                <!-- 日志内容将通过JavaScript动态加载 -->
            </div>
        </div>
    </div>

    <script>
        // 全局变量
        let currentPeriod = '1h';
        let refreshInterval;

        // 初始化
        document.addEventListener('DOMContentLoaded', function() {
            loadMetrics();
            loadTasks();
            loadLogs();
            setupEventListeners();
            
            // 设置自动刷新
            refreshInterval = setInterval(loadMetrics, 30000); // 30秒刷新一次
        });

        // 设置事件监听器
        function setupEventListeners() {
            // 时间选择器
            document.querySelectorAll('.time-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.time-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    currentPeriod = this.dataset.period;
                    loadMetrics();
                });
            });
        }

        // 加载性能指标
        async function loadMetrics() {
            try {
                const response = await fetch('api/performance/metrics');
                const data = await response.json();
                
                updateMetric('dbQueries', data.db_queries || 0, 'dbQueriesChange', data.db_queries_status || 'healthy');
                updateMetric('responseTime', (data.avg_response_time || 0) + 'ms', 'responseTimeChange', data.response_time_status || 'healthy');
                updateMetric('memoryUsage', (data.memory_usage || 0) + '%', 'memoryUsageChange', data.memory_status || 'healthy');
                updateMetric('diskUsage', (data.disk_usage || 0) + '%', 'diskUsageChange', data.disk_status || 'healthy');
                
                updateProgressBars(data);
                
            } catch (error) {
                console.error('加载性能指标失败:', error);
                showAlert('无法加载性能指标数据', 'danger');
            }
        }

        // 更新指标显示
        function updateMetric(elementId, value, changeElementId, status) {
            const element = document.getElementById(elementId);
            const changeElement = document.getElementById(changeElementId);
            
            element.textContent = value;
            
            const statusClass = status === 'healthy' ? 'positive' : (status === 'warning' ? 'negative' : 'negative');
            const statusIndicator = status === 'healthy' ? 'status-healthy' : (status === 'warning' ? 'status-warning' : 'status-critical');
            const statusText = status === 'healthy' ? '正常' : (status === 'warning' ? '警告' : '严重');
            
            changeElement.className = `metric-change ${statusClass}`;
            changeElement.innerHTML = `<span class="status-indicator ${statusIndicator}"></span>${statusText}`;
        }

        // 更新进度条
        function updateProgressBars(data) {
            updateProgressBar('dbQueriesProgress', data.db_queries_percent || 30);
            updateProgressBar('responseTimeProgress', data.response_time_percent || 20);
            updateProgressBar('memoryUsageProgress', data.memory_usage || 45);
            updateProgressBar('diskUsageProgress', data.disk_usage || 60);
        }

        // 更新单个进度条
        function updateProgressBar(elementId, percentage) {
            const element = document.getElementById(elementId);
            element.style.width = Math.min(percentage, 100) + '%';
            
            // 根据百分比改变颜色
            if (percentage > 80) {
                element.style.background = 'linear-gradient(90deg, #dc3545, #e91e63)';
            } else if (percentage > 60) {
                element.style.background = 'linear-gradient(90deg, #ffc107, #ff9800)';
            } else {
                element.style.background = 'linear-gradient(90deg, #667eea, #764ba2)';
            }
        }

        // 加载任务列表
        async function loadTasks() {
            try {
                const response = await fetch('api/performance/tasks');
                const tasks = await response.json();
                
                const taskList = document.getElementById('taskList');
                taskList.innerHTML = '';
                
                tasks.forEach(task => {
                    const taskItem = createTaskItem(task);
                    taskList.appendChild(taskItem);
                });
                
            } catch (error) {
                console.error('加载任务列表失败:', error);
            }
        }

        // 创建任务项
        function createTaskItem(task) {
            const div = document.createElement('div');
            div.className = 'task-item';
            div.innerHTML = `
                <div class="task-info">
                    <div class="task-name">${task.name}</div>
                    <div class="task-description">${task.description}</div>
                </div>
                <div class="task-actions">
                    <button class="btn btn-primary" onclick="runTask('${task.id}')">
                        执行
                    </button>
                </div>
            `;
            return div;
        }

        // 运行单个任务
        async function runTask(taskId) {
            const button = event.target;
            const originalText = button.textContent;
            button.innerHTML = '<span class="loading"></span>';
            button.disabled = true;
            
            try {
                const response = await fetch(`api/performance/run-task/${taskId}`, {
                    method: 'POST'
                });
                const result = await response.json();
                
                if (result.status === 'success') {
                    showAlert(`任务执行成功: ${result.result}`, 'success');
                } else {
                    showAlert(`任务执行失败: ${result.message}`, 'danger');
                }
                
            } catch (error) {
                console.error('执行任务失败:', error);
                showAlert('任务执行失败', 'danger');
            } finally {
                button.textContent = originalText;
                button.disabled = false;
            }
        }

        // 运行所有任务
        async function runAllTasks() {
            const button = document.getElementById('runAllText');
            const originalText = button.textContent;
            button.innerHTML = '<span class="loading"></span> 执行中...';
            button.parentElement.disabled = true;
            
            try {
                const response = await fetch('api/performance/run-all-tasks', {
                    method: 'POST'
                });
                const results = await response.json();
                
                let successCount = 0;
                let errorCount = 0;
                
                Object.values(results).forEach(result => {
                    if (result.status === 'success') {
                        successCount++;
                    } else {
                        errorCount++;
                    }
                });
                
                if (errorCount === 0) {
                    showAlert(`所有任务执行成功 (${successCount}/${successCount + errorCount})`, 'success');
                } else {
                    showAlert(`任务执行完成: ${successCount} 成功, ${errorCount} 失败`, 'warning');
                }
                
                loadMetrics(); // 刷新指标
                
            } catch (error) {
                console.error('执行所有任务失败:', error);
                showAlert('执行任务失败', 'danger');
            } finally {
                button.textContent = originalText;
                button.parentElement.disabled = false;
            }
        }

        // 加载日志
        async function loadLogs() {
            try {
                const response = await fetch('api/performance/logs');
                const logs = await response.json();
                
                const logContainer = document.getElementById('logContainer');
                logContainer.innerHTML = '';
                
                logs.forEach(log => {
                    const logEntry = createLogEntry(log);
                    logContainer.appendChild(logEntry);
                });
                
            } catch (error) {
                console.error('加载日志失败:', error);
            }
        }

        // 创建日志条目
        function createLogEntry(log) {
            const div = document.createElement('div');
            div.className = 'log-entry';
            
            const levelClass = log.level === 'ERROR' ? 'log-error' : (log.level === 'WARNING' ? 'log-warning' : 'log-info');
            
            div.innerHTML = `
                <span class="log-time">${log.time}</span>
                <span class="log-level ${levelClass}">${log.level}</span>
                <span>${log.message}</span>
            `;
            
            return div;
        }

        // 刷新日志
        function refreshLogs() {
            loadLogs();
        }

        // 显示提示信息
        function showAlert(message, type) {
            const alertsContainer = document.getElementById('alerts');
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertsContainer.appendChild(alert);
            
            // 3秒后自动移除
            setTimeout(() => {
                alert.remove();
            }, 3000);
        }

        // 页面卸载时清理
        window.addEventListener('beforeunload', function() {
            if (refreshInterval) {
                clearInterval(refreshInterval);
            }
        });
    </script>
</body>
</html>