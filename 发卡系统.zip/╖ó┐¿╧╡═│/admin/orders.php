<?php
/**
 * 订单管理页面
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/AuthManager.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/SecurityUtils.php';
require_once __DIR__ . '/../includes/EnhancedValidator.php';
require_once __DIR__ . '/../includes/InjectionProtection.php';

// 启动会话
session_start();

// 检查管理员权限
$authManager = new AuthManager();
if (!$authManager->isLoggedIn() || !in_array($_SESSION['user_role'], ['admin', 'business_admin'])) {
    header('Location: ../login.php');
    exit;
}

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();

// 获取数据库连接
$db = Database::getInstance();

// 处理操作
$message = '';
$error = '';

// 初始化验证器
$validator = EnhancedValidator::getInstance();
$protection = InjectionProtection::getInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取并清理操作类型
    $action = $protection->cleanInput($_POST['action'] ?? '');
    
    // 验证操作类型
    if (!$validator->validateString($action, ['min_length' => 1, 'max_length' => 50])) {
        $error = '无效的操作类型';
    } else {
        switch ($action) {
        case 'update_order_status':
            try {
                // 验证和清理输入
                $orderId = $protection->cleanInput($_POST['order_id'] ?? '');
                $newStatus = $protection->cleanInput($_POST['status'] ?? '');
                $remark = $protection->cleanInput(trim($_POST['remark'] ?? ''));
                
                // 验证订单ID
                if (!$validator->validateInteger($orderId, ['min' => 1])) {
                    throw new Exception('无效的订单ID');
                }
                
                // 验证状态
                $validStatuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled', 'refunded'];
                if (!in_array($newStatus, $validStatuses)) {
                    throw new Exception('无效的订单状态');
                }
                
                // 验证备注长度
                if (!$validator->validateString($remark, ['max_length' => 500])) {
                    throw new Exception('备注内容不能超过500个字符');
                }
                
                // 获取当前订单状态
                $currentOrder = $db->queryOne("SELECT * FROM orders WHERE id = ?", [$orderId]);
                if (!$currentOrder) {
                    throw new Exception('订单不存在');
                }
                
                // 更新订单状态
                $db->query("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?", [$newStatus, $orderId]);
                
                // 记录状态变更日志
                $db->query("INSERT INTO order_status_logs (order_id, old_status, new_status, remark, created_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$orderId, $currentOrder['status'], $newStatus, $remark, $currentUser['id']]);
                
                // 记录操作日志
                $db->query("INSERT INTO order_operation_logs (order_id, operation, operator_id, operator_name, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                    [$orderId, "状态变更: {$currentOrder['status']} -> $newStatus", $currentUser['id'], $currentUser['username'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
                $message = '订单状态更新成功';
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'add_order_note':
            try {
                // 验证和清理输入
                $orderId = $protection->cleanInput($_POST['order_id'] ?? '');
                $note = $protection->cleanInput(trim($_POST['note'] ?? ''));
                
                // 验证订单ID
                if (!$validator->validateInteger($orderId, ['min' => 1])) {
                    throw new Exception('无效的订单ID');
                }
                
                // 验证备注内容
                if (!strlen($note)) {
                    throw new Exception('备注内容不能为空');
                }
                
                if (!$validator->validateString($note, ['max_length' => 1000])) {
                    throw new Exception('备注内容不能超过1000个字符');
                }
                
                // 添加订单备注
                $db->query("INSERT INTO order_notes (order_id, note, created_by, created_at) VALUES (?, ?, ?, NOW())",
                    [$orderId, $note, $currentUser['id']]);
                
                // 记录操作日志
                $db->query("INSERT INTO order_operation_logs (order_id, operation, operator_id, operator_name, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                    [$orderId, "添加备注", $currentUser['id'], $currentUser['username'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
                $message = '备注添加成功';
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'refund_order':
            try {
                // 验证和清理输入
                $orderId = $protection->cleanInput($_POST['order_id'] ?? '');
                $refundAmount = $protection->cleanInput($_POST['refund_amount'] ?? '');
                $refundReason = $protection->cleanInput(trim($_POST['refund_reason'] ?? ''));
                
                // 验证订单ID
                if (!$validator->validateInteger($orderId, ['min' => 1])) {
                    throw new Exception('无效的订单ID');
                }
                
                // 验证退款金额
                $refundAmount = $validator->validateAndConvert('float', $refundAmount);
                if (!$validator->validateFloat($refundAmount, ['min' => 0.01])) {
                    throw new Exception('退款金额必须大于0');
                }
                
                // 验证退款原因
                if (!strlen($refundReason)) {
                    throw new Exception('退款原因不能为空');
                }
                
                if (!$validator->validateString($refundReason, ['max_length' => 500])) {
                    throw new Exception('退款原因不能超过500个字符');
                }
                
                // 获取订单信息
                $order = $db->queryOne("SELECT * FROM orders WHERE id = ?", [$orderId]);
                if (!$order) {
                    throw new Exception('订单不存在');
                }
                
                if ($order['status'] !== 'paid' && $order['status'] !== 'shipped') {
                    throw new Exception('只有已支付或已发货的订单才能退款');
                }
                
                if ($refundAmount > $order['total_amount']) {
                    throw new Exception('退款金额不能超过订单总金额');
                }
                
                // 创建退款记录
                $db->query("INSERT INTO refunds (order_id, refund_amount, refund_reason, status, created_by, created_at) VALUES (?, ?, ?, 'processing', ?, NOW())",
                    [$orderId, $refundAmount, $refundReason, $currentUser['id']]);
                
                // 更新订单状态
                $db->query("UPDATE orders SET status = 'refunded', updated_at = NOW() WHERE id = ?", [$orderId]);
                
                // 记录状态变更日志
                $db->query("INSERT INTO order_status_logs (order_id, old_status, new_status, remark, created_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$orderId, $order['status'], 'refunded', "退款: ¥$refundAmount", $currentUser['id']]);
                
                // 记录操作日志
                $db->query("INSERT INTO order_operation_logs (order_id, operation, operator_id, operator_name, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                    [$orderId, "退款: ¥$refundAmount", $currentUser['id'], $currentUser['username'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
                $message = '退款处理成功';
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
        default:
            $error = '未知的操作类型';
    }
}

// 获取订单列表 - 验证所有GET参数
$page = $validator->validateAndConvert('integer', $_GET['page'] ?? 1);
$page = max(1, $page);
$limit = 20; // 固定每页数量以防止大量数据查询
$offset = ($page - 1) * $limit;

// 搜索条件 - 清理和验证
$search = $protection->cleanInput(trim($_GET['search'] ?? ''));
if (!$validator->validateString($search, ['max_length' => 100])) {
    $search = '';
}

$status_filter = $protection->cleanInput($_GET['status'] ?? '');
$validStatuses = ['', 'pending', 'paid', 'shipped', 'delivered', 'cancelled', 'refunded'];
if (!in_array($status_filter, $validStatuses)) {
    $status_filter = '';
}

// 日期格式验证
$date_from = $protection->cleanInput($_GET['date_from'] ?? '');
if (!empty($date_from) && !$validator->validateDate($date_from, 'Y-m-d')) {
    $date_from = '';
}

$date_to = $protection->cleanInput($_GET['date_to'] ?? '');
if (!empty($date_to) && !$validator->validateDate($date_to, 'Y-m-d')) {
    $date_to = '';
}

$whereConditions = [];
$params = [];

if (!empty($search)) {
    $whereConditions[] = "(order_number LIKE ? OR customer_name LIKE ? OR customer_email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($status_filter)) {
    $whereConditions[] = "o.status = ?";
    $params[] = $status_filter;
}

if (!empty($date_from)) {
    $whereConditions[] = "o.created_at >= ?";
    $params[] = $date_from . ' 00:00:00';
}

if (!empty($date_to)) {
    $whereConditions[] = "o.created_at <= ?";
    $params[] = $date_to . ' 23:59:59';
}

$whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// 获取总数
$totalQuery = "SELECT COUNT(*) as total FROM orders o $whereClause";
$totalResult = $db->queryOne($totalQuery, $params);
$totalOrders = $totalResult['total'];
$totalPages = ceil($totalOrders / $limit);

// 获取订单列表
$ordersQuery = "SELECT o.*, u.username as created_by_name FROM orders o LEFT JOIN users u ON o.created_by = u.id $whereClause ORDER BY o.created_at DESC LIMIT $limit OFFSET $offset";
$orders = $db->query($ordersQuery, $params);

// 获取订单详情（用于模态框）
function getOrderDetails($orderId) {
    global $db;
    $order = $db->queryOne("SELECT * FROM orders WHERE id = ?", [$orderId]);
    if ($order) {
        $order['items'] = $db->query("SELECT oi.*, p.name as product_name FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?", [$orderId]);
        $order['cards'] = $db->query("SELECT oc.*, c.card_number FROM order_cards oc LEFT JOIN cards c ON oc.card_id = c.id WHERE oc.order_id = ?", [$orderId]);
        $order['notes'] = $db->query("SELECT on.*, u.username as creator_name FROM order_notes on LEFT JOIN users u ON on.created_by = u.id WHERE on.order_id = ? ORDER BY on.created_at DESC", [$orderId]);
        $order['status_logs'] = $db->query("SELECT osl.*, u.username as operator_name FROM order_status_logs osl LEFT JOIN users u ON osl.created_by = u.id WHERE osl.order_id = ? ORDER BY osl.created_at DESC", [$orderId]);
    }
    return $order;
}

// 处理AJAX请求
if ($_GET['action'] === 'get_order_details') {
    $orderId = (int)$_GET['id'];
    $orderDetails = getOrderDetails($orderId);
    header('Content-Type: application/json');
    echo json_encode($orderDetails);
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>订单管理 - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/ui-components.css">
    <style>
        .page-header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .search-filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .filter-form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .filter-group label {
            font-size: 14px;
            color: #555;
            font-weight: 500;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .orders-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .table tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background: #fef5e7;
            color: #f39c12;
        }
        
        .status-paid {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .status-shipped {
            background: #d6eaf8;
            color: #2874a6;
        }
        
        .status-delivered {
            background: #d5f4e6;
            color: #239b56;
        }
        
        .status-cancelled {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .status-refunded {
            background: #fdebd0;
            color: #dc7633;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn-sm {
            padding: 4px 8px;
            font-size: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-view {
            background: #3498db;
            color: white;
        }
        
        .btn-edit {
            background: #f39c12;
            color: white;
        }
        
        .btn-refund {
            background: #e74c3c;
            color: white;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        
        .modal-content {
            background: white;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            max-width: 800px;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .order-details {
            margin-bottom: 20px;
        }
        
        .detail-section {
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        
        .detail-section h4 {
            margin-bottom: 10px;
            color: #333;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .detail-label {
            font-weight: 500;
            color: #555;
        }
        
        .detail-value {
            color: #333;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        
        .items-table th,
        .items-table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-group textarea {
            height: 80px;
            resize: vertical;
        }
        
        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }
        
        .alert {
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d5f4e6;
            color: #27ae60;
            border: 1px solid #27ae60;
        }
        
        .alert-error {
            background: #fadbd8;
            color: #e74c3c;
            border: 1px solid #e74c3c;
        }
        
        .notes-list {
            max-height: 200px;
            overflow-y: auto;
        }
        
        .note-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .note-item:last-child {
            border-bottom: none;
        }
        
        .note-meta {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .note-content {
            color: #333;
        }
        
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #ddd;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 15px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -24px;
            top: 5px;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #3498db;
        }
        
        .timeline-time {
            font-size: 12px;
            color: #666;
            margin-bottom: 2px;
        }
        
        .timeline-content {
            color: #333;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .detail-row {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>管理控制台</h2>
                <div class="user-info">
                    <?php echo htmlspecialchars($currentUser['username']); ?>
                    <br>
                    <small><?php echo htmlspecialchars($currentUser['role']); ?></small>
                </div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i>📊</i>仪表板</a></li>
                <li><a href="users.php"><i>👥</i>用户管理</a></li>
                <li><a href="cards.php"><i>💳</i>卡片管理</a></li>
                <li><a href="orders.php" class="active"><i>📦</i>订单管理</a></li>
                <li><a href="products.php"><i>🛍️</i>产品管理</a></li>
                <li><a href="security.php"><i>🔒</i>安全管理</a></li>
                <li><a href="logs.php"><i>📝</i>日志管理</a></li>
                <li><a href="settings.php"><i>⚙️</i>系统设置</a></li>
                <li><a href="../logout.php"><i>🚪</i>退出登录</a></li>
            </ul>
        </div>

        <!-- 主要内容 -->
        <div class="main-content">
            <!-- 页面头部 -->
            <div class="page-header">
                <h1>订单管理</h1>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="exportOrders()">导出订单</button>
                </div>
            </div>

            <!-- 消息提示 -->
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- 搜索过滤 -->
            <div class="search-filters">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <label>搜索</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="订单号、客户姓名或邮箱">
                    </div>
                    <div class="filter-group">
                        <label>状态</label>
                        <select name="status">
                            <option value="">全部</option>
                            <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>待支付</option>
                            <option value="paid" <?php echo $status_filter === 'paid' ? 'selected' : ''; ?>>已支付</option>
                            <option value="shipped" <?php echo $status_filter === 'shipped' ? 'selected' : ''; ?>>已发货</option>
                            <option value="delivered" <?php echo $status_filter === 'delivered' ? 'selected' : ''; ?>>已送达</option>
                            <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>已取消</option>
                            <option value="refunded" <?php echo $status_filter === 'refunded' ? 'selected' : ''; ?>>已退款</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>开始日期</label>
                        <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                    </div>
                    <div class="filter-group">
                        <label>结束日期</label>
                        <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">搜索</button>
                    <a href="orders.php" class="btn btn-secondary">重置</a>
                </form>
            </div>

            <!-- 订单列表 -->
            <div class="orders-table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>订单号</th>
                            <th>客户</th>
                            <th>金额</th>
                            <th>状态</th>
                            <th>支付方式</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 40px;">没有找到订单</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($order['customer_name']); ?><br>
                                        <small><?php echo htmlspecialchars($order['customer_email']); ?></small>
                                    </td>
                                    <td>¥<?php echo number_format($order['total_amount'], 2); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $order['status']; ?>">
                                            <?php 
                                            $statuses = [
                                                'pending' => '待支付',
                                                'paid' => '已支付',
                                                'shipped' => '已发货',
                                                'delivered' => '已送达',
                                                'cancelled' => '已取消',
                                                'refunded' => '已退款'
                                            ];
                                            echo $statuses[$order['status']] ?? $order['status'];
                                            ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($order['payment_method'] ?? '-'); ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn-sm btn-view" onclick="showOrderDetails(<?php echo $order['id']; ?>)">查看</button>
                                            <?php if (in_array($order['status'], ['paid', 'shipped'])): ?>
                                                <button class="btn-sm btn-refund" onclick="showRefundModal(<?php echo $order['id']; ?>)">退款</button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- 分页 -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>">上一页</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>">下一页</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 订单详情模态框 -->
    <div id="orderDetailsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>订单详情</h3>
                <button class="modal-close" onclick="hideModal('orderDetailsModal')">&times;</button>
            </div>
            <div id="orderDetailsContent">
                <!-- 订单详情将通过AJAX加载 -->
            </div>
        </div>
    </div>

    <!-- 更新状态模态框 -->
    <div id="updateStatusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>更新订单状态</h3>
                <button class="modal-close" onclick="hideModal('updateStatusModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_order_status">
                <input type="hidden" name="order_id" id="status_order_id">
                <div class="form-group">
                    <label>新状态</label>
                    <select name="status" id="new_status" required>
                        <option value="">请选择状态</option>
                        <option value="pending">待支付</option>
                        <option value="paid">已支付</option>
                        <option value="shipped">已发货</option>
                        <option value="delivered">已送达</option>
                        <option value="cancelled">已取消</option>
                        <option value="refunded">已退款</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>备注</label>
                    <textarea name="remark" placeholder="请输入状态变更原因"></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('updateStatusModal')">取消</button>
                    <button type="submit" class="btn btn-primary">更新</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 添加备注模态框 -->
    <div id="addNoteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>添加备注</h3>
                <button class="modal-close" onclick="hideModal('addNoteModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_order_note">
                <input type="hidden" name="order_id" id="note_order_id">
                <div class="form-group">
                    <label>备注内容</label>
                    <textarea name="note" placeholder="请输入备注内容" required></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('addNoteModal')">取消</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 退款模态框 -->
    <div id="refundModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>订单退款</h3>
                <button class="modal-close" onclick="hideModal('refundModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="refund_order">
                <input type="hidden" name="order_id" id="refund_order_id">
                <div class="form-group">
                    <label>退款金额</label>
                    <input type="number" name="refund_amount" id="refund_amount" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label>退款原因</label>
                    <textarea name="refund_reason" placeholder="请输入退款原因" required></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('refundModal')">取消</button>
                    <button type="submit" class="btn btn-danger">确认退款</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showOrderDetails(orderId) {
            fetch('orders.php?action=get_order_details&id=' + orderId)
                .then(response => response.json())
                .then(data => {
                    let html = `
                        <div class="order-details">
                            <div class="detail-section">
                                <h4>基本信息</h4>
                                <div class="detail-row">
                                    <span class="detail-label">订单号:</span>
                                    <span class="detail-value">${data.order_number}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">客户姓名:</span>
                                    <span class="detail-value">${data.customer_name}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">客户邮箱:</span>
                                    <span class="detail-value">${data.customer_email}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">客户电话:</span>
                                    <span class="detail-value">${data.customer_phone || '-'}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">订单金额:</span>
                                    <span class="detail-value">¥${parseFloat(data.total_amount).toFixed(2)}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">支付方式:</span>
                                    <span class="detail-value">${data.payment_method || '-'}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">订单状态:</span>
                                    <span class="detail-value">${data.status}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">创建时间:</span>
                                    <span class="detail-value">${new Date(data.created_at).toLocaleString()}</span>
                                </div>
                            </div>
                    `;
                    
                    if (data.items && data.items.length > 0) {
                        html += `
                            <div class="detail-section">
                                <h4>订单商品</h4>
                                <table class="items-table">
                                    <thead>
                                        <tr>
                                            <th>商品名称</th>
                                            <th>单价</th>
                                            <th>数量</th>
                                            <th>小计</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;
                        data.items.forEach(item => {
                            html += `
                                <tr>
                                    <td>${item.product_name}</td>
                                    <td>¥${parseFloat(item.price).toFixed(2)}</td>
                                    <td>${item.quantity}</td>
                                    <td>¥${parseFloat(item.subtotal).toFixed(2)}</td>
                                </tr>
                            `;
                        });
                        html += `
                                    </tbody>
                                </table>
                            </div>
                        `;
                    }
                    
                    if (data.cards && data.cards.length > 0) {
                        html += `
                            <div class="detail-section">
                                <h4>关联卡片</h4>
                                <table class="items-table">
                                    <thead>
                                        <tr>
                                            <th>卡号</th>
                                            <th>状态</th>
                                            <th>分配时间</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;
                        data.cards.forEach(card => {
                            html += `
                                <tr>
                                    <td>${card.card_number}</td>
                                    <td>${card.status}</td>
                                    <td>${new Date(card.assigned_at).toLocaleString()}</td>
                                </tr>
                            `;
                        });
                        html += `
                                    </tbody>
                                </table>
                            </div>
                        `;
                    }
                    
                    html += `
                            <div class="detail-section">
                                <h4>操作</h4>
                                <div style="display: flex; gap: 10px;">
                                    <button class="btn btn-primary" onclick="showUpdateStatusModal(${data.id})">更新状态</button>
                                    <button class="btn btn-secondary" onclick="showAddNoteModal(${data.id})">添加备注</button>
                        `;
                        if (data.status === 'paid' || data.status === 'shipped') {
                            html += `<button class="btn btn-danger" onclick="showRefundModal(${data.id})">退款</button>`;
                        }
                        html += `
                                </div>
                            </div>
                        `;
                    
                    if (data.notes && data.notes.length > 0) {
                        html += `
                            <div class="detail-section">
                                <h4>备注记录</h4>
                                <div class="notes-list">
                        `;
                        data.notes.forEach(note => {
                            html += `
                                <div class="note-item">
                                    <div class="note-meta">${note.creator_name} - ${new Date(note.created_at).toLocaleString()}</div>
                                    <div class="note-content">${note.note}</div>
                                </div>
                            `;
                        });
                        html += `
                                </div>
                            </div>
                        `;
                    }
                    
                    if (data.status_logs && data.status_logs.length > 0) {
                        html += `
                            <div class="detail-section">
                                <h4>状态变更记录</h4>
                                <div class="timeline">
                        `;
                        data.status_logs.forEach(log => {
                            html += `
                                <div class="timeline-item">
                                    <div class="timeline-time">${new Date(log.created_at).toLocaleString()}</div>
                                    <div class="timeline-content">
                                        ${log.old_status} → ${log.new_status}
                                        ${log.remark ? `<br><small>${log.remark}</small>` : ''}
                                        <br><small>操作人: ${log.operator_name}</small>
                                    </div>
                                </div>
                            `;
                        });
                        html += `
                                </div>
                            </div>
                        `;
                    }
                    
                    html += '</div>';
                    document.getElementById('orderDetailsContent').innerHTML = html;
                    document.getElementById('orderDetailsModal').style.display = 'block';
                })
                .catch(error => {
                    console.error('获取订单详情失败:', error);
                    alert('获取订单详情失败');
                });
        }

        function showUpdateStatusModal(orderId) {
            document.getElementById('status_order_id').value = orderId;
            document.getElementById('updateStatusModal').style.display = 'block';
        }

        function showAddNoteModal(orderId) {
            document.getElementById('note_order_id').value = orderId;
            document.getElementById('addNoteModal').style.display = 'block';
        }

        function showRefundModal(orderId) {
            document.getElementById('refund_order_id').value = orderId;
            document.getElementById('refundModal').style.display = 'block';
        }

        function hideModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function exportOrders() {
            const params = new URLSearchParams(window.location.search);
            params.set('export', '1');
            window.open('orders.php?' + params.toString());
        }

        // 点击模态框外部关闭
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>