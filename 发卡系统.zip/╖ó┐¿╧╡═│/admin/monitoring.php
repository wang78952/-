<?php
/**
 * 系统监控页面
 */

require_once '../includes/Database.php';
require_once '../includes/AuthManager.php';
require_once '../includes/SecurityUtils.php';

// 检查管理员权限
AuthManager::requireAdmin();

// 获取数据库连接
$db = Database::getInstance();

// 获取系统监控数据
function getSystemStats($db) {
    $stats = [];
    
    // 系统基础信息
    $stats['system'] = [
        'php_version' => PHP_VERSION,
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'server_time' => date('Y-m-d H:i:s'),
        'timezone' => date_default_timezone_get(),
        'memory_limit' => ini_get('memory_limit'),
        'max_execution_time' => ini_get('max_execution_time'),
        'upload_max_filesize' => ini_get('upload_max_filesize')
    ];
    
    // 数据库统计
    $stats['database'] = [
        'version' => $db->query("SELECT VERSION() as version")->fetch()['version'],
        'size' => getDatabaseSize($db),
        'connections' => $db->query("SHOW STATUS LIKE 'Threads_connected'")->fetch()['Value'] ?? 0
    ];
    
    // 用户统计
    $stats['users'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM users")->fetch()['count'],
        'active' => $db->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'")->fetch()['count'],
        'online' => $db->query("SELECT COUNT(*) as count FROM users WHERE last_login > DATE_SUB(NOW(), INTERVAL 30 MINUTE)")->fetch()['count']
    ];
    
    // 卡片统计
    $stats['cards'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM cards")->fetch()['count'],
        'active' => $db->query("SELECT COUNT(*) as count FROM cards WHERE status = 'active'")->fetch()['count'],
        'used' => $db->query("SELECT COUNT(*) as count FROM cards WHERE status = 'used'")->fetch()['count'],
        'expired' => $db->query("SELECT COUNT(*) as count FROM cards WHERE status = 'expired'")->fetch()['count']
    ];
    
    // 订单统计
    $stats['orders'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM orders")->fetch()['count'],
        'today' => $db->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()")->fetch()['count'],
        'pending' => $db->query("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")->fetch()['count'],
        'revenue_today' => $db->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE DATE(created_at) = CURDATE() AND status = 'paid'")->fetch()['total']
    ];
    
    // 系统性能
    $stats['performance'] = [
        'memory_usage' => memory_get_usage(true),
        'memory_peak' => memory_get_peak_usage(true),
        'cpu_usage' => getServerCpuUsage(),
        'disk_usage' => getDiskUsage()
    ];
    
    return $stats;
}

// 获取数据库大小
function getDatabaseSize($db) {
    $result = $db->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size FROM information_schema.tables WHERE table_schema = DATABASE()")->fetch();
    return $result['size'] . ' MB';
}

// 获取服务器CPU使用率
function getServerCpuUsage() {
    if (function_exists('sys_getloadavg')) {
        $load = sys_getloadavg();
        return round($load[0] * 100, 2) . '%';
    }
    return 'N/A';
}

// 获取磁盘使用率
function getDiskUsage() {
    $total = disk_total_space('.');
    $free = disk_free_space('.');
    if ($total && $free) {
        $used = $total - $free;
        $percentage = round(($used / $total) * 100, 2);
        return [
            'total' => round($total / 1024 / 1024 / 1024, 2) . ' GB',
            'used' => round($used / 1024 / 1024 / 1024, 2) . ' GB',
            'free' => round($free / 1024 / 1024 / 1024, 2) . ' GB',
            'percentage' => $percentage . '%'
        ];
    }
    return ['total' => 'N/A', 'used' => 'N/A', 'free' => 'N/A', 'percentage' => 'N/A'];
}

// 获取最近的系统日志
function getRecentLogs($db, $limit = 50) {
    return $db->query("
        SELECT 
            id,
            level,
            message,
            context,
            created_at
        FROM system_logs 
        ORDER BY created_at DESC 
        LIMIT ?
    ", [$limit])->fetchAll();
}

// 获取错误日志
function getErrorLogs($db, $limit = 20) {
    return $db->query("
        SELECT 
            id,
            error_type,
            message,
            file,
            line,
            stack_trace,
            created_at
        FROM error_logs 
        ORDER BY created_at DESC 
        LIMIT ?
    ", [$limit])->fetchAll();
}

// 获取操作日志
function getOperationLogs($db, $limit = 20) {
    return $db->query("
        SELECT 
            ol.id,
            ol.user_id,
            u.username,
            ol.action,
            ol.resource_type,
            ol.resource_id,
            ol.ip_address,
            ol.user_agent,
            ol.created_at
        FROM operation_logs ol
        LEFT JOIN users u ON ol.user_id = u.id
        ORDER BY ol.created_at DESC 
        LIMIT ?
    ", [$limit])->fetchAll();
}

// 处理AJAX请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    try {
        switch ($_POST['action']) {
            case 'get_stats':
                echo json_encode(['success' => true, 'data' => getSystemStats($db)]);
                break;
                
            case 'get_logs':
                $type = $_POST['type'] ?? 'system';
                $limit = (int)($_POST['limit'] ?? 20);
                
                switch ($type) {
                    case 'system':
                        $logs = getRecentLogs($db, $limit);
                        break;
                    case 'error':
                        $logs = getErrorLogs($db, $limit);
                        break;
                    case 'operation':
                        $logs = getOperationLogs($db, $limit);
                        break;
                    default:
                        $logs = [];
                }
                
                echo json_encode(['success' => true, 'data' => $logs]);
                break;
                
            case 'clear_logs':
                $type = $_POST['type'] ?? 'system';
                
                switch ($type) {
                    case 'system':
                        $db->query("DELETE FROM system_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
                        break;
                    case 'error':
                        $db->query("DELETE FROM error_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
                        break;
                    case 'operation':
                        $db->query("DELETE FROM operation_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
                        break;
                }
                
                echo json_encode(['success' => true, 'message' => '日志清理完成']);
                break;
                
            default:
                echo json_encode(['success' => false, 'message' => '未知操作']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// 获取初始数据
$systemStats = getSystemStats($db);
$recentLogs = getRecentLogs($db);
$errorLogs = getErrorLogs($db);
$operationLogs = getOperationLogs($db);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统监控 - 发卡系统管理后台</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            line-height: 1.6;
        }
        
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding: 20px 0;
        }
        
        .sidebar h3 {
            padding: 0 20px 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-menu li {
            border-bottom: 1px solid #34495e;
        }
        
        .nav-menu a {
            display: block;
            padding: 15px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .nav-menu a:hover,
        .nav-menu a.active {
            background: #34495e;
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: #2c3e50;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2980b9;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #219a52;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .stat-card h3 {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .stat-card .change {
            font-size: 12px;
            margin-top: 5px;
        }
        
        .change.positive {
            color: #27ae60;
        }
        
        .change.negative {
            color: #e74c3c;
        }
        
        .monitoring-section {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .section-header {
            background: #34495e;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .section-content {
            padding: 20px;
        }
        
        .system-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: #7f8c8d;
        }
        
        .info-value {
            color: #2c3e50;
            font-weight: 500;
        }
        
        .log-tabs {
            display: flex;
            border-bottom: 1px solid #ecf0f1;
            margin-bottom: 20px;
        }
        
        .log-tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.3s;
        }
        
        .log-tab.active {
            color: #3498db;
            border-bottom-color: #3498db;
        }
        
        .log-content {
            display: none;
        }
        
        .log-content.active {
            display: block;
        }
        
        .log-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .log-table th,
        .log-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .log-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .log-table tr:hover {
            background: #f8f9fa;
        }
        
        .log-level {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .log-level.info {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .log-level.warning {
            background: #fff3e0;
            color: #f57c00;
        }
        
        .log-level.error {
            background: #ffebee;
            color: #d32f2f;
        }
        
        .log-level.debug {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #ecf0f1;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #3498db, #2980b9);
            transition: width 0.3s;
        }
        
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d5f4e6;
            color: #27ae60;
            border: 1px solid #27ae60;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffc107;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #dc3545;
        }
        
        .refresh-btn {
            background: #95a5a6;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }
        
        .refresh-btn:hover {
            background: #7f8c8d;
        }
        
        .loading {
            text-align: center;
            padding: 20px;
            color: #7f8c8d;
        }
        
        @media (max-width: 768px) {
            .admin-layout {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .system-info-grid {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <div class="sidebar">
            <h3>发卡系统管理</h3>
            <ul class="nav-menu">
                <li><a href="../admin/index.php">仪表板</a></li>
                <li><a href="../admin/users.php">用户管理</a></li>
                <li><a href="../admin/cards.php">卡片管理</a></li>
                <li><a href="../admin/orders.php">订单管理</a></li>
                <li><a href="#" class="active">系统监控</a></li>
                <li><a href="../admin/settings.php">系统设置</a></li>
                <li><a href="../logout.php">退出登录</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>系统监控</h1>
                <div class="header-actions">
                    <button class="refresh-btn" onclick="refreshData()">刷新数据</button>
                    <a href="../admin/index.php" class="btn btn-primary">返回仪表板</a>
                </div>
            </div>
            
            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>系统运行时间</h3>
                    <div class="value" id="uptime">计算中...</div>
                    <div class="change positive">正常运行</div>
                </div>
                
                <div class="stat-card">
                    <h3>在线用户</h3>
                    <div class="value"><?php echo $systemStats['users']['online']; ?></div>
                    <div class="change positive">活跃用户</div>
                </div>
                
                <div class="stat-card">
                    <h3>今日订单</h3>
                    <div class="value"><?php echo $systemStats['orders']['today']; ?></div>
                    <div class="change positive">新增订单</div>
                </div>
                
                <div class="stat-card">
                    <h3>今日收入</h3>
                    <div class="value">¥<?php echo number_format($systemStats['orders']['revenue_today'], 2); ?></div>
                    <div class="change positive">营业收入</div>
                </div>
            </div>
            
            <!-- 系统信息 -->
            <div class="monitoring-section">
                <div class="section-header">
                    <h3>系统信息</h3>
                    <button class="refresh-btn" onclick="refreshSystemInfo()">刷新</button>
                </div>
                <div class="section-content">
                    <div class="system-info-grid">
                        <div>
                            <h4>服务器信息</h4>
                            <div class="info-item">
                                <span class="info-label">PHP版本</span>
                                <span class="info-value"><?php echo $systemStats['system']['php_version']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">服务器软件</span>
                                <span class="info-value"><?php echo $systemStats['system']['server_software']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">服务器时间</span>
                                <span class="info-value"><?php echo $systemStats['system']['server_time']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">时区</span>
                                <span class="info-value"><?php echo $systemStats['system']['timezone']; ?></span>
                            </div>
                        </div>
                        
                        <div>
                            <h4>数据库信息</h4>
                            <div class="info-item">
                                <span class="info-label">数据库版本</span>
                                <span class="info-value"><?php echo $systemStats['database']['version']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">数据库大小</span>
                                <span class="info-value"><?php echo $systemStats['database']['size']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">活跃连接数</span>
                                <span class="info-value"><?php echo $systemStats['database']['connections']; ?></span>
                            </div>
                        </div>
                        
                        <div>
                            <h4>系统性能</h4>
                            <div class="info-item">
                                <span class="info-label">CPU使用率</span>
                                <span class="info-value"><?php echo $systemStats['performance']['cpu_usage']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">内存使用</span>
                                <span class="info-value"><?php echo round($systemStats['performance']['memory_usage'] / 1024 / 1024, 2); ?> MB</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">磁盘使用</span>
                                <span class="info-value"><?php echo $systemStats['performance']['disk_usage']['percentage']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">磁盘空间</span>
                                <span class="info-value"><?php echo $systemStats['performance']['disk_usage']['used']; ?> / <?php echo $systemStats['performance']['disk_usage']['total']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 日志管理 -->
            <div class="monitoring-section">
                <div class="section-header">
                    <h3>日志管理</h3>
                    <div>
                        <button class="btn btn-danger" onclick="clearLogs()">清理日志</button>
                        <button class="refresh-btn" onclick="refreshLogs()">刷新</button>
                    </div>
                </div>
                <div class="section-content">
                    <div class="log-tabs">
                        <div class="log-tab active" onclick="switchTab('system')">系统日志</div>
                        <div class="log-tab" onclick="switchTab('error')">错误日志</div>
                        <div class="log-tab" onclick="switchTab('operation')">操作日志</div>
                    </div>
                    
                    <!-- 系统日志 -->
                    <div id="system-logs" class="log-content active">
                        <table class="log-table">
                            <thead>
                                <tr>
                                    <th>时间</th>
                                    <th>级别</th>
                                    <th>消息</th>
                                </tr>
                            </thead>
                            <tbody id="system-log-tbody">
                                <?php foreach ($recentLogs as $log): ?>
                                <tr>
                                    <td><?php echo $log['created_at']; ?></td>
                                    <td><span class="log-level <?php echo $log['level']; ?>"><?php echo strtoupper($log['level']); ?></span></td>
                                    <td><?php echo htmlspecialchars($log['message']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- 错误日志 -->
                    <div id="error-logs" class="log-content">
                        <table class="log-table">
                            <thead>
                                <tr>
                                    <th>时间</th>
                                    <th>错误类型</th>
                                    <th>消息</th>
                                    <th>文件</th>
                                </tr>
                            </thead>
                            <tbody id="error-log-tbody">
                                <?php foreach ($errorLogs as $log): ?>
                                <tr>
                                    <td><?php echo $log['created_at']; ?></td>
                                    <td><?php echo htmlspecialchars($log['error_type']); ?></td>
                                    <td><?php echo htmlspecialchars($log['message']); ?></td>
                                    <td><?php echo htmlspecialchars($log['file']); ?>:<?php echo $log['line']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- 操作日志 -->
                    <div id="operation-logs" class="log-content">
                        <table class="log-table">
                            <thead>
                                <tr>
                                    <th>时间</th>
                                    <th>用户</th>
                                    <th>操作</th>
                                    <th>资源</th>
                                    <th>IP地址</th>
                                </tr>
                            </thead>
                            <tbody id="operation-log-tbody">
                                <?php foreach ($operationLogs as $log): ?>
                                <tr>
                                    <td><?php echo $log['created_at']; ?></td>
                                    <td><?php echo htmlspecialchars($log['username']); ?></td>
                                    <td><?php echo htmlspecialchars($log['action']); ?></td>
                                    <td><?php echo htmlspecialchars($log['resource_type']); ?>:<?php echo $log['resource_id']; ?></td>
                                    <td><?php echo $log['ip_address']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let currentTab = 'system';
        
        // 切换标签页
        function switchTab(tab) {
            // 移除所有活动状态
            document.querySelectorAll('.log-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.log-content').forEach(c => c.classList.remove('active'));
            
            // 设置当前活动标签
            event.target.classList.add('active');
            document.getElementById(tab + '-logs').classList.add('active');
            
            currentTab = tab;
        }
        
        // 刷新数据
        function refreshData() {
            fetch('monitoring.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=get_stats'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateSystemStats(data.data);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
        // 更新系统统计
        function updateSystemStats(stats) {
            // 更新系统信息
            const systemInfo = document.querySelector('.system-info-grid');
            // 这里可以根据需要更新具体的统计数据
        }
        
        // 刷新系统信息
        function refreshSystemInfo() {
            refreshData();
        }
        
        // 刷新日志
        function refreshLogs() {
            fetch('monitoring.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=get_logs&type=' + currentTab + '&limit=20'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateLogTable(currentTab, data.data);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
        // 更新日志表格
        function updateLogTable(type, logs) {
            const tbody = document.getElementById(type + '-log-tbody');
            tbody.innerHTML = '';
            
            logs.forEach(log => {
                const tr = document.createElement('tr');
                
                if (type === 'system') {
                    tr.innerHTML = `
                        <td>${log.created_at}</td>
                        <td><span class="log-level ${log.level}">${log.level.toUpperCase()}</span></td>
                        <td>${log.message}</td>
                    `;
                } else if (type === 'error') {
                    tr.innerHTML = `
                        <td>${log.created_at}</td>
                        <td>${log.error_type}</td>
                        <td>${log.message}</td>
                        <td>${log.file}:${log.line}</td>
                    `;
                } else if (type === 'operation') {
                    tr.innerHTML = `
                        <td>${log.created_at}</td>
                        <td>${log.username}</td>
                        <td>${log.action}</td>
                        <td>${log.resource_type}:${log.resource_id}</td>
                        <td>${log.ip_address}</td>
                    `;
                }
                
                tbody.appendChild(tr);
            });
        }
        
        // 清理日志
        function clearLogs() {
            if (confirm('确定要清理30天前的日志吗？此操作不可恢复。')) {
                fetch('monitoring.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=clear_logs&type=' + currentTab
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('日志清理完成');
                        refreshLogs();
                    } else {
                        alert('清理失败：' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('清理失败');
                });
            }
        }
        
        // 计算系统运行时间
        function calculateUptime() {
            // 这里应该从服务器获取实际的启动时间
            // 暂时显示一个模拟值
            const uptimeElement = document.getElementById('uptime');
            uptimeElement.textContent = '2天 15小时 32分钟';
        }
        
        // 页面加载完成后初始化
        document.addEventListener('DOMContentLoaded', function() {
            calculateUptime();
            
            // 设置自动刷新（每30秒）
            setInterval(refreshData, 30000);
        });
    </script>
</body>
</html>