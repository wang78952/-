<?php
/**
 * 数据库性能监控和优化管理界面
 */

// 验证管理员权限
require_once '../includes/common.php';
if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    header('Location: login.php');
    exit;
}

// 加载必要的类
require_once '../includes/database/DatabaseConnectionManager.php';
require_once '../includes/database/DatabaseMaintenance.php';
require_once '../includes/database/DatabaseOptimizationAdvisor.php';
require_once '../includes/database/DatabaseMaintenanceScheduler.php';
require_once '../includes/monitoring/PerformanceProfiler.php';

// 初始化数据库连接
$config = [
    'host' => DB_HOST,
    'port' => DB_PORT,
    'dbname' => DB_NAME,
    'username' => DB_USER,
    'password' => DB_PASS,
];
$connectionManager = DatabaseConnectionManager::getInstance($config);

// 初始化工具类
$advisor = new DatabaseOptimizationAdvisor($connectionManager);
$scheduler = new DatabaseMaintenanceScheduler($connectionManager);
$maintenance = new DatabaseMaintenance($connectionManager);
$profiler = new PerformanceProfiler();

// 页面动作处理
$action = isset($_GET['action']) ? $_GET['action'] : 'dashboard';
$message = null;
$messageType = 'success';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        switch ($_POST['action']) {
            case 'run_maintenance':
                // 手动运行维护任务
                $taskId = $_POST['task_id'] ?? null;
                if ($taskId) {
                    $scheduler->runTask($taskId);
                    $message = "维护任务 '{$taskId}' 已手动启动";
                } else {
                    // 运行所有启用的任务
                    $scheduler->run();
                    $message = "所有启用的维护任务已启动";
                }
                break;
                
            case 'update_task':
                // 更新任务配置
                $taskId = $_POST['task_id'] ?? null;
                if ($taskId) {
                    $task = [
                        'id' => $taskId,
                        'enabled' => isset($_POST['enabled']),
                        'name' => $_POST['name'] ?? '',
                        'schedule' => $_POST['schedule'] ?? 'daily',
                        'time' => $_POST['time'] ?? '00:00',
                        'params' => json_decode($_POST['params'] ?? '{}', true),
                    ];
                    $scheduler->addTask($task);
                    $message = "任务配置已更新";
                }
                break;
                
            case 'delete_task':
                // 删除任务
                $taskId = $_POST['task_id'] ?? null;
                if ($taskId) {
                    $scheduler->removeTask($taskId);
                    $message = "任务已删除";
                }
                break;
                
            case 'add_task':
                // 添加新任务
                $newTask = [
                    'name' => $_POST['name'] ?? '',
                    'type' => $_POST['task_type'] ?? 'optimize_indexes',
                    'schedule' => $_POST['schedule'] ?? 'daily',
                    'time' => $_POST['time'] ?? '00:00',
                    'enabled' => isset($_POST['enabled']),
                    'params' => json_decode($_POST['params'] ?? '{}', true),
                ];
                $scheduler->addTask($newTask);
                $message = "新任务已添加";
                break;
                
            case 'update_settings':
                // 更新调度器设置
                $settings = [
                    'maintenance_window' => [
                        'start' => $_POST['window_start'] ?? '00:00',
                        'end' => $_POST['window_end'] ?? '06:00',
                    ],
                    'email_notifications' => isset($_POST['email_notifications']),
                    'email_recipients' => explode(',', $_POST['email_recipients'] ?? ''),
                ];
                $scheduler->setConfig($settings);
                $message = "设置已更新";
                break;
                
            case 'force_optimize':
                // 强制优化指定表
                $table = $_POST['table'] ?? '';
                if ($table) {
                    $result = $maintenance->optimizeTablespaces([$table]);
                    $message = "表 '{$table}' 优化完成";
                }
                break;
                
            case 'clear_cache':
                // 清除缓存
                $advisor->clearCache();
                $message = "性能分析缓存已清除";
                break;
        }
    } catch (Exception $e) {
        $message = "操作失败: " . $e->getMessage();
        $messageType = 'error';
    }
}

// 获取数据
$performanceReport = null;
$runningTasks = [];
$taskSchedule = [];
$schedulerStatus = [];
$fragmentationStats = [];

switch ($action) {
    case 'dashboard':
        // 获取性能报告摘要
        $performanceReport = $advisor->getOptimizationReport();
        $runningTasks = $scheduler->getRunningTasks();
        $schedulerStatus = $scheduler->getStatus();
        $fragmentationStats = $maintenance->analyzeFragmentation();
        break;
        
    case 'maintenance_tasks':
        // 获取任务列表
        $taskSchedule = $scheduler->getSchedule();
        $runningTasks = $scheduler->getRunningTasks();
        $schedulerStatus = $scheduler->getStatus();
        break;
        
    case 'optimization_advice':
        // 获取完整的优化建议
        $performanceReport = $advisor->getOptimizationReport(true);
        break;
        
    case 'fragmentation':
        // 获取碎片分析
        $fragmentationStats = $maintenance->analyzeFragmentation();
        break;
        
    case 'settings':
        // 获取设置信息
        $schedulerConfig = $scheduler->getConfig();
        break;
}

// 任务类型选项
$taskTypes = [
    'optimize_indexes' => '索引优化',
    'optimize_tablespaces' => '表空间优化',
    'generate_report' => '生成性能报告',
    'backup' => '数据库备份',
    'analyze_schema' => '数据库架构分析',
];

// 调度类型选项
$schedules = [
    'daily' => '每日',
    'weekly' => '每周',
    'monthly' => '每月',
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据库性能监控与优化 - 管理中心</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #212529;
            padding-top: 1rem;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
            padding: 0.75rem 1rem;
            border-radius: 0.375rem;
            margin-bottom: 0.25rem;
        }
        .sidebar .nav-link:hover {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link.active {
            color: #ffffff;
            background-color: #0d6efd;
        }
        .card {
            border-radius: 0.5rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
        }
        .card-header {
            background-color: #f8f9fa;
            font-weight: 600;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .badge {
            font-size: 0.75rem;
            padding: 0.375rem 0.75rem;
        }
        .progress {
            height: 0.75rem;
            border-radius: 0.375rem;
        }
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
        .list-group-item {
            border: none;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .list-group-item:last-child {
            border-bottom: none;
        }
        .form-check-input:checked {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 1.5rem;
        }
        .severity-low {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        .severity-medium {
            background-color: #fff3cd;
            color: #664d03;
        }
        .severity-high {
            background-color: #f8d7da;
            color: #842029;
        }
        .severity-critical {
            background-color: #ffcccc;
            color: #721c24;
        }
        .status-running {
            background-color: #0dcaf0;
            color: #004085;
        }
        .status-completed {
            background-color: #198754;
            color: white;
        }
        .status-failed {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- 侧边栏导航 -->
            <nav class="col-md-2 d-none d-md-block bg-dark sidebar">
                <div class="sidebar-sticky">
                    <div class="text-center p-3 mb-4">
                        <h4 class="text-white">数据库管理</h4>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $action === 'dashboard' ? 'active' : ''; ?>" href="database_performance.php?action=dashboard">
                                <i class="fa fa-tachometer mr-2"></i> 仪表盘
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $action === 'maintenance_tasks' ? 'active' : ''; ?>" href="database_performance.php?action=maintenance_tasks">
                                <i class="fa fa-tasks mr-2"></i> 维护任务
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $action === 'optimization_advice' ? 'active' : ''; ?>" href="database_performance.php?action=optimization_advice">
                                <i class="fa fa-lightbulb-o mr-2"></i> 优化建议
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $action === 'fragmentation' ? 'active' : ''; ?>" href="database_performance.php?action=fragmentation">
                                <i class="fa fa-database mr-2"></i> 碎片分析
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $action === 'settings' ? 'active' : ''; ?>" href="database_performance.php?action=settings">
                                <i class="fa fa-cog mr-2"></i> 设置
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- 主内容区域 -->
            <main role="main" class="col-md-10 ml-sm-auto px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">数据库性能监控与优化</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group mr-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#refreshDataModal">
                                <i class="fa fa-refresh mr-1"></i> 刷新数据
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#runMaintenanceModal">
                                <i class="fa fa-play mr-1"></i> 运行维护
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 消息提示 -->
                <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType === 'error' ? 'danger' : 'success'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <!-- 仪表盘视图 -->
                <?php if ($action === 'dashboard'): ?>
                    <div class="row">
                        <!-- 性能概览卡片 -->
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">优化建议数量</h5>
                                    <p class="h2 mb-0"><?php echo count($performanceReport['recommendations'] ?? []); ?></p>
                                    <div class="text-sm text-muted mt-1">需要优化的项</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">运行中任务</h5>
                                    <p class="h2 mb-0"><?php echo count(array_filter($runningTasks, function($t) { return $t['status'] === 'running'; })); ?></p>
                                    <div class="text-sm text-muted mt-1">当前执行的任务</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">维护任务总数</h5>
                                    <p class="h2 mb-0"><?php echo $schedulerStatus['total_tasks'] ?? 0; ?></p>
                                    <div class="text-sm text-muted mt-1">已配置的定时任务</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">碎片表数量</h5>
                                    <p class="h2 mb-0"><?php echo count(array_filter($fragmentationStats['tables'] ?? [], function($t) { return $t['fragmentation'] > 10; })); ?></p>
                                    <div class="text-sm text-muted mt-1">需要优化的表</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 维护状态图表 -->
                    <div class="card">
                        <div class="card-header">维护任务状态</div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="maintenanceStatusChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- 优化建议列表 -->
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <span>优化建议概览</span>
                                <a href="database_performance.php?action=optimization_advice" class="btn btn-sm btn-outline-primary">查看全部</a>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group">
                                <?php if (!empty($performanceReport['recommendations'])): ?>
                                    <?php foreach (array_slice($performanceReport['recommendations'], 0, 5) as $advice): ?>
                                        <li class="list-group-item">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span class="font-weight-medium"><?php echo $advice['title']; ?></span>
                                                <span class="badge severity-<?php echo strtolower($advice['severity']); ?>">
                                                    <?php echo $advice['severity']; ?>
                                                </span>
                                            </div>
                                            <p class="text-sm text-muted mb-1"><?php echo $advice['description']; ?></p>
                                            <div class="text-xs text-muted">影响对象: <?php echo $advice['affected_entity']; ?></div>
                                        </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li class="list-group-item text-center text-muted">暂无优化建议</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- 运行中任务 -->
                    <div class="card">
                        <div class="card-header">运行中任务</div>
                        <div class="card-body p-0">
                            <ul class="list-group">
                                <?php if (!empty($runningTasks)): ?>
                                    <?php foreach ($runningTasks as $taskId => $task): ?>
                                        <li class="list-group-item">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span class="font-weight-medium"><?php echo $task['name']; ?></span>
                                                <span class="badge status-<?php echo $task['status']; ?>">
                                                    <?php echo ucfirst($task['status']); ?>
                                                </span>
                                            </div>
                                            <div class="text-xs text-muted mb-1">
                                                开始时间: <?php echo date('Y-m-d H:i:s', $task['start_time']); ?>
                                            </div>
                                            <?php if (isset($task['end_time'])): ?>
                                                <div class="text-xs text-muted">
                                                    执行时间: <?php echo gmdate('H:i:s', $task['end_time'] - $task['start_time']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li class="list-group-item text-center text-muted">当前没有运行中的任务</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- 维护任务视图 -->
                <?php if ($action === 'maintenance_tasks'): ?>
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <span>维护任务列表</span>
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                                    <i class="fa fa-plus mr-1"></i> 添加任务
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">任务名称</th>
                                            <th scope="col">类型</th>
                                            <th scope="col">调度方式</th>
                                            <th scope="col">状态</th>
                                            <th scope="col">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($taskSchedule as $task): ?>
                                            <tr>
                                                <td>
                                                    <div class="font-medium"><?php echo $task['name']; ?></div>
                                                    <div class="text-xs text-muted">ID: <?php echo $task['id']; ?></div>
                                                </td>
                                                <td><?php echo $taskTypes[$task['type']] ?? $task['type']; ?></td>
                                                <td>
                                                    <div><?php echo $schedules[$task['schedule']] ?? $task['schedule']; ?></div>
                                                    <div class="text-xs text-muted">时间: <?php echo $task['time']; ?></div>
                                                </td>
                                                <td>
                                                    <span class="badge <?php echo $task['enabled'] ? 'bg-success' : 'bg-secondary'; ?>">
                                                        <?php echo $task['enabled'] ? '启用' : '禁用'; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" 
                                                                data-bs-target="#editTaskModal" 
                                                                data-task-id="<?php echo $task['id']; ?>" 
                                                                data-task-name="<?php echo $task['name']; ?>" 
                                                                data-task-type="<?php echo $task['type']; ?>" 
                                                                data-task-schedule="<?php echo $task['schedule']; ?>" 
                                                                data-task-time="<?php echo $task['time']; ?>" 
                                                                data-task-enabled="<?php echo $task['enabled']; ?>" 
                                                                data-task-params="<?php echo json_encode($task['params'] ?? []); ?>">
                                                            <i class="fa fa-pencil"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-outline-secondary" 
                                                                onclick="document.getElementById('delete-task-id').value = '<?php echo $task['id']; ?>';
                                                                document.getElementById('delete-task-form').submit();">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-outline-secondary" 
                                                                onclick="document.getElementById('run-task-id').value = '<?php echo $task['id']; ?>';
                                                                document.getElementById('run-task-form').submit();">
                                                            <i class="fa fa-play"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- 运行中的任务 -->
                    <div class="card">
                        <div class="card-header">当前任务状态</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <div class="h4 mb-0"><?php echo $schedulerStatus['active_tasks'] ?? 0; ?></div>
                                        <div class="text-sm text-muted">运行中任务</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <div class="h4 mb-0"><?php echo $schedulerStatus['completed_tasks'] ?? 0; ?></div>
                                        <div class="text-sm text-muted">已完成任务</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <div class="h4 mb-0"><?php echo $schedulerStatus['failed_tasks'] ?? 0; ?></div>
                                        <div class="text-sm text-muted">失败任务</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <div class="h4 mb-0">
                                            <span class="badge <?php echo $schedulerStatus['in_maintenance_window'] ? 'bg-success' : 'bg-warning'; ?>">
                                                <?php echo $schedulerStatus['in_maintenance_window'] ? '维护时间内' : '非维护时间'; ?>
                                            </span>
                                        </div>
                                        <div class="text-sm text-muted">维护窗口状态</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- 优化建议视图 -->
                <?php if ($action === 'optimization_advice'): ?>
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <span>优化建议</span>
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="document.getElementById('clear-cache-form').submit();">
                                        <i class="fa fa-trash mr-1"></i> 清除缓存
                                    </button>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-secondary" onclick="filterAdvice('all')">全部</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="filterAdvice('high')">高</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="filterAdvice('medium')">中</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="filterAdvice('low')">低</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group advice-list">
                                <?php if (!empty($performanceReport['recommendations'])): ?>
                                    <?php foreach ($performanceReport['recommendations'] as $advice): ?>
                                        <li class="list-group-item advice-item severity-<?php echo strtolower($advice['severity']); ?>">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span class="font-weight-medium"><?php echo $advice['title']; ?></span>
                                                <span class="badge severity-<?php echo strtolower($advice['severity']); ?>">
                                                    <?php echo $advice['severity']; ?>
                                                </span>
                                            </div>
                                            <p class="text-sm text-muted mb-1"><?php echo $advice['description']; ?></p>
                                            <div class="text-xs text-muted mb-2">影响对象: <?php echo $advice['affected_entity']; ?></div>
                                            <div class="bg-light p-2 rounded">
                                                <div class="text-xs font-weight-medium mb-1">优化建议:</div>
                                                <div class="text-sm"><?php echo $advice['recommendation']; ?></div>
                                            </div>
                                            <div class="mt-2">
                                                <?php if (isset($advice['sql_example'])): ?>
                                                    <div class="text-xs font-weight-medium mb-1">SQL示例:</div>
                                                    <pre class="text-xs p-2 bg-gray-100 rounded overflow-x-auto"><?php echo $advice['sql_example']; ?></pre>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li class="list-group-item text-center text-muted">暂无优化建议</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- 碎片分析视图 -->
                <?php if ($action === 'fragmentation'): ?>
                    <div class="card">
                        <div class="card-header">表空间碎片分析</div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">表名</th>
                                            <th scope="col">表大小 (MB)</th>
                                            <th scope="col">碎片大小 (MB)</th>
                                            <th scope="col">碎片率</th>
                                            <th scope="col">状态</th>
                                            <th scope="col">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($fragmentationStats['tables'])): ?>
                                            <?php foreach ($fragmentationStats['tables'] as $table): ?>
                                                <tr>
                                                    <td><?php echo $table['name']; ?></td>
                                                    <td><?php echo number_format($table['size'] / 1024 / 1024, 2); ?></td>
                                                    <td><?php echo number_format($table['fragmentation_size'] / 1024 / 1024, 2); ?></td>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <div class="progress flex-grow-1 mr-2">
                                                                <div class="progress-bar bg-<?php echo $table['fragmentation'] > 20 ? 'danger' : ($table['fragmentation'] > 10 ? 'warning' : 'success'); ?>"
                                                                     style="width: <?php echo min($table['fragmentation'], 100); ?>%"
                                                                     role="progressbar"></div>
                                                            </div>
                                                            <span><?php echo number_format($table['fragmentation'], 1); ?>%</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?php echo $table['fragmentation'] > 20 ? 'danger' : ($table['fragmentation'] > 10 ? 'warning' : 'success'); ?>">
                                                            <?php echo $table['fragmentation'] > 20 ? '需要优化' : ($table['fragmentation'] > 10 ? '建议优化' : '正常'); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-sm btn-outline-secondary" 
                                                                onclick="document.getElementById('optimize-table').value = '<?php echo $table['name']; ?>';
                                                                document.getElementById('optimize-table-form').submit();">
                                                            <i class="fa fa-wrench"></i> 优化
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center text-muted">暂无碎片分析数据</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer text-xs text-muted">
                            <div>分析时间: <?php echo $fragmentationStats['timestamp'] ? date('Y-m-d H:i:s', $fragmentationStats['timestamp']) : 'N/A'; ?></div>
                            <div>总共分析表数量: <?php echo count($fragmentationStats['tables'] ?? []); ?></div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- 设置视图 -->
                <?php if ($action === 'settings'): ?>
                    <div class="card">
                        <div class="card-header">调度器设置</div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="action" value="update_settings">
                                
                                <div class="mb-3">
                                    <label for="window_start" class="form-label">维护窗口开始时间</label>
                                    <input type="time" class="form-control" id="window_start" name="window_start" 
                                           value="<?php echo $schedulerConfig['maintenance_window']['start'] ?? '00:00'; ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="window_end" class="form-label">维护窗口结束时间</label>
                                    <input type="time" class="form-control" id="window_end" name="window_end" 
                                           value="<?php echo $schedulerConfig['maintenance_window']['end'] ?? '06:00'; ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" 
                                               <?php echo isset($schedulerConfig['email_notifications']) && $schedulerConfig['email_notifications'] ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="email_notifications">启用邮件通知</label>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email_recipients" class="form-label">通知邮箱 (多个邮箱用逗号分隔)</label>
                                    <input type="text" class="form-control" id="email_recipients" name="email_recipients" 
                                           value="<?php echo implode(', ', $schedulerConfig['email_recipients'] ?? []); ?>">
                                </div>
                                
                                <button type="submit" class="btn btn-primary">保存设置</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <!-- 模态框 -->
    <!-- 运行维护模态框 -->
    <div class="modal fade" id="runMaintenanceModal" tabindex="-1" aria-labelledby="runMaintenanceModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="runMaintenanceModalLabel">运行维护任务</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>确认要立即运行数据库维护任务吗？这可能会对系统性能产生一定影响。</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" onclick="document.getElementById('run-maintenance-form').submit();">运行</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 编辑任务模态框 -->
    <div class="modal fade" id="editTaskModal" tabindex="-1" aria-labelledby="editTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTaskModalLabel">编辑任务</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="edit-task-form" method="POST">
                        <input type="hidden" name="action" value="update_task">
                        <input type="hidden" name="task_id" id="edit-task-id">
                        
                        <div class="mb-3">
                            <label for="edit-task-name" class="form-label">任务名称</label>
                            <input type="text" class="form-control" id="edit-task-name" name="name" required>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="edit-task-type" class="form-label">任务类型</label>
                                <select class="form-control" id="edit-task-type" name="task_type" disabled>
                                    <?php foreach ($taskTypes as $value => $label): ?>
                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="edit-task-schedule" class="form-label">调度方式</label>
                                <select class="form-control" id="edit-task-schedule" name="schedule">
                                    <?php foreach ($schedules as $value => $label): ?>
                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="edit-task-time" class="form-label">执行时间</label>
                                <input type="time" class="form-control" id="edit-task-time" name="time" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="edit-task-enabled" name="enabled">
                                <label class="form-check-label" for="edit-task-enabled">启用任务</label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit-task-params" class="form-label">任务参数 (JSON)</label>
                            <textarea class="form-control" id="edit-task-params" name="params" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" onclick="document.getElementById('edit-task-form').submit();">保存</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 添加任务模态框 -->
    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTaskModalLabel">添加新任务</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="add-task-form" method="POST">
                        <input type="hidden" name="action" value="add_task">
                        
                        <div class="mb-3">
                            <label for="new-task-name" class="form-label">任务名称</label>
                            <input type="text" class="form-control" id="new-task-name" name="name" required>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="new-task-type" class="form-label">任务类型</label>
                                <select class="form-control" id="new-task-type" name="task_type">
                                    <?php foreach ($taskTypes as $value => $label): ?>
                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="new-task-schedule" class="form-label">调度方式</label>
                                <select class="form-control" id="new-task-schedule" name="schedule">
                                    <?php foreach ($schedules as $value => $label): ?>
                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="new-task-time" class="form-label">执行时间</label>
                                <input type="time" class="form-control" id="new-task-time" name="time" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="new-task-enabled" name="enabled" checked>
                                <label class="form-check-label" for="new-task-enabled">启用任务</label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new-task-params" class="form-label">任务参数 (JSON)</label>
                            <textarea class="form-control" id="new-task-params" name="params" rows="3">{}</textarea>
                            <div class="text-xs text-muted mt-1">默认为空对象，根据任务类型填写相应参数</div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" onclick="document.getElementById('add-task-form').submit();">添加</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 表单 -->
    <form id="run-maintenance-form" method="POST" style="display: none;">
        <input type="hidden" name="action" value="run_maintenance">
    </form>
    
    <form id="run-task-form" method="POST" style="display: none;">
        <input type="hidden" name="action" value="run_maintenance">
        <input type="hidden" name="task_id" id="run-task-id">
    </form>
    
    <form id="delete-task-form" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete_task">
        <input type="hidden" name="task_id" id="delete-task-id">
    </form>
    
    <form id="clear-cache-form" method="POST" style="display: none;">
        <input type="hidden" name="action" value="clear_cache">
    </form>
    
    <form id="optimize-table-form" method="POST" style="display: none;">
        <input type="hidden" name="action" value="force_optimize">
        <input type="hidden" name="table" id="optimize-table">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
    <script>
        // 初始化编辑任务模态框
        document.getElementById('editTaskModal').addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const taskId = button.getAttribute('data-task-id');
            const taskName = button.getAttribute('data-task-name');
            const taskType = button.getAttribute('data-task-type');
            const taskSchedule = button.getAttribute('data-task-schedule');
            const taskTime = button.getAttribute('data-task-time');
            const taskEnabled = button.getAttribute('data-task-enabled') === 'true';
            const taskParams = button.getAttribute('data-task-params');
            
            document.getElementById('edit-task-id').value = taskId;
            document.getElementById('edit-task-name').value = taskName;
            document.getElementById('edit-task-type').value = taskType;
            document.getElementById('edit-task-schedule').value = taskSchedule;
            document.getElementById('edit-task-time').value = taskTime;
            document.getElementById('edit-task-enabled').checked = taskEnabled;
            document.getElementById('edit-task-params').value = JSON.stringify(JSON.parse(taskParams), null, 2);
        });
        
        // 筛选优化建议
        function filterAdvice(severity) {
            const items = document.querySelectorAll('.advice-item');
            items.forEach(item => {
                if (severity === 'all' || item.classList.contains('severity-' + severity)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }
        
        // 初始化图表
        window.addEventListener('load', function() {
            const ctx = document.getElementById('maintenanceStatusChart');
            if (ctx) {
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: ['运行中', '已完成', '已失败', '未执行'],
                        datasets: [{
                            data: [
                                <?php echo $schedulerStatus['active_tasks'] ?? 0; ?>,
                                <?php echo $schedulerStatus['completed_tasks'] ?? 0; ?>,
                                <?php echo $schedulerStatus['failed_tasks'] ?? 0; ?>,
                                <?php echo ($schedulerStatus['total_tasks'] ?? 0) - ($schedulerStatus['active_tasks'] ?? 0) - ($schedulerStatus['completed_tasks'] ?? 0) - ($schedulerStatus['failed_tasks'] ?? 0); ?>
                            ],
                            backgroundColor: [
                                '#0dcaf0',
                                '#198754',
                                '#dc3545',
                                '#6c757d'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });
            }
        });
    </script>
</body>
</html>