<?php
/**
 * 用户购卡偏好分析前端页面
 * 展示用户购买行为分析、产品偏好统计等数据可视化内容
 */

require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/AuthManager.php';

// 验证管理员权限
$authManager = new AuthManager();
if (!$authManager->hasPermission('view_analytics')) {
    header('Location: login.php');
    exit;
}

$page_title = '用户购卡偏好分析';
$page_type = 'analytics';
$active_menu = 'user_purchase_analytics';

// 默认日期范围（最近30天）
$default_start_date = date('Y-m-d', strtotime('-30 days'));
$default_end_date = date('Y-m-d');

// 获取URL参数中的日期范围
$start_date = $_GET['start_date'] ?? $default_start_date;
$end_date = $_GET['end_date'] ?? $default_end_date;

// 获取用户ID（如果有）
$user_id = $_GET['user_id'] ?? '';

// 设置选中的选项卡
$active_tab = $_GET['tab'] ?? 'overview';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - 发卡系统管理后台</title>
    
    <!-- 引入CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dataTables.bootstrap4.min.css">
    
    <!-- 引入ECharts -->
    <script src="../assets/js/echarts.min.js"></script>
    
    <!-- 引入Flatpickr日期选择器 -->
    <link rel="stylesheet" href="../assets/css/flatpickr.min.css">
    <script src="../assets/js/flatpickr.min.js"></script>
    <script src="../assets/js/l10n/zh.js"></script>
    
    <style>
        /* 统计卡片样式 */
        .stat-card {
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .stat-card .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .stat-card .stat-icon {
            font-size: 2.5rem;
            color: #3498db;
            margin-bottom: 10px;
        }
        
        /* 图表容器样式 */
        .chart-container {
            height: 400px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .small-chart-container {
            height: 300px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        /* 选项卡样式 */
        .nav-tabs .nav-link {
            border-radius: 0;
            border: none;
            color: #666;
            font-weight: 500;
        }
        
        .nav-tabs .nav-link.active {
            color: #3498db;
            border-bottom: 3px solid #3498db;
            background-color: transparent;
        }
        
        /* 加载动画 */
        .loading-spinner {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 200px;
            font-size: 1.2rem;
            color: #666;
        }
        
        /* 数据表格样式调整 */
        .table-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin-bottom: 20px;
        }
        
        /* 筛选器样式 */
        .filter-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        /* 响应式调整 */
        @media (max-width: 768px) {
            .stat-card {
                margin-bottom: 15px;
            }
            
            .chart-container, .small-chart-container {
                height: 300px;
            }
        }
    </style>
</head>
<body>
    <!-- 顶部导航栏 -->
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <!-- 侧边栏导航 -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- 主内容区域 -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4 py-4">
                <div class="container-fluid">
                    <!-- 页面标题 -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><?php echo $page_title; ?></h1>
                        <div>
                            <a href="javascript:void(0)" id="export-excel" class="btn btn-success mr-2">
                                <i class="fa fa-download mr-1"></i> 导出Excel
                            </a>
                            <a href="javascript:void(0)" id="refresh-data" class="btn btn-primary">
                                <i class="fa fa-refresh mr-1"></i> 刷新数据
                            </a>
                        </div>
                    </div>
                    
                    <!-- 筛选表单 -->
                    <div class="filter-form">
                        <form id="filter-form" class="form-row">
                            <div class="form-group col-md-4">
                                <label for="start-date">开始日期</label>
                                <input type="date" id="start-date" name="start_date" class="form-control" value="<?php echo $start_date; ?>">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="end-date">结束日期</label>
                                <input type="date" id="end-date" name="end_date" class="form-control" value="<?php echo $end_date; ?>">
                            </div>
                            <div class="form-group col-md-2">
                                <label for="user-id">用户ID</label>
                                <input type="text" id="user-id" name="user_id" class="form-control" value="<?php echo $user_id; ?>" placeholder="可选">
                            </div>
                            <div class="form-group col-md-2 align-self-end">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-filter mr-1"></i> 筛选
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- 选项卡导航 -->
                    <ul class="nav nav-tabs mb-4" id="analytics-tabs">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_tab == 'overview' ? 'active' : ''; ?>" data-tab="overview" href="?tab=overview&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&user_id=<?php echo $user_id; ?>">
                                <i class="fa fa-dashboard mr-1"></i> 概览
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_tab == 'products' ? 'active' : ''; ?>" data-tab="products" href="?tab=products&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&user_id=<?php echo $user_id; ?>">
                                <i class="fa fa-shopping-bag mr-1"></i> 产品偏好
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_tab == 'categories' ? 'active' : ''; ?>" data-tab="categories" href="?tab=categories&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&user_id=<?php echo $user_id; ?>">
                                <i class="fa fa-sitemap mr-1"></i> 分类偏好
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_tab == 'time' ? 'active' : ''; ?>" data-tab="time" href="?tab=time&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&user_id=<?php echo $user_id; ?>">
                                <i class="fa fa-clock-o mr-1"></i> 时间偏好
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_tab == 'frequency' ? 'active' : ''; ?>" data-tab="frequency" href="?tab=frequency&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&user_id=<?php echo $user_id; ?>">
                                <i class="fa fa-bar-chart mr-1"></i> 购买频率
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_tab == 'recommendations' ? 'active' : ''; ?>" data-tab="recommendations" href="?tab=recommendations&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&user_id=<?php echo $user_id; ?>">
                                <i class="fa fa-lightbulb-o mr-1"></i> 产品推荐
                            </a>
                        </li>
                    </ul>
                    
                    <!-- 选项卡内容 -->
                    <div class="tab-content">
                        <!-- 概览选项卡 -->
                        <div class="tab-pane fade show <?php echo $active_tab == 'overview' ? 'active' : ''; ?>" id="tab-overview">
                            <!-- 统计卡片行 -->
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="stat-icon"><i class="fa fa-users"></i></div>
                                        <h3>总用户数</h3>
                                        <div class="stat-value" id="total-users">--</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="stat-icon"><i class="fa fa-file-text"></i></div>
                                        <h3>总订单数</h3>
                                        <div class="stat-value" id="total-orders">--</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="stat-icon"><i class="fa fa-money"></i></div>
                                        <h3>总交易额</h3>
                                        <div class="stat-value" id="total-amount">¥--</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="stat-icon"><i class="fa fa-shopping-cart"></i></div>
                                        <h3>平均订单金额</h3>
                                        <div class="stat-value" id="avg-order-value">¥--</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 图表行 -->
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">产品偏好TOP10</h4>
                                        <div id="product-preferences-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">分类偏好统计</h4>
                                        <div id="category-preferences-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">价格区间偏好</h4>
                                        <div id="price-range-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">购买时段分析</h4>
                                        <div id="hourly-purchase-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 产品偏好选项卡 -->
                        <div class="tab-pane fade show <?php echo $active_tab == 'products' ? 'active' : ''; ?>" id="tab-products">
                            <!-- 产品偏好图表 -->
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <div class="chart-container">
                                        <h4 class="mb-3">产品偏好TOP20</h4>
                                        <div id="detailed-product-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 产品偏好表格 -->
                            <div class="table-container">
                                <h4 class="mb-3">产品偏好数据</h4>
                                <table class="table table-striped table-hover" id="product-preferences-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>产品名称</th>
                                            <th>分类</th>
                                            <th>价格</th>
                                            <th>购买次数</th>
                                            <th>购买数量</th>
                                            <th>总金额</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- 数据将通过JavaScript动态加载 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- 分类偏好选项卡 -->
                        <div class="tab-pane fade show <?php echo $active_tab == 'categories' ? 'active' : ''; ?>" id="tab-categories">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">分类偏好分布</h4>
                                        <div id="category-pie-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">分类销售额对比</h4>
                                        <div id="category-sales-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 分类偏好表格 -->
                            <div class="table-container">
                                <h4 class="mb-3">分类偏好数据</h4>
                                <table class="table table-striped table-hover" id="category-preferences-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>分类名称</th>
                                            <th>购买次数</th>
                                            <th>购买数量</th>
                                            <th>总金额</th>
                                            <th>平均价格</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- 数据将通过JavaScript动态加载 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- 时间偏好选项卡 -->
                        <div class="tab-pane fade show <?php echo $active_tab == 'time' ? 'active' : ''; ?>" id="tab-time">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">24小时购买分布</h4>
                                        <div id="hourly-distribution-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="chart-container">
                                        <h4 class="mb-3">星期购买分布</h4>
                                        <div id="weekday-distribution-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 时间偏好分析 -->
                            <div class="table-container">
                                <h4 class="mb-3">最佳购买时段分析</h4>
                                <div class="alert alert-info">
                                    <strong>最佳购买时段：</strong> <span id="best-time-period">--</span><br>
                                    <strong>最佳购买星期：</strong> <span id="best-weekday">--</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 购买频率选项卡 -->
                        <div class="tab-pane fade show <?php echo $active_tab == 'frequency' ? 'active' : ''; ?>" id="tab-frequency">
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <div class="chart-container">
                                        <h4 class="mb-3">用户购买频率分布</h4>
                                        <div id="frequency-chart" class="w-100 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 购买频率表格 -->
                            <div class="table-container">
                                <h4 class="mb-3">购买频率数据</h4>
                                <table class="table table-striped table-hover" id="frequency-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>购买次数</th>
                                            <th>用户数量</th>
                                            <th>平均消费金额</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- 数据将通过JavaScript动态加载 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- 产品推荐选项卡 -->
                        <div class="tab-pane fade show <?php echo $active_tab == 'recommendations' ? 'active' : ''; ?>" id="tab-recommendations">
                            <div class="filter-form mb-4">
                                <div class="form-row">
                                    <div class="form-group col-md-8">
                                        <label for="recommend-user-id">用户ID</label>
                                        <div class="input-group">
                                            <input type="text" id="recommend-user-id" class="form-control" value="<?php echo $user_id; ?>" placeholder="请输入用户ID">
                                            <div class="input-group-append">
                                                <button type="button" id="get-recommendations" class="btn btn-primary">获取推荐</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="recommend-limit">推荐数量</label>
                                        <select id="recommend-limit" class="form-control">
                                            <option value="5">5</option>
                                            <option value="10" selected>10</option>
                                            <option value="20">20</option>
                                            <option value="50">50</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 产品推荐结果 -->
                            <div id="recommendations-results">
                                <div class="alert alert-info">
                                    请输入用户ID并点击"获取推荐"按钮来查看产品推荐结果
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- 加载动画模态框 -->
    <div class="modal fade" id="loading-modal" tabindex="-1" role="dialog" aria-labelledby="loading-modal-label" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="loading-spinner">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">加载中...</span>
                        </div>
                        <p class="mt-2">正在加载数据...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 引入JavaScript -->
    <script src="../assets/js/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/Chart.min.js"></script>
    <script src="../assets/js/jquery.dataTables.min.js"></script>
    <script src="../assets/js/dataTables.bootstrap4.min.js"></script>
    
    <script>
        // 页面加载完成后初始化
        $(document).ready(function() {
            // 初始化日期选择器
            $('#start-date, #end-date').flatpickr({
                dateFormat: 'Y-m-d',
                locale: 'zh'
            });
            
            // 初始化选项卡切换
            $('#analytics-tabs a').on('click', function(e) {
                e.preventDefault();
                $(this).tab('show');
                var tabId = $(this).data('tab');
                
                // 切换URL参数
                var url = new URL(window.location);
                url.searchParams.set('tab', tabId);
                window.history.pushState({}, '', url);
            });
            
            // 筛选表单提交
            $('#filter-form').on('submit', function(e) {
                e.preventDefault();
                
                var startDate = $('#start-date').val();
                var endDate = $('#end-date').val();
                var userId = $('#user-id').val();
                
                // 构建URL
                var url = new URL(window.location);
                url.searchParams.set('start_date', startDate);
                url.searchParams.set('end_date', endDate);
                if (userId) {
                    url.searchParams.set('user_id', userId);
                } else {
                    url.searchParams.delete('user_id');
                }
                
                // 重新加载页面
                window.location.href = url.toString();
            });
            
            // 刷新数据按钮
            $('#refresh-data').on('click', function() {
                // 显示加载动画
                $('#loading-modal').modal('show');
                
                // 重新加载页面
                setTimeout(function() {
                    location.reload();
                }, 500);
            });
            
            // 导出Excel按钮
            $('#export-excel').on('click', function() {
                // 构建导出URL
                var url = '../api/analytics/export_user_purchase_analytics.php';
                var params = new URLSearchParams();
                params.append('start_date', $('#start-date').val());
                params.append('end_date', $('#end-date').val());
                if ($('#user-id').val()) {
                    params.append('user_id', $('#user-id').val());
                }
                params.append('format', 'excel');
                
                // 下载文件
                window.location.href = url + '?' + params.toString();
            });
            
            // 获取产品推荐
            $('#get-recommendations').on('click', function() {
                var userId = $('#recommend-user-id').val();
                var limit = $('#recommend-limit').val();
                
                if (!userId) {
                    alert('请输入用户ID');
                    return;
                }
                
                // 显示加载动画
                $('#loading-modal').modal('show');
                
                // 调用API获取推荐数据
                $.ajax({
                    url: '../api/analytics/user_purchase_analytics.php',
                    type: 'GET',
                    data: {
                        action: 'recommendations',
                        user_id: userId,
                        limit: limit
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#loading-modal').modal('hide');
                        
                        if (response.success) {
                            renderRecommendations(response.data);
                        } else {
                            alert('获取推荐失败: ' + response.message);
                        }
                    },
                    error: function() {
                        $('#loading-modal').modal('hide');
                        alert('获取推荐时发生错误');
                    }
                });
            });
            
            // 根据当前选中的选项卡加载相应数据
            if ('<?php echo $active_tab; ?>' === 'overview') {
                loadOverviewData();
            } else if ('<?php echo $active_tab; ?>' === 'products') {
                loadProductPreferencesData();
            } else if ('<?php echo $active_tab; ?>' === 'categories') {
                loadCategoryPreferencesData();
            } else if ('<?php echo $active_tab; ?>' === 'time') {
                loadTimePreferencesData();
            } else if ('<?php echo $active_tab; ?>' === 'frequency') {
                loadFrequencyData();
            }
        });
        
        /**
         * 加载概览数据
         */
        function loadOverviewData() {
            // 显示加载动画
            $('#loading-modal').modal('show');
            
            // 调用API获取概览数据
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'summary',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 更新统计卡片数据
                        $('#total-users').text(response.data.total_users);
                        $('#total-orders').text(response.data.total_orders);
                        $('#total-amount').text('¥' + response.data.total_amount.toFixed(2));
                        $('#avg-order-value').text('¥' + response.data.avg_order_value.toFixed(2));
                    }
                    
                    // 加载产品偏好图表
                    loadProductPreferencesChart();
                    
                    // 加载分类偏好图表
                    loadCategoryPreferencesChart();
                    
                    // 加载价格区间偏好图表
                    loadPriceRangeChart();
                    
                    // 加载购买时段分析图表
                    loadHourlyPurchaseChart();
                    
                    // 隐藏加载动画
                    $('#loading-modal').modal('hide');
                },
                error: function() {
                    alert('加载概览数据失败');
                    $('#loading-modal').modal('hide');
                }
            });
        }
        
        /**
         * 加载产品偏好图表
         */
        function loadProductPreferencesChart() {
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'product_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val(),
                    limit: 10
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data;
                        
                        // 提取数据
                        var productNames = [];
                        var purchaseCounts = [];
                        
                        chartData.forEach(function(item) {
                            productNames.push(item.product_name);
                            purchaseCounts.push(item.purchase_count);
                        });
                        
                        // 创建图表
                        var chart = echarts.init(document.getElementById('product-preferences-chart'));
                        var option = {
                            tooltip: {
                                trigger: 'axis',
                                axisPointer: {
                                    type: 'shadow'
                                }
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '15%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: productNames,
                                axisLabel: {
                                    interval: 0,
                                    rotate: 45
                                }
                            },
                            yAxis: {
                                type: 'value'
                            },
                            series: [{
                                data: purchaseCounts,
                                type: 'bar',
                                itemStyle: {
                                    color: '#3498db'
                                }
                            }]
                        };
                        
                        chart.setOption(option);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            chart.resize();
                        });
                    }
                }
            });
        }
        
        /**
         * 加载分类偏好图表
         */
        function loadCategoryPreferencesChart() {
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'category_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data;
                        
                        // 提取数据
                        var categories = [];
                        var amounts = [];
                        
                        chartData.forEach(function(item) {
                            categories.push(item.category_name || '未分类');
                            amounts.push(parseFloat(item.total_amount));
                        });
                        
                        // 创建图表
                        var chart = echarts.init(document.getElementById('category-preferences-chart'));
                        var option = {
                            tooltip: {
                                trigger: 'item',
                                formatter: '{a} <br/>{b}: {c} ({d}%)'
                            },
                            legend: {
                                orient: 'vertical',
                                left: 10,
                                data: categories
                            },
                            series: [{
                                name: '分类偏好',
                                type: 'pie',
                                radius: ['40%', '70%'],
                                avoidLabelOverlap: false,
                                itemStyle: {
                                    borderRadius: 10,
                                    borderColor: '#fff',
                                    borderWidth: 2
                                },
                                label: {
                                    show: false,
                                    position: 'center'
                                },
                                emphasis: {
                                    label: {
                                        show: true,
                                        fontSize: 18,
                                        fontWeight: 'bold'
                                    }
                                },
                                labelLine: {
                                    show: false
                                },
                                data: chartData.map(function(item) {
                                    return {
                                        value: parseFloat(item.total_amount),
                                        name: item.category_name || '未分类'
                                    };
                                })
                            }]
                        };
                        
                        chart.setOption(option);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            chart.resize();
                        });
                    }
                }
            });
        }
        
        /**
         * 加载价格区间偏好图表
         */
        function loadPriceRangeChart() {
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'price_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data;
                        
                        // 提取数据
                        var ranges = [];
                        var amounts = [];
                        
                        chartData.forEach(function(item) {
                            ranges.push(item.price_range);
                            amounts.push(parseFloat(item.total_amount));
                        });
                        
                        // 创建图表
                        var chart = echarts.init(document.getElementById('price-range-chart'));
                        var option = {
                            tooltip: {
                                trigger: 'axis',
                                axisPointer: {
                                    type: 'shadow'
                                }
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: ranges
                            },
                            yAxis: {
                                type: 'value',
                                name: '金额'
                            },
                            series: [{
                                data: amounts,
                                type: 'bar',
                                itemStyle: {
                                    color: '#2ecc71'
                                }
                            }]
                        };
                        
                        chart.setOption(option);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            chart.resize();
                        });
                    }
                }
            });
        }
        
        /**
         * 加载购买时段分析图表
         */
        function loadHourlyPurchaseChart() {
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'time_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data.hourly;
                        
                        // 提取数据
                        var hours = [];
                        var orderCounts = [];
                        
                        // 初始化24小时数组
                        for (var i = 0; i < 24; i++) {
                            hours.push(i + '点');
                            orderCounts.push(0);
                        }
                        
                        // 填充实际数据
                        chartData.forEach(function(item) {
                            orderCounts[item.hour] = item.order_count;
                        });
                        
                        // 创建图表
                        var chart = echarts.init(document.getElementById('hourly-purchase-chart'));
                        var option = {
                            tooltip: {
                                trigger: 'axis'
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: hours,
                                boundaryGap: false
                            },
                            yAxis: {
                                type: 'value',
                                name: '订单数'
                            },
                            series: [{
                                data: orderCounts,
                                type: 'line',
                                smooth: true,
                                areaStyle: {
                                    color: {
                                        type: 'linear',
                                        x: 0,
                                        y: 0,
                                        x2: 0,
                                        y2: 1,
                                        colorStops: [{
                                            offset: 0, color: 'rgba(52, 152, 219, 0.6)'
                                        }, {
                                            offset: 1, color: 'rgba(52, 152, 219, 0.1)'
                                        }]
                                    }
                                },
                                lineStyle: {
                                    color: '#3498db'
                                }
                            }]
                        };
                        
                        chart.setOption(option);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            chart.resize();
                        });
                    }
                }
            });
        }
        
        /**
         * 加载产品偏好详细数据
         */
        function loadProductPreferencesData() {
            // 显示加载动画
            $('#loading-modal').modal('show');
            
            // 加载产品偏好图表
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'product_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val(),
                    limit: 20
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data;
                        
                        // 提取数据
                        var productNames = [];
                        var amounts = [];
                        
                        chartData.forEach(function(item) {
                            productNames.push(item.product_name);
                            amounts.push(parseFloat(item.total_amount));
                        });
                        
                        // 创建图表
                        var chart = echarts.init(document.getElementById('detailed-product-chart'));
                        var option = {
                            tooltip: {
                                trigger: 'axis',
                                axisPointer: {
                                    type: 'shadow'
                                }
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '15%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: productNames,
                                axisLabel: {
                                    interval: 0,
                                    rotate: 45
                                }
                            },
                            yAxis: {
                                type: 'value',
                                name: '总金额'
                            },
                            series: [{
                                data: amounts,
                                type: 'bar',
                                itemStyle: {
                                    color: '#9b59b6'
                                }
                            }]
                        };
                        
                        chart.setOption(option);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            chart.resize();
                        });
                        
                        // 加载产品偏好表格
                        loadProductPreferencesTable(chartData);
                    }
                    
                    // 隐藏加载动画
                    $('#loading-modal').modal('hide');
                },
                error: function() {
                    alert('加载产品偏好数据失败');
                    $('#loading-modal').modal('hide');
                }
            });
        }
        
        /**
         * 加载产品偏好表格
         */
        function loadProductPreferencesTable(data) {
            var tbody = $('#product-preferences-table tbody');
            tbody.empty();
            
            data.forEach(function(item, index) {
                var row = $('<tr>')
                    .append($('<td>').text(index + 1))
                    .append($('<td>').text(item.product_name))
                    .append($('<td>').text(item.category_name || '未分类'))
                    .append($('<td>').text('¥' + item.price.toFixed(2)))
                    .append($('<td>').text(item.purchase_count))
                    .append($('<td>').text(item.total_quantity))
                    .append($('<td>').text('¥' + item.total_amount.toFixed(2)))
                    .append($('<td>')
                        .append($('<button class="btn btn-sm btn-primary">详情</button>')
                            .on('click', function() {
                                // 可以添加详情查看功能
                                alert('产品ID: ' + item.product_id + '\n产品名称: ' + item.product_name);
                            })
                        )
                    );
                tbody.append(row);
            });
            
            // 初始化数据表格
            $('#product-preferences-table').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true
            });
        }
        
        /**
         * 加载分类偏好数据
         */
        function loadCategoryPreferencesData() {
            // 显示加载动画
            $('#loading-modal').modal('show');
            
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'category_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data;
                        
                        // 创建饼图
                        var pieChart = echarts.init(document.getElementById('category-pie-chart'));
                        var pieOption = {
                            tooltip: {
                                trigger: 'item',
                                formatter: '{a} <br/>{b}: {c} ({d}%)'
                            },
                            legend: {
                                orient: 'vertical',
                                left: 10,
                                data: chartData.map(function(item) {
                                    return item.category_name || '未分类';
                                })
                            },
                            series: [{
                                name: '分类分布',
                                type: 'pie',
                                radius: '60%',
                                data: chartData.map(function(item) {
                                    return {
                                        value: item.purchase_count,
                                        name: item.category_name || '未分类'
                                    };
                                }),
                                emphasis: {
                                    itemStyle: {
                                        shadowBlur: 10,
                                        shadowOffsetX: 0,
                                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                                    }
                                }
                            }]
                        };
                        
                        pieChart.setOption(pieOption);
                        
                        // 创建柱状图
                        var barChart = echarts.init(document.getElementById('category-sales-chart'));
                        var barOption = {
                            tooltip: {
                                trigger: 'axis',
                                axisPointer: {
                                    type: 'shadow'
                                }
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: chartData.map(function(item) {
                                    return item.category_name || '未分类';
                                }),
                                axisLabel: {
                                    interval: 0,
                                    rotate: 45
                                }
                            },
                            yAxis: {
                                type: 'value',
                                name: '销售额'
                            },
                            series: [{
                                data: chartData.map(function(item) {
                                    return parseFloat(item.total_amount);
                                }),
                                type: 'bar',
                                itemStyle: {
                                    color: '#e74c3c'
                                }
                            }]
                        };
                        
                        barChart.setOption(barOption);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            pieChart.resize();
                            barChart.resize();
                        });
                        
                        // 加载分类偏好表格
                        loadCategoryPreferencesTable(chartData);
                    }
                    
                    // 隐藏加载动画
                    $('#loading-modal').modal('hide');
                },
                error: function() {
                    alert('加载分类偏好数据失败');
                    $('#loading-modal').modal('hide');
                }
            });
        }
        
        /**
         * 加载分类偏好表格
         */
        function loadCategoryPreferencesTable(data) {
            var tbody = $('#category-preferences-table tbody');
            tbody.empty();
            
            data.forEach(function(item, index) {
                var row = $('<tr>')
                    .append($('<td>').text(index + 1))
                    .append($('<td>').text(item.category_name || '未分类'))
                    .append($('<td>').text(item.purchase_count))
                    .append($('<td>').text(item.total_quantity))
                    .append($('<td>').text('¥' + item.total_amount.toFixed(2)))
                    .append($('<td>').text('¥' + item.avg_price.toFixed(2)));
                tbody.append(row);
            });
            
            // 初始化数据表格
            $('#category-preferences-table').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true
            });
        }
        
        /**
         * 加载时间偏好数据
         */
        function loadTimePreferencesData() {
            // 显示加载动画
            $('#loading-modal').modal('show');
            
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'time_preferences',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var hourlyData = response.data.hourly;
                        var weekdayData = response.data.weekday;
                        
                        // 创建24小时分布图
                        var hourlyChart = echarts.init(document.getElementById('hourly-distribution-chart'));
                        
                        // 初始化24小时数组
                        var hours = [];
                        var hourlyOrderCounts = [];
                        
                        for (var i = 0; i < 24; i++) {
                            hours.push(i + '点');
                            hourlyOrderCounts.push(0);
                        }
                        
                        // 填充实际数据
                        hourlyData.forEach(function(item) {
                            hourlyOrderCounts[item.hour] = item.order_count;
                        });
                        
                        var hourlyOption = {
                            tooltip: {
                                trigger: 'axis'
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: hours
                            },
                            yAxis: {
                                type: 'value',
                                name: '订单数'
                            },
                            series: [{
                                data: hourlyOrderCounts,
                                type: 'bar',
                                itemStyle: {
                                    color: '#1abc9c'
                                }
                            }]
                        };
                        
                        hourlyChart.setOption(hourlyOption);
                        
                        // 创建星期分布图
                        var weekdayChart = echarts.init(document.getElementById('weekday-distribution-chart'));
                        
                        // 提取星期数据
                        var weekdays = [];
                        var weekdayOrderCounts = [];
                        
                        weekdayData.forEach(function(item) {
                            weekdays.push(item.weekday_name);
                            weekdayOrderCounts.push(item.order_count);
                        });
                        
                        var weekdayOption = {
                            tooltip: {
                                trigger: 'axis'
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: weekdays
                            },
                            yAxis: {
                                type: 'value',
                                name: '订单数'
                            },
                            series: [{
                                data: weekdayOrderCounts,
                                type: 'bar',
                                itemStyle: {
                                    color: '#f39c12'
                                }
                            }]
                        };
                        
                        weekdayChart.setOption(weekdayOption);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            hourlyChart.resize();
                            weekdayChart.resize();
                        });
                        
                        // 计算最佳时间
                        calculateBestTime(hourlyData, weekdayData);
                    }
                    
                    // 隐藏加载动画
                    $('#loading-modal').modal('hide');
                },
                error: function() {
                    alert('加载时间偏好数据失败');
                    $('#loading-modal').modal('hide');
                }
            });
        }
        
        /**
         * 计算最佳购买时间
         */
        function calculateBestTime(hourlyData, weekdayData) {
            // 找到订单最多的小时
            var maxHour = hourlyData.reduce(function(max, item) {
                return item.order_count > max.order_count ? item : max;
            });
            
            // 找到订单最多的星期
            var maxWeekday = weekdayData.reduce(function(max, item) {
                return item.order_count > max.order_count ? item : max;
            });
            
            // 更新最佳时间信息
            $('#best-time-period').text(maxHour.hour + '点 (' + maxHour.order_count + ' 订单)');
            $('#best-weekday').text(maxWeekday.weekday_name + ' (' + maxWeekday.order_count + ' 订单)');
        }
        
        /**
         * 加载频率数据
         */
        function loadFrequencyData() {
            // 显示加载动画
            $('#loading-modal').modal('show');
            
            $.ajax({
                url: '../api/analytics/user_purchase_analytics.php',
                type: 'GET',
                data: {
                    action: 'frequency_analysis',
                    start_date: $('#start-date').val(),
                    end_date: $('#end-date').val(),
                    user_id: $('#user-id').val()
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var chartData = response.data;
                        
                        // 提取数据
                        var purchaseCounts = [];
                        var userCounts = [];
                        var avgSpent = [];
                        
                        chartData.forEach(function(item) {
                            purchaseCounts.push(item.purchase_count + '次购买');
                            userCounts.push(item.user_count);
                            avgSpent.push(parseFloat(item.avg_spent_per_user));
                        });
                        
                        // 创建图表
                        var chart = echarts.init(document.getElementById('frequency-chart'));
                        var option = {
                            tooltip: {
                                trigger: 'axis'
                            },
                            legend: {
                                data: ['用户数量', '平均消费金额']
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'category',
                                data: purchaseCounts
                            },
                            yAxis: [
                                {
                                    type: 'value',
                                    name: '用户数量',
                                    position: 'left',
                                    axisLabel: {
                                        formatter: '{value}'
                                    }
                                },
                                {
                                    type: 'value',
                                    name: '平均消费金额',
                                    position: 'right',
                                    axisLabel: {
                                        formatter: '¥{value}'
                                    }
                                }
                            ],
                            series: [
                                {
                                    name: '用户数量',
                                    type: 'bar',
                                    data: userCounts,
                                    itemStyle: {
                                        color: '#7f8c8d'
                                    }
                                },
                                {
                                    name: '平均消费金额',
                                    type: 'line',
                                    yAxisIndex: 1,
                                    data: avgSpent,
                                    itemStyle: {
                                        color: '#e74c3c'
                                    }
                                }
                            ]
                        };
                        
                        chart.setOption(option);
                        
                        // 响应式调整
                        window.addEventListener('resize', function() {
                            chart.resize();
                        });
                        
                        // 加载频率表格
                        loadFrequencyTable(chartData);
                    }
                    
                    // 隐藏加载动画
                    $('#loading-modal').modal('hide');
                },
                error: function() {
                    alert('加载频率数据失败');
                    $('#loading-modal').modal('hide');
                }
            });
        }
        
        /**
         * 加载频率表格
         */
        function loadFrequencyTable(data) {
            var tbody = $('#frequency-table tbody');
            tbody.empty();
            
            data.forEach(function(item, index) {
                var row = $('<tr>')
                    .append($('<td>').text(index + 1))
                    .append($('<td>').text(item.purchase_count + '次'))
                    .append($('<td>').text(item.user_count))
                    .append($('<td>').text('¥' + item.avg_spent_per_user.toFixed(2)));
                tbody.append(row);
            });
            
            // 初始化数据表格
            $('#frequency-table').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true
            });
        }
        
        /**
         * 渲染产品推荐结果
         */
        function renderRecommendations(data) {
            var container = $('#recommendations-results');
            container.empty();
            
            // 添加标题
            container.append('<h4 class="mb-3">产品推荐结果</h4>');
            
            // 分类相关推荐
            if (data.category_based && data.category_based.length > 0) {
                var categorySection = $('<div class="mb-4">');
                categorySection.append('<h5>基于用户偏好分类的推荐</h5>');
                
                var categoryList = $('<div class="row">');
                data.category_based.forEach(function(product) {
                    var productCard = $('<div class="col-md-3 mb-3">');
                    productCard.append($('<div class="card">')
                        .append($('<div class="card-body">')
                            .append($('<h6 class="card-title">').text(product.name))
                            .append($('<p class="card-text">').text('¥' + product.price))
                        )
                    );
                    categoryList.append(productCard);
                });
                
                categorySection.append(categoryList);
                container.append(categorySection);
            }
            
            // 热门产品推荐
            if (data.popular_products && data.popular_products.length > 0) {
                var popularSection = $('<div class="mb-4">');
                popularSection.append('<h5>热门产品推荐</h5>');
                
                var popularList = $('<div class="row">');
                data.popular_products.forEach(function(product) {
                    var productCard = $('<div class="col-md-3 mb-3">');
                    productCard.append($('<div class="card">')
                        .append($('<div class="card-body">')
                            .append($('<h6 class="card-title">').text(product.name))
                            .append($('<p class="card-text">').text('¥' + product.price))
                            .append($('<small class="text-muted">').text('销量: ' + product.sales_count))
                        )
                    );
                    popularList.append(productCard);
                });
                
                popularSection.append(popularList);
                container.append(popularSection);
            }
            
            // 价格区间相关推荐
            if (data.price_based && data.price_based.length > 0) {
                var priceSection = $('<div class="mb-4">');
                priceSection.append('<h5>基于价格偏好的推荐</h5>');
                
                var priceList = $('<div class="row">');
                data.price_based.forEach(function(product) {
                    var productCard = $('<div class="col-md-3 mb-3">');
                    productCard.append($('<div class="card">')
                        .append($('<div class="card-body">')
                            .append($('<h6 class="card-title">').text(product.name))
                            .append($('<p class="card-text">').text('¥' + product.price))
                        )
                    );
                    priceList.append(productCard);
                });
                
                priceSection.append(priceList);
                container.append(priceSection);
            }
            
            // 如果没有推荐结果
            if (!data.category_based && !data.popular_products && !data.price_based) {
                container.append('<div class="alert alert-warning">暂无推荐结果</div>');
            }
        }
    </script>
</body>
</html>