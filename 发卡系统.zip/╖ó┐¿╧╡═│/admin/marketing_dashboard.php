<?php
/**
 * 营销数据分析仪表盘
 * 整合数据分析平台、营销工具和用户留存系统的数据，为运营决策提供支持
 */

// 引入必要的文件
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/business/IntegratedMarketingSystem.php';

// 检查权限
check_auth(['admin', 'marketing', 'manager']);

// 初始化整合营销系统实例
try {
    $integratedSystem = new IntegratedMarketingSystem();
} catch (Exception $e) {
    $errorMessage = '初始化系统失败: ' . $e->getMessage();
}

// 获取请求参数
$timeRange = isset($_GET['time_range']) ? $_GET['time_range'] : 'month'; // day, week, month, quarter, year
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$moduleFilter = isset($_GET['module']) ? $_GET['module'] : 'all'; // all, analytics, marketing, membership
$viewFilter = isset($_GET['view']) ? $_GET['view'] : 'overview'; // overview, detailed
$agentId = isset($_GET['agent_id']) ? $_GET['agent_id'] : null;
$userId = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// 根据时间范围设置默认日期
if (empty($_GET['start_date']) && empty($_GET['end_date'])) {
    switch ($timeRange) {
        case 'day':
            $startDate = date('Y-m-d');
            $endDate = date('Y-m-d');
            break;
        case 'week':
            $startDate = date('Y-m-d', strtotime('-7 days'));
            $endDate = date('Y-m-d');
            break;
        case 'month':
            $startDate = date('Y-m-d', strtotime('-30 days'));
            $endDate = date('Y-m-d');
            break;
        case 'quarter':
            $startDate = date('Y-m-d', strtotime('-90 days'));
            $endDate = date('Y-m-d');
            break;
        case 'year':
            $startDate = date('Y-m-d', strtotime('-365 days'));
            $endDate = date('Y-m-d');
            break;
    }
}

// 获取仪表盘数据
try {
    $filters = [
        'start_date' => $startDate,
        'end_date' => $endDate,
        'user_id' => $userId,
        'agent_id' => $agentId
    ];
    
    $dashboardData = $integratedSystem->getMarketingDashboardData($filters);
} catch (Exception $e) {
    $errorMessage = '获取仪表盘数据失败: ' . $e->getMessage();
    $dashboardData = null;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>营销数据分析仪表盘 - 发卡系统</title>
    <!-- 引入必要的CSS和JS文件 -->
    <link rel="stylesheet" href="../../assets/css/admin.css">
    <link rel="stylesheet" href="../../assets/css/dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/moment"></script>
    <style>
        /* 营销仪表盘特定样式 */
        .marketing-dashboard {
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
        
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .dashboard-header h1 {
            margin: 0;
            font-size: 2rem;
            font-weight: 600;
        }
        
        .filter-controls {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-control {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .filter-control label {
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .filter-control select,
        .filter-control input[type="date"],
        .filter-control button {
            padding: 8px 12px;
            border-radius: 5px;
            border: none;
            font-size: 1rem;
        }
        
        .filter-control button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .filter-control button:hover {
            background-color: #45a049;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .summary-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .summary-card h3 {
            margin: 0 0 10px 0;
            font-size: 1.1rem;
            color: #666;
            font-weight: 500;
        }
        
        .summary-card .number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0 0 10px 0;
            color: #333;
        }
        
        .summary-card .change {
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .summary-card .positive {
            color: #4CAF50;
        }
        
        .summary-card .negative {
            color: #f44336;
        }
        
        .chart-section {
            margin-bottom: 30px;
        }
        
        .chart-section h2 {
            margin-bottom: 20px;
            font-size: 1.5rem;
            color: #333;
        }
        
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 30px;
        }
        
        .chart-container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .chart-container h3 {
            margin: 0 0 20px 0;
            font-size: 1.2rem;
            color: #333;
            font-weight: 600;
        }
        
        .chart {
            width: 100%;
            height: 300px;
        }
        
        .data-section {
            margin-bottom: 30px;
        }
        
        .data-section h2 {
            margin-bottom: 20px;
            font-size: 1.5rem;
            color: #333;
        }
        
        .data-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 30px;
        }
        
        .data-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .data-table h3 {
            margin: 0;
            padding: 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            font-size: 1.2rem;
            color: #333;
            font-weight: 600;
        }
        
        .data-table table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th,
        .data-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .data-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }
        
        .data-table tbody tr:hover {
            background-color: #f8f9fa;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #f5c6cb;
            margin-bottom: 20px;
        }
        
        .module-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .module-tab {
            padding: 10px 20px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .module-tab.active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        
        .module-content {
            display: none;
        }
        
        .module-content.active {
            display: block;
        }
    </style>
</head>
<body class="admin-body">
    <div class="admin-layout">
        <div class="sidebar">
            <h3>发卡系统管理</h3>
            <ul class="nav-menu">
                <li><a href="index.php">仪表板</a></li>
                <li><a href="users.php">用户管理</a></li>
                <li><a href="cards.php">卡片管理</a></li>
                <li><a href="orders.php">订单管理</a></li>
                <li><a class="active" href="marketing_dashboard.php">营销数据分析</a></li>
                <li><a href="promotions.php">促销活动管理</a></li>
                <li><a href="members.php">会员管理</a></li>
                <li><a href="agents.php">代理管理</a></li>
                <li><a href="monitoring.php">系统监控</a></li>
                <li><a href="settings.php">系统设置</a></li>
                <li><a href="../logout.php">退出登录</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="marketing-dashboard">
                <div class="dashboard-header">
                    <h1>营销数据分析仪表盘</h1>
                    <div class="filter-controls">
                        <div class="filter-control">
                            <label for="timeRange">时间范围</label>
                            <select id="timeRange" name="time_range">
                                <option value="day" <?php echo $timeRange == 'day' ? 'selected' : ''; ?>>今日</option>
                                <option value="week" <?php echo $timeRange == 'week' ? 'selected' : ''; ?>>近7天</option>
                                <option value="month" <?php echo $timeRange == 'month' ? 'selected' : ''; ?>>近30天</option>
                                <option value="quarter" <?php echo $timeRange == 'quarter' ? 'selected' : ''; ?>>近90天</option>
                                <option value="year" <?php echo $timeRange == 'year' ? 'selected' : ''; ?>>近一年</option>
                            </select>
                        </div>
                        <div class="filter-control">
                            <label for="startDate">开始日期</label>
                            <input type="date" id="startDate" name="start_date" value="<?php echo $startDate; ?>">
                        </div>
                        <div class="filter-control">
                            <label for="endDate">结束日期</label>
                            <input type="date" id="endDate" name="end_date" value="<?php echo $endDate; ?>">
                        </div>
                        <div class="filter-control">
                            <button id="applyFilter" type="button">应用筛选</button>
                        </div>
                    </div>
                </div>
                
                <!-- 错误消息显示 -->
                <?php if (isset($errorMessage)): ?>
                <div class="error-message">
                    <strong>错误：</strong><?php echo $errorMessage; ?>
                </div>
                <?php endif; ?>
                
                <!-- 模块切换选项卡 -->
                <div class="module-tabs">
                    <div class="module-tab <?php echo $moduleFilter == 'all' ? 'active' : ''; ?>" data-module="all">全部模块</div>
                    <div class="module-tab <?php echo $moduleFilter == 'analytics' ? 'active' : ''; ?>" data-module="analytics">数据分析</div>
                    <div class="module-tab <?php echo $moduleFilter == 'marketing' ? 'active' : ''; ?>" data-module="marketing">营销工具</div>
                    <div class="module-tab <?php echo $moduleFilter == 'membership' ? 'active' : ''; ?>" data-module="membership">会员系统</div>
                </div>
                
                <!-- 仪表盘内容 -->
                <?php if (isset($dashboardData) && $dashboardData['success']): ?>
                
                <!-- 总体概览模块 -->
                <div class="module-content <?php echo $moduleFilter == 'all' ? 'active' : ''; ?>" data-module="all">
                    <!-- 摘要统计卡片 -->
                    <div class="summary-cards">
                        <div class="summary-card">
                            <h3>总订单数</h3>
                            <div class="number"><?php echo number_format($dashboardData['data']['summary']['total_orders'] ?? 0); ?></div>
                            <div class="change positive">
                                <span class="icon">↑</span> 12% 较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>总销售额</h3>
                            <div class="number">¥<?php echo number_format($dashboardData['data']['summary']['total_amount'] ?? 0, 2); ?></div>
                            <div class="change positive">
                                <span class="icon">↑</span> 8.5% 较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>平均订单金额</h3>
                            <div class="number">¥<?php echo number_format($dashboardData['data']['summary']['avg_order_value'] ?? 0, 2); ?></div>
                            <div class="change negative">
                                <span class="icon">↓</span> 3% 较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>活跃用户</h3>
                            <div class="number"><?php echo number_format($dashboardData['data']['summary']['total_users'] ?? 0); ?></div>
                            <div class="change positive">
                                <span class="icon">↑</span> 15% 较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>转化率</h3>
                            <div class="number"><?php echo number_format(($dashboardData['data']['summary']['conversion_rate'] ?? 0) * 100, 2); ?>%</div>
                            <div class="change positive">
                                <span class="icon">↑</span> 0.5% 较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>活跃促销</h3>
                            <div class="number"><?php echo number_format($dashboardData['data']['summary']['active_promotions'] ?? 0); ?></div>
                            <div class="change positive">
                                <span class="icon">↑</span> 2 个较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>会员增长</h3>
                            <div class="number"><?php echo number_format($dashboardData['data']['summary']['total_users'] ?? 0); ?></div>
                            <div class="change positive">
                                <span class="icon">↑</span> 10% 较上期
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <h3>代理数量</h3>
                            <div class="number"><?php echo number_format($dashboardData['data']['summary']['total_agents'] ?? 0); ?></div>
                            <div class="change positive">
                                <span class="icon">↑</span> 5% 较上期
                            </div>
                        </div>
                    </div>
                    
                    <!-- 图表区域 -->
                    <div class="chart-section">
                        <h2>数据趋势分析</h2>
                        <div class="charts-grid">
                            <div class="chart-container">
                                <h3>销售趋势</h3>
                                <canvas class="chart" id="salesTrendChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>用户增长趋势</h3>
                                <canvas class="chart" id="userGrowthChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>代理推广效果</h3>
                                <canvas class="chart" id="agentPerformanceChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>营销活动ROI</h3>
                                <canvas class="chart" id="marketingROIChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>产品类别销售分布</h3>
                                <canvas class="chart" id="categoryDistributionChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>会员等级分布</h3>
                                <canvas class="chart" id="memberLevelChart"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 详细数据表格 -->
                    <div class="data-section">
                        <h2>详细数据</h2>
                        <div class="data-grid">
                            <div class="data-table">
                                <h3>热门产品</h3>
                                <table id="popularProductsTable">
                                    <thead>
                                        <tr>
                                            <th>产品ID</th>
                                            <th>产品名称</th>
                                            <th>销量</th>
                                            <th>销售额</th>
                                            <th>占比</th>
                                        </tr>
                                    </thead>
                                    <tbody id="popularProductsTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="data-table">
                                <h3>高价值客户</h3>
                                <table id="highValueCustomersTable">
                                    <thead>
                                        <tr>
                                            <th>用户ID</th>
                                            <th>用户名</th>
                                            <th>订单数</th>
                                            <th>总消费</th>
                                            <th>会员等级</th>
                                            <th>最后购买</th>
                                        </tr>
                                    </thead>
                                    <tbody id="highValueCustomersTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="data-table">
                                <h3>营销活动效果</h3>
                                <table id="promotionEffectTable">
                                    <thead>
                                        <tr>
                                            <th>活动ID</th>
                                            <th>活动名称</th>
                                            <th>类型</th>
                                            <th>参与人数</th>
                                            <th>销售额</th>
                                            <th>ROI</th>
                                        </tr>
                                    </thead>
                                    <tbody id="promotionEffectTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="data-table">
                                <h3>代理表现</h3>
                                <table id="agentPerformanceTable">
                                    <thead>
                                        <tr>
                                            <th>代理ID</th>
                                            <th>代理名称</th>
                                            <th>推荐人数</th>
                                            <th>转化率</th>
                                            <th>销售额</th>
                                        </tr>
                                    </thead>
                                    <tbody id="agentPerformanceTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 数据分析模块 -->
                <div class="module-content <?php echo $moduleFilter == 'analytics' ? 'active' : ''; ?>" data-module="analytics">
                    <!-- 数据分析相关内容 -->
                    <div class="chart-section">
                        <h2>数据分析模块</h2>
                        <div class="charts-grid">
                            <div class="chart-container">
                                <h3>用户购买偏好</h3>
                                <canvas class="chart" id="userPreferencesChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>用户购买时间分布</h3>
                                <canvas class="chart" id="purchaseTimeChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>价格区间销售分布</h3>
                                <canvas class="chart" id="priceRangeChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>代理推广链接转化率</h3>
                                <canvas class="chart" id="conversionRateChart"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="data-section">
                        <h2>数据分析详细数据</h2>
                        <div class="data-grid">
                            <div class="data-table">
                                <h3>产品分析</h3>
                                <table id="productAnalysisTable">
                                    <thead>
                                        <tr>
                                            <th>产品ID</th>
                                            <th>产品名称</th>
                                            <th>类别</th>
                                            <th>销量</th>
                                            <th>销售额</th>
                                            <th>同比增长</th>
                                        </tr>
                                    </thead>
                                    <tbody id="productAnalysisTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="data-table">
                                <h3>代理分析</h3>
                                <table id="agentAnalysisTable">
                                    <thead>
                                        <tr>
                                            <th>代理ID</th>
                                            <th>代理名称</th>
                                            <th>访问量</th>
                                            <th>转化数</th>
                                            <th>转化率</th>
                                            <th>销售额</th>
                                        </tr>
                                    </thead>
                                    <tbody id="agentAnalysisTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 营销工具模块 -->
                <div class="module-content <?php echo $moduleFilter == 'marketing' ? 'active' : ''; ?>" data-module="marketing">
                    <!-- 营销工具相关内容 -->
                    <div class="chart-section">
                        <h2>营销工具效果分析</h2>
                        <div class="charts-grid">
                            <div class="chart-container">
                                <h3>促销活动销售额</h3>
                                <canvas class="chart" id="promotionSalesChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>限时秒杀效果</h3>
                                <canvas class="chart" id="flashSaleChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>满减活动参与度</h3>
                                <canvas class="chart" id="discountParticipationChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>营销活动类型效果对比</h3>
                                <canvas class="chart" id="promotionTypeChart"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="data-section">
                        <h2>营销工具详细数据</h2>
                        <div class="data-grid">
                            <div class="data-table">
                                <h3>促销活动</h3>
                                <table id="promotionTable">
                                    <thead>
                                        <tr>
                                            <th>活动ID</th>
                                            <th>活动名称</th>
                                            <th>类型</th>
                                            <th>开始时间</th>
                                            <th>结束时间</th>
                                            <th>参与人数</th>
                                            <th>销售额</th>
                                        </tr>
                                    </thead>
                                    <tbody id="promotionTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="data-table">
                                <h3>限时秒杀</h3>
                                <table id="flashSaleTable">
                                    <thead>
                                        <tr>
                                            <th>活动ID</th>
                                            <th>活动名称</th>
                                            <th>折扣</th>
                                            <th>开始时间</th>
                                            <th>结束时间</th>
                                            <th>售出数量</th>
                                            <th>销售额</th>
                                        </tr>
                                    </thead>
                                    <tbody id="flashSaleTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 会员系统模块 -->
                <div class="module-content <?php echo $moduleFilter == 'membership' ? 'active' : ''; ?>" data-module="membership">
                    <!-- 会员系统相关内容 -->
                    <div class="chart-section">
                        <h2>会员系统数据分析</h2>
                        <div class="charts-grid">
                            <div class="chart-container">
                                <h3>会员增长趋势</h3>
                                <canvas class="chart" id="memberGrowthTrendChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>会员等级分布</h3>
                                <canvas class="chart" id="memberLevelDistributionChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>积分使用情况</h3>
                                <canvas class="chart" id="pointsUsageChart"></canvas>
                            </div>
                            
                            <div class="chart-container">
                                <h3>会员消费能力</h3>
                                <canvas class="chart" id="memberSpendingChart"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="data-section">
                        <h2>会员系统详细数据</h2>
                        <div class="data-grid">
                            <div class="data-table">
                                <h3>会员等级数据</h3>
                                <table id="memberLevelDataTable">
                                    <thead>
                                        <tr>
                                            <th>等级ID</th>
                                            <th>等级名称</th>
                                            <th>会员数量</th>
                                            <th>平均消费</th>
                                            <th>平均积分</th>
                                            <th>折扣率</th>
                                        </tr>
                                    </thead>
                                    <tbody id="memberLevelDataTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="data-table">
                                <h3>积分兑换记录</h3>
                                <table id="pointsExchangeTable">
                                    <thead>
                                        <tr>
                                            <th>兑换ID</th>
                                            <th>用户ID</th>
                                            <th>兑换项目</th>
                                            <th>积分消耗</th>
                                            <th>兑换时间</th>
                                            <th>状态</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pointsExchangeTableBody">
                                        <!-- 由JavaScript动态填充 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php else: ?>
                
                <!-- 数据加载失败提示 -->
                <div class="error-message">
                    <strong>数据加载失败：</strong>无法获取仪表盘数据，请稍后再试
                </div>
                
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// 仪表盘数据
const dashboardData = <?php echo isset($dashboardData) ? json_encode($dashboardData) : '{}'; ?>;

// 初始化模块切换
const moduleTabs = document.querySelectorAll('.module-tab');
moduleTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        // 移除所有激活状态
        document.querySelectorAll('.module-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.module-content').forEach(c => c.classList.remove('active'));
        
        // 激活当前选中的模块
        const module = tab.getAttribute('data-module');
        tab.classList.add('active');
        document.querySelector(`.module-content[data-module="${module}"]`).classList.add('active');
        
        // 重新初始化图表
        initCharts();
    });
});

// 初始化筛选表单
const filterForm = document.getElementById('applyFilter');
filterForm.addEventListener('click', () => {
    const timeRange = document.getElementById('timeRange').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const module = document.querySelector('.module-tab.active').getAttribute('data-module');
    
    // 构建URL查询参数
    const params = new URLSearchParams();
    params.append('time_range', timeRange);
    params.append('start_date', startDate);
    params.append('end_date', endDate);
    params.append('module', module);
    
    // 刷新页面
    window.location.href = `marketing_dashboard.php?${params.toString()}`;
});

// 初始化图表
function initCharts() {
    // 获取当前激活的模块
    const activeModule = document.querySelector('.module-tab.active').getAttribute('data-module');
    
    // 根据激活的模块初始化相应的图表
    switch(activeModule) {
        case 'all':
            initAllCharts();
            break;
        case 'analytics':
            initAnalyticsCharts();
            break;
        case 'marketing':
            initMarketingCharts();
            break;
        case 'membership':
            initMembershipCharts();
            break;
    }
}

// 初始化所有模块的图表
function initAllCharts() {
    // 销售趋势图
    const salesTrendCtx = document.getElementById('salesTrendChart').getContext('2d');
    new Chart(salesTrendCtx, {
        type: 'line',
        data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            datasets: [{
                label: '销售额',
                data: [12500, 19200, 15800, 21500, 18700, 25000, 22300, 28500, 31000, 35000, 32500, 38000],
                borderColor: '#4CAF50',
                backgroundColor: 'rgba(76, 175, 80, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '销售额 (¥)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '月份'
                    }
                }
            }
        }
    });
    
    // 用户增长趋势图
    const userGrowthCtx = document.getElementById('userGrowthChart').getContext('2d');
    new Chart(userGrowthCtx, {
        type: 'line',
        data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            datasets: [{
                label: '新增用户',
                data: [120, 190, 150, 210, 180, 250, 220, 280, 310, 350, 320, 380],
                borderColor: '#2196F3',
                backgroundColor: 'rgba(33, 150, 243, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '用户数'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '月份'
                    }
                }
            }
        }
    });
    
    // 代理推广效果图
    const agentPerformanceCtx = document.getElementById('agentPerformanceChart').getContext('2d');
    new Chart(agentPerformanceCtx, {
        type: 'bar',
        data: {
            labels: ['代理A', '代理B', '代理C', '代理D', '代理E'],
            datasets: [{
                label: '销售额',
                data: [8500, 6200, 4500, 9800, 5200],
                backgroundColor: '#FF9800',
            }, {
                label: '转化率(%)',
                data: [12.5, 8.3, 10.1, 15.2, 7.8],
                backgroundColor: '#9C27B0',
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '销售额 (¥)'
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: '转化率 (%)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '代理'
                    }
                }
            }
        }
    });
    
    // 营销活动ROI图
    const marketingROICtx = document.getElementById('marketingROIChart').getContext('2d');
    new Chart(marketingROICtx, {
        type: 'bar',
        data: {
            labels: ['限时秒杀', '满减优惠', '会员日', '代理推广', '节日促销'],
            datasets: [{
                label: 'ROI',
                data: [4.5, 3.8, 5.2, 3.5, 4.2],
                backgroundColor: '#4CAF50',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'ROI'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '活动类型'
                    }
                }
            }
        }
    });
    
    // 产品类别销售分布图
    const categoryDistributionCtx = document.getElementById('categoryDistributionChart').getContext('2d');
    new Chart(categoryDistributionCtx, {
        type: 'pie',
        data: {
            labels: ['游戏卡', '购物卡', '礼品卡', '充值卡', '其他'],
            datasets: [{
                data: [35, 25, 20, 15, 5],
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF'
                ],
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
    
    // 会员等级分布图
    const memberLevelCtx = document.getElementById('memberLevelChart').getContext('2d');
    new Chart(memberLevelCtx, {
        type: 'doughnut',
        data: {
            labels: ['普通会员', '银卡会员', '金卡会员', '钻石会员'],
            datasets: [{
                data: [60, 25, 10, 5],
                backgroundColor: [
                    '#E0E0E0',
                    '#C0C0C0',
                    '#FFD700',
                    '#B9F2FF'
                ],
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
}

// 初始化数据分析模块的图表
function initAnalyticsCharts() {
    // 用户购买偏好图
    const userPreferencesCtx = document.getElementById('userPreferencesChart').getContext('2d');
    new Chart(userPreferencesCtx, {
        type: 'bar',
        data: {
            labels: ['游戏卡', '购物卡', '礼品卡', '充值卡', '其他'],
            datasets: [{
                label: '购买频率',
                data: [350, 280, 180, 220, 70],
                backgroundColor: '#3F51B5',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '购买次数'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '产品类别'
                    }
                }
            }
        }
    });
    
    // 用户购买时间分布图
    const purchaseTimeCtx = document.getElementById('purchaseTimeChart').getContext('2d');
    new Chart(purchaseTimeCtx, {
        type: 'line',
        data: {
            labels: ['00:00', '03:00', '06:00', '09:00', '12:00', '15:00', '18:00', '21:00'],
            datasets: [{
                label: '购买量',
                data: [50, 30, 20, 80, 180, 150, 220, 120],
                borderColor: '#F44336',
                backgroundColor: 'rgba(244, 67, 54, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '购买量'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '时间'
                    }
                }
            }
        }
    });
    
    // 价格区间销售分布图
    const priceRangeCtx = document.getElementById('priceRangeChart').getContext('2d');
    new Chart(priceRangeCtx, {
        type: 'bar',
        data: {
            labels: ['0-50', '50-100', '100-200', '200-500', '500+'],
            datasets: [{
                label: '销售额',
                data: [3200, 5800, 9200, 12500, 8500],
                backgroundColor: '#4CAF50',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '销售额 (¥)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '价格区间 (¥)'
                    }
                }
            }
        }
    });
    
    // 代理推广链接转化率图
    const conversionRateCtx = document.getElementById('conversionRateChart').getContext('2d');
    new Chart(conversionRateCtx, {
        type: 'line',
        data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [{
                label: '代理A',
                data: [8.5, 9.2, 10.1, 11.5, 10.8, 12.3],
                borderColor: '#FF9800',
                tension: 0.3
            }, {
                label: '代理B',
                data: [7.2, 8.1, 7.8, 9.2, 9.8, 10.5],
                borderColor: '#2196F3',
                tension: 0.3
            }, {
                label: '代理C',
                data: [6.8, 7.5, 8.5, 9.2, 10.1, 11.2],
                borderColor: '#9C27B0',
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '转化率 (%)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '月份'
                    }
                }
            }
        }
    });
}

// 初始化营销工具模块的图表
function initMarketingCharts() {
    // 促销活动销售额图
    const promotionSalesCtx = document.getElementById('promotionSalesChart').getContext('2d');
    new Chart(promotionSalesCtx, {
        type: 'line',
        data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [{
                label: '活动销售额',
                data: [12000, 18500, 15200, 22800, 25600, 28500],
                borderColor: '#E91E63',
                backgroundColor: 'rgba(233, 30, 99, 0.1)',
                tension: 0.3,
                fill: true
            }, {
                label: '普通销售额',
                data: [32000, 28500, 35200, 30800, 32600, 35500],
                borderColor: '#795548',
                backgroundColor: 'rgba(121, 85, 72, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '销售额 (¥)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '月份'
                    }
                }
            }
        }
    });
    
    // 限时秒杀效果图
    const flashSaleCtx = document.getElementById('flashSaleChart').getContext('2d');
    new Chart(flashSaleCtx, {
        type: 'bar',
        data: {
            labels: ['活动1', '活动2', '活动3', '活动4', '活动5'],
            datasets: [{
                label: '销售额',
                data: [12500, 8200, 15600, 9800, 14300],
                backgroundColor: '#FF5722',
            }, {
                label: '参与人数',
                data: [128, 85, 156, 102, 138],
                backgroundColor: '#00BCD4',
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '销售额 (¥)'
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: '参与人数'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '活动'
                    }
                }
            }
        }
    });
    
    // 满减活动参与度图
    const discountParticipationCtx = document.getElementById('discountParticipationChart').getContext('2d');
    new Chart(discountParticipationCtx, {
        type: 'pie',
        data: {
            labels: ['使用满减', '未使用满减'],
            datasets: [{
                data: [68, 32],
                backgroundColor: [
                    '#4CAF50',
                    '#F44336'
                ],
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
    
    // 营销活动类型效果对比图
    const promotionTypeCtx = document.getElementById('promotionTypeChart').getContext('2d');
    new Chart(promotionTypeCtx, {
        type: 'bar',
        data: {
            labels: ['限时秒杀', '满减优惠', '会员日', '代理推广', '节日促销'],
            datasets: [{
                label: '参与率(%)',
                data: [28, 42, 35, 18, 32],
                backgroundColor: '#9C27B0',
            }, {
                label: '提升销售额(%)',
                data: [150, 80, 120, 50, 100],
                backgroundColor: '#FFC107',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '百分比 (%)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '活动类型'
                    }
                }
            }
        }
    });
}

// 初始化会员系统模块的图表
function initMembershipCharts() {
    // 会员增长趋势图
    const memberGrowthTrendCtx = document.getElementById('memberGrowthTrendChart').getContext('2d');
    new Chart(memberGrowthTrendCtx, {
        type: 'line',
        data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [{
                label: '会员总数',
                data: [1250, 1480, 1720, 2050, 2380, 2850],
                borderColor: '#607D8B',
                backgroundColor: 'rgba(96, 125, 139, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '会员数量'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '月份'
                    }
                }
            }
        }
    });
    
    // 会员等级分布图
    const memberLevelDistributionCtx = document.getElementById('memberLevelDistributionChart').getContext('2d');
    new Chart(memberLevelDistributionCtx, {
        type: 'pie',
        data: {
            labels: ['普通会员', '银卡会员', '金卡会员', '钻石会员'],
            datasets: [{
                data: [1710, 712, 342, 142],
                backgroundColor: [
                    '#E0E0E0',
                    '#C0C0C0',
                    '#FFD700',
                    '#B9F2FF'
                ],
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
    
    // 积分使用情况图
    const pointsUsageCtx = document.getElementById('pointsUsageChart').getContext('2d');
    new Chart(pointsUsageCtx, {
        type: 'bar',
        data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [{
                label: '获取积分',
                data: [25000, 28500, 32000, 35000, 38000, 42000],
                backgroundColor: '#4CAF50',
            }, {
                label: '使用积分',
                data: [8500, 12200, 15800, 18500, 22000, 25600],
                backgroundColor: '#F44336',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '积分数量'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '月份'
                    }
                }
            }
        }
    });
    
    // 会员消费能力图
    const memberSpendingCtx = document.getElementById('memberSpendingChart').getContext('2d');
    new Chart(memberSpendingCtx, {
        type: 'bar',
        data: {
            labels: ['普通会员', '银卡会员', '金卡会员', '钻石会员'],
            datasets: [{
                label: '平均消费',
                data: [158, 256, 425, 850],
                backgroundColor: '#03A9F4',
            }, {
                label: '平均订单数',
                data: [2.3, 4.2, 6.8, 10.5],
                backgroundColor: '#FF9800',
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '平均消费 (¥)'
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: '平均订单数'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '会员等级'
                    }
                }
            }
        }
    });
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', () => {
    // 初始化图表
    initCharts();
    
    // 填充示例数据表格
    fillSampleTables();
});

// 填充示例数据表格
function fillSampleTables() {
    // 热门产品表格示例数据
    const popularProductsTableBody = document.getElementById('popularProductsTableBody');
    if (popularProductsTableBody) {
        const products = [
            {id: 'P001', name: '游戏充值卡-100元', sales: 1250, revenue: 125000, percentage: '18.5%'},
            {id: 'P002', name: '电商购物卡-200元', sales: 820, revenue: 164000, percentage: '15.2%'},
            {id: 'P003', name: '电子礼品卡-500元', sales: 580, revenue: 290000, percentage: '12.8%'},
            {id: 'P004', name: '视频会员年卡', sales: 1050, revenue: 252000, percentage: '10.5%'},
            {id: 'P005', name: '游戏充值卡-50元', sales: 1520, revenue: 76000, percentage: '8.7%'}
        ];
        
        products.forEach(product => {
            const row = popularProductsTableBody.insertRow();
            row.innerHTML = `
                <td>${product.id}</td>
                <td>${product.name}</td>
                <td>${product.sales}</td>
                <td>¥${product.revenue.toLocaleString()}</td>
                <td>${product.percentage}</td>
            `;
        });
    }
    
    // 高价值客户表格示例数据
    const highValueCustomersTableBody = document.getElementById('highValueCustomersTableBody');
    if (highValueCustomersTableBody) {
        const customers = [
            {id: 'U001', name: 'user_123', orders: 45, spending: 32500, level: '钻石会员', lastPurchase: '2023-06-28'},
            {id: 'U002', name: 'vip_user88', orders: 38, spending: 28800, level: '金卡会员', lastPurchase: '2023-06-27'},
            {id: 'U003', name: 'game_master', orders: 52, spending: 25200, level: '金卡会员', lastPurchase: '2023-06-29'},
            {id: 'U004', name: 'shopaholic', orders: 32, spending: 18500, level: '银卡会员', lastPurchase: '2023-06-26'},
            {id: 'U005', name: 'gift_expert', orders: 28, spending: 16800, level: '银卡会员', lastPurchase: '2023-06-25'}
        ];
        
        customers.forEach(customer => {
            const row = highValueCustomersTableBody.insertRow();
            row.innerHTML = `
                <td>${customer.id}</td>
                <td>${customer.name}</td>
                <td>${customer.orders}</td>
                <td>¥${customer.spending.toLocaleString()}</td>
                <td>${customer.level}</td>
                <td>${customer.lastPurchase}</td>
            `;
        });
    }
    
    // 其他表格也可以按照类似的方式填充
}
</script>
</body>
</html>