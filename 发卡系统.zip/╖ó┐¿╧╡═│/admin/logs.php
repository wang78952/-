<?php
/**
 * 日志管理页面
 */

require_once '../includes/Database.php';
require_once '../includes/AuthManager.php';
require_once '../includes/SecurityUtils.php';

// 检查管理员权限
$authManager = new AuthManager();
$authManager->requireAdmin();

// 获取数据库连接
$db = Database::getInstance();

// 获取系统日志
function getSystemLogs($db, $page = 1, $limit = 50, $filters = []) {
    $offset = ($page - 1) * $limit;
    $where = [];
    $params = [];
    
    // 构建查询条件
    if (!empty($filters['level'])) {
        $where[] = "level = ?";
        $params[] = $filters['level'];
    }
    
    if (!empty($filters['date_from'])) {
        $where[] = "created_at >= ?";
        $params[] = $filters['date_from'] . ' 00:00:00';
    }
    
    if (!empty($filters['date_to'])) {
        $where[] = "created_at <= ?";
        $params[] = $filters['date_to'] . ' 23:59:59';
    }
    
    if (!empty($filters['search'])) {
        $where[] = "(message LIKE ? OR context LIKE ?)";
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }
    
    $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
    
    // 获取总数
    $countQuery = "SELECT COUNT(*) as total FROM system_logs $whereClause";
    $total = $db->query($countQuery, $params)->fetch()['total'];
    
    // 获取数据
    $query = "
        SELECT 
            id,
            level,
            message,
            context,
            created_at
        FROM system_logs 
        $whereClause
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $logs = $db->query($query, $params)->fetchAll();
    
    return [
        'logs' => $logs,
        'total' => $total,
        'pages' => ceil($total / $limit),
        'current_page' => $page
    ];
}

// 获取错误日志
function getErrorLogs($db, $page = 1, $limit = 50, $filters = []) {
    $offset = ($page - 1) * $limit;
    $where = [];
    $params = [];
    
    // 构建查询条件
    if (!empty($filters['error_type'])) {
        $where[] = "error_type = ?";
        $params[] = $filters['error_type'];
    }
    
    if (!empty($filters['date_from'])) {
        $where[] = "created_at >= ?";
        $params[] = $filters['date_from'] . ' 00:00:00';
    }
    
    if (!empty($filters['date_to'])) {
        $where[] = "created_at <= ?";
        $params[] = $filters['date_to'] . ' 23:59:59';
    }
    
    if (!empty($filters['search'])) {
        $where[] = "(message LIKE ? OR file LIKE ? OR stack_trace LIKE ?)";
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }
    
    $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
    
    // 获取总数
    $countQuery = "SELECT COUNT(*) as total FROM error_logs $whereClause";
    $total = $db->query($countQuery, $params)->fetch()['total'];
    
    // 获取数据
    $query = "
        SELECT 
            id,
            error_type,
            message,
            file,
            line,
            stack_trace,
            created_at
        FROM error_logs 
        $whereClause
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $logs = $db->query($query, $params)->fetchAll();
    
    return [
        'logs' => $logs,
        'total' => $total,
        'pages' => ceil($total / $limit),
        'current_page' => $page
    ];
}

// 获取操作日志
function getOperationLogs($db, $page = 1, $limit = 50, $filters = []) {
    $offset = ($page - 1) * $limit;
    $where = [];
    $params = [];
    
    // 构建查询条件
    if (!empty($filters['user_id'])) {
        $where[] = "ol.user_id = ?";
        $params[] = $filters['user_id'];
    }
    
    if (!empty($filters['action'])) {
        $where[] = "ol.action = ?";
        $params[] = $filters['action'];
    }
    
    if (!empty($filters['resource_type'])) {
        $where[] = "ol.resource_type = ?";
        $params[] = $filters['resource_type'];
    }
    
    if (!empty($filters['date_from'])) {
        $where[] = "ol.created_at >= ?";
        $params[] = $filters['date_from'] . ' 00:00:00';
    }
    
    if (!empty($filters['date_to'])) {
        $where[] = "ol.created_at <= ?";
        $params[] = $filters['date_to'] . ' 23:59:59';
    }
    
    if (!empty($filters['search'])) {
        $where[] = "(u.username LIKE ? OR ol.action LIKE ? OR ol.resource_type LIKE ?)";
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }
    
    $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
    
    // 获取总数
    $countQuery = "
        SELECT COUNT(*) as total 
        FROM operation_logs ol
        LEFT JOIN users u ON ol.user_id = u.id
        $whereClause
    ";
    $total = $db->query($countQuery, $params)->fetch()['total'];
    
    // 获取数据
    $query = "
        SELECT 
            ol.id,
            ol.user_id,
            u.username,
            ol.action,
            ol.resource_type,
            ol.resource_id,
            ol.ip_address,
            ol.user_agent,
            ol.created_at
        FROM operation_logs ol
        LEFT JOIN users u ON ol.user_id = u.id
        $whereClause
        ORDER BY ol.created_at DESC 
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $logs = $db->query($query, $params)->fetchAll();
    
    return [
        'logs' => $logs,
        'total' => $total,
        'pages' => ceil($total / $limit),
        'current_page' => $page
    ];
}

// 获取用户列表（用于筛选）
function getUsers($db) {
    return $db->query("SELECT id, username FROM users ORDER BY username")->fetchAll();
}

// 获取日志统计
function getLogStats($db) {
    $stats = [];
    
    // 系统日志统计
    $stats['system'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM system_logs")->fetch()['count'],
        'info' => $db->query("SELECT COUNT(*) as count FROM system_logs WHERE level = 'info'")->fetch()['count'],
        'warning' => $db->query("SELECT COUNT(*) as count FROM system_logs WHERE level = 'warning'")->fetch()['count'],
        'error' => $db->query("SELECT COUNT(*) as count FROM system_logs WHERE level = 'error'")->fetch()['count'],
        'debug' => $db->query("SELECT COUNT(*) as count FROM system_logs WHERE level = 'debug'")->fetch()['count']
    ];
    
    // 错误日志统计
    $stats['error'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM error_logs")->fetch()['count'],
        'fatal' => $db->query("SELECT COUNT(*) as count FROM error_logs WHERE error_type = 'fatal'")->fetch()['count'],
        'exception' => $db->query("SELECT COUNT(*) as count FROM error_logs WHERE error_type = 'exception'")->fetch()['count'],
        'warning' => $db->query("SELECT COUNT(*) as count FROM error_logs WHERE error_type = 'warning'")->fetch()['count']
    ];
    
    // 操作日志统计
    $stats['operation'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM operation_logs")->fetch()['count'],
        'today' => $db->query("SELECT COUNT(*) as count FROM operation_logs WHERE DATE(created_at) = CURDATE()")->fetch()['count']
    ];
    
    // 审计统计
    $stats['audit'] = [
        'total' => $db->query("SELECT COUNT(*) as count FROM anomaly_records WHERE 1=1")->fetch()['count'] ?? 0,
        'high_risk' => $db->query("SELECT COUNT(*) as count FROM anomaly_records WHERE risk_level = 'high'")->fetch()['count'] ?? 0,
        'medium_risk' => $db->query("SELECT COUNT(*) as count FROM anomaly_records WHERE risk_level = 'medium'")->fetch()['count'] ?? 0,
        'low_risk' => $db->query("SELECT COUNT(*) as count FROM anomaly_records WHERE risk_level = 'low'")->fetch()['count'] ?? 0
    ];
    
    return $stats;
}

// 获取审计异常记录
function getAnomalyRecords($db, $page = 1, $limit = 50, $filters = []) {
    $offset = ($page - 1) * $limit;
    $where = [];
    $params = [];
    
    // 构建查询条件
    if (!empty($filters['risk_level'])) {
        $where[] = "risk_level = ?";
        $params[] = $filters['risk_level'];
    }
    
    if (!empty($filters['type'])) {
        $where[] = "anomaly_type = ?";
        $params[] = $filters['type'];
    }
    
    if (!empty($filters['user_id'])) {
        $where[] = "user_id = ?";
        $params[] = $filters['user_id'];
    }
    
    if (!empty($filters['date_from'])) {
        $where[] = "created_at >= ?";
        $params[] = $filters['date_from'] . ' 00:00:00';
    }
    
    if (!empty($filters['date_to'])) {
        $where[] = "created_at <= ?";
        $params[] = $filters['date_to'] . ' 23:59:59';
    }
    
    $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
    
    // 获取总数
    $countQuery = "SELECT COUNT(*) as total FROM anomaly_records $whereClause";
    $total = $db->query($countQuery, $params)->fetch()['total'] ?? 0;
    
    // 获取数据
    $query = "
        SELECT 
            id,
            user_id,
            username,
            anomaly_type,
            description,
            risk_level,
            details,
            created_at,
            status
        FROM anomaly_records 
        $whereClause
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $logs = $db->query($query, $params)->fetchAll() ?? [];
    
    return [
        'logs' => $logs,
        'total' => $total,
        'pages' => ceil($total / $limit),
        'current_page' => $page
    ];
}

// 执行审计操作
function runAudit() {
    try {
        // 包含审计系统文件
        require_once '../check_logs_syntax.php';
        
        // 创建审计系统实例
        $auditSystem = new LogAuditSystem();
        
        // 执行完整审计
        $results = $auditSystem->runFullAudit();
        
        // 生成报告
        $reportPath = $auditSystem->generateReport('manual_audit_' . date('YmdHis'));
        
        return [
            'success' => true,
            'results' => [
                'admin_anomalies' => count($results['admin_anomalies']),
                'price_anomalies' => count($results['price_anomalies']),
                'withdraw_anomalies' => count($results['withdraw_anomalies'])
            ],
            'report_path' => $reportPath
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

// 处理AJAX请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    try {
        switch ($_POST['action']) {
            case 'export_logs':
                $type = $_POST['type'] ?? 'system';
                $format = $_POST['format'] ?? 'csv';
                
                switch ($type) {
                    case 'system':
                        $logs = getSystemLogs($db, 1, 10000);
                        break;
                    case 'error':
                        $logs = getErrorLogs($db, 1, 10000);
                        break;
                    case 'operation':
                        $logs = getOperationLogs($db, 1, 10000);
                        break;
                    case 'audit':
                        $logs = getAnomalyRecords($db, 1, 10000);
                        break;
                    default:
                        throw new Exception('无效的日志类型');
                }
                
                if ($format === 'csv') {
                    $filename = $type . '_logs_' . date('Y-m-d_H-i-s') . '.csv';
                    $filepath = '../temp/' . $filename;
                    
                    $file = fopen($filepath, 'w');
                    
                    // 写入CSV头部
                    if ($type === 'system') {
                        fputcsv($file, ['ID', '级别', '消息', '上下文', '创建时间']);
                        foreach ($logs['logs'] as $log) {
                            fputcsv($file, [
                                $log['id'],
                                $log['level'],
                                $log['message'],
                                $log['context'],
                                $log['created_at']
                            ]);
                        }
                    } elseif ($type === 'error') {
                        fputcsv($file, ['ID', '错误类型', '消息', '文件', '行号', '堆栈跟踪', '创建时间']);
                        foreach ($logs['logs'] as $log) {
                            fputcsv($file, [
                                $log['id'],
                                $log['error_type'],
                                $log['message'],
                                $log['file'],
                                $log['line'],
                                $log['stack_trace'],
                                $log['created_at']
                            ]);
                        }
                    } elseif ($type === 'operation') {
                        fputcsv($file, ['ID', '用户ID', '用户名', '操作', '资源类型', '资源ID', 'IP地址', '用户代理', '创建时间']);
                        foreach ($logs['logs'] as $log) {
                            fputcsv($file, [
                                $log['id'],
                                $log['user_id'],
                                $log['username'],
                                $log['action'],
                                $log['resource_type'],
                                $log['resource_id'],
                                $log['ip_address'],
                                $log['user_agent'],
                                $log['created_at']
                            ]);
                        }
                    } elseif ($type === 'audit') {
                        fputcsv($file, ['ID', '用户ID', '用户名', '异常类型', '描述', '风险级别', '状态', '创建时间']);
                        foreach ($logs['logs'] as $log) {
                            fputcsv($file, [
                                $log['id'],
                                $log['user_id'],
                                $log['username'],
                                $log['anomaly_type'],
                                $log['description'],
                                $log['risk_level'],
                                $log['status'],
                                $log['created_at']
                            ]);
                        }
                    }
                    
                    fclose($file);
                    
                    echo json_encode([
                        'success' => true,
                        'file' => $filename,
                        'url' => '../temp/' . $filename
                    ]);
                } else {
                    throw new Exception('不支持的导出格式');
                }
                break;
                
            case 'delete_logs':
                $type = $_POST['type'] ?? 'system';
                $days = (int)($_POST['days'] ?? 30);
                
                switch ($type) {
                    case 'system':
                        $db->query("DELETE FROM system_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)", [$days]);
                        break;
                    case 'error':
                        $db->query("DELETE FROM error_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)", [$days]);
                        break;
                    case 'operation':
                        $db->query("DELETE FROM operation_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)", [$days]);
                        break;
                    default:
                        throw new Exception('无效的日志类型');
                }
                
                echo json_encode(['success' => true, 'message' => '日志删除完成']);
                break;
                
            case 'run_audit':
                // 执行审计
                $auditResult = runAudit();
                echo json_encode($auditResult);
                break;
                
            case 'update_anomaly_status':
                // 更新异常状态
                $id = $_POST['id'] ?? '';
                $status = $_POST['status'] ?? 'pending';
                
                if (empty($id)) {
                    throw new Exception('无效的异常ID');
                }
                
                $db->query("UPDATE anomaly_records SET status = ? WHERE id = ?", [$status, $id]);
                echo json_encode(['success' => true, 'message' => '状态更新成功']);
                break;
                
            default:
                echo json_encode(['success' => false, 'message' => '未知操作']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// 获取请求参数
$page = (int)($_GET['page'] ?? 1);
$type = $_GET['type'] ?? 'system';
$limit = 50;

// 获取筛选参数
$filters = [
    'search' => $_GET['search'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? '',
    'level' => $_GET['level'] ?? '',
    'error_type' => $_GET['error_type'] ?? '',
    'user_id' => $_GET['user_id'] ?? '',
    'action' => $_GET['action'] ?? '',
    'resource_type' => $_GET['resource_type'] ?? ''
];

// 获取日志数据
switch ($type) {
    case 'system':
        $result = getSystemLogs($db, $page, $limit, $filters);
        break;
    case 'error':
        $result = getErrorLogs($db, $page, $limit, $filters);
        break;
    case 'operation':
        $result = getOperationLogs($db, $page, $limit, $filters);
        break;
    case 'audit':
        $result = getAnomalyRecords($db, $page, $limit, $filters);
        break;
    default:
        $result = ['logs' => [], 'total' => 0, 'pages' => 0, 'current_page' => 1];
}

// 获取统计数据和用户列表
$stats = getLogStats($db);
$users = getUsers($db);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>日志管理 - 发卡系统管理后台</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            line-height: 1.6;
        }
        
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding: 20px 0;
        }
        
        .sidebar h3 {
            padding: 0 20px 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-menu li {
            border-bottom: 1px solid #34495e;
        }
        
        .nav-menu a {
            display: block;
            padding: 15px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .nav-menu a:hover,
        .nav-menu a.active {
            background: #34495e;
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: #2c3e50;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2980b9;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #219a52;
        }
        
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-card h3 {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .log-section {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .section-header {
            background: #34495e;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .section-content {
            padding: 20px;
        }
        
        .log-tabs {
            display: flex;
            border-bottom: 1px solid #ecf0f1;
            margin-bottom: 20px;
        }
        
        .log-tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.3s;
        }
        
        .log-tab.active {
            color: #3498db;
            border-bottom-color: #3498db;
        }
        
        .filters {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            min-width: 150px;
        }
        
        .filter-group label {
            font-size: 12px;
            color: #7f8c8d;
            margin-bottom: 5px;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .log-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .log-table th,
        .log-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .log-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .log-table tr:hover {
            background: #f8f9fa;
        }
        
        .log-level {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .log-level.info {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .log-level.warning {
            background: #fff3e0;
            color: #f57c00;
        }
        
        .log-level.error {
            background: #ffebee;
            color: #d32f2f;
        }
        
        .log-level.debug {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #2c3e50;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .pagination .disabled {
            color: #ccc;
            cursor: not-allowed;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .modal-header h3 {
            color: #2c3e50;
        }
        
        .close {
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: #aaa;
        }
        
        .close:hover {
            color: #000;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #2c3e50;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        
        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d5f4e6;
            color: #27ae60;
            border: 1px solid #27ae60;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffc107;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #dc3545;
        }
        
        .text-truncate {
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        @media (max-width: 768px) {
            .admin-layout {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-row {
                flex-direction: column;
            }
            
            .header {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <div class="sidebar">
            <h3>发卡系统管理</h3>
            <ul class="nav-menu">
                <li><a href="../admin/index.php">仪表板</a></li>
                <li><a href="../admin/users.php">用户管理</a></li>
                <li><a href="../admin/cards.php">卡片管理</a></li>
                <li><a href="../admin/orders.php">订单管理</a></li>
                <li><a href="../admin/monitoring.php">系统监控</a></li>
                <li><a href="#" class="active">日志管理</a></li>
                <li><a href="../admin/settings.php">系统设置</a></li>
                <li><a href="../logout.php">退出登录</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>日志与审计管理</h1>
                <div class="header-actions">
                    <button class="btn btn-success" onclick="exportLogs()">导出日志</button>
                    <button class="btn btn-danger" onclick="showDeleteModal()">清理日志</button>
                    <?php if ($type === 'audit'): ?>
                    <button class="btn btn-warning" onclick="runAudit()">立即审计</button>
                    <?php endif; ?>
                    <a href="../admin/index.php" class="btn btn-primary">返回仪表板</a>
                </div>
            </div>
            
            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>系统日志总数</h3>
                    <div class="value"><?php echo number_format($stats['system']['total']); ?></div>
                </div>
                
                <div class="stat-card">
                    <h3>错误日志总数</h3>
                    <div class="value"><?php echo number_format($stats['error']['total']); ?></div>
                </div>
                
                <div class="stat-card">
                    <h3>操作日志总数</h3>
                    <div class="value"><?php echo number_format($stats['operation']['total']); ?></div>
                </div>
                
                <div class="stat-card">
                    <h3>今日操作</h3>
                    <div class="value"><?php echo number_format($stats['operation']['today']); ?></div>
                </div>
                
                <div class="stat-card" style="border-left: 4px solid #e74c3c;">
                    <h3>审计异常总数</h3>
                    <div class="value" style="color: #e74c3c;"><?php echo number_format($stats['audit']['total']); ?></div>
                </div>
                
                <div class="stat-card" style="border-left: 4px solid #f39c12;">
                    <h3>高风险异常</h3>
                    <div class="value" style="color: #f39c12;"><?php echo number_format($stats['audit']['high_risk']); ?></div>
                </div>
            </div>
            
            <!-- 日志查看 -->
            <div class="log-section">
                <div class="section-header">
                    <h3>日志查看</h3>
                </div>
                <div class="section-content">
                    <!-- 日志类型选择 -->
                    <div class="log-tabs">
                        <div class="log-tab <?php echo $type === 'system' ? 'active' : ''; ?>" onclick="switchType('system')">系统日志</div>
                        <div class="log-tab <?php echo $type === 'error' ? 'active' : ''; ?>" onclick="switchType('error')">错误日志</div>
                        <div class="log-tab <?php echo $type === 'operation' ? 'active' : ''; ?>" onclick="switchType('operation')">操作日志</div>
                        <div class="log-tab <?php echo $type === 'audit' ? 'active' : ''; ?>" onclick="switchType('audit')">安全审计</div>
                    </div>
                    
                    <!-- 筛选器 -->
                    <div class="filters">
                        <form method="GET" id="filterForm">
                            <input type="hidden" name="type" value="<?php echo $type; ?>">
                            
                            <div class="filter-row">
                                <div class="filter-group">
                                    <label>搜索关键词</label>
                                    <input type="text" name="search" value="<?php echo htmlspecialchars($filters['search']); ?>" placeholder="搜索日志内容">
                                </div>
                                
                                <div class="filter-group">
                                    <label>开始日期</label>
                                    <input type="date" name="date_from" value="<?php echo htmlspecialchars($filters['date_from']); ?>">
                                </div>
                                
                                <div class="filter-group">
                                    <label>结束日期</label>
                                    <input type="date" name="date_to" value="<?php echo htmlspecialchars($filters['date_to']); ?>">
                                </div>
                            </div>
                            
                            <?php if ($type === 'system'): ?>
                            <div class="filter-row">
                                <div class="filter-group">
                                    <label>日志级别</label>
                                    <select name="level">
                                        <option value="">全部级别</option>
                                        <option value="info" <?php echo $filters['level'] === 'info' ? 'selected' : ''; ?>>信息</option>
                                        <option value="warning" <?php echo $filters['level'] === 'warning' ? 'selected' : ''; ?>>警告</option>
                                        <option value="error" <?php echo $filters['level'] === 'error' ? 'selected' : ''; ?>>错误</option>
                                        <option value="debug" <?php echo $filters['level'] === 'debug' ? 'selected' : ''; ?>>调试</option>
                                    </select>
                                </div>
                            </div>
                            
                            <?php elseif ($type === 'error'): ?>
                            <div class="filter-row">
                                <div class="filter-group">
                                    <label>错误类型</label>
                                    <select name="error_type">
                                        <option value="">全部类型</option>
                                        <option value="fatal" <?php echo $filters['error_type'] === 'fatal' ? 'selected' : ''; ?>>致命错误</option>
                                        <option value="exception" <?php echo $filters['error_type'] === 'exception' ? 'selected' : ''; ?>>异常</option>
                                        <option value="warning" <?php echo $filters['error_type'] === 'warning' ? 'selected' : ''; ?>>警告</option>
                                    </select>
                                </div>
                            </div>
                            
                            <?php elseif ($type === 'operation'): ?>
                            <div class="filter-row">
                                <div class="filter-group">
                                    <label>用户</label>
                                    <select name="user_id">
                                        <option value="">全部用户</option>
                                        <?php foreach ($users as $user): ?>
                                        <option value="<?php echo $user['id']; ?>" <?php echo $filters['user_id'] == $user['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($user['username']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>操作类型</label>
                                    <select name="action">
                                        <option value="">全部操作</option>
                                        <option value="create" <?php echo $filters['action'] === 'create' ? 'selected' : ''; ?>>创建</option>
                                        <option value="update" <?php echo $filters['action'] === 'update' ? 'selected' : ''; ?>>更新</option>
                                        <option value="delete" <?php echo $filters['action'] === 'delete' ? 'selected' : ''; ?>>删除</option>
                                        <option value="view" <?php echo $filters['action'] === 'view' ? 'selected' : ''; ?>>查看</option>
                                        <option value="login" <?php echo $filters['action'] === 'login' ? 'selected' : ''; ?>>登录</option>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>资源类型</label>
                                    <select name="resource_type">
                                        <option value="">全部资源</option>
                                        <option value="user" <?php echo $filters['resource_type'] === 'user' ? 'selected' : ''; ?>>用户</option>
                                        <option value="card" <?php echo $filters['resource_type'] === 'card' ? 'selected' : ''; ?>>卡片</option>
                                        <option value="order" <?php echo $filters['resource_type'] === 'order' ? 'selected' : ''; ?>>订单</option>
                                        <option value="product" <?php echo $filters['resource_type'] === 'product' ? 'selected' : ''; ?>>产品</option>
                                    </select>
                                </div>
                            </div>
                            
                            <?php elseif ($type === 'audit'): ?>
                            <div class="filter-row">
                                <div class="filter-group">
                                    <label>用户</label>
                                    <select name="user_id">
                                        <option value="">全部用户</option>
                                        <?php foreach ($users as $user): ?>
                                        <option value="<?php echo $user['id']; ?>" <?php echo $filters['user_id'] == $user['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($user['username']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>风险级别</label>
                                    <select name="risk_level">
                                        <option value="">全部级别</option>
                                        <option value="high" <?php echo $filters['risk_level'] === 'high' ? 'selected' : ''; ?>>高风险</option>
                                        <option value="medium" <?php echo $filters['risk_level'] === 'medium' ? 'selected' : ''; ?>>中风险</option>
                                        <option value="low" <?php echo $filters['risk_level'] === 'low' ? 'selected' : ''; ?>>低风险</option>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>异常类型</label>
                                    <select name="type">
                                        <option value="">全部类型</option>
                                        <option value="price_change" <?php echo $filters['type'] === 'price_change' ? 'selected' : ''; ?>>价格修改</option>
                                        <option value="withdrawal" <?php echo $filters['type'] === 'withdrawal' ? 'selected' : ''; ?>>提现操作</option>
                                        <option value="login" <?php echo $filters['type'] === 'login' ? 'selected' : ''; ?>>登录异常</option>
                                        <option value="admin_action" <?php echo $filters['type'] === 'admin_action' ? 'selected' : ''; ?>>管理员操作</option>
                                    </select>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <div class="filter-row">
                                <button type="submit" class="btn btn-primary">筛选</button>
                                <button type="button" class="btn btn-secondary" onclick="clearFilters()">清除筛选</button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- 日志表格 -->
                    <table class="log-table">
                        <thead>
                            <?php if ($type === 'system'): ?>
                            <tr>
                                <th>ID</th>
                                <th>时间</th>
                                <th>级别</th>
                                <th>消息</th>
                                <th>上下文</th>
                            </tr>
                            <?php elseif ($type === 'error'): ?>
                            <tr>
                                <th>ID</th>
                                <th>时间</th>
                                <th>错误类型</th>
                                <th>消息</th>
                                <th>文件</th>
                                <th>行号</th>
                            </tr>
                            <?php elseif ($type === 'operation'): ?>
                            <tr>
                                <th>ID</th>
                                <th>时间</th>
                                <th>用户</th>
                                <th>操作</th>
                                <th>资源</th>
                                <th>IP地址</th>
                            </tr>
                            
                            <?php elseif ($type === 'audit'): ?>
                            <tr>
                                <th>ID</th>
                                <th>时间</th>
                                <th>用户</th>
                                <th>异常类型</th>
                                <th>描述</th>
                                <th>风险级别</th>
                                <th>状态</th>
                                <th>操作</th>
                            </tr>
                            <?php endif; ?>
                        </thead>
                        <tbody>
                            <?php foreach ($result['logs'] as $log): ?>
                            <?php if ($type === 'system'): ?>
                            <tr>
                                <td><?php echo $log['id']; ?></td>
                                <td><?php echo $log['created_at']; ?></td>
                                <td><span class="log-level <?php echo $log['level']; ?>"><?php echo strtoupper($log['level']); ?></span></td>
                                <td class="text-truncate" title="<?php echo htmlspecialchars($log['message']); ?>"><?php echo htmlspecialchars($log['message']); ?></td>
                                <td class="text-truncate" title="<?php echo htmlspecialchars($log['context']); ?>"><?php echo htmlspecialchars($log['context']); ?></td>
                            </tr>
                            <?php elseif ($type === 'error'): ?>
                            <tr>
                                <td><?php echo $log['id']; ?></td>
                                <td><?php echo $log['created_at']; ?></td>
                                <td><?php echo htmlspecialchars($log['error_type']); ?></td>
                                <td class="text-truncate" title="<?php echo htmlspecialchars($log['message']); ?>"><?php echo htmlspecialchars($log['message']); ?></td>
                                <td class="text-truncate" title="<?php echo htmlspecialchars($log['file']); ?>"><?php echo htmlspecialchars($log['file']); ?></td>
                                <td><?php echo $log['line']; ?></td>
                            </tr>
                            <?php elseif ($type === 'operation'): ?>
                            <tr>
                                <td><?php echo $log['id']; ?></td>
                                <td><?php echo $log['created_at']; ?></td>
                                <td><?php echo htmlspecialchars($log['username']); ?></td>
                                <td><?php echo htmlspecialchars($log['action']); ?></td>
                                <td><?php echo htmlspecialchars($log['resource_type']); ?>:<?php echo $log['resource_id']; ?></td>
                                <td><?php echo $log['ip_address']; ?></td>
                            </tr>
                            
                            <?php elseif ($type === 'audit'): ?>
                            <tr>
                                <td><?php echo $log['id']; ?></td>
                                <td><?php echo $log['created_at']; ?></td>
                                <td><?php echo htmlspecialchars($log['username']); ?></td>
                                <td><?php echo htmlspecialchars($log['anomaly_type']); ?></td>
                                <td class="text-truncate" title="<?php echo htmlspecialchars($log['description']); ?>">
                                    <?php echo htmlspecialchars($log['description']); ?>
                                </td>
                                <td>
                                    <span class="log-level" style="
                                        background: <?php echo $log['risk_level'] === 'high' ? '#ffebee' : ($log['risk_level'] === 'medium' ? '#fff3e0' : '#e8f5e8'); ?>
                                        color: <?php echo $log['risk_level'] === 'high' ? '#d32f2f' : ($log['risk_level'] === 'medium' ? '#f57c00' : '#2e7d32'); ?>
                                    ">
                                        <?php echo strtoupper($log['risk_level']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="log-level" style="
                                        background: <?php echo $log['status'] === 'resolved' ? '#e8f5e8' : ($log['status'] === 'investigating' ? '#e3f2fd' : '#fff3cd'); ?>
                                        color: <?php echo $log['status'] === 'resolved' ? '#2e7d32' : ($log['status'] === 'investigating' ? '#1976d2' : '#856404'); ?>
                                    ">
                                        <?php echo $log['status'] === 'resolved' ? '已解决' : ($log['status'] === 'investigating' ? '调查中' : '待处理'); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="viewAnomalyDetails(<?php echo $log['id']; ?>)">详情</button>
                                    <select onchange="updateAnomalyStatus(<?php echo $log['id']; ?>, this.value)" style="margin-left: 5px; padding: 2px 5px;">
                                        <option value="pending" <?php echo $log['status'] === 'pending' ? 'selected' : ''; ?>>待处理</option>
                                        <option value="investigating" <?php echo $log['status'] === 'investigating' ? 'selected' : ''; ?>>调查中</option>
                                        <option value="resolved" <?php echo $log['status'] === 'resolved' ? 'selected' : ''; ?>>已解决</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <!-- 分页 -->
                    <?php if ($result['pages'] > 1): ?>
                    <div class="pagination">
                        <?php if ($result['current_page'] > 1): ?>
                        <a href="?type=<?php echo $type; ?>&page=<?php echo $result['current_page'] - 1; ?><?php echo buildQueryString(); ?>">上一页</a>
                        <?php else: ?>
                        <span class="disabled">上一页</span>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $result['current_page'] - 3); $i <= min($result['pages'], $result['current_page'] + 3); $i++): ?>
                        <?php if ($i == $result['current_page']): ?>
                        <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                        <a href="?type=<?php echo $type; ?>&page=<?php echo $i; ?><?php echo buildQueryString(); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($result['current_page'] < $result['pages']): ?>
                        <a href="?type=<?php echo $type; ?>&page=<?php echo $result['current_page'] + 1; ?><?php echo buildQueryString(); ?>">下一页</a>
                        <?php else: ?>
                        <span class="disabled">下一页</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 删除日志模态框 -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>清理日志</h3>
                <span class="close" onclick="closeDeleteModal()">&times;</span>
            </div>
            <form id="deleteForm">
                <div class="form-group">
                    <label>日志类型</label>
                    <select name="type" required>
                        <option value="system">系统日志</option>
                        <option value="error">错误日志</option>
                        <option value="operation">操作日志</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>删除多少天前的日志</label>
                    <input type="number" name="days" value="30" min="1" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">取消</button>
                    <button type="submit" class="btn btn-danger">确认删除</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // 切换日志类型
        function switchType(type) {
            window.location.href = '?type=' + type;
        }
        
        // 清除筛选
        function clearFilters() {
            window.location.href = '?type=<?php echo $type; ?>';
        }
        
        // 构建查询字符串
        function buildQueryString() {
            const params = new URLSearchParams(window.location.search);
            params.delete('type');
            params.delete('page');
            const queryString = params.toString();
            return queryString ? '&' + queryString : '';
        }
        
        // 显示删除模态框
        function showDeleteModal() {
            document.getElementById('deleteModal').style.display = 'block';
        }
        
        // 关闭删除模态框
        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }
        
        // 导出日志
        function exportLogs() {
            const type = '<?php echo $type; ?>';
            
            fetch('logs.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=export_logs&type=' + type + '&format=csv'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // 创建下载链接
                    const a = document.createElement('a');
                    a.href = data.url;
                    a.download = data.file;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                } else {
                    alert('导出失败：' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('导出失败');
            });
        }
        
        // 执行审计
        function runAudit() {
            if (!confirm('确定要执行完整的审计操作吗？这可能需要一些时间。')) {
                return;
            }
            
            alert('审计开始执行，请稍候...');
            
            fetch('logs.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=run_audit'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('审计完成！\n' +
                          '- 管理员异常: ' + data.results.admin_anomalies + '\n' +
                          '- 价格异常: ' + data.results.price_anomalies + '\n' +
                          '- 提现异常: ' + data.results.withdraw_anomalies);
                    location.reload();
                } else {
                    alert('审计失败：' + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('审计执行失败');
            });
        }
        
        // 查看异常详情
        function viewAnomalyDetails(id) {
            // 这里可以实现查看详情的功能
            alert('查看异常ID: ' + id + ' 的详情');
            // 可以通过AJAX获取详情并显示在模态框中
        }
        
        // 更新异常状态
        function updateAnomalyStatus(id, status) {
            fetch('logs.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=update_anomaly_status&id=' + id + '&status=' + status
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('状态更新成功');
                } else {
                    alert('状态更新失败：' + data.message);
                }
            });
        }
        
        // 处理删除表单提交
        document.getElementById('deleteForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!confirm('确定要删除指定天数前的日志吗？此操作不可恢复。')) {
                return;
            }
            
            const formData = new FormData(this);
            formData.append('action', 'delete_logs');
            
            fetch('logs.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('日志删除成功');
                    closeDeleteModal();
                    location.reload();
                } else {
                    alert('删除失败：' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('删除失败');
            });
        });
        
        // 点击模态框外部关闭
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target == modal) {
                closeDeleteModal();
            }
        }
    </script>
</body>
</html>

<?php
// 辅助函数：构建查询字符串
function buildQueryString() {
    $params = $_GET;
    unset($params['type']);
    unset($params['page']);
    
    $queryString = '';
    foreach ($params as $key => $value) {
        if (!empty($value)) {
            $queryString .= '&' . $key . '=' . urlencode($value);
        }
    }
    
    return $queryString;
}
?>