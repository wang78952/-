<?php
/**
 * 用户管理页面
 */

require_once '../config.php';
require_once '../includes/AuthManager.php';
require_once '../includes/Database.php';
require_once '../includes/SecurityUtils.php';

// 启动会话
session_start();

// 检查管理员权限
$authManager = new AuthManager();
if (!$authManager->isLoggedIn() || !in_array($_SESSION['user_role'], ['admin', 'business_admin'])) {
    header('Location: ../login.php');
    exit;
}

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();

// 获取数据库连接
$db = Database::getInstance();

// 处理操作
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_user':
            try {
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $password = $_POST['password'];
                $role = $_POST['role'];
                $status = $_POST['status'] ?? 'active';
                
                // 验证输入
                if (empty($username) || empty($email) || empty($password) || empty($role)) {
                    throw new Exception('所有必填字段都不能为空');
                }
                
                // 检查用户名是否已存在
                if ($db->queryOne("SELECT id FROM users WHERE username = ?", [$username])) {
                    throw new Exception('用户名已存在');
                }
                
                // 检查邮箱是否已存在
                if ($db->queryOne("SELECT id FROM users WHERE email = ?", [$email])) {
                    throw new Exception('邮箱已存在');
                }
                
                // 密码加密
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // 插入用户
                $db->query("INSERT INTO users (username, email, password, role, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())", 
                    [$username, $email, $hashedPassword, $role, $status]);
                
                $message = '用户添加成功';
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "添加用户: $username", 'user_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'edit_user':
            try {
                $userId = (int)$_POST['user_id'];
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $role = $_POST['role'];
                $status = $_POST['status'] ?? 'active';
                
                // 验证输入
                if (empty($username) || empty($email) || empty($role)) {
                    throw new Exception('所有必填字段都不能为空');
                }
                
                // 检查用户名是否已存在（排除当前用户）
                if ($db->queryOne("SELECT id FROM users WHERE username = ? AND id != ?", [$username, $userId])) {
                    throw new Exception('用户名已存在');
                }
                
                // 检查邮箱是否已存在（排除当前用户）
                if ($db->queryOne("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $userId])) {
                    throw new Exception('邮箱已存在');
                }
                
                // 更新用户信息
                $db->query("UPDATE users SET username = ?, email = ?, role = ?, status = ?, updated_at = NOW() WHERE id = ?", 
                    [$username, $email, $role, $status, $userId]);
                
                // 如果提供了新密码，更新密码
                if (!empty($_POST['password'])) {
                    $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $db->query("UPDATE users SET password = ? WHERE id = ?", [$hashedPassword, $userId]);
                }
                
                $message = '用户信息更新成功';
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "更新用户: $username", 'user_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
            
        case 'delete_user':
            try {
                $userId = (int)$_POST['user_id'];
                
                // 不能删除自己
                if ($userId === $currentUser['id']) {
                    throw new Exception('不能删除自己的账户');
                }
                
                // 获取用户信息
                $user = $db->queryOne("SELECT username FROM users WHERE id = ?", [$userId]);
                if (!$user) {
                    throw new Exception('用户不存在');
                }
                
                // 删除用户
                $db->query("DELETE FROM users WHERE id = ?", [$userId]);
                
                $message = '用户删除成功';
                
                // 记录操作日志
                $db->query("INSERT INTO user_logs (user_id, action, action_type, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
                    [$currentUser['id'], "删除用户: {$user['username']}", 'user_management', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
                
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
            break;
    }
}

// 获取用户列表
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// 搜索条件
$search = trim($_GET['search'] ?? '');
$role_filter = $_GET['role'] ?? '';
$status_filter = $_GET['status'] ?? '';

$whereConditions = [];
$params = [];

if (!empty($search)) {
    $whereConditions[] = "(username LIKE ? OR email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($role_filter)) {
    $whereConditions[] = "role = ?";
    $params[] = $role_filter;
}

if (!empty($status_filter)) {
    $whereConditions[] = "status = ?";
    $params[] = $status_filter;
}

$whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// 获取总数
$totalQuery = "SELECT COUNT(*) as total FROM users $whereClause";
$totalResult = $db->queryOne($totalQuery, $params);
$totalUsers = $totalResult['total'];
$totalPages = ceil($totalUsers / $limit);

// 获取用户列表
$usersQuery = "SELECT * FROM users $whereClause ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$users = $db->query($usersQuery, $params);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/ui-components.css">
    <style>
        .page-header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .search-filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .filter-form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .filter-group label {
            font-size: 14px;
            color: #555;
            font-weight: 500;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .users-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .table tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-active {
            background: #d5f4e6;
            color: #27ae60;
        }
        
        .status-inactive {
            background: #fadbd8;
            color: #e74c3c;
        }
        
        .status-suspended {
            background: #fef5e7;
            color: #f39c12;
        }
        
        .role-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .role-admin {
            background: #e8daef;
            color: #6c3483;
        }
        
        .role-business_admin {
            background: #d6eaf8;
            color: #2874a6;
        }
        
        .role-operator {
            background: #d5f4e6;
            color: #239b56;
        }
        
        .role-viewer {
            background: #fdebd0;
            color: #dc7633;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn-sm {
            padding: 4px 8px;
            font-size: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-edit {
            background: #3498db;
            color: white;
        }
        
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        
        .modal-content {
            background: white;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            max-width: 500px;
            position: relative;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }
        
        .alert {
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d5f4e6;
            color: #27ae60;
            border: 1px solid #27ae60;
        }
        
        .alert-error {
            background: #fadbd8;
            color: #e74c3c;
            border: 1px solid #e74c3c;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>管理控制台</h2>
                <div class="user-info">
                    <?php echo htmlspecialchars($currentUser['username']); ?>
                    <br>
                    <small><?php echo htmlspecialchars($currentUser['role']); ?></small>
                </div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i>📊</i>仪表板</a></li>
                <li><a href="users.php" class="active"><i>👥</i>用户管理</a></li>
                <li><a href="cards.php"><i>💳</i>卡片管理</a></li>
                <li><a href="orders.php"><i>📦</i>订单管理</a></li>
                <li><a href="products.php"><i>🛍️</i>产品管理</a></li>
                <li><a href="security.php"><i>🔒</i>安全管理</a></li>
                <li><a href="logs.php"><i>📝</i>日志管理</a></li>
                <li><a href="settings.php"><i>⚙️</i>系统设置</a></li>
                <li><a href="../logout.php"><i>🚪</i>退出登录</a></li>
            </ul>
        </div>

        <!-- 主要内容 -->
        <div class="main-content">
            <!-- 页面头部 -->
            <div class="page-header">
                <h1>用户管理</h1>
                <button class="btn btn-primary" onclick="showAddUserModal()">添加用户</button>
            </div>

            <!-- 消息提示 -->
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- 搜索过滤 -->
            <div class="search-filters">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <label>搜索</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="用户名或邮箱">
                    </div>
                    <div class="filter-group">
                        <label>角色</label>
                        <select name="role">
                            <option value="">全部</option>
                            <option value="admin" <?php echo $role_filter === 'admin' ? 'selected' : ''; ?>>管理员</option>
                            <option value="business_admin" <?php echo $role_filter === 'business_admin' ? 'selected' : ''; ?>>业务管理员</option>
                            <option value="operator" <?php echo $role_filter === 'operator' ? 'selected' : ''; ?>>操作员</option>
                            <option value="viewer" <?php echo $role_filter === 'viewer' ? 'selected' : ''; ?>>查看者</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>状态</label>
                        <select name="status">
                            <option value="">全部</option>
                            <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>活跃</option>
                            <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>禁用</option>
                            <option value="suspended" <?php echo $status_filter === 'suspended' ? 'selected' : ''; ?>>暂停</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">搜索</button>
                    <a href="users.php" class="btn btn-secondary">重置</a>
                </form>
            </div>

            <!-- 用户列表 -->
            <div class="users-table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>用户名</th>
                            <th>邮箱</th>
                            <th>角色</th>
                            <th>状态</th>
                            <th>注册时间</th>
                            <th>最后登录</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 40px;">没有找到用户</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <span class="role-badge role-<?php echo $user['role']; ?>">
                                            <?php 
                                            $roles = [
                                                'admin' => '管理员',
                                                'business_admin' => '业务管理员',
                                                'operator' => '操作员',
                                                'viewer' => '查看者'
                                            ];
                                            echo $roles[$user['role']] ?? $user['role'];
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $user['status']; ?>">
                                            <?php 
                                            $statuses = [
                                                'active' => '活跃',
                                                'inactive' => '禁用',
                                                'suspended' => '暂停'
                                            ];
                                            echo $statuses[$user['status']] ?? $user['status'];
                                            ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($user['created_at'])); ?></td>
                                    <td><?php echo $user['last_login'] ? date('Y-m-d H:i', strtotime($user['last_login'])) : '从未登录'; ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn-sm btn-edit" onclick="showEditUserModal(<?php echo $user['id']; ?>)">编辑</button>
                                            <?php if ($user['id'] !== $currentUser['id']): ?>
                                                <button class="btn-sm btn-delete" onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')">删除</button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- 分页 -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>&status=<?php echo urlencode($status_filter); ?>">上一页</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>&status=<?php echo urlencode($status_filter); ?>">下一页</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 添加用户模态框 -->
    <div id="addUserModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>添加用户</h3>
                <button class="modal-close" onclick="hideModal('addUserModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_user">
                <div class="form-group">
                    <label>用户名 *</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-group">
                    <label>邮箱 *</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>密码 *</label>
                    <input type="password" name="password" required>
                </div>
                <div class="form-group">
                    <label>角色 *</label>
                    <select name="role" required>
                        <option value="">请选择角色</option>
                        <option value="admin">管理员</option>
                        <option value="business_admin">业务管理员</option>
                        <option value="operator">操作员</option>
                        <option value="viewer">查看者</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>状态</label>
                    <select name="status">
                        <option value="active">活跃</option>
                        <option value="inactive">禁用</option>
                        <option value="suspended">暂停</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('addUserModal')">取消</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 编辑用户模态框 -->
    <div id="editUserModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>编辑用户</h3>
                <button class="modal-close" onclick="hideModal('editUserModal')">&times;</button>
            </div>
            <form method="POST" id="editUserForm">
                <input type="hidden" name="action" value="edit_user">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="form-group">
                    <label>用户名 *</label>
                    <input type="text" name="username" id="edit_username" required>
                </div>
                <div class="form-group">
                    <label>邮箱 *</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                <div class="form-group">
                    <label>新密码（留空则不修改）</label>
                    <input type="password" name="password">
                </div>
                <div class="form-group">
                    <label>角色 *</label>
                    <select name="role" id="edit_role" required>
                        <option value="">请选择角色</option>
                        <option value="admin">管理员</option>
                        <option value="business_admin">业务管理员</option>
                        <option value="operator">操作员</option>
                        <option value="viewer">查看者</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>状态</label>
                    <select name="status" id="edit_status">
                        <option value="active">活跃</option>
                        <option value="inactive">禁用</option>
                        <option value="suspended">暂停</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('editUserModal')">取消</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showAddUserModal() {
            document.getElementById('addUserModal').style.display = 'block';
        }

        function showEditUserModal(userId) {
            // 获取用户数据
            fetch('users.php?action=get_user&id=' + userId)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('edit_user_id').value = data.id;
                    document.getElementById('edit_username').value = data.username;
                    document.getElementById('edit_email').value = data.email;
                    document.getElementById('edit_role').value = data.role;
                    document.getElementById('edit_status').value = data.status;
                    document.getElementById('editUserModal').style.display = 'block';
                })
                .catch(error => {
                    console.error('获取用户数据失败:', error);
                    alert('获取用户数据失败');
                });
        }

        function hideModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function deleteUser(userId, username) {
            if (confirm('确定要删除用户 "' + username + '" 吗？此操作不可恢复。')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_user">
                    <input type="hidden" name="user_id" value="${userId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // 点击模态框外部关闭
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>