<?php
/**
 * 监控面板JavaScript引入文件
 */
?>

<!-- 引入Chart.js库 -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- 引入监控面板JavaScript -->
<script src="/admin/monitoring/dashboard.js"></script>