// JavaScript 部分
// 获取URL参数
function getUrlParams() {
    const params = {};
    window.location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi, (str, key, value) => {
        params[key] = value;
    });
    return params;
}

// 页面刷新间隔设置
const params = getUrlParams();
const refreshInterval = parseInt(params.refresh || 30);
let refreshTimer = null;

if (!params.no_refresh) {
    refreshTimer = setInterval(() => {
        location.reload();
    }, refreshInterval * 1000);
}

// 刷新按钮事件
if (document.getElementById('refresh-btn')) {
    document.getElementById('refresh-btn').addEventListener('click', () => {
        if (refreshTimer) {
            clearInterval(refreshTimer);
        }
        location.reload();
    });
}

// 初始化图表
function initCharts() {
    // 根据当前激活的标签页初始化相应的图表
    const activeTab = params.tab || 'overview';
    
    if (activeTab === 'overview' || activeTab === 'performance') {
        initServerLoadChart();
        initResourceUsageChart();
        initDbConnectionsChart();
        initApiResponseChart();
    }
    
    if (activeTab === 'overview' || activeTab === 'business') {
        initSalesChart();
        initActivationRateChart();
    }
}

// 初始化服务器负载图表
function initServerLoadChart() {
    const ctx = document.getElementById('server-load-chart');
    if (!ctx) return;
    
    // 模拟数据 - 实际应用中应该从API获取
    const labels = Array.from({length: 24}, (_, i) => `${i}:00`);
    const data = Array.from({length: 24}, () => (Math.random() * 3 + 0.5).toFixed(2));
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: '服务器负载',
                data: data,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1,
                fill: true,
                backgroundColor: 'rgba(75, 192, 192, 0.1)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '负载值'
                    }
                }
            }
        }
    });
}

// 初始化资源使用图表
function initResourceUsageChart() {
    const ctx = document.getElementById('resource-usage-chart');
    if (!ctx) return;
    
    // 模拟数据
    const labels = Array.from({length: 24}, (_, i) => `${i}:00`);
    const cpuData = Array.from({length: 24}, () => Math.floor(Math.random() * 80 + 10));
    const memoryData = Array.from({length: 24}, () => Math.floor(Math.random() * 70 + 20));
    const diskData = Array.from({length: 24}, () => Math.floor(Math.random() * 50 + 30));
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'CPU使用率(%)',
                    data: cpuData,
                    borderColor: 'rgb(255, 99, 132)',
                    tension: 0.1,
                    yAxisID: 'y'
                },
                {
                    label: '内存使用率(%)',
                    data: memoryData,
                    borderColor: 'rgb(54, 162, 235)',
                    tension: 0.1,
                    yAxisID: 'y'
                },
                {
                    label: '磁盘使用率(%)',
                    data: diskData,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1,
                    yAxisID: 'y'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: '使用率(%)'
                    }
                }
            }
        }
    });
}

// 初始化数据库连接池图表
function initDbConnectionsChart() {
    const ctx = document.getElementById('db-connections-chart');
    if (!ctx) return;
    
    // 模拟数据
    const labels = Array.from({length: 24}, (_, i) => `${i}:00`);
    const connectionsData = Array.from({length: 24}, () => Math.floor(Math.random() * 50 + 10));
    const maxConnections = 100; // 最大连接数
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '活跃连接数',
                    data: connectionsData,
                    borderColor: 'rgb(153, 102, 255)',
                    tension: 0.1,
                    fill: true,
                    backgroundColor: 'rgba(153, 102, 255, 0.1)'
                },
                {
                    label: '最大连接数',
                    data: Array(24).fill(maxConnections),
                    borderColor: 'rgb(255, 99, 132)',
                    borderDash: [5, 5],
                    fill: false,
                    tension: 0,
                    pointRadius: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '连接数'
                    }
                }
            }
        }
    });
}

// 初始化API响应时间图表
function initApiResponseChart() {
    const ctx = document.getElementById('api-response-chart');
    if (!ctx) return;
    
    // 模拟数据
    const labels = Array.from({length: 24}, (_, i) => `${i}:00`);
    const responseData = Array.from({length: 24}, () => (Math.random() * 200 + 50).toFixed(2));
    const threshold = 300; // 阈值
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'API平均响应时间(ms)',
                    data: responseData,
                    borderColor: 'rgb(54, 162, 235)',
                    tension: 0.1,
                    fill: true,
                    backgroundColor: 'rgba(54, 162, 235, 0.1)'
                },
                {
                    label: '响应时间阈值(ms)',
                    data: Array(24).fill(threshold),
                    borderColor: 'rgb(255, 99, 132)',
                    borderDash: [5, 5],
                    fill: false,
                    tension: 0,
                    pointRadius: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '响应时间(ms)'
                    }
                }
            }
        }
    });
}

// 初始化销售额图表
function initSalesChart() {
    const ctx = document.getElementById('sales-chart');
    if (!ctx) return;
    
    // 模拟数据
    const labels = Array.from({length: 30}, (_, i) => `第${i+1}天`);
    const salesData = Array.from({length: 30}, () => Math.floor(Math.random() * 5000 + 1000));
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: '每日销售额(¥)',
                data: salesData,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgb(75, 192, 192)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '销售额(¥)'
                    }
                }
            }
        }
    });
}

// 初始化激活率图表
function initActivationRateChart() {
    const ctx = document.getElementById('activation-rate-chart');
    if (!ctx) return;
    
    // 模拟数据
    const labels = ['卡密1', '卡密2', '卡密3', '卡密4', '卡密5'];
    const activationData = labels.map(() => (Math.random() * 40 + 60).toFixed(2));
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                label: '激活率(%)',
                data: activationData,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)'
                ],
                borderColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 206, 86)',
                    'rgb(75, 192, 192)',
                    'rgb(153, 102, 255)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });
}

// 告警操作相关函数
function viewAlertDetail(alertId) {
    // 查看告警详情
    alert(`查看告警ID: ${alertId} 的详情`);
    // 实际应用中应该跳转到详情页面或显示模态框
}

function acknowledgeAlert(alertId, btn) {
    // 确认告警
    if (confirm(`确认处理告警ID: ${alertId} ?`)) {
        // 实际应用中应该发送AJAX请求到服务器
        const row = btn.closest('tr');
        row.classList.remove('alert-warning', 'alert-danger', 'alert-info');
        row.classList.add('alert-success');
        
        const statusCell = row.querySelector('td:nth-child(6)');
        statusCell.innerHTML = '<span class="badge badge-success">已处理</span>';
        
        btn.disabled = true;
        btn.textContent = '已确认';
    }
}

// 动态更新性能指标
function updatePerformanceMetrics() {
    // 实际应用中应该通过AJAX定期获取最新数据
    // 这里只是简单的演示
    const loadElement = document.querySelector('.load-value');
    const cpuElement = document.querySelector('.cpu-value');
    const memoryElement = document.querySelector('.memory-value');
    
    if (loadElement) {
        const currentLoad = parseFloat(loadElement.textContent);
        const newLoad = (currentLoad + (Math.random() - 0.5) * 0.1).toFixed(2);
        loadElement.textContent = Math.max(0, newLoad);
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    // 确保Chart.js已加载
    if (typeof Chart !== 'undefined') {
        initCharts();
    } else {
        // 如果Chart.js未加载，尝试重新加载
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
        script.onload = initCharts;
        document.head.appendChild(script);
    }
    
    // 每5秒更新一次性能指标
    setInterval(updatePerformanceMetrics, 5000);
});