<?php
// 验证管理员登录
require_once '../includes/bootstrap.php';
require_once '../includes/auth_manager.php';

// 检查是否登录且具有管理员权限
$authManager = new AuthManager();
if (!$authManager->isLoggedIn() || !$authManager->hasPermission('view_analytics')) {
    header('Location: login.php');
    exit;
}

$pageTitle = '代理数据分析 - 发卡系统管理后台';
$activeMenu = 'agent_analytics';

// 加载页面头
include_once 'header.php';
?>

<div class="dashboard-container">
    <!-- 页面标题栏 -->
    <div class="page-header">
        <h1><i class="bi bi-bar-chart-line"></i> 代理数据分析</h1>
        <div class="header-actions">
            <div class="date-range-selector">
                <select id="dateRange" class="form-select">
                    <option value="7days">最近7天</option>
                    <option value="30days">最近30天</option>
                    <option value="today">今天</option>
                    <option value="yesterday">昨天</option>
                    <option value="custom">自定义</option>
                </select>
                <input type="date" id="startDate" class="form-control" style="display: none;" placeholder="开始日期">
                <input type="date" id="endDate" class="form-control" style="display: none;" placeholder="结束日期">
                <button id="applyDateRange" class="btn btn-primary" style="display: none;">应用</button>
            </div>
            <button id="exportData" class="btn btn-success ml-2">
                <i class="bi bi-download"></i> 导出数据
            </button>
        </div>
    </div>

    <!-- 统计卡片区域 -->
    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-icon bg-primary"><i class="bi bi-mouse"></i></div>
            <div class="stat-content">
                <div class="stat-number" id="totalClicks">--</div>
                <div class="stat-label">总点击量</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon bg-success"><i class="bi bi-shopping-cart"></i></div>
            <div class="stat-content">
                <div class="stat-number" id="totalOrders">--</div>
                <div class="stat-label">总订单量</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon bg-warning"><i class="bi bi-currency-yuan"></i></div>
            <div class="stat-content">
                <div class="stat-number" id="totalRevenue">¥--</div>
                <div class="stat-label">总交易额</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon bg-info"><i class="bi bi-percent"></i></div>
            <div class="stat-content">
                <div class="stat-number" id="conversionRate">--%</div>
                <div class="stat-label">平均转化率</div>
            </div>
        </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="content-area">
        <!-- 图表区域 -->
        <div class="chart-section">
            <div class="section-header">
                <h2><i class="bi bi-line-chart"></i> 转化率趋势</h2>
                <div class="chart-controls">
                    <select id="chartAgentFilter" class="form-select">
                        <option value="0">所有代理</option>
                        <!-- 代理选项将通过JavaScript动态加载 -->
                    </select>
                </div>
            </div>
            <div class="chart-container">
                <div id="conversionTrendChart" style="width: 100%; height: 400px;"></div>
            </div>
        </div>

        <!-- 数据表格区域 -->
        <div class="table-section">
            <div class="section-header">
                <h2><i class="bi bi-table"></i> 代理推广效果</h2>
                <div class="table-controls">
                    <div class="search-box">
                        <input type="text" id="agentSearch" class="form-control" placeholder="搜索代理名称...">
                    </div>
                    <select id="agentLevelFilter" class="form-select">
                        <option value="0">所有等级</option>
                        <option value="1">一级代理</option>
                        <option value="2">二级代理</option>
                        <option value="3">三级代理</option>
                    </select>
                    <select id="sortBy" class="form-select">
                        <option value="conversion_rate">转化率排序</option>
                        <option value="clicks">点击量排序</option>
                        <option value="orders">订单量排序</option>
                        <option value="revenue">交易额排序</option>
                    </select>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>代理名称</th>
                            <th>代理等级</th>
                            <th>团队规模</th>
                            <th>点击量</th>
                            <th>注册量</th>
                            <th>订单量</th>
                            <th>转化率</th>
                            <th>平均订单金额</th>
                            <th>总交易额</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody id="agentsTableBody">
                        <!-- 表格数据将通过JavaScript动态加载 -->
                        <tr>
                            <td colspan="10" class="text-center">
                                <div class="loading">加载中...</div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- 分页控件 -->
            <div class="pagination-controls" id="paginationControls">
                <!-- 分页将通过JavaScript动态生成 -->
            </div>
        </div>
    </div>
</div>

<!-- 代理详情模态框 -->
<div class="modal fade" id="agentDetailsModal" tabindex="-1" aria-labelledby="agentDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="agentDetailsModalLabel">代理详情</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="agentDetailsContent">
                    <!-- 代理详情内容将通过JavaScript动态加载 -->
                    <div class="loading">加载中...</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                <button type="button" id="exportAgentDetails" class="btn btn-success">导出详情</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
<script>
    // 全局变量
    let currentPage = 1;
    const pageSize = 20;
    let agentsList = [];
    let conversionTrendChart = null;
    
    // 页面加载完成后执行
    document.addEventListener('DOMContentLoaded', function() {
        // 初始化图表
        initCharts();
        
        // 加载代理列表到下拉框
        loadAgentsList();
        
        // 加载初始数据
        loadDashboardData();
        loadAgentsData();
        
        // 绑定事件监听器
        bindEventListeners();
    });
    
    // 初始化图表
    function initCharts() {
        // 初始化转化率趋势图表
        conversionTrendChart = echarts.init(document.getElementById('conversionTrendChart'));
        
        // 设置初始图表配置
        const option = {
            title: {
                text: '转化率趋势分析',
                left: 'center'
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                }
            },
            legend: {
                data: ['转化率(%)', '点击量', '订单量'],
                bottom: 0
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '10%',
                containLabel: true
            },
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: [],
                    name: '日期'
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '转化率(%)',
                    position: 'left'
                },
                {
                    type: 'value',
                    name: '数量',
                    position: 'right'
                }
            ],
            series: [
                {
                    name: '转化率(%)',
                    type: 'line',
                    data: [],
                    smooth: true,
                    itemStyle: {
                        color: '#16a34a'
                    }
                },
                {
                    name: '点击量',
                    type: 'line',
                    yAxisIndex: 1,
                    data: [],
                    smooth: true,
                    itemStyle: {
                        color: '#2563eb'
                    }
                },
                {
                    name: '订单量',
                    type: 'line',
                    yAxisIndex: 1,
                    data: [],
                    smooth: true,
                    itemStyle: {
                        color: '#d97706'
                    }
                }
            ]
        };
        
        conversionTrendChart.setOption(option);
        
        // 监听窗口大小变化，自动调整图表大小
        window.addEventListener('resize', function() {
            conversionTrendChart.resize();
        });
    }
    
    // 加载代理列表
    function loadAgentsList() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '../api/admin/agent_management.php?action=get_agents');
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success && response.data) {
                        const selectElement = document.getElementById('chartAgentFilter');
                        response.data.forEach(agent => {
                            const option = document.createElement('option');
                            option.value = agent.id;
                            option.textContent = agent.contact_name;
                            selectElement.appendChild(option);
                        });
                    }
                } catch (error) {
                    console.error('解析代理列表失败:', error);
                }
            }
        };
        xhr.onerror = function() {
            console.error('加载代理列表失败');
        };
        xhr.send();
    }
    
    // 加载仪表盘数据
    function loadDashboardData() {
        const dateRange = document.getElementById('dateRange').value;
        let startDate = '';
        let endDate = '';
        
        if (dateRange === 'custom') {
            startDate = document.getElementById('startDate').value;
            endDate = document.getElementById('endDate').value;
            
            // 如果没有选择自定义日期，使用默认值
            if (!startDate || !endDate) {
                showToast('请选择自定义日期范围', 'error');
                return;
            }
        }
        
        const xhr = new XMLHttpRequest();
        let url = `../api/analytics/agent_analytics.php?action=dashboard_summary&date_range=${dateRange}`;
        
        if (startDate && endDate) {
            url += `&start_date=${startDate}&end_date=${endDate}`;
        }
        
        xhr.open('GET', url);
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success && response.data) {
                        const summary = response.data.summary;
                        
                        // 更新统计卡片
                        document.getElementById('totalClicks').textContent = summary.total_clicks.toLocaleString();
                        document.getElementById('totalOrders').textContent = summary.total_orders.toLocaleString();
                        document.getElementById('totalRevenue').textContent = '¥' + summary.total_revenue.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                        document.getElementById('conversionRate').textContent = summary.average_conversion_rate.toFixed(2) + '%';
                        
                        // 更新趋势图
                        if (response.data.conversion_trend && response.data.conversion_trend.length > 0) {
                            updateTrendChart(response.data.conversion_trend);
                        }
                    }
                } catch (error) {
                    console.error('解析仪表盘数据失败:', error);
                    showToast('加载数据失败', 'error');
                }
            } else {
                showToast('加载数据失败', 'error');
            }
        };
        xhr.onerror = function() {
            console.error('加载仪表盘数据失败');
            showToast('网络错误，请重试', 'error');
        };
        xhr.send();
    }
    
    // 更新趋势图表
    function updateTrendChart(data) {
        const dates = data.map(item => item.date);
        const conversionRates = data.map(item => item.conversion_rate);
        const clicks = data.map(item => item.total_clicks);
        const orders = data.map(item => item.orders);
        
        conversionTrendChart.setOption({
            xAxis: {
                data: dates
            },
            series: [
                {
                    data: conversionRates
                },
                {
                    data: clicks
                },
                {
                    data: orders
                }
            ]
        });
    }
    
    // 加载代理数据表格
    function loadAgentsData(page = 1) {
        currentPage = page;
        
        const dateRange = document.getElementById('dateRange').value;
        const levelFilter = document.getElementById('agentLevelFilter').value;
        const searchTerm = document.getElementById('agentSearch').value;
        
        let startDate = '';
        let endDate = '';
        
        if (dateRange === 'custom') {
            startDate = document.getElementById('startDate').value;
            endDate = document.getElementById('endDate').value;
        }
        
        let url = `../api/analytics/agent_analytics.php?action=conversion_stats&level=${levelFilter}`;
        
        if (startDate && endDate) {
            url += `&start_date=${startDate}&end_date=${endDate}`;
        } else {
            url += `&date_range=${dateRange}`;
        }
        
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success && response.data) {
                        // 保存原始数据用于搜索和排序
                        agentsList = response.data;
                        
                        // 应用搜索和排序
                        filterAndSortAgents(searchTerm);
                    } else {
                        document.getElementById('agentsTableBody').innerHTML = `
                            <tr>
                                <td colspan="10" class="text-center text-danger">
                                    ${response.message || '加载数据失败'}
                                </td>
                            </tr>
                        `;
                    }
                } catch (error) {
                    console.error('解析代理数据失败:', error);
                    document.getElementById('agentsTableBody').innerHTML = `
                        <tr>
                            <td colspan="10" class="text-center text-danger">数据解析错误</td>
                        </tr>
                    `;
                }
            } else {
                document.getElementById('agentsTableBody').innerHTML = `
                    <tr>
                        <td colspan="10" class="text-center text-danger">加载失败，请重试</td>
                    </tr>
                `;
            }
        };
        xhr.onerror = function() {
            console.error('加载代理数据失败');
            document.getElementById('agentsTableBody').innerHTML = `
                <tr>
                    <td colspan="10" class="text-center text-danger">网络错误，请检查连接</td>
                </tr>
            `;
        };
        xhr.send();
    }
    
    // 筛选和排序代理数据
    function filterAndSortAgents(searchTerm) {
        let filteredData = agentsList;
        
        // 应用搜索过滤
        if (searchTerm) {
            filteredData = filteredData.filter(agent => 
                agent.agent_name.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        
        // 应用排序
        const sortBy = document.getElementById('sortBy').value;
        filteredData.sort((a, b) => {
            switch (sortBy) {
                case 'conversion_rate':
                    return b.conversion_rate - a.conversion_rate;
                case 'clicks':
                    return b.total_clicks - a.total_clicks;
                case 'orders':
                    return b.orders - a.orders;
                case 'revenue':
                    return (b.order_amount || 0) - (a.order_amount || 0);
                default:
                    return b.conversion_rate - a.conversion_rate;
            }
        });
        
        // 应用分页
        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = startIndex + pageSize;
        const paginatedData = filteredData.slice(startIndex, endIndex);
        
        // 更新表格
        renderAgentsTable(paginatedData);
        
        // 更新分页控件
        renderPagination(filteredData.length);
    }
    
    // 渲染代理数据表格
    function renderAgentsTable(data) {
        const tableBody = document.getElementById('agentsTableBody');
        
        if (data.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="10" class="text-center">未找到符合条件的代理</td>
                </tr>
            `;
            return;
        }
        
        let html = '';
        data.forEach(agent => {
            html += `
                <tr>
                    <td>${agent.agent_name}</td>
                    <td>第${agent.level}级代理</td>
                    <td>${agent.team_size}</td>
                    <td>${agent.total_clicks}</td>
                    <td>${agent.registrations || 0}</td>
                    <td>${agent.orders || 0}</td>
                    <td class="${agent.conversion_rate > 5 ? 'text-success' : agent.conversion_rate > 2 ? 'text-warning' : 'text-danger'}">
                        ${agent.conversion_rate.toFixed(2)}%
                    </td>
                    <td>¥${(agent.avg_order_value || 0).toFixed(2)}</td>
                    <td>¥${(agent.order_amount || 0).toFixed(2)}</td>
                    <td>
                        <button class="btn btn-sm btn-info view-details" data-id="${agent.agent_id}">
                            <i class="bi bi-eye"></i> 详情
                        </button>
                    </td>
                </tr>
            `;
        });
        
        tableBody.innerHTML = html;
        
        // 绑定详情按钮事件
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', function() {
                const agentId = this.getAttribute('data-id');
                viewAgentDetails(agentId);
            });
        });
    }
    
    // 渲染分页控件
    function renderPagination(totalItems) {
        const totalPages = Math.ceil(totalItems / pageSize);
        const paginationControls = document.getElementById('paginationControls');
        
        if (totalPages <= 1) {
            paginationControls.innerHTML = '';
            return;
        }
        
        let html = `
            <nav>
                <ul class="pagination justify-content-center">
                    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">上一页</a>
                    </li>
        `;
        
        // 生成页码按钮
        const maxButtons = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxButtons / 2));
        let endPage = Math.min(totalPages, startPage + maxButtons - 1);
        
        if (endPage - startPage + 1 < maxButtons) {
            startPage = Math.max(1, endPage - maxButtons + 1);
        }
        
        // 首页按钮
        if (startPage > 1) {
            html += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
            if (startPage > 2) {
                html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
            }
        }
        
        // 中间页码按钮
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <li class="page-item ${currentPage === i ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `;
        }
        
        // 末页按钮
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
            }
            html += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a></li>`;
        }
        
        html += `
                    <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">下一页</a>
                    </li>
                </ul>
            </nav>
        `;
        
        paginationControls.innerHTML = html;
        
        // 绑定分页按钮事件
        document.querySelectorAll('.pagination .page-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const page = parseInt(this.getAttribute('data-page'));
                if (!isNaN(page) && page > 0) {
                    loadAgentsData(page);
                }
            });
        });
    }
    
    // 查看代理详情
    function viewAgentDetails(agentId) {
        const modalContent = document.getElementById('agentDetailsContent');
        modalContent.innerHTML = '<div class="loading">加载中...</div>';
        
        const dateRange = document.getElementById('dateRange').value;
        let startDate = '';
        let endDate = '';
        
        if (dateRange === 'custom') {
            startDate = document.getElementById('startDate').value;
            endDate = document.getElementById('endDate').value;
        }
        
        let url = `../api/analytics/agent_analytics.php?action=agent_details&agent_id=${agentId}`;
        
        if (startDate && endDate) {
            url += `&start_date=${startDate}&end_date=${endDate}`;
        } else {
            url += `&date_range=${dateRange}`;
        }
        
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success && response.data) {
                        renderAgentDetails(response.data);
                    } else {
                        modalContent.innerHTML = `<div class="text-danger">${response.message || '加载详情失败'}</div>`;
                    }
                } catch (error) {
                    console.error('解析代理详情失败:', error);
                    modalContent.innerHTML = '<div class="text-danger">数据解析错误</div>';
                }
            } else {
                modalContent.innerHTML = '<div class="text-danger">加载失败，请重试</div>';
            }
        };
        xhr.onerror = function() {
            console.error('加载代理详情失败');
            modalContent.innerHTML = '<div class="text-danger">网络错误，请检查连接</div>';
        };
        xhr.send();
        
        // 打开模态框
        const modal = new bootstrap.Modal(document.getElementById('agentDetailsModal'));
        modal.show();
        
        // 保存当前代理ID到导出按钮
        document.getElementById('exportAgentDetails').setAttribute('data-id', agentId);
    }
    
    // 渲染代理详情
    function renderAgentDetails(data) {
        const { agent_info, summary, trend, team_performance } = data;
        
        let html = `
            <div class="agent-details-container">
                <!-- 代理基本信息 -->
                <div class="agent-info-card">
                    <h3>${agent_info.contact_name} - 详细数据</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <label>代理等级：</label>
                            <span>第${agent_info.level}级代理</span>
                        </div>
                        <div class="info-item">
                            <label>状态：</label>
                            <span class="badge bg-${agent_info.status === 'active' ? 'success' : 'secondary'}">
                                ${agent_info.status === 'active' ? '活跃' : '非活跃'}
                            </span>
                        </div>
                        <div class="info-item">
                            <label>加入时间：</label>
                            <span>${agent_info.created_at}</span>
                        </div>
                    </div>
                </div>
                
                <!-- 关键指标 -->
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-title">总点击量</div>
                        <div class="metric-value">${summary.total_clicks}</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">独立访客</div>
                        <div class="metric-value">${summary.unique_clicks}</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">注册转化率</div>
                        <div class="metric-value ${summary.registration_rate > 10 ? 'text-success' : 'text-warning'}">
                            ${summary.registration_rate.toFixed(2)}%
                        </div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">订单转化率</div>
                        <div class="metric-value ${summary.conversion_rate > 5 ? 'text-success' : 'text-warning'}">
                            ${summary.conversion_rate.toFixed(2)}%
                        </div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">总交易额</div>
                        <div class="metric-value">¥${summary.revenue.toFixed(2)}</div>
                    </div>
                </div>
                
                <!-- 趋势图表 -->
                <div class="trend-section">
                    <h4>推广趋势</h4>
                    <div id="agentTrendChart" style="width: 100%; height: 300px;"></div>
                </div>
                
                <!-- 团队表现 -->
                ${team_performance && team_performance.length > 0 ? `
                    <div class="team-section">
                        <h4>团队成员表现</h4>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>代理名称</th>
                                        <th>点击量</th>
                                        <th>订单量</th>
                                        <th>总交易额</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${team_performance.map(member => `
                                        <tr>
                                            <td>${member.agent_name}</td>
                                            <td>${member.total_clicks}</td>
                                            <td>${member.orders || 0}</td>
                                            <td>¥${(member.revenue || 0).toFixed(2)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
        
        document.getElementById('agentDetailsContent').innerHTML = html;
        
        // 初始化趋势图表
        initAgentTrendChart(trend);
    }
    
    // 初始化代理个人趋势图表
    function initAgentTrendChart(data) {
        const chartDom = document.getElementById('agentTrendChart');
        const agentChart = echarts.init(chartDom);
        
        const dates = data.map(item => item.date);
        const conversionRates = data.map(item => item.conversion_rate);
        const clicks = data.map(item => item.total_clicks);
        const orders = data.map(item => item.orders);
        
        const option = {
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['转化率(%)', '点击量', '订单量']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: dates
            },
            yAxis: [
                {
                    type: 'value',
                    name: '转化率(%)'
                },
                {
                    type: 'value',
                    name: '数量'
                }
            ],
            series: [
                {
                    name: '转化率(%)',
                    type: 'line',
                    data: conversionRates,
                    smooth: true,
                    itemStyle: {
                        color: '#dc2626'
                    }
                },
                {
                    name: '点击量',
                    type: 'line',
                    yAxisIndex: 1,
                    data: clicks,
                    smooth: true,
                    itemStyle: {
                        color: '#0284c7'
                    }
                },
                {
                    name: '订单量',
                    type: 'line',
                    yAxisIndex: 1,
                    data: orders,
                    smooth: true,
                    itemStyle: {
                        color: '#4d7c0f'
                    }
                }
            ]
        };
        
        agentChart.setOption(option);
        
        // 监听窗口大小变化
        window.addEventListener('resize', function() {
            agentChart.resize();
        });
    }
    
    // 绑定所有事件监听器
    function bindEventListeners() {
        // 日期范围选择器变化
        document.getElementById('dateRange').addEventListener('change', function() {
            const showCustom = this.value === 'custom';
            document.getElementById('startDate').style.display = showCustom ? 'inline-block' : 'none';
            document.getElementById('endDate').style.display = showCustom ? 'inline-block' : 'none';
            document.getElementById('applyDateRange').style.display = showCustom ? 'inline-block' : 'none';
            
            if (!showCustom) {
                loadDashboardData();
                loadAgentsData(1);
            }
        });
        
        // 应用自定义日期
        document.getElementById('applyDateRange').addEventListener('click', function() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate) {
                showToast('请选择完整的日期范围', 'error');
                return;
            }
            
            if (new Date(startDate) > new Date(endDate)) {
                showToast('开始日期不能晚于结束日期', 'error');
                return;
            }
            
            loadDashboardData();
            loadAgentsData(1);
        });
        
        // 图表代理筛选
        document.getElementById('chartAgentFilter').addEventListener('change', function() {
            const agentId = this.value;
            loadConversionTrend(agentId);
        });
        
        // 搜索框输入事件
        document.getElementById('agentSearch').addEventListener('input', function() {
            filterAndSortAgents(this.value);
        });
        
        // 等级筛选变化
        document.getElementById('agentLevelFilter').addEventListener('change', function() {
            loadAgentsData(1);
        });
        
        // 排序方式变化
        document.getElementById('sortBy').addEventListener('change', function() {
            const searchTerm = document.getElementById('agentSearch').value;
            filterAndSortAgents(searchTerm);
        });
        
        // 导出按钮点击
        document.getElementById('exportData').addEventListener('click', function() {
            exportAnalyticsData();
        });
        
        // 导出代理详情
        document.getElementById('exportAgentDetails').addEventListener('click', function() {
            const agentId = this.getAttribute('data-id');
            exportAgentDetails(agentId);
        });
    }
    
    // 加载转化率趋势数据
    function loadConversionTrend(agentId) {
        const dateRange = document.getElementById('dateRange').value;
        let startDate = '';
        let endDate = '';
        
        if (dateRange === 'custom') {
            startDate = document.getElementById('startDate').value;
            endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate) {
                return;
            }
        }
        
        let url = `../api/analytics/agent_analytics.php?action=conversion_trend&agent_id=${agentId}`;
        
        if (startDate && endDate) {
            url += `&start_date=${startDate}&end_date=${endDate}`;
        } else {
            url += `&date_range=${dateRange}`;
        }
        
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success && response.data) {
                        updateTrendChart(response.data);
                    }
                } catch (error) {
                    console.error('解析趋势数据失败:', error);
                }
            }
        };
        xhr.send();
    }
    
    // 导出分析数据
    function exportAnalyticsData() {
        const dateRange = document.getElementById('dateRange').value;
        let startDate = '';
        let endDate = '';
        
        if (dateRange === 'custom') {
            startDate = document.getElementById('startDate').value;
            endDate = document.getElementById('endDate').value;
        }
        
        let url = `../api/analytics/export.php?type=agent_analytics`;
        
        if (startDate && endDate) {
            url += `&start_date=${startDate}&end_date=${endDate}`;
        } else {
            url += `&date_range=${dateRange}`;
        }
        
        window.location.href = url;
    }
    
    // 导出代理详情
    function exportAgentDetails(agentId) {
        const dateRange = document.getElementById('dateRange').value;
        let startDate = '';
        let endDate = '';
        
        if (dateRange === 'custom') {
            startDate = document.getElementById('startDate').value;
            endDate = document.getElementById('endDate').value;
        }
        
        let url = `../api/analytics/export.php?type=agent_details&agent_id=${agentId}`;
        
        if (startDate && endDate) {
            url += `&start_date=${startDate}&end_date=${endDate}`;
        } else {
            url += `&date_range=${dateRange}`;
        }
        
        window.location.href = url;
    }
    
    // 显示提示信息
    function showToast(message, type = 'info') {
        const toastContainer = document.createElement('div');
        toastContainer.className = `toast toast-${type} show`;
        toastContainer.style.position = 'fixed';
        toastContainer.style.top = '20px';
        toastContainer.style.right = '20px';
        toastContainer.style.zIndex = '9999';
        toastContainer.style.padding = '12px 20px';
        toastContainer.style.borderRadius = '4px';
        toastContainer.style.color = 'white';
        toastContainer.style.backgroundColor = type === 'success' ? '#16a34a' : 
                                              type === 'error' ? '#dc2626' : 
                                              type === 'warning' ? '#d97706' : '#3b82f6';
        toastContainer.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        
        toastContainer.textContent = message;
        document.body.appendChild(toastContainer);
        
        setTimeout(() => {
            toastContainer.classList.remove('show');
            toastContainer.classList.add('fade');
            setTimeout(() => {
                document.body.removeChild(toastContainer);
            }, 300);
        }, 3000);
    }
</script>

<?php
// 加载页面脚
include_once 'footer.php';