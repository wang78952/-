<?php
/**
 * 管理后台首页
 * 支持管理员和商户用户两种角色视图
 * 
 * Copyright © 2025 远
 * 未经授权禁止传播或用于商业用途
 */

// 加载文件监控钩子，确保核心文件完整性
if (file_exists(__DIR__ . '/../includes/file_monitor_hook.php')) {
    include_once __DIR__ . '/../includes/file_monitor_hook.php';
}

require_once '../config.php';
require_once '../includes/AuthManager.php';
require_once '../includes/Database.php';

// 启动会话
session_start();

// 检查登录权限
$authManager = new AuthManager();
if (!$authManager->isLoggedIn() || !in_array($_SESSION['user_role'], ['admin', 'business_admin', 'merchant'])) {
    header('Location: ../login.php');
    exit;
}

// 获取当前用户信息
$currentUser = $authManager->getCurrentUser();
$userRole = $currentUser['role'];
$isMerchant = $userRole === 'merchant';
$isAdmin = in_array($userRole, ['admin', 'business_admin']);

// 获取数据库连接
$db = Database::getInstance();

// 初始化统计数据
$stats = [
    'today_orders' => 0,
    'today_revenue' => 0,
    'today_activation_rate' => 0,
    'low_stock_items' => [],
    'total_users' => 0,
    'total_cards' => 0,
    'active_cards' => 0,
    'total_orders' => 0,
    'pending_orders' => 0,
    'completed_orders' => 0,
    'total_revenue' => 0
];

// 获取商户特定数据（适用于所有角色）
try {
    // 今日订单
    $stats['today_orders'] = $db->queryOne("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()")['count'];
    
    // 今日收入
    $stats['today_revenue'] = $db->queryOne("SELECT COALESCE(SUM(amount), 0) as total FROM orders WHERE status = 'completed' AND DATE(created_at) = CURDATE()")['total'];
    
    // 计算今日激活率
    $todayActiveCards = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'active' AND DATE(activated_at) = CURDATE()")['count'];
    $todayTotalCards = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE DATE(created_at) = CURDATE()")['count'];
    $stats['today_activation_rate'] = $todayTotalCards > 0 ? round(($todayActiveCards / $todayTotalCards) * 100, 2) : 0;
    
    // 获取库存预警（低于10张的商品）
    $stats['low_stock_items'] = $db->query("SELECT p.name, COUNT(c.id) as stock_count FROM products p LEFT JOIN cards c ON p.id = c.product_id AND c.status = 'active' GROUP BY p.id, p.name HAVING COUNT(c.id) < 10 AND p.id IS NOT NULL");
    
} catch (Exception $e) {
    error_log("统计数据获取失败: " . $e->getMessage());
}

// 获取管理员完整统计数据
if ($isAdmin) {
    try {
        // 用户统计
        $stats['total_users'] = $db->queryOne("SELECT COUNT(*) as count FROM users")['count'];
        
        // 卡片统计
        $stats['total_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards")['count'];
        $stats['active_cards'] = $db->queryOne("SELECT COUNT(*) as count FROM cards WHERE status = 'active'")['count'];
        
        // 订单统计
        $stats['total_orders'] = $db->queryOne("SELECT COUNT(*) as count FROM orders")['count'];
        $stats['pending_orders'] = $db->queryOne("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")['count'];
        $stats['completed_orders'] = $db->queryOne("SELECT COUNT(*) as count FROM orders WHERE status = 'completed'")['count'];
        
        // 收入统计
        $stats['total_revenue'] = $db->queryOne("SELECT COALESCE(SUM(amount), 0) as total FROM orders WHERE status = 'completed'")['total'];
        
    } catch (Exception $e) {
        error_log("管理员统计数据获取失败: " . $e->getMessage());
    }
    
    // 获取最近活动
    $recent_activities = [];
    try {
        $recent_activities = $db->query("
            SELECT ul.*, u.username 
            FROM user_logs ul 
            LEFT JOIN users u ON ul.user_id = u.id 
            ORDER BY ul.created_at DESC 
            LIMIT 10
        ");
    } catch (Exception $e) {
        error_log("最近活动获取失败: " . $e->getMessage());
    }
    
    // 获取系统告警
    $system_alerts = [];
    try {
        $system_alerts = $db->query("
            SELECT * FROM alert_logs 
            WHERE status = 'active' 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
    } catch (Exception $e) {
        error_log("系统告警获取失败: " . $e->getMessage());
    }
}

// 检查是否需要显示新手引导
$showGuide = false;
if ($isAdmin && isset($_SESSION['login_count']) && $_SESSION['login_count'] <= 3) {
    // 检查是否已完成引导步骤
    $guideSteps = [
        'payment_config' => isset($_SESSION['guide_payment_config']) && $_SESSION['guide_payment_config'],
        'test_card_import' => isset($_SESSION['guide_test_card_import']) && $_SESSION['guide_test_card_import'],
        'first_order' => isset($_SESSION['guide_first_order']) && $_SESSION['guide_first_order']
    ];
    
    // 如果有任何步骤未完成，显示引导
    $showGuide = !($guideSteps['payment_config'] && $guideSteps['test_card_import'] && $guideSteps['first_order']);
}

?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员控制台 - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/ui-components.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
            line-height: 1.6;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            padding: 20px 0;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        
        .sidebar-header h2 {
            font-size: 20px;
            margin-bottom: 5px;
        }
        
        .sidebar-header .user-info {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        
        .sidebar-menu a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: background 0.3s ease;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: #34495e;
        }
        
        .sidebar-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 24px;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-warning {
            background: #f39c12;
            color: white;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .stat-change {
            font-size: 12px;
            color: #27ae60;
        }
        
        .stat-card.users { border-left: 4px solid #3498db; }
        .stat-card.cards { border-left: 4px solid #9b59b6; }
        .stat-card.orders { border-left: 4px solid #e67e22; }
        .stat-card.revenue { border-left: 4px solid #27ae60; }
        .stat-card.activation { border-left: 4px solid #9b59b6; }
        
        /* 快速操作区样式 */
        .quick-actions {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .quick-actions h3 {
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .action-btn {
            background: white;
            border: 2px solid #ecf0f1;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: #2c3e50;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-color: #3498db;
        }
        
        .action-icon {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .action-text {
            font-weight: bold;
        }
        
        /* 库存预警样式 */
        .stock-alert .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .alert-count {
            background: #e74c3c;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
        }
        
        .no-alerts {
            text-align: center;
            padding: 40px;
            color: #27ae60;
            font-size: 16px;
        }
        
        .stock-list {
            list-style: none;
        }
        
        .stock-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .stock-item:last-child {
            border-bottom: none;
        }
        
        .restock-btn {
            background: #3498db;
            color: white;
            padding: 4px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 12px;
        }
        
        /* 常见问题浮窗样式 */
        .faq-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .faq-content {
            background: white;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .faq-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .faq-header h3 {
            margin: 0;
        }
        
        .close-faq, .close-guide {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #7f8c8d;
        }
        
        .faq-body {
            padding: 20px;
        }
        
        .faq-item {
            margin-bottom: 20px;
        }
        
        .faq-question {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 8px;
            cursor: pointer;
        }
        
        .faq-answer {
            color: #7f8c8d;
            line-height: 1.6;
        }
        
        /* 新手引导气泡样式 */
        .guide-bubble {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            width: 300px;
            z-index: 999;
        }
        
        .guide-content {
            padding: 20px;
        }
        
        .guide-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .guide-header h3 {
            margin: 0;
            color: #2c3e50;
        }
        
        .guide-steps {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .step {
            display: flex;
            align-items: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
            gap: 10px;
        }
        
        .step.active {
            background: #e3f2fd;
            border-left: 3px solid #3498db;
        }
        
        .step i {
            width: 20px;
            text-align: center;
        }
        
        .guide-btn {
            margin-left: auto;
            background: #3498db;
            color: white;
            padding: 4px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 12px;
        }
        
        /* 响应式调整 */
        @media (max-width: 768px) {
            .guide-bubble {
                width: 90%;
                right: 5%;
            }
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
        }
        
        .panel {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .panel-header {
            padding: 15px 20px;
            background: #ecf0f1;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .panel-content {
            padding: 20px;
        }
        
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #ecf0f1;
            display: flex;
            align-items: start;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 14px;
            flex-shrink: 0;
        }
        
        .activity-icon.success { background: #d5f4e6; color: #27ae60; }
        .activity-icon.warning { background: #fef5e7; color: #f39c12; }
        .activity-icon.danger { background: #fadbd8; color: #e74c3c; }
        .activity-icon.info { background: #d6eaf8; color: #3498db; }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-text {
            font-size: 14px;
            color: #2c3e50;
            margin-bottom: 4px;
        }
        
        .activity-time {
            font-size: 12px;
            color: #7f8c8d;
        }
        
        .alert-list {
            list-style: none;
        }
        
        .alert-item {
            padding: 12px;
            margin-bottom: 10px;
            border-radius: 4px;
            border-left: 4px solid;
        }
        
        .alert-item.high {
            background: #fadbd8;
            border-left-color: #e74c3c;
        }
        
        .alert-item.medium {
            background: #fef5e7;
            border-left-color: #f39c12;
        }
        
        .alert-item.low {
            background: #d6eaf8;
            border-left-color: #3498db;
        }
        
        .alert-title {
            font-weight: bold;
            margin-bottom: 4px;
        }
        
        .alert-message {
            font-size: 14px;
            color: #2c3e50;
            margin-bottom: 4px;
        }
        
        .alert-time {
            font-size: 12px;
            color: #7f8c8d;
        }
        
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                order: 2;
            }
            
            .main-content {
                order: 1;
            }
            
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>管理控制台</h2>
                <div class="user-info">
                    <?php echo htmlspecialchars($currentUser['username']); ?>
                    <br>
                    <small><?php echo htmlspecialchars($currentUser['role']); ?></small>
                </div>
            </div>
            <ul class="sidebar-menu">
                <?php if ($isMerchant): ?>
                <!-- 商户用户菜单 -->
                <li><a href="index.php" class="active"><i>📊</i>仪表盘</a></li>
                <li><a href="products.php"><i>🛍️</i>产品管理</a></li>
                <li><a href="cards.php"><i>💳</i>卡片管理</a></li>
                <li><a href="orders.php"><i>📦</i>订单管理</a></li>
                <li><a href="settings.php"><i>⚙️</i>我的设置</a></li>
                <li><a href="../logout.php"><i>🚪</i>退出登录</a></li>
                <?php else: ?>
                <!-- 管理员菜单 -->
                <li><a href="index.php" class="active"><i>📊</i>仪表板</a></li>
                <li><a href="users.php"><i>👥</i>用户管理</a></li>
                <li><a href="cards.php"><i>💳</i>卡片管理</a></li>
                <li><a href="orders.php"><i>📦</i>订单管理</a></li>
                <li><a href="products.php"><i>🛍️</i>产品管理</a></li>
                <li><a href="security.php"><i>🔒</i>安全管理</a></li>
                <li><a href="logs.php"><i>📝</i>日志管理</a></li>
                <li><a href="settings.php"><i>⚙️</i>系统设置</a></li>
                <li><a href="../logout.php"><i>🚪</i>退出登录</a></li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- 主要内容 -->
            <div class="main-content">
                <!-- 头部 -->
                <div class="header">
                    <h1><?php echo $isMerchant ? '商户仪表盘' : '管理员仪表板'; ?></h1>
                    <div class="header-actions">
                        <a href="../index.php" class="btn btn-primary">返回前台</a>
                        <a href="settings.php" class="btn btn-warning"><?php echo $isMerchant ? '我的设置' : '系统设置'; ?></a>
                        
                        <!-- 常见问题浮窗按钮（仅商户显示） -->
                        <?php if ($isMerchant): ?>
                        <button class="btn btn-info" id="showFaqBtn">
                            <i>❓</i> 常见问题
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 商户用户视图 -->
                <?php if ($isMerchant): ?>
                
                <!-- 今日数据统计 -->
                <div class="stats-grid">
                    <div class="stat-card orders">
                        <div class="stat-number"><?php echo number_format($stats['today_orders']); ?></div>
                        <div class="stat-label">今日订单</div>
                        <div class="stat-change">实时更新</div>
                    </div>
                    <div class="stat-card revenue">
                        <div class="stat-number">¥<?php echo number_format($stats['today_revenue'], 2); ?></div>
                        <div class="stat-label">今日收入</div>
                        <div class="stat-change">实时统计</div>
                    </div>
                    <div class="stat-card activation">
                        <div class="stat-number"><?php echo number_format($stats['today_activation_rate'], 1); ?>%</div>
                        <div class="stat-label">今日激活率</div>
                        <div class="stat-change">卡片激活情况</div>
                    </div>
                </div>

                <!-- 快速操作区 -->
                <div class="quick-actions">
                    <h3>快速操作</h3>
                    <div class="action-buttons">
                        <a href="products.php?action=add" class="action-btn add-product">
                            <div class="action-icon">🛍️</div>
                            <div class="action-text">创建产品</div>
                        </a>
                        <a href="cards.php?action=import" class="action-btn import-cards">
                            <div class="action-icon">📥</div>
                            <div class="action-text">导入卡密</div>
                        </a>
                        <a href="orders.php" class="action-btn view-orders">
                            <div class="action-icon">🔍</div>
                            <div class="action-text">查询订单</div>
                        </a>
                    </div>
                </div>

                <!-- 库存预警 -->
                <div class="panel stock-alert">
                    <div class="panel-header">
                        <i>⚠️</i> 库存预警
                        <span class="alert-count">(<?php echo count($stats['low_stock_items']); ?>)</span>
                    </div>
                    <div class="panel-content">
                        <?php if (empty($stats['low_stock_items'])): ?>
                            <div class="no-alerts">
                                <i>✅</i> 所有产品库存充足
                            </div>
                        <?php else: ?>
                            <ul class="stock-list">
                                <?php foreach ($stats['low_stock_items'] as $item): ?>
                                    <li class="stock-item">
                                        <div class="stock-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                        <div class="stock-count" style="color: <?php echo $item['stock_count'] < 5 ? '#e74c3c' : '#f39c12'; ?>">
                                            剩余 <?php echo $item['stock_count']; ?> 张
                                        </div>
                                        <a href="cards.php?product_id=<?php echo $item['product_id'] ?? ''; ?>&action=add" class="restock-btn">补充库存</a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- 管理员视图 -->
                <?php else: ?>
                
                <!-- 统计卡片 -->
                <div class="stats-grid">
                    <div class="stat-card users">
                        <div class="stat-number"><?php echo number_format($stats['total_users']); ?></div>
                        <div class="stat-label">总用户数</div>
                        <div class="stat-change">+0 今日新增</div>
                    </div>
                    <div class="stat-card cards">
                        <div class="stat-number"><?php echo number_format($stats['total_cards']); ?></div>
                        <div class="stat-label">总卡片数</div>
                        <div class="stat-change"><?php echo number_format($stats['active_cards']); ?> 活跃</div>
                    </div>
                    <div class="stat-card orders">
                        <div class="stat-number"><?php echo number_format($stats['total_orders']); ?></div>
                        <div class="stat-label">总订单数</div>
                        <div class="stat-change"><?php echo number_format($stats['pending_orders']); ?> 待处理</div>
                    </div>
                    <div class="stat-card revenue">
                        <div class="stat-number">¥<?php echo number_format($stats['total_revenue'], 2); ?></div>
                        <div class="stat-label">总收入</div>
                        <div class="stat-change">+¥<?php echo number_format($stats['today_revenue'], 2); ?> 今日</div>
                    </div>
                </div>

                <!-- 内容区域 -->
                <div class="content-grid">
                    <!-- 最近活动 -->
                    <div class="panel">
                        <div class="panel-header">最近活动</div>
                        <div class="panel-content">
                            <ul class="activity-list">
                                <?php if (empty($recent_activities)): ?>
                                    <li class="activity-item">
                                        <div class="activity-icon info">
                                            <i>ℹ️</i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-text">暂无最近活动</div>
                                            <div class="activity-time">系统运行正常</div>
                                        </div>
                                    </li>
                                <?php else: ?>
                                    <?php foreach ($recent_activities as $activity): ?>
                                        <li class="activity-item">
                                            <div class="activity-icon <?php echo $activity['action_type'] === 'login' ? 'success' : 'info'; ?>">
                                                <i><?php echo $activity['action_type'] === 'login' ? '🔑' : '📝'; ?></i>
                                            </div>
                                            <div class="activity-content">
                                                <div class="activity-text">
                                                    <?php echo htmlspecialchars($activity['username'] ?? '未知用户'); ?> 
                                                    <?php echo htmlspecialchars($activity['action']); ?>
                                                </div>
                                                <div class="activity-time"><?php echo date('Y-m-d H:i:s', strtotime($activity['created_at'])); ?></div>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- 系统告警 -->
                    <div class="panel">
                        <div class="panel-header">系统告警</div>
                        <div class="panel-content">
                            <ul class="alert-list">
                                <?php if (empty($system_alerts)): ?>
                                    <li class="alert-item low">
                                        <div class="alert-title">系统正常</div>
                                        <div class="alert-message">当前没有活跃的告警</div>
                                        <div class="alert-time"><?php echo date('Y-m-d H:i:s'); ?></div>
                                    </li>
                                <?php else: ?>
                                    <?php foreach ($system_alerts as $alert): ?>
                                        <li class="alert-item <?php echo $alert['level']; ?>">
                                            <div class="alert-title"><?php echo htmlspecialchars($alert['title']); ?></div>
                                            <div class="alert-message"><?php echo htmlspecialchars($alert['message']); ?></div>
                                            <div class="alert-time"><?php echo date('Y-m-d H:i:s', strtotime($alert['created_at'])); ?></div>
                                        </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- 新手引导气泡（仅管理员首次登录显示） -->
                <?php if ($showGuide): ?>
                <div class="guide-bubble" id="guideBubble">
                    <div class="guide-content">
                        <div class="guide-header">
                            <h3>🎯 新手引导</h3>
                            <button class="close-guide" onclick="document.getElementById('guideBubble').style.display = 'none'">×</button>
                        </div>
                        <div class="guide-steps">
                            <div class="step <?php echo !isset($guideSteps['payment_config']) || !$guideSteps['payment_config'] ? 'active' : ''; ?>">
                                <i><?php echo isset($guideSteps['payment_config']) && $guideSteps['payment_config'] ? '✅' : '1'; ?></i>
                                <span>完成支付配置</span>
                                <a href="settings.php?tab=payment" class="guide-btn">去配置</a>
                            </div>
                            <div class="step <?php echo !isset($guideSteps['test_card_import']) || !$guideSteps['test_card_import'] ? 'active' : ''; ?>">
                                <i><?php echo isset($guideSteps['test_card_import']) && $guideSteps['test_card_import'] ? '✅' : '2'; ?></i>
                                <span>测试卡密导入</span>
                                <a href="cards.php?action=import" class="guide-btn">去导入</a>
                            </div>
                            <div class="step <?php echo !isset($guideSteps['first_order']) || !$guideSteps['first_order'] ? 'active' : ''; ?>">
                                <i><?php echo isset($guideSteps['first_order']) && $guideSteps['first_order'] ? '✅' : '3'; ?></i>
                                <span>创建首单</span>
                                <a href="products.php" class="guide-btn">去创建</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php endif; ?>
                
                <!-- 常见问题浮窗（所有用户可用，但按钮仅商户显示） -->
                <div class="faq-modal" id="faqModal">
                    <div class="faq-content">
                        <div class="faq-header">
                            <h3>❓ 常见问题</h3>
                            <button class="close-faq" onclick="document.getElementById('faqModal').style.display = 'none'">×</button>
                        </div>
                        <div class="faq-body">
                            <div class="faq-item">
                                <div class="faq-question">如何导入卡密？</div>
                                <div class="faq-answer">在左侧菜单点击"卡片管理"，然后选择"导入卡密"，按格式上传即可。</div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-question">如何设置自动发货？</div>
                                <div class="faq-answer">在产品编辑页面，勾选"启用自动发货"选项即可。</div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-question">订单多久会自动确认？</div>
                                <div class="faq-answer">默认情况下，已支付订单会在24小时后自动确认完成。</div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-question">如何查看详细的销售报表？</div>
                                <div class="faq-answer">在订单管理页面，可以导出销售数据进行详细分析。</div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-question">忘记密码怎么办？</div>
                                <div class="faq-answer">点击登录页面的"忘记密码"，按提示重置密码。</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript for FAQ modal -->
    <script>
        // 显示常见问题浮窗
        document.addEventListener('DOMContentLoaded', function() {
            const faqBtn = document.getElementById('showFaqBtn');
            const faqModal = document.getElementById('faqModal');
            
            if (faqBtn && faqModal) {
                faqBtn.addEventListener('click', function() {
                    faqModal.style.display = 'flex';
                });
            }
            
            // 点击浮窗外区域关闭
            window.addEventListener('click', function(event) {
                if (event.target === faqModal) {
                    faqModal.style.display = 'none';
                }
            });
            
            // 点击常见问题自动展开/折叠
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    const answer = this.nextElementSibling;
                    answer.style.display = answer.style.display === 'none' ? 'block' : 'none';
                });
            });
        });
    </script>
</body>
</html>