/**
 * 数据库性能监控界面的JavaScript辅助函数库
 */

class DatabaseMonitor {
    constructor() {
        // 初始化配置
        this.config = {
            refreshInterval: 60000, // 默认刷新间隔1分钟
            baseUrl: window.location.origin + window.location.pathname,
            chartColors: {
                success: '#198754',
                warning: '#ffc107',
                danger: '#dc3545',
                info: '#0dcaf0',
                secondary: '#6c757d',
                primary: '#0d6efd'
            }
        };
        
        // 存储图表实例
        this.charts = {};
        
        // 定时器引用
        this.refreshTimer = null;
        
        // 初始化事件监听器
        this.initEventListeners();
    }
    
    /**
     * 初始化事件监听器
     */
    initEventListeners() {
        // 绑定刷新按钮事件
        const refreshButtons = document.querySelectorAll('[data-refresh]');
        refreshButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const target = button.getAttribute('data-refresh');
                this.refreshData(target);
            });
        });
        
        // 绑定筛选器事件
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const category = button.getAttribute('data-category');
                const value = button.getAttribute('data-value');
                this.filterData(category, value);
            });
        });
        
        // 绑定编辑任务模态框
        const editTaskModal = document.getElementById('editTaskModal');
        if (editTaskModal) {
            editTaskModal.addEventListener('show.bs.modal', (event) => {
                this.prepareEditTaskForm(event);
            });
        }
        
        // 绑定表单提交增强
        const forms = document.querySelectorAll('form[data-enhanced]');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitForm(form);
            });
        });
    }
    
    /**
     * 启动自动刷新
     * @param {number} interval - 刷新间隔（毫秒）
     */
    startAutoRefresh(interval = null) {
        if (this.refreshTimer) {
            clearInterval(this.refreshTimer);
        }
        
        this.config.refreshInterval = interval || this.config.refreshInterval;
        this.refreshTimer = setInterval(() => {
            this.refreshData('dashboard');
        }, this.config.refreshInterval);
    }
    
    /**
     * 停止自动刷新
     */
    stopAutoRefresh() {
        if (this.refreshTimer) {
            clearInterval(this.refreshTimer);
            this.refreshTimer = null;
        }
    }
    
    /**
     * 刷新指定区域的数据
     * @param {string} target - 目标区域标识
     */
    async refreshData(target) {
        try {
            // 显示加载状态
            this.showLoading(target);
            
            // 根据目标区域构建参数
            const params = new URLSearchParams();
            params.append('action', target);
            params.append('refresh', 'true');
            params.append('timestamp', Date.now());
            
            // 发送请求
            const response = await fetch(this.config.baseUrl + '?' + params.toString(), {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) {
                throw new Error('网络请求失败');
            }
            
            const data = await response.json();
            
            // 更新数据
            this.updateDataDisplay(target, data);
            
            // 更新图表
            this.updateCharts(target, data);
            
        } catch (error) {
            this.showError(target, '数据刷新失败: ' + error.message);
        } finally {
            // 隐藏加载状态
            this.hideLoading(target);
        }
    }
    
    /**
     * 准备编辑任务表单
     * @param {Event} event - 模态框显示事件
     */
    prepareEditTaskForm(event) {
        const button = event.relatedTarget;
        const taskId = button.getAttribute('data-task-id');
        
        if (taskId) {
            // 可以在此处添加预加载任务数据的逻辑
            console.log('准备编辑任务:', taskId);
        }
    }
    
    /**
     * 提交表单并处理响应
     * @param {HTMLFormElement} form - 表单元素
     */
    async submitForm(form) {
        try {
            // 显示加载状态
            const submitButton = form.querySelector('[type="submit"], [data-submit]');
            const originalText = submitButton ? submitButton.innerHTML : '';
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 处理中...';
            }
            
            // 收集表单数据
            const formData = new FormData(form);
            const params = new URLSearchParams(formData);
            
            // 发送请求
            const response = await fetch(form.action || this.config.baseUrl, {
                method: form.method || 'POST',
                headers: {
                    'Accept': 'application/json'
                },
                body: params
            });
            
            const data = await response.json();
            
            // 处理响应
            if (data.success) {
                this.showMessage('success', data.message || '操作成功');
                
                // 如果有指定刷新区域，则刷新数据
                if (form.getAttribute('data-refresh-target')) {
                    this.refreshData(form.getAttribute('data-refresh-target'));
                }
                
                // 关闭模态框（如果在模态框中）
                const modal = form.closest('.modal');
                if (modal) {
                    const modalInstance = bootstrap.Modal.getInstance(modal);
                    modalInstance.hide();
                }
            } else {
                this.showMessage('error', data.message || '操作失败');
            }
            
        } catch (error) {
            this.showMessage('error', '提交失败: ' + error.message);
        } finally {
            // 恢复按钮状态
            const submitButton = form.querySelector('[type="submit"], [data-submit]');
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.innerHTML = originalText;
            }
        }
    }
    
    /**
     * 筛选数据
     * @param {string} category - 分类类型
     * @param {string} value - 筛选值
     */
    filterData(category, value) {
        // 更新按钮状态
        const buttons = document.querySelectorAll(`[data-category="${category}"]`);
        buttons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.getAttribute('data-value') === value) {
                btn.classList.add('active');
            }
        });
        
        // 筛选项目
        const items = document.querySelectorAll(`[data-${category}]`);
        items.forEach(item => {
            if (value === 'all' || item.getAttribute(`data-${category}`) === value) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    /**
     * 初始化图表
     * @param {string} id - 图表容器ID
     * @param {string} type - 图表类型
     * @param {object} data - 初始数据
     * @param {object} options - 图表选项
     */
    initChart(id, type, data, options = {}) {
        const ctx = document.getElementById(id);
        if (!ctx) return null;
        
        // 如果已存在图表实例，先销毁
        if (this.charts[id]) {
            this.charts[id].destroy();
        }
        
        // 合并默认选项
        const defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        };
        
        // 创建新图表
        this.charts[id] = new Chart(ctx, {
            type: type,
            data: data,
            options: { ...defaultOptions, ...options }
        });
        
        return this.charts[id];
    }
    
    /**
     * 更新图表数据
     * @param {string} target - 目标区域
     * @param {object} data - 新数据
     */
    updateCharts(target, data) {
        // 根据目标区域更新不同图表
        switch (target) {
            case 'dashboard':
                // 更新维护状态图表
                if (data.maintenanceStatus && document.getElementById('maintenanceStatusChart')) {
                    this.updateMaintenanceStatusChart(data.maintenanceStatus);
                }
                
                // 更新性能趋势图表
                if (data.performanceTrend && document.getElementById('performanceTrendChart')) {
                    this.updatePerformanceTrendChart(data.performanceTrend);
                }
                break;
                
            case 'fragmentation':
                // 更新碎片分布图
                if (data.fragmentationData && document.getElementById('fragmentationChart')) {
                    this.updateFragmentationChart(data.fragmentationData);
                }
                break;
        }
    }
    
    /**
     * 更新维护状态图表
     * @param {object} data - 维护状态数据
     */
    updateMaintenanceStatusChart(data) {
        const ctx = document.getElementById('maintenanceStatusChart');
        if (!ctx) return;
        
        const chartData = {
            labels: ['运行中', '已完成', '已失败', '未执行'],
            datasets: [{
                data: [
                    data.activeTasks || 0,
                    data.completedTasks || 0,
                    data.failedTasks || 0,
                    data.pendingTasks || 0
                ],
                backgroundColor: [
                    this.config.chartColors.info,
                    this.config.chartColors.success,
                    this.config.chartColors.danger,
                    this.config.chartColors.secondary
                ]
            }]
        };
        
        this.initChart('maintenanceStatusChart', 'doughnut', chartData);
    }
    
    /**
     * 更新性能趋势图表
     * @param {object} data - 性能趋势数据
     */
    updatePerformanceTrendChart(data) {
        const ctx = document.getElementById('performanceTrendChart');
        if (!ctx) return;
        
        const chartData = {
            labels: data.labels || [],
            datasets: [
                {
                    label: '平均查询时间 (ms)',
                    data: data.queryTimes || [],
                    borderColor: this.config.chartColors.primary,
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    borderWidth: 2,
                    tension: 0.3
                },
                {
                    label: '慢查询数量',
                    data: data.slowQueries || [],
                    borderColor: this.config.chartColors.danger,
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    borderWidth: 2,
                    tension: 0.3
                }
            ]
        };
        
        this.initChart('performanceTrendChart', 'line', chartData, {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        });
    }
    
    /**
     * 更新碎片分布图表
     * @param {object} data - 碎片数据
     */
    updateFragmentationChart(data) {
        const ctx = document.getElementById('fragmentationChart');
        if (!ctx) return;
        
        const chartData = {
            labels: ['正常 (<=10%)', '建议优化 (10-20%)', '需要优化 (>20%)'],
            datasets: [{
                data: [
                    data.normalTables || 0,
                    data.warningTables || 0,
                    data.dangerTables || 0
                ],
                backgroundColor: [
                    this.config.chartColors.success,
                    this.config.chartColors.warning,
                    this.config.chartColors.danger
                ]
            }]
        };
        
        this.initChart('fragmentationChart', 'doughnut', chartData);
    }
    
    /**
     * 更新数据显示
     * @param {string} target - 目标区域
     * @param {object} data - 数据对象
     */
    updateDataDisplay(target, data) {
        // 更新各类指标卡片
        if (data.metrics) {
            Object.entries(data.metrics).forEach(([key, value]) => {
                const element = document.getElementById(`metric-${key}`);
                if (element) {
                    element.textContent = value;
                }
            });
        }
        
        // 更新优化建议列表
        if (data.recommendations && target === 'dashboard') {
            this.updateRecommendationsList(data.recommendations);
        }
        
        // 更新任务列表
        if (data.tasks && (target === 'dashboard' || target === 'maintenance_tasks')) {
            this.updateTasksList(data.tasks);
        }
        
        // 更新碎片分析结果
        if (data.fragmentation && target === 'fragmentation') {
            this.updateFragmentationTable(data.fragmentation);
        }
    }
    
    /**
     * 更新优化建议列表
     * @param {array} recommendations - 建议列表
     */
    updateRecommendationsList(recommendations) {
        const container = document.querySelector('.advice-list');
        if (!container) return;
        
        // 清空现有内容
        container.innerHTML = '';
        
        if (recommendations.length === 0) {
            container.innerHTML = '<li class="list-group-item text-center text-muted">暂无优化建议</li>';
            return;
        }
        
        // 添加建议项
        recommendations.slice(0, 5).forEach(advice => {
            const item = document.createElement('li');
            item.className = `list-group-item advice-item severity-${advice.severity.toLowerCase()}`;
            
            item.innerHTML = `
                <div class="d-flex justify-content-between mb-1">
                    <span class="font-weight-medium">${advice.title}</span>
                    <span class="badge severity-${advice.severity.toLowerCase()}">${advice.severity}</span>
                </div>
                <p class="text-sm text-muted mb-1">${advice.description}</p>
                <div class="text-xs text-muted">影响对象: ${advice.affected_entity}</div>
            `;
            
            container.appendChild(item);
        });
    }
    
    /**
     * 更新任务列表
     * @param {array} tasks - 任务列表
     */
    updateTasksList(tasks) {
        const container = document.querySelector('.tasks-list');
        if (!container) return;
        
        // 清空现有内容
        container.innerHTML = '';
        
        if (tasks.length === 0) {
            container.innerHTML = '<li class="list-group-item text-center text-muted">暂无任务</li>';
            return;
        }
        
        // 添加任务项
        tasks.forEach(task => {
            const item = document.createElement('li');
            item.className = 'list-group-item';
            
            item.innerHTML = `
                <div class="d-flex justify-content-between mb-1">
                    <span class="font-weight-medium">${task.name}</span>
                    <span class="badge status-${task.status}">${task.status.charAt(0).toUpperCase() + task.status.slice(1)}</span>
                </div>
                <p class="text-sm text-muted mb-1">开始时间: ${task.start_time ? new Date(task.start_time).toLocaleString() : 'N/A'}</p>
            `;
            
            container.appendChild(item);
        });
    }
    
    /**
     * 更新碎片分析表格
     * @param {array} fragmentationData - 碎片数据
     */
    updateFragmentationTable(fragmentationData) {
        const tbody = document.querySelector('#fragmentation-table tbody');
        if (!tbody) return;
        
        // 清空现有内容
        tbody.innerHTML = '';
        
        if (fragmentationData.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">暂无碎片分析数据</td></tr>';
            return;
        }
        
        // 添加表格行
        fragmentationData.forEach(table => {
            const severity = table.fragmentation > 20 ? 'danger' : (table.fragmentation > 10 ? 'warning' : 'success');
            const statusText = table.fragmentation > 20 ? '需要优化' : (table.fragmentation > 10 ? '建议优化' : '正常');
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${table.name}</td>
                <td>${(table.size / 1024 / 1024).toFixed(2)}</td>
                <td>${(table.fragmentation_size / 1024 / 1024).toFixed(2)}</td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="progress flex-grow-1 mr-2">
                            <div class="progress-bar bg-${severity}" 
                                 style="width: ${Math.min(table.fragmentation, 100)}%" role="progressbar"></div>
                        </div>
                        <span>${table.fragmentation.toFixed(1)}%</span>
                    </div>
                </td>
                <td>
                    <span class="badge bg-${severity}">${statusText}</span>
                </td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-secondary optimize-table-btn" 
                            data-table="${table.name}">
                        <i class="fa fa-wrench"></i> 优化
                    </button>
                </td>
            `;
            
            tbody.appendChild(row);
        });
        
        // 重新绑定优化按钮事件
        this.bindOptimizeButtons();
    }
    
    /**
     * 绑定优化按钮事件
     */
    bindOptimizeButtons() {
        const buttons = document.querySelectorAll('.optimize-table-btn');
        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const table = button.getAttribute('data-table');
                if (table) {
                    this.optimizeTable(table);
                }
            });
        });
    }
    
    /**
     * 优化指定表
     * @param {string} table - 表名
     */
    async optimizeTable(table) {
        if (!confirm(`确定要优化表 ${table} 吗？这可能会暂时锁定表。`)) {
            return;
        }
        
        try {
            // 显示加载状态
            this.showLoading('table-optimization');
            
            // 构建请求
            const params = new URLSearchParams();
            params.append('action', 'force_optimize');
            params.append('table', table);
            
            // 发送请求
            const response = await fetch(this.config.baseUrl, {
                method: 'POST',
                body: params
            });
            
            if (!response.ok) {
                throw new Error('网络请求失败');
            }
            
            const data = await response.json();
            
            if (data.success) {
                this.showMessage('success', `表 ${table} 优化成功`);
                // 刷新碎片分析数据
                this.refreshData('fragmentation');
            } else {
                this.showMessage('error', `优化失败: ${data.message || '未知错误'}`);
            }
            
        } catch (error) {
            this.showMessage('error', '优化操作失败: ' + error.message);
        } finally {
            this.hideLoading('table-optimization');
        }
    }
    
    /**
     * 显示加载状态
     * @param {string} target - 目标区域
     */
    showLoading(target) {
        const container = document.querySelector(`[data-loading="${target}"]`);
        if (container) {
            container.style.display = 'block';
        }
        
        // 也可以添加通用的加载指示器
        const overlay = document.createElement('div');
        overlay.className = 'loading-overlay';
        overlay.style.position = 'absolute';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.zIndex = '1000';
        overlay.innerHTML = '<i class="fa fa-spinner fa-spin fa-3x"></i>';
        
        // 如果是针对特定卡片，添加到卡片中
        const card = document.querySelector(`.card[data-target="${target}"]`);
        if (card) {
            card.style.position = 'relative';
            card.appendChild(overlay);
        }
    }
    
    /**
     * 隐藏加载状态
     * @param {string} target - 目标区域
     */
    hideLoading(target) {
        const container = document.querySelector(`[data-loading="${target}"]`);
        if (container) {
            container.style.display = 'none';
        }
        
        // 移除加载覆盖层
        const overlays = document.querySelectorAll('.loading-overlay');
        overlays.forEach(overlay => overlay.remove());
    }
    
    /**
     * 显示错误消息
     * @param {string} target - 目标区域
     * @param {string} message - 错误消息
     */
    showError(target, message) {
        this.showMessage('error', message);
    }
    
    /**
     * 显示成功消息
     * @param {string} message - 消息内容
     */
    showSuccess(message) {
        this.showMessage('success', message);
    }
    
    /**
     * 显示消息通知
     * @param {string} type - 消息类型 (success, error, warning, info)
     * @param {string} message - 消息内容
     */
    showMessage(type, message) {
        // 检查是否已存在消息元素
        let messageDiv = document.getElementById('notification-message');
        
        if (!messageDiv) {
            // 创建新的消息元素
            messageDiv = document.createElement('div');
            messageDiv.id = 'notification-message';
            messageDiv.className = 'position-fixed bottom-3 right-3 p-3 rounded shadow-lg z-50';
            messageDiv.style.maxWidth = '350px';
            messageDiv.style.minWidth = '300px';
            document.body.appendChild(messageDiv);
        }
        
        // 设置消息样式和内容
        messageDiv.className = `position-fixed bottom-3 right-3 p-3 rounded shadow-lg z-50 alert alert-${type}`;
        messageDiv.innerHTML = `
            ${type === 'success' ? '<i class="fa fa-check-circle mr-2"></i>' : ''}
            ${type === 'error' ? '<i class="fa fa-exclamation-circle mr-2"></i>' : ''}
            ${type === 'warning' ? '<i class="fa fa-exclamation-triangle mr-2"></i>' : ''}
            ${type === 'info' ? '<i class="fa fa-info-circle mr-2"></i>' : ''}
            ${message}
        `;
        
        // 显示消息
        messageDiv.style.display = 'block';
        messageDiv.style.opacity = '0';
        messageDiv.style.transition = 'opacity 0.3s ease';
        
        // 淡入效果
        setTimeout(() => {
            messageDiv.style.opacity = '1';
        }, 10);
        
        // 自动关闭
        setTimeout(() => {
            messageDiv.style.opacity = '0';
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 300);
        }, 5000);
    }
    
    /**
     * 导出性能报告
     * @param {string} format - 导出格式 (csv, json, html)
     */
    async exportReport(format) {
        try {
            // 构建URL
            const url = new URL(this.config.baseUrl);
            url.searchParams.append('action', 'export_report');
            url.searchParams.append('format', format);
            url.searchParams.append('timestamp', Date.now());
            
            // 触发下载
            window.open(url.toString(), '_blank');
            
        } catch (error) {
            this.showMessage('error', '导出报告失败: ' + error.message);
        }
    }
    
    /**
     * 获取任务进度
     * @param {string} taskId - 任务ID
     */
    async getTaskProgress(taskId) {
        try {
            const response = await fetch(this.config.baseUrl, {
                method: 'POST',
                body: new URLSearchParams({
                    action: 'get_task_progress',
                    task_id: taskId
                })
            });
            
            const data = await response.json();
            return data.progress || 0;
            
        } catch (error) {
            console.error('获取任务进度失败:', error);
            return 0;
        }
    }
    
    /**
     * 格式化字节大小
     * @param {number} bytes - 字节数
     * @returns {string} 格式化后的大小字符串
     */
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    /**
     * 初始化性能监控
     */
    initPerformanceMonitoring() {
        // 这里可以添加性能监控相关的初始化代码
        console.log('性能监控已初始化');
    }
}

// 页面加载完成后初始化
window.addEventListener('load', function() {
    // 初始化监控类
    const monitor = new DatabaseMonitor();
    
    // 启动自动刷新
    if (document.body.classList.contains('auto-refresh')) {
        monitor.startAutoRefresh();
    }
    
    // 初始化性能监控
    monitor.initPerformanceMonitoring();
    
    // 绑定导出按钮
    const exportButtons = document.querySelectorAll('[data-export]');
    exportButtons.forEach(button => {
        button.addEventListener('click', () => {
            const format = button.getAttribute('data-export');
            monitor.exportReport(format);
        });
    });
    
    // 将实例暴露到全局，便于调试
    window.databaseMonitor = monitor;
});