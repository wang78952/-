<?php
// 支付接口傻瓜式配置页面
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入配置管理
require_once __DIR__ . '/../includes/ConfigManager.php';
require_once __DIR__ . '/../includes/PaymentManager.php';
require_once __DIR__ . '/../includes/AlipayPayment.php';
require_once __DIR__ . '/../includes/WechatPayment.php';

$configManager = new ConfigManager();
$paymentConfig = $configManager->getPaymentConfig();
$paymentManager = new PaymentManager();

// 获取当前域名，用于自动生成回调地址
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'];
$baseUrl = "$protocol://$domain";
$alipayNotifyUrl = "$baseUrl/payment/alipay/notify";
$alipayReturnUrl = "$baseUrl/payment/alipay/return";
$wechatNotifyUrl = "$baseUrl/payment/wechat/notify";

// 初始化消息
$message = '';
$messageType = 'success';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'save_alipay':
                // 保存支付宝配置
                $alipayConfig = [
                    'app_id' => $_POST['alipay_app_id'] ?? '',
                    'private_key' => $_POST['alipay_private_key'] ?? '',
                    'public_key' => $_POST['alipay_public_key'] ?? '',
                    'sandbox' => isset($_POST['alipay_sandbox']) && $_POST['alipay_sandbox'] === '1',
                    'notify_url' => $alipayNotifyUrl,
                    'return_url' => $alipayReturnUrl
                ];
                
                // 保存配置到文件
                if ($configManager->updatePaymentConfig('alipay', $alipayConfig)) {
                    $message = '支付宝配置保存成功';
                    $messageType = 'success';
                    // 更新新手引导状态
                    if (isset($_SESSION['guide_payment_config'])) {
                        $_SESSION['guide_payment_config'] = true;
                    }
                } else {
                    $message = '配置保存失败，请检查文件权限';
                    $messageType = 'danger';
                }
                break;
                
            case 'save_wechat':
                // 保存微信支付配置
                $wechatConfig = [
                    'app_id' => $_POST['wechat_app_id'] ?? '',
                    'mch_id' => $_POST['wechat_mch_id'] ?? '',
                    'key' => $_POST['wechat_key'] ?? '',
                    'cert_path' => $_POST['wechat_cert_path'] ?? '',
                    'key_path' => $_POST['wechat_key_path'] ?? '',
                    'notify_url' => $wechatNotifyUrl
                ];
                
                // 保存配置到文件
                if ($configManager->updatePaymentConfig('wechat', $wechatConfig)) {
                    $message = '微信支付配置保存成功';
                    $messageType = 'success';
                } else {
                    $message = '配置保存失败，请检查文件权限';
                    $messageType = 'danger';
                }
                break;
                
            case 'test_alipay':
                // 测试支付宝支付
                try {
                    $alipayConfig = [
                        'app_id' => $_POST['alipay_app_id'] ?? '',
                        'private_key' => $_POST['alipay_private_key'] ?? '',
                        'public_key' => $_POST['alipay_public_key'] ?? '',
                        'sandbox' => isset($_POST['alipay_sandbox']) && $_POST['alipay_sandbox'] === '1',
                        'notify_url' => $alipayNotifyUrl,
                        'return_url' => $alipayReturnUrl
                    ];
                    
                    $alipay = new AlipayPayment($alipayConfig);
                    $result = $alipay->createTestPayment();
                    
                    if ($result['success']) {
                        $message = '支付宝测试支付发起成功，请在弹出窗口中完成支付';
                        $messageType = 'success';
                        echo '<script>window.open("' . $result['pay_url'] . '", "_blank", "width=800,height=600");</script>';
                    } else {
                        $message = '支付宝测试失败: ' . $result['error_msg'];
                        $messageType = 'danger';
                    }
                } catch (Exception $e) {
                    $message = '测试失败: ' . $e->getMessage();
                    $messageType = 'danger';
                }
                break;
                
            case 'test_wechat':
                // 测试微信支付
                try {
                    $wechatConfig = [
                        'app_id' => $_POST['wechat_app_id'] ?? '',
                        'mch_id' => $_POST['wechat_mch_id'] ?? '',
                        'key' => $_POST['wechat_key'] ?? '',
                        'cert_path' => $_POST['wechat_cert_path'] ?? '',
                        'key_path' => $_POST['wechat_key_path'] ?? '',
                        'notify_url' => $wechatNotifyUrl
                    ];
                    
                    $wechat = new WechatPayment($wechatConfig);
                    $result = $wechat->createTestPayment();
                    
                    if ($result['success']) {
                        $message = '微信支付测试二维码已生成，请使用微信扫码支付';
                        $messageType = 'success';
                        $_SESSION['wechat_test_qrcode'] = $result['qrcode_url'];
                    } else {
                        $message = '微信支付测试失败: ' . $result['error_msg'];
                        $messageType = 'danger';
                    }
                } catch (Exception $e) {
                    $message = '测试失败: ' . $e->getMessage();
                    $messageType = 'danger';
                }
                break;
        }
        // 重新加载配置
        $paymentConfig = $configManager->getPaymentConfig();
    }
}

// 自动检测环境
$isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
$phpVersion = phpversion();
$hasCurl = extension_loaded('curl');

// 获取微信测试二维码
$wechatTestQrcode = $_SESSION['wechat_test_qrcode'] ?? '';
if ($wechatTestQrcode) {
    unset($_SESSION['wechat_test_qrcode']);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>支付接口傻瓜式配置 - 发卡系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --primary-light: #85a3e0;
            --success: #1cc88a;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --info: #36b9cc;
        }
        
        body {
            background-color: #f8f9fc;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
        
        .sidebar {
            background-color: #2c3e50;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 25px rgba(0,0,0,0.1);
        }
        
        .card-header {
            border-bottom: 1px solid #e9ecef;
            background-color: #f8f9fa;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .btn {
            border-radius: 6px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background-color: #3a5daa;
            border-color: #3a5daa;
            transform: translateY(-1px);
        }
        
        .btn-test {
            background-color: var(--info);
            border-color: var(--info);
            color: white;
        }
        
        .btn-test:hover {
            background-color: #25a1b8;
            border-color: #25a1b8;
        }
        
        .form-control {
            border-radius: 6px;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .alert {
            border-radius: 6px;
            animation: fadeInUp 0.5s ease;
        }
        
        .code-block {
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 12px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            word-break: break-all;
            position: relative;
        }
        
        .copy-btn {
            position: absolute;
            top: 6px;
            right: 6px;
            font-size: 12px;
            padding: 4px 8px;
        }
        
        .tab-content {
            animation: fadeIn 0.5s ease;
        }
        
        .tab-pane {
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* 响应式设计 */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- 侧边栏 -->
    <div class="sidebar">
        <div class="p-4 text-center text-white">
            <h4>发卡系统管理</h4>
            <p class="text-sm text-gray-300">支付接口配置</p>
        </div>
        <ul class="nav flex-column p-2">
            <li class="nav-item mb-2">
                <a href="index.php" class="nav-link text-gray-300 hover:bg-gray-700 p-3 rounded">
                    <i class="bi bi-house me-2"></i> 管理首页
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="payment_config.php" class="nav-link bg-primary text-white p-3 rounded">
                    <i class="bi bi-credit-card me-2"></i> 支付配置
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="cards.php" class="nav-link text-gray-300 hover:bg-gray-700 p-3 rounded">
                    <i class="bi bi-card-list me-2"></i> 卡密管理
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="orders.php" class="nav-link text-gray-300 hover:bg-gray-700 p-3 rounded">
                    <i class="bi bi-file-text me-2"></i> 订单管理
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="users.php" class="nav-link text-gray-300 hover:bg-gray-700 p-3 rounded">
                    <i class="bi bi-people me-2"></i> 用户管理
                </a>
            </li>
            <li class="nav-item mb-2 mt-auto">
                <a href="logout.php" class="nav-link text-gray-300 hover:bg-gray-700 p-3 rounded">
                    <i class="bi bi-box-arrow-right me-2"></i> 退出登录
                </a>
            </li>
        </ul>
    </div>

    <!-- 主内容 -->
    <div class="main-content">
        <!-- 顶部导航 -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
            <div class="container-fluid">
                <button class="btn btn-outline-secondary d-lg-none" type="button">
                    <i class="bi bi-list"></i>
                </button>
                <div class="navbar-text ms-auto">
                    欢迎回来，管理员
                </div>
            </div>
        </nav>

        <!-- 页面标题 -->
        <div class="mb-4">
            <h1 class="h3 text-gray-800">支付接口傻瓜式配置</h1>
            <p class="text-muted">简化的支付宝/微信支付配置，一键测试功能</p>
        </div>

        <!-- 消息提示 -->
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show mb-4" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <!-- 配置选项卡 -->
        <div class="card mb-4">
            <div class="card-body">
                <ul class="nav nav-tabs" id="paymentTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="alipay-tab" data-bs-toggle="tab" data-bs-target="#alipay" type="button" role="tab" aria-controls="alipay" aria-selected="true">
                            <i class="bi bi-alipay me-2"></i> 支付宝配置
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="wechat-tab" data-bs-toggle="tab" data-bs-target="#wechat" type="button" role="tab" aria-controls="wechat" aria-selected="false">
                            <i class="bi bi-wechat me-2"></i> 微信支付配置
                        </button>
                    </li>
                </ul>
                <div class="tab-content mt-4" id="paymentTabsContent">
                    <!-- 支付宝配置 -->
                    <div class="tab-pane fade show active" id="alipay" role="tabpanel" aria-labelledby="alipay-tab">
                        <form method="post" id="alipayForm">
                            <input type="hidden" name="action" value="save_alipay">
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="mb-0">基本配置</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-4">
                                        <label for="alipay_app_id" class="form-label required">应用ID <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="alipay_app_id" name="alipay_app_id" 
                                            value="<?php echo $paymentConfig['alipay']['app_id'] ?? ''; ?>" 
                                            placeholder="请输入支付宝开放平台应用ID" required>
                                        <div class="form-text">从支付宝开放平台获取的应用ID</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="alipay_private_key" class="form-label required">应用私钥 <span class="text-danger">*</span></label>
                                        <textarea class="form-control" id="alipay_private_key" name="alipay_private_key" rows="6" 
                                            placeholder="请输入应用私钥（不要包含首尾标签）" required><?php echo $paymentConfig['alipay']['private_key'] ?? ''; ?></textarea>
                                        <div class="form-text">开发者私钥，用于签名请求</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="alipay_public_key" class="form-label">支付宝公钥</label>
                                        <textarea class="form-control" id="alipay_public_key" name="alipay_public_key" rows="6" 
                                            placeholder="请输入支付宝公钥（可选，有些接口需要）"><?php echo $paymentConfig['alipay']['public_key'] ?? ''; ?></textarea>
                                        <div class="form-text">支付宝公钥，用于验证回调签名</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="mb-0">回调设置（自动生成）</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-4">
                                        <label class="form-label">支付通知地址</label>
                                        <div class="code-block position-relative">
                                            <?php echo $alipayNotifyUrl; ?>
                                            <button type="button" class="btn btn-sm copy-btn" onclick="copyToClipboard(this, '<?php echo $alipayNotifyUrl; ?>')">复制</button>
                                        </div>
                                        <div class="form-text">请在支付宝开放平台配置此回调地址</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">页面跳转地址</label>
                                        <div class="code-block position-relative">
                                            <?php echo $alipayReturnUrl; ?>
                                            <button type="button" class="btn btn-sm copy-btn" onclick="copyToClipboard(this, '<?php echo $alipayReturnUrl; ?>')">复制</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="mb-0">环境设置</h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-check form-switch mb-4">
                                        <input class="form-check-input" type="checkbox" id="alipay_sandbox" name="alipay_sandbox"
                                            <?php echo isset($paymentConfig['alipay']['sandbox']) && $paymentConfig['alipay']['sandbox'] ? 'checked' : ''; ?> value="1">
                                        <label class="form-check-label" for="alipay_sandbox">启用沙箱模式</label>
                                        <div class="form-text">开发测试时请启用沙箱模式</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-center mb-4">
                                <button type="submit" class="btn btn-primary btn-lg me-3">
                                    <i class="bi bi-save me-2"></i> 保存配置
                                </button>
                                <button type="button" class="btn btn-test btn-lg" onclick="testPayment('alipay')">
                                    <i class="bi bi-play-circle me-2"></i> 1分钱测试支付
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- 微信支付配置 -->
                    <div class="tab-pane fade" id="wechat" role="tabpanel" aria-labelledby="wechat-tab">
                        <form method="post" id="wechatForm">
                            <input type="hidden" name="action" value="save_wechat">
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="mb-0">基本配置</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-4">
                                        <label for="wechat_app_id" class="form-label required">AppID <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="wechat_app_id" name="wechat_app_id" 
                                            value="<?php echo $paymentConfig['wechat']['app_id'] ?? ''; ?>" 
                                            placeholder="请输入微信支付AppID" required>
                                        <div class="form-text">微信公众号或小程序的AppID</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="wechat_mch_id" class="form-label required">商户号 <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="wechat_mch_id" name="wechat_mch_id" 
                                            value="<?php echo $paymentConfig['wechat']['mch_id'] ?? ''; ?>" 
                                            placeholder="请输入微信支付商户号" required>
                                        <div class="form-text">微信支付商户平台的商户号</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="wechat_key" class="form-label required">API密钥 <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="wechat_key" name="wechat_key" 
                                            value="<?php echo $paymentConfig['wechat']['key'] ?? ''; ?>" 
                                            placeholder="请输入API密钥" required>
                                        <div class="form-text">在微信支付商户平台设置的API密钥</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="mb-0">回调设置（自动生成）</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-4">
                                        <label class="form-label">支付通知地址</label>
                                        <div class="code-block position-relative">
                                            <?php echo $wechatNotifyUrl; ?>
                                            <button type="button" class="btn btn-sm copy-btn" onclick="copyToClipboard(this, '<?php echo $wechatNotifyUrl; ?>')">复制</button>
                                        </div>
                                        <div class="form-text">请在微信支付商户平台配置此回调地址</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-center mb-4">
                                <button type="submit" class="btn btn-primary btn-lg me-3">
                                    <i class="bi bi-save me-2"></i> 保存配置
                                </button>
                                <button type="button" class="btn btn-test btn-lg" onclick="testPayment('wechat')">
                                    <i class="bi bi-play-circle me-2"></i> 1分钱测试支付
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- 微信测试二维码弹窗 -->
        <?php if ($wechatTestQrcode): ?>
        <div class="modal fade show" id="qrcodeModal" tabindex="-1" role="dialog" aria-labelledby="qrcodeModalLabel" aria-modal="true" style="display: block;">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="qrcodeModalLabel">微信支付测试二维码</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="$('#qrcodeModal').hide();"></button>
                    </div>
                    <div class="modal-body text-center">
                        <p class="mb-3">请使用微信扫码支付0.01元进行测试</p>
                        <img src="<?php echo $wechatTestQrcode; ?>" alt="微信支付测试二维码" style="max-width: 250px; max-height: 250px;">
                        <p class="text-muted mt-3">测试完成后请检查支付状态</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="$('#qrcodeModal').hide();">关闭</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show" onclick="$('#qrcodeModal').hide();"></div>
        <?php endif; ?>
    </div>

    <!-- 脚本 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 复制到剪贴板
        function copyToClipboard(button, text) {
            navigator.clipboard.writeText(text).then(() => {
                const originalText = button.textContent;
                button.textContent = '已复制!';
                button.classList.add('btn-success');
                setTimeout(() => {
                    button.textContent = originalText;
                    button.classList.remove('btn-success');
                }, 2000);
            }).catch(err => {
                console.error('复制失败:', err);
                button.textContent = '复制失败';
                button.classList.add('btn-danger');
                setTimeout(() => {
                    button.textContent = '复制';
                    button.classList.remove('btn-danger');
                }, 2000);
            });
        }

        // 测试支付
        function testPayment(type) {
            if (type === 'alipay') {
                const appId = document.getElementById('alipay_app_id').value;
                const privateKey = document.getElementById('alipay_private_key').value;
                
                if (!appId || !privateKey) {
                    alert('请先填写必填项：应用ID和应用私钥');
                    return;
                }
                
                // 提交测试表单
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.name = 'action';
                actionInput.value = 'test_alipay';
                form.appendChild(actionInput);
                
                const appIdInput = document.createElement('input');
                appIdInput.name = 'alipay_app_id';
                appIdInput.value = appId;
                form.appendChild(appIdInput);
                
                const privateKeyInput = document.createElement('input');
                privateKeyInput.name = 'alipay_private_key';
                privateKeyInput.value = privateKey;
                form.appendChild(privateKeyInput);
                
                const sandboxInput = document.createElement('input');
                sandboxInput.name = 'alipay_sandbox';
                sandboxInput.value = document.getElementById('alipay_sandbox').checked ? '1' : '0';
                form.appendChild(sandboxInput);
                
                document.body.appendChild(form);
                form.submit();
            } else if (type === 'wechat') {
                const appId = document.getElementById('wechat_app_id').value;
                const mchId = document.getElementById('wechat_mch_id').value;
                const key = document.getElementById('wechat_key').value;
                
                if (!appId || !mchId || !key) {
                    alert('请先填写必填项：AppID、商户号和API密钥');
                    return;
                }
                
                // 提交测试表单
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.name = 'action';
                actionInput.value = 'test_wechat';
                form.appendChild(actionInput);
                
                const appIdInput = document.createElement('input');
                appIdInput.name = 'wechat_app_id';
                appIdInput.value = appId;
                form.appendChild(appIdInput);
                
                const mchIdInput = document.createElement('input');
                mchIdInput.name = 'wechat_mch_id';
                mchIdInput.value = mchId;
                form.appendChild(mchIdInput);
                
                const keyInput = document.createElement('input');
                keyInput.name = 'wechat_key';
                keyInput.value = key;
                form.appendChild(keyInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }

        // 页面加载完成后，为新手引导设置高亮
        document.addEventListener('DOMContentLoaded', function() {
            // 平滑滚动效果
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });
        });
    </script>
</body>
</html>