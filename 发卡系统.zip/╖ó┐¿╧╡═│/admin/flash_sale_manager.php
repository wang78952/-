<?php
/**
 * 秒杀活动管理页面
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/MarketingAndMembershipSystem.php';
require_once __DIR__ . '/../includes/ProductManager.php';
require_once __DIR__ . '/../includes/AuthManager.php';

// 检查权限
$authManager = new AuthManager();
if (!$authManager->hasPermission('flash_sale.manage')) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();
$marketingSystem = new MarketingAndMembershipSystem();
$productManager = new ProductManager();

// 获取产品列表供选择
$products = $productManager->getProducts();

// 处理表单提交
$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_flash_sale'])) {
        // 创建秒杀活动
        $data = [
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'start_time' => $_POST['start_time'],
            'end_time' => $_POST['end_time'],
            'priority' => $_POST['priority'] ?? 0,
            'notify_users' => isset($_POST['notify_users']),
            'products' => []
        ];

        // 处理秒杀商品
        if (!empty($_POST['product_ids'])) {
            foreach ($_POST['product_ids'] as $index => $productId) {
                if (!empty($productId) && !empty($_POST['flash_prices'][$index]) && !empty($_POST['flash_stocks'][$index])) {
                    $data['products'][] = [
                        'product_id' => $productId,
                        'price' => $_POST['flash_prices'][$index],
                        'stock' => $_POST['flash_stocks'][$index],
                        'max_per_user' => $_POST['max_per_user'][$index] ?? 1
                    ];
                }
            }
        }

        $result = $marketingSystem->createFlashSale($data);
        if ($result > 0) {
            $message = '秒杀活动创建成功！';
            header('Location: flash_sale_manager.php');
            exit;
        } else {
            $message = '秒杀活动创建失败，请检查输入！';
            $messageType = 'error';
        }
    } elseif (isset($_POST['update_flash_sale'])) {
        // 更新秒杀活动（这里调用API中的更新逻辑）
        $flashSaleId = $_POST['flash_sale_id'];
        $data = [
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'start_time' => $_POST['start_time'],
            'end_time' => $_POST['end_time'],
            'status' => $_POST['status'],
            'priority' => $_POST['priority'] ?? 0
        ];

        // 直接更新数据库
        $updates = [];
        foreach ($data as $key => $value) {
            $updates[] = "{$key} = '{$db->escapeString($value)}'";
        }
        $updates[] = "updated_at = NOW()";
        
        $updateQuery = "UPDATE flash_sales SET " . implode(', ', $updates) . " WHERE id = {$flashSaleId}";
        $db->query($updateQuery);
        
        $message = '秒杀活动更新成功！';
    } elseif (isset($_POST['delete_flash_sale'])) {
        // 删除秒杀活动
        $flashSaleId = $_POST['flash_sale_id'];
        $db->query("DELETE FROM flash_sales WHERE id = {$flashSaleId}");
        $message = '秒杀活动删除成功！';
    }
}

// 获取所有秒杀活动
$db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($db->connect_error) {
    die('数据库连接失败: ' . $db->connect_error);
}

// 使用预处理语句获取闪购活动列表
$stmt = $db->prepare("SELECT * FROM flash_sales ORDER BY created_at DESC");
$stmt->execute();
$result = $stmt->get_result();
$flashSales = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// 获取当前激活的秒杀活动（用于展示效果）
$activeFlashSales = $marketingSystem->getActiveFlashSales();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>秒杀活动管理 - 发卡系统</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/echarts.min.js"></script>
    <style>
        .flash-sale-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 16px;
            background: #fff;
        }
        .flash-sale-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .flash-sale-products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 12px;
        }
        .product-item {
            border: 1px solid #f0f0f0;
            border-radius: 6px;
            padding: 12px;
            position: relative;
        }
        .product-discount {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ff4444;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 12px;
        }
        .time-left {
            color: #ff6600;
            font-weight: bold;
        }
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-active {
            background: #e6f7ff;
            color: #1890ff;
        }
        .status-inactive {
            background: #f5f5f5;
            color: #999;
        }
        .status-completed {
            background: #f6ffed;
            color: #52c41a;
        }
        .status-cancelled {
            background: #fff2e8;
            color: #fa8c16;
        }
        .date-picker {
            width: 100%;
            padding: 8px;
            border: 1px solid #d9d9d9;
            border-radius: 4px;
        }
        .product-select-group {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            <div class="col-md-10 col-lg-9 p-4">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h2 class="mb-0"><i class="fa fa-bolt"></i> 秒杀活动管理</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($message): ?>
                            <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                                <?php echo $message; ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>

                        <!-- 数据统计面板 -->
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="card text-center p-3 bg-info text-white">
                                    <h4><?php echo count($flashSales); ?></h4>
                                    <p>总活动数</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center p-3 bg-success text-white">
                                    <h4><?php echo count($activeFlashSales); ?></h4>
                                    <p>当前激活</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center p-3 bg-warning text-white">
                                    <h4><?php 
                                        $upcoming = $db->query("SELECT COUNT(*) as count FROM flash_sales WHERE start_time > NOW() AND status = 'active'")->fetch_assoc()['count'];
                                        echo $upcoming;
                                    ?></h4>
                                    <p>即将开始</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center p-3 bg-danger text-white">
                                    <h4><?php 
                                        $completed = $db->query("SELECT COUNT(*) as count FROM flash_sales WHERE end_time < NOW() OR status = 'completed'")->fetch_assoc()['count'];
                                        echo $completed;
                                    ?></h4>
                                    <p>已结束</p>
                                </div>
                            </div>
                        </div>

                        <!-- 创建秒杀活动按钮 -->
                        <div class="mb-4">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#createFlashSaleModal">
                                <i class="fa fa-plus"></i> 创建秒杀活动
                            </button>
                        </div>

                        <!-- 当前激活的秒杀活动展示 -->
                        <div class="mb-6">
                            <h3><i class="fa fa-bullhorn"></i> 当前激活的秒杀活动</h3>
                            <?php if (!empty($activeFlashSales)): ?>
                                <?php foreach ($activeFlashSales as $sale): ?>
                                    <div class="flash-sale-card">
                                        <div class="flash-sale-header">
                                            <h4><?php echo $sale['name']; ?></h4>
                                            <div>
                                                <span class="status-badge status-active">进行中</span>
                                                <span class="time-left ml-2">剩余时间: <span id="time-left-<?php echo $sale['id']; ?>"></span></span>
                                            </div>
                                        </div>
                                        <p class="text-muted mb-2"><?php echo $sale['description']; ?></p>
                                        <div class="flash-sale-products">
                                            <?php foreach ($sale['products'] as $product): ?>
                                                <div class="product-item">
                                                    <span class="product-discount"><?php echo $product['discount']; ?>%</span>
                                                    <h5><?php echo $product['name']; ?></h5>
                                                    <div class="mb-2">
                                                        <span class="text-danger font-bold">¥<?php echo $product['flash_price']; ?></span>
                                                        <span class="text-muted line-through ml-2">¥<?php echo $product['original_price']; ?></span>
                                                    </div>
                                                    <div class="text-sm">
                                                        库存: <?php echo $product['stock']; ?> | 已售: <?php echo $product['sales_count']; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="alert alert-info">当前没有激活的秒杀活动</div>
                            <?php endif; ?>
                        </div>

                        <!-- 所有秒杀活动列表 -->
                        <h3><i class="fa fa-list"></i> 秒杀活动列表</h3>
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>活动名称</th>
                                        <th>时间范围</th>
                                        <th>商品数量</th>
                                        <th>状态</th>
                                        <th>优先级</th>
                                        <th>创建时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($flashSales as $sale): ?>
                                        <?php 
                                            $productCount = $db->query("SELECT COUNT(*) as count FROM flash_sale_products WHERE flash_sale_id = {$sale['id']}")->fetch_assoc()['count'];
                                            $statusClass = 'status-' . $sale['status'];
                                        ?>
                                        <tr>
                                            <td><?php echo $sale['id']; ?></td>
                                            <td><?php echo $sale['name']; ?></td>
                                            <td><?php echo $sale['start_time']; ?> - <?php echo $sale['end_time']; ?></td>
                                            <td><?php echo $productCount; ?></td>
                                            <td><span class="status-badge <?php echo $statusClass; ?>"><?php 
                                                switch ($sale['status']) {
                                                    case 'active': echo '进行中'; break;
                                                    case 'inactive': echo '未激活'; break;
                                                    case 'completed': echo '已完成'; break;
                                                    case 'cancelled': echo '已取消'; break;
                                                }
                                            ?></span></td>
                                            <td><?php echo $sale['priority']; ?></td>
                                            <td><?php echo $sale['created_at']; ?></td>
                                            <td>
                                                <button class="btn btn-info btn-sm" data-action="edit-flash-sale" data-sale-id="<?php echo $sale['id']; ?>">
                                                    <i class="fa fa-edit"></i> 编辑
                                                </button>
                                                <button class="btn btn-danger btn-sm" data-action="delete-flash-sale" data-sale-id="<?php echo $sale['id']; ?>">
                                                    <i class="fa fa-trash"></i> 删除
                                                </button>
                                                <button class="btn btn-warning btn-sm" data-action="view-flash-sale-stats" data-sale-id="<?php echo $sale['id']; ?>">
                                                    <i class="fa fa-bar-chart"></i> 统计
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 创建秒杀活动模态框 -->
    <div class="modal fade" id="createFlashSaleModal" tabindex="-1" role="dialog" aria-labelledby="createFlashSaleModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="createFlashSaleModalLabel">创建秒杀活动</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="createFlashSaleForm" method="POST">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">活动名称</label>
                            <input type="text" class="form-control" id="name" name="name" required placeholder="请输入秒杀活动名称">
                        </div>
                        
                        <div class="form-group">
                            <label for="description">活动描述</label>
                            <textarea class="form-control" id="description" name="description" rows="3" placeholder="请输入活动描述"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="start_time">开始时间</label>
                                    <input type="datetime-local" class="form-control date-picker" id="start_time" name="start_time" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="end_time">结束时间</label>
                                    <input type="datetime-local" class="form-control date-picker" id="end_time" name="end_time" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="priority">优先级</label>
                            <input type="number" class="form-control" id="priority" name="priority" min="0" max="100" value="0">
                            <small class="text-muted">数字越大优先级越高</small>
                        </div>

                        <div class="form-group">
                            <label>秒杀商品</label>
                            <div id="product-selector">
                                <div class="product-select-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <select class="form-control product-id-select" name="product_ids[]">
                                                <option value="">请选择商品</option>
                                                <?php foreach ($products as $product): ?>
                                                    <option value="<?php echo $product['id']; ?>" data-price="<?php echo $product['price']; ?>">
                                                        <?php echo $product['name']; ?> (¥<?php echo $product['price']; ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <input type="number" class="form-control" name="flash_prices[]" placeholder="秒杀价" min="0.01" step="0.01">
                                        </div>
                                        <div class="col-md-2">
                                            <input type="number" class="form-control" name="flash_stocks[]" placeholder="秒杀库存" min="1">
                                        </div>
                                        <div class="col-md-2">
                                            <input type="number" class="form-control" name="max_per_user[]" placeholder="每用户限购" min="1" value="1">
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-danger remove-product" disabled>
                                                <i class="fa fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" id="add-product" class="btn btn-info mt-2">
                                <i class="fa fa-plus"></i> 添加商品
                            </button>
                        </div>

                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="notify_users" name="notify_users">
                            <label class="form-check-label" for="notify_users">创建后通知用户</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="submit" name="create_flash_sale" class="btn btn-primary">创建活动</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 编辑秒杀活动模态框 -->
    <div class="modal fade" id="editFlashSaleModal" tabindex="-1" role="dialog" aria-labelledby="editFlashSaleModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="editFlashSaleModalLabel">编辑秒杀活动</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="editFlashSaleForm" method="POST">
                    <input type="hidden" id="edit_flash_sale_id" name="flash_sale_id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="edit_name">活动名称</label>
                            <input type="text" class="form-control" id="edit_name" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_description">活动描述</label>
                            <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_start_time">开始时间</label>
                                    <input type="datetime-local" class="form-control date-picker" id="edit_start_time" name="start_time" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_end_time">结束时间</label>
                                    <input type="datetime-local" class="form-control date-picker" id="edit_end_time" name="end_time" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="edit_status">活动状态</label>
                            <select class="form-control" id="edit_status" name="status">
                                <option value="active">激活</option>
                                <option value="inactive">未激活</option>
                                <option value="completed">已完成</option>
                                <option value="cancelled">已取消</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="edit_priority">优先级</label>
                            <input type="number" class="form-control" id="edit_priority" name="priority" min="0" max="100">
                        </div>

                        <!-- 商品信息仅显示，不允许编辑 -->
                        <div class="form-group">
                            <label>秒杀商品（不可编辑，请创建新活动）</label>
                            <div id="edit_products_list" class="bg-light p-3 rounded">
                                <!-- 由JavaScript填充 -->
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="submit" name="update_flash_sale" class="btn btn-primary">更新活动</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 删除确认模态框 -->
    <div class="modal fade" id="deleteConfirmModal" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteConfirmModalLabel">确认删除</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST">
                    <input type="hidden" id="delete_flash_sale_id" name="flash_sale_id">
                    <div class="modal-body">
                        <p>确定要删除这个秒杀活动吗？此操作不可撤销。</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="submit" name="delete_flash_sale" class="btn btn-danger">确认删除</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 统计模态框 -->
    <div class="modal fade" id="statsModal" tabindex="-1" role="dialog" aria-labelledby="statsModalLabel">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="statsModalLabel">秒杀活动统计</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="stats-content">
                        <!-- 由JavaScript填充 -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    // 设置默认时间
    document.addEventListener('DOMContentLoaded', function() {
        const now = new Date();
        const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
        
        document.getElementById('start_time').value = formatDateTime(now);
        document.getElementById('end_time').value = formatDateTime(tomorrow);
        
        // 添加商品按钮
        document.getElementById('add-product').addEventListener('click', addProductRow);
        
        // 初始化移除按钮
        updateRemoveButtons();
        
        // 初始化倒计时
        initCountdowns();
        
        // 事件委托监听器 - 处理所有带有data-action属性的元素
        document.addEventListener('click', function(event) {
            const action = event.target.closest('[data-action]');
            if (!action) return;
            
            const saleId = action.getAttribute('data-sale-id');
            
            switch (action.getAttribute('data-action')) {
                case 'edit-flash-sale':
                    // 需要重新查询数据，因为我们不再通过PHP直接传递json数据
                    fetchFlashSaleData(saleId);
                    break;
                case 'delete-flash-sale':
                    deleteFlashSale(saleId);
                    break;
                case 'view-flash-sale-stats':
                    viewFlashSaleStats(saleId);
                    break;
            }
        });
        
        // 获取秒杀活动数据的函数
        function fetchFlashSaleData(saleId) {
            // 显示加载状态
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'loading-overlay';
            loadingDiv.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loadingDiv);
            
            // 发送AJAX请求获取秒杀活动数据
            const xhr = new XMLHttpRequest();
            xhr.open('GET', '../api/flash_sale/get.php?id=' + saleId, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            
            xhr.onload = function() {
                // 移除加载状态
                document.body.removeChild(loadingDiv);
                
                if (xhr.status === 200) {
                    try {
                        const data = JSON.parse(xhr.responseText);
                        if (data.success) {
                            const saleData = data.data.sale;
                            const productData = data.data.products;
                            // 调用原来的editFlashSale函数
                            editFlashSale(saleData, productData);
                        } else {
                            alert('获取数据失败: ' + (data.message || '未知错误'));
                        }
                    } catch (e) {
                        console.error('解析响应数据失败:', e);
                        alert('获取数据失败，请重试');
                    }
                } else {
                    alert('请求失败，状态码: ' + xhr.status);
                }
            };
            
            xhr.onerror = function() {
                document.body.removeChild(loadingDiv);
                alert('网络错误，请检查网络连接');
            };
            
            xhr.send();
        }
    });
    
    function formatDateTime(date) {
        return date.getFullYear() + '-' + 
               String(date.getMonth() + 1).padStart(2, '0') + '-' + 
               String(date.getDate()).padStart(2, '0') + 'T' + 
               String(date.getHours()).padStart(2, '0') + ':' + 
               String(date.getMinutes()).padStart(2, '0');
    }
    
    function addProductRow() {
        const selector = document.getElementById('product-selector');
        const newRow = document.querySelector('.product-select-group').cloneNode(true);
        
        // 清空输入值
        newRow.querySelector('select').value = '';
        newRow.querySelector('input[name="flash_prices[]"]').value = '';
        newRow.querySelector('input[name="flash_stocks[]"]').value = '';
        newRow.querySelector('input[name="max_per_user[]"]').value = 1;
        
        // 启用移除按钮
        const removeButton = newRow.querySelector('.remove-product');
        removeButton.disabled = false;
        removeButton.addEventListener('click', function() {
            this.closest('.product-select-group').remove();
            updateRemoveButtons();
        });
        
        // 添加到列表
        selector.appendChild(newRow);
        
        // 为新添加的选择器添加事件监听
        const productSelect = newRow.querySelector('.product-id-select');
        productSelect.addEventListener('change', function() {
            const flashPriceInput = this.closest('.row').querySelector('input[name="flash_prices[]"]');
            if (this.value) {
                const originalPrice = parseFloat(this.options[this.selectedIndex].dataset.price);
                // 默认设置为原价的8折
                flashPriceInput.value = (originalPrice * 0.8).toFixed(2);
            }
        });
    }
    
    function updateRemoveButtons() {
        const allGroups = document.querySelectorAll('.product-select-group');
        const removeButtons = document.querySelectorAll('.remove-product');
        
        removeButtons.forEach((button, index) => {
            if (allGroups.length > 1) {
                button.disabled = false;
                button.addEventListener('click', function() {
                    this.closest('.product-select-group').remove();
                    updateRemoveButtons();
                });
            } else {
                button.disabled = true;
            }
        });
    }
    
    function editFlashSale(saleData, productsData) {
        // 填充编辑表单
        document.getElementById('edit_flash_sale_id').value = saleData.id;
        document.getElementById('edit_name').value = saleData.name;
        document.getElementById('edit_description').value = saleData.description || '';
        document.getElementById('edit_start_time').value = formatDateTimeForInput(saleData.start_time);
        document.getElementById('edit_end_time').value = formatDateTimeForInput(saleData.end_time);
        document.getElementById('edit_status').value = saleData.status;
        document.getElementById('edit_priority').value = saleData.priority;
        
        // 填充商品列表
        const productsList = document.getElementById('edit_products_list');
        productsList.innerHTML = '';
        
        if (productsData && productsData.length > 0) {
            const table = document.createElement('table');
            table.className = 'table table-striped';
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>商品名称</th>
                        <th>原价</th>
                        <th>秒杀价</th>
                        <th>秒杀库存</th>
                        <th>每用户限购</th>
                        <th>已售数量</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            `;
            
            const tbody = table.querySelector('tbody');
            productsData.forEach(product => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td>${product.product_name || '未知商品'}</td>
                    <td>¥${product.original_price || '0.00'}</td>
                    <td class="text-danger font-bold">¥${product.price}</td>
                    <td>${product.stock}</td>
                    <td>${product.max_per_user}</td>
                    <td>${product.sales_count || 0}</td>
                `;
            });
            
            productsList.appendChild(table);
        } else {
            productsList.textContent = '暂无秒杀商品';
        }
        
        // 显示模态框
        $('#editFlashSaleModal').modal('show');
    }
    
    function formatDateTimeForInput(datetimeString) {
        const date = new Date(datetimeString);
        return date.getFullYear() + '-' + 
               String(date.getMonth() + 1).padStart(2, '0') + '-' + 
               String(date.getDate()).padStart(2, '0') + 'T' + 
               String(date.getHours()).padStart(2, '0') + ':' + 
               String(date.getMinutes()).padStart(2, '0');
    }
    
    function deleteFlashSale(saleId) {
        document.getElementById('delete_flash_sale_id').value = saleId;
        $('#deleteConfirmModal').modal('show');
    }
    
    function viewFlashSaleStats(saleId) {
        const statsContent = document.getElementById('stats-content');
        statsContent.innerHTML = '<div class="text-center p-4"><i class="fa fa-spinner fa-spin text-primary"></i> 加载统计数据...</div>';
        
        // 模拟加载统计数据
        $.ajax({
            url: '../api/marketing.php',
            type: 'GET',
            data: { action: 'get_flash_sale_stats', flash_sale_id: saleId },
            success: function(data) {
                if (data.success) {
                    // 渲染统计图表和数据
                    renderStats(data.stats, saleId);
                } else {
                    statsContent.innerHTML = `<div class="alert alert-danger">加载失败: ${data.error}</div>`;
                }
            },
            error: function() {
                statsContent.innerHTML = '<div class="alert alert-danger">加载失败，请重试</div>';
            }
        });
        
        $('#statsModal').modal('show');
    }
    
    function renderStats(stats, saleId) {
        const statsContent = document.getElementById('stats-content');
        
        // 这里只是一个简单的实现，实际应该使用ECharts渲染图表
        statsContent.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">销售趋势</div>
                        <div class="card-body" style="height: 300px;">
                            <div id="sales-chart-${saleId}" style="width: 100%; height: 100%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">商品销售占比</div>
                        <div class="card-body" style="height: 300px;">
                            <div id="product-chart-${saleId}" style="width: 100%; height: 100%;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="card bg-info text-white text-center p-3">
                        <h4>${stats.total_orders || 0}</h4>
                        <p>总订单数</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white text-center p-3">
                        <h4>¥${stats.total_sales || 0}</h4>
                        <p>总销售额</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white text-center p-3">
                        <h4>${stats.total_users || 0}</h4>
                        <p>参与用户数</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-danger text-white text-center p-3">
                        <h4>${stats.conversion_rate || '0%'}</h4>
                        <p>转化率</p>
                    </div>
                </div>
            </div>
        `;
    }
    
    function initCountdowns() {
        const elements = document.querySelectorAll('[id^="time-left-"]');
        elements.forEach(element => {
            const saleId = element.id.split('-').pop();
            // 这里应该从服务器获取结束时间，简化起见使用模拟数据
            const endTime = new Date(Date.now() + Math.random() * 7 * 24 * 60 * 60 * 1000);
            
            function updateCountdown() {
                const now = new Date();
                const diff = endTime - now;
                
                if (diff <= 0) {
                    element.textContent = '已结束';
                    return;
                }
                
                const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((diff % (1000 * 60)) / 1000);
                
                element.textContent = `${days}天 ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
            
            updateCountdown();
            setInterval(updateCountdown, 1000);
        });
    }
</script>
</html>