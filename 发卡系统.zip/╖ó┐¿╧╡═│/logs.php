<?php
require_once 'includes/core/SecurityUtils.php';
require_once 'includes/core/Database.php';
require_once 'includes/services/AuthService.php';
require_once 'includes/services/ComplianceService.php';
require_once 'monitoring/ErrorMonitor.php';
require_once 'config.php';

// 启动会话
session_start();

// 初始化认证服务
$authService = new AuthService();

// 检查用户登录状态
if (!$authService->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 检查会话是否过期
if ($authService->isSessionExpired()) {
    $authService->logout();
    header('Location: login.php?error=session_expired');
    exit;
}

// 刷新会话
$authService->refreshSession();

// 获取当前用户信息
$currentUser = $authService->getCurrentUser();

// 检查数据访问权限
if (!ComplianceService::checkDataAccessPermission($currentUser['id'], 'read', 'logs')) {
    $_SESSION['error'] = '您没有权限访问操作日志';
    header('Location: dashboard.php');
    exit;
}

// 记录数据访问授权
ComplianceService::recordDataAccessAuthorization(
    $currentUser['id'], 
    'logs', 
    'read', 
    '访问操作日志页面', 
    ['page' => 'logs_view']
)

// 初始化查询参数
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// 获取筛选参数
$search = $_GET['search'] ?? '';
$action_type = $_GET['action_type'] ?? '';
$user_filter = $_GET['user'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// 构建查询条件
$whereConditions = [];
$params = [];

// 根据用户角色确定查询范围
if (!in_array($currentUser['role'], ['admin', 'business_admin'])) {
    // 非管理员只能查看自己的日志
    $whereConditions[] = "ul.user_id = ?";
    $params[] = $currentUser['id'];
}

if (!empty($search)) {
    $whereConditions[] = "(ul.description LIKE ? OR ul.action LIKE ?)";
    $searchParam = '%' . $search . '%';
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($action_type)) {
    $whereConditions[] = "ul.action_type = ?";
    $params[] = $action_type;
}

if (!empty($user_filter) && in_array($currentUser['role'], ['admin', 'business_admin'])) {
    $whereConditions[] = "ul.user_id = ?";
    $params[] = $user_filter;
}

if (!empty($date_from)) {
    $whereConditions[] = "DATE(ul.created_at) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $whereConditions[] = "DATE(ul.created_at) <= ?";
    $params[] = $date_to;
}

$whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

try {
    $db = Database::getInstance();
    
    // 初始化错误监控器
    $errorMonitor = new ErrorMonitor($db);
    
    // 获取错误监控数据（仅管理员可见）
    $errorStats = null;
    $recentErrors = [];
    $errorTrends = [];
    
    if (in_array($currentUser['role'], ['admin', 'business_admin'])) {
        // 获取错误统计
        $errorStats = $errorMonitor->getErrorStats();
        
        // 获取最近错误
        $recentErrors = $errorMonitor->getRecentErrors(10);
        
        // 获取错误趋势数据
        $errorTrends = $errorMonitor->getErrorTrends(7); // 最近7天
    }
    
    // 获取总记录数
    $countQuery = "SELECT COUNT(*) as total FROM user_logs ul 
                   LEFT JOIN users u ON ul.user_id = u.id 
                   $whereClause";
    $totalResult = $db->queryOne($countQuery, $params);
    $totalLogs = $totalResult['total'];
    $totalPages = ceil($totalLogs / $limit);
    
    // 获取日志记录
    $logsQuery = "SELECT ul.*, u.username, u.role 
                  FROM user_logs ul 
                  LEFT JOIN users u ON ul.user_id = u.id 
                  $whereClause 
                  ORDER BY ul.created_at DESC 
                  LIMIT ? OFFSET ?";
    $logsParams = array_merge($params, [$limit, $offset]);
    $logs = $db->query($logsQuery, $logsParams);
    
    // 对敏感数据进行脱敏处理
    foreach ($logs as &$log) {
        // 对描述中的敏感信息进行脱敏
        $log['description'] = ComplianceManager::maskSensitiveData(
            $log['description'], 
            $currentUser['role']
        );
        
        // 对用户名进行脱敏（非管理员查看其他用户日志时）
        if (!in_array($currentUser['role'], ['admin', 'business_admin']) && 
            $log['user_id'] != $currentUser['id']) {
            $log['username'] = ComplianceManager::maskName($log['username'], $currentUser['role']);
        }
    }
    
    // 获取操作类型列表（用于筛选）
    $actionTypesQuery = "SELECT DISTINCT action_type FROM user_logs ORDER BY action_type";
    $actionTypes = $db->query($actionTypesQuery);
    
    // 获取用户列表（仅管理员和业务管理员可筛选用户）
    $users = [];
    if (in_array($currentUser['role'], ['admin', 'business_admin'])) {
        $usersQuery = "SELECT id, username, role FROM users ORDER BY username";
        $users = $db->query($usersQuery);
        
        // 对用户名进行脱敏处理
        foreach ($users as &$user) {
            $user['username'] = ComplianceManager::maskName($user['username'], $currentUser['role']);
        }
    }
    
    // 获取统计信息
    $statsQuery = "SELECT 
                   COUNT(*) as total_logs,
                   COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_logs,
                   COUNT(CASE WHEN DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 END) as week_logs
                   FROM user_logs ul $whereClause";
    $stats = $db->queryOne($statsQuery, $params);
    
} catch (Exception $e) {
    $error = '获取日志数据失败：' . $e->getMessage();
    
    // 记录错误日志
    SecurityUtils::logSecurity('ERROR', '日志页面数据获取失败', [
        'user_id' => $currentUser['id'],
        'username' => $currentUser['username'],
        'error' => $e->getMessage()
    ]);
}

// 生成CSRF令牌
$csrfToken = SecurityUtils::generateCSRFToken();

// 处理CSV导出请求
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    // 验证CSRF令牌
    if (!isset($_GET['csrf_token']) || !SecurityUtils::validateCSRFToken($_GET['csrf_token'])) {
        die('CSRF验证失败');
    }
    
    // 检查导出权限
    if (!ComplianceManager::checkDataAccessPermission($currentUser['id'], 'export', 'logs')) {
        die('您没有权限导出日志数据');
    }
    
    try {
        // 获取所有符合条件的日志（不分页）
        $exportQuery = "SELECT ul.*, u.username, u.role 
                       FROM user_logs ul 
                       LEFT JOIN users u ON ul.user_id = u.id 
                       $whereClause 
                       ORDER BY ul.created_at DESC";
        $exportLogs = $db->query($exportQuery, $params);
        
        // 设置CSV头部
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="logs_export_' . date('Y-m-d_H-i-s') . '.csv"');
        
        // 输出CSV
        $output = fopen('php://output', 'w');
        
        // 添加BOM以支持中文
        fwrite($output, "\xEF\xBB\xBF");
        
        // CSV头部
        fputcsv($output, ['ID', '用户', '角色', '操作类型', '描述', 'IP地址', '创建时间']);
        
        // CSV数据
        foreach ($exportLogs as $log) {
            // 对敏感数据进行脱敏处理
            $description = ComplianceManager::maskSensitiveData($log['description'], $currentUser['role']);
            $username = $log['username'];
            
            if (!in_array($currentUser['role'], ['admin', 'business_admin']) && 
                $log['user_id'] != $currentUser['id']) {
                $username = ComplianceManager::maskName($username, $currentUser['role']);
            }
            
            fputcsv($output, [
                $log['id'],
                $username,
                $log['role'],
                $log['action_type'],
                $description,
                $log['ip_address'],
                $log['created_at']
            ]);
        }
        
        fclose($output);
        
        // 记录导出操作
        SecurityUtils::logSecurity('INFO', '日志数据导出', [
            'user_id' => $currentUser['id'],
            'username' => $currentUser['username'],
            'export_count' => count($exportLogs),
            'filters' => [
                'search' => $search,
                'action_type' => $action_type,
                'user_filter' => $user_filter,
                'date_from' => $date_from,
                'date_to' => $date_to
            ]
        ]);
        
        exit;
        
    } catch (Exception $e) {
        die('导出失败：' . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>操作日志 - 商业级发卡系统</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4a5568;
        }
        
        .nav-links {
            display: flex;
            gap: 2rem;
            align-items: center;
        }
        
        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: #667eea;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.5rem 1rem;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 8px;
        }
        
        .user-role {
            font-size: 0.875rem;
            color: #718096;
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 1rem;
            flex: 1;
        }
        
        .page-header {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 2rem;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        
        .page-subtitle {
            color: #718096;
            font-size: 1rem;
        }
        
        .compliance-notice {
            background: #f7fafc;
            border-left: 4px solid #4299e1;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .compliance-notice h3 {
            color: #2b6cb0;
            margin-bottom: 0.5rem;
        }
        
        .compliance-notice p {
            color: #4a5568;
            font-size: 0.875rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 8px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: #718096;
            font-size: 0.875rem;
        }
        
        .filter-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 2rem;
        }
        
        .filter-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: #4a5568;
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            padding: 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            font-size: 0.875rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .filter-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-secondary {
            background: #e2e8f0;
            color: #4a5568;
        }
        
        .btn-secondary:hover {
            background: #cbd5e0;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
        }
        
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(72, 187, 120, 0.3);
        }
        
        .logs-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .logs-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .logs-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d3748;
        }
        
        .logs-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .logs-table th,
        .logs-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .logs-table th {
            background: #f7fafc;
            color: #4a5568;
            font-weight: 600;
            font-size: 0.875rem;
        }
        
        .logs-table tr:hover {
            background: #f7fafc;
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-info {
            background: #bee3f8;
            color: #2c5282;
        }
        
        .badge-success {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .badge-warning {
            background: #feebc8;
            color: #7c2d12;
        }
        
        .badge-danger {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .text-muted {
            color: #718096;
            font-size: 0.875rem;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .pagination a,
        .pagination span {
            padding: 0.5rem 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            text-decoration: none;
            color: #4a5568;
            font-size: 0.875rem;
        }
        
        .pagination a:hover {
            background: #f7fafc;
            border-color: #667eea;
            color: #667eea;
        }
        
        .pagination .current {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #718096;
        }
        
        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-danger {
            background: #fed7d7;
            color: #742a2a;
            border: 1px solid #fc8181;
        }
        
        @media (max-width: 768px) {
            .filter-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                flex-direction: column;
            }
            
            .logs-header {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
            
            .logs-table {
                font-size: 0.875rem;
            }
            
            .logs-table th,
            .logs-table td {
                padding: 0.5rem;
            }
            
            .navbar {
                flex-direction: column;
                padding: 1rem;
            }
            
            .nav-links {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">商业级发卡系统</div>
        <div class="nav-links">
            <a href="dashboard.php">仪表板</a>
            <a href="add_card.php">添加卡片</a>
            <a href="search_card.php">查询卡片</a>
            <a href="identity_verification.php">身份核验</a>
            <a href="update_status.php">更新状态</a>
            <a href="logs.php" class="active">操作日志</a>
            <a href="compliance.php">合规管理</a>
            <div class="user-info">
                <span><?php echo htmlspecialchars($currentUser['username']); ?></span>
                <span class="user-role"><?php echo htmlspecialchars($currentUser['role']); ?></span>
                <a href="logout.php" style="color: #f56565;">退出</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1 class="page-title">操作日志</h1>
            <p class="page-subtitle">查看系统操作记录和审计日志</p>
        </div>

        <div class="compliance-notice">
            <h3>数据安全提示</h3>
            <p>日志中的敏感信息已进行脱敏处理，您的所有操作将被记录用于合规审计。</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- 统计信息 -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['total_logs']); ?></div>
                <div class="stat-label">总日志数</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['today_logs']); ?></div>
                <div class="stat-label">今日日志</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['week_logs']); ?></div>
                <div class="stat-label">本周日志</div>
            </div>
        </div>

        <!-- 错误监控面板（仅管理员可见） -->
        <?php if (in_array($currentUser['role'], ['admin', 'business_admin']) && $errorStats): ?>
        <div class="error-monitor-panel" style="margin-bottom: 2rem;">
            <div class="panel-header">
                <h3 style="color: #2d3748; margin-bottom: 1rem;">错误监控</h3>
                <div class="error-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                    <div class="stat-card" style="background: #fed7d7; border-left: 4px solid #e53e3e;">
                        <div class="stat-value" style="color: #742a2a;"><?php echo number_format($errorStats['total_errors'] ?? 0); ?></div>
                        <div class="stat-label">总错误数</div>
                    </div>
                    <div class="stat-card" style="background: #feebc8; border-left: 4px solid #dd6b20;">
                        <div class="stat-value" style="color: #7c2d12;"><?php echo number_format($errorStats['today_errors'] ?? 0); ?></div>
                        <div class="stat-label">今日错误</div>
                    </div>
                    <div class="stat-card" style="background: #faf5ff; border-left: 4px solid #805ad5;">
                        <div class="stat-value" style="color: #44337a;"><?php echo number_format($errorStats['critical_errors'] ?? 0); ?></div>
                        <div class="stat-label">严重错误</div>
                    </div>
                    <div class="stat-card" style="background: #e6fffa; border-left: 4px solid #319795;">
                        <div class="stat-value" style="color: #234e52;"><?php echo number_format($errorStats['warning_errors'] ?? 0); ?></div>
                        <div class="stat-label">警告错误</div>
                    </div>
                </div>
                
                <div class="error-actions" style="display: flex; gap: 1rem; margin-bottom: 1.5rem;">
                    <a href="monitoring/realtime.php" class="btn btn-primary" target="_blank">实时监控</a>
                    <a href="scripts/error_monitor_task.php" class="btn btn-secondary" onclick="runErrorAnalysis(); return false;">立即分析</a>
                    <a href="monitoring/api/performance.php?endpoint=alerts" class="btn btn-info" target="_blank">查看告警</a>
                </div>
                
                <?php if (!empty($recentErrors)): ?>
                <div class="recent-errors" style="background: #fff5f5; border-radius: 8px; padding: 1rem;">
                    <h4 style="color: #742a2a; margin-bottom: 1rem;">最近错误</h4>
                    <div class="error-list" style="max-height: 200px; overflow-y: auto;">
                        <?php foreach ($recentErrors as $error): ?>
                        <div class="error-item" style="padding: 0.75rem; border-bottom: 1px solid #fed7d7; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span class="error-level" style="padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: bold; 
                                    <?php 
                                    $levelClass = 'bg-gray-100 text-gray-800';
                                    if ($error['level'] === 'CRITICAL') $levelClass = 'bg-red-100 text-red-800';
                                    elseif ($error['level'] === 'ERROR') $levelClass = 'bg-orange-100 text-orange-800';
                                    elseif ($error['level'] === 'WARNING') $levelClass = 'bg-yellow-100 text-yellow-800';
                                    echo $levelClass;
                                    ?>">
                                    <?php echo htmlspecialchars($error['level']); ?>
                                </span>
                                <span class="error-message" style="margin-left: 0.5rem; color: #4a5568;">
                                    <?php echo htmlspecialchars(substr($error['message'], 0, 100) . (strlen($error['message']) > 100 ? '...' : '')); ?>
                                </span>
                            </div>
                            <span class="error-time" style="color: #718096; font-size: 0.875rem;">
                                <?php echo date('H:i:s', strtotime($error['created_at'])); ?>
                            </span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- 筛选器 -->
        <div class="filter-section">
            <h3 class="filter-title">筛选条件</h3>
            <form method="GET" action="logs.php">
                <div class="filter-grid">
                    <div class="form-group">
                        <label class="form-label">关键词搜索</label>
                        <input type="text" name="search" class="form-control" 
                               value="<?php echo htmlspecialchars($search); ?>" 
                               placeholder="搜索描述或操作内容">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">操作类型</label>
                        <select name="action_type" class="form-control">
                            <option value="">全部类型</option>
                            <?php foreach ($actionTypes as $type): ?>
                                <option value="<?php echo htmlspecialchars($type['action_type']); ?>"
                                        <?php echo $action_type === $type['action_type'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($type['action_type']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <?php if (in_array($currentUser['role'], ['admin', 'business_admin'])): ?>
                        <div class="form-group">
                            <label class="form-label">用户</label>
                            <select name="user" class="form-control">
                                <option value="">全部用户</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo htmlspecialchars($user['id']); ?>"
                                            <?php echo $user_filter == $user['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['username']); ?> 
                                        (<?php echo htmlspecialchars($user['role']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label class="form-label">开始日期</label>
                        <input type="date" name="date_from" class="form-control" 
                               value="<?php echo htmlspecialchars($date_from); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">结束日期</label>
                        <input type="date" name="date_to" class="form-control" 
                               value="<?php echo htmlspecialchars($date_to); ?>">
                    </div>
                </div>
                
                <div class="filter-actions">
                    <button type="submit" class="btn btn-primary">筛选</button>
                    <a href="logs.php" class="btn btn-secondary">重置</a>
                    <a href="logs.php?export=csv&csrf_token=<?php echo urlencode($csrfToken); ?><?php 
                        echo !empty($search) ? '&search=' . urlencode($search) : ''; 
                        echo !empty($action_type) ? '&action_type=' . urlencode($action_type) : ''; 
                        echo !empty($user_filter) ? '&user=' . urlencode($user_filter) : ''; 
                        echo !empty($date_from) ? '&date_from=' . urlencode($date_from) : ''; 
                        echo !empty($date_to) ? '&date_to=' . urlencode($date_to) : ''; 
                    ?>" class="btn btn-success">导出CSV</a>
                </div>
            </form>
        </div>

        <!-- 日志列表 -->
        <div class="logs-section">
            <div class="logs-header">
                <h3 class="logs-title">日志记录</h3>
                <span class="text-muted">
                    共 <?php echo number_format($totalLogs); ?> 条记录
                </span>
            </div>
            
            <?php if (!empty($logs)): ?>
                <table class="logs-table">
                    <thead>
                        <tr>
                            <th>时间</th>
                            <th>用户</th>
                            <th>角色</th>
                            <th>操作类型</th>
                            <th>描述</th>
                            <th>IP地址</th>
                            <th>用户代理</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td>
                                    <?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?>
                                    <br>
                                    <span class="text-muted">
                                        <?php echo SecurityUtils::timeAgo($log['created_at']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($log['username'] ?? '未知用户'); ?>
                                    <?php if (!empty($log['user_email'])): ?>
                                        <br>
                                        <span class="text-muted"><?php echo htmlspecialchars($log['user_email']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $roleColors = [
                                        'admin' => 'badge-danger',
                                        'business_admin' => 'badge-warning',
                                        'operator' => 'badge-info',
                                        'readonly' => 'badge-success'
                                    ];
                                    $roleClass = $roleColors[$log['role']] ?? 'badge-info';
                                    $roleNames = [
                                        'admin' => '管理员',
                                        'business_admin' => '业务管理员',
                                        'operator' => '操作员',
                                        'readonly' => '只读用户'
                                    ];
                                    echo '<span class="badge ' . $roleClass . '">' . 
                                         ($roleNames[$log['role']] ?? $log['role']) . '</span>';
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    $typeColors = [
                                        'card_add' => 'badge-success',
                                        'card_search' => 'badge-info',
                                        'card_status_update' => 'badge-warning',
                                        'user_login' => 'badge-info',
                                        'user_logout' => 'badge-info',
                                        'user_register' => 'badge-success',
                                        'password_change' => 'badge-warning',
                                        'admin_action' => 'badge-danger'
                                    ];
                                    $typeClass = $typeColors[$log['action_type']] ?? 'badge-info';
                                    $typeNames = [
                                        'card_add' => '添加卡片',
                                        'card_search' => '查询卡片',
                                        'card_status_update' => '更新状态',
                                        'user_login' => '用户登录',
                                        'user_logout' => '用户登出',
                                        'user_register' => '用户注册',
                                        'password_change' => '密码修改',
                                        'admin_action' => '管理操作'
                                    ];
                                    echo '<span class="badge ' . $typeClass . '">' . 
                                         ($typeNames[$log['action_type']] ?? $log['action_type']) . '</span>';
                                    ?>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($log['description']); ?>
                                    <?php if (!empty($log['details'])): ?>
                                        <br>
                                        <span class="text-muted">
                                            详情: <?php echo htmlspecialchars(substr($log['details'], 0, 100)); ?>...
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                <td>
                                    <span class="text-muted" title="<?php echo htmlspecialchars($log['ip_address']); ?>">
                                        <?php echo htmlspecialchars(substr($log['ip_address'], 0, 30)); ?>...
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <!-- 分页 -->
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&<?php echo http_build_query(array_diff_key($_GET, ['page' => ''])); ?>">« 上一页</a>
                <?php endif; ?>
                
                <?php
                $startPage = max(1, $page - 2);
                $endPage = min($totalPages, $page + 2);
                
                for ($i = $startPage; $i <= $endPage; $i++):
                ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>&<?php echo http_build_query(array_diff_key($_GET, ['page' => ''])); ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page + 1; ?>&<?php echo http_build_query(array_diff_key($_GET, ['page' => ''])); ?>">下一页 »</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        </div>
    </div>

    <script>
        // 错误分析功能
        function runErrorAnalysis() {
            // 显示加载状态
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = '分析中...';
            btn.disabled = true;
            
            // 发送AJAX请求执行错误分析
            fetch('monitoring/api/performance.php?endpoint=analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    action: 'analyze_errors',
                    timestamp: new Date().toISOString()
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('错误分析完成！\n' + 
                          '发现 ' + data.analysis.total_errors + ' 个错误\n' + 
                          '严重错误: ' + data.analysis.critical_errors + ' 个\n' + 
                          '警告错误: ' + data.analysis.warning_errors + ' 个');
                    
                    // 刷新页面以显示最新数据
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    alert('错误分析失败: ' + (data.message || '未知错误'));
                }
            })
            .catch(error => {
                console.error('错误分析请求失败:', error);
                alert('错误分析请求失败，请检查网络连接');
            })
            .finally(() => {
                // 恢复按钮状态
                btn.textContent = originalText;
                btn.disabled = false;
            });
        }
        
        // 实时错误监控WebSocket连接（可选）
        let errorWebSocket = null;
        
        function connectErrorMonitor() {
            if (typeof WebSocket !== 'undefined') {
                try {
                    errorWebSocket = new WebSocket('ws://localhost:8080/error-monitor');
                    
                    errorWebSocket.onmessage = function(event) {
                        const data = JSON.parse(event.data);
                        if (data.type === 'new_error') {
                            // 显示新错误通知
                            showErrorNotification(data.error);
                        }
                    };
                    
                    errorWebSocket.onerror = function(error) {
                        console.error('WebSocket连接错误:', error);
                    };
                    
                } catch (error) {
                    console.log('WebSocket不可用，使用轮询方式');
                }
            }
        }
        
        // 显示错误通知
        function showErrorNotification(error) {
            const notification = document.createElement('div');
            notification.className = 'error-notification';
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #fed7d7;
                border: 1px solid #fc8181;
                border-radius: 8px;
                padding: 1rem;
                max-width: 400px;
                z-index: 9999;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            `;
            
            notification.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <strong style="color: #742a2a;">新错误告警</strong>
                        <div style="margin-top: 0.5rem; color: #4a5568;">
                            <span style="background: ${getErrorLevelColor(error.level)}; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem;">
                                ${error.level}
                            </span>
                            <div style="margin-top: 0.25rem; font-size: 0.875rem;">
                                ${error.message}
                            </div>
                        </div>
                    </div>
                    <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: #742a2a; cursor: pointer; font-size: 1.2rem;">×</button>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // 5秒后自动移除
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 5000);
        }
        
        // 获取错误级别颜色
        function getErrorLevelColor(level) {
            const colors = {
                'CRITICAL': '#e53e3e',
                'ERROR': '#dd6b20',
                'WARNING': '#d69e2e',
                'INFO': '#3182ce'
            };
            return colors[level] || '#718096';
        }
        
        // 导出CSV功能
        document.addEventListener('DOMContentLoaded', function() {
            const exportLinks = document.querySelectorAll('a[href*="export=csv"]');
            exportLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    // 这里可以添加导出确认对话框
                    if (!confirm('确定要导出当前筛选条件下的日志数据吗？')) {
                        e.preventDefault();
                    }
                });
            });
            
            // 初始化错误监控连接
            const userRole = '<?php echo $currentUser["role"]; ?>';
            if (['admin', 'business_admin'].includes(userRole)) {
                connectErrorMonitor();
            }
        });

        // 自动刷新功能（可选）
        let autoRefreshInterval;
        
        function startAutoRefresh() {
            autoRefreshInterval = setInterval(() => {
                // 每5分钟刷新一次数据
                window.location.reload();
            }, 300000); // 5分钟
        }
        
        function stopAutoRefresh() {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
        }
        
        // 页面可见性变化时的处理
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                stopAutoRefresh();
            } else {
                startAutoRefresh();
            }
        });
        
        // 启动自动刷新
        // startAutoRefresh(); // 根据需要启用
    </script>
</body>
</html>