<?php
/**
 * 创建用户会话表
 * 用于会话安全管理的数据库表结构
 */

require_once 'config.php';

try {
    $db = getDB();
    
    // 创建用户会话表
    $sql = "
    CREATE TABLE IF NOT EXISTS `user_sessions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `session_id` varchar(255) NOT NULL,
        `user_id` int(11) NOT NULL,
        `ip_address` varchar(45) NOT NULL,
        `user_agent` text,
        `created_at` int(11) NOT NULL,
        `last_activity` int(11) NOT NULL,
        `is_active` tinyint(1) NOT NULL DEFAULT 1,
        `created_at_datetime` datetime GENERATED ALWAYS AS (FROM_UNIXTIME(created_at)) STORED,
        `last_activity_datetime` datetime GENERATED ALWAYS AS (FROM_UNIXTIME(last_activity)) STORED,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unique_session` (`session_id`),
        KEY `idx_user_id` (`user_id`),
        KEY `idx_last_activity` (`last_activity`),
        KEY `idx_is_active` (`is_active`),
        KEY `idx_user_active` (`user_id`, `is_active`, `last_activity`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户会话管理表';
    ";
    
    $db->exec($sql);
    
    echo "用户会话表创建成功！\n";
    
} catch (Exception $e) {
    echo "创建用户会话表失败: " . $e->getMessage() . "\n";
}
?>