-- 会员系统初始化脚本

-- 创建会员等级表
CREATE TABLE IF NOT EXISTS `member_levels` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL COMMENT '等级名称',
  `level` INT NOT NULL COMMENT '等级值，数值越大等级越高',
  `min_points` INT NOT NULL COMMENT '升级所需最低积分',
  `discount_rate` DECIMAL(3,2) DEFAULT 1.00 COMMENT '折扣率，如0.9表示9折',
  `description` TEXT COMMENT '等级描述',
  `icon_url` VARCHAR(255) COMMENT '等级图标URL',
  `privileges` TEXT COMMENT '等级特权，JSON格式',
  `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_level` (`level`),
  UNIQUE KEY `unique_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员等级表';

-- 创建用户会员信息表
CREATE TABLE IF NOT EXISTS `user_members` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT '用户ID',
  `member_level_id` INT NOT NULL DEFAULT 1 COMMENT '会员等级ID',
  `current_points` INT NOT NULL DEFAULT 0 COMMENT '当前可用积分',
  `total_points` INT NOT NULL DEFAULT 0 COMMENT '累计积分',
  `member_since` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '成为会员时间',
  `last_level_change` TIMESTAMP NULL COMMENT '最后等级变更时间',
  `last_points_change` TIMESTAMP NULL COMMENT '最后积分变更时间',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`member_level_id`) REFERENCES `member_levels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户会员信息表';

-- 创建积分交易记录表
CREATE TABLE IF NOT EXISTS `point_transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT '用户ID',
  `type` ENUM('order', 'activity', 'exchange', 'expire', 'other') NOT NULL DEFAULT 'other' COMMENT '积分交易类型',
  `change_points` INT NOT NULL COMMENT '积分变化量（正数增加，负数减少）',
  `balance_points` INT NOT NULL COMMENT '交易后积分余额',
  `reason` VARCHAR(255) COMMENT '积分变更原因',
  `expire_date` DATE NULL COMMENT '积分过期日期',
  `related_id` INT NULL COMMENT '关联ID（如订单ID、活动ID等）',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  INDEX `idx_expire_date` (`expire_date`),
  INDEX `idx_type` (`type`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分交易记录表';

-- 创建会员等级变更历史表
CREATE TABLE IF NOT EXISTS `member_level_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT '用户ID',
  `old_level_id` INT NOT NULL COMMENT '原等级ID',
  `new_level_id` INT NOT NULL COMMENT '新等级ID',
  `change_reason` VARCHAR(255) COMMENT '变更原因',
  `change_points` INT NOT NULL COMMENT '变更时的积分',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`old_level_id`) REFERENCES `member_levels` (`id`),
  FOREIGN KEY (`new_level_id`) REFERENCES `member_levels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员等级变更历史表';

-- 创建积分兑换规则表
CREATE TABLE IF NOT EXISTS `point_exchange_rules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL COMMENT '兑换项名称',
  `type` ENUM('cash', 'coupon', 'product', 'other') NOT NULL COMMENT '兑换类型',
  `exchange_value` DECIMAL(10,2) NOT NULL COMMENT '兑换价值',
  `required_points` INT NOT NULL COMMENT '所需积分',
  `min_spend` DECIMAL(10,2) DEFAULT 0 COMMENT '最低消费要求（适用于优惠券）',
  `max_daily_exchanges` INT DEFAULT 1 COMMENT '每日最大兑换次数',
  `related_id` INT NULL COMMENT '关联ID（如产品ID）',
  `start_date` DATE NULL COMMENT '开始日期',
  `end_date` DATE NULL COMMENT '结束日期',
  `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
  `description` TEXT COMMENT '兑换项描述',
  `icon_url` VARCHAR(255) COMMENT '图标URL',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_status` (`status`),
  INDEX `idx_date_range` (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分兑换规则表';

-- 创建积分兑换记录表
CREATE TABLE IF NOT EXISTS `point_exchanges` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT '用户ID',
  `rule_id` INT NOT NULL COMMENT '兑换规则ID',
  `exchange_type` ENUM('cash', 'coupon', 'product', 'other') NOT NULL COMMENT '兑换类型',
  `exchange_value` DECIMAL(10,2) NOT NULL COMMENT '兑换价值',
  `points_cost` INT NOT NULL COMMENT '消耗积分',
  `status` ENUM('pending', 'completed', 'cancelled') DEFAULT 'completed' COMMENT '兑换状态',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  INDEX `idx_rule` (`rule_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`rule_id`) REFERENCES `point_exchange_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分兑换记录表';

-- 插入默认会员等级数据
INSERT INTO `member_levels` (`name`, `level`, `min_points`, `discount_rate`, `description`, `privileges`) VALUES
('普通会员', 1, 0, 1.00, '注册即可成为普通会员，享受基础服务', '["正常购物体验"]'),
('银卡会员', 2, 1000, 0.95, '累计1000积分自动升级为银卡会员，享受全场9.5折优惠', '["全场9.5折优惠", "专属客服"]'),
('金卡会员', 3, 5000, 0.90, '累计5000积分自动升级为金卡会员，享受全场9折优惠', '["全场9折优惠", "专属客服", "生日礼包"]'),
('钻石会员', 4, 10000, 0.85, '累计10000积分自动升级为钻石会员，享受全场8.5折优惠', '["全场8.5折优惠", "专属客服", "生日礼包", "优先发货", "专属活动"]'),
('至尊会员', 5, 50000, 0.80, '累计50000积分自动升级为至尊会员，享受全场8折优惠', '["全场8折优惠", "专属客服", "生日礼包", "优先发货", "专属活动", "免费配送", "专属客户经理"]')
ON DUPLICATE KEY UPDATE `min_points`=VALUES(`min_points`), `discount_rate`=VALUES(`discount_rate`), `description`=VALUES(`description`), `privileges`=VALUES(`privileges`);

-- 插入默认积分兑换规则
INSERT INTO `point_exchange_rules` (`name`, `type`, `exchange_value`, `required_points`, `min_spend`, `max_daily_exchanges`, `description`) VALUES
('10元现金券', 'coupon', 10.00, 2000, 50.00, 3, '兑换10元现金券，订单满50元可用'),
('20元现金券', 'coupon', 20.00, 3500, 100.00, 2, '兑换20元现金券，订单满100元可用'),
('50元现金券', 'coupon', 50.00, 8000, 200.00, 1, '兑换50元现金券，订单满200元可用'),
('满100减15优惠券', 'coupon', 15.00, 2500, 100.00, 3, '满100元减15元优惠券'),
('满300减50优惠券', 'coupon', 50.00, 7000, 300.00, 2, '满300元减50元优惠券'),
('满500减100优惠券', 'coupon', 100.00, 15000, 500.00, 1, '满500元减100元优惠券'),
('5元无门槛现金券', 'coupon', 5.00, 1200, 0.00, 5, '5元无门槛现金券')
ON DUPLICATE KEY UPDATE `exchange_value`=VALUES(`exchange_value`), `required_points`=VALUES(`required_points`), `min_spend`=VALUES(`min_spend`), `max_daily_exchanges`=VALUES(`max_daily_exchanges`), `description`=VALUES(`description`);

-- 为现有用户创建会员信息记录
INSERT INTO `user_members` (`user_id`, `member_level_id`, `current_points`, `total_points`) 
SELECT `id`, 1, 0, 0 FROM `users` 
WHERE `id` NOT IN (SELECT `user_id` FROM `user_members`)
ON DUPLICATE KEY UPDATE `user_id`=VALUES(`user_id`);

-- 创建触发器，当用户注册时自动创建会员记录
DELIMITER //
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `users`
FOR EACH ROW
BEGIN
    INSERT INTO `user_members` (`user_id`, `member_level_id`, `current_points`, `total_points`)
    VALUES (NEW.id, 1, 0, 0);
END//
DELIMITER ;

-- 创建触发器，当订单完成时自动增加用户积分
DELIMITER //
CREATE TRIGGER `after_order_complete` AFTER UPDATE ON `orders`
FOR EACH ROW
BEGIN
    -- 只有订单状态变为完成时才增加积分
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        -- 计算应得积分（订单金额的10%，向下取整）
        SET @points = FLOOR(NEW.total_amount * 10);
        
        -- 更新用户积分
        UPDATE `user_members` 
        SET `current_points` = `current_points` + @points,
            `total_points` = `total_points` + @points,
            `last_points_change` = NOW()
        WHERE `user_id` = NEW.user_id;
        
        -- 记录积分交易
        INSERT INTO `point_transactions` 
        (`user_id`, `type`, `change_points`, `balance_points`, `reason`, `expire_date`, `related_id`)
        SELECT 
            NEW.user_id,
            'order',
            @points,
            `current_points`,
            CONCAT('订单支付获得积分：订单号', NEW.order_no),
            DATE_ADD(NOW(), INTERVAL 1 YEAR),
            NEW.id
        FROM `user_members`
        WHERE `user_id` = NEW.user_id;
    END IF;
END//
DELIMITER ;

-- 创建存储过程：清理过期积分
DELIMITER //
CREATE PROCEDURE `cleanup_expired_points`()
BEGIN
    -- 记录需要过期的积分交易
    CREATE TEMPORARY TABLE IF NOT EXISTS expired_points_temp AS
    SELECT 
        pt.user_id,
        SUM(pt.change_points) AS total_expired
    FROM 
        point_transactions pt
    WHERE 
        pt.expire_date <= CURRENT_DATE() 
        AND pt.expire_date IS NOT NULL
        AND pt.type != 'expire'
        AND pt.change_points > 0
        AND pt.id NOT IN (SELECT related_id FROM point_transactions WHERE type = 'expire')
    GROUP BY 
        pt.user_id;
    
    -- 更新用户积分并记录积分过期
    UPDATE 
        user_members um
    JOIN 
        expired_points_temp ept ON um.user_id = ept.user_id
    SET 
        um.current_points = um.current_points - ept.total_expired;
    
    -- 插入积分过期记录
    INSERT INTO point_transactions 
    (user_id, type, change_points, balance_points, reason, created_at)
    SELECT 
        ept.user_id,
        'expire',
        -ept.total_expired,
        um.current_points,
        '积分过期',
        NOW()
    FROM 
        expired_points_temp ept
    JOIN 
        user_members um ON ept.user_id = um.user_id;
    
    -- 检查是否需要降级
    UPDATE 
        user_members um
    JOIN 
        expired_points_temp ept ON um.user_id = ept.user_id
    JOIN 
        member_levels ml ON ml.level > (SELECT level FROM member_levels WHERE id = um.member_level_id)
    SET 
        um.member_level_id = ml.id,
        um.last_level_change = NOW()
    WHERE 
        um.current_points < ml.min_points;
    
    -- 删除临时表
    DROP TEMPORARY TABLE IF EXISTS expired_points_temp;
END//
DELIMITER ;

-- 创建视图：会员积分统计视图
CREATE VIEW IF NOT EXISTS `v_member_statistics` AS
SELECT 
    um.user_id,
    um.member_level_id,
    ml.name AS member_level_name,
    ml.level AS member_level_value,
    um.current_points,
    um.total_points,
    um.member_since,
    um.last_level_change,
    um.last_points_change,
    (
        SELECT COUNT(*) FROM orders WHERE user_id = um.user_id AND status = 'completed'
    ) AS completed_orders,
    (
        SELECT COALESCE(SUM(change_points), 0) FROM point_transactions 
        WHERE user_id = um.user_id AND type = 'order' AND change_points > 0
    ) AS points_from_orders,
    (
        SELECT COALESCE(SUM(change_points), 0) FROM point_transactions 
        WHERE user_id = um.user_id AND type = 'activity' AND change_points > 0
    ) AS points_from_activities,
    (
        SELECT COALESCE(SUM(change_points), 0) FROM point_transactions 
        WHERE user_id = um.user_id AND expire_date BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), INTERVAL 30 DAY)
        AND change_points > 0
    ) AS expiring_points,
    (
        SELECT COALESCE(MIN(expire_date), NULL) FROM point_transactions 
        WHERE user_id = um.user_id AND expire_date BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), INTERVAL 30 DAY)
        AND change_points > 0
    ) AS earliest_expire_date
FROM 
    user_members um
JOIN 
    member_levels ml ON um.member_level_id = ml.id;

-- 索引优化
ALTER TABLE `member_levels` ADD INDEX IF NOT EXISTS `idx_min_points` (`min_points`);
ALTER TABLE `user_members` ADD INDEX IF NOT EXISTS `idx_member_level` (`member_level_id`);
ALTER TABLE `point_transactions` ADD INDEX IF NOT EXISTS `idx_created_at` (`created_at`);
ALTER TABLE `point_exchanges` ADD INDEX IF NOT EXISTS `idx_created_at` (`created_at`);

-- 结束脚本
SELECT '会员系统初始化完成' AS message;