-- 数据库优化脚本
-- 创建索引、优化查询、完善数据表结构

-- ========================================
-- 1. 为主要表创建索引
-- ========================================

-- 用户表索引
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);
CREATE INDEX IF NOT EXISTS idx_users_last_login ON users(last_login);

-- 卡片表索引
CREATE INDEX IF NOT EXISTS idx_cards_card_number ON cards(card_number);
CREATE INDEX IF NOT EXISTS idx_cards_cardholder_name ON cards(cardholder_name);
CREATE INDEX IF NOT EXISTS idx_cards_status ON cards(status);
CREATE INDEX IF NOT EXISTS idx_cards_created_at ON cards(created_at);
CREATE INDEX IF NOT EXISTS idx_cards_created_by ON cards(created_by);
CREATE INDEX IF NOT EXISTS idx_cards_expiry_date ON cards(expiry_date);
CREATE INDEX IF NOT EXISTS idx_cards_status_created ON cards(status, created_at);

-- 系统日志表索引
CREATE INDEX IF NOT EXISTS idx_system_logs_user_id ON system_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_system_logs_action ON system_logs(action);
CREATE INDEX IF NOT EXISTS idx_system_logs_created_at ON system_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_system_logs_ip_address ON system_logs(ip_address);
CREATE INDEX IF NOT EXISTS idx_system_logs_user_created ON system_logs(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_system_logs_action_created ON system_logs(action, created_at);

-- 身份核验表索引
CREATE INDEX IF NOT EXISTS idx_identity_verifications_card_id ON identity_verifications(card_id);
CREATE INDEX IF NOT EXISTS idx_identity_verifications_status ON identity_verifications(status);
CREATE INDEX IF NOT EXISTS idx_identity_verifications_created_at ON identity_verifications(created_at);
CREATE INDEX IF NOT EXISTS idx_identity_verifications_created_by ON identity_verifications(created_by);
CREATE INDEX IF NOT EXISTS idx_identity_verifications_status_created ON identity_verifications(status, created_at);

-- 核验审核表索引
CREATE INDEX IF NOT EXISTS idx_verification_reviews_verification_id ON verification_reviews(verification_id);
CREATE INDEX IF NOT EXISTS idx_verification_reviews_reviewer_id ON verification_reviews(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_verification_reviews_review_level ON verification_reviews(review_level);
CREATE INDEX IF NOT EXISTS idx_verification_reviews_status ON verification_reviews(status);
CREATE INDEX IF NOT EXISTS idx_verification_reviews_review_date ON verification_reviews(review_date);

-- 卡片激活表索引
CREATE INDEX IF NOT EXISTS idx_card_activations_verification_id ON card_activations(verification_id);
CREATE INDEX IF NOT EXISTS idx_card_activations_activated_by ON card_activations(activated_by);
CREATE INDEX IF NOT EXISTS idx_card_activations_status ON card_activations(status);
CREATE INDEX IF NOT EXISTS idx_card_activations_activation_date ON card_activations(activation_date);
CREATE INDEX IF NOT EXISTS idx_card_activations_status_date ON card_activations(status, activation_date);

-- 数据访问日志表索引
CREATE INDEX IF NOT EXISTS idx_data_access_logs_user_id ON data_access_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_data_access_logs_data_type ON data_access_logs(data_type);
CREATE INDEX IF NOT EXISTS idx_data_access_logs_access_time ON data_access_logs(access_time);
CREATE INDEX IF NOT EXISTS idx_data_access_logs_user_time ON data_access_logs(user_id, access_time);
CREATE INDEX IF NOT EXISTS idx_data_access_logs_type_time ON data_access_logs(data_type, access_time);

-- 用户会话表索引
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_session_token ON user_sessions(session_token);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at ON user_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_user_sessions_status ON user_sessions(status);

-- ========================================
-- 2. 创建复合索引优化常用查询
-- ========================================

-- 卡片查询优化
CREATE INDEX IF NOT EXISTS idx_cards_status_created_by ON cards(status, created_by, created_at);
CREATE INDEX IF NOT EXISTS idx_cards_cardholder_status ON cards(cardholder_name, status);

-- 日志查询优化
CREATE INDEX IF NOT EXISTS idx_logs_user_action_time ON system_logs(user_id, action, created_at);
CREATE INDEX IF NOT EXISTS idx_logs_action_time_range ON system_logs(action, created_at, ip_address);

-- 身份核验查询优化
CREATE INDEX IF NOT EXISTS idx_verifications_status_created_by ON identity_verifications(status, created_by, created_at);
CREATE INDEX IF NOT EXISTS idx_verifications_card_status ON identity_verifications(card_id, status);

-- ========================================
-- 3. 优化表结构
-- ========================================

-- 为大文本字段添加全文索引（如果支持）
-- CREATE FULLTEXT INDEX IF NOT EXISTS idx_cards_cardholder_fulltext ON cards(cardholder_name);
-- CREATE FULLTEXT INDEX IF NOT EXISTS idx_logs_description_fulltext ON system_logs(description);

-- 优化枚举字段
ALTER TABLE users MODIFY COLUMN role ENUM('admin', 'manager', 'user') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user';
ALTER TABLE users MODIFY COLUMN status ENUM('active', 'inactive', 'suspended') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active';

ALTER TABLE cards MODIFY COLUMN status ENUM('active', 'inactive', 'expired', 'blocked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active';

ALTER TABLE identity_verifications MODIFY COLUMN status ENUM('pending', 'approved', 'rejected', 'cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending';
ALTER TABLE identity_verifications MODIFY COLUMN verification_type ENUM('standard', 'enhanced', 'premium') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'standard';

ALTER TABLE verification_reviews MODIFY COLUMN review_level ENUM('level1', 'level2', 'level3') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'level1';
ALTER TABLE verification_reviews MODIFY COLUMN status ENUM('pending', 'approved', 'rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending';

ALTER TABLE card_activations MODIFY COLUMN status ENUM('pending', 'activated', 'failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending';

ALTER TABLE user_sessions MODIFY COLUMN status ENUM('active', 'expired', 'revoked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active';

-- ========================================
-- 4. 创建分区表（适用于大数据量场景）
-- ========================================

-- 为系统日志表按月分区（MySQL 8.0+）
-- ALTER TABLE system_logs PARTITION BY RANGE (YEAR(created_at) * 100 + MONTH(created_at)) (
--     PARTITION p202401 VALUES LESS THAN (202402),
--     PARTITION p202402 VALUES LESS THAN (202403),
--     PARTITION p202403 VALUES LESS THAN (202404),
--     PARTITION p202404 VALUES LESS THAN (202405),
--     PARTITION p202405 VALUES LESS THAN (202406),
--     PARTITION p202406 VALUES LESS THAN (202407),
--     PARTITION p202407 VALUES LESS THAN (202408),
--     PARTITION p202408 VALUES LESS THAN (202409),
--     PARTITION p202409 VALUES LESS THAN (202410),
--     PARTITION p202410 VALUES LESS THAN (202411),
--     PARTITION p202411 VALUES LESS THAN (202412),
--     PARTITION p202412 VALUES LESS THAN (202501),
--     PARTITION p_future VALUES LESS THAN MAXVALUE
-- );

-- ========================================
-- 5. 创建优化视图
-- ========================================

-- 优化的卡片统计视图
CREATE OR REPLACE VIEW card_statistics_optimized AS
SELECT 
    c.status,
    COUNT(*) as count,
    SUM(CASE WHEN c.expiry_date < CURDATE() THEN 1 ELSE 0 END) as expired_count,
    SUM(CASE WHEN c.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as expiring_soon_count,
    DATE(c.created_at) as created_date
FROM cards c
GROUP BY c.status, DATE(c.created_at);

-- 优化的用户活动视图
CREATE OR REPLACE VIEW user_activity_optimized AS
SELECT 
    u.id,
    u.username,
    u.role,
    COUNT(DISTINCT sl.id) as login_count,
    COUNT(DISTINCT CASE WHEN sl.action = 'card_created' THEN sl.id END) as cards_created,
    MAX(sl.created_at) as last_activity,
    COUNT(DISTINCT iv.id) as verifications_created
FROM users u
LEFT JOIN system_logs sl ON u.id = sl.user_id
LEFT JOIN identity_verifications iv ON u.id = iv.created_by
GROUP BY u.id, u.username, u.role;

-- 优化的核验效率视图
CREATE OR REPLACE VIEW verification_efficiency_optimized AS
SELECT 
    DATE(iv.created_at) as verification_date,
    COUNT(*) as total_verifications,
    COUNT(CASE WHEN iv.status = 'approved' THEN 1 END) as approved_count,
    COUNT(CASE WHEN iv.status = 'rejected' THEN 1 END) as rejected_count,
    AVG(TIMESTAMPDIFF(HOUR, iv.created_at, vr.review_date)) as avg_review_hours,
    COUNT(DISTINCT iv.created_by) as unique_creators,
    COUNT(DISTINCT vr.reviewer_id) as unique_reviewers
FROM identity_verifications iv
LEFT JOIN verification_reviews vr ON iv.id = vr.verification_id
GROUP BY DATE(iv.created_at);

-- ========================================
-- 6. 创建存储过程优化常用操作
-- ========================================

DELIMITER //

-- 优化的卡片状态更新存储过程
CREATE PROCEDURE UpdateCardStatusOptimized(
    IN p_card_id INT,
    IN p_new_status VARCHAR(20),
    IN p_user_id INT,
    IN p_notes TEXT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- 更新卡片状态
    UPDATE cards 
    SET status = p_new_status, 
        updated_at = NOW()
    WHERE id = p_card_id;
    
    -- ========================================
-- 7. 性能监控和统计表
-- ========================================

-- 创建每日统计表
CREATE TABLE IF NOT EXISTS daily_card_stats (
    date DATE PRIMARY KEY,
    total_cards INT DEFAULT 0,
    active_cards INT DEFAULT 0,
    sold_cards INT DEFAULT 0,
    expired_cards INT DEFAULT 0,
    new_cards INT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS daily_user_stats (
    date DATE PRIMARY KEY,
    new_users INT DEFAULT 0,
    active_users INT DEFAULT 0,
    total_logins INT DEFAULT 0,
    unique_logins INT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS daily_verification_stats (
    date DATE PRIMARY KEY,
    total_verifications INT DEFAULT 0,
    approved_verifications INT DEFAULT 0,
    rejected_verifications INT DEFAULT 0,
    pending_verifications INT DEFAULT 0,
    avg_processing_time DECIMAL(10,2) DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建性能监控表
CREATE TABLE IF NOT EXISTS query_performance_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    query_hash VARCHAR(64) NOT NULL,
    query_type VARCHAR(50) NOT NULL,
    execution_time DECIMAL(10,4) NOT NULL,
    rows_examined INT DEFAULT 0,
    rows_returned INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_query_hash (query_hash),
    INDEX idx_execution_time (execution_time),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- 8. 自动化统计更新存储过程
-- ========================================

DELIMITER //

-- 更新每日卡片统计
CREATE PROCEDURE IF NOT EXISTS UpdateDailyCardStats()
BEGIN
    DECLARE v_date DATE DEFAULT CURDATE();
    
    INSERT INTO daily_card_stats (date, total_cards, active_cards, sold_cards, expired_cards, new_cards)
    SELECT 
        v_date,
        COUNT(*),
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'sold' THEN 1 ELSE 0 END),
        SUM(CASE WHEN expiry_date < v_date THEN 1 ELSE 0 END),
        SUM(CASE WHEN DATE(created_at) = v_date THEN 1 ELSE 0 END)
    FROM cards
    ON DUPLICATE KEY UPDATE
        total_cards = VALUES(total_cards),
        active_cards = VALUES(active_cards),
        sold_cards = VALUES(sold_cards),
        expired_cards = VALUES(expired_cards),
        new_cards = VALUES(new_cards);
END //

-- 更新每日用户统计
CREATE PROCEDURE IF NOT EXISTS UpdateDailyUserStats()
BEGIN
    DECLARE v_date DATE DEFAULT CURDATE();
    
    INSERT INTO daily_user_stats (date, new_users, active_users, total_logins, unique_logins)
    SELECT 
        v_date,
        SUM(CASE WHEN DATE(created_at) = v_date THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END),
        COUNT(CASE WHEN DATE(last_login) = v_date THEN 1 END),
        COUNT(DISTINCT CASE WHEN DATE(last_login) = v_date THEN id END)
    FROM users
    ON DUPLICATE KEY UPDATE
        new_users = VALUES(new_users),
        active_users = VALUES(active_users),
        total_logins = VALUES(total_logins),
        unique_logins = VALUES(unique_logins);
END //

-- 更新每日核验统计
CREATE PROCEDURE IF NOT EXISTS UpdateDailyVerificationStats()
BEGIN
    DECLARE v_date DATE DEFAULT CURDATE();
    
    INSERT INTO daily_verification_stats (date, total_verifications, approved_verifications, rejected_verifications, pending_verifications, avg_processing_time)
    SELECT 
        v_date,
        COUNT(*),
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END),
        AVG(CASE WHEN status IN ('approved', 'rejected') 
                 THEN TIMESTAMPDIFF(HOUR, created_at, updated_at) 
                 ELSE NULL END)
    FROM identity_verifications
    ON DUPLICATE KEY UPDATE
        total_verifications = VALUES(total_verifications),
        approved_verifications = VALUES(approved_verifications),
        rejected_verifications = VALUES(rejected_verifications),
        pending_verifications = VALUES(pending_verifications),
        avg_processing_time = VALUES(avg_processing_time);
END //

-- 清理过期数据的存储过程
CREATE PROCEDURE IF NOT EXISTS CleanupOldData()
BEGIN
    -- 清理90天前的系统日志
    DELETE FROM system_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);
    
    -- 清理30天前的查询性能日志
    DELETE FROM query_performance_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- 清理过期的用户会话
    DELETE FROM user_sessions WHERE expires_at < NOW() OR status = 'expired';
    
    -- 清理180天前的合规日志
    DELETE FROM compliance_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY);
    
    -- 优化表
    OPTIMIZE TABLE system_logs;
    OPTIMIZE TABLE query_performance_log;
    OPTIMIZE TABLE user_sessions;
    OPTIMIZE TABLE compliance_logs;
END //

-- 记录慢查询的存储过程
CREATE PROCEDURE IF NOT EXISTS LogSlowQuery(
    IN p_query_hash VARCHAR(64),
    IN p_query_type VARCHAR(50),
    IN p_execution_time DECIMAL(10,4),
    IN p_rows_examined INT,
    IN p_rows_returned INT
)
BEGIN
    INSERT INTO query_performance_log (query_hash, query_type, execution_time, rows_examined, rows_returned)
    VALUES (p_query_hash, p_query_type, p_execution_time, p_rows_examined, p_rows_returned);
END //

DELIMITER ;

-- ========================================
-- 9. 定时事件（需要启用事件调度器）
-- ========================================

-- 启用事件调度器
-- SET GLOBAL event_scheduler = ON;

-- 创建每日统计更新事件
-- CREATE EVENT IF NOT EXISTS daily_stats_update
-- ON SCHEDULE EVERY 1 DAY
-- STARTS CONCAT(CURDATE(), ' 23:59:00')
-- DO
-- BEGIN
--     CALL UpdateDailyCardStats();
--     CALL UpdateDailyUserStats();
--     CALL UpdateDailyVerificationStats();
-- END;

-- 创建每周数据清理事件
-- CREATE EVENT IF NOT EXISTS weekly_cleanup
-- ON SCHEDULE EVERY 1 WEEK
-- STARTS CONCAT(CURDATE(), ' 02:00:00')
-- DO CALL CleanupOldData();

-- ========================================
-- 10. 性能优化配置建议
-- ========================================

-- MySQL配置优化（需要管理员权限）
/*
-- 内存配置
SET GLOBAL innodb_buffer_pool_size = 1G;              -- 根据服务器内存的70-80%设置
SET GLOBAL innodb_log_buffer_size = 256M;             -- 日志缓冲区
SET GLOBAL sort_buffer_size = 4M;                     -- 排序缓冲区
SET GLOBAL join_buffer_size = 4M;                     -- 连接缓冲区

-- 查询缓存
SET GLOBAL query_cache_type = ON;                     -- 启用查询缓存
SET GLOBAL query_cache_size = 256M;                   -- 查询缓存大小

-- 连接配置
SET GLOBAL max_connections = 500;                     -- 最大连接数
SET GLOBAL innodb_thread_concurrency = 16;           -- 并发线程数

-- 日志配置
SET GLOBAL slow_query_log = ON;                       -- 启用慢查询日志
SET GLOBAL long_query_time = 2;                        -- 慢查询阈值（秒）
SET GLOBAL log_queries_not_using_indexes = ON;        -- 记录未使用索引的查询

-- InnoDB配置
SET GLOBAL innodb_flush_log_at_trx_commit = 2;         -- 平衡性能和安全性
SET GLOBAL innodb_log_file_size = 256M;                -- 日志文件大小
SET GLOBAL innodb_file_per_table = ON;                 -- 每表独立文件
SET GLOBAL innodb_open_files = 400;                    -- 打开文件数限制
*/

-- ========================================
-- 11. 监控查询
-- ========================================

-- 查看表大小
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)',
    table_rows,
    ROUND((index_length / 1024 / 1024), 2) AS 'Index Size (MB)'
FROM information_schema.tables 
WHERE table_schema = DATABASE()
ORDER BY (data_length + index_length) DESC;

-- 查看索引使用情况
SELECT 
    table_name,
    index_name,
    cardinality,
    sub_part,
    packed,
    nullable,
    index_type
FROM information_schema.statistics 
WHERE table_schema = DATABASE()
ORDER BY table_name, seq_in_index;

-- 查看慢查询
SELECT 
    start_time,
    query_time,
    lock_time,
    rows_sent,
    rows_examined,
    sql_text
FROM mysql.slow_log 
WHERE start_time >= DATE_SUB(NOW(), INTERVAL 1 DAY)
ORDER BY query_time DESC
LIMIT 10;

-- 查看连接状态
SHOW PROCESSLIST;

-- 查看InnoDB状态
SHOW ENGINE INNODB STATUS;

-- ========================================
-- 12. 执行完成提示
-- ========================================

SELECT 'Database optimization script completed successfully!' as message,
       'Please review the optimization suggestions and configure MySQL settings accordingly.' as note;
    INSERT INTO system_logs (user_id, action, description, ip_address, user_agent, created_at)
    VALUES (p_user_id, 'card_status_updated', 
            CONCAT('卡片状态更新为: ', p_new_status, ', 卡片ID: ', p_card_id, ', 备注: ', COALESCE(p_notes, '')),
            '', '', NOW());
    
    COMMIT;
END //

-- 优化的用户活动统计存储过程
CREATE PROCEDURE GetUserActivityStatsOptimized(
    IN p_user_id INT,
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    SELECT 
        u.username,
        u.role,
        COUNT(DISTINCT sl.id) as total_activities,
        COUNT(DISTINCT CASE WHEN sl.action LIKE '%login%' THEN sl.id END) as login_count,
        COUNT(DISTINCT CASE WHEN sl.action LIKE '%card%' THEN sl.id END) as card_activities,
        COUNT(DISTINCT CASE WHEN sl.action LIKE '%verification%' THEN sl.id END) as verification_activities,
        MAX(sl.created_at) as last_activity
    FROM users u
    LEFT JOIN system_logs sl ON u.id = sl.user_id 
        AND DATE(sl.created_at) BETWEEN p_start_date AND p_end_date
    WHERE u.id = p_user_id
    GROUP BY u.id, u.username, u.role;
END //

-- 批量清理过期会话存储过程
CREATE PROCEDURE CleanExpiredSessionsOptimized()
BEGIN
    DELETE FROM user_sessions 
    WHERE expires_at < NOW() 
       OR (status = 'expired' AND expires_at < DATE_SUB(NOW(), INTERVAL 7 DAY));
    
    SELECT ROW_COUNT() as cleaned_sessions;
END //

DELIMITER ;

-- ========================================
-- 7. 数据库性能监控查询
-- ========================================

-- 查看索引使用情况
-- SELECT 
--     TABLE_NAME,
--     INDEX_NAME,
--     CARDINALITY,
--     SUB_PART,
--     NULLABLE,
--     INDEX_TYPE
-- FROM information_schema.STATISTICS 
-- WHERE TABLE_SCHEMA = DATABASE()
-- ORDER BY TABLE_NAME, SEQ_IN_INDEX;

-- 查看表大小和行数
-- SELECT 
--     TABLE_NAME,
--     ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) AS 'Table Size (MB)',
--     TABLE_ROWS AS 'Row Count'
-- FROM information_schema.TABLES 
-- WHERE TABLE_SCHEMA = DATABASE()
-- ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC;

-- 查看慢查询（需要启用慢查询日志）
-- SELECT * FROM mysql.slow_log ORDER BY start_time DESC LIMIT 10;

-- ========================================
-- 8. 定期维护任务
-- ========================================

-- 分析表以优化查询计划
-- ANALYZE TABLE users, cards, system_logs, identity_verifications, verification_reviews, card_activations;

-- 优化表结构
-- OPTIMIZE TABLE users, cards, system_logs, identity_verifications, verification_reviews, card_activations;

-- 检查表完整性
-- CHECK TABLE users, cards, system_logs, identity_verifications, verification_reviews, card_activations;

-- ========================================
-- 9. 性能优化建议
-- ========================================

/*
1. 定期执行维护任务：
   - 每周执行 ANALYZE TABLE 更新统计信息
   - 每月执行 OPTIMIZE TABLE 优化表结构
   - 每季度检查和重建索引

2. 监控关键指标：
   - 查询执行时间
   - 索引使用率
   - 表大小增长趋势
   - 慢查询日志

3. 配置优化：
   - 调整 innodb_buffer_pool_size
   - 优化 query_cache_size
   - 配置适当的连接数限制

4. 备份策略：
   - 定期全量备份
   - 增量备份配置
   - 备份验证测试
*/

-- 执行优化脚本完成提示
SELECT 'Database optimization completed successfully!' as status;