-- ========================================
-- 代理系统数据库表结构
-- 版本: 1.0.0
-- 创建时间: 2024年
-- ========================================

USE `card_system`;

-- ========================================
-- 代理管理相关表
-- ========================================

-- 代理表
CREATE TABLE IF NOT EXISTS `agents` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '关联用户ID',
    `agent_code` VARCHAR(20) NOT NULL UNIQUE COMMENT '代理编号',
    `parent_agent_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '上级代理ID（最多二级）',
    `level` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '代理级别：1-一级代理，2-二级代理',
    `status` ENUM('pending', 'active', 'inactive', 'suspended') NOT NULL DEFAULT 'pending' COMMENT '状态',
    `commission_rate` DECIMAL(5,2) NOT NULL DEFAULT 5.00 COMMENT '佣金比例（百分比）',
    `sub_commission_rate` DECIMAL(5,2) DEFAULT 2.00 COMMENT '下级佣金比例（百分比）',
    `total_sales` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '总销售额',
    `total_commission` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '总佣金',
    `available_commission` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '可提现佣金',
    `team_sales` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '团队销售额',
    `team_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '团队人数',
    `contact_name` VARCHAR(50) COMMENT '联系人姓名',
    `contact_phone` VARCHAR(20) COMMENT '联系电话',
    `contact_email` VARCHAR(100) COMMENT '联系邮箱',
    `business_license` VARCHAR(255) COMMENT '营业执照图片',
    `id_card_front` VARCHAR(255) COMMENT '身份证正面',
    `id_card_back` VARCHAR(255) COMMENT '身份证背面',
    `application_reason` TEXT COMMENT '申请理由',
    `review_notes` TEXT COMMENT '审核备注',
    `reviewed_by` BIGINT UNSIGNED COMMENT '审核人ID',
    `reviewed_at` TIMESTAMP NULL COMMENT '审核时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_agent_code` (`agent_code`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_parent_agent_id` (`parent_agent_id`),
    KEY `idx_level` (`level`),
    KEY `idx_status` (`status`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`parent_agent_id`) REFERENCES `agents`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='代理表';

-- 佣金记录表
CREATE TABLE IF NOT EXISTS `commissions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `order_id` INT UNSIGNED COMMENT '关联订单ID',
    `source_agent_id` BIGINT UNSIGNED COMMENT '来源代理ID（下级代理产生佣金时）',
    `type` ENUM('direct', 'indirect', 'bonus', 'adjustment') NOT NULL COMMENT '佣金类型：direct-直接佣金，indirect-间接佣金，bonus-奖励佣金，adjustment-调整',
    `amount` DECIMAL(10,2) NOT NULL COMMENT '佣金金额',
    `rate` DECIMAL(5,2) COMMENT '佣金比例',
    `sales_amount` DECIMAL(15,2) COMMENT '销售金额',
    `description` VARCHAR(255) COMMENT '佣金说明',
    `status` ENUM('pending', 'available', 'withdrawn', 'cancelled') NOT NULL DEFAULT 'pending' COMMENT '状态',
    `available_at` TIMESTAMP NULL COMMENT '可用时间',
    `withdrawn_at` TIMESTAMP NULL COMMENT '提现时间',
    `withdrawal_id` BIGINT UNSIGNED COMMENT '提现记录ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_order_id` (`order_id`),
    KEY `idx_source_agent_id` (`source_agent_id`),
    KEY `idx_type` (`type`),
    KEY `idx_status` (`status`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`source_agent_id`) REFERENCES `agents`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='佣金记录表';

-- 推广记录表
CREATE TABLE IF NOT EXISTS `promotions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `promotion_code` VARCHAR(50) NOT NULL UNIQUE COMMENT '推广码',
    `promotion_link` VARCHAR(500) NOT NULL COMMENT '推广链接',
    `name` VARCHAR(100) NOT NULL COMMENT '推广活动名称',
    `description` TEXT COMMENT '推广描述',
    `type` ENUM('link', 'code', 'qrcode') NOT NULL DEFAULT 'link' COMMENT '推广类型',
    `target_url` VARCHAR(500) COMMENT '目标URL',
    `discount_type` ENUM('percentage', 'fixed') DEFAULT NULL COMMENT '优惠类型',
    `discount_value` DECIMAL(10,2) DEFAULT NULL COMMENT '优惠值',
    `max_uses` INT UNSIGNED DEFAULT NULL COMMENT '最大使用次数',
    `used_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '已使用次数',
    `click_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击次数',
    `conversion_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '转化次数',
    `status` ENUM('active', 'inactive', 'expired') NOT NULL DEFAULT 'active' COMMENT '状态',
    `expires_at` TIMESTAMP NULL COMMENT '过期时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_promotion_code` (`promotion_code`),
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_promotion_code` (`promotion_code`),
    KEY `idx_type` (`type`),
    KEY `idx_status` (`status`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='推广记录表';

-- 推广点击记录表
CREATE TABLE IF NOT EXISTS `promotion_clicks` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `promotion_id` BIGINT UNSIGNED NOT NULL COMMENT '推广ID',
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `ip` VARCHAR(45) COMMENT 'IP地址',
    `user_agent` TEXT COMMENT '用户代理',
    `referrer` VARCHAR(500) COMMENT '来源页面',
    `landing_page` VARCHAR(500) COMMENT '落地页',
    `session_id` VARCHAR(100) COMMENT '会话ID',
    `converted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否转化',
    `order_id` INT UNSIGNED COMMENT '转化订单ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '点击时间',
    
    KEY `idx_promotion_id` (`promotion_id`),
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_ip` (`ip`),
    KEY `idx_session_id` (`session_id`),
    KEY `idx_converted` (`converted`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`promotion_id`) REFERENCES `promotions`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='推广点击记录表';

-- 提现记录表
CREATE TABLE IF NOT EXISTS `withdrawals` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `amount` DECIMAL(10,2) NOT NULL COMMENT '提现金额',
    `fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '手续费',
    `actual_amount` DECIMAL(10,2) NOT NULL COMMENT '实际到账金额',
    `method` ENUM('bank', 'alipay', 'wechat') NOT NULL COMMENT '提现方式',
    `account_info` JSON COMMENT '账户信息',
    `status` ENUM('pending', 'processing', 'completed', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending' COMMENT '状态',
    `notes` TEXT COMMENT '备注',
    `admin_notes` TEXT COMMENT '管理员备注',
    `processed_by` BIGINT UNSIGNED COMMENT '处理人ID',
    `processed_at` TIMESTAMP NULL COMMENT '处理时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_status` (`status`),
    KEY `idx_method` (`method`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`processed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='提现记录表';

-- 代理统计表
CREATE TABLE IF NOT EXISTS `agent_statistics` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `date` DATE NOT NULL COMMENT '统计日期',
    `new_customers` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '新客户数',
    `orders_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '订单数量',
    `sales_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '销售金额',
    `commission_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '佣金金额',
    `click_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击次数',
    `conversion_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '转化次数',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_agent_date` (`agent_id`, `date`),
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_date` (`date`),
    
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='代理统计表';

-- ========================================
-- 修改现有表以支持代理功能
-- ========================================

-- 为用户表添加代理相关字段
ALTER TABLE `users` 
ADD COLUMN `is_agent` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否为代理',
ADD COLUMN `agent_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '代理ID',
ADD INDEX `idx_is_agent` (`is_agent`),
ADD INDEX `idx_agent_id` (`agent_id`);

-- 为订单表添加代理相关字段
ALTER TABLE `orders` 
ADD COLUMN `agent_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '代理ID',
ADD COLUMN `promotion_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '推广ID',
ADD COLUMN `commission_calculated` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '佣金是否已计算',
ADD INDEX `idx_agent_id` (`agent_id`),
ADD INDEX `idx_promotion_id` (`promotion_id`),
ADD INDEX `idx_commission_calculated` (`commission_calculated`);

-- ========================================
-- 添加系统配置项
-- ========================================

-- 插入代理相关配置
INSERT INTO `system_configs` (`config_key`, `config_value`, `description`, `category`, `created_at`) VALUES
('enable_agent_system', 'true', '是否启用代理系统', 'agent', NOW()),
('agent_auto_approve', 'false', '是否自动审核代理', 'agent', NOW()),
('agent_max_level', '2', '代理最大层级（最多二级分销）', 'agent', NOW()),
('agent_level1_commission', '5.00', '一级代理佣金比例', 'agent', NOW()),
('agent_level2_commission', '2.00', '二级代理佣金比例', 'agent', NOW()),
('agent_min_withdrawal', '100.00', '代理最低提现金额', 'agent', NOW()),
('agent_withdrawal_fee', '0.01', '代理提现手续费比例', 'agent', NOW()),
('promotion_link_domain', '', '推广链接域名', 'agent', NOW())
ON DUPLICATE KEY UPDATE `config_value` = VALUES(`config_value`);

-- ========================================
-- 创建触发器和存储过程
-- ========================================

-- 代理统计更新触发器
DELIMITER //
CREATE TRIGGER `update_agent_statistics` 
AFTER INSERT ON `orders` 
FOR EACH ROW
BEGIN
    IF NEW.agent_id IS NOT NULL THEN
        INSERT INTO `agent_statistics` 
        (`agent_id`, `date`, `orders_count`, `sales_amount`) 
        VALUES (NEW.agent_id, DATE(NOW()), 1, NEW.total_amount)
        ON DUPLICATE KEY UPDATE 
        `orders_count` = `orders_count` + 1,
        `sales_amount` = `sales_amount` + NEW.total_amount;
    END IF;
END//
DELIMITER ;

-- 代理佣金计算存储过程
DELIMITER //
CREATE PROCEDURE `calculate_agent_commission`(
    IN p_order_id INT UNSIGNED
)
BEGIN
    DECLARE v_agent_id BIGINT UNSIGNED;
    DECLARE v_parent_agent_id BIGINT UNSIGNED;
    DECLARE v_order_amount DECIMAL(15,2);
    DECLARE v_level1_rate DECIMAL(5,2);
    DECLARE v_level2_rate DECIMAL(5,2);
    
    -- 获取订单信息
    SELECT agent_id, total_amount INTO v_agent_id, v_order_amount
    FROM orders WHERE id = p_order_id AND agent_id IS NOT NULL;
    
    IF v_agent_id IS NOT NULL THEN
        -- 获取代理信息和佣金比例
        SELECT a.parent_agent_id, a.commission_rate, a.sub_commission_rate
        INTO v_parent_agent_id, v_level1_rate, v_level2_rate
        FROM agents a WHERE a.id = v_agent_id AND a.status = 'active';
        
        -- 计算直接佣金
        IF v_level1_rate > 0 THEN
            INSERT INTO commissions 
            (agent_id, order_id, type, amount, rate, sales_amount, description, status, available_at)
            VALUES (v_agent_id, p_order_id, 'direct', 
                    v_order_amount * v_level1_rate / 100, v_level1_rate, v_order_amount, 
                    '直接销售佣金', 'pending', DATE_ADD(NOW(), INTERVAL 7 DAY));
        END IF;
        
        -- 计算间接佣金（二级代理）
        IF v_parent_agent_id IS NOT NULL AND v_level2_rate > 0 THEN
            INSERT INTO commissions 
            (agent_id, order_id, source_agent_id, type, amount, rate, sales_amount, description, status, available_at)
            VALUES (v_parent_agent_id, p_order_id, v_agent_id, 'indirect', 
                    v_order_amount * v_level2_rate / 100, v_level2_rate, v_order_amount, 
                    '下级代理销售佣金', 'pending', DATE_ADD(NOW(), INTERVAL 7 DAY));
        END IF;
        
        -- 更新订单佣金计算状态
        UPDATE orders SET commission_calculated = 1 WHERE id = p_order_id;
    END IF;
END//
DELIMITER ;