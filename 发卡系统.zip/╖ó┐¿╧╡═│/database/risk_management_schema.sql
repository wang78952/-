-- 风控管理相关数据库表结构

-- 风控规则表
CREATE TABLE IF NOT EXISTS `risk_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `rule_name` varchar(100) NOT NULL COMMENT '规则名称',
  `rule_type` varchar(50) NOT NULL COMMENT '规则类型',
  `description` varchar(255) DEFAULT NULL COMMENT '规则描述',
  `conditions` json NOT NULL COMMENT '规则条件',
  `threshold` decimal(10,2) DEFAULT NULL COMMENT '阈值',
  `action` varchar(50) NOT NULL COMMENT '触发动作',
  `risk_score` int(11) DEFAULT NULL COMMENT '风险分值',
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled' COMMENT '规则状态',
  `priority` int(11) NOT NULL DEFAULT 0 COMMENT '优先级',
  `created_by` bigint(20) unsigned DEFAULT NULL COMMENT '创建人',
  `updated_by` bigint(20) unsigned DEFAULT NULL COMMENT '更新人',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_rule_type` (`rule_type`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='风控规则表';

-- 风控事件表
CREATE TABLE IF NOT EXISTS `risk_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `event_type` varchar(50) NOT NULL COMMENT '事件类型',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '用户ID',
  `merchant_id` bigint(20) unsigned DEFAULT NULL COMMENT '商户ID',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `device_id` varchar(100) DEFAULT NULL COMMENT '设备ID',
  `user_agent` text COMMENT '用户代理',
  `related_data` json DEFAULT NULL COMMENT '相关数据',
  `triggered_rules` json DEFAULT NULL COMMENT '触发的规则',
  `risk_score` int(11) DEFAULT NULL COMMENT '风险分值',
  `risk_level` enum('low','medium','high','critical') DEFAULT NULL COMMENT '风险等级',
  `status` enum('pending','reviewed','resolved','false_positive') NOT NULL DEFAULT 'pending' COMMENT '处理状态',
  `action_taken` varchar(100) DEFAULT NULL COMMENT '已采取的措施',
  `reviewed_by` bigint(20) unsigned DEFAULT NULL COMMENT '审核人',
  `reviewed_at` timestamp NULL DEFAULT NULL COMMENT '审核时间',
  `review_notes` text COMMENT '审核说明',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_merchant_id` (`merchant_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_risk_level` (`risk_level`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='风控事件表';

-- 用户行为表
CREATE TABLE IF NOT EXISTS `user_behaviors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '用户ID',
  `behavior_type` varchar(50) NOT NULL COMMENT '行为类型',
  `behavior_data` json DEFAULT NULL COMMENT '行为数据',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `device_id` varchar(100) DEFAULT NULL COMMENT '设备ID',
  `user_agent` text COMMENT '用户代理',
  `location` varchar(255) DEFAULT NULL COMMENT '地理位置',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_behavior_type` (`behavior_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户行为表';

-- 商户信用评级表
CREATE TABLE IF NOT EXISTS `merchant_credit_rating` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `merchant_id` bigint(20) unsigned NOT NULL COMMENT '商户ID',
  `credit_score` int(11) NOT NULL DEFAULT 0 COMMENT '信用分数',
  `credit_level` enum('excellent','good','average','poor','bad') NOT NULL DEFAULT 'average' COMMENT '信用等级',
  `transaction_volume` decimal(18,2) NOT NULL DEFAULT 0 COMMENT '交易量',
  `success_rate` decimal(5,2) NOT NULL DEFAULT 100 COMMENT '交易成功率',
  `dispute_rate` decimal(5,2) NOT NULL DEFAULT 0 COMMENT '纠纷率',
  `refund_rate` decimal(5,2) NOT NULL DEFAULT 0 COMMENT '退款率',
  `avg_processing_time` decimal(10,2) NOT NULL DEFAULT 0 COMMENT '平均处理时间(分钟)',
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_merchant_id` (`merchant_id`),
  KEY `idx_credit_level` (`credit_level`),
  KEY `idx_credit_score` (`credit_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商户信用评级表';

-- 商户权限限制表
CREATE TABLE IF NOT EXISTS `merchant_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `merchant_id` bigint(20) unsigned NOT NULL COMMENT '商户ID',
  `max_listings` int(11) DEFAULT NULL COMMENT '最大上架数量',
  `max_daily_sales` int(11) DEFAULT NULL COMMENT '每日最大销售数量',
  `withdrawal_speed` enum('instant','same_day','next_day','slow') DEFAULT 'next_day' COMMENT '提现速度',
  `manual_review_required` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否需要人工审核',
  `credit_limit` decimal(18,2) DEFAULT NULL COMMENT '信用额度',
  `status` enum('active','restricted','suspended') NOT NULL DEFAULT 'active' COMMENT '权限状态',
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_merchant_id` (`merchant_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商户权限限制表';

-- IP异常检测表
CREATE TABLE IF NOT EXISTS `ip_anomalies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ip_address` varchar(45) NOT NULL COMMENT 'IP地址',
  `anomaly_type` varchar(50) NOT NULL COMMENT '异常类型',
  `anomaly_count` int(11) NOT NULL DEFAULT 1 COMMENT '异常次数',
  `last_detected` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后检测时间',
  `location` varchar(255) DEFAULT NULL COMMENT '地理位置',
  `isp` varchar(100) DEFAULT NULL COMMENT '网络服务提供商',
  `risk_level` enum('low','medium','high','critical') DEFAULT 'medium' COMMENT '风险等级',
  `action_taken` varchar(100) DEFAULT NULL COMMENT '已采取的措施',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_anomaly_type` (`anomaly_type`),
  KEY `idx_risk_level` (`risk_level`),
  KEY `idx_last_detected` (`last_detected`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IP异常检测表';

-- 设备指纹表
CREATE TABLE IF NOT EXISTS `device_fingerprints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `device_id` varchar(100) NOT NULL COMMENT '设备ID',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '关联用户ID',
  `browser` varchar(100) DEFAULT NULL COMMENT '浏览器',
  `os` varchar(100) DEFAULT NULL COMMENT '操作系统',
  `screen_resolution` varchar(50) DEFAULT NULL COMMENT '屏幕分辨率',
  `device_type` varchar(50) DEFAULT NULL COMMENT '设备类型',
  `first_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次出现时间',
  `last_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后出现时间',
  `anomaly_count` int(11) NOT NULL DEFAULT 0 COMMENT '异常次数',
  `risk_score` int(11) NOT NULL DEFAULT 0 COMMENT '风险分值',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id` (`device_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_last_seen` (`last_seen`),
  KEY `idx_risk_score` (`risk_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备指纹表';

-- 风控统计数据
CREATE TABLE IF NOT EXISTS `risk_statistics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stat_date` date NOT NULL COMMENT '统计日期',
  `total_events` int(11) NOT NULL DEFAULT 0 COMMENT '总事件数',
  `low_risk_events` int(11) NOT NULL DEFAULT 0 COMMENT '低风险事件',
  `medium_risk_events` int(11) NOT NULL DEFAULT 0 COMMENT '中风险事件',
  `high_risk_events` int(11) NOT NULL DEFAULT 0 COMMENT '高风险事件',
  `critical_risk_events` int(11) NOT NULL DEFAULT 0 COMMENT '严重风险事件',
  `blocked_attempts` int(11) NOT NULL DEFAULT 0 COMMENT '拦截尝试次数',
  `unique_ips` int(11) NOT NULL DEFAULT 0 COMMENT '独立IP数',
  `unique_users` int(11) NOT NULL DEFAULT 0 COMMENT '独立用户数',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_stat_date` (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='风控统计数据表';

-- 创建存储过程：更新商户信用评分
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `UpdateMerchantCreditScore`(IN merchant_id_param BIGINT)
BEGIN
    DECLARE transaction_volume DECIMAL(18,2);
    DECLARE success_count INT;
    DECLARE total_count INT;
    DECLARE dispute_count INT;
    DECLARE refund_count INT;
    DECLARE avg_processing_time DECIMAL(10,2);
    DECLARE success_rate DECIMAL(5,2);
    DECLARE dispute_rate DECIMAL(5,2);
    DECLARE refund_rate DECIMAL(5,2);
    DECLARE credit_score INT;
    DECLARE credit_level ENUM('excellent','good','average','poor','bad');
    
    -- 计算交易量
    SELECT COALESCE(SUM(amount), 0) INTO transaction_volume
    FROM orders
    WHERE merchant_id = merchant_id_param AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- 计算交易成功率
    SELECT 
        COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END), 0),
        COALESCE(COUNT(*), 0)
    INTO success_count, total_count
    FROM orders
    WHERE merchant_id = merchant_id_param AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    SET success_rate = CASE WHEN total_count > 0 THEN ROUND((success_count / total_count) * 100, 2) ELSE 100 END;
    
    -- 计算纠纷率
    SELECT COALESCE(COUNT(*), 0) INTO dispute_count
    FROM disputes
    WHERE merchant_id = merchant_id_param AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    SET dispute_rate = CASE WHEN total_count > 0 THEN ROUND((dispute_count / total_count) * 100, 2) ELSE 0 END;
    
    -- 计算退款率
    SELECT COALESCE(COUNT(*), 0) INTO refund_count
    FROM refunds
    WHERE merchant_id = merchant_id_param AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    SET refund_rate = CASE WHEN total_count > 0 THEN ROUND((refund_count / total_count) * 100, 2) ELSE 0 END;
    
    -- 计算平均处理时间
    SELECT COALESCE(AVG(TIMESTAMPDIFF(MINUTE, created_at, updated_at)), 0) INTO avg_processing_time
    FROM orders
    WHERE merchant_id = merchant_id_param 
      AND status = 'completed' 
      AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- 计算信用分数 (基于多维度评分)
    SET credit_score = 100;
    
    -- 交易量评分 (最高30分)
    IF transaction_volume >= 100000 THEN
        SET credit_score = credit_score + 30;
    ELSEIF transaction_volume >= 50000 THEN
        SET credit_score = credit_score + 25;
    ELSEIF transaction_volume >= 20000 THEN
        SET credit_score = credit_score + 20;
    ELSEIF transaction_volume >= 10000 THEN
        SET credit_score = credit_score + 15;
    ELSEIF transaction_volume >= 5000 THEN
        SET credit_score = credit_score + 10;
    ELSEIF transaction_volume >= 1000 THEN
        SET credit_score = credit_score + 5;
    END IF;
    
    -- 交易成功率评分 (最高25分)
    IF success_rate >= 99 THEN
        SET credit_score = credit_score + 25;
    ELSEIF success_rate >= 97 THEN
        SET credit_score = credit_score + 20;
    ELSEIF success_rate >= 95 THEN
        SET credit_score = credit_score + 15;
    ELSEIF success_rate >= 90 THEN
        SET credit_score = credit_score + 10;
    ELSEIF success_rate >= 85 THEN
        SET credit_score = credit_score + 5;
    ELSE
        SET credit_score = credit_score - 10;
    END IF;
    
    -- 纠纷率评分 (最高20分)
    IF dispute_rate = 0 THEN
        SET credit_score = credit_score + 20;
    ELSEIF dispute_rate <= 0.5 THEN
        SET credit_score = credit_score + 15;
    ELSEIF dispute_rate <= 1 THEN
        SET credit_score = credit_score + 10;
    ELSEIF dispute_rate <= 2 THEN
        SET credit_score = credit_score + 5;
    ELSEIF dispute_rate <= 5 THEN
        SET credit_score = credit_score - 5;
    ELSE
        SET credit_score = credit_score - 15;
    END IF;
    
    -- 退款率评分 (最高15分)
    IF refund_rate = 0 THEN
        SET credit_score = credit_score + 15;
    ELSEIF refund_rate <= 1 THEN
        SET credit_score = credit_score + 12;
    ELSEIF refund_rate <= 3 THEN
        SET credit_score = credit_score + 8;
    ELSEIF refund_rate <= 5 THEN
        SET credit_score = credit_score + 5;
    ELSEIF refund_rate <= 10 THEN
        SET credit_score = credit_score - 5;
    ELSE
        SET credit_score = credit_score - 10;
    END IF;
    
    -- 处理时间评分 (最高10分)
    IF avg_processing_time <= 30 THEN
        SET credit_score = credit_score + 10;
    ELSEIF avg_processing_time <= 60 THEN
        SET credit_score = credit_score + 8;
    ELSEIF avg_processing_time <= 120 THEN
        SET credit_score = credit_score + 5;
    ELSEIF avg_processing_time <= 240 THEN
        SET credit_score = credit_score + 2;
    ELSE
        SET credit_score = credit_score - 5;
    END IF;
    
    -- 限制分数范围
    SET credit_score = GREATEST(0, LEAST(200, credit_score));
    
    -- 确定信用等级
    IF credit_score >= 160 THEN
        SET credit_level = 'excellent';
    ELSEIF credit_score >= 130 THEN
        SET credit_level = 'good';
    ELSEIF credit_score >= 100 THEN
        SET credit_level = 'average';
    ELSEIF credit_score >= 70 THEN
        SET credit_level = 'poor';
    ELSE
        SET credit_level = 'bad';
    END IF;
    
    -- 更新商户信用评级
    INSERT INTO merchant_credit_rating (
        merchant_id, credit_score, credit_level, 
        transaction_volume, success_rate, dispute_rate, refund_rate, 
        avg_processing_time
    ) VALUES (
        merchant_id_param, credit_score, credit_level, 
        transaction_volume, success_rate, dispute_rate, refund_rate, 
        avg_processing_time
    ) ON DUPLICATE KEY UPDATE 
        credit_score = VALUES(credit_score),
        credit_level = VALUES(credit_level),
        transaction_volume = VALUES(transaction_volume),
        success_rate = VALUES(success_rate),
        dispute_rate = VALUES(dispute_rate),
        refund_rate = VALUES(refund_rate),
        avg_processing_time = VALUES(avg_processing_time),
        last_updated = NOW();
    
    -- 更新商户权限限制
    CALL UpdateMerchantPermissions(merchant_id_param, credit_level);
END//
DELIMITER ;

-- 创建存储过程：更新商户权限
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `UpdateMerchantPermissions`(IN merchant_id_param BIGINT, IN credit_level_param ENUM('excellent','good','average','poor','bad'))
BEGIN
    DECLARE max_listings INT;
    DECLARE max_daily_sales INT;
    DECLARE withdrawal_speed ENUM('instant','same_day','next_day','slow');
    DECLARE manual_review_required TINYINT;
    DECLARE credit_limit DECIMAL(18,2);
    DECLARE status ENUM('active','restricted','suspended');
    
    -- 根据信用等级设置权限
    CASE credit_level_param
        WHEN 'excellent' THEN
            SET max_listings = 1000;
            SET max_daily_sales = 5000;
            SET withdrawal_speed = 'instant';
            SET manual_review_required = 0;
            SET credit_limit = 100000;
            SET status = 'active';
        WHEN 'good' THEN
            SET max_listings = 500;
            SET max_daily_sales = 3000;
            SET withdrawal_speed = 'same_day';
            SET manual_review_required = 0;
            SET credit_limit = 50000;
            SET status = 'active';
        WHEN 'average' THEN
            SET max_listings = 200;
            SET max_daily_sales = 1000;
            SET withdrawal_speed = 'next_day';
            SET manual_review_required = 0;
            SET credit_limit = 20000;
            SET status = 'active';
        WHEN 'poor' THEN
            SET max_listings = 100;
            SET max_daily_sales = 500;
            SET withdrawal_speed = 'slow';
            SET manual_review_required = 1;
            SET credit_limit = 10000;
            SET status = 'restricted';
        WHEN 'bad' THEN
            SET max_listings = 50;
            SET max_daily_sales = 100;
            SET withdrawal_speed = 'slow';
            SET manual_review_required = 1;
            SET credit_limit = 5000;
            SET status = 'restricted';
    END CASE;
    
    -- 插入或更新商户权限限制
    INSERT INTO merchant_permissions (
        merchant_id, max_listings, max_daily_sales, withdrawal_speed, 
        manual_review_required, credit_limit, status
    ) VALUES (
        merchant_id_param, max_listings, max_daily_sales, withdrawal_speed, 
        manual_review_required, credit_limit, status
    ) ON DUPLICATE KEY UPDATE
        max_listings = VALUES(max_listings),
        max_daily_sales = VALUES(max_daily_sales),
        withdrawal_speed = VALUES(withdrawal_speed),
        manual_review_required = VALUES(manual_review_required),
        credit_limit = VALUES(credit_limit),
        status = VALUES(status);
END//
DELIMITER ;

-- 创建视图：风控仪表盘概览
CREATE OR REPLACE VIEW `v_risk_dashboard` AS
SELECT
    (SELECT COUNT(*) FROM risk_events WHERE DATE(created_at) = CURRENT_DATE) AS today_events,
    (SELECT COUNT(*) FROM risk_events WHERE DATE(created_at) = CURRENT_DATE AND risk_level = 'critical') AS today_critical,
    (SELECT COUNT(*) FROM risk_events WHERE DATE(created_at) = CURRENT_DATE AND risk_level = 'high') AS today_high,
    (SELECT COUNT(*) FROM ip_anomalies WHERE DATE(last_detected) = CURRENT_DATE) AS today_ip_anomalies,
    (SELECT COUNT(*) FROM user_behaviors WHERE DATE(created_at) = CURRENT_DATE) AS today_behaviors,
    (SELECT COUNT(*) FROM merchant_credit_rating WHERE credit_level IN ('poor', 'bad')) AS high_risk_merchants,
    (SELECT COUNT(*) FROM merchant_permissions WHERE status = 'restricted') AS restricted_merchants;

-- 插入默认风控规则
INSERT INTO `risk_rules` (`rule_name`, `rule_type`, `description`, `conditions`, `threshold`, `action`, `risk_score`, `status`, `priority`) VALUES
('多次登录失败', 'login', '短时间内多次登录失败', '{"time_window": 300, "max_attempts": 5}', 5, 'block_login', 80, 'enabled', 10),
('异常IP登录', 'login', '从未使用过的IP地址登录', '{"days_to_check": 30}', NULL, 'verify_identity', 60, 'enabled', 20),
('批量注册检测', 'registration', '同一IP短时间内注册多个账号', '{"time_window": 3600, "max_registrations": 5}', 5, 'block_registration', 90, 'enabled', 10),
('高频交易检测', 'transaction', '短时间内多次交易', '{"time_window": 300, "max_transactions": 10}', 10, 'review_transaction', 70, 'enabled', 15),
('异常交易金额', 'transaction', '交易金额与历史模式不符', '{"percentage_deviation": 300}', 300, 'flag_transaction', 65, 'enabled', 25),
('批量退款检测', 'refund', '短时间内多次退款', '{"time_window": 86400, "max_refunds": 10}', 10, 'review_refund', 85, 'enabled', 15),
('异常地点访问', 'access', '短时间内从地理距离较远的地点访问', '{"time_window": 3600, "distance_threshold": 500}', 500, 'require_verification', 75, 'enabled', 20),
('敏感操作监控', 'operation', '管理员敏感操作监控', '{"operation_types": ["modify_permission", "delete_user", "update_config"]}', NULL, 'log_audit', 50, 'enabled', 5);

-- 创建索引优化
CREATE INDEX IF NOT EXISTS `idx_risk_events_user_created` ON `risk_events` (`user_id`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_risk_events_merchant_created` ON `risk_events` (`merchant_id`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_user_behaviors_user_created` ON `user_behaviors` (`user_id`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_merchant_credit_rating_level` ON `merchant_credit_rating` (`credit_level`);
CREATE INDEX IF NOT EXISTS `idx_ip_anomalies_risk_last` ON `ip_anomalies` (`risk_level`, `last_detected`);