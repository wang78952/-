-- 权限管理数据库表结构
-- 创建时间: 2025-01-17

-- 角色表
CREATE TABLE IF NOT EXISTS `roles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL UNIQUE COMMENT '角色名称',
    `display_name` VARCHAR(100) NOT NULL COMMENT '角色显示名称',
    `description` TEXT COMMENT '角色描述',
    `level` INT NOT NULL DEFAULT 0 COMMENT '角色级别，数字越大权限越高',
    `is_system` BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否系统角色',
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_role_name` (`name`),
    INDEX `idx_role_level` (`level`),
    INDEX `idx_role_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色表';

-- 权限表
CREATE TABLE IF NOT EXISTS `permissions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE COMMENT '权限名称',
    `display_name` VARCHAR(100) NOT NULL COMMENT '权限显示名称',
    `description` TEXT COMMENT '权限描述',
    `module` VARCHAR(50) NOT NULL COMMENT '所属模块',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型',
    `resource` VARCHAR(100) COMMENT '资源标识',
    `is_system` BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否系统权限',
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_permission_name` (`name`),
    INDEX `idx_permission_module` (`module`),
    INDEX `idx_permission_action` (`action`),
    INDEX `idx_permission_resource` (`resource`),
    INDEX `idx_permission_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限表';

-- 角色权限关联表
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `role_id` INT NOT NULL,
    `permission_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `created_by` INT COMMENT '创建人ID',
    FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    UNIQUE KEY `uk_role_permission` (`role_id`, `permission_id`),
    INDEX `idx_role_permissions_role` (`role_id`),
    INDEX `idx_role_permissions_permission` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色权限关联表';

-- 用户角色关联表
CREATE TABLE IF NOT EXISTS `user_roles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `role_id` INT NOT NULL,
    `assigned_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `assigned_by` INT COMMENT '分配人ID',
    `expires_at` TIMESTAMP NULL COMMENT '过期时间',
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`assigned_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    UNIQUE KEY `uk_user_role` (`user_id`, `role_id`),
    INDEX `idx_user_roles_user` (`user_id`),
    INDEX `idx_user_roles_role` (`role_id`),
    INDEX `idx_user_roles_active` (`is_active`),
    INDEX `idx_user_roles_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户角色关联表';

-- 权限申请表
CREATE TABLE IF NOT EXISTS `permission_requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `role_id` INT COMMENT '申请的角色ID',
    `permission_id` INT COMMENT '申请的权限ID',
    `request_type` ENUM('role', 'permission') NOT NULL COMMENT '申请类型：role-角色，permission-权限',
    `reason` TEXT NOT NULL COMMENT '申请理由',
    `status` ENUM('pending', 'approved', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending' COMMENT '申请状态',
    `priority` ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium' COMMENT '优先级',
    `requested_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `reviewed_at` TIMESTAMP NULL COMMENT '审核时间',
    `reviewed_by` INT COMMENT '审核人ID',
    `review_comment` TEXT COMMENT '审核意见',
    `approved_at` TIMESTAMP NULL COMMENT '批准时间',
    `approved_by` INT COMMENT '批准人ID',
    `expires_at` TIMESTAMP NULL COMMENT '权限过期时间',
    `auto_approve` BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否自动批准',
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_permission_requests_user` (`user_id`),
    INDEX `idx_permission_requests_role` (`role_id`),
    INDEX `idx_permission_requests_permission` (`permission_id`),
    INDEX `idx_permission_requests_status` (`status`),
    INDEX `idx_permission_requests_type` (`request_type`),
    INDEX `idx_permission_requests_priority` (`priority`),
    INDEX `idx_permission_requests_requested` (`requested_at`),
    INDEX `idx_permission_requests_reviewed` (`reviewed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限申请表';

-- 权限审批流程表
CREATE TABLE IF NOT EXISTS `approval_workflows` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL COMMENT '流程名称',
    `description` TEXT COMMENT '流程描述',
    `module` VARCHAR(50) NOT NULL COMMENT '适用模块',
    `request_type` ENUM('role', 'permission') NOT NULL COMMENT '申请类型',
    `min_level` INT NOT NULL DEFAULT 0 COMMENT '最低审批级别',
    `max_level` INT NOT NULL DEFAULT 999 COMMENT '最高审批级别',
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_approval_workflows_name` (`name`),
    INDEX `idx_approval_workflows_module` (`module`),
    INDEX `idx_approval_workflows_type` (`request_type`),
    INDEX `idx_approval_workflows_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限审批流程表';

-- 审批步骤表
CREATE TABLE IF NOT EXISTS `approval_steps` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `workflow_id` INT NOT NULL,
    `step_order` INT NOT NULL COMMENT '步骤顺序',
    `step_type` ENUM('sequential', 'parallel', 'conditional') NOT NULL DEFAULT 'sequential' COMMENT '步骤类型',
    `required_role_id` INT COMMENT '需要的角色ID',
    `required_permission` VARCHAR(100) COMMENT '需要的权限',
    `min_approvers` INT NOT NULL DEFAULT 1 COMMENT '最少审批人数',
    `max_approvers` INT NOT NULL DEFAULT 1 COMMENT '最多审批人数',
    `timeout_hours` INT NOT NULL DEFAULT 72 COMMENT '超时时间（小时）',
    `is_required` BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否必需',
    `conditions` JSON COMMENT '条件配置',
    FOREIGN KEY (`workflow_id`) REFERENCES `approval_workflows`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`required_role_id`) REFERENCES `roles`(`id`) ON DELETE SET NULL,
    INDEX `idx_approval_steps_workflow` (`workflow_id`),
    INDEX `idx_approval_steps_order` (`step_order`),
    INDEX `idx_approval_steps_role` (`required_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审批步骤表';

-- 权限申请审批记录表
CREATE TABLE IF NOT EXISTS `permission_approvals` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `request_id` INT NOT NULL,
    `step_id` INT NOT NULL,
    `approver_id` INT NOT NULL,
    `action` ENUM('approve', 'reject', 'forward', 'return') NOT NULL COMMENT '审批动作',
    `comment` TEXT COMMENT '审批意见',
    `approved_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `next_approver_id` INT COMMENT '转交的下一个审批人ID',
    FOREIGN KEY (`request_id`) REFERENCES `permission_requests`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`step_id`) REFERENCES `approval_steps`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`approver_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`next_approver_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_permission_approvals_request` (`request_id`),
    INDEX `idx_permission_approvals_step` (`step_id`),
    INDEX `idx_permission_approvals_approver` (`approver_id`),
    INDEX `idx_permission_approvals_action` (`action`),
    INDEX `idx_permission_approvals_approved` (`approved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限申请审批记录表';

-- 用户权限缓存表（用于快速权限检查）
CREATE TABLE IF NOT EXISTS `user_permissions_cache` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `permission_name` VARCHAR(100) NOT NULL,
    `granted_via` ENUM('role', 'direct', 'temporary') NOT NULL COMMENT '权限来源',
    `source_id` INT COMMENT '来源ID（角色ID或直接授权ID）',
    `expires_at` TIMESTAMP NULL COMMENT '过期时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `uk_user_permission` (`user_id`, `permission_name`),
    INDEX `idx_user_permissions_cache_user` (`user_id`),
    INDEX `idx_user_permissions_cache_permission` (`permission_name`),
    INDEX `idx_user_permissions_cache_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户权限缓存表';

-- 权限操作日志表
CREATE TABLE IF NOT EXISTS `permission_audit_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `target_user_id` INT COMMENT '目标用户ID',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型',
    `resource_type` ENUM('role', 'permission', 'user_role', 'user_permission') NOT NULL COMMENT '资源类型',
    `resource_id` INT COMMENT '资源ID',
    `old_value` JSON COMMENT '旧值',
    `new_value` JSON COMMENT '新值',
    `ip_address` VARCHAR(45) COMMENT 'IP地址',
    `user_agent` TEXT COMMENT '用户代理',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`target_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_permission_audit_user` (`user_id`),
    INDEX `idx_permission_audit_target` (`target_user_id`),
    INDEX `idx_permission_audit_action` (`action`),
    INDEX `idx_permission_audit_resource` (`resource_type`),
    INDEX `idx_permission_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限操作日志表';

-- 权限配置表
CREATE TABLE IF NOT EXISTS `permission_settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) NOT NULL UNIQUE COMMENT '配置键',
    `value` TEXT NOT NULL COMMENT '配置值',
    `description` TEXT COMMENT '配置描述',
    `type` ENUM('string', 'number', 'boolean', 'json') NOT NULL DEFAULT 'string' COMMENT '值类型',
    `is_system` BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否系统配置',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_permission_settings_key` (`key`),
    INDEX `idx_permission_settings_system` (`is_system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限配置表';

-- 插入默认角色
INSERT INTO `roles` (`name`, `display_name`, `description`, `level`, `is_system`) VALUES
('super_admin', '超级管理员', '拥有系统所有权限的超级管理员', 100, TRUE),
('admin', '管理员', '拥有大部分管理权限的管理员', 80, TRUE),
('operator', '操作员', '负责日常操作的运营人员', 60, TRUE),
('auditor', '审计员', '负责审计和合规检查的人员', 50, TRUE),
('support', '客服', '负责客户支持和售后服务', 40, TRUE),
('user', '普通用户', '普通注册用户', 20, TRUE),
('guest', '访客', '未登录的访客用户', 10, TRUE);

-- 插入默认权限
INSERT INTO `permissions` (`name`, `display_name`, `description`, `module`, `action`, `resource`, `is_system`) VALUES
-- 用户管理权限
('user.view', '查看用户', '查看用户列表和详情', 'user', 'view', 'user', TRUE),
('user.create', '创建用户', '创建新用户', 'user', 'create', 'user', TRUE),
('user.edit', '编辑用户', '编辑用户信息', 'user', 'edit', 'user', TRUE),
('user.delete', '删除用户', '删除用户', 'user', 'delete', 'user', TRUE),
('user.assign_role', '分配角色', '为用户分配角色', 'user', 'assign', 'role', TRUE),

-- 角色管理权限
('role.view', '查看角色', '查看角色列表和详情', 'role', 'view', 'role', TRUE),
('role.create', '创建角色', '创建新角色', 'role', 'create', 'role', TRUE),
('role.edit', '编辑角色', '编辑角色信息', 'role', 'edit', 'role', TRUE),
('role.delete', '删除角色', '删除角色', 'role', 'delete', 'role', TRUE),
('role.assign_permission', '分配权限', '为角色分配权限', 'role', 'assign', 'permission', TRUE),

-- 权限管理权限
('permission.view', '查看权限', '查看权限列表', 'permission', 'view', 'permission', TRUE),
('permission.create', '创建权限', '创建新权限', 'permission', 'create', 'permission', TRUE),
('permission.edit', '编辑权限', '编辑权限信息', 'permission', 'edit', 'permission', TRUE),
('permission.delete', '删除权限', '删除权限', 'permission', 'delete', 'permission', TRUE),

-- 权限申请权限
('permission.request', '申请权限', '申请角色或权限', 'permission', 'request', 'request', TRUE),
('permission.approve', '审批权限', '审批权限申请', 'permission', 'approve', 'request', TRUE),
('permission.audit', '审计权限', '查看权限审计日志', 'permission', 'audit', 'audit', TRUE),

-- 卡密管理权限
('card.view', '查看卡密', '查看卡密列表和详情', 'card', 'view', 'card', TRUE),
('card.create', '创建卡密', '批量创建卡密', 'card', 'create', 'card', TRUE),
('card.edit', '编辑卡密', '编辑卡密信息', 'card', 'edit', 'card', TRUE),
('card.delete', '删除卡密', '删除卡密', 'card', 'delete', 'card', TRUE),
('card.export', '导出卡密', '导出卡密数据', 'card', 'export', 'card', TRUE),

-- 订单管理权限
('order.view', '查看订单', '查看订单列表和详情', 'order', 'view', 'order', TRUE),
('order.create', '创建订单', '创建新订单', 'order', 'create', 'order', TRUE),
('order.edit', '编辑订单', '编辑订单信息', 'order', 'edit', 'order', TRUE),
('order.delete', '删除订单', '删除订单', 'order', 'delete', 'order', TRUE),
('order.process', '处理订单', '处理订单发货等', 'order', 'process', 'order', TRUE),
('order.refund', '退款处理', '处理订单退款', 'order', 'refund', 'order', TRUE),

-- 支付管理权限
('payment.view', '查看支付', '查看支付记录', 'payment', 'view', 'payment', TRUE),
('payment.process', '处理支付', '处理支付相关操作', 'payment', 'process', 'payment', TRUE),
('payment.refund', '支付退款', '处理支付退款', 'payment', 'refund', 'payment', TRUE),

-- 安全管理权限
('security.view', '查看安全', '查看安全设置和日志', 'security', 'view', 'security', TRUE),
('security.config', '安全配置', '配置安全参数', 'security', 'config', 'security', TRUE),
('security.audit', '安全审计', '查看安全审计日志', 'security', 'audit', 'audit', TRUE),

-- 合规管理权限
('compliance.view', '查看合规', '查看合规信息', 'compliance', 'view', 'compliance', TRUE),
('compliance.aml', 'AML管理', '反洗钱管理', 'compliance', 'aml', 'aml', TRUE),
('compliance.kyc', 'KYC管理', '身份验证管理', 'compliance', 'kyc', 'kyc', TRUE),

-- 系统管理权限
('system.view', '查看系统', '查看系统信息', 'system', 'view', 'system', TRUE),
('system.config', '系统配置', '配置系统参数', 'system', 'config', 'system', TRUE),
('system.backup', '系统备份', '执行系统备份', 'system', 'backup', 'backup', TRUE),
('system.monitor', '系统监控', '查看系统监控', 'system', 'monitor', 'monitor', TRUE);

-- 为超级管理员角色分配所有权限
INSERT INTO `role_permissions` (role_id, permission_id)
SELECT 1, id FROM `permissions` WHERE `is_active` = TRUE;

-- 为管理员角色分配大部分权限（除了系统级权限）
INSERT INTO `role_permissions` (role_id, permission_id)
SELECT 2, id FROM `permissions` 
WHERE `is_active` = TRUE 
AND `name` NOT IN ('system.config', 'system.backup', 'permission.delete', 'role.delete');

-- 为操作员分配基础操作权限
INSERT INTO `role_permissions` (role_id, permission_id)
SELECT 3, id FROM `permissions` 
WHERE `is_active` = TRUE 
AND `module` IN ('card', 'order', 'payment', 'user')
AND `action` IN ('view', 'create', 'edit', 'process');

-- 为审计员分配查看权限
INSERT INTO `role_permissions` (role_id, permission_id)
SELECT 4, id FROM `permissions` 
WHERE `is_active` = TRUE 
AND (`action` = 'view' OR `name` LIKE '%audit%');

-- 为客服分配基础支持权限
INSERT INTO `role_permissions` (role_id, permission_id)
SELECT 5, id FROM `permissions` 
WHERE `is_active` = TRUE 
AND `module` IN ('card', 'order', 'user')
AND `action` IN ('view');

-- 为普通用户分配基础权限
INSERT INTO `role_permissions` (role_id, permission_id)
SELECT 6, id FROM `permissions` 
WHERE `is_active` = TRUE 
AND `name` IN ('card.view', 'order.view', 'user.view');

-- 插入默认审批流程
INSERT INTO `approval_workflows` (`name`, `description`, `module`, `request_type`, `min_level`, `max_level`) VALUES
('角色申请审批', '用户申请角色的标准审批流程', 'role', 'role', 60, 100),
('权限申请审批', '用户申请权限的标准审批流程', 'permission', 'permission', 60, 100),
('高级权限审批', '高级权限申请的严格审批流程', 'permission', 'permission', 80, 100);

-- 插入审批步骤
INSERT INTO `approval_steps` (`workflow_id`, `step_order`, `step_type`, `required_role_id`, `min_approvers`, `max_approvers`) VALUES
(1, 1, 'sequential', 3, 1, 1), -- 操作员初审
(1, 2, 'sequential', 2, 1, 1), -- 管理员终审
(2, 1, 'sequential', 3, 1, 1), -- 操作员初审
(2, 2, 'sequential', 2, 1, 1), -- 管理员终审
(3, 1, 'sequential', 2, 1, 1), -- 管理员初审
(3, 2, 'sequential', 1, 1, 1); -- 超级管理员终审

-- 插入默认配置
INSERT INTO `permission_settings` (`key`, `value`, `description`, `type`, `is_system`) VALUES
('cache_enabled', 'true', '是否启用权限缓存', 'boolean', TRUE),
('cache_ttl', '3600', '权限缓存过期时间（秒）', 'number', TRUE),
('auto_approve_low_risk', 'true', '是否自动批准低风险申请', 'boolean', TRUE),
('max_pending_requests', '10', '用户最大待审批申请数', 'number', TRUE),
('request_timeout_hours', '72', '申请超时时间（小时）', 'number', TRUE),
('allow_self_approval', 'false', '是否允许自我审批', 'boolean', TRUE),
('require_reason', 'true', '是否必须填写申请理由', 'boolean', TRUE),
('audit_log_retention_days', '365', '审计日志保留天数', 'number', TRUE);

-- 创建触发器：用户角色变更时更新权限缓存
DELIMITER //
CREATE TRIGGER `update_user_permissions_cache` 
AFTER INSERT ON `user_roles`
FOR EACH ROW
BEGIN
    -- 删除该用户的旧权限缓存
    DELETE FROM `user_permissions_cache` WHERE `user_id` = NEW.`user_id`;
    
    -- 重新生成权限缓存（这里简化处理，实际应用中可能需要更复杂的逻辑）
    INSERT INTO `user_permissions_cache` (`user_id`, `permission_name`, `granted_via`, `source_id`)
    SELECT 
        NEW.`user_id`,
        p.`name`,
        'role',
        NEW.`role_id`
    FROM `permissions` p
    INNER JOIN `role_permissions` rp ON p.`id` = rp.`permission_id`
    WHERE rp.`role_id` = NEW.`role_id` AND p.`is_active` = TRUE;
END//
DELIMITER ;

-- 创建存储过程：检查用户权限
DELIMITER //
CREATE PROCEDURE `check_user_permission`(
    IN p_user_id INT,
    IN p_permission_name VARCHAR(100),
    OUT p_has_permission BOOLEAN
)
BEGIN
    DECLARE v_cache_count INT DEFAULT 0;
    DECLARE v_cache_expired BOOLEAN DEFAULT FALSE;
    
    -- 检查缓存中是否有有效权限
    SELECT COUNT(*) INTO v_cache_count
    FROM `user_permissions_cache`
    WHERE `user_id` = p_user_id 
    AND `permission_name` = p_permission_name
    AND (`expires_at` IS NULL OR `expires_at` > NOW());
    
    IF v_cache_count > 0 THEN
        SET p_has_permission = TRUE;
    ELSE
        -- 缓存中没有，实时检查
        SELECT COUNT(*) > 0 INTO p_has_permission
        FROM `user_roles` ur
        INNER JOIN `role_permissions` rp ON ur.`role_id` = rp.`role_id`
        INNER JOIN `permissions` p ON rp.`permission_id` = p.`id`
        WHERE ur.`user_id` = p_user_id
        AND p.`name` = p_permission_name
        AND ur.`is_active` = TRUE
        AND p.`is_active` = TRUE
        AND (ur.`expires_at` IS NULL OR ur.`expires_at` > NOW());
        
        -- 更新缓存
        IF p_has_permission THEN
            INSERT INTO `user_permissions_cache` (`user_id`, `permission_name`, `granted_via`, `source_id`)
            SELECT p_user_id, p_permission_name, 'role', ur.`role_id`
            FROM `user_roles` ur
            INNER JOIN `role_permissions` rp ON ur.`role_id` = rp.`role_id`
            INNER JOIN `permissions` p ON rp.`permission_id` = p.`id`
            WHERE ur.`user_id` = p_user_id
            AND p.`name` = p_permission_name
            AND ur.`is_active` = TRUE
            AND p.`is_active` = TRUE
            AND (ur.`expires_at` IS NULL OR ur.`expires_at` > NOW())
            LIMIT 1;
        END IF;
    END IF;
END//
DELIMITER ;

-- 创建视图：用户权限视图
CREATE VIEW `v_user_permissions` AS
SELECT 
    u.`id` as user_id,
    u.`username`,
    u.`email`,
    r.`id` as role_id,
    r.`name` as role_name,
    r.`display_name` as role_display_name,
    p.`id` as permission_id,
    p.`name` as permission_name,
    p.`display_name` as permission_display_name,
    p.`module`,
    p.`action`,
    p.`resource`,
    ur.`assigned_at`,
    ur.`expires_at` as role_expires_at,
    ur.`is_active` as role_active
FROM `users` u
INNER JOIN `user_roles` ur ON u.`id` = ur.`user_id`
INNER JOIN `roles` r ON ur.`role_id` = r.`id`
INNER JOIN `role_permissions` rp ON r.`id` = rp.`role_id`
INNER JOIN `permissions` p ON rp.`permission_id` = p.`id`
WHERE ur.`is_active` = TRUE 
AND r.`is_active` = TRUE 
AND p.`is_active` = TRUE
AND (ur.`expires_at` IS NULL OR ur.`expires_at` > NOW());

-- 创建视图：权限申请统计视图
CREATE VIEW `v_permission_request_stats` AS
SELECT 
    DATE(requested_at) as request_date,
    request_type,
    status,
    COUNT(*) as request_count,
    AVG(TIMESTAMPDIFF(HOUR, requested_at, COALESCE(reviewed_at, approved_at, NOW()))) as avg_process_hours
FROM `permission_requests`
GROUP BY DATE(requested_at), request_type, status;

-- 创建索引优化
CREATE INDEX `idx_permissions_composite` ON `permissions` (`module`, `action`, `resource`, `is_active`);
CREATE INDEX `idx_user_roles_composite` ON `user_roles` (`user_id`, `is_active`, `expires_at`);
CREATE INDEX `idx_role_permissions_composite` ON `role_permissions` (`role_id`, `permission_id`);
CREATE INDEX `idx_permission_requests_composite` ON `permission_requests` (`user_id`, `status`, `request_type`, `requested_at`);
CREATE INDEX `idx_permission_approvals_composite` ON `permission_approvals` (`request_id`, `step_id`, `approver_id`, `approved_at`);