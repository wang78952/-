-- ========================================
-- 数据分析平台数据库表结构
-- 版本: 1.0.0
-- 创建时间: 2024年
-- ========================================

USE `card_system`;

-- ========================================
-- 数据分析核心表
-- ========================================

-- 数据分析汇总表
CREATE TABLE IF NOT EXISTS `data_analysis_summary` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `date` DATE NOT NULL COMMENT '统计日期',
    `period_type` ENUM('daily', 'weekly', 'monthly', 'quarterly', 'yearly') NOT NULL DEFAULT 'daily' COMMENT '统计周期类型',
    `total_visits` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '总访问量',
    `new_users` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '新增用户数',
    `active_users` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '活跃用户数',
    `total_orders` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '总订单数',
    `total_sales` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '总销售额',
    `avg_order_value` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '平均订单金额',
    `conversion_rate` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '转化率(%)',
    `refund_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '退款订单数',
    `refund_rate` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '退款率(%)',
    `product_popularity` JSON COMMENT '产品热度排行',
    `category_analysis` JSON COMMENT '分类销售分析',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_date_period` (`date`, `period_type`),
    KEY `idx_date` (`date`),
    KEY `idx_period_type` (`period_type`)
) ENGINE=InnoDB COMMENT='数据分析汇总表';

-- ========================================
-- 代理推广效果分析
-- ========================================

-- 代理推广效果跟踪表
CREATE TABLE IF NOT EXISTS `agent_promotion_analytics` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `promotion_id` BIGINT UNSIGNED COMMENT '推广ID',
    `date` DATE NOT NULL COMMENT '统计日期',
    `clicks` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击次数',
    `unique_clicks` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '独立点击次数',
    `registrations` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '注册数',
    `orders` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '订单数',
    `sales_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '销售金额',
    `conversion_rate` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '点击率到注册转化率',
    `order_conversion_rate` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '注册到订单转化率',
    `avg_order_value` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '平均订单金额',
    `roi` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '投资回报率',
    `traffic_source` JSON COMMENT '流量来源分布',
    `device_distribution` JSON COMMENT '设备分布',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_agent_date_promotion` (`agent_id`, `date`, `promotion_id`),
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_promotion_id` (`promotion_id`),
    KEY `idx_date` (`date`),
    
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`promotion_id`) REFERENCES `promotions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='代理推广效果跟踪表';

-- 推广链接点击详情表
CREATE TABLE IF NOT EXISTS `promotion_link_details` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `promotion_id` BIGINT UNSIGNED NOT NULL COMMENT '推广ID',
    `agent_id` BIGINT UNSIGNED NOT NULL COMMENT '代理ID',
    `ip_address` VARCHAR(45) COMMENT 'IP地址',
    `user_agent` TEXT COMMENT '用户代理',
    `referrer` VARCHAR(500) COMMENT '来源页面',
    `landing_page` VARCHAR(500) COMMENT '落地页',
    `device_type` ENUM('desktop', 'mobile', 'tablet', 'other') DEFAULT 'other' COMMENT '设备类型',
    `browser` VARCHAR(100) COMMENT '浏览器',
    `os` VARCHAR(100) COMMENT '操作系统',
    `country` VARCHAR(100) COMMENT '国家',
    `region` VARCHAR(100) COMMENT '地区',
    `city` VARCHAR(100) COMMENT '城市',
    `is_unique` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否唯一点击',
    `converted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否转化',
    `conversion_time` TIMESTAMP NULL COMMENT '转化时间',
    `user_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '转化用户ID',
    `order_id` INT UNSIGNED DEFAULT NULL COMMENT '转化订单ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '点击时间',
    
    KEY `idx_promotion_id` (`promotion_id`),
    KEY `idx_agent_id` (`agent_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_order_id` (`order_id`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_converted` (`converted`),
    
    FOREIGN KEY (`promotion_id`) REFERENCES `promotions`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`agent_id`) REFERENCES `agents`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='推广链接点击详情表';

-- ========================================
-- 用户购卡偏好分析
-- ========================================

-- 用户偏好分析表
CREATE TABLE IF NOT EXISTS `user_preference_analysis` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `preferred_categories` JSON COMMENT '偏好产品分类(权重排名)',
    `preferred_price_ranges` JSON COMMENT '偏好价格区间(权重排名)',
    `purchase_frequency` ENUM('rarely', 'monthly', 'weekly', 'daily') DEFAULT 'monthly' COMMENT '购买频率',
    `avg_purchase_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '平均购买金额',
    `preferred_payment_method` VARCHAR(50) COMMENT '偏好支付方式',
    `last_purchase_date` TIMESTAMP NULL COMMENT '最后购买时间',
    `next_purchase_prediction` DATE NULL COMMENT '下次购买预测日期',
    `churn_risk_score` TINYINT UNSIGNED DEFAULT 0 COMMENT '流失风险分数(0-100)',
    `customer_value_segment` ENUM('low', 'medium', 'high', 'vip') DEFAULT 'medium' COMMENT '客户价值分层',
    `tags` JSON COMMENT '用户标签',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    UNIQUE KEY `uk_user_id` (`user_id`),
    KEY `idx_last_purchase_date` (`last_purchase_date`),
    KEY `idx_customer_value_segment` (`customer_value_segment`),
    KEY `idx_churn_risk_score` (`churn_risk_score`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='用户偏好分析表';

-- 产品偏好统计数据表
CREATE TABLE IF NOT EXISTS `product_preference_stats` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT UNSIGNED NOT NULL COMMENT '产品ID',
    `category_id` INT UNSIGNED COMMENT '分类ID',
    `period_type` ENUM('daily', 'weekly', 'monthly') NOT NULL DEFAULT 'daily' COMMENT '统计周期',
    `period_start` DATE NOT NULL COMMENT '周期开始日期',
    `view_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '浏览次数',
    `add_to_cart_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '加入购物车次数',
    `purchase_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '购买次数',
    `view_to_cart_rate` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '浏览转购物车转化率',
    `cart_to_purchase_rate` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '购物车转购买转化率',
    `total_sales` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '总销售额',
    `customer_segment_distribution` JSON COMMENT '客户群体分布',
    `time_distribution` JSON COMMENT '时段分布',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_product_period` (`product_id`, `period_type`, `period_start`),
    KEY `idx_product_id` (`product_id`),
    KEY `idx_category_id` (`category_id`),
    KEY `idx_period_start` (`period_start`),
    KEY `idx_period_type` (`period_type`)
) ENGINE=InnoDB COMMENT='产品偏好统计数据表';

-- ========================================
-- 营销活动效果分析
-- ========================================

-- 营销活动效果分析表
CREATE TABLE IF NOT EXISTS `marketing_campaign_analytics` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `campaign_id` INT UNSIGNED NOT NULL COMMENT '活动ID(关联promotions表)',
    `campaign_name` VARCHAR(255) NOT NULL COMMENT '活动名称',
    `campaign_type` VARCHAR(50) NOT NULL COMMENT '活动类型',
    `start_date` DATE NOT NULL COMMENT '活动开始日期',
    `end_date` DATE NOT NULL COMMENT '活动结束日期',
    `impressions` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '曝光量',
    `clicks` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击量',
    `ctr` DECIMAL(6,4) NOT NULL DEFAULT 0.0000 COMMENT '点击率',
    `participants` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '参与人数',
    `orders` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '活动订单数',
    `sales_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '活动销售额',
    `avg_discount` DECIMAL(6,2) NOT NULL DEFAULT 0.00 COMMENT '平均折扣率(%)',
    `roi` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '投资回报率',
    `new_customers` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '新增客户数',
    `old_customers` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '老客户参与数',
    `customer_acquisition_cost` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '客户获取成本',
    `status` ENUM('upcoming', 'active', 'completed', 'cancelled') DEFAULT 'upcoming' COMMENT '状态',
    `data_breakdown` JSON COMMENT '数据明细(JSON格式)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    KEY `idx_campaign_id` (`campaign_id`),
    KEY `idx_start_date` (`start_date`),
    KEY `idx_end_date` (`end_date`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB COMMENT='营销活动效果分析表';

-- ========================================
-- 数据可视化配置表
-- ========================================

-- 数据仪表盘配置表
CREATE TABLE IF NOT EXISTS `data_dashboard_config` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL COMMENT '仪表盘名称',
    `description` TEXT COMMENT '仪表盘描述',
    `type` ENUM('admin', 'agent', 'user') NOT NULL DEFAULT 'admin' COMMENT '仪表盘类型',
    `config_data` JSON NOT NULL COMMENT '配置数据(包含图表、布局等信息)',
    `is_default` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否默认仪表盘',
    `created_by` BIGINT UNSIGNED COMMENT '创建者ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    KEY `idx_type` (`type`),
    KEY `idx_created_by` (`created_by`),
    KEY `idx_is_default` (`is_default`),
    
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='数据仪表盘配置表';

-- 用户仪表盘个性化配置表
CREATE TABLE IF NOT EXISTS `user_dashboard_config` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `dashboard_id` INT UNSIGNED NOT NULL COMMENT '仪表盘配置ID',
    `custom_config` JSON DEFAULT NULL COMMENT '个性化配置数据',
    `last_viewed_at` TIMESTAMP NULL COMMENT '最后查看时间',
    `view_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '查看次数',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_user_dashboard` (`user_id`, `dashboard_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_dashboard_id` (`dashboard_id`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`dashboard_id`) REFERENCES `data_dashboard_config`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='用户仪表盘个性化配置表';

-- ========================================
-- 索引优化
-- ========================================

-- 为现有表添加索引以支持数据分析查询
ALTER TABLE `promotions` ADD INDEX `idx_created_at` (`created_at`);
ALTER TABLE `promotion_clicks` ADD INDEX `idx_created_at` (`created_at`);
ALTER TABLE `orders` ADD INDEX `idx_created_at_user_id` (`created_at`, `user_id`);
ALTER TABLE `users` ADD INDEX `idx_created_at` (`created_at`);
ALTER TABLE `cards` ADD INDEX `idx_product_id_created_at` (`product_id`, `created_at`);

-- ========================================
-- 触发器和存储过程示例
-- ========================================

-- 注意：完整的触发器和存储过程实现将在应用程序层面处理，这里仅提供示例
-- 实际生产环境中请根据需要创建相应的数据同步和分析计算逻辑

-- 初始化脚本示例
-- INSERT INTO `data_analysis_summary` (date, period_type) VALUES (CURDATE(), 'daily');
-- INSERT INTO `data_dashboard_config` (name, description, type, config_data, is_default) VALUES 
-- ('运营总览', '系统整体运营数据统计', 'admin', '{}', 1),
-- ('代理推广效果', '代理推广数据分析', 'agent', '{}', 1);