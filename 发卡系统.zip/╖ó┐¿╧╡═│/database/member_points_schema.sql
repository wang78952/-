-- 会员等级与积分系统数据库表结构
-- 版本: 1.0.0
-- 创建时间: 2024年

-- ========================================\n-- 会员等级表\n-- ========================================\nCREATE TABLE IF NOT EXISTS `member_levels` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL COMMENT '等级名称(普通/银牌/金牌/钻石/黑钻)',
    `level` TINYINT UNSIGNED NOT NULL UNIQUE COMMENT '等级数值(1-5)',
    `min_points` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '最低积分要求',
    `discount_rate` DECIMAL(3,2) DEFAULT 1.00 COMMENT '折扣率(1.0为不打折)',
    `description` TEXT COMMENT '等级描述',
    `icon_url` VARCHAR(500) COMMENT '等级图标',
    `privileges` JSON DEFAULT '{}' COMMENT '会员特权配置',
    `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_level` (`level`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB COMMENT='会员等级表';

-- ========================================\n-- 用户会员信息表\n-- ========================================\nCREATE TABLE IF NOT EXISTS `user_members` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `member_level_id` INT UNSIGNED DEFAULT 1 COMMENT '当前会员等级ID',
    `current_points` BIGINT UNSIGNED DEFAULT 0 COMMENT '当前可用积分',
    `total_points` BIGINT UNSIGNED DEFAULT 0 COMMENT '累计积分总额',
    `expire_points` BIGINT UNSIGNED DEFAULT 0 COMMENT '即将过期积分',
    `points_expire_date` DATE COMMENT '积分过期日期',
    `member_since` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '会员开始时间',
    `last_level_change` TIMESTAMP NULL COMMENT '上次等级变更时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_user_id` (`user_id`),
    KEY `idx_member_level_id` (`member_level_id`),
    KEY `idx_current_points` (`current_points`),
    KEY `idx_total_points` (`total_points`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`member_level_id`) REFERENCES `member_levels`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='用户会员信息表';

-- ========================================\n-- 积分变动记录表\n-- ========================================\nCREATE TABLE IF NOT EXISTS `point_transactions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `type` ENUM('order', 'refund', 'activity', 'exchange', 'expire', 'manual', 'sign_in', 'invite', 'review') NOT NULL COMMENT '积分类型',
    `change_points` BIGINT NOT NULL COMMENT '积分变动数量(正数增加，负数减少)',
    `balance_points` BIGINT UNSIGNED NOT NULL COMMENT '变动后余额',
    `source_id` VARCHAR(50) DEFAULT NULL COMMENT '来源ID(订单号等)',
    `description` TEXT COMMENT '变动描述',
    `expire_date` DATE NULL COMMENT '积分过期日期',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_type` (`type`),
    INDEX `idx_source_id` (`source_id`),
    INDEX `idx_expire_date` (`expire_date`),
    INDEX `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='积分变动记录表';

-- ========================================\n-- 会员等级变更历史表\n-- ========================================\nCREATE TABLE IF NOT EXISTS `member_level_history` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `old_level_id` INT UNSIGNED DEFAULT NULL COMMENT '旧等级ID',
    `new_level_id` INT UNSIGNED DEFAULT NULL COMMENT '新等级ID',
    `change_reason` VARCHAR(255) DEFAULT '积分达到升级条件' COMMENT '等级变更原因',
    `change_points` BIGINT UNSIGNED DEFAULT 0 COMMENT '变更时积分',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '变更时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_old_level_id` (`old_level_id`),
    INDEX `idx_new_level_id` (`new_level_id`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`old_level_id`) REFERENCES `member_levels`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`new_level_id`) REFERENCES `member_levels`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='会员等级变更历史表';

-- ========================================\n-- 积分兑换规则表\n-- ========================================\nCREATE TABLE IF NOT EXISTS `point_exchange_rules` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL COMMENT '兑换名称',
    `type` ENUM('coupon', 'cash', 'gift_card', 'product') NOT NULL COMMENT '兑换类型',
    `required_points` BIGINT UNSIGNED NOT NULL COMMENT '所需积分',
    `exchange_value` DECIMAL(10,2) DEFAULT 0 COMMENT '兑换价值',
    `coupon_type_id` INT UNSIGNED DEFAULT NULL COMMENT '优惠券类型ID',
    `product_id` INT UNSIGNED DEFAULT NULL COMMENT '商品ID',
    `gift_card_id` INT UNSIGNED DEFAULT NULL COMMENT '礼品卡ID',
    `exchange_ratio` DECIMAL(5,2) DEFAULT 1.0 COMMENT '兑换比例',
    `max_daily_exchanges` INT UNSIGNED DEFAULT 1 COMMENT '每日最大兑换次数',
    `max_user_exchanges` INT UNSIGNED DEFAULT NULL COMMENT '每人最大兑换次数',
    `start_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
    `end_time` TIMESTAMP DEFAULT NULL COMMENT '结束时间',
    `status` ENUM('active', 'inactive', 'expired') DEFAULT 'inactive' COMMENT '状态',
    `description` TEXT COMMENT '规则描述',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_type` (`type`),
    INDEX `idx_status` (`status`),
    INDEX `idx_start_time` (`start_time`),
    INDEX `idx_end_time` (`end_time`),
    
    FOREIGN KEY (`coupon_type_id`) REFERENCES `coupon_types`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='积分兑换规则表';

-- ========================================\n-- 积分兑换记录表\n-- ========================================\nCREATE TABLE IF NOT EXISTS `point_exchanges` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `exchange_rule_id` INT UNSIGNED NOT NULL COMMENT '兑换规则ID',
    `exchange_code` VARCHAR(50) NOT NULL COMMENT '兑换码',
    `points` BIGINT UNSIGNED NOT NULL COMMENT '消耗积分',
    `exchange_value` DECIMAL(10,2) DEFAULT 0 COMMENT '兑换价值',
    `status` ENUM('pending', 'completed', 'cancelled', 'expired') DEFAULT 'pending' COMMENT '状态',
    `delivery_info` JSON DEFAULT NULL COMMENT '配送信息',
    `description` TEXT COMMENT '兑换描述',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_exchange_rule_id` (`exchange_rule_id`),
    INDEX `idx_exchange_code` (`exchange_code`),
    INDEX `idx_status` (`status`),
    
    UNIQUE KEY `uk_exchange_code` (`exchange_code`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`exchange_rule_id`) REFERENCES `point_exchange_rules`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='积分兑换记录表';

-- ========================================\n-- 用户积分统计视图\n-- ========================================\nCREATE OR REPLACE VIEW `user_points_stats` AS
SELECT 
    um.user_id,
    um.current_points,
    um.total_points,
    um.expire_points,
    um.points_expire_date,
    ml.name AS member_level_name,
    ml.level AS member_level,
    ml.discount_rate,
    
    -- 最近30天获得的积分
    (SELECT COALESCE(SUM(change_points), 0) 
     FROM point_transactions 
     WHERE user_id = um.user_id 
     AND change_points > 0
     AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS points_30days,
    
    -- 积分获取渠道分布
    (SELECT COALESCE(SUM(change_points), 0) 
     FROM point_transactions 
     WHERE user_id = um.user_id 
     AND type = 'order' 
     AND change_points > 0) AS points_from_orders,
    
    (SELECT COALESCE(SUM(change_points), 0) 
     FROM point_transactions 
     WHERE user_id = um.user_id 
     AND type = 'activity' 
     AND change_points > 0) AS points_from_activities,
    
    -- 距离下一等级所需积分
    (SELECT MIN(min_points) 
     FROM member_levels 
     WHERE min_points > um.current_points 
     AND status = 'active') AS next_level_points,
    
    -- 会员等级有效期
    DATE_FORMAT(um.member_since, '%Y-%m-%d') AS member_since_date,
    DATEDIFF(NOW(), um.member_since) AS member_days
FROM 
    user_members um
LEFT JOIN 
    member_levels ml ON um.member_level_id = ml.id;

-- ========================================\n-- 会员等级配置初始化\n-- ========================================\nINSERT INTO `member_levels` (`name`, `level`, `min_points`, `discount_rate`, `description`, `privileges`) 
VALUES
('普通会员', 1, 0, 1.00, '基础会员，享受标准服务', '"{\"free_shipping_threshold\": 99, \"priority_service\": false, \"exclusive_events\": false}"'),
('银牌会员', 2, 1000, 0.95, '累计积分1000以上，享受95折优惠', '"{\"free_shipping_threshold\": 88, \"priority_service\": false, \"exclusive_events\": true, \"birthday_gift\": true}"'),
('金牌会员', 3, 5000, 0.90, '累计积分5000以上，享受9折优惠', '"{\"free_shipping_threshold\": 68, \"priority_service\": true, \"exclusive_events\": true, \"birthday_gift\": true, \"early_access\": true}"'),
('钻石会员', 4, 10000, 0.85, '累计积分10000以上，享受85折优惠', '"{\"free_shipping_threshold\": 49, \"priority_service\": true, \"exclusive_events\": true, \"birthday_gift\": true, \"early_access\": true, \"vip_support\": true}"'),
('黑钻会员', 5, 50000, 0.80, '累计积分50000以上，享受8折优惠', '"{\"free_shipping_threshold\": 0, \"priority_service\": true, \"exclusive_events\": true, \"birthday_gift\": true, \"early_access\": true, \"vip_support\": true, \"personal_manager\": true, \"customized_offers\": true}"');

-- ========================================\n-- 积分兑换规则初始化\n-- ========================================\nINSERT INTO `point_exchange_rules` (`name`, `type`, `required_points`, `exchange_value`, `exchange_ratio`, `max_daily_exchanges`, `status`, `description`)
VALUES
('积分抵扣现金', 'cash', 100, 1.00, 100.0, 5, 'active', '100积分可抵扣1元现金'),
('5元优惠券', 'coupon', 500, 5.00, 100.0, 1, 'active', '500积分兑换5元无门槛优惠券'),
('满100减10优惠券', 'coupon', 800, 10.00, 80.0, 1, 'active', '800积分兑换满100减10优惠券'),
('会员日特权礼包', 'product', 2000, 20.00, 100.0, 1, 'active', '2000积分兑换会员日特权礼包'),
('10元电子礼品卡', 'gift_card', 1000, 10.00, 100.0, 3, 'active', '1000积分兑换10元电子礼品卡');

-- ========================================\n-- 存储过程：更新用户会员等级\n-- ========================================\nDELIMITER //
CREATE PROCEDURE IF NOT EXISTS `update_user_member_level`(IN `user_id_param` INT)
BEGIN
    DECLARE `current_points_var` BIGINT;
    DECLARE `new_level_id_var` INT;
    DECLARE `old_level_id_var` INT;
    DECLARE `level_change_reason` VARCHAR(255);
    
    -- 获取用户当前积分和等级
    SELECT `current_points`, `member_level_id` 
    INTO `current_points_var`, `old_level_id_var` 
    FROM `user_members` 
    WHERE `user_id` = `user_id_param`;
    
    IF `current_points_var` IS NULL THEN
        -- 如果用户还没有会员记录，创建一个
        INSERT INTO `user_members` (`user_id`, `member_level_id`, `current_points`, `total_points`)
        VALUES (`user_id_param`, 1, 0, 0);
        SET `old_level_id_var` = NULL;
        SET `new_level_id_var` = 1;
    ELSE
        -- 获取用户应该升级到的等级
        SELECT `id` 
        INTO `new_level_id_var`
        FROM `member_levels`
        WHERE `min_points` <= `current_points_var` AND `status` = 'active'
        ORDER BY `min_points` DESC
        LIMIT 1;
    END IF;
    
    -- 如果等级发生变化，更新用户等级并记录历史
    IF `old_level_id_var` != `new_level_id_var` THEN
        -- 确定等级变化原因
        IF `old_level_id_var` IS NULL THEN
            SET `level_change_reason` = '新用户首次分配等级';
        ELSEIF `new_level_id_var` > `old_level_id_var` THEN
            SET `level_change_reason` = '积分达到升级条件';
        ELSE
            SET `level_change_reason` = '积分不足降级';
        END IF;
        
        -- 更新用户等级
        UPDATE `user_members` 
        SET `member_level_id` = `new_level_id_var`, 
            `last_level_change` = NOW() 
        WHERE `user_id` = `user_id_param`;
        
        -- 记录等级变更历史
        INSERT INTO `member_level_history` (`user_id`, `old_level_id`, `new_level_id`, `change_reason`, `change_points`)
        VALUES (`user_id_param`, `old_level_id_var`, `new_level_id_var`, `level_change_reason`, `current_points_var`);
        
        -- 触发会员等级变更事件
        -- 这里可以添加会员等级变更通知逻辑
    END IF;
END //
DELIMITER ;

-- ========================================\n-- 存储过程：清理过期积分\n-- ========================================\nDELIMITER //
CREATE PROCEDURE IF NOT EXISTS `cleanup_expired_points`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE user_id_var INT;
    DECLARE expired_points_var BIGINT;
    DECLARE cur CURSOR FOR 
        SELECT `user_id`, SUM(`change_points`) AS expired_points 
        FROM `point_transactions` 
        WHERE `expire_date` <= DATE(NOW()) AND `type` != 'expire' AND `change_points` > 0
        GROUP BY `user_id`;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO user_id_var, expired_points_var;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- 开始事务
        START TRANSACTION;
        
        -- 更新用户积分
        UPDATE `user_members` 
        SET `current_points` = `current_points` - `expired_points_var` 
        WHERE `user_id` = `user_id_var` AND `current_points` >= `expired_points_var`;
        
        -- 记录积分过期
        INSERT INTO `point_transactions` (`user_id`, `type`, `change_points`, `balance_points`, `description`)
        SELECT 
            `user_id_var`, 
            'expire', 
            -`expired_points_var`, 
            `current_points` - `expired_points_var`,
            '积分过期'
        FROM `user_members` 
        WHERE `user_id` = `user_id_var` AND `current_points` >= `expired_points_var`;
        
        -- 提交事务
        COMMIT;
    END LOOP;
    
    CLOSE cur;
END //
DELIMITER ;

-- ========================================\n-- 事件调度器：定期更新会员等级\n-- ========================================\nSET GLOBAL event_scheduler = ON;

DELIMITER //
CREATE EVENT IF NOT EXISTS `event_update_member_levels`
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    -- 获取需要检查等级的用户列表
    DECLARE done INT DEFAULT FALSE;
    DECLARE user_id_var INT;
    DECLARE cur CURSOR FOR 
        SELECT DISTINCT `user_id` 
        FROM `user_members` 
        WHERE `last_level_change` < DATE_SUB(NOW(), INTERVAL 1 DAY);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO user_id_var;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        CALL `update_user_member_level`(user_id_var);
    END LOOP;
    
    CLOSE cur;
END //
DELIMITER ;

-- ========================================\n-- 事件调度器：定期清理过期积分\n-- ========================================\nDELIMITER //
CREATE EVENT IF NOT EXISTS `event_cleanup_expired_points`
ON SCHEDULE EVERY 1 DAY STARTS '2024-01-01 00:00:00'
DO
BEGIN
    CALL `cleanup_expired_points`;
END //
DELIMITER ;

-- ========================================\n-- 索引优化\n-- ========================================\n-- 为user_members表添加复合索引以优化会员等级查询
ALTER TABLE `user_members` ADD INDEX IF NOT EXISTS `idx_user_level_points` (`user_id`, `member_level_id`, `current_points`);

-- 为point_transactions表添加复合索引以优化积分查询
ALTER TABLE `point_transactions` ADD INDEX IF NOT EXISTS `idx_user_type_date` (`user_id`, `type`, `created_at`);

-- 为point_exchanges表添加复合索引以优化兑换记录查询
ALTER TABLE `point_exchanges` ADD INDEX IF NOT EXISTS `idx_user_rule_date` (`user_id`, `exchange_rule_id`, `created_at`);