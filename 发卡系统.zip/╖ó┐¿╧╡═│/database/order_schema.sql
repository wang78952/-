-- 订单管理系统数据库表结构

-- 订单表
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(50) NOT NULL COMMENT '订单号',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `product_name` varchar(255) NOT NULL COMMENT '产品名称',
  `quantity` int(11) NOT NULL DEFAULT '1' COMMENT '购买数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `total_amount` decimal(10,2) NOT NULL COMMENT '总金额',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT '折扣金额',
  `actual_amount` decimal(10,2) NOT NULL COMMENT '实付金额',
  `payment_method` varchar(50) DEFAULT NULL COMMENT '支付方式(alipay,wechat,balance)',
  `payment_id` varchar(100) DEFAULT NULL COMMENT '支付交易号',
  `status` varchar(50) NOT NULL DEFAULT 'pending' COMMENT '订单状态(pending,paid,processing,completed,cancelled,refunded,partial_refund)',
  `remark` text COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `paid_at` timestamp NULL DEFAULT NULL COMMENT '支付时间',
  `completed_at` timestamp NULL DEFAULT NULL COMMENT '完成时间',
  `cancelled_at` timestamp NULL DEFAULT NULL COMMENT '取消时间',
  `refunded_at` timestamp NULL DEFAULT NULL COMMENT '退款时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_payment_method` (`payment_method`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- 订单卡密关联表
CREATE TABLE IF NOT EXISTS `order_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '关联ID',
  `order_id` int(11) NOT NULL COMMENT '订单ID',
  `card_id` int(11) NOT NULL COMMENT '卡密ID',
  `card_code` varchar(255) DEFAULT NULL COMMENT '卡密代码(冗余字段)',
  `status` varchar(50) DEFAULT 'reserved' COMMENT '状态(reserved,activated,used,expired,refunded)',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `activated_at` timestamp NULL DEFAULT NULL COMMENT '激活时间',
  `used_at` timestamp NULL DEFAULT NULL COMMENT '使用时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_card` (`order_id`, `card_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单卡密关联表';

-- 订单状态变更日志表
CREATE TABLE IF NOT EXISTS `order_status_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `order_id` int(11) NOT NULL COMMENT '订单ID',
  `old_status` varchar(50) DEFAULT NULL COMMENT '原状态',
  `new_status` varchar(50) NOT NULL COMMENT '新状态',
  `remark` text COMMENT '备注',
  `operator_id` int(11) DEFAULT NULL COMMENT '操作人ID',
  `operator_name` varchar(100) DEFAULT NULL COMMENT '操作人姓名',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单状态变更日志表';

-- 订单操作日志表
CREATE TABLE IF NOT EXISTS `order_operation_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `order_id` int(11) NOT NULL COMMENT '订单ID',
  `operation_type` varchar(50) NOT NULL COMMENT '操作类型(create,update,pay,cancel,refund,export)',
  `operation_content` text COMMENT '操作内容',
  `operator_id` int(11) DEFAULT NULL COMMENT '操作人ID',
  `operator_name` varchar(100) DEFAULT NULL COMMENT '操作人姓名',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_operation_type` (`operation_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单操作日志表';

-- 订单统计表(用于快速统计)
CREATE TABLE IF NOT EXISTS `order_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '统计ID',
  `stat_date` date NOT NULL COMMENT '统计日期',
  `total_orders` int(11) DEFAULT '0' COMMENT '总订单数',
  `pending_orders` int(11) DEFAULT '0' COMMENT '待支付订单数',
  `paid_orders` int(11) DEFAULT '0' COMMENT '已支付订单数',
  `completed_orders` int(11) DEFAULT '0' COMMENT '已完成订单数',
  `cancelled_orders` int(11) DEFAULT '0' COMMENT '已取消订单数',
  `refunded_orders` int(11) DEFAULT '0' COMMENT '已退款订单数',
  `total_amount` decimal(15,2) DEFAULT '0.00' COMMENT '总金额',
  `paid_amount` decimal(15,2) DEFAULT '0.00' COMMENT '已支付金额',
  `refunded_amount` decimal(15,2) DEFAULT '0.00' COMMENT '已退款金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_stat_date` (`stat_date`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单统计表';

-- 订单配置表
CREATE TABLE IF NOT EXISTS `order_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `config_type` varchar(50) DEFAULT 'string' COMMENT '配置类型(string,int,float,bool,json)',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_system` tinyint(1) DEFAULT '0' COMMENT '是否系统配置',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单配置表';

-- 插入默认配置
INSERT INTO `order_config` (`config_key`, `config_value`, `config_type`, `description`, `is_system`) VALUES
('order_auto_cancel_minutes', '30', 'int', '订单自动取消时间(分钟)', 1),
('order_auto_complete_minutes', '60', 'int', '订单自动完成时间(分钟)', 1),
('order_export_limit', '10000', 'int', '订单导出数量限制', 1),
('order_search_days', '90', 'int', '订单搜索天数限制', 1),
('order_refund_days', '7', 'int', '订单退款天数限制', 1),
('order_batch_process_limit', '100', 'int', '批量处理订单数量限制', 1),
('order_notification_enabled', 'true', 'bool', '是否启用订单通知', 1),
('order_sms_enabled', 'false', 'bool', '是否启用短信通知', 0),
('order_email_enabled', 'true', 'bool', '是否启用邮件通知', 0);

-- 创建订单视图
CREATE OR REPLACE VIEW `order_summary_view` AS
SELECT 
    o.id,
    o.order_no,
    o.user_id,
    u.username,
    u.email,
    o.product_id,
    o.product_name,
    o.quantity,
    o.unit_price,
    o.total_amount,
    o.discount_amount,
    o.actual_amount,
    o.payment_method,
    o.status,
    o.remark,
    o.created_at,
    o.updated_at,
    o.paid_at,
    o.completed_at,
    COUNT(oc.card_id) as card_count,
    SUM(CASE WHEN oc.status = 'activated' THEN 1 ELSE 0 END) as activated_cards,
    SUM(CASE WHEN oc.status = 'used' THEN 1 ELSE 0 END) as used_cards
FROM orders o
LEFT JOIN users u ON o.user_id = u.id
LEFT JOIN order_cards oc ON o.id = oc.order_id
GROUP BY o.id;

-- 创建订单统计视图
CREATE OR REPLACE VIEW `order_daily_stats_view` AS
SELECT 
    DATE(created_at) as stat_date,
    COUNT(*) as total_orders,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
    SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid_orders,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
    SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders,
    SUM(CASE WHEN status = 'refunded' THEN 1 ELSE 0 END) as refunded_orders,
    SUM(total_amount) as total_amount,
    SUM(CASE WHEN status IN ('paid', 'completed') THEN actual_amount ELSE 0 END) as paid_amount,
    SUM(CASE WHEN status = 'refunded' THEN actual_amount ELSE 0 END) as refunded_amount
FROM orders
GROUP BY DATE(created_at);

-- 创建触发器：订单创建时记录操作日志
DELIMITER $$
CREATE TRIGGER `order_after_insert` 
AFTER INSERT ON `orders`
FOR EACH ROW
BEGIN
    INSERT INTO `order_operation_logs` (`order_id`, `operation_type`, `operation_content`, `operator_id`, `operator_name`)
    VALUES (NEW.id, 'create', CONCAT('创建订单: ', NEW.order_no, ', 金额: ', NEW.actual_amount), NEW.user_id, 'system');
END$$
DELIMITER ;

-- 创建触发器：订单状态更新时记录日志
DELIMITER $$
CREATE TRIGGER `order_after_update` 
AFTER UPDATE ON `orders`
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO `order_status_logs` (`order_id`, `old_status`, `new_status`, `operator_id`, `operator_name`)
        VALUES (NEW.id, OLD.status, NEW.status, NEW.user_id, 'system');
        
        INSERT INTO `order_operation_logs` (`order_id`, `operation_type`, `operation_content`, `operator_id`, `operator_name`)
        VALUES (NEW.id, 'update', CONCAT('状态变更: ', OLD.status, ' -> ', NEW.status), NEW.user_id, 'system');
    END IF;
END$$
DELIMITER ;

-- 创建存储过程：自动取消超时订单
DELIMITER $$
CREATE PROCEDURE `AutoCancelExpiredOrders`()
BEGIN
    DECLARE cancel_minutes INT DEFAULT 30;
    DECLARE cancel_count INT DEFAULT 0;
    
    -- 获取配置的取消时间
    SELECT CAST(config_value AS UNSIGNED) INTO cancel_minutes 
    FROM order_config 
    WHERE config_key = 'order_auto_cancel_minutes' 
    LIMIT 1;
    
    -- 更新超时订单状态
    UPDATE orders 
    SET status = 'cancelled', 
        cancelled_at = NOW(),
        updated_at = NOW()
    WHERE status = 'pending' 
    AND created_at < DATE_SUB(NOW(), INTERVAL cancel_minutes MINUTE);
    
    -- 获取影响的行数
    SET cancel_count = ROW_COUNT();
    
    -- 记录操作日志
    IF cancel_count > 0 THEN
        INSERT INTO order_operation_logs (order_id, operation_type, operation_content, operator_id, operator_name)
        SELECT id, 'cancel', CONCAT('自动取消超时订单: ', order_no), 0, 'system'
        FROM orders 
        WHERE status = 'cancelled' 
        AND cancelled_at = DATE_SUB(NOW(), INTERVAL 1 SECOND);
    END IF;
    
    SELECT cancel_count as cancelled_orders;
END$$
DELIMITER ;

-- 创建存储过程：自动完成已支付订单
DELIMITER $$
CREATE PROCEDURE `AutoCompletePaidOrders`()
BEGIN
    DECLARE complete_minutes INT DEFAULT 60;
    DECLARE complete_count INT DEFAULT 0;
    
    -- 获取配置的完成时间
    SELECT CAST(config_value AS UNSIGNED) INTO complete_minutes 
    FROM order_config 
    WHERE config_key = 'order_auto_complete_minutes' 
    LIMIT 1;
    
    -- 更新已支付订单状态
    UPDATE orders 
    SET status = 'completed', 
        completed_at = NOW(),
        updated_at = NOW()
    WHERE status = 'paid' 
    AND paid_at < DATE_SUB(NOW(), INTERVAL complete_minutes MINUTE);
    
    -- 获取影响的行数
    SET complete_count = ROW_COUNT();
    
    -- 记录操作日志
    IF complete_count > 0 THEN
        INSERT INTO order_operation_logs (order_id, operation_type, operation_content, operator_id, operator_name)
        SELECT id, 'complete', CONCAT('自动完成订单: ', order_no), 0, 'system'
        FROM orders 
        WHERE status = 'completed' 
        AND completed_at = DATE_SUB(NOW(), INTERVAL 1 SECOND);
    END IF;
    
    SELECT complete_count as completed_orders;
END$$
DELIMITER ;

-- 创建存储过程：更新订单统计
DELIMITER $$
CREATE PROCEDURE `UpdateOrderStatistics`(IN stat_date DATE)
BEGIN
    DECLARE total_count INT DEFAULT 0;
    DECLARE pending_count INT DEFAULT 0;
    DECLARE paid_count INT DEFAULT 0;
    DECLARE completed_count INT DEFAULT 0;
    DECLARE cancelled_count INT DEFAULT 0;
    DECLARE refunded_count INT DEFAULT 0;
    DECLARE total_amt DECIMAL(15,2) DEFAULT 0.00;
    DECLARE paid_amt DECIMAL(15,2) DEFAULT 0.00;
    DECLARE refunded_amt DECIMAL(15,2) DEFAULT 0.00;
    
    -- 统计订单数据
    SELECT 
        COUNT(*),
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'refunded' THEN 1 ELSE 0 END),
        SUM(total_amount),
        SUM(CASE WHEN status IN ('paid', 'completed') THEN actual_amount ELSE 0 END),
        SUM(CASE WHEN status = 'refunded' THEN actual_amount ELSE 0 END)
    INTO 
        total_count, pending_count, paid_count, completed_count, 
        cancelled_count, refunded_count, total_amt, paid_amt, refunded_amt
    FROM orders 
    WHERE DATE(created_at) = stat_date;
    
    -- 更新或插入统计数据
    INSERT INTO order_statistics 
    (stat_date, total_orders, pending_orders, paid_orders, completed_orders, 
     cancelled_orders, refunded_orders, total_amount, paid_amount, refunded_amount)
    VALUES 
    (stat_date, total_count, pending_count, paid_count, completed_count, 
     cancelled_count, refunded_count, total_amt, paid_amt, refunded_amt)
    ON DUPLICATE KEY UPDATE
    total_orders = total_count,
    pending_orders = pending_count,
    paid_orders = paid_count,
    completed_orders = completed_count,
    cancelled_orders = cancelled_count,
    refunded_orders = refunded_count,
    total_amount = total_amt,
    paid_amount = paid_amt,
    refunded_amount = refunded_amt,
    updated_at = NOW();
    
    SELECT 'Statistics updated successfully' as result;
END$$
DELIMITER ;

-- 创建事件：每天凌晨1点自动取消超时订单
CREATE EVENT IF NOT EXISTS `auto_cancel_expired_orders`
ON SCHEDULE EVERY 1 HOUR
DO CALL AutoCancelExpiredOrders();

-- 创建事件：每天凌晨2点自动完成已支付订单
CREATE EVENT IF NOT EXISTS `auto_complete_paid_orders`
ON SCHEDULE EVERY 1 HOUR
DO CALL AutoCompletePaidOrders();

-- 创建事件：每天凌晨3点更新订单统计
CREATE EVENT IF NOT EXISTS `update_daily_order_stats`
ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE, '03:00:00')
DO CALL UpdateOrderStatistics(CURDATE() - INTERVAL 1 DAY);

-- 添加索引优化
ALTER TABLE `orders` ADD INDEX `idx_status_created` (`status`, `created_at`);
ALTER TABLE `orders` ADD INDEX `idx_user_status` (`user_id`, `status`);
ALTER TABLE `order_cards` ADD INDEX `idx_status_created` (`status`, `created_at`);
ALTER TABLE `order_status_logs` ADD INDEX `idx_order_created` (`order_id`, `created_at`);
ALTER TABLE `order_operation_logs` ADD INDEX `idx_type_created` (`operation_type`, `created_at`);