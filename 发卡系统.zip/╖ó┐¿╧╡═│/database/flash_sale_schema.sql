-- 秒杀活动表
CREATE TABLE IF NOT EXISTS `flash_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '活动名称',
  `description` text COMMENT '活动描述',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `status` enum('active','inactive','completed','cancelled') NOT NULL DEFAULT 'active' COMMENT '状态',
  `priority` int(11) NOT NULL DEFAULT 0 COMMENT '优先级',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status_time` (`status`,`start_time`,`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='限时秒杀活动表';

-- 秒杀活动商品表
CREATE TABLE IF NOT EXISTS `flash_sale_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flash_sale_id` int(11) NOT NULL COMMENT '秒杀活动ID',
  `product_id` int(11) NOT NULL COMMENT '商品ID',
  `price` decimal(10,2) NOT NULL COMMENT '秒杀价格',
  `stock` int(11) NOT NULL COMMENT '秒杀库存',
  `max_per_user` int(11) NOT NULL DEFAULT 1 COMMENT '每用户限购数量',
  `sales_count` int(11) NOT NULL DEFAULT 0 COMMENT '已售数量',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_flash_sale_product` (`flash_sale_id`,`product_id`),
  KEY `idx_product_stock` (`product_id`,`stock`),
  CONSTRAINT `fk_flash_sale_products_sale` FOREIGN KEY (`flash_sale_id`) REFERENCES `flash_sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_flash_sale_products_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='秒杀活动商品表';

-- 秒杀订单表
CREATE TABLE IF NOT EXISTS `flash_sale_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `flash_sale_id` int(11) NOT NULL COMMENT '秒杀活动ID',
  `flash_sale_product_id` int(11) NOT NULL COMMENT '秒杀商品ID',
  `order_id` int(11) NOT NULL COMMENT '订单ID',
  `quantity` int(11) NOT NULL DEFAULT 1 COMMENT '购买数量',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_flash_sale` (`user_id`,`flash_sale_id`),
  KEY `idx_flash_sale_product_order` (`flash_sale_product_id`,`order_id`),
  CONSTRAINT `fk_flash_sale_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_flash_sale_orders_sale` FOREIGN KEY (`flash_sale_id`) REFERENCES `flash_sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_flash_sale_orders_product` FOREIGN KEY (`flash_sale_product_id`) REFERENCES `flash_sale_products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_flash_sale_orders_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='秒杀订单记录表';

-- 更新products表，添加秒杀库存字段
ALTER TABLE `products`
ADD COLUMN `flash_sale_stock` int(11) NOT NULL DEFAULT 0 COMMENT '秒杀库存' AFTER `stock`;

-- 添加秒杀活动相关权限
INSERT INTO `permissions` (`name`, `description`, `module`, `action`, `detail`) VALUES
('flash_sale.view', '查看秒杀活动', 'flash_sale', 'view', '查看秒杀活动列表和详情'),
('flash_sale.create', '创建秒杀活动', 'flash_sale', 'create', '创建新的秒杀活动'),
('flash_sale.edit', '编辑秒杀活动', 'flash_sale', 'edit', '编辑秒杀活动信息'),
('flash_sale.delete', '删除秒杀活动', 'flash_sale', 'delete', '删除秒杀活动'),
('flash_sale.manage', '管理秒杀活动', 'flash_sale', 'manage', '全面管理秒杀活动');

-- 为管理员角色分配秒杀活动权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r, `permissions` p 
WHERE r.name IN ('admin', 'manager') AND p.module = 'flash_sale';