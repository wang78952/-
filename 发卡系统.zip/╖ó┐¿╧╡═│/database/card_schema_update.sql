-- 卡密管理模块整改 - 数据库结构更新

-- 1. 修改card_batches表，添加卡密类型和格式配置字段
ALTER TABLE `card_batches` 
ADD COLUMN `card_type` VARCHAR(20) NOT NULL DEFAULT 'fixed' COMMENT '卡密类型：fixed(固定卡密)/dynamic(动态卡密)/time_based(时段卡密)',
ADD COLUMN `card_format_config` TEXT COMMENT '卡密格式配置(JSON)',
ADD COLUMN `api_config` TEXT COMMENT '动态卡密API配置(JSON)',
ADD COLUMN `time_config` TEXT COMMENT '时段卡密时间配置(JSON)';

-- 2. 修改cards表，添加支持动态卡密和时段卡密的字段
ALTER TABLE `cards` 
ADD COLUMN `activation_status` VARCHAR(20) NOT NULL DEFAULT 'inactive' COMMENT '激活状态：inactive(未激活)/active(已激活)',
ADD COLUMN `activation_time` DATETIME DEFAULT NULL COMMENT '激活时间',
ADD COLUMN `transfer_code` VARCHAR(100) DEFAULT NULL COMMENT '转赠码',
ADD COLUMN `original_owner_id` INT(11) DEFAULT NULL COMMENT '原始拥有者ID',
ADD COLUMN `transfer_history` TEXT COMMENT '转赠历史(JSON)',
ADD COLUMN `api_data` TEXT COMMENT '动态卡密API数据(JSON)',
ADD INDEX `idx_transfer_code` (`transfer_code`),
ADD INDEX `idx_activation_status` (`activation_status`),
ADD INDEX `idx_original_owner_id` (`original_owner_id`);

-- 3. 创建卡密权限映射表
CREATE TABLE IF NOT EXISTS `card_permission_mappings` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '映射ID',
  `card_id` INT(11) NOT NULL COMMENT '卡密ID',
  `permission_type` VARCHAR(50) NOT NULL COMMENT '权限类型',
  `permission_data` TEXT NOT NULL COMMENT '权限数据(JSON)',
  `status` VARCHAR(20) NOT NULL DEFAULT 'active' COMMENT '状态：active/used/expired',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_permission_type` (`permission_type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_card_permission_mapping_card` FOREIGN KEY (`card_id`) REFERENCES `cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密权限映射表';

-- 4. 创建卡密导入导出记录表
CREATE TABLE IF NOT EXISTS `card_import_export_records` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `operation_type` VARCHAR(20) NOT NULL COMMENT '操作类型：import/export',
  `file_name` VARCHAR(255) NOT NULL COMMENT '文件名',
  `file_path` VARCHAR(255) DEFAULT NULL COMMENT '文件路径',
  `total_count` INT(11) DEFAULT 0 COMMENT '总数量',
  `success_count` INT(11) DEFAULT 0 COMMENT '成功数量',
  `failed_count` INT(11) DEFAULT 0 COMMENT '失败数量',
  `duplicate_count` INT(11) DEFAULT 0 COMMENT '重复数量',
  `failed_items` TEXT COMMENT '失败项(JSON)',
  `user_id` INT(11) DEFAULT NULL COMMENT '操作用户ID',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_operation_type` (`operation_type`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密导入导出记录表';

-- 5. 创建卡密转赠记录表
CREATE TABLE IF NOT EXISTS `card_transfers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '转赠ID',
  `card_id` INT(11) NOT NULL COMMENT '卡密ID',
  `transfer_code` VARCHAR(100) NOT NULL COMMENT '转赠码',
  `from_user_id` INT(11) DEFAULT NULL COMMENT '转出用户ID',
  `to_user_id` INT(11) DEFAULT NULL COMMENT '转入用户ID',
  `transfer_time` DATETIME DEFAULT NULL COMMENT '转赠完成时间',
  `expire_time` DATETIME NOT NULL COMMENT '转赠码过期时间',
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态：pending(待接收)/completed(已完成)/expired(已过期)/cancelled(已取消)',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_transfer_code` (`transfer_code`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_from_user_id` (`from_user_id`),
  KEY `idx_to_user_id` (`to_user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_card_transfers_card` FOREIGN KEY (`card_id`) REFERENCES `cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密转赠记录表';

-- 更新完成时间
SELECT '卡密管理模块数据库结构更新完成' AS result;