-- 营销运营系统数据库表结构
-- 版本: 1.0.0
-- 创建时间: 2024年

-- ========================================
-- 会员等级与积分体系
-- ========================================

-- 会员等级表
CREATE TABLE IF NOT EXISTS `member_levels` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL COMMENT '等级名称(普通/银牌/金牌/钻石)',
    `level` TINYINT UNSIGNED NOT NULL UNIQUE COMMENT '等级数值(1-4)',
    `min_points` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '最低积分要求',
    `discount_rate` DECIMAL(3,2) DEFAULT 1.00 COMMENT '折扣率(1.0为不打折)',
    `description` TEXT COMMENT '等级描述',
    `icon_url` VARCHAR(500) COMMENT '等级图标',
    `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_level` (`level`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB COMMENT='会员等级表';

-- 用户会员信息表
CREATE TABLE IF NOT EXISTS `user_members` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `member_level_id` INT UNSIGNED DEFAULT 1 COMMENT '当前会员等级ID',
    `current_points` BIGINT UNSIGNED DEFAULT 0 COMMENT '当前积分',
    `total_points` BIGINT UNSIGNED DEFAULT 0 COMMENT '累计积分',
    `points_expire_date` DATE COMMENT '积分过期日期',
    `member_since` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '会员开始时间',
    `last_level_change` TIMESTAMP NULL COMMENT '上次等级变更时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_user_id` (`user_id`),
    KEY `idx_member_level_id` (`member_level_id`),
    KEY `idx_current_points` (`current_points`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`member_level_id`) REFERENCES `member_levels`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='用户会员信息表';

-- 积分变动记录表
CREATE TABLE IF NOT EXISTS `point_transactions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `type` ENUM('order', 'refund', 'activity', 'exchange', 'expire', 'manual') NOT NULL COMMENT '积分类型',
    `change_points` BIGINT NOT NULL COMMENT '积分变动数量(正数增加，负数减少)',
    `balance_points` BIGINT UNSIGNED NOT NULL COMMENT '变动后余额',
    `source_id` VARCHAR(50) DEFAULT NULL COMMENT '来源ID(订单号等)',
    `description` TEXT COMMENT '变动描述',
    `expire_date` DATE NULL COMMENT '积分过期日期',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_type` (`type`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_expire_date` (`expire_date`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='积分变动记录表';

-- ========================================
-- 促销活动系统
-- ========================================

-- 促销活动表
CREATE TABLE IF NOT EXISTS `promotions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL COMMENT '活动名称',
    `type` ENUM('discount', 'cashback', 'points', 'gift', 'combination') NOT NULL COMMENT '活动类型',
    `sub_type` VARCHAR(50) DEFAULT NULL COMMENT '子类型(满减/秒杀/团购等)',
    `description` TEXT COMMENT '活动描述',
    `start_time` TIMESTAMP NOT NULL COMMENT '开始时间',
    `end_time` TIMESTAMP NOT NULL COMMENT '结束时间',
    `status` ENUM('draft', 'active', 'paused', 'ended', 'cancelled') DEFAULT 'draft' COMMENT '状态',
    `rules` JSON NOT NULL COMMENT '活动规则(JSON格式)',
    `target_scope` ENUM('all', 'new', 'member_level', 'specific_users') DEFAULT 'all' COMMENT '目标用户范围',
    `target_data` JSON DEFAULT NULL COMMENT '目标用户数据',
    `max_usage` INT UNSIGNED DEFAULT NULL COMMENT '最大使用次数',
    `usage_count` INT UNSIGNED DEFAULT 0 COMMENT '已使用次数',
    `created_by` BIGINT UNSIGNED COMMENT '创建者ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_status` (`status`),
    INDEX `idx_type` (`type`),
    INDEX `idx_start_time` (`start_time`),
    INDEX `idx_end_time` (`end_time`),
    
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='促销活动表';

-- 优惠券类型表
CREATE TABLE IF NOT EXISTS `coupon_types` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL COMMENT '优惠券名称',
    `type` ENUM('discount', 'cash', 'points') NOT NULL COMMENT '优惠券类型',
    `value` DECIMAL(10,2) NOT NULL COMMENT '优惠值(折扣率或金额)',
    `min_amount` DECIMAL(10,2) DEFAULT 0 COMMENT '最低消费金额',
    `max_discount` DECIMAL(10,2) DEFAULT NULL COMMENT '最大优惠金额',
    `valid_days` INT DEFAULT 30 COMMENT '有效期天数',
    `product_scope` ENUM('all', 'category', 'specific') DEFAULT 'all' COMMENT '适用商品范围',
    `product_data` JSON DEFAULT NULL COMMENT '适用商品数据',
    `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_type` (`type`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB COMMENT='优惠券类型表';

-- 用户优惠券表
CREATE TABLE IF NOT EXISTS `user_coupons` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `coupon_type_id` INT UNSIGNED NOT NULL COMMENT '优惠券类型ID',
    `coupon_code` VARCHAR(50) NOT NULL UNIQUE COMMENT '优惠券码',
    `status` ENUM('unused', 'used', 'expired', 'cancelled') DEFAULT 'unused' COMMENT '状态',
    `issue_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '发放日期',
    `expire_date` TIMESTAMP NOT NULL COMMENT '过期日期',
    `used_date` TIMESTAMP NULL COMMENT '使用日期',
    `order_id` INT UNSIGNED DEFAULT NULL COMMENT '使用订单ID',
    `source_promotion_id` INT UNSIGNED DEFAULT NULL COMMENT '来源活动ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_coupon_type_id` (`coupon_type_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_expire_date` (`expire_date`),
    UNIQUE KEY `uk_coupon_code` (`coupon_code`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`coupon_type_id`) REFERENCES `coupon_types`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`source_promotion_id`) REFERENCES `promotions`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='用户优惠券表';

-- ========================================
-- 社交分享裂变系统
-- ========================================

-- 分享规则表
CREATE TABLE IF NOT EXISTS `share_rules` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL COMMENT '规则名称',
    `type` ENUM('points', 'coupon', 'cashback') NOT NULL COMMENT '奖励类型',
    `reward_value` DECIMAL(10,2) NOT NULL COMMENT '奖励值',
    `reward_count` INT DEFAULT NULL COMMENT '可奖励次数(为空不限制)',
    `new_user_points` BIGINT DEFAULT NULL COMMENT '新用户注册奖励积分',
    `min_order_amount` DECIMAL(10,2) DEFAULT 0 COMMENT '最低订单金额要求',
    `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    `description` TEXT COMMENT '规则描述',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB COMMENT='分享规则表';

-- 分享记录表
CREATE TABLE IF NOT EXISTS `share_records` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '分享用户ID',
    `share_code` VARCHAR(50) NOT NULL UNIQUE COMMENT '分享码',
    `share_url` TEXT NOT NULL COMMENT '分享URL',
    `share_type` ENUM('product', 'activity', 'general') DEFAULT 'general' COMMENT '分享类型',
    `target_id` VARCHAR(50) DEFAULT NULL COMMENT '分享目标ID',
    `view_count` INT UNSIGNED DEFAULT 0 COMMENT '查看次数',
    `click_count` INT UNSIGNED DEFAULT 0 COMMENT '点击次数',
    `register_count` INT UNSIGNED DEFAULT 0 COMMENT '注册次数',
    `order_count` INT UNSIGNED DEFAULT 0 COMMENT '下单次数',
    `total_reward` DECIMAL(10,2) DEFAULT 0 COMMENT '累计奖励',
    `status` ENUM('active', 'expired') DEFAULT 'active' COMMENT '状态',
    `expire_date` TIMESTAMP NULL COMMENT '过期日期',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_share_code` (`share_code`),
    INDEX `idx_status` (`status`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='分享记录表';

-- 分享奖励记录表
CREATE TABLE IF NOT EXISTS `share_rewards` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `share_record_id` BIGINT UNSIGNED NOT NULL COMMENT '分享记录ID',
    `referrer_user_id` BIGINT UNSIGNED NOT NULL COMMENT '推荐人用户ID',
    `referee_user_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '被推荐人用户ID',
    `order_id` INT UNSIGNED DEFAULT NULL COMMENT '关联订单ID',
    `reward_type` ENUM('points', 'coupon', 'cashback') NOT NULL COMMENT '奖励类型',
    `reward_value` DECIMAL(10,2) NOT NULL COMMENT '奖励值',
    `coupon_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '奖励优惠券ID',
    `status` ENUM('pending', 'issued', 'cancelled') DEFAULT 'pending' COMMENT '状态',
    `issue_date` TIMESTAMP NULL COMMENT '发放日期',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_share_record_id` (`share_record_id`),
    INDEX `idx_referrer_user_id` (`referrer_user_id`),
    INDEX `idx_referee_user_id` (`referee_user_id`),
    INDEX `idx_status` (`status`),
    
    FOREIGN KEY (`share_record_id`) REFERENCES `share_records`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`referrer_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`referee_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`coupon_id`) REFERENCES `user_coupons`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='分享奖励记录表';

-- ========================================
-- 数据初始化
-- ========================================

-- 插入会员等级初始化数据
INSERT INTO `member_levels` (`name`, `level`, `min_points`, `discount_rate`, `description`)
VALUES 
('普通会员', 1, 0, 1.00, '基础会员等级，所有注册用户自动获得'),
('银牌会员', 2, 1000, 0.95, '累计积分1000以上，享受95折优惠'),
('金牌会员', 3, 5000, 0.90, '累计积分5000以上，享受9折优惠'),
('钻石会员', 4, 10000, 0.85, '累计积分10000以上，享受85折优惠');

-- 插入分享规则初始化数据
INSERT INTO `share_rules` (`name`, `type`, `reward_value`, `reward_count`, `new_user_points`, `min_order_amount`, `description`)
VALUES
('好友分享奖励', 'points', 100, 50, 50, 0, '每成功邀请一位好友注册并下单，可获得100积分奖励'),
('优惠活动分享', 'coupon', 1, 100, 0, 100, '分享优惠活动给好友，好友首次下单可获得优惠券'),

-- 插入默认优惠券类型
INSERT INTO `coupon_types` (`name`, `type`, `value`, `min_amount`, `max_discount`, `valid_days`) VALUES
('新人立减券', 'cash', 10.00, 100.00, 10.00, 7),
('满100减20', 'cash', 20.00, 100.00, 20.00, 30),
('9折优惠券', 'discount', 0.90, 50.00, NULL, 30);