-- 合规性管理数据库表结构

-- AML筛查结果表
CREATE TABLE IF NOT EXISTS aml_screening_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    risk_score INT NOT NULL DEFAULT 0,
    blacklist_match JSON,
    anomaly_detected JSON,
    overall_risk ENUM('LOW', 'MEDIUM', 'HIGH') NOT NULL DEFAULT 'LOW',
    screening_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    transaction_data JSON,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_screening_time (screening_time),
    INDEX idx_overall_risk (overall_risk)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- AML警报表
CREATE TABLE IF NOT EXISTS aml_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    alert_type ENUM('HIGH_RISK', 'BLACKLIST_MATCH', 'ANOMALY_DETECTED', 'SANCTIONS_HIT') NOT NULL,
    risk_score INT NOT NULL DEFAULT 0,
    screening_data JSON,
    description TEXT,
    status ENUM('OPEN', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE') NOT NULL DEFAULT 'OPEN',
    assigned_to INT,
    resolution_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at DATETIME NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_alert_type (alert_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- KYC验证记录表
CREATE TABLE IF NOT EXISTS kyc_verifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    real_name VARCHAR(100) NOT NULL,
    id_number VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    verification_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    status ENUM('PENDING', 'VERIFIED', 'REJECTED', 'EXPIRED') NOT NULL DEFAULT 'PENDING',
    verification_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATE NOT NULL,
    additional_data JSON,
    documents JSON,
    verified_by INT,
    rejection_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_verification_time (verification_time),
    INDEX idx_expiry_date (expiry_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- KYC文档表
CREATE TABLE IF NOT EXISTS kyc_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    document_type ENUM('ID_FRONT', 'ID_BACK', 'PASSPORT', 'SELFIE', 'PROOF_OF_ADDRESS', 'OTHER') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    hash_value VARCHAR(64) NOT NULL,
    verification_status ENUM('PENDING', 'VERIFIED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    verification_notes TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_at DATETIME NULL,
    verified_by INT,
    INDEX idx_user_id (user_id),
    INDEX idx_document_type (document_type),
    INDEX idx_verification_status (verification_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 数据留存策略表
CREATE TABLE IF NOT EXISTS data_retention_policies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    policy_name VARCHAR(100) NOT NULL,
    table_name VARCHAR(100) NOT NULL,
    date_column VARCHAR(50) NOT NULL,
    retention_days INT NOT NULL,
    action_type ENUM('DELETE', 'ARCHIVE', 'ANONYMIZE') NOT NULL DEFAULT 'DELETE',
    archive_table VARCHAR(100) NULL,
    conditions TEXT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    last_executed DATETIME NULL,
    execution_frequency ENUM('DAILY', 'WEEKLY', 'MONTHLY') NOT NULL DEFAULT 'MONTHLY',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_table_name (table_name),
    INDEX idx_active (active),
    INDEX idx_last_executed (last_executed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 留存操作日志表
CREATE TABLE IF NOT EXISTS retention_operation_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    policy_id INT NOT NULL,
    table_name VARCHAR(100) NOT NULL,
    operation_type ENUM('DELETE', 'ARCHIVE', 'ANONYMIZE') NOT NULL,
    deleted_rows INT NOT NULL DEFAULT 0,
    archived_rows INT NOT NULL DEFAULT 0,
    anonymized_rows INT NOT NULL DEFAULT 0,
    cutoff_date DATE NOT NULL,
    execution_time DECIMAL(10,3) NOT NULL DEFAULT 0.000,
    operation_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('SUCCESS', 'PARTIAL', 'FAILED') NOT NULL DEFAULT 'SUCCESS',
    error_message TEXT NULL,
    INDEX idx_policy_id (policy_id),
    INDEX idx_operation_time (operation_time),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 合规事件表
CREATE TABLE IF NOT EXISTS compliance_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_type ENUM('AML_ALERT', 'KYC_VERIFICATION', 'RETENTION_EXECUTION', 'REPORT_GENERATED', 'POLICY_VIOLATION') NOT NULL,
    severity ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL DEFAULT 'LOW',
    user_id INT NULL,
    description TEXT NOT NULL,
    event_data JSON,
    source_system VARCHAR(50) NOT NULL DEFAULT 'CARD_SYSTEM',
    event_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
    acknowledged_by INT NULL,
    acknowledged_at DATETIME NULL,
    INDEX idx_event_type (event_type),
    INDEX idx_severity (severity),
    INDEX idx_user_id (user_id),
    INDEX idx_event_time (event_time),
    INDEX idx_acknowledged (acknowledged)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 合规报告表
CREATE TABLE IF NOT EXISTS compliance_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_type ENUM('DAILY', 'WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY', 'CUSTOM') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL DEFAULT 0,
    file_hash VARCHAR(64) NOT NULL,
    generated_by INT NOT NULL,
    generated_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('GENERATING', 'COMPLETED', 'FAILED') NOT NULL DEFAULT 'GENERATING',
    download_count INT NOT NULL DEFAULT 0,
    last_downloaded_at DATETIME NULL,
    INDEX idx_report_type (report_type),
    INDEX idx_start_date (start_date),
    INDEX idx_end_date (end_date),
    INDEX idx_generated_time (generated_time),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 制裁名单表
CREATE TABLE IF NOT EXISTS sanctions_list (
    id INT AUTO_INCREMENT PRIMARY KEY,
    list_name VARCHAR(100) NOT NULL,
    list_type ENUM('SANCTIONS', 'PEPS', 'WATCHLIST', 'BLOCKLIST') NOT NULL,
    entity_type ENUM('INDIVIDUAL', 'ENTITY', 'VESSEL', 'AIRCRAFT') NOT NULL,
    name VARCHAR(255) NOT NULL,
    aliases JSON,
    identification_numbers JSON,
    addresses JSON,
    birth_dates JSON,
    nationalities JSON,
    additional_info JSON,
    source VARCHAR(100) NOT NULL,
    source_url VARCHAR(500) NULL,
    list_date DATE NOT NULL,
    last_updated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    INDEX idx_list_type (list_type),
    INDEX idx_entity_type (entity_type),
    INDEX idx_name (name),
    INDEX idx_active (active),
    FULLTEXT idx_full_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 合规配置表
CREATE TABLE IF NOT EXISTS compliance_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT NOT NULL,
    config_type ENUM('STRING', 'NUMBER', 'BOOLEAN', 'JSON') NOT NULL DEFAULT 'STRING',
    description TEXT NULL,
    category VARCHAR(50) NOT NULL DEFAULT 'GENERAL',
    is_encrypted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_config_key (config_key),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 风险评估规则表
CREATE TABLE IF NOT EXISTS risk_assessment_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    rule_type ENUM('TRANSACTION', 'USER_BEHAVIOR', 'GEOGRAPHIC', 'TEMPORAL') NOT NULL,
    conditions JSON NOT NULL,
    risk_score INT NOT NULL DEFAULT 0,
    risk_level ENUM('LOW', 'MEDIUM', 'HIGH') NOT NULL DEFAULT 'LOW',
    action ENUM('ALERT', 'BLOCK', 'REVIEW', 'LOG_ONLY') NOT NULL DEFAULT 'LOG_ONLY',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    priority INT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_rule_type (rule_type),
    INDEX idx_risk_level (risk_level),
    INDEX idx_active (active),
    INDEX idx_priority (priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 插入默认合规配置
INSERT INTO compliance_config (config_key, config_value, config_type, description, category) VALUES
('aml_enabled', 'true', 'BOOLEAN', '是否启用AML筛查', 'AML'),
('aml_risk_threshold', '70', 'NUMBER', 'AML风险评分阈值', 'AML'),
('kyc_required', 'true', 'BOOLEAN', '是否强制KYC验证', 'KYC'),
('kyc_pass_score', '80', 'NUMBER', 'KYC验证通过分数', 'KYC'),
('kyc_expiry_days', '365', 'NUMBER', 'KYC验证有效期（天）', 'KYC'),
('data_retention_enabled', 'true', 'BOOLEAN', '是否启用数据留存策略', 'RETENTION'),
('auto_report_generation', 'true', 'BOOLEAN', '是否自动生成合规报告', 'REPORTS'),
('alert_notification_enabled', 'true', 'BOOLEAN', '是否启用警报通知', 'ALERTS'),
('max_daily_transactions', '50', 'NUMBER', '单日最大交易次数限制', 'TRANSACTION'),
('max_transaction_amount', '10000', 'NUMBER', '单笔最大交易金额限制', 'TRANSACTION');

-- 插入默认数据留存策略
INSERT INTO data_retention_policies (policy_name, table_name, date_column, retention_days, action_type, execution_frequency) VALUES
('清理过期日志', 'system_logs', 'created_at', 90, 'DELETE', 'WEEKLY'),
('清理临时文件记录', 'temp_files', 'created_at', 7, 'DELETE', 'DAILY'),
('归档历史订单', 'orders', 'created_at', 1095, 'ARCHIVE', 'MONTHLY'),
('清理过期会话', 'user_sessions', 'created_at', 30, 'DELETE', 'DAILY');

-- 插入默认风险评估规则
INSERT INTO risk_assessment_rules (rule_name, rule_type, conditions, risk_score, risk_level, action, priority) VALUES
('新用户大额交易', 'TRANSACTION', '{"user_age_days": 30, "amount_threshold": 5000}', 60, 'MEDIUM', 'ALERT', 1),
('异常高频交易', 'USER_BEHAVIOR', '{"hourly_count": 10, "daily_count": 50}', 70, 'HIGH', 'REVIEW', 2),
('异常时间段交易', 'TEMPORAL', '{"start_hour": 0, "end_hour": 6}', 30, 'LOW', 'LOG_ONLY', 3),
('高风险地区交易', 'GEOGRAPHIC', '{"risk_countries": ["XX", "YY"]}', 80, 'HIGH', 'ALERT', 1);

-- 创建触发器：用户注册时创建KYC待验证记录
DELIMITER //
CREATE TRIGGER after_user_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO kyc_verifications (user_id, real_name, status, verification_time, expiry_date)
    VALUES (NEW.id, '', 'PENDING', NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR));
END//
DELIMITER ;

-- 创建存储过程：执行AML筛查
DELIMITER //
CREATE PROCEDURE PerformAMLScreening(
    IN p_user_id INT,
    IN p_transaction_data JSON
)
BEGIN
    DECLARE v_risk_score INT DEFAULT 0;
    DECLARE v_overall_risk VARCHAR(10) DEFAULT 'LOW';
    
    -- 计算风险评分
    SELECT 
        CASE 
            WHEN (SELECT COUNT(*) FROM orders WHERE user_id = p_user_id 
                  AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)) > 10 THEN 80
            WHEN (SELECT COUNT(*) FROM orders WHERE user_id = p_user_id 
                  AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)) > 5 THEN 50
            ELSE 20
        END INTO v_risk_score;
    
    -- 评估整体风险
    SET v_overall_risk = CASE 
        WHEN v_risk_score >= 80 THEN 'HIGH'
        WHEN v_risk_score >= 50 THEN 'MEDIUM'
        ELSE 'LOW'
    END;
    
    -- 保存筛查结果
    INSERT INTO aml_screening_results 
    (user_id, risk_score, overall_risk, screening_time, transaction_data)
    VALUES (p_user_id, v_risk_score, v_overall_risk, NOW(), p_transaction_data);
    
    -- 如果高风险，创建警报
    IF v_overall_risk = 'HIGH' THEN
        INSERT INTO aml_alerts 
        (user_id, alert_type, risk_score, screening_data, status)
        VALUES (p_user_id, 'HIGH_RISK', v_risk_score, 
                JSON_OBJECT('risk_score', v_risk_score, 'screening_time', NOW()), 'OPEN');
    END IF;
    
    SELECT v_risk_score as risk_score, v_overall_risk as overall_risk;
END//
DELIMITER ;

-- 创建视图：合规概览
CREATE VIEW compliance_overview AS
SELECT 
    'AML筛查' as category,
    COUNT(*) as total_count,
    SUM(CASE WHEN overall_risk = 'HIGH' THEN 1 ELSE 0 END) as high_risk_count,
    SUM(CASE WHEN overall_risk = 'MEDIUM' THEN 1 ELSE 0 END) as medium_risk_count,
    SUM(CASE WHEN overall_risk = 'LOW' THEN 1 ELSE 0 END) as low_risk_count,
    DATE(screening_time) as report_date
FROM aml_screening_results 
WHERE screening_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)

UNION ALL

SELECT 
    'KYC验证' as category,
    COUNT(*) as total_count,
    SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as high_risk_count,
    SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as medium_risk_count,
    SUM(CASE WHEN status = 'VERIFIED' THEN 1 ELSE 0 END) as low_risk_count,
    DATE(verification_time) as report_date
FROM kyc_verifications 
WHERE verification_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)

UNION ALL

SELECT 
    '合规事件' as category,
    COUNT(*) as total_count,
    SUM(CASE WHEN severity = 'CRITICAL' THEN 1 ELSE 0 END) as high_risk_count,
    SUM(CASE WHEN severity = 'HIGH' THEN 1 ELSE 0 END) as medium_risk_count,
    SUM(CASE WHEN severity IN ('LOW', 'MEDIUM') THEN 1 ELSE 0 END) as low_risk_count,
    DATE(event_time) as report_date
FROM compliance_events 
WHERE event_time >= DATE_SUB(NOW(), INTERVAL 30 DAY);

-- 创建索引优化
CREATE INDEX idx_aml_user_time ON aml_screening_results(user_id, screening_time);
CREATE INDEX idx_kyc_user_status ON kyc_verifications(user_id, status);
CREATE INDEX idx_alerts_status_time ON aml_alerts(status, created_at);
CREATE INDEX idx_events_type_severity ON compliance_events(event_type, severity);
CREATE INDEX idx_reports_type_dates ON compliance_reports(report_type, start_date, end_date);