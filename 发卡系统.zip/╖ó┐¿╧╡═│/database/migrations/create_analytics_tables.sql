-- 创建分析事件表
CREATE TABLE IF NOT EXISTS analytics_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    user_id INT DEFAULT NULL,
    event_name VARCHAR(50) NOT NULL,
    event_data JSON DEFAULT NULL,
    device_info JSON DEFAULT NULL,
    timestamp INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_id (session_id),
    INDEX idx_user_id (user_id),
    INDEX idx_event_name (event_name),
    INDEX idx_created_at (created_at)
);

-- 创建错误分析表
CREATE TABLE IF NOT EXISTS analytics_errors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    user_id INT DEFAULT NULL,
    error_type VARCHAR(50) NOT NULL,
    error_message TEXT NOT NULL,
    page_path VARCHAR(255) DEFAULT NULL,
    timestamp INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_id (session_id),
    INDEX idx_user_id (user_id),
    INDEX idx_error_type (error_type),
    INDEX idx_created_at (created_at)
);

-- 创建性能分析表
CREATE TABLE IF NOT EXISTS analytics_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    user_id INT DEFAULT NULL,
    page_path VARCHAR(255) NOT NULL,
    load_time FLOAT NOT NULL,
    timestamp INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_id (session_id),
    INDEX idx_user_id (user_id),
    INDEX idx_page_path (page_path),
    INDEX idx_created_at (created_at)
);