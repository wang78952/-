-- ========================================
-- 发卡系统数据库初始化脚本
-- 版本: 1.0.0
-- 创建时间: 2024年
-- ========================================

-- 设置字符集和排序规则
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 创建数据库
CREATE DATABASE IF NOT EXISTS `card_system` 
DEFAULT CHARACTER SET utf8mb4 
DEFAULT COLLATE utf8mb4_unicode_ci;

USE `card_system`;

-- ========================================
-- 用户管理相关表
-- ========================================

-- 用户表
CREATE TABLE IF NOT EXISTS `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    `password` VARCHAR(255) NOT NULL COMMENT '密码哈希',
    `email` VARCHAR(100) UNIQUE COMMENT '邮箱',
    `phone` VARCHAR(20) COMMENT '手机号',
    `real_name` VARCHAR(50) COMMENT '真实姓名',
    `role` ENUM('admin', 'manager', 'operator', 'viewer') NOT NULL DEFAULT 'operator' COMMENT '角色',
    `status` ENUM('active', 'inactive', 'locked') NOT NULL DEFAULT 'active' COMMENT '状态',
    `failed_login_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录失败次数',
    `last_login_time` TIMESTAMP NULL COMMENT '最后登录时间',
    `last_login_ip` VARCHAR(45) COMMENT '最后登录IP',
    `last_failed_login_time` TIMESTAMP NULL COMMENT '最后登录失败时间',
    `last_failed_login_ip` VARCHAR(45) COMMENT '最后登录失败IP',
    `two_factor_code` VARCHAR(10) NULL COMMENT '二次验证码',
    `two_factor_expire_time` TIMESTAMP NULL COMMENT '二次验证码过期时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_username` (`username`),
    INDEX `idx_email` (`email`),
    INDEX `idx_role` (`role`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB COMMENT='用户表';

-- 用户操作日志表
CREATE TABLE IF NOT EXISTS `user_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型',
    `description` TEXT NOT NULL COMMENT '操作描述',
    `target_type` VARCHAR(50) COMMENT '目标类型',
    `target_id` BIGINT UNSIGNED COMMENT '目标ID',
    `ip` VARCHAR(45) COMMENT 'IP地址',
    `user_agent` TEXT COMMENT '用户代理',
    `context` JSON COMMENT '上下文信息',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_target_type` (`target_type`),
    INDEX `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='用户操作日志表';

-- 登录日志表
CREATE TABLE IF NOT EXISTS `login_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL COMMENT '用户名',
    `user_id` BIGINT UNSIGNED COMMENT '用户ID',
    `ip` VARCHAR(45) NOT NULL COMMENT 'IP地址',
    `user_agent` TEXT COMMENT '用户代理',
    `success` TINYINT(1) NOT NULL COMMENT '是否成功',
    `failure_reason` VARCHAR(100) COMMENT '失败原因',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
    
    INDEX `idx_username` (`username`),
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_ip` (`ip`),
    INDEX `idx_success` (`success`),
    INDEX `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='登录日志表';

-- ========================================
-- 产品管理相关表
-- ========================================

-- 产品分类表
CREATE TABLE IF NOT EXISTS `categories` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL COMMENT '分类名称',
    `description` TEXT COMMENT '分类描述',
    `parent_id` INT UNSIGNED DEFAULT NULL COMMENT '父分类ID',
    `sort_order` INT DEFAULT 0 COMMENT '排序顺序',
    `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_parent_id` (`parent_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_sort_order` (`sort_order`),
    
    FOREIGN KEY (`parent_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='产品分类表';

-- 产品表
CREATE TABLE IF NOT EXISTS `products` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `category_id` INT UNSIGNED COMMENT '分类ID',
    `name` VARCHAR(255) NOT NULL COMMENT '产品名称',
    `description` TEXT COMMENT '产品描述',
    `price` DECIMAL(10,2) NOT NULL COMMENT '价格',
    `stock` INT DEFAULT 0 COMMENT '库存数量',
    `min_stock` INT DEFAULT 0 COMMENT '最低库存预警',
    `status` ENUM('active', 'inactive', 'out_of_stock') DEFAULT 'active' COMMENT '状态',
    `image_url` VARCHAR(500) COMMENT '产品图片URL',
    `specifications` JSON COMMENT '产品规格',
    `created_by` BIGINT UNSIGNED COMMENT '创建者ID',
    `updated_by` BIGINT UNSIGNED COMMENT '更新者ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_category_id` (`category_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_price` (`price`),
    INDEX `idx_stock` (`stock`),
    INDEX `idx_created_by` (`created_by`),
    
    FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`updated_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='产品表';

-- ========================================
-- 卡密管理相关表
-- ========================================

-- 卡密批次表
CREATE TABLE IF NOT EXISTS `card_batches` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `batch_no` VARCHAR(50) NOT NULL COMMENT '批次号',
    `product_id` INT UNSIGNED NOT NULL COMMENT '产品ID',
    `quantity` INT NOT NULL COMMENT '生成数量',
    `generated_count` INT DEFAULT 0 COMMENT '已生成数量',
    `valid_days` INT DEFAULT 365 COMMENT '有效期天数',
    `status` ENUM('processing', 'completed', 'failed', 'cancelled') DEFAULT 'processing' COMMENT '状态',
    `prefix` VARCHAR(10) DEFAULT NULL COMMENT '卡密前缀',
    `description` VARCHAR(255) DEFAULT NULL COMMENT '批次描述',
    `operator_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
    `operator_name` VARCHAR(50) DEFAULT NULL COMMENT '操作员姓名',
    `generated_at` DATETIME DEFAULT NULL COMMENT '生成完成时间',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_batch_no` (`batch_no`),
    KEY `idx_product_id` (`product_id`),
    KEY `idx_status` (`status`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`operator_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='卡密批次表';

-- 卡密表
CREATE TABLE IF NOT EXISTS `cards` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `batch_id` INT UNSIGNED NOT NULL COMMENT '批次ID',
    `product_id` INT UNSIGNED NOT NULL COMMENT '产品ID',
    `card_code` VARCHAR(50) NOT NULL COMMENT '卡密编码',
    `card_secret` TEXT NOT NULL COMMENT '卡密密码(加密存储)',
    `status` ENUM('active', 'used', 'expired', 'cancelled') DEFAULT 'active' COMMENT '状态',
    `expires_at` DATETIME DEFAULT NULL COMMENT '过期时间',
    `used_at` DATETIME DEFAULT NULL COMMENT '使用时间',
    `used_ip` VARCHAR(45) DEFAULT NULL COMMENT '使用IP',
    `used_user_agent` VARCHAR(500) DEFAULT NULL COMMENT '使用用户代理',
    `usage_data` TEXT COMMENT '使用数据(JSON)',
    `order_id` INT UNSIGNED DEFAULT NULL COMMENT '关联订单ID',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY `uk_card_code` (`card_code`),
    KEY `idx_batch_id` (`batch_id`),
    KEY `idx_product_id` (`product_id`),
    KEY `idx_status` (`status`),
    KEY `idx_expires_at` (`expires_at`),
    KEY `idx_used_at` (`used_at`),
    KEY `idx_order_id` (`order_id`),
    
    FOREIGN KEY (`batch_id`) REFERENCES `card_batches`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='卡密表';

-- 卡密使用日志表
CREATE TABLE IF NOT EXISTS `card_usage_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `card_id` BIGINT UNSIGNED NOT NULL COMMENT '卡密ID',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型：redeem/verify/expire/cancel',
    `result` VARCHAR(20) NOT NULL COMMENT '结果：success/failed/pending',
    `message` VARCHAR(255) DEFAULT NULL COMMENT '消息',
    `usage_data` TEXT COMMENT '使用数据(JSON)',
    `ip_address` VARCHAR(45) DEFAULT NULL COMMENT 'IP地址',
    `user_agent` VARCHAR(500) DEFAULT NULL COMMENT '用户代理',
    `session_id` VARCHAR(100) DEFAULT NULL COMMENT '会话ID',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    KEY `idx_card_id` (`card_id`),
    KEY `idx_action` (`action`),
    KEY `idx_result` (`result`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`card_id`) REFERENCES `cards`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='卡密使用日志表';

-- ========================================
-- 订单管理相关表
-- ========================================

-- 订单表
CREATE TABLE IF NOT EXISTS `orders` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `order_no` VARCHAR(50) NOT NULL COMMENT '订单号',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `product_id` INT UNSIGNED NOT NULL COMMENT '产品ID',
    `product_name` VARCHAR(255) NOT NULL COMMENT '产品名称',
    `quantity` INT NOT NULL DEFAULT 1 COMMENT '购买数量',
    `unit_price` DECIMAL(10,2) NOT NULL COMMENT '单价',
    `total_amount` DECIMAL(10,2) NOT NULL COMMENT '总金额',
    `discount_amount` DECIMAL(10,2) DEFAULT 0.00 COMMENT '折扣金额',
    `actual_amount` DECIMAL(10,2) NOT NULL COMMENT '实付金额',
    `payment_method` VARCHAR(50) DEFAULT NULL COMMENT '支付方式(alipay,wechat,balance)',
    `payment_id` VARCHAR(100) DEFAULT NULL COMMENT '支付交易号',
    `status` ENUM('pending', 'paid', 'processing', 'completed', 'cancelled', 'refunded', 'partial_refund') DEFAULT 'pending' COMMENT '订单状态',
    `remark` TEXT COMMENT '备注',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `paid_at` TIMESTAMP NULL DEFAULT NULL COMMENT '支付时间',
    `completed_at` TIMESTAMP NULL DEFAULT NULL COMMENT '完成时间',
    `cancelled_at` TIMESTAMP NULL DEFAULT NULL COMMENT '取消时间',
    `refunded_at` TIMESTAMP NULL DEFAULT NULL COMMENT '退款时间',
    
    UNIQUE KEY `uk_order_no` (`order_no`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_product_id` (`product_id`),
    KEY `idx_status` (`status`),
    KEY `idx_payment_method` (`payment_method`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_payment_id` (`payment_id`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='订单表';

-- 订单卡密关联表
CREATE TABLE IF NOT EXISTS `order_cards` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT UNSIGNED NOT NULL COMMENT '订单ID',
    `card_id` BIGINT UNSIGNED NOT NULL COMMENT '卡密ID',
    `card_code` VARCHAR(255) DEFAULT NULL COMMENT '卡密代码(冗余字段)',
    `status` ENUM('reserved', 'activated', 'used', 'expired', 'refunded') DEFAULT 'reserved' COMMENT '状态',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `activated_at` TIMESTAMP NULL DEFAULT NULL COMMENT '激活时间',
    `used_at` TIMESTAMP NULL DEFAULT NULL COMMENT '使用时间',
    
    UNIQUE KEY `uk_order_card` (`order_id`, `card_id`),
    KEY `idx_order_id` (`order_id`),
    KEY `idx_card_id` (`card_id`),
    KEY `idx_status` (`status`),
    
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`card_id`) REFERENCES `cards`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='订单卡密关联表';

-- 订单状态变更日志表
CREATE TABLE IF NOT EXISTS `order_status_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT UNSIGNED NOT NULL COMMENT '订单ID',
    `old_status` VARCHAR(50) DEFAULT NULL COMMENT '原状态',
    `new_status` VARCHAR(50) NOT NULL COMMENT '新状态',
    `remark` TEXT COMMENT '备注',
    `operator_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '操作人ID',
    `operator_name` VARCHAR(100) DEFAULT NULL COMMENT '操作人姓名',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    KEY `idx_order_id` (`order_id`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`operator_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='订单状态变更日志表';

-- ========================================
-- 系统配置相关表
-- ========================================

-- 系统配置表
CREATE TABLE IF NOT EXISTS `system_configs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `config_key` VARCHAR(100) NOT NULL UNIQUE COMMENT '配置键',
    `config_value` TEXT COMMENT '配置值',
    `config_type` ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string' COMMENT '配置类型',
    `description` VARCHAR(200) COMMENT '配置描述',
    `is_encrypted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否加密存储',
    `created_by` BIGINT UNSIGNED COMMENT '创建者ID',
    `updated_by` BIGINT UNSIGNED COMMENT '更新者ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_config_key` (`config_key`),
    
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`updated_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='系统配置表';

-- 数据备份记录表
CREATE TABLE IF NOT EXISTS `backup_records` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `backup_type` ENUM('full', 'incremental') NOT NULL COMMENT '备份类型',
    `backup_file` VARCHAR(255) NOT NULL COMMENT '备份文件路径',
    `file_size` BIGINT UNSIGNED COMMENT '文件大小（字节）',
    `backup_status` ENUM('running', 'success', 'failed') DEFAULT 'running' COMMENT '备份状态',
    `error_message` TEXT COMMENT '错误信息',
    `start_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
    `end_time` TIMESTAMP NULL COMMENT '结束时间',
    `created_by` BIGINT UNSIGNED COMMENT '创建者ID',
    
    INDEX `idx_backup_type` (`backup_type`),
    INDEX `idx_backup_status` (`backup_status`),
    INDEX `idx_start_time` (`start_time`),
    
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='数据备份记录表';

-- 异常告警记录表
CREATE TABLE IF NOT EXISTS `alert_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `alert_type` ENUM('security', 'system', 'business') NOT NULL COMMENT '告警类型',
    `alert_level` ENUM('low', 'medium', 'high', 'critical') NOT NULL COMMENT '告警级别',
    `title` VARCHAR(200) NOT NULL COMMENT '告警标题',
    `message` TEXT NOT NULL COMMENT '告警消息',
    `source` VARCHAR(100) COMMENT '告警来源',
    `context` JSON COMMENT '上下文信息',
    `status` ENUM('new', 'acknowledged', 'resolved') DEFAULT 'new' COMMENT '处理状态',
    `acknowledged_by` BIGINT UNSIGNED COMMENT '确认人ID',
    `acknowledged_at` TIMESTAMP NULL COMMENT '确认时间',
    `resolved_by` BIGINT UNSIGNED COMMENT '解决人ID',
    `resolved_at` TIMESTAMP NULL COMMENT '解决时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_alert_type` (`alert_type`),
    INDEX `idx_alert_level` (`alert_level`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`acknowledged_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`resolved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='异常告警记录表';

-- ========================================
-- 会话管理相关表
-- ========================================

-- 用户会话表
CREATE TABLE IF NOT EXISTS `user_sessions` (
    `id` VARCHAR(128) NOT NULL PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `ip_address` VARCHAR(45) NOT NULL COMMENT 'IP地址',
    `user_agent` TEXT COMMENT '用户代理',
    `payload` TEXT NOT NULL COMMENT '会话数据',
    `last_activity` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后活动时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_last_activity` (`last_activity`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='用户会话表';

-- ========================================
-- 权限管理相关表
-- ========================================

-- 角色表
CREATE TABLE IF NOT EXISTS `roles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL UNIQUE COMMENT '角色名称',
    `display_name` VARCHAR(100) NOT NULL COMMENT '显示名称',
    `description` TEXT COMMENT '角色描述',
    `status` ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB COMMENT='角色表';

-- 权限表
CREATE TABLE IF NOT EXISTS `permissions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL UNIQUE COMMENT '权限名称',
    `display_name` VARCHAR(100) NOT NULL COMMENT '显示名称',
    `description` TEXT COMMENT '权限描述',
    `module` VARCHAR(50) NOT NULL COMMENT '所属模块',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX `idx_module` (`module`),
    INDEX `idx_action` (`action`)
) ENGINE=InnoDB COMMENT='权限表';

-- 角色权限关联表
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `role_id` INT UNSIGNED NOT NULL COMMENT '角色ID',
    `permission_id` INT UNSIGNED NOT NULL COMMENT '权限ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    UNIQUE KEY `uk_role_permission` (`role_id`, `permission_id`),
    KEY `idx_role_id` (`role_id`),
    KEY `idx_permission_id` (`permission_id`),
    
    FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='角色权限关联表';

-- 用户角色关联表
CREATE TABLE IF NOT EXISTS `user_roles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `role_id` INT UNSIGNED NOT NULL COMMENT '角色ID',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    UNIQUE KEY `uk_user_role` (`user_id`, `role_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_role_id` (`role_id`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='用户角色关联表';

-- ========================================
-- 合规管理相关表
-- ========================================

-- 身份核验记录表
CREATE TABLE IF NOT EXISTS `identity_verifications` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `verification_type` ENUM('id_card', 'passport', 'phone', 'email') NOT NULL COMMENT '核验类型',
    `verification_value` VARCHAR(255) NOT NULL COMMENT '核验值',
    `verification_result` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending' COMMENT '核验结果',
    `verification_data` JSON COMMENT '核验数据',
    `verified_by` BIGINT UNSIGNED COMMENT '核验员ID',
    `verified_at` TIMESTAMP NULL COMMENT '核验时间',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    KEY `idx_user_id` (`user_id`),
    KEY `idx_verification_type` (`verification_type`),
    KEY `idx_verification_result` (`verification_result`),
    KEY `idx_created_at` (`created_at`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`verified_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='身份核验记录表';

-- ========================================
-- 插入初始数据
-- ========================================

-- 插入默认角色
INSERT INTO `roles` (`name`, `display_name`, `description`) VALUES
('admin', '超级管理员', '系统超级管理员，拥有所有权限'),
('manager', '管理员', '系统管理员，拥有大部分管理权限'),
('operator', '操作员', '普通操作员，拥有基本操作权限'),
('viewer', '查看者', '只读用户，只能查看信息');

-- 插入默认权限
INSERT INTO `permissions` (`name`, `display_name`, `module`, `action`, `description`) VALUES
-- 用户管理权限
('user.view', '查看用户', 'user', 'view', '查看用户列表和详情'),
('user.create', '创建用户', 'user', 'create', '创建新用户'),
('user.edit', '编辑用户', 'user', 'edit', '编辑用户信息'),
('user.delete', '删除用户', 'user', 'delete', '删除用户'),
('user.manage_role', '管理用户角色', 'user', 'manage_role', '分配和管理用户角色'),

-- 产品管理权限
('product.view', '查看产品', 'product', 'view', '查看产品列表和详情'),
('product.create', '创建产品', 'product', 'create', '创建新产品'),
('product.edit', '编辑产品', 'product', 'edit', '编辑产品信息'),
('product.delete', '删除产品', 'product', 'delete', '删除产品'),

-- 卡密管理权限
('card.view', '查看卡密', 'card', 'view', '查看卡密列表和详情'),
('card.create', '生成卡密', 'card', 'create', '生成新卡密'),
('card.edit', '编辑卡密', 'card', 'edit', '编辑卡密信息'),
('card.delete', '删除卡密', 'card', 'delete', '删除卡密'),
('card.export', '导出卡密', 'card', 'export', '导出卡密数据'),

-- 订单管理权限
('order.view', '查看订单', 'order', 'view', '查看订单列表和详情'),
('order.create', '创建订单', 'order', 'create', '创建新订单'),
('order.edit', '编辑订单', 'order', 'edit', '编辑订单信息'),
('order.delete', '删除订单', 'order', 'delete', '删除订单'),
('order.process', '处理订单', 'order', 'process', '处理订单状态'),
('order.refund', '退款处理', 'order', 'refund', '处理订单退款'),

-- 系统管理权限
('system.config', '系统配置', 'system', 'config', '管理系统配置'),
('system.backup', '系统备份', 'system', 'backup', '执行系统备份'),
('system.logs', '查看日志', 'system', 'logs', '查看系统日志'),
('system.monitor', '系统监控', 'system', 'monitor', '查看系统监控信息');

-- 为角色分配权限
-- 超级管理员拥有所有权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r, `permissions` p WHERE r.name = 'admin';

-- 管理员权限（除了系统配置和备份）
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r, `permissions` p 
WHERE r.name = 'manager' AND p.module NOT IN ('system');

-- 操作员权限（用户、产品、卡密、订单的基本操作）
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r, `permissions` p 
WHERE r.name = 'operator' AND p.action IN ('view', 'create', 'edit') AND p.module NOT IN ('system');

-- 查看者权限（只有查看权限）
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r, `permissions` p 
WHERE r.name = 'viewer' AND p.action = 'view';

-- 插入默认管理员用户
INSERT INTO `users` (`username`, `password`, `email`, `real_name`, `role`, `status`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@example.com', '系统管理员', 'admin', 'active');

-- 为默认管理员分配角色
INSERT INTO `user_roles` (`user_id`, `role_id`)
SELECT u.id, r.id FROM `users` u, `roles` r 
WHERE u.username = 'admin' AND r.name = 'admin';

-- 插入默认系统配置
INSERT INTO `system_configs` (`config_key`, `config_value`, `config_type`, `description`) VALUES
('site_name', '发卡系统', 'string', '网站名称'),
('site_description', '专业的发卡系统', 'string', '网站描述'),
('admin_email', 'admin@example.com', 'string', '管理员邮箱'),
('max_login_attempts', '5', 'number', '最大登录尝试次数'),
('session_timeout', '7200', 'number', '会话超时时间(秒)'),
('password_min_length', '8', 'number', '密码最小长度'),
('enable_two_factor', 'false', 'boolean', '是否启用二次验证'),
('backup_retention_days', '30', 'number', '备份保留天数'),
('enable_registration', 'false', 'boolean', '是否允许用户注册'),
('default_user_role', 'viewer', 'string', '默认用户角色');

-- 插入默认产品分类
INSERT INTO `categories` (`name`, `description`, `parent_id`, `sort_order`) VALUES
('软件产品', '各类软件产品', NULL, 1),
('游戏产品', '游戏相关产品', NULL, 2),
('会员服务', '会员充值服务', NULL, 3),
('其他产品', '其他类型产品', NULL, 4);

-- ========================================
-- 创建视图
-- ========================================

-- 订单汇总视图
CREATE OR REPLACE VIEW `order_summary_view` AS
SELECT 
    o.id,
    o.order_no,
    o.user_id,
    u.username,
    u.email,
    o.product_id,
    o.product_name,
    o.quantity,
    o.unit_price,
    o.total_amount,
    o.discount_amount,
    o.actual_amount,
    o.payment_method,
    o.status,
    o.remark,
    o.created_at,
    o.updated_at,
    o.paid_at,
    o.completed_at,
    COUNT(oc.card_id) as card_count,
    SUM(CASE WHEN oc.status = 'activated' THEN 1 ELSE 0 END) as activated_cards,
    SUM(CASE WHEN oc.status = 'used' THEN 1 ELSE 0 END) as used_cards
FROM orders o
LEFT JOIN users u ON o.user_id = u.id
LEFT JOIN order_cards oc ON o.id = oc.order_id
GROUP BY o.id;

-- 产品统计视图
CREATE OR REPLACE VIEW `product_stats_view` AS
SELECT 
    p.id,
    p.name,
    p.price,
    p.stock,
    p.status,
    c.name as category_name,
    COUNT(cb.id) as batch_count,
    SUM(cb.quantity) as total_generated,
    SUM(CASE WHEN cd.status = 'active' THEN 1 ELSE 0 END) as active_cards,
    SUM(CASE WHEN cd.status = 'used' THEN 1 ELSE 0 END) as used_cards,
    SUM(CASE WHEN cd.status = 'expired' THEN 1 ELSE 0 END) as expired_cards
FROM products p
LEFT JOIN categories c ON p.category_id = c.id
LEFT JOIN card_batches cb ON p.id = cb.product_id
LEFT JOIN cards cd ON cb.id = cd.batch_id
GROUP BY p.id;

-- ========================================
-- 创建触发器
-- ========================================

-- 订单创建时记录操作日志
DELIMITER $$
CREATE TRIGGER `order_after_insert` 
AFTER INSERT ON `orders`
FOR EACH ROW
BEGIN
    INSERT INTO `order_status_logs` (`order_id`, `old_status`, `new_status`, `operator_id`, `operator_name`)
    VALUES (NEW.id, NULL, NEW.status, NEW.user_id, 'system');
END$$
DELIMITER ;

-- 订单状态更新时记录日志
DELIMITER $$
CREATE TRIGGER `order_after_update` 
AFTER UPDATE ON `orders`
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO `order_status_logs` (`order_id`, `old_status`, `new_status`, `operator_id`, `operator_name`)
        VALUES (NEW.id, OLD.status, NEW.status, NEW.user_id, 'system');
    END IF;
END$$
DELIMITER ;

-- 用户操作日志触发器
DELIMITER $$
CREATE TRIGGER `user_after_update` 
AFTER UPDATE ON `users`
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO `user_logs` (`user_id`, `action`, `description`, `target_type`, `target_id`)
        VALUES (NEW.id, 'status_change', CONCAT('状态变更: ', OLD.status, ' -> ', NEW.status), 'user', NEW.id);
    END IF;
END$$
DELIMITER ;

-- ========================================
-- 创建存储过程
-- ========================================

-- 清理过期会话
DELIMITER $$
CREATE PROCEDURE `cleanup_expired_sessions`(IN days_old INT)
BEGIN
    DELETE FROM `user_sessions` 
    WHERE `last_activity` < DATE_SUB(NOW(), INTERVAL days_old DAY);
END$$
DELIMITER ;

-- 清理旧日志
DELIMITER $$
CREATE PROCEDURE `cleanup_old_logs`(IN days_to_keep INT)
BEGIN
    -- 清理登录日志
    DELETE FROM `login_logs` 
    WHERE `created_at` < DATE_SUB(NOW(), INTERVAL days_to_keep DAY);
    
    -- 清理用户操作日志
    DELETE FROM `user_logs` 
    WHERE `created_at` < DATE_SUB(NOW(), INTERVAL days_to_keep DAY);
    
    -- 清理卡密使用日志
    DELETE FROM `card_usage_logs` 
    WHERE `created_at` < DATE_SUB(NOW(), INTERVAL days_to_keep DAY);
END$$
DELIMITER ;

-- ========================================
-- 创建索引优化
-- ========================================

-- 为经常查询的字段组合创建复合索引
ALTER TABLE `orders` ADD INDEX `idx_user_status_date` (`user_id`, `status`, `created_at`);
ALTER TABLE `cards` ADD INDEX `idx_status_expires` (`status`, `expires_at`);
ALTER TABLE `user_logs` ADD INDEX `idx_user_action_date` (`user_id`, `action`, `created_at`);

-- ========================================
-- 完成初始化
-- ========================================

SET FOREIGN_KEY_CHECKS = 1;

-- 输出初始化完成信息
SELECT '发卡系统数据库初始化完成！' as message,
       NOW() as init_time,
       VERSION() as mysql_version;