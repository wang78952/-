-- 订单精细化管理功能增强数据库脚本
-- 版本：v1.0
-- 日期：2024-03-01

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------
-- 1. 修改订单表，增加拆分相关字段
-- -----------------------------
ALTER TABLE IF EXISTS `orders` 
ADD COLUMN `parent_order_id` INT(11) NULL DEFAULT NULL COMMENT '父订单ID（用于订单拆分）' AFTER `id`,
ADD COLUMN `is_split` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否为拆分订单',
ADD COLUMN `split_reason` VARCHAR(255) NULL DEFAULT NULL COMMENT '拆分原因',
ADD COLUMN `after_sales_status` VARCHAR(50) NULL DEFAULT NULL COMMENT '售后状态(pending_processing,processing,completed,cancelled)',
ADD INDEX `idx_parent_order_id` (`parent_order_id`),
ADD INDEX `idx_after_sales_status` (`after_sales_status`);

-- -----------------------------
-- 2. 创建订单备注表
-- -----------------------------
CREATE TABLE IF NOT EXISTS `order_notes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '备注ID',
  `order_id` INT(11) NOT NULL COMMENT '订单ID',
  `user_id` INT(11) NULL DEFAULT NULL COMMENT '操作人ID',
  `user_type` ENUM('merchant', 'user', 'system') NOT NULL DEFAULT 'system' COMMENT '操作人类型',
  `content` TEXT NOT NULL COMMENT '备注内容',
  `is_public` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否公开（用户可见）',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_order_notes_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单备注表';

-- -----------------------------
-- 3. 创建售后申请表
-- -----------------------------
CREATE TABLE IF NOT EXISTS `order_after_sales` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '售后ID',
  `order_id` INT(11) NOT NULL COMMENT '订单ID',
  `refund_order_id` INT(11) NULL DEFAULT NULL COMMENT '退款订单ID',
  `user_id` INT(11) NOT NULL COMMENT '申请用户ID',
  `type` ENUM('refund', 'resend', 'complaint') NOT NULL DEFAULT 'refund' COMMENT '售后类型：退款/补发/投诉',
  `reason` VARCHAR(255) NOT NULL COMMENT '售后原因',
  `description` TEXT NULL COMMENT '详细描述',
  `evidence_urls` TEXT NULL COMMENT '凭证图片URLs（JSON格式）',
  `status` ENUM('pending', 'processing', 'approved', 'rejected', 'completed', 'cancelled') NOT NULL DEFAULT 'pending' COMMENT '状态',
  `amount` DECIMAL(10,2) NULL DEFAULT NULL COMMENT '申请退款金额',
  `admin_id` INT(11) NULL DEFAULT NULL COMMENT '处理管理员ID',
  `admin_note` TEXT NULL COMMENT '管理员处理备注',
  `processed_at` TIMESTAMP NULL DEFAULT NULL COMMENT '处理时间',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_refund_order_id` (`refund_order_id`),
  CONSTRAINT `fk_after_sales_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='售后申请表';

-- -----------------------------
-- 4. 创建售后处理日志表
-- -----------------------------
CREATE TABLE IF NOT EXISTS `after_sales_logs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `after_sales_id` INT(11) NOT NULL COMMENT '售后ID',
  `operator_id` INT(11) NULL DEFAULT NULL COMMENT '操作人ID',
  `operator_type` ENUM('merchant', 'user', 'system') NOT NULL DEFAULT 'system' COMMENT '操作人类型',
  `action` VARCHAR(50) NOT NULL COMMENT '操作动作',
  `content` TEXT NOT NULL COMMENT '操作内容',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_after_sales_id` (`after_sales_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_after_sales_logs_after_sales` FOREIGN KEY (`after_sales_id`) REFERENCES `order_after_sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='售后处理日志表';

-- -----------------------------
-- 5. 修改订单卡密关联表，增加拆分和售后相关字段
-- -----------------------------
ALTER TABLE IF EXISTS `order_cards` 
ADD COLUMN `is_after_sales` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否申请售后',
ADD COLUMN `after_sales_id` INT(11) NULL DEFAULT NULL COMMENT '关联的售后ID',
ADD COLUMN `replace_card_id` INT(11) NULL DEFAULT NULL COMMENT '替换的新卡密ID',
ADD COLUMN `refund_amount` DECIMAL(10,2) NULL DEFAULT NULL COMMENT '退款金额',
ADD INDEX `idx_after_sales_id` (`after_sales_id`),
ADD INDEX `idx_replace_card_id` (`replace_card_id`);

-- -----------------------------
-- 6. 创建订单导出模板配置表
-- -----------------------------
CREATE TABLE IF NOT EXISTS `order_export_templates` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '模板ID',
  `name` VARCHAR(100) NOT NULL COMMENT '模板名称',
  `type` ENUM('agent_orders', 'abnormal_orders', 'time_range_orders', 'custom') NOT NULL DEFAULT 'custom' COMMENT '模板类型',
  `config` TEXT NOT NULL COMMENT '模板配置（JSON格式，包含字段选择、排序等）',
  `user_id` INT(11) NULL DEFAULT NULL COMMENT '用户ID（NULL表示系统模板）',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否为系统模板',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单导出模板配置表';

-- -----------------------------
-- 7. 创建默认的订单导出模板
-- -----------------------------
INSERT INTO `order_export_templates` (`name`, `type`, `config`, `is_system`)
VALUES
('代理推广订单模板', 'agent_orders', '{"fields":["order_no","user_id","username","product_name","quantity","total_amount","actual_amount","payment_method","status","created_at","agent_name","commission_amount"],"sort":"created_at","order":"desc"}', 1),
('异常订单模板', 'abnormal_orders', '{"fields":["order_no","user_id","username","product_name","total_amount","payment_method","status","after_sales_status","problem_type","created_at","processed_at"],"sort":"created_at","order":"desc"}', 1),
('时间范围订单模板', 'time_range_orders', '{"fields":["order_no","user_id","username","product_name","quantity","unit_price","total_amount","discount_amount","actual_amount","payment_method","status","card_status","created_at","paid_at","completed_at"],"sort":"created_at","order":"desc"}', 1);

-- -----------------------------
-- 8. 创建订单拆分记录表
-- -----------------------------
CREATE TABLE IF NOT EXISTS `order_split_records` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `parent_order_id` INT(11) NOT NULL COMMENT '父订单ID',
  `split_order_id` INT(11) NOT NULL COMMENT '拆分出的订单ID',
  `operator_id` INT(11) NULL DEFAULT NULL COMMENT '操作人ID',
  `reason` VARCHAR(255) NOT NULL COMMENT '拆分原因',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_parent_order_id` (`parent_order_id`),
  KEY `idx_split_order_id` (`split_order_id`),
  CONSTRAINT `fk_order_split_parent` FOREIGN KEY (`parent_order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_split_split` FOREIGN KEY (`split_order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单拆分记录表';

SET FOREIGN_KEY_CHECKS = 1;