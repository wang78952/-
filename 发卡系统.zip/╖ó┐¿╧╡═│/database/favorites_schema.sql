-- 卡密收藏夹数据表结构
CREATE TABLE IF NOT EXISTS `card_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '收藏ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `card_id` int(11) NOT NULL COMMENT '卡密ID',
  `card_code` varchar(255) NOT NULL COMMENT '卡密码',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `product_name` varchar(255) NOT NULL COMMENT '产品名称',
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_card` (`user_id`,`card_id`,`card_code`),
  INDEX `idx_user` (`user_id`),
  INDEX `idx_card` (`card_id`),
  INDEX `idx_added_at` (`added_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户卡密收藏表';

-- 有效期提醒配置表
CREATE TABLE IF NOT EXISTS `expiry_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '提醒ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `card_id` int(11) NOT NULL COMMENT '卡密ID',
  `card_code` varchar(255) NOT NULL COMMENT '卡密码',
  `reminder_days` int(11) NOT NULL DEFAULT 7 COMMENT '提前提醒天数',
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否启用',
  `last_reminded` timestamp NULL DEFAULT NULL COMMENT '上次提醒时间',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  INDEX `idx_user_card` (`user_id`,`card_id`),
  INDEX `idx_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='卡密有效期提醒配置表';