-- 性能监控相关数据库表

-- 性能指标表
CREATE TABLE IF NOT EXISTS `performance_metrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` bigint(20) NOT NULL COMMENT '时间戳',
  `cpu_usage` decimal(5,2) DEFAULT 0 COMMENT 'CPU使用率(%)',
  `memory_usage` decimal(5,2) DEFAULT 0 COMMENT '内存使用率(%)',
  `disk_usage` decimal(5,2) DEFAULT 0 COMMENT '磁盘使用率(%)',
  `load_average` decimal(5,2) DEFAULT 0 COMMENT '系统负载',
  `network_io` text COMMENT '网络IO数据(JSON)',
  `process_count` int(11) DEFAULT 0 COMMENT '进程数量',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='性能指标表';

-- 告警表
CREATE TABLE IF NOT EXISTS `alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL COMMENT '告警类型(cpu/memory/disk/load)',
  `severity` enum('info','warning','critical') NOT NULL DEFAULT 'info' COMMENT '严重程度',
  `message` text NOT NULL COMMENT '告警消息',
  `threshold` decimal(5,2) DEFAULT 0 COMMENT '阈值',
  `details` text COMMENT '详细信息(JSON)',
  `status` enum('active','acknowledged','resolved') NOT NULL DEFAULT 'active' COMMENT '状态',
  `acknowledged_by` int(11) DEFAULT NULL COMMENT '确认人ID',
  `acknowledged_at` datetime DEFAULT NULL COMMENT '确认时间',
  `resolved_by` int(11) DEFAULT NULL COMMENT '解决人ID',
  `resolved_at` datetime DEFAULT NULL COMMENT '解决时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='告警表';

-- 监控配置表
CREATE TABLE IF NOT EXISTS `monitoring_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `description` varchar(255) DEFAULT NULL COMMENT '配置描述',
  `is_active` tinyint(1) DEFAULT 1 COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='监控配置表';

-- 插入默认监控配置
INSERT INTO `monitoring_config` (`config_key`, `config_value`, `description`) VALUES
('cpu_warning_threshold', '70', 'CPU使用率警告阈值'),
('cpu_critical_threshold', '90', 'CPU使用率严重阈值'),
('memory_warning_threshold', '75', '内存使用率警告阈值'),
('memory_critical_threshold', '90', '内存使用率严重阈值'),
('disk_warning_threshold', '80', '磁盘使用率警告阈值'),
('disk_critical_threshold', '95', '磁盘使用率严重阈值'),
('load_warning_threshold', '2.0', '系统负载警告阈值'),
('load_critical_threshold', '4.0', '系统负载严重阈值'),
('monitoring_enabled', '1', '是否启用监控'),
('alert_enabled', '1', '是否启用告警'),
('monitoring_interval', '60', '监控间隔(秒)'),
('data_retention_days', '30', '数据保留天数'),
('email_alerts_enabled', '0', '是否启用邮件告警'),
('sms_alerts_enabled', '0', '是否启用短信告警'),
('alert_email_addresses', '', '告警邮箱地址(逗号分隔)'),
('alert_phone_numbers', '', '告警手机号(逗号分隔)');

-- 业务指标表
CREATE TABLE IF NOT EXISTS `business_metrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metric_name` varchar(100) NOT NULL COMMENT '指标名称',
  `metric_value` decimal(15,2) NOT NULL COMMENT '指标值',
  `metric_unit` varchar(20) DEFAULT NULL COMMENT '指标单位',
  `tags` text COMMENT '标签(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_metric_name` (`metric_name`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='业务指标表';

-- 系统健康检查表
CREATE TABLE IF NOT EXISTS `health_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_name` varchar(100) NOT NULL COMMENT '检查名称',
  `status` enum('healthy','warning','critical') NOT NULL DEFAULT 'healthy' COMMENT '状态',
  `response_time` decimal(8,3) DEFAULT 0 COMMENT '响应时间(毫秒)',
  `details` text COMMENT '详细信息(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_check_name` (`check_name`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统健康检查表';