-- 安全管理相关数据库表结构

-- 限流记录表
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `identifier` varchar(255) NOT NULL COMMENT '标识符(IP地址或用户ID)',
  `timestamp` int(11) NOT NULL COMMENT '时间戳',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_identifier_timestamp` (`identifier`, `timestamp`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='接口限流记录表';

-- 登录保护表
CREATE TABLE IF NOT EXISTS `login_protection` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `identifier` varchar(255) NOT NULL COMMENT '标识符(用户名、邮箱或IP)',
  `failure_count` int(11) NOT NULL DEFAULT 0 COMMENT '失败次数',
  `last_failure_time` timestamp NULL DEFAULT NULL COMMENT '最后失败时间',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_identifier` (`identifier`),
  KEY `idx_failure_count` (`failure_count`),
  KEY `idx_last_failure_time` (`last_failure_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录保护表';

-- 登录日志表
CREATE TABLE IF NOT EXISTS `login_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `identifier` varchar(255) NOT NULL COMMENT '标识符(用户名、邮箱或IP)',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `status` enum('success','failure','blocked') NOT NULL COMMENT '登录状态',
  `failure_reason` varchar(255) DEFAULT NULL COMMENT '失败原因',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_identifier` (`identifier`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录日志表';

-- 审计日志表
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '用户ID',
  `username` varchar(100) DEFAULT NULL COMMENT '用户名',
  `action` varchar(100) NOT NULL COMMENT '操作动作',
  `resource` varchar(255) NOT NULL COMMENT '操作资源',
  `resource_id` varchar(100) DEFAULT NULL COMMENT '资源ID',
  `details` json DEFAULT NULL COMMENT '操作详情',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `session_id` varchar(255) DEFAULT NULL COMMENT '会话ID',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_username` (`username`),
  KEY `idx_action` (`action`),
  KEY `idx_resource` (`resource`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审计日志表';

-- 安全事件表
CREATE TABLE IF NOT EXISTS `security_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `event_type` varchar(50) NOT NULL COMMENT '事件类型',
  `severity` enum('low','medium','high','critical') NOT NULL COMMENT '严重程度',
  `title` varchar(255) NOT NULL COMMENT '事件标题',
  `description` text COMMENT '事件描述',
  `source_ip` varchar(45) DEFAULT NULL COMMENT '源IP地址',
  `target_user` varchar(100) DEFAULT NULL COMMENT '目标用户',
  `target_resource` varchar(255) DEFAULT NULL COMMENT '目标资源',
  `details` json DEFAULT NULL COMMENT '事件详情',
  `status` enum('open','investigating','resolved','false_positive') NOT NULL DEFAULT 'open' COMMENT '处理状态',
  `assigned_to` bigint(20) unsigned DEFAULT NULL COMMENT '分配给',
  `resolved_by` bigint(20) unsigned DEFAULT NULL COMMENT '解决人',
  `resolved_at` timestamp NULL DEFAULT NULL COMMENT '解决时间',
  `resolution_notes` text COMMENT '解决说明',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_status` (`status`),
  KEY `idx_source_ip` (`source_ip`),
  KEY `idx_target_user` (`target_user`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_assigned_to` (`assigned_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='安全事件表';

-- 敏感操作日志表
CREATE TABLE IF NOT EXISTS `sensitive_operations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `operation_type` varchar(50) NOT NULL COMMENT '操作类型',
  `operation_name` varchar(255) NOT NULL COMMENT '操作名称',
  `target_data` json DEFAULT NULL COMMENT '目标数据',
  `old_values` json DEFAULT NULL COMMENT '修改前值',
  `new_values` json DEFAULT NULL COMMENT '修改后值',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `risk_level` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium' COMMENT '风险等级',
  `approval_required` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否需要审批',
  `approved_by` bigint(20) unsigned DEFAULT NULL COMMENT '审批人',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT '审批时间',
  `approval_notes` text COMMENT '审批说明',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_username` (`username`),
  KEY `idx_operation_type` (`operation_type`),
  KEY `idx_risk_level` (`risk_level`),
  KEY `idx_approval_required` (`approval_required`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='敏感操作日志表';

-- IP黑白名单表
CREATE TABLE IF NOT EXISTS `ip_lists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ip_address` varchar(45) NOT NULL COMMENT 'IP地址',
  `ip_range` varchar(45) DEFAULT NULL COMMENT 'IP范围(CIDR格式)',
  `list_type` enum('whitelist','blacklist') NOT NULL COMMENT '列表类型',
  `reason` varchar(255) DEFAULT NULL COMMENT '原因',
  `created_by` bigint(20) unsigned DEFAULT NULL COMMENT '创建人',
  `expires_at` timestamp NULL DEFAULT NULL COMMENT '过期时间',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否激活',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ip_address` (`ip_address`),
  KEY `idx_list_type` (`list_type`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IP黑白名单表';

-- 安全配置表
CREATE TABLE IF NOT EXISTS `security_configs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `config_type` enum('string','number','boolean','json') NOT NULL DEFAULT 'string' COMMENT '配置类型',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_encrypted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否加密',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='安全配置表';

-- 插入默认安全配置
INSERT INTO `security_configs` (`config_key`, `config_value`, `config_type`, `description`) VALUES
('force_https', 'true', 'boolean', '强制HTTPS'),
('session_timeout', '3600', 'number', '会话超时时间(秒)'),
('password_min_length', '8', 'number', '密码最小长度'),
('password_require_special', 'true', 'boolean', '密码要求特殊字符'),
('max_login_attempts', '5', 'number', '最大登录尝试次数'),
('login_lockout_time', '1800', 'number', '登录锁定时间(秒)'),
('rate_limit_window', '60', 'number', '限流时间窗口(秒)'),
('rate_limit_requests', '100', 'number', '限流请求数'),
('enable_audit_log', 'true', 'boolean', '启用审计日志'),
('enable_ip_whitelist', 'false', 'boolean', '启用IP白名单'),
('enable_ip_blacklist', 'true', 'boolean', '启用IP黑名单'),
('file_upload_max_size', '5242880', 'number', '文件上传最大大小(字节)'),
('enable_csrf_protection', 'true', 'boolean', '启用CSRF保护'),
('enable_xss_protection', 'true', 'boolean', '启用XSS保护'),
('enable_sql_injection_protection', 'true', 'boolean', '启用SQL注入保护');

-- 创建触发器：自动清理过期的限流记录
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `cleanup_rate_limits` 
AFTER INSERT ON `rate_limits`
FOR EACH ROW
BEGIN
    DELETE FROM `rate_limits` WHERE timestamp < UNIX_TIMESTAMP() - 3600; -- 清理1小时前的记录
END//
DELIMITER ;

-- 创建存储过程：获取安全统计信息
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `GetSecurityStats`(IN date_range INT)
BEGIN
    DECLARE start_date DATETIME;
    SET start_date = DATE_SUB(NOW(), INTERVAL date_range DAY);
    
    -- 登录统计
    SELECT 
        'login_stats' as type,
        COUNT(*) as total_logins,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_logins,
        SUM(CASE WHEN status = 'failure' THEN 1 ELSE 0 END) as failed_logins,
        SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked_logins
    FROM login_logs 
    WHERE created_at >= start_date;
    
    -- 安全事件统计
    SELECT 
        'security_events' as type,
        COUNT(*) as total_events,
        SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical_events,
        SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high_events,
        SUM(CASE WHEN severity = 'medium' THEN 1 ELSE 0 END) as medium_events,
        SUM(CASE WHEN severity = 'low' THEN 1 ELSE 0 END) as low_events
    FROM security_events 
    WHERE created_at >= start_date;
    
    -- 敏感操作统计
    SELECT 
        'sensitive_operations' as type,
        COUNT(*) as total_operations,
        SUM(CASE WHEN risk_level = 'critical' THEN 1 ELSE 0 END) as critical_operations,
        SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END) as high_operations,
        SUM(CASE WHEN risk_level = 'medium' THEN 1 ELSE 0 END) as medium_operations,
        SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END) as low_operations
    FROM sensitive_operations 
    WHERE created_at >= start_date;
    
END//
DELIMITER ;

-- 创建视图：安全事件概览
CREATE OR REPLACE VIEW `v_security_overview` AS
SELECT 
    DATE(created_at) as event_date,
    COUNT(*) as total_events,
    SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical_count,
    SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high_count,
    SUM(CASE WHEN severity = 'medium' THEN 1 ELSE 0 END) as medium_count,
    SUM(CASE WHEN severity = 'low' THEN 1 ELSE 0 END) as low_count,
    SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_count,
    SUM(CASE WHEN status = 'investigating' THEN 1 ELSE 0 END) as investigating_count,
    SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved_count,
    SUM(CASE WHEN status = 'false_positive' THEN 1 ELSE 0 END) as false_positive_count
FROM security_events 
GROUP BY DATE(created_at)
ORDER BY event_date DESC;

-- 创建视图：登录风险分析
CREATE OR REPLACE VIEW `v_login_risk_analysis` AS
SELECT 
    DATE(created_at) as login_date,
    COUNT(*) as total_attempts,
    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_logins,
    SUM(CASE WHEN status = 'failure' THEN 1 ELSE 0 END) as failed_logins,
    SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked_logins,
    COUNT(DISTINCT identifier) as unique_users,
    COUNT(DISTINCT ip_address) as unique_ips,
    ROUND(SUM(CASE WHEN status = 'failure' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as failure_rate
FROM login_logs 
GROUP BY DATE(created_at)
ORDER BY login_date DESC;

-- 创建索引优化
CREATE INDEX IF NOT EXISTS `idx_rate_limits_cleanup` ON `rate_limits` (`timestamp`);
CREATE INDEX IF NOT EXISTS `idx_audit_logs_user_time` ON `audit_logs` (`user_id`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_security_events_severity_status` ON `security_events` (`severity`, `status`);
CREATE INDEX IF NOT EXISTS `idx_sensitive_operations_user_time` ON `sensitive_operations` (`user_id`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_login_logs_status_time` ON `login_logs` (`status`, `created_at`);