-- 支付相关数据库表结构

-- 支付记录表
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '支付ID',
  `order_id` int(11) NOT NULL COMMENT '关联订单ID',
  `payment_method` varchar(20) NOT NULL COMMENT '支付方式：alipay/wechat/balance',
  `payment_type` varchar(20) DEFAULT 'online' COMMENT '支付类型：online/offline',
  `amount` decimal(10,2) NOT NULL COMMENT '支付金额',
  `paid_amount` decimal(10,2) DEFAULT NULL COMMENT '实际支付金额',
  `currency` varchar(10) DEFAULT 'CNY' COMMENT '货币类型',
  `subject` varchar(255) DEFAULT NULL COMMENT '支付主题',
  `out_trade_no` varchar(64) DEFAULT NULL COMMENT '第三方交易号',
  `trade_no` varchar(64) DEFAULT NULL COMMENT '第三方支付流水号',
  `status` varchar(20) NOT NULL DEFAULT 'created' COMMENT '状态：created/pending/success/failed/closed/refunded',
  `payment_data` text COMMENT '支付数据(JSON)',
  `callback_data` text COMMENT '回调数据(JSON)',
  `query_data` text COMMENT '查询数据(JSON)',
  `extra_data` text COMMENT '扩展数据(JSON)',
  `client_ip` varchar(45) DEFAULT NULL COMMENT '客户端IP',
  `user_agent` varchar(500) DEFAULT NULL COMMENT '用户代理',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `paid_at` datetime DEFAULT NULL COMMENT '支付完成时间',
  `expired_at` datetime DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_out_trade_no` (`out_trade_no`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_payment_method` (`payment_method`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_payments_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付记录表';

-- 退款记录表
CREATE TABLE IF NOT EXISTS `refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '退款ID',
  `payment_id` int(11) NOT NULL COMMENT '支付ID',
  `refund_no` varchar(64) NOT NULL COMMENT '退款单号',
  `out_refund_no` varchar(64) DEFAULT NULL COMMENT '第三方退款单号',
  `refund_amount` decimal(10,2) NOT NULL COMMENT '退款金额',
  `refund_fee` decimal(10,2) DEFAULT NULL COMMENT '退款手续费',
  `refund_reason` varchar(255) DEFAULT NULL COMMENT '退款原因',
  `status` varchar(20) NOT NULL DEFAULT 'created' COMMENT '状态：created/processing/success/failed/cancelled',
  `refund_data` text COMMENT '退款数据(JSON)',
  `callback_data` text COMMENT '回调数据(JSON)',
  `operator_id` int(11) DEFAULT NULL COMMENT '操作员ID',
  `operator_name` varchar(50) DEFAULT NULL COMMENT '操作员姓名',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `processed_at` datetime DEFAULT NULL COMMENT '处理时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_refund_no` (`refund_no`),
  KEY `idx_payment_id` (`payment_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_refunds_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='退款记录表';

-- 支付日志表
CREATE TABLE IF NOT EXISTS `payment_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `payment_id` int(11) DEFAULT NULL COMMENT '支付ID',
  `refund_id` int(11) DEFAULT NULL COMMENT '退款ID',
  `action` varchar(50) NOT NULL COMMENT '操作类型：create/query/refund/callback/close',
  `level` varchar(20) DEFAULT 'info' COMMENT '日志级别：info/warning/error',
  `message` varchar(500) DEFAULT NULL COMMENT '日志消息',
  `data` text COMMENT '相关数据(JSON)',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` varchar(500) DEFAULT NULL COMMENT '用户代理',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_payment_id` (`payment_id`),
  KEY `idx_refund_id` (`refund_id`),
  KEY `idx_action` (`action`),
  KEY `idx_level` (`level`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_payment_logs_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_logs_refund` FOREIGN KEY (`refund_id`) REFERENCES `refunds` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付日志表';

-- 支付配置表
CREATE TABLE IF NOT EXISTS `payment_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `payment_method` varchar(20) NOT NULL COMMENT '支付方式',
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `config_type` varchar(20) DEFAULT 'string' COMMENT '配置类型：string/json/boolean/number',
  `is_encrypted` tinyint(1) DEFAULT 0 COMMENT '是否加密',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_active` tinyint(1) DEFAULT 1 COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_method_key` (`payment_method`, `config_key`),
  KEY `idx_payment_method` (`payment_method`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付配置表';

-- 支付方式表
CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `code` varchar(20) NOT NULL COMMENT '支付方式代码',
  `name` varchar(50) NOT NULL COMMENT '支付方式名称',
  `icon` varchar(100) DEFAULT NULL COMMENT '图标',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `min_amount` decimal(10,2) DEFAULT 0.01 COMMENT '最小金额',
  `max_amount` decimal(10,2) DEFAULT 50000.00 COMMENT '最大金额',
  `fee_type` varchar(20) DEFAULT 'fixed' COMMENT '手续费类型：fixed/rate',
  `fee_value` decimal(10,4) DEFAULT 0.0000 COMMENT '手续费值',
  `is_online` tinyint(1) DEFAULT 1 COMMENT '是否在线支付',
  `is_active` tinyint(1) DEFAULT 1 COMMENT '是否启用',
  `sort_order` int(11) DEFAULT 0 COMMENT '排序',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付方式表';

-- 支付回调记录表
CREATE TABLE IF NOT EXISTS `payment_callbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '回调ID',
  `payment_id` int(11) DEFAULT NULL COMMENT '支付ID',
  `refund_id` int(11) DEFAULT NULL COMMENT '退款ID',
  `payment_method` varchar(20) NOT NULL COMMENT '支付方式',
  `callback_type` varchar(20) NOT NULL COMMENT '回调类型：payment/refund',
  `raw_data` text NOT NULL COMMENT '原始回调数据',
  `parsed_data` text COMMENT '解析后的数据(JSON)',
  `signature` varchar(255) DEFAULT NULL COMMENT '签名',
  `is_verified` tinyint(1) DEFAULT 0 COMMENT '是否验证通过',
  `is_processed` tinyint(1) DEFAULT 0 COMMENT '是否已处理',
  `process_result` varchar(20) DEFAULT NULL COMMENT '处理结果：success/failed/pending',
  `process_message` varchar(500) DEFAULT NULL COMMENT '处理消息',
  `ip_address` varchar(45) DEFAULT NULL COMMENT '回调IP',
  `user_agent` varchar(500) DEFAULT NULL COMMENT '用户代理',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `processed_at` datetime DEFAULT NULL COMMENT '处理时间',
  PRIMARY KEY (`id`),
  KEY `idx_payment_id` (`payment_id`),
  KEY `idx_refund_id` (`refund_id`),
  KEY `idx_payment_method` (`payment_method`),
  KEY `idx_callback_type` (`callback_type`),
  KEY `idx_is_processed` (`is_processed`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_payment_callbacks_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_callbacks_refund` FOREIGN KEY (`refund_id`) REFERENCES `refunds` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付回调记录表';

-- 插入默认支付方式
INSERT INTO `payment_methods` (`code`, `name`, `icon`, `description`, `min_amount`, `max_amount`, `fee_type`, `fee_value`, `is_online`, `is_active`, `sort_order`) VALUES
('alipay', '支付宝', 'alipay.png', '支付宝在线支付', 0.01, 50000.00, 'rate', 0.0060, 1, 1, 1),
('wechat', '微信支付', 'wechat.png', '微信在线支付', 0.01, 50000.00, 'rate', 0.0060, 1, 1, 2),
('balance', '余额支付', 'balance.png', '账户余额支付', 0.01, 10000.00, 'fixed', 0.0000, 1, 1, 3),
('bank', '银行转账', 'bank.png', '银行线下转账', 100.00, 100000.00, 'fixed', 2.0000, 0, 1, 4);

-- 插入默认支付配置
INSERT INTO `payment_configs` (`payment_method`, `config_key`, `config_value`, `config_type`, `is_encrypted`, `description`) VALUES
('alipay', 'app_id', '', 'string', 0, '支付宝应用ID'),
('alipay', 'private_key', '', 'string', 1, '支付宝私钥'),
('alipay', 'public_key', '', 'string', 0, '支付宝公钥'),
('alipay', 'notify_url', '/payment/alipay/notify', 'string', 0, '支付宝回调地址'),
('alipay', 'return_url', '/payment/alipay/return', 'string', 0, '支付宝返回地址'),
('alipay', 'sandbox', 'false', 'boolean', 0, '是否沙箱模式'),
('wechat', 'app_id', '', 'string', 0, '微信应用ID'),
('wechat', 'mch_id', '', 'string', 0, '微信商户号'),
('wechat', 'key', '', 'string', 1, '微信支付密钥'),
('wechat', 'cert_path', '', 'string', 0, '微信证书路径'),
('wechat', 'key_path', '', 'string', 0, '微信私钥路径'),
('wechat', 'notify_url', '/payment/wechat/notify', 'string', 0, '微信回调地址'),
('balance', 'enabled', 'true', 'boolean', 0, '是否启用余额支付'),
('balance', 'min_balance', '0.00', 'number', 0, '最小余额要求');

-- 创建索引优化查询性能
CREATE INDEX idx_payments_order_status ON payments(order_id, status);
CREATE INDEX idx_payments_method_status ON payments(payment_method, status);
CREATE INDEX idx_payments_created_status ON payments(created_at, status);
CREATE INDEX idx_refunds_payment_status ON refunds(payment_id, status);
CREATE INDEX idx_payment_logs_payment_action ON payment_logs(payment_id, action);
CREATE INDEX idx_payment_callbacks_method_processed ON payment_callbacks(payment_method, is_processed);