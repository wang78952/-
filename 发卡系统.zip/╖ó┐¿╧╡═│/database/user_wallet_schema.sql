-- 用户卡包表
CREATE TABLE IF NOT EXISTS `user_wallet_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `order_id` int(11) NOT NULL COMMENT '订单ID',
  `card_id` int(11) NOT NULL COMMENT '原始卡密ID',
  `card_code` varchar(100) NOT NULL COMMENT '卡密编码',
  `card_secret` text NOT NULL COMMENT '卡密密码',
  `product_name` varchar(255) NOT NULL COMMENT '产品名称',
  `product_image` varchar(500) DEFAULT NULL COMMENT '产品图片',
  `category` varchar(50) DEFAULT NULL COMMENT '产品分类',
  `status` enum('unused','used','expired') NOT NULL DEFAULT 'unused' COMMENT '状态',
  `added_at` datetime NOT NULL COMMENT '添加时间',
  `used_at` datetime DEFAULT NULL COMMENT '使用时间',
  `used_ip` varchar(45) DEFAULT NULL COMMENT '使用IP',
  `used_device` varchar(255) DEFAULT NULL COMMENT '使用设备',
  `usage_notes` text DEFAULT NULL COMMENT '使用备注',
  `expires_at` datetime DEFAULT NULL COMMENT '过期时间',
  `wechat_synced` tinyint(1) DEFAULT 0 COMMENT '是否同步到微信',
  `alipay_synced` tinyint(1) DEFAULT 0 COMMENT '是否同步到支付宝',
  `synced_at` datetime DEFAULT NULL COMMENT '同步时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_user_status` (`user_id`, `status`),
  KEY `idx_user_category` (`user_id`, `category`),
  UNIQUE KEY `uk_user_card` (`user_id`, `card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户卡包表';

-- 复购清单表
CREATE TABLE IF NOT EXISTS `user_repurchase_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `product_name` varchar(255) NOT NULL COMMENT '产品名称',
  `product_image` varchar(500) DEFAULT NULL COMMENT '产品图片',
  `last_order_id` int(11) NOT NULL COMMENT '最后订单ID',
  `last_quantity` int(11) NOT NULL DEFAULT 1 COMMENT '最后购买数量',
  `last_price` decimal(10,2) NOT NULL COMMENT '最后购买价格',
  `reminder_type` enum('none','weekly','monthly','custom') NOT NULL DEFAULT 'none' COMMENT '提醒类型',
  `reminder_interval` int(11) DEFAULT NULL COMMENT '提醒间隔（天）',
  `next_reminder_date` date DEFAULT NULL COMMENT '下次提醒日期',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否激活',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_reminder_date` (`next_reminder_date`),
  KEY `idx_user_active` (`user_id`, `is_active`),
  UNIQUE KEY `uk_user_product` (`user_id`, `product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户复购清单表';

-- 卡密激活指引表
CREATE TABLE IF NOT EXISTS `card_activation_guides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `merchant_id` int(11) NOT NULL COMMENT '商户ID',
  `title` varchar(255) NOT NULL COMMENT '指引标题',
  `description` text DEFAULT NULL COMMENT '指引描述',
  `activation_url` varchar(500) DEFAULT NULL COMMENT '激活入口链接',
  `steps` json DEFAULT NULL COMMENT '激活步骤（JSON格式）',
  `common_issues` json DEFAULT NULL COMMENT '常见问题（JSON格式）',
  `images` json DEFAULT NULL COMMENT '指引图片（JSON格式）',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否激活',
  `sort_order` int(11) DEFAULT 0 COMMENT '排序',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_merchant_id` (`merchant_id`),
  KEY `idx_active_sort` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密激活指引表';

-- 用户卡密激活记录表
CREATE TABLE IF NOT EXISTS `user_card_activations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `wallet_card_id` int(11) NOT NULL COMMENT '卡包卡密ID',
  `card_code` varchar(100) NOT NULL COMMENT '卡密编码',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `activation_time` datetime NOT NULL COMMENT '激活时间',
  `activation_ip` varchar(45) DEFAULT NULL COMMENT '激活IP',
  `activation_device` varchar(255) DEFAULT NULL COMMENT '激活设备',
  `activation_result` enum('success','failed','pending') NOT NULL COMMENT '激活结果',
  `error_message` text DEFAULT NULL COMMENT '错误信息',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_wallet_card_id` (`wallet_card_id`),
  KEY `idx_card_code` (`card_code`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_activation_time` (`activation_time`),
  KEY `idx_activation_result` (`activation_result`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户卡密激活记录表';

-- 微信通知模板表
CREATE TABLE IF NOT EXISTS `wechat_notification_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` varchar(100) NOT NULL COMMENT '微信模板ID',
  `template_name` varchar(255) NOT NULL COMMENT '模板名称',
  `title` varchar(255) NOT NULL COMMENT '模板标题',
  `content` text NOT NULL COMMENT '模板内容',
  `example` text DEFAULT NULL COMMENT '示例',
  `type` varchar(50) NOT NULL COMMENT '通知类型',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否激活',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_template_id` (`template_id`),
  KEY `idx_type` (`type`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='微信通知模板表';

-- 支付宝卡券记录表
CREATE TABLE IF NOT EXISTS `alipay_vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `wallet_card_id` int(11) NOT NULL COMMENT '卡包卡密ID',
  `voucher_id` varchar(100) NOT NULL COMMENT '支付宝卡券ID',
  `voucher_title` varchar(255) NOT NULL COMMENT '卡券标题',
  `voucher_code` varchar(100) NOT NULL COMMENT '卡券码',
  `voucher_secret` varchar(100) DEFAULT NULL COMMENT '卡券密码',
  `valid_start_time` datetime NOT NULL COMMENT '有效开始时间',
  `valid_end_time` datetime NOT NULL COMMENT '有效结束时间',
  `status` enum('active','used','expired') NOT NULL DEFAULT 'active' COMMENT '状态',
  `sync_time` datetime NOT NULL COMMENT '同步时间',
  `notify_url` varchar(500) DEFAULT NULL COMMENT '通知URL',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_wallet_card_id` (`wallet_card_id`),
  KEY `idx_voucher_id` (`voucher_id`),
  KEY `idx_status` (`status`),
  KEY `idx_valid_end_time` (`valid_end_time`),
  UNIQUE KEY `uk_voucher_id` (`voucher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付宝卡券记录表';

-- 用户扩展信息表（用于存储第三方账号绑定）
CREATE TABLE IF NOT EXISTS `user_external_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `platform` enum('wechat','alipay','qq','weibo') NOT NULL COMMENT '平台',
  `open_id` varchar(100) NOT NULL COMMENT '第三方用户ID',
  `union_id` varchar(100) DEFAULT NULL COMMENT '统一用户ID（微信）',
  `nickname` varchar(100) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(500) DEFAULT NULL COMMENT '头像',
  `access_token` text DEFAULT NULL COMMENT '访问令牌',
  `refresh_token` text DEFAULT NULL COMMENT '刷新令牌',
  `expires_at` datetime DEFAULT NULL COMMENT '令牌过期时间',
  `is_verified` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已验证',
  `last_sync_time` datetime DEFAULT NULL COMMENT '最后同步时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_platform` (`platform`),
  KEY `idx_open_id` (`open_id`),
  UNIQUE KEY `uk_user_platform` (`user_id`, `platform`),
  UNIQUE KEY `uk_platform_openid` (`platform`, `open_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户第三方账号绑定表';

-- 插入默认的微信通知模板
INSERT INTO `wechat_notification_templates` (`template_id`, `template_name`, `title`, `content`, `type`) VALUES
('card_delivery', '卡密发放通知', '您的卡密已到账', '您好，您购买的{{product_name}}卡密已发放到您的账户。\n\n卡密编码：{{card_code}}\n购买时间：{{purchase_time}}\n\n请及时查收并妥善保管。', 'card_delivery'),
('card_expiry_reminder', '卡密过期提醒', '卡密即将过期', '您好，您有{{count}}张卡密即将在{{days}}天内过期，请及时使用。\n\n过期时间：{{expiry_date}}\n\n点击查看详情。', 'expiry_reminder'),
('repurchase_reminder', '复购提醒', '您可能需要再次购买', '您好，您上次购买的{{product_name}}可能即将到期，是否需要再次购买？\n\n上次购买：{{last_purchase_date}}\n购买数量：{{last_quantity}}\n\n点击查看产品详情。', 'repurchase_reminder');

-- 为现有用户表添加第三方账号字段（如果不存在）
ALTER TABLE `users` 
ADD COLUMN IF NOT EXISTS `wechat_openid` varchar(100) DEFAULT NULL COMMENT '微信OpenID',
ADD COLUMN IF NOT EXISTS `wechat_unionid` varchar(100) DEFAULT NULL COMMENT '微信UnionID',
ADD COLUMN IF NOT EXISTS `alipay_user_id` varchar(100) DEFAULT NULL COMMENT '支付宝用户ID',
ADD COLUMN IF NOT EXISTS `qq_openid` varchar(100) DEFAULT NULL COMMENT 'QQ OpenID',
ADD COLUMN IF NOT EXISTS `weibo_uid` varchar(100) DEFAULT NULL COMMENT '微博UID',
ADD INDEX IF NOT EXISTS `idx_wechat_openid` (`wechat_openid`),
ADD INDEX IF NOT EXISTS `idx_wechat_unionid` (`wechat_unionid`),
ADD INDEX IF NOT EXISTS `idx_alipay_user_id` (`alipay_user_id`);