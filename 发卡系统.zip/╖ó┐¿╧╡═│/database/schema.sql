-- 商业级发卡系统数据库表结构
-- 支持安全加密存储、用户权限管理、操作审计等功能

-- 创建数据库
CREATE DATABASE IF NOT EXISTS card_system 
DEFAULT CHARACTER SET utf8mb4 
DEFAULT COLLATE utf8mb4_unicode_ci;

USE card_system;

-- 用户表
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码哈希',
    email VARCHAR(100) UNIQUE COMMENT '邮箱',
    phone VARCHAR(20) COMMENT '手机号',
    real_name VARCHAR(50) COMMENT '真实姓名',
    role ENUM('admin', 'manager', 'operator', 'viewer') NOT NULL DEFAULT 'operator' COMMENT '角色',
    status ENUM('active', 'inactive', 'locked') NOT NULL DEFAULT 'active' COMMENT '状态',
    failed_login_count INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录失败次数',
    last_login_time TIMESTAMP NULL COMMENT '最后登录时间',
    last_login_ip VARCHAR(45) COMMENT '最后登录IP',
    last_failed_login_time TIMESTAMP NULL COMMENT '最后登录失败时间',
    last_failed_login_ip VARCHAR(45) COMMENT '最后登录失败IP',
    two_factor_code VARCHAR(10) NULL COMMENT '二次验证码',
    two_factor_expire_time TIMESTAMP NULL COMMENT '二次验证码过期时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB COMMENT='用户表';

-- 卡片信息表（敏感信息加密存储）
CREATE TABLE cards (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    card_number_encrypted TEXT NOT NULL COMMENT '加密的卡号',
    card_number_hash VARCHAR(64) NOT NULL UNIQUE COMMENT '卡号哈希（用于快速查询）',
    card_type ENUM('credit', 'debit', 'prepaid') NOT NULL DEFAULT 'credit' COMMENT '卡片类型',
    card_holder_encrypted TEXT COMMENT '加密的持卡人姓名',
    holder_phone_encrypted TEXT COMMENT '加密的持卡人手机号',
    holder_email_encrypted TEXT COMMENT '加密的持卡人邮箱',
    bank_name VARCHAR(100) COMMENT '发卡银行',
    card_level ENUM('standard', 'gold', 'platinum', 'diamond') DEFAULT 'standard' COMMENT '卡片等级',
    credit_limit DECIMAL(12,2) COMMENT '信用额度',
    currency VARCHAR(3) DEFAULT 'CNY' COMMENT '货币类型',
    issue_date DATE COMMENT '发卡日期',
    expire_date DATE COMMENT '到期日期',
    status ENUM('active', 'inactive', 'frozen', 'cancelled', 'expired') NOT NULL DEFAULT 'active' COMMENT '卡片状态',
    activation_code_encrypted TEXT COMMENT '加密的激活码',
    activation_status ENUM('unactivated', 'activated') DEFAULT 'unactivated' COMMENT '激活状态',
    activation_time TIMESTAMP NULL COMMENT '激活时间',
    cvv_encrypted TEXT COMMENT '加密的CVV',
    pin_encrypted TEXT COMMENT '加密的PIN码',
    created_by BIGINT UNSIGNED COMMENT '创建者ID',
    updated_by BIGINT UNSIGNED COMMENT '更新者ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX idx_card_number_hash (card_number_hash),
    INDEX idx_status (status),
    INDEX idx_card_type (card_type),
    INDEX idx_bank_name (bank_name),
    INDEX idx_created_by (created_by),
    INDEX idx_created_at (created_at),
    INDEX idx_expire_date (expire_date),
    
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='卡片信息表';

-- 卡片状态变更记录表
CREATE TABLE card_status_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    card_id BIGINT UNSIGNED NOT NULL COMMENT '卡片ID',
    old_status VARCHAR(20) COMMENT '原状态',
    new_status VARCHAR(20) NOT NULL COMMENT '新状态',
    change_reason VARCHAR(200) COMMENT '变更原因',
    operator_id BIGINT UNSIGNED NOT NULL COMMENT '操作员ID',
    operator_ip VARCHAR(45) COMMENT '操作IP',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '变更时间',
    
    INDEX idx_card_id (card_id),
    INDEX idx_operator_id (operator_id),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (card_id) REFERENCES cards(id) ON DELETE CASCADE,
    FOREIGN KEY (operator_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='卡片状态变更记录表';

-- 用户操作日志表
CREATE TABLE user_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    action VARCHAR(50) NOT NULL COMMENT '操作类型',
    description TEXT NOT NULL COMMENT '操作描述',
    target_type VARCHAR(50) COMMENT '目标类型',
    target_id BIGINT UNSIGNED COMMENT '目标ID',
    ip VARCHAR(45) COMMENT 'IP地址',
    user_agent TEXT COMMENT '用户代理',
    context JSON COMMENT '上下文信息',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_target_type (target_type),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='用户操作日志表';

-- 登录日志表
CREATE TABLE login_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL COMMENT '用户名',
    user_id BIGINT UNSIGNED COMMENT '用户ID',
    ip VARCHAR(45) NOT NULL COMMENT 'IP地址',
    user_agent TEXT COMMENT '用户代理',
    success TINYINT(1) NOT NULL COMMENT '是否成功',
    failure_reason VARCHAR(100) COMMENT '失败原因',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
    
    INDEX idx_username (username),
    INDEX idx_user_id (user_id),
    INDEX idx_ip (ip),
    INDEX idx_success (success),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='登录日志表';

-- 系统配置表
CREATE TABLE system_configs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE COMMENT '配置键',
    config_value TEXT COMMENT '配置值',
    config_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string' COMMENT '配置类型',
    description VARCHAR(200) COMMENT '配置描述',
    is_encrypted TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否加密存储',
    created_by BIGINT UNSIGNED COMMENT '创建者ID',
    updated_by BIGINT UNSIGNED COMMENT '更新者ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX idx_config_key (config_key),
    
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='系统配置表';

-- 数据备份记录表
CREATE TABLE backup_records (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    backup_type ENUM('full', 'incremental') NOT NULL COMMENT '备份类型',
    backup_file VARCHAR(255) NOT NULL COMMENT '备份文件路径',
    file_size BIGINT UNSIGNED COMMENT '文件大小（字节）',
    backup_status ENUM('running', 'success', 'failed') NOT NULL DEFAULT 'running' COMMENT '备份状态',
    error_message TEXT COMMENT '错误信息',
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
    end_time TIMESTAMP NULL COMMENT '结束时间',
    created_by BIGINT UNSIGNED COMMENT '创建者ID',
    
    INDEX idx_backup_type (backup_type),
    INDEX idx_backup_status (backup_status),
    INDEX idx_start_time (start_time),
    
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='数据备份记录表';

-- 异常告警记录表
CREATE TABLE alert_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alert_type ENUM('security', 'system', 'business') NOT NULL COMMENT '告警类型',
    alert_level ENUM('low', 'medium', 'high', 'critical') NOT NULL COMMENT '告警级别',
    title VARCHAR(200) NOT NULL COMMENT '告警标题',
    message TEXT NOT NULL COMMENT '告警消息',
    source VARCHAR(100) COMMENT '告警来源',
    context JSON COMMENT '上下文信息',
    status ENUM('new', 'acknowledged', 'resolved') DEFAULT 'new' COMMENT '处理状态',
    acknowledged_by BIGINT UNSIGNED COMMENT '确认人ID',
    acknowledged_at TIMESTAMP NULL COMMENT '确认时间',
    resolved_by BIGINT UNSIGNED COMMENT '解决人ID',
    resolved_at TIMESTAMP NULL COMMENT '解决时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX idx_alert_type (alert_type),
    INDEX idx_alert_level (alert_level),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (acknowledged_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='异常告警记录表';

-- 角色权限映射表
CREATE TABLE role_permissions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role ENUM('admin', 'manager', 'operator', 'viewer') NOT NULL COMMENT '角色',
    permission VARCHAR(100) NOT NULL COMMENT '权限',
    description VARCHAR(200) COMMENT '权限描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    UNIQUE KEY uk_role_permission (role, permission),
    INDEX idx_role (role),
    INDEX idx_permission (permission)
) ENGINE=InnoDB COMMENT='角色权限映射表';

-- API限流记录表
CREATE TABLE rate_limits (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL COMMENT 'IP地址',
    endpoint VARCHAR(255) NOT NULL COMMENT 'API端点',
    request_count INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '请求次数',
    window_start TIMESTAMP NOT NULL COMMENT '时间窗口开始',
    window_end TIMESTAMP NOT NULL COMMENT '时间窗口结束',
    is_blocked TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否被阻止',
    block_until TIMESTAMP NULL COMMENT '阻止到期时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    UNIQUE KEY uk_ip_endpoint_window (ip_address, endpoint, window_start),
    INDEX idx_ip_address (ip_address),
    INDEX idx_endpoint (endpoint),
    INDEX idx_window_end (window_end),
    INDEX idx_is_blocked (is_blocked),
    INDEX idx_block_until (block_until)
) ENGINE=InnoDB COMMENT='API限流记录表';

-- API限流记录表（简化版，用于快速查询）
CREATE TABLE api_rate_limits (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL COMMENT 'IP地址',
    endpoint VARCHAR(255) NOT NULL COMMENT 'API端点',
    method VARCHAR(10) NOT NULL COMMENT 'HTTP方法',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX idx_ip_address (ip_address),
    INDEX idx_endpoint (endpoint),
    INDEX idx_created_at (created_at),
    INDEX idx_ip_created (ip_address, created_at)
) ENGINE=InnoDB COMMENT='API限流记录表（简化版）';

-- 限流违规记录表
CREATE TABLE rate_limit_violations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL COMMENT 'IP地址',
    endpoint VARCHAR(255) NOT NULL COMMENT 'API端点',
    method VARCHAR(10) NOT NULL COMMENT 'HTTP方法',
    current_count INT UNSIGNED NOT NULL COMMENT '当前请求次数',
    limit_count INT UNSIGNED NOT NULL COMMENT '限制次数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX idx_ip_address (ip_address),
    INDEX idx_endpoint (endpoint),
    INDEX idx_created_at (created_at),
    INDEX idx_ip_created (ip_address, created_at)
) ENGINE=InnoDB COMMENT='限流违规记录表';

-- IP阻止记录表
CREATE TABLE ip_blocks (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL UNIQUE COMMENT 'IP地址',
    block_reason VARCHAR(200) COMMENT '阻止原因',
    block_until TIMESTAMP NOT NULL COMMENT '阻止到期时间',
    violation_count INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '违规次数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX idx_ip_address (ip_address),
    INDEX idx_block_until (block_until),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB COMMENT='IP阻止记录表';
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role VARCHAR(20) NOT NULL COMMENT '角色',
    permission VARCHAR(50) NOT NULL COMMENT '权限',
    description VARCHAR(200) COMMENT '权限描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    UNIQUE KEY uk_role_permission (role, permission),
    INDEX idx_role (role),
    INDEX idx_permission (permission)
) ENGINE=InnoDB COMMENT='角色权限映射表';

-- 插入默认角色权限
INSERT INTO role_permissions (role, permission, description) VALUES
-- 管理员权限
('admin', 'card_create', '创建卡片'),
('admin', 'card_read', '查看卡片'),
('admin', 'card_update', '更新卡片'),
('admin', 'card_delete', '删除卡片'),
('admin', 'user_manage', '用户管理'),
('admin', 'system_config', '系统配置'),
('admin', 'log_view', '查看日志'),
('admin', 'export_data', '导出数据'),
('admin', 'backup_manage', '备份管理'),

-- 业务管理员权限
('manager', 'card_create', '创建卡片'),
('manager', 'card_read', '查看卡片'),
('manager', 'card_update', '更新卡片'),
('manager', 'log_view', '查看日志'),
('manager', 'export_data', '导出数据'),

-- 操作员权限
('operator', 'card_create', '创建卡片'),
('operator', 'card_read', '查看卡片'),
('operator', 'card_update', '更新卡片'),

-- 只读用户权限
('viewer', 'card_read', '查看卡片');

-- 插入默认系统配置
INSERT INTO system_configs (config_key, config_value, config_type, description, is_encrypted) VALUES
('system_name', '商业级发卡系统', 'string', '系统名称', 0),
('max_login_attempts', '5', 'number', '最大登录尝试次数', 0),
('login_lockout_time', '30', 'number', '登录锁定时间（分钟）', 0),
('session_timeout', '30', 'number', '会话超时时间（分钟）', 0),
('password_min_length', '8', 'number', '密码最小长度', 0),
('require_two_factor', 'true', 'boolean', '是否启用二次验证', 0),
('backup_retention_days', '30', 'number', '备份保留天数', 0),
('encryption_key_rotation_days', '90', 'number', '加密密钥轮换天数', 1);

-- 创建默认管理员账户（密码：Admin123456）
INSERT INTO users (username, password, email, real_name, role, status) VALUES
('admin', '$argon2id$v=19$m=65536,t=4,p=3$c2FsdHNhbHRzYWx0c2FsdHNhbHQ$RGNhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5eg', 'admin@example.com', '系统管理员', 'admin', 'active');

-- 创建触发器：记录卡片状态变更
DELIMITER //
CREATE TRIGGER tr_card_status_update 
AFTER UPDATE ON cards
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO card_status_history (card_id, old_status, new_status, operator_id, operator_ip)
        VALUES (NEW.id, OLD.status, NEW.status, NEW.updated_by, '127.0.0.1');
    END IF;
END//
DELIMITER ;

-- 创建存储过程：批量插入卡片
DELIMITER //
CREATE PROCEDURE sp_batch_insert_cards(
    IN p_card_data JSON,
    IN p_created_by BIGINT UNSIGNED
)
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE card_count INT;
    DECLARE card_number VARCHAR(16);
    DECLARE card_holder VARCHAR(100);
    DECLARE card_type VARCHAR(20);
    DECLARE bank_name VARCHAR(100);
    
    SET card_count = JSON_LENGTH(p_card_data);
    
    WHILE i < card_count DO
        SET card_number = JSON_UNQUOTE(JSON_EXTRACT(p_card_data, CONCAT('$[', i, '].card_number')));
        SET card_holder = JSON_UNQUOTE(JSON_EXTRACT(p_card_data, CONCAT('$[', i, '].card_holder')));
        SET card_type = JSON_UNQUOTE(JSON_EXTRACT(p_card_data, CONCAT('$[', i, '].card_type')));
        SET bank_name = JSON_UNQUOTE(JSON_EXTRACT(p_card_data, CONCAT('$[', i, '].bank_name')));
        
        -- 这里应该调用加密函数，简化处理
        INSERT INTO cards (
            card_number_encrypted, 
            card_number_hash, 
            card_holder_encrypted,
            card_type,
            bank_name,
            created_by
        ) VALUES (
            card_number,  -- 实际应该加密
            SHA2(card_number, 256),
            card_holder,  -- 实际应该加密
            card_type,
            bank_name,
            p_created_by
        );
        
        SET i = i + 1;
    END WHILE;
END//
DELIMITER ;

-- 创建视图：卡片统计视图
CREATE VIEW v_card_statistics AS
SELECT 
    COUNT(*) as total_cards,
    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_cards,
    COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive_cards,
    COUNT(CASE WHEN status = 'frozen' THEN 1 END) as frozen_cards,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_cards,
    COUNT(CASE WHEN status = 'expired' THEN 1 END) as expired_cards,
    COUNT(CASE WHEN activation_status = 'activated' THEN 1 END) as activated_cards,
    COUNT(CASE WHEN activation_status = 'unactivated' THEN 1 END) as unactivated_cards,
    COUNT(CASE WHEN expire_date < CURDATE() THEN 1 END) as expired_cards_count,
    COUNT(CASE WHEN expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 END) as expiring_soon_cards
FROM cards;

-- 创建视图：用户活动统计视图
CREATE VIEW v_user_activity AS
SELECT 
    u.id,
    u.username,
    u.role,
    COUNT(DISTINCT DATE(l.created_at)) as active_days,
    COUNT(l.id) as total_operations,
    COUNT(CASE WHEN l.action LIKE '%login%' THEN 1 END) as login_count,
    COUNT(CASE WHEN l.action LIKE '%card%' THEN 1 END) as card_operations,
    MAX(l.created_at) as last_activity
FROM users u
LEFT JOIN user_logs l ON u.id = l.user_id
GROUP BY u.id, u.username, u.role;

-- 数据访问授权表
CREATE TABLE IF NOT EXISTS `data_access_authorizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `data_type` varchar(50) NOT NULL COMMENT '数据类型',
  `action` varchar(20) NOT NULL COMMENT '操作类型(read/write/delete)',
  `reason` text COMMENT '授权原因',
  `context` text COMMENT '上下文信息(JSON)',
  `ip_address` varchar(45) COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_data_type` (`data_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='数据访问授权记录表';

-- 数据归档表
CREATE TABLE IF NOT EXISTS `archived_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_id` int(11) NOT NULL COMMENT '原卡片ID',
  `card_data` longtext NOT NULL COMMENT '卡片数据(JSON)',
  `archived_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '归档时间',
  `archived_reason` varchar(100) DEFAULT NULL COMMENT '归档原因',
  `retention_expiry` timestamp NULL DEFAULT NULL COMMENT '留存到期时间',
  PRIMARY KEY (`id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_archived_at` (`archived_at`),
  KEY `idx_retention_expiry` (`retention_expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='归档卡片数据表';

-- 用户权限配置表
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `permissions` text NOT NULL COMMENT '权限配置(JSON)',
  `granted_by` int(11) NOT NULL COMMENT '授权人ID',
  `granted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间',
  `expires_at` timestamp NULL DEFAULT NULL COMMENT '权限过期时间',
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否激活',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`),
  KEY `idx_granted_by` (`granted_by`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户权限配置表';

-- 合规报告表
CREATE TABLE IF NOT EXISTS `compliance_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_type` varchar(50) NOT NULL COMMENT '报告类型',
  `report_period_start` date NOT NULL COMMENT '报告期间开始',
  `report_period_end` date NOT NULL COMMENT '报告期间结束',
  `report_data` longtext NOT NULL COMMENT '报告数据(JSON)',
  `generated_by` int(11) NOT NULL COMMENT '生成人ID',
  `generated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '生成时间',
  `file_path` varchar(255) DEFAULT NULL COMMENT '报告文件路径',
  `file_format` varchar(10) DEFAULT NULL COMMENT '文件格式',
  PRIMARY KEY (`id`),
  KEY `idx_report_type` (`report_type`),
  KEY `idx_report_period` (`report_period_start`, `report_period_end`),
  KEY `idx_generated_by` (`generated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='合规报告表';

-- 数据留存策略表
CREATE TABLE IF NOT EXISTS `data_retention_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_type` varchar(50) NOT NULL COMMENT '数据类型',
  `retention_days` int(11) NOT NULL COMMENT '留存天数',
  `retention_action` enum('delete','archive') NOT NULL DEFAULT 'archive' COMMENT '到期操作',
  `description` text COMMENT '策略描述',
  `created_by` int(11) NOT NULL COMMENT '创建人ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` int(11) DEFAULT NULL COMMENT '更新人ID',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否激活',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_data_type` (`data_type`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='数据留存策略表';

-- 插入默认数据留存策略
INSERT IGNORE INTO `data_retention_policies` 
(`data_type`, `retention_days`, `retention_action`, `description`, `created_by`) VALUES
('card_data', 3650, 'archive', '卡片数据留存10年，到期后归档', 1),
('user_data', 2555, 'archive', '用户数据留存7年，到期后归档', 1),
('transaction_data', 1825, 'archive', '交易数据留存5年，到期后归档', 1),
('audit_logs', 1095, 'delete', '审计日志留存3年，到期后删除', 1),
('access_logs', 730, 'delete', '访问日志留存2年，到期后删除', 1),
('temporary_data', 30, 'delete', '临时数据留存30天，到期后删除', 1);

-- 为现有用户添加默认权限配置
INSERT IGNORE INTO `user_permissions` 
(`user_id`, `permissions`, `granted_by`) 
SELECT 
    u.id,
    CASE 
        WHEN u.role = 'admin' THEN '{"card_data_read":true,"card_data_write":true,"card_data_delete":true,"user_data_read":true,"user_data_write":true,"user_data_delete":true,"audit_logs_read":true,"security_logs_read":true}'
        WHEN u.role = 'business_admin' THEN '{"card_data_read":true,"card_data_write":true,"card_data_delete":false,"user_data_read":true,"user_data_write":false,"user_data_delete":false,"audit_logs_read":true,"security_logs_read":false}'
        WHEN u.role = 'operator' THEN '{"card_data_read":true,"card_data_write":true,"card_data_delete":false,"user_data_read":true,"user_data_write":false,"user_data_delete":false,"audit_logs_read":false,"security_logs_read":false}'
        WHEN u.role = 'readonly' THEN '{"card_data_read":true,"card_data_write":false,"card_data_delete":false,"user_data_read":true,"user_data_write":false,"user_data_delete":false,"audit_logs_read":false,"security_logs_read":false}'
        ELSE '{}'
    END,
    1
FROM users u;

-- 创建数据访问授权检查存储过程
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `CheckDataAccessPermission`(
    IN p_user_id INT,
    IN p_data_type VARCHAR(50),
    IN p_action VARCHAR(20)
)
BEGIN
    DECLARE v_role VARCHAR(50);
    DECLARE v_has_permission BOOLEAN DEFAULT FALSE;
    DECLARE v_permission_json TEXT;
    
    -- 获取用户角色
    SELECT role INTO v_role FROM users WHERE id = p_user_id AND status = 'active';
    
    -- 管理员拥有所有权限
    IF v_role = 'admin' THEN
        SELECT TRUE AS has_permission;
    ELSE
        -- 获取用户权限配置
        SELECT permissions INTO v_permission_json 
        FROM user_permissions 
        WHERE user_id = p_user_id AND is_active = 1 
        AND (expires_at IS NULL OR expires_at > NOW());
        
        -- 检查特定权限
        IF v_permission_json IS NOT NULL THEN
            SELECT JSON_UNQUOTE(JSON_EXTRACT(v_permission_json, CONCAT('$.', p_data_type, '_', p_action))) = 'true' 
            INTO v_has_permission;
        END IF;
        
        SELECT v_has_permission AS has_permission;
    END IF;
END //
DELIMITER ;

-- 创建数据清理存储过程
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `CleanupExpiredData`(
    IN p_data_type VARCHAR(50) DEFAULT NULL
)
BEGIN
    DECLARE v_retention_days INT;
    DECLARE v_expiry_date DATETIME;
    DECLARE v_cleaned_count INT DEFAULT 0;
    
    -- 如果指定了数据类型，获取对应的留存天数
    IF p_data_type IS NOT NULL THEN
        SELECT retention_days INTO v_retention_days
        FROM data_retention_policies
        WHERE data_type = p_data_type AND is_active = 1;
        
        IF v_retention_days IS NOT NULL THEN
            SET v_expiry_date = DATE_SUB(NOW(), INTERVAL v_retention_days DAY);
            
            -- 根据数据类型执行清理
            CASE p_data_type
                WHEN 'card_data' THEN
                    -- 归档过期的卡片数据
                    INSERT INTO archived_cards (card_id, card_data, archived_at, archived_reason, retention_expiry)
                    SELECT id, JSON_OBJECT(*), NOW(), 'retention_expired', DATE_ADD(NOW(), INTERVAL 10 YEAR)
                    FROM cards
                    WHERE created_at < v_expiry_date AND status IN ('closed', 'expired');
                    
                    -- 删除已归档的记录
                    DELETE FROM cards 
                    WHERE id IN (SELECT card_id FROM archived_cards WHERE archived_reason = 'retention_expired');
                    
                    SET v_cleaned_count = ROW_COUNT();
                    
                WHEN 'user_logs' THEN
                    DELETE FROM user_logs WHERE created_at < v_expiry_date;
                    SET v_cleaned_count = ROW_COUNT();
                    
                WHEN 'security_logs' THEN
                    DELETE FROM security_logs WHERE created_at < v_expiry_date;
                    SET v_cleaned_count = ROW_COUNT();
                    
                WHEN 'data_access_authorizations' THEN
                    DELETE FROM data_access_authorizations WHERE created_at < v_expiry_date;
                    SET v_cleaned_count = ROW_COUNT();
            END CASE;
        END IF;
    ELSE
        -- 清理所有类型的过期数据
        CALL CleanupExpiredData('card_data');
        CALL CleanupExpiredData('user_logs');
        CALL CleanupExpiredData('security_logs');
        CALL CleanupExpiredData('data_access_authorizations');
    END IF;
    
    SELECT v_cleaned_count AS cleaned_count;
END //
DELIMITER ;

-- 创建合规报告生成视图
CREATE OR REPLACE VIEW `compliance_summary_view` AS
SELECT 
    'data_access' as metric_type,
    COUNT(*) as total_count,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT data_type) as data_types,
    DATE_FORMAT(created_at, '%Y-%m') as month
FROM data_access_authorizations
GROUP BY DATE_FORMAT(created_at, '%Y-%m')

UNION ALL

SELECT 
    'security_incidents' as metric_type,
    COUNT(*) as total_count,
    0 as unique_users,
    0 as data_types,
    DATE_FORMAT(created_at, '%Y-%m') as month
FROM security_logs
WHERE level IN ('WARNING', 'ERROR', 'CRITICAL')
GROUP BY DATE_FORMAT(created_at, '%Y-%m')

UNION ALL

SELECT 
    'card_operations' as metric_type,
    COUNT(*) as total_count,
    COUNT(DISTINCT user_id) as unique_users,
    0 as data_types,
    DATE_FORMAT(created_at, '%Y-%m') as month
FROM card_status_changes
GROUP BY DATE_FORMAT(created_at, '%Y-%m');

-- 身份核验相关表结构

-- 身份核验表
CREATE TABLE IF NOT EXISTS identity_verifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    verification_id VARCHAR(50) UNIQUE NOT NULL COMMENT '核验申请ID',
    user_id INT NOT NULL COMMENT '申请人ID',
    card_id INT NOT NULL COMMENT '关联卡片ID',
    verification_type ENUM('standard', 'enhanced', 'premium') DEFAULT 'standard' COMMENT '核验类型',
    id_number_encrypted TEXT NOT NULL COMMENT '加密的身份证号码',
    id_front_image_encrypted TEXT COMMENT '加密的身份证正面照片路径',
    id_back_image_encrypted TEXT COMMENT '加密的身份证背面照片路径',
    selfie_image_encrypted TEXT COMMENT '加密的本人照片路径',
    phone_number_encrypted TEXT COMMENT '加密的手机号码',
    email_encrypted TEXT COMMENT '加密的电子邮箱',
    address_encrypted TEXT COMMENT '加密的联系地址',
    status ENUM('pending', 'in_review', 'approved', 'rejected', 'need_info') DEFAULT 'pending' COMMENT '核验状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_verification_id (verification_id),
    INDEX idx_user_id (user_id),
    INDEX idx_card_id (card_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (card_id) REFERENCES cards(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='身份核验表';

-- 核验审核表
CREATE TABLE IF NOT EXISTS verification_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    verification_id VARCHAR(50) NOT NULL COMMENT '核验申请ID',
    review_level TINYINT NOT NULL COMMENT '审核级别(1-3)',
    reviewer_id INT NOT NULL COMMENT '审核人ID',
    review_result ENUM('approved', 'rejected', 'need_info') NOT NULL COMMENT '审核结果',
    review_comment TEXT COMMENT '审核意见',
    review_data JSON COMMENT '审核数据',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '审核时间',
    INDEX idx_verification_id (verification_id),
    INDEX idx_reviewer_id (reviewer_id),
    INDEX idx_review_level (review_level),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (verification_id) REFERENCES identity_verifications(verification_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='核验审核表';

-- 卡片激活表
CREATE TABLE IF NOT EXISTS card_activations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_id INT NOT NULL COMMENT '卡片ID',
    activation_code VARCHAR(50) UNIQUE NOT NULL COMMENT '激活码',
    activation_method ENUM('online', 'offline', 'phone') DEFAULT 'online' COMMENT '激活方式',
    activation_data JSON COMMENT '激活数据',
    status ENUM('pending', 'active', 'suspended', 'blocked') DEFAULT 'active' COMMENT '激活状态',
    activated_by INT COMMENT '激活操作人ID',
    activated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '激活时间',
    expires_at TIMESTAMP NULL COMMENT '过期时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_card_id (card_id),
    INDEX idx_activation_code (activation_code),
    INDEX idx_status (status),
    INDEX idx_activated_by (activated_by),
    INDEX idx_activated_at (activated_at),
    FOREIGN KEY (card_id) REFERENCES cards(id) ON DELETE CASCADE,
    FOREIGN KEY (activated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡片激活表';

-- 核验配置表
CREATE TABLE IF NOT EXISTS verification_configs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    verification_type ENUM('standard', 'enhanced', 'premium') NOT NULL COMMENT '核验类型',
    required_documents JSON NOT NULL COMMENT '必需文档列表',
    review_levels TINYINT NOT NULL DEFAULT 1 COMMENT '审核级别数',
    auto_approve_rules JSON COMMENT '自动批准规则',
    risk_threshold DECIMAL(3,2) DEFAULT 0.50 COMMENT '风险阈值',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    UNIQUE KEY uk_verification_type (verification_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='核验配置表';

-- 风险评估表
CREATE TABLE IF NOT EXISTS risk_assessments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    verification_id VARCHAR(50) NOT NULL COMMENT '核验申请ID',
    risk_score DECIMAL(5,2) NOT NULL COMMENT '风险评分',
    risk_level ENUM('low', 'medium', 'high', 'critical') NOT NULL COMMENT '风险等级',
    risk_factors JSON NOT NULL COMMENT '风险因素',
    assessment_result TEXT COMMENT '评估结果',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '评估时间',
    INDEX idx_verification_id (verification_id),
    INDEX idx_risk_level (risk_level),
    INDEX idx_risk_score (risk_score),
    FOREIGN KEY (verification_id) REFERENCES identity_verifications(verification_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='风险评估表';

-- 插入默认核验配置
INSERT INTO verification_configs (verification_type, required_documents, review_levels, auto_approve_rules, risk_threshold) VALUES
('standard', '["id_front", "id_back", "selfie"]', 1, '{"min_score": 80, "auto_approve": true}', 0.70),
('enhanced', '["id_front", "id_back", "selfie", "address_proof"]', 2, '{"min_score": 85, "auto_approve": false}', 0.50),
('premium', '["id_front", "id_back", "selfie", "address_proof", "income_proof"]', 3, '{"min_score": 90, "auto_approve": false}', 0.30);

-- 创建核验统计视图
CREATE OR REPLACE VIEW verification_stats_view AS
SELECT 
    DATE(iv.created_at) as date,
    iv.verification_type,
    iv.status,
    COUNT(*) as count,
    AVG(CASE WHEN ra.risk_score IS NOT NULL THEN ra.risk_score ELSE 0 END) as avg_risk_score
FROM identity_verifications iv
LEFT JOIN risk_assessments ra ON iv.verification_id = ra.verification_id
GROUP BY DATE(iv.created_at), iv.verification_type, iv.status
ORDER BY date DESC;

-- 创建激活统计视图
CREATE OR REPLACE VIEW activation_stats_view AS
SELECT 
    DATE(ca.activated_at) as date,
    ca.activation_method,
    ca.status,
    COUNT(*) as count
FROM card_activations ca
GROUP BY DATE(ca.activated_at), ca.activation_method, ca.status
ORDER BY date DESC;

-- 创建核验效率统计存储过程
DELIMITER //
CREATE PROCEDURE GetVerificationEfficiencyStats(IN start_date DATE, IN end_date DATE)
BEGIN
    SELECT 
        iv.verification_type,
        COUNT(*) as total_applications,
        SUM(CASE WHEN iv.status = 'approved' THEN 1 ELSE 0 END) as approved_count,
        SUM(CASE WHEN iv.status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
        AVG(DATEDIFF(
            (SELECT MAX(created_at) FROM verification_reviews vr WHERE vr.verification_id = iv.verification_id),
            iv.created_at
        )) as avg_review_days,
        AVG(CASE WHEN ra.risk_score IS NOT NULL THEN ra.risk_score ELSE 0 END) as avg_risk_score
    FROM identity_verifications iv
    LEFT JOIN risk_assessments ra ON iv.verification_id = ra.verification_id
    WHERE DATE(iv.created_at) BETWEEN start_date AND end_date
    GROUP BY iv.verification_type
    ORDER BY total_applications DESC;
END //
DELIMITER ;

-- 创建自动风险评估存储过程
DELIMITER //
CREATE PROCEDURE AutoRiskAssessment(IN verification_id VARCHAR(50))
BEGIN
    DECLARE risk_score DECIMAL(5,2) DEFAULT 0.0;
    DECLARE risk_level VARCHAR(20) DEFAULT 'low';
    
    -- 基于历史数据计算风险评分
    SELECT 
        CASE 
            WHEN COUNT(*) = 0 THEN 50.0
            ELSE (100.0 - (COUNT(*) * 5.0))
        END INTO risk_score
    FROM identity_verifications 
    WHERE user_id = (SELECT user_id FROM identity_verifications WHERE verification_id = verification_id)
    AND status = 'rejected';
    
    -- 确定风险等级
    CASE 
        WHEN risk_score >= 80 THEN SET risk_level = 'low';
        WHEN risk_score >= 60 THEN SET risk_level = 'medium';
        WHEN risk_score >= 40 THEN SET risk_level = 'high';
        ELSE SET risk_level = 'critical';
    END CASE;
    
    -- 插入风险评估记录
    INSERT INTO risk_assessments (verification_id, risk_score, risk_level, risk_factors, assessment_result)
    VALUES (
        verification_id,
        risk_score,
        risk_level,
        JSON_OBJECT('historical_rejections', risk_score < 80, 'document_completeness', 0.9),
        CONCAT('自动风险评估完成，风险评分：', risk_score, '，风险等级：', risk_level)
    );
END //
DELIMITER ;

-- 创建核验申请触发器
DELIMITER //
CREATE TRIGGER after_verification_insert
AFTER INSERT ON identity_verifications
FOR EACH ROW
BEGIN
    -- 自动执行风险评估
    CALL AutoRiskAssessment(NEW.verification_id);
    
    -- 记录安全日志
    INSERT INTO security_logs (user_id, action, description, ip_address, user_agent, created_at)
    VALUES (
        NEW.user_id,
        'identity_verification_created',
        CONCAT('创建身份核验申请：', NEW.verification_id),
        '',
        '',
        NOW()
    );
END //
DELIMITER ;

-- 创建审核完成触发器
DELIMITER //
CREATE TRIGGER after_review_insert
AFTER INSERT ON verification_reviews
FOR EACH ROW
BEGIN
    -- 更新核验状态
    UPDATE identity_verifications 
    SET status = CASE 
        WHEN NEW.review_result = 'rejected' THEN 'rejected'
        WHEN NEW.review_result = 'need_info' THEN 'need_info'
        WHEN NEW.review_level >= 3 THEN 'approved'
        ELSE 'in_review'
    END,
    updated_at = NOW()
    WHERE verification_id = NEW.verification_id;
    
    -- 记录安全日志
    INSERT INTO security_logs (user_id, action, description, ip_address, user_agent, created_at)
    VALUES (
        NEW.reviewer_id,
        'verification_review_completed',
        CONCAT('完成核验审核：', NEW.verification_id, '，结果：', NEW.review_result),
        '',
        '',
        NOW()
    );
END //
DELIMITER ;

-- 创建卡片激活触发器
DELIMITER //
CREATE TRIGGER after_activation_insert
AFTER INSERT ON card_activations
FOR EACH ROW
BEGIN
    -- 更新卡片状态
    UPDATE cards 
    SET status = 'active',
        updated_at = NOW()
    WHERE id = NEW.card_id;
    
    -- 记录安全日志
    INSERT INTO security_logs (user_id, action, description, ip_address, user_agent, created_at)
    VALUES (
        NEW.activated_by,
        'card_activated',
        CONCAT('卡片激活成功：', NEW.activation_code),
        '',
        '',
        NOW()
    );
END //
DELIMITER ;