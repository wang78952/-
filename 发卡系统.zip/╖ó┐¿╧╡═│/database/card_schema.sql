-- 卡密生命周期管理相关数据库表结构

-- 卡密批次表
CREATE TABLE IF NOT EXISTS `card_batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '批次ID',
  `batch_no` varchar(50) NOT NULL COMMENT '批次号',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `quantity` int(11) NOT NULL COMMENT '生成数量',
  `generated_count` int(11) DEFAULT 0 COMMENT '已生成数量',
  `valid_days` int(11) DEFAULT 365 COMMENT '有效期天数',
  `status` varchar(20) NOT NULL DEFAULT 'processing' COMMENT '状态：processing/completed/failed/cancelled',
  `prefix` varchar(10) DEFAULT NULL COMMENT '卡密前缀',
  `description` varchar(255) DEFAULT NULL COMMENT '批次描述',
  `operator_id` int(11) DEFAULT NULL COMMENT '操作员ID',
  `operator_name` varchar(50) DEFAULT NULL COMMENT '操作员姓名',
  `generated_at` datetime DEFAULT NULL COMMENT '生成完成时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_batch_no` (`batch_no`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_card_batches_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密批次表';

-- 卡密表
CREATE TABLE IF NOT EXISTS `cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '卡密ID',
  `batch_id` int(11) NOT NULL COMMENT '批次ID',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `card_code` varchar(50) NOT NULL COMMENT '卡密编码',
  `card_secret` text NOT NULL COMMENT '卡密密码(加密存储)',
  `status` varchar(20) NOT NULL DEFAULT 'active' COMMENT '状态：active/used/expired/cancelled',
  `expires_at` datetime DEFAULT NULL COMMENT '过期时间',
  `used_at` datetime DEFAULT NULL COMMENT '使用时间',
  `used_ip` varchar(45) DEFAULT NULL COMMENT '使用IP',
  `used_user_agent` varchar(500) DEFAULT NULL COMMENT '使用用户代理',
  `usage_data` text COMMENT '使用数据(JSON)',
  `order_id` int(11) DEFAULT NULL COMMENT '关联订单ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_card_code` (`card_code`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_used_at` (`used_at`),
  KEY `idx_order_id` (`order_id`),
  CONSTRAINT `fk_cards_batch` FOREIGN KEY (`batch_id`) REFERENCES `card_batches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cards_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cards_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密表';

-- 卡密使用日志表
CREATE TABLE IF NOT EXISTS `card_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `card_id` int(11) NOT NULL COMMENT '卡密ID',
  `action` varchar(50) NOT NULL COMMENT '操作类型：redeem/verify/expire/cancel',
  `result` varchar(20) NOT NULL COMMENT '结果：success/failed/pending',
  `message` varchar(255) DEFAULT NULL COMMENT '消息',
  `usage_data` text COMMENT '使用数据(JSON)',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` varchar(500) DEFAULT NULL COMMENT '用户代理',
  `session_id` varchar(100) DEFAULT NULL COMMENT '会话ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_action` (`action`),
  KEY `idx_result` (`result`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_card_usage_logs_card` FOREIGN KEY (`card_id`) REFERENCES `cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密使用日志表';

-- 卡密异常记录表
CREATE TABLE IF NOT EXISTS `card_anomalies` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '异常ID',
  `card_id` int(11) DEFAULT NULL COMMENT '卡密ID',
  `batch_id` int(11) DEFAULT NULL COMMENT '批次ID',
  `anomaly_type` varchar(50) NOT NULL COMMENT '异常类型：duplicate/abnormal_usage/expiring_soon/security_risk',
  `severity` varchar(20) NOT NULL DEFAULT 'medium' COMMENT '严重程度：low/medium/high/critical',
  `description` varchar(500) NOT NULL COMMENT '异常描述',
  `anomaly_data` text COMMENT '异常数据(JSON)',
  `status` varchar(20) NOT NULL DEFAULT 'open' COMMENT '状态：open/investigating/resolved/ignored',
  `resolved_at` datetime DEFAULT NULL COMMENT '解决时间',
  `resolution_note` varchar(255) DEFAULT NULL COMMENT '解决备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_anomaly_type` (`anomaly_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_card_anomalies_card` FOREIGN KEY (`card_id`) REFERENCES `cards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_card_anomalies_batch` FOREIGN KEY (`batch_id`) REFERENCES `card_batches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密异常记录表';

-- 卡密统计表
CREATE TABLE IF NOT EXISTS `card_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '统计ID',
  `date` date NOT NULL COMMENT '统计日期',
  `product_id` int(11) DEFAULT NULL COMMENT '产品ID',
  `generated_count` int(11) DEFAULT 0 COMMENT '生成数量',
  `used_count` int(11) DEFAULT 0 COMMENT '使用数量',
  `expired_count` int(11) DEFAULT 0 COMMENT '过期数量',
  `cancelled_count` int(11) DEFAULT 0 COMMENT '取消数量',
  `active_count` int(11) DEFAULT 0 COMMENT '活跃数量',
  `revenue` decimal(10,2) DEFAULT 0.00 COMMENT '收入',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_date_product` (`date`, `product_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密统计表';

-- 卡密配置表
CREATE TABLE IF NOT EXISTS `card_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `config_type` varchar(20) DEFAULT 'string' COMMENT '配置类型：string/number/boolean/json',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_active` tinyint(1) DEFAULT 1 COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密配置表';

-- 插入默认配置
INSERT INTO `card_configs` (`config_key`, `config_value`, `config_type`, `description`) VALUES
('secret_length', '16', 'number', '卡密密码长度'),
('checksum_salt', 'card_system_salt_2024', 'string', '校验码盐值'),
('max_generation_batch', '10000', 'number', '单次最大生成数量'),
('default_valid_days', '365', 'number', '默认有效期天数'),
('auto_expire_check', 'true', 'boolean', '自动检查过期卡密'),
('expire_check_interval', '3600', 'number', '过期检查间隔(秒)'),
('anomaly_detection', 'true', 'boolean', '启用异常检测'),
('max_usage_per_ip_hour', '100', 'number', '单IP每小时最大使用次数'),
('expire_warning_days', '7', 'number', '过期预警天数'),
('card_code_format', 'timestamp-random-checksum', 'string', '卡密编码格式');

-- 创建触发器：更新产品统计
DELIMITER //
CREATE TRIGGER tr_card_used_stats 
AFTER UPDATE ON cards
FOR EACH ROW
BEGIN
    IF OLD.status != 'used' AND NEW.status = 'used' THEN
        INSERT INTO card_statistics (date, product_id, used_count)
        VALUES (CURDATE(), NEW.product_id, 1)
        ON DUPLICATE KEY UPDATE 
        used_count = used_count + 1;
    END IF;
    
    IF OLD.status != 'expired' AND NEW.status = 'expired' THEN
        INSERT INTO card_statistics (date, product_id, expired_count)
        VALUES (CURDATE(), NEW.product_id, 1)
        ON DUPLICATE KEY UPDATE 
        expired_count = expired_count + 1;
    END IF;
END//
DELIMITER ;

-- 创建触发器：生成时统计
DELIMITER //
CREATE TRIGGER tr_card_generated_stats 
AFTER INSERT ON cards
FOR EACH ROW
BEGIN
    INSERT INTO card_statistics (date, product_id, generated_count)
    VALUES (CURDATE(), NEW.product_id, 1)
    ON DUPLICATE KEY UPDATE 
    generated_count = generated_count + 1;
END//
DELIMITER ;

-- 创建存储过程：批量过期检测
DELIMITER //
CREATE PROCEDURE sp_detect_expired_cards(IN batch_size INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE card_id INT;
    DECLARE card_count INT DEFAULT 0;
    
    DECLARE expired_cursor CURSOR FOR 
        SELECT id FROM cards 
        WHERE status = 'active' 
        AND expires_at < NOW() 
        LIMIT batch_size;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN expired_cursor;
    
    read_loop: LOOP
        FETCH expired_cursor INTO card_id;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        UPDATE cards SET status = 'expired' WHERE id = card_id;
        SET card_count = card_count + 1;
        
        -- 记录过期日志
        INSERT INTO card_usage_logs (card_id, action, result, message)
        VALUES (card_id, 'expire', 'success', 'Card expired automatically');
    END LOOP;
    
    CLOSE expired_cursor;
    
    SELECT card_count as expired_count;
END//
DELIMITER ;

-- 创建存储过程：异常检测
DELIMITER //
CREATE PROCEDURE sp_detect_anomalies()
BEGIN
    DECLARE duplicate_count INT DEFAULT 0;
    DECLARE abnormal_usage_count INT DEFAULT 0;
    DECLARE expiring_soon_count INT DEFAULT 0;
    
    -- 检测重复卡密
    SELECT COUNT(*) INTO duplicate_count
    FROM (
        SELECT card_code, COUNT(*) as cnt
        FROM cards
        GROUP BY card_code
        HAVING cnt > 1
    ) duplicates;
    
    -- 检测异常使用
    SELECT COUNT(*) INTO abnormal_usage_count
    FROM (
        SELECT used_ip, COUNT(*) as cnt
        FROM cards
        WHERE used_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
        GROUP BY used_ip
        HAVING cnt > 100
    ) abnormal;
    
    -- 检测即将过期
    SELECT COUNT(*) INTO expiring_soon_count
    FROM cards
    WHERE status = 'active'
    AND expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY);
    
    -- 插入异常记录
    IF duplicate_count > 0 THEN
        INSERT INTO card_anomalies (anomaly_type, severity, description, anomaly_data)
        VALUES ('duplicate', 'high', CONCAT('发现 ', duplicate_count, ' 个重复卡密'), 
                JSON_OBJECT('duplicate_count', duplicate_count));
    END IF;
    
    IF abnormal_usage_count > 0 THEN
        INSERT INTO card_anomalies (anomaly_type, severity, description, anomaly_data)
        VALUES ('abnormal_usage', 'medium', CONCAT('发现 ', abnormal_usage_count, ' 个异常使用IP'), 
                JSON_OBJECT('abnormal_count', abnormal_usage_count));
    END IF;
    
    IF expiring_soon_count > 0 THEN
        INSERT INTO card_anomalies (anomaly_type, severity, description, anomaly_data)
        VALUES ('expiring_soon', 'low', CONCAT('有 ', expiring_soon_count, ' 个卡密即将过期'), 
                JSON_OBJECT('expiring_count', expiring_soon_count));
    END IF;
    
    SELECT duplicate_count, abnormal_usage_count, expiring_soon_count;
END//
DELIMITER ;

-- 创建视图：卡密状态统计
CREATE VIEW v_card_status_stats AS
SELECT 
    p.id as product_id,
    p.name as product_name,
    COUNT(c.id) as total_count,
    SUM(CASE WHEN c.status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN c.status = 'used' THEN 1 ELSE 0 END) as used_count,
    SUM(CASE WHEN c.status = 'expired' THEN 1 ELSE 0 END) as expired_count,
    SUM(CASE WHEN c.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count,
    SUM(CASE WHEN c.expires_at > NOW() THEN 1 ELSE 0 END) as valid_count,
    ROUND(SUM(CASE WHEN c.status = 'used' THEN 1 ELSE 0 END) / COUNT(c.id) * 100, 2) as usage_rate
FROM products p
LEFT JOIN cards c ON p.id = c.product_id
GROUP BY p.id, p.name;

-- 创建索引优化查询性能
CREATE INDEX idx_cards_status_expires ON cards(status, expires_at);
CREATE INDEX idx_cards_product_status ON cards(product_id, status);
CREATE INDEX idx_card_usage_logs_card_action ON card_usage_logs(card_id, action);
CREATE INDEX idx_card_anomalies_type_status ON card_anomalies(anomaly_type, status);
CREATE INDEX idx_card_statistics_date_product ON card_statistics(date, product_id);