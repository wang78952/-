<?php
/**
 * 基本语法检查脚本
 * 尝试加载关键PHP文件来检查语法错误
 */

echo "开始基本语法检查...\n";
echo "=============================\n";

// 关键PHP文件列表
$keyFiles = [
    'config.php',
    'includes/SecurityManager.php',
    'api/router.php',
    'includes/Database.php',
    'includes/PluginManager.php',
    'includes/ErrorHandler.php'
];

// 检查每个文件
$errors = 0;
$checked = 0;

try {
    foreach ($keyFiles as $file) {
        $fullPath = __DIR__ . '/' . $file;
        echo "检查文件: $file... ";
        
        if (file_exists($fullPath)) {
            // 使用token_get_all来检查语法，而不是直接include
            $tokens = token_get_all(file_get_contents($fullPath));
            echo "✓ 语法看起来正确\n";
            $checked++;
        } else {
            echo "✗ 文件不存在\n";
            $errors++;
        }
    }
    
    echo "\n检查完成!\n";
    echo "成功检查: $checked 个文件\n";
    echo "发现错误: $errors 个问题\n";
    
    if ($errors === 0) {
        echo "\n🎉 语法检查通过! 没有发现明显的语法错误。\n";
    } else {
        echo "\n⚠️  检查完成，但发现一些问题需要处理。\n";
    }
    
} catch (Exception $e) {
    echo "\n✗ 检查过程中发生错误: " . $e->getMessage() . "\n";
    echo "文件: " . $e->getFile() . "\n";
    echo "行号: " . $e->getLine() . "\n";
}

echo "\n注意: 这只是基本检查，无法检测所有类型的错误。推荐在PHP环境中运行完整的语法检查。\n";
?>