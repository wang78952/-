<?php
/**
 * 代理推广数据看板页面
 * 提供代理实时推广数据的可视化展示
 * 包含访问量、转化量、佣金明细等数据统计
 */

// 加载系统初始化文件
require_once __DIR__ . '/../init.php';

// 验证代理身份
$proxyAuth = new Auth\ProxyAuth();

// 代理认证检查
$authResult = $proxyAuth->authenticate();

if (!$authResult['success']) {
    header('Location: /agent/login.php');
    exit;
}

// 获取当前登录代理ID
$currentAgentId = $proxyAuth->getCurrentAgentId();

// 获取代理基本信息
$agentModel = new Models\Agent();
$agentInfo = $agentModel->getAgentById($currentAgentId);

// 页面标题
$pageTitle = '推广数据看板 - 发卡系统';

// 页面样式
$styles = array(
    '/assets/css/bootstrap.min.css',
    '/assets/css/font-awesome.min.css',
    '/assets/css/agent_dashboard.css',
    '/assets/css/analytics_dashboard.css'
);

// 页面脚本
$scripts = array(
    '/assets/js/jquery-3.6.0.min.js',
    '/assets/js/bootstrap.min.js',
    '/assets/js/echarts.min.js',
    '/assets/js/agent_analytics_dashboard.js'
);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    
    <!-- 页面样式 -->
    <?php foreach ($styles as $style) { ?>
    <link rel="stylesheet" href="<?php echo $style; ?>">
    <?php } ?>
    
    <style>
        /* 自定义样式 */
        body {
            font-family: 'Arial', 'Microsoft YaHei', sans-serif;
            background-color: #f5f7fa;
        }
        
        .dashboard-container {
            margin-top: 20px;
            margin-bottom: 40px;
        }
        
        .dashboard-header {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
        }
        
        .dashboard-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        
        .date-range-selector {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .date-range-selector .btn {
            min-width: 80px;
        }
        
        .date-picker-group {
            display: flex;
            gap: 10px;
        }
        
        .date-picker-group input[type="date"] {
            padding: 6px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .summary-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .summary-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px 0 rgba(0,0,0,0.15);
        }
        
        .summary-card-icon {
            font-size: 28px;
            margin-bottom: 10px;
            color: #1890ff;
        }
        
        .summary-card-title {
            font-size: 14px;
            color: #888;
            margin-bottom: 5px;
        }
        
        .summary-card-value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        
        .summary-card-change {
            font-size: 12px;
        }
        
        .change-positive {
            color: #52c41a;
        }
        
        .change-negative {
            color: #ff4d4f;
        }
        
        .chart-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
        }
        
        .chart-section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .chart-section-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        
        .chart-container {
            height: 350px;
            width: 100%;
        }
        
        .chart-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .table-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
        }
        
        .table-section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .table-section-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        
        .table-actions {
            display: flex;
            gap: 10px;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        table th {
            background-color: #fafafa;
            font-weight: bold;
            color: #333;
        }
        
        table tr:hover {
            background-color: #f8f9fa;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-pending {
            background-color: #fff7e6;
            color: #fa8c16;
        }
        
        .badge-settled {
            background-color: #f6ffed;
            color: #52c41a;
        }
        
        .badge-rejected {
            background-color: #fff1f0;
            color: #ff4d4f;
        }
        
        /* 加载动画 */
        .loading-spinner {
            border: 3px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top: 3px solid #1890ff;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .chart-wrapper {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
        
        .chart-wrapper.loading {
            color: #888;
        }
        
        /* 响应式调整 */
        @media (max-width: 768px) {
            .summary-cards {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
            
            .chart-grid,
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .date-range-selector {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .date-picker-group {
                width: 100%;
            }
            
            .date-picker-group input[type="date"] {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <?php include __DIR__ . '/includes/nav.php'; ?>
    
    <!-- 页面内容 -->
    <div class="container dashboard-container">
        <!-- 页面标题 -->
        <div class="dashboard-header">
            <h1 class="dashboard-title">推广数据看板</h1>
            <p>欢迎回来，<?php echo $agentInfo['contact_name']; ?>！以下是您的推广数据概览。</p>
        </div>
        
        <!-- 时间范围选择器 -->
        <div class="date-range-selector">
            <button class="btn btn-primary date-range-btn" data-range="today">今日</button>
            <button class="btn btn-default date-range-btn" data-range="yesterday">昨日</button>
            <button class="btn btn-default date-range-btn" data-range="7days">近7天</button>
            <button class="btn btn-default date-range-btn" data-range="30days">近30天</button>
            <div class="date-picker-group">
                <input type="date" id="custom-start-date" placeholder="开始日期">
                <input type="date" id="custom-end-date" placeholder="结束日期">
                <button class="btn btn-default" id="apply-custom-date">应用</button>
            </div>
        </div>
        
        <!-- 总览卡片 -->
        <div class="summary-cards">
            <!-- 总点击量 -->
            <div class="summary-card" id="card-total-clicks">
                <div class="summary-card-icon">
                    <i class="fa fa-mouse-pointer"></i>
                </div>
                <div class="summary-card-title">总点击量</div>
                <div class="summary-card-value">--</div>
                <div class="summary-card-change"></div>
            </div>
            
            <!-- 独立访客 -->
            <div class="summary-card" id="card-unique-clicks">
                <div class="summary-card-icon">
                    <i class="fa fa-users"></i>
                </div>
                <div class="summary-card-title">独立访客</div>
                <div class="summary-card-value">--</div>
                <div class="summary-card-change"></div>
            </div>
            
            <!-- 注册用户 -->
            <div class="summary-card" id="card-registrations">
                <div class="summary-card-icon">
                    <i class="fa fa-user-plus"></i>
                </div>
                <div class="summary-card-title">注册用户</div>
                <div class="summary-card-value">--</div>
                <div class="summary-card-change"></div>
            </div>
            
            <!-- 订单数量 -->
            <div class="summary-card" id="card-orders">
                <div class="summary-card-icon">
                    <i class="fa fa-shopping-cart"></i>
                </div>
                <div class="summary-card-title">订单数量</div>
                <div class="summary-card-value">--</div>
                <div class="summary-card-change"></div>
            </div>
            
            <!-- 总销售额 -->
            <div class="summary-card" id="card-total-amount">
                <div class="summary-card-icon">
                    <i class="fa fa-line-chart"></i>
                </div>
                <div class="summary-card-title">总销售额</div>
                <div class="summary-card-value">¥--</div>
                <div class="summary-card-change"></div>
            </div>
            
            <!-- 佣金收入 -->
            <div class="summary-card" id="card-commission-earned">
                <div class="summary-card-icon">
                    <i class="fa fa-money"></i>
                </div>
                <div class="summary-card-title">佣金收入</div>
                <div class="summary-card-value">¥--</div>
                <div class="summary-card-change"></div>
            </div>
        </div>
        
        <!-- 图表区域 -->
        <div class="chart-grid">
            <!-- 推广趋势图表 -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3 class="chart-section-title">推广趋势</h3>
                    <div>
                        <select id="trend-metric-selector" class="btn btn-default" style="padding: 6px 12px;">
                            <option value="clicks">点击量</option>
                            <option value="registrations">注册量</option>
                            <option value="orders">订单量</option>
                            <option value="commission">佣金收入</option>
                        </select>
                    </div>
                </div>
                <div id="promotion-trend-chart" class="chart-container loading">
                    <div class="loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            </div>
            
            <!-- 转化率图表 -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3 class="chart-section-title">转化率分析</h3>
                </div>
                <div id="conversion-rate-chart" class="chart-container loading">
                    <div class="loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            </div>
        </div>
        
        <!-- 佣金明细表格 -->
        <div class="table-section">
            <div class="table-section-header">
                <h3 class="table-section-title">佣金明细</h3>
                <div class="table-actions">
                    <select id="commission-status-filter" class="btn btn-default" style="padding: 6px 12px;">
                        <option value="">全部状态</option>
                        <option value="pending">待结算</option>
                        <option value="settled">已结算</option>
                        <option value="rejected">已拒绝</option>
                    </select>
                    <button class="btn btn-primary" id="export-commission-details">导出数据</button>
                </div>
            </div>
            
            <div class="table-responsive">
                <table id="commission-details-table">
                    <thead>
                        <tr>
                            <th>订单号</th>
                            <th>订单金额</th>
                            <th>佣金金额</th>
                            <th>状态</th>
                            <th>创建时间</th>
                            <th>结算时间</th>
                        </tr>
                    </thead>
                    <tbody id="commission-details-table-body">
                        <!-- 由JavaScript动态填充 -->
                    </tbody>
                </table>
            </div>
            
            <!-- 分页控件 -->
            <div class="pagination">
                <button class="btn btn-default" id="prev-page">上一页</button>
                <span id="page-info">第 1 页</span>
                <button class="btn btn-default" id="next-page">下一页</button>
            </div>
        </div>
        
        <!-- 详细统计数据 -->
        <div class="stats-grid">
            <!-- 页面效果分析 -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3 class="chart-section-title">页面效果分析</h3>
                </div>
                <div class="table-responsive">
                    <table id="page-effectiveness-table">
                        <thead>
                            <tr>
                                <th>页面URL</th>
                                <th>点击量</th>
                                <th>转化率</th>
                            </tr>
                        </thead>
                        <tbody id="page-effectiveness-table-body">
                            <!-- 由JavaScript动态填充 -->
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- 地域分布 -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3 class="chart-section-title">地域分布</h3>
                </div>
                <div id="geographic-distribution-chart" class="chart-container loading">
                    <div class="loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            </div>
            
            <!-- 设备类型统计 -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3 class="chart-section-title">设备类型统计</h3>
                </div>
                <div id="device-types-chart" class="chart-container loading">
                    <div class="loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            </div>
            
            <!-- 浏览器统计 -->
            <div class="chart-section">
                <div class="chart-header">
                    <h3 class="chart-section-title">浏览器统计</h3>
                </div>
                <div id="browsers-chart" class="chart-container loading">
                    <div class="loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 页脚 -->
    <?php include __DIR__ . '/includes/footer.php'; ?>
    
    <!-- 加载页面脚本 -->
    <?php foreach ($scripts as $script) { ?>
    <script src="<?php echo $script; ?>"></script>
    <?php } ?>
    
    <!-- 页面数据 -->
    <script>
        // 全局数据
        const dashboardData = {
            currentAgentId: <?php echo $currentAgentId; ?>,
            currentDateRange: '7days',
            currentPage: 1,
            pageSize: 20,
            commissionFilters: {}
        };
        
        // 初始化页面
        $(document).ready(function() {
            // 初始化日期选择器
            const today = new Date();
            const formattedToday = formatDate(today);
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(today.getDate() - 30);
            const formattedThirtyDaysAgo = formatDate(thirtyDaysAgo);
            
            $('#custom-start-date').val(formattedThirtyDaysAgo);
            $('#custom-end-date').val(formattedToday);
            
            // 绑定时间范围按钮事件
            $('.date-range-btn').on('click', function() {
                // 重置按钮样式
                $('.date-range-btn').removeClass('btn-primary').addClass('btn-default');
                $(this).removeClass('btn-default').addClass('btn-primary');
                
                // 设置当前时间范围
                dashboardData.currentDateRange = $(this).data('range');
                
                // 加载数据
                loadAllData();
            });
            
            // 绑定自定义日期应用按钮
            $('#apply-custom-date').on('click', function() {
                const startDate = $('#custom-start-date').val();
                const endDate = $('#custom-end-date').val();
                
                if (startDate && endDate) {
                    // 更新按钮样式
                    $('.date-range-btn').removeClass('btn-primary').addClass('btn-default');
                    
                    // 设置自定义日期范围
                    dashboardData.currentDateRange = 'custom';
                    dashboardData.customStartDate = startDate;
                    dashboardData.customEndDate = endDate;
                    
                    // 加载数据
                    loadAllData();
                } else {
                    alert('请选择开始日期和结束日期');
                }
            });
            
            // 绑定佣金状态筛选
            $('#commission-status-filter').on('change', function() {
                dashboardData.commissionFilters.status = $(this).val();
                dashboardData.currentPage = 1; // 重置到第一页
                loadCommissionDetails();
            });
            
            // 绑定分页控制
            $('#prev-page').on('click', function() {
                if (dashboardData.currentPage > 1) {
                    dashboardData.currentPage--;
                    loadCommissionDetails();
                }
            });
            
            $('#next-page').on('click', function() {
                dashboardData.currentPage++;
                loadCommissionDetails();
            });
            
            // 绑定导出按钮
            $('#export-commission-details').on('click', function() {
                exportCommissionDetails();
            });
            
            // 绑定趋势指标选择器
            $('#trend-metric-selector').on('change', function() {
                renderPromotionTrendChart();
            });
            
            // 初始加载数据
            loadAllData();
        });
        
        // 加载所有数据
        function loadAllData() {
            // 重置分页
            dashboardData.currentPage = 1;
            
            // 加载总览数据
            loadOverviewData();
            
            // 加载推广趋势数据
            loadPromotionTrendData();
            
            // 加载佣金明细
            loadCommissionDetails();
            
            // 加载页面效果分析
            loadPageEffectivenessData();
            
            // 加载设备和地域统计
            loadDeviceAndGeographicData();
        }
        
        // 加载总览数据
        function loadOverviewData() {
            // 构建请求URL
            let url = `/api/agent/promotion_analytics_api.php?action=overview&date_range=${dashboardData.currentDateRange}`;
            
            // 添加自定义日期参数
            if (dashboardData.currentDateRange === 'custom') {
                url += `&start_date=${dashboardData.customStartDate}&end_date=${dashboardData.customEndDate}`;
            }
            
            // 发送请求
            $.ajax({
                url: url,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 更新总览卡片
                        updateSummaryCards(response);
                    } else {
                        console.error('获取总览数据失败:', response.error);
                        alert('获取数据失败，请稍后重试');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('请求总览数据失败:', error);
                    alert('网络错误，请稍后重试');
                }
            });
        }
        
        // 更新总览卡片
        function updateSummaryCards(data) {
            const metrics = data.metrics;
            
            // 更新各个卡片
            updateSummaryCard('card-total-clicks', metrics.total_clicks);
            updateSummaryCard('card-unique-clicks', metrics.unique_clicks);
            updateSummaryCard('card-registrations', metrics.registrations);
            updateSummaryCard('card-orders', metrics.orders);
            updateSummaryCard('card-total-amount', metrics.total_amount, true);
            updateSummaryCard('card-commission-earned', metrics.commission_earned, true);
        }
        
        // 更新单个总览卡片
        function updateSummaryCard(cardId, value, isCurrency = false) {
            const card = $(`#${cardId}`);
            
            if (isCurrency) {
                card.find('.summary-card-value').text(`¥${value.toFixed(2)}`);
            } else {
                card.find('.summary-card-value').text(value);
            }
            
            // 这里可以添加变化趋势计算
            // 暂时留空，可在后续版本中添加
        }
        
        // 加载推广趋势数据
        function loadPromotionTrendData() {
            // 构建请求URL
            let url = `/api/agent/promotion_analytics_api.php?action=promotion_trend&date_range=${dashboardData.currentDateRange}`;
            
            // 添加自定义日期参数
            if (dashboardData.currentDateRange === 'custom') {
                url += `&start_date=${dashboardData.customStartDate}&end_date=${dashboardData.customEndDate}`;
            }
            
            // 发送请求
            $.ajax({
                url: url,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 存储趋势数据
                        dashboardData.promotionTrendData = response;
                        
                        // 渲染图表
                        renderPromotionTrendChart();
                        renderConversionRateChart();
                    } else {
                        console.error('获取推广趋势数据失败:', response.error);
                        showError('#promotion-trend-chart');
                        showError('#conversion-rate-chart');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('请求推广趋势数据失败:', error);
                    showError('#promotion-trend-chart');
                    showError('#conversion-rate-chart');
                }
            });
        }
        
        // 渲染推广趋势图表
        function renderPromotionTrendChart() {
            if (!dashboardData.promotionTrendData) return;
            
            const chartElement = document.getElementById('promotion-trend-chart');
            
            // 移除加载状态
            $(chartElement).removeClass('loading');
            
            // 获取数据
            const data = dashboardData.promotionTrendData.data;
            const periods = data.map(item => item.period_label);
            
            // 根据选择的指标渲染不同的数据
            const metric = $('#trend-metric-selector').val();
            let chartData = [];
            let chartTitle = '';
            let yAxisName = '';
            
            switch (metric) {
                case 'clicks':
                    chartData = data.map(item => item.total_clicks);
                    chartTitle = '点击量趋势';
                    yAxisName = '点击量';
                    break;
                case 'registrations':
                    chartData = data.map(item => item.registrations || 0);
                    chartTitle = '注册量趋势';
                    yAxisName = '注册量';
                    break;
                case 'orders':
                    chartData = data.map(item => item.orders || 0);
                    chartTitle = '订单量趋势';
                    yAxisName = '订单量';
                    break;
                case 'commission':
                    chartData = data.map(item => item.commission_amount || 0);
                    chartTitle = '佣金收入趋势';
                    yAxisName = '佣金金额(¥)';
                    break;
            }
            
            // 初始化图表
            const chart = echarts.init(chartElement);
            
            // 配置图表选项
            const option = {
                title: {
                    text: chartTitle,
                    left: 'center'
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function(params) {
                        const dataIndex = params[0].dataIndex;
                        const dataItem = data[dataIndex];
                        let tooltipHtml = `<div>时间: ${dataItem.period_label}</div>`;
                        
                        switch (metric) {
                            case 'clicks':
                                tooltipHtml += `<div>点击量: ${dataItem.total_clicks}</div>`;
                                tooltipHtml += `<div>独立访客: ${dataItem.unique_clicks}</div>`;
                                break;
                            case 'registrations':
                                tooltipHtml += `<div>注册量: ${dataItem.registrations || 0}</div>`;
                                break;
                            case 'orders':
                                tooltipHtml += `<div>订单量: ${dataItem.orders || 0}</div>`;
                                tooltipHtml += `<div>订单金额: ¥${(dataItem.order_amount || 0).toFixed(2)}</div>`;
                                break;
                            case 'commission':
                                tooltipHtml += `<div>佣金: ¥${(dataItem.commission_amount || 0).toFixed(2)}</div>`;
                                break;
                        }
                        
                        return tooltipHtml;
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    data: periods,
                    axisLabel: {
                        rotate: 45
                    }
                },
                yAxis: {
                    type: 'value',
                    name: yAxisName
                },
                series: [{
                    name: yAxisName,
                    type: 'line',
                    smooth: true,
                    data: chartData,
                    itemStyle: {
                        color: '#1890ff'
                    },
                    areaStyle: {
                        color: {
                            type: 'linear',
                            x: 0,
                            y: 0,
                            x2: 0,
                            y2: 1,
                            colorStops: [{
                                offset: 0,
                                color: 'rgba(24, 144, 255, 0.6)'
                            }, {
                                offset: 1,
                                color: 'rgba(24, 144, 255, 0.05)'
                            }]
                        }
                    }
                }]
            };
            
            // 设置图表选项
            chart.setOption(option);
            
            // 响应窗口大小变化
            window.addEventListener('resize', function() {
                chart.resize();
            });
        }
        
        // 渲染转化率图表
        function renderConversionRateChart() {
            if (!dashboardData.promotionTrendData) return;
            
            const chartElement = document.getElementById('conversion-rate-chart');
            
            // 移除加载状态
            $(chartElement).removeClass('loading');
            
            // 获取数据
            const data = dashboardData.promotionTrendData.data;
            const periods = data.map(item => item.period_label);
            
            // 计算转化率数据
            const conversionRates = data.map(item => {
                const totalClicks = item.total_clicks || 1;
                const orders = item.orders || 0;
                return (orders / totalClicks * 100).toFixed(2);
            });
            
            // 初始化图表
            const chart = echarts.init(chartElement);
            
            // 配置图表选项
            const option = {
                title: {
                    text: '转化率趋势',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function(params) {
                        const dataIndex = params[0].dataIndex;
                        const dataItem = data[dataIndex];
                        const conversionRate = conversionRates[dataIndex];
                        
                        return `<div>
                            <div>时间: ${dataItem.period_label}</div>
                            <div>点击量: ${dataItem.total_clicks}</div>
                            <div>订单量: ${dataItem.orders || 0}</div>
                            <div>转化率: ${conversionRate}%</div>
                        </div>`;
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    data: periods,
                    axisLabel: {
                        rotate: 45
                    }
                },
                yAxis: {
                    type: 'value',
                    name: '转化率(%)',
                    axisLabel: {
                        formatter: '{value}%'
                    }
                },
                series: [{
                    name: '转化率',
                    type: 'line',
                    smooth: true,
                    data: conversionRates,
                    itemStyle: {
                        color: '#52c41a'
                    },
                    areaStyle: {
                        color: {
                            type: 'linear',
                            x: 0,
                            y: 0,
                            x2: 0,
                            y2: 1,
                            colorStops: [{
                                offset: 0,
                                color: 'rgba(82, 196, 26, 0.6)'
                            }, {
                                offset: 1,
                                color: 'rgba(82, 196, 26, 0.05)'
                            }]
                        }
                    }
                }]
            };
            
            // 设置图表选项
            chart.setOption(option);
            
            // 响应窗口大小变化
            window.addEventListener('resize', function() {
                chart.resize();
            });
        }
        
        // 加载佣金明细
        function loadCommissionDetails() {
            // 显示加载状态
            const tableBody = $('#commission-details-table-body');
            tableBody.html('<tr><td colspan="6" style="text-align: center;"><div class="loading-spinner" style="display: inline-block; width: 20px; height: 20px; margin-right: 10px;"></div>加载中...</td></tr>');
            
            // 构建请求参数
            const params = {
                action: 'commission_details',
                page: dashboardData.currentPage,
                page_size: dashboardData.pageSize,
                date_range: dashboardData.currentDateRange
            };
            
            // 添加自定义日期参数
            if (dashboardData.currentDateRange === 'custom') {
                params.start_date = dashboardData.customStartDate;
                params.end_date = dashboardData.customEndDate;
            }
            
            // 添加筛选条件
            if (dashboardData.commissionFilters.status) {
                params.status = dashboardData.commissionFilters.status;
            }
            
            // 发送请求
            $.ajax({
                url: '/api/agent/promotion_analytics_api.php',
                type: 'GET',
                data: params,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 更新表格
                        updateCommissionDetailsTable(response.data);
                    } else {
                        console.error('获取佣金明细失败:', response.error);
                        alert('获取数据失败，请稍后重试');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('请求佣金明细失败:', error);
                    alert('网络错误，请稍后重试');
                }
            });
        }
        
        // 更新佣金明细表格
        function updateCommissionDetailsTable(data) {
            const tableBody = $('#commission-details-table-body');
            const commissions = data.commissions || [];
            const pagination = data.pagination || {};
            
            // 清空表格
            tableBody.empty();
            
            // 检查是否有数据
            if (commissions.length === 0) {
                tableBody.html('<tr><td colspan="6" style="text-align: center;">暂无数据</td></tr>');
                return;
            }
            
            // 添加表格行
            commissions.forEach(function(commission) {
                const statusBadge = getStatusBadge(commission.status);
                const row = `<tr>
                    <td>${commission.order_no || '-'}</td>
                    <td>¥${commission.order_amount ? commission.order_amount.toFixed(2) : '0.00'}</td>
                    <td>¥${commission.commission_amount.toFixed(2)}</td>
                    <td>${statusBadge}</td>
                    <td>${formatDateTime(commission.created_at)}</td>
                    <td>${commission.settled_at ? formatDateTime(commission.settled_at) : '-'}</td>
                </tr>`;
                tableBody.append(row);
            });
            
            // 更新分页信息
            $('#page-info').text(`第 ${pagination.current_page} / ${pagination.total_pages} 页`);
            
            // 更新分页按钮状态
            $('#prev-page').prop('disabled', pagination.current_page <= 1);
            $('#next-page').prop('disabled', pagination.current_page >= pagination.total_pages);
        }
        
        // 获取状态徽章
        function getStatusBadge(status) {
            switch (status) {
                case 'pending':
                    return '<span class="status-badge badge-pending">待结算</span>';
                case 'settled':
                    return '<span class="status-badge badge-settled">已结算</span>';
                case 'rejected':
                    return '<span class="status-badge badge-rejected">已拒绝</span>';
                default:
                    return status;
            }
        }
        
        // 加载页面效果分析数据
        function loadPageEffectivenessData() {
            // 构建请求参数
            const params = {
                action: 'page_effectiveness',
                date_range: dashboardData.currentDateRange
            };
            
            // 添加自定义日期参数
            if (dashboardData.currentDateRange === 'custom') {
                params.start_date = dashboardData.customStartDate;
                params.end_date = dashboardData.customEndDate;
            }
            
            // 发送请求
            $.ajax({
                url: '/api/agent/promotion_analytics_api.php',
                type: 'GET',
                data: params,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 更新表格
                        updatePageEffectivenessTable(response.data);
                    } else {
                        console.error('获取页面效果分析失败:', response.error);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('请求页面效果分析失败:', error);
                }
            });
        }
        
        // 更新页面效果分析表格
        function updatePageEffectivenessTable(data) {
            const tableBody = $('#page-effectiveness-table-body');
            
            // 清空表格
            tableBody.empty();
            
            // 检查是否有数据
            if (data.length === 0) {
                tableBody.html('<tr><td colspan="3" style="text-align: center;">暂无数据</td></tr>');
                return;
            }
            
            // 添加表格行
            data.forEach(function(page) {
                const row = `<tr>
                    <td>${page.target_url}</td>
                    <td>${page.total_clicks}</td>
                    <td>${page.conversion_rate}%</td>
                </tr>`;
                tableBody.append(row);
            });
        }
        
        // 加载设备和地域统计数据
        function loadDeviceAndGeographicData() {
            loadGeographicData();
            loadDeviceData();
        }
        
        // 加载地域数据
        function loadGeographicData() {
            // 构建请求参数
            const params = {
                action: 'geographic_distribution',
                date_range: dashboardData.currentDateRange
            };
            
            // 添加自定义日期参数
            if (dashboardData.currentDateRange === 'custom') {
                params.start_date = dashboardData.customStartDate;
                params.end_date = dashboardData.customEndDate;
            }
            
            // 发送请求
            $.ajax({
                url: '/api/agent/promotion_analytics_api.php',
                type: 'GET',
                data: params,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 渲染地域分布图表
                        renderGeographicChart(response.data);
                    } else {
                        console.error('获取地域分布数据失败:', response.error);
                        showError('#geographic-distribution-chart');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('请求地域分布数据失败:', error);
                    showError('#geographic-distribution-chart');
                }
            });
        }
        
        // 渲染地域分布图表
        function renderGeographicChart(data) {
            const chartElement = document.getElementById('geographic-distribution-chart');
            
            // 移除加载状态
            $(chartElement).removeClass('loading');
            
            // 初始化图表
            const chart = echarts.init(chartElement);
            
            // 准备图表数据
            const chartData = data.map(item => {
                return {
                    name: `${item.region || item.country}`,
                    value: item.visit_count
                };
            }).slice(0, 10); // 只显示前10个地区
            
            // 配置图表选项
            const option = {
                tooltip: {
                    trigger: 'item',
                    formatter: function(params) {
                        return `${params.name}<br/>访问量: ${params.value}<br/>转化率: ${data[params.dataIndex].conversion_rate}%`;
                    }
                },
                series: [{
                    name: '访问量',
                    type: 'pie',
                    radius: ['40%', '70%'],
                    center: ['50%', '55%'],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        label: {
                            show: true,
                            fontSize: '18',
                            fontWeight: 'bold'
                        }
                    },
                    labelLine: {
                        show: false
                    },
                    data: chartData
                }]
            };
            
            // 设置图表选项
            chart.setOption(option);
            
            // 响应窗口大小变化
            window.addEventListener('resize', function() {
                chart.resize();
            });
        }
        
        // 加载设备数据
        function loadDeviceData() {
            // 构建请求参数
            const params = {
                action: 'device_statistics',
                date_range: dashboardData.currentDateRange
            };
            
            // 添加自定义日期参数
            if (dashboardData.currentDateRange === 'custom') {
                params.start_date = dashboardData.customStartDate;
                params.end_date = dashboardData.customEndDate;
            }
            
            // 发送请求
            $.ajax({
                url: '/api/agent/promotion_analytics_api.php',
                type: 'GET',
                data: params,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // 渲染设备类型图表
                        renderDeviceTypeChart(response.data.device_types);
                        // 渲染浏览器图表
                        renderBrowserChart(response.data.browsers);
                    } else {
                        console.error('获取设备统计数据失败:', response.error);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('请求设备统计数据失败:', error);
                }
            });
        }
        
        // 渲染设备类型图表
        function renderDeviceTypeChart(data) {
            const chartElement = document.getElementById('device-types-chart');
            
            // 移除加载状态
            $(chartElement).removeClass('loading');
            
            // 初始化图表
            const chart = echarts.init(chartElement);
            
            // 准备图表数据
            const chartData = data.map(item => {
                return {
                    name: formatDeviceType(item.device_type),
                    value: item.count
                };
            });
            
            // 配置图表选项
            const option = {
                title: {
                    text: '设备类型分布',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b}: {c} ({d}%)'
                },
                series: [{
                    name: '设备类型',
                    type: 'pie',
                    radius: '60%',
                    data: chartData,
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }]
            };
            
            // 设置图表选项
            chart.setOption(option);
            
            // 响应窗口大小变化
            window.addEventListener('resize', function() {
                chart.resize();
            });
        }
        
        // 渲染浏览器图表
        function renderBrowserChart(data) {
            const chartElement = document.getElementById('browsers-chart');
            
            // 移除加载状态
            $(chartElement).removeClass('loading');
            
            // 初始化图表
            const chart = echarts.init(chartElement);
            
            // 准备图表数据
            const chartData = data.map(item => item.count);
            const browserNames = data.map(item => item.browser_name);
            
            // 配置图表选项
            const option = {
                title: {
                    text: '浏览器分布',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    data: browserNames,
                    axisLabel: {
                        rotate: 45
                    }
                },
                yAxis: {
                    type: 'value',
                    name: '访问量'
                },
                series: [{
                    name: '访问量',
                    type: 'bar',
                    data: chartData,
                    itemStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: '#83bff6'
                        }, {
                            offset: 0.5,
                            color: '#188df0'
                        }, {
                            offset: 1,
                            color: '#188df0'
                        }])
                    }
                }]
            };
            
            // 设置图表选项
            chart.setOption(option);
            
            // 响应窗口大小变化
            window.addEventListener('resize', function() {
                chart.resize();
            });
        }
        
        // 导出佣金明细数据
        function exportCommissionDetails() {
            // 构建导出URL
            let url = '/api/agent/promotion_analytics_api.php?action=export_data&export_type=commission_details';
            
            // 添加日期范围参数
            if (dashboardData.currentDateRange === 'custom') {
                url += `&start_date=${dashboardData.customStartDate}&end_date=${dashboardData.customEndDate}`;
            } else {
                url += `&date_range=${dashboardData.currentDateRange}`;
            }
            
            // 添加筛选条件
            if (dashboardData.commissionFilters.status) {
                url += `&status=${dashboardData.commissionFilters.status}`;
            }
            
            // 打开下载链接
            window.open(url, '_self');
        }
        
        // 辅助函数：格式化日期
        function formatDate(date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }
        
        // 辅助函数：格式化日期时间
        function formatDateTime(dateTimeString) {
            if (!dateTimeString) return '';
            
            const date = new Date(dateTimeString);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            
            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        }
        
        // 辅助函数：格式化设备类型
        function formatDeviceType(deviceType) {
            switch (deviceType) {
                case 'desktop':
                    return '桌面端';
                case 'mobile':
                    return '移动端';
                case 'tablet':
                    return '平板';
                default:
                    return deviceType || '未知';
            }
        }
        
        // 辅助函数：显示错误信息
        function showError(elementId) {
            $(elementId).html('<div style="text-align: center; padding: 20px; color: #ff4d4f;">数据加载失败</div>');
        }
        
        // 辅助函数：更新总览卡片
        function updateSummaryCard(cardId, value, isCurrency = false) {
            const card = $(`#${cardId}`);
            
            if (isCurrency) {
                card.find('.summary-card-value').text(`¥${value.toFixed(2)}`);
            } else {
                card.find('.summary-card-value').text(value);
            }
        }
    </script>
</body>
</html>