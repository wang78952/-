<?php

/**
 * 压缩配置
 * 定义系统中不同内容类型的压缩策略
 */
return [
    // 压缩器设置
    'compressor' => [
        // 首选压缩器：'brotli', 'gzip', 'auto'
        'preferred' => 'auto',
        
        // 默认压缩级别 (0-11)
        'default_quality' => 6,
        
        // 最小压缩大小 (字节)
        'min_size' => 1024,
        
        // 最大压缩大小 (字节)
        'max_size' => 5242880, // 5MB
    ],
    
    // 内容类型配置
    'content_types' => [
        // HTML文件
        'text/html' => [
            'enabled' => true,
            'quality' => 11, // 最高压缩级别
        ],
        
        // CSS文件
        'text/css' => [
            'enabled' => true,
            'quality' => 11,
        ],
        
        // JavaScript文件
        'text/javascript' => [
            'enabled' => true,
            'quality' => 11,
        ],
        
        'application/javascript' => [
            'enabled' => true,
            'quality' => 11,
        ],
        
        // JSON数据
        'application/json' => [
            'enabled' => true,
            'quality' => 11,
        ],
        
        // XML数据
        'application/xml' => [
            'enabled' => true,
            'quality' => 9,
        ],
        
        'text/xml' => [
            'enabled' => true,
            'quality' => 9,
        ],
        
        // SVG图像
        'image/svg+xml' => [
            'enabled' => true,
            'quality' => 8,
        ],
        
        // 纯文本
        'text/plain' => [
            'enabled' => true,
            'quality' => 6,
        ],
        
        // CSV文件
        'text/csv' => [
            'enabled' => true,
            'quality' => 7,
        ],
    ],
    
    // 静态文件缓存设置
    'static_cache' => [
        'enabled' => true,
        'cache_dir' => __DIR__ . '/../storage/compression_cache/',
        'cache_ttl' => 86400, // 24小时
    ],
    
    // HTTP响应压缩
    'http_compression' => [
        'enabled' => true,
        // 支持的压缩算法
        'supported_encodings' => ['gzip', 'deflate'],
        // 压缩后自动添加的头部
        'headers' => true,
    ],
    
    // 排除的URL模式
    'excluded_paths' => [
        '/api/stream',
        '/download/',
        '/upload/',
        '/images/',
        '/fonts/',
    ],
];