<?php
/**
 * 安全配置文件
 */

return [
    'encryption_key' => 'your-secret-encryption-key-here',
    'jwt_secret' => 'your-jwt-secret-here',
    'password_salt' => 'your-password-salt-here',
    'session_timeout' => 3600,
    'max_login_attempts' => 5,
    'lockout_duration' => 900,
    'password_min_length' => 8,
    'require_special_chars' => true,
    'csrf_token_expiry' => 7200,
    'rate_limiting' => [
        'enabled' => true,
        'requests_per_minute' => 60,
        'burst_size' => 10
    ],
    'allowed_ips' => [],
    'blocked_ips' => []
];