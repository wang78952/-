<?php
/**
 * 缓存配置文件
 * 定义Redis和其他缓存服务的连接参数及缓存策略
 */

// 更新默认缓存驱动为Redis
$cache_config = [
    'enabled' => true,
    'default' => 'redis',
    'stores' => [
        'file' => [
            'driver' => 'file',
            'path' => __DIR__ . '/../cache',
        ],
        'redis' => [
            'driver' => 'redis',
            'host' => '127.0.0.1',
            'port' => 6379,
            'password' => '',
            'database' => 0,
            'prefix' => 'card_system:',
            'timeout' => 0.5,
            'ttl' => 3600,
            'pool' => [
                'min_connections' => 1,
                'max_connections' => 10,
                'connection_timeout' => 1.0
            ]
        ],
        'memcached' => [
            'driver' => 'memcached',
            'servers' => [
                [
                    'host' => '127.0.0.1',
                    'port' => 11211,
                    'weight' => 100
                ]
            ],
            'prefix' => 'card_system:',
            'ttl' => 3600
        ],
        'apcu' => [
            'driver' => 'apcu',
            'prefix' => 'card_system:',
            'ttl' => 3600
        ]
    ],
    
    // 缓存过期时间配置（秒）
    'ttl' => [
        // 卡密信息缓存
        'card_info' => 3600, // 1小时
        
        // 代理佣金配置缓存
        'agent_commission' => 7200, // 2小时
        
        // 用户信息缓存
        'user_info' => 1800, // 30分钟
        
        // 产品信息缓存
        'product_info' => 3600, // 1小时
        
        // 系统配置缓存
        'system_config' => 3600, // 1小时
        
        // 热门卡密缓存
        'hot_cards' => 1800, // 30分钟
        
        // 统计数据缓存
        'statistics' => 900, // 15分钟
        
        // 验证码缓存
        'captcha' => 300, // 5分钟
        
        // 临时数据缓存
        'temporary' => 600 // 10分钟
    ],
    
    // 热点数据配置
    'hot_data' => [
        // 自动缓存的热门卡密数量
        'auto_cache_cards_count' => 100,
        
        // 卡密访问热度阈值
        'card_heat_threshold' => 10,
        
        // 是否启用热点预加载
        'preload_enabled' => true,
        
        // 预加载间隔（秒）
        'preload_interval' => 600 // 10分钟
    ],
    
    // 缓存监控
    'monitoring' => [
        // 是否启用监控
        'enabled' => true,
        
        // 记录命中率
        'record_hit_rate' => true,
        
        // 记录缓存操作
        'log_operations' => false
    ]
];

// 设置全局缓存配置
$GLOBALS['cache_config'] = $cache_config;

// 缓存键名常量定义
define('CACHE_KEY_PREFIX', $cache_config['stores']['redis']['prefix']);

// 卡密相关缓存键
function CACHE_KEY_CARD_INFO($cardId) { return CACHE_KEY_PREFIX . "card:info:{$cardId}"; }
function CACHE_KEY_CARD_STATUS($cardId) { return CACHE_KEY_PREFIX . "card:status:{$cardId}"; }
function CACHE_KEY_USER_CARDS($userId) { return CACHE_KEY_PREFIX . "user:cards:{$userId}"; }
function CACHE_KEY_HOT_CARDS() { return CACHE_KEY_PREFIX . "hot:cards"; }
function CACHE_KEY_CARD_SEARCH($keyword) { return CACHE_KEY_PREFIX . "search:card:{$keyword}"; }

// 代理相关缓存键
function CACHE_KEY_AGENT_INFO($agentId) { return CACHE_KEY_PREFIX . "agent:info:{$agentId}"; }
function CACHE_KEY_AGENT_COMMISSION($agentId) { return CACHE_KEY_PREFIX . "agent:commission:{$agentId}"; }
function CACHE_KEY_AGENT_STATS($agentId) { return CACHE_KEY_PREFIX . "agent:stats:{$agentId}"; }

// 用户相关缓存键
function CACHE_KEY_USER_INFO($userId) { return CACHE_KEY_PREFIX . "user:info:{$userId}"; }
function CACHE_KEY_USER_SESSION($sessionId) { return CACHE_KEY_PREFIX . "user:session:{$sessionId}"; }
function CACHE_KEY_USER_PERMISSIONS($userId) { return CACHE_KEY_PREFIX . "user:permissions:{$userId}"; }

// 产品相关缓存键
function CACHE_KEY_PRODUCT_INFO($productId) { return CACHE_KEY_PREFIX . "product:info:{$productId}"; }
function CACHE_KEY_PRODUCT_LIST() { return CACHE_KEY_PREFIX . "product:list"; }
function CACHE_KEY_PRODUCT_CATEGORY($categoryId) { return CACHE_KEY_PREFIX . "product:category:{$categoryId}"; }

// 系统相关缓存键
function CACHE_KEY_SYSTEM_CONFIG() { return CACHE_KEY_PREFIX . "system:config"; }
function CACHE_KEY_RATE_LIMIT($ip) { return CACHE_KEY_PREFIX . "rate:limit:{$ip}"; }
function CACHE_KEY_CAPTCHA($key) { return CACHE_KEY_PREFIX . "captcha:{$key}"; }

// 返回原始配置格式，保持兼容性
return $cache_config['stores'];