<?php
/**
 * 二次验证配置文件
 * 定义敏感操作、风险级别和验证策略
 */

return [
    // 二次验证开关
    'enabled' => true,
    
    // 验证方法配置
    'methods' => [
        // 短信验证码
        'sms' => [
            'enabled' => true,
            'code_length' => 6,
            'expire_time' => 300, // 5分钟
            'cooldown' => 60, // 60秒内不能重复发送
        ],
        
        // 邮箱验证码
        'email' => [
            'enabled' => true,
            'code_length' => 8,
            'expire_time' => 300, // 5分钟
            'cooldown' => 60, // 60秒内不能重复发送
        ],
        
        // TOTP验证器
        'totp' => [
            'enabled' => false,
            'time_step' => 30, // 30秒一个周期
            'window' => 1, // 允许前后1个时间窗口的偏差
        ],
    ],
    
    // 默认验证方法
    'default_method' => 'sms',
    
    // 操作风险级别定义
    'risk_levels' => [
        'critical' => [
            'user_delete',        // 删除用户
            'admin_password_change', // 修改管理员密码
            'permission_change',  // 修改权限
            'system_config_core', // 修改核心配置
            'export_all_data',    // 导出所有数据
        ],
        
        'high' => [
            'login',              // 添加登录操作
            'user_manage',        // 用户管理
            'system_config',      // 系统配置
            'card_delete',        // 删除卡密
            'export_data',        // 导出数据
            'payment_process',    // 支付处理
            'refund_process',     // 退款处理
            'blacklist_add',      // 添加黑名单
        ],
        
        'medium' => [
            'card_batch_issue',   // 批量发卡
            'role_assign',        // 角色分配
            'template_modify',    // 修改模板
            'api_key_generate',   // 生成API密钥
            'rate_limit_change',  // 修改限流设置
        ],
    ],
    
    // 每个风险级别对应的验证要求
    'verification_requirements' => [
        'critical' => [
            'require_two_factor' => true,
            'require_approval' => true, // 需要管理员审批
        ],
        
        'high' => [
            'require_two_factor' => true,
            'require_approval' => false,
        ],
        
        'medium' => [
            'require_two_factor' => false,
            'require_approval' => false,
        ],
    ],
    
    // 验证失败策略
    'failure_policy' => [
        'max_attempts' => 5,       // 最大尝试次数
        'lockout_duration' => 300, // 锁定时间（秒）
        'alert_on_max_attempts' => true, // 达到最大尝试次数是否触发告警
    ],
    
    // 验证会话设置
    'session' => [
        'validity_duration' => 3600, // 验证会话有效期（秒）
        'allow_same_session' => true, // 同一会话内是否允许复用验证
    ],
    
    // 异常行为检测
    'anomaly_detection' => [
        'enabled' => true,
        'time_window' => 300, // 5分钟检测窗口
        'max_verification_attempts' => 10, // 最大验证尝试次数
        'block_threshold' => 15, // 达到阈值则自动封禁IP
    ],
];