<?php
/**
 * API配置文件
 */

return [
    'version' => 'v1',
    'base_url' => '/api',
    'rate_limit' => [
        'requests_per_minute' => 60,
        'burst_size' => 10
    ],
    'cors' => [
        'allowed_origins' => ['*'],
        'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE'],
        'allowed_headers' => ['Content-Type', 'Authorization']
    ],
    'pagination' => [
        'default_limit' => 20,
        'max_limit' => 100
    ],
    'response_format' => 'json',
    'debug' => DEBUG_MODE
];