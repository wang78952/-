<?php
/**
 * 支付配置文件
 */

return [
    'default' => 'alipay',
    'providers' => [
        'alipay' => [
            'app_id' => '',
            'private_key' => '',
            'public_key' => '',
            'sandbox' => true,
            'notify_url' => '/payment/alipay/notify',
            'return_url' => '/payment/alipay/return'
        ],
        'wechat' => [
            'app_id' => '',
            'mch_id' => '',
            'key' => '',
            'cert_path' => '',
            'key_path' => '',
            'notify_url' => '/payment/wechat/notify'
        ]
    ],
    'timeout' => 300,
    'retry_attempts' => 3
];