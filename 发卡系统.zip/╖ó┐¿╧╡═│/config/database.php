<?php
/**
 * 数据库配置文件 - 支持读写分离
 */

return [
    // 主库配置（用于写操作）
    'master' => [
        'host' => DB_HOST,
        'port' => 3306,
        'database' => DB_NAME,
        'username' => DB_USER,
        'password' => DB_PASS,
        'charset' => DB_CHARSET
    ],
    
    // 从库配置（用于读操作）
    'slaves' => [
        [
            'host' => defined('DB_SLAVE1_HOST') ? DB_SLAVE1_HOST : 'localhost',
            'port' => defined('DB_SLAVE1_PORT') ? DB_SLAVE1_PORT : 3306,
            'database' => DB_NAME,
            'username' => DB_USER,
            'password' => DB_PASS,
            'charset' => DB_CHARSET
        ],
        [
            'host' => defined('DB_SLAVE2_HOST') ? DB_SLAVE2_HOST : 'localhost',
            'port' => defined('DB_SLAVE2_PORT') ? DB_SLAVE2_PORT : 3306,
            'database' => DB_NAME,
            'username' => DB_USER,
            'password' => DB_PASS,
            'charset' => DB_CHARSET
        ]
    ],
    
    // 数据库通用选项
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ],
    
    // 读写分离配置
    'readWriteSplitting' => [
        'enabled' => true,
        'useMasterForReads' => false, // 设置为false启用读写分离
        'loadBalanceStrategy' => 'random' // 负载均衡策略: random, round-robin
    ],
    
    // 故障转移配置
    'failover' => [
        'enabled' => true,
        'masterToSlaveOnFailure' => true, // 主库故障时使用从库
        'slaveHealthCheckInterval' => 60 // 从库健康检查间隔（秒）
    ]
];