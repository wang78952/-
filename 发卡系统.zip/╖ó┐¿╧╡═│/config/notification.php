<?php
/**
 * 通知配置文件
 */

return [
    'email' => [
        'enabled' => true,
        'smtp_host' => 'smtp.example.com',
        'smtp_port' => 587,
        'smtp_username' => '',
        'smtp_password' => '',
        'from_email' => 'noreply@example.com',
        'from_name' => APP_NAME
    ],
    'sms' => [
        'enabled' => false,
        'provider' => 'aliyun',
        'access_key' => '',
        'access_secret' => '',
        'sign_name' => '',
        'template_code' => ''
    ],
    'webhook' => [
        'enabled' => true,
        'timeout' => 30,
        'retry_attempts' => 3,
        'endpoints' => []
    ]
];