<?php
/**
 * 监控配置文件
 */

return [
    'enabled' => true,
    'error_monitoring' => [
        'enabled' => true,
        'log_file' => __DIR__ . '/../logs/error.log',
        'email_alerts' => false,
        'sms_alerts' => false,
        'threshold' => [
            'errors_per_minute' => 10,
            'errors_per_hour' => 100
        ]
    ],
    'performance_monitoring' => [
        'enabled' => true,
        'slow_query_threshold' => 1000, // 毫秒
        'memory_threshold' => 128, // MB
        'cpu_threshold' => 80 // 百分比
    ],
    'business_metrics' => [
        'enabled' => true,
        'track_orders' => true,
        'track_revenue' => true,
        'track_users' => true
    ],
    'alerts' => [
        'email' => '',
        'webhook' => '',
        'slack' => ''
    ],
    'retention' => [
        'logs_days' => 30,
        'metrics_days' => 90
    ]
];