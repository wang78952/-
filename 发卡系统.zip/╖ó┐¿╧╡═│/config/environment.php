<?php
/**
 * 环境配置文件
 * 包含系统运行所需的环境变量和常量
 */

// 应用基础配置
define('APP_NAME', '发卡系统');
define('APP_VERSION', '1.0.0');
define('DEBUG_MODE', true);
define('IS_DEVELOPMENT', DEBUG_MODE);

// 安全配置
define('ENABLE_SECURITY_MONITORING', true);
define('ALERT_EMAIL', 'admin@example.com');

// 日志配置
define('AUDIT_LOG_RETENTION_DAYS', 30);

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'card_system');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// 缓存配置
define('CACHE_ENABLED', true);
define('CACHE_DEFAULT_TTL', 3600);

// 邮件配置
define('MAIL_FROM', 'noreply@example.com');
define('MAIL_FROM_NAME', '发卡系统');

// 系统路径
define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('LOG_PATH', ROOT_PATH . '/logs');
define('CACHE_PATH', ROOT_PATH . '/cache');

// API配置
define('API_VERSION', 'v1');
define('API_RATE_LIMIT', 100); // 每分钟请求次数

// 支付配置
define('PAYMENT_TIMEOUT', 1800); // 30分钟
define('ORDER_EXPIRE_TIME', 3600); // 1小时

// 安全配置
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15分钟

/**
 * 获取环境变量
 */
function env($key, $default = null) {
    $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
    
    if ($value === false) {
        return $default;
    }
    
    // 处理布尔值
    switch (strtolower($value)) {
        case 'true':
        case '(true)':
            return true;
        case 'false':
        case '(false)':
            return false;
        case 'empty':
        case '(empty)':
            return '';
        case 'null':
        case '(null)':
            return null;
    }
    
    return $value;
}

/**
 * 检查是否为CLI环境
 */
function is_cli() {
    return php_sapi_name() === 'cli';
}

/**
 * 获取客户端IP地址
 */
function get_client_ip() {
    $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    
    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}
?>