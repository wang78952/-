<?php
/**
 * CDN配置文件
 * 管理静态资源的CDN加速配置
 */

return [
    // CDN开关
    'enabled' => true,
    
    // CDN基础URL
    'base_url' => 'https://cdn.example.com',
    
    // 资源类型配置
    'resources' => [
        'css' => [
            'base_path' => '/assets/css',
            'cache_time' => 86400, // 24小时
            'cdn_path' => '/assets/css',
            'enabled' => true
        ],
        'js' => [
            'base_path' => '/assets/js',
            'cache_time' => 86400, // 24小时
            'cdn_path' => '/assets/js',
            'enabled' => true
        ],
        'images' => [
            'base_path' => '/assets/images',
            'cache_time' => 604800, // 7天
            'cdn_path' => '/assets/images',
            'enabled' => true
        ],
        'lang' => [
            'base_path' => '/assets/lang',
            'cache_time' => 3600, // 1小时
            'cdn_path' => '/assets/lang',
            'enabled' => true
        ]
    ],
    
    // 本地开发环境配置
    'development' => [
        'enabled' => false, // 开发环境禁用CDN
        'base_url' => '' // 使用相对路径
    ],
    
    // CDN提供商配置
    'provider' => [
        'name' => 'generic', // 通用CDN配置
        'config' => [
            'ssl_verify' => true,
            'timeout' => 30,
            'headers' => []
        ]
    ],
    
    // 版本号管理
    'versioning' => [
        'enabled' => true,
        'strategy' => 'hash', // 'hash', 'timestamp', 'fixed'
        'fixed_version' => '1.0.0',
        'hash_algorithm' => 'md5',
        'file_path' => __DIR__ . '/../storage/cdn_versions.json'
    ],
    
    // 预加载配置
    'preload' => [
        'enabled' => true,
        'resources' => [
            'critical_css' => ['/assets/css/main.css', '/assets/css/responsive.css'],
            'critical_js' => ['/assets/js/main.js']
        ]
    ],
    
    // 错误处理
    'error_handling' => [
        'fallback_to_local' => true, // CDN不可用时回退到本地资源
        'retry_count' => 2,
        'retry_delay' => 100
    ]
];