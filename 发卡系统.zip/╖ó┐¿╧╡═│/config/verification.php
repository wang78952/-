<?php
/**
 * 身份核验服务配置
 */

return [
    // 身份核验服务配置
    'identity_verification' => [
        // 启用身份核验服务
        'enabled' => true,
        
        // 核验服务提供商
        'provider' => 'third_party_api', // 可选值: 'third_party_api', 'internal_service', 'mock'
        
        // 第三方API配置
        'third_party' => [
            // API基础URL
            'base_url' => 'https://api.id-verification-service.com/v2',
            
            // API密钥和密钥
            'api_key' => env('VERIFICATION_API_KEY', ''),
            'api_secret' => env('VERIFICATION_API_SECRET', ''),
            
            // 超时设置（秒）
            'timeout' => 30,
            
            // 重试次数
            'retry_count' => 2,
            
            // 重试间隔（毫秒）
            'retry_interval' => 1000,
            
            // 是否启用沙箱环境
            'sandbox' => env('VERIFICATION_SANDBOX', false),
        ],
        
        // 核验类型配置
        'verification_types' => [
            'basic' => [
                'enabled' => true,
                'fields' => ['id_card', 'name', 'phone'],
                'required_fields' => ['id_card', 'name'],
            ],
            'advanced' => [
                'enabled' => true,
                'fields' => ['id_card', 'name', 'phone', 'address', 'birthdate'],
                'required_fields' => ['id_card', 'name', 'phone'],
            ],
            'enhanced' => [
                'enabled' => false,
                'fields' => ['id_card', 'name', 'phone', 'address', 'birthdate', 'face_image'],
                'required_fields' => ['id_card', 'name', 'phone', 'face_image'],
            ],
        ],
        
        // 速率限制
        'rate_limits' => [
            // 每分钟最大请求数
            'requests_per_minute' => 60,
            // 每小时最大请求数
            'requests_per_hour' => 1000,
            // 每天最大请求数
            'requests_per_day' => 10000,
        ],
        
        // 缓存设置
        'cache' => [
            'enabled' => true,
            'ttl' => 3600, // 缓存有效期（秒）
        ],
        
        // 日志级别
        'log_level' => 'info', // 可选值: 'debug', 'info', 'warning', 'error'
        
        // 失败处理策略
        'failover' => [
            // 启用失败转移
            'enabled' => true,
            // 备用服务
            'backup_provider' => 'mock',
        ],
    ],
    
    // 反欺诈配置
    'fraud_detection' => [
        'enabled' => true,
        
        // 风险评分阈值
        'risk_thresholds' => [
            'low' => 0,
            'medium' => 60,
            'high' => 80,
        ],
        
        // 规则配置
        'rules' => [
            // 同一IP地址最大核验次数
            'max_verifications_per_ip' => 10,
            // 同一手机号最大核验次数
            'max_verifications_per_phone' => 3,
            // 同一身份证号最大核验次数
            'max_verifications_per_id' => 1,
        ],
    ],
    
    // 合规配置
    'compliance' => [
        // 数据保留期限（天）
        'data_retention_days' => 180,
        
        // 数据加密
        'encryption' => [
            'enabled' => true,
            'algorithm' => 'aes-256-cbc',
        ],
        
        // 审计日志
        'audit_logging' => [
            'enabled' => true,
            'log_all_access' => true,
        ],
    ],
];