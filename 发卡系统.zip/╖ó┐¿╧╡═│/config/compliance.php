<?php
/**
 * 合规配置文件
 */

return [
    'data_retention' => [
        'orders' => 365, // 天数
        'logs' => 90,
        'user_data' => 2555 // 7年
    ],
    'privacy' => [
        'anonymize_after_days' => 365,
        'delete_request_timeout' => 30 // 天
    ],
    'audit' => [
        'enabled' => true,
        'log_all_actions' => true,
        'retention_days' => 2555
    ],
    'gdpr' => [
        'enabled' => true,
        'cookie_consent' => true,
        'data_portability' => true
    ],
    'legal' => [
        'terms_required' => true,
        'privacy_policy_required' => true,
        'age_verification' => false
    ]
];