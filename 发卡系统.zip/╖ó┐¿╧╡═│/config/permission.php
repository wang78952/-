<?php
/**
 * 权限配置文件
 */

return [
    'roles' => [
        'admin' => [
            'name' => '管理员',
            'permissions' => ['*']
        ],
        'user' => [
            'name' => '用户',
            'permissions' => [
                'cards.view',
                'cards.create',
                'orders.view',
                'orders.create'
            ]
        ],
        'guest' => [
            'name' => '访客',
            'permissions' => [
                'cards.view'
            ]
        ]
    ],
    'permissions' => [
        'cards.view' => '查看卡密',
        'cards.create' => '创建卡密',
        'cards.edit' => '编辑卡密',
        'cards.delete' => '删除卡密',
        'orders.view' => '查看订单',
        'orders.create' => '创建订单',
        'orders.edit' => '编辑订单',
        'orders.delete' => '删除订单',
        'users.view' => '查看用户',
        'users.edit' => '编辑用户',
        'system.admin' => '系统管理'
    ],
    'default_role' => 'user'
];