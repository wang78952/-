<?php
/**
 * IP地址配置文件
 * 包含地理位置验证、可信代理、IP过滤等配置
 */

// 启用地理位置验证
define('ENABLE_GEOIP_VERIFICATION', true);

// 启用IP地址过滤
define('ENABLE_IP_FILTERING', true);

// 允许的国家/地区列表（ISO 3166-1 alpha-2 代码）
// 例如：['CN', 'US', 'JP', 'KR', 'SG'] 只允许中国、美国、日本、韩国和新加坡的用户访问
$allowedCountries = [
    'CN' // 默认只允许中国大陆访问
];

// 可信代理IP列表
// 如果服务器前面有代理服务器（如Nginx、Cloudflare等），需要将这些代理IP添加到列表中
$trustedProxies = [
    // '127.0.0.1', // 本地代理
    // '10.0.0.1',  // 内部代理
    // '172.16.0.1', // 内部网络
    // '192.168.1.1' // 内部网络
];

// 检测VPN/代理的敏感度级别
// 'low' - 较低敏感度，减少误判
// 'medium' - 中等敏感度，平衡安全性和用户体验
// 'high' - 高敏感度，可能增加误判
$proxyDetectionLevel = 'medium';

// 是否阻止已知的VPN/代理IP
$blockProxies = false;

// 是否阻止Tor出口节点
$blockTorExitNodes = true;

// 是否启用IP信誉检查
$enableIpReputationCheck = true;

// IP信誉阈值（0-100）
// 如果IP的风险评分高于此阈值，将被阻止
$ipRiskScoreThreshold = 70;

// IP地理位置数据库配置
$geoipConfig = [
    'type' => 'auto', // 'maxmind', 'ip2location', 'api', 'auto'
    'maxmind_db_path' => __DIR__ . '/GeoLite2-City.mmdb',
    'ip2location_db_path' => __DIR__ . '/IP2LOCATION-LITE-DB11.BIN',
    
    // 第三方API配置
    'api_providers' => [
        'ip_api' => [
            'enabled' => true,
            'url' => 'http://ip-api.com/json/',
            'fields' => 'status,country,countryCode,region,regionName,city,lat,lon,isp,org,timezone'
        ],
        'ipinfo' => [
            'enabled' => false,
            'url' => 'https://ipinfo.io/',
            'token' => '', // 如果有API密钥，请在此处填写
            'timeout' => 3
        ],
        'geoip_lookup' => [
            'enabled' => false,
            'url' => 'https://freegeoip.app/json/',
            'timeout' => 3
        ]
    ],
    
    // 缓存设置
    'cache_ttl' => 86400, // 缓存时间，单位秒（24小时）
    'fallback_to_next' => true // 当前一种方法失败时，是否尝试下一种方法
];

// IP地址白名单
// 这些IP地址将绕过所有IP相关的限制和检查
$ipWhitelist = [
    '127.0.0.1', // 本地主机
    // '10.0.0.0/8', // 内部网络
    // '192.168.0.0/16', // 内部网络
    // '172.16.0.0/12' // 内部网络
];

// IP地址黑名单
// 这些IP地址将被直接阻止
$ipBlacklist = [
    // '1.2.3.4', // 示例IP
    // '5.6.7.8'  // 示例IP
];

// 动态IP检查间隔（秒）
// 如果用户IP地址发生变化，需要重新验证身份的时间间隔
$ipChangeVerificationInterval = 3600; // 1小时

// 是否记录地理位置信息到日志
$logGeolocationInfo = true;

// 是否保存用户IP地址历史
$saveIpHistory = true;

// IP历史保存天数
$ipHistoryRetentionDays = 30;

// 是否启用异常登录检测
$enableUnusualLoginDetection = true;

// 异常登录检测的时间范围（分钟）
$unusualLoginTimeWindow = 30; // 30分钟内

// 异常登录检测的地理位置阈值（公里）
// 如果两次登录的地理位置距离超过此阈值，则视为异常登录
$unusualLoginDistanceThreshold = 500; // 500公里

// 是否限制登录尝试次数
$limitLoginAttempts = true;

// 登录尝试次数限制
$loginAttemptsLimit = 5;

// 登录尝试限制的时间窗口（分钟）
$loginAttemptsWindow = 15;

// 登录限制后的封禁时间（分钟）
$loginBlockTime = 30;

// 获取IP配置的函数
if (!function_exists('getIpConfig')) {
    function getIpConfig() {
        return [
            'enabled' => ENABLE_GEOIP_VERIFICATION,
            'filtering' => ENABLE_IP_FILTERING,
            'allowedCountries' => $allowedCountries,
            'trustedProxies' => $trustedProxies,
            'proxyDetectionLevel' => $proxyDetectionLevel,
            'blockProxies' => $blockProxies,
            'blockTorExitNodes' => $blockTorExitNodes,
            'enableIpReputation' => $enableIpReputationCheck,
            'riskScoreThreshold' => $ipRiskScoreThreshold,
            'geoipConfig' => $geoipConfig,
            'whitelist' => $ipWhitelist,
            'blacklist' => $ipBlacklist,
            'ipChangeInterval' => $ipChangeVerificationInterval,
            'logGeolocation' => $logGeolocationInfo,
            'saveHistory' => $saveIpHistory,
            'historyRetention' => $ipHistoryRetentionDays,
            'enableUnusualLogin' => $enableUnusualLoginDetection,
            'loginTimeWindow' => $unusualLoginTimeWindow,
            'loginDistanceThreshold' => $unusualLoginDistanceThreshold,
            'limitLoginAttempts' => $limitLoginAttempts,
            'loginAttemptsLimit' => $loginAttemptsLimit,
            'loginAttemptsWindow' => $loginAttemptsWindow,
            'loginBlockTime' => $loginBlockTime
        ];
    }
}