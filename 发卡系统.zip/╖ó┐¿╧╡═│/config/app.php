<?php
/**
 * 应用配置文件
 */

return [
    'name' => APP_NAME,
    'version' => APP_VERSION,
    'debug' => DEBUG_MODE,
    'timezone' => 'Asia/Shanghai',
    'locale' => 'zh-CN',
    'charset' => 'UTF-8',
    'session' => [
        'lifetime' => 3600,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true
    ],
    'logging' => [
        'enabled' => true,
        'level' => 'info',
        'file' => __DIR__ . '/../logs/app.log',
        'max_files' => 30
    ],
    'maintenance_mode' => [
        'enabled' => false, // 默认为关闭状态
        'maintenance_page' => __DIR__ . '/../public/maintenance.html',
        'allowed_ips' => ['127.0.0.1'], // 允许访问的IP白名单
        'admin_notification' => true,
        'notification_email' => 'admin@example.com',
        'message' => '系统正在进行例行维护，预计维护时间为15分钟。给您带来的不便，敬请谅解。',
        'planned_maintenance' => [
            'enabled' => false,
            'start_time' => null,
            'end_time' => null,
            'auto_activate' => false
        ],
        'emergency_override' => [
            'enabled' => false,
            'reason' => null,
            'activated_by' => null,
            'activated_at' => null
        ]
    ]
];