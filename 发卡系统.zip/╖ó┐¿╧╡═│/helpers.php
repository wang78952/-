<?php
/**
 * 全局辅助函数库
 * 提供常用的工具函数和便捷方法
 */

/**
 * 生成随机字符串
 * @param int $length 长度
 * @param string $type 类型：alnum（字母数字）、alpha（字母）、numeric（数字）
 * @return string
 */
function generateRandomString($length = 32, $type = 'alnum') {
    switch ($type) {
        case 'alpha':
            $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'numeric':
            $characters = '0123456789';
            break;
        case 'alnum':
        default:
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
    }
    
    $charactersLength = strlen($characters);
    $randomString = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    
    return $randomString;
}

/**
 * 生成订单号
 * @param string $prefix 前缀
 * @return string
 */
function generateOrderNumber($prefix = 'ORD') {
    $timestamp = date('YmdHis');
    $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    return $prefix . $timestamp . $random;
}

/**
 * 生成交易号
 * @param string $prefix 前缀
 * @return string
 */
function generateTransactionNumber($prefix = 'TRX') {
    $timestamp = date('YmdHis');
    $random = str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
    return $prefix . $timestamp . $random;
}

/**
 * 格式化金额
 * @param float $amount 金额
 * @param int $decimals 小数位数
 * @return string
 */
function formatAmount($amount, $decimals = 2) {
    return number_format($amount, $decimals, '.', '');
}

/**
 * 格式化日期时间
 * @param string $datetime 日期时间
 * @param string $format 格式
 * @return string
 */
function formatDateTime($datetime = null, $format = 'Y-m-d H:i:s') {
    if ($datetime === null) {
        $datetime = 'now';
    }
    
    $date = new DateTime($datetime);
    return $date->format($format);
}

/**
 * 计算两个日期之间的天数差
 * @param string $date1 日期1
 * @param string $date2 日期2
 * @return int
 */
function dateDiff($date1, $date2) {
    $datetime1 = new DateTime($date1);
    $datetime2 = new DateTime($date2);
    $interval = $datetime1->diff($datetime2);
    return $interval->days;
}

/**
 * 验证手机号格式
 * @param string $phone 手机号
 * @return bool
 */
function validatePhone($phone) {
    return preg_match('/^1[3-9]\d{9}$/', $phone);
}

/**
 * 验证邮箱格式
 * @param string $email 邮箱
 * @return bool
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * 验证身份证号格式
 * @param string $idCard 身份证号
 * @return bool
 */
function validateIdCard($idCard) {
    return preg_match('/^\d{17}[\dXx]$/', $idCard);
}

/**
 * 隐藏手机号中间4位
 * @param string $phone 手机号
 * @return string
 */
function maskPhone($phone) {
    return preg_replace('/(\d{3})\d{4}(\d{4})/', '$1****$2', $phone);
}

/**
 * 隐藏邮箱部分字符
 * @param string $email 邮箱
 * @return string
 */
function maskEmail($email) {
    $parts = explode('@', $email);
    $name = $parts[0];
    $domain = $parts[1];
    
    if (strlen($name) <= 2) {
        $maskedName = str_repeat('*', strlen($name));
    } else {
        $maskedName = substr($name, 0, 2) . str_repeat('*', strlen($name) - 2);
    }
    
    return $maskedName . '@' . $domain;
}

/**
 * 获取客户端IP地址
 * @return string
 */
function getClientIp() {
    // 确保IPAddressManager类已加载
    if (!class_exists('IPAddressManager')) {
        require_once __DIR__ . '/includes/IPAddressManager.php';
    }
    
    // 使用IPAddressManager获取客户端IP
    $ipManager = getIPManager();
    return $ipManager->getClientIP();
}

/**
 * 获取用户代理字符串
 * @return string
 */
function getUserAgent() {
    return $_SERVER['HTTP_USER_AGENT'] ?? '';
}

/**
 * 生成UUID
 * @return string
 */
function generateUuid() {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff)
    );
}

/**
 * 加密密码
 * @param string $password 密码
 * @return string
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID);
}

/**
 * 验证密码
 * @param string $password 密码
 * @param string $hash 哈希值
 * @return bool
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * 生成JWT Token
 * @param array $payload 载荷
 * @param string $secret 密钥
 * @param int $expire 过期时间（秒）
 * @return string
 */
function generateJwtToken($payload, $secret, $expire = 3600) {
    $header = json_encode(array('typ' => 'JWT', 'alg' => 'HS256'));
    $payload['exp'] = time() + $expire;
    $payload['iat'] = time();
    
    $base64UrlHeader = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($header));
    $base64UrlPayload = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode(json_encode($payload)));
    
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
    $base64UrlSignature = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($signature));
    
    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

/**
 * 验证JWT Token
 * @param string $token Token
 * @param string $secret 密钥
 * @return array|false
 */
function verifyJwtToken($token, $secret) {
    $parts = explode('.', $token);
    
    if (count($parts) !== 3) {
        return false;
    }
    
    $header = base64_decode(str_replace(array('-', '_'), array('+', '/'), $parts[0]));
    $payload = base64_decode(str_replace(array('-', '_'), array('+', '/'), $parts[1]));
    $signature = $parts[2];
    
    $payloadData = json_decode($payload, true);
    
    if (!$payloadData || !isset($payloadData['exp'])) {
        return false;
    }
    
    if ($payloadData['exp'] < time()) {
        return false;
    }
    
    $base64UrlHeader = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($header));
    $base64UrlPayload = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($payload));
    
    $expectedSignature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
    $base64UrlExpectedSignature = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($expectedSignature));
    
    if (hash_equals($signature, $base64UrlExpectedSignature)) {
        return $payloadData;
    }
    
    return false;
}

/**
 * 发送HTTP请求
 * @param string $url URL
 * @param array $options 选项
 * @return array
 */
function httpRequest($url, $options = array()) {
    $defaultOptions = array(
        'method' => 'GET',
        'headers' => array(),
        'data' => null,
        'timeout' => 30,
        'verify_ssl' => true
    );
    
    $options = array_merge($defaultOptions, $options);
    
    $ch = curl_init();
    
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $options['timeout'],
        CURLOPT_SSL_VERIFYPEER => $options['verify_ssl'],
        CURLOPT_SSL_VERIFYHOST => $options['verify_ssl'] ? 2 : 0,
        CURLOPT_CUSTOMREQUEST => $options['method']
    ));
    
    if (!empty($options['headers'])) {
        $headers = array();
        foreach ($options['headers'] as $key => $value) {
            $headers[] = $key . ': ' . $value;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    
    if ($options['data'] !== null) {
        if (is_array($options['data'])) {
            $options['data'] = json_encode($options['data']);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($options['data'])
            ));
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $options['data']);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    
    curl_close($ch);
    
    return array(
        'success' => !$error,
        'http_code' => $httpCode,
        'response' => $response,
        'error' => $error
    );
}

/**
 * 记录日志
 * @param string $level 日志级别
 * @param string $message 消息
 * @param array $context 上下文
 */
function logMessage($level, $message, $context = array()) {
    $timestamp = date('Y-m-d H:i:s');
    $ip = getClientIp();
    $userAgent = getUserAgent();
    
    $logEntry = array(
        'timestamp' => $timestamp,
        'level' => $level,
        'message' => $message,
        'ip' => $ip,
        'user_agent' => $userAgent
    );
    
    if (!empty($context)) {
        $logEntry['context'] = $context;
    }
    
    $logLine = json_encode($logEntry, JSON_PRETTY_PRINT) . PHP_EOL;
    
    $logFile = __DIR__ . '/logs/app.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
}

/**
 * 调试输出
 * @param mixed $data 数据
 * @param bool $die 是否终止执行
 */
function debug($data, $die = false) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    
    if ($die) {
        die();
    }
}

/**
 * 重定向
 * @param string $url URL
 * @param int $statusCode 状态码
 */
function redirect($url, $statusCode = 302) {
    header("Location: {$url}", true, $statusCode);
    exit;
}

/**
 * 获取当前URL
 * @return string
 */
function getCurrentUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $uri = $_SERVER['REQUEST_URI'];
    
    return $protocol . '://' . $host . $uri;
}

/**
 * 截取字符串
 * @param string $string 字符串
 * @param int $length 长度
 * @param string $suffix 后缀
 * @return string
 */
function truncateString($string, $length, $suffix = '...') {
    if (mb_strlen($string, 'UTF-8') <= $length) {
        return $string;
    }
    
    return mb_substr($string, 0, $length, 'UTF-8') . $suffix;
}

/**
 * 转换为驼峰命名
 * @param string $string 字符串
 * @return string
 */
function toCamelCase($string) {
    return str_replace(' ', '', ucwords(str_replace('_', ' ', $string)));
}

/**
 * 转换为下划线命名
 * @param string $string 字符串
 * @return string
 */
function toSnakeCase($string) {
    return strtolower(preg_replace('/([A-Z])/', '_$1', $string));
}

/**
 * 获取CDN资源URL
 * @param string $path 资源相对路径
 * @param string $type 资源类型 (css, js, images, lang)
 * @return string 完整的资源URL
 */
function asset($path, $type = null) {
    try {
        // 确保CDNManager类已加载
        if (!class_exists('CDNManager')) {
            require_once __DIR__ . '/includes/CDNManager.php';
        }
        
        $cdnManager = CDNManager::getInstance();
        return $cdnManager->getResourceUrl($path, $type);
    } catch (Exception $e) {
        // 出错时返回原始路径
        return $path;
    }
}

/**
 * 生成CDN预加载标签
 * @return string HTML标签字符串
 */
function cdn_preload_tags() {
    try {
        // 确保CDNManager类已加载
        if (!class_exists('CDNManager')) {
            require_once __DIR__ . '/includes/CDNManager.php';
        }
        
        $cdnManager = CDNManager::getInstance();
        return $cdnManager->generatePreloadTags();
    } catch (Exception $e) {
        return '';
    }
}

/**
 * 清除CDN缓存
 * @param string $path 特定资源路径，如果为null则清除所有
 * @return bool 是否成功
 */
function cdn_clear_cache($path = null) {
    try {
        // 确保CDNManager类已加载
        if (!class_exists('CDNManager')) {
            require_once __DIR__ . '/includes/CDNManager.php';
        }
        
        $cdnManager = CDNManager::getInstance();
        return $cdnManager->clearCache($path);
    } catch (Exception $e) {
        return false;
    }
}
?>