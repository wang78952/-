<template>
  <div class="search-results-container">
    <!-- 搜索面包屑 -->
    <div class="search-breadcrumb">
      <span class="breadcrumb-home" @click="navigateToHome">首页</span>
      <span class="breadcrumb-separator">/</span>
      <span class="breadcrumb-current">搜索: {{ searchKeyword }}</span>
    </div>
    
    <div class="search-results-content">
      <!-- 左侧过滤面板 --</
      <div class="filter-panel">
        <div class="filter-panel-header">
          <span class="filter-title">筛选条件</span>
          <button 
            v-if="hasActiveFilters" 
            class="clear-filters" 
            @click="clearAllFilters"
          >
            清空筛选
          </button>
        </div>
        
        <!-- 价格区间过滤 -->
        <div class="filter-section">
          <div class="filter-section-title">价格区间</div>
          <div class="price-filter">
            <input 
              v-model.number="priceRange.min" 
              type="number" 
              placeholder="最低价" 
              class="price-input"
              @change="applyFilters"
            />
            <span class="price-separator">-</span>
            <input 
              v-model.number="priceRange.max" 
              type="number" 
              placeholder="最高价" 
              class="price-input"
              @change="applyFilters"
            />
            <button class="price-apply" @click="applyFilters">确定</button>
          </div>
        </div>
        <!-- 分类过滤 -->
        <div class="filter-section">
          <div class="filter-section-title">卡密分类</div>
          <div class="filter-options">
            <label 
              v-for="category in categories" 
              :key="`category-${category.id}`" 
              class="filter-option"
            >
              <input 
                type="checkbox" 
                :value="category.id" 
                v-model="selectedCategories"
                @change="applyFilters"
              />
              <span class="filter-option-text">{{ category.name }}</span>
              <span class="filter-option-count">({{ category.count }})</span>
            </label>
          </div>
        </div>
        <!-- 品牌过滤 -->
        <div class="filter-section">
          <div class="filter-section-title">发行商</div>
          <div class="filter-options">
            <label 
              v-for="brand in brands" 
              :key="`brand-${brand.id}`" 
              class="filter-option"
            >
              <input 
                type="checkbox" 
                :value="brand.id" 
                v-model="selectedBrands"
                @change="applyFilters"
              />
              <span class="filter-option-text">{{ brand.name }}</span>
              <span class="filter-option-count">({{ brand.count }})</span>
            </label>
          </div>
        <div class="filter-section">
          <div class="filter-section-title">评分</div>
          <div class="filter-options">
            <label 
              v-for="rating in ratings" 
              :key="`rating-${rating.value}`" 
              class="filter-option"
            >
              <input 
                type="radio" 
                name="rating" 
                :value="rating.value" 
                v-model="selectedRating"
                @change="applyFilters"
              />
              <span class="filter-option-text">
                <span class="rating-stars">
                  <span 
                    v-for="star in 5" 
                    :key="star"
                    class="star" 
                    :class="{ filled: star <= rating.stars }"
                  >★</span>
                  <span class="rating-text">及以上</span>
                </span>
              </span>
            </label>
          </div>
        </div>
        <!-- 标签过滤 --</
        <div class="filter-section">
          <div class="filter-section-title">热门标签</div>
          <div class="tag-filters">
            <span 
              v-for="tag in tags" 
              :key="`tag-${tag.id}`" 
              class="tag-filter"
              :class="{ active: selectedTags.includes(tag.id) }"
              @click="toggleTag(tag.id)"
            >
              {{ tag.name }}
              <span class="tag-count">({{ tag.count }})</span>
            </span>
          </div>
        </div>
      </div>
      <!-- 右侧搜索结果 --</
      <div class="results-content">
        <!-- 搜索统计和排序 --</
        <div class="search-stats-sort">
          <div class="search-stats">
            <span v-if="searchKeyword">"{{ searchKeyword }}"的搜索结果共 <strong>{{ totalResults }}</strong> 项</span>
            <span v-else>全部商品共 <strong>{{ totalResults }}</strong> 项</span>
          </div>
          <div class="search-sort">
            <span class="sort-label">排序方式:</span>
            <select v-model="sortBy" @change="applySort">
              <option value="relevance">相关度优先</option>
              <option value="price_asc">价格从低到高</option>
              <option value="price_desc">价格从高到低</option>
              <option value="sales_desc">销量优先</option>
              <option value="rating_desc">评分优先</option>
              <option value="newest">最新上架</option>
            </select>
            <div class="view-toggle">
              <button 
                class="view-btn" 
                :class="{ active: viewMode === 'grid' }" 
                @click="viewMode = 'grid'"
                title="网格视图"
              ><i class="icon-grid"></i></button>
              <button 
                class="view-btn" 
                :class="{ active: viewMode === 'list' }" 
                @click="viewMode = 'list'"
                title="列表视图"
              ><i class="icon-list"></i></button>
            </div>
          </div>
        </div>
        <!-- 已选筛选条件标签 -->
        <div v-if="activeFilterTags.length > 0" class="active-filters">
          <span class="active-filters-title">已选筛选条件:</span>
          <span 
            v-for="(tag, index) in activeFilterTags" 
            :key="`active-${index}`" 
            class="active-filter-tag"
          >
            {{ tag.text }}
            <button class="remove-filter" @click="removeFilter(tag.type, tag.value)">×</button>
          </span>
        </div>
        <!-- 商品列表 --</
        <div v-if="loading" class="loading-container">
          <div class="loading-spinner"></div>
          <div class="loading-text">加载中...</div>
        </div>
        <div v-else-if="products.length > 0" :class="['products-list', viewMode]">
          <div 
            v-for="product in products" 
            :key="`product-${product.id}`" 
            class="product-item"
            @click="navigateToProduct(product.id)"
          <!-- 网格视图 -->
          <div class="product-grid">
            <div class="product-image">
              <img :src="product.image" :alt="product.name" />
              <div v-if="product.discount" class="discount-badge">{{ product.discount }}折</div>
            </div>
            <div class="product-info">
              <div class="product-category">{{ product.category }}</div>
              <div class="product-name">{{ product.name }}</div>
              <div class="product-rating">
                <span class="rating-stars">
                  <span 
                    v-for="star in 5" 
                    :key="star"
                    class="star" 
                    :class="{ filled: star <= product.rating }"
                  >★</span>
                  <span class="rating-value">{{ product.rating }}</span>
                </span>
                <span class="rating-count">({{ product.reviewCount }}条评价)</span>
              </div>
              <div class="product-price">
                <span class="current-price">¥{{ product.price }}</span>
                <span v-if="product.originalPrice" class="original-price">¥{{ product.originalPrice }}</span>
              </div>
              <div class="product-sales">已售 {{ product.sales }} 件</div>
              <div class="product-tags">
                <span v-for="(tag, index) in product.tags" :key="index" class="product-tag">{{ tag }}</span>
              </div>
            </div>
          </div>
          <!-- 列表视图 -->
          <div class="product-list-item">
            <div class="product-list-image">
              <img :src="product.image" :alt="product.name" />
              <div v-if="product.discount" class="discount-badge">{{ product.discount }}折</div>
            <div class="product-list-info">
              <div class="product-list-header">
                <div class="product-list-category">{{ product.category }} / {{ product.brand }}</div>
                <div class="product-list-name">{{ product.name }}</div>
                <div class="product-list-description">{{ product.description }}</div>
              <div class="product-list-details">
                <div class="product-list-tags">
                  <span v-for="(tag, index) in product.tags" :key="index" class="product-tag">{{ tag }}</span>
                <div class="product-list-rating">
                  <span class="rating-stars">
                    <span 
                      v-for="star in 5" 
                      :key="star"
                      class="star" 
                      :class="{ filled: star <= product.rating }"
                    >★</span>
                    <span class="rating-value">{{ product.rating }}</span>
                  </span>
                  <span class="rating-count">({{ product.reviewCount }}条评价)</span>
                <div class="product-list-sales">已售 {{ product.sales }} 件</div>
              <div class="product-list-price">
                <span class="current-price">¥{{ product.price }}</span>
                <span v-if="product.originalPrice" class="original-price">¥{{ product.originalPrice }}</span>
                <button class="add-to-cart-btn">加入购物车</button>
              </div>
            </div>
          </div>
        </div>
        <div v-else class="no-results">
          <div class="no-results-icon"><i class="icon-search-large"></i></div>
          <div class="no-results-title">暂无相关商品</div>
          <div class="no-results-text">换个关键词试试吧，或浏览推荐商品</div>
          <button class="browse-recommendations" @click="browseRecommendations">查看推荐商品</button>
        </div>
        <!-- 分页 --</
        <div v-if="!loading && totalPages > 1" class="pagination">
          <button 
            class="pagination-btn" 
            :disabled="currentPage === 1" 
            @click="goToPage(1)"
          >首页</button>
          <button 
            class="pagination-btn" 
            :disabled="currentPage === 1" 
            @click="goToPage(currentPage - 1)"
          >上一页</button>
          <button 
            v-for="page in visiblePages" 
            :key="page" 
            class="pagination-btn" 
            :class="{ active: page === currentPage }" 
            @click="goToPage(page)"
          >{{ page }}</button>
          <button 
            class="pagination-btn" 
            :disabled="currentPage === totalPages" 
            @click="goToPage(currentPage + 1)"
          >下一页</button>
          <button 
            class="pagination-btn" 
            :disabled="currentPage === totalPages" 
            @click="goToPage(totalPages)"
          >末页</button>
          <div class="pagination-info">
            共 {{ totalPages }} 页，到第 
            <input 
              type="number" 
              v-model.number="targetPage" 
              min="1" 
              :max="totalPages" 
              class="page-input"
              @change="goToPage(targetPage)"
            /
            页
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { searchService } from '@/services/searchService';
import { sortingFilteringService } from '@/services/sortingFilteringService';

export default {
  name: 'SearchResults',
  setup() {
    const route = useRoute();
    const router = useRouter();
    
    // 搜索参数
    const searchKeyword = ref('');
    const currentPage = ref(1);
    const pageSize = ref(20);
    const totalResults = ref(0);
    const totalPages = ref(0);
    const targetPage = ref(1);
    const loading = ref(false);
    const viewMode = ref('grid'); // grid, list
    
    // 排序参数
    const sortBy = ref('relevance');
    
    // 过滤参数
    const priceRange = ref({ min: null, max: null });
    const selectedCategories = ref([]);
    const selectedBrands = ref([]);
    const selectedRating = ref(null);
    const selectedTags = ref([]);
    
    // 数据
    const products = ref([]);
    const categories = ref([]);
    const brands = ref([]);
    const tags = ref([]);
    
    // 评分选项
    const ratings = ref([
      { value: 4, stars: 4, text: '4分及以上' },
      { value: 3, stars: 3, text: '3分及以上' },
      { value: 2, stars: 2, text: '2分及以上' },
      { value: 1, stars: 1, text: '1分及以上' },
    ]);
    
    // 计算可见的分页页码
    const visiblePages = computed(() => {
      const total = totalPages.value;
      const current = currentPage.value;
      const pages = [];
      
      let start = Math.max(1, current - 2);
      let end = Math.min(total, start + 4);
      
      if (end - start < 4) {
        start = Math.max(1, end - 4);
      }
      
      for (let i = start; i <= end; i++) {
        pages.push(i);
      }
      
      return pages;
    });
    
    // 判断是否有激活的筛选条件
    const hasActiveFilters = computed(() => {
      return (
        (priceRange.value.min !== null && priceRange.value.min > 0) ||
        (priceRange.value.max !== null && priceRange.value.max > 0) ||
        selectedCategories.value.length > 0 ||
        selectedBrands.value.length > 0 ||
        selectedRating.value !== null ||
        selectedTags.value.length > 0
      );
    });
    
    // 生成已选筛选条件标签
    const activeFilterTags = computed(() => {
      const tags = [];
      
      // 价格范围
      if (priceRange.value.min !== null && priceRange.value.max !== null) {
        tags.push({
          type: 'price',
          value: 'range',
          text: `价格: ¥${priceRange.value.min}-¥${priceRange.value.max}`
        });
      } else if (priceRange.value.min !== null) {
        tags.push({
          type: 'price',
          value: 'min',
          text: `价格: ≥¥${priceRange.value.min}`
        });
      } else if (priceRange.value.max !== null) {
        tags.push({
          type: 'price',
          value: 'max',
          text: `价格: ≤¥${priceRange.value.max}`
        });
      }
      
      // 分类
      selectedCategories.value.forEach(catId => {
        const category = categories.value.find(c => c.id === catId);
        if (category) {
          tags.push({
            type: 'category',
            value: catId,
            text: `分类: ${category.name}`
          });
        }
      });
      
      // 品牌
      selectedBrands.value.forEach(brandId => {
        const brand = brands.value.find(b => b.id === brandId);
        if (brand) {
          tags.push({
            type: 'brand',
            value: brandId,
            text: `品牌: ${brand.name}`
          });
        }
      });
      
      // 评分
      if (selectedRating.value !== null) {
        const rating = ratings.value.find(r => r.value === selectedRating.value);
        if (rating) {
          tags.push({
            type: 'rating',
            value: selectedRating.value,
            text: rating.text
          });
        }
      }
      
      // 标签
      selectedTags.value.forEach(tagId => {
        const tag = tags.value.find(t => t.id === tagId);
        if (tag) {
          tags.push({
            type: 'tag',
            value: tagId,
            text: tag.name
          });
        }
      });
      
      return tags;
    });
    
    // 加载搜索结果
    const loadSearchResults = async () => {
      loading.value = true;
      
      try {
        // 构建筛选参数
        const filters = {
          keyword: searchKeyword.value,
          page: currentPage.value,
          page_size: pageSize.value,
          sort_by: sortBy.value,
          price_min: priceRange.value.min,
          price_max: priceRange.value.max,
          categories: selectedCategories.value,
          brands: selectedBrands.value,
          rating: selectedRating.value,
          tags: selectedTags.value
        };
        
        const results = await searchService.search(filters);
        
        products.value = results.products || [];
        totalResults.value = results.total || 0;
        totalPages.value = Math.ceil(totalResults.value / pageSize.value);
        targetPage.value = currentPage.value;
        
        // 加载分面数据（分类、品牌、标签等）
        const facets = results.facets || {};
        categories.value = facets.categories || [];
        brands.value = facets.brands || [];
        tags.value = facets.tags || [];
        
      } catch (error) {
        console.error('加载搜索结果失败:', error);
        // 使用模拟数据
        loadMockData();
      } finally {
        loading.value = false;
      }
    };
    
    // 加载模拟数据
    const loadMockData = () => {
      // 模拟商品数据
      const mockProducts = [];
      for (let i = 1; i <= 20; i++) {
        mockProducts.push({
          id: i,
          name: `腾讯Q币充值卡 ${i}00元 ${i}折优惠`,
          description: `官方正版腾讯Q币充值卡，支持QQ游戏、腾讯视频、王者荣耀等腾讯旗下所有游戏及服务的充值。`,
          image: `/images/products/qcoin-${i}.jpg`,
          price: 88 + i,
          originalPrice: 100 + i,
          discount: 8.8,
          category: '游戏点卡',
          brand: '腾讯',
          rating: 4.5 + (i % 10) / 10,
          reviewCount: 1234 + i * 100,
          sales: 5678 + i * 1000,
          tags: ['官方授权', '自动发货', '即时到账']
        });
      }
      
      products.value = mockProducts;
      totalResults.value = 120;
      totalPages.value = 6;
      targetPage.value = currentPage.value;
      
      // 模拟分面数据
      categories.value = [
        { id: 1, name: '游戏点卡', count: 150 },
        { id: 2, name: '手机充值', count: 120 },
        { id: 3, name: '视频会员', count: 80 },
        { id: 4, name: '音乐会员', count: 60 },
        { id: 5, name: '软件激活', count: 40 }
      ];
      
      brands.value = [
        { id: 1, name: '腾讯', count: 90 },
        { id: 2, name: '网易', count: 60 },
        { id: 3, name: '完美世界', count: 40 },
        { id: 4, name: '盛大', count: 30 },
        { id: 5, name: '久游', count: 20 }
      ];
      
      tags.value = [
        { id: 1, name: '官方授权', count: 200 },
        { id: 2, name: '自动发货', count: 180 },
        { id: 3, name: '即时到账', count: 150 },
        { id: 4, name: '特价优惠', count: 80 },
        { id: 5, name: '新用户专享', count: 50 }
      ];
    };
    
    // 应用排序
    const applySort = () => {
      currentPage.value = 1;
      loadSearchResults();
    };
    
    // 应用筛选
    const applyFilters = () => {
      currentPage.value = 1;
      loadSearchResults();
    };
    
    // 切换标签筛选
    const toggleTag = (tagId) => {
      const index = selectedTags.value.indexOf(tagId);
      if (index >= 0) {
        selectedTags.value.splice(index, 1);
      } else {
        selectedTags.value.push(tagId);
      }
      applyFilters();
    };
    
    // 移除特定筛选条件
    const removeFilter = (type, value) => {
      switch (type) {
        case 'price':
          if (value === 'range' || value === 'min') {
            priceRange.value.min = null;
          }
          if (value === 'range' || value === 'max') {
            priceRange.value.max = null;
          }
          break;
        case 'category':
          const catIndex = selectedCategories.value.indexOf(value);
          if (catIndex >= 0) {
            selectedCategories.value.splice(catIndex, 1);
          }
          break;
        case 'brand':
          const brandIndex = selectedBrands.value.indexOf(value);
          if (brandIndex >= 0) {
            selectedBrands.value.splice(brandIndex, 1);
          }
          break;
        case 'rating':
          selectedRating.value = null;
          break;
        case 'tag':
          const tagIndex = selectedTags.value.indexOf(value);
          if (tagIndex >= 0) {
            selectedTags.value.splice(tagIndex, 1);
          }
          break;
      }
      applyFilters();
    };
    
    // 清空所有筛选条件
    const clearAllFilters = () => {
      priceRange.value.min = null;
      priceRange.value.max = null;
      selectedCategories.value = [];
      selectedBrands.value = [];
      selectedRating.value = null;
      selectedTags.value = [];
      currentPage.value = 1;
      loadSearchResults();
    };
    
    // 分页导航
    const goToPage = (page) => {
      if (page < 1 || page > totalPages.value || page === currentPage.value) {
        return;
      }
      currentPage.value = page;
      loadSearchResults();
      // 滚动到顶部
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    
    // 导航到产品详情页
    const navigateToProduct = (productId) => {
      router.push(`/product/${productId}`);
    };
    
    // 导航到首页
    const navigateToHome = () => {
      router.push('/');
    };
    
    // 浏览推荐商品
    const browseRecommendations = () => {
      router.push('/recommendations');
    };
    
    // 监听路由参数变化
    watch(() => route.query.keyword, (newKeyword) => {
      searchKeyword.value = newKeyword || '';
      currentPage.value = 1;
      loadSearchResults();
    }, { immediate: true });
    
    // 监听页码变化
    watch(currentPage, () => {
      loadSearchResults();
    });
    
    // 初始化加载
    onMounted(() => {
      searchKeyword.value = route.query.keyword || '';
      loadSearchResults();
    });
    
    return {
      // 数据
      searchKeyword,
      currentPage,
      totalResults,
      totalPages,
      targetPage,
      loading,
      viewMode,
      products,
      categories,
      brands,
      tags,
      ratings,
      
      // 排序和过滤参数
      sortBy,
      priceRange,
      selectedCategories,
      selectedBrands,
      selectedRating,
      selectedTags,
      
      // 计算属性
      visiblePages,
      hasActiveFilters,
      activeFilterTags,
      
      // 方法
      applySort,
      applyFilters,
      toggleTag,
      removeFilter,
      clearAllFilters,
      goToPage,
      navigateToProduct,
      navigateToHome,
      browseRecommendations
    };
  }
};
>
</style scoped>
.search-results-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.search-breadcrumb {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  font-size: 14px;
  color: #666;
}

.breadcrumb-home {
  color: #1890ff;
  cursor: pointer;
}

.breadcrumb-home:hover {
  text-decoration: underline;
}

.breadcrumb-separator {
  margin: 0 8px;
  color: #999;
}

.breadcrumb-current {
  color: #333;
  font-weight: 500;
}

.search-results-content {
  display: flex;
  gap: 24px;
}

/* 左侧过滤面板 */
.filter-panel {
  width: 240px;
  flex-shrink: 0;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  padding: 20px;
  position: sticky;
  top: 20px;
  max-height: calc(100vh - 40px);
  overflow-y: auto;
}

.filter-panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px solid #f0f0f0;
}

.filter-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.clear-filters {
  background: none;
  border: none;
  color: #1890ff;
  font-size: 14px;
  cursor: pointer;
}

.clear-filters:hover {
  text-decoration: underline;
}

.filter-section {
  margin-bottom: 24px;
}

.filter-section-title {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 12px;
}

/* 价格过滤 */
.price-filter {
  display: flex;
  align-items: center;
  gap: 8px;
}

.price-input {
  flex: 1;
  height: 32px;
  padding: 0 8px;
  border: 1px solid #e0e0e0;
  border-radius: 2px;
  font-size: 14px;
}

.price-separator {
  color: #999;
}

.price-apply {
  height: 32px;
  padding: 0 12px;
  background-color: #1890ff;
  color: white;
  border: none;
  border-radius: 2px;
  font-size: 14px;
  cursor: pointer;
}

.price-apply:hover {
  background-color: #40a9ff;
}

/* 过滤选项 */
.filter-options {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.filter-option {
  display: flex;
  align-items: center;
  cursor: pointer;
  font-size: 14px;
  color: #333;
}

.filter-option input[type="checkbox"],
.filter-option input[type="radio"] {
  margin-right: 8px;
}

.filter-option-text {
  flex: 1;
}

.filter-option-count {
  color: #999;
  font-size: 12px;
}

/* 评分星星 */
.rating-stars {
  display: inline-flex;
  align-items: center;
  gap: 2px;
}

.star {
  color: #e0e0e0;
  font-size: 14px;
}

.star.filled {
  color: #ffd700;
}

.rating-value {
  margin-left: 4px;
  font-size: 14px;
  color: #ff6700;
  font-weight: 500;
}

.rating-count {
  margin-left: 4px;
  font-size: 12px;
  color: #999;
}

.rating-text {
  margin-left: 4px;
  font-size: 14px;
  color: #333;
}

/* 标签过滤 */
.tag-filters {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag-filter {
  padding: 4px 12px;
  background-color: #f5f5f5;
  color: #666;
  font-size: 12px;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  white-space: nowrap;
}

.tag-filter:hover {
  background-color: #e6f7ff;
  color: #1890ff;
}

.tag-filter.active {
  background-color: #1890ff;
  color: white;
}

.tag-count {
  margin-left: 4px;
  font-size: 11px;
  opacity: 0.8;
}

/* 右侧搜索结果 */
.results-content {
  flex: 1;
}

/* 搜索统计和排序 */
.search-stats-sort {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 0;
  border-bottom: 1px solid #f0f0f0;
}

.search-stats {
  font-size: 14px;
  color: #666;
}

.search-sort {
  display: flex;
  align-items: center;
  gap: 16px;
}

.sort-label {
  font-size: 14px;
  color: #666;
}

.search-sort select {
  height: 32px;
  padding: 0 8px;
  border: 1px solid #e0e0e0;
  border-radius: 2px;
  font-size: 14px;
  cursor: pointer;
}

.view-toggle {
  display: flex;
  gap: 4px;
}

.view-btn {
  width: 32px;
  height: 32px;
  border: 1px solid #e0e0e0;
  background-color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 2px;
}

.view-btn.active {
  background-color: #1890ff;
  border-color: #1890ff;
  color: white;
}

/* 已选筛选条件 */
.active-filters {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  padding: 12px 0;
  margin-bottom: 16px;
}

.active-filters-title {
  font-size: 14px;
  color: #666;
}

.active-filter-tag {
  display: inline-flex;
  align-items: center;
  padding: 4px 8px;
  background-color: #e6f7ff;
  color: #1890ff;
  font-size: 12px;
  border-radius: 12px;
  gap: 4px;
}

.remove-filter {
  width: 16px;
  height: 16px;
  border: none;
  background: none;
  color: #1890ff;
  font-size: 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.2s;
}

.remove-filter:hover {
  background-color: #1890ff;
  color: white;
}

/* 加载状态 */
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #1890ff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.loading-text {
  margin-top: 16px;
  font-size: 14px;
  color: #666;
}

/* 商品列表 */
.products-list {
  margin: 20px 0;
}

/* 网格视图 */
.products-list.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 20px;
}

.product-item {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s;
}

.product-item:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transform: translateY(-2px);
}

.product-grid {
  display: flex;
  flex-direction: column;
}

.product-image {
  position: relative;
  padding-top: 100%;
  overflow: hidden;
}

.product-image img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.product-item:hover .product-image img {
  transform: scale(1.05);
}

.discount-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  background-color: #ff4d4f;
  color: white;
  padding: 2px 8px;
  font-size: 12px;
  border-radius: 2px;
}

.product-info {
  padding: 12px;
}

.product-category {
  font-size: 12px;
  color: #999;
  margin-bottom: 4px;
}

.product-name {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-rating {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
}

.product-price {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.current-price {
  font-size: 18px;
  font-weight: 500;
  color: #ff4d4f;
}

.original-price {
  font-size: 14px;
  color: #999;
  text-decoration: line-through;
}

.product-sales {
  font-size: 12px;
  color: #999;
  margin-bottom: 8px;
}

.product-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.product-tag {
  padding: 2px 6px;
  background-color: #f0f0f0;
  color: #666;
  font-size: 10px;
  border-radius: 2px;
}

/* 列表视图 */
.products-list.list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.product-list-item {
  display: flex;
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.product-list-image {
  width: 120px;
  height: 120px;
  position: relative;
  flex-shrink: 0;
}

.product-list-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.product-list-info {
  flex: 1;
  padding: 16px;
  display: flex;
  flex-direction: column;
}

.product-list-header {
  flex: 1;
}

.product-list-category {
  font-size: 12px;
  color: #999;
  margin-bottom: 4px;
}

.product-list-name {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
}

.product-list-description {
  font-size: 14px;
  color: #666;
  line-height: 1.4;
  margin-bottom: 12px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-list-details {
  display: flex;
  align-items: center;
  gap: 24px;
  margin-bottom: 12px;
}

.product-list-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.product-list-rating {
  display: flex;
  align-items: center;
}

.product-list-sales {
  font-size: 14px;
  color: #666;
}

.product-list-price {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.add-to-cart-btn {
  padding: 8px 24px;
  background-color: #ff6700;
  color: white;
  border: none;
  border-radius: 2px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.add-to-cart-btn:hover {
  background-color: #ff8533;
}

/* 无结果状态 */
.no-results {
  text-align: center;
  padding: 60px 0;
}

.no-results-icon {
  font-size: 48px;
  color: #e0e0e0;
  margin-bottom: 16px;
}

.no-results-title {
  font-size: 18px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
}

.no-results-text {
  font-size: 14px;
  color: #999;
  margin-bottom: 24px;
}

.browse-recommendations {
  padding: 8px 24px;
  background-color: #1890ff;
  color: white;
  border: none;
  border-radius: 2px;
  font-size: 14px;
  cursor: pointer;
}

.browse-recommendations:hover {
  background-color: #40a9ff;
}

/* 分页 */
.pagination {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 40px 0;
  flex-wrap: wrap;
}

.pagination-btn {
  padding: 8px 16px;
  border: 1px solid #e0e0e0;
  background-color: white;
  color: #333;
  cursor: pointer;
  font-size: 14px;
  border-radius: 2px;
  transition: all 0.2s;
}

.pagination-btn:hover:not(:disabled) {
  border-color: #1890ff;
  color: #1890ff;
}

.pagination-btn.active {
  background-color: #1890ff;
  border-color: #1890ff;
  color: white;
}

.pagination-btn:disabled {
  color: #d9d9d9;
  cursor: not-allowed;
}

.pagination-info {
  margin-left: 16px;
  font-size: 14px;
  color: #666;
}

.page-input {
  width: 50px;
  height: 32px;
  padding: 0 8px;
  border: 1px solid #e0e0e0;
  border-radius: 2px;
  text-align: center;
  margin: 0 4px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-results-content {
    flex-direction: column;
  }
  
  .filter-panel {
    width: 100%;
    position: static;
    max-height: none;
    margin-bottom: 20px;
  }
  
  .products-list.grid {
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 12px;
  }
  
  .product-list-item {
    flex-direction: column;
  }
  
  .product-list-image {
    width: 100%;
    height: 160px;
  }
  
  .product-list-details {
    flex-wrap: wrap;
    gap: 12px;
  }
  
  .pagination {
    flex-wrap: wrap;
  }
  
  .search-stats-sort {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }
}
</style>