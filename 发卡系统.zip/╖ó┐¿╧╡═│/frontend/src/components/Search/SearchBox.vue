<template>
  <div class="search-box">
    <div class="search-input-container">
      <input
        v-model="searchQuery"
        type="text"
        class="search-input"
        placeholder="搜索游戏点卡、充值卡..."
        @input="handleInput"
        @keypress.enter="handleSearch"
        @focus="showSuggestions = true"
        @blur="handleBlur"
      />
      <button class="search-button" @click="handleSearch" :disabled="isSearching">
        <i class="icon-search"></i>
        <span v-if="isSearching">搜索中...</span>
        <span v-else>搜索</span>
      </button>
    </div>
    
    <!-- 搜索建议 -->
    <div v-if="showSuggestions && (suggestions.length > 0 || recentSearches.length > 0)" class="suggestions-container">
      <!-- 最近搜索 -->
      <div v-if="recentSearches.length > 0 && !searchQuery" class="suggestion-section">
        <div class="suggestion-section-title">
          <i class="icon-history"></i>
          最近搜索
          <button class="clear-history" @click.stop="clearRecentSearches">清空</button>
        </div>
        <div
          v-for="(search, index) in recentSearches"
          :key="`recent-${index}`"
          class="suggestion-item"
          @mousedown="selectSuggestion(search)"
        >
          <i class="icon-history small"></i>
          <span class="suggestion-text">{{ search }}</span>
        </div>
      </div>
      
      <!-- 搜索建议 -->
      <div v-if="suggestions.length > 0" class="suggestion-section">
        <div class="suggestion-section-title">
          <i class="icon-search"></i>
          搜索建议
        </div>
        <div
          v-for="(suggestion, index) in suggestions"
          :key="`suggestion-${index}`"
          class="suggestion-item"
          @mousedown="selectSuggestion(suggestion.text)"
        >
          <i class="icon-search small"></i>
          <span class="suggestion-text" v-html="highlightText(suggestion.text)"></span>
          <span v-if="suggestion.category" class="suggestion-category">{{ suggestion.category }}</span>
        </div>
      </div>
    </div>
    
    <!-- 热门搜索标签 -->
    <div v-if="!searchQuery && popularSearches.length > 0" class="popular-searches">
      <span class="popular-searches-title">热门搜索：</span>
      <span
        v-for="(popular, index) in popularSearches"
        :key="`popular-${index}`"
        class="popular-search-tag"
        @click="handlePopularSearch(popular)"
      >
        {{ popular }}
      </span>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';
import { searchService } from '@/services/searchService';
import { storageService } from '@/services/storageService';

export default {
  name: 'SearchBox',
  emits: ['search'],
  setup(props, { emit }) {
    const router = useRouter();
    const searchQuery = ref('');
    const suggestions = ref([]);
    const popularSearches = ref([]);
    const recentSearches = ref([]);
    const showSuggestions = ref(false);
    const isSearching = ref(false);
    const inputTimer = ref(null);
    
    // 最大保存的最近搜索数量
    const MAX_RECENT_SEARCHES = 10;
    
    // 加载最近搜索
    const loadRecentSearches = () => {
      const recent = storageService.get('recent_searches') || [];
      recentSearches.value = recent;
    };
    
    // 保存最近搜索
    const saveRecentSearch = (query) => {
      if (!query.trim()) return;
      
      let recent = [...recentSearches.value];
      
      // 移除已存在的相同查询
      recent = recent.filter(item => item !== query);
      
      // 添加到开头
      recent.unshift(query);
      
      // 限制数量
      if (recent.length > MAX_RECENT_SEARCHES) {
        recent = recent.slice(0, MAX_RECENT_SEARCHES);
      }
      
      recentSearches.value = recent;
      storageService.set('recent_searches', recent);
    };
    
    // 清空最近搜索
    const clearRecentSearches = () => {
      recentSearches.value = [];
      storageService.remove('recent_searches');
    };
    
    // 加载热门搜索
    const loadPopularSearches = async () => {
      try {
        const result = await searchService.getPopularSearches();
        popularSearches.value = result || [];
      } catch (error) {
        console.error('加载热门搜索失败:', error);
        // 设置默认热门搜索
        popularSearches.value = ['游戏点卡', '充值卡', '腾讯Q币', '网易一卡通', '魔兽世界'];
      }
    };
    
    // 处理输入
    const handleInput = () => {
      clearTimeout(inputTimer.value);
      
      if (searchQuery.value.trim()) {
        // 防抖，300ms后获取搜索建议
        inputTimer.value = setTimeout(() => {
          fetchSuggestions();
        }, 300);
      } else {
        suggestions.value = [];
      }
    };
    
    // 获取搜索建议
    const fetchSuggestions = async () => {
      try {
        const query = searchQuery.value.trim();
        if (!query) return;
        
        const result = await searchService.getSuggestions(query);
        suggestions.value = result || [];
      } catch (error) {
        console.error('获取搜索建议失败:', error);
        suggestions.value = [];
      }
    };
    
    // 高亮文本
    const highlightText = (text) => {
      if (!searchQuery.value.trim()) return text;
      
      const query = searchQuery.value.trim();
      const regex = new RegExp(`(${query})`, 'gi');
      return text.replace(regex, '<span class="highlight">$1</span>');
    };
    
    // 选择建议
    const selectSuggestion = (text) => {
      searchQuery.value = text;
      showSuggestions.value = false;
      handleSearch();
    };
    
    // 处理热门搜索点击
    const handlePopularSearch = (text) => {
      searchQuery.value = text;
      handleSearch();
    };
    
    // 处理搜索
    const handleSearch = async () => {
      const query = searchQuery.value.trim();
      if (!query) return;
      
      isSearching.value = true;
      showSuggestions.value = false;
      
      try {
        // 保存到最近搜索
        saveRecentSearch(query);
        
        // 发出搜索事件
        emit('search', query);
        
        // 导航到搜索结果页面
        router.push({
          path: '/search',
          query: { keyword: query }
        });
      } catch (error) {
        console.error('搜索失败:', error);
      } finally {
        isSearching.value = false;
      }
    };
    
    // 处理失焦
    const handleBlur = () => {
      // 延迟隐藏，以便点击建议项能够触发
      setTimeout(() => {
        showSuggestions.value = false;
      }, 200);
    };
    
    // 监听路由变化，更新搜索框的值
    watch(() => router.currentRoute.value.query.keyword, (newKeyword) => {
      if (newKeyword) {
        searchQuery.value = newKeyword;
      }
    });
    
    // 组件挂载时加载数据
    onMounted(() => {
      loadRecentSearches();
      loadPopularSearches();
    });
    
    return {
      searchQuery,
      suggestions,
      popularSearches,
      recentSearches,
      showSuggestions,
      isSearching,
      handleInput,
      handleSearch,
      handleBlur,
      selectSuggestion,
      handlePopularSearch,
      clearRecentSearches,
      highlightText
    };
  }
};
</script>

<style scoped>
.search-box {
  position: relative;
  width: 100%;
  max-width: 600px;
}

.search-input-container {
  display: flex;
  width: 100%;
}

.search-input {
  flex: 1;
  height: 40px;
  padding: 0 16px;
  border: 2px solid #e0e0e0;
  border-right: none;
  border-radius: 4px 0 0 4px;
  font-size: 16px;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-input:focus {
  border-color: #1890ff;
}

.search-button {
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 80px;
  height: 40px;
  padding: 0 16px;
  background-color: #1890ff;
  color: white;
  border: none;
  border-radius: 0 4px 4px 0;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.search-button:hover:not(:disabled) {
  background-color: #40a9ff;
}

.search-button:disabled {
  background-color: #f5f5f5;
  color: #bfbfbf;
  cursor: not-allowed;
}

.suggestions-container {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background: white;
  border: 1px solid #e0e0e0;
  border-top: none;
  border-radius: 0 0 4px 4px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  z-index: 1000;
  max-height: 400px;
  overflow-y: auto;
}

.suggestion-section {
  padding: 8px 0;
}

.suggestion-section-title {
  display: flex;
  align-items: center;
  padding: 8px 16px;
  font-size: 12px;
  color: #999;
  font-weight: 500;
}

.clear-history {
  margin-left: auto;
  background: none;
  border: none;
  color: #1890ff;
  font-size: 12px;
  cursor: pointer;
  padding: 2px 8px;
  border-radius: 2px;
  transition: background-color 0.2s;
}

.clear-history:hover {
  background-color: #f0f0f0;
}

.suggestion-item {
  display: flex;
  align-items: center;
  padding: 10px 16px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.suggestion-item:hover {
  background-color: #f5f5f5;
}

.suggestion-text {
  flex: 1;
  word-break: break-word;
}

.suggestion-category {
  margin-left: 8px;
  padding: 2px 8px;
  background-color: #f0f0f0;
  color: #666;
  font-size: 12px;
  border-radius: 2px;
}

.highlight {
  color: #1890ff;
  font-weight: 500;
}

.popular-searches {
  margin-top: 12px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}

.popular-searches-title {
  font-size: 12px;
  color: #999;
}

.popular-search-tag {
  display: inline-block;
  padding: 4px 12px;
  background-color: #f5f5f5;
  color: #666;
  font-size: 12px;
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.2s;
}

.popular-search-tag:hover {
  background-color: #e6f7ff;
  color: #1890ff;
}

.icon-search,
.icon-history {
  margin-right: 8px;
  color: #999;
  font-size: 14px;
}

.icon-search.small,
.icon-history.small {
  font-size: 12px;
  margin-right: 6px;
}

/* 滚动条样式 */
.suggestions-container::-webkit-scrollbar {
  width: 6px;
}

.suggestions-container::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.suggestions-container::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 3px;
}

.suggestions-container::-webkit-scrollbar-thumb:hover {
  background: #555;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-input {
    font-size: 14px;
  }
  
  .suggestions-container {
    max-height: 300px;
  }
  
  .popular-searches {
    flex-wrap: wrap;
  }
}
</style>