<template>
  <div class="recommendations-container">
    <!-- 推荐头部 -->
    <div class="recommendations-header">
      <div class="header-left">
        <span class="recommendations-title">
          {{ isProductPage ? '猜你喜欢' : '为您推荐' }}
        </span>
        <span v-if="currentRecommendationType !== 'all'" class="recommendations-subtitle">
          基于您的{{ recommendationTypeText }}推荐
        </span>
      </div>
      
      <div class="header-right">
        <!-- 推荐类型选择器（大屏幕） -->
        <div class="recommendation-tabs large">
          <div 
            v-for="type in recommendationTypes" 
            :key="type.value"
            class="recommendation-tab"
            :class="{ active: currentRecommendationType === type.value }"
            @click="switchRecommendationType(type.value)"
          >
            {{ type.label }}
          </div>
        </!
        <!-- 推荐类型选择器（小屏幕） -->
        <select v-model="currentRecommendationType" class="recommendation-select small" @change="handleTypeChange">
          <option 
            v-for="type in recommendationTypes" 
            :key="type.value" 
            :value="type.value"
          >
            {{ type.label }}
          </option>
        </select>
        <button class="refresh-btn" @click="refreshRecommendations" :disabled="loading">
          <i class="icon-refresh" :class="{ spinning: loading }"></i>
          换一批
        </button>
      </div>
    </div>
    <!-- 加载状态 -->
    <div v-if="loading" class="loading-container">
      <div class="loading-spinner"></div>
      <div class="loading-text">正在为您生成推荐...</div>
    </div>
    <!-- 推荐商品列表 --</div>
    <div v-else-if="recommendations.length > 0" class="recommendations-list">
      <div 
        v-for="product in recommendations" 
        :key="`rec-${product.id}`" 
        class="recommendation-item"
        @click="navigateToProduct(product.id)"
      >
        <div class="product-image">
          <img :src="product.image" :alt="product.name" loading="lazy" />
          <div v-if="product.discount" class="discount-badge">{{ product.discount }}折</div>
          <div v-if="product.is_new" class="new-badge">新品</div>
        </div>
        <div class="product-info">
          <div class="product-name">{{ product.name }}</div>
          <div class="product-tags">
            <span v-for="(tag, index) in product.tags.slice(0, 2)" :key="index" class="product-tag">{{ tag }}</span>
          </div>
          <div class="product-rating">
            <span class="rating-stars">
              <span 
                v-for="star in 5" 
                :key="star"
                class="star" 
                :class="{ filled: star <= product.rating }"
              >★</span>
              <span class="rating-value">{{ product.rating }}</span>
            </span>
            <span class="rating-count">({{ product.reviewCount }})</span>
          </div>
          <div class="product-price">
            <span class="current-price">¥{{ product.price }}</span>
            <span v-if="product.originalPrice" class="original-price">¥{{ product.originalPrice }}</span>
          </div>
          <div class="product-sales">已售 {{ product.sales }} 件</div>
          <div class="product-recommend-reason" v-if="product.recommendReason">
            <span class="reason-icon">💡</span>
            <span class="reason-text">{{ product.recommendReason }}</span>
          </div>
        </div>
      </div>
    </div>
    <!-- 无推荐状态 -->
    <div v-else class="no-recommendations">
      <div class="no-recommendations-icon"><i class="icon-recommend"></i></div>
      <div class="no-recommendations-text">暂无推荐商品
      </span>
    </div>
    <!-- 查看更多 --</div>
    <div v-if="recommendations.length > 0 && !loading" class="view-more">
      <button class="view-more-btn" @click="navigateToAllRecommendations">
        查看更多推荐 <span class="view-more-icon">→</span>
      </button>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch, nextTick } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { recommendationService } from '@/services/recommendationService';
import { userService } from '@/services/userService';

export default {
  name: 'ProductRecommendations',
  props: {
    // 产品ID，用于在产品详情页显示相关推荐
    productId: {
      type: String,
      default: null
    },
    // 显示数量
    limit: {
      type: Number,
      default: 10
    },
    // 是否显示标题
    showTitle: {
      type: Boolean,
      default: true
    },
    // 是否显示类型切换
    showTypeSwitch: {
      type: Boolean,
      default: true
    }
  },
  setup(props) {
    const route = useRoute();
    const router = useRouter();
    
    // 状态
    const recommendations = ref([]);
    const currentRecommendationType = ref('all');
    const loading = ref(false);
    const isProductPage = computed(() => props.productId || route.path.includes('/product/'));
    
    // 推荐类型
    const recommendationTypes = ref([
      { value: 'all', label: '全部推荐' },
      { value: 'browse', label: '浏览历史' },
      { value: 'purchase', label: '购买历史' },
      { value: 'similar', label: '相似商品' },
      { value: 'popular', label: '热门商品' },
      { value: 'new', label: '新品上架' }
    ]);
    
    // 推荐类型文本
    const recommendationTypeText = computed(() => {
      const type = recommendationTypes.value.find(t => t.value === currentRecommendationType.value);
      if (type.value === 'browse') return '浏览历史';
      if (type.value === 'purchase') return '购买历史';
      if (type.value === 'similar') return '相似偏好';
      return type.label;
    });
    
    // 加载推荐商品
    const loadRecommendations = async () => {
      loading.value = true;
      
      try {
        // 获取用户ID（如果已登录）
        const userId = userService.getCurrentUserId();
        
        // 构建推荐参数
        const params = {
          type: currentRecommendationType.value,
          limit: props.limit,
          user_id: userId,
          product_id: props.productId || (isProductPage.value ? route.params.id : null)
        };
        
        const results = await recommendationService.getRecommendations(params);
        recommendations.value = results.products || [];
        
        // 如果没有推荐结果，使用热门商品作为备选
        if (recommendations.value.length === 0 && currentRecommendationType.value !== 'popular') {
          currentRecommendationType.value = 'popular';
          await loadRecommendations();
        }
        
      } catch (error) {
        console.error('加载推荐失败:', error);
        // 使用模拟数据
        loadMockRecommendations();
      } finally {
        loading.value = false;
      }
    };
    
    // 加载模拟推荐数据
    const loadMockRecommendations = () => {
      const mockRecommendations = [];
      const productNames = [
        '腾讯Q币充值卡',
        '网易一卡通',
        '盛大游戏点卡',
        '完美世界点卡',
        '魔兽世界点卡',
        '英雄联盟点券',
        '王者荣耀点券',
        '穿越火线CF点',
        'QQ会员月卡',
        '腾讯视频会员'
      ];
      
      const categories = ['游戏点卡', '视频会员', '音乐会员', '软件激活'];
      const brands = ['腾讯', '网易', '盛大', '完美世界', '暴雪'];
      const tags = ['官方授权', '自动发货', '即时到账', '特价优惠', '新用户专享'];
      
      for (let i = 1; i <= props.limit; i++) {
        const basePrice = 50 + Math.floor(Math.random() * 150);
        const discount = Math.random() > 0.7 ? (8 + Math.floor(Math.random() * 2)) + '.' + (Math.floor(Math.random() * 10)) : null;
        
        mockRecommendations.push({
          id: `rec-${Date.now()}-${i}`,
          name: `${productNames[i % productNames.length]} ${basePrice}元`,
          image: `/images/products/${i % 10 + 1}.jpg`,
          price: discount ? Math.floor(basePrice * parseFloat(discount) / 10) : basePrice,
          originalPrice: discount ? basePrice : null,
          discount: discount,
          category: categories[i % categories.length],
          brand: brands[i % brands.length],
          rating: (4 + Math.random()).toFixed(1),
          reviewCount: 100 + Math.floor(Math.random() * 900),
          sales: 1000 + Math.floor(Math.random() * 9000),
          tags: [tags[i % tags.length], tags[(i + 1) % tags.length]],
          is_new: Math.random() > 0.8,
          recommendReason: getRecommendReason(i, currentRecommendationType.value)
        });
      }
      
      recommendations.value = mockRecommendations;
    };
    
    // 获取推荐理由
    const getRecommendReason = (index, type) => {
      const reasons = {
        browse: ['您近期浏览过类似商品', '基于您的浏览历史推荐', '根据您的兴趣精选'],
        purchase: ['与您购买过的商品相关', '基于您的购买记录推荐', '您可能还需要'],
        similar: ['与当前商品相似', '用户经常一起购买', '热门搭配'],
        popular: ['销量领先', '用户好评如潮', '限时热销'],
        new: ['新品上架', '最新到货', '限时首购优惠'],
        all: ['为您精选', '个性化推荐', '热门优选']
      };
      
      const typeReasons = reasons[type] || reasons.all;
      return typeReasons[index % typeReasons.length];
    };
    
    // 切换推荐类型
    const switchRecommendationType = async (type) => {
      if (type === currentRecommendationType.value || loading.value) return;
      
      currentRecommendationType.value = type;
      await loadRecommendations();
      
      // 滚动到顶部
      await nextTick();
      const container = document.querySelector('.recommendations-container');
      if (container) {
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    };
    
    // 处理选择器变化（移动端）
    const handleTypeChange = async () => {
      await loadRecommendations();
    };
    
    // 刷新推荐
    const refreshRecommendations = async () => {
      await loadRecommendations();
    };
    
    // 导航到商品详情
    const navigateToProduct = (productId) => {
      router.push(`/product/${productId}`);
    };
    
    // 导航到全部推荐页面
    const navigateToAllRecommendations = () => {
      router.push({
        path: '/recommendations',
        query: { type: currentRecommendationType.value }
      });
    };
    
    // 监听推荐类型变化
    watch(currentRecommendationType, () => {
      // 类型变化时不需要立即加载，由switchRecommendationType处理
    });
    
    // 监听产品ID变化
    watch(() => props.productId, () => {
      if (props.productId) {
        loadRecommendations();
      }
    });
    
    // 初始化
    onMounted(() => {
      // 如果是产品详情页，默认使用相似推荐
      if (isProductPage.value && !props.productId) {
        currentRecommendationType.value = 'similar';
      }
      loadRecommendations();
    });
    
    return {
      // 数据
      recommendations,
      currentRecommendationType,
      recommendationTypes,
      loading,
      
      // 计算属性
      isProductPage,
      recommendationTypeText,
      
      // 方法
      switchRecommendationType,
      handleTypeChange,
      refreshRecommendations,
      navigateToProduct,
      navigateToAllRecommendations
    };
  }
};
>
</style scoped>
.recommendations-container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

/* 推荐头部 */
.recommendations-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  flex-wrap: wrap;
  gap: 16px;
}

.header-left {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.recommendations-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}

.recommendations-subtitle {
  font-size: 14px;
  color: #666;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}

/* 推荐类型标签 */
.recommendation-tabs {
  display: flex;
  gap: 4px;
  background-color: #f5f5f5;
  padding: 4px;
  border-radius: 20px;
}

.recommendation-tab {
  padding: 6px 16px;
  font-size: 14px;
  color: #666;
  cursor: pointer;
  border-radius: 16px;
  transition: all 0.3s;
  white-space: nowrap;
}

.recommendation-tab:hover {
  color: #1890ff;
}

.recommendation-tab.active {
  background-color: #1890ff;
  color: white;
}

/* 推荐类型选择器（移动端） */
.recommendation-select {
  padding: 8px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  background-color: white;
}

/* 刷新按钮 */
.refresh-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 16px;
  border: 1px solid #e0e0e0;
  background-color: white;
  color: #333;
  font-size: 14px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s;
}

.refresh-btn:hover:not(:disabled) {
  border-color: #1890ff;
  color: #1890ff;
}

.refresh-btn:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}

.icon-refresh {
  font-size: 16px;
  transition: transform 0.3s;
}

.icon-refresh.spinning {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 加载状态 */
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
  gap: 16px;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #1890ff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

.loading-text {
  font-size: 14px;
  color: #666;
}

/* 推荐商品列表 */
.recommendations-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}

.recommendation-item {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s;
  display: flex;
  flex-direction: column;
}

.recommendation-item:hover {
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
  transform: translateY(-2px);
}

/* 商品图片 */
.product-image {
  position: relative;
  padding-top: 100%;
  overflow: hidden;
}

.product-image img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s;
}

.recommendation-item:hover .product-image img {
  transform: scale(1.08);
}

/* 折扣标签 */
.discount-badge,
.new-badge {
  position: absolute;
  top: 8px;
  padding: 2px 8px;
  font-size: 12px;
  border-radius: 4px;
}

.discount-badge {
  left: 8px;
  background-color: #ff4d4f;
  color: white;
}

.new-badge {
  right: 8px;
  background-color: #52c41a;
  color: white;
}

/* 商品信息 */
.product-info {
  padding: 12px;
  flex: 1;
  display: flex;
  flex-direction: column;
}

.product-name {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 8px;
}

.product-tag {
  padding: 2px 6px;
  background-color: #f0f0f0;
  color: #666;
  font-size: 10px;
  border-radius: 2px;
}

/* 评分 */
.product-rating {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
}

.rating-stars {
  display: flex;
  align-items: center;
  gap: 2px;
}

.star {
  color: #e0e0e0;
  font-size: 14px;
}

.star.filled {
  color: #ffd700;
}

.rating-value {
  margin-left: 4px;
  font-size: 14px;
  color: #ff6700;
  font-weight: 500;
}

.rating-count {
  margin-left: 4px;
  font-size: 12px;
  color: #999;
}

/* 价格 */
.product-price {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.current-price {
  font-size: 18px;
  font-weight: 600;
  color: #ff4d4f;
}

.original-price {
  font-size: 14px;
  color: #999;
  text-decoration: line-through;
}

.product-sales {
  font-size: 12px;
  color: #999;
  margin-bottom: 8px;
}

/* 推荐理由 */
.product-recommend-reason {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 8px;
  background-color: #f6ffed;
  border: 1px solid #b7eb8f;
  border-radius: 4px;
  margin-top: auto;
}

.reason-icon {
  font-size: 14px;
}

.reason-text {
  font-size: 12px;
  color: #52c41a;
  line-height: 1.4;
}

/* 无推荐状态 */
.no-recommendations {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
  color: #999;
}

.no-recommendations-icon {
  font-size: 48px;
  margin-bottom: 16px;
}

.no-recommendations-text {
  font-size: 14px;
}

/* 查看更多 */
.view-more {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

.view-more-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 10px 32px;
  border: 1px solid #e0e0e0;
  background-color: white;
  color: #333;
  font-size: 14px;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s;
}

.view-more-btn:hover {
  border-color: #1890ff;
  color: #1890ff;
}

.view-more-icon {
  font-size: 12px;
  transition: transform 0.3s;
}

.view-more-btn:hover .view-more-icon {
  transform: translateX(2px);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .recommendations-container {
    padding: 16px;
  }
  
  .recommendations-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }
  
  .header-right {
    width: 100%;
    justify-content: space-between;
  }
  
  .recommendation-tabs.large {
    display: none;
  }
  
  .recommendation-select.small {
    display: block;
  }
  
  .recommendations-list {
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 12px;
  }
  
  .recommendations-title {
    font-size: 20px;
  }
  
  .current-price {
    font-size: 16px;
  }
  
  .product-info {
    padding: 10px;
  }
}

@media (min-width: 769px) {
  .recommendation-tabs.large {
    display: flex;
  }
  
  .recommendation-select.small {
    display: none;
  }
}

@media (max-width: 480px) {
  .recommendations-list {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .product-name {
    font-size: 13px;
  }
  
  .current-price {
    font-size: 14px;
  }
  
  .refresh-btn {
    font-size: 12px;
    padding: 6px 12px;
  }
  
  .view-more-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>