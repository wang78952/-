// 存储服务 - 提供本地数据持久化功能

/**
 * 存储服务类，提供本地数据持久化功能
 */
export const storageService = {
  /**
   * 检查存储是否可用
   * @returns {boolean} 存储是否可用
   */
  isStorageAvailable: () => {
    try {
      const test = '__storage_test__';
      localStorage.setItem(test, test);
      localStorage.removeItem(test);
      return true;
    } catch (e) {
      console.warn('Local storage is not available:', e);
      return false;
    }
  },

  /**
   * 保存数据到本地存储
   * @param {string} key - 存储键名
   * @param {any} value - 存储值
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {boolean} 是否保存成功
   */
  set: (key, value, options = {}) => {
    try {
      const storage = options.session ? sessionStorage : localStorage;
      const jsonValue = JSON.stringify(value);
      storage.setItem(key, jsonValue);
      return true;
    } catch (e) {
      console.error(`Error saving data for key "${key}":`, e);
      return false;
    }
  },

  /**
   * 从本地存储获取数据
   * @param {string} key - 存储键名
   * @param {any} defaultValue - 默认值
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {any} 获取的数据或默认值
   */
  get: (key, defaultValue = null, options = {}) => {
    try {
      const storage = options.session ? sessionStorage : localStorage;
      const jsonValue = storage.getItem(key);
      return jsonValue != null ? JSON.parse(jsonValue) : defaultValue;
    } catch (e) {
      console.error(`Error reading data for key "${key}":`, e);
      return defaultValue;
    }
  },

  /**
   * 从本地存储移除数据
   * @param {string} key - 存储键名
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {boolean} 是否移除成功
   */
  remove: (key, options = {}) => {
    try {
      const storage = options.session ? sessionStorage : localStorage;
      storage.removeItem(key);
      return true;
    } catch (e) {
      console.error(`Error removing data for key "${key}":`, e);
      return false;
    }
  },

  /**
   * 清空所有存储数据
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {boolean} 是否清空成功
   */
  clear: (options = {}) => {
    try {
      const storage = options.session ? sessionStorage : localStorage;
      storage.clear();
      return true;
    } catch (e) {
      console.error('Error clearing storage:', e);
      return false;
    }
  },

  /**
   * 获取所有存储键名
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {Array} 键名数组
   */
  getAllKeys: (options = {}) => {
    try {
      const storage = options.session ? sessionStorage : localStorage;
      const keys = [];
      for (let i = 0; i < storage.length; i++) {
        keys.push(storage.key(i));
      }
      return keys;
    } catch (e) {
      console.error('Error getting all keys:', e);
      return [];
    }
  },

  /**
   * 保存带有过期时间的数据
   * @param {string} key - 存储键名
   * @param {any} value - 存储值
   * @param {number} ttl - 过期时间（毫秒）
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {boolean} 是否保存成功
   */
  setWithExpiry: (key, value, ttl, options = {}) => {
    const item = {
      value,
      expiry: Date.now() + ttl
    };
    return this.set(key, item, options);
  },

  /**
   * 获取带有过期时间的数据
   * @param {string} key - 存储键名
   * @param {any} defaultValue - 默认值
   * @param {Object} options - 选项
   * @param {boolean} options.session - 是否使用sessionStorage
   * @returns {any} 获取的数据或默认值
   */
  getWithExpiry: (key, defaultValue = null, options = {}) => {
    const item = this.get(key, null, options);
    
    // 如果数据不存在
    if (!item) {
      return defaultValue;
    }
    
    // 检查是否过期
    if (Date.now() > item.expiry) {
      // 数据已过期，移除
      this.remove(key, options);
      return defaultValue;
    }
    
    return item.value;
  },

  /**
   * 存储用户相关数据
   * @param {string} key - 存储键名（将自动添加user_前缀）
   * @param {any} value - 存储值
   * @returns {boolean} 是否保存成功
   */
  setUserData: (key, value) => {
    return this.set(`user_${key}`, value);
  },

  /**
   * 获取用户相关数据
   * @param {string} key - 存储键名（将自动添加user_前缀）
   * @param {any} defaultValue - 默认值
   * @returns {any} 获取的数据或默认值
   */
  getUserData: (key, defaultValue = null) => {
    return this.get(`user_${key}`, defaultValue);
  },

  /**
   * 移除用户相关数据
   * @param {string} key - 存储键名（将自动添加user_前缀）
   * @returns {boolean} 是否移除成功
   */
  removeUserData: (key) => {
    return this.remove(`user_${key}`);
  },

  /**
   * 清空所有用户相关数据
   * @returns {boolean} 是否清空成功
   */
  clearUserData: () => {
    try {
      const keys = this.getAllKeys();
      keys.forEach(key => {
        if (key.startsWith('user_')) {
          this.remove(key);
        }
      });
      return true;
    } catch (e) {
      console.error('Error clearing user data:', e);
      return false;
    }
  },

  /**
   * 缓存搜索结果
   * @param {string} keyword - 搜索关键词
   * @param {Object} results - 搜索结果
   * @param {number} ttl - 过期时间（毫秒，默认5分钟）
   * @returns {boolean} 是否缓存成功
   */
  cacheSearchResults: (keyword, results, ttl = 300000) => {
    return this.setWithExpiry(`search_${keyword.toLowerCase()}`, results, ttl);
  },

  /**
   * 获取缓存的搜索结果
   * @param {string} keyword - 搜索关键词
   * @returns {Object|null} 缓存的搜索结果或null
   */
  getCachedSearchResults: (keyword) => {
    return this.getWithExpiry(`search_${keyword.toLowerCase()}`);
  },

  /**
   * 清空所有搜索缓存
   * @returns {boolean} 是否清空成功
   */
  clearSearchCache: () => {
    try {
      const keys = this.getAllKeys();
      keys.forEach(key => {
        if (key.startsWith('search_')) {
          this.remove(key);
        }
      });
      return true;
    } catch (e) {
      console.error('Error clearing search cache:', e);
      return false;
    }
  },

  /**
   * 存储应用设置
   * @param {Object} settings - 设置对象
   * @returns {boolean} 是否保存成功
   */
  saveAppSettings: (settings) => {
    return this.set('app_settings', settings);
  },

  /**
   * 获取应用设置
   * @returns {Object} 应用设置
   */
  getAppSettings: () => {
    const defaultSettings = {
      search: {
        showSuggestions: true,
        showPopularSearches: true,
        saveSearchHistory: true
      },
      recommendations: {
        showPopular: true,
        showForYou: true,
        showRecentlyViewed: true
      },
      ui: {
        viewMode: 'grid', // grid 或 list
        itemsPerPage: 20
      }
    };
    
    return {
      ...defaultSettings,
      ...this.get('app_settings', {})
    };
  },

  /**
   * 更新应用设置
   * @param {string} path - 设置路径（如 'search.showSuggestions'）
   * @param {any} value - 设置值
   * @returns {boolean} 是否更新成功
   */
  updateAppSetting: (path, value) => {
    try {
      const settings = this.getAppSettings();
      const keys = path.split('.');
      let current = settings;
      
      // 导航到目标设置对象
      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) {
          current[keys[i]] = {};
        }
        current = current[keys[i]];
      }
      
      // 设置值
      current[keys[keys.length - 1]] = value;
      
      // 保存设置
      return this.saveAppSettings(settings);
    } catch (e) {
      console.error(`Error updating setting "${path}":`, e);
      return false;
    }
  }
};

export default storageService;