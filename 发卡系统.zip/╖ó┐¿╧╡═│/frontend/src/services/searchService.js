// 搜索服务
import axios from 'axios';
import { storageService } from './storageService';

// API 基础配置
const API_BASE_URL = process.env.VUE_APP_API_BASE_URL || '/api';
const SEARCH_ENDPOINT = `${API_BASE_URL}/search`;
const SUGGESTIONS_ENDPOINT = `${API_BASE_URL}/search/suggestions`;
const POPULAR_SEARCHES_ENDPOINT = `${API_BASE_URL}/search/popular`;

// 创建axios实例
const apiClient = axios.create({
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器
apiClient.interceptors.request.use(
  config => {
    // 添加用户ID（如果有）
    const userId = storageService.get('user_id');
    if (userId) {
      config.headers['X-User-ID'] = userId;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// 响应拦截器
apiClient.interceptors.response.use(
  response => {
    return response.data;
  },
  error => {
    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

export const searchService = {
  /**
   * 执行搜索
   * @param {Object} params - 搜索参数
   * @param {string} params.keyword - 搜索关键词
   * @param {number} params.page - 页码
   * @param {number} params.page_size - 每页数量
   * @param {string} params.sort_by - 排序方式
   * @param {number} params.price_min - 最低价格
   * @param {number} params.price_max - 最高价格
   * @param {Array} params.categories - 分类ID数组
   * @param {Array} params.brands - 品牌ID数组
   * @param {number} params.rating - 最低评分
   * @param {Array} params.tags - 标签ID数组
   * @returns {Promise} 搜索结果
   */
  search: async (params) => {
    try {
      const response = await apiClient.get(SEARCH_ENDPOINT, { params });
      return response;
    } catch (error) {
      console.error('Search failed:', error);
      // 返回模拟数据
      return getMockSearchResults(params);
    }
  },
  
  /**
   * 获取搜索建议
   * @param {string} keyword - 搜索关键词
   * @returns {Promise} 搜索建议列表
   */
  getSuggestions: async (keyword) => {
    try {
      const response = await apiClient.get(SUGGESTIONS_ENDPOINT, {
        params: { keyword }
      });
      return response.suggestions || [];
    } catch (error) {
      console.error('Get suggestions failed:', error);
      // 返回模拟建议数据
      return getMockSuggestions(keyword);
    }
  },
  
  /**
   * 获取热门搜索
   * @returns {Promise} 热门搜索列表
   */
  getPopularSearches: async () => {
    try {
      const response = await apiClient.get(POPULAR_SEARCHES_ENDPOINT);
      return response.popular_searches || [];
    } catch (error) {
      console.error('Get popular searches failed:', error);
      // 返回默认热门搜索
      return [
        '腾讯Q币',
        '网易一卡通',
        '魔兽世界',
        '英雄联盟',
        '王者荣耀',
        '完美世界',
        '盛大游戏',
        '穿越火线'
      ];
    }
  },
  
  /**
   * 记录搜索行为
   * @param {string} keyword - 搜索关键词
   * @param {string} action - 行为类型 (search, click_suggestion, etc.)
   */
  trackSearchEvent: async (keyword, action = 'search') => {
    try {
      await apiClient.post(`${API_BASE_URL}/analytics/search-event`, {
        keyword,
        action,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      // 分析事件失败不影响主要功能
      console.warn('Track search event failed:', error);
    }
  },
  
  /**
   * 获取搜索历史
   * @returns {Array} 搜索历史列表
   */
  getSearchHistory: () => {
    return storageService.get('search_history') || [];
  },
  
  /**
   * 保存搜索历史
   * @param {string} keyword - 搜索关键词
   * @param {number} maxItems - 最大保存数量
   */
  saveSearchHistory: (keyword, maxItems = 10) => {
    if (!keyword.trim()) return;
    
    let history = storageService.get('search_history') || [];
    
    // 移除重复项
    history = history.filter(item => item !== keyword);
    
    // 添加到开头
    history.unshift(keyword);
    
    // 限制数量
    if (history.length > maxItems) {
      history = history.slice(0, maxItems);
    }
    
    storageService.set('search_history', history);
  },
  
  /**
   * 清除搜索历史
   */
  clearSearchHistory: () => {
    storageService.remove('search_history');
  }
};

// 模拟搜索结果
function getMockSearchResults(params) {
  const { keyword = '', page = 1, page_size = 20, sort_by = 'relevance' } = params;
  
  // 模拟产品数据
  const products = [];
  const total = 120;
  const startIdx = (page - 1) * page_size + 1;
  const endIdx = Math.min(startIdx + page_size - 1, total);
  
  // 生成模拟产品
  for (let i = startIdx; i <= endIdx; i++) {
    const basePrice = 50 + Math.floor(Math.random() * 150);
    const discount = Math.random() > 0.7 ? (8 + Math.floor(Math.random() * 2)) + '.' + (Math.floor(Math.random() * 10)) : null;
    const price = discount ? Math.floor(basePrice * parseFloat(discount) / 10) : basePrice;
    
    products.push({
      id: `product-${i}`,
      name: `${keyword || '游戏点卡'} ${i}00元 ${discount ? discount + '折优惠' : ''}`,
      description: `官方正版${keyword || '游戏'}充值卡，支持各种游戏及服务的充值。`,
      image: `/images/products/${i % 10 + 1}.jpg`,
      price: price,
      originalPrice: discount ? basePrice : null,
      discount: discount,
      category: ['游戏点卡', '视频会员', '音乐会员', '软件激活'][Math.floor(Math.random() * 4)],
      brand: ['腾讯', '网易', '盛大', '完美世界', '暴雪'][Math.floor(Math.random() * 5)],
      rating: (4 + Math.random()).toFixed(1),
      reviewCount: 100 + Math.floor(Math.random() * 900),
      sales: 1000 + Math.floor(Math.random() * 9000),
      tags: ['官方授权', '自动发货', '即时到账', '特价优惠', '新用户专享'].filter(() => Math.random() > 0.5)
    });
  }
  
  // 根据排序方式排序
  if (sort_by === 'price_asc') {
    products.sort((a, b) => a.price - b.price);
  } else if (sort_by === 'price_desc') {
    products.sort((a, b) => b.price - a.price);
  } else if (sort_by === 'sales_desc') {
    products.sort((a, b) => b.sales - a.sales);
  } else if (sort_by === 'rating_desc') {
    products.sort((a, b) => b.rating - a.rating);
  }
  
  // 模拟分面数据
  const facets = {
    categories: [
      { id: 1, name: '游戏点卡', count: 150 },
      { id: 2, name: '手机充值', count: 120 },
      { id: 3, name: '视频会员', count: 80 },
      { id: 4, name: '音乐会员', count: 60 },
      { id: 5, name: '软件激活', count: 40 }
    ],
    brands: [
      { id: 1, name: '腾讯', count: 90 },
      { id: 2, name: '网易', count: 60 },
      { id: 3, name: '盛大', count: 40 },
      { id: 4, name: '完美世界', count: 30 },
      { id: 5, name: '暴雪', count: 25 }
    ],
    tags: [
      { id: 1, name: '官方授权', count: 200 },
      { id: 2, name: '自动发货', count: 180 },
      { id: 3, name: '即时到账', count: 150 },
      { id: 4, name: '特价优惠', count: 80 },
      { id: 5, name: '新用户专享', count: 50 }
    ]
  };
  
  return {
    products,
    total,
    page,
    page_size,
    facets
  };
}

// 模拟搜索建议
function getMockSuggestions(keyword) {
  if (!keyword) return [];
  
  const suggestionTemplates = [
    '{{keyword}} 充值卡',
    '{{keyword}} 点卡',
    '{{keyword}} 会员',
    '{{keyword}} 优惠',
    '{{keyword}} 折扣',
    '{{keyword}} 100元',
    '{{keyword}} 50元',
    '{{keyword}} 官方'
  ];
  
  const brandSuggestions = [
    '腾讯 {{keyword}}',
    '网易 {{keyword}}',
    '盛大 {{keyword}}',
    '完美世界 {{keyword}}',
    '暴雪 {{keyword}}'
  ];
  
  const suggestions = [];
  
  // 生成基于关键词的建议
  suggestionTemplates.forEach((template, index) => {
    if (index < 5) { // 最多5个相关建议
      suggestions.push({
        text: template.replace('{{keyword}}', keyword),
        category: '相关搜索',
        score: 0.9 - (index * 0.1)
      });
    }
  });
  
  // 生成品牌建议
  brandSuggestions.forEach((template, index) => {
    if (index < 3) { // 最多3个品牌建议
      suggestions.push({
        text: template.replace('{{keyword}}', keyword),
        category: '品牌',
        score: 0.8 - (index * 0.1)
      });
    }
  });
  
  // 按分数排序
  suggestions.sort((a, b) => b.score - a.score);
  
  return suggestions;
}

// 默认导出
// 搜索服务
import axios from 'axios';
import { storageService } from './storageService';

// API 基础配置
const API_BASE_URL = process.env.VUE_APP_API_BASE_URL || '/api';
const SEARCH_ENDPOINT = `${API_BASE_URL}/search`;
const SUGGESTIONS_ENDPOINT = `${API_BASE_URL}/search/suggestions`;
const POPULAR_SEARCHES_ENDPOINT = `${API_BASE_URL}/search/popular`;

// 创建axios实例
const apiClient = axios.create({
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器
apiClient.interceptors.request.use(
  config => {
    // 添加用户ID（如果有）
    const userId = storageService.get('user_id');
    if (userId) {
      config.headers['X-User-ID'] = userId;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// 响应拦截器
apiClient.interceptors.response.use(
  response => {
    return response.data;
  },
  error => {
    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

export const searchService = {
  /**
   * 执行搜索
   * @param {Object} params - 搜索参数
   * @param {string} params.keyword - 搜索关键词
   * @param {number} params.page - 页码
   * @param {number} params.page_size - 每页数量
   * @param {string} params.sort_by - 排序方式
   * @param {number} params.price_min - 最低价格
   * @param {number} params.price_max - 最高价格
   * @param {Array} params.categories - 分类ID数组
   * @param {Array} params.brands - 品牌ID数组
   * @param {number} params.rating - 最低评分
   * @param {Array} params.tags - 标签ID数组
   * @returns {Promise} 搜索结果
   */
  search: async (params) => {
    try {
      const response = await apiClient.get(SEARCH_ENDPOINT, { params });
      return response;
    } catch (error) {
      console.error('Search failed:', error);
      // 返回模拟数据
      return getMockSearchResults(params);
    }
  },
  
  /**
   * 获取搜索建议
   * @param {string} keyword - 搜索关键词
   * @returns {Promise} 搜索建议列表
   */
  getSuggestions: async (keyword) => {
    try {
      const response = await apiClient.get(SUGGESTIONS_ENDPOINT, {
        params: { keyword }
      });
      return response.suggestions || [];
    } catch (error) {
      console.error('Get suggestions failed:', error);
      // 返回模拟建议数据
      return getMockSuggestions(keyword);
    }
  },
  
  /**
   * 获取热门搜索
   * @returns {Promise} 热门搜索列表
   */
  getPopularSearches: async () => {
    try {
      const response = await apiClient.get(POPULAR_SEARCHES_ENDPOINT);
      return response.popular_searches || [];
    } catch (error) {
      console.error('Get popular searches failed:', error);
      // 返回默认热门搜索
      return [
        '腾讯Q币',
        '网易一卡通',
        '魔兽世界',
        '英雄联盟',
        '王者荣耀',
        '完美世界',
        '盛大游戏',
        '穿越火线'
      ];
    }
  },
  
  /**
   * 记录搜索行为
   * @param {string} keyword - 搜索关键词
   * @param {string} action - 行为类型 (search, click_suggestion, etc.)
   */
  trackSearchEvent: async (keyword, action = 'search') => {
    try {
      await apiClient.post(`${API_BASE_URL}/analytics/search-event`, {
        keyword,
        action,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      // 分析事件失败不影响主要功能
      console.warn('Track search event failed:', error);
    }
  },
  
  /**
   * 获取搜索历史
   * @returns {Array} 搜索历史列表
   */
  getSearchHistory: () => {
    return storageService.get('search_history') || [];
  },
  
  /**
   * 保存搜索历史
   * @param {string} keyword - 搜索关键词
   * @param {number} maxItems - 最大保存数量
   */
  saveSearchHistory: (keyword, maxItems = 10) => {
    if (!keyword.trim()) return;
    
    let history = storageService.get('search_history') || [];
    
    // 移除重复项
    history = history.filter(item => item !== keyword);
    
    // 添加到开头
    history.unshift(keyword);
    
    // 限制数量
    if (history.length > maxItems) {
      history = history.slice(0, maxItems);
    }
    
    storageService.set('search_history', history);
  },
  
  /**
   * 清除搜索历史
   */
  clearSearchHistory: () => {
    storageService.remove('search_history');
  }
};

// 模拟搜索结果
function getMockSearchResults(params) {
  const { keyword = '', page = 1, page_size = 20, sort_by = 'relevance' } = params;
  
  // 模拟产品数据
  const products = [];
  const total = 120;
  const startIdx = (page - 1) * page_size + 1;
  const endIdx = Math.min(startIdx + page_size - 1, total);
  
  // 生成模拟产品
  for (let i = startIdx; i <= endIdx; i++) {
    const basePrice = 50 + Math.floor(Math.random() * 150);
    const discount = Math.random() > 0.7 ? (8 + Math.floor(Math.random() * 2)) + '.' + (Math.floor(Math.random() * 10)) : null;
    const price = discount ? Math.floor(basePrice * parseFloat(discount) / 10) : basePrice;
    
    products.push({
      id: `product-${i}`,
      name: `${keyword || '游戏点卡'} ${i}00元 ${discount ? discount + '折优惠' : ''}`,
      description: `官方正版${keyword || '游戏'}充值卡，支持各种游戏及服务的充值。`,
      image: `/images/products/${i % 10 + 1}.jpg`,
      price: price,
      originalPrice: discount ? basePrice : null,
      discount: discount,
      category: ['游戏点卡', '视频会员', '音乐会员', '软件激活'][Math.floor(Math.random() * 4)],
      brand: ['腾讯', '网易', '盛大', '完美世界', '暴雪'][Math.floor(Math.random() * 5)],
      rating: (4 + Math.random()).toFixed(1),
      reviewCount: 100 + Math.floor(Math.random() * 900),
      sales: 1000 + Math.floor(Math.random() * 9000),
      tags: ['官方授权', '自动发货', '即时到账', '特价优惠', '新用户专享'].filter(() => Math.random() > 0.5)
    });
  }
  
  // 根据排序方式排序
  if (sort_by === 'price_asc') {
    products.sort((a, b) => a.price - b.price);
  } else if (sort_by === 'price_desc') {
    products.sort((a, b) => b.price - a.price);
  } else if (sort_by === 'sales_desc') {
    products.sort((a, b) => b.sales - a.sales);
  } else if (sort_by === 'rating_desc') {
    products.sort((a, b) => b.rating - a.rating);
  }
  
  // 模拟分面数据
  const facets = {
    categories: [
      { id: 1, name: '游戏点卡', count: 150 },
      { id: 2, name: '手机充值', count: 120 },
      { id: 3, name: '视频会员', count: 80 },
      { id: 4, name: '音乐会员', count: 60 },
      { id: 5, name: '软件激活', count: 40 }
    ],
    brands: [
      { id: 1, name: '腾讯', count: 90 },
      { id: 2, name: '网易', count: 60 },
      { id: 3, name: '盛大', count: 40 },
      { id: 4, name: '完美世界', count: 30 },
      { id: 5, name: '暴雪', count: 25 }
    ],
    tags: [
      { id: 1, name: '官方授权', count: 200 },
      { id: 2, name: '自动发货', count: 180 },
      { id: 3, name: '即时到账', count: 150 },
      { id: 4, name: '特价优惠', count: 80 },
      { id: 5, name: '新用户专享', count: 50 }
    ]
  };
  
  return {
    products,
    total,
    page,
    page_size,
    facets
  };
}

// 模拟搜索建议
function getMockSuggestions(keyword) {
  if (!keyword) return [];
  
  const suggestionTemplates = [
    '{{keyword}} 充值卡',
    '{{keyword}} 点卡',
    '{{keyword}} 会员',
    '{{keyword}} 优惠',
    '{{keyword}} 折扣',
    '{{keyword}} 100元',
    '{{keyword}} 50元',
    '{{keyword}} 官方'
  ];
  
  const brandSuggestions = [
    '腾讯 {{keyword}}',
    '网易 {{keyword}}',
    '盛大 {{keyword}}',
    '完美世界 {{keyword}}',
    '暴雪 {{keyword}}'
  ];
  
  const suggestions = [];
  
  // 生成基于关键词的建议
  suggestionTemplates.forEach((template, index) => {
    if (index < 5) { // 最多5个相关建议
      suggestions.push({
        text: template.replace('{{keyword}}', keyword),
        category: '相关搜索',
        score: 0.9 - (index * 0.1)
      });
    }
  });
  
  // 生成品牌建议
  brandSuggestions.forEach((template, index) => {
    if (index < 3) { // 最多3个品牌建议
      suggestions.push({
        text: template.replace('{{keyword}}', keyword),
        category: '品牌',
        score: 0.8 - (index * 0.1)
      });
    }
  });
  
  // 按分数排序
  suggestions.sort((a, b) => b.score - a.score);
  
  return suggestions;
}

export default searchService;