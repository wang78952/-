// 推荐服务
import axios from 'axios';
import { storageService } from './storageService';

// API 基础配置
const API_BASE_URL = process.env.VUE_APP_API_BASE_URL || '/api';
const RECOMMENDATION_ENDPOINT = `${API_BASE_URL}/recommendations`;

// 创建axios实例
const apiClient = axios.create({
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器
apiClient.interceptors.request.use(
  config => {
    // 添加用户ID（如果有）
    const userId = storageService.get('user_id');
    if (userId) {
      config.headers['X-User-ID'] = userId;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// 响应拦截器
apiClient.interceptors.response.use(
  response => {
    return response.data;
  },
  error => {
    console.error('Recommendation API Error:', error);
    return Promise.reject(error);
  }
);

export const recommendationService = {
  /**
   * 获取推荐产品列表
   * @param {Object} params - 推荐参数
   * @param {string} params.type - 推荐类型 (popular, related, recently_viewed, for_you)
   * @param {string} params.product_id - 产品ID（用于相关推荐）
   * @param {number} params.count - 推荐产品数量
   * @param {Array} params.categories - 类别过滤
   * @param {number} params.min_price - 最低价格
   * @param {number} params.max_price - 最高价格
   * @returns {Promise} 推荐产品列表
   */
  getRecommendations: async (params = {}) => {
    try {
      const response = await apiClient.get(RECOMMENDATION_ENDPOINT, { params });
      return response.products || [];
    } catch (error) {
      console.error('Failed to get recommendations:', error);
      // 返回模拟数据
      return getMockRecommendations(params);
    }
  },

  /**
   * 获取热门推荐（基于销量和评分）
   * @param {number} count - 返回数量
   * @returns {Promise} 热门产品列表
   */
  getPopular: async (count = 10) => {
    return this.getRecommendations({ type: 'popular', count });
  },

  /**
   * 获取相关推荐
   * @param {string} productId - 当前产品ID
   * @param {number} count - 返回数量
   * @returns {Promise} 相关产品列表
   */
  getRelated: async (productId, count = 6) => {
    return this.getRecommendations({ type: 'related', product_id: productId, count });
  },

  /**
   * 获取个性化推荐（基于用户行为）
   * @param {number} count - 返回数量
   * @returns {Promise} 个性化推荐产品列表
   */
  getForYou: async (count = 10) => {
    return this.getRecommendations({ type: 'for_you', count });
  },

  /**
   * 获取最近浏览的产品推荐
   * @param {number} count - 返回数量
   * @returns {Promise} 最近浏览产品列表
   */
  getRecentlyViewed: async (count = 10) => {
    try {
      const response = await apiClient.get(`${RECOMMENDATION_ENDPOINT}/recently-viewed`, { params: { count } });
      return response.products || [];
    } catch (error) {
      console.error('Failed to get recently viewed products:', error);
      // 返回本地存储的浏览历史
      return getLocalRecentlyViewed(count);
    }
  },

  /**
   * 记录产品浏览事件
   * @param {string} productId - 产品ID
   * @param {string} action - 操作类型 (view, add_to_cart, purchase)
   */
  trackProductEvent: async (productId, action = 'view') => {
    try {
      await apiClient.post(`${API_BASE_URL}/analytics/product-event`, {
        product_id: productId,
        action,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.warn('Failed to track product event:', error);
    }
  },

  /**
   * 添加产品到本地浏览历史
   * @param {Object} product - 产品信息
   */
  addToRecentlyViewed: (product) => {
    if (!product || !product.id) return;
    
    let recentlyViewed = storageService.get('recently_viewed') || [];
    
    // 移除重复项
    recentlyViewed = recentlyViewed.filter(item => item.id !== product.id);
    
    // 添加到开头
    recentlyViewed.unshift({
      id: product.id,
      name: product.name,
      image: product.image,
      price: product.price,
      viewed_at: new Date().toISOString()
    });
    
    // 限制数量
    if (recentlyViewed.length > 20) {
      recentlyViewed = recentlyViewed.slice(0, 20);
    }
    
    storageService.set('recently_viewed', recentlyViewed);
  },

  /**
   * 清除本地浏览历史
   */
  clearRecentlyViewed: () => {
    storageService.remove('recently_viewed');
  },

  /**
   * 获取推荐配置
   * @returns {Object} 推荐配置
   */
  getRecommendationConfig: () => {
    return {
      relatedProducts: {
        enabled: true,
        displayCount: 6,
        title: '您可能还喜欢'
      },
      popularProducts: {
        enabled: true,
        displayCount: 10,
        title: '热门推荐'
      },
      recentlyViewed: {
        enabled: true,
        displayCount: 8,
        title: '最近浏览'
      },
      personalizedRecommendations: {
        enabled: true,
        displayCount: 12,
        title: '为您推荐'
      }
    };
  }
};

// 模拟推荐数据
function getMockRecommendations(params = {}) {
  const { type = 'popular', product_id, count = 10, categories = [] } = params;
  
  // 模拟产品数据
  const products = [];
  const productCount = Math.min(count, 20); // 最大20个
  
  // 生成模拟产品
  for (let i = 1; i <= productCount; i++) {
    const basePrice = 30 + Math.floor(Math.random() * 170);
    const discount = Math.random() > 0.75 ? (7 + Math.floor(Math.random() * 3)) + '.' + (Math.floor(Math.random() * 10)) : null;
    const price = discount ? Math.floor(basePrice * parseFloat(discount) / 10) : basePrice;
    
    const allCategories = ['游戏点卡', '视频会员', '音乐会员', '软件激活', '通讯充值', '云服务'];
    const category = categories.length > 0 ? categories[Math.floor(Math.random() * categories.length)] : allCategories[Math.floor(Math.random() * allCategories.length)];
    
    const allBrands = ['腾讯', '网易', '盛大', '完美世界', '暴雪', '爱奇艺', '优酷', 'QQ音乐', '网易云音乐'];
    
    // 根据推荐类型调整数据分布
    let rating = 0, sales = 0;
    if (type === 'popular') {
      // 热门推荐：更高的销量和评分
      rating = (4.2 + Math.random() * 0.8).toFixed(1);
      sales = 10000 + Math.floor(Math.random() * 90000);
    } else if (type === 'related' && product_id) {
      // 相关推荐：模拟与当前产品相似
      rating = (3.8 + Math.random() * 1.2).toFixed(1);
      sales = 5000 + Math.floor(Math.random() * 45000);
    } else if (type === 'for_you') {
      // 个性化推荐：多样化的评分和销量
      rating = (3.5 + Math.random() * 1.5).toFixed(1);
      sales = 1000 + Math.floor(Math.random() * 49000);
    } else {
      // 默认：中等评分和销量
      rating = (4 + Math.random()).toFixed(1);
      sales = 3000 + Math.floor(Math.random() * 27000);
    }
    
    products.push({
      id: `rec-product-${i}-${Date.now()}`,
      name: `${category} ${type === 'popular' ? '热门' : type === 'for_you' ? '精选' : ''}${i}00元 ${discount ? discount + '折优惠' : ''}`,
      description: `官方授权${category}，支持各种游戏及服务的充值。${type === 'related' && product_id ? '与您浏览的产品相关' : ''}`,
      image: `/images/products/${i % 10 + 1}.jpg`,
      price: price,
      originalPrice: discount ? basePrice : null,
      discount: discount,
      category: category,
      brand: allBrands[Math.floor(Math.random() * allBrands.length)],
      rating: rating,
      reviewCount: 200 + Math.floor(Math.random() * 1800),
      sales: sales,
      tags: ['官方授权', '自动发货', '即时到账', '特价优惠', '新用户专享'].filter(() => Math.random() > 0.5)
    });
  }
  
  return products;
}

// 获取本地最近浏览的产品
function getLocalRecentlyViewed(count = 10) {
  const recentlyViewed = storageService.get('recently_viewed') || [];
  return recentlyViewed.slice(0, count);
}

export default recommendationService;