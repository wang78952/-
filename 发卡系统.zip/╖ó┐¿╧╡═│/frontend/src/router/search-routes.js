// 搜索和推荐相关路由配置

// 懒加载组件
const SearchBox = () => import('@/components/Search/SearchBox.vue');
const SearchResults = () => import('@/components/Search/SearchResults.vue');
const ProductRecommendations = () => import('@/components/Recommendation/ProductRecommendations.vue');

// 搜索相关路由
const searchRoutes = [
  {
    path: '/search',
    name: 'SearchResults',
    component: SearchResults,
    meta: {
      title: '搜索结果',
      keepAlive: true,
      requiresAuth: false
    },
    props: true
  },
  {
    path: '/search/category/:categoryId',
    name: 'CategorySearch',
    component: SearchResults,
    meta: {
      title: '分类搜索',
      keepAlive: true,
      requiresAuth: false
    },
    props: true
  },
  {
    path: '/search/brand/:brandId',
    name: 'BrandSearch',
    component: SearchResults,
    meta: {
      title: '品牌搜索',
      keepAlive: true,
      requiresAuth: false
    },
    props: true
  },
  {
    path: '/search/tag/:tagId',
    name: 'TagSearch',
    component: SearchResults,
    meta: {
      title: '标签搜索',
      keepAlive: true,
      requiresAuth: false
    },
    props: true
  },
  {
    path: '/recommendations',
    name: 'AllRecommendations',
    component: ProductRecommendations,
    meta: {
      title: '全部推荐',
      keepAlive: true,
      requiresAuth: false
    },
    props: {
      type: 'all'
    }
  },
  {
    path: '/recommendations/popular',
    name: 'PopularProducts',
    component: ProductRecommendations,
    meta: {
      title: '热门推荐',
      keepAlive: true,
      requiresAuth: false
    },
    props: {
      type: 'popular'
    }
  },
  {
    path: '/recommendations/for-you',
    name: 'PersonalizedRecommendations',
    component: ProductRecommendations,
    meta: {
      title: '为您推荐',
      keepAlive: true,
      requiresAuth: false
    },
    props: {
      type: 'for_you'
    }
  },
  {
    path: '/recommendations/recently-viewed',
    name: 'RecentlyViewed',
    component: ProductRecommendations,
    meta: {
      title: '最近浏览',
      keepAlive: true,
      requiresAuth: false
    },
    props: {
      type: 'recently_viewed'
    }
  }
];

// 全局组件配置
export const globalComponents = [
  {
    name: 'SearchBox',
    component: SearchBox
  },
  {
    name: 'ProductRecommendations',
    component: ProductRecommendations
  }
];

// 导航守卫 - 搜索相关
export const searchNavigationGuard = (to, from, next) => {
  // 设置页面标题
  if (to.params.keyword) {
    to.meta.title = `${to.params.keyword} - 搜索结果`;
  } else if (to.params.categoryName) {
    to.meta.title = `${to.params.categoryName} - 分类搜索`;
  } else if (to.params.brandName) {
    to.meta.title = `${to.params.brandName} - 品牌搜索`;
  } else if (to.params.tagName) {
    to.meta.title = `${to.params.tagName} - 标签搜索`;
  }
  
  next();
};

// 动态路由配置
export const setupSearchRoutes = (router) => {
  // 添加搜索相关路由
  searchRoutes.forEach(route => {
    router.addRoute(route);
  });
  
  // 注册全局组件
  const app = router.app;
  if (app) {
    globalComponents.forEach(({ name, component }) => {
      app.component(name, component);
    });
  }
  
  // 添加导航守卫
  router.beforeEach(searchNavigationGuard);
};

// 导出默认路由
export default searchRoutes;

// 搜索路由辅助函数
export const searchRouteHelpers = {
  /**
   * 生成搜索路由
   * @param {Object} params - 搜索参数
   * @returns {Object} 路由对象
   */
  generateSearchRoute: (params) => {
    const route = { name: 'SearchResults', params: {} };
    
    // 添加搜索参数
    if (params.keyword) route.params.keyword = params.keyword;
    if (params.page) route.params.page = params.page;
    if (params.sortBy) route.params.sortBy = params.sortBy;
    if (params.priceMin) route.params.priceMin = params.priceMin;
    if (params.priceMax) route.params.priceMax = params.priceMax;
    if (params.categoryId) route.params.categoryId = params.categoryId;
    if (params.brandId) route.params.brandId = params.brandId;
    if (params.rating) route.params.rating = params.rating;
    if (params.tags) route.params.tags = params.tags;
    
    return route;
  },
  
  /**
   * 生成推荐路由
   * @param {string} type - 推荐类型
   * @returns {Object} 路由对象
   */
  generateRecommendationRoute: (type) => {
    const routeMapping = {
      'popular': 'PopularProducts',
      'for_you': 'PersonalizedRecommendations',
      'recently_viewed': 'RecentlyViewed'
    };
    
    return {
      name: routeMapping[type] || 'AllRecommendations',
      params: { type }
    };
  },
  
  /**
   * 获取搜索历史路由
   * @returns {Array} 历史路由列表
   */
  getSearchHistoryRoutes: () => {
    try {
      // 从本地存储获取搜索历史
      const searchHistory = JSON.parse(localStorage.getItem('search_history') || '[]');
      
      return searchHistory.map(keyword => ({
        name: 'SearchResults',
        params: { keyword },
        text: keyword
      }));
    } catch (error) {
      console.error('Error getting search history routes:', error);
      return [];
    }
  }
};