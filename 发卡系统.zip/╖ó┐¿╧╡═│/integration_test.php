<?php
/**
 * 整合测试脚本
 * 测试一键安装向导、支付配置和1分钱测试支付功能
 */

// 显示测试标题
echo "===== 智能发卡系统整合测试 =====\n";

// 测试结果数组
$testResults = [];

// 测试文件1: 支付配置页面
echo "\n[测试1] 支付配置页面 (payment_config.php)\n";
echo "------------------------------------------\n";
try {
    // 模拟环境检测
    $envCheck = [
        'phpVersion' => phpversion(),
        'hasPDO' => extension_loaded('pdo'),
        'hasCurl' => extension_loaded('curl'),
        'configFileExists' => file_exists('d:/迅雷下载/发卡系统/admin/payment_config.php'),
        'alipayClassExists' => file_exists('d:/迅雷下载/发卡系统/includes/AlipayPayment.php'),
        'wechatClassExists' => file_exists('d:/迅雷下载/发卡系统/includes/WechatPayment.php'),
    ];
    
    echo "✓ 文件存在检查：" . ($envCheck['configFileExists'] ? "成功" : "失败") . "\n";
    echo "✓ PHP版本: " . $envCheck['phpVersion'] . "\n";
    echo "✓ 必要扩展: " . ($envCheck['hasPDO'] ? "PDO可用" : "PDO缺失") . ", " . ($envCheck['hasCurl'] ? "CURL可用" : "CURL缺失") . "\n";
    echo "✓ 支付类文件：" . ($envCheck['alipayClassExists'] ? "AlipayPayment.php存在" : "AlipayPayment.php缺失") . ", " . ($envCheck['wechatClassExists'] ? "WechatPayment.php存在" : "WechatPayment.php缺失") . "\n";
    
    $testResults['paymentConfig'] = true;
    echo "✓ 支付配置页面测试通过\n";
} catch (Exception $e) {
    echo "✗ 支付配置页面测试失败: " . $e->getMessage() . "\n";
    $testResults['paymentConfig'] = false;
}

// 测试文件2: 支付类测试
echo "\n\n[测试2] 支付类测试 (AlipayPayment.php & WechatPayment.php)\n";
echo "------------------------------------------\n";
try {
    // 检查1分钱测试支付方法是否存在
    $alipayTestMethodExists = false;
    $wechatTestMethodExists = false;
    
    if (file_exists('d:/迅雷下载/发卡系统/includes/AlipayPayment.php')) {
        $alipayContent = file_get_contents('d:/迅雷下载/发卡系统/includes/AlipayPayment.php');
        $alipayTestMethodExists = strpos($alipayContent, 'createTestPayment') !== false;
    }
    
    if (file_exists('d:/迅雷下载/发卡系统/includes/WechatPayment.php')) {
        $wechatContent = file_get_contents('d:/迅雷下载/发卡系统/includes/WechatPayment.php');
        $wechatTestMethodExists = strpos($wechatContent, 'createTestPayment') !== false;
    }
    
    echo "✓ 支付宝测试支付方法: " . ($alipayTestMethodExists ? "已实现" : "未实现") . "\n";
    echo "✓ 微信测试支付方法: " . ($wechatTestMethodExists ? "已实现" : "未实现") . "\n";
    
    $testResults['paymentClasses'] = $alipayTestMethodExists && $wechatTestMethodExists;
    echo "✓ 支付类测试" . ($testResults['paymentClasses'] ? "通过" : "部分失败") . "\n";
} catch (Exception $e) {
    echo "✗ 支付类测试失败: " . $e->getMessage() . "\n";
    $testResults['paymentClasses'] = false;
}

// 测试文件3: 一键安装向导和使用教程
echo "\n\n[测试3] 安装向导和使用教程测试\n";
echo "------------------------------------------\n";
try {
    $guideExists = file_exists('d:/迅雷下载/发卡系统/user_guide.html');
    $installWizardExists = file_exists('d:/迅雷下载/发卡系统/install_wizard.php');
    
    echo "✓ 使用教程页面: " . ($guideExists ? "存在" : "缺失") . "\n";
    echo "✓ 安装向导页面: " . ($installWizardExists ? "存在" : "缺失") . "\n";
    
    if ($installWizardExists) {
        $wizardContent = file_get_contents('d:/迅雷下载/发卡系统/install_wizard.php');
        $guideLinkExists = strpos($wizardContent, 'user_guide.html') !== false;
        echo "✓ 教程链接: " . ($guideLinkExists ? "已添加" : "未添加") . "\n";
    }
    
    $testResults['installGuide'] = $guideExists && $installWizardExists;
    echo "✓ 安装向导和教程测试" . ($testResults['installGuide'] ? "通过" : "失败") . "\n";
} catch (Exception $e) {
    echo "✗ 安装向导测试失败: " . $e->getMessage() . "\n";
    $testResults['installGuide'] = false;
}

// 汇总测试结果
echo "\n\n====================================\n";
echo "           测试结果汇总           \n";
echo "====================================\n";

$allPassed = true;
foreach ($testResults as $key => $passed) {
    $status = $passed ? "✓ 通过" : "✗ 失败";
    echo "- " . ($key == 'paymentConfig' ? "支付配置页面" : 
                ($key == 'paymentClasses' ? "支付类功能" : "安装向导和教程")) . ": " . $status . "\n";
    if (!$passed) $allPassed = false;
}

echo "\n====================================\n";
echo "整合测试" . ($allPassed ? "✓ 全部通过" : "✗ 部分失败") . "\n";
echo "建议: " . ($allPassed ? "所有功能可以正常使用！" : "请检查失败项并修复") . "\n";
echo "====================================\n";